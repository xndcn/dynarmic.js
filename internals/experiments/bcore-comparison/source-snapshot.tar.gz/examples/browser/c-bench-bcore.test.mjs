import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
const source = fs.readFileSync(new URL('../c-bench/bcore/runtime.js', import.meta.url), 'utf8');
const sha256 = vm.runInNewContext(source + '\nbcoreSha256');
test('synchronous deferred-module verification matches SHA-256 across padding boundaries and large buffers', () => {
  for (const length of [0,1,3,55,56,63,64,65,127,128,129,1048576]) {
    const bytes = Uint8Array.from({length}, (_, i) => (i * 137 + 51) & 255);
    assert.equal(sha256(bytes), createHash('sha256').update(bytes).digest('hex'), String(length));
  }
});
