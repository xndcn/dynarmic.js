# One C workload, selectable browser execution paths

The Pages C lab compiles the same five kernels to ARM32 for dynarmic.js, x86
for v86, and direct WebAssembly. All three use the same Zig-provided Clang
frontend, O2 and scalar settings: vectorization, loop unrolling, fast-math and
floating-point contraction are disabled. There is no libc, allocation or I/O
inside a timed kernel. Each path has 16 MiB of guest or Wasm data memory.

Build the standalone artifacts from the repository root with Python 3.10+ and
the `ziglang` Python package (locally exercised with Zig 0.17.0 / Clang 22.1.8):

```sh
python3 examples/c-bench/build.py \
  --dist build-c-bench/dist --cache build-c-bench/cache
```

The complete page builds these assets through `browser_page`; see the
[browser guide](../browser/README.md). The standalone command leaves the
existing page distribution unchanged. The build also copies the checksum-pinned
official v86 npm release `0.5.473+g315b2b0`, its Wasm engine and license. Subsequent
builds reuse the verified archive. `c-bench-manifest.json` records the exact
compiler binary, common and target flags, commands, input hashes and artifacts.
The distributed `c-bench-v86-LICENSE.txt` combines v86's npm BSD license with
the complete notices for its bundled SoftFloat, Zstandard (including FSE,
Huff0 and xxHash), and MIT-licensed QEMU floppy code. The retained
[third-party notices](licenses/v86-third-party.txt) identify the pinned source
URLs and hashes; their own hash is included in the build manifest.

## Work and verification

Every case uses seed `0x12345678`. Counts below are kernel iterations per call;
they remain identical across all three paths.

| Case | Quick | Full | Timed work |
| --- | ---: | ---: | --- |
| Integer | 4,000,000 | 16,000,000 | Dependent uint32 multiply, XOR and rotate |
| Branch | 1,000,000 | 4,000,000 | Seeded data-dependent choices between distinct non-inlined callees |
| Stream | 8,000,000 | 32,000,000 | Sequential read, update and accumulation over 8,192 words |
| Pointer | 4,000,000 | 16,000,000 | Follow one shuffled 8,192-entry cycle with dependent loads |
| Float | 4,000,000 | 16,000,000 | Seeded binary64 dyadic products and sums |

`bench_init(caseIndex, iterations, seed)` resets input outside timing.
`bench_run()` performs the work and returns its uint32 checksum. Each guest
executes six identical calls: one first call, two discarded warmups and three
measured samples. The page can repeat this in three fresh Worker rounds. JIT
state is retained between calls inside a Worker; a first call may include guest
compilation and is reported separately.

[`reference.py`](reference.py) independently computes expected checksums with
Python integers. For the floating-point case it uses rational integer
numerators, so the oracle does not reuse host floating-point calculations.
The selected dyadic values and accepted iteration limit make all C binary64
products and sums exact. Every call, including warmups, must match the fixed
checksum in `c-bench-reference.json`.

The branch kernel has distinct `noinline` callees to retain conditional control
flow. Generated code was inspected for actual ARM/x86 conditional jumps and
calls, and VFP/SSE2/scalar-Wasm double arithmetic. The build retains compiler
assembly in its cache for further inspection.

## Host protocol

ARM loads the flat binary at `0x10000`; x86 loads a Multiboot ELF at `0x100000`.
Both use stack top `0xff0000` and a mailbox of little-endian 32-bit words at
`0xf000`:

| Words | Meaning |
| --- | --- |
| 0–3 | Request: magic `0x43424e31`, case index 0–4, iteration count, seed |
| 4 | Status: 1 running, 2 complete, 3 invalid request |
| 5 | Number of completed calls, 6 on success |
| 6–11 | Checksums in call order |

ARM records start/end using SVC 3, yielding twelve timestamps, then exits with
SVC 0 and R0 = 0. x86 writes phase 0/1 to port `0xE200` and exit status to
`0xE208`. The host timestamps these markers; input preparation stays outside
them. Direct Wasm exports only `memory`, `bench_init` and `bench_run`, has no
imports, and uses fixed 16 MiB memory without growth. Its host timestamps each
`bench_run` call.

These compare complete execution paths. ARM and x86 instructions, ABI,
floating-point instructions, memory access paths, JIT strategy and scheduling
differ, even with one compiler frontend and shared scalar C. Marker/call
overhead also differs. Preserve the browser, inputs, per-call samples and
per-round results when interpreting ratios; do not attribute a measured ratio
solely to an emulator. Earlier small-count calibration reports are development
evidence, not results for the final profiles above.

## Collect performance measurements

Use `measure.mjs` to execute the ordinary Extended Pages run in five separate
Chromium processes, retaining all raw reports and any failed sessions:

```sh
node examples/c-bench/measure.mjs --browser /path/to/chrome \
  --dist build-em/examples/browser/dist --sessions 5 --output NEW_RESULTS
```

Build first and keep the page files fixed during measurement. The collector
rejects diagnostic/profile hosts and verifies inputs before and after each
session. It does not silently retry or average away failed sessions. Summarize
paired round ratios within each session before combining session medians;
inner measured calls are not independent browser repetitions.

The [recorded five-session comparison](../../internals/measurements/2026-10-31-c-bench-performance/README.md)
contains the analysis script, raw evidence, per-case ratios, first-call and
preparation times, and the separately retained incomplete Chrome 133 attempt.

## Blackfin / bcore comparison

Select **ARM / Blackfin / direct Wasm** to run the same five kernels through
`bfin-elf-gcc` and [op1emu/bcore](https://github.com/op1emu/bcore)'s Wasm backend.
The original ARM / x86 comparison remains available. Each group has three paths
so every runtime occupies each of the three order positions once per case.
The Blackfin mode keeps the same Quick/Extended counts, seeds, independent
reference checksums, six-call protocol, fresh Workers and paired ratios.
`bcore / ARM > 1` means the ARM path takes less time.

Blackfin uses GCC 4.5.3 (ADI 2014R1_45-RC2), `-O2 -mcpu=bf532`, scalar settings
and no libc. This is **not a same-compiler comparison**: the other two paths use
Clang. GCC 4.5 does not support Clang's vectorization switches or
`-ffp-contract=off`; vectorization is disabled with `-fno-tree-vectorize`, and
Blackfin's binary64 operations call libgcc helpers (including `__muldf3` and
`__adddf3`), with no hardware FMA or host floating-point shortcut. The float
result therefore includes software floating-point costs, not just translation.
Read integer/memory and floating-point results separately.

The pinned bcore revision is `df7aee68589424364e74d6cee4def5269721e3e6`.
The host follows OP-1's web defaults: copy-and-patch with hints and split
stencils; 10 cold starts, batches of 32 blocks or 65,536 packets; chaining,
lazy state and loop blocks. After startup the webpage Worker enables remote
LLVM promotion at threshold `100000`, size reference `16`. The compiler Worker
warms each generated function before sending the module back. Tier 1 uses IR
O1 / codegen O2; the light tier-1 pipeline is off. LLVM is split into a deferred
module, loaded by the compiler Worker, and only by the execution Worker if an
unsupported packet requires it. Profiling, chained-block diagnostic counts and
verification are disabled. Runs yield through MessageChannel after an 8 ms
slice, checking the clock every 32 dispatches or 100,000 guest packets. The
chain cap is `2^24`; host cycles, IDLE waits and `SYSCFG=0x30` match OP-1.
RAM uses a page table: bcore cannot use copy-and-patch with FlatMemory's raw
inline path. This measures bare-metal C, not the full OP-1 firmware/device
simulation. These settings are taken from `web/src/op1_web.cpp`, `web/worker.js`,
`web/compile-worker.js` and `src/cpu/cpu.cpp` at op1emu revision
`9ba8d234b561efc77f1894f142b39efbd1f7a2db`. Its host builds with the
upstream-supported Emscripten 4.0.9 and Wasm LLVM 23.1.2, versus the ARM host's
Emscripten 6.0.13. Host code uses Release O3 and the upstream-recommended O1
link. The manifest records these differences.

Blackfin has the same 16 MiB guest RAM, entry `0x10000`, stack `0xff0000` and
mailbox `0xf000`. Guest writes of phase 0/1 to `0x01000000` record real host
monotonic timestamps using `emscripten_get_now`; writing the exit status to
`0x01000004` stops execution. Initialization and input resets remain outside
the timed interval. The host starts with 128 MiB Wasm memory and may grow;
LLVM also compiles guest blocks to separate Wasm modules. This is not a claim
of equal total host memory consumption. Loading, first-call compilation and
warm measurements are shown separately. The execution and compiler Workers
have separate 128 MiB initial memories; the report records both. The split
host downloads roughly 43 MiB of main Wasm and 29 MiB of deferred LLVM,
uncompressed. It loads only when selected. OP-1's Brotli/Service Worker download
cache is not replicated, so preparation timings do not compare download UX.

Two fixed warmup calls may finish before a background promotion arrives.
Every observation exports submitted/installed counts, the first installation's
marker index (0–12; use the installed count to distinguish no installation)
and installations before measured calls.
The page shows the counts in its details. Timings include time spent yielding
and any tier changes within a call; they do not claim pure tier-1 steady state.
A failed compiler Worker invalidates this benchmark, rather than silently
reporting a slower tier-0-only path. See the [configuration audit](OP1-CONFIG.md).

The Pages workflow includes this path. To add it to a local `browser_page`
distribution on Linux x86_64 (Node 24+, Python 3.10+, CMake):

```sh
bash examples/c-bench/setup-bcore.sh build-bcore-tools
python3 examples/c-bench/build-bcore.py \
  --bcore-source build-bcore-tools/bcore \
  --bfin-gcc build-bcore-tools/bfin-elf/bin/bfin-elf-gcc \
  --emsdk build-bcore-tools/wasm-tools/emsdk-4.0.9 \
  --llvm build-bcore-tools/wasm-tools/llvm-23.1.2 \
  --dist build-em/examples/browser/dist --cache build-c-bench-bcore
```

Alternatively pass existing toolchain paths. The builder requires the pinned,
tracked-clean bcore checkout and builds a source snapshot in its own cache;
it does not change the checkout or reuse unknown upstream build artifacts.
It retains guest ELF/disassembly and packages bcore's source, MIT license,
LLVM/Emscripten/runtime notices, GCC GPLv3 and GCC Runtime Library Exception.
`c-bench-bcore-manifest.json` binds the compiler, libgcc, inputs and artifacts.
Both the page and Worker reject mismatched C sources, and the Worker verifies
the bytes of every bcore executable before running them. Source packaging also
rejects stale Blackfin inputs/artifacts. Rebuild both guest sets after changing
shared sources. A local build without the optional artifacts reports a missing
resource if Blackfin is selected.

Run correctness checks and collect paired performance evidence:

```sh
node tests/browser/verify_bcore_bench.mjs /path/to/chrome \
  build-em/examples/browser/dist build-c-bench-bcore/checks.json
node examples/c-bench/measure.mjs --browser /path/to/chrome \
  --dist build-em/examples/browser/dist --comparison bcore --profile quick \
  --sessions 5 --output NEW_RESULTS
```

Quick is useful for this comparison because binary64 software arithmetic is
much slower than the integer cases; Extended remains available with unchanged
work counts. Use Chrome/Edge 133+ with Wasm tail calls (tested with Chrome 149). The verifier executes all Quick page rounds,
all six Blackfin calls for every Extended case, corrupt-asset rejection,
cancellation, visibility invalidation and mobile layout.

The earlier [LLVM O2 five-session comparison](../../internals/measurements/2026-10-31-bcore-c-bench-performance/README.md)
is retained as a separate, non-default configuration. It must not be presented
as the default copy-and-patch result.

The [web-default five-session comparison](../../internals/measurements/2026-10-31-bcore-web-defaults-performance/README.md)
uses copy-and-patch with background LLVM promotion and records the actual
compilation stage of each observation. It supersedes the LLVM-only setup as
the page default.

## Native backend comparison

The [native harness](native/README.md) runs the same ARM/Blackfin guest binaries
through their x86-64 native JITs, without Wasm. It retains the fixed-work,
six-call checksum protocol and paired repetitions, with separate bcore native
default, CP-without-promotion and LLVM-only configurations.
The [five-session native report](../../internals/measurements/2026-11-01-native-c-bench-performance/README.md)
covers the four integer/memory cases at Extended counts, including raw samples,
first-call costs and exact build provenance.
