#!/usr/bin/env bash
# Optional Linux x86_64 toolchains, isolated from the main Emscripten SDK.
set -euo pipefail
task_root=${1:?Usage: setup-bcore.sh TOOL_DIRECTORY}
mkdir -p "$task_root"
task_root=$(cd "$task_root" && pwd)
revision=df7aee68589424364e74d6cee4def5269721e3e6
if [ ! -d "$task_root/bcore/.git" ]; then
    git clone --no-checkout https://github.com/op1emu/bcore.git "$task_root/bcore"
    git -C "$task_root/bcore" checkout --detach "$revision"
fi
test "$(git -C "$task_root/bcore" rev-parse HEAD)" = "$revision"
test -z "$(git -C "$task_root/bcore" status --porcelain --untracked-files=no)"
if [ ! -f "$task_root/bfin-elf/bin/bfin-elf-gcc" ]; then
    archive="$task_root/blackfin-2014R1_45-RC2.tar.bz2"
    if [ ! -f "$archive" ]; then
        curl -fL --retry 3 --retry-delay 5 \
            'https://master.dl.sourceforge.net/project/adi-toolchain/2014R1/2014R1_45-RC2/x86_64/blackfin-toolchain-elf-gcc-4.5-2014R1_45-RC2.x86_64.tar.bz2?viasf=1' -o "$archive.part"
        mv "$archive.part" "$archive"
    fi
    echo "5ef1a625e4dd127c0eda00b0b0be983a298737281864c83363305ccdd60d3c4c  $archive" | sha256sum --check --status
    task_unpack=$(mktemp -d "$task_root/bfin-unpack.XXXXXX")
    tar xjf "$archive" --strip-components=3 -C "$task_unpack"
    mv "$task_unpack/bfin-elf" "$task_root/bfin-elf"
    rmdir "$task_unpack"
fi
# Pinned upstream setup downloads Emscripten 4.0.9 and checksum-pinned Wasm LLVM 23.1.2.
BCORE_WASM_TOOLS="$task_root/wasm-tools" bash "$task_root/bcore/tools/wasm/setup.sh"
printf 'bcore tools ready: %s\n' "$task_root"
