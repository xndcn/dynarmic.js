// Adapted from op1emu web/src/tier_worker.cpp (MIT, copyright 2026 op1emu).
#include "remote_tier.h"
#include <emscripten.h>
#include <cstdint>
static bcore::RemoteCompiler* compiler;
static bcore::RemoteCode code;
static uint32_t answer[6];
static uint32_t address(const void* p) { return uint32_t(reinterpret_cast<uintptr_t>(p)); }
extern "C" EMSCRIPTEN_KEEPALIVE const uint32_t* bcore_tier_compile(const uint8_t* job, uint32_t size) {
    if (!compiler) compiler = new bcore::RemoteCompiler;
    answer[0] = compiler->compile(job, size, code);
    answer[1] = address(code.object.data());
    answer[2] = uint32_t(code.object.size());
    answer[3] = address(code.name.c_str());
    answer[4] = code.fallthrough_pc;
    answer[5] = address(code.why.c_str());
    return answer;
}
