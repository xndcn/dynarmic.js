The Blackfin guest links libgcc from ADI's GCC 4.5.3 (2014R1_45-RC2).
Retained upstream notices:

- `libgcc-COPYING3.txt`: https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-4.5.3/COPYING3
- `libgcc-RUNTIME-LIBRARY-EXCEPTION.txt`: https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-4.5.3/COPYING.RUNTIME

The guest uses only libgcc's arithmetic helpers, not newlib. The optional
bcore distribution combines these notices with the MIT bcore license and the
installed Wasm LLVM/Emscripten runtime licenses. The manifest records their
hashes and the exact libgcc archive used.
