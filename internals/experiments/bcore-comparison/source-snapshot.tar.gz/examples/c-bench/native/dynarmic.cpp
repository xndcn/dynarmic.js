#include "common.h"
#include <memory>
#include <optional>
#include <dynarmic/interface/A32/a32.h>
#include <dynarmic/interface/A32/config.h>
using namespace Dynarmic;
static std::array<uint8_t, RAM_SIZE> ram;
static std::array<uint8_t*, A32::UserConfig::NUM_PAGE_TABLE_ENTRIES> pages;
static Timings timings;
static A32::Jit* jit;
template<typename T> T read(uint32_t addr) {
    need(addr <= RAM_SIZE-sizeof(T), "ARM read out of bounds");
    T value; std::memcpy(&value, ram.data()+addr, sizeof value); return value;
}
template<typename T> void write(uint32_t addr, T value) {
    need(addr <= RAM_SIZE-sizeof(T), "ARM write out of bounds");
    std::memcpy(ram.data()+addr, &value, sizeof value);
}
struct Callbacks final : A32::UserCallbacks {
    std::optional<uint32_t> MemoryReadCode(uint32_t addr) override { return read<uint32_t>(addr); }
    uint8_t MemoryRead8(uint32_t addr) override { return read<uint8_t>(addr); }
    uint16_t MemoryRead16(uint32_t addr) override { return read<uint16_t>(addr); }
    uint32_t MemoryRead32(uint32_t addr) override { return read<uint32_t>(addr); }
    uint64_t MemoryRead64(uint32_t addr) override { return read<uint64_t>(addr); }
    void MemoryWrite8(uint32_t addr,uint8_t v) override { write(addr,v); }
    void MemoryWrite16(uint32_t addr,uint16_t v) override { write(addr,v); }
    void MemoryWrite32(uint32_t addr,uint32_t v) override { write(addr,v); }
    void MemoryWrite64(uint32_t addr,uint64_t v) override { write(addr,v); }
    bool IsReadOnlyMemory(uint32_t) override { return false; }
    void InterpreterFallback(uint32_t,size_t) override { throw std::runtime_error("ARM interpreter fallback"); }
    void ExceptionRaised(uint32_t,A32::Exception) override { throw std::runtime_error("ARM exception"); }
    void CallSVC(uint32_t svc) override {
        if(svc == 3) timings.mark(timings.count % 2);
        else if(svc == 0) jit->HaltExecution(HaltReason::UserDefined1);
        else throw std::runtime_error("unexpected SVC");
    }
    void AddTicks(uint64_t) override {}
    uint64_t GetTicksRemaining() override { return 1u << 24; }
};
int main(int argc,char** argv) {
    try {
        const double start=now_ms(); Request request(argc,argv); need(request.mode == "default", "ARM mode");
        request.load(ram.data());
        for(size_t i=0;i<RAM_SIZE/4096;++i) pages[i]=ram.data()+i*4096;
        Callbacks callbacks; A32::UserConfig config;
        config.callbacks=&callbacks; config.page_table=&pages;
        // Upstream's safe optimizations, linking and cycle accounting defaults.
        A32::Jit engine(config); jit=&engine;
        engine.Regs()[15]=0x10000; engine.SetCpsr(0x1f);
        const double prepare=now_ms()-start;
        for(;;) {
            const auto reason=engine.Run();
            if(reason == HaltReason::UserDefined1) break;
            need(!reason, "unexpected ARM halt");
        }
        need(engine.Regs()[0] == 0, "ARM guest exit");
        timings.report(request,ram.data(),prepare);
    } catch(const std::exception& e) {std::fprintf(stderr,"%s\n",e.what()); return 1;}
}
