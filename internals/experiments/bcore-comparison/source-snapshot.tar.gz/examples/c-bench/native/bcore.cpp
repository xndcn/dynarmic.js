#include "common.h"
#include "core.h"
#include "flat_memory.h"
#include <sys/resource.h>
#include <sys/syscall.h>
#include <unistd.h>
using namespace bcore;
static CpuState cpu;
static Timings timings;
static uint8_t idle_wake;
class BenchMemory final : public FlatMemory {
public:
    BenchMemory() : FlatMemory(0, RAM_SIZE, &cpu) { enable_page_table(); }
    void write32(uint32_t addr,uint32_t value) override {
        if(addr == RAM_SIZE) timings.mark(value);
        else if(addr == RAM_SIZE+4) {cpu.halted=true;cpu.exit_code=value;cpu.chain_budget=0;}
        else FlatMemory::write32(addr,value);
    }
};
int main(int argc,char** argv) {
    try {
        const double start=now_ms(); Request request(argc,argv);
        const bool native_default=request.mode=="default", cp_only=request.mode=="cp", llvm=request.mode=="llvm";
        need(native_default || cp_only || llvm, "bcore mode");
        cpu_state_init(&cpu); cpu.pc=0x10000;
        cpu.dpregs[14]=cpu.dpregs[15]=cpu.ksp=cpu.usp=0xff0000; cpu.syscfg=0x30;
        BenchMemory memory; request.load(memory.raw_mut());
        Core core(&cpu,&memory);
        core.set_chaining(true); core.set_count_chained(false);
        core.set_chain_filter([](uint32_t pc){return pc != 0xffa00000;});
        core.set_host_cycles(true); core.set_idle_waits(true,&idle_wake);
        core.set_verify(false); core.set_steady_skip(2);
        core.set_copy_patch(!llvm); core.set_copy_patch_hints(true);
        core.set_tiering(native_default ? 30000 : cp_only ? UINT32_MAX : 0,16);
        core.set_light_tier1(native_default);
        // OP-1 native compiles in a lower-priority background thread. No pin
        // beyond the affinity mask shared by every compared process.
        if(native_default) need(core.set_tier_background(true,0,[]{
            if(setpriority(PRIO_PROCESS,static_cast<id_t>(syscall(SYS_gettid)),10)) std::abort();
        }),"background compiler unavailable");
        need(core.init(1,2),"bcore initialization failed");
        const double prepare=now_ms()-start;
        uint64_t cycles=0;
        while(!cpu.halted) {
            cpu.cycles[0]=uint32_t(cycles);cpu.cycles[1]=cpu.cycles[2]=uint32_t(cycles>>32);
            cpu.chain_budget=1u<<24;
            need(core.run(cpu.pc),"bcore run failed");
            cycles+=cpu.chain_packets+cpu.packets;
            cpu.chain_packets=cpu.packets=cpu.chain_blocks=0;cpu.did_jump=false;
        }
        need(cpu.exit_code==0,"Blackfin guest exit");
        timings.report(request,memory.raw(),prepare);
    } catch(const std::exception& e) {std::fprintf(stderr,"%s\n",e.what());return 1;}
}
