#!/usr/bin/env python3
"""Collect paired native C observations, one fresh process/engine per case."""
import argparse,hashlib,json,math,os,platform,statistics,subprocess,time
from pathlib import Path

def record(file):
    b=file.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',type=Path,default=Path('build-c-bench-native'))
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--sessions',type=int,default=5)
    p.add_argument('--rounds',type=int,default=3)
    p.add_argument('--profile',choices=['quick','full'],default='full')
    a=p.parse_args();build=a.build.resolve();out=a.output.resolve()
    assert 1<=a.sessions<=20 and 1<=a.rounds<=4
    out.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((build/'manifest.json').read_text())
    names=[Path(r['path']) for r in manifest['artifacts']]+[build/'manifest.json']
    frozen={str(f):record(f) for f in names}
    for r in manifest['artifacts']:assert frozen[r['path']]=={k:r[k] for k in ['bytes','sha256']}
    ref=json.loads((build/'c-bench-reference.json').read_text())
    cases=[c['id'] for c in ref['cases'][:4]];config=ref['profiles'][a.profile]
    runtimes=['dynarmic','bcore-default','bcore-cp','bcore-llvm']
    def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
    def verify():
        assert {str(f):record(f) for f in names}==frozen,'Artifacts changed during measurement'
    write('experiment.json',dict(schema='dynarmic.js/native-c-bench-performance-v1',startedAt=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        profile=a.profile,sessions=a.sessions,rounds=a.rounds,runtimes=runtimes,cases=cases,build=manifest,reference=ref,artifacts=frozen,
        collector=record(Path(__file__)),environment=dict(platform=platform.platform(),cpu=next((l.split(':',1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),None),
        affinity=sorted(os.sched_getaffinity(0)),cpuCount=os.cpu_count()),
        methodology='Fresh subprocess per observation, 1 first +2 warmup +3 measured calls. Serial tasks with case/runtime order rotation. Pair round medians within a collection session, then summarize five session medians. Sessions are blocks of fresh processes, not browser sessions.'))
    failures=0
    for session in range(a.sessions):
        verify();result=dict(session=session,status='running',loadBefore=os.getloadavg(),observations=[])
        for rnd in range(a.rounds):
            for ci in range(len(cases)):
                case=cases[(ci+rnd+session)%len(cases)]
                offset=(rnd+session+cases.index(case))%len(runtimes)
                for position in range(len(runtimes)):
                    runtime=runtimes[(position+offset)%len(runtimes)]
                    mode='default' if runtime=='dynarmic' else runtime.split('-')[1]
                    host=build/'host'/('c-bench-dynarmic' if runtime=='dynarmic' else 'c-bench-bcore')
                    guest=build/('c-bench-arm.bin' if runtime=='dynarmic' else 'c-bench-bfin.bin')
                    task=dict(runtime=runtime,caseId=case,round=rnd,position=position,iterations=config['iterations'][case],expected=config['expected'][case])
                    cmd=list(map(str,[host,guest,cases.index(case),task['iterations'],task['expected'],mode]))
                    start=time.monotonic()
                    entry=dict(task=task,command=cmd,status='fail')
                    try:
                        proc=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
                        entry.update(exitCode=proc.returncode,stderr=proc.stderr,stdout=proc.stdout,processWallMs=(time.monotonic()-start)*1000)
                        assert proc.returncode==0,proc.stderr
                        data=json.loads(proc.stdout)
                        assert data['ok'] and data['caseIndex']==cases.index(case) and data['iterations']==task['iterations'] and data['expected']==task['expected']
                        assert data['checksums']==[task['expected']]*6
                        assert len(data['samplesMs'])==6 and all(math.isfinite(v) and v>=0 for v in data['samplesMs'])
                        assert statistics.median(data['samplesMs'][3:])>=.1
                        assert math.isfinite(data['prepareMs']) and data['prepareMs']>=0
                        entry.update(result=data,status='pass')
                    except Exception as error:
                        entry['error']=repr(error);failures+=1
                    result['observations'].append(entry)
                    write(f'session-{session}.json',result)
        verify();result.update(status='pass' if all(e['status']=='pass' for e in result['observations']) else 'fail',loadAfter=os.getloadavg())
        write(f'session-{session}.json',result)
        print(result['status'].upper(),session+1,'/',a.sessions,len(result['observations']),'observations',flush=True)
    write('completion.json',dict(verified=failures==0,failedObservations=failures,sessions=a.sessions))
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
