# Native dynarmic / bcore comparison

These Linux x86-64 hosts execute the existing, unchanged C-lab guest binaries:
ARM32 through upstream Dynarmic's native x86-64 JIT, and Blackfin through
bcore's native x86-64 copy-and-patch/LLVM backend. No Wasm or browser is involved.
Only integer, branch, sequential-memory and pointer-chasing cases are included.

Both hosts have 16 MiB guest RAM and use a 4 KiB page table. This avoids giving
one runtime an unchecked flat pointer while the other needs page translation.
Dynarmic uses its upstream safe optimization and cycle-counting defaults; no
fault-based 4 GiB fastmem reservation is enabled. It is the pristine pinned
upstream submodule, not the repository root's Wasm backend built with a native
compiler.

The primary bcore configuration follows OP-1's native defaults, audited at
op1emu `a2ff78e3ec866384225545caa0e77343d754f199`:

- copy-and-patch, hints and split stencils enabled;
- background LLVM promotion at threshold 30000, size reference 16;
- light tier-1 pipeline enabled; LLVM IR O1 / codegen O2 for the normal pipeline;
- compiler thread at nice 10, no separate CPU pin, publication as soon as ready;
- chaining, lazy state, loop blocks, host cycles, IDLE waits and steady skipping
  enabled; chain budget capped at `2^24`; `SYSCFG=0x30`;
- profiling, counted chained blocks, perf events and LLVM verification disabled.

The native backend has no Wasm cold tier, browser event loop or remote compiler
Worker. Like the other C-lab hosts, this is bare-metal computation without
firmware, peripherals, interrupt deadlines or audio pacing. Every tested loop
changes its state; steady skipping is not a shortcut for omitted C work.

Two diagnostic bcore configurations are included: **CP only**, with tier
threshold `UINT32_MAX` and no compiler thread, and **LLVM only**, compiling
directly with IR O1 / codegen O2, without copy-and-patch or promotion. These do
not represent OP-1's native defaults. Keep their results separate.

## Build and run

Build the ordinary C-lab guests and Blackfin guest first (see the parent guide).
Then use Python 3.10+, CMake 3.21+, a native C++20 compiler, Boost development
headers and LLVM 15 development libraries:

```sh
python3 examples/c-bench/native/build.py \
  --bcore-source /path/to/pinned/bcore \
  --dist build-em/examples/browser/dist --cache build-c-bench-native
taskset -c 8,10,12,14 python3 examples/c-bench/native/measure.py \
  --build build-c-bench-native --profile full --sessions 5 --rounds 3 \
  --output NEW_RESULTS
python3 examples/c-bench/native/analyze.py NEW_RESULTS NEW_SUMMARY
```

Choose an affinity mask valid for your host. All processes, including compiler
threads, inherit the same mask. No CPU exclusivity or frequency lock is implied.
Finish builds before collecting timings. Each observation launches a new process
and engine; process launch and host preparation are outside the guest markers.
The first of six calls is retained separately, two calls are warmups, and three
calls are measured. Inputs reset outside each interval. Every checksum must
match the independent C-lab reference.

Five collection sessions each contain three rounds, with serial execution and
rotating case/runtime order. A collection session groups many fresh processes;
it is not a single persistent engine or browser. Four configurations across
three rounds do not occupy every position once within each session. The order
rotates across sessions as well, and the raw report retains each position.

The analyzer takes the median of measured calls per observation, pairs runtimes
within each round, summarizes round ratios within each session, then reports
median/range across sessions. Two fixed warmups do not prove that asynchronous
promotion has completed. Native profiler counters are disabled, so do not infer
the installed tier solely from a timing value. CP-only and LLVM-only results
help interpret this limitation.

`manifest.json` retains guest build provenance, compiler/version/options,
source and binary hashes, the exact stencil generator/data and build flags.
The builder uses a tracked-clean bcore Git snapshot; it leaves the upstream
checkout and its existing builds untouched. ARM and Blackfin remain different
ISAs and use different guest compilers (Clang and bfin GCC respectively), so
this measures complete execution paths, not identical machine instructions.
