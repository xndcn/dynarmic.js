#pragma once
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

constexpr uint32_t RAM_SIZE = 16 * 1024 * 1024, MAILBOX = 0xf000;
inline double now_ms() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
inline void need(bool ok, const char* why) { if (!ok) throw std::runtime_error(why); }
struct Request {
    std::vector<uint8_t> binary;
    uint32_t case_index, iterations, expected;
    std::string mode;
    Request(int argc, char** argv) {
        need(argc == 6, "usage: HOST BINARY CASE ITERATIONS EXPECTED MODE");
        case_index = std::stoul(argv[2]); iterations = std::stoul(argv[3]); expected = std::stoul(argv[4]); mode = argv[5];
        need(case_index < 4 && iterations && iterations <= 32000000, "integer/memory cases only");
        std::ifstream in(argv[1], std::ios::binary);
        need(bool(in), "cannot read guest");
        binary = std::vector<uint8_t>(std::istreambuf_iterator<char>(in), {});
        need(!binary.empty() && binary.size() < RAM_SIZE - 0x10000, "guest size");
    }
    void load(uint8_t* ram) const {
        std::memcpy(ram + 0x10000, binary.data(), binary.size());
        const uint32_t input[] = {0x43424e31, case_index, iterations, 0x12345678};
        std::memcpy(ram + MAILBOX, input, sizeof input);
    }
};
struct Timings {
    std::array<double, 12> marks{};
    unsigned count = 0;
    void mark(unsigned phase) {
        need(count < marks.size() && phase == count % 2, "invalid marker order");
        marks[count++] = now_ms();
    }
    void report(const Request& request, const uint8_t* ram, double prepare_ms) {
        need(count == 12, "missing timing markers");
        uint32_t output[32]; std::memcpy(output, ram + MAILBOX, sizeof output);
        need(output[4] == 2 && output[5] == 6, "incomplete guest result");
        for (unsigned i=0; i<6; ++i) need(output[6+i] == request.expected, "checksum mismatch");
        std::printf("{\"ok\":true,\"caseIndex\":%u,\"iterations\":%u,\"expected\":%u,\"prepareMs\":%.6f,\"samplesMs\":[",
                    request.case_index, request.iterations, request.expected, prepare_ms);
        for (unsigned i=0; i<6; ++i) std::printf("%s%.6f", i ? "," : "", marks[2*i+1]-marks[2*i]);
        std::printf("],\"checksums\":[");
        for (unsigned i=0; i<6; ++i) std::printf("%s%u", i ? "," : "", output[6+i]);
        std::printf("]}\n");
    }
};
