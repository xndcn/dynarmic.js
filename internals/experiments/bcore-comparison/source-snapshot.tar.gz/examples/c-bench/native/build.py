#!/usr/bin/env python3
"""Build native x86-64 hosts against pinned, unmodified emulator sources."""
import argparse,hashlib,io,json,os,shutil,subprocess,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--bcore-source',type=Path,required=True)
p.add_argument('--dist',type=Path,default=ROOT/'build-em/examples/browser/dist')
p.add_argument('--cache',type=Path,default=ROOT/'build-c-bench-native')
p.add_argument('--llvm',type=Path,default=Path('/usr/lib/llvm-15/lib/cmake/llvm'))
p.add_argument('--jobs',type=int,default=8);a=p.parse_args()
cache=a.cache.resolve();cache.mkdir(parents=True,exist_ok=True);dist=a.dist.resolve();src=a.bcore_source.resolve()
commands=[]
def run(cmd):
 cmd=list(map(str,cmd));commands.append(cmd);subprocess.run(cmd,check=True)
def git(folder,*args):return subprocess.check_output(['git','-C',str(folder),*args])
def rec(f):
 b=f.read_bytes();return dict(path=str(f),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
revision='df7aee68589424364e74d6cee4def5269721e3e6'
assert git(src,'rev-parse','HEAD').decode().strip()==revision
assert not git(src,'status','--porcelain','--untracked-files=no')
dyn=ROOT/'externals/dynarmic'
assert not git(dyn,'status','--porcelain','--ignore-submodules=none')
snapshot=cache/('bcore-'+revision);snapshot.mkdir(exist_ok=True)
archive=git(src,'archive',revision)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(snapshot,filter='data')
fixtures=cache/'unused-testsuite';fixtures.mkdir(exist_ok=True)
run(['cmake','-S',HERE,'-B',cache/'host','-DCMAKE_BUILD_TYPE=Release','-DBCORE_SOURCE='+str(snapshot),'-DLLVM_DIR='+str(a.llvm.resolve()),'-DFETCHCONTENT_SOURCE_DIR_BFIN_TESTSUITE='+str(fixtures),'-DBCORE_STENCIL_CACHE_DIR='+str(cache/'stencil-cache')])
run(['cmake','--build',cache/'host','--target','c-bench-dynarmic','c-bench-bcore','-j',a.jobs])
arm=json.loads((dist/'c-bench-manifest.json').read_text());bfin=json.loads((dist/'c-bench-bcore-manifest.json').read_text())
for name,m in [('c-bench-arm.bin',arm),('c-bench-bfin.bin',bfin),('c-bench-reference.json',arm)]:
 r=next(x for x in m['artifacts'] if x['path']==name);actual=rec(dist/name)
 assert all(actual[k]==r[k] for k in ['bytes','sha256'])
 shutil.copyfile(dist/name,cache/name)
for name in ['kernels.c','kernels.h','guest.c']:
 key='examples/c-bench/'+name
 x=next(x for x in arm['sources'] if x['path']==key);y=next(x for x in bfin['inputs'] if x['path']==key)
 assert x==y and x['sha256']==rec(ROOT/key)['sha256']
manifest=dict(schema='dynarmic.js/native-c-bench-build-v1',bcoreRevision=revision,dynarmicRevision=git(dyn,'rev-parse','HEAD').decode().strip(),
 bcoreSourceArchiveSha256=hashlib.sha256(archive).hexdigest(),commands=commands,
 compiler=subprocess.check_output(['c++','--version']).decode().strip(),llvm=str(a.llvm.resolve()),
 llvmVersion=subprocess.check_output(['/usr/lib/llvm-15/bin/llvm-config','--version']).decode().strip(),
 configuration=dict(host='x86-64',buildType='Release',profile=False,guestRamBytes=16777216,memory='4 KiB page table on both hosts; no fault-based fastmem',
  dynarmic='upstream A32 safe defaults, cycle counting on, native x86-64 JIT',
  bcoreDefault='OP-1 native: CP hints/split; background 30000/16; light tier1; LLVM O1/codegen2; steadySkip2; chain cap2^24; compiler nice10',
  bcoreCp='CP only; UINT32_MAX; no background compiler',bcoreLlvm='untiered LLVM O1/codegen2; CP disabled',
  timing='steady_clock at SVC/MMIO markers; first +2 warmups +3 measured; no device/audio pacing'),
 guestBuilds=dict(arm=arm,blackfin=bfin),sources=[rec(x) for x in sorted(HERE.iterdir()) if x.is_file()],
 buildFiles=[rec(cache/'host'/x) for x in ['CMakeCache.txt','CMakeFiles/c-bench-dynarmic.dir/flags.make',
             'CMakeFiles/c-bench-bcore.dir/flags.make','CMakeFiles/c-bench-bcore.dir/link.txt',
             'bcore-upstream/CMakeFiles/bfin-core.dir/flags.make']],
 artifacts=[rec(cache/x) for x in ['host/c-bench-dynarmic','host/c-bench-bcore','c-bench-arm.bin','c-bench-bfin.bin','c-bench-reference.json']],
 stencils=[rec(cache/'host/bcore-upstream'/x) for x in ['bcore-stencilgen','cp_gen/cp_stencils.bin','cp_gen/cp_tables.bin']])
assert not git(dyn,'status','--porcelain','--ignore-submodules=none')
(cache/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Native hosts ready:',cache)
