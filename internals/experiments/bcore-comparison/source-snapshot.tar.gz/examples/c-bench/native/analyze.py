#!/usr/bin/env python3
"""Validate native observations and summarize paired session ratios."""
import argparse,csv,json,math,statistics
from pathlib import Path

def stats(values):
    return dict(samples=values,median=statistics.median(values),min=min(values),max=max(values))
def geom(values):return math.exp(sum(map(math.log,values))/len(values))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    spec=json.loads((a.input/'experiment.json').read_text());completion=json.loads((a.input/'completion.json').read_text())
    assert completion['verified'] and completion['failedObservations']==0
    cases=spec['cases'];runtimes=spec['runtimes'];rounds=spec['rounds'];count=spec['sessions']
    config=spec['reference']['profiles'][spec['profile']]
    ratios=[('bcoreDefaultOverDynarmic','bcore-default','dynarmic'),('bcoreCpOverDynarmic','bcore-cp','dynarmic'),
            ('bcoreLlvmOverDynarmic','bcore-llvm','dynarmic'),('cpOverLlvm','bcore-cp','bcore-llvm')]
    sessions=[];rows=[]
    for i in range(count):
        report=json.loads((a.input/f'session-{i}.json').read_text());assert report['status']=='pass'
        lookup={}
        for entry in report['observations']:
            assert entry['status']=='pass' and entry['exitCode']==0
            t=entry['task'];r=entry['result'];case=t['caseId'];runtime=t['runtime'];rnd=t['round']
            assert case in cases and runtime in runtimes and 0<=rnd<rounds
            assert r['iterations']==config['iterations'][case] and r['expected']==config['expected'][case]
            assert r['checksums']==[config['expected'][case]]*6
            assert len(r['samplesMs'])==6 and all(math.isfinite(v) and v>=0 for v in r['samplesMs'])
            assert math.isfinite(r['prepareMs']) and r['prepareMs']>=0
            assert (case,runtime,rnd) not in lookup
            warm=statistics.median(r['samplesMs'][3:]);assert warm>=.1
            lookup[case,runtime,rnd]=dict(warm=warm,first=r['samplesMs'][0],prepare=r['prepareMs'])
            rows.append([i,rnd,case,runtime,r['iterations'],warm,*r['samplesMs'],r['prepareMs'],entry['processWallMs']])
        assert len(lookup)==len(cases)*len(runtimes)*rounds
        local={};roundRatios={name:[[] for _ in range(rounds)] for name,_,_ in ratios}
        for case in cases:
            item=dict(runtimes={},ratios={})
            for runtime in runtimes:
                item['runtimes'][runtime]={metric:statistics.median([lookup[case,runtime,j][metric] for j in range(rounds)]) for metric in ['warm','first','prepare']}
            for name,num,den in ratios:
                values=[lookup[case,num,j]['warm']/lookup[case,den,j]['warm'] for j in range(rounds)]
                item['ratios'][name]=statistics.median(values)
                for j,v in enumerate(values):roundRatios[name][j].append(v)
            local[case]=item
        sessions.append(dict(session=i,cases=local,overall={name:statistics.median([geom(v) for v in values]) for name,values in roundRatios.items()}))
    summary=dict(schema='dynarmic.js/native-c-bench-summary-v1',profile=spec['profile'],sessions=count,rounds=rounds,
        observations=len(rows),checkedCalls=len(rows)*6,measuredCalls=len(rows)*3,environment=spec['environment'],cases={},overall={})
    for case in cases:
        summary['cases'][case]=dict(iterations=config['iterations'][case],runtimes={runtime:{metric:stats([s['cases'][case]['runtimes'][runtime][metric] for s in sessions]) for metric in ['warm','first','prepare']} for runtime in runtimes},
            ratios={name:stats([s['cases'][case]['ratios'][name] for s in sessions]) for name,_,_ in ratios})
    summary['overall']={name:stats([s['overall'][name] for s in sessions]) for name,_,_ in ratios}
    summary['sessionSummaries']=sessions
    a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (a.output/'samples.csv').open('w') as f:
        w=csv.writer(f,lineterminator='\n');w.writerow(['session','round','case','runtime','iterations','warmMedianMs','firstMs','warmup1Ms','warmup2Ms','measured1Ms','measured2Ms','measured3Ms','prepareMs','processWallMs']);w.writerows(rows)
    print(json.dumps(summary['overall'],indent=2))

if __name__=='__main__':main()
