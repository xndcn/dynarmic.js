// LLVM splitting method from op1emu/web/tools/split-module.mjs (MIT, 2026 op1emu).
// Keep LLVM's constructors reached by init; defer every other LLVM function.
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const [directory, splitter, mode] = process.argv.slice(2);
const dir = path.resolve(directory), stem = path.join(dir, 'c-bench-bcore');
const features = ['--enable-tail-call', '--enable-exception-handling', '--enable-bulk-memory',
  '--enable-nontrapping-float-to-int', '--enable-sign-ext', '--enable-mutable-globals'];
if (mode === 'profile') {
  const instantiate = WebAssembly.instantiate;
  let instrumented;
  WebAssembly.instantiate = async (...args) => {
    const result = await instantiate(...args), instance = result.instance ?? result;
    if (instance.exports.__write_profile) instrumented = instance.exports;
    return result;
  };
  const create = createRequire(import.meta.url)(stem + '.js');
  const module = await create({wasmBinary: fs.readFileSync(stem + '.instrumented.wasm')});
  if (module._bcore_init() !== 0 || !instrumented) throw new Error('Cannot profile bcore startup');
  const size = 64 << 20, at = module._malloc(size);
  const written = instrumented.__write_profile(at, size);
  fs.writeFileSync(stem + '.startup.prof', module.HEAPU8.slice(at, at + written));
} else {
  execFileSync(splitter, [...features, '--instrument', stem + '.wasm.orig', '-o', stem + '.instrumented.wasm'], {stdio: 'inherit'});
  execFileSync(process.execPath, [new URL(import.meta.url).pathname, dir, splitter, 'profile'], {stdio: 'inherit'});
  const printed = execFileSync(splitter, [...features, '--print-profile=' + stem + '.startup.prof', stem + '.wasm.orig'],
    {encoding: 'utf8', maxBuffer: 1 << 30});
  const unescape = name => name.replace(/\\([0-9a-f]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
  const moved = printed.split('\n').filter(line => line.startsWith('- ') && /\bllvm::|^llvm|LLVM/.test(unescape(line.slice(2)))).map(line => line.slice(2));
  if (moved.length < 1000) throw new Error('LLVM split omitted functions');
  fs.writeFileSync(stem + '.deferred-functions.txt', moved.join('\n') + '\n');
  execFileSync(splitter, [...features, stem + '.wasm.orig', '--split-funcs=@' + stem + '.deferred-functions.txt',
    '-o1', stem + '.wasm', '-o2', stem + '.deferred.wasm'], {stdio: 'inherit'});
  console.log('Deferred LLVM functions:', moved.length);
}
