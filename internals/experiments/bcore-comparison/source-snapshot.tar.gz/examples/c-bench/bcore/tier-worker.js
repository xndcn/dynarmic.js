// Adapted from op1emu/web/compile-worker.js (MIT, copyright 2026 op1emu).
// Compiles and warms promotions off the execution Worker's thread.
'use strict';
Error.stackTraceLimit = 0;
let host, dead = false, busy = false;
const jobs = [], memory = new WebAssembly.Memory({initial: 0});
const table = new WebAssembly.Table({initial: 0, element: 'anyfunc'});
const stack = new WebAssembly.Global({value: 'i32', mutable: true}, 0);
function warm(module) {
  const env = Object.create(null);
  env.__linear_memory = memory; env.__indirect_function_table = table; env.__stack_pointer = stack;
  for (const {name, kind} of WebAssembly.Module.imports(module)) if (kind === 'function') env[name] = () => {throw new Error('warming');};
  for (const fn of Object.values(new WebAssembly.Instance(module, {env}).exports)) {
    if (typeof fn === 'function') {try {fn(0, 0);} catch {}}
  }
}
function fail(error) {
  dead = true; host = null; jobs.length = 0;
  postMessage({type: 'dead', why: String(error)});
}
function next() {
  if (dead || busy || !host || !jobs.length) return;
  busy = true;
  setTimeout(() => {
    const {ticket, job} = jobs.shift();
    try {
      const at = host._malloc(job.length); host.HEAPU8.set(job, at);
      let answer;
      try {answer = host._bcore_tier_compile(at, job.length) >>> 2;} finally {host._free(at);}
      const word = i => host.HEAPU32[answer + i] >>> 0;
      if (!word(0)) postMessage({type: 'fail', ticket, why: host.UTF8ToString(word(5))});
      else {
        const module = new WebAssembly.Module(host.HEAPU8.slice(word(1), word(1) + word(2)));
        warm(module);
        postMessage({type: 'code', ticket, module, name: host.UTF8ToString(word(3)), fallthrough: word(4)});
      }
    } catch (error) {fail(error);}
    busy = false; next();
  }, 0);
}
self.onmessage = async ({data}) => {
  if (data.type === 'job') {
    if (dead) postMessage({type: 'fail', ticket: data.ticket, why: 'Compiler Worker failed'});
    else {jobs.push(data); next();}
  } else if (data.type === 'init') {
    try {
      const response = await fetch(data.deferredUrl);
      if (!response.ok) throw new Error('Cannot load deferred LLVM: ' + response.status);
      const bytes = await response.arrayBuffer();
      const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2, '0')).join('');
      if (bytes.byteLength !== data.deferred.bytes || hash !== data.deferred.sha256) throw new Error('Deferred LLVM identity mismatch');
      const deferred = await WebAssembly.compile(bytes);
      const url = URL.createObjectURL(new Blob([data.javascript], {type: 'text/javascript'}));
      try {importScripts(url);} finally {URL.revokeObjectURL(url);}
      host = await createCBenchBcore({print: () => {},
        instantiateWasm(imports, done) {
          WebAssembly.instantiate(data.module, imports).then(instance => done(instance, data.module), fail); return {};
        }, locateFile: name => name,
        loadSplitModule: (_file, imports) => [new WebAssembly.Instance(deferred, imports), deferred]});
      postMessage({type: 'ready', memoryBytes: host.HEAPU8.byteLength, deferredModule: deferred}); next();
    } catch (error) {fail(error);}
  }
};
