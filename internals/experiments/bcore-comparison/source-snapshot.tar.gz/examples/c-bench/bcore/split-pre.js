// Same SPLIT_MODULE initialization fix as op1emu/web/src/split-module-pre.js
// (MIT, copyright 2026 op1emu).
if (Module['instantiateWasm']) {
  var hostInstantiateWasm = Module['instantiateWasm'];
  Module['instantiateWasm'] = (imports, done) => {
    wasmBinaryFile ??= findWasmBinary();
    return hostInstantiateWasm(imports, done);
  };
}
