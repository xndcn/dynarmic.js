#!/usr/bin/env python3
"""Build the optional Blackfin/bcore path, without modifying the upstream checkout."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
REVISION = 'df7aee68589424364e74d6cee4def5269721e3e6'
FLAGS = ['-std=c99', '-O2', '-mcpu=bf532', '-ffreestanding', '-fno-builtin',
         '-fno-strict-aliasing', '-fno-fast-math',
         '-fno-tree-vectorize', '-fno-unroll-loops', '-fno-stack-protector',
         '-fno-pic', '-fno-pie', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
         '-ffunction-sections', '-fdata-sections', '-nostdlib']


def record(path, name=None):
    b = path.read_bytes()
    return dict(path=name or path.name, bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bcore-source', type=Path, required=True, help='Pinned bcore Git checkout')
    p.add_argument('--bfin-gcc', type=Path, required=True)
    p.add_argument('--emsdk', type=Path, required=True, help='Emscripten 4.0.9 SDK root')
    p.add_argument('--llvm', type=Path, required=True, help='Wasm LLVM 23.1.2 package root')
    p.add_argument('--dist', type=Path, default=ROOT / 'build-em/examples/browser/dist')
    p.add_argument('--cache', type=Path, default=ROOT / 'build-c-bench-bcore')
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--stencil-cache', type=Path, help='Reuse stencils only when the generator hash matches')
    a = p.parse_args()
    source, gcc, sdk, llvm, dist, cache = [x.resolve() for x in
        [a.bcore_source, a.bfin_gcc, a.emsdk, a.llvm, a.dist, a.cache]]
    if cache == dist or cache.is_relative_to(dist):
        p.error('Build cache must be outside public dist')
    git = lambda *args: subprocess.check_output(['git', '-C', str(source), *args])
    if git('rev-parse', 'HEAD').decode().strip() != REVISION or git('status', '--porcelain', '--untracked-files=no'):
        p.error('Expected clean tracked bcore source at ' + REVISION)
    cache.mkdir(parents=True, exist_ok=True)
    dist.mkdir(parents=True, exist_ok=True)
    archive = git('archive', '--format=tar', REVISION)
    snapshot = cache / ('source-' + REVISION)
    snapshot.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        tar.extractall(snapshot, filter='data')
    # The upstream testsuite is fetched unconditionally, but this build uses
    # no test fixtures. An empty source override avoids an unpinned Git fetch.
    fixture = cache / 'unused-testsuite'
    fixture.mkdir(exist_ok=True)
    env = dict(os.environ, EM_CONFIG=str(sdk / '.emscripten'))
    commands = []
    def run(cmd):
        cmd = list(map(str, cmd)); commands.append(cmd)
        subprocess.run(cmd, check=True, env=env)
    binary = dist / 'c-bench-bfin.bin'
    elf = cache / 'c-bench-bfin.elf'
    run([gcc, *FLAGS, '-I', HERE, HERE / 'start-bfin.S', HERE / 'guest.c', HERE / 'kernels.c',
         '-Wl,-T,' + str(HERE / 'link-bfin.ld'), '-Wl,--gc-sections', '-o', elf, '-lgcc'])
    objcopy = gcc.with_name(gcc.name.replace('gcc', 'objcopy'))
    objdump = gcc.with_name(gcc.name.replace('gcc', 'objdump'))
    run([objcopy, '-O', 'binary', elf, binary])
    (cache / 'bfin-disassembly.txt').write_bytes(subprocess.check_output([objdump, '-d', elf]))
    run([gcc, *FLAGS, '-S', HERE / 'kernels.c', '-o', cache / 'bfin-kernels.s'])
    em = sdk / 'upstream/emscripten'
    build = cache / 'host'
    run(['cmake', '-S', HERE / 'bcore', '-B', build, '-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_TOOLCHAIN_FILE=' + str(em / 'cmake/Modules/Platform/Emscripten.cmake'),
         '-DLLVM_DIR=' + str(llvm / 'lib/cmake/llvm'), '-DBCORE_SOURCE=' + str(snapshot),
         '-DBCORE_STENCIL_CACHE_DIR=' + str((a.stencil_cache or cache / 'stencil-cache').resolve()),
         '-DCMAKE_CROSSCOMPILING_EMULATOR=' + shutil.which('node'),
         '-DFETCHCONTENT_SOURCE_DIR_BFIN_TESTSUITE=' + str(fixture)])
    run(['cmake', '--build', build, '--target', 'c-bench-bcore', '-j', a.jobs])
    run(['node', HERE / 'bcore/split-module.mjs', build, sdk / 'upstream/bin/wasm-split'])
    for ext in ['js', 'wasm', 'deferred.wasm']:
        shutil.copyfile(build / ('c-bench-bcore.' + ext), dist / ('c-bench-bcore.' + ext))
    for source_name, target in [('runtime.js', 'c-bench-bcore-runtime.js'), ('tier-worker.js', 'c-bench-bcore-tier-worker.js')]:
        shutil.copyfile(HERE / 'bcore' / source_name, dist / target)
    # Retain upstream source and complete notices with the optional host.
    (dist / 'c-bench-bcore-source.tar.gz').write_bytes(
        gzip.compress(git('archive', '--format=tar', '--prefix=bcore/', REVISION), mtime=0))
    notices = [snapshot / 'LICENSE', llvm / 'info/licenses/LICENSE.TXT', em / 'LICENSE',
               HERE / 'licenses/libgcc-COPYING3.txt', HERE / 'licenses/libgcc-RUNTIME-LIBRARY-EXCEPTION.txt']
    notices += [em / name for name in ['system/lib/libc/musl/COPYRIGHT', 'system/lib/libcxx/LICENSE.TXT',
                'system/lib/libcxxabi/LICENSE.TXT', 'system/lib/compiler-rt/LICENSE.TXT', 'system/lib/libunwind/LICENSE.TXT']]
    (dist / 'c-bench-bcore-LICENSE.txt').write_text('\n\n'.join(path.read_text() for path in notices))
    libgcc = Path(subprocess.check_output([gcc, '-mcpu=bf532', '-print-libgcc-file-name']).decode().strip())
    inputs = [HERE / name for name in ['kernels.c', 'kernels.h', 'guest.c', 'start-bfin.S', 'link-bfin.ld',
              'bcore-host.cpp', 'bcore-tier.cpp', 'bcore/CMakeLists.txt', 'bcore/split-pre.js',
              'bcore/split-module.mjs', 'bcore/runtime.js', 'bcore/tier-worker.js', 'build-bcore.py',
              'licenses/libgcc-COPYING3.txt', 'licenses/libgcc-RUNTIME-LIBRARY-EXCEPTION.txt']]
    manifest = dict(schema='dynarmic.js/c-bench-bcore-build-v1',
        source=dict(url='https://github.com/op1emu/bcore', revision=REVISION,
                    gitArchiveSha256=hashlib.sha256(archive).hexdigest()),
        compiler=dict(version=subprocess.check_output([gcc, '--version']).decode().strip(), binary=record(gcc),
                      flags=FLAGS, libgcc=record(libgcc), doubleBits=64, floatingPoint='libgcc software binary64'),
        hostToolchain=dict(emscripten=subprocess.check_output([em / 'em++', '--version'], env=env).decode().strip(),
                           llvm='23.1.2', llvmWasmCodegen=record(llvm / 'lib/libLLVMWebAssemblyCodeGen.a'),
                           buildType='Release', hostCompile='O3', hostLink='O1', splitModule=True),
        stencils=[record(build / 'upstream' / name) for name in ['bcore-stencilgen.js', 'bcore-stencilgen.wasm',
                  'cp_gen/cp_stencils.inc', 'cp_gen/cp_stencils.bin', 'cp_gen/cp_tables.bin']],
        configuration=dict(guestRamBytes=16777216, initialWasmMemoryBytes=134217728,
            llvmOptLevel=1, llvmCodegenLevel=2, chaining=True, countChained=False,
            lazyState=True, loopBlocks=True, copyPatch=True, copyPatchHints=True, stencilSplit=True,
            tiering=100000, tierSizeRef=16, remoteTier=True, lightTier1=False,
            llvmOnDemand=True, coldThreshold=10, coldBatch=32, coldAgePackets=65536, verify=False,
            sliceMs=8, clockRuns=32, clockPackets=100000, maxChainPackets=16777216,
            hostCycles=True, idleWaits=True, steadySkip=0, syscfg=48, splitModule=True,
            memory='page-table RAM; MMIO callbacks', timing='emscripten_get_now at guest MMIO markers'),
        defaultsSource=dict(url='https://github.com/op1emu/op1emu', revision='9ba8d234b561efc77f1894f142b39efbd1f7a2db',
                            files=['web/src/op1_web.cpp', 'src/cpu/cpu.cpp', 'src/cpu/cpu.h', 'web/worker.js',
                                   'web/compile-worker.js', 'web/compile-helpers.js', 'web/CMakeLists.txt']),
        scope='Same C and work counts; bfin GCC differs from Clang. OP-1 web backend defaults: copy-and-patch, cold tier, background LLVM promotion (100000/16), 8 ms slices and split LLVM. Bare-metal 16 MiB RAM, no firmware, device deadlines or audio pacing.',
        inputs=[record(path, str(path.relative_to(ROOT))) for path in inputs],
        noticeInputs=[record(path) for path in notices], commands=commands,
        artifacts=[record(dist / name) for name in ['c-bench-bfin.bin', 'c-bench-bcore.js', 'c-bench-bcore.wasm',
                    'c-bench-bcore.deferred.wasm', 'c-bench-bcore-runtime.js', 'c-bench-bcore-tier-worker.js',
                    'c-bench-bcore-LICENSE.txt', 'c-bench-bcore-source.tar.gz']])
    (dist / 'c-bench-bcore-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('Built optional Blackfin/bcore artifacts:', dist)


if __name__ == '__main__':
    main()
