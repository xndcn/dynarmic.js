// Reuse the existing official benchmark source and adapter unchanged.
'use strict';
let busy = false;
self.onmessage = async ({data}) => {
  if (busy) {postMessage({ok: false, error: 'Worker is busy'}); return;}
  busy = true;
  const {caseId} = data;
  let runtime;
  try {
    const started = performance.now();
    postMessage({type: 'progress', runtime: 'bcore', caseId, phase: 'loading'});
    importScripts('bcore-runtime.js');
    const file = async name => {
      const response = await fetch(name);
      if (!response.ok) throw new Error(`Missing ${name}: ${response.status}`);
      return new Uint8Array(await response.arrayBuffer());
    };
    const manifest = JSON.parse(new TextDecoder().decode(await file('quickjs-bcore-manifest.json')));
    const names = ['c-bench-bcore.js', 'c-bench-bcore.wasm', 'quickjs-bfin.bin',
      'bcore-tier-worker.js', 'official-v8.js', 'official-v8-adapter.js'];
    const bytes = Object.fromEntries(await Promise.all(names.map(async name => [name, await file(name)])));
    for (const name of names) {
      const identity = manifest.artifacts[name];
      if (identity && (identity.bytes !== bytes[name].length || identity.sha256 !== bcoreSha256(bytes[name])))
        throw new Error('Artifact hash mismatch: ' + name);
    }
    const text = name => new TextDecoder().decode(bytes[name]);
    const javascript = text('c-bench-bcore.js');
    const url = URL.createObjectURL(new Blob([javascript], {type: 'text/javascript'}));
    try {importScripts(url);} finally {URL.revokeObjectURL(url);}
    runtime = await prepareBcore({host: {artifacts: Object.entries(manifest.artifacts).map(([path, v]) => ({path, ...v}))},
      javascript, wasmBinary: bytes['c-bench-bcore.wasm'], tierSource: text('bcore-tier-worker.js'), base: self.location.href});
    const module = runtime.module;
    if (module._bcore_init() !== 0) throw new Error('bcore init failed');
    const size = 256 * 1024 * 1024, limit = 192 * 1024 * 1024, address = size - 8 * 1024 * 1024;
    const ram = module._bcore_ram() >>> 0;
    const source = data.source ?? `${text('official-v8.js')}\n${text('official-v8-adapter.js')}\nJSON.stringify(OfficialV8Bench.run(${JSON.stringify(caseId)}, {}, benchNow));\n`;
    const script = new TextEncoder().encode(source + '\0');
    if (script.length >= 4 * 1024 * 1024 || bytes['quickjs-bfin.bin'].length >= address - 0x10000)
      throw new Error('Guest source/image too large');
    module.HEAPU8.fill(0, ram, ram + size);
    module.HEAPU8.set(bytes['quickjs-bfin.bin'], ram + 0x10000);
    module.HEAPU8.set(script, ram + address);
    const mailbox = new DataView(module.HEAPU8.buffer, ram + 0xf000, 24);
    [2, address, script.length - 1, limit, size, size - 64 * 1024].forEach((v,i) => mailbox.setUint32(i*4,v,true));
    runtime.start();
    const loadMs = performance.now() - started;
    postMessage({type: 'progress', runtime: 'bcore', caseId, phase: 'executing'});
    const startRun = performance.now();
    let stats;
    try {stats = await runtime.run();}
    catch (error) {throw new Error(String(error) + '\n' + module.UTF8ToString(module._bcore_console()));}
    const runMs = performance.now() - startRun;
    const output = module.UTF8ToString(module._bcore_console());
    // C-lab marker statistics do not describe the QuickJS harness.
    delete stats.firstTierInstallMarker;
    delete stats.tierInstalledBeforeMeasured;
    postMessage({ok: true, runtime: 'bcore', caseId, official: JSON.parse(output.trim()),
      loadMs, runMs, memoryBytes: module.HEAPU8.byteLength, guestRamBytes: size,
      quickjsMemoryLimitBytes: limit, stats, exitCode: module._bcore_exit_code()});
  } catch (error) {
    postMessage({ok: false, runtime: 'bcore', caseId, error: String(error?.stack || error)});
  } finally {runtime?.stop();}
};
