#!/usr/bin/env node
// Smoke / individual-case runner. Formal repetitions use compare.mjs.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
import {withChromium, pause} from '../../../tests/browser/chromium.mjs';
const [dist = 'build-bcore-quickjs/dist', caseId = 'smoke', output = 'build-bcore-quickjs/smoke.json'] = process.argv.slice(2);
const browser = process.env.BROWSER || '/home/xiong/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome';
let source;
if (caseId === 'smoke') source = `JSON.stringify({answer:6*7, float:1.25*2.5, integer:(0xffffffff>>>0),
  math:Math.sqrt(144), string:'abc'.replace(/b/,'X'), now:benchNow(),
  largeMemory:(()=>{const a=new Uint8Array(20*1024*1024);for(let i=0;i<a.length;i+=4096)a[i]=173;
    for(let i=0;i<a.length;i+=4096)if(a[i]!==173)throw Error('RAM mismatch');return true;})()});`;
if (caseId === 'kernels') source = fs.readFileSync(path.join(dist, 'quickjs-workloads.js'), 'utf8') +
  "\nJSON.stringify(QuickJSBench.run('full',benchNow));";
await withChromium({browser, root:dist}, async ({evaluate,navigate}) => {
  await navigate();
  await evaluate(`(() => {
    window.result=null;window.progress=[];
    const w=new Worker('bcore-worker.js');window.worker=w;
    w.onerror=e=>{window.result={ok:false,error:e.message};w.terminate();};
    w.onmessage=e=>{if(e.data.type==='progress')window.progress.push(e.data);else{window.result=e.data;w.terminate();}};
    w.postMessage(${JSON.stringify({caseId,source})});
  })()`);
  const started=Date.now();let result;
  while(!(result=await evaluate('window.result'))) {
    if(Date.now()-started>600000) throw new Error('Worker timeout');
    await pause(1000);
  }
  fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));assert(result.ok,result.error);
  if(caseId==='smoke') {
    assert.deepEqual({...result.official,now:0},{answer:42,float:3.125,integer:4294967295,math:12,string:'aXc',now:0,largeMemory:true});
    assert(result.official.now>0);
  }
});
