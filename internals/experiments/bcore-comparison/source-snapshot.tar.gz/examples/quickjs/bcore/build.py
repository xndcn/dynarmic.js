#!/usr/bin/env python3
"""Reuse the existing QuickJS benchmarks with a Blackfin guest and bcore Wasm.

Build in isolation, reusing the verified C-lab bcore static archives. Benchmark
JS, ARM QuickJS, ARM emulator, and upstream QuickJS engine remain unchanged.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
QJS = HERE.parent
ROOT = QJS.parent.parent


def record(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, default=ROOT / 'build-bcore-quickjs')
    p.add_argument('--arm-dist', type=Path, default=ROOT / 'build-em/examples/browser/dist')
    p.add_argument('--bcore-build', type=Path, default=ROOT / 'build-c-bench-bcore/host')
    p.add_argument('--bfin-gcc', type=Path, default=Path.home() / 'toolchains/bfin-elf/bin/bfin-elf-gcc')
    p.add_argument('--emsdk', type=Path, default=Path.home() / '.cache/bcore-wasm/emsdk-4.0.9')
    p.add_argument('--guest-only', action='store_true')
    a = p.parse_args()
    cache, arm, build, gcc, sdk = [x.resolve() for x in
        [a.cache, a.arm_dist, a.bcore_build, a.bfin_gcc, a.emsdk]]
    dist = cache / 'dist'
    cache.mkdir(parents=True, exist_ok=True)
    dist.mkdir(exist_ok=True)
    manifest = json.loads((arm / 'quickjs-manifest.json').read_text())
    archive = arm / 'quickjs-source.tar.xz'
    assert record(archive)['sha256'] == manifest['upstream']['sha256']
    with tarfile.open(archive) as t:
        t.extractall(cache, filter='data')
    source = cache / ('quickjs-' + manifest['upstream']['version'])
    engine = source / 'quickjs.c'
    engine.write_text(replace_once(engine.read_text(),
        '        localtime_r(&ti, &tm);\n        res = -tm.tm_gmtoff / 60;',
        '        (void)tm; (void)ti;\n        res = 0; /* Bare-metal demo: UTC on both targets. */'))
    assert record(engine)['sha256'] == manifest['configuration']['targets']['arm']['engineSource']['sha256']
    # GCC 4.5/newlib 1.19 have no C11 max_align_t. The ABI aligns scalar
    # types to 4 bytes; this union retains the allocator's 8-byte header.
    (cache / 'compat.h').write_text('#ifndef __ASSEMBLER__\ntypedef union { long long i; long double d; void *p; } max_align_t;\n#endif\n')
    # No fenv functions/constants are referenced by this QuickJS source.
    (cache / 'fenv.h').write_text('/* Unused fenv include; Blackfin uses software IEEE binary64. */\n')
    workloads = (QJS / 'workloads.js').read_bytes() + b'\0'
    (cache / 'workloads.h').write_text('static const unsigned char workloads_js[] = {' +
        ','.join(map(str, workloads)) + '};\n')
    runner = replace_once((QJS / 'runner.c').read_text(),
        '    register uint32_t value __asm__("r0");\n    __asm__ volatile("svc #4" : "=r"(value) :: "memory");',
        '    uint32_t value = *(volatile const uint32_t *)0x10000000;')
    (cache / 'runner.c').write_text(runner)
    syscalls = replace_once((QJS / 'syscalls.c').read_text(),
        '        register uint32_t value __asm__("r0") = bytes[i];\n        __asm__ volatile("svc #1" :: "r"(value) : "memory");',
        '        *(volatile uint32_t *)0x10000004 = bytes[i];')
    syscalls = replace_once(syscalls,
        '    register uint32_t value __asm__("r0") = (uint32_t)status;\n    __asm__ volatile("svc #0" :: "r"(value) : "memory");',
        '    *(volatile uint32_t *)0x10000008 = (uint32_t)status;')
    (cache / 'syscalls.c').write_text(syscalls)
    commands = []
    env = dict(os.environ, EM_CONFIG=str(sdk / '.emscripten'))

    def run(cmd, cwd=None):
        cmd = list(map(str, cmd))
        commands.append(dict(argv=cmd, cwd=str(cwd or ROOT)))
        print('+', shlex.join(cmd), flush=True)
        subprocess.run(cmd, cwd=cwd, env=env, check=True)

    flags = ['-O2', '-std=gnu99', '-mcpu=bf532', '-fwrapv', '-fno-strict-aliasing',
        '-D_GNU_SOURCE', '-DCONFIG_VERSION="2025-09-13"', '-DEMSCRIPTEN',
        '-ffunction-sections', '-fdata-sections', '-I' + str(source), '-I' + str(cache),
        '-include', str(cache / 'compat.h')]
    sources = [source / n for n in ['quickjs.c', 'dtoa.c', 'libregexp.c', 'libunicode.c', 'cutils.c']]
    sources += [cache / 'runner.c', cache / 'syscalls.c', HERE / 'start.S']
    objects = []
    for file in sources:
        obj = cache / (file.name + '.o')
        run([gcc, *flags, '-c', file, '-o', obj])
        objects.append(obj)
    elf = cache / 'quickjs-bfin.elf'
    run([gcc, '-mcpu=bf532', '-nostdlib', *objects, '-Wl,--gc-sections',
        '-Wl,-T,' + str(HERE / 'link.ld'), '-lm', '-lc', '-lgcc', '-o', elf])
    run([gcc.with_name('bfin-elf-objcopy'), '-O', 'binary', elf, dist / 'quickjs-bfin.bin'])
    if a.guest_only:
        return
    host = (ROOT / 'examples/c-bench/bcore-host.cpp').read_text()
    host = host.replace('#include <memory>', '#include <memory>\n#include <string>\n#include <cmath>\nstatic std::string console;')
    host = replace_once(host, 'FlatMemory(0, 16 * 1024 * 1024, &cpu)', 'FlatMemory(0, 256 * 1024 * 1024, &cpu)')
    host = replace_once(host, '    void write32(uint32_t addr, uint32_t value) override {',
        '    uint32_t read32(uint32_t addr) const override {\n'
        '        if(addr == 0x10000000) return uint32_t(uint64_t(emscripten_get_now()*1000.0));\n'
        '        return FlatMemory::read32(addr);\n    }\n'
        '    void write32(uint32_t addr, uint32_t value) override {\n'
        '        if(addr == 0x10000004) { if(console.size()<4*1024*1024) console.push_back(char(value)); return; }')
    host = host.replace('addr == 0x01000004', 'addr == 0x10000008')
    host = replace_once(host,
        '        if (addr == 0x01000000) {\n'
        '            if (mark_count >= 12 || value != (mark_count & 1)) marker_error = true;\n'
        '            else marks[mark_count++] = emscripten_get_now();\n'
        '        } else if (addr == 0x10000008) {',
        '        if (addr == 0x10000008) {')
    host = host.replace('= 0xff0000;', '= 0x0fff0000;')
    host = host.replace('return marker_error || mark_count != 12 || cpu.exit_code ? -3 : 1;',
        'return cpu.exit_code ? -3 : 1;')
    host += '\nextern "C" {\nEMSCRIPTEN_KEEPALIVE const char* bcore_console() { return console.c_str(); }\n' \
        'EMSCRIPTEN_KEEPALIVE int bcore_exit_code() { return cpu.exit_code; }\n}\n'
    (cache / 'host.cpp').write_text(host)
    bcore_manifest = json.loads((arm / 'c-bench-bcore-manifest.json').read_text())
    snapshot = build.parent / ('source-' + bcore_manifest['source']['revision'])
    em = sdk / 'upstream/emscripten'
    run([em / 'em++', '-O3', '-DNDEBUG', '-std=c++17', '-fwasm-exceptions', '-fno-rtti',
        '-I', snapshot / 'include', '-I', snapshot / 'tools', '-c', cache / 'host.cpp', '-o', cache / 'host.o'])
    link = shlex.split((build / 'CMakeFiles/c-bench-bcore.dir/link.txt').read_text())
    object_at = link.index('@CMakeFiles/c-bench-bcore.dir/objects1.rsp')
    tier = next(build.rglob('bcore-tier.cpp.o'))
    link[object_at:object_at+1] = [str(cache / 'host.o'), str(tier)]
    link[link.index('-o')+1] = str(dist / 'c-bench-bcore.js')
    link = [x.replace('-sINITIAL_MEMORY=128MB', '-sINITIAL_MEMORY=384MB') for x in link]
    run(link, cwd=build)
    run(['node', ROOT / 'examples/c-bench/bcore/split-module.mjs', dist, sdk / 'upstream/bin/wasm-split'])
    for name in ['arm_bench_jit.js', 'arm_bench_jit.wasm', 'arm-bench-build-manifest.json',
                 'quickjs-arm.bin', 'quickjs-manifest.json', 'quickjs-workloads.js',
                 'official-v8.js', 'official-v8-adapter.js', 'official-benchmarks.json',
                 'quickjs-LICENSE.txt', 'quickjs-runtime-licenses.txt', 'c-bench-bcore-LICENSE.txt',
                 'c-bench-bcore-source.tar.gz', 'quickjs-source.tar.xz', 'quickjs-extras-source.tar.xz']:
        shutil.copyfile(arm / name, dist / name)
    shutil.copyfile(ROOT / 'examples/browser/official-benchmarks-worker.js', dist / 'official-benchmarks-worker.js')
    for name, target in [('runtime.js', 'bcore-runtime.js'), ('tier-worker.js', 'bcore-tier-worker.js')]:
        shutil.copyfile(ROOT / 'examples/c-bench/bcore' / name, dist / target)
    shutil.copyfile(HERE / 'worker.js', dist / 'bcore-worker.js')
    (dist / 'index.html').write_text('<!doctype html><meta charset="utf-8"><title>QuickJS comparison</title>\n')
    records = lambda paths: {str(f): record(f) for f in paths}
    result = dict(schema='dynarmic.js/bcore-quickjs-build-v1', quickjs=manifest['upstream'],
        engine=record(engine), compiler=subprocess.check_output([gcc, '--version'], text=True).strip(),
        flags=flags, configuration=dict(dispatch='switch', optimization='O2', lto=False,
            ramBytes=256*1024*1024, quickjsLimitBytes=192*1024*1024, newlib='1.19.0',
            doubleBits=64, floatingPoint='software libgcc/libm'),
        bcoreBase=bcore_manifest, commands=commands,
        libraries=records(sorted((build / 'upstream').glob('lib*.a'))),
        sources=records([*sources, HERE / 'link.ld', HERE / 'build.py', cache / 'host.cpp',
            cache / 'compat.h', cache / 'fenv.h']),
        artifacts={f.name: record(f) for f in dist.iterdir() if f.is_file() and
            f.name in ['quickjs-bfin.bin', 'c-bench-bcore.js', 'c-bench-bcore.wasm', 'c-bench-bcore.deferred.wasm']})
    (dist / 'quickjs-bcore-manifest.json').write_text(json.dumps(result, indent=2)+'\n')
    (dist / 'comparison-inputs.json').write_text(json.dumps(dict(
        schema='dynarmic.js/bcore-quickjs-inputs-v1', artifacts={f.name: record(f)
            for f in sorted(dist.iterdir()) if f.is_file() and f.name != 'comparison-inputs.json'}), indent=2)+'\n')


if __name__ == '__main__':
    main()
