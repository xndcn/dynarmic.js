# Existing QuickJS benchmarks through bcore Wasm

This harness runs the existing ten [official JavaScript cases](../README.md)
through two complete execution paths: ARM QuickJS in dynarmic.js, and Blackfin
QuickJS in bcore Wasm. It reuses the official source, adapter, timing windows,
assertions and ARM Worker unchanged. It does not add a new benchmark workload
or alter the public Pages UI.

Both interpreters use the pinned QuickJS 2025-09-13 engine with the same UTC
adaptation, switch dispatch, O2, no LTO, EMSCRIPTEN feature guards, allocation
tracking, 256 MiB guest RAM and 192 MiB QuickJS allocation limit. The builder
requires the adapted interpreter source hash to match the ARM build manifest.
Blackfin uses ADI GCC 4.5.3/BF532, bundled newlib 1.19.0 and software IEEE
binary64; ARM uses its existing GCC/newlib/VFP build. These are complete
execution-path comparisons, not an isolated measurement of emulator quality.

The Blackfin guest uses the shared `runner.c` and `syscalls.c`, with only the
ARM SVC clock/output/exit bridges replaced by MMIO. GCC 4.5 lacks C11
`max_align_t`, so an ABI-appropriate union retains an 8-byte allocation header.
The unused `fenv.h` include has an empty compatibility header; no floating-point
environment functions are stubbed or bypassed. The default Blackfin stack
frame settings remain unchanged.

The bcore host reuses the verified C-lab release static archives and the same
web settings: copy-and-patch with hints/split, cold threshold 10, remote LLVM
promotion 100000/16, O1/codegen2, 8 ms scheduling slices, page-table RAM, host
cycles and chain budget 2^24. The deferred LLVM module and compiler Worker
remain enabled. Its guest RAM and initial Wasm memory are increased to
256 MiB and 384 MiB to match the official QuickJS lab's memory requirements.
The compiler Worker has its own Wasm memory, reported separately.

The build creates an isolated `build-bcore-quickjs/` tree and leaves the upstream
bcore checkout, C-lab artifacts and public browser dist unchanged. It currently
requires the existing QuickJS and bcore C-lab builds as prerequisites; see their
respective guides for installing the toolchains and building those archives.

```sh
python3 examples/quickjs/bcore/build.py
# Select a current Chromium supporting Wasm tail calls and exceptions.
export BROWSER=/path/to/chrome
taskset -c 8,10,12,14 node examples/quickjs/bcore/run.mjs
taskset -c 8,10,12,14 node examples/quickjs/bcore/run.mjs \
  build-bcore-quickjs/dist kernels build-bcore-quickjs/kernels.json
# Finish all builds before collecting measurements.
taskset -c 8,10,12,14 node examples/quickjs/bcore/compare.mjs \
  --browser "$BROWSER" --repeats 3 --timeout 1800000 --output NEW_RESULTS
node examples/quickjs/bcore/analyze.mjs NEW_RESULTS --output-prefix NEW_ANALYSIS
```

Choose valid CPU numbers for your machine. The smoke runner accepts an official
case ID instead of `smoke` or `kernels`; its results are kept separate from the
formal comparison. `kernels` runs the unchanged Full LCG/sieve/pi workload with
its existing independent reference outputs.

Formal collection uses a fresh Chromium process per round and a fresh Worker
and engine per observation. Case order rotates and emulator order alternates.
The original one-second warmup, one-second measurement batches and minimum
32 invocations remain intact. Reported milliseconds are per official
invocation; adaptive whole-run durations cannot be used as equal-work ratios.
Each round combines the two Crypto and two EarleyBoyer cases geometrically,
then weights the eight suites equally. Failed cases and incomplete rounds are
retained and cannot become an overall successful comparison.

The collector hashes its scripts and prepared runtime inputs throughout the
run. Resume requires unchanged inputs and complete pairs within one browser
attempt. An interrupted half-pair must be preserved under `superseded/` with
an explicit recovery record before rerunning both members together. Preparation,
compilation statistics and whole-run times are retained separately. RegExp and
NavierStokes have no independent numerical assertions in the upstream suite.
