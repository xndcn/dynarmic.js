#!/usr/bin/env node
// Real Wasm execution, source/asset failures and cancellation of the Blackfin path.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {withChromium} from './chromium.mjs';
const P = createRequire(import.meta.url)('../../examples/browser/c-bench-protocol.js');
const [browser, dist = 'build-em/examples/browser/dist', output] = process.argv.slice(2);
assert(browser, 'Usage: verify_bcore_bench.mjs CHROME [DIST] [REPORT.json]');
let broken = null;
const evidence = {checks: [], full: []};
const pass = name => {evidence.checks.push(name); console.log('PASS', name);};
await withChromium({browser, root: path.resolve(dist), serve: ({name, response}) => {
  if (name === 'bcore-diagnostic-worker.js') {
    const prefix = `let cpModules=0;const Original=WebAssembly.Module;
      WebAssembly.Module=new Proxy(Original,{construct(target,args){const m=new target(...args);
        if(Original.exports(m).some(e=>e.kind==='function'&&/^\\d+$/.test(e.name)))cpModules++;return m;}});
      const post=self.postMessage.bind(self);self.postMessage=data=>{if(data.ok)data.cpModules=cpModules;post(data);};\n`;
    response.writeHead(200, {'Content-Type': 'text/javascript'}).end(prefix + fs.readFileSync(path.join(dist, 'c-bench-worker.js'), 'utf8'));
    return true;
  }
  if (name !== broken) return false;
  // A successful fetch with wrong bytes must fail the identity check.
  response.writeHead(200, {'Content-Type': 'application/wasm'}).end('corrupt'); return true;
}}, async ({navigate, evaluate, until, call}) => {
  const finished = () => until(async () => {
    const value = await evaluate('window.cBenchReport?.status');
    return value && value !== 'running' && await evaluate('!window.cBenchRunning') ? await evaluate('window.cBenchReport') : null;
  }, 'Blackfin page comparison', 605000);
  await navigate('?cbench=quick&cbench-path=bcore');
  const report = await finished(); evidence.quick = report;
  assert.equal(report.status, 'pass', report.error); assert.equal(report.performanceValid, true);
  assert.deepEqual(report.runtimes, P.BCORE_RUNTIMES); assert.equal(report.observations.length, 45);
  for (const entry of report.observations) P.validateResult(entry.result, entry.task, report.reference);
  assert(report.observations.filter(e => e.task.runtime === 'bcore').every(e => e.result.stats.tierSubmitted > 0));
  assert(report.observations.filter(e => e.task.runtime === 'bcore' && e.task.caseId === 'float').every(e => e.result.stats.tierInstalled > 0));
  assert(report.observations.filter(e => e.task.runtime === 'bcore').every(e => !e.result.stats.tierFailed && !e.result.stats.tierRefused));
  const summary = P.summarize(report.observations.map(x => x.result), P.CASE_IDS, 3, P.BCORE_RUNTIMES);
  assert(summary.complete);
  for (const id of P.CASE_IDS) assert.deepEqual(report.summary.cases[id].bcoreOverArm, summary.cases[id].ratios.bcoreOverDynarmic);
  assert.equal(report.summary.v86OverArm, null);
  assert.equal(await evaluate("document.getElementById('c-bench-peer-name').textContent"), 'bcore');
  pass('Quick page comparison: 45 observations, 270 matching checksums and paired ratios');
  await evaluate(`window.cpDiagnostic=null;const w=new Worker('bcore-diagnostic-worker.js');
    w.onmessage=({data})=>{if(data.type!=='progress'){window.cpDiagnostic=data;w.terminate();}};
    w.postMessage({runtime:'bcore',caseId:'integer',profile:'quick',round:0,token:'diagnostic'});`);
  const diagnostic = await until(() => evaluate('window.cpDiagnostic'), 'copy-and-patch module verification', 90000);
  assert.equal(diagnostic.ok, true, diagnostic.error); assert(diagnostic.cpModules > 0);
  evidence.diagnostic = diagnostic;
  pass('Copy-and-patch modules are actually generated; background LLVM jobs are submitted and installed');
  for (const width of [1440, 320]) {
    await call('Emulation.setDeviceMetricsOverride', {width, height: 1000, deviceScaleFactor: 1, mobile: false});
    assert.equal(await evaluate('document.documentElement.scrollWidth <= document.documentElement.clientWidth'), true);
    if (output) {
      await evaluate("document.getElementById('c-bench').scrollIntoView({behavior:'instant'})");
      const shot = await call('Page.captureScreenshot', {format: 'png'});
      fs.writeFileSync(output.replace(/\.json$/, '') + `-${width}.png`, Buffer.from(shot.data, 'base64'));
    }
  }
  pass('Blackfin results fit desktop and 320px mobile viewports');
  // Full input is also executed, including all six software-binary64 calls.
  for (const caseId of P.CASE_IDS) {
    const task = {runtime: 'bcore', caseId, profile: 'full', round: 0, token: 'full-' + caseId};
    await evaluate(`window.bcoreFull=null;window.bcoreWorker=new Worker('c-bench-worker.js');
      bcoreWorker.onmessage=({data})=>{if(data.type!=='progress'){window.bcoreFull=data;bcoreWorker.terminate();}};
      bcoreWorker.onerror=e=>window.bcoreFull={error:e.message};bcoreWorker.postMessage(${JSON.stringify(task)});`);
    const result = await until(() => evaluate('window.bcoreFull'), 'full Blackfin ' + caseId, 180000);
    P.validateResult(result, task, report.reference); evidence.full.push(result);
    pass('Full Blackfin ' + caseId + ': six matching checksums');
  }
  await evaluate("document.getElementById('c-bench-case').value='integer'");
  broken = 'c-bench-bcore.wasm';
  await evaluate("document.getElementById('c-bench-run').click()");
  const failed = await finished();
  assert.equal(failed.status, 'fail'); assert.equal(failed.summary.bcoreOverArm, null);
  assert(failed.observations.filter(e => e.task.runtime === 'bcore').every(e => /Build identity mismatch/.test(e.error)));
  pass('Corrupt bcore Wasm is rejected before executing, with no comparison ratio');
  broken = 'c-bench-bcore.deferred.wasm';
  await evaluate("document.getElementById('c-bench-run').click()");
  const badDeferred = await finished();
  assert.equal(badDeferred.status, 'fail'); assert.equal(badDeferred.summary.bcoreOverArm, null);
  assert(badDeferred.observations.filter(e => e.task.runtime === 'bcore').every(e => /Deferred LLVM identity mismatch/.test(e.error)));
  pass('Corrupt deferred LLVM fails visibly instead of silently benchmarking tier zero');
  broken = null;
  await evaluate("document.getElementById('c-bench-run').click()");
  assert.equal((await finished()).status, 'pass'); pass('Retry uses fresh Workers');
  for (const hidden of [false, true]) {
    await evaluate("document.getElementById('c-bench-case').value='float';document.getElementById('c-bench-run').click()");
    await until(() => evaluate("window.cBenchReport.observations.some(e=>e.task.runtime==='bcore'&&e.status==='running')"), 'active bcore Worker');
    await evaluate(hidden ? "Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))" : "document.getElementById('c-bench-stop').click()");
    const stopped = await finished();
    assert.equal(stopped.status, hidden ? 'invalid' : 'cancelled');
    assert.equal(stopped.summary.bcoreOverArm, null); assert.equal(stopped.performanceValid, false);
  }
  pass('Stop and tab hiding terminate Blackfin work and withhold ratios');
});
if (output) fs.writeFileSync(output, JSON.stringify(evidence, null, 2) + '\n');
