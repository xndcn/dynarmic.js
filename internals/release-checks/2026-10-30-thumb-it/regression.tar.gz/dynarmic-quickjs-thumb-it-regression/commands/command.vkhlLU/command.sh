/home/xiong/workspace/dynarmic.js/build-native/tests/guest/media_ref_log 
