/home/xiong/workspace/dynarmic.js/build-native/tests/guest/neon_ref_log 
