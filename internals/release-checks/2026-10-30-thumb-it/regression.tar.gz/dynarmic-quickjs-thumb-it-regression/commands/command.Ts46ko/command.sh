/home/xiong/workspace/dynarmic.js/build-native/tests/guest/host_ref 
