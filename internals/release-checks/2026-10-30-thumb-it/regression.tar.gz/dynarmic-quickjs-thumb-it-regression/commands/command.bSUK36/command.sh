/home/xiong/workspace/dynarmic.js/build-native/tests/smoke_ir smoke.wasm 
