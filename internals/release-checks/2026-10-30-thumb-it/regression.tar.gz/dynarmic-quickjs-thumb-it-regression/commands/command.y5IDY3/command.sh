/home/xiong/workspace/dynarmic.js/build-native/tests/tools/block_dump loop 1000 dispatch-optimized/b1000.wasm 
