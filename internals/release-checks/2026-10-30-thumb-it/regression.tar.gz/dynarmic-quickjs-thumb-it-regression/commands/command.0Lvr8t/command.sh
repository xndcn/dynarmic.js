/home/xiong/workspace/dynarmic.js/build-native/tests/guest/neon2_ref_log 
