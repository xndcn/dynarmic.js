node /home/xiong/workspace/dynarmic.js/build-em/tests/jit_runbin.js /home/xiong/workspace/dynarmic.js/build-native/tests/guest/neon4_log.bin 1 
