/home/xiong/workspace/dynarmic.js/build-native/tests/arm_decoder_test 
