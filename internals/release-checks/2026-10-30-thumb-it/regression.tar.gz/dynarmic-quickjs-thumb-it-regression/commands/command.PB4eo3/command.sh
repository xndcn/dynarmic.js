/home/xiong/workspace/dynarmic.js/build-native/tests/tools/block_dump loop 1010 dispatch-optimized/b1010.wasm 
