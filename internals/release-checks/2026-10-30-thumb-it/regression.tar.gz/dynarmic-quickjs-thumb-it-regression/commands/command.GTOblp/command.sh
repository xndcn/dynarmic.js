node /home/xiong/workspace/dynarmic.js/tests/ir/wasm_binary_test.mjs . 
