node /home/xiong/workspace/dynarmic.js/tests/ir/integer_edge_test.mjs /home/xiong/workspace/dynarmic.js/build-native/tests/integer_edge_test 
