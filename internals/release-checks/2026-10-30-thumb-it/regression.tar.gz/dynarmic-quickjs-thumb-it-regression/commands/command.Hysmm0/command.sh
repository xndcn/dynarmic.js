node /home/xiong/workspace/dynarmic.js/examples/browser/fault_test.mjs /home/xiong/workspace/dynarmic.js/build-em/examples/browser 
