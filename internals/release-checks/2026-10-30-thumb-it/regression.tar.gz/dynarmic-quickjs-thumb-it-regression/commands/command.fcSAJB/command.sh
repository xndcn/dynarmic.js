/home/xiong/workspace/dynarmic.js/build-native/tests/guest/fp16_ref 
