/home/xiong/workspace/dynarmic.js/build-native/tests/wasm_binary_test . 
