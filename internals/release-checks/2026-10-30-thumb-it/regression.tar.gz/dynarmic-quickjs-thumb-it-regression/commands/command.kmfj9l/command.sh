/home/xiong/workspace/dynarmic.js/build-native/tests/tools/block_dump --raw loop 1010 dispatch-raw/b1010.wasm 
