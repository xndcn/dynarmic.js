node /home/xiong/workspace/dynarmic.js/tests/ir/vector_edge_test.mjs /home/xiong/workspace/dynarmic.js/build-native/tests/vector_edge_test 
