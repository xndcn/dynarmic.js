/home/xiong/workspace/dynarmic.js/build-native/tests/sat64_ir sat64.wasm 
