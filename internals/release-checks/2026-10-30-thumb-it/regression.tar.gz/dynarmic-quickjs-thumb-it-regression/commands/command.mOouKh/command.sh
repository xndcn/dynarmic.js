/home/xiong/workspace/dynarmic.js/build-native/tests/guest/neon3_ref_log 
