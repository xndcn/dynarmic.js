/home/xiong/workspace/dynarmic.js/build-native/tests/tools/block_dump --raw loop 1008 dispatch-raw/b1008.wasm 
