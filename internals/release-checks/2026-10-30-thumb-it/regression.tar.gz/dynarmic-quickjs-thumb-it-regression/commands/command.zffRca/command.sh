node /home/xiong/workspace/dynarmic.js/build-em/tests/smc_test.js /home/xiong/workspace/dynarmic.js/build-native/tests/guest/smc.bin 
