node /home/xiong/workspace/dynarmic.js/build-em/tests/a64_runbin.js /home/xiong/workspace/dynarmic.js/build-native/tests/guest64/fp_fma.bin 2 
