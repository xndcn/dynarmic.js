node /home/xiong/workspace/dynarmic.js/tests/ir/memory_edge_test.mjs /home/xiong/workspace/dynarmic.js/build-native/tests/memory_edge_test 
