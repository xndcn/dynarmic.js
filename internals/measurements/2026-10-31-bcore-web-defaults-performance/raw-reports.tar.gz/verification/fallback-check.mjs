import fs from 'node:fs';
import assert from 'node:assert/strict';
import {withChromium} from '../tests/browser/chromium.mjs';
const code=`importScripts('c-bench-bcore.js','c-bench-bcore-runtime.js');
(async()=>{let loads=0;const create=createCBenchBcore;createCBenchBcore=opts=>create({...opts,loadSplitModule:(...args)=>{loads++;return opts.loadSplitModule(...args);}});
 const host=await(await fetch('c-bench-bcore-manifest.json')).json();
 const wasmBinary=await(await fetch('c-bench-bcore.wasm')).arrayBuffer();
 const adapter=await prepareBcore({host,wasmBinary,javascript:new Uint8Array(),tierSource:new Uint8Array(),base:location.href});
 const m=adapter.module;if(m._bcore_init())throw new Error('init');
 const words=[0xcc0d,0x4210,0,0,0x6000,0xe148,0x0100,0xe108,4,0x9300,0x2000];
 m.HEAPU8.set(new Uint8Array(new Uint16Array(words).buffer),m._bcore_ram()+0x10000);
 let status;do{status=m._bcore_step(8);}while(status===0);
 postMessage({status,loads});adapter.stop();
})().catch(e=>postMessage({error:String(e.stack||e)}));`;
await withChromium({browser:'/home/xiong/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome',root:'build-em/examples/browser/dist',serve:({name,response})=>{
 if(name!=='fallback-worker.js')return false;response.writeHead(200,{'content-type':'text/javascript'}).end(code);return true;
}},async({navigate,evaluate,until})=>{
 await navigate();await evaluate("window.result=null;const w=new Worker('fallback-worker.js');w.onmessage=e=>{window.result=e.data;w.terminate();}");
 const r=await until(()=>evaluate('window.result'),'deferred fallback',90000);console.log(r);
 assert.deepEqual(r,{status:-3,loads:1});
 fs.writeFileSync('build-c-bench-copy-patch/fallback-check.json',JSON.stringify(r,null,2)+'\n');
});
