(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32) (result i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_read32" (func $fimport$0 (param i32 i32) (result i32)))
 (import "env" "cec_data_alignment" (func $fimport$1 (param i32 i32 i32 i32 i32)))
 (export "bb_0x000104c0" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (block $block3
   (block $block12
    (block $block
     (br_if $block
      (i32.gt_u
       (i32.add
        (i32.load offset=160
         (local.get $0)
        )
        (i32.const -66777)
       )
       (i32.const -26)
      )
     )
     (br_if $block
      (i32.gt_u
       (i32.add
        (i32.load offset=164
         (local.get $0)
        )
        (i32.const -66777)
       )
       (i32.const -26)
      )
     )
     (local.set $2
      (i32.load offset=312
       (local.get $0)
      )
     )
     (local.set $3
      (i32.load offset=324
       (local.get $0)
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 70388)
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eqz
         (local.tee $4
          (i32.load
           (i32.add
            (local.get $2)
            (i32.const 68)
           )
          )
         )
        )
       )
       (local.set $4
        (i32.load
         (i32.add
          (local.get $4)
          (i32.const 756)
         )
        )
       )
       (br $block2)
      )
      (local.set $5
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (local.set $6
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 66760)
      )
      (local.set $4
       (call $fimport$0
        (local.get $1)
        (i32.const 70388)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 70392)
     )
     (i32.store
      (local.get $0)
      (local.get $4)
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eqz
         (local.tee $4
          (i32.load
           (i32.add
            (local.get $2)
            (i32.const 68)
           )
          )
         )
        )
       )
       (local.set $4
        (i32.load
         (i32.add
          (local.get $4)
          (i32.const 760)
         )
        )
       )
       (br $block5)
      )
      (local.set $5
       (i32.const 6)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 6)
      )
      (local.set $6
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 66770)
      )
      (local.set $4
       (call $fimport$0
        (local.get $1)
        (i32.const 70392)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $4)
     )
     (block $block6
      (br_if $block6
       (i32.eqz
        (i32.and
         (local.tee $4
          (i32.load offset=60
           (local.get $0)
          )
         )
         (i32.const 3)
        )
       )
      )
      (local.set $5
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 7)
      )
      (local.set $6
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 66772)
      )
      (call $fimport$1
       (local.get $0)
       (local.get $1)
       (i32.const 66772)
       (local.get $4)
       (i32.const 0)
      )
      (br $block3)
     )
     (block $block8
      (block $block7
       (br_if $block7
        (i32.eqz
         (local.tee $7
          (i32.load
           (i32.add
            (local.get $2)
            (i32.and
             (i32.shr_u
              (local.get $4)
              (i32.const 10)
             )
             (i32.const 4194300)
            )
           )
          )
         )
        )
       )
       (local.set $7
        (i32.load
         (i32.add
          (local.get $7)
          (i32.and
           (local.get $4)
           (i32.const 4092)
          )
         )
        )
       )
       (br $block8)
      )
      (local.set $5
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 7)
      )
      (local.set $6
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 66772)
      )
      (local.set $7
       (call $fimport$0
        (local.get $1)
        (local.get $4)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (local.set $6
      (i32.const 4)
     )
     (block $block10
      (block $block9
       (br_if $block9
        (i32.eqz
         (local.tee $2
          (i32.load
           (i32.add
            (local.get $2)
            (i32.and
             (i32.shr_u
              (local.tee $8
               (i32.add
                (local.get $4)
                (i32.const 4)
               )
              )
              (i32.const 10)
             )
             (i32.const 4194300)
            )
           )
          )
         )
        )
       )
       (local.set $2
        (i32.load
         (i32.add
          (local.get $2)
          (i32.and
           (local.get $8)
           (i32.const 4092)
          )
         )
        )
       )
       (br $block10)
      )
      (local.set $5
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 66772)
      )
      (local.set $2
       (call $fimport$0
        (local.get $1)
        (local.get $8)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=168
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=60
      (local.get $0)
      (local.get $7)
     )
     (i32.store
      (local.tee $7
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
      )
      (i32.const 65952)
     )
     (i32.store offset=56
      (local.get $0)
      (i32.add
       (local.get $4)
       (i32.const 8)
      )
     )
     (block $block11
      (br_if $block11
       (i32.ge_u
        (local.tee $2
         (i32.add
          (i32.load offset=332
           (local.get $0)
          )
          (i32.const 8)
         )
        )
        (i32.load offset=328
         (local.get $0)
        )
       )
      )
      (br_if $block12
       (i32.eq
        (i32.load offset=395712
         (local.get $3)
        )
        (i32.const 65952)
       )
      )
     )
     (i32.store offset=308
      (local.get $0)
      (i32.const 8)
     )
     (i32.store offset=292
      (local.get $0)
      (i32.const 4)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store
      (local.get $7)
      (i32.const 65952)
     )
     (return)
    )
    (i32.store8 offset=341
     (local.get $0)
     (i32.const 1)
    )
    (return)
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $2)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
    (i32.const 65952)
   )
   (return_call_indirect $timport$0 (type $0)
    (local.get $0)
    (local.get $1)
    (i32.load offset=395720
     (local.get $3)
    )
   )
  )
  (block $block14
   (block $block13
    (br_if $block13
     (i32.ge_u
      (local.tee $2
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $5)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block14
     (i32.eq
      (i32.load
       (local.tee $3
        (i32.add
         (local.get $3)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.tee $4
             (i32.load
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
            )
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $4)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $6)
   )
   (return)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $2)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $3)
   )
  )
 )
 ;; custom section "linking", size 34
 ;; custom section "reloc.CODE", size 38
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

