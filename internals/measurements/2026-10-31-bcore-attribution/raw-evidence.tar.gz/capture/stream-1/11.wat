(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32) (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (import "env" "mem_read32" (func $fimport$3 (param i32 i32) (result i32)))
 (import "env" "cec_exception" (func $fimport$4 (param i32 i32 i32)))
 (export "bb_0x000101a0" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (block $block6
   (block $block2
    (block $block28
     (block $block22
      (block $block19
       (block $block12
        (block $block9
         (block $block26
          (block $block16
           (block $block
            (br_if $block
             (i32.gt_u
              (i32.add
               (i32.load offset=160
                (local.get $0)
               )
               (i32.const -66031)
              )
              (i32.const -80)
             )
            )
            (br_if $block
             (i32.gt_u
              (i32.add
               (i32.load offset=164
                (local.get $0)
               )
               (i32.const -66031)
              )
              (i32.const -80)
             )
            )
            (local.set $2
             (i32.load offset=324
              (local.get $0)
             )
            )
            (local.set $4
             (i32.add
              (local.tee $3
               (i32.load offset=56
                (local.get $0)
               )
              )
              (i32.const -4)
             )
            )
            (block $block1
             (br_if $block1
              (i32.eqz
               (i32.and
                (local.get $3)
                (i32.const 3)
               )
              )
             )
             (local.set $5
              (i32.const 1)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 1)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (call $fimport$0
              (local.get $0)
              (local.get $1)
              (i32.const 65952)
              (local.get $4)
              (i32.const 65536)
             )
             (local.set $7
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
             (br $block2)
            )
            (local.set $8
             (i32.load offset=316
              (local.get $0)
             )
            )
            (local.set $9
             (i32.load offset=28
              (local.get $0)
             )
            )
            (block $block4
             (block $block3
              (br_if $block3
               (i32.eqz
                (local.tee $12
                 (i32.load
                  (local.tee $11
                   (i32.add
                    (local.tee $10
                     (i32.load offset=312
                      (local.get $0)
                     )
                    )
                    (i32.and
                     (i32.shr_u
                      (local.get $4)
                      (i32.const 10)
                     )
                     (i32.const 4194300)
                    )
                   )
                  )
                 )
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $12)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
               (local.get $9)
              )
              (br $block4)
             )
             (local.set $5
              (i32.const 1)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 1)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (call $fimport$1
              (local.get $1)
              (local.get $4)
              (local.get $9)
             )
             (br_if $block2
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i32.store offset=56
             (local.get $0)
             (local.get $4)
            )
            (block $block5
             (br_if $block5
              (i32.eqz
               (i32.load8_u
                (local.get $8)
               )
              )
             )
             (local.set $5
              (i32.const 1)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 1)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (i32.store
              (local.tee $9
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65954)
             )
             (call $fimport$2
              (local.get $0)
             )
             (br_if $block5
              (i32.eqz
               (local.tee $7
                (i32.load8_u offset=296
                 (local.get $0)
                )
               )
              )
             )
             (local.set $9
              (i32.load
               (local.get $9)
              )
             )
             (br $block6)
            )
            (local.set $9
             (i32.load offset=60
              (local.get $0)
             )
            )
            (local.set $12
             (i32.load offset=168
              (local.get $0)
             )
            )
            (block $block8
             (block $block7
              (br_if $block7
               (i32.eqz
                (local.tee $15
                 (i32.load
                  (local.tee $14
                   (i32.add
                    (local.get $10)
                    (i32.and
                     (i32.shr_u
                      (local.tee $13
                       (i32.add
                        (local.get $3)
                        (i32.const -8)
                       )
                      )
                      (i32.const 10)
                     )
                     (i32.const 4194300)
                    )
                   )
                  )
                 )
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $15)
                (i32.and
                 (local.get $13)
                 (i32.const 4092)
                )
               )
               (local.get $12)
              )
              (br $block8)
             )
             (local.set $5
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 2)
             )
             (local.set $6
              (i32.const 4)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 4)
             )
             (i32.store
              (local.tee $15
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65954)
             )
             (call $fimport$1
              (local.get $1)
              (local.get $13)
              (local.get $12)
             )
             (br_if $block9
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (block $block11
             (block $block10
              (br_if $block10
               (i32.eqz
                (local.tee $15
                 (i32.load
                  (local.tee $16
                   (i32.add
                    (local.get $10)
                    (i32.and
                     (i32.shr_u
                      (local.tee $12
                       (i32.add
                        (local.get $3)
                        (i32.const -12)
                       )
                      )
                      (i32.const 10)
                     )
                     (i32.const 4194300)
                    )
                   )
                  )
                 )
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $15)
                (i32.and
                 (local.get $12)
                 (i32.const 4092)
                )
               )
               (local.get $9)
              )
              (br $block11)
             )
             (local.set $5
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 2)
             )
             (local.set $6
              (i32.const 4)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 4)
             )
             (i32.store
              (local.tee $15
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65954)
             )
             (call $fimport$1
              (local.get $1)
              (local.get $12)
              (local.get $9)
             )
             (br_if $block12
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i32.store offset=56
             (local.get $0)
             (local.get $12)
            )
            (i32.store offset=60
             (local.get $0)
             (local.get $12)
            )
            (block $block13
             (br_if $block13
              (i32.eqz
               (i32.load8_u
                (local.get $8)
               )
              )
             )
             (local.set $5
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 2)
             )
             (local.set $6
              (i32.const 4)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 4)
             )
             (i32.store
              (local.tee $9
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65958)
             )
             (call $fimport$2
              (local.get $0)
             )
             (br_if $block13
              (i32.eqz
               (local.tee $7
                (i32.load8_u offset=296
                 (local.get $0)
                )
               )
              )
             )
             (local.set $9
              (i32.load
               (local.get $9)
              )
             )
             (br $block6)
            )
            (i64.store offset=236 align=4
             (local.get $0)
             (i64.const 4294967297)
            )
            (i32.store offset=276
             (local.get $0)
             (local.tee $9
              (i32.eqz
               (local.tee $15
                (i32.load
                 (local.get $0)
                )
               )
              )
             )
            )
            (i32.store offset=232
             (local.get $0)
             (i32.shr_u
              (local.get $15)
              (i32.const 31)
             )
            )
            (i32.store offset=228
             (local.get $0)
             (local.get $9)
            )
            (block $block14
             (br_if $block14
              (local.get $15)
             )
             (i32.store
              (local.tee $4
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 66032)
             )
             (block $block15
              (br_if $block15
               (i32.ge_u
                (local.tee $9
                 (i32.add
                  (i32.load offset=332
                   (local.get $0)
                  )
                  (i32.const 4)
                 )
                )
                (i32.load offset=328
                 (local.get $0)
                )
               )
              )
              (br_if $block16
               (i32.eq
                (i32.load offset=396192
                 (local.get $2)
                )
                (i32.const 66032)
               )
              )
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 4)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 2)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 1)
             )
             (i32.store
              (local.get $4)
              (i32.const 66032)
             )
             (return)
            )
            (i64.store offset=28 align=4
             (local.get $0)
             (i64.const 302348517777407)
            )
            (i64.store offset=248 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i64.store offset=236 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i64.store offset=228 align=4
             (local.get $0)
             (i64.const 1)
            )
            (i32.store offset=40
             (local.get $0)
             (i32.const 70396)
            )
            (i32.store offset=36
             (local.get $0)
             (local.tee $17
              (i32.load offset=4
               (local.get $0)
              )
             )
            )
            (i64.store offset=4 align=4
             (local.get $0)
             (i64.const 0)
            )
            (block $block18
             (block $block17
              (br_if $block17
               (i32.eqz
                (local.tee $9
                 (i32.load
                  (i32.add
                   (local.get $10)
                   (i32.const 68)
                  )
                 )
                )
               )
              )
              (local.set $9
               (i32.load
                (i32.add
                 (local.get $9)
                 (i32.const 764)
                )
               )
              )
              (br $block18)
             )
             (local.set $5
              (i32.const 13)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 13)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (i32.store
              (local.tee $18
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65984)
             )
             (local.set $9
              (call $fimport$3
               (local.get $1)
               (i32.const 70396)
              )
             )
             (br_if $block19
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i64.store offset=248 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i64.store offset=236 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i32.store offset=12
             (local.get $0)
             (local.get $9)
            )
            (i32.store offset=232
             (local.get $0)
             (i32.shr_u
              (local.get $9)
              (i32.const 31)
             )
            )
            (i32.store offset=228
             (local.get $0)
             (i32.eqz
              (local.get $9)
             )
            )
            (i32.store offset=4
             (local.get $0)
             (local.tee $7
              (i32.xor
               (i32.shr_u
                (local.get $9)
                (i32.const 11)
               )
               (local.get $9)
              )
             )
            )
            (local.set $18
             (i32.load offset=256
              (local.get $0)
             )
            )
            (block $block21
             (block $block20
              (br_if $block20
               (i32.eqz
                (local.tee $5
                 (i32.load
                  (i32.add
                   (local.get $10)
                   (i32.const 68)
                  )
                 )
                )
               )
              )
              (i32.store
               (i32.add
                (local.get $5)
                (i32.const 764)
               )
               (local.get $7)
              )
              (br $block21)
             )
             (local.set $5
              (i32.const 17)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 17)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (i32.store
              (local.tee $19
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65994)
             )
             (call $fimport$1
              (local.get $1)
              (i32.const 70396)
              (local.get $7)
             )
             (br_if $block22
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (block $block23
             (br_if $block23
              (i32.eqz
               (i32.load8_u
                (local.get $8)
               )
              )
             )
             (local.set $5
              (i32.const 17)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 17)
             )
             (local.set $6
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (i32.store
              (local.tee $8
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65996)
             )
             (call $fimport$2
              (local.get $0)
             )
             (br_if $block23
              (i32.eqz
               (local.tee $7
                (i32.load8_u offset=296
                 (local.get $0)
                )
               )
              )
             )
             (local.set $9
              (i32.load
               (local.get $8)
              )
             )
             (br $block6)
            )
            (i32.store offset=256
             (local.get $0)
             (local.get $18)
            )
            (i64.store offset=248 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i32.store offset=8
             (local.get $0)
             (i32.const 1)
            )
            (i32.store offset=40
             (local.get $0)
             (local.get $9)
            )
            (i32.store offset=240
             (local.get $0)
             (i32.const 1)
            )
            (i64.store offset=232 align=4
             (local.get $0)
             (i64.const 4294967296)
            )
            (i32.store offset=276
             (local.get $0)
             (local.tee $8
              (i32.eq
               (local.get $15)
               (i32.const 1)
              )
             )
            )
            (i32.store offset=228
             (local.get $0)
             (local.get $8)
            )
            (i32.store offset=36
             (local.get $0)
             (local.tee $15
              (i32.add
               (local.get $9)
               (local.get $17)
              )
             )
            )
            (block $block24
             (br_if $block24
              (local.get $8)
             )
             (i32.store
              (local.tee $4
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 65978)
             )
             (block $block25
              (br_if $block25
               (i32.ge_u
                (local.tee $9
                 (i32.add
                  (i32.load offset=332
                   (local.get $0)
                  )
                  (i32.const 22)
                 )
                )
                (i32.load offset=328
                 (local.get $0)
                )
               )
              )
              (br_if $block26
               (i32.eq
                (i32.load offset=395868
                 (local.get $2)
                )
                (i32.const 65978)
               )
              )
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 22)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 2)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 1)
             )
             (i32.store
              (local.get $4)
              (i32.const 65978)
             )
             (return)
            )
            (i64.store offset=248 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i64.store offset=236 align=4
             (local.get $0)
             (i64.const 0)
            )
            (i64.store offset=228 align=4
             (local.get $0)
             (i64.const 1)
            )
            (i32.store
             (local.get $0)
             (i32.const 0)
            )
            (i32.store offset=256
             (local.get $0)
             (local.get $18)
            )
            (i32.store offset=40
             (local.get $0)
             (i32.const 0)
            )
            (i32.store offset=4
             (local.get $0)
             (local.get $15)
            )
            (block $block27
             (br_if $block27
              (i32.eqz
               (local.tee $9
                (i32.load
                 (local.get $16)
                )
               )
              )
             )
             (local.set $12
              (i32.load
               (i32.add
                (local.get $9)
                (i32.and
                 (local.get $12)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block28)
            )
            (local.set $5
             (i32.const 28)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 28)
            )
            (local.set $6
             (i32.const 4)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 4)
            )
            (i32.store
             (local.tee $9
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 66018)
            )
            (local.set $12
             (call $fimport$3
              (local.get $1)
              (local.get $12)
             )
            )
            (br_if $block28
             (i32.eqz
              (local.tee $7
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (local.get $9)
             )
            )
            (br $block6)
           )
           (i32.store8 offset=341
            (local.get $0)
            (i32.const 1)
           )
           (return)
          )
          (i32.store offset=332
           (local.get $0)
           (local.get $9)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 66032)
          )
          (return_call_indirect $timport$0 (type $0)
           (local.get $0)
           (local.get $1)
           (i32.load offset=396200
            (local.get $2)
           )
          )
         )
         (i32.store offset=332
          (local.get $0)
          (local.get $9)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
          (i32.const 65978)
         )
         (return_call_indirect $timport$0 (type $0)
          (local.get $0)
          (local.get $1)
          (i32.load offset=395876
           (local.get $2)
          )
         )
        )
        (local.set $9
         (i32.load
          (local.get $15)
         )
        )
        (br $block6)
       )
       (local.set $9
        (i32.load
         (local.get $15)
        )
       )
       (br $block6)
      )
      (local.set $9
       (i32.load
        (local.get $18)
       )
      )
      (br $block6)
     )
     (local.set $9
      (i32.load
       (local.get $19)
      )
     )
     (br $block6)
    )
    (block $block34
     (block $block31
      (block $block30
       (block $block29
        (br_if $block29
         (i32.eqz
          (local.tee $9
           (i32.load
            (local.get $14)
           )
          )
         )
        )
        (local.set $9
         (i32.load
          (i32.add
           (local.get $9)
           (i32.and
            (local.get $13)
            (i32.const 4092)
           )
          )
         )
        )
        (br $block30)
       )
       (local.set $5
        (i32.const 28)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 28)
       )
       (local.set $6
        (i32.const 4)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 4)
       )
       (i32.store
        (local.tee $8
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
        )
        (i32.const 66018)
       )
       (local.set $9
        (call $fimport$3
         (local.get $1)
         (local.get $13)
        )
       )
       (br_if $block31
        (local.tee $7
         (i32.load8_u offset=296
          (local.get $0)
         )
        )
       )
      )
      (i32.store offset=168
       (local.get $0)
       (local.get $9)
      )
      (i32.store offset=60
       (local.get $0)
       (local.get $12)
      )
      (i32.store offset=56
       (local.get $0)
       (local.get $4)
      )
      (block $block33
       (block $block32
        (br_if $block32
         (i32.eqz
          (local.tee $12
           (i32.load
            (local.get $11)
           )
          )
         )
        )
        (local.set $4
         (i32.load
          (i32.add
           (local.get $12)
           (i32.and
            (local.get $4)
            (i32.const 4092)
           )
          )
         )
        )
        (br $block33)
       )
       (local.set $5
        (i32.const 29)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 29)
       )
       (local.set $6
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (local.tee $12
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
        )
        (i32.const 66022)
       )
       (local.set $4
        (call $fimport$3
         (local.get $1)
         (local.get $4)
        )
       )
       (br_if $block34
        (local.tee $7
         (i32.load8_u offset=296
          (local.get $0)
         )
        )
       )
      )
      (i32.store offset=56
       (local.get $0)
       (local.get $3)
      )
      (i32.store offset=28
       (local.get $0)
       (local.get $4)
      )
      (i32.store offset=32
       (local.get $0)
       (i32.const 70396)
      )
      (block $block38
       (block $block37
        (block $block36
         (block $block35
          (br_if $block35
           (i32.eqz
            (local.tee $4
             (i32.load
              (i32.add
               (local.get $10)
               (i32.const 68)
              )
             )
            )
           )
          )
          (local.set $4
           (i32.load
            (i32.add
             (local.get $4)
             (i32.const 764)
            )
           )
          )
          (br $block36)
         )
         (local.set $5
          (i32.const 31)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 308)
          )
          (i32.const 31)
         )
         (local.set $6
          (i32.const 2)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 292)
          )
          (i32.const 2)
         )
         (i32.store
          (local.tee $10
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
          )
          (i32.const 66026)
         )
         (local.set $4
          (call $fimport$3
           (local.get $1)
           (i32.const 70396)
          )
         )
         (br_if $block37
          (local.tee $7
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
        )
        (i64.store offset=248 align=4
         (local.get $0)
         (i64.const 0)
        )
        (i64.store offset=236 align=4
         (local.get $0)
         (i64.const 0)
        )
        (i32.store offset=228
         (local.get $0)
         (i32.eq
          (local.get $4)
          (local.get $15)
         )
        )
        (i32.store
         (local.get $0)
         (local.tee $4
          (i32.xor
           (local.get $4)
           (local.get $15)
          )
         )
        )
        (i32.store offset=232
         (local.get $0)
         (i32.shr_u
          (local.get $4)
          (i32.const 31)
         )
        )
        (local.set $7
         (i32.const 1)
        )
        (br_if $block38
         (i32.and
          (local.get $9)
          (i32.const 1)
         )
        )
        (local.set $6
         (i32.const 2)
        )
        (local.set $5
         (i32.const 33)
        )
        (br $block6)
       )
       (local.set $9
        (i32.load
         (local.get $10)
        )
       )
       (br $block6)
      )
      (local.set $5
       (i32.const 33)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 33)
      )
      (local.set $6
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $9
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
       )
       (i32.const 66030)
      )
      (call $fimport$4
       (local.get $0)
       (i32.const 42)
       (local.get $1)
      )
      (local.set $9
       (i32.load
        (local.get $9)
       )
      )
      (local.set $7
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
      (br $block6)
     )
     (local.set $9
      (i32.load
       (local.get $8)
      )
     )
     (br $block6)
    )
    (local.set $9
     (i32.load
      (local.get $12)
     )
    )
    (br $block6)
   )
   (local.set $9
    (i32.load offset=188
     (local.get $0)
    )
   )
  )
  (block $block40
   (block $block39
    (br_if $block39
     (i32.ge_u
      (local.tee $4
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $5)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block40
     (i32.eq
      (i32.load
       (local.tee $10
        (i32.add
         (local.get $2)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $9)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $9)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $6)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $9)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $7)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $4)
  )
  (i32.store offset=188
   (local.get $0)
   (local.get $9)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $10)
   )
  )
 )
 ;; custom section "linking", size 43
 ;; custom section "reloc.CODE", size 82
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

