(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "bfin_hwloop_step" (func $fimport$0 (param i32 i32 i32)))
 (export "bb_0x0001037a" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (block $block3
   (block $block
    (br_if $block
     (i32.gt_u
      (i32.add
       (local.tee $2
        (i32.load offset=160
         (local.get $0)
        )
       )
       (i32.const -66455)
      )
      (i32.const -30)
     )
    )
    (br_if $block
     (i32.gt_u
      (i32.add
       (i32.load offset=164
        (local.get $0)
       )
       (i32.const -66455)
      )
      (i32.const -30)
     )
    )
    (local.set $3
     (i32.load offset=324
      (local.get $0)
     )
    )
    (i64.store offset=36 align=4
     (local.get $0)
     (i64.const 35184372159228)
    )
    (i32.store offset=164
     (local.get $0)
     (i32.const 66462)
    )
    (i32.store offset=148
     (local.get $0)
     (i32.const 66458)
    )
    (i64.store align=4
     (local.get $0)
     (i64.const 7149081452278623)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 1)
    )
    (i32.store offset=156
     (local.get $0)
     (i32.const 8192)
    )
    (i32.store
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
     (i32.const 66458)
    )
    (block $block1
     (br_if $block1
      (i32.ne
       (local.get $2)
       (i32.const 66454)
      )
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 308)
      )
      (i32.const 8)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 292)
      )
      (i32.const 4)
     )
     (call $fimport$0
      (local.get $0)
      (i32.const 66454)
      (i32.const 66454)
     )
    )
    (block $block2
     (br_if $block2
      (i32.ge_u
       (local.tee $2
        (i32.add
         (i32.load offset=332
          (local.get $0)
         )
         (i32.const 8)
        )
       )
       (i32.load offset=328
        (local.get $0)
       )
      )
     )
     (br_if $block3
      (i32.eq
       (i32.load offset=398748
        (local.get $3)
       )
       (i32.const 66458)
      )
     )
    )
    (i32.store offset=308
     (local.get $0)
     (i32.const 8)
    )
    (i32.store offset=292
     (local.get $0)
     (i32.const 4)
    )
    (i32.store
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
     (i32.const 66458)
    )
    (return)
   )
   (i32.store8 offset=341
    (local.get $0)
    (i32.const 1)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $2)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store
   (i32.add
    (local.get $0)
    (i32.const 188)
   )
   (i32.const 66458)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=398756
    (local.get $3)
   )
  )
 )
 ;; custom section "linking", size 31
 ;; custom section "reloc.CODE", size 14
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

