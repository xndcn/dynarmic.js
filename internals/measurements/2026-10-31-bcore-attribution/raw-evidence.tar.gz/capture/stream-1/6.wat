(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32 i32 i32)))
 (type $2 (func (param i32 i32) (result i32)))
 (type $3 (func (param i32 i32 i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_read32" (func $fimport$1 (param i32 i32) (result i32)))
 (import "env" "cec_exception" (func $fimport$2 (param i32 i32 i32)))
 (export "bb_0x00010368" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block24
   (block $block2
    (block $block19
     (block $block16
      (block $block13
       (block $block10
        (block $block7
         (block $block
          (br_if $block
           (i32.gt_u
            (i32.add
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const -66415)
            )
            (i32.const -8)
           )
          )
          (br_if $block
           (i32.gt_u
            (i32.add
             (i32.load offset=164
              (local.get $0)
             )
             (i32.const -66415)
            )
            (i32.const -8)
           )
          )
          (local.set $2
           (i32.load offset=324
            (local.get $0)
           )
          )
          (block $block1
           (br_if $block1
            (i32.eqz
             (i32.and
              (local.tee $3
               (i32.load offset=60
                (local.get $0)
               )
              )
              (i32.const 3)
             )
            )
           )
           (local.set $4
            (i32.const 1)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 1)
           )
           (local.set $5
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 4)
           )
           (call $fimport$0
            (local.get $0)
            (local.get $1)
            (i32.const 66408)
            (local.get $3)
            (i32.const 0)
           )
           (local.set $6
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
           (br $block2)
          )
          (block $block4
           (block $block3
            (br_if $block3
             (i32.eqz
              (local.tee $8
               (i32.load
                (i32.add
                 (local.tee $7
                  (i32.load offset=312
                   (local.get $0)
                  )
                 )
                 (i32.and
                  (i32.shr_u
                   (local.get $3)
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (i32.add
               (local.get $8)
               (i32.and
                (local.get $3)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block4)
           )
           (local.set $4
            (i32.const 1)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 1)
           )
           (local.set $5
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 4)
           )
           (local.set $9
            (call $fimport$1
             (local.get $1)
             (local.get $3)
            )
           )
           (br_if $block2
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (block $block6
           (block $block5
            (br_if $block5
             (i32.eqz
              (local.tee $4
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $8
                    (i32.add
                     (local.get $3)
                     (i32.const 4)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $8
             (i32.load
              (i32.add
               (local.get $4)
               (i32.and
                (local.get $8)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block6)
           )
           (local.set $4
            (i32.const 1)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 1)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 4)
           )
           (local.set $8
            (call $fimport$1
             (local.get $1)
             (local.get $8)
            )
           )
           (br_if $block7
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (i32.store offset=168
           (local.get $0)
           (local.get $8)
          )
          (i32.store offset=60
           (local.get $0)
           (local.get $9)
          )
          (i32.store offset=56
           (local.get $0)
           (local.tee $9
            (i32.add
             (local.get $3)
             (i32.const 8)
            )
           )
          )
          (block $block9
           (block $block8
            (br_if $block8
             (i32.eqz
              (local.tee $4
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.get $9)
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (i32.add
               (local.get $4)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block9)
           )
           (local.set $4
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 2)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (i32.const 66412)
           )
           (local.set $9
            (call $fimport$1
             (local.get $1)
             (local.get $9)
            )
           )
           (br_if $block10
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (i32.store offset=52
           (local.get $0)
           (local.get $9)
          )
          (block $block12
           (block $block11
            (br_if $block11
             (i32.eqz
              (local.tee $4
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $9
                    (i32.add
                     (local.get $3)
                     (i32.const 12)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (i32.add
               (local.get $4)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block12)
           )
           (local.set $4
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 2)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (i32.const 66412)
           )
           (local.set $9
            (call $fimport$1
             (local.get $1)
             (local.get $9)
            )
           )
           (br_if $block13
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (i32.store offset=48
           (local.get $0)
           (local.get $9)
          )
          (block $block15
           (block $block14
            (br_if $block14
             (i32.eqz
              (local.tee $4
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $9
                    (i32.add
                     (local.get $3)
                     (i32.const 16)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (i32.add
               (local.get $4)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block15)
           )
           (local.set $4
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 2)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (i32.const 66412)
           )
           (local.set $9
            (call $fimport$1
             (local.get $1)
             (local.get $9)
            )
           )
           (br_if $block16
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (i32.store offset=44
           (local.get $0)
           (local.get $9)
          )
          (block $block18
           (block $block17
            (br_if $block17
             (i32.eqz
              (local.tee $4
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $9
                    (i32.add
                     (local.get $3)
                     (i32.const 20)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (local.set $9
             (i32.load
              (i32.add
               (local.get $4)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
             )
            )
            (br $block18)
           )
           (local.set $4
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 2)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (i32.const 66412)
           )
           (local.set $9
            (call $fimport$1
             (local.get $1)
             (local.get $9)
            )
           )
           (br_if $block19
            (local.tee $6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (i32.store offset=28
           (local.get $0)
           (local.get $9)
          )
          (block $block23
           (block $block22
            (block $block21
             (block $block20
              (br_if $block20
               (i32.eqz
                (local.tee $7
                 (i32.load
                  (i32.add
                   (local.get $7)
                   (i32.and
                    (i32.shr_u
                     (local.tee $9
                      (i32.add
                       (local.get $3)
                       (i32.const 24)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $7
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (local.get $9)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block21)
             )
             (local.set $4
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
              (i32.const 2)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
              )
              (i32.const 66412)
             )
             (local.set $7
              (call $fimport$1
               (local.get $1)
               (local.get $9)
              )
             )
             (br_if $block22
              (local.tee $6
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i32.store offset=24
             (local.get $0)
             (local.get $7)
            )
            (i32.store offset=56
             (local.get $0)
             (i32.add
              (local.get $3)
              (i32.const 28)
             )
            )
            (local.set $6
             (i32.const 1)
            )
            (br_if $block23
             (i32.and
              (local.get $8)
              (i32.const 1)
             )
            )
            (local.set $5
             (i32.const 2)
            )
            (local.set $4
             (i32.const 3)
            )
            (br $block24)
           )
           (local.set $8
            (i32.load
             (local.get $5)
            )
           )
           (local.set $5
            (i32.const 2)
           )
           (br $block24)
          )
          (local.set $4
           (i32.const 3)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 3)
          )
          (local.set $5
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 2)
          )
          (i32.store
           (local.tee $3
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66414)
          )
          (call $fimport$2
           (local.get $0)
           (i32.const 42)
           (local.get $1)
          )
          (local.set $8
           (i32.load
            (local.get $3)
           )
          )
          (local.set $6
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
          (br $block24)
         )
         (i32.store8 offset=341
          (local.get $0)
          (i32.const 1)
         )
         (return)
        )
        (local.set $8
         (i32.load offset=188
          (local.get $0)
         )
        )
        (local.set $5
         (i32.const 4)
        )
        (br $block24)
       )
       (local.set $8
        (i32.load
         (local.get $5)
        )
       )
       (local.set $5
        (i32.const 2)
       )
       (br $block24)
      )
      (local.set $8
       (i32.load
        (local.get $5)
       )
      )
      (local.set $5
       (i32.const 2)
      )
      (br $block24)
     )
     (local.set $8
      (i32.load
       (local.get $5)
      )
     )
     (local.set $5
      (i32.const 2)
     )
     (br $block24)
    )
    (local.set $8
     (i32.load
      (local.get $5)
     )
    )
    (local.set $5
     (i32.const 2)
    )
    (br $block24)
   )
   (local.set $8
    (i32.load offset=188
     (local.get $0)
    )
   )
  )
  (block $block26
   (block $block25
    (br_if $block25
     (i32.ge_u
      (local.tee $3
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $4)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block26
     (i32.eq
      (i32.load
       (local.tee $7
        (i32.add
         (local.get $2)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $8)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $8)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $4)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $8)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $6)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $3)
  )
  (i32.store offset=188
   (local.get $0)
   (local.get $8)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $7)
   )
  )
 )
 ;; custom section "linking", size 37
 ;; custom section "reloc.CODE", size 45
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

