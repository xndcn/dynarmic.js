(module
 (type $0 (func (param i32 i32 i32)))
 (type $1 (func (param i32 i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32 i32) (result i32)))
 (type $4 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_read32" (func $fimport$1 (param i32 i32) (result i32)))
 (import "env" "mem_write32" (func $fimport$2 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$3 (param i32)))
 (import "env" "cec_exception" (func $fimport$4 (param i32 i32 i32)))
 (export "bb_0x000101ba" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i32)
  (local $23 i32)
  (local $24 i32)
  (local $25 i32)
  (local $26 i32)
  (local $27 i32)
  (local $28 i32)
  (local $29 i32)
  (local $30 i32)
  (local $31 i32)
  (local $32 i32)
  (block $block11
   (block $block
    (br_if $block
     (i32.gt_u
      (i32.add
       (i32.load offset=160
        (local.get $0)
       )
       (i32.const -66031)
      )
      (i32.const -54)
     )
    )
    (br_if $block
     (i32.gt_u
      (i32.add
       (i32.load offset=164
        (local.get $0)
       )
       (i32.const -66031)
      )
      (i32.const -54)
     )
    )
    (local.set $2
     (i32.load offset=312
      (local.get $0)
     )
    )
    (local.set $3
     (i32.load offset=316
      (local.get $0)
     )
    )
    (local.set $4
     (i32.load offset=328
      (local.get $0)
     )
    )
    (local.set $5
     (i32.load offset=324
      (local.get $0)
     )
    )
    (local.set $6
     (i32.load
      (local.get $0)
     )
    )
    (local.set $7
     (i32.load offset=8
      (local.get $0)
     )
    )
    (local.set $8
     (i32.load offset=12
      (local.get $0)
     )
    )
    (local.set $9
     (i32.load offset=28
      (local.get $0)
     )
    )
    (local.set $10
     (i32.load offset=32
      (local.get $0)
     )
    )
    (local.set $11
     (i32.load offset=36
      (local.get $0)
     )
    )
    (local.set $12
     (i32.load offset=256
      (local.get $0)
     )
    )
    (local.set $13
     (i32.load offset=276
      (local.get $0)
     )
    )
    (local.set $14
     (i32.load offset=332
      (local.get $0)
     )
    )
    (block $block23
     (loop $label1
      (local.set $15
       (i32.xor
        (local.get $7)
        (i32.const -1)
       )
      )
      (local.set $16
       (i32.and
        (local.get $10)
        (i32.const 3)
       )
      )
      (local.set $17
       (i32.const 0)
      )
      (local.set $18
       (local.get $14)
      )
      (local.set $19
       (local.get $13)
      )
      (local.set $20
       (local.get $12)
      )
      (local.set $21
       (local.get $11)
      )
      (local.set $22
       (local.get $8)
      )
      (local.set $23
       (local.get $7)
      )
      (block $block22
       (block $block5
        (block $block2
         (loop $label
          (local.set $24
           (local.get $21)
          )
          (local.set $25
           (local.get $18)
          )
          (local.set $27
           (i32.shr_u
            (local.tee $18
             (i32.and
              (local.tee $26
               (i32.add
                (local.get $7)
                (local.get $17)
               )
              )
              (local.get $9)
             )
            )
            (i32.const 31)
           )
          )
          (local.set $21
           (i32.add
            (i32.shl
             (local.get $18)
             (i32.const 2)
            )
            (local.get $10)
           )
          )
          (local.set $28
           (i32.eqz
            (local.get $18)
           )
          )
          (block $block1
           (br_if $block1
            (i32.eqz
             (local.get $16)
            )
           )
           (i32.store offset=332
            (local.get $0)
            (local.get $14)
           )
           (i32.store offset=308
            (local.get $0)
            (i32.const 4)
           )
           (i32.store8 offset=296
            (local.get $0)
            (i32.const 0)
           )
           (i32.store offset=292
            (local.get $0)
            (i32.const 2)
           )
           (i32.store offset=276
            (local.get $0)
            (local.get $13)
           )
           (i32.store offset=256
            (local.get $0)
            (local.get $12)
           )
           (i64.store offset=248 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i64.store offset=236 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i32.store offset=232
            (local.get $0)
            (local.get $27)
           )
           (i32.store offset=228
            (local.get $0)
            (local.get $28)
           )
           (i32.store offset=188
            (local.get $0)
            (i32.const 65984)
           )
           (i32.store offset=40
            (local.get $0)
            (local.get $21)
           )
           (i32.store offset=36
            (local.get $0)
            (local.get $11)
           )
           (i32.store offset=32
            (local.get $0)
            (local.get $10)
           )
           (i32.store offset=28
            (local.get $0)
            (local.get $9)
           )
           (i32.store offset=12
            (local.get $0)
            (local.get $8)
           )
           (i32.store offset=8
            (local.get $0)
            (local.get $7)
           )
           (i32.store offset=4
            (local.get $0)
            (local.get $18)
           )
           (i32.store
            (local.get $0)
            (local.get $6)
           )
           (call $fimport$0
            (local.get $0)
            (local.get $1)
            (i32.const 65984)
            (local.get $21)
            (i32.const 0)
           )
           (br $block2)
          )
          (local.set $30
           (i32.add
            (local.tee $29
             (i32.load
              (i32.add
               (local.get $2)
               (i32.and
                (i32.shr_u
                 (local.get $21)
                 (i32.const 10)
                )
                (i32.const 4194300)
               )
              )
             )
            )
            (i32.and
             (local.get $21)
             (i32.const 4092)
            )
           )
          )
          (block $block4
           (block $block3
            (br_if $block3
             (i32.eqz
              (local.get $29)
             )
            )
            (local.set $27
             (i32.load
              (local.get $30)
             )
            )
            (br $block4)
           )
           (i32.store offset=332
            (local.get $0)
            (local.get $25)
           )
           (i32.store offset=308
            (local.get $0)
            (i32.const 4)
           )
           (i32.store8 offset=296
            (local.get $0)
            (i32.const 0)
           )
           (i32.store offset=292
            (local.get $0)
            (i32.const 2)
           )
           (i32.store offset=276
            (local.get $0)
            (local.get $19)
           )
           (i32.store offset=256
            (local.get $0)
            (local.get $20)
           )
           (i64.store offset=248 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i64.store offset=236 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i32.store offset=232
            (local.get $0)
            (local.get $27)
           )
           (i32.store offset=228
            (local.get $0)
            (local.get $28)
           )
           (i32.store offset=188
            (local.get $0)
            (i32.const 65984)
           )
           (i32.store offset=40
            (local.get $0)
            (local.get $21)
           )
           (i32.store offset=36
            (local.get $0)
            (local.get $24)
           )
           (i32.store offset=32
            (local.get $0)
            (local.get $10)
           )
           (i32.store offset=28
            (local.get $0)
            (local.get $9)
           )
           (i32.store offset=12
            (local.get $0)
            (local.get $22)
           )
           (i32.store offset=8
            (local.get $0)
            (local.get $26)
           )
           (i32.store offset=4
            (local.get $0)
            (local.get $18)
           )
           (i32.store
            (local.get $0)
            (local.get $6)
           )
           (local.set $27
            (call $fimport$1
             (local.get $1)
             (local.get $21)
            )
           )
           (br_if $block5
            (local.tee $31
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (local.set $28
           (i32.xor
            (i32.shr_u
             (local.tee $18
              (i32.add
               (i32.add
                (local.get $7)
                (local.get $27)
               )
               (local.get $17)
              )
             )
             (i32.const 11)
            )
            (local.get $18)
           )
          )
          (local.set $20
           (i32.or
            (i32.shr_u
             (i32.and
              (i32.xor
               (local.get $18)
               (local.get $26)
              )
              (i32.xor
               (local.get $18)
               (local.get $27)
              )
             )
             (i32.const 31)
            )
            (local.get $20)
           )
          )
          (local.set $22
           (i32.shr_u
            (local.get $18)
            (i32.const 31)
           )
          )
          (local.set $32
           (i32.eqz
            (local.get $18)
           )
          )
          (block $block7
           (block $block6
            (br_if $block6
             (i32.eqz
              (local.get $29)
             )
            )
            (i32.store
             (local.get $30)
             (local.get $28)
            )
            (br $block7)
           )
           (i32.store offset=332
            (local.get $0)
            (local.get $25)
           )
           (i32.store offset=308
            (local.get $0)
            (i32.const 8)
           )
           (i32.store8 offset=296
            (local.get $0)
            (i32.const 0)
           )
           (i32.store offset=292
            (local.get $0)
            (i32.const 2)
           )
           (i32.store offset=276
            (local.get $0)
            (local.get $19)
           )
           (i32.store offset=256
            (local.get $0)
            (local.get $20)
           )
           (i64.store offset=248 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i64.store offset=236 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i32.store offset=232
            (local.get $0)
            (local.get $22)
           )
           (i32.store offset=228
            (local.get $0)
            (local.get $32)
           )
           (i32.store offset=188
            (local.get $0)
            (i32.const 65994)
           )
           (i32.store offset=40
            (local.get $0)
            (local.get $21)
           )
           (i32.store offset=36
            (local.get $0)
            (local.get $24)
           )
           (i32.store offset=32
            (local.get $0)
            (local.get $10)
           )
           (i32.store offset=28
            (local.get $0)
            (local.get $9)
           )
           (i32.store offset=12
            (local.get $0)
            (local.get $18)
           )
           (i32.store offset=8
            (local.get $0)
            (local.get $26)
           )
           (i32.store offset=4
            (local.get $0)
            (local.get $28)
           )
           (i32.store
            (local.get $0)
            (local.get $6)
           )
           (call $fimport$2
            (local.get $1)
            (local.get $21)
            (local.get $28)
           )
           (br_if $block5
            (local.tee $31
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (block $block8
           (br_if $block8
            (i32.eqz
             (i32.load8_u
              (local.get $3)
             )
            )
           )
           (i32.store offset=332
            (local.get $0)
            (local.get $25)
           )
           (i32.store offset=308
            (local.get $0)
            (i32.const 8)
           )
           (i32.store8 offset=296
            (local.get $0)
            (i32.const 0)
           )
           (i32.store offset=292
            (local.get $0)
            (i32.const 2)
           )
           (i32.store offset=276
            (local.get $0)
            (local.get $19)
           )
           (i32.store offset=256
            (local.get $0)
            (local.get $20)
           )
           (i64.store offset=248 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i64.store offset=236 align=4
            (local.get $0)
            (i64.const 0)
           )
           (i32.store offset=232
            (local.get $0)
            (local.get $22)
           )
           (i32.store offset=228
            (local.get $0)
            (local.get $32)
           )
           (i32.store offset=188
            (local.get $0)
            (i32.const 65996)
           )
           (i32.store offset=40
            (local.get $0)
            (local.get $21)
           )
           (i32.store offset=36
            (local.get $0)
            (local.get $24)
           )
           (i32.store offset=32
            (local.get $0)
            (local.get $10)
           )
           (i32.store offset=28
            (local.get $0)
            (local.get $9)
           )
           (i32.store offset=12
            (local.get $0)
            (local.get $18)
           )
           (i32.store offset=8
            (local.get $0)
            (local.get $26)
           )
           (i32.store offset=4
            (local.get $0)
            (local.get $28)
           )
           (i32.store
            (local.get $0)
            (local.get $6)
           )
           (call $fimport$3
            (local.get $0)
           )
           (br_if $block5
            (local.tee $31
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
          )
          (local.set $20
           (i32.or
            (local.get $20)
            (local.tee $29
             (i32.shr_u
              (i32.and
               (local.tee $18
                (i32.add
                 (local.get $26)
                 (i32.const 1)
                )
               )
               (local.get $15)
              )
              (i32.const 31)
             )
            )
           )
          )
          (block $block21
           (block $block10
            (block $block9
             (br_if $block9
              (local.tee $19
               (i32.le_u
                (local.get $6)
                (local.get $18)
               )
              )
             )
             (br_if $block10
              (i32.lt_u
               (local.tee $18
                (i32.add
                 (local.get $25)
                 (i32.const 13)
                )
               )
               (local.get $4)
              )
             )
             (br $block11)
            )
            (local.set $11
             (i32.add
              (local.get $26)
              (i32.add
               (local.get $24)
               (local.get $27)
              )
             )
            )
            (local.set $8
             (i32.add
              (local.get $26)
              (local.get $27)
             )
            )
            (local.set $12
             (i32.or
              (local.get $20)
              (i32.shr_u
               (i32.and
                (local.get $6)
                (i32.sub
                 (i32.const 0)
                 (local.get $6)
                )
               )
               (i32.const 31)
              )
             )
            )
            (local.set $23
             (i32.eqz
              (local.tee $30
               (i32.and
                (i32.add
                 (local.get $6)
                 (i32.const -1)
                )
                (i32.const 8191)
               )
              )
             )
            )
            (block $block12
             (br_if $block12
              (i32.eqz
               (i32.and
                (local.tee $26
                 (i32.load offset=60
                  (local.get $0)
                 )
                )
                (i32.const 3)
               )
              )
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $25)
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 19)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 0)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 4)
             )
             (i32.store offset=276
              (local.get $0)
              (local.get $19)
             )
             (i32.store offset=256
              (local.get $0)
              (local.get $12)
             )
             (i64.store offset=248 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=240
              (local.get $0)
              (i32.const 0)
             )
             (i64.store offset=232 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=228
              (local.get $0)
              (local.get $23)
             )
             (i32.store offset=188
              (local.get $0)
              (i32.const 66018)
             )
             (i32.store offset=40
              (local.get $0)
              (local.get $30)
             )
             (i32.store offset=36
              (local.get $0)
              (local.get $11)
             )
             (i32.store offset=32
              (local.get $0)
              (local.get $10)
             )
             (i32.store offset=28
              (local.get $0)
              (local.get $9)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $8)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $18)
             )
             (i32.store offset=4
              (local.get $0)
              (local.get $11)
             )
             (i32.store
              (local.get $0)
              (local.get $30)
             )
             (call $fimport$0
              (local.get $0)
              (local.get $1)
              (i32.const 66018)
              (local.get $26)
              (i32.const 0)
             )
             (br $block2)
            )
            (block $block14
             (block $block13
              (br_if $block13
               (i32.eqz
                (local.tee $21
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.and
                    (i32.shr_u
                     (local.get $26)
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $29
               (i32.load
                (i32.add
                 (local.get $21)
                 (i32.and
                  (local.get $26)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block14)
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $25)
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 19)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 0)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 4)
             )
             (i32.store offset=276
              (local.get $0)
              (local.get $19)
             )
             (i32.store offset=256
              (local.get $0)
              (local.get $12)
             )
             (i64.store offset=248 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=240
              (local.get $0)
              (i32.const 0)
             )
             (i64.store offset=232 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=228
              (local.get $0)
              (local.get $23)
             )
             (i32.store offset=188
              (local.get $0)
              (i32.const 66018)
             )
             (i32.store offset=40
              (local.get $0)
              (local.get $30)
             )
             (i32.store offset=36
              (local.get $0)
              (local.get $11)
             )
             (i32.store offset=32
              (local.get $0)
              (local.get $10)
             )
             (i32.store offset=28
              (local.get $0)
              (local.get $9)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $8)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $18)
             )
             (i32.store offset=4
              (local.get $0)
              (local.get $11)
             )
             (i32.store
              (local.get $0)
              (local.get $30)
             )
             (local.set $29
              (call $fimport$1
               (local.get $1)
               (local.get $26)
              )
             )
             (br_if $block5
              (local.tee $31
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (block $block16
             (block $block15
              (br_if $block15
               (i32.eqz
                (local.tee $15
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.and
                    (i32.shr_u
                     (local.tee $21
                      (i32.add
                       (local.get $26)
                       (i32.const 4)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $21
               (i32.load
                (i32.add
                 (local.get $15)
                 (i32.and
                  (local.get $21)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block16)
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $25)
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 19)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 0)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 4)
             )
             (i32.store offset=276
              (local.get $0)
              (local.get $19)
             )
             (i32.store offset=256
              (local.get $0)
              (local.get $12)
             )
             (i64.store offset=248 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=240
              (local.get $0)
              (i32.const 0)
             )
             (i64.store offset=232 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=228
              (local.get $0)
              (local.get $23)
             )
             (i32.store offset=188
              (local.get $0)
              (i32.const 66018)
             )
             (i32.store offset=40
              (local.get $0)
              (local.get $30)
             )
             (i32.store offset=36
              (local.get $0)
              (local.get $11)
             )
             (i32.store offset=32
              (local.get $0)
              (local.get $10)
             )
             (i32.store offset=28
              (local.get $0)
              (local.get $9)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $8)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $18)
             )
             (i32.store offset=4
              (local.get $0)
              (local.get $11)
             )
             (i32.store
              (local.get $0)
              (local.get $30)
             )
             (local.set $21
              (call $fimport$1
               (local.get $1)
               (local.get $21)
              )
             )
             (br_if $block5
              (local.tee $31
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i32.store offset=168
             (local.get $0)
             (local.get $21)
            )
            (i32.store offset=60
             (local.get $0)
             (local.get $29)
            )
            (i32.store offset=56
             (local.get $0)
             (local.tee $29
              (i32.add
               (local.get $26)
               (i32.const 8)
              )
             )
            )
            (block $block18
             (block $block17
              (br_if $block17
               (i32.eqz
                (local.tee $15
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.and
                    (i32.shr_u
                     (local.get $29)
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $9
               (i32.load
                (i32.add
                 (local.get $15)
                 (i32.and
                  (local.get $29)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block18)
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $25)
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 20)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 0)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 2)
             )
             (i32.store offset=276
              (local.get $0)
              (local.get $19)
             )
             (i32.store offset=256
              (local.get $0)
              (local.get $12)
             )
             (i64.store offset=248 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=240
              (local.get $0)
              (i32.const 0)
             )
             (i64.store offset=232 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=228
              (local.get $0)
              (local.get $23)
             )
             (i32.store offset=188
              (local.get $0)
              (i32.const 66022)
             )
             (i32.store offset=40
              (local.get $0)
              (local.get $30)
             )
             (i32.store offset=36
              (local.get $0)
              (local.get $11)
             )
             (i32.store offset=32
              (local.get $0)
              (local.get $10)
             )
             (i32.store offset=28
              (local.get $0)
              (local.get $9)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $8)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $18)
             )
             (i32.store offset=4
              (local.get $0)
              (local.get $11)
             )
             (i32.store
              (local.get $0)
              (local.get $30)
             )
             (local.set $9
              (call $fimport$1
               (local.get $1)
               (local.get $29)
              )
             )
             (br_if $block5
              (local.tee $31
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (i32.store offset=56
             (local.get $0)
             (i32.add
              (local.get $26)
              (i32.const 12)
             )
            )
            (block $block20
             (block $block19
              (br_if $block19
               (i32.eqz
                (local.tee $26
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.and
                    (i32.shr_u
                     (local.tee $10
                      (i32.add
                       (i32.shl
                        (local.get $30)
                        (i32.const 2)
                       )
                       (local.get $10)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $26
               (i32.load
                (i32.add
                 (local.get $26)
                 (i32.and
                  (local.get $10)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block20)
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $25)
             )
             (i32.store offset=308
              (local.get $0)
              (i32.const 22)
             )
             (i32.store8 offset=296
              (local.get $0)
              (i32.const 0)
             )
             (i32.store offset=292
              (local.get $0)
              (i32.const 2)
             )
             (i32.store offset=276
              (local.get $0)
              (local.get $19)
             )
             (i32.store offset=256
              (local.get $0)
              (local.get $12)
             )
             (i64.store offset=248 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=240
              (local.get $0)
              (i32.const 0)
             )
             (i64.store offset=232 align=4
              (local.get $0)
              (i64.const 0)
             )
             (i32.store offset=228
              (local.get $0)
              (local.get $23)
             )
             (i32.store offset=188
              (local.get $0)
              (i32.const 66026)
             )
             (i32.store offset=40
              (local.get $0)
              (local.get $30)
             )
             (i32.store offset=36
              (local.get $0)
              (local.get $11)
             )
             (i32.store offset=32
              (local.get $0)
              (local.get $10)
             )
             (i32.store offset=28
              (local.get $0)
              (local.get $9)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $8)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $18)
             )
             (i32.store offset=4
              (local.get $0)
              (local.get $11)
             )
             (i32.store
              (local.get $0)
              (local.get $30)
             )
             (local.set $26
              (call $fimport$1
               (local.get $1)
               (local.get $10)
              )
             )
             (br_if $block5
              (local.tee $31
               (i32.load8_u offset=296
                (local.get $0)
               )
              )
             )
            )
            (local.set $29
             (i32.shr_u
              (local.tee $6
               (i32.xor
                (local.get $26)
                (local.get $11)
               )
              )
              (i32.const 31)
             )
            )
            (local.set $31
             (i32.const 1)
            )
            (local.set $17
             (i32.eqz
              (i32.add
               (i32.add
                (local.get $7)
                (i32.add
                 (i32.sub
                  (local.get $24)
                  (local.get $26)
                 )
                 (local.get $27)
                )
               )
               (local.get $17)
              )
             )
            )
            (br_if $block21
             (i32.and
              (local.get $21)
              (i32.const 1)
             )
            )
            (local.set $26
             (i32.const 0)
            )
            (local.set $15
             (i32.const 2)
            )
            (local.set $27
             (i32.const 24)
            )
            (local.set $13
             (local.get $19)
            )
            (local.set $23
             (i32.const 0)
            )
            (local.set $20
             (i32.const 0)
            )
            (local.set $24
             (i32.const 0)
            )
            (local.set $7
             (local.get $18)
            )
            (local.set $18
             (local.get $11)
            )
            (br $block22)
           )
           (local.set $21
            (i32.add
             (local.tee $22
              (i32.add
               (local.get $27)
               (local.get $23)
              )
             )
             (local.get $24)
            )
           )
           (local.set $23
            (i32.add
             (local.get $23)
             (i32.const 1)
            )
           )
           (local.set $17
            (i32.add
             (local.get $17)
             (i32.const 1)
            )
           )
           (local.set $15
            (i32.add
             (local.get $15)
             (i32.const -1)
            )
           )
           (br_if $label
            (i32.load offset=328
             (local.get $0)
            )
           )
           (br $block11)
          )
         )
         (i32.store offset=332
          (local.get $0)
          (local.get $25)
         )
         (i32.store offset=308
          (local.get $0)
          (i32.const 24)
         )
         (i32.store8 offset=296
          (local.get $0)
          (i32.const 0)
         )
         (i32.store offset=292
          (local.get $0)
          (i32.const 2)
         )
         (i32.store offset=276
          (local.get $0)
          (local.get $19)
         )
         (i32.store offset=256
          (local.get $0)
          (local.get $12)
         )
         (i64.store offset=248 align=4
          (local.get $0)
          (i64.const 0)
         )
         (i64.store offset=236 align=4
          (local.get $0)
          (i64.const 0)
         )
         (i32.store offset=232
          (local.get $0)
          (local.get $29)
         )
         (i32.store offset=228
          (local.get $0)
          (local.get $17)
         )
         (i32.store offset=188
          (local.get $0)
          (i32.const 66030)
         )
         (i32.store offset=40
          (local.get $0)
          (local.get $30)
         )
         (i32.store offset=36
          (local.get $0)
          (local.get $11)
         )
         (i32.store offset=32
          (local.get $0)
          (local.get $10)
         )
         (i32.store offset=28
          (local.get $0)
          (local.get $9)
         )
         (i32.store offset=12
          (local.get $0)
          (local.get $8)
         )
         (i32.store offset=8
          (local.get $0)
          (local.get $18)
         )
         (i32.store offset=4
          (local.get $0)
          (local.get $11)
         )
         (i32.store
          (local.get $0)
          (local.get $6)
         )
         (call $fimport$4
          (local.get $0)
          (i32.const 42)
          (local.get $1)
         )
        )
        (local.set $31
         (i32.load8_u offset=296
          (local.get $0)
         )
        )
       )
       (local.set $25
        (i32.load offset=332
         (local.get $0)
        )
       )
       (local.set $27
        (i32.load offset=308
         (local.get $0)
        )
       )
       (local.set $15
        (i32.load offset=292
         (local.get $0)
        )
       )
       (local.set $13
        (i32.load offset=276
         (local.get $0)
        )
       )
       (local.set $12
        (i32.load offset=256
         (local.get $0)
        )
       )
       (local.set $26
        (i32.load offset=252
         (local.get $0)
        )
       )
       (local.set $23
        (i32.load offset=248
         (local.get $0)
        )
       )
       (local.set $20
        (i32.load offset=240
         (local.get $0)
        )
       )
       (local.set $24
        (i32.load offset=236
         (local.get $0)
        )
       )
       (local.set $29
        (i32.load offset=232
         (local.get $0)
        )
       )
       (local.set $17
        (i32.load offset=228
         (local.get $0)
        )
       )
       (local.set $30
        (i32.load offset=40
         (local.get $0)
        )
       )
       (local.set $11
        (i32.load offset=36
         (local.get $0)
        )
       )
       (local.set $10
        (i32.load offset=32
         (local.get $0)
        )
       )
       (local.set $9
        (i32.load offset=28
         (local.get $0)
        )
       )
       (local.set $8
        (i32.load offset=12
         (local.get $0)
        )
       )
       (local.set $7
        (i32.load offset=8
         (local.get $0)
        )
       )
       (local.set $18
        (i32.load offset=4
         (local.get $0)
        )
       )
       (local.set $6
        (i32.load
         (local.get $0)
        )
       )
       (local.set $21
        (i32.load offset=188
         (local.get $0)
        )
       )
      )
      (br_if $block23
       (i32.ge_u
        (local.tee $14
         (i32.add
          (local.get $27)
          (local.get $25)
         )
        )
        (local.get $4)
       )
      )
      (br_if $block23
       (i32.eqz
        (i32.load offset=328
         (local.get $0)
        )
       )
      )
      (br_if $label1
       (i32.eq
        (local.get $21)
        (i32.const 65978)
       )
      )
     )
     (br_if $block23
      (i32.ne
       (i32.load
        (local.tee $28
         (i32.add
          (local.get $5)
          (i32.mul
           (i32.and
            (i32.shr_u
             (local.get $21)
             (i32.const 1)
            )
            (i32.const 65535)
           )
           (i32.const 12)
          )
         )
        )
       )
       (local.get $21)
      )
     )
     (local.set $25
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $14)
     )
     (i32.store offset=308
      (local.get $0)
      (local.get $27)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=292
      (local.get $0)
      (local.get $15)
     )
     (i32.store offset=276
      (local.get $0)
      (local.get $13)
     )
     (i32.store offset=256
      (local.get $0)
      (local.get $12)
     )
     (i32.store offset=252
      (local.get $0)
      (local.get $26)
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $23)
     )
     (i32.store offset=240
      (local.get $0)
      (local.get $20)
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $24)
     )
     (i32.store offset=232
      (local.get $0)
      (local.get $29)
     )
     (i32.store offset=228
      (local.get $0)
      (local.get $17)
     )
     (i32.store offset=188
      (local.get $0)
      (local.get $21)
     )
     (i32.store offset=40
      (local.get $0)
      (local.get $30)
     )
     (i32.store offset=36
      (local.get $0)
      (local.get $11)
     )
     (i32.store offset=32
      (local.get $0)
      (local.get $10)
     )
     (i32.store offset=28
      (local.get $0)
      (local.get $9)
     )
     (i32.store offset=12
      (local.get $0)
      (local.get $8)
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $7)
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $18)
     )
     (i32.store
      (local.get $0)
      (local.get $6)
     )
     (return_call_indirect $timport$0 (type $1)
      (local.get $0)
      (local.get $1)
      (local.get $25)
     )
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $25)
    )
    (i32.store offset=308
     (local.get $0)
     (local.get $27)
    )
    (i32.store8 offset=296
     (local.get $0)
     (local.get $31)
    )
    (i32.store offset=292
     (local.get $0)
     (local.get $15)
    )
    (i32.store offset=276
     (local.get $0)
     (local.get $13)
    )
    (i32.store offset=256
     (local.get $0)
     (local.get $12)
    )
    (i32.store offset=252
     (local.get $0)
     (local.get $26)
    )
    (i32.store offset=248
     (local.get $0)
     (local.get $23)
    )
    (i32.store offset=240
     (local.get $0)
     (local.get $20)
    )
    (i32.store offset=236
     (local.get $0)
     (local.get $24)
    )
    (i32.store offset=232
     (local.get $0)
     (local.get $29)
    )
    (i32.store offset=228
     (local.get $0)
     (local.get $17)
    )
    (i32.store offset=188
     (local.get $0)
     (local.get $21)
    )
    (i32.store offset=40
     (local.get $0)
     (local.get $30)
    )
    (i32.store offset=36
     (local.get $0)
     (local.get $11)
    )
    (i32.store offset=32
     (local.get $0)
     (local.get $10)
    )
    (i32.store offset=28
     (local.get $0)
     (local.get $9)
    )
    (i32.store offset=12
     (local.get $0)
     (local.get $8)
    )
    (i32.store offset=8
     (local.get $0)
     (local.get $7)
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $18)
    )
    (i32.store
     (local.get $0)
     (local.get $6)
    )
    (return)
   )
   (i32.store8 offset=341
    (local.get $0)
    (i32.const 1)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $25)
  )
  (i32.store offset=308
   (local.get $0)
   (i32.const 13)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 1)
  )
  (i32.store offset=292
   (local.get $0)
   (i32.const 2)
  )
  (i32.store offset=276
   (local.get $0)
   (local.get $19)
  )
  (i32.store offset=256
   (local.get $0)
   (local.get $20)
  )
  (i32.store offset=252
   (local.get $0)
   (local.get $29)
  )
  (i32.store offset=248
   (local.get $0)
   (local.get $29)
  )
  (i32.store offset=188
   (local.get $0)
   (i32.const 65978)
  )
  (i32.store offset=32
   (local.get $0)
   (local.get $10)
  )
  (i32.store offset=28
   (local.get $0)
   (local.get $9)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $28)
  )
  (i32.store
   (local.get $0)
   (local.get $6)
  )
  (i32.store offset=40
   (local.get $0)
   (local.tee $18
    (i32.add
     (local.get $26)
     (local.get $27)
    )
   )
  )
  (i32.store offset=36
   (local.get $0)
   (i32.add
    (local.get $26)
    (i32.add
     (local.get $24)
     (local.get $27)
    )
   )
  )
  (i32.store offset=12
   (local.get $0)
   (local.get $18)
  )
  (i32.store offset=8
   (local.get $0)
   (local.tee $18
    (i32.add
     (local.get $26)
     (i32.const 1)
    )
   )
  )
  (i32.store offset=240
   (local.get $0)
   (local.tee $27
    (i32.le_u
     (local.get $18)
     (local.get $6)
    )
   )
  )
  (i32.store offset=236
   (local.get $0)
   (local.get $27)
  )
  (i32.store offset=232
   (local.get $0)
   (i32.gt_u
    (local.get $18)
    (local.get $6)
   )
  )
  (i32.store offset=228
   (local.get $0)
   (i32.eq
    (i32.sub
     (local.get $26)
     (local.get $6)
    )
    (i32.const -1)
   )
  )
 )
 ;; custom section "linking", size 43
 ;; custom section "reloc.CODE", size 50
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

