(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32 i32 i32)))
 (type $2 (func (param i32 i32 i32)))
 (type $3 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (export "bb_0x0001039a" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i32)
  (local $23 i32)
  (local $24 i32)
  (block $block
   (br_if $block
    (i32.gt_u
     (i32.add
      (i32.load offset=160
       (local.get $0)
      )
      (i32.const -66467)
     )
     (i32.const -10)
    )
   )
   (br_if $block
    (i32.ne
     (i32.load offset=164
      (local.get $0)
     )
     (i32.const 66462)
    )
   )
   (br_if $block
    (i32.ne
     (i32.load offset=148
      (local.get $0)
     )
     (i32.const 66458)
    )
   )
   (local.set $2
    (i32.load offset=312
     (local.get $0)
    )
   )
   (local.set $3
    (i32.load offset=316
     (local.get $0)
    )
   )
   (local.set $4
    (i32.load offset=328
     (local.get $0)
    )
   )
   (local.set $5
    (i32.load offset=324
     (local.get $0)
    )
   )
   (local.set $6
    (i32.load
     (local.get $0)
    )
   )
   (local.set $7
    (i32.load offset=4
     (local.get $0)
    )
   )
   (local.set $8
    (i32.load offset=8
     (local.get $0)
    )
   )
   (local.set $9
    (i32.load offset=36
     (local.get $0)
    )
   )
   (local.set $10
    (i32.load offset=156
     (local.get $0)
    )
   )
   (local.set $11
    (i32.load offset=256
     (local.get $0)
    )
   )
   (local.set $12
    (i32.load offset=332
     (local.get $0)
    )
   )
   (block $block11
    (loop $label
     (local.set $11
      (i32.or
       (local.tee $14
        (i32.shr_u
         (i32.and
          (i32.xor
           (local.tee $13
            (i32.mul
             (local.get $7)
             (local.get $8)
            )
           )
           (local.tee $8
            (i32.add
             (local.get $13)
             (local.get $6)
            )
           )
          )
          (i32.xor
           (local.get $8)
           (local.get $6)
          )
         )
         (i32.const 31)
        )
       )
       (local.get $11)
      )
     )
     (local.set $13
      (i32.gt_u
       (local.get $6)
       (i32.xor
        (local.get $13)
        (i32.const -1)
       )
      )
     )
     (local.set $15
      (i32.shr_u
       (local.get $8)
       (i32.const 31)
      )
     )
     (local.set $16
      (i32.eqz
       (local.get $8)
      )
     )
     (block $block7
      (block $block2
       (block $block1
        (br_if $block1
         (i32.eqz
          (i32.and
           (local.get $9)
           (i32.const 3)
          )
         )
        )
        (i32.store offset=332
         (local.get $0)
         (local.get $12)
        )
        (i32.store offset=308
         (local.get $0)
         (i32.const 3)
        )
        (i32.store8 offset=296
         (local.get $0)
         (i32.const 0)
        )
        (i32.store offset=292
         (local.get $0)
         (i32.const 2)
        )
        (i32.store offset=256
         (local.get $0)
         (local.get $11)
        )
        (i32.store offset=252
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=248
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=240
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=236
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=232
         (local.get $0)
         (local.get $15)
        )
        (i32.store offset=228
         (local.get $0)
         (local.get $16)
        )
        (i32.store offset=188
         (local.get $0)
         (i32.const 66462)
        )
        (i32.store offset=156
         (local.get $0)
         (local.get $10)
        )
        (i32.store offset=36
         (local.get $0)
         (local.get $9)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $8)
        )
        (call $fimport$0
         (local.get $0)
         (local.get $1)
         (i32.const 66462)
         (local.get $9)
         (i32.const 65536)
        )
        (local.set $17
         (i32.load8_u offset=296
          (local.get $0)
         )
        )
        (br $block2)
       )
       (block $block4
        (block $block3
         (br_if $block3
          (i32.eqz
           (local.tee $18
            (i32.load
             (i32.add
              (local.get $2)
              (i32.and
               (i32.shr_u
                (local.get $9)
                (i32.const 10)
               )
               (i32.const 4194300)
              )
             )
            )
           )
          )
         )
         (i32.store
          (i32.add
           (local.get $18)
           (i32.and
            (local.get $9)
            (i32.const 4092)
           )
          )
          (local.get $8)
         )
         (br $block4)
        )
        (i32.store offset=332
         (local.get $0)
         (local.get $12)
        )
        (i32.store offset=308
         (local.get $0)
         (i32.const 3)
        )
        (i32.store8 offset=296
         (local.get $0)
         (i32.const 0)
        )
        (i32.store offset=292
         (local.get $0)
         (i32.const 2)
        )
        (i32.store offset=256
         (local.get $0)
         (local.get $11)
        )
        (i32.store offset=252
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=248
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=240
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=236
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=232
         (local.get $0)
         (local.get $15)
        )
        (i32.store offset=228
         (local.get $0)
         (local.get $16)
        )
        (i32.store offset=188
         (local.get $0)
         (i32.const 66462)
        )
        (i32.store offset=156
         (local.get $0)
         (local.get $10)
        )
        (i32.store offset=36
         (local.get $0)
         (local.get $9)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $8)
        )
        (call $fimport$1
         (local.get $1)
         (local.get $9)
         (local.get $8)
        )
        (br_if $block2
         (local.tee $17
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
        )
       )
       (local.set $9
        (i32.add
         (local.get $9)
         (i32.const 4)
        )
       )
       (block $block6
        (block $block5
         (br_if $block5
          (i32.lt_u
           (local.get $10)
           (i32.const 2)
          )
         )
         (local.set $10
          (i32.add
           (local.get $10)
           (i32.const -1)
          )
         )
         (br_if $block6
          (i32.load8_u
           (local.get $3)
          )
         )
         (local.set $18
          (i32.const 66458)
         )
         (local.set $19
          (i32.const 2)
         )
         (local.set $20
          (i32.const 1)
         )
         (local.set $21
          (i32.const 3)
         )
         (local.set $22
          (local.get $12)
         )
         (local.set $23
          (local.get $14)
         )
         (local.set $24
          (local.get $13)
         )
         (br $block7)
        )
        (block $block8
         (br_if $block8
          (i32.eqz
           (i32.load8_u
            (local.get $3)
           )
          )
         )
         (i32.store offset=332
          (local.get $0)
          (local.get $12)
         )
         (i32.store offset=308
          (local.get $0)
          (i32.const 3)
         )
         (i32.store8 offset=296
          (local.get $0)
          (i32.const 0)
         )
         (i32.store offset=292
          (local.get $0)
          (i32.const 2)
         )
         (i32.store offset=256
          (local.get $0)
          (local.get $11)
         )
         (i32.store offset=252
          (local.get $0)
          (local.get $14)
         )
         (i32.store offset=248
          (local.get $0)
          (local.get $14)
         )
         (i32.store offset=240
          (local.get $0)
          (local.get $13)
         )
         (i32.store offset=236
          (local.get $0)
          (local.get $13)
         )
         (i32.store offset=232
          (local.get $0)
          (local.get $15)
         )
         (i32.store offset=228
          (local.get $0)
          (local.get $16)
         )
         (i32.store offset=188
          (local.get $0)
          (i32.const 66464)
         )
         (i32.store offset=156
          (local.get $0)
          (i32.const 0)
         )
         (i32.store offset=36
          (local.get $0)
          (local.get $9)
         )
         (i32.store offset=8
          (local.get $0)
          (local.get $8)
         )
         (call $fimport$2
          (local.get $0)
         )
         (br_if $block2
          (local.tee $17
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
        )
        (block $block10
         (block $block9
          (br_if $block9
           (i32.ge_u
            (local.tee $6
             (i32.add
              (local.get $12)
              (i32.const 5)
             )
            )
            (local.get $4)
           )
          )
          (br_if $block9
           (i32.eqz
            (i32.load offset=328
             (local.get $0)
            )
           )
          )
          (br_if $block10
           (i32.eq
            (i32.load offset=398448
             (local.get $5)
            )
            (i32.const 66408)
           )
          )
         )
         (i32.store offset=332
          (local.get $0)
          (local.get $12)
         )
         (i32.store offset=308
          (local.get $0)
          (i32.const 5)
         )
         (i32.store8 offset=296
          (local.get $0)
          (i32.const 1)
         )
         (i32.store offset=292
          (local.get $0)
          (i32.const 2)
         )
         (i32.store offset=256
          (local.get $0)
          (local.get $11)
         )
         (i32.store offset=252
          (local.get $0)
          (local.get $14)
         )
         (i32.store offset=248
          (local.get $0)
          (local.get $14)
         )
         (i32.store offset=240
          (local.get $0)
          (local.get $13)
         )
         (i32.store offset=236
          (local.get $0)
          (local.get $13)
         )
         (i32.store offset=232
          (local.get $0)
          (local.get $15)
         )
         (i32.store offset=228
          (local.get $0)
          (local.get $16)
         )
         (i32.store offset=188
          (local.get $0)
          (i32.const 66408)
         )
         (i32.store offset=156
          (local.get $0)
          (i32.const 0)
         )
         (i32.store offset=36
          (local.get $0)
          (local.get $9)
         )
         (i32.store offset=8
          (local.get $0)
          (local.get $8)
         )
         (i32.store
          (local.get $0)
          (i32.const 0)
         )
         (return)
        )
        (local.set $10
         (i32.load offset=398456
          (local.get $5)
         )
        )
        (i32.store offset=332
         (local.get $0)
         (local.get $6)
        )
        (i32.store offset=308
         (local.get $0)
         (i32.const 4)
        )
        (i32.store8 offset=296
         (local.get $0)
         (i32.const 0)
        )
        (i32.store offset=292
         (local.get $0)
         (i32.const 2)
        )
        (i32.store offset=256
         (local.get $0)
         (local.get $11)
        )
        (i32.store offset=252
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=248
         (local.get $0)
         (local.get $14)
        )
        (i32.store offset=240
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=236
         (local.get $0)
         (local.get $13)
        )
        (i32.store offset=232
         (local.get $0)
         (local.get $15)
        )
        (i32.store offset=228
         (local.get $0)
         (local.get $16)
        )
        (i32.store offset=188
         (local.get $0)
         (i32.const 66408)
        )
        (i32.store offset=156
         (local.get $0)
         (i32.const 0)
        )
        (i32.store offset=36
         (local.get $0)
         (local.get $9)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $8)
        )
        (i32.store
         (local.get $0)
         (i32.const 0)
        )
        (return_call_indirect $timport$0 (type $0)
         (local.get $0)
         (local.get $1)
         (local.get $10)
        )
       )
       (i32.store offset=332
        (local.get $0)
        (local.get $12)
       )
       (local.set $21
        (i32.const 3)
       )
       (i32.store offset=308
        (local.get $0)
        (i32.const 3)
       )
       (local.set $20
        (i32.const 1)
       )
       (i32.store8 offset=296
        (local.get $0)
        (i32.const 1)
       )
       (local.set $19
        (i32.const 2)
       )
       (i32.store offset=292
        (local.get $0)
        (i32.const 2)
       )
       (i32.store offset=256
        (local.get $0)
        (local.get $11)
       )
       (i32.store offset=252
        (local.get $0)
        (local.get $14)
       )
       (i32.store offset=248
        (local.get $0)
        (local.get $14)
       )
       (i32.store offset=240
        (local.get $0)
        (local.get $13)
       )
       (i32.store offset=236
        (local.get $0)
        (local.get $13)
       )
       (i32.store offset=232
        (local.get $0)
        (local.get $15)
       )
       (i32.store offset=228
        (local.get $0)
        (local.get $16)
       )
       (local.set $18
        (i32.const 66458)
       )
       (i32.store offset=188
        (local.get $0)
        (i32.const 66458)
       )
       (i32.store offset=156
        (local.get $0)
        (local.get $10)
       )
       (i32.store offset=36
        (local.get $0)
        (local.get $9)
       )
       (i32.store offset=8
        (local.get $0)
        (local.get $8)
       )
       (call $fimport$2
        (local.get $0)
       )
       (local.set $22
        (local.get $12)
       )
       (local.set $23
        (local.get $14)
       )
       (local.set $24
        (local.get $13)
       )
       (br_if $block7
        (i32.eqz
         (local.tee $17
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
        )
       )
      )
      (local.set $22
       (i32.load offset=332
        (local.get $0)
       )
      )
      (local.set $21
       (i32.load offset=308
        (local.get $0)
       )
      )
      (local.set $19
       (i32.load offset=292
        (local.get $0)
       )
      )
      (local.set $11
       (i32.load offset=256
        (local.get $0)
       )
      )
      (local.set $14
       (i32.load offset=252
        (local.get $0)
       )
      )
      (local.set $23
       (i32.load offset=248
        (local.get $0)
       )
      )
      (local.set $13
       (i32.load offset=240
        (local.get $0)
       )
      )
      (local.set $24
       (i32.load offset=236
        (local.get $0)
       )
      )
      (local.set $15
       (i32.load offset=232
        (local.get $0)
       )
      )
      (local.set $16
       (i32.load offset=228
        (local.get $0)
       )
      )
      (local.set $18
       (i32.load offset=188
        (local.get $0)
       )
      )
      (local.set $10
       (i32.load offset=156
        (local.get $0)
       )
      )
      (local.set $9
       (i32.load offset=36
        (local.get $0)
       )
      )
      (local.set $8
       (i32.load offset=8
        (local.get $0)
       )
      )
      (local.set $7
       (i32.load offset=4
        (local.get $0)
       )
      )
      (local.set $6
       (i32.load
        (local.get $0)
       )
      )
      (local.set $20
       (local.get $17)
      )
     )
     (br_if $block11
      (i32.ge_u
       (local.tee $12
        (i32.add
         (local.get $21)
         (local.get $22)
        )
       )
       (local.get $4)
      )
     )
     (br_if $block11
      (i32.eqz
       (i32.load offset=328
        (local.get $0)
       )
      )
     )
     (br_if $label
      (i32.eq
       (local.get $18)
       (i32.const 66458)
      )
     )
    )
    (br_if $block11
     (i32.ne
      (i32.load
       (local.tee $6
        (i32.add
         (local.get $5)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $18)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $18)
     )
    )
    (local.set $6
     (i32.load offset=8
      (local.get $6)
     )
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $12)
    )
    (i32.store offset=308
     (local.get $0)
     (local.get $21)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=292
     (local.get $0)
     (local.get $19)
    )
    (i32.store offset=256
     (local.get $0)
     (local.get $11)
    )
    (i32.store offset=252
     (local.get $0)
     (local.get $14)
    )
    (i32.store offset=248
     (local.get $0)
     (local.get $23)
    )
    (i32.store offset=240
     (local.get $0)
     (local.get $13)
    )
    (i32.store offset=236
     (local.get $0)
     (local.get $24)
    )
    (i32.store offset=232
     (local.get $0)
     (local.get $15)
    )
    (i32.store offset=228
     (local.get $0)
     (local.get $16)
    )
    (i32.store offset=188
     (local.get $0)
     (local.get $18)
    )
    (i32.store offset=156
     (local.get $0)
     (local.get $10)
    )
    (i32.store offset=36
     (local.get $0)
     (local.get $9)
    )
    (i32.store offset=8
     (local.get $0)
     (local.get $8)
    )
    (return_call_indirect $timport$0 (type $0)
     (local.get $0)
     (local.get $1)
     (local.get $6)
    )
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $22)
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $21)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $20)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $19)
   )
   (i32.store offset=256
    (local.get $0)
    (local.get $11)
   )
   (i32.store offset=252
    (local.get $0)
    (local.get $14)
   )
   (i32.store offset=248
    (local.get $0)
    (local.get $23)
   )
   (i32.store offset=240
    (local.get $0)
    (local.get $13)
   )
   (i32.store offset=236
    (local.get $0)
    (local.get $24)
   )
   (i32.store offset=232
    (local.get $0)
    (local.get $15)
   )
   (i32.store offset=228
    (local.get $0)
    (local.get $16)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $18)
   )
   (i32.store offset=156
    (local.get $0)
    (local.get $10)
   )
   (i32.store offset=36
    (local.get $0)
    (local.get $9)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $8)
   )
   (return)
  )
  (i32.store8 offset=341
   (local.get $0)
   (i32.const 1)
  )
 )
 ;; custom section "linking", size 37
 ;; custom section "reloc.CODE", size 34
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

