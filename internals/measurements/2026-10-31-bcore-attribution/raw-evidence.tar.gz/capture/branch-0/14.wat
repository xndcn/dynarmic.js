(module
 (type $0 (func (param i32 i32 i32)))
 (type $1 (func (param i32) (result i32)))
 (type $2 (func (param i32)))
 (type $3 (func (param i32 i32) (result i32)))
 (type $4 (func (param i32 i32)))
 (type $5 (func (param i32 i32 i32) (result i32)))
 (type $6 (func (param i32 i32 i32 i32 i32)))
 (type $7 (func (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_read8" (func $fimport$0 (param i32 i32) (result i32)))
 (import "env" "mem_read16" (func $fimport$1 (param i32 i32) (result i32)))
 (import "env" "mem_read32" (func $fimport$2 (param i32 i32) (result i32)))
 (import "env" "mem_write8" (func $fimport$3 (param i32 i32 i32)))
 (import "env" "mem_write16" (func $fimport$4 (param i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$5 (param i32 i32 i32)))
 (import "env" "cec_data_alignment" (func $fimport$6 (param i32 i32 i32 i32 i32)))
 (import "env" "cec_exception" (func $fimport$7 (param i32 i32 i32)))
 (import "env" "cec_raise" (func $fimport$8 (param i32 i32)))
 (import "env" "cec_return_rti" (func $fimport$9 (param i32) (result i32)))
 (import "env" "cec_return_rtx" (func $fimport$10 (param i32) (result i32)))
 (import "env" "cec_return_rtn" (func $fimport$11 (param i32) (result i32)))
 (import "env" "cec_return_rte" (func $fimport$12 (param i32) (result i32)))
 (import "env" "cec_cli" (func $fimport$13 (param i32) (result i32)))
 (import "env" "cec_sti" (func $fimport$14 (param i32 i32)))
 (import "env" "cec_push_reti" (func $fimport$15 (param i32)))
 (import "env" "cec_pop_reti" (func $fimport$16 (param i32)))
 (import "env" "cec_check_sup" (func $fimport$17 (param i32)))
 (import "env" "cec_is_user_mode" (func $fimport$18 (result i32)))
 (import "env" "cec_check_pending" (func $fimport$19 (param i32)))
 (import "env" "bfin_hwloop_step" (func $fimport$20 (param i32 i32 i32)))
 (import "env" "bfin_putchar" (func $fimport$21 (param i32)))
 (import "env" "bfin_syscall" (func $fimport$22 (param i32 i32)))
 (import "env" "memset" (func $fimport$23 (param i32 i32 i32) (result i32)))
 (import "env" "memcpy" (func $fimport$24 (param i32 i32 i32) (result i32)))
 (import "env" "memmove" (func $fimport$25 (param i32 i32 i32) (result i32)))
 (export "0" (func $0))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block20
   (block $block19
    (block $block18
     (block $block15
      (block $block12
       (block $block9
        (block $block6
         (block $block3
          (block $block
           (br_if $block
            (i32.and
             (local.tee $2
              (i32.load offset=56
               (local.get $0)
              )
             )
             (i32.const 3)
            )
           )
           (block $block2
            (block $block1
             (br_if $block1
              (i32.eqz
               (local.tee $4
                (i32.load
                 (i32.add
                  (local.tee $3
                   (i32.load offset=312
                    (local.get $0)
                   )
                  )
                  (i32.and
                   (i32.shr_u
                    (local.get $2)
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (local.set $4
              (i32.load
               (i32.add
                (local.get $4)
                (i32.and
                 (local.get $2)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block2)
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $6
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=4
              (local.get $28)
             )
            )
            (local.set $4
             (call $fimport$2
              (local.get $1)
              (local.get $2)
             )
            )
            (br_if $block3
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=52
            (local.get $0)
            (local.get $4)
           )
           (block $block5
            (block $block4
             (br_if $block4
              (i32.eqz
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $3)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $2)
                      (i32.const 4)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (local.set $4
              (i32.load
               (i32.add
                (local.get $5)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block5)
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load offset=8
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $6
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=12
              (local.get $28)
             )
            )
            (local.set $4
             (call $fimport$2
              (local.get $1)
              (local.get $4)
             )
            )
            (br_if $block6
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=28
            (local.get $0)
            (local.get $4)
           )
           (block $block8
            (block $block7
             (br_if $block7
              (i32.eqz
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $3)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $2)
                      (i32.const 8)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (local.set $4
              (i32.load
               (i32.add
                (local.get $5)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block8)
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load offset=16
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $6
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=20
              (local.get $28)
             )
            )
            (local.set $4
             (call $fimport$2
              (local.get $1)
              (local.get $4)
             )
            )
            (br_if $block9
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=24
            (local.get $0)
            (local.get $4)
           )
           (block $block11
            (block $block10
             (br_if $block10
              (i32.eqz
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $3)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $2)
                      (i32.const 12)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (local.set $4
              (i32.load
               (i32.add
                (local.get $5)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block11)
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load offset=24
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $6
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=28
              (local.get $28)
             )
            )
            (local.set $4
             (call $fimport$2
              (local.get $1)
              (local.get $4)
             )
            )
            (br_if $block12
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=20
            (local.get $0)
            (local.get $4)
           )
           (block $block14
            (block $block13
             (br_if $block13
              (i32.eqz
               (local.tee $3
                (i32.load
                 (i32.add
                  (local.get $3)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $2)
                      (i32.const 16)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (local.set $3
              (i32.load
               (i32.add
                (local.get $3)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block14)
            )
            (i32.store
             (local.tee $5
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load offset=32
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $6
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=36
              (local.get $28)
             )
            )
            (local.set $3
             (call $fimport$2
              (local.get $1)
              (local.get $4)
             )
            )
            (br_if $block15
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=16
            (local.get $0)
            (local.get $3)
           )
           (i32.store offset=56
            (local.get $0)
            (i32.add
             (local.get $2)
             (i32.const 20)
            )
           )
           (block $block17
            (block $block16
             (br_if $block16
              (i32.eq
               (i32.load offset=160
                (local.get $0)
               )
               (i32.load offset=40
                (local.get $28)
               )
              )
             )
             (br_if $block17
              (i32.ne
               (i32.load offset=164
                (local.get $0)
               )
               (i32.load offset=44
                (local.get $28)
               )
              )
             )
            )
            (i32.store
             (local.tee $2
              (i32.add
               (local.get $0)
               (i32.const 308)
              )
             )
             (i32.load offset=48
              (local.get $28)
             )
            )
            (i32.store
             (local.tee $3
              (i32.add
               (local.get $0)
               (i32.const 292)
              )
             )
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.load offset=52
              (local.get $28)
             )
            )
            (call $fimport$20
             (local.get $0)
             (i32.load offset=56
              (local.get $28)
             )
             (i32.load offset=60
              (local.get $28)
             )
            )
            (br_if $block18
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (br $block19)
          )
          (i32.store
           (local.tee $3
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.load offset=64
            (local.get $28)
           )
          )
          (i32.store
           (local.tee $4
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.load offset=68
            (local.get $28)
           )
          )
          (call $fimport$6
           (local.get $0)
           (local.get $1)
           (i32.load offset=72
            (local.get $28)
           )
           (local.get $2)
           (i32.const 0)
          )
          (i32.store
           (local.get $3)
           (i32.load offset=76
            (local.get $28)
           )
          )
          (i32.store
           (local.get $4)
           (i32.const 2)
          )
          (br $block20)
         )
         (i32.store
          (local.get $5)
          (i32.load offset=80
           (local.get $28)
          )
         )
         (i32.store
          (local.get $6)
          (i32.const 2)
         )
         (br $block20)
        )
        (i32.store
         (local.get $5)
         (i32.load offset=84
          (local.get $28)
         )
        )
        (i32.store
         (local.get $6)
         (i32.const 2)
        )
        (br $block20)
       )
       (i32.store
        (local.get $5)
        (i32.load offset=88
         (local.get $28)
        )
       )
       (i32.store
        (local.get $6)
        (i32.const 2)
       )
       (br $block20)
      )
      (i32.store
       (local.get $5)
       (i32.load offset=92
        (local.get $28)
       )
      )
      (i32.store
       (local.get $6)
       (i32.const 2)
      )
      (br $block20)
     )
     (i32.store
      (local.get $5)
      (i32.load offset=96
       (local.get $28)
      )
     )
     (i32.store
      (local.get $6)
      (i32.const 2)
     )
     (br $block20)
    )
    (i32.store
     (local.get $2)
     (i32.load offset=100
      (local.get $28)
     )
    )
    (i32.store
     (local.get $3)
     (i32.const 2)
    )
    (br $block20)
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
)

