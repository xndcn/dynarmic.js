(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32) (result i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32) (result i32)))
 (type $5 (func (param i32 i32 i32) (result i32)))
 (type $6 (func (param i32 i32 i32 i32 i32)))
 (type $7 (func (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_read8" (func $fimport$0 (param i32 i32) (result i32)))
 (import "env" "mem_read16" (func $fimport$1 (param i32 i32) (result i32)))
 (import "env" "mem_read32" (func $fimport$2 (param i32 i32) (result i32)))
 (import "env" "mem_write8" (func $fimport$3 (param i32 i32 i32)))
 (import "env" "mem_write16" (func $fimport$4 (param i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$5 (param i32 i32 i32)))
 (import "env" "cec_data_alignment" (func $fimport$6 (param i32 i32 i32 i32 i32)))
 (import "env" "cec_exception" (func $fimport$7 (param i32 i32 i32)))
 (import "env" "cec_raise" (func $fimport$8 (param i32 i32)))
 (import "env" "cec_return_rti" (func $fimport$9 (param i32) (result i32)))
 (import "env" "cec_return_rtx" (func $fimport$10 (param i32) (result i32)))
 (import "env" "cec_return_rtn" (func $fimport$11 (param i32) (result i32)))
 (import "env" "cec_return_rte" (func $fimport$12 (param i32) (result i32)))
 (import "env" "cec_cli" (func $fimport$13 (param i32) (result i32)))
 (import "env" "cec_sti" (func $fimport$14 (param i32 i32)))
 (import "env" "cec_push_reti" (func $fimport$15 (param i32)))
 (import "env" "cec_pop_reti" (func $fimport$16 (param i32)))
 (import "env" "cec_check_sup" (func $fimport$17 (param i32)))
 (import "env" "cec_is_user_mode" (func $fimport$18 (result i32)))
 (import "env" "cec_check_pending" (func $fimport$19 (param i32)))
 (import "env" "bfin_hwloop_step" (func $fimport$20 (param i32 i32 i32)))
 (import "env" "bfin_putchar" (func $fimport$21 (param i32)))
 (import "env" "bfin_syscall" (func $fimport$22 (param i32 i32)))
 (import "env" "memset" (func $fimport$23 (param i32 i32 i32) (result i32)))
 (import "env" "memcpy" (func $fimport$24 (param i32 i32 i32) (result i32)))
 (import "env" "memmove" (func $fimport$25 (param i32 i32 i32) (result i32)))
 (export "0" (func $0))
 (export "1" (func $1))
 (export "2" (func $2))
 (export "3" (func $3))
 (export "4" (func $4))
 (export "5" (func $5))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786468)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 9)
      )
     )
    )
    (block
     (i32.store offset=28
      (local.get $0)
      (i32.mul
       (i32.load offset=16
        (local.get $0)
       )
       (i32.load offset=28
        (local.get $0)
       )
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65916)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65916)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65916)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65916)
       (i32.const 65918)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 1)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=4
      (local.get $0)
      (i32.load offset=52
       (local.get $0)
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65918)
        )
       )
       (br_if $block5
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65918)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65918)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65918)
       (i32.const 65920)
      )
      (br_if $block5
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=28
      (local.get $0)
      (local.tee $4
       (i32.add
        (local.tee $2
         (i32.load offset=4
          (local.get $0)
         )
        )
        (local.tee $3
         (i32.load offset=28
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $4)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $4)
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $5
       (i32.gt_u
        (local.get $2)
        (i32.xor
         (local.get $3)
         (i32.const -1)
        )
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $5)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $4
       (i32.shr_u
        (i32.and
         (i32.xor
          (local.get $4)
          (local.get $3)
         )
         (i32.xor
          (local.get $4)
          (local.get $2)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (block $block7
      (block $block6
       (br_if $block6
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65920)
        )
       )
       (br_if $block7
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65920)
        )
       )
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 3)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65920)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65920)
       (i32.const 65922)
      )
      (br_if $block7
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $4)
       (i32.const 3)
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 4294967297)
     )
     (i32.store offset=276
      (local.get $0)
      (local.tee $3
       (i32.shr_u
        (local.tee $2
         (i32.load offset=28
          (local.get $0)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (local.get $3)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block9
      (block $block8
       (br_if $block8
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65922)
        )
       )
       (br_if $block9
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65922)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65922)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65922)
       (i32.const 65924)
      )
      (br_if $block9
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 4)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (block $block10
      (br_if $block10
       (i32.load offset=276
        (local.get $0)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (block $block12
       (block $block11
        (br_if $block11
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65924)
         )
        )
        (br_if $block12
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65924)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 5)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65904)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65924)
        (i32.const 65924)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 5)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65904)
      )
      (br $block3)
     )
     (block $block14
      (block $block13
       (br_if $block13
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65924)
        )
       )
       (br_if $block14
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65924)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 5)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65924)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65924)
       (i32.const 65926)
      )
      (br_if $block14
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 5)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.tee $2
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=28
         (local.get $0)
        )
       )
      )
     )
     (i32.store
      (local.get $0)
      (local.tee $2
       (i32.xor
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (block $block16
      (block $block15
       (br_if $block15
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65926)
        )
       )
       (br_if $block16
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65926)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 6)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65926)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65926)
       (i32.const 65928)
      )
      (br_if $block16
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 6)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store offset=168
      (local.get $0)
      (select
       (select
        (i32.load offset=148
         (local.get $0)
        )
        (local.tee $3
         (select
          (select
           (i32.load offset=144
            (local.get $0)
           )
           (i32.const 65932)
           (local.tee $2
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65928)
            )
           )
          )
          (i32.const 65932)
          (i32.gt_u
           (i32.load offset=152
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (i32.eq
         (local.tee $4
          (i32.load offset=164
           (local.get $0)
          )
         )
         (i32.const 65928)
        )
       )
       (local.get $3)
       (i32.gt_u
        (i32.load offset=156
         (local.get $0)
        )
        (i32.const 1)
       )
      )
     )
     (block $block18
      (block $block17
       (br_if $block17
        (local.get $2)
       )
       (br_if $block18
        (i32.ne
         (local.get $4)
         (i32.const 65928)
        )
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65808)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65928)
       (i32.const 65928)
      )
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 308)
      )
      (i32.const 7)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 292)
      )
      (i32.const 4)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65808)
     )
     (br $block3)
    )
   )
   (block
    (block $block21
     (block $block20
      (block $block19
       (br_if $block19
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block20
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65916)
        )
       )
       (br_if $block21
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
 (func $1 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786472)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 10)
      )
     )
    )
    (block
     (i32.store
      (local.get $0)
      (local.tee $4
       (i32.add
        (local.tee $2
         (i32.load
          (local.get $0)
         )
        )
        (local.tee $3
         (i32.load offset=28
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $4)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $4)
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $5
       (i32.gt_u
        (local.get $2)
        (i32.xor
         (local.get $3)
         (i32.const -1)
        )
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $5)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $4
       (i32.shr_u
        (i32.and
         (i32.xor
          (local.get $4)
          (local.get $3)
         )
         (i32.xor
          (local.get $4)
          (local.get $2)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65904)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65904)
        )
       )
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65904)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65904)
       (i32.const 65906)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $4)
       (i32.const 1)
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store offset=168
      (local.get $0)
      (select
       (select
        (i32.load offset=148
         (local.get $0)
        )
        (local.tee $3
         (select
          (select
           (i32.load offset=144
            (local.get $0)
           )
           (i32.const 65910)
           (local.tee $2
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65906)
            )
           )
          )
          (i32.const 65910)
          (i32.gt_u
           (i32.load offset=152
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (i32.eq
         (local.tee $4
          (i32.load offset=164
           (local.get $0)
          )
         )
         (i32.const 65906)
        )
       )
       (local.get $3)
       (i32.gt_u
        (i32.load offset=156
         (local.get $0)
        )
        (i32.const 1)
       )
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (local.get $2)
       )
       (br_if $block5
        (i32.ne
         (local.get $4)
         (i32.const 65906)
        )
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65840)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65906)
       (i32.const 65906)
      )
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 308)
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 292)
      )
      (i32.const 4)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65840)
     )
     (br $block3)
    )
   )
   (block
    (block $block8
     (block $block7
      (block $block6
       (br_if $block6
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block7
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65904)
        )
       )
       (br_if $block8
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
 (func $2 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786476)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 11)
      )
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=4
      (local.get $0)
      (local.tee $2
       (i32.shl
        (i32.load
         (local.get $0)
        )
        (i32.const 5)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65840)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65840)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65840)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65840)
       (i32.const 65844)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 1)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=232
      (local.get $0)
      (i32.const 0)
     )
     (i32.store
      (local.get $0)
      (local.tee $2
       (i32.shr_u
        (i32.load
         (local.get $0)
        )
        (i32.const 27)
       )
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65844)
        )
       )
       (br_if $block5
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65844)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65844)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65844)
       (i32.const 65846)
      )
      (br_if $block5
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store
      (local.get $0)
      (local.tee $2
       (i32.or
        (i32.load
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block7
      (block $block6
       (br_if $block6
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65846)
        )
       )
       (br_if $block7
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65846)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 3)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65846)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65846)
       (i32.const 65848)
      )
      (br_if $block7
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 3)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=4
      (local.get $0)
      (i32.or
       (i32.load16_u offset=4
        (local.get $0)
       )
       (i32.const 2135556096)
      )
     )
     (block $block9
      (block $block8
       (br_if $block8
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65848)
        )
       )
       (br_if $block9
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65848)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65848)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65848)
       (i32.const 65852)
      )
      (br_if $block9
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 4)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (local.set $3
      (i32.add
       (local.tee $2
        (i32.load offset=56
         (local.get $0)
        )
       )
       (i32.const -4)
      )
     )
     (block $block20
      (block $block21
       (block $block16
        (block $block13
         (block $block10
          (br_if $block10
           (i32.and
            (local.get $2)
            (i32.const 3)
           )
          )
          (local.set $4
           (i32.load offset=60
            (local.get $0)
           )
          )
          (local.set $5
           (i32.load offset=168
            (local.get $0)
           )
          )
          (local.set $6
           (i32.load offset=316
            (local.get $0)
           )
          )
          (block $block12
           (block $block11
            (br_if $block11
             (i32.eqz
              (local.tee $8
               (i32.load
                (i32.add
                 (local.tee $7
                  (i32.load offset=312
                   (local.get $0)
                  )
                 )
                 (i32.and
                  (i32.shr_u
                   (local.get $3)
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (i32.add
              (local.get $8)
              (i32.and
               (local.get $3)
               (i32.const 4092)
              )
             )
             (local.get $5)
            )
            (br $block12)
           )
           (i32.store
            (local.tee $8
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 5)
           )
           (i32.store
            (local.tee $9
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65852)
           )
           (call $fimport$5
            (local.get $1)
            (local.get $3)
            (local.get $5)
           )
           (br_if $block13
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
          (block $block15
           (block $block14
            (br_if $block14
             (i32.eqz
              (local.tee $3
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $2
                    (i32.add
                     (local.get $2)
                     (i32.const -8)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (i32.add
              (local.get $3)
              (i32.and
               (local.get $2)
               (i32.const 4092)
              )
             )
             (local.get $4)
            )
            (br $block15)
           )
           (i32.store
            (local.tee $3
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 5)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65852)
           )
           (call $fimport$5
            (local.get $1)
            (local.get $2)
            (local.get $4)
           )
           (br_if $block16
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
          (i32.store offset=60
           (local.get $0)
           (local.get $2)
          )
          (i32.store offset=56
           (local.get $0)
           (i32.sub
            (local.get $2)
            (i32.const 0)
           )
          )
          (block $block18
           (block $block17
            (br_if $block17
             (i32.eq
              (i32.load offset=160
               (local.get $0)
              )
              (i32.const 65852)
             )
            )
            (br_if $block18
             (i32.ne
              (i32.load offset=164
               (local.get $0)
              )
              (i32.const 65852)
             )
            )
           )
           (i32.store
            (local.tee $2
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 5)
           )
           (i32.store
            (local.tee $3
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65852)
           )
           (call $fimport$20
            (local.get $0)
            (i32.const 65852)
            (i32.const 65856)
           )
           (block $block19
            (br_if $block19
             (i32.eqz
              (i32.load8_u
               (local.get $6)
              )
             )
            )
            (i32.store
             (local.get $2)
             (i32.const 5)
            )
            (i32.store
             (local.get $3)
             (i32.const 4)
            )
            (call $fimport$19
             (local.get $0)
            )
           )
           (br_if $block20
            (i32.eqz
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 5)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 4)
           )
           (br $block3)
          )
          (br_if $block21
           (i32.load8_u
            (local.get $6)
           )
          )
          (br $block20)
         )
         (i32.store
          (local.tee $2
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
          )
          (i32.const 5)
         )
         (i32.store
          (local.tee $4
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
          )
          (i32.const 4)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
          (i32.const 65852)
         )
         (call $fimport$6
          (local.get $0)
          (local.get $1)
          (i32.const 65852)
          (local.get $3)
          (i32.const 65536)
         )
         (i32.store
          (local.get $2)
          (i32.const 5)
         )
         (i32.store
          (local.get $4)
          (i32.const 4)
         )
         (br $block3)
        )
        (i32.store
         (local.get $8)
         (i32.const 5)
        )
        (i32.store
         (local.get $9)
         (i32.const 4)
        )
        (br $block3)
       )
       (i32.store
        (local.get $3)
        (i32.const 5)
       )
       (i32.store
        (local.get $5)
        (i32.const 4)
       )
       (br $block3)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 5)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65856)
      )
      (call $fimport$19
       (local.get $0)
      )
      (br_if $block20
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 5)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=4
      (local.get $0)
      (i32.or
       (i32.shl
        (i32.load16_u offset=6
         (local.get $0)
        )
        (i32.const 16)
       )
       (i32.const 31765)
      )
     )
     (block $block23
      (block $block22
       (br_if $block22
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65856)
        )
       )
       (br_if $block23
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65856)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 6)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65856)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65856)
       (i32.const 65860)
      )
      (br_if $block23
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 6)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (i32.store
      (local.get $0)
      (local.tee $4
       (i32.add
        (local.tee $2
         (i32.load offset=4
          (local.get $0)
         )
        )
        (local.tee $3
         (i32.load
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $4)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $4)
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $5
       (i32.gt_u
        (local.get $2)
        (i32.xor
         (local.get $3)
         (i32.const -1)
        )
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $5)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $4
       (i32.shr_u
        (i32.and
         (i32.xor
          (local.get $4)
          (local.get $3)
         )
         (i32.xor
          (local.get $4)
          (local.get $2)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (block $block25
      (block $block24
       (br_if $block24
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65860)
        )
       )
       (br_if $block25
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65860)
        )
       )
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 7)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65860)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65860)
       (i32.const 65862)
      )
      (br_if $block25
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $4)
       (i32.const 7)
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block $block36
     (block $block35
      (block $block32
       (block $block29
        (block $block26
         (br_if $block26
          (i32.and
           (local.tee $2
            (i32.load offset=60
             (local.get $0)
            )
           )
           (i32.const 3)
          )
         )
         (block $block28
          (block $block27
           (br_if $block27
            (i32.eqz
             (local.tee $4
              (i32.load
               (i32.add
                (local.tee $3
                 (i32.load offset=312
                  (local.get $0)
                 )
                )
                (i32.and
                 (i32.shr_u
                  (local.get $2)
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $4
            (i32.load
             (i32.add
              (local.get $4)
              (i32.and
               (local.get $2)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block28)
          )
          (i32.store
           (local.tee $5
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 8)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65862)
          )
          (local.set $4
           (call $fimport$2
            (local.get $1)
            (local.get $2)
           )
          )
          (br_if $block29
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (block $block31
          (block $block30
           (br_if $block30
            (i32.eqz
             (local.tee $3
              (i32.load
               (i32.add
                (local.get $3)
                (i32.and
                 (i32.shr_u
                  (local.tee $5
                   (i32.add
                    (local.get $2)
                    (i32.const 4)
                   )
                  )
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $3
            (i32.load
             (i32.add
              (local.get $3)
              (i32.and
               (local.get $5)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block31)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 8)
          )
          (i32.store
           (local.tee $7
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65862)
          )
          (local.set $3
           (call $fimport$2
            (local.get $1)
            (local.get $5)
           )
          )
          (br_if $block32
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (i32.store offset=168
          (local.get $0)
          (local.get $3)
         )
         (i32.store offset=60
          (local.get $0)
          (local.get $4)
         )
         (i32.store offset=56
          (local.get $0)
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
         )
         (block $block34
          (block $block33
           (br_if $block33
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65862)
            )
           )
           (br_if $block34
            (i32.ne
             (i32.load offset=164
              (local.get $0)
             )
             (i32.const 65862)
            )
           )
          )
          (i32.store
           (local.tee $2
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 8)
          )
          (i32.store
           (local.tee $3
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65862)
          )
          (call $fimport$20
           (local.get $0)
           (i32.const 65862)
           (i32.const 65866)
          )
          (br_if $block35
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (br $block36)
        )
        (i32.store
         (local.tee $3
          (i32.add
           (local.get $0)
           (i32.const 308)
          )
         )
         (i32.const 8)
        )
        (i32.store
         (local.tee $4
          (i32.add
           (local.get $0)
           (i32.const 292)
          )
         )
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
         (i32.const 65862)
        )
        (call $fimport$6
         (local.get $0)
         (local.get $1)
         (i32.const 65862)
         (local.get $2)
         (i32.const 0)
        )
        (i32.store
         (local.get $3)
         (i32.const 8)
        )
        (i32.store
         (local.get $4)
         (i32.const 4)
        )
        (br $block3)
       )
       (i32.store
        (local.get $5)
        (i32.const 8)
       )
       (i32.store
        (local.get $6)
        (i32.const 4)
       )
       (br $block3)
      )
      (i32.store
       (local.get $6)
       (i32.const 8)
      )
      (i32.store
       (local.get $7)
       (i32.const 4)
      )
      (br $block3)
     )
     (i32.store
      (local.get $2)
      (i32.const 8)
     )
     (i32.store
      (local.get $3)
      (i32.const 4)
     )
     (br $block3)
    )
    (block
     (block $block37
      (br_if $block37
       (i32.and
        (local.tee $2
         (i32.load offset=168
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (local.get $2)
      )
      (block $block39
       (block $block38
        (br_if $block38
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65866)
         )
        )
        (br_if $block39
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65866)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 9)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65866)
        (i32.const 65866)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 9)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (br $block3)
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.const 9)
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65866)
     )
     (call $fimport$7
      (local.get $0)
      (i32.const 42)
      (local.get $1)
     )
     (i32.store
      (local.get $2)
      (i32.const 9)
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block3)
    )
   )
   (block
    (block $block42
     (block $block41
      (block $block40
       (br_if $block40
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block41
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65840)
        )
       )
       (br_if $block42
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
 (func $3 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786480)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 12)
      )
     )
    )
    (block
     (i32.store offset=24
      (local.get $0)
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=24
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $3)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (local.tee $4
       (i32.eqz
        (local.get $3)
       )
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $3
       (i32.shr_u
        (i32.and
         (local.get $3)
         (i32.xor
          (local.get $2)
          (i32.const -1)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $3)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $3)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65910)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65910)
        )
       )
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65910)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65910)
       (i32.const 65912)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $3)
       (i32.const 1)
      )
      (i32.store
       (local.get $4)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=276
      (local.get $0)
      (i32.le_u
       (local.tee $2
        (i32.load offset=20
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=24
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $4
       (i32.le_u
        (local.get $3)
        (local.get $2)
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=232
      (local.get $0)
      (i32.gt_u
       (local.get $3)
       (local.get $2)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.get $2)
       (local.get $3)
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65912)
        )
       )
       (br_if $block5
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65912)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65912)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65912)
       (i32.const 65914)
      )
      (br_if $block5
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (block $block6
      (br_if $block6
       (i32.eqz
        (i32.load offset=276
         (local.get $0)
        )
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (block $block8
       (block $block7
        (br_if $block7
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65914)
         )
        )
        (br_if $block8
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65914)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 3)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65938)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65914)
        (i32.const 65914)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65938)
      )
      (br $block3)
     )
     (block $block10
      (block $block9
       (br_if $block9
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65914)
        )
       )
       (br_if $block10
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65914)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 3)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65914)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65914)
       (i32.const 65916)
      )
      (br_if $block10
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 3)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=28
      (local.get $0)
      (i32.mul
       (i32.load offset=16
        (local.get $0)
       )
       (i32.load offset=28
        (local.get $0)
       )
      )
     )
     (block $block12
      (block $block11
       (br_if $block11
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65916)
        )
       )
       (br_if $block12
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65916)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65916)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65916)
       (i32.const 65918)
      )
      (br_if $block12
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 4)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=4
      (local.get $0)
      (i32.load offset=52
       (local.get $0)
      )
     )
     (block $block14
      (block $block13
       (br_if $block13
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65918)
        )
       )
       (br_if $block14
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65918)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 5)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65918)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65918)
       (i32.const 65920)
      )
      (br_if $block14
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 5)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=28
      (local.get $0)
      (local.tee $4
       (i32.add
        (local.tee $2
         (i32.load offset=4
          (local.get $0)
         )
        )
        (local.tee $3
         (i32.load offset=28
          (local.get $0)
         )
        )
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $4)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $4)
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $5
       (i32.gt_u
        (local.get $2)
        (i32.xor
         (local.get $3)
         (i32.const -1)
        )
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $5)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $4
       (i32.shr_u
        (i32.and
         (i32.xor
          (local.get $4)
          (local.get $3)
         )
         (i32.xor
          (local.get $4)
          (local.get $2)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $4)
      )
     )
     (block $block16
      (block $block15
       (br_if $block15
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65920)
        )
       )
       (br_if $block16
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65920)
        )
       )
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 6)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65920)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65920)
       (i32.const 65922)
      )
      (br_if $block16
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $4)
       (i32.const 6)
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 4294967297)
     )
     (i32.store offset=276
      (local.get $0)
      (local.tee $3
       (i32.shr_u
        (local.tee $2
         (i32.load offset=28
          (local.get $0)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (local.get $3)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block18
      (block $block17
       (br_if $block17
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65922)
        )
       )
       (br_if $block18
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65922)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 7)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65922)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65922)
       (i32.const 65924)
      )
      (br_if $block18
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 7)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (block $block19
      (br_if $block19
       (i32.load offset=276
        (local.get $0)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (block $block21
       (block $block20
        (br_if $block20
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65924)
         )
        )
        (br_if $block21
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65924)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 8)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65904)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65924)
        (i32.const 65924)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 8)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65904)
      )
      (br $block3)
     )
     (block $block23
      (block $block22
       (br_if $block22
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65924)
        )
       )
       (br_if $block23
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65924)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 8)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65924)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65924)
       (i32.const 65926)
      )
      (br_if $block23
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 8)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.tee $2
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=28
         (local.get $0)
        )
       )
      )
     )
     (i32.store
      (local.get $0)
      (local.tee $2
       (i32.xor
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (block $block25
      (block $block24
       (br_if $block24
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65926)
        )
       )
       (br_if $block25
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65926)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 9)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65926)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65926)
       (i32.const 65928)
      )
      (br_if $block25
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 9)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store offset=168
      (local.get $0)
      (select
       (select
        (i32.load offset=148
         (local.get $0)
        )
        (local.tee $3
         (select
          (select
           (i32.load offset=144
            (local.get $0)
           )
           (i32.const 65932)
           (local.tee $2
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65928)
            )
           )
          )
          (i32.const 65932)
          (i32.gt_u
           (i32.load offset=152
            (local.get $0)
           )
           (i32.const 1)
          )
         )
        )
        (i32.eq
         (local.tee $4
          (i32.load offset=164
           (local.get $0)
          )
         )
         (i32.const 65928)
        )
       )
       (local.get $3)
       (i32.gt_u
        (i32.load offset=156
         (local.get $0)
        )
        (i32.const 1)
       )
      )
     )
     (block $block27
      (block $block26
       (br_if $block26
        (local.get $2)
       )
       (br_if $block27
        (i32.ne
         (local.get $4)
         (i32.const 65928)
        )
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 10)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65808)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65928)
       (i32.const 65928)
      )
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 308)
      )
      (i32.const 10)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 292)
      )
      (i32.const 4)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65808)
     )
     (br $block3)
    )
   )
   (block
    (block $block30
     (block $block29
      (block $block28
       (br_if $block28
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block29
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65910)
        )
       )
       (br_if $block30
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
 (func $4 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786484)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 13)
      )
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=232
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=4
      (local.get $0)
      (local.tee $2
       (i32.shr_u
        (i32.load
         (local.get $0)
        )
        (i32.const 7)
       )
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eqz
       (local.get $2)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65808)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65808)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65808)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65808)
       (i32.const 65812)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 1)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.tee $2
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=4
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (local.tee $2
       (i32.xor
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65812)
        )
       )
       (br_if $block5
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65812)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65812)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65812)
       (i32.const 65814)
      )
      (br_if $block5
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=40
      (local.get $0)
      (i32.load offset=4
       (local.get $0)
      )
     )
     (block $block7
      (block $block6
       (br_if $block6
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65814)
        )
       )
       (br_if $block7
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65814)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 3)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65814)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65814)
       (i32.const 65816)
      )
      (br_if $block7
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 3)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=36
      (local.get $0)
      (i32.or
       (i32.load16_u offset=36
        (local.get $0)
       )
       (i32.const -1640562688)
      )
     )
     (block $block9
      (block $block8
       (br_if $block8
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65816)
        )
       )
       (br_if $block9
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65816)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65816)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65816)
       (i32.const 65820)
      )
      (br_if $block9
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 4)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=36
      (local.get $0)
      (i32.or
       (i32.shl
        (i32.load16_u offset=38
         (local.get $0)
        )
        (i32.const 16)
       )
       (i32.const 31161)
      )
     )
     (block $block11
      (block $block10
       (br_if $block10
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65820)
        )
       )
       (br_if $block11
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65820)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 5)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65820)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65820)
       (i32.const 65824)
      )
      (br_if $block11
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 5)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block
     (local.set $3
      (i32.add
       (local.tee $2
        (i32.load offset=56
         (local.get $0)
        )
       )
       (i32.const -4)
      )
     )
     (block $block22
      (block $block23
       (block $block18
        (block $block15
         (block $block12
          (br_if $block12
           (i32.and
            (local.get $2)
            (i32.const 3)
           )
          )
          (local.set $4
           (i32.load offset=60
            (local.get $0)
           )
          )
          (local.set $5
           (i32.load offset=168
            (local.get $0)
           )
          )
          (local.set $6
           (i32.load offset=316
            (local.get $0)
           )
          )
          (block $block14
           (block $block13
            (br_if $block13
             (i32.eqz
              (local.tee $8
               (i32.load
                (i32.add
                 (local.tee $7
                  (i32.load offset=312
                   (local.get $0)
                  )
                 )
                 (i32.and
                  (i32.shr_u
                   (local.get $3)
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (i32.add
              (local.get $8)
              (i32.and
               (local.get $3)
               (i32.const 4092)
              )
             )
             (local.get $5)
            )
            (br $block14)
           )
           (i32.store
            (local.tee $8
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 6)
           )
           (i32.store
            (local.tee $9
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65824)
           )
           (call $fimport$5
            (local.get $1)
            (local.get $3)
            (local.get $5)
           )
           (br_if $block15
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
          (block $block17
           (block $block16
            (br_if $block16
             (i32.eqz
              (local.tee $3
               (i32.load
                (i32.add
                 (local.get $7)
                 (i32.and
                  (i32.shr_u
                   (local.tee $2
                    (i32.add
                     (local.get $2)
                     (i32.const -8)
                    )
                   )
                   (i32.const 10)
                  )
                  (i32.const 4194300)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (i32.add
              (local.get $3)
              (i32.and
               (local.get $2)
               (i32.const 4092)
              )
             )
             (local.get $4)
            )
            (br $block17)
           )
           (i32.store
            (local.tee $3
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 6)
           )
           (i32.store
            (local.tee $5
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65824)
           )
           (call $fimport$5
            (local.get $1)
            (local.get $2)
            (local.get $4)
           )
           (br_if $block18
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
          (i32.store offset=60
           (local.get $0)
           (local.get $2)
          )
          (i32.store offset=56
           (local.get $0)
           (i32.sub
            (local.get $2)
            (i32.const 0)
           )
          )
          (block $block20
           (block $block19
            (br_if $block19
             (i32.eq
              (i32.load offset=160
               (local.get $0)
              )
              (i32.const 65824)
             )
            )
            (br_if $block20
             (i32.ne
              (i32.load offset=164
               (local.get $0)
              )
              (i32.const 65824)
             )
            )
           )
           (i32.store
            (local.tee $2
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 6)
           )
           (i32.store
            (local.tee $3
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 4)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65824)
           )
           (call $fimport$20
            (local.get $0)
            (i32.const 65824)
            (i32.const 65828)
           )
           (block $block21
            (br_if $block21
             (i32.eqz
              (i32.load8_u
               (local.get $6)
              )
             )
            )
            (i32.store
             (local.get $2)
             (i32.const 6)
            )
            (i32.store
             (local.get $3)
             (i32.const 4)
            )
            (call $fimport$19
             (local.get $0)
            )
           )
           (br_if $block22
            (i32.eqz
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
            (i32.const 6)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
            (i32.const 4)
           )
           (br $block3)
          )
          (br_if $block23
           (i32.load8_u
            (local.get $6)
           )
          )
          (br $block22)
         )
         (i32.store
          (local.tee $2
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
          )
          (i32.const 6)
         )
         (i32.store
          (local.tee $4
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
          )
          (i32.const 4)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
          (i32.const 65824)
         )
         (call $fimport$6
          (local.get $0)
          (local.get $1)
          (i32.const 65824)
          (local.get $3)
          (i32.const 65536)
         )
         (i32.store
          (local.get $2)
          (i32.const 6)
         )
         (i32.store
          (local.get $4)
          (i32.const 4)
         )
         (br $block3)
        )
        (i32.store
         (local.get $8)
         (i32.const 6)
        )
        (i32.store
         (local.get $9)
         (i32.const 4)
        )
        (br $block3)
       )
       (i32.store
        (local.get $3)
        (i32.const 6)
       )
       (i32.store
        (local.get $5)
        (i32.const 4)
       )
       (br $block3)
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 6)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65828)
      )
      (call $fimport$19
       (local.get $0)
      )
      (br_if $block22
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 6)
      )
      (i32.store
       (local.get $3)
       (i32.const 4)
      )
      (br $block3)
     )
    )
    (block $block34
     (block $block33
      (block $block30
       (block $block27
        (block $block24
         (br_if $block24
          (i32.and
           (local.tee $2
            (i32.load offset=60
             (local.get $0)
            )
           )
           (i32.const 3)
          )
         )
         (block $block26
          (block $block25
           (br_if $block25
            (i32.eqz
             (local.tee $4
              (i32.load
               (i32.add
                (local.tee $3
                 (i32.load offset=312
                  (local.get $0)
                 )
                )
                (i32.and
                 (i32.shr_u
                  (local.get $2)
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $4
            (i32.load
             (i32.add
              (local.get $4)
              (i32.and
               (local.get $2)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block26)
          )
          (i32.store
           (local.tee $5
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 7)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65828)
          )
          (local.set $4
           (call $fimport$2
            (local.get $1)
            (local.get $2)
           )
          )
          (br_if $block27
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (block $block29
          (block $block28
           (br_if $block28
            (i32.eqz
             (local.tee $3
              (i32.load
               (i32.add
                (local.get $3)
                (i32.and
                 (i32.shr_u
                  (local.tee $5
                   (i32.add
                    (local.get $2)
                    (i32.const 4)
                   )
                  )
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $3
            (i32.load
             (i32.add
              (local.get $3)
              (i32.and
               (local.get $5)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block29)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 7)
          )
          (i32.store
           (local.tee $7
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65828)
          )
          (local.set $3
           (call $fimport$2
            (local.get $1)
            (local.get $5)
           )
          )
          (br_if $block30
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (i32.store offset=168
          (local.get $0)
          (local.get $3)
         )
         (i32.store offset=60
          (local.get $0)
          (local.get $4)
         )
         (i32.store offset=56
          (local.get $0)
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
         )
         (block $block32
          (block $block31
           (br_if $block31
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65828)
            )
           )
           (br_if $block32
            (i32.ne
             (i32.load offset=164
              (local.get $0)
             )
             (i32.const 65828)
            )
           )
          )
          (i32.store
           (local.tee $2
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 7)
          )
          (i32.store
           (local.tee $3
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65828)
          )
          (call $fimport$20
           (local.get $0)
           (i32.const 65828)
           (i32.const 65832)
          )
          (br_if $block33
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (br $block34)
        )
        (i32.store
         (local.tee $3
          (i32.add
           (local.get $0)
           (i32.const 308)
          )
         )
         (i32.const 7)
        )
        (i32.store
         (local.tee $4
          (i32.add
           (local.get $0)
           (i32.const 292)
          )
         )
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
         (i32.const 65828)
        )
        (call $fimport$6
         (local.get $0)
         (local.get $1)
         (i32.const 65828)
         (local.get $2)
         (i32.const 0)
        )
        (i32.store
         (local.get $3)
         (i32.const 7)
        )
        (i32.store
         (local.get $4)
         (i32.const 4)
        )
        (br $block3)
       )
       (i32.store
        (local.get $5)
        (i32.const 7)
       )
       (i32.store
        (local.get $6)
        (i32.const 4)
       )
       (br $block3)
      )
      (i32.store
       (local.get $6)
       (i32.const 7)
      )
      (i32.store
       (local.get $7)
       (i32.const 4)
      )
      (br $block3)
     )
     (i32.store
      (local.get $2)
      (i32.const 7)
     )
     (i32.store
      (local.get $3)
      (i32.const 4)
     )
     (br $block3)
    )
    (block
     (i32.store offset=40
      (local.get $0)
      (i32.mul
       (i32.load offset=40
        (local.get $0)
       )
       (i32.const 3)
      )
     )
     (block $block36
      (block $block35
       (br_if $block35
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65832)
        )
       )
       (br_if $block36
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65832)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 8)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65832)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65832)
       (i32.const 65834)
      )
      (br_if $block36
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 8)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=36
      (local.get $0)
      (i32.add
       (i32.load offset=36
        (local.get $0)
       )
       (i32.load offset=40
        (local.get $0)
       )
      )
     )
     (block $block38
      (block $block37
       (br_if $block37
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65834)
        )
       )
       (br_if $block38
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65834)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 9)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65834)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65834)
       (i32.const 65836)
      )
      (br_if $block38
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 9)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store
      (local.get $0)
      (i32.load offset=36
       (local.get $0)
      )
     )
     (block $block40
      (block $block39
       (br_if $block39
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65836)
        )
       )
       (br_if $block40
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65836)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 10)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65836)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65836)
       (i32.const 65838)
      )
      (br_if $block40
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 10)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (block $block41
      (br_if $block41
       (i32.and
        (local.tee $2
         (i32.load offset=168
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (local.get $2)
      )
      (block $block43
       (block $block42
        (br_if $block42
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65838)
         )
        )
        (br_if $block43
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65838)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 11)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65838)
        (i32.const 65838)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 11)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (br $block3)
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.const 11)
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65838)
     )
     (call $fimport$7
      (local.get $0)
      (i32.const 42)
      (local.get $1)
     )
     (i32.store
      (local.get $2)
      (i32.const 11)
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block3)
    )
   )
   (block
    (block $block46
     (block $block45
      (block $block44
       (br_if $block44
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block45
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65808)
        )
       )
       (br_if $block46
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
 (func $5 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (loop $label
   (block $block3
    (block
     (i32.store
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=324
          (local.get $0)
         )
        )
        (i32.const 786488)
       )
      )
      (local.tee $3
       (i32.add
        (i32.load
         (local.get $3)
        )
        (i32.const 1)
       )
      )
     )
     (block $block
      (br_if $block
       (i32.ne
        (local.get $3)
        (i32.const 100000)
       )
      )
      (i32.store offset=1048576
       (local.get $2)
       (i32.add
        (local.tee $3
         (i32.load offset=1048576
          (local.get $2)
         )
        )
        (i32.const 1)
       )
      )
      (br_if $block
       (i32.gt_u
        (local.get $3)
        (i32.const 255)
       )
      )
      (i32.store offset=1048580
       (i32.add
        (local.get $2)
        (i32.shl
         (local.get $3)
         (i32.const 2)
        )
       )
       (i32.const 14)
      )
     )
    )
    (block
     (i32.store offset=24
      (local.get $0)
      (local.tee $3
       (i32.add
        (local.tee $2
         (i32.load offset=24
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $3)
       (i32.const 31)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (local.tee $4
       (i32.eqz
        (local.get $3)
       )
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=252
      (local.get $0)
      (local.tee $3
       (i32.shr_u
        (i32.and
         (local.get $3)
         (i32.xor
          (local.get $2)
          (i32.const -1)
         )
        )
        (i32.const 31)
       )
      )
     )
     (i32.store offset=248
      (local.get $0)
      (local.get $3)
     )
     (i32.store offset=256
      (local.get $0)
      (i32.or
       (i32.load offset=256
        (local.get $0)
       )
       (local.get $3)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65932)
        )
       )
       (br_if $block2
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65932)
        )
       )
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 1)
      )
      (i32.store
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65932)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65932)
       (i32.const 65934)
      )
      (br_if $block2
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $3)
       (i32.const 1)
      )
      (i32.store
       (local.get $4)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i32.store offset=276
      (local.get $0)
      (i32.le_u
       (local.tee $2
        (i32.load offset=20
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=24
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=240
      (local.get $0)
      (local.tee $4
       (i32.le_u
        (local.get $3)
        (local.get $2)
       )
      )
     )
     (i32.store offset=236
      (local.get $0)
      (local.get $4)
     )
     (i32.store offset=232
      (local.get $0)
      (i32.gt_u
       (local.get $3)
       (local.get $2)
      )
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.get $2)
       (local.get $3)
      )
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65934)
        )
       )
       (br_if $block5
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65934)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65934)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65934)
       (i32.const 65936)
      )
      (br_if $block5
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 2)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (block $block6
      (br_if $block6
       (i32.load offset=276
        (local.get $0)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (block $block8
       (block $block7
        (br_if $block7
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65936)
         )
        )
        (br_if $block8
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65936)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 3)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65916)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65936)
        (i32.const 65936)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65916)
      )
      (br $block3)
     )
     (block $block10
      (block $block9
       (br_if $block9
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65936)
        )
       )
       (br_if $block10
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65936)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 3)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65936)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65936)
       (i32.const 65938)
      )
      (br_if $block10
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 3)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block
     (i64.store offset=248 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i64.store offset=236 align=4
      (local.get $0)
      (i64.const 0)
     )
     (i32.store offset=228
      (local.get $0)
      (i32.eq
       (local.tee $2
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $3
        (i32.load offset=28
         (local.get $0)
        )
       )
      )
     )
     (i32.store
      (local.get $0)
      (local.tee $2
       (i32.xor
        (local.get $2)
        (local.get $3)
       )
      )
     )
     (i32.store offset=232
      (local.get $0)
      (i32.shr_u
       (local.get $2)
       (i32.const 31)
      )
     )
     (block $block12
      (block $block11
       (br_if $block11
        (i32.eq
         (i32.load offset=160
          (local.get $0)
         )
         (i32.const 65938)
        )
       )
       (br_if $block12
        (i32.ne
         (i32.load offset=164
          (local.get $0)
         )
         (i32.const 65938)
        )
       )
      )
      (i32.store
       (local.tee $2
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $3
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65938)
      )
      (call $fimport$20
       (local.get $0)
       (i32.const 65938)
       (i32.const 65940)
      )
      (br_if $block12
       (i32.eqz
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.get $2)
       (i32.const 4)
      )
      (i32.store
       (local.get $3)
       (i32.const 2)
      )
      (br $block3)
     )
    )
    (block $block23
     (block $block22
      (block $block19
       (block $block16
        (block $block13
         (br_if $block13
          (i32.and
           (local.tee $2
            (i32.load offset=60
             (local.get $0)
            )
           )
           (i32.const 3)
          )
         )
         (block $block15
          (block $block14
           (br_if $block14
            (i32.eqz
             (local.tee $4
              (i32.load
               (i32.add
                (local.tee $3
                 (i32.load offset=312
                  (local.get $0)
                 )
                )
                (i32.and
                 (i32.shr_u
                  (local.get $2)
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $4
            (i32.load
             (i32.add
              (local.get $4)
              (i32.and
               (local.get $2)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block15)
          )
          (i32.store
           (local.tee $5
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 5)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65940)
          )
          (local.set $4
           (call $fimport$2
            (local.get $1)
            (local.get $2)
           )
          )
          (br_if $block16
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (block $block18
          (block $block17
           (br_if $block17
            (i32.eqz
             (local.tee $3
              (i32.load
               (i32.add
                (local.get $3)
                (i32.and
                 (i32.shr_u
                  (local.tee $5
                   (i32.add
                    (local.get $2)
                    (i32.const 4)
                   )
                  )
                  (i32.const 10)
                 )
                 (i32.const 4194300)
                )
               )
              )
             )
            )
           )
           (local.set $3
            (i32.load
             (i32.add
              (local.get $3)
              (i32.and
               (local.get $5)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block18)
          )
          (i32.store
           (local.tee $6
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 5)
          )
          (i32.store
           (local.tee $7
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65940)
          )
          (local.set $3
           (call $fimport$2
            (local.get $1)
            (local.get $5)
           )
          )
          (br_if $block19
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (i32.store offset=168
          (local.get $0)
          (local.get $3)
         )
         (i32.store offset=60
          (local.get $0)
          (local.get $4)
         )
         (i32.store offset=56
          (local.get $0)
          (i32.add
           (local.get $2)
           (i32.const 8)
          )
         )
         (block $block21
          (block $block20
           (br_if $block20
            (i32.eq
             (i32.load offset=160
              (local.get $0)
             )
             (i32.const 65940)
            )
           )
           (br_if $block21
            (i32.ne
             (i32.load offset=164
              (local.get $0)
             )
             (i32.const 65940)
            )
           )
          )
          (i32.store
           (local.tee $2
            (i32.add
             (local.get $0)
             (i32.const 308)
            )
           )
           (i32.const 5)
          )
          (i32.store
           (local.tee $3
            (i32.add
             (local.get $0)
             (i32.const 292)
            )
           )
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 65940)
          )
          (call $fimport$20
           (local.get $0)
           (i32.const 65940)
           (i32.const 65944)
          )
          (br_if $block22
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
         (br $block23)
        )
        (i32.store
         (local.tee $3
          (i32.add
           (local.get $0)
           (i32.const 308)
          )
         )
         (i32.const 5)
        )
        (i32.store
         (local.tee $4
          (i32.add
           (local.get $0)
           (i32.const 292)
          )
         )
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
         (i32.const 65940)
        )
        (call $fimport$6
         (local.get $0)
         (local.get $1)
         (i32.const 65940)
         (local.get $2)
         (i32.const 0)
        )
        (i32.store
         (local.get $3)
         (i32.const 5)
        )
        (i32.store
         (local.get $4)
         (i32.const 4)
        )
        (br $block3)
       )
       (i32.store
        (local.get $5)
        (i32.const 5)
       )
       (i32.store
        (local.get $6)
        (i32.const 4)
       )
       (br $block3)
      )
      (i32.store
       (local.get $6)
       (i32.const 5)
      )
      (i32.store
       (local.get $7)
       (i32.const 4)
      )
      (br $block3)
     )
     (i32.store
      (local.get $2)
      (i32.const 5)
     )
     (i32.store
      (local.get $3)
      (i32.const 4)
     )
     (br $block3)
    )
    (block $block43
     (block $block42
      (block $block39
       (block $block36
        (block $block33
         (block $block30
          (block $block27
           (block $block24
            (br_if $block24
             (i32.and
              (local.tee $2
               (i32.load offset=56
                (local.get $0)
               )
              )
              (i32.const 3)
             )
            )
            (block $block26
             (block $block25
              (br_if $block25
               (i32.eqz
                (local.tee $4
                 (i32.load
                  (i32.add
                   (local.tee $3
                    (i32.load offset=312
                     (local.get $0)
                    )
                   )
                   (i32.and
                    (i32.shr_u
                     (local.get $2)
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $4
               (i32.load
                (i32.add
                 (local.get $4)
                 (i32.and
                  (local.get $2)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block26)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $6
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (local.set $4
              (call $fimport$2
               (local.get $1)
               (local.get $2)
              )
             )
             (br_if $block27
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (i32.store offset=52
             (local.get $0)
             (local.get $4)
            )
            (block $block29
             (block $block28
              (br_if $block28
               (i32.eqz
                (local.tee $5
                 (i32.load
                  (i32.add
                   (local.get $3)
                   (i32.and
                    (i32.shr_u
                     (local.tee $4
                      (i32.add
                       (local.get $2)
                       (i32.const 4)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $4
               (i32.load
                (i32.add
                 (local.get $5)
                 (i32.and
                  (local.get $4)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block29)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $6
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (local.set $4
              (call $fimport$2
               (local.get $1)
               (local.get $4)
              )
             )
             (br_if $block30
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (i32.store offset=28
             (local.get $0)
             (local.get $4)
            )
            (block $block32
             (block $block31
              (br_if $block31
               (i32.eqz
                (local.tee $5
                 (i32.load
                  (i32.add
                   (local.get $3)
                   (i32.and
                    (i32.shr_u
                     (local.tee $4
                      (i32.add
                       (local.get $2)
                       (i32.const 8)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $4
               (i32.load
                (i32.add
                 (local.get $5)
                 (i32.and
                  (local.get $4)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block32)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $6
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (local.set $4
              (call $fimport$2
               (local.get $1)
               (local.get $4)
              )
             )
             (br_if $block33
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (i32.store offset=24
             (local.get $0)
             (local.get $4)
            )
            (block $block35
             (block $block34
              (br_if $block34
               (i32.eqz
                (local.tee $5
                 (i32.load
                  (i32.add
                   (local.get $3)
                   (i32.and
                    (i32.shr_u
                     (local.tee $4
                      (i32.add
                       (local.get $2)
                       (i32.const 12)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $4
               (i32.load
                (i32.add
                 (local.get $5)
                 (i32.and
                  (local.get $4)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block35)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $6
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (local.set $4
              (call $fimport$2
               (local.get $1)
               (local.get $4)
              )
             )
             (br_if $block36
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (i32.store offset=20
             (local.get $0)
             (local.get $4)
            )
            (block $block38
             (block $block37
              (br_if $block37
               (i32.eqz
                (local.tee $3
                 (i32.load
                  (i32.add
                   (local.get $3)
                   (i32.and
                    (i32.shr_u
                     (local.tee $4
                      (i32.add
                       (local.get $2)
                       (i32.const 16)
                      )
                     )
                     (i32.const 10)
                    )
                    (i32.const 4194300)
                   )
                  )
                 )
                )
               )
              )
              (local.set $3
               (i32.load
                (i32.add
                 (local.get $3)
                 (i32.and
                  (local.get $4)
                  (i32.const 4092)
                 )
                )
               )
              )
              (br $block38)
             )
             (i32.store
              (local.tee $5
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $6
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (local.set $3
              (call $fimport$2
               (local.get $1)
               (local.get $4)
              )
             )
             (br_if $block39
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (i32.store offset=16
             (local.get $0)
             (local.get $3)
            )
            (i32.store offset=56
             (local.get $0)
             (i32.add
              (local.get $2)
              (i32.const 20)
             )
            )
            (block $block41
             (block $block40
              (br_if $block40
               (i32.eq
                (i32.load offset=160
                 (local.get $0)
                )
                (i32.const 65944)
               )
              )
              (br_if $block41
               (i32.ne
                (i32.load offset=164
                 (local.get $0)
                )
                (i32.const 65944)
               )
              )
             )
             (i32.store
              (local.tee $2
               (i32.add
                (local.get $0)
                (i32.const 308)
               )
              )
              (i32.const 6)
             )
             (i32.store
              (local.tee $3
               (i32.add
                (local.get $0)
                (i32.const 292)
               )
              )
              (i32.const 2)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 65944)
             )
             (call $fimport$20
              (local.get $0)
              (i32.const 65944)
              (i32.const 65946)
             )
             (br_if $block42
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
            (br $block43)
           )
           (i32.store
            (local.tee $3
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
            )
            (i32.const 6)
           )
           (i32.store
            (local.tee $4
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
            )
            (i32.const 2)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 65944)
           )
           (call $fimport$6
            (local.get $0)
            (local.get $1)
            (i32.const 65944)
            (local.get $2)
            (i32.const 0)
           )
           (i32.store
            (local.get $3)
            (i32.const 6)
           )
           (i32.store
            (local.get $4)
            (i32.const 2)
           )
           (br $block3)
          )
          (i32.store
           (local.get $5)
           (i32.const 6)
          )
          (i32.store
           (local.get $6)
           (i32.const 2)
          )
          (br $block3)
         )
         (i32.store
          (local.get $5)
          (i32.const 6)
         )
         (i32.store
          (local.get $6)
          (i32.const 2)
         )
         (br $block3)
        )
        (i32.store
         (local.get $5)
         (i32.const 6)
        )
        (i32.store
         (local.get $6)
         (i32.const 2)
        )
        (br $block3)
       )
       (i32.store
        (local.get $5)
        (i32.const 6)
       )
       (i32.store
        (local.get $6)
        (i32.const 2)
       )
       (br $block3)
      )
      (i32.store
       (local.get $5)
       (i32.const 6)
      )
      (i32.store
       (local.get $6)
       (i32.const 2)
      )
      (br $block3)
     )
     (i32.store
      (local.get $2)
      (i32.const 6)
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block3)
    )
    (block
     (block $block44
      (br_if $block44
       (i32.and
        (local.tee $2
         (i32.load offset=168
          (local.get $0)
         )
        )
        (i32.const 1)
       )
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (local.get $2)
      )
      (block $block46
       (block $block45
        (br_if $block45
         (i32.eq
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const 65946)
         )
        )
        (br_if $block46
         (i32.ne
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const 65946)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 7)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (call $fimport$20
        (local.get $0)
        (i32.const 65946)
        (i32.const 65946)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 7)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (br $block3)
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.const 7)
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.const 65946)
     )
     (call $fimport$7
      (local.get $0)
      (i32.const 42)
      (local.get $1)
     )
     (i32.store
      (local.get $2)
      (i32.const 7)
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block3)
    )
   )
   (block
    (block $block49
     (block $block48
      (block $block47
       (br_if $block47
        (i32.ge_u
         (local.tee $2
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.load offset=308
            (local.get $0)
           )
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block48
        (i32.eq
         (local.tee $3
          (i32.load offset=188
           (local.get $0)
          )
         )
         (i32.const 65932)
        )
       )
       (br_if $block49
        (i32.eq
         (i32.load
          (local.tee $4
           (i32.add
            (i32.load offset=324
             (local.get $0)
            )
            (i32.mul
             (i32.and
              (i32.shr_u
               (local.get $3)
               (i32.const 1)
              )
              (i32.const 65535)
             )
             (i32.const 12)
            )
           )
          )
         )
         (local.get $3)
        )
       )
      )
      (return)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 0)
     )
     (i32.store offset=332
      (local.get $0)
      (local.get $2)
     )
     (drop
      (local.get $0)
     )
     (drop
      (local.get $1)
     )
     (br $label)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 0)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $2)
    )
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=8
      (local.get $4)
     )
    )
   )
  )
 )
)

