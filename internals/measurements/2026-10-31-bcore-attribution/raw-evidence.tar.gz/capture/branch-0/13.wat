(module
 (type $0 (func (param i32 i32) (result i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32) (result i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32)))
 (type $5 (func (param i32 i32 i32) (result i32)))
 (type $6 (func (param i32 i32 i32 i32 i32)))
 (type $7 (func (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_read8" (func $fimport$0 (param i32 i32) (result i32)))
 (import "env" "mem_read16" (func $fimport$1 (param i32 i32) (result i32)))
 (import "env" "mem_read32" (func $fimport$2 (param i32 i32) (result i32)))
 (import "env" "mem_write8" (func $fimport$3 (param i32 i32 i32)))
 (import "env" "mem_write16" (func $fimport$4 (param i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$5 (param i32 i32 i32)))
 (import "env" "cec_data_alignment" (func $fimport$6 (param i32 i32 i32 i32 i32)))
 (import "env" "cec_exception" (func $fimport$7 (param i32 i32 i32)))
 (import "env" "cec_raise" (func $fimport$8 (param i32 i32)))
 (import "env" "cec_return_rti" (func $fimport$9 (param i32) (result i32)))
 (import "env" "cec_return_rtx" (func $fimport$10 (param i32) (result i32)))
 (import "env" "cec_return_rtn" (func $fimport$11 (param i32) (result i32)))
 (import "env" "cec_return_rte" (func $fimport$12 (param i32) (result i32)))
 (import "env" "cec_cli" (func $fimport$13 (param i32) (result i32)))
 (import "env" "cec_sti" (func $fimport$14 (param i32 i32)))
 (import "env" "cec_push_reti" (func $fimport$15 (param i32)))
 (import "env" "cec_pop_reti" (func $fimport$16 (param i32)))
 (import "env" "cec_check_sup" (func $fimport$17 (param i32)))
 (import "env" "cec_is_user_mode" (func $fimport$18 (result i32)))
 (import "env" "cec_check_pending" (func $fimport$19 (param i32)))
 (import "env" "bfin_hwloop_step" (func $fimport$20 (param i32 i32 i32)))
 (import "env" "bfin_putchar" (func $fimport$21 (param i32)))
 (import "env" "bfin_syscall" (func $fimport$22 (param i32 i32)))
 (import "env" "memset" (func $fimport$23 (param i32 i32 i32) (result i32)))
 (import "env" "memcpy" (func $fimport$24 (param i32 i32 i32) (result i32)))
 (import "env" "memmove" (func $fimport$25 (param i32 i32 i32) (result i32)))
 (export "0" (func $0))
 (export "1" (func $1))
 (export "2" (func $2))
 (export "3" (func $3))
 (export "4" (func $4))
 (export "5" (func $5))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local $scratch i32)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i64.store offset=248 align=4
     (local.get $0)
     (i64.const 0)
    )
    (i32.store offset=232
     (local.get $0)
     (i32.const 0)
    )
    (i32.store
     (i32.add
      (block (result i32)
       (local.set $scratch
        (local.get $0)
       )
       (local.set $29
        (local.tee $2
         (i32.shr_u
          (i32.load
           (i32.add
            (local.get $0)
            (i32.load
             (local.get $28)
            )
           )
          )
          (i32.const 7)
         )
        )
       )
       (local.get $scratch)
      )
      (i32.load offset=4
       (local.get $28)
      )
     )
     (local.get $29)
    )
    (i32.store offset=228
     (local.get $0)
     (i32.eqz
      (local.get $2)
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load offset=8
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=12
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=16
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 4)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=24
       (local.get $28)
      )
      (i32.load offset=28
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=32
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 4)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
 (func $1 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i64.store offset=248 align=4
     (local.get $0)
     (i64.const 0)
    )
    (i64.store offset=236 align=4
     (local.get $0)
     (i64.const 0)
    )
    (i32.store offset=228
     (local.get $0)
     (i32.eq
      (local.tee $2
       (i32.load
        (local.get $0)
       )
      )
      (local.tee $3
       (i32.load offset=4
        (local.get $0)
       )
      )
     )
    )
    (i32.store offset=4
     (local.get $0)
     (local.tee $2
      (i32.xor
       (local.get $2)
       (local.get $3)
      )
     )
    )
    (i32.store offset=232
     (local.get $0)
     (i32.shr_u
      (local.get $2)
      (i32.const 31)
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=12
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=16
       (local.get $28)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=24
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
 (func $2 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i32.store offset=40
     (local.get $0)
     (i32.load offset=4
      (local.get $0)
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=12
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=16
       (local.get $28)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=24
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
 (func $3 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i32.store offset=40
     (local.get $0)
     (i32.mul
      (i32.load offset=40
       (local.get $0)
      )
      (i32.const 3)
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=12
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=16
       (local.get $28)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=24
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
 (func $4 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i32.store offset=36
     (local.get $0)
     (i32.add
      (i32.load offset=36
       (local.get $0)
      )
      (i32.load offset=40
       (local.get $0)
      )
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=12
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=16
       (local.get $28)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=24
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
 (func $5 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i32)
  (local $29 i32)
  (local $30 i64)
  (local.set $28
   (i32.load
    (i32.const 41183968)
   )
  )
  (block $block2
   (block
    (i32.store
     (local.get $0)
     (i32.load offset=36
      (local.get $0)
     )
    )
    (block $block1
     (block $block
      (br_if $block
       (i32.eq
        (i32.load offset=160
         (local.get $0)
        )
        (i32.load
         (local.get $28)
        )
       )
      )
      (br_if $block1
       (i32.ne
        (i32.load offset=164
         (local.get $0)
        )
        (i32.load offset=4
         (local.get $28)
        )
       )
      )
     )
     (i32.store
      (local.tee $2
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
      )
      (i32.load offset=8
       (local.get $28)
      )
     )
     (i32.store
      (local.tee $3
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
      (i32.load offset=12
       (local.get $28)
      )
     )
     (call $fimport$20
      (local.get $0)
      (i32.load offset=16
       (local.get $28)
      )
      (i32.load offset=20
       (local.get $28)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $2)
      (i32.load offset=24
       (local.get $28)
      )
     )
     (i32.store
      (local.get $3)
      (i32.const 2)
     )
     (br $block2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (i32.const 1)
 )
)

