(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32 i32 i32)))
 (type $2 (func (param i32 i32 i32)))
 (type $3 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (export "bb_0x00010092" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (block $block5
   (block $block10
    (block $block3
     (block $block
      (br_if $block
       (i32.gt_u
        (i32.add
         (local.tee $2
          (i32.load offset=160
           (local.get $0)
          )
         )
         (i32.const -65689)
        )
        (i32.const -8)
       )
      )
      (br_if $block
       (i32.gt_u
        (i32.add
         (local.tee $3
          (i32.load offset=164
           (local.get $0)
          )
         )
         (i32.const -65689)
        )
        (i32.const -8)
       )
      )
      (local.set $4
       (i32.load offset=312
        (local.get $0)
       )
      )
      (local.set $5
       (i32.load offset=316
        (local.get $0)
       )
      )
      (local.set $6
       (i32.load offset=324
        (local.get $0)
       )
      )
      (i64.store offset=236 align=4
       (local.get $0)
       (i64.const 4294967297)
      )
      (i32.store offset=276
       (local.get $0)
       (local.tee $8
        (i32.eqz
         (local.tee $7
          (i32.load
           (local.get $0)
          )
         )
        )
       )
      )
      (i32.store offset=232
       (local.get $0)
       (i32.shr_u
        (local.get $7)
        (i32.const 31)
       )
      )
      (i32.store offset=228
       (local.get $0)
       (local.get $8)
      )
      (block $block1
       (br_if $block1
        (i32.eqz
         (local.get $7)
        )
       )
       (i32.store
        (local.tee $8
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
        )
        (i32.const 65728)
       )
       (block $block2
        (br_if $block2
         (i32.ge_u
          (local.tee $7
           (i32.add
            (i32.load offset=332
             (local.get $0)
            )
            (i32.const 2)
           )
          )
          (i32.load offset=328
           (local.get $0)
          )
         )
        )
        (br_if $block3
         (i32.eq
          (i32.load offset=394368
           (local.get $6)
          )
          (i32.const 65728)
         )
        )
       )
       (i32.store offset=308
        (local.get $0)
        (i32.const 2)
       )
       (i32.store offset=292
        (local.get $0)
        (i32.const 2)
       )
       (i32.store8 offset=296
        (local.get $0)
        (i32.const 1)
       )
       (i32.store
        (local.get $8)
        (i32.const 65728)
       )
       (return)
      )
      (block $block4
       (br_if $block4
        (i32.eqz
         (i32.and
          (local.tee $7
           (i32.load offset=48
            (local.get $0)
           )
          )
          (i32.const 3)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 3)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65686)
       )
       (call $fimport$0
        (local.get $0)
        (local.get $1)
        (i32.const 65686)
        (local.get $7)
        (i32.const 65536)
       )
       (br $block5)
      )
      (local.set $8
       (i32.load offset=24
        (local.get $0)
       )
      )
      (block $block7
       (block $block6
        (br_if $block6
         (i32.eqz
          (local.tee $4
           (i32.load
            (i32.add
             (local.get $4)
             (i32.and
              (i32.shr_u
               (local.get $7)
               (i32.const 10)
              )
              (i32.const 4194300)
             )
            )
           )
          )
         )
        )
        (i32.store
         (i32.add
          (local.get $4)
          (i32.and
           (local.get $7)
           (i32.const 4092)
          )
         )
         (local.get $8)
        )
        (br $block7)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 3)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65686)
       )
       (call $fimport$1
        (local.get $1)
        (local.get $7)
        (local.get $8)
       )
       (br_if $block5
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (block $block8
       (br_if $block8
        (i32.eqz
         (i32.load8_u
          (local.get $5)
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 3)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 2)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
        (i32.const 65688)
       )
       (call $fimport$2
        (local.get $0)
       )
       (br_if $block5
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
      (i32.store
       (local.tee $8
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
       )
       (i32.const 66600)
      )
      (i32.store offset=168
       (local.get $0)
       (select
        (select
         (i32.load offset=148
          (local.get $0)
         )
         (local.tee $7
          (select
           (select
            (i32.load offset=144
             (local.get $0)
            )
            (i32.const 65692)
            (i32.gt_u
             (i32.load offset=152
              (local.get $0)
             )
             (i32.const 1)
            )
           )
           (i32.const 65692)
           (i32.eq
            (local.get $2)
            (i32.const 65688)
           )
          )
         )
         (i32.gt_u
          (i32.load offset=156
           (local.get $0)
          )
          (i32.const 1)
         )
        )
        (local.get $7)
        (i32.eq
         (local.get $3)
         (i32.const 65688)
        )
       )
      )
      (block $block9
       (br_if $block9
        (i32.ge_u
         (local.tee $7
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.const 4)
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block10
        (i32.eq
         (i32.load offset=399600
          (local.get $6)
         )
         (i32.const 66600)
        )
       )
      )
      (i32.store offset=308
       (local.get $0)
       (i32.const 4)
      )
      (i32.store offset=292
       (local.get $0)
       (i32.const 4)
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (i32.store
       (local.get $8)
       (i32.const 66600)
      )
      (return)
     )
     (i32.store8 offset=341
      (local.get $0)
      (i32.const 1)
     )
     (return)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $7)
    )
    (i32.store
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
     (i32.const 65728)
    )
    (return_call_indirect $timport$0 (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=394376
      (local.get $6)
     )
    )
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $7)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
    (i32.const 66600)
   )
   (return_call_indirect $timport$0 (type $0)
    (local.get $0)
    (local.get $1)
    (i32.load offset=399608
     (local.get $6)
    )
   )
  )
  (block $block12
   (block $block11
    (br_if $block11
     (i32.ge_u
      (local.tee $7
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (i32.const 3)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block12
     (i32.eq
      (i32.load
       (local.tee $6
        (i32.add
         (local.get $6)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.tee $8
             (i32.load
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
            )
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $8)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (i32.const 3)
   )
   (i32.store offset=292
    (local.get $0)
    (i32.const 2)
   )
   (return)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $7)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $6)
   )
  )
 )
 ;; custom section "linking", size 37
 ;; custom section "reloc.CODE", size 38
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

