(module
 (type $0 (func (param i32 i32 i32)))
 (type $1 (func (param i32 i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32) (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (import "env" "mem_read32" (func $fimport$3 (param i32 i32) (result i32)))
 (import "env" "cec_exception" (func $fimport$4 (param i32 i32 i32)))
 (export "bb_0x00010130" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (block $block2
   (block $block11
    (block $block8
     (block $block5
      (block $block
       (br_if $block
        (i32.gt_u
         (i32.add
          (i32.load offset=160
           (local.get $0)
          )
          (i32.const -65867)
         )
         (i32.const -28)
        )
       )
       (br_if $block
        (i32.gt_u
         (i32.add
          (i32.load offset=164
           (local.get $0)
          )
          (i32.const -65867)
         )
         (i32.const -28)
        )
       )
       (local.set $2
        (i32.load offset=312
         (local.get $0)
        )
       )
       (local.set $3
        (i32.load offset=316
         (local.get $0)
        )
       )
       (local.set $4
        (i32.load offset=324
         (local.get $0)
        )
       )
       (i64.store offset=248 align=4
        (local.get $0)
        (i64.const 0)
       )
       (i64.store offset=236 align=4
        (local.get $0)
        (i64.const 0)
       )
       (i32.store offset=228
        (local.get $0)
        (i32.eqz
         (local.tee $5
          (i32.load
           (local.get $0)
          )
         )
        )
       )
       (local.set $6
        (i32.const 5)
       )
       (i32.store
        (local.get $0)
        (local.tee $7
         (i32.rotl
          (local.get $5)
          (i32.const 5)
         )
        )
       )
       (i32.store offset=232
        (local.get $0)
        (local.tee $8
         (i32.shr_u
          (local.tee $5
           (i32.shl
            (local.get $5)
            (i32.const 5)
           )
          )
          (i32.const 31)
         )
        )
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (i32.and
          (local.get $5)
          (i32.const 65504)
         )
         (i32.const 2135556096)
        )
       )
       (local.set $10
        (i32.add
         (local.tee $9
          (i32.load offset=56
           (local.get $0)
          )
         )
         (i32.const -4)
        )
       )
       (block $block1
        (br_if $block1
         (i32.eqz
          (i32.and
           (local.get $9)
           (i32.const 3)
          )
         )
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 308)
         )
         (i32.const 5)
        )
        (local.set $11
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 292)
         )
         (i32.const 4)
        )
        (i32.store
         (local.tee $5
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
         )
         (i32.const 65852)
        )
        (call $fimport$0
         (local.get $0)
         (local.get $1)
         (i32.const 65852)
         (local.get $10)
         (i32.const 65536)
        )
        (local.set $5
         (i32.load
          (local.get $5)
         )
        )
        (local.set $12
         (i32.load8_u offset=296
          (local.get $0)
         )
        )
        (br $block2)
       )
       (local.set $13
        (i32.load offset=60
         (local.get $0)
        )
       )
       (local.set $5
        (i32.load offset=168
         (local.get $0)
        )
       )
       (block $block4
        (block $block3
         (br_if $block3
          (i32.eqz
           (local.tee $6
            (i32.load
             (local.tee $14
              (i32.add
               (local.get $2)
               (i32.and
                (i32.shr_u
                 (local.get $10)
                 (i32.const 10)
                )
                (i32.const 4194300)
               )
              )
             )
            )
           )
          )
         )
         (i32.store
          (i32.add
           (local.get $6)
           (i32.and
            (local.get $10)
            (i32.const 4092)
           )
          )
          (local.get $5)
         )
         (br $block4)
        )
        (local.set $6
         (i32.const 5)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 308)
         )
         (i32.const 5)
        )
        (local.set $11
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 292)
         )
         (i32.const 4)
        )
        (i32.store
         (local.tee $15
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
         )
         (i32.const 65852)
        )
        (call $fimport$1
         (local.get $1)
         (local.get $10)
         (local.get $5)
        )
        (br_if $block5
         (local.tee $12
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
        )
       )
       (block $block7
        (block $block6
         (br_if $block6
          (i32.eqz
           (local.tee $6
            (i32.load
             (local.tee $2
              (i32.add
               (local.get $2)
               (i32.and
                (i32.shr_u
                 (local.tee $5
                  (i32.add
                   (local.get $9)
                   (i32.const -8)
                  )
                 )
                 (i32.const 10)
                )
                (i32.const 4194300)
               )
              )
             )
            )
           )
          )
         )
         (i32.store
          (i32.add
           (local.get $6)
           (i32.and
            (local.get $5)
            (i32.const 4092)
           )
          )
          (local.get $13)
         )
         (br $block7)
        )
        (local.set $6
         (i32.const 5)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 308)
         )
         (i32.const 5)
        )
        (local.set $11
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 292)
         )
         (i32.const 4)
        )
        (i32.store
         (local.tee $15
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
         )
         (i32.const 65852)
        )
        (call $fimport$1
         (local.get $1)
         (local.get $5)
         (local.get $13)
        )
        (br_if $block8
         (local.tee $12
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
        )
       )
       (i32.store offset=56
        (local.get $0)
        (local.get $5)
       )
       (i32.store offset=60
        (local.get $0)
        (local.get $5)
       )
       (block $block9
        (br_if $block9
         (i32.eqz
          (i32.load8_u
           (local.get $3)
          )
         )
        )
        (local.set $6
         (i32.const 5)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 308)
         )
         (i32.const 5)
        )
        (local.set $11
         (i32.const 4)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 292)
         )
         (i32.const 4)
        )
        (i32.store
         (local.tee $3
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
         )
         (i32.const 65856)
        )
        (call $fimport$2
         (local.get $0)
        )
        (br_if $block9
         (i32.eqz
          (local.tee $12
           (i32.load8_u offset=296
            (local.get $0)
           )
          )
         )
        )
        (local.set $5
         (i32.load
          (local.get $3)
         )
        )
        (br $block2)
       )
       (i32.store offset=4
        (local.get $0)
        (i32.const 2135587861)
       )
       (i32.store
        (local.get $0)
        (local.tee $6
         (i32.add
          (local.get $7)
          (i32.const 2135587861)
         )
        )
       )
       (i32.store offset=240
        (local.get $0)
        (local.tee $7
         (i32.gt_u
          (local.get $7)
          (i32.const -2135587862)
         )
        )
       )
       (i32.store offset=236
        (local.get $0)
        (local.get $7)
       )
       (i32.store offset=232
        (local.get $0)
        (local.tee $7
         (i32.shr_u
          (local.get $6)
          (i32.const 31)
         )
        )
       )
       (i32.store offset=228
        (local.get $0)
        (i32.eqz
         (local.get $6)
        )
       )
       (i32.store offset=252
        (local.get $0)
        (local.tee $6
         (i32.and
          (local.get $7)
          (i32.xor
           (local.get $8)
           (i32.const -1)
          )
         )
        )
       )
       (i32.store offset=248
        (local.get $0)
        (local.get $6)
       )
       (i32.store offset=256
        (local.get $0)
        (i32.or
         (i32.load offset=256
          (local.get $0)
         )
         (local.get $6)
        )
       )
       (block $block10
        (br_if $block10
         (i32.eqz
          (local.tee $6
           (i32.load
            (local.get $2)
           )
          )
         )
        )
        (local.set $2
         (i32.load
          (i32.add
           (local.get $6)
           (i32.and
            (local.get $5)
            (i32.const 4092)
           )
          )
         )
        )
        (br $block11)
       )
       (local.set $6
        (i32.const 8)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 308)
        )
        (i32.const 8)
       )
       (local.set $11
        (i32.const 4)
       )
       (i32.store
        (i32.add
         (local.get $0)
         (i32.const 292)
        )
        (i32.const 4)
       )
       (i32.store
        (local.tee $7
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
        )
        (i32.const 65862)
       )
       (local.set $2
        (call $fimport$3
         (local.get $1)
         (local.get $5)
        )
       )
       (br_if $block11
        (i32.eqz
         (local.tee $12
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
        )
       )
       (local.set $5
        (i32.load
         (local.get $7)
        )
       )
       (br $block2)
      )
      (i32.store8 offset=341
       (local.get $0)
       (i32.const 1)
      )
      (return)
     )
     (local.set $5
      (i32.load
       (local.get $15)
      )
     )
     (br $block2)
    )
    (local.set $5
     (i32.load
      (local.get $15)
     )
    )
    (br $block2)
   )
   (block $block15
    (block $block14
     (block $block13
      (block $block12
       (br_if $block12
        (i32.eqz
         (local.tee $5
          (i32.load
           (local.get $14)
          )
         )
        )
       )
       (local.set $5
        (i32.load
         (i32.add
          (local.get $5)
          (i32.and
           (local.get $10)
           (i32.const 4092)
          )
         )
        )
       )
       (br $block13)
      )
      (local.set $6
       (i32.const 8)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 8)
      )
      (local.set $11
       (i32.const 4)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 4)
      )
      (i32.store
       (local.tee $7
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
       )
       (i32.const 65862)
      )
      (local.set $5
       (call $fimport$3
        (local.get $1)
        (local.get $10)
       )
      )
      (br_if $block14
       (local.tee $12
        (i32.load8_u offset=296
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=168
      (local.get $0)
      (local.get $5)
     )
     (i32.store offset=60
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=56
      (local.get $0)
      (local.get $9)
     )
     (local.set $12
      (i32.const 1)
     )
     (br_if $block15
      (i32.and
       (local.get $5)
       (i32.const 1)
      )
     )
     (local.set $11
      (i32.const 2)
     )
     (local.set $6
      (i32.const 9)
     )
     (br $block2)
    )
    (local.set $5
     (i32.load
      (local.get $7)
     )
    )
    (br $block2)
   )
   (local.set $6
    (i32.const 9)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 308)
    )
    (i32.const 9)
   )
   (local.set $11
    (i32.const 2)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 292)
    )
    (i32.const 2)
   )
   (i32.store
    (local.tee $5
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
    )
    (i32.const 65866)
   )
   (call $fimport$4
    (local.get $0)
    (i32.const 42)
    (local.get $1)
   )
   (local.set $5
    (i32.load
     (local.get $5)
    )
   )
   (local.set $12
    (i32.load8_u offset=296
     (local.get $0)
    )
   )
  )
  (block $block17
   (block $block16
    (br_if $block16
     (i32.ge_u
      (local.tee $9
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $6)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block17
     (i32.eq
      (i32.load
       (local.tee $10
        (i32.add
         (local.get $4)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $5)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $5)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $6)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $11)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $5)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $12)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $9)
  )
  (i32.store offset=188
   (local.get $0)
   (local.get $5)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (return_call_indirect $timport$0 (type $1)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $10)
   )
  )
 )
 ;; custom section "linking", size 43
 ;; custom section "reloc.CODE", size 38
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

