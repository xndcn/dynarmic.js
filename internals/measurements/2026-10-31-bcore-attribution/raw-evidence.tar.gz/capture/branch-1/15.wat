(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32) (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (import "env" "mem_read32" (func $fimport$3 (param i32 i32) (result i32)))
 (import "env" "cec_exception" (func $fimport$4 (param i32 i32 i32)))
 (export "bb_0x0001009c" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (block $block6
   (block $block2
    (block $block48
     (block $block45
      (block $block42
       (block $block39
        (block $block36
         (block $block33
          (block $block30
           (block $block27
            (block $block22
             (block $block15
              (block $block10
               (block $block19
                (block $block
                 (br_if $block
                  (i32.gt_u
                   (i32.add
                    (i32.load offset=160
                     (local.get $0)
                    )
                    (i32.const -65727)
                   )
                   (i32.const -36)
                  )
                 )
                 (br_if $block
                  (i32.gt_u
                   (i32.add
                    (i32.load offset=164
                     (local.get $0)
                    )
                    (i32.const -65727)
                   )
                   (i32.const -36)
                  )
                 )
                 (local.set $2
                  (i32.load offset=324
                   (local.get $0)
                  )
                 )
                 (block $block1
                  (br_if $block1
                   (i32.eqz
                    (i32.and
                     (local.tee $3
                      (i32.load offset=48
                       (local.get $0)
                      )
                     )
                     (i32.const 3)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 1)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 1)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (call $fimport$0
                   (local.get $0)
                   (local.get $1)
                   (i32.const 65692)
                   (local.get $3)
                   (i32.const 65536)
                  )
                  (local.set $6
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                  (br $block2)
                 )
                 (local.set $7
                  (i32.load offset=316
                   (local.get $0)
                  )
                 )
                 (local.set $8
                  (i32.load offset=20
                   (local.get $0)
                  )
                 )
                 (block $block4
                  (block $block3
                   (br_if $block3
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.tee $9
                         (i32.load offset=312
                          (local.get $0)
                         )
                        )
                        (i32.and
                         (i32.shr_u
                          (local.get $3)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.store
                    (i32.add
                     (local.get $10)
                     (i32.and
                      (local.get $3)
                      (i32.const 4092)
                     )
                    )
                    (local.get $8)
                   )
                   (br $block4)
                  )
                  (local.set $4
                   (i32.const 1)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 1)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (call $fimport$1
                   (local.get $1)
                   (local.get $3)
                   (local.get $8)
                  )
                  (br_if $block2
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (block $block5
                  (br_if $block5
                   (i32.eqz
                    (i32.load8_u
                     (local.get $7)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 1)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 1)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65694)
                  )
                  (call $fimport$2
                   (local.get $0)
                  )
                  (br_if $block5
                   (i32.eqz
                    (local.tee $6
                     (i32.load8_u offset=296
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (local.set $7
                   (i32.load
                    (local.get $3)
                   )
                  )
                  (br $block6)
                 )
                 (block $block7
                  (br_if $block7
                   (i32.eqz
                    (i32.and
                     (local.tee $3
                      (i32.load offset=52
                       (local.get $0)
                      )
                     )
                     (i32.const 3)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $9
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65694)
                  )
                  (call $fimport$0
                   (local.get $0)
                   (local.get $1)
                   (i32.const 65694)
                   (local.get $3)
                   (i32.const 65536)
                  )
                  (local.set $7
                   (i32.load
                    (local.get $9)
                   )
                  )
                  (local.set $6
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (br $block6)
                 )
                 (local.set $8
                  (i32.load
                   (local.get $0)
                  )
                 )
                 (block $block9
                  (block $block8
                   (br_if $block8
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.get $3)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.store
                    (i32.add
                     (local.get $10)
                     (i32.and
                      (local.get $3)
                      (i32.const 4092)
                     )
                    )
                    (local.get $8)
                   )
                   (br $block9)
                  )
                  (local.set $4
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65694)
                  )
                  (call $fimport$1
                   (local.get $1)
                   (local.get $3)
                   (local.get $8)
                  )
                  (br_if $block10
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=52
                  (local.get $0)
                  (i32.add
                   (local.get $3)
                   (i32.const 4)
                  )
                 )
                 (block $block11
                  (br_if $block11
                   (i32.eqz
                    (i32.load8_u
                     (local.get $7)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65696)
                  )
                  (call $fimport$2
                   (local.get $0)
                  )
                  (br_if $block11
                   (i32.eqz
                    (local.tee $6
                     (i32.load8_u offset=296
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (local.set $7
                   (i32.load
                    (local.get $3)
                   )
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (br $block6)
                 )
                 (i32.store
                  (local.get $0)
                  (i32.const 6)
                 )
                 (i32.store offset=28
                  (local.get $0)
                  (local.tee $3
                   (i32.add
                    (local.tee $10
                     (i32.load offset=28
                      (local.get $0)
                     )
                    )
                    (i32.const 1)
                   )
                  )
                 )
                 (i32.store offset=232
                  (local.get $0)
                  (i32.shr_u
                   (local.get $3)
                   (i32.const 31)
                  )
                 )
                 (i32.store offset=228
                  (local.get $0)
                  (local.tee $8
                   (i32.eqz
                    (local.get $3)
                   )
                  )
                 )
                 (i32.store offset=240
                  (local.get $0)
                  (local.get $8)
                 )
                 (i32.store offset=236
                  (local.get $0)
                  (local.get $8)
                 )
                 (i32.store offset=252
                  (local.get $0)
                  (local.tee $8
                   (i32.shr_u
                    (i32.and
                     (local.get $3)
                     (i32.xor
                      (local.get $10)
                      (i32.const -1)
                     )
                    )
                    (i32.const 31)
                   )
                  )
                 )
                 (i32.store offset=248
                  (local.get $0)
                  (local.get $8)
                 )
                 (i32.store offset=256
                  (local.get $0)
                  (i32.or
                   (i32.load offset=256
                    (local.get $0)
                   )
                   (local.get $8)
                  )
                 )
                 (block $block12
                  (br_if $block12
                   (i32.eqz
                    (i32.and
                     (local.tee $8
                      (i32.load offset=44
                       (local.get $0)
                      )
                     )
                     (i32.const 3)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 5)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 5)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65700)
                  )
                  (call $fimport$0
                   (local.get $0)
                   (local.get $1)
                   (i32.const 65700)
                   (local.get $8)
                   (i32.const 65536)
                  )
                  (local.set $7
                   (i32.load
                    (local.get $3)
                   )
                  )
                  (local.set $6
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                  (br $block6)
                 )
                 (block $block14
                  (block $block13
                   (br_if $block13
                    (i32.eqz
                     (local.tee $4
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.get $8)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (i32.store
                    (i32.add
                     (local.get $4)
                     (i32.and
                      (local.get $8)
                      (i32.const 4092)
                     )
                    )
                    (local.get $3)
                   )
                   (br $block14)
                  )
                  (local.set $4
                   (i32.const 5)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 5)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $11
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65700)
                  )
                  (call $fimport$1
                   (local.get $1)
                   (local.get $8)
                   (local.get $3)
                  )
                  (br_if $block15
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (block $block16
                  (br_if $block16
                   (i32.eqz
                    (i32.load8_u
                     (local.get $7)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 5)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 5)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $8
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65702)
                  )
                  (call $fimport$2
                   (local.get $0)
                  )
                  (br_if $block16
                   (i32.eqz
                    (local.tee $6
                     (i32.load8_u offset=296
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (local.set $7
                   (i32.load
                    (local.get $8)
                   )
                  )
                  (br $block6)
                 )
                 (i32.store offset=240
                  (local.get $0)
                  (local.tee $8
                   (i32.gt_u
                    (local.get $3)
                    (i32.const 5)
                   )
                  )
                 )
                 (i32.store offset=236
                  (local.get $0)
                  (local.get $8)
                 )
                 (i32.store offset=228
                  (local.get $0)
                  (local.tee $10
                   (i32.eqz
                    (local.tee $8
                     (i32.add
                      (local.get $10)
                      (i32.const -5)
                     )
                    )
                   )
                  )
                 )
                 (i32.store offset=276
                  (local.get $0)
                  (local.get $10)
                 )
                 (i32.store offset=232
                  (local.get $0)
                  (i32.shr_u
                   (i32.or
                    (local.get $8)
                    (local.get $3)
                   )
                   (i32.const 31)
                  )
                 )
                 (block $block17
                  (br_if $block17
                   (i32.eqz
                    (local.get $8)
                   )
                  )
                  (i32.store
                   (local.tee $9
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65668)
                  )
                  (block $block18
                   (br_if $block18
                    (i32.ge_u
                     (local.tee $3
                      (i32.add
                       (i32.load offset=332
                        (local.get $0)
                       )
                       (i32.const 7)
                      )
                     )
                     (i32.load offset=328
                      (local.get $0)
                     )
                    )
                   )
                   (br_if $block19
                    (i32.eq
                     (i32.load offset=394008
                      (local.get $2)
                     )
                     (i32.const 65668)
                    )
                   )
                  )
                  (i32.store offset=308
                   (local.get $0)
                   (i32.const 7)
                  )
                  (i32.store offset=292
                   (local.get $0)
                   (i32.const 2)
                  )
                  (i32.store8 offset=296
                   (local.get $0)
                   (i32.const 1)
                  )
                  (i32.store
                   (local.get $9)
                   (i32.const 65668)
                  )
                  (return)
                 )
                 (i32.store offset=40
                  (local.get $0)
                  (i32.const 61456)
                 )
                 (i32.store
                  (local.get $0)
                  (i32.const 2)
                 )
                 (block $block21
                  (block $block20
                   (br_if $block20
                    (i32.eqz
                     (local.tee $3
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.const 60)
                       )
                      )
                     )
                    )
                   )
                   (i32.store
                    (i32.add
                     (local.get $3)
                     (i32.const 16)
                    )
                    (i32.const 2)
                   )
                   (br $block21)
                  )
                  (local.set $4
                   (i32.const 11)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 11)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65716)
                  )
                  (call $fimport$1
                   (local.get $1)
                   (i32.const 61456)
                   (i32.const 2)
                  )
                  (br_if $block22
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (block $block23
                  (br_if $block23
                   (i32.eqz
                    (i32.load8_u
                     (local.get $7)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 11)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 11)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $3
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65718)
                  )
                  (call $fimport$2
                   (local.get $0)
                  )
                  (br_if $block23
                   (i32.eqz
                    (local.tee $6
                     (i32.load8_u offset=296
                      (local.get $0)
                     )
                    )
                   )
                  )
                  (local.set $7
                   (i32.load
                    (local.get $3)
                   )
                  )
                  (br $block6)
                 )
                 (block $block24
                  (br_if $block24
                   (i32.eqz
                    (i32.and
                     (local.tee $3
                      (i32.load offset=60
                       (local.get $0)
                      )
                     )
                     (i32.const 3)
                    )
                   )
                  )
                  (local.set $4
                   (i32.const 12)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 12)
                  )
                  (local.set $5
                   (i32.const 4)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 4)
                  )
                  (i32.store
                   (local.tee $9
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65718)
                  )
                  (call $fimport$0
                   (local.get $0)
                   (local.get $1)
                   (i32.const 65718)
                   (local.get $3)
                   (i32.const 0)
                  )
                  (local.set $7
                   (i32.load
                    (local.get $9)
                   )
                  )
                  (local.set $6
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                  (br $block6)
                 )
                 (block $block26
                  (block $block25
                   (br_if $block25
                    (i32.eqz
                     (local.tee $7
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.get $3)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $7)
                      (i32.and
                       (local.get $3)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block26)
                  )
                  (local.set $4
                   (i32.const 12)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 12)
                  )
                  (local.set $5
                   (i32.const 4)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 4)
                  )
                  (i32.store
                   (local.tee $7
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65718)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $3)
                   )
                  )
                  (br_if $block27
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (block $block29
                  (block $block28
                   (br_if $block28
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $7
                           (i32.add
                            (local.get $3)
                            (i32.const 4)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $7
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $7)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block29)
                  )
                  (local.set $4
                   (i32.const 12)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 12)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 4)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65718)
                  )
                  (local.set $7
                   (call $fimport$3
                    (local.get $1)
                    (local.get $7)
                   )
                  )
                  (br_if $block30
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=168
                  (local.get $0)
                  (local.get $7)
                 )
                 (i32.store offset=60
                  (local.get $0)
                  (local.get $8)
                 )
                 (i32.store
                  (local.get $0)
                  (i32.const 0)
                 )
                 (i32.store offset=56
                  (local.get $0)
                  (local.tee $8
                   (i32.add
                    (local.get $3)
                    (i32.const 8)
                   )
                  )
                 )
                 (block $block32
                  (block $block31
                   (br_if $block31
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.get $8)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block32)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block33
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=52
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block35
                  (block $block34
                   (br_if $block34
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $8
                           (i32.add
                            (local.get $3)
                            (i32.const 12)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block35)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block36
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=48
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block38
                  (block $block37
                   (br_if $block37
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $8
                           (i32.add
                            (local.get $3)
                            (i32.const 16)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block38)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block39
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=44
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block41
                  (block $block40
                   (br_if $block40
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $8
                           (i32.add
                            (local.get $3)
                            (i32.const 20)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block41)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block42
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=28
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block44
                  (block $block43
                   (br_if $block43
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $8
                           (i32.add
                            (local.get $3)
                            (i32.const 24)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block44)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block45
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=24
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block47
                  (block $block46
                   (br_if $block46
                    (i32.eqz
                     (local.tee $10
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (i32.shr_u
                          (local.tee $8
                           (i32.add
                            (local.get $3)
                            (i32.const 28)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                   (local.set $8
                    (i32.load
                     (i32.add
                      (local.get $10)
                      (i32.and
                       (local.get $8)
                       (i32.const 4092)
                      )
                     )
                    )
                   )
                   (br $block47)
                  )
                  (local.set $4
                   (i32.const 14)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 308)
                   )
                   (i32.const 14)
                  )
                  (local.set $5
                   (i32.const 2)
                  )
                  (i32.store
                   (i32.add
                    (local.get $0)
                    (i32.const 292)
                   )
                   (i32.const 2)
                  )
                  (i32.store
                   (local.tee $10
                    (i32.add
                     (local.get $0)
                     (i32.const 188)
                    )
                   )
                   (i32.const 65724)
                  )
                  (local.set $8
                   (call $fimport$3
                    (local.get $1)
                    (local.get $8)
                   )
                  )
                  (br_if $block48
                   (local.tee $6
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (i32.store offset=20
                  (local.get $0)
                  (local.get $8)
                 )
                 (block $block52
                  (block $block51
                   (block $block50
                    (block $block49
                     (br_if $block49
                      (i32.eqz
                       (local.tee $9
                        (i32.load
                         (i32.add
                          (local.get $9)
                          (i32.and
                           (i32.shr_u
                            (local.tee $8
                             (i32.add
                              (local.get $3)
                              (i32.const 32)
                             )
                            )
                            (i32.const 10)
                           )
                           (i32.const 4194300)
                          )
                         )
                        )
                       )
                      )
                     )
                     (local.set $9
                      (i32.load
                       (i32.add
                        (local.get $9)
                        (i32.and
                         (local.get $8)
                         (i32.const 4092)
                        )
                       )
                      )
                     )
                     (br $block50)
                    )
                    (local.set $4
                     (i32.const 14)
                    )
                    (i32.store
                     (i32.add
                      (local.get $0)
                      (i32.const 308)
                     )
                     (i32.const 14)
                    )
                    (local.set $5
                     (i32.const 2)
                    )
                    (i32.store
                     (i32.add
                      (local.get $0)
                      (i32.const 292)
                     )
                     (i32.const 2)
                    )
                    (i32.store
                     (local.tee $10
                      (i32.add
                       (local.get $0)
                       (i32.const 188)
                      )
                     )
                     (i32.const 65724)
                    )
                    (local.set $9
                     (call $fimport$3
                      (local.get $1)
                      (local.get $8)
                     )
                    )
                    (br_if $block51
                     (local.tee $6
                      (i32.load8_u offset=296
                       (local.get $0)
                      )
                     )
                    )
                   )
                   (i32.store offset=16
                    (local.get $0)
                    (local.get $9)
                   )
                   (i32.store offset=56
                    (local.get $0)
                    (i32.add
                     (local.get $3)
                     (i32.const 36)
                    )
                   )
                   (local.set $6
                    (i32.const 1)
                   )
                   (br_if $block52
                    (i32.and
                     (local.get $7)
                     (i32.const 1)
                    )
                   )
                   (local.set $5
                    (i32.const 2)
                   )
                   (local.set $4
                    (i32.const 15)
                   )
                   (br $block6)
                  )
                  (local.set $7
                   (i32.load
                    (local.get $10)
                   )
                  )
                  (br $block6)
                 )
                 (local.set $4
                  (i32.const 15)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 15)
                 )
                 (local.set $5
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $3
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 65726)
                 )
                 (call $fimport$4
                  (local.get $0)
                  (i32.const 42)
                  (local.get $1)
                 )
                 (local.set $7
                  (i32.load
                   (local.get $3)
                  )
                 )
                 (local.set $6
                  (i32.load8_u offset=296
                   (local.get $0)
                  )
                 )
                 (br $block6)
                )
                (i32.store8 offset=341
                 (local.get $0)
                 (i32.const 1)
                )
                (return)
               )
               (i32.store offset=332
                (local.get $0)
                (local.get $3)
               )
               (i32.store
                (i32.add
                 (local.get $0)
                 (i32.const 188)
                )
                (i32.const 65668)
               )
               (return_call_indirect $timport$0 (type $0)
                (local.get $0)
                (local.get $1)
                (i32.load offset=394016
                 (local.get $2)
                )
               )
              )
              (local.set $7
               (i32.load
                (local.get $10)
               )
              )
              (local.set $5
               (i32.const 2)
              )
              (br $block6)
             )
             (local.set $7
              (i32.load
               (local.get $11)
              )
             )
             (br $block6)
            )
            (local.set $7
             (i32.load
              (local.get $3)
             )
            )
            (local.set $5
             (i32.const 2)
            )
            (br $block6)
           )
           (local.set $7
            (i32.load
             (local.get $7)
            )
           )
           (br $block6)
          )
          (local.set $7
           (i32.load
            (local.get $10)
           )
          )
          (local.set $5
           (i32.const 4)
          )
          (br $block6)
         )
         (local.set $7
          (i32.load
           (local.get $10)
          )
         )
         (br $block6)
        )
        (local.set $7
         (i32.load
          (local.get $10)
         )
        )
        (br $block6)
       )
       (local.set $7
        (i32.load
         (local.get $10)
        )
       )
       (br $block6)
      )
      (local.set $7
       (i32.load
        (local.get $10)
       )
      )
      (br $block6)
     )
     (local.set $7
      (i32.load
       (local.get $10)
      )
     )
     (br $block6)
    )
    (local.set $7
     (i32.load
      (local.get $10)
     )
    )
    (br $block6)
   )
   (local.set $7
    (i32.load offset=188
     (local.get $0)
    )
   )
  )
  (block $block54
   (block $block53
    (br_if $block53
     (i32.ge_u
      (local.tee $3
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $4)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block54
     (i32.eq
      (i32.load
       (local.tee $9
        (i32.add
         (local.get $2)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $7)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $7)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $4)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $7)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $6)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $3)
  )
  (i32.store offset=188
   (local.get $0)
   (local.get $7)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $9)
   )
  )
 )
 ;; custom section "linking", size 43
 ;; custom section "reloc.CODE", size 106
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

