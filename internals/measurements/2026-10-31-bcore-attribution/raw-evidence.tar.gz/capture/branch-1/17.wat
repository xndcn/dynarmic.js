(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_write32" (func $fimport$0 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$1 (param i32)))
 (export "bb_0x00010006" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (block $block3
   (block $block6
    (block $block
     (br_if $block
      (i32.gt_u
       (i32.add
        (i32.load offset=160
         (local.get $0)
        )
        (i32.const -65553)
       )
       (i32.const -12)
      )
     )
     (br_if $block
      (i32.gt_u
       (i32.add
        (i32.load offset=164
         (local.get $0)
        )
        (i32.const -65553)
       )
       (i32.const -12)
      )
     )
     (local.set $2
      (i32.load offset=316
       (local.get $0)
      )
     )
     (local.set $3
      (i32.load offset=324
       (local.get $0)
      )
     )
     (i32.store offset=32
      (local.get $0)
      (i32.const 16777220)
     )
     (local.set $4
      (i32.load
       (local.get $0)
      )
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eqz
         (local.tee $5
          (i32.load
           (i32.add
            (i32.load offset=312
             (local.get $0)
            )
            (i32.const 16384)
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $5)
         (i32.const 4)
        )
        (local.get $4)
       )
       (br $block2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65550)
      )
      (call $fimport$0
       (local.get $1)
       (i32.const 16777220)
       (local.get $4)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (block $block4
      (br_if $block4
       (i32.eqz
        (i32.load8_u
         (local.get $2)
        )
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65552)
      )
      (call $fimport$1
       (local.get $0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.tee $4
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
      )
      (i32.const 65552)
     )
     (block $block5
      (br_if $block5
       (i32.ge_u
        (local.tee $2
         (i32.add
          (i32.load offset=332
           (local.get $0)
          )
          (i32.const 4)
         )
        )
        (i32.load offset=328
         (local.get $0)
        )
       )
      )
      (br_if $block6
       (i32.eq
        (i32.load offset=393312
         (local.get $3)
        )
        (i32.const 65552)
       )
      )
     )
     (i32.store offset=308
      (local.get $0)
      (i32.const 4)
     )
     (i32.store offset=292
      (local.get $0)
      (i32.const 2)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store
      (local.get $4)
      (i32.const 65552)
     )
     (return)
    )
    (i32.store8 offset=341
     (local.get $0)
     (i32.const 1)
    )
    (return)
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $2)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
    (i32.const 65552)
   )
   (return_call_indirect $timport$0 (type $0)
    (local.get $0)
    (local.get $1)
    (i32.load offset=393320
     (local.get $3)
    )
   )
  )
  (block $block8
   (block $block7
    (br_if $block7
     (i32.ge_u
      (local.tee $2
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (i32.const 3)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block8
     (i32.eq
      (i32.load
       (local.tee $3
        (i32.add
         (local.get $3)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.tee $4
             (i32.load
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
            )
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $4)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (i32.const 3)
   )
   (i32.store offset=292
    (local.get $0)
    (i32.const 2)
   )
   (return)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $2)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $3)
   )
  )
 )
 ;; custom section "linking", size 34
 ;; custom section "reloc.CODE", size 26
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

