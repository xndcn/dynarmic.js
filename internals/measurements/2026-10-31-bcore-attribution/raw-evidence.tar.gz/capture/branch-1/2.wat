(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32) (result i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32 i32 i32)))
 (type $4 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "mem_read32" (func $fimport$0 (param i32 i32) (result i32)))
 (import "env" "cec_data_alignment" (func $fimport$1 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$2 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$3 (param i32)))
 (export "bb_0x00010040" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (block $block3
   (block $block26
    (block $block
     (br_if $block
      (i32.gt_u
       (i32.add
        (local.tee $2
         (i32.load offset=160
          (local.get $0)
         )
        )
        (i32.const -65679)
       )
       (i32.const -80)
      )
     )
     (br_if $block
      (i32.gt_u
       (i32.add
        (local.tee $3
         (i32.load offset=164
          (local.get $0)
         )
        )
        (i32.const -65679)
       )
       (i32.const -80)
      )
     )
     (local.set $4
      (i32.load offset=312
       (local.get $0)
      )
     )
     (local.set $5
      (i32.load offset=316
       (local.get $0)
      )
     )
     (local.set $6
      (i32.load offset=324
       (local.get $0)
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 61444)
     )
     (block $block2
      (block $block1
       (br_if $block1
        (i32.eqz
         (local.tee $7
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 60)
           )
          )
         )
        )
       )
       (local.set $8
        (i32.load
         (i32.add
          (local.get $7)
          (i32.const 4)
         )
        )
       )
       (br $block2)
      )
      (local.set $9
       (i32.const 3)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 3)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65606)
      )
      (local.set $8
       (call $fimport$0
        (local.get $1)
        (i32.const 61444)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 61448)
     )
     (i32.store offset=16
      (local.get $0)
      (local.get $8)
     )
     (block $block5
      (block $block4
       (br_if $block4
        (i32.eqz
         (local.tee $7
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 60)
           )
          )
         )
        )
       )
       (local.set $11
        (i32.load
         (i32.add
          (local.get $7)
          (i32.const 8)
         )
        )
       )
       (br $block5)
      )
      (local.set $9
       (i32.const 5)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 5)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65610)
      )
      (local.set $11
       (call $fimport$0
        (local.get $1)
        (i32.const 61448)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=44
      (local.get $0)
      (i32.const 61460)
     )
     (i32.store
      (local.get $0)
      (i32.const 1)
     )
     (i32.store offset=40
      (local.get $0)
      (local.get $11)
     )
     (local.set $7
      (i32.add
       (local.tee $12
        (i32.load offset=60
         (local.get $0)
        )
       )
       (i32.const -4)
      )
     )
     (block $block6
      (br_if $block6
       (i32.eqz
        (i32.and
         (local.get $12)
         (i32.const 3)
        )
       )
      )
      (local.set $9
       (i32.const 9)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 9)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65620)
      )
      (call $fimport$1
       (local.get $0)
       (local.get $1)
       (i32.const 65620)
       (local.get $7)
       (i32.const 65536)
      )
      (br $block3)
     )
     (block $block8
      (block $block7
       (br_if $block7
        (i32.eqz
         (local.tee $14
          (i32.load
           (local.tee $13
            (i32.add
             (local.get $4)
             (i32.and
              (i32.shr_u
               (local.get $7)
               (i32.const 10)
              )
              (i32.const 4194300)
             )
            )
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $14)
         (i32.and
          (local.get $7)
          (i32.const 4092)
         )
        )
        (local.get $11)
       )
       (br $block8)
      )
      (local.set $9
       (i32.const 9)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 9)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65620)
      )
      (call $fimport$2
       (local.get $1)
       (local.get $7)
       (local.get $11)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (block $block9
      (br_if $block9
       (i32.eqz
        (i32.load8_u
         (local.get $5)
        )
       )
      )
      (local.set $9
       (i32.const 9)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 9)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65622)
      )
      (call $fimport$3
       (local.get $0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 61452)
     )
     (block $block11
      (block $block10
       (br_if $block10
        (i32.eqz
         (local.tee $11
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 60)
           )
          )
         )
        )
       )
       (local.set $11
        (i32.load
         (i32.add
          (local.get $11)
          (i32.const 12)
         )
        )
       )
       (br $block11)
      )
      (local.set $9
       (i32.const 12)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 12)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65628)
      )
      (local.set $11
       (call $fimport$0
        (local.get $1)
        (i32.const 61452)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=40
      (local.get $0)
      (local.get $11)
     )
     (i32.store offset=52
      (local.get $0)
      (i32.const 61464)
     )
     (i32.store16
      (i32.add
       (local.get $0)
       (i32.const 50)
      )
      (i32.const 256)
     )
     (block $block13
      (block $block12
       (br_if $block12
        (i32.eqz
         (local.tee $9
          (i32.load
           (local.tee $14
            (i32.add
             (local.get $4)
             (i32.and
              (i32.shr_u
               (local.tee $12
                (i32.add
                 (local.get $12)
                 (i32.const -8)
                )
               )
               (i32.const 10)
              )
              (i32.const 4194300)
             )
            )
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $9)
         (i32.and
          (local.get $12)
          (i32.const 4092)
         )
        )
        (local.get $11)
       )
       (br $block13)
      )
      (local.set $9
       (i32.const 16)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 16)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65642)
      )
      (call $fimport$2
       (local.get $1)
       (local.get $12)
       (local.get $11)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (block $block14
      (br_if $block14
       (i32.eqz
        (i32.load8_u
         (local.get $5)
        )
       )
      )
      (local.set $9
       (i32.const 16)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 16)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65644)
      )
      (call $fimport$3
       (local.get $0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=40
      (local.get $0)
      (i32.const 61456)
     )
     (block $block16
      (block $block15
       (br_if $block15
        (i32.eqz
         (local.tee $11
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 60)
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $11)
         (i32.const 16)
        )
        (i32.const 1)
       )
       (br $block16)
      )
      (local.set $9
       (i32.const 19)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 19)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65652)
      )
      (call $fimport$2
       (local.get $1)
       (i32.const 61456)
       (i32.const 1)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (block $block17
      (br_if $block17
       (i32.eqz
        (i32.load8_u
         (local.get $5)
        )
       )
      )
      (local.set $9
       (i32.const 19)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 19)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65654)
      )
      (call $fimport$3
       (local.get $0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store
      (local.get $0)
      (i32.const 0)
     )
     (block $block19
      (block $block18
       (br_if $block18
        (i32.eqz
         (local.tee $4
          (i32.load
           (i32.add
            (local.get $4)
            (i32.const 60)
           )
          )
         )
        )
       )
       (i32.store
        (i32.add
         (local.get $4)
         (i32.const 20)
        )
        (i32.const 0)
       )
       (br $block19)
      )
      (local.set $9
       (i32.const 21)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 21)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65656)
      )
      (call $fimport$2
       (local.get $1)
       (i32.const 61460)
       (i32.const 0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (block $block20
      (br_if $block20
       (i32.eqz
        (i32.load8_u
         (local.get $5)
        )
       )
      )
      (local.set $9
       (i32.const 21)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 21)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65658)
      )
      (call $fimport$3
       (local.get $0)
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=48
      (local.get $0)
      (i32.const 16777216)
     )
     (i32.store offset=28
      (local.get $0)
      (i32.const 0)
     )
     (i64.store offset=20 align=4
      (local.get $0)
      (i64.const 1)
     )
     (block $block22
      (block $block21
       (br_if $block21
        (i32.eqz
         (local.tee $4
          (i32.load
           (local.get $13)
          )
         )
        )
       )
       (local.set $4
        (i32.load
         (i32.add
          (local.get $4)
          (i32.and
           (local.get $7)
           (i32.const 4092)
          )
         )
        )
       )
       (br $block22)
      )
      (local.set $9
       (i32.const 26)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 26)
      )
      (local.set $10
       (i32.const 8)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 8)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65668)
      )
      (local.set $4
       (call $fimport$0
        (local.get $1)
        (local.get $7)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $4)
     )
     (i32.store
      (local.get $0)
      (local.get $8)
     )
     (block $block24
      (block $block23
       (br_if $block23
        (i32.eqz
         (local.tee $4
          (i32.load
           (local.get $14)
          )
         )
        )
       )
       (local.set $4
        (i32.load
         (i32.add
          (local.get $4)
          (i32.and
           (local.get $12)
           (i32.const 4092)
          )
         )
        )
       )
       (br $block24)
      )
      (local.set $9
       (i32.const 27)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 308)
       )
       (i32.const 27)
      )
      (local.set $10
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 292)
       )
       (i32.const 2)
      )
      (i32.store
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
       (i32.const 65676)
      )
      (local.set $4
       (call $fimport$0
        (local.get $1)
        (local.get $12)
       )
      )
      (br_if $block3
       (i32.load8_u offset=296
        (local.get $0)
       )
      )
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $4)
     )
     (i32.store
      (local.tee $5
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
      )
      (i32.const 66344)
     )
     (i32.store offset=168
      (local.get $0)
      (select
       (select
        (i32.load offset=148
         (local.get $0)
        )
        (local.tee $4
         (select
          (select
           (i32.load offset=144
            (local.get $0)
           )
           (i32.const 65682)
           (i32.gt_u
            (i32.load offset=152
             (local.get $0)
            )
            (i32.const 1)
           )
          )
          (i32.const 65682)
          (i32.eq
           (local.get $2)
           (i32.const 65678)
          )
         )
        )
        (i32.gt_u
         (i32.load offset=156
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (local.get $4)
       (i32.eq
        (local.get $3)
        (i32.const 65678)
       )
      )
     )
     (block $block25
      (br_if $block25
       (i32.ge_u
        (local.tee $4
         (i32.add
          (i32.load offset=332
           (local.get $0)
          )
          (i32.const 28)
         )
        )
        (i32.load offset=328
         (local.get $0)
        )
       )
      )
      (br_if $block26
       (i32.eq
        (i32.load offset=398064
         (local.get $6)
        )
        (i32.const 66344)
       )
      )
     )
     (i32.store offset=308
      (local.get $0)
      (i32.const 28)
     )
     (i32.store offset=292
      (local.get $0)
      (i32.const 4)
     )
     (i32.store8 offset=296
      (local.get $0)
      (i32.const 1)
     )
     (i32.store
      (local.get $5)
      (i32.const 66344)
     )
     (return)
    )
    (i32.store8 offset=341
     (local.get $0)
     (i32.const 1)
    )
    (return)
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $4)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
    (i32.const 66344)
   )
   (return_call_indirect $timport$0 (type $0)
    (local.get $0)
    (local.get $1)
    (i32.load offset=398072
     (local.get $6)
    )
   )
  )
  (block $block28
   (block $block27
    (br_if $block27
     (i32.ge_u
      (local.tee $4
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $9)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block28
     (i32.eq
      (i32.load
       (local.tee $7
        (i32.add
         (local.get $6)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.tee $5
             (i32.load
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
            )
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $5)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $9)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $10)
   )
   (return)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $4)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $7)
   )
  )
 )
 ;; custom section "linking", size 40
 ;; custom section "reloc.CODE", size 74
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

