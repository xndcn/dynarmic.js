(module
 (type $0 (func (param i32 i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (export "bb_0x00010170" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block2
   (block $block
    (br_if $block
     (i32.gt_u
      (i32.add
       (local.tee $2
        (i32.load offset=160
         (local.get $0)
        )
       )
       (i32.const -65907)
      )
      (i32.const -4)
     )
    )
    (br_if $block
     (i32.gt_u
      (i32.add
       (local.tee $3
        (i32.load offset=164
         (local.get $0)
        )
       )
       (i32.const -65907)
      )
      (i32.const -4)
     )
    )
    (local.set $4
     (i32.load offset=324
      (local.get $0)
     )
    )
    (i32.store
     (local.tee $5
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
     )
     (i32.const 65840)
    )
    (i32.store
     (local.get $0)
     (local.tee $8
      (i32.add
       (local.tee $6
        (i32.load
         (local.get $0)
        )
       )
       (local.tee $7
        (i32.load offset=28
         (local.get $0)
        )
       )
      )
     )
    )
    (i32.store offset=232
     (local.get $0)
     (i32.shr_u
      (local.get $8)
      (i32.const 31)
     )
    )
    (i32.store offset=228
     (local.get $0)
     (i32.eqz
      (local.get $8)
     )
    )
    (i32.store offset=240
     (local.get $0)
     (local.tee $9
      (i32.gt_u
       (local.get $6)
       (i32.xor
        (local.get $7)
        (i32.const -1)
       )
      )
     )
    )
    (i32.store offset=236
     (local.get $0)
     (local.get $9)
    )
    (i32.store offset=252
     (local.get $0)
     (local.tee $8
      (i32.shr_u
       (i32.and
        (i32.xor
         (local.get $8)
         (local.get $7)
        )
        (i32.xor
         (local.get $8)
         (local.get $6)
        )
       )
       (i32.const 31)
      )
     )
    )
    (i32.store offset=248
     (local.get $0)
     (local.get $8)
    )
    (i32.store offset=256
     (local.get $0)
     (i32.or
      (i32.load offset=256
       (local.get $0)
      )
      (local.get $8)
     )
    )
    (i32.store offset=168
     (local.get $0)
     (select
      (select
       (i32.load offset=148
        (local.get $0)
       )
       (local.tee $8
        (select
         (select
          (i32.load offset=144
           (local.get $0)
          )
          (i32.const 65910)
          (i32.gt_u
           (i32.load offset=152
            (local.get $0)
           )
           (i32.const 1)
          )
         )
         (i32.const 65910)
         (i32.eq
          (local.get $2)
          (i32.const 65906)
         )
        )
       )
       (i32.gt_u
        (i32.load offset=156
         (local.get $0)
        )
        (i32.const 1)
       )
      )
      (local.get $8)
      (i32.eq
       (local.get $3)
       (i32.const 65906)
      )
     )
    )
    (block $block1
     (br_if $block1
      (i32.ge_u
       (local.tee $8
        (i32.add
         (i32.load offset=332
          (local.get $0)
         )
         (i32.const 2)
        )
       )
       (i32.load offset=328
        (local.get $0)
       )
      )
     )
     (br_if $block2
      (i32.eq
       (i32.load offset=395040
        (local.get $4)
       )
       (i32.const 65840)
      )
     )
    )
    (i32.store offset=308
     (local.get $0)
     (i32.const 2)
    )
    (i32.store offset=292
     (local.get $0)
     (i32.const 4)
    )
    (i32.store8 offset=296
     (local.get $0)
     (i32.const 1)
    )
    (i32.store
     (local.get $5)
     (i32.const 65840)
    )
    (return)
   )
   (i32.store8 offset=341
    (local.get $0)
    (i32.const 1)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $8)
  )
  (i32.store
   (i32.add
    (local.get $0)
    (i32.const 188)
   )
   (i32.const 65840)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=395048
    (local.get $4)
   )
  )
 )
 ;; custom section "linking", size 28
 ;; custom section "reloc.CODE", size 10
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

