(module
 (type $0 (func (param i32 i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (export "bb_0x00010176" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block4
   (block $block6
    (block $block3
     (block $block
      (br_if $block
       (i32.gt_u
        (i32.add
         (local.tee $2
          (i32.load offset=160
           (local.get $0)
          )
         )
         (i32.const -65929)
        )
        (i32.const -20)
       )
      )
      (br_if $block
       (i32.gt_u
        (i32.add
         (local.tee $3
          (i32.load offset=164
           (local.get $0)
          )
         )
         (i32.const -65929)
        )
        (i32.const -20)
       )
      )
      (local.set $4
       (i32.load offset=324
        (local.get $0)
       )
      )
      (i32.store offset=24
       (local.get $0)
       (local.tee $6
        (i32.add
         (local.tee $5
          (i32.load offset=24
           (local.get $0)
          )
         )
         (i32.const 1)
        )
       )
      )
      (i32.store offset=276
       (local.get $0)
       (i32.le_u
        (local.tee $7
         (i32.load offset=20
          (local.get $0)
         )
        )
        (local.get $6)
       )
      )
      (i32.store offset=240
       (local.get $0)
       (local.tee $8
        (i32.le_u
         (local.get $6)
         (local.get $7)
        )
       )
      )
      (i32.store offset=236
       (local.get $0)
       (local.get $8)
      )
      (i32.store offset=232
       (local.get $0)
       (i32.gt_u
        (local.get $6)
        (local.get $7)
       )
      )
      (i32.store offset=228
       (local.get $0)
       (i32.eq
        (local.get $7)
        (local.get $6)
       )
      )
      (i32.store offset=252
       (local.get $0)
       (local.tee $5
        (i32.shr_u
         (i32.and
          (local.get $6)
          (i32.xor
           (local.get $5)
           (i32.const -1)
          )
         )
         (i32.const 31)
        )
       )
      )
      (i32.store offset=248
       (local.get $0)
       (local.get $5)
      )
      (i32.store offset=256
       (local.get $0)
       (local.tee $5
        (i32.or
         (i32.load offset=256
          (local.get $0)
         )
         (local.get $5)
        )
       )
      )
      (block $block1
       (br_if $block1
        (i32.gt_u
         (local.get $7)
         (local.get $6)
        )
       )
       (i32.store
        (local.tee $7
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
        )
        (i32.const 65938)
       )
       (block $block2
        (br_if $block2
         (i32.ge_u
          (local.tee $6
           (i32.add
            (i32.load offset=332
             (local.get $0)
            )
            (i32.const 3)
           )
          )
          (i32.load offset=328
           (local.get $0)
          )
         )
        )
        (br_if $block3
         (i32.eq
          (i32.load offset=395628
           (local.get $4)
          )
          (i32.const 65938)
         )
        )
       )
       (i32.store offset=308
        (local.get $0)
        (i32.const 3)
       )
       (i32.store offset=292
        (local.get $0)
        (i32.const 2)
       )
       (i32.store8 offset=296
        (local.get $0)
        (i32.const 1)
       )
       (i32.store
        (local.get $7)
        (i32.const 65938)
       )
       (return)
      )
      (i64.store offset=236 align=4
       (local.get $0)
       (i64.const 4294967297)
      )
      (i32.store offset=4
       (local.get $0)
       (local.tee $7
        (i32.load offset=52
         (local.get $0)
        )
       )
      )
      (i32.store offset=28
       (local.get $0)
       (local.tee $6
        (i32.add
         (local.get $7)
         (local.tee $8
          (i32.mul
           (i32.load offset=16
            (local.get $0)
           )
           (i32.load offset=28
            (local.get $0)
           )
          )
         )
        )
       )
      )
      (i32.store offset=276
       (local.get $0)
       (local.tee $9
        (i32.shr_u
         (local.get $6)
         (i32.const 31)
        )
       )
      )
      (i32.store offset=232
       (local.get $0)
       (local.get $9)
      )
      (i32.store offset=228
       (local.get $0)
       (i32.eqz
        (local.get $6)
       )
      )
      (i32.store offset=252
       (local.get $0)
       (local.tee $7
        (i32.shr_u
         (i32.and
          (i32.xor
           (local.get $6)
           (local.get $8)
          )
          (i32.xor
           (local.get $6)
           (local.get $7)
          )
         )
         (i32.const 31)
        )
       )
      )
      (i32.store offset=248
       (local.get $0)
       (local.get $7)
      )
      (i32.store offset=256
       (local.get $0)
       (i32.or
        (local.get $7)
        (local.get $5)
       )
      )
      (br_if $block4
       (i32.lt_s
        (local.get $6)
        (i32.const 0)
       )
      )
      (i32.store
       (local.tee $7
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
       )
       (i32.const 65904)
      )
      (block $block5
       (br_if $block5
        (i32.ge_u
         (local.tee $6
          (i32.add
           (i32.load offset=332
            (local.get $0)
           )
           (i32.const 8)
          )
         )
         (i32.load offset=328
          (local.get $0)
         )
        )
       )
       (br_if $block6
        (i32.eq
         (i32.load offset=395424
          (local.get $4)
         )
         (i32.const 65904)
        )
       )
      )
      (i32.store offset=308
       (local.get $0)
       (i32.const 8)
      )
      (i32.store offset=292
       (local.get $0)
       (i32.const 2)
      )
      (i32.store8 offset=296
       (local.get $0)
       (i32.const 1)
      )
      (i32.store
       (local.get $7)
       (i32.const 65904)
      )
      (return)
     )
     (i32.store8 offset=341
      (local.get $0)
      (i32.const 1)
     )
     (return)
    )
    (i32.store offset=332
     (local.get $0)
     (local.get $6)
    )
    (i32.store
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
     (i32.const 65938)
    )
    (return_call_indirect $timport$0 (type $0)
     (local.get $0)
     (local.get $1)
     (i32.load offset=395636
      (local.get $4)
     )
    )
   )
   (i32.store offset=332
    (local.get $0)
    (local.get $6)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
    (i32.const 65904)
   )
   (return_call_indirect $timport$0 (type $0)
    (local.get $0)
    (local.get $1)
    (i32.load offset=395432
     (local.get $4)
    )
   )
  )
  (i64.store offset=248 align=4
   (local.get $0)
   (i64.const 0)
  )
  (i64.store offset=236 align=4
   (local.get $0)
   (i64.const 0)
  )
  (i32.store
   (local.tee $5
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
   )
   (i32.const 65808)
  )
  (i32.store offset=228
   (local.get $0)
   (i32.eq
    (local.tee $7
     (i32.load
      (local.get $0)
     )
    )
    (local.get $6)
   )
  )
  (i32.store
   (local.get $0)
   (local.tee $6
    (i32.xor
     (local.get $7)
     (local.get $6)
    )
   )
  )
  (i32.store offset=232
   (local.get $0)
   (i32.shr_u
    (local.get $6)
    (i32.const 31)
   )
  )
  (i32.store offset=168
   (local.get $0)
   (select
    (select
     (i32.load offset=148
      (local.get $0)
     )
     (local.tee $6
      (select
       (select
        (i32.load offset=144
         (local.get $0)
        )
        (i32.const 65932)
        (i32.gt_u
         (i32.load offset=152
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (i32.const 65932)
       (i32.eq
        (local.get $2)
        (i32.const 65928)
       )
      )
     )
     (i32.gt_u
      (i32.load offset=156
       (local.get $0)
      )
      (i32.const 1)
     )
    )
    (local.get $6)
    (i32.eq
     (local.get $3)
     (i32.const 65928)
    )
   )
  )
  (block $block8
   (block $block7
    (br_if $block7
     (i32.ge_u
      (local.tee $6
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (i32.const 10)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block8
     (i32.eq
      (i32.load offset=394848
       (local.get $4)
      )
      (i32.const 65808)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (i32.const 10)
   )
   (i32.store offset=292
    (local.get $0)
    (i32.const 4)
   )
   (i32.store8 offset=296
    (local.get $0)
    (i32.const 1)
   )
   (i32.store
    (local.get $5)
    (i32.const 65808)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $6)
  )
  (i32.store
   (i32.add
    (local.get $0)
    (i32.const 188)
   )
   (i32.const 65808)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=394856
    (local.get $4)
   )
  )
 )
 ;; custom section "linking", size 28
 ;; custom section "reloc.CODE", size 26
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

