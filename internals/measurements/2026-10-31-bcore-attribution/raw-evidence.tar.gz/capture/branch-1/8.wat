(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32 i32 i32)))
 (type $2 (func (param i32 i32 i32)))
 (type $3 (func (param i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (export "bb_0x0001014c" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (block $block2
   (block $block17
    (block $block14
     (block $block11
      (block $block8
       (block $block5
        (block $block24
         (block $block26
          (block $block
           (br_if $block
            (i32.gt_u
             (i32.add
              (i32.load offset=160
               (local.get $0)
              )
              (i32.const -65903)
             )
             (i32.const -36)
            )
           )
           (br_if $block
            (i32.gt_u
             (i32.add
              (i32.load offset=164
               (local.get $0)
              )
              (i32.const -65903)
             )
             (i32.const -36)
            )
           )
           (local.set $2
            (i32.load offset=324
             (local.get $0)
            )
           )
           (local.set $4
            (i32.add
             (local.tee $3
              (i32.load offset=56
               (local.get $0)
              )
             )
             (i32.const -4)
            )
           )
           (block $block1
            (br_if $block1
             (i32.eqz
              (i32.and
               (local.get $3)
               (i32.const 3)
              )
             )
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$0
             (local.get $0)
             (local.get $1)
             (i32.const 65868)
             (local.get $4)
             (i32.const 65536)
            )
            (local.set $7
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (br $block2)
           )
           (local.set $8
            (i32.load offset=316
             (local.get $0)
            )
           )
           (local.set $9
            (i32.load offset=16
             (local.get $0)
            )
           )
           (block $block4
            (block $block3
             (br_if $block3
              (i32.eqz
               (local.tee $11
                (i32.load
                 (i32.add
                  (local.tee $10
                   (i32.load offset=312
                    (local.get $0)
                   )
                  )
                  (i32.and
                   (i32.shr_u
                    (local.get $4)
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $11)
               (i32.and
                (local.get $4)
                (i32.const 4092)
               )
              )
              (local.get $9)
             )
             (br $block4)
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $4)
             (local.get $9)
            )
            (br_if $block5
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (local.set $4
            (i32.load offset=20
             (local.get $0)
            )
           )
           (block $block7
            (block $block6
             (br_if $block6
              (i32.eqz
               (local.tee $11
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $9
                     (i32.add
                      (local.get $3)
                      (i32.const -8)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $11)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
              (local.get $4)
             )
             (br $block7)
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $9)
             (local.get $4)
            )
            (br_if $block8
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (local.set $4
            (i32.load offset=24
             (local.get $0)
            )
           )
           (block $block10
            (block $block9
             (br_if $block9
              (i32.eqz
               (local.tee $11
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $9
                     (i32.add
                      (local.get $3)
                      (i32.const -12)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $11)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
              (local.get $4)
             )
             (br $block10)
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $9)
             (local.get $4)
            )
            (br_if $block11
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (local.set $4
            (i32.load offset=28
             (local.get $0)
            )
           )
           (block $block13
            (block $block12
             (br_if $block12
              (i32.eqz
               (local.tee $11
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $9
                     (i32.add
                      (local.get $3)
                      (i32.const -16)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $11)
               (i32.and
                (local.get $9)
                (i32.const 4092)
               )
              )
              (local.get $4)
             )
             (br $block13)
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $9)
             (local.get $4)
            )
            (br_if $block14
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (local.set $9
            (i32.load offset=52
             (local.get $0)
            )
           )
           (block $block16
            (block $block15
             (br_if $block15
              (i32.eqz
               (local.tee $11
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $3)
                      (i32.const -20)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $11)
               (i32.and
                (local.get $4)
                (i32.const 4092)
               )
              )
              (local.get $9)
             )
             (br $block16)
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $4)
             (local.get $9)
            )
            (br_if $block17
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=56
            (local.get $0)
            (local.get $4)
           )
           (block $block18
            (br_if $block18
             (i32.eqz
              (i32.load8_u
               (local.get $8)
              )
             )
            )
            (local.set $5
             (i32.const 1)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 1)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (i32.store
             (local.tee $7
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 65870)
            )
            (call $fimport$2
             (local.get $0)
            )
            (br_if $block2
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (local.set $9
            (i32.load offset=60
             (local.get $0)
            )
           )
           (local.set $4
            (i32.load offset=168
             (local.get $0)
            )
           )
           (block $block20
            (block $block19
             (br_if $block19
              (i32.eqz
               (local.tee $5
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $11
                     (i32.add
                      (local.get $3)
                      (i32.const -24)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $5)
               (i32.and
                (local.get $11)
                (i32.const 4092)
               )
              )
              (local.get $4)
             )
             (br $block20)
            )
            (local.set $5
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 2)
            )
            (local.set $6
             (i32.const 4)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 4)
            )
            (i32.store
             (local.tee $7
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 65870)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $11)
             (local.get $4)
            )
            (br_if $block2
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (block $block22
            (block $block21
             (br_if $block21
              (i32.eqz
               (local.tee $10
                (i32.load
                 (i32.add
                  (local.get $10)
                  (i32.and
                   (i32.shr_u
                    (local.tee $4
                     (i32.add
                      (local.get $3)
                      (i32.const -28)
                     )
                    )
                    (i32.const 10)
                   )
                   (i32.const 4194300)
                  )
                 )
                )
               )
              )
             )
             (i32.store
              (i32.add
               (local.get $10)
               (i32.and
                (local.get $4)
                (i32.const 4092)
               )
              )
              (local.get $9)
             )
             (br $block22)
            )
            (local.set $5
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 2)
            )
            (local.set $6
             (i32.const 4)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 4)
            )
            (i32.store
             (local.tee $7
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 65870)
            )
            (call $fimport$1
             (local.get $1)
             (local.get $4)
             (local.get $9)
            )
            (br_if $block2
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i32.store offset=60
            (local.get $0)
            (local.get $4)
           )
           (i32.store offset=56
            (local.get $0)
            (i32.add
             (local.get $3)
             (i32.const -40)
            )
           )
           (block $block23
            (br_if $block23
             (i32.eqz
              (i32.load8_u
               (local.get $8)
              )
             )
            )
            (local.set $5
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 2)
            )
            (local.set $6
             (i32.const 4)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 4)
            )
            (i32.store
             (local.tee $7
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 65874)
            )
            (call $fimport$2
             (local.get $0)
            )
            (br_if $block2
             (i32.load8_u offset=296
              (local.get $0)
             )
            )
           )
           (i64.store offset=236 align=4
            (local.get $0)
            (i64.const 4294967297)
           )
           (i32.store offset=20
            (local.get $0)
            (local.tee $3
             (i32.load
              (local.get $0)
             )
            )
           )
           (i32.store offset=276
            (local.get $0)
            (local.tee $10
             (i32.eqz
              (local.get $3)
             )
            )
           )
           (i32.store offset=232
            (local.get $0)
            (i32.shr_u
             (local.get $3)
             (i32.const 31)
            )
           )
           (i32.store offset=228
            (local.get $0)
            (local.get $10)
           )
           (br_if $block24
            (local.get $3)
           )
           (i32.store
            (local.tee $10
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
            )
            (i32.const 65948)
           )
           (block $block25
            (br_if $block25
             (i32.ge_u
              (local.tee $3
               (i32.add
                (i32.load offset=332
                 (local.get $0)
                )
                (i32.const 5)
               )
              )
              (i32.load offset=328
               (local.get $0)
              )
             )
            )
            (br_if $block26
             (i32.eq
              (i32.load offset=395688
               (local.get $2)
              )
              (i32.const 65948)
             )
            )
           )
           (i32.store offset=308
            (local.get $0)
            (i32.const 5)
           )
           (i32.store offset=292
            (local.get $0)
            (i32.const 2)
           )
           (i32.store8 offset=296
            (local.get $0)
            (i32.const 1)
           )
           (i32.store
            (local.get $10)
            (i32.const 65948)
           )
           (return)
          )
          (i32.store8 offset=341
           (local.get $0)
           (i32.const 1)
          )
          (return)
         )
         (i32.store offset=332
          (local.get $0)
          (local.get $3)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
          (i32.const 65948)
         )
         (return_call_indirect $timport$0 (type $0)
          (local.get $0)
          (local.get $1)
          (i32.load offset=395696
           (local.get $2)
          )
         )
        )
        (i32.store offset=24
         (local.get $0)
         (i32.const 0)
        )
        (i32.store offset=52
         (local.get $0)
         (i32.const 1013904223)
        )
        (i32.store offset=16
         (local.get $0)
         (i32.const 1664525)
        )
        (i32.store offset=28
         (local.get $0)
         (local.tee $3
          (i32.load offset=4
           (local.get $0)
          )
         )
        )
        (i32.store
         (local.get $0)
         (local.get $3)
        )
        (i32.store
         (local.tee $10
          (i32.add
           (local.get $0)
           (i32.const 188)
          )
         )
         (i32.const 65916)
        )
        (block $block28
         (block $block27
          (br_if $block27
           (i32.ge_u
            (local.tee $3
             (i32.add
              (i32.load offset=332
               (local.get $0)
              )
              (i32.const 13)
             )
            )
            (i32.load offset=328
             (local.get $0)
            )
           )
          )
          (br_if $block28
           (i32.eq
            (i32.load offset=395496
             (local.get $2)
            )
            (i32.const 65916)
           )
          )
         )
         (i32.store offset=308
          (local.get $0)
          (i32.const 13)
         )
         (i32.store offset=292
          (local.get $0)
          (i32.const 2)
         )
         (i32.store8 offset=296
          (local.get $0)
          (i32.const 1)
         )
         (i32.store
          (local.get $10)
          (i32.const 65916)
         )
         (return)
        )
        (i32.store offset=332
         (local.get $0)
         (local.get $3)
        )
        (i32.store
         (i32.add
          (local.get $0)
          (i32.const 188)
         )
         (i32.const 65916)
        )
        (return_call_indirect $timport$0 (type $0)
         (local.get $0)
         (local.get $1)
         (i32.load offset=395504
          (local.get $2)
         )
        )
       )
       (local.set $7
        (i32.add
         (local.get $0)
         (i32.const 188)
        )
       )
       (br $block2)
      )
      (local.set $7
       (i32.add
        (local.get $0)
        (i32.const 188)
       )
      )
      (br $block2)
     )
     (local.set $7
      (i32.add
       (local.get $0)
       (i32.const 188)
      )
     )
     (br $block2)
    )
    (local.set $7
     (i32.add
      (local.get $0)
      (i32.const 188)
     )
    )
    (br $block2)
   )
   (local.set $7
    (i32.add
     (local.get $0)
     (i32.const 188)
    )
   )
  )
  (block $block30
   (block $block29
    (br_if $block29
     (i32.ge_u
      (local.tee $3
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $5)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block30
     (i32.eq
      (i32.load
       (local.tee $4
        (i32.add
         (local.get $2)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.tee $10
             (i32.load
              (local.get $7)
             )
            )
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $10)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $6)
   )
   (return)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $3)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $4)
   )
  )
 )
 ;; custom section "linking", size 37
 ;; custom section "reloc.CODE", size 66
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

