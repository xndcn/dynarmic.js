(module
 (type $0 (func (param i32 i32)))
 (type $1 (func (param i32 i32 i32)))
 (type $2 (func (param i32 i32 i32 i32 i32)))
 (type $3 (func (param i32)))
 (type $4 (func (param i32 i32) (result i32)))
 (import "env" "__linear_memory" (memory $mimport$0 0))
 (import "env" "__indirect_function_table" (table $timport$0 0 funcref))
 (import "env" "cec_data_alignment" (func $fimport$0 (param i32 i32 i32 i32 i32)))
 (import "env" "mem_write32" (func $fimport$1 (param i32 i32 i32)))
 (import "env" "cec_check_pending" (func $fimport$2 (param i32)))
 (import "env" "mem_read32" (func $fimport$3 (param i32 i32) (result i32)))
 (import "env" "cec_exception" (func $fimport$4 (param i32 i32 i32)))
 (export "bb_0x00010328" (func $0))
 (func $0 (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i32)
  (local $23 i32)
  (local $24 i32)
  (local $25 i32)
  (block $block14
   (block $block2
    (block $block50
     (block $block41
      (block $block37
       (block $block33
        (block $block20
         (block $block17
          (block $block48
           (block $block45
            (block $block30
             (block $block27
              (block $block24
               (block $block
                (br_if $block
                 (i32.gt_u
                  (i32.add
                   (i32.load offset=160
                    (local.get $0)
                   )
                   (i32.const -66415)
                  )
                  (i32.const -72)
                 )
                )
                (br_if $block
                 (i32.gt_u
                  (i32.add
                   (i32.load offset=164
                    (local.get $0)
                   )
                   (i32.const -66415)
                  )
                  (i32.const -72)
                 )
                )
                (local.set $2
                 (i32.load offset=324
                  (local.get $0)
                 )
                )
                (local.set $4
                 (i32.add
                  (local.tee $3
                   (i32.load offset=56
                    (local.get $0)
                   )
                  )
                  (i32.const -4)
                 )
                )
                (block $block1
                 (br_if $block1
                  (i32.eqz
                   (i32.and
                    (local.get $3)
                    (i32.const 3)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$0
                  (local.get $0)
                  (local.get $1)
                  (i32.const 66344)
                  (local.get $4)
                  (i32.const 65536)
                 )
                 (local.set $7
                  (i32.load8_u offset=296
                   (local.get $0)
                  )
                 )
                 (br $block2)
                )
                (local.set $8
                 (i32.load offset=316
                  (local.get $0)
                 )
                )
                (local.set $9
                 (i32.load offset=24
                  (local.get $0)
                 )
                )
                (block $block4
                 (block $block3
                  (br_if $block3
                   (i32.eqz
                    (local.tee $12
                     (i32.load
                      (local.tee $11
                       (i32.add
                        (local.tee $10
                         (i32.load offset=312
                          (local.get $0)
                         )
                        )
                        (i32.and
                         (i32.shr_u
                          (local.get $4)
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $12)
                    (i32.and
                     (local.get $4)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block4)
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $4)
                  (local.get $9)
                 )
                 (br_if $block2
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (local.set $9
                 (i32.load offset=28
                  (local.get $0)
                 )
                )
                (block $block6
                 (block $block5
                  (br_if $block5
                   (i32.eqz
                    (local.tee $12
                     (i32.load
                      (local.tee $14
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $13
                           (i32.add
                            (local.get $3)
                            (i32.const -8)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $12)
                    (i32.and
                     (local.get $13)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block6)
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $13)
                  (local.get $9)
                 )
                 (br_if $block2
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (local.set $9
                 (i32.load offset=44
                  (local.get $0)
                 )
                )
                (block $block8
                 (block $block7
                  (br_if $block7
                   (i32.eqz
                    (local.tee $12
                     (i32.load
                      (local.tee $16
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $15
                           (i32.add
                            (local.get $3)
                            (i32.const -12)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $12)
                    (i32.and
                     (local.get $15)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block8)
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $15)
                  (local.get $9)
                 )
                 (br_if $block2
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (local.set $9
                 (i32.load offset=48
                  (local.get $0)
                 )
                )
                (block $block10
                 (block $block9
                  (br_if $block9
                   (i32.eqz
                    (local.tee $12
                     (i32.load
                      (local.tee $18
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $17
                           (i32.add
                            (local.get $3)
                            (i32.const -16)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $12)
                    (i32.and
                     (local.get $17)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block10)
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $17)
                  (local.get $9)
                 )
                 (br_if $block2
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (local.set $9
                 (i32.load offset=52
                  (local.get $0)
                 )
                )
                (block $block12
                 (block $block11
                  (br_if $block11
                   (i32.eqz
                    (local.tee $12
                     (i32.load
                      (local.tee $20
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $19
                           (i32.add
                            (local.get $3)
                            (i32.const -20)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $12)
                    (i32.and
                     (local.get $19)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block12)
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $19)
                  (local.get $9)
                 )
                 (br_if $block2
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (i32.store offset=56
                 (local.get $0)
                 (local.get $19)
                )
                (block $block13
                 (br_if $block13
                  (i32.eqz
                   (i32.load8_u
                    (local.get $8)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 1)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 1)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $9
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66346)
                 )
                 (call $fimport$2
                  (local.get $0)
                 )
                 (br_if $block13
                  (i32.eqz
                   (local.tee $7
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.set $10
                  (i32.load
                   (local.get $9)
                  )
                 )
                 (br $block14)
                )
                (local.set $9
                 (i32.load offset=60
                  (local.get $0)
                 )
                )
                (local.set $12
                 (i32.load offset=168
                  (local.get $0)
                 )
                )
                (block $block16
                 (block $block15
                  (br_if $block15
                   (i32.eqz
                    (local.tee $23
                     (i32.load
                      (local.tee $22
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $21
                           (i32.add
                            (local.get $3)
                            (i32.const -24)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $23)
                    (i32.and
                     (local.get $21)
                     (i32.const 4092)
                    )
                   )
                   (local.get $12)
                  )
                  (br $block16)
                 )
                 (local.set $5
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 2)
                 )
                 (local.set $6
                  (i32.const 4)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 4)
                 )
                 (i32.store
                  (local.tee $23
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66346)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $21)
                  (local.get $12)
                 )
                 (br_if $block17
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (block $block19
                 (block $block18
                  (br_if $block18
                   (i32.eqz
                    (local.tee $23
                     (i32.load
                      (local.tee $24
                       (i32.add
                        (local.get $10)
                        (i32.and
                         (i32.shr_u
                          (local.tee $12
                           (i32.add
                            (local.get $3)
                            (i32.const -28)
                           )
                          )
                          (i32.const 10)
                         )
                         (i32.const 4194300)
                        )
                       )
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $23)
                    (i32.and
                     (local.get $12)
                     (i32.const 4092)
                    )
                   )
                   (local.get $9)
                  )
                  (br $block19)
                 )
                 (local.set $5
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 2)
                 )
                 (local.set $6
                  (i32.const 4)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 4)
                 )
                 (i32.store
                  (local.tee $23
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66346)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (local.get $12)
                  (local.get $9)
                 )
                 (br_if $block20
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (i32.store offset=56
                 (local.get $0)
                 (local.get $12)
                )
                (i32.store offset=60
                 (local.get $0)
                 (local.get $12)
                )
                (block $block21
                 (br_if $block21
                  (i32.eqz
                   (i32.load8_u
                    (local.get $8)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 2)
                 )
                 (local.set $6
                  (i32.const 4)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 4)
                 )
                 (i32.store
                  (local.tee $9
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66350)
                 )
                 (call $fimport$2
                  (local.get $0)
                 )
                 (br_if $block21
                  (i32.eqz
                   (local.tee $7
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.set $10
                  (i32.load
                   (local.get $9)
                  )
                 )
                 (br $block14)
                )
                (i32.store offset=276
                 (local.get $0)
                 (local.tee $23
                  (i32.lt_u
                   (local.tee $9
                    (i32.load
                     (local.get $0)
                    )
                   )
                   (i32.const 5)
                  )
                 )
                )
                (i32.store offset=240
                 (local.get $0)
                 (local.tee $5
                  (i32.gt_u
                   (local.get $9)
                   (i32.const 3)
                  )
                 )
                )
                (i32.store offset=236
                 (local.get $0)
                 (local.get $5)
                )
                (i32.store offset=232
                 (local.get $0)
                 (i32.lt_u
                  (local.get $9)
                  (i32.const 4)
                 )
                )
                (i32.store offset=228
                 (local.get $0)
                 (i32.eq
                  (local.get $9)
                  (i32.const 4)
                 )
                )
                (block $block22
                 (br_if $block22
                  (local.get $23)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66416)
                 )
                 (block $block23
                  (br_if $block23
                   (i32.ge_u
                    (local.tee $3
                     (i32.add
                      (i32.load offset=332
                       (local.get $0)
                      )
                      (i32.const 4)
                     )
                    )
                    (i32.load offset=328
                     (local.get $0)
                    )
                   )
                  )
                  (br_if $block24
                   (i32.eq
                    (i32.load offset=398496
                     (local.get $2)
                    )
                    (i32.const 66416)
                   )
                  )
                 )
                 (i32.store offset=308
                  (local.get $0)
                  (i32.const 4)
                 )
                 (i32.store offset=292
                  (local.get $0)
                  (i32.const 2)
                 )
                 (i32.store8 offset=296
                  (local.get $0)
                  (i32.const 1)
                 )
                 (i32.store
                  (local.get $10)
                  (i32.const 66416)
                 )
                 (return)
                )
                (i64.store offset=236 align=4
                 (local.get $0)
                 (i64.const 4294967297)
                )
                (i32.store offset=276
                 (local.get $0)
                 (local.tee $5
                  (i32.eqz
                   (local.tee $23
                    (i32.load offset=4
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
                (i32.store offset=232
                 (local.get $0)
                 (i32.shr_u
                  (local.get $23)
                  (i32.const 31)
                 )
                )
                (i32.store offset=228
                 (local.get $0)
                 (local.get $5)
                )
                (block $block25
                 (br_if $block25
                  (local.get $23)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66416)
                 )
                 (block $block26
                  (br_if $block26
                   (i32.ge_u
                    (local.tee $3
                     (i32.add
                      (i32.load offset=332
                       (local.get $0)
                      )
                      (i32.const 6)
                     )
                    )
                    (i32.load offset=328
                     (local.get $0)
                    )
                   )
                  )
                  (br_if $block27
                   (i32.eq
                    (i32.load offset=398496
                     (local.get $2)
                    )
                    (i32.const 66416)
                   )
                  )
                 )
                 (i32.store offset=308
                  (local.get $0)
                  (i32.const 6)
                 )
                 (i32.store offset=292
                  (local.get $0)
                  (i32.const 2)
                 )
                 (i32.store8 offset=296
                  (local.get $0)
                  (i32.const 1)
                 )
                 (i32.store
                  (local.get $10)
                  (i32.const 66416)
                 )
                 (return)
                )
                (i64.store offset=248 align=4
                 (local.get $0)
                 (i64.const 0)
                )
                (i32.store offset=12
                 (local.get $0)
                 (i32.const 32000000)
                )
                (i32.store offset=276
                 (local.get $0)
                 (local.tee $5
                  (i32.lt_u
                   (local.get $23)
                   (i32.const 32000001)
                  )
                 )
                )
                (i32.store offset=240
                 (local.get $0)
                 (local.tee $7
                  (i32.gt_u
                   (local.get $23)
                   (i32.const 31999999)
                  )
                 )
                )
                (i32.store offset=236
                 (local.get $0)
                 (local.get $7)
                )
                (i32.store offset=232
                 (local.get $0)
                 (i32.lt_u
                  (local.get $23)
                  (i32.const 32000000)
                 )
                )
                (i32.store offset=228
                 (local.get $0)
                 (i32.eq
                  (local.get $23)
                  (i32.const 32000000)
                 )
                )
                (block $block28
                 (br_if $block28
                  (local.get $5)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66416)
                 )
                 (block $block29
                  (br_if $block29
                   (i32.ge_u
                    (local.tee $3
                     (i32.add
                      (i32.load offset=332
                       (local.get $0)
                      )
                      (i32.const 10)
                     )
                    )
                    (i32.load offset=328
                     (local.get $0)
                    )
                   )
                  )
                  (br_if $block30
                   (i32.eq
                    (i32.load offset=398496
                     (local.get $2)
                    )
                    (i32.const 66416)
                   )
                  )
                 )
                 (i32.store offset=308
                  (local.get $0)
                  (i32.const 10)
                 )
                 (i32.store offset=292
                  (local.get $0)
                  (i32.const 2)
                 )
                 (i32.store8 offset=296
                  (local.get $0)
                  (i32.const 1)
                 )
                 (i32.store
                  (local.get $10)
                  (i32.const 66416)
                 )
                 (return)
                )
                (i32.store offset=40
                 (local.get $0)
                 (i32.const 70384)
                )
                (block $block32
                 (block $block31
                  (br_if $block31
                   (i32.eqz
                    (local.tee $5
                     (i32.load
                      (i32.add
                       (local.get $10)
                       (i32.const 68)
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $5)
                    (i32.const 752)
                   )
                   (local.get $9)
                  )
                  (br $block32)
                 )
                 (local.set $5
                  (i32.const 13)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 13)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $25
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66376)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (i32.const 70384)
                  (local.get $9)
                 )
                 (br_if $block33
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (block $block34
                 (br_if $block34
                  (i32.eqz
                   (i32.load8_u
                    (local.get $8)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 13)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 13)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $25
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66378)
                 )
                 (call $fimport$2
                  (local.get $0)
                 )
                 (br_if $block34
                  (i32.eqz
                   (local.tee $7
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.set $10
                  (i32.load
                   (local.get $25)
                  )
                 )
                 (br $block14)
                )
                (i32.store offset=40
                 (local.get $0)
                 (i32.const 70388)
                )
                (block $block36
                 (block $block35
                  (br_if $block35
                   (i32.eqz
                    (local.tee $5
                     (i32.load
                      (i32.add
                       (local.get $10)
                       (i32.const 68)
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $5)
                    (i32.const 756)
                   )
                   (local.get $23)
                  )
                  (br $block36)
                 )
                 (local.set $5
                  (i32.const 16)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 16)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $25
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66386)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (i32.const 70388)
                  (local.get $23)
                 )
                 (br_if $block37
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (block $block38
                 (br_if $block38
                  (i32.eqz
                   (i32.load8_u
                    (local.get $8)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 16)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 16)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $23
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66388)
                 )
                 (call $fimport$2
                  (local.get $0)
                 )
                 (br_if $block38
                  (i32.eqz
                   (local.tee $7
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.set $10
                  (i32.load
                   (local.get $23)
                  )
                 )
                 (br $block14)
                )
                (i32.store offset=40
                 (local.get $0)
                 (i32.const 70392)
                )
                (local.set $23
                 (i32.load offset=8
                  (local.get $0)
                 )
                )
                (block $block40
                 (block $block39
                  (br_if $block39
                   (i32.eqz
                    (local.tee $10
                     (i32.load
                      (i32.add
                       (local.get $10)
                       (i32.const 68)
                      )
                     )
                    )
                   )
                  )
                  (i32.store
                   (i32.add
                    (local.get $10)
                    (i32.const 760)
                   )
                   (local.get $23)
                  )
                  (br $block40)
                 )
                 (local.set $5
                  (i32.const 19)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 19)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66396)
                 )
                 (call $fimport$1
                  (local.get $1)
                  (i32.const 70392)
                  (local.get $23)
                 )
                 (br_if $block41
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (block $block42
                 (br_if $block42
                  (i32.eqz
                   (i32.load8_u
                    (local.get $8)
                   )
                  )
                 )
                 (local.set $5
                  (i32.const 19)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 308)
                  )
                  (i32.const 19)
                 )
                 (local.set $6
                  (i32.const 2)
                 )
                 (i32.store
                  (i32.add
                   (local.get $0)
                   (i32.const 292)
                  )
                  (i32.const 2)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66398)
                 )
                 (call $fimport$2
                  (local.get $0)
                 )
                 (br_if $block42
                  (i32.eqz
                   (local.tee $7
                    (i32.load8_u offset=296
                     (local.get $0)
                    )
                   )
                  )
                 )
                 (local.set $10
                  (i32.load
                   (local.get $10)
                  )
                 )
                 (br $block14)
                )
                (i32.store offset=240
                 (local.get $0)
                 (local.tee $10
                  (i32.gt_u
                   (local.get $9)
                   (i32.const 1)
                  )
                 )
                )
                (i32.store offset=236
                 (local.get $0)
                 (local.get $10)
                )
                (i32.store offset=232
                 (local.get $0)
                 (i32.shr_u
                  (local.tee $10
                   (i32.add
                    (local.get $9)
                    (i32.const -2)
                   )
                  )
                  (i32.const 31)
                 )
                )
                (i32.store offset=228
                 (local.get $0)
                 (local.tee $8
                  (i32.eqz
                   (local.get $10)
                  )
                 )
                )
                (i32.store offset=276
                 (local.get $0)
                 (local.get $8)
                )
                (block $block43
                 (br_if $block43
                  (local.get $10)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66426)
                 )
                 (block $block44
                  (br_if $block44
                   (i32.ge_u
                    (local.tee $3
                     (i32.add
                      (i32.load offset=332
                       (local.get $0)
                      )
                      (i32.const 21)
                     )
                    )
                    (i32.load offset=328
                     (local.get $0)
                    )
                   )
                  )
                  (br_if $block45
                   (i32.eq
                    (i32.load offset=398556
                     (local.get $2)
                    )
                    (i32.const 66426)
                   )
                  )
                 )
                 (i32.store offset=308
                  (local.get $0)
                  (i32.const 21)
                 )
                 (i32.store offset=292
                  (local.get $0)
                  (i32.const 2)
                 )
                 (i32.store8 offset=296
                  (local.get $0)
                  (i32.const 1)
                 )
                 (i32.store
                  (local.get $10)
                  (i32.const 66426)
                 )
                 (return)
                )
                (i32.store offset=240
                 (local.get $0)
                 (local.tee $10
                  (i32.gt_u
                   (local.get $9)
                   (i32.const 2)
                  )
                 )
                )
                (i32.store offset=236
                 (local.get $0)
                 (local.get $10)
                )
                (i32.store offset=232
                 (local.get $0)
                 (i32.shr_u
                  (local.tee $10
                   (i32.add
                    (local.get $9)
                    (i32.const -3)
                   )
                  )
                  (i32.const 31)
                 )
                )
                (i32.store offset=228
                 (local.get $0)
                 (local.tee $9
                  (i32.eqz
                   (local.get $10)
                  )
                 )
                )
                (i32.store offset=276
                 (local.get $0)
                 (local.get $9)
                )
                (block $block46
                 (br_if $block46
                  (local.get $10)
                 )
                 (i32.store
                  (local.tee $10
                   (i32.add
                    (local.get $0)
                    (i32.const 188)
                   )
                  )
                  (i32.const 66468)
                 )
                 (block $block47
                  (br_if $block47
                   (i32.ge_u
                    (local.tee $3
                     (i32.add
                      (i32.load offset=332
                       (local.get $0)
                      )
                      (i32.const 23)
                     )
                    )
                    (i32.load offset=328
                     (local.get $0)
                    )
                   )
                  )
                  (br_if $block48
                   (i32.eq
                    (i32.load offset=398808
                     (local.get $2)
                    )
                    (i32.const 66468)
                   )
                  )
                 )
                 (i32.store offset=308
                  (local.get $0)
                  (i32.const 23)
                 )
                 (i32.store offset=292
                  (local.get $0)
                  (i32.const 2)
                 )
                 (i32.store8 offset=296
                  (local.get $0)
                  (i32.const 1)
                 )
                 (i32.store
                  (local.get $10)
                  (i32.const 66468)
                 )
                 (return)
                )
                (i32.store
                 (local.get $0)
                 (i32.const 0)
                )
                (block $block49
                 (br_if $block49
                  (i32.eqz
                   (local.tee $10
                    (i32.load
                     (local.get $24)
                    )
                   )
                  )
                 )
                 (local.set $9
                  (i32.load
                   (i32.add
                    (local.get $10)
                    (i32.and
                     (local.get $12)
                     (i32.const 4092)
                    )
                   )
                  )
                 )
                 (br $block50)
                )
                (local.set $5
                 (i32.const 25)
                )
                (i32.store
                 (i32.add
                  (local.get $0)
                  (i32.const 308)
                 )
                 (i32.const 25)
                )
                (local.set $6
                 (i32.const 4)
                )
                (i32.store
                 (i32.add
                  (local.get $0)
                  (i32.const 292)
                 )
                 (i32.const 4)
                )
                (i32.store
                 (local.tee $10
                  (i32.add
                   (local.get $0)
                   (i32.const 188)
                  )
                 )
                 (i32.const 66408)
                )
                (local.set $9
                 (call $fimport$3
                  (local.get $1)
                  (local.get $12)
                 )
                )
                (br_if $block50
                 (i32.eqz
                  (local.tee $7
                   (i32.load8_u offset=296
                    (local.get $0)
                   )
                  )
                 )
                )
                (local.set $10
                 (i32.load
                  (local.get $10)
                 )
                )
                (br $block14)
               )
               (i32.store8 offset=341
                (local.get $0)
                (i32.const 1)
               )
               (return)
              )
              (i32.store offset=332
               (local.get $0)
               (local.get $3)
              )
              (i32.store
               (i32.add
                (local.get $0)
                (i32.const 188)
               )
               (i32.const 66416)
              )
              (return_call_indirect $timport$0 (type $0)
               (local.get $0)
               (local.get $1)
               (i32.load offset=398504
                (local.get $2)
               )
              )
             )
             (i32.store offset=332
              (local.get $0)
              (local.get $3)
             )
             (i32.store
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
              (i32.const 66416)
             )
             (return_call_indirect $timport$0 (type $0)
              (local.get $0)
              (local.get $1)
              (i32.load offset=398504
               (local.get $2)
              )
             )
            )
            (i32.store offset=332
             (local.get $0)
             (local.get $3)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 188)
             )
             (i32.const 66416)
            )
            (return_call_indirect $timport$0 (type $0)
             (local.get $0)
             (local.get $1)
             (i32.load offset=398504
              (local.get $2)
             )
            )
           )
           (i32.store offset=332
            (local.get $0)
            (local.get $3)
           )
           (i32.store
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
            (i32.const 66426)
           )
           (return_call_indirect $timport$0 (type $0)
            (local.get $0)
            (local.get $1)
            (i32.load offset=398564
             (local.get $2)
            )
           )
          )
          (i32.store offset=332
           (local.get $0)
           (local.get $3)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
           (i32.const 66468)
          )
          (return_call_indirect $timport$0 (type $0)
           (local.get $0)
           (local.get $1)
           (i32.load offset=398816
            (local.get $2)
           )
          )
         )
         (local.set $10
          (i32.load
           (local.get $23)
          )
         )
         (br $block14)
        )
        (local.set $10
         (i32.load
          (local.get $23)
         )
        )
        (br $block14)
       )
       (local.set $10
        (i32.load
         (local.get $25)
        )
       )
       (br $block14)
      )
      (local.set $10
       (i32.load
        (local.get $25)
       )
      )
      (br $block14)
     )
     (local.set $10
      (i32.load
       (local.get $10)
      )
     )
     (br $block14)
    )
    (block $block65
     (block $block62
      (block $block59
       (block $block56
        (block $block53
         (block $block52
          (block $block51
           (br_if $block51
            (i32.eqz
             (local.tee $10
              (i32.load
               (local.get $22)
              )
             )
            )
           )
           (local.set $10
            (i32.load
             (i32.add
              (local.get $10)
              (i32.and
               (local.get $21)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block52)
          )
          (local.set $5
           (i32.const 25)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 25)
          )
          (local.set $6
           (i32.const 4)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 4)
          )
          (i32.store
           (local.tee $12
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66408)
          )
          (local.set $10
           (call $fimport$3
            (local.get $1)
            (local.get $21)
           )
          )
          (br_if $block53
           (local.tee $7
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
         )
         (i32.store offset=168
          (local.get $0)
          (local.get $10)
         )
         (i32.store offset=60
          (local.get $0)
          (local.get $9)
         )
         (i32.store offset=56
          (local.get $0)
          (local.get $19)
         )
         (block $block55
          (block $block54
           (br_if $block54
            (i32.eqz
             (local.tee $9
              (i32.load
               (local.get $20)
              )
             )
            )
           )
           (local.set $9
            (i32.load
             (i32.add
              (local.get $9)
              (i32.and
               (local.get $19)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block55)
          )
          (local.set $5
           (i32.const 26)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 26)
          )
          (local.set $6
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 2)
          )
          (i32.store
           (local.tee $12
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66412)
          )
          (local.set $9
           (call $fimport$3
            (local.get $1)
            (local.get $19)
           )
          )
          (br_if $block56
           (local.tee $7
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
         )
         (i32.store offset=52
          (local.get $0)
          (local.get $9)
         )
         (block $block58
          (block $block57
           (br_if $block57
            (i32.eqz
             (local.tee $9
              (i32.load
               (local.get $18)
              )
             )
            )
           )
           (local.set $9
            (i32.load
             (i32.add
              (local.get $9)
              (i32.and
               (local.get $17)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block58)
          )
          (local.set $5
           (i32.const 26)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 26)
          )
          (local.set $6
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 2)
          )
          (i32.store
           (local.tee $12
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66412)
          )
          (local.set $9
           (call $fimport$3
            (local.get $1)
            (local.get $17)
           )
          )
          (br_if $block59
           (local.tee $7
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
         )
         (i32.store offset=48
          (local.get $0)
          (local.get $9)
         )
         (block $block61
          (block $block60
           (br_if $block60
            (i32.eqz
             (local.tee $9
              (i32.load
               (local.get $16)
              )
             )
            )
           )
           (local.set $9
            (i32.load
             (i32.add
              (local.get $9)
              (i32.and
               (local.get $15)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block61)
          )
          (local.set $5
           (i32.const 26)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 26)
          )
          (local.set $6
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 2)
          )
          (i32.store
           (local.tee $12
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66412)
          )
          (local.set $9
           (call $fimport$3
            (local.get $1)
            (local.get $15)
           )
          )
          (br_if $block62
           (local.tee $7
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
         )
         (i32.store offset=44
          (local.get $0)
          (local.get $9)
         )
         (block $block64
          (block $block63
           (br_if $block63
            (i32.eqz
             (local.tee $9
              (i32.load
               (local.get $14)
              )
             )
            )
           )
           (local.set $9
            (i32.load
             (i32.add
              (local.get $9)
              (i32.and
               (local.get $13)
               (i32.const 4092)
              )
             )
            )
           )
           (br $block64)
          )
          (local.set $5
           (i32.const 26)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 308)
           )
           (i32.const 26)
          )
          (local.set $6
           (i32.const 2)
          )
          (i32.store
           (i32.add
            (local.get $0)
            (i32.const 292)
           )
           (i32.const 2)
          )
          (i32.store
           (local.tee $12
            (i32.add
             (local.get $0)
             (i32.const 188)
            )
           )
           (i32.const 66412)
          )
          (local.set $9
           (call $fimport$3
            (local.get $1)
            (local.get $13)
           )
          )
          (br_if $block65
           (local.tee $7
            (i32.load8_u offset=296
             (local.get $0)
            )
           )
          )
         )
         (i32.store offset=28
          (local.get $0)
          (local.get $9)
         )
         (block $block69
          (block $block68
           (block $block67
            (block $block66
             (br_if $block66
              (i32.eqz
               (local.tee $9
                (i32.load
                 (local.get $11)
                )
               )
              )
             )
             (local.set $9
              (i32.load
               (i32.add
                (local.get $9)
                (i32.and
                 (local.get $4)
                 (i32.const 4092)
                )
               )
              )
             )
             (br $block67)
            )
            (local.set $5
             (i32.const 26)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 308)
             )
             (i32.const 26)
            )
            (local.set $6
             (i32.const 2)
            )
            (i32.store
             (i32.add
              (local.get $0)
              (i32.const 292)
             )
             (i32.const 2)
            )
            (i32.store
             (local.tee $12
              (i32.add
               (local.get $0)
               (i32.const 188)
              )
             )
             (i32.const 66412)
            )
            (local.set $9
             (call $fimport$3
              (local.get $1)
              (local.get $4)
             )
            )
            (br_if $block68
             (local.tee $7
              (i32.load8_u offset=296
               (local.get $0)
              )
             )
            )
           )
           (i32.store offset=56
            (local.get $0)
            (local.get $3)
           )
           (i32.store offset=24
            (local.get $0)
            (local.get $9)
           )
           (local.set $7
            (i32.const 1)
           )
           (br_if $block69
            (i32.and
             (local.get $10)
             (i32.const 1)
            )
           )
           (local.set $6
            (i32.const 2)
           )
           (local.set $5
            (i32.const 27)
           )
           (br $block14)
          )
          (local.set $10
           (i32.load
            (local.get $12)
           )
          )
          (br $block14)
         )
         (local.set $5
          (i32.const 27)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 308)
          )
          (i32.const 27)
         )
         (local.set $6
          (i32.const 2)
         )
         (i32.store
          (i32.add
           (local.get $0)
           (i32.const 292)
          )
          (i32.const 2)
         )
         (i32.store
          (local.tee $3
           (i32.add
            (local.get $0)
            (i32.const 188)
           )
          )
          (i32.const 66414)
         )
         (call $fimport$4
          (local.get $0)
          (i32.const 42)
          (local.get $1)
         )
         (local.set $10
          (i32.load
           (local.get $3)
          )
         )
         (local.set $7
          (i32.load8_u offset=296
           (local.get $0)
          )
         )
         (br $block14)
        )
        (local.set $10
         (i32.load
          (local.get $12)
         )
        )
        (br $block14)
       )
       (local.set $10
        (i32.load
         (local.get $12)
        )
       )
       (br $block14)
      )
      (local.set $10
       (i32.load
        (local.get $12)
       )
      )
      (br $block14)
     )
     (local.set $10
      (i32.load
       (local.get $12)
      )
     )
     (br $block14)
    )
    (local.set $10
     (i32.load
      (local.get $12)
     )
    )
    (br $block14)
   )
   (local.set $10
    (i32.load offset=188
     (local.get $0)
    )
   )
  )
  (block $block71
   (block $block70
    (br_if $block70
     (i32.ge_u
      (local.tee $3
       (i32.add
        (i32.load offset=332
         (local.get $0)
        )
        (local.get $5)
       )
      )
      (i32.load offset=328
       (local.get $0)
      )
     )
    )
    (br_if $block71
     (i32.eq
      (i32.load
       (local.tee $9
        (i32.add
         (local.get $2)
         (i32.mul
          (i32.and
           (i32.shr_u
            (local.get $10)
            (i32.const 1)
           )
           (i32.const 65535)
          )
          (i32.const 12)
         )
        )
       )
      )
      (local.get $10)
     )
    )
   )
   (i32.store offset=308
    (local.get $0)
    (local.get $5)
   )
   (i32.store offset=292
    (local.get $0)
    (local.get $6)
   )
   (i32.store offset=188
    (local.get $0)
    (local.get $10)
   )
   (i32.store8 offset=296
    (local.get $0)
    (local.get $7)
   )
   (return)
  )
  (i32.store offset=332
   (local.get $0)
   (local.get $3)
  )
  (i32.store offset=188
   (local.get $0)
   (local.get $10)
  )
  (i32.store8 offset=296
   (local.get $0)
   (i32.const 0)
  )
  (return_call_indirect $timport$0 (type $0)
   (local.get $0)
   (local.get $1)
   (i32.load offset=8
    (local.get $9)
   )
  )
 )
 ;; custom section "linking", size 43
 ;; custom section "reloc.CODE", size 146
 ;; features section: mutable-globals, nontrapping-float-to-int, simd, bulk-memory, sign-ext, tail-call, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

