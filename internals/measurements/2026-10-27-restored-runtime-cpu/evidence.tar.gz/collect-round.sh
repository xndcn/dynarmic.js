#!/usr/bin/env bash
set -euo pipefail

round=$1
if [[ ! $round =~ ^[0-2]$ ]]; then
    printf 'usage: %s <0|1|2>\n' "$0" >&2
    exit 2
fi

root=/home/xiong/workspace/dynarmic.js
host=/tmp/dynarmic-restored-profile/examples/browser/dist/arm_jit.js
workload=/tmp/dynarmic-coremark-long
out=/tmp/dynarmic-restored-profile-evidence-339939c
cases=(
    'a32-thunk a32 0'
    'a32-page-table a32 1'
    'a32-flat-window a32 2'
    'a64-thunk a64 0'
    'a64-page-table a64 1'
    'a64-flat-window a64 2'
)

for ((i = 0; i < ${#cases[@]}; i++)); do
    index=$(( (i + round) % ${#cases[@]} ))
    read -r name frontend memory <<< "${cases[$index]}"
    printf 'round=%s case=%s frontend=%s memory=%s\n' \
        "$round" "$name" "$frontend" "$memory" | tee -a "$out/commands.log"
    env -u DYN_DUMP_DIR NODE_OPTIONS= taskset -c 0,2,4,6 \
        node "$root/tests/bench/coremark/profile.mjs" \
        "$host" "$workload/coremark_${frontend}.bin" "$frontend" "$memory" \
        "$out/${name}-p${round}.cpuprofile" \
        > "$out/${name}-p${round}-sample.txt" \
        2> "$out/${name}-p${round}-stderr.txt"
done
