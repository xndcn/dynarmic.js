import fs from 'node:fs';
import path from 'node:path';

const root = process.argv[2];
if (!root || process.argv.length !== 3) throw new Error('usage: make-observations.mjs <evidence-dir>');
const read = name => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const sample = name => {
  const text = fs.readFileSync(path.join(root, name), 'utf8');
  const lines = text.trim().split('\n').filter(line => line.startsWith('COREMARK_SAMPLE '));
  if (lines.length !== 1) throw new Error(`invalid sample ${name}`);
  const value = JSON.parse(lines[0].slice(16));
  return {haltReason: value.haltReason, runMs: value.runMs,
    kernelSeconds: Number(value.stdout.match(/Total time \(secs\): ([^\n]+)/)[1]), compile: value.compile};
};
const baseline = sample('baseline-a64-flat-sample.txt');
const candidate = sample('candidate-a64-flat-sample.txt');
const baselineModules = read('baseline-modules.json');
const candidateModules = read('candidate-modules.json');
const hot = ['a64_11700_region', 'a64_11fd0_region', 'a64_1202c_region', 'a64_1209c_region', 'a64_10b00_region', 'a64_10b18_region'];
const regions = hot.map(entry => ({entry,
  baseline: baselineModules.find(row => row.entry === entry) || null,
  candidate: candidateModules.find(row => row.entry === entry) || null,
}));
const observations = {schema: 'dynarmic.js/region-size-observations-v1',
  baseRevision: '80928262a1628d0e0e6b85ac0adc60d51eb4a8c9',
  limits: {maxBlocks: 128, maxInstructions: 2000, maxGuestDistance: 4096},
  baseline, candidate,
  emittedBytesRatio: candidate.compile.bytes / baseline.compile.bytes,
  diagnosticRunRatio: candidate.runMs / baseline.runMs,
  diagnosticKernelRatio: candidate.kernelSeconds / baseline.kernelSeconds,
  regions,
  concurrentCandidate: 'Retained for transparency only; it overlapped a native build and is excluded from every timing observation.',
  outcome: 'REJECTED during diagnostic screening: emitted bytes exceed the 1.10 gate. Single CPU-sampled Runs are not benchmark evidence; no complete-duration performance cohort was started.',
};
fs.writeFileSync(path.join(root, 'observations.json'), JSON.stringify(observations, null, 2) + '\n', {flag: 'wx'});
