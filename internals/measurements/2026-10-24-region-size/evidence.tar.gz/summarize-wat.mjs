import fs from 'node:fs';
import path from 'node:path';

const root = process.argv[2];
if (!root || process.argv.length !== 3) throw new Error('usage: summarize-wat.mjs <directory>');
const rows = [];
for (const name of fs.readdirSync(root).filter(name => name.endsWith('.wat'))) {
  const text = fs.readFileSync(path.join(root, name), 'utf8');
  const code = text.replace(/\(;.*?;\)/gs, '');
  const entry = text.match(/\(func \$(a(?:32|64)_[0-9a-f]+(?:_region)?) /)?.[1] || null;
  const tables = [...code.matchAll(/\(br_table\s+([^)]+)\)/gs)].map(match => match[1].trim().split(/\s+/).length);
  rows.push({
    file: name,
    entry,
    bytes: fs.statSync(path.join(root, name.replace(/\.wat$/, '.wasm'))).size,
    externalTransfers: (text.match(/return_call_indirect/g) || []).length,
    dispatchTargets: tables.length ? Math.max(...tables) : 0,
    dispatchSites: tables.length,
    watBytes: Buffer.byteLength(text),
  });
}
rows.sort((a, b) => Number(a.file.match(/\d+/)[0]) - Number(b.file.match(/\d+/)[0]));
console.log(JSON.stringify(rows, null, 2));
