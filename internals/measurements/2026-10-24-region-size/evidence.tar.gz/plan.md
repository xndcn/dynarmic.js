# Bounded region experiment 128

- Base: 80928262a1628d0e0e6b85ac0adc60d51eb4a8c9, upstream a41c380246d3d9f9874f0f792d234dc0cc17c180.
- Candidate: RegionSelectionLimits.max_blocks 64 -> 128; IR and guest-distance limits unchanged.
- Source: /tmp/dynarmic-region-src. Baseline build: build-em-before. Candidate build: build-em-after.
- Workload: /tmp/dynarmic-coremark-120k (120000 iterations), native CRC oracle.
- First screen: A64 flat diagnostic Run, generated WAT for iterate entries 0x10b00 and 0x10b18, compile phases, emitted bytes, region rejection migration and code layout.
- No timing claim from dump/profile runs. Performance candidates use ordinary Release, DYN_DUMP_DIR unset, taskset 0,2,4,6, alternating fresh processes.
- Existing acceptance gates: kernel median ratio <= 1/0.95, Run/compile <= 1.15, emitted bytes/cache peaks <= 1.10. Adoption additionally requires reproducible improvement beyond dispersion and demonstrated hot-edge absorption; neutral/noisy results retain 64.
- Stop early if hot shape does not change or distance/layout dominates. If IR budget prevents absorption, a separate 128/4000 probe is required and is not a max_blocks-only result.
- External rationale: larger functions can increase optimizing-compiler cost and alter tier-up; no assumption that absorption is beneficial.
