import fs from 'node:fs';
import {pathToFileURL} from 'node:url';

const source = '/tmp/dynarmic-region-src';
const output = process.argv[2];
if (!output || process.argv.length !== 3) throw new Error('usage: record-environment.mjs <output>');
const env = await import(pathToFileURL(`${source}/tests/bench/environment.mjs`));
const dirs = [`${source}/build-em-before`, `${source}/build-em-after`];
const configs = dirs.map(dir => env.readBuildInfo(dir));
const artifact = dir => ({
  jsSha256: env.hashFile(`${dir}/examples/browser/dist/arm_jit.js`),
  wasmSha256: env.hashFile(`${dir}/examples/browser/dist/arm_jit.wasm`),
});
const result = {
  baseRevision: '80928262a1628d0e0e6b85ac0adc60d51eb4a8c9',
  upstreamRevision: 'a41c380246d3d9f9874f0f792d234dc0cc17c180',
  system: env.systemInfo(),
  builds: configs.map(config => config.build),
  sourceObservationAfter: env.sourceInfo(source),
  artifacts: {baseline: artifact(dirs[0]), candidate: artifact(dirs[1])},
  provenanceLimitations: 'Local source observations and hashes are not independent attestation. The baseline was built before the one-line candidate edit; SDKs and external workload binaries are not archived.',
};
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
