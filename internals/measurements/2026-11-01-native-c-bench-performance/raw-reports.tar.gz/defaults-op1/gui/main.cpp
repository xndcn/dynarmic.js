#include "loader/ldr.h"
#include "cpu/cpu.h"
#include "cpu/dma.h"
#include "cpu/twi.h"
#include "peripheral/MT29F4G08.h"
#include "utils/log.h"
#include "glfw_display.h"
#include "headless.h"
#include "audio_output_miniaudio.h"
#include "usbipd.h"
#include "build_info.h"
#ifdef ENABLE_PROFILING
#include "profiling/profiler.h"
#endif
#include <algorithm>
#include <vector>
#include <iostream>
#include <memory>
#include <thread>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <csignal>
#include <string>
#include <optional>
#include <stdexcept>
#include <fcntl.h>
#include <unistd.h>

std::atomic<bool> cpuShouldStop(false);

// Headless runs are stopped with SIGTERM/SIGINT. Default termination bypasses
// destructors and loses buffered output, so request a clean shutdown instead.
// The handler only stores to a lock-free atomic on the supported host.
static_assert(std::atomic<bool>::is_always_lock_free);
static void StopSigHandler(int) {
    cpuShouldStop.store(true);
}

void LdrExecutionThread(BlackFinCpu& cpu, const LDRParser& parser) {
    const auto& dxes = parser.getDXEs();
    for (const auto& dxe : dxes) {
        for (const auto& block : dxe.blocks) {
            if (!block.data.empty()) {
                cpu.GetEmulator().MemoryWrite(
                    block.header.target_address,
                    block.data.data(),
                    block.data.size()
                );
            }
            if (block.IsFirstBlock()) {
                cpu.SetRegister(RegIndex::RETS, 0x8000000);
                cpu.SetPC(block.header.target_address);
            }
        }
        LogInfo("Start executing DXE");

        while (!cpuShouldStop.load()) {
            cpu.Run();
            if (cpu.Failed()) cpuShouldStop.store(true);

            if (cpu.PC() == 0x8000000) {
                LogInfo("Finished executing DXE");
                break;
            }
            if (cpu.PC() == 0xffa06e54) {
                LogInfo("Hit delay(%d)", cpu.GetRegister(RegIndex::R0));
            }
            if (cpu.PC() == 0xffa06eec) {
                LogInfo("Hit delay end");
            }
        }

        if (cpuShouldStop.load()) {
            break;
        }
    }
    cpuShouldStop.store(true);
    LogInfo("CPU thread exiting");
}

void BootExcutionThread(BlackFinCpu& cpu) {
    cpu.SetPC(0xEF000000); // Boot entry point
    while (!cpuShouldStop.load()) {
        cpu.Run();
        if (cpu.Failed()) cpuShouldStop.store(true);
    }
    cpuShouldStop.store(true);
    LogInfo("CPU thread exiting");
}

static int RunEmulator(int argc, char* argv[]) {
    // Separate flags from positional args so flag order relative to
    // <nand_flash_file> [ldr_file] doesn't matter.
    std::vector<std::string> positional;
    // Persist guest writes by default, matching real hardware. --nand-snapshot
    // opens the image copy-on-write (backing file untouched) for disposable
    // runs or deterministic tests; --nand-rw is accepted as an explicit
    // persistent-mode selector.
    bool nandSnapshot = false;
    bool headless = false;
    bool deterministic = false;
    std::optional<long long> rtcEpoch;
    unsigned twiSpeedup = TWI::kDefaultSpeedup;
    unsigned mdmaSpeedup = DMA::kDefaultMdmaSpeedup;
    unsigned audioBufferMs = MiniaudioOutput::kDefaultBufferMs;
    bool help = false;
    bool options = true;
    std::string inputScript;
    // Profiling options (profiling builds only; see docs/profiling.md).
    std::string profileMarks, profileTrace, profileCensus, perfFifo, perfWindow, profileUntil;
    std::string profileChecksum, profileChecksumEvery, profileChecksumFrom, profileDumpIr, profileDumpDir;
    std::string profileTraceEvents, profileEndCycles;
    bool perfJitdump = false;
    bool profileCounters = false;
    bool noChain = false;
    bool noLoopBlocks = false;
    bool noIdleWait = false;
    bool noDmaSettle = false;
    int steadySkip = 2;
    long long tierThreshold = BlackFinCpu::kTierThreshold;
    long long tierSizeRef = BlackFinCpu::kTierSizeRef;
    bool lightTier1 = true;
    bool tierBackground = true;
    bool copyPatch = true;
    bool copyPatchHints = true;
    long long tierPublishAfter = 0;
    long long jitCpu = -1;
    bool chainDry = false;
    bool markDigest = false;
    bool profileProbes = false;
    const std::pair<const char*, std::string*> valueOptions[] = {
        {"--profile-marks", &profileMarks}, {"--profile-trace", &profileTrace},
        {"--profile-census", &profileCensus}, {"--perf-ctl-fifo", &perfFifo},
        {"--perf-window", &perfWindow}, {"--profile-until", &profileUntil},
        {"--profile-checksum", &profileChecksum}, {"--profile-checksum-every", &profileChecksumEvery},
        {"--profile-checksum-from", &profileChecksumFrom},
        {"--profile-dump-ir", &profileDumpIr}, {"--profile-dump-dir", &profileDumpDir},
        {"--profile-trace-events", &profileTraceEvents}, {"--profile-end-cycles", &profileEndCycles},
    };
    bool anyProfiling = false;
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (options && arg == "--") options = false;
        else if (options && arg == "--nand-rw") nandSnapshot = false;
        else if (options && arg == "--nand-snapshot") nandSnapshot = true;
        else if (options && arg == "--headless") headless = true;
        else if (options && arg == "--deterministic") deterministic = true;
        else if (options && arg == "--no-chain") noChain = true;
        else if (options && arg == "--no-loop-blocks") noLoopBlocks = true;
        else if (options && arg == "--no-idle-wait") noIdleWait = true;
        else if (options && arg == "--no-dma-settle") noDmaSettle = true;
        else if (options && arg == "--steady-skip") {
            if (++i == argc) throw std::runtime_error("--steady-skip requires off, dry or on");
            const std::string mode = argv[i];
            if (mode == "off") steadySkip = 0;
            else if (mode == "dry") steadySkip = 1;
            else if (mode == "on") steadySkip = 2;
            else throw std::runtime_error("Invalid --steady-skip (off, dry, on): " + mode);
        }
        else if (options && (arg == "--tier-threshold" || arg == "--tier-size-ref")) {
            if (++i == argc) throw std::runtime_error(arg + " requires a count (0 for none)");
            size_t used = 0;
            long long value = -1;
            try { value = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || value < 0 || value > UINT32_MAX)
                throw std::runtime_error("Invalid " + arg + ": " + argv[i]);
            (arg == "--tier-threshold" ? tierThreshold : tierSizeRef) = value;
        }
        else if (options && arg == "--tier1-pipeline") {
            if (++i == argc) throw std::runtime_error("--tier1-pipeline requires light or o1");
            const std::string pipeline = argv[i];
            if (pipeline == "light") lightTier1 = true;
            else if (pipeline == "o1") lightTier1 = false;
            else throw std::runtime_error("Invalid --tier1-pipeline (light, o1): " + pipeline);
        }
        else if (options && (arg == "--tier-publish-after" || arg == "--jit-cpu")) {
            if (++i == argc) throw std::runtime_error(arg + " requires a number");
            size_t used = 0;
            long long value = -1;
            try { value = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || value < 0)
                throw std::runtime_error("Invalid " + arg + ": " + argv[i]);
            (arg == "--jit-cpu" ? jitCpu : tierPublishAfter) = value;
        }
        else if (options && arg == "--no-tier-background") tierBackground = false;
        else if (options && arg == "--no-copy-patch") copyPatch = false;
        else if (options && arg == "--no-cp-hints") copyPatchHints = false;
        else if (options && arg == "--profile-chain-dry") chainDry = anyProfiling = true;
        else if (options && arg == "--profile-mark-digest") markDigest = anyProfiling = true;
        else if (options && arg == "--rtc-epoch") {
            if (++i == argc) throw std::runtime_error("--rtc-epoch requires seconds since 1970");
            size_t used = 0;
            long long seconds = -1;
            try { seconds = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || seconds < 0)
                throw std::runtime_error(std::string("Invalid --rtc-epoch: ") + argv[i]);
            if (seconds > TimeSource::kMaxEpochSeconds)
                throw std::runtime_error(std::string("--rtc-epoch past the RTC's range (2059-09-18, ") +
                                         std::to_string(TimeSource::kMaxEpochSeconds) + "): " + argv[i]);
            rtcEpoch = seconds;
        }
        else if (options && arg == "--twi-speedup") {
            if (++i == argc) throw std::runtime_error("--twi-speedup requires a factor");
            size_t used = 0;
            long long factor = -1;
            try { factor = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || factor < 1 || factor > 100000)
                throw std::runtime_error(std::string("Invalid --twi-speedup (1..100000): ") + argv[i]);
            twiSpeedup = static_cast<unsigned>(factor);
        }
        else if (options && arg == "--mdma-speedup") {
            if (++i == argc) throw std::runtime_error("--mdma-speedup requires a factor");
            size_t used = 0;
            long long factor = -1;
            try { factor = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || factor < 1 || factor > 100000)
                throw std::runtime_error(std::string("Invalid --mdma-speedup (1..100000): ") + argv[i]);
            mdmaSpeedup = static_cast<unsigned>(factor);
        }
        else if (options && arg == "--audio-buffer") {
            if (++i == argc) throw std::runtime_error("--audio-buffer requires milliseconds");
            size_t used = 0;
            long long ms = -1;
            try { ms = std::stoll(argv[i], &used); } catch (const std::exception&) {}
            if (used == 0 || argv[i][used] != '\0' || ms < MiniaudioOutput::kMinBufferMs ||
                ms > MiniaudioOutput::kMaxBufferMs)
                throw std::runtime_error("Invalid --audio-buffer (" + std::to_string(MiniaudioOutput::kMinBufferMs) +
                                         ".." + std::to_string(MiniaudioOutput::kMaxBufferMs) + "): " + argv[i]);
            audioBufferMs = static_cast<unsigned>(ms);
        }
        else if (options && arg == "--perf-jitdump") perfJitdump = anyProfiling = true;
        else if (options && arg == "--profile-counters") profileCounters = anyProfiling = true;
        else if (options && arg == "--profile-probes") profileProbes = anyProfiling = true;
        else if (options && std::any_of(std::begin(valueOptions), std::end(valueOptions),
                                        [&](const auto& option) { return arg == option.first; })) {
            if (++i == argc || !*argv[i]) throw std::runtime_error(arg + " requires a nonempty value");
            for (const auto& [name, value] : valueOptions)
                if (arg == name) *value = argv[i];
            anyProfiling = true;
        }
        else if (options && (arg == "--help" || arg == "-h")) help = true;
        else if (options && arg == "--build-info") {
            std::cout << BuildInfoJson() << std::endl;
            return 0;
        }
        else if (options && arg == "--input-script") {
            if (++i == argc) throw std::runtime_error("--input-script requires a path");
            inputScript = argv[i];
            if (inputScript.empty()) throw std::runtime_error("--input-script requires a nonempty path");
        } else if (options && arg.rfind("-", 0) == 0) {
            throw std::runtime_error("Unknown option: " + arg);
        } else positional.push_back(arg);
    }

    if (help || positional.empty()) {
        std::cout << "Usage: " << argv[0]
                  << " <nand_flash_file> [ldr_file] [--nand-rw|--nand-snapshot]\n"
                     "  --headless            No GLFW window or host audio device\n"
                     "  --input-script PATH   Read headless commands from PATH instead of stdin\n"
                     "  --deterministic       Run as fast as the host allows, not at the device's\n"
                     "                        pace: repeatable runs, for measurement and tests\n"
                     "  --rtc-epoch SECONDS   RTC time at boot (default: the host's; 2024-01-01\n"
                     "                        with --deterministic)\n"
                     "  --no-chain            Return to the host after every guest block\n"
                     "  --no-idle-wait        Run an IDLE as a NOP instead of\n"
                     "                        letting guest time pass to the next wakeup\n"
                     "  --steady-skip MODE    on (default), dry or off: a loop whose iteration changed\n"
                     "                        nothing but its counters goes to its last iteration\n"
                     "                        (dry: only counts the iterations it would skip)\n"
                     "  --no-dma-settle       Move each memory DMA element at its own time instead\n"
                     "                        of when something could see it (same transfers, slower)\n"
                     "  --tier-threshold N    Compile a block with the whole pipeline once it\n"
                     "                        started N times, cheaply before (default 30000;\n"
                     "                        0: every block once, with the whole pipeline)\n"
                     "  --tier-size-ref N     A block of more than N packets waits as many times\n"
                     "                        longer as it has packets more (default 16; 0: the\n"
                     "                        same threshold for every block)\n"
                     "  --tier1-pipeline P    light (default) or o1: the IR pipeline of those second\n"
                     "                        compilations, but for loop blocks, which get O1\n"
                     "  --no-tier-background  Compile those blocks again on the CPU thread, not on\n"
                     "                        a thread of their own\n"
                     "  --no-copy-patch       Make the cheap compilations with LLVM, not from\n"
                     "                        stencils where the instructions allow\n"
                     "  --no-cp-hints         Make those from stencils that rely on nothing the\n"
                     "                        loop registers held when they were made\n"
                     "  --tier-publish-after N  With --deterministic, use such a block's second\n"
                     "                        compilation N packets after it was asked for\n"
                     "                        (default 8388608; the CPU thread waits for it)\n"
                     "  --jit-cpu N           Run the second compilations on CPU N\n"
                     "  --no-loop-blocks      Keep a guest loop's registers in memory across it\n"
                     "                        (bcore loop blocks off; same results, slower)\n"
                     "  --twi-speedup N       Run the I2C bus N times faster than programmed\n"
                     "                        (default 10; 1 is the hardware's rate)\n"
                     "  --mdma-speedup N      Run memory DMA N times faster than the hardware\n"
                     "                        (default 10; 1 is the hardware's rate)\n"
                     "  --audio-buffer MS     Audio latency, from the emulator to the sound card's\n"
                     "                        output (default 26, 9..200; more: later sound,\n"
                     "                        fewer gaps on a busy host)\n"
                     "  --build-info          Print what this binary was built from (JSON) and exit\n"
                     "Profiling builds (-DENABLE_PROFILING=ON, see docs/profiling.md):\n"
                     "  --profile-marks FILE  Phase marks (firmware PC ranges, verified frame)\n"
                     "  --profile-trace FILE  Chrome/Perfetto trace of translations and marks\n"
                     "  --profile-census PFX  Block, edge and MMIO census at every mark (diagnostic)\n"
                     "  --profile-until MARK  Stop cleanly when MARK fires\n"
                     "  --profile-end-cycles N  Mark 'end' at the first block boundary at or past N\n"
                     "                        guest cycles (a phase end that keystrokes cannot name)\n"
                     "  --perf-ctl-fifo FIFO  perf record --control=fifo:FIFO\n"
                     "  --perf-window A:B     Enable perf at mark A, disable at mark B\n"
                     "  --perf-jitdump        Write LLVM jitdump for perf inject --jit\n"
                     "  --profile-counters    CPU thread's user-space instructions and cycles at every mark\n"
                     "  --profile-checksum F  Guest-state checksum every N blocks (diagnostic)\n"
                     "  --profile-probes      Capture the marks file's probes (diagnostic)\n"
                     "  --profile-mark-digest Hashes of guest registers, CEC and RAM at every mark\n"
                     "  --profile-chain-dry   Blocks only report that they would chain; check that\n"
                     "                        the host then has nothing to do ([chain] violations)\n"
                     "  --profile-dump-ir PCS Write the LLVM IR of blocks at these PCs (comma-separated hex)\n"
                     "  --profile-dump-dir D  Directory for those files (default ir)\n"
                     "  --profile-checksum-every N  Blocks between checksums (default 65536)\n"
                     "  --profile-checksum-from N   First block to checksum (default 0)\n"
                     "  --profile-trace-events N    Trace capacity in events (default 262144)\n"
                     "Headless commands (one per line):\n"
                     "  keys | press KEY | release KEY | tap KEY [MS] | wait MS | quit\n"
                     "  at MS: later press/release/tap are for guest time MS (before the script's\n"
                     "         first wait: queued before the CPU starts)\n"
                     "  accel X Y Z | accel random | volume 0..255\n"
                     "  wait-frames N [TIMEOUT_MS] | screenshot PATH.ppm\n"
                     "Keys are button names from gui/ui.json. Tap defaults to 100ms.\n"
                     "Wait/tap use wall time. EOF leaves the emulator running; quit or Ctrl-C stops it.\n";
        return help ? 0 : 1;
    }
    if (positional.size() > 2) throw std::runtime_error("Expected NAND and optional LDR paths");
    if (!inputScript.empty() && !headless)
        throw std::runtime_error("--input-script requires --headless");
#ifndef ENABLE_PROFILING
    if (anyProfiling)
        throw std::runtime_error("Profiling options need a build with -DENABLE_PROFILING=ON");
#endif

    std::shared_ptr<GLFWDisplay> window;
    std::shared_ptr<HeadlessFrontend> console;
    std::shared_ptr<Display> display;
    std::shared_ptr<Keyboard> keyboard;
    if (headless) {
        int fd = inputScript.empty() ? STDIN_FILENO : open(inputScript.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) throw std::runtime_error("Failed to open input script: " + inputScript);
        try {
            console = std::make_shared<HeadlessFrontend>("gui/ui.json", fd);
        } catch (...) {
            if (!inputScript.empty()) close(fd);
            throw;
        }
        if (!inputScript.empty()) close(fd);
        display = console;
        keyboard = console;
        LogInfo("Headless mode: commands from %s", inputScript.empty() ? "stdin" : inputScript.c_str());
    } else {
        window = std::make_shared<GLFWDisplay>();
        display = window;
        keyboard = window;
    }

    std::signal(SIGTERM, StopSigHandler);
    std::signal(SIGINT, StopSigHandler);

    // Create BlackFin CPU
    BlackFinCpu cpu(deterministic);
    cpu.SetTwiSpeedup(twiSpeedup);
    cpu.SetMdmaSpeedup(mdmaSpeedup);
    // An LDR runs with the host looking at the PC after every block
    // (LdrExecutionThread).
    if (chainDry && noChain) throw std::runtime_error("--profile-chain-dry checks chaining: not with --no-chain");
    cpu.SetChaining(!noChain && positional.size() < 2, chainDry);
    if (noLoopBlocks) cpu.SetLoopBlocks(false);
    if (noIdleWait) cpu.SetIdleWaits(false);
    cpu.SetSteadySkip(steadySkip);
    cpu.SetTiering(static_cast<uint32_t>(tierThreshold), static_cast<uint32_t>(tierSizeRef));
    cpu.SetLightTier1(lightTier1);
    cpu.SetTierBackground(tierBackground, static_cast<uint64_t>(tierPublishAfter), static_cast<int>(jitCpu));
    cpu.SetCopyPatch(copyPatch);
    cpu.SetCopyPatchHints(copyPatchHints);
    if (noDmaSettle) cpu.SetDmaSettling(false);
    if (rtcEpoch) cpu.SetRtcEpoch(std::chrono::system_clock::time_point(std::chrono::seconds(*rtcEpoch)));
#ifdef ENABLE_PROFILING
    std::unique_ptr<Profiler> profiler;
    if (anyProfiling) {
        ProfilerOptions profile;
        profile.nandPath = positional[0];
        profile.buildInfo = BuildInfoJson();
        profile.marksPath = profileMarks;
        profile.tracePath = profileTrace;
        profile.censusPrefix = profileCensus;
        profile.perfFifo = perfFifo;
        profile.perfWindow = perfWindow;
        profile.until = profileUntil;
        profile.jitdump = perfJitdump;
        profile.counters = profileCounters;
        profile.probes = profileProbes;
        profile.markDigest = markDigest;
        if (!profileDumpDir.empty()) profile.dumpIrDir = profileDumpDir;
        for (size_t at = 0; !profileDumpIr.empty() && at <= profileDumpIr.size();) {
            const size_t comma = std::min(profileDumpIr.find(',', at), profileDumpIr.size());
            const std::string text = profileDumpIr.substr(at, comma - at);
            size_t used = 0;
            unsigned long long pc = 0;
            try { pc = std::stoull(text, &used, 16); } catch (const std::exception&) { used = 0; }
            if (used == 0 || used != text.size() || pc > 0xFFFFFFFFull)
                throw std::runtime_error("Invalid --profile-dump-ir PC: " + text);
            profile.dumpIrPcs.push_back(static_cast<uint32_t>(pc));
            at = comma + 1;
        }
        profile.checksumPath = profileChecksum;
        auto count = [](const std::string& text, const char* option, bool zero) {
            size_t used = 0;
            unsigned long long value = 0;
            bool parsed = text.find('-') == std::string::npos;
            try { if (parsed) value = std::stoull(text, &used); } catch (const std::exception&) { parsed = false; }
            if (!parsed || used != text.size() || (!zero && value == 0))
                throw std::runtime_error(std::string("Invalid ") + option + ": " + text);
            return static_cast<uint64_t>(value);
        };
        if (!profileChecksumEvery.empty())
            profile.checksumEvery = count(profileChecksumEvery, "--profile-checksum-every", false);
        if (!profileChecksumFrom.empty())
            profile.checksumFrom = count(profileChecksumFrom, "--profile-checksum-from", true);
        if (!profileEndCycles.empty())
            profile.endCycles = count(profileEndCycles, "--profile-end-cycles", false);
        if (!profileTraceEvents.empty()) {
            if (profileTrace.empty()) throw std::runtime_error("--profile-trace-events sizes --profile-trace: add it");
            profile.traceEvents = count(profileTraceEvents, "--profile-trace-events", false);
        }
        profiler = std::make_unique<Profiler>(profile, cpu, [] { cpuShouldStop.store(true); });
        cpu.SetProfiler(profiler.get());
        // The verified-frame mark sees exactly the pixels the frontend gets.
        if (profiler->WantsFrames()) display = std::make_shared<FrameTap>(display, *profiler);
    }
#endif
    cpu.AttachDisplay(display);
    cpu.AttachKeyboard(keyboard);
    // SPORT still drains DMA and advances its sample accounting without a
    // host sink. Avoid opening ALSA/PulseAudio devices on headless hosts.
    if (!headless) cpu.AttachAudioOutput(std::make_shared<MiniaudioOutput>(audioBufferMs));
    cpu.SetBootMode(0x0D); // Set BMODE to 0b1101, boot from NAND flash with port H

    auto loop = uvw::loop::get_default();
    // Its handles are made before the loop runs them, on its thread.
    USBIPServer usbipd(*loop, cpu.GetUSB());
    usbipd.Start();
    std::thread uvloop([loop]() {
        while (true) {
            loop->run();
        }
    });
    // Detached: this thread intentionally runs until process exit. A joinable
    // std::thread destroyed at return would call std::terminate, masking the
    // exit code of a clean quit/SIGTERM shutdown.
    uvloop.detach();

    // Load LDR file
    LDRParser parser;
    if (positional.size() > 1 && !parser.loadFile(positional[1])) {
        std::cerr << "Failed to load LDR file: " << positional[1] << std::endl;
        return 1;
    }

    // Load NAND Flash underlying storage
    auto nandFlash = std::make_shared<MT29F4G08>(cpu, positional[0], nandSnapshot);
    if (nandSnapshot)
        LogInfo("NAND flash image opened read-only (snapshot mode; guest writes will be discarded)");
    cpu.AttachNandFlash(nandFlash);

    uint64_t sensorVersion = UINT64_MAX; // forces the first headless push
    bool randomAccelSent = false;
    auto pushSensors = [&]() {
        const bool fixedAccel = headless && console->GetSensors().accelFixed;
        const bool sensorsChanged = headless && console->SensorVersion() != sensorVersion;
        // The random feed sends a sample, and so an ADXL interrupt, on every
        // host poll: how many, and at which guest instruction, depends on host
        // load. --deterministic sends one when the feed starts and on each
        // script change, so the guest sees the same samples on every run.
        const bool randomDue = !deterministic || !randomAccelSent || sensorsChanged;
        if (!fixedAccel && randomDue) {
            randomAccelSent = true;
            int16_t ax = static_cast<int16_t>((std::rand() % (540 - 50 + 1)) + 50); // ax in [50, 540]
            int16_t ay = static_cast<int16_t>((std::rand() % (-50 - (-540) + 1)) + (-540)); // ay in [-540, -50]
            int16_t az = static_cast<int16_t>((std::rand() % (874 - 75 + 1)) + 75); // az in [75, 874]
            cpu.SetAcceleration(ax, ay, az); // Placeholder for random accelerometer data
        }
        if (headless) {
            // Script-set sensors are pushed once per change; the CPU keeps the value.
            if (sensorsChanged) {
                const auto& sensors = console->GetSensors();
                if (sensors.accelFixed) cpu.SetAcceleration(sensors.ax, sensors.ay, sensors.az);
                cpu.SetPotentiometerValue(0xFF - sensors.volume);
                sensorVersion = console->SensorVersion();
            }
        } else {
            cpu.SetPotentiometerValue(0xFF - window->GetVolumeValue()); // Update potentiometer (volume) value
        }
    };
    // A script's leading commands (up to its first wait) take effect before
    // the CPU starts, so sensor values reach the guest at the same point of
    // every run instead of whenever the first host poll happens to land.
    if (headless) console->PollEvents();
    pushSensors();

    // Start CPU execution thread
    std::thread cpuThread;
    if (positional.size() > 1) {
        cpuThread = std::thread(LdrExecutionThread, std::ref(cpu), std::ref(parser));
    } else {
        // If no LDR file is provided, just run the CPU without loading any code
        cpuThread = std::thread(BootExcutionThread, std::ref(cpu));
    }

    // Main thread handles GLFW display or headless input. cpuShouldStop is in
    // the condition so SIGTERM/SIGINT and CPU thread exit end the loop too.
    int result = 0;
    try {
        while (!cpuShouldStop.load() && !(headless ? console->ShouldClose() : window->ShouldClose())) {
            if (headless) console->PollEvents();
            else window->PollEvents();
            pushSensors();

            // Preserve the existing host frame/input cadence, without a GL swap.
            std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60 FPS
        }
    } catch (const std::exception& e) {
        LogError("Headless input: %s", e.what());
        result = 1;
    }

    // Signal CPU thread to stop and wait for it
    LogInfo("Stopping CPU thread...");
    cpuShouldStop.store(true);
    cpuThread.join();
    if (cpu.Failed()) {
        LogError("Emulation stopped: CPU execution failed");
        result = 1;
    }
#ifdef ENABLE_PROFILING
    if (profiler && !profiler->Finish()) {
        LogError("Profiling output is incomplete");
        result = 1;
    }
#endif

    return result;
}

int main(int argc, char* argv[]) {
    try {
        return RunEmulator(argc, argv);
    } catch (const std::exception& e) {
        LogError("%s", e.what());
        return 1;
    }
}
