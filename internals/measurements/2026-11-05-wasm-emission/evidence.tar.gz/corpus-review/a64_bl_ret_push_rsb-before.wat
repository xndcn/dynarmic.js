(module
 (type $0 (func (param i32 i32) (result i32)))
 (type $1 (func (param i32 i32 i64 i64)))
 (import "e" "m" (memory $mimport$0 1))
 (import "e" "t" (table $timport$0 0 funcref))
 (import "e" "a64_raise" (func $fimport$0 (param i32 i32 i64 i64)))
 (export "f" (func $0))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (local $11 i32)
  (local $12 i32)
  (local $scratch i32)
  (local $scratch_14 i32)
  (local $scratch_15 i32)
  (local $scratch_16 i32)
  (local $scratch_17 i64)
  (local $scratch_18 i32)
  (local $scratch_19 i32)
  (local.set $2
   (i64.load offset=272
    (local.get $0)
   )
  )
  (local.set $3
   (i32.const 65536)
  )
  (block $block
   (local.set $2
    (i64.const 12292)
   )
   (drop
    (local.tee $5
     (i32.add
      (i32.add
       (local.get $1)
       (i32.shl
        (local.tee $4
         (i32.load offset=12
          (local.get $1)
         )
        )
        (i32.const 4)
       )
      )
      (i32.const 40)
     )
    )
   )
   (if
    (i64.eq
     (i64.load
      (local.get $5)
     )
     (i64.const 12292)
    )
    (then
    )
    (else
     (i64.store
      (local.get $5)
      (i64.const 12292)
     )
     (i32.store offset=8
      (local.get $5)
      (select
       (i32.load offset=8
        (i32.const 2146320)
       )
       (i32.const 0)
       (i64.eq
        (i64.load
         (i32.const 2146320)
        )
        (i64.const 12292)
       )
      )
     )
    )
   )
   (i32.store offset=12
    (local.get $1)
    (i32.and
     (i32.add
      (local.get $4)
      (i32.const 1)
     )
     (i32.const 7)
    )
   )
   (br $block)
   (unreachable)
  )
  (block $block1
   (local.set $6
    (local.get $2)
   )
   (i64.store offset=16
    (local.get $0)
    (local.get $6)
   )
   (local.set $7
    (i64.or
     (i64.and
      (i64.load offset=16
       (local.get $0)
      )
      (i64.const 72057594037927935)
     )
     (i64.shl
      (i64.extend_i32_u
       (i32.and
        (i32.load offset=8
         (local.get $0)
        )
        (i32.const 130547712)
       )
      )
      (i64.const 37)
     )
    )
   )
   (if
    (i64.eq
     (local.get $7)
     (i64.const 12292)
    )
    (then
     (i32.store offset=12
      (local.get $1)
      (i32.and
       (i32.sub
        (i32.load offset=12
         (local.get $1)
        )
        (i32.const 1)
       )
       (i32.const 7)
      )
     )
     (br $block1)
    )
   )
   (drop
    (local.tee $4
     (i32.add
      (i32.add
       (i32.shl
        (local.tee $5
         (i32.and
          (i32.sub
           (i32.load offset=12
            (local.get $1)
           )
           (i32.const 1)
          )
          (i32.const 7)
         )
        )
        (i32.const 4)
       )
       (local.get $1)
      )
      (i32.const 40)
     )
    )
   )
   (i32.store offset=12
    (local.get $1)
    (local.get $5)
   )
   (local.set $9
    (i64.eq
     (i64.load
      (local.get $4)
     )
     (i64.or
      (i64.and
       (i64.load offset=16
        (local.get $0)
       )
       (i64.const 72057594037927935)
      )
      (i64.shl
       (i64.extend_i32_u
        (i32.and
         (i32.load offset=8
          (local.get $0)
         )
         (i32.const 130547712)
        )
       )
       (i64.const 37)
      )
     )
    )
   )
   (if
    (local.get $9)
    (then
     (if
      (i32.and
       (i32.eqz
        (i32.eqz
         (local.tee $8
          (i32.load offset=8
           (local.get $4)
          )
         )
        )
       )
       (i32.eqz
        (i32.load
         (local.get $1)
        )
       )
      )
      (then
       (return_call_indirect (type $0)
        (local.get $0)
        (local.get $1)
        (block (result i32)
         (local.set $scratch
          (local.get $8)
         )
         (i64.store offset=272
          (local.get $0)
          (local.get $2)
         )
         (local.get $scratch)
        )
       )
      )
      (else
       (if
        (i32.eqz
         (local.get $8)
        )
        (then
         (i32.store offset=8
          (local.get $1)
          (i32.add
           (local.get $4)
           (i32.const 8)
          )
         )
        )
       )
       (return
        (block (result i32)
         (local.set $scratch_14
          (i32.const 0)
         )
         (i64.store offset=272
          (local.get $0)
          (local.get $2)
         )
         (local.get $scratch_14)
        )
       )
      )
     )
    )
    (else
     (local.set $10
      (i64.or
       (i64.and
        (i64.load offset=16
         (local.get $0)
        )
        (i64.const 72057594037927935)
       )
       (i64.shl
        (i64.extend_i32_u
         (i32.and
          (i32.load offset=8
           (local.get $0)
          )
          (i32.const 130547712)
         )
        )
        (i64.const 37)
       )
      )
     )
     (if
      (i32.and
       (i32.and
        (i64.eq
         (i64.load
          (local.tee $11
           (i32.add
            (i32.shl
             (i32.and
              (i32.xor
               (i32.shr_u
                (local.tee $11
                 (i32.wrap_i64
                  (local.get $10)
                 )
                )
                (i32.const 2)
               )
               (i32.shr_u
                (local.get $11)
                (i32.const 14)
               )
              )
              (i32.const 4095)
             )
             (i32.const 4)
            )
            (i32.const 2097152)
           )
          )
         )
         (local.get $10)
        )
        (i32.eqz
         (i32.eqz
          (local.tee $12
           (i32.load offset=8
            (local.get $11)
           )
          )
         )
        )
       )
       (i32.eqz
        (i32.load
         (local.get $1)
        )
       )
      )
      (then
       (return_call_indirect (type $0)
        (local.get $0)
        (local.get $1)
        (block (result i32)
         (local.set $scratch_15
          (local.get $12)
         )
         (i64.store offset=272
          (local.get $0)
          (local.get $2)
         )
         (local.get $scratch_15)
        )
       )
      )
     )
     (i32.store offset=16
      (local.get $1)
      (local.get $11)
     )
     (return
      (block (result i32)
       (local.set $scratch_16
        (i32.const 0)
       )
       (i64.store offset=272
        (local.get $0)
        (local.get $2)
       )
       (local.get $scratch_16)
      )
     )
    )
   )
   (unreachable)
  )
  (i64.store offset=16
   (local.get $0)
   (i64.const 12296)
  )
  (call $fimport$0
   (local.get $0)
   (local.get $1)
   (i64.const 12292)
   (block (result i64)
    (local.set $scratch_17
     (i64.const 8)
    )
    (i64.store offset=272
     (local.get $0)
     (local.get $2)
    )
    (local.get $scratch_17)
   )
  )
  (local.set $2
   (i64.load offset=272
    (local.get $0)
   )
  )
  (if
   (i32.load
    (local.get $1)
   )
   (then
    (local.set $3
     (i32.const 1)
    )
   )
  )
  (block $block2
   (br_if $block2
    (i32.eqz
     (i32.load
      (local.get $1)
     )
    )
   )
   (return
    (block (result i32)
     (local.set $scratch_18
      (i32.load
       (local.get $1)
      )
     )
     (i64.store offset=272
      (local.get $0)
      (local.get $2)
     )
     (local.get $scratch_18)
    )
   )
  )
  (return
   (block (result i32)
    (local.set $scratch_19
     (i32.const 0)
    )
    (i64.store offset=272
     (local.get $0)
     (local.get $2)
    )
    (local.get $scratch_19)
   )
  )
  (unreachable)
  (unreachable)
 )
 ;; custom section "compilationHints", size 2
)

