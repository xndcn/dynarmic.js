(module
 (type $0 (func (param i32 i32) (result i32)))
 (import "e" "m" (memory $mimport$0 1))
 (import "e" "t" (table $timport$0 0 funcref))
 (export "f" (func $0))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (local $11 i32)
  (local $12 i32)
  (local.set $4
   (i32.load
    (local.get $0)
   )
  )
  (local.set $2
   (i32.load offset=76
    (local.get $0)
   )
  )
  (local.set $3
   (i32.const 65536)
  )
  (block $block1
   (block $block
    (local.set $5
     (local.get $4)
    )
    (if
     (i32.and
      (i32.shr_u
       (local.get $5)
       (i32.const 30)
      )
      (i32.const 1)
     )
     (then
     )
     (else
      (br $block)
     )
    )
    (br $block1)
    (unreachable)
   )
   (block $block2
    (local.set $6
     (local.get $4)
    )
    (if
     (i32.eqz
      (i32.and
       (i32.shr_u
        (local.get $6)
        (i32.const 30)
       )
       (i32.const 1)
      )
     )
     (then
     )
     (else
      (br $block1)
     )
    )
    (br $block2)
    (unreachable)
   )
   (br $block1)
   (unreachable)
  )
  (local.set $7
   (local.get $2)
  )
  (local.set $6
   (local.get $7)
  )
  (i32.store offset=80
   (local.get $0)
   (i32.and
    (local.get $6)
    (select
     (i32.const -2)
     (i32.const -4)
     (i32.and
      (local.get $6)
      (i32.const 1)
     )
    )
   )
  )
  (i32.store offset=84
   (local.get $0)
   (i32.or
    (i32.const 0)
    (i32.and
     (local.get $6)
     (i32.const 1)
    )
   )
  )
  (drop
   (local.tee $5
    (i32.add
     (i32.add
      (i32.shl
       (local.tee $6
        (i32.and
         (i32.sub
          (i32.load offset=12
           (local.get $1)
          )
          (i32.const 1)
         )
         (i32.const 7)
        )
       )
       (i32.const 4)
      )
      (local.get $1)
     )
     (i32.const 40)
    )
   )
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $6)
  )
  (local.set $9
   (i64.eq
    (i64.load
     (local.get $5)
    )
    (i64.or
     (i64.extend_i32_u
      (i32.load offset=80
       (local.get $0)
      )
     )
     (i64.shl
      (i64.extend_i32_u
       (i32.load offset=84
        (local.get $0)
       )
      )
      (i64.const 32)
     )
    )
   )
  )
  (if
   (local.get $9)
   (then
    (if
     (i32.and
      (i32.eqz
       (i32.eqz
        (local.tee $8
         (i32.load offset=8
          (local.get $5)
         )
        )
       )
      )
      (i32.eqz
       (i32.load
        (local.get $1)
       )
      )
     )
     (then
      (return_call_indirect (type $0)
       (local.get $0)
       (local.get $1)
       (local.get $8)
      )
     )
     (else
      (if
       (i32.eqz
        (local.get $8)
       )
       (then
        (i32.store offset=8
         (local.get $1)
         (i32.add
          (local.get $5)
          (i32.const 8)
         )
        )
       )
      )
      (return
       (i32.const 0)
      )
     )
    )
   )
   (else
    (local.set $10
     (i64.or
      (i64.extend_i32_u
       (i32.load offset=80
        (local.get $0)
       )
      )
      (i64.shl
       (i64.extend_i32_u
        (i32.load offset=84
         (local.get $0)
        )
       )
       (i64.const 32)
      )
     )
    )
    (if
     (i32.and
      (i32.and
       (i64.eq
        (i64.load
         (local.tee $11
          (i32.add
           (i32.shl
            (i32.and
             (i32.xor
              (i32.shr_u
               (local.tee $11
                (i32.wrap_i64
                 (local.get $10)
                )
               )
               (i32.const 2)
              )
              (i32.shr_u
               (local.get $11)
               (i32.const 14)
              )
             )
             (i32.const 4095)
            )
            (i32.const 4)
           )
           (i32.const 2097152)
          )
         )
        )
        (local.get $10)
       )
       (i32.eqz
        (i32.eqz
         (local.tee $12
          (i32.load offset=8
           (local.get $11)
          )
         )
        )
       )
      )
      (i32.eqz
       (i32.load
        (local.get $1)
       )
      )
     )
     (then
      (return_call_indirect (type $0)
       (local.get $0)
       (local.get $1)
       (local.get $12)
      )
     )
    )
    (i32.store offset=16
     (local.get $1)
     (local.get $11)
    )
    (return
     (i32.const 0)
    )
   )
  )
  (unreachable)
  (unreachable)
 )
 ;; custom section "compilationHints", size 2
)

