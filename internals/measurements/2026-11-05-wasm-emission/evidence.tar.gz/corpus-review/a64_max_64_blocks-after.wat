(module
 (type $0 (func (param i32 i32) (result i32)))
 (import "e" "m" (memory $mimport$0 1))
 (import "e" "t" (table $timport$0 0 funcref))
 (export "f" (func $0))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.const 65536)
  )
  (block $block
   (br $block)
   (unreachable)
  )
  (block $block1
   (br $block1)
   (unreachable)
  )
  (block $block2
   (br $block2)
   (unreachable)
  )
  (block $block3
   (br $block3)
   (unreachable)
  )
  (block $block4
   (br $block4)
   (unreachable)
  )
  (block $block5
   (br $block5)
   (unreachable)
  )
  (block $block6
   (br $block6)
   (unreachable)
  )
  (block $block7
   (br $block7)
   (unreachable)
  )
  (block $block8
   (br $block8)
   (unreachable)
  )
  (block $block9
   (br $block9)
   (unreachable)
  )
  (block $block10
   (br $block10)
   (unreachable)
  )
  (block $block11
   (br $block11)
   (unreachable)
  )
  (block $block12
   (br $block12)
   (unreachable)
  )
  (block $block13
   (br $block13)
   (unreachable)
  )
  (block $block14
   (br $block14)
   (unreachable)
  )
  (block $block15
   (br $block15)
   (unreachable)
  )
  (block $block16
   (br $block16)
   (unreachable)
  )
  (block $block17
   (br $block17)
   (unreachable)
  )
  (block $block18
   (br $block18)
   (unreachable)
  )
  (block $block19
   (br $block19)
   (unreachable)
  )
  (block $block20
   (br $block20)
   (unreachable)
  )
  (block $block21
   (br $block21)
   (unreachable)
  )
  (block $block22
   (br $block22)
   (unreachable)
  )
  (block $block23
   (br $block23)
   (unreachable)
  )
  (block $block24
   (br $block24)
   (unreachable)
  )
  (block $block25
   (br $block25)
   (unreachable)
  )
  (block $block26
   (br $block26)
   (unreachable)
  )
  (block $block27
   (br $block27)
   (unreachable)
  )
  (block $block28
   (br $block28)
   (unreachable)
  )
  (block $block29
   (br $block29)
   (unreachable)
  )
  (block $block30
   (br $block30)
   (unreachable)
  )
  (block $block31
   (br $block31)
   (unreachable)
  )
  (block $block32
   (br $block32)
   (unreachable)
  )
  (block $block33
   (br $block33)
   (unreachable)
  )
  (block $block34
   (br $block34)
   (unreachable)
  )
  (block $block35
   (br $block35)
   (unreachable)
  )
  (block $block36
   (br $block36)
   (unreachable)
  )
  (block $block37
   (br $block37)
   (unreachable)
  )
  (block $block38
   (br $block38)
   (unreachable)
  )
  (block $block39
   (br $block39)
   (unreachable)
  )
  (block $block40
   (br $block40)
   (unreachable)
  )
  (block $block41
   (br $block41)
   (unreachable)
  )
  (block $block42
   (br $block42)
   (unreachable)
  )
  (block $block43
   (br $block43)
   (unreachable)
  )
  (block $block44
   (br $block44)
   (unreachable)
  )
  (block $block45
   (br $block45)
   (unreachable)
  )
  (block $block46
   (br $block46)
   (unreachable)
  )
  (block $block47
   (br $block47)
   (unreachable)
  )
  (block $block48
   (br $block48)
   (unreachable)
  )
  (block $block49
   (br $block49)
   (unreachable)
  )
  (block $block50
   (br $block50)
   (unreachable)
  )
  (block $block51
   (br $block51)
   (unreachable)
  )
  (block $block52
   (br $block52)
   (unreachable)
  )
  (block $block53
   (br $block53)
   (unreachable)
  )
  (block $block54
   (br $block54)
   (unreachable)
  )
  (block $block55
   (br $block55)
   (unreachable)
  )
  (block $block56
   (br $block56)
   (unreachable)
  )
  (block $block57
   (br $block57)
   (unreachable)
  )
  (block $block58
   (br $block58)
   (unreachable)
  )
  (block $block59
   (br $block59)
   (unreachable)
  )
  (block $block60
   (br $block60)
   (unreachable)
  )
  (block $block61
   (br $block61)
   (unreachable)
  )
  (block $block62
   (br $block62)
   (unreachable)
  )
  (i64.store offset=16
   (local.get $0)
   (i64.const 16640)
  )
  (if
   (i32.and
    (i32.eqz
     (i32.eqz
      (local.tee $3
       (i32.load
        (i32.const 1048828)
       )
      )
     )
    )
    (i32.eqz
     (i32.load
      (local.get $1)
     )
    )
   )
   (then
    (return_call_indirect (type $0)
     (local.get $0)
     (local.get $1)
     (local.get $3)
    )
   )
   (else
    (if
     (i32.eqz
      (local.get $3)
     )
     (then
      (i32.store offset=8
       (local.get $1)
       (i32.const 1048828)
      )
     )
    )
    (return
     (i32.const 0)
    )
   )
  )
  (unreachable)
  (unreachable)
 )
 ;; custom section "compilationHints", size 2
)

