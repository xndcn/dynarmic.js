(module
 (type $0 (func (param i32 i32 i64 i64)))
 (type $1 (func (param i32 i32) (result i32)))
 (import "e" "m" (memory $mimport$0 1))
 (import "e" "t" (table $timport$0 0 funcref))
 (import "e" "a64_raise" (func $fimport$0 (param i32 i32 i64 i64)))
 (export "f" (func $0))
 (func $0 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local.set $3
   (i32.load
    (local.get $0)
   )
  )
  (local.set $2
   (i32.const 65536)
  )
  (block $block1
   (block $block
    (local.set $4
     (local.get $3)
    )
    (if
     (i32.eqz
      (i32.and
       (i32.shr_u
        (local.get $4)
        (i32.const 30)
       )
       (i32.const 1)
      )
     )
     (then
      (br $block)
     )
     (else
      (br $block1)
     )
    )
    (unreachable)
   )
   (br $block1)
   (unreachable)
  )
  (i64.store offset=16
   (local.get $0)
   (i64.const 8200)
  )
  (call $fimport$0
   (local.get $0)
   (local.get $1)
   (i64.const 8196)
   (i64.const 8)
  )
  (local.set $3
   (i32.load
    (local.get $0)
   )
  )
  (if
   (i32.load
    (local.get $1)
   )
   (then
    (local.set $2
     (i32.const 1)
    )
   )
  )
  (block $block2
   (br_if $block2
    (i32.eqz
     (i32.load
      (local.get $1)
     )
    )
   )
   (return
    (i32.load
     (local.get $1)
    )
   )
  )
  (return
   (i32.const 0)
  )
  (unreachable)
  (unreachable)
 )
 ;; custom section "compilationHints", size 2
)

