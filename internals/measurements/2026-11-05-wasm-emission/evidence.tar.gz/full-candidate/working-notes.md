# a18df34 review 与 Wasm 生成优化（2026-11-05）

审阅对象是 `~/sandbox/xhalf/xhalf-re/xhalf-hle` 的
`a18df34bb1d450e1fae2f9fdcb038dfda0439f41`。五项优化的语义在现有调用契约下合理，
但性能数据不支持无条件移植。最终将 i32 专门化、local.tee 及常量地址访存限制在显式 board policy，
共享出口也保持 A32/Thumb opt-in 范围，并增强可写字节流引用的保护。
原应用仓库保持只读。

## Review

| 改动 | 判断与必要条件 | 本次落地范围 |
| --- | --- | --- |
| 共享 region 出口 | 将每个出口重复生成的寄存器/clock 提交移到一个 epilogue，可明显减少大 region 的代码；每个 originating exit 必须先物化 deferred NZCV，callback 的提交/重载屏障仍独立存在 | 仅 A32/Thumb 的 opt-in multi-entry fallback region，与参考提交一致 |
| 省略 board RSB 写入 | board return 已使用完整 descriptor 分派与 budget/halt/hook guards，不读取 speculative RSB；PushRSB IR 仍用于发现 region 内 continuation | A32/A64 board 路径；普通 RSB 继续工作 |
| 固定 carry 的 i32 加减 | ADD carry-in=0、SUB carry-in=1 时，C 分别为 result<a 和 a>=b，V 使用原有符号逻辑；同时存在 carry/overflow/NZCV consumers 时也需正确 | 仅 board 的共用 32-bit IR lowering；动态 ADC/SBC 及 64-bit lowering 保留原路径 |
| local.tee 合并 | 仅合并相邻完整指令，不能扫描原始字节模式；多字节 local index、栈效果和 mutation 都必须覆盖 | 仅 board 生成函数；可写 Body() 引用暴露后永久停止该 body 的合并；记录逻辑放在 .cpp 中以控制 host emitter 体积 |
| 常量地址访存 | 仅折叠页索引和 containment，不能缓存 live page pointer；保留 mask、absolute-offset 和 null/跨页 fallback | 仅 board 的 A32 page-table 路径，1/2/4/8-byte；flat-window 和 A64 地址规则保持原有实现 |

原 patch 的一个防御性缺口：非 const `Body()` 只清空一次 last-set 记录。
调用者可保留引用，在之后的 `LocalSet` 后原地改写字节，导致 `LocalGet` 仍按过期边界
进行合并。当前生产 emitter 没有这种调用，故不作为现有应用的错误结论；本次直接禁止
暴露可写引用后的合并，并验证 retained-reference 的场景。

共享出口的分支位于寄存器 cache 初始化之后，entry descriptor miss 仍在加载 cache 前
返回；tail-call 保存 function-table index，丢弃原本不变的 state/context 参数，统一
flush 后恢复这些参数。index=0 是未链接哨兵，已有 guards 保证不会作为有效 tail target。
初始化完整 cache 后，未执行到的寄存器写入路径也不会把未初始化值冲回 state。

参考提交的约 10% First Play 改善及 40.8% Wasm 输入缩减，是 16-block/512-IR、特定固件
与三个 Chromium pairs 的证据，不能推出本仓库的普遍吞吐收益。本次仍使用原有
64-block/2000-IR 限制，regionMultiEntry 默认关闭；没有引入 packing 或后续 commit 的
register-allocation 优化。

## 源码与测量身份

工作基线为 `0939fae` 加任务开始时已有的 pthread / 文档改动，见
[pre-existing.patch](pre-existing.patch)；这些改动在两边一致保留。
[baseline-source.json](baseline-source.json) 和 [candidate-source.json](candidate-source.json)
记录 backend 文件哈希；`baseline-artifacts.json` / `candidate-artifacts.json` 记录冻结产物。
构建为 Release，Emscripten 6.0.13，profiling 与 region diagnostics 均关闭。

两个冻结目录是 `/tmp/dynarmic-emission-before-20261105` 和
`/tmp/dynarmic-emission-scoped-20261105`。最初移植候选另留在 `/tmp/dynarmic-emission-after-20261105`，未限定范围的 out-of-line 候选在 `/tmp/dynarmic-emission-final-20261105`。`freeze.py` 可复制已构建的相同 hosts、CMake cache
及 compiler metadata。只限定 i32 / local.tee 的中间候选在 `/tmp/dynarmic-emission-board-20261105`。相同 benchmark 函数的原文及 SHA256 在
[benchmark-functions.json](benchmark-functions.json)；新增的正确性测试不进入计时函数。

性能采集前完成构建和自身的其他 emulator 测试；采集期间不运行这些工作。
Node 24.19.0、默认 V8 参数，i7-12700 的 governor 是 powersave，turbo 开启。
最终 cohort 固定 CPU 2；前面的候选和 `scoped-dual` 使用 affinity `2,4`，两种设置的数据分开报告。
这仍是有其他桌面任务的共享机器。每个进程保留冷态和全部八次热态运行；没有剔除慢值，
也没有声称八次运行已达到引擎稳态。字节数是 emitted Wasm，不能当作 native code/RSS。

## 功能验证

- 新增 192 次 A32 常量访存字节 oracle 检查，覆盖各宽度、非连续跨页、live remap、
  absolute-offset、pointer tags、null/observer/protection 与缺页异常。
- 扩展整数 oracle：固定/动态 carry、同时消费 C/V/NZCV，1,201,020 次通过。
- A32 共享出口在多种预算下，与逐指令执行的 16 个寄存器及 CPSR 比较；新增嵌套
  BL/BLX、栈恢复、board RSB 不写入和普通 RSB 回归；A64 也验证 board RSB 不写入。
- 初版不限定范围时，region 字节基准有三个 fixture 因 local.tee 缩小：398→388、202→200、646→640 bytes。
  逐项反汇编差异见 [corpus-review](corpus-review)，旧文件留在 [corpus-before](corpus-before)。
  新旧各 28 次 guest 语义检查通过；descriptor 选择和另外两个模块不变。
  最终改为 board policy 后，普通 corpus 逐字节恢复原基准，源树中的 corpus fixture、
  manifest 和 comparator 均恢复任务开始时的版本。

构建和最初的失败日志保留：第一次新增 host 编译遗漏 CreateA32Jit 的 boundary 参数，
修正为 nullptr；原生首次检查还包含上述预期的字节基准变更，复核后已更新并单独复跑通过。
它们不是有效性能样本。

最终 board 限定版的验证见 `scoped-native-tests.log`（24/24）、`scoped-wasm-tests.log`（11/11）、
`scoped-fuzz-corpus.log`（6/6）、`scoped-chromium-worker.json`（33 项）及
`scoped-firefox-worker.json`。整数 oracle 此时显式选择 board emission，确保新路径确实被执行。

首次完整严格回归 `regression.log` 为 fail=0，包含 21 个随机差分 campaign：24,300 个
oracle-accepted cases、22,459 次实际比较、1,841 个 unsupported、零 mismatch，所有原有
unsupported 比例门槛通过，汇总见 `fuzz-summary.json`。这次完整 gate 位于最初未限定范围的
候选；后续只改 helper 放置位置和 ordinary/board 选择，最终重新运行上述 CTest、corpus 和
双浏览器检查，没有把前一轮完整 gate 伪称为最终版本新跑的一轮。
未运行外部 CoreMark，也未重跑 xhalf 私有固件；浏览器检查是兼容性证据，性能表来自 Node。

## 初版候选与后续调整

最初直接移植版的 25 对默认配置在 call-return 的 compile-phase 比值为 1.1543，
略超既有 1.15 门槛；其 12 项热态吞吐门槛均通过。整批报告及最初 14 项共享负载的
10 对数据保留在 [initial](initial)，未将其作为最终通过批次。

进一步将 FuncBody::LocalGet/LocalSet 的实现从头文件移到 wasm_binary.cpp，避免在
每个 opcode emitter 展开 peephole bookkeeping。jit_callbench 宿主模块
从 1,911,939 降到 1,653,057 bytes（相对最初移植版减少 13.5%；原基线为 1,786,185）。
生成的五项固定 corpus 则与最初移植版保持逐字节一致。该候选的 50 对默认回归
记录在 [unscoped-out-of-line](unscoped-out-of-line)：call-return compile 比为 0.9088，
编译问题已解决，但 A32 flat-memory 热态吞吐比为 0.8824，仍不合格。

先将 i32 / local.tee 限制为 board policy；这个中间版本的 50 对数据在
[partly-scoped](partly-scoped)。A32 flat-memory 吞吐比恢复为 0.9994，但 Thumb page-table
仍为 0.9416，低于 0.95 门槛。因此最终也把 constant-address lookup 限制到 board，
使普通路径完整保留原有生成指令。最终 12 项普通负载的 emitted bytes 全部与基线一致，
所有五项优化都在显式 `boundary_state != nullptr` 的 board policy 下生效，共享出口还需
A32/Thumb multi-entry。最终 host 再次冻结、重新测量。
旧候选样本没有混入最终 cohort，也没有放宽 5% / 15% / 10% 门槛。

最终源码在双核 affinity `2,4` 下的 50 对结果保留在 [scoped-dual](scoped-dual)：
A32 flat-memory 吞吐比 0.8890 未过门槛，其他 11 项通过，12 项 bytes 比均为 1。
[default-code-check](default-code-check) 的实际模块反汇编确认该负载两版指令相同，
仅宿主地址常量统一重定位 +592 bytes。故不能把这些双核计时差异全部归因于某项指令优化，
前面逐步限定范围的过程也是保守选择，不是对每项独立性能影响的因果证明。

随后在 CPU 2 和 CPU 4 分别进行 30 对定向复核，配对时间比为 1.0066 和 0.9985，
均未复现双核的约 11% 损失。原始样本见 `flat-cpu2.json` / `flat-cpu4.json`。
这提示调度、频率、布局或引擎 tiering 仍可能影响短样本，不能据此断言唯一根因。
最后完整默认套件改为固定 CPU 2 的 25 对进程，共享套件也在同一 CPU 重新收集 10 对。
这是同机单核的局部性能检查，不是跨 affinity 的无回退保证；所有旧失败都保留。

一次自编采集器误按 A32 的 REGION_SAMPLE 前缀解析 A64_REGION_SAMPLE，
在第一个 A64 case 中止；保留 `regions-collector-failure.*` 作为工具失败证据，
不计入有效 cohort。修正解析前缀后从头采集，没有按时间选择样本。

## 复现

```sh
cmake --build build-native-region-sharing -j4
cmake --build build-em -j4
ctest --test-dir build-native-region-sharing --output-on-failure
ctest --test-dir build-em --output-on-failure
DYNARMIC_JS_TEST_ARTIFACTS="$PWD/test-results/new-emission-regression" \
  tests/regress.sh --strict build-em build-native-region-sharing
```

先以 `baseline-source.json` 对应源码构建并冻结，再以候选源码构建并冻结。下述命令应串行执行，
且输出路径必须不存在：

```sh
taskset -c 2 node tests/bench/run.mjs /tmp/dynarmic-emission-before-20261105/tests \
  --runs 5 --output /tmp/emission-before-template.json
taskset -c 2 node tests/bench/run.mjs /tmp/dynarmic-emission-scoped-20261105/tests \
  --runs 5 --output /tmp/emission-after-template.json
taskset -c 2 node tests/bench/paired_run.mjs fixed \
  /tmp/dynarmic-emission-before-20261105/tests /tmp/dynarmic-emission-scoped-20261105/tests \
  /tmp/emission-before-template.json /tmp/emission-after-template.json /tmp/emission-paired-fixed --runs 25
taskset -c 2 node internals/measurements/2026-11-05-wasm-emission/collect-regions.mjs \
  /tmp/dynarmic-emission-before-20261105/tests /tmp/dynarmic-emission-scoped-20261105/tests \
  /tmp/emission-regions.json 10
```
