"""Recompute summaries from every retained process; negative time change is faster."""
import json
import pathlib
import random
import statistics

root = pathlib.Path(__file__).resolve().parent
read = lambda name: json.loads((root / name).read_text())
median = statistics.median
rng = random.Random(0xa18df34)


def interval(values):
    boot = sorted(median(rng.choices(values, k=len(values))) for _ in range(10000))
    return [boot[250], boot[9749]]


before, after = [read(f'paired-fixed/fixed-{v}.json') for v in ['before', 'after']]
comparison = read('paired-fixed/fixed-comparison.json')
regions = read('regions.json')
assert regions['status'] == 'complete'
fixed_rows, region_rows = [], []
for a, b, gate in zip(before['cases'], after['cases'], comparison['cases']):
    assert a['name'] == b['name'] == gate['name']
    samples = lambda case, process: [s['ms'] for s in case['samples'] if s['process'] == process and s['phase'] == 'warm']
    ratios = [median(samples(b, i)) / median(samples(a, i)) for i in range(a['runs'])]
    fixed_rows.append({
        'name': a['name'], 'beforeMs': a['summary']['warmMedianMs'], 'afterMs': b['summary']['warmMedianMs'],
        'pairedTimeRatio': median(ratios), 'pairedTimeCI95': interval(ratios),
        'throughputRatio': b['summary']['warmMinstrPerSec'] / a['summary']['warmMinstrPerSec'],
        'byteRatio': b['summary']['emittedBytesMedian'] / a['summary']['emittedBytesMedian'],
        'compileRatio': b['summary']['coldCompileMedianMs'] / a['summary']['coldCompileMedianMs'],
        'gate': gate['pass'],
    })
for case in regions['cases']:
    ratios = []
    for i in range(regions['methodology']['rounds']):
        times = [median(next(t for t in case['trials'] if t['round'] == i and t['variant'] == v)['samples'][j]['ms']
                        for j in range(1, 9)) for v in ['before', 'after']]
        ratios.append(times[1] / times[0])
    assert median(ratios) == case['paired']['warm']['median']
    region_rows.append({
        'name': case['name'], 'beforeMs': case['before']['warmMs']['median'], 'afterMs': case['after']['warmMs']['median'],
        'pairedTimeRatio': median(ratios), 'pairedTimeCI95': interval(ratios),
        'pairedColdRatio': case['paired']['cold']['median'],
        'beforeBytes': case['before']['bytes']['median'], 'afterBytes': case['after']['bytes']['median'],
        'byteRatio': case['after']['bytes']['median'] / case['before']['bytes']['median'],
    })
summary = {'fixedGate': comparison['pass'], 'fixed': fixed_rows, 'regions': region_rows,
           'interval': '10000 percentile bootstrap resamples of per-round time ratios; process pair is the sampling unit; local screening only',
           'fixedProcesses': sum(c['runs'] for c in before['cases'] + after['cases']),
           'regionProcesses': sum(len(c['trials']) for c in regions['cases'])}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

lines = ['默认配置使用现有 comparator 门槛：吞吐损失≤5%、compile-phase 增长≤15%、bytes 增长≤10%。',
         '表中时间变化是逐轮配对比值的中位数减一；默认 gate 的吞吐比另按标准协议计算。', '',
         '| 默认负载 | before / after 热态 ms | 配对时间变化 | 95% 区间 | bytes 变化 | compile 比 | gate |',
         '| --- | ---: | ---: | ---: | ---: | ---: | --- |']
for row in fixed_rows:
    lo, hi = row['pairedTimeCI95']
    lines.append(f"| {row['name']} | {row['beforeMs']:.3f} / {row['afterMs']:.3f} | {(row['pairedTimeRatio']-1)*100:+.1f}% | {(lo-1)*100:+.1f}%～{(hi-1)*100:+.1f}% | {(row['byteRatio']-1)*100:+.1f}% | {row['compileRatio']:.3f} | {'pass' if row['gate'] else 'FAIL'} |")
lines += ['', '| 入口共享负载 | before / after 热态 ms | 配对时间变化 | 95% 区间 | before→after bytes | 配对冷态变化 |',
          '| --- | ---: | ---: | ---: | ---: | ---: |']
for row in region_rows:
    lo, hi = row['pairedTimeCI95']
    lines.append(f"| {row['name']} | {row['beforeMs']:.3f} / {row['afterMs']:.3f} | {(row['pairedTimeRatio']-1)*100:+.1f}% | {(lo-1)*100:+.1f}%～{(hi-1)*100:+.1f}% | {row['beforeBytes']:.0f}→{row['afterBytes']:.0f} | {(row['pairedColdRatio']-1)*100:+.1f}% |")
(root / 'results.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
