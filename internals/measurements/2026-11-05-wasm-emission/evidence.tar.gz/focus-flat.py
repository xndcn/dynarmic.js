import hashlib,json,pathlib,statistics,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
cpu=sys.argv[1]
output=root/f'flat-cpu{cpu}.json'
assert not output.exists()
hosts=[pathlib.Path('/tmp/dynarmic-emission-before-20261105/tests/jit_bench.js'),pathlib.Path('/tmp/dynarmic-emission-scoped-20261105/tests/jit_bench.js')]
report={'cpu':cpu,'rounds':30,'trials':[],'artifacts':[{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [host,host.with_suffix('.wasm')]} for host in hosts]}
try:
    for i in range(30):
        for variant in ([1,0] if i%2 else [0,1]):
            argv=['taskset','-c',cpu,'node',str(hosts[variant]),'2']
            r=subprocess.run(argv,capture_output=True,text=True,timeout=60)
            row={'round':i,'variant':variant,'argv':argv,'status':r.returncode,'stdout':r.stdout,'stderr':r.stderr}; report['trials'].append(row)
            assert r.returncode==0 and '\nPASS\n' in r.stdout and 'WRONG' not in r.stdout
            samples=[json.loads(line[10:]) for line in r.stdout.splitlines() if line.startswith('BENCHMARK ')]
            assert len(samples)==9 and [s['runIndex'] for s in samples]==list(range(9))
            assert all(s['compile']['blocks']==0 and s['compile']['bytes']==0 for s in samples[1:])
            row['warmMs']=statistics.median(s['ms'] for s in samples[1:])
    ratios=[next(t['warmMs'] for t in report['trials'] if t['round']==i and t['variant']==1)/next(t['warmMs'] for t in report['trials'] if t['round']==i and t['variant']==0) for i in range(30)]
    report['pairedTimeRatio']=statistics.median(ratios);report['ratios']=ratios
    report['warmMs']=[statistics.median(t['warmMs'] for t in report['trials'] if t['variant']==v) for v in [0,1]]
    report['complete']=True
finally:
    output.write_text(json.dumps(report,indent=2)+'\n')
print(report.get('pairedTimeRatio'),report.get('warmMs'))
