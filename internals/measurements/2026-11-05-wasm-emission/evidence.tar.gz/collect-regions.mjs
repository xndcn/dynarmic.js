// Compare frozen before/after artifacts. Build and test before collecting.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {hashFile, readBuildInfo, systemInfo} from '../../../tests/bench/environment.mjs';

const [before, after, output, count = '10'] = process.argv.slice(2);
const rounds = Number(count);
assert(before && after && output && !fs.existsSync(output));
assert(Number.isInteger(rounds) && rounds >= 5 && rounds <= 100);
assert(!process.env.DYN_DUMP_DIR && !process.env.NODE_OPTIONS && !process.env.DYNARMIC_REGION_WARMUP);
const dirs = [before, after].map(dir => path.resolve(dir));
const builds = dirs.map(dir => readBuildInfo(path.dirname(dir)).build);
assert.deepEqual(builds[0], builds[1]);
assert.equal(builds[0].profile, false); assert.equal(builds[0].regionDiagnostics, false);
const median = values => {
  const a = [...values].sort((a,b) => a-b), n = a.length;
  return (a[Math.floor(n/2)] + a[Math.floor((n-1)/2)])/2;
};
const stats = values => ({median: median(values), mad: median(values.map(v => Math.abs(v-median(values)))), values});
const cases = [
  ...[false,true].flatMap(thumb => [false,true].map(boundaries => ({
    name: `${thumb ? 'thumb' : 'arm'}-${boundaries ? 'boundaries' : 'chain'}`,
    file: 'a32_region_alias_test.js', argv: ['1',String(+thumb),String(+boundaries)], instructions: 2400,
  }))),
  ...[0,1,2].map(mode => ({name: `arm-memory-${mode}`, file: 'a32_region_alias_test.js',
    argv: ['1',String(mode),'0','loop'], instructions: 3082002, loop: true})),
  ...['chain','boundaries','memory-0','memory-1','memory-2','scalar','neon'].map(kind => ({
    name: `a64-${kind}`, file: 'a64_region_sharing_test.js',
    argv: ['2',kind.startsWith('memory') ? 'memory' : kind,kind.startsWith('memory') ? kind.slice(-1) : '0'],
    loop: !['chain','boundaries'].includes(kind),
    instructions: kind.startsWith('memory') ? 2568003 : kind === 'scalar' ? 4194308 : kind === 'neon' ? 4194310 : 2400,
  })),
].map(c => ({...c, trials: []}));
const identity = () => dirs.map(dir => Object.fromEntries(['a32_region_alias_test','a64_region_sharing_test']
  .flatMap(stem => ['.js','.wasm'].map(ext => [stem+ext,hashFile(path.join(dir,stem+ext))]))));
const policy = () => Object.fromEntries([2,4].map(cpu => [`cpu${cpu}`,
  fs.readFileSync(`/sys/devices/system/cpu/cpu${cpu}/cpufreq/scaling_governor`,'utf8').trim()])
  .concat([['noTurbo',fs.readFileSync('/sys/devices/system/cpu/intel_pstate/no_turbo','utf8').trim()]]));
const report = {schema:'dynarmic.js/emission-region-comparison-v1',timestamp:new Date().toISOString(),
  ...systemInfo(),build:builds[0],artifacts:identity(),cpuPolicyBefore:policy(),
  collectorSha256:hashFile(new URL(import.meta.url)),
  methodology:{rounds,freshProcesses:true,alternatingOrder:true,rotatingCases:true,warmSamples:8,
    untimedWarmups:0,certifiedSteadyState:false,regionSharing:true,
    validation:'Guest results, memory, exact ticks and zero warm compilation; benchmark function identity checked separately.'},cases};
try {
  for (let round=0; round<rounds; ++round) for (let j=0; j<cases.length; ++j) {
    const c = cases[(j+round)%cases.length];
    for (const variant of round%2 ? [1,0] : [0,1]) {
      const argv = [path.join(dirs[variant],c.file),...c.argv];
      const result = spawnSync(process.execPath,argv,{encoding:'utf8',timeout:60000});
      const trial = {round,variant:variant ? 'after' : 'before',argv,status:result.status,
        signal:result.signal,stdout:result.stdout,stderr:result.stderr};
      c.trials.push(trial);
      assert.equal(result.status,0,result.error?.message || result.stderr);
      assert(!/FAIL|WRONG/.test(result.stdout));
      const prefix = c.file.startsWith('a64') ? 'A64_REGION_SAMPLE ' : 'REGION_SAMPLE ';
      trial.samples = result.stdout.split('\n').filter(s => s.startsWith(prefix)).map(s => JSON.parse(s.slice(prefix.length)));
      assert.equal(trial.samples.length,9);
      trial.samples.forEach((s,i) => {
        assert.equal(s.sample,i); assert(s.ms>0 && Number.isFinite(s.ms));
        assert.equal(s.instructions,c.instructions*(c.loop || i===0 ? 1 : 1000));
        if (i) {assert.equal(s.blocks,0); assert.equal(s.bytes,0);}
      });
      assert.equal(trial.samples[0].blocks,1);
      console.log(`${round} ${c.name} ${trial.variant} warm=${median(trial.samples.slice(1).map(s=>s.ms)).toFixed(3)}`);
    }
  }
  assert.deepEqual(identity(),report.artifacts,'artifacts changed');
  report.cpuPolicyAfter=policy(); assert.deepEqual(report.cpuPolicyAfter,report.cpuPolicyBefore);
  for (const c of cases) {
    for (const variant of ['before','after']) {
      const trials=c.trials.filter(t=>t.variant===variant);
      c[variant]={coldMs:stats(trials.map(t=>t.samples[0].ms)),
        warmMs:stats(trials.map(t=>median(t.samples.slice(1).map(s=>s.ms)))),
        bytes:stats(trials.map(t=>t.samples[0].bytes))};
    }
    c.paired={};
    for (const metric of ['cold','warm']) c.paired[metric]=stats(Array.from({length:rounds},(_,round)=>{
      const time=variant=>{
        const samples=c.trials.find(t=>t.round===round && t.variant===variant).samples;
        return metric==='cold' ? samples[0].ms : median(samples.slice(1).map(s=>s.ms));
      };
      return time('after')/time('before');
    }));
  }
  report.status='complete';
} catch(error) {report.status='failed';report.error=String(error);throw error;}
finally {fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});}
