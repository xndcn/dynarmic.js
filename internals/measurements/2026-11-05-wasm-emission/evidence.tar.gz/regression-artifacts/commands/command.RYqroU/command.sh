/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/guest/neon_ref_log 
