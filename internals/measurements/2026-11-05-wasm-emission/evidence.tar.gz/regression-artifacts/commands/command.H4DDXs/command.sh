node /home/xiong/workspace/dynarmic.js/tests/ir/sat64.mjs sat64.wasm 
