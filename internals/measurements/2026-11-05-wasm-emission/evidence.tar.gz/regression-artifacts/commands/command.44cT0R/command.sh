node /home/xiong/workspace/dynarmic.js/tests/bench/cache_population_validate.mjs cache-population.json 
