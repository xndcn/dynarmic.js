node /home/xiong/workspace/dynarmic.js/tests/bench/browser_validate.mjs browser-benchmark.json 
