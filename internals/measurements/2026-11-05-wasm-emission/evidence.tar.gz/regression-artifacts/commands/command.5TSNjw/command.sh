node /home/xiong/workspace/dynarmic.js/tests/bench/run.mjs /home/xiong/workspace/dynarmic.js/build-em/tests --runs 5 --output benchmark.json 
