node /home/xiong/workspace/dynarmic.js/build-em/tests/a32_region_alias_test.js 
