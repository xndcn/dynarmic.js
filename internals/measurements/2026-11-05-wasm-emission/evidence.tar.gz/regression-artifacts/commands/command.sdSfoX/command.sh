node /home/xiong/workspace/dynarmic.js/build-em/tests/a64_region_sharing_test.js 
