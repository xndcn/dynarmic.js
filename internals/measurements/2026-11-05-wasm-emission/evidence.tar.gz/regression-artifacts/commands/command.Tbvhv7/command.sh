/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/arm_decoder_test 
