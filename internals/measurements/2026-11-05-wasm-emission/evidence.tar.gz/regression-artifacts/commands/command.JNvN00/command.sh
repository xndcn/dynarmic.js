python3 -c import\ unicorn\,\ capstone 
