node /home/xiong/workspace/dynarmic.js/tests/ir/smoke.mjs smoke.wasm 
