node /home/xiong/workspace/dynarmic.js/tests/ir/fp_edge_test.mjs /home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/fp_edge_test 
