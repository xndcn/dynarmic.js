node /home/xiong/workspace/dynarmic.js/build-em/tests/thumb_it_return_test.js 
