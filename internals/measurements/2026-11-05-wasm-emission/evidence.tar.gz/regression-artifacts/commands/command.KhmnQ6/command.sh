/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/sat64_ir sat64.wasm 
