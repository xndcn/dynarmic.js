node /home/xiong/workspace/dynarmic.js/build-em/tests/jit_runbin.js /home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/guest/neon6_log.bin 1 
