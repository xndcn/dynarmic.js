node /home/xiong/workspace/dynarmic.js/build-em/tests/smc_test.js /home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/guest/smc.bin 
