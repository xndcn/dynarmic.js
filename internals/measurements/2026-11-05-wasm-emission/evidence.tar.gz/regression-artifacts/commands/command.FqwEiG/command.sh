node /home/xiong/workspace/dynarmic.js/tests/bench/validate.mjs benchmark.json 
