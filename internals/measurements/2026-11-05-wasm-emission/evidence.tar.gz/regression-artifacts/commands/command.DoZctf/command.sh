node /home/xiong/workspace/dynarmic.js/build-em/tests/jit_demo.js 
