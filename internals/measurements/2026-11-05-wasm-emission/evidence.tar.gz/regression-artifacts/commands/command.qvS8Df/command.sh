/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/guest/neon2_ref_log 
