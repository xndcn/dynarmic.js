/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/tools/block_dump --raw loop 1010 dispatch-raw/b1010.wasm 
