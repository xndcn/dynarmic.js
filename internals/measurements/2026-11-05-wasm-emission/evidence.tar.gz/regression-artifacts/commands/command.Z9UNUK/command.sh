node /home/xiong/workspace/dynarmic.js/build-em/tests/instance_test.js 
