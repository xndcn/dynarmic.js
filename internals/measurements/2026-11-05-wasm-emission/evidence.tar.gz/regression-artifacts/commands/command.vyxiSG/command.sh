/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/smoke_ir smoke.wasm 
