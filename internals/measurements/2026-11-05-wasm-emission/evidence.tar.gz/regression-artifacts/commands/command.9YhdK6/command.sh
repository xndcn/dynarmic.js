node /home/xiong/workspace/dynarmic.js/build-em/tests/runtime_table_test.js 
