node /home/xiong/workspace/dynarmic.js/tests/ir/a32_memory_edge_test.mjs /home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/a32_memory_edge_test 
