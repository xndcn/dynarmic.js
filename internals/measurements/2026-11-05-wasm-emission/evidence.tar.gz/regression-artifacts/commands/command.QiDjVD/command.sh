node /home/xiong/workspace/dynarmic.js/build-em/tests/stats_test.js 
