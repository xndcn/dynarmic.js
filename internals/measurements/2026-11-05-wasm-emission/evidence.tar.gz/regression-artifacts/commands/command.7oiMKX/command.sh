node /home/xiong/workspace/dynarmic.js/examples/browser/bench.mjs /home/xiong/workspace/dynarmic.js/build-em/examples/browser 3 --json browser-benchmark.json 
