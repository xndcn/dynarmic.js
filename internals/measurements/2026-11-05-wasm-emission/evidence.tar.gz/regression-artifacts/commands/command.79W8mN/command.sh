python3 /home/xiong/workspace/dynarmic.js/examples/c-bench/reference.py --output c-bench-reference.json 
