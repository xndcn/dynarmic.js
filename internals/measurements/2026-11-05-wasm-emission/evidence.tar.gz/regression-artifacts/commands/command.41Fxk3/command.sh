node /home/xiong/workspace/dynarmic.js/build-em/tests/lifecycle_test.js 
