/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/tools/block_dump --raw loop 1000 dispatch-raw/b1000.wasm 
