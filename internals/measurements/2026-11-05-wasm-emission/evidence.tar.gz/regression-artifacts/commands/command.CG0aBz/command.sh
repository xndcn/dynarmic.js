/home/xiong/workspace/dynarmic.js/build-native-region-sharing/tests/wasm_binary_test . 
