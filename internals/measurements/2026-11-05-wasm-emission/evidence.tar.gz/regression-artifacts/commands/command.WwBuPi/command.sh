node /home/xiong/workspace/dynarmic.js/tests/bench/cache_validate.mjs cache-benchmark.json 
