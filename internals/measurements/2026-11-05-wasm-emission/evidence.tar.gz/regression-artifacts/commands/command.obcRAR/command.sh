node /home/xiong/workspace/dynarmic.js/tests/bench/cache_run.mjs /home/xiong/workspace/dynarmic.js/build-em/tests --runs 5 --output cache-benchmark.json 
