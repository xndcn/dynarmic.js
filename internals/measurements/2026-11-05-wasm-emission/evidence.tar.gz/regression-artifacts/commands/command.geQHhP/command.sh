node /home/xiong/workspace/dynarmic.js/build-em/tests/region_diagnostics_test.js 
