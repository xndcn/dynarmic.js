.file "/home/xiong/workspace/dynarmic.js/examples/c-bench/kernels.c";
	.section	.text.integer_mix,"ax",@progbits
	.align 4
.type _integer_mix, STT_FUNC;
_integer_mix:
	[--sp] = ( r7:6 );

	LINK 0;
	cc =R0==0;
	if cc jump .L2;
	R6.H = 25;
	R7.H = 15470;
	R2 = 0 (X);
	R6.L = 26125;
	R7.L = 62303;
.L3:
	R1 *= R6;
	R1 = R1 + R7;
	R3 = R1 >> 13;
	R1 = R3 ^ R1;
	R3 = R1 << 7;
	R1 >>= 25;
	R2 += 1;
	R1 = R1 | R3;
	cc =R0<=R2 (iu);
	if !cc jump .L3 (bp);
.L2:
	UNLINK;
	R0 = R1;
	( r7:6 ) = [sp++];

	rts;
	.size	_integer_mix, .-_integer_mix
	.section	.text.branch_left,"ax",@progbits
	.align 4
.type _branch_left, STT_FUNC;
_branch_left:
	R1 = R0 >> 7;
	R1 = R1 ^ R0;
	P2 = R1;
	P1.H = 40503;
	P1.L = 31161;
	LINK 0;
	UNLINK;
	P2 = P2 + (P2 << 1);
	P1 = P2 + P1;
	R0 = P1;
	rts;
	.size	_branch_left, .-_branch_left
	.section	.text.branch_right,"ax",@progbits
	.align 4
.type _branch_right, STT_FUNC;
_branch_right:
	R1 = R0 << 5;
	R0 >>= 27;
	R0 = R1 | R0;
	R1.H = 32586;
	LINK 0;
	R1.L = 31765;
	R0 = R0 + R1;
	UNLINK;
	rts;
	.size	_branch_right, .-_branch_right
	.section	.text.branch_mix,"ax",@progbits
	.align 4
.type _branch_mix, STT_FUNC;
_branch_mix:
	[--sp] = ( r7:4, p5:5 );

	LINK 12;
	R5 = R0;
	cc =R0==0;
	if cc jump .L14;
	R4.H = 25;
	P5.H = 15470;
	R7 = R1;
	R0 = R1;
	R6 = 0 (X);
	R4.L = 26125;
	P5.L = 62303;
	jump.s .L13;
.L11:
	R0 = R7 + R0;
	call _branch_right;
	R6 += 1;
	cc =R5<=R6 (iu);
	if cc jump .L16;
.L13:
	R7 *= R4;
	R1 = P5;
	R7 = R7 + R1;
	cc =R7<0;
	if !cc jump .L11 (bp);
	R0 = R7 ^ R0;
	call _branch_left;
	R6 += 1;
	cc =R5<=R6 (iu);
	if !cc jump .L13 (bp);
.L16:
	R0 = R7 ^ R0;
.L10:
	UNLINK;
	( r7:4, p5:5 ) = [sp++];

	rts;
.L14:
	R0 = 0 (X);
	jump.s .L10;
	.size	_branch_mix, .-_branch_mix
	.section	.text.stream_array,"ax",@progbits
	.align 4
.type _stream_array, STT_FUNC;
_stream_array:
	[--sp] = ( r7:7 );

	LINK 0;
	cc =R0==0;
	if cc jump .L20;
	P0.H = _data;
	P1 = R1;
	R2 = 0 (X);
	P0.L = _data;
	R7 = 8191 (X);
.L19:
	R1 = R2 & R7;
	P2 = R1;
	P2 = P0 + (P2 << 2);
	R3 = [P2];
	R3 = R2 + R3;
	R1 = R3 >> 11;
	R1 = R1 ^ R3;
	[P2] = R1;
	P2 = R3;
	R2 += 1;
	cc =R0<=R2 (iu);
	P1 = P1 + P2;
	if !cc jump .L19 (bp);
.L18:
	R1 = 8191 (X);
	R0 += -1;
	R0 = R0 & R1;
	P2 = R0;
	R1 = P1;
	UNLINK;
	( r7:7 ) = [sp++];

	P0 = P0 + (P2 << 2);
	R0 = [P0];
	R0 = R1 ^ R0;
	rts;
.L20:
	P0.H = _data;
	P1 = R1;
	P0.L = _data;
	jump.s .L18;
	.size	_stream_array, .-_stream_array
	.section	.text.pointer_chase,"ax",@progbits
	.align 4
.type _pointer_chase, STT_FUNC;
_pointer_chase:
	[--sp] = ( r7:7 );

	R2 = 8191 (X);
	LINK 0;
	R2 = R1 & R2;
	cc =R0==0;
	if cc jump .L23;
	P1.H = _data;
	R7.H = 40503;
	R3 = 0 (X);
	P1.L = _data;
	R7.L = 31161;
.L24:
	P0 = R2;
	R3 += 1;
	cc =R0<=R3 (iu);
	P2 = P1 + (P0 << 2);
	R2 = [P2];
	R1 = R2 ^ R1;
	R1 = R1 + R7;
	if !cc jump .L24 (bp);
.L23:
	UNLINK;
	R0 = R1 ^ R2;
	( r7:7 ) = [sp++];

	rts;
	.size	_pointer_chase, .-_pointer_chase
.global ___floatunsidf;
.global ___muldf3;
.global ___adddf3;
.global ___fixunsdfsi;
	.section	.text.float_dyadic,"ax",@progbits
	.align 4
.type _float_dyadic, STT_FUNC;
_float_dyadic:
	[--sp] = ( r7:4, p5:3 );

	LINK 20;
	[FP+36] = R0;
	cc =R0==0;
	if cc jump .L30;
	R6 = 0 (X);
	R7 = 0 (X);
	P3 = R1;
	R3 = 0 (X);
	R4 = R6;
	R5 = R7;
.L29:
	R1.H = 25;
	R0 = P3;
	R1.L = 26125;
	R0 *= R1;
	P1 = R0;
	P2.H = 15470;
	P2.L = 62303;
	[FP+-4] = R3;
	P3 = P1 + P2;
	R0 = P3;
	R0 >>= 22;
	call ___floatunsidf;
	R2 = 1013 (X);
	R2 <<= 20;
	[SP+12] = R2;
	R2 = 0 (X);
	call ___muldf3;
	P4 = R0;
	P5 = R1;
	R2 = ROT R0 BY 0 ||
	[SP+12] = R1 ||
	nop;
	call ___muldf3;
	R2 = ROT R0 BY 0 ||
	[SP+12] = R1 ||
	nop;
	R0 = R4;
	R1 = R5;
	call ___adddf3;
	P1.H = 16352;
	P1.L = 0;
	R4 = R0;
	R5 = R1;
	[SP+12] = P1;
	R2 = 0 (X);
	R0 = P4;
	R1 = P5;
	call ___adddf3;
	P2.H = 16336;
	P2.L = 0;
	[SP+12] = P2;
	R2 = 0 (X);
	call ___muldf3;
	[SP+12] = R1;
	R2 = R0;
	R0 = R6;
	R1 = R7;
	call ___adddf3;
	R6 = ROT R0 BY 0 ||
	R3 = [FP+-4] ||
	nop;
	R3 += 1;
	R0 = [FP+36];
	R7 = R1;
	cc =R0<=R3 (iu);
	if !cc jump .L29 (bp);
	R0 = 1027 (X);
	R0 <<= 20;
	[SP+12] = R0;
	R2 = 0 (X);
	R0 = R6;
	call ___muldf3;
	call ___fixunsdfsi;
	R6 = R0;
	R0 = 1029 (X);
	R0 <<= 20;
	[SP+12] = R0;
	R2 = 0 (X);
	R0 = R4;
	R1 = R5;
	call ___muldf3;
	call ___fixunsdfsi;
	R0 = R6 ^ R0;
.L28:
	R1 = P3;
	UNLINK;
	R0 = R0 ^ R1;
	( r7:4, p5:3 ) = [sp++];

	rts;
.L30:
	P3 = R1;
	R0 = 0 (X);
	jump.s .L28;
	.size	_float_dyadic, .-_float_dyadic
	.section	.text.bench_init,"ax",@progbits
	.align 4
.global _bench_init;
.type _bench_init, STT_FUNC;
_bench_init:
	[--sp] = ( r7:6, p5:3 );

	LINK 0;
	cc =R0<=4 (iu);
	if !cc jump .L41;
	cc =R1==0;
	if cc jump .L41;
	R3 = 15625 (X);
	R3 <<= 11;
	cc =R1<=R3 (iu);
	if !cc jump .L41;
	P2.H = _selected_case;
	P2.L = _selected_case;
	[P2] = R0;
	P2.H = _count;
	P2.L = _count;
	[P2] = R1;
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	[P2] = R2;
	cc =R0==2;
	if cc jump .L47;
	cc =R0==3;
	if cc jump .L48;
	R0 = 0 (X);
.L49:
	UNLINK;
	( r7:6, p5:3 ) = [sp++];

	rts;
.L41:
	UNLINK;
	R0 = 1 (X);
	( r7:6, p5:3 ) = [sp++];

	rts;
.L47:
	P1.H = _data;
	R1.H = 25;
	R0.H = 15470;
	P1.L = _data;
	R1.L = 26125;
	R0.L = 62303;
	P2 = 8192 (X);
	LSETUP (.L35, .L53) LC1 = P2;
.L35:
	R2 *= R1;
	R2 = R2 + R0;
.L53:
	[P1++] = R2;
	R0 = 0 (X);
	jump.s .L49;
.L48:
	P5.H = _order;
	P5.L = _order;
	P1 = P5;
	R0 = 0 (X);
	P2 = 8192 (X);
	LSETUP (.L36, .L52) LC1 = P2;
.L36:
	[P1++] = R0;
.L52:
	R0 += 1;
	P0.H = _order;
	P0.L = _order;
	P4 = P0;
	R6.H = 25;
	R7.H = 15470;
	P3 = P0;
	R6.L = 26125;
	R7.L = 62303;
	R3 = 8191 (X);
	P2 = 8192 (X);
	I0 = P4;
	LSETUP (.L37, .L51) LC1 = P2;
.L37:
	R2 *= R6;
	R2 = R2 + R7;
	R0 = R2 >> 8;
	R0 = R0 & R3;
	P1 = R0;
	R0 = [I0++];
	P1 = P0 + (P1 << 2);
	R1 = [P1];
	[P3++] = R1;
.L51:
	[P1] = R0;
	P3.H = _data;
	R0 = 0 (X);
	P3.L = _data;
	R2 = 8191 (X);
	P2 = 8192 (X);
	LSETUP (.L38, .L50) LC1 = P2;
.L38:
	R0 += 1;
	R1 = R0 & R2;
	P4 = R1;
	P1 = [P5++];
	P4 = P0 + (P4 << 2);
	P1 = P3 + (P1 << 2);
	R1 = [P4];
.L50:
	[P1] = R1;
	R0 = 0 (X);
	jump.s .L49;
	.size	_bench_init, .-_bench_init
	.section	.text.bench_run,"ax",@progbits
	.align 4
.global _bench_run;
.type _bench_run, STT_FUNC;
_bench_run:
	P2.H = _selected_case;
	LINK 0;
	P2.L = _selected_case;
	P2 = [P2];
	cc =P2<=4 (iu);
	if cc jump .L62 (bp);
	R0 = 0 (X);
	UNLINK;
	rts;
.L62:
	P1.H = .L61;
	P1.L = .L61;
	P2 = P1 + (P2 << 2);
	P2 = [P2];
	jump (P2);
	.section	.rodata.bench_run,"a",@progbits
	.align 4
	.align 4
.L61:
	.dd	.L56;
	.dd	.L57;
	.dd	.L58;
	.dd	.L59;
	.dd	.L60;
	.section	.text.bench_run
.L59:
	P2.H = _count;
	P2.L = _count;
	R0 = [P2];
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	R1 = [P2];
	UNLINK;
	jump.l _pointer_chase;
.L60:
	P2.H = _count;
	P2.L = _count;
	R0 = [P2];
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	R1 = [P2];
	UNLINK;
	jump.l _float_dyadic;
.L56:
	P2.H = _count;
	P2.L = _count;
	R0 = [P2];
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	R1 = [P2];
	UNLINK;
	jump.l _integer_mix;
.L57:
	P2.H = _count;
	P2.L = _count;
	R0 = [P2];
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	R1 = [P2];
	UNLINK;
	jump.l _branch_mix;
.L58:
	P2.H = _count;
	P2.L = _count;
	R0 = [P2];
	P2.H = _initial_seed;
	P2.L = _initial_seed;
	R1 = [P2];
	UNLINK;
	jump.l _stream_array;
	.size	_bench_run, .-_bench_run
	.section	.bss.selected_case,"aw",@nobits
	.align 4
	.type	_selected_case, @object
	.size	_selected_case, 4
_selected_case:
	.zero	4
	.section	.bss.count,"aw",@nobits
	.align 4
	.type	_count, @object
	.size	_count, 4
_count:
	.zero	4
	.section	.bss.initial_seed,"aw",@nobits
	.align 4
	.type	_initial_seed, @object
	.size	_initial_seed, 4
_initial_seed:
	.zero	4
	.section	.bss.data,"aw",@nobits
	.align 4
	.type	_data, @object
	.size	_data, 32768
_data:
	.zero	32768
	.section	.bss.order,"aw",@nobits
	.align 4
	.type	_order, @object
	.size	_order, 32768
_order:
	.zero	32768
	.ident	"GCC: (ADI-2014R1_45-RC2) 4.5.3"
