// Minimal bare-metal host: the same mailbox and six calls as ARM/x86.
#include "core.h"
#include "flat_memory.h"
#include <emscripten.h>
#include <memory>
#include <string>
#include <cmath>
static std::string console;

using namespace bcore;
static CpuState cpu;
static double marks[12];
static unsigned mark_count;
static bool marker_error;
static uint8_t idle_wake;
static uint64_t cycles;
EM_JS(int, submit_tier_job, (uint32_t ticket, const uint8_t* bytes, uint32_t size), {
    return Module["bcoreSubmit"]?.(ticket >>> 0, HEAPU8.slice(bytes >>> 0, (bytes >>> 0) + (size >>> 0))) ? 1 : 0;
});
class BenchMemory final : public FlatMemory {
public:
    BenchMemory() : FlatMemory(0, 256 * 1024 * 1024, &cpu) {}
    uint32_t read32(uint32_t addr) const override {
        if(addr == 0x10000000) return uint32_t(uint64_t(emscripten_get_now()*1000.0));
        return FlatMemory::read32(addr);
    }
    void write32(uint32_t addr, uint32_t value) override {
        if(addr == 0x10000004) { if(console.size()<4*1024*1024) console.push_back(char(value)); return; }
        if (addr == 0x01000000) {
            if (mark_count >= 12 || value != (mark_count & 1)) marker_error = true;
            else marks[mark_count++] = emscripten_get_now();
        } else if (addr == 0x10000008) {
            cpu.halted = true;
            cpu.exit_code = value;
            cpu.chain_budget = 0;
        } else FlatMemory::write32(addr, value);
    }
};
static std::unique_ptr<BenchMemory> memory;
static std::unique_ptr<Core> core;
extern "C" {
EMSCRIPTEN_KEEPALIVE int bcore_init() {
    if (core) return -1; // One engine per fresh Worker.
    cpu_state_init(&cpu);
    cpu.pc = 0x10000;
    cpu.dpregs[14] = cpu.dpregs[15] = cpu.ksp = cpu.usp = 0x0fff0000;
    cpu.syscfg = 0x30;
    memory = std::make_unique<BenchMemory>();
    // Copy-and-patch requires page-table RAM (rawmem_limit == 0). Keeping
    // FlatMemory's raw inline mode would silently select LLVM instead.
    memory->enable_page_table();
    core = std::make_unique<Core>(&cpu, memory.get());
    core->set_chaining(true);
    core->set_count_chained(false);
    core->set_host_cycles(true);
    core->set_idle_waits(true, &idle_wake);
    core->set_chain_filter([](uint32_t pc) { return pc != 0xffa00000; });
    // Effective defaults include web/worker.js's override after op1_start:
    // copy-and-patch first, then remote LLVM promotion at 100000 / size 16.
    core->set_llvm_on_demand(true);
    core->set_copy_patch(true);
    core->set_tiering(100000, 16);
    if (!core->set_cold_threshold(10)) return -2;
    core->set_cold_batch(32, 65536);
    core->set_verify(false);
    return core->init(1, 2) ? 0 : -1;
}
EMSCRIPTEN_KEEPALIVE uint8_t* bcore_ram() { return memory->raw_mut(); }
EMSCRIPTEN_KEEPALIVE double* bcore_marks() { return marks; }
EMSCRIPTEN_KEEPALIVE unsigned bcore_mark_count() { return mark_count; }
EMSCRIPTEN_KEEPALIVE void bcore_remote_tier(int on) {
    if (!on) { core->set_remote_tier(nullptr); return; }
    core->set_remote_tier([](uint32_t ticket, std::vector<uint8_t> job) {
        return submit_tier_job(ticket, job.data(), uint32_t(job.size())) != 0;
    });
}
EMSCRIPTEN_KEEPALIVE int bcore_tier_delivered(uint32_t ticket, int ok, const char* name, uint32_t fallthrough) {
    return core->deliver(ticket, ok, {}, ok ? name : "", fallthrough);
}
EMSCRIPTEN_KEEPALIVE double bcore_remote_stat(int which) {
    const auto s = core->remote_stats();
    const uint64_t values[] = {s.submitted, s.refused, s.installed, s.stale, s.failed};
    return which >= 0 && which < 5 ? double(values[which]) : 0;
}
// OP-1 checks the wall clock every 32 dispatches or 100000 guest packets.
// With no devices, its chain limit is the only applicable guest deadline.
EMSCRIPTEN_KEEPALIVE int bcore_step(double budget_ms) {
    const double end = emscripten_get_now() + budget_ms;
    unsigned runs = 0;
    uint64_t from = cycles;
    while (!cpu.halted) {
        cpu.cycles[0] = uint32_t(cycles);
        cpu.cycles[1] = uint32_t(cycles >> 32);
        cpu.cycles[2] = cpu.cycles[1];
        cpu.chain_budget = 1u << 24;
        if (!core->run(cpu.pc)) return -2;
        cycles += cpu.chain_packets + cpu.packets;
        cpu.chain_packets = cpu.packets = cpu.chain_blocks = 0;
        cpu.did_jump = false;
        if (++runs >= 32 || cycles - from >= 100000) {
            if (emscripten_get_now() >= end && !cpu.halted) return 0;
            runs = 0; from = cycles;
        }
    }
    return cpu.exit_code ? -3 : 1;
}
}

extern "C" {
EMSCRIPTEN_KEEPALIVE const char* bcore_console() { return console.c_str(); }
EMSCRIPTEN_KEEPALIVE int bcore_exit_code() { return cpu.exit_code; }
}
