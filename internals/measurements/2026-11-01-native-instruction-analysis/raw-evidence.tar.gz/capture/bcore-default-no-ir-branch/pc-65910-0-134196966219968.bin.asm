
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65910-0-134196966219968.bin:     file format binary


Disassembly of section .data:

00007a0d2a8060c0 <.data>:
    7a0d2a8060c0:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a8060c7:	01 
    7a0d2a8060c8:	c2 08 00             	ret    0x8
    7a0d2a8060cb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7a0d2a8060d2:	92 01 01 00 
    7a0d2a8060d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8060dd:	02 00 00 00 
    7a0d2a8060e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8060e8:	03 00 00 00 
    7a0d2a8060ec:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a8060f3:	01 
    7a0d2a8060f4:	c2 08 00             	ret    0x8
    7a0d2a8060f7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d2a8060fe:	70 01 01 00 
    7a0d2a806102:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806109:	02 00 00 00 
    7a0d2a80610d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a806114:	08 00 00 00 
    7a0d2a806118:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a80611f:	01 
    7a0d2a806120:	c2 08 00             	ret    0x8
    7a0d2a806123:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d2a80612a:	10 01 01 00 
    7a0d2a80612e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806135:	04 00 00 00 
    7a0d2a806139:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a806140:	0a 00 00 00 
    7a0d2a806144:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a80614b:	01 
    7a0d2a80614c:	c2 08 00             	ret    0x8
