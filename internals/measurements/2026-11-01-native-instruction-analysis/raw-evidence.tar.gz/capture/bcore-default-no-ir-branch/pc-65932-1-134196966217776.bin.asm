
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65932-1-134196966217776.bin:     file format binary


Disassembly of section .data:

00007a0d2a805830 <.data>:
    7a0d2a805830:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a805836:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a805839:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80583f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a805846:	0f 87 75 eb ff e7    	ja     0x7a0d128043c1
    7a0d2a80584c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xe
    7a0d2a805853:	0e 00 00 00 
    7a0d2a805857:	e9 65 eb ff e7       	jmp    0x7a0d128043c1
    7a0d2a80585c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1018c
    7a0d2a805863:	8c 01 01 00 
    7a0d2a805867:	b8 8c 01 01 00       	mov    eax,0x1018c
    7a0d2a80586c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805873:	02 00 00 00 
    7a0d2a805877:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80587e:	01 00 00 00 
    7a0d2a805882:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a805885:	be 8c 01 01 00       	mov    esi,0x1018c
    7a0d2a80588a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80588d:	e8 ce a8 ff e7       	call   0x7a0d12800160
    7a0d2a805892:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805899:	00 
    7a0d2a80589a:	0f 84 9b eb ff e7    	je     0x7a0d1280443b
    7a0d2a8058a0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8058a7:	02 00 00 00 
    7a0d2a8058ab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8058b2:	01 00 00 00 
    7a0d2a8058b6:	58                   	pop    rax
    7a0d2a8058b7:	e9 a2 ee ff e7       	jmp    0x7a0d1280475e
    7a0d2a8058bc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1018e
    7a0d2a8058c3:	8e 01 01 00 
    7a0d2a8058c7:	b8 8e 01 01 00       	mov    eax,0x1018e
    7a0d2a8058cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8058d3:	02 00 00 00 
    7a0d2a8058d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8058de:	02 00 00 00 
    7a0d2a8058e2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8058e5:	be 8e 01 01 00       	mov    esi,0x1018e
    7a0d2a8058ea:	4c 89 ef             	mov    rdi,r13
    7a0d2a8058ed:	e8 6e a8 ff e7       	call   0x7a0d12800160
    7a0d2a8058f2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8058f9:	00 
    7a0d2a8058fa:	0f 84 a2 eb ff e7    	je     0x7a0d128044a2
    7a0d2a805900:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805907:	02 00 00 00 
    7a0d2a80590b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a805912:	02 00 00 00 
    7a0d2a805916:	58                   	pop    rax
    7a0d2a805917:	e9 42 ee ff e7       	jmp    0x7a0d1280475e
    7a0d2a80591c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10190
    7a0d2a805923:	90 01 01 00 
    7a0d2a805927:	b8 90 01 01 00       	mov    eax,0x10190
    7a0d2a80592c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805933:	02 00 00 00 
    7a0d2a805937:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80593e:	03 00 00 00 
    7a0d2a805942:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a805945:	be 90 01 01 00       	mov    esi,0x10190
    7a0d2a80594a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80594d:	e8 0e a8 ff e7       	call   0x7a0d12800160
    7a0d2a805952:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805959:	00 
    7a0d2a80595a:	0f 84 70 eb ff e7    	je     0x7a0d128044d0
    7a0d2a805960:	e9 aa eb ff e7       	jmp    0x7a0d1280450f
    7a0d2a805965:	b8 90 01 01 00       	mov    eax,0x10190
    7a0d2a80596a:	83 c0 ec             	add    eax,0xffffffec
    7a0d2a80596d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a805974:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80597b:	02 00 00 00 
    7a0d2a80597f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a805986:	03 00 00 00 
    7a0d2a80598a:	be 90 01 01 00       	mov    esi,0x10190
    7a0d2a80598f:	ba 90 01 01 00       	mov    edx,0x10190
    7a0d2a805994:	4c 89 ef             	mov    rdi,r13
    7a0d2a805997:	e8 c4 a7 ff e7       	call   0x7a0d12800160
    7a0d2a80599c:	e9 5f eb ff e7       	jmp    0x7a0d12804500
    7a0d2a8059a1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7a0d2a8059a8:	92 01 01 00 
    7a0d2a8059ac:	b8 92 01 01 00       	mov    eax,0x10192
    7a0d2a8059b1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8059b8:	02 00 00 00 
    7a0d2a8059bc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8059c3:	04 00 00 00 
    7a0d2a8059c7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8059ca:	be 92 01 01 00       	mov    esi,0x10192
    7a0d2a8059cf:	4c 89 ef             	mov    rdi,r13
    7a0d2a8059d2:	e8 89 a7 ff e7       	call   0x7a0d12800160
    7a0d2a8059d7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8059de:	00 
    7a0d2a8059df:	0f 84 a3 eb ff e7    	je     0x7a0d12804588
    7a0d2a8059e5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8059ec:	02 00 00 00 
    7a0d2a8059f0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8059f7:	04 00 00 00 
    7a0d2a8059fb:	58                   	pop    rax
    7a0d2a8059fc:	e9 5d ed ff e7       	jmp    0x7a0d1280475e
    7a0d2a805a01:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a805a08:	94 01 01 00 
    7a0d2a805a0c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805a13:	04 00 00 00 
    7a0d2a805a17:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805a1e:	05 00 00 00 
    7a0d2a805a22:	ba 94 01 01 00       	mov    edx,0x10194
    7a0d2a805a27:	4c 89 ef             	mov    rdi,r13
    7a0d2a805a2a:	4c 89 f6             	mov    rsi,r14
    7a0d2a805a2d:	89 d9                	mov    ecx,ebx
    7a0d2a805a2f:	45 31 c0             	xor    r8d,r8d
    7a0d2a805a32:	e8 49 a6 ff e7       	call   0x7a0d12800080
    7a0d2a805a37:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805a3e:	04 00 00 00 
    7a0d2a805a42:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805a49:	05 00 00 00 
    7a0d2a805a4d:	58                   	pop    rax
    7a0d2a805a4e:	e9 0b ed ff e7       	jmp    0x7a0d1280475e
    7a0d2a805a53:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a805a5a:	94 01 01 00 
    7a0d2a805a5e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805a65:	04 00 00 00 
    7a0d2a805a69:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805a70:	05 00 00 00 
    7a0d2a805a74:	4c 89 f7             	mov    rdi,r14
    7a0d2a805a77:	89 de                	mov    esi,ebx
    7a0d2a805a79:	e8 c2 a5 ff e7       	call   0x7a0d12800040
    7a0d2a805a7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805a85:	00 
    7a0d2a805a86:	75 af                	jne    0x7a0d2a805a37
    7a0d2a805a88:	41 89 c7             	mov    r15d,eax
    7a0d2a805a8b:	e9 2f eb ff e7       	jmp    0x7a0d128045bf
    7a0d2a805a90:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a805a97:	94 01 01 00 
    7a0d2a805a9b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805aa2:	04 00 00 00 
    7a0d2a805aa6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805aad:	05 00 00 00 
    7a0d2a805ab1:	4c 89 f7             	mov    rdi,r14
    7a0d2a805ab4:	e8 87 a5 ff e7       	call   0x7a0d12800040
    7a0d2a805ab9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805ac0:	00 
    7a0d2a805ac1:	0f 84 19 eb ff e7    	je     0x7a0d128045e0
    7a0d2a805ac7:	e9 6b ff ff ff       	jmp    0x7a0d2a805a37
    7a0d2a805acc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a805ad3:	94 01 01 00 
    7a0d2a805ad7:	b8 94 01 01 00       	mov    eax,0x10194
    7a0d2a805adc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805ae3:	04 00 00 00 
    7a0d2a805ae7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805aee:	05 00 00 00 
    7a0d2a805af2:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a805af5:	be 94 01 01 00       	mov    esi,0x10194
    7a0d2a805afa:	4c 89 ef             	mov    rdi,r13
    7a0d2a805afd:	e8 5e a6 ff e7       	call   0x7a0d12800160
    7a0d2a805b02:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805b09:	00 
    7a0d2a805b0a:	0f 84 04 eb ff e7    	je     0x7a0d12804614
    7a0d2a805b10:	e9 22 ff ff ff       	jmp    0x7a0d2a805a37
    7a0d2a805b15:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805b1c:	98 01 01 00 
    7a0d2a805b20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805b27:	02 00 00 00 
    7a0d2a805b2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805b32:	06 00 00 00 
    7a0d2a805b36:	ba 98 01 01 00       	mov    edx,0x10198
    7a0d2a805b3b:	4c 89 ef             	mov    rdi,r13
    7a0d2a805b3e:	4c 89 f6             	mov    rsi,r14
    7a0d2a805b41:	89 d9                	mov    ecx,ebx
    7a0d2a805b43:	45 31 c0             	xor    r8d,r8d
    7a0d2a805b46:	e8 35 a5 ff e7       	call   0x7a0d12800080
    7a0d2a805b4b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805b52:	02 00 00 00 
    7a0d2a805b56:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805b5d:	06 00 00 00 
    7a0d2a805b61:	58                   	pop    rax
    7a0d2a805b62:	e9 f7 eb ff e7       	jmp    0x7a0d1280475e
    7a0d2a805b67:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805b6e:	98 01 01 00 
    7a0d2a805b72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805b79:	02 00 00 00 
    7a0d2a805b7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805b84:	06 00 00 00 
    7a0d2a805b88:	4c 89 f7             	mov    rdi,r14
    7a0d2a805b8b:	89 de                	mov    esi,ebx
    7a0d2a805b8d:	e8 ae a4 ff e7       	call   0x7a0d12800040
    7a0d2a805b92:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805b99:	00 
    7a0d2a805b9a:	0f 84 aa ea ff e7    	je     0x7a0d1280464a
    7a0d2a805ba0:	eb a9                	jmp    0x7a0d2a805b4b
    7a0d2a805ba2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805ba9:	98 01 01 00 
    7a0d2a805bad:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805bb4:	02 00 00 00 
    7a0d2a805bb8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805bbf:	06 00 00 00 
    7a0d2a805bc3:	4c 89 f7             	mov    rdi,r14
    7a0d2a805bc6:	e8 75 a4 ff e7       	call   0x7a0d12800040
    7a0d2a805bcb:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805bd2:	00 
    7a0d2a805bd3:	0f 84 94 ea ff e7    	je     0x7a0d1280466d
    7a0d2a805bd9:	e9 6d ff ff ff       	jmp    0x7a0d2a805b4b
    7a0d2a805bde:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805be5:	98 01 01 00 
    7a0d2a805be9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805bf0:	02 00 00 00 
    7a0d2a805bf4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805bfb:	06 00 00 00 
    7a0d2a805bff:	4c 89 f7             	mov    rdi,r14
    7a0d2a805c02:	e8 39 a4 ff e7       	call   0x7a0d12800040
    7a0d2a805c07:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805c0e:	00 
    7a0d2a805c0f:	0f 84 7b ea ff e7    	je     0x7a0d12804690
    7a0d2a805c15:	e9 31 ff ff ff       	jmp    0x7a0d2a805b4b
    7a0d2a805c1a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805c21:	98 01 01 00 
    7a0d2a805c25:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805c2c:	02 00 00 00 
    7a0d2a805c30:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805c37:	06 00 00 00 
    7a0d2a805c3b:	4c 89 f7             	mov    rdi,r14
    7a0d2a805c3e:	e8 fd a3 ff e7       	call   0x7a0d12800040
    7a0d2a805c43:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805c4a:	00 
    7a0d2a805c4b:	0f 84 62 ea ff e7    	je     0x7a0d128046b3
    7a0d2a805c51:	e9 f5 fe ff ff       	jmp    0x7a0d2a805b4b
    7a0d2a805c56:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805c5d:	98 01 01 00 
    7a0d2a805c61:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805c68:	02 00 00 00 
    7a0d2a805c6c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805c73:	06 00 00 00 
    7a0d2a805c77:	4c 89 f7             	mov    rdi,r14
    7a0d2a805c7a:	e8 c1 a3 ff e7       	call   0x7a0d12800040
    7a0d2a805c7f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805c86:	00 
    7a0d2a805c87:	0f 84 4b ea ff e7    	je     0x7a0d128046d8
    7a0d2a805c8d:	e9 b9 fe ff ff       	jmp    0x7a0d2a805b4b
    7a0d2a805c92:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a805c99:	98 01 01 00 
    7a0d2a805c9d:	b8 98 01 01 00       	mov    eax,0x10198
    7a0d2a805ca2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805ca9:	02 00 00 00 
    7a0d2a805cad:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805cb4:	06 00 00 00 
    7a0d2a805cb8:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a805cbb:	be 98 01 01 00       	mov    esi,0x10198
    7a0d2a805cc0:	4c 89 ef             	mov    rdi,r13
    7a0d2a805cc3:	e8 98 a4 ff e7       	call   0x7a0d12800160
    7a0d2a805cc8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805ccf:	00 
    7a0d2a805cd0:	0f 84 2f ea ff e7    	je     0x7a0d12804705
    7a0d2a805cd6:	e9 70 fe ff ff       	jmp    0x7a0d2a805b4b
    7a0d2a805cdb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019a
    7a0d2a805ce2:	9a 01 01 00 
    7a0d2a805ce6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805ced:	02 00 00 00 
    7a0d2a805cf1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a805cf8:	07 00 00 00 
    7a0d2a805cfc:	4c 89 ef             	mov    rdi,r13
    7a0d2a805cff:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a805d04:	4c 89 f2             	mov    rdx,r14
    7a0d2a805d07:	e8 84 a3 ff e7       	call   0x7a0d12800090
    7a0d2a805d0c:	e9 36 ea ff e7       	jmp    0x7a0d12804747
    7a0d2a805d11:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805d18:	02 00 00 00 
    7a0d2a805d1c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a805d23:	07 00 00 00 
    7a0d2a805d27:	be 9a 01 01 00       	mov    esi,0x1019a
    7a0d2a805d2c:	ba 9a 01 01 00       	mov    edx,0x1019a
    7a0d2a805d31:	4c 89 ef             	mov    rdi,r13
    7a0d2a805d34:	e8 27 a4 ff e7       	call   0x7a0d12800160
    7a0d2a805d39:	e9 09 ea ff e7       	jmp    0x7a0d12804747
    7a0d2a805d3e:	c2 08 00             	ret    0x8
