
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65682-1-134196966207072.bin:     file format binary


Disassembly of section .data:

00007a0d2a802e60 <.data>:
    7a0d2a802e60:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a802e66:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a802e69:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a802e6f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a802e76:	0f 87 95 f2 ff e7    	ja     0x7a0d12802111
    7a0d2a802e7c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x4
    7a0d2a802e83:	04 00 00 00 
    7a0d2a802e87:	e9 85 f2 ff e7       	jmp    0x7a0d12802111
    7a0d2a802e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10092
    7a0d2a802e93:	92 00 01 00 
    7a0d2a802e97:	b8 92 00 01 00       	mov    eax,0x10092
    7a0d2a802e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802ea3:	02 00 00 00 
    7a0d2a802ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a802eae:	01 00 00 00 
    7a0d2a802eb2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802eb5:	be 92 00 01 00       	mov    esi,0x10092
    7a0d2a802eba:	4c 89 ef             	mov    rdi,r13
    7a0d2a802ebd:	e8 9e d2 ff e7       	call   0x7a0d12800160
    7a0d2a802ec2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802ec9:	00 
    7a0d2a802eca:	0f 84 9a f2 ff e7    	je     0x7a0d1280216a
    7a0d2a802ed0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802ed7:	02 00 00 00 
    7a0d2a802edb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a802ee2:	01 00 00 00 
    7a0d2a802ee6:	58                   	pop    rax
    7a0d2a802ee7:	e9 1c f4 ff e7       	jmp    0x7a0d12802308
    7a0d2a802eec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10094
    7a0d2a802ef3:	94 00 01 00 
    7a0d2a802ef7:	b8 94 00 01 00       	mov    eax,0x10094
    7a0d2a802efc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802f03:	02 00 00 00 
    7a0d2a802f07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a802f0e:	02 00 00 00 
    7a0d2a802f12:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802f15:	be 94 00 01 00       	mov    esi,0x10094
    7a0d2a802f1a:	4c 89 ef             	mov    rdi,r13
    7a0d2a802f1d:	e8 3e d2 ff e7       	call   0x7a0d12800160
    7a0d2a802f22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802f29:	00 
    7a0d2a802f2a:	0f 84 68 f2 ff e7    	je     0x7a0d12802198
    7a0d2a802f30:	e9 a2 f2 ff e7       	jmp    0x7a0d128021d7
    7a0d2a802f35:	b8 94 00 01 00       	mov    eax,0x10094
    7a0d2a802f3a:	83 c0 2c             	add    eax,0x2c
    7a0d2a802f3d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802f44:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802f4b:	02 00 00 00 
    7a0d2a802f4f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a802f56:	02 00 00 00 
    7a0d2a802f5a:	be 94 00 01 00       	mov    esi,0x10094
    7a0d2a802f5f:	ba 94 00 01 00       	mov    edx,0x10094
    7a0d2a802f64:	4c 89 ef             	mov    rdi,r13
    7a0d2a802f67:	e8 f4 d1 ff e7       	call   0x7a0d12800160
    7a0d2a802f6c:	e9 57 f2 ff e7       	jmp    0x7a0d128021c8
    7a0d2a802f71:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    7a0d2a802f78:	96 00 01 00 
    7a0d2a802f7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802f83:	02 00 00 00 
    7a0d2a802f87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a802f8e:	03 00 00 00 
    7a0d2a802f92:	ba 96 00 01 00       	mov    edx,0x10096
    7a0d2a802f97:	4c 89 ef             	mov    rdi,r13
    7a0d2a802f9a:	4c 89 f6             	mov    rsi,r14
    7a0d2a802f9d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a802fa3:	e8 d8 d0 ff e7       	call   0x7a0d12800080
    7a0d2a802fa8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802faf:	02 00 00 00 
    7a0d2a802fb3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a802fba:	03 00 00 00 
    7a0d2a802fbe:	58                   	pop    rax
    7a0d2a802fbf:	e9 44 f3 ff e7       	jmp    0x7a0d12802308
    7a0d2a802fc4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    7a0d2a802fcb:	96 00 01 00 
    7a0d2a802fcf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802fd6:	02 00 00 00 
    7a0d2a802fda:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a802fe1:	03 00 00 00 
    7a0d2a802fe5:	4c 89 f7             	mov    rdi,r14
    7a0d2a802fe8:	89 ce                	mov    esi,ecx
    7a0d2a802fea:	e8 81 d0 ff e7       	call   0x7a0d12800070
    7a0d2a802fef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802ff6:	00 
    7a0d2a802ff7:	0f 84 33 f2 ff e7    	je     0x7a0d12802230
    7a0d2a802ffd:	eb a9                	jmp    0x7a0d2a802fa8
    7a0d2a802fff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    7a0d2a803006:	96 00 01 00 
    7a0d2a80300a:	b8 96 00 01 00       	mov    eax,0x10096
    7a0d2a80300f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803016:	02 00 00 00 
    7a0d2a80301a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803021:	03 00 00 00 
    7a0d2a803025:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803028:	be 96 00 01 00       	mov    esi,0x10096
    7a0d2a80302d:	4c 89 ef             	mov    rdi,r13
    7a0d2a803030:	e8 2b d1 ff e7       	call   0x7a0d12800160
    7a0d2a803035:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a803038:	0f 84 23 f2 ff e7    	je     0x7a0d12802261
    7a0d2a80303e:	eb 0f                	jmp    0x7a0d2a80304f
    7a0d2a803040:	b8 96 00 01 00       	mov    eax,0x10096
    7a0d2a803045:	83 c0 02             	add    eax,0x2
    7a0d2a803048:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80304f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803056:	02 00 00 00 
    7a0d2a80305a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803061:	03 00 00 00 
    7a0d2a803065:	4c 89 ef             	mov    rdi,r13
    7a0d2a803068:	e8 e3 d0 ff e7       	call   0x7a0d12800150
    7a0d2a80306d:	e9 ef f1 ff e7       	jmp    0x7a0d12802261
    7a0d2a803072:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7a0d2a803079:	28 04 01 00 
    7a0d2a80307d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803084:	04 00 00 00 
    7a0d2a803088:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80308f:	04 00 00 00 
    7a0d2a803093:	be 98 00 01 00       	mov    esi,0x10098
    7a0d2a803098:	ba 98 00 01 00       	mov    edx,0x10098
    7a0d2a80309d:	4c 89 ef             	mov    rdi,r13
    7a0d2a8030a0:	e8 bb d0 ff e7       	call   0x7a0d12800160
    7a0d2a8030a5:	e9 3c f2 ff e7       	jmp    0x7a0d128022e6
    7a0d2a8030aa:	c2 08 00             	ret    0x8
