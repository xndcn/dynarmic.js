
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65904-0-134196966219073.bin:     file format binary


Disassembly of section .data:

00007a0d2a805d41 <.data>:
    7a0d2a805d41:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d2a805d48:	30 01 01 00 
    7a0d2a805d4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805d53:	04 00 00 00 
    7a0d2a805d57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a805d5e:	02 00 00 00 
    7a0d2a805d62:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a805d69:	01 
    7a0d2a805d6a:	c2 08 00             	ret    0x8
    7a0d2a805d6d:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a805d74:	01 
    7a0d2a805d75:	c2 08 00             	ret    0x8
