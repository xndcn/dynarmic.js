
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65840-0-134196966219128.bin:     file format binary


Disassembly of section .data:

00007a0d2a805d78 <.data>:
    7a0d2a805d78:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a805d7f:	01 
    7a0d2a805d80:	48 83 c4 38          	add    rsp,0x38
    7a0d2a805d84:	c2 08 00             	ret    0x8
    7a0d2a805d87:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a805d8e:	3c 01 01 00 
    7a0d2a805d92:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805d99:	04 00 00 00 
    7a0d2a805d9d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805da4:	05 00 00 00 
    7a0d2a805da8:	48 b8 e0 b8 82 06 01 	movabs rax,0x65010682b8e0
    7a0d2a805daf:	65 00 00 
    7a0d2a805db2:	4c 89 ef             	mov    rdi,r13
    7a0d2a805db5:	4c 89 de             	mov    rsi,r11
    7a0d2a805db8:	ba 3c 01 01 00       	mov    edx,0x1013c
    7a0d2a805dbd:	89 d9                	mov    ecx,ebx
    7a0d2a805dbf:	4d 89 de             	mov    r14,r11
    7a0d2a805dc2:	4c 89 c3             	mov    rbx,r8
    7a0d2a805dc5:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a805dcb:	ff d0                	call   rax
    7a0d2a805dcd:	49 89 d8             	mov    r8,rbx
    7a0d2a805dd0:	4d 89 f3             	mov    r11,r14
    7a0d2a805dd3:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a805dda:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a805de1:	00 
    7a0d2a805de2:	bb 05 00 00 00       	mov    ebx,0x5
    7a0d2a805de7:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a805dec:	e9 fe ec ff e7       	jmp    0x7a0d12804aef
    7a0d2a805df1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a805df8:	3c 01 01 00 
    7a0d2a805dfc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805e03:	04 00 00 00 
    7a0d2a805e07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805e0e:	05 00 00 00 
    7a0d2a805e12:	48 b8 20 56 71 06 01 	movabs rax,0x650106715620
    7a0d2a805e19:	65 00 00 
    7a0d2a805e1c:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    7a0d2a805e20:	4c 89 df             	mov    rdi,r11
    7a0d2a805e23:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    7a0d2a805e28:	89 de                	mov    esi,ebx
    7a0d2a805e2a:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    7a0d2a805e2f:	4c 89 c5             	mov    rbp,r8
    7a0d2a805e32:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    7a0d2a805e37:	4d 89 d4             	mov    r12,r10
    7a0d2a805e3a:	ff d0                	call   rax
    7a0d2a805e3c:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    7a0d2a805e40:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    7a0d2a805e45:	4d 89 e2             	mov    r10,r12
    7a0d2a805e48:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    7a0d2a805e4d:	49 89 e8             	mov    r8,rbp
    7a0d2a805e50:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    7a0d2a805e55:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a805e5c:	00 
    7a0d2a805e5d:	84 c9                	test   cl,cl
    7a0d2a805e5f:	0f 84 9f eb ff e7    	je     0x7a0d12804a04
    7a0d2a805e65:	e9 e0 00 00 00       	jmp    0x7a0d2a805f4a
    7a0d2a805e6a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a805e71:	3c 01 01 00 
    7a0d2a805e75:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805e7c:	04 00 00 00 
    7a0d2a805e80:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805e87:	05 00 00 00 
    7a0d2a805e8b:	48 b8 20 56 71 06 01 	movabs rax,0x650106715620
    7a0d2a805e92:	65 00 00 
    7a0d2a805e95:	89 fa                	mov    edx,edi
    7a0d2a805e97:	4c 89 df             	mov    rdi,r11
    7a0d2a805e9a:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    7a0d2a805e9f:	89 ee                	mov    esi,ebp
    7a0d2a805ea1:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    7a0d2a805ea6:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a805eab:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    7a0d2a805eb0:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    7a0d2a805eb5:	ff d0                	call   rax
    7a0d2a805eb7:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    7a0d2a805ebc:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    7a0d2a805ec1:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    7a0d2a805ec6:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a805ecb:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    7a0d2a805ed0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a805ed7:	00 
    7a0d2a805ed8:	84 c9                	test   cl,cl
    7a0d2a805eda:	0f 84 47 eb ff e7    	je     0x7a0d12804a27
    7a0d2a805ee0:	eb 68                	jmp    0x7a0d2a805f4a
    7a0d2a805ee2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10140
    7a0d2a805ee9:	40 01 01 00 
    7a0d2a805eed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805ef4:	04 00 00 00 
    7a0d2a805ef8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805eff:	05 00 00 00 
    7a0d2a805f03:	48 b8 10 b6 82 06 01 	movabs rax,0x65010682b610
    7a0d2a805f0a:	65 00 00 
    7a0d2a805f0d:	4c 89 ef             	mov    rdi,r13
    7a0d2a805f10:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    7a0d2a805f15:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a805f1a:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    7a0d2a805f1f:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    7a0d2a805f24:	ff d0                	call   rax
    7a0d2a805f26:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    7a0d2a805f2b:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    7a0d2a805f30:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a805f35:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    7a0d2a805f3a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a805f41:	00 
    7a0d2a805f42:	84 c9                	test   cl,cl
    7a0d2a805f44:	0f 84 ee ea ff e7    	je     0x7a0d12804a38
    7a0d2a805f4a:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a805f51:	e9 8c fe ff ff       	jmp    0x7a0d2a805de2
    7a0d2a805f56:	49 89 de             	mov    r14,rbx
    7a0d2a805f59:	4d 89 d4             	mov    r12,r10
    7a0d2a805f5c:	4c 89 cb             	mov    rbx,r9
    7a0d2a805f5f:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a805f64:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a805f6b:	46 01 01 00 
    7a0d2a805f6f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805f76:	04 00 00 00 
    7a0d2a805f7a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a805f81:	08 00 00 00 
    7a0d2a805f85:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a805f8c:	65 00 00 
    7a0d2a805f8f:	4d 89 df             	mov    r15,r11
    7a0d2a805f92:	4c 89 df             	mov    rdi,r11
    7a0d2a805f95:	89 ee                	mov    esi,ebp
    7a0d2a805f97:	ff d0                	call   rax
    7a0d2a805f99:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a805fa0:	00 
    7a0d2a805fa1:	84 c9                	test   cl,cl
    7a0d2a805fa3:	0f 85 c9 00 00 00    	jne    0x7a0d2a806072
    7a0d2a805fa9:	89 c5                	mov    ebp,eax
    7a0d2a805fab:	4d 89 fb             	mov    r11,r15
    7a0d2a805fae:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a805fb3:	49 89 d9             	mov    r9,rbx
    7a0d2a805fb6:	4d 89 e2             	mov    r10,r12
    7a0d2a805fb9:	4c 89 f3             	mov    rbx,r14
    7a0d2a805fbc:	e9 f0 ea ff e7       	jmp    0x7a0d12804ab1
    7a0d2a805fc1:	4d 89 cc             	mov    r12,r9
    7a0d2a805fc4:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a805fc9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a805fd0:	46 01 01 00 
    7a0d2a805fd4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805fdb:	04 00 00 00 
    7a0d2a805fdf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a805fe6:	08 00 00 00 
    7a0d2a805fea:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a805ff1:	65 00 00 
    7a0d2a805ff4:	4d 89 df             	mov    r15,r11
    7a0d2a805ff7:	4c 89 df             	mov    rdi,r11
    7a0d2a805ffa:	89 de                	mov    esi,ebx
    7a0d2a805ffc:	ff d0                	call   rax
    7a0d2a805ffe:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806005:	00 
    7a0d2a806006:	84 c9                	test   cl,cl
    7a0d2a806008:	75 68                	jne    0x7a0d2a806072
    7a0d2a80600a:	4d 89 fb             	mov    r11,r15
    7a0d2a80600d:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a806012:	4d 89 e1             	mov    r9,r12
    7a0d2a806015:	e9 b2 ea ff e7       	jmp    0x7a0d12804acc
    7a0d2a80601a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014a
    7a0d2a806021:	4a 01 01 00 
    7a0d2a806025:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80602c:	02 00 00 00 
    7a0d2a806030:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a806037:	09 00 00 00 
    7a0d2a80603b:	48 b8 e0 aa 82 06 01 	movabs rax,0x65010682aae0
    7a0d2a806042:	65 00 00 
    7a0d2a806045:	4c 89 ef             	mov    rdi,r13
    7a0d2a806048:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a80604d:	4c 89 da             	mov    rdx,r11
    7a0d2a806050:	4d 89 de             	mov    r14,r11
    7a0d2a806053:	4d 89 c7             	mov    r15,r8
    7a0d2a806056:	ff d0                	call   rax
    7a0d2a806058:	4d 89 f8             	mov    r8,r15
    7a0d2a80605b:	4d 89 f3             	mov    r11,r14
    7a0d2a80605e:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a806065:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a80606c:	00 
    7a0d2a80606d:	e9 7d ea ff e7       	jmp    0x7a0d12804aef
    7a0d2a806072:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a806079:	bb 08 00 00 00       	mov    ebx,0x8
    7a0d2a80607e:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a806083:	4d 89 fb             	mov    r11,r15
    7a0d2a806086:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a80608b:	e9 5f ea ff e7       	jmp    0x7a0d12804aef
