
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65910-1-134196563557056.bin:     file format binary


Disassembly of section .data:

00007a0d12803ac0 <.data>:
    7a0d12803ac0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803ac7:	8b 88 30 00 10 00    	mov    ecx,DWORD PTR [rax+0x100030]
    7a0d12803acd:	ff c1                	inc    ecx
    7a0d12803acf:	89 88 30 00 10 00    	mov    DWORD PTR [rax+0x100030],ecx
    7a0d12803ad5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d12803adb:	0f 84 3f 13 00 18    	je     0x7a0d2a804e20
    7a0d12803ae1:	50                   	push   rax
    7a0d12803ae2:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
    7a0d12803ae6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803aed:	31 d2                	xor    edx,edx
    7a0d12803aef:	89 c6                	mov    esi,eax
    7a0d12803af1:	ff c6                	inc    esi
    7a0d12803af3:	0f 94 c2             	sete   dl
    7a0d12803af6:	41 89 75 18          	mov    DWORD PTR [r13+0x18],esi
    7a0d12803afa:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803afd:	89 f7                	mov    edi,esi
    7a0d12803aff:	c1 ef 1f             	shr    edi,0x1f
    7a0d12803b02:	f7 d0                	not    eax
    7a0d12803b04:	21 f8                	and    eax,edi
    7a0d12803b06:	31 db                	xor    ebx,ebx
    7a0d12803b08:	85 f6                	test   esi,esi
    7a0d12803b0a:	0f 94 c3             	sete   bl
    7a0d12803b0d:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7a0d12803b14:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d12803b1b:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7a0d12803b22:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7a0d12803b29:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    7a0d12803b30:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7a0d12803b37:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7a0d12803b3e:	81 f9 76 01 01 00    	cmp    ecx,0x10176
    7a0d12803b44:	0f 84 02 13 00 18    	je     0x7a0d2a804e4c
    7a0d12803b4a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10176
    7a0d12803b51:	76 01 01 00 
    7a0d12803b55:	0f 84 f1 12 00 18    	je     0x7a0d2a804e4c
    7a0d12803b5b:	58                   	pop    rax
    7a0d12803b5c:	50                   	push   rax
    7a0d12803b5d:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    7a0d12803b61:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    7a0d12803b65:	31 d2                	xor    edx,edx
    7a0d12803b67:	31 f6                	xor    esi,esi
    7a0d12803b69:	31 ff                	xor    edi,edi
    7a0d12803b6b:	31 db                	xor    ebx,ebx
    7a0d12803b6d:	39 c8                	cmp    eax,ecx
    7a0d12803b6f:	0f 96 c2             	setbe  dl
    7a0d12803b72:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12803b79:	40 0f 94 c6          	sete   sil
    7a0d12803b7d:	40 0f 92 c7          	setb   dil
    7a0d12803b81:	0f 93 c3             	setae  bl
    7a0d12803b84:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d12803b8b:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d12803b92:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    7a0d12803b99:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    7a0d12803ba0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10178
    7a0d12803ba7:	78 01 01 00 
    7a0d12803bab:	0f 84 fb 12 00 18    	je     0x7a0d2a804eac
    7a0d12803bb1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10178
    7a0d12803bb8:	78 01 01 00 
    7a0d12803bbc:	0f 84 ea 12 00 18    	je     0x7a0d2a804eac
    7a0d12803bc2:	58                   	pop    rax
    7a0d12803bc3:	50                   	push   rax
    7a0d12803bc4:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12803bcb:	00 
    7a0d12803bcc:	74 55                	je     0x7a0d12803c23
    7a0d12803bce:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12803bd5:	01 
    7a0d12803bd6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1017a
    7a0d12803bdd:	7a 01 01 00 
    7a0d12803be1:	0f 84 25 13 00 18    	je     0x7a0d2a804f0c
    7a0d12803be7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017a
    7a0d12803bee:	7a 01 01 00 
    7a0d12803bf2:	0f 84 14 13 00 18    	je     0x7a0d2a804f0c
    7a0d12803bf8:	b8 7a 01 01 00       	mov    eax,0x1017a
    7a0d12803bfd:	83 c0 18             	add    eax,0x18
    7a0d12803c00:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12803c07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12803c0e:	02 00 00 00 
    7a0d12803c12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d12803c19:	03 00 00 00 
    7a0d12803c1d:	58                   	pop    rax
    7a0d12803c1e:	e9 e2 02 00 00       	jmp    0x7a0d12803f05
    7a0d12803c23:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1017a
    7a0d12803c2a:	7a 01 01 00 
    7a0d12803c2e:	0f 84 14 13 00 18    	je     0x7a0d2a804f48
    7a0d12803c34:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017a
    7a0d12803c3b:	7a 01 01 00 
    7a0d12803c3f:	0f 84 03 13 00 18    	je     0x7a0d2a804f48
    7a0d12803c45:	58                   	pop    rax
    7a0d12803c46:	50                   	push   rax
    7a0d12803c47:	41 8b 45 10          	mov    eax,DWORD PTR [r13+0x10]
    7a0d12803c4b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803c52:	41 0f af 45 1c       	imul   eax,DWORD PTR [r13+0x1c]
    7a0d12803c57:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12803c5b:	81 f9 7c 01 01 00    	cmp    ecx,0x1017c
    7a0d12803c61:	0f 84 2a 13 00 18    	je     0x7a0d2a804f91
    7a0d12803c67:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017c
    7a0d12803c6e:	7c 01 01 00 
    7a0d12803c72:	0f 84 19 13 00 18    	je     0x7a0d2a804f91
    7a0d12803c78:	58                   	pop    rax
    7a0d12803c79:	50                   	push   rax
    7a0d12803c7a:	41 8b 45 34          	mov    eax,DWORD PTR [r13+0x34]
    7a0d12803c7e:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803c85:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d12803c89:	81 f9 7e 01 01 00    	cmp    ecx,0x1017e
    7a0d12803c8f:	0f 84 5c 13 00 18    	je     0x7a0d2a804ff1
    7a0d12803c95:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017e
    7a0d12803c9c:	7e 01 01 00 
    7a0d12803ca0:	0f 84 4b 13 00 18    	je     0x7a0d2a804ff1
    7a0d12803ca6:	58                   	pop    rax
    7a0d12803ca7:	50                   	push   rax
    7a0d12803ca8:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d12803cac:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    7a0d12803cb0:	89 ca                	mov    edx,ecx
    7a0d12803cb2:	c1 ea 1f             	shr    edx,0x1f
    7a0d12803cb5:	89 c6                	mov    esi,eax
    7a0d12803cb7:	c1 ee 1f             	shr    esi,0x1f
    7a0d12803cba:	31 ff                	xor    edi,edi
    7a0d12803cbc:	01 c1                	add    ecx,eax
    7a0d12803cbe:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    7a0d12803cc2:	40 0f 92 c7          	setb   dil
    7a0d12803cc6:	89 c8                	mov    eax,ecx
    7a0d12803cc8:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803ccb:	31 c6                	xor    esi,eax
    7a0d12803ccd:	31 c2                	xor    edx,eax
    7a0d12803ccf:	21 f2                	and    edx,esi
    7a0d12803cd1:	31 f6                	xor    esi,esi
    7a0d12803cd3:	85 c9                	test   ecx,ecx
    7a0d12803cd5:	40 0f 94 c6          	sete   sil
    7a0d12803cd9:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d12803ce0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803ce7:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7a0d12803cee:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7a0d12803cf5:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7a0d12803cfc:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d12803d03:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12803d0a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10180
    7a0d12803d11:	80 01 01 00 
    7a0d12803d15:	0f 84 36 13 00 18    	je     0x7a0d2a805051
    7a0d12803d1b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10180
    7a0d12803d22:	80 01 01 00 
    7a0d12803d26:	0f 84 25 13 00 18    	je     0x7a0d2a805051
    7a0d12803d2c:	58                   	pop    rax
    7a0d12803d2d:	50                   	push   rax
    7a0d12803d2e:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7a0d12803d32:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803d39:	31 d2                	xor    edx,edx
    7a0d12803d3b:	85 c0                	test   eax,eax
    7a0d12803d3d:	0f 94 c2             	sete   dl
    7a0d12803d40:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803d43:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    7a0d12803d4a:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12803d51:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803d58:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d12803d5f:	00 00 00 
    7a0d12803d62:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d12803d69:	81 f9 82 01 01 00    	cmp    ecx,0x10182
    7a0d12803d6f:	0f 84 3c 13 00 18    	je     0x7a0d2a8050b1
    7a0d12803d75:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10182
    7a0d12803d7c:	82 01 01 00 
    7a0d12803d80:	0f 84 2b 13 00 18    	je     0x7a0d2a8050b1
    7a0d12803d86:	58                   	pop    rax
    7a0d12803d87:	50                   	push   rax
    7a0d12803d88:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12803d8f:	00 
    7a0d12803d90:	74 28                	je     0x7a0d12803dba
    7a0d12803d92:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10184
    7a0d12803d99:	84 01 01 00 
    7a0d12803d9d:	0f 84 6e 13 00 18    	je     0x7a0d2a805111
    7a0d12803da3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10184
    7a0d12803daa:	84 01 01 00 
    7a0d12803dae:	0f 84 5d 13 00 18    	je     0x7a0d2a805111
    7a0d12803db4:	58                   	pop    rax
    7a0d12803db5:	e9 55 00 00 00       	jmp    0x7a0d12803e0f
    7a0d12803dba:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12803dc1:	01 
    7a0d12803dc2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10184
    7a0d12803dc9:	84 01 01 00 
    7a0d12803dcd:	0f 84 87 13 00 18    	je     0x7a0d2a80515a
    7a0d12803dd3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10184
    7a0d12803dda:	84 01 01 00 
    7a0d12803dde:	0f 84 76 13 00 18    	je     0x7a0d2a80515a
    7a0d12803de4:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d12803de9:	83 c0 ec             	add    eax,0xffffffec
    7a0d12803dec:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12803df3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12803dfa:	02 00 00 00 
    7a0d12803dfe:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d12803e05:	08 00 00 00 
    7a0d12803e09:	58                   	pop    rax
    7a0d12803e0a:	e9 f6 00 00 00       	jmp    0x7a0d12803f05
    7a0d12803e0f:	50                   	push   rax
    7a0d12803e10:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12803e14:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803e1b:	31 d2                	xor    edx,edx
    7a0d12803e1d:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    7a0d12803e21:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12803e25:	0f 94 c2             	sete   dl
    7a0d12803e28:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803e2b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12803e32:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803e39:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12803e40:	00 00 00 00 
    7a0d12803e44:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12803e4b:	00 00 00 00 
    7a0d12803e4f:	81 f9 86 01 01 00    	cmp    ecx,0x10186
    7a0d12803e55:	0f 84 3b 13 00 18    	je     0x7a0d2a805196
    7a0d12803e5b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10186
    7a0d12803e62:	86 01 01 00 
    7a0d12803e66:	0f 84 2a 13 00 18    	je     0x7a0d2a805196
    7a0d12803e6c:	58                   	pop    rax
    7a0d12803e6d:	50                   	push   rax
    7a0d12803e6e:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12803e75:	b9 88 01 01 00       	mov    ecx,0x10188
    7a0d12803e7a:	83 c1 04             	add    ecx,0x4
    7a0d12803e7d:	89 ca                	mov    edx,ecx
    7a0d12803e7f:	3d 88 01 01 00       	cmp    eax,0x10188
    7a0d12803e84:	75 07                	jne    0x7a0d12803e8d
    7a0d12803e86:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d12803e8d:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12803e94:	02 
    7a0d12803e95:	0f 43 ca             	cmovae ecx,edx
    7a0d12803e98:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d12803e9f:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d12803ea6:	89 cf                	mov    edi,ecx
    7a0d12803ea8:	81 fa 88 01 01 00    	cmp    edx,0x10188
    7a0d12803eae:	75 07                	jne    0x7a0d12803eb7
    7a0d12803eb0:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d12803eb7:	83 fe 02             	cmp    esi,0x2
    7a0d12803eba:	0f 43 cf             	cmovae ecx,edi
    7a0d12803ebd:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d12803ec4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12803ecb:	01 
    7a0d12803ecc:	3d 88 01 01 00       	cmp    eax,0x10188
    7a0d12803ed1:	0f 84 1f 13 00 18    	je     0x7a0d2a8051f6
    7a0d12803ed7:	81 fa 88 01 01 00    	cmp    edx,0x10188
    7a0d12803edd:	0f 84 13 13 00 18    	je     0x7a0d2a8051f6
    7a0d12803ee3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12803eea:	10 01 01 00 
    7a0d12803eee:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d12803ef5:	04 00 00 00 
    7a0d12803ef9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d12803f00:	0a 00 00 00 
    7a0d12803f04:	58                   	pop    rax
    7a0d12803f05:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803f0c:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12803f13:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12803f1a:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12803f21:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12803f28:	39 f1                	cmp    ecx,esi
    7a0d12803f2a:	0f 83 fe 12 00 18    	jae    0x7a0d2a80522e
    7a0d12803f30:	81 fa 76 01 01 00    	cmp    edx,0x10176
    7a0d12803f36:	75 14                	jne    0x7a0d12803f4c
    7a0d12803f38:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803f3f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803f46:	00 
    7a0d12803f47:	e9 74 fb ff ff       	jmp    0x7a0d12803ac0
    7a0d12803f4c:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12803f53:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12803f59:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12803f5c:	0f 85 cc 12 00 18    	jne    0x7a0d2a80522e
    7a0d12803f62:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803f69:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803f70:	00 
    7a0d12803f71:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12803f76:	ff e0                	jmp    rax
