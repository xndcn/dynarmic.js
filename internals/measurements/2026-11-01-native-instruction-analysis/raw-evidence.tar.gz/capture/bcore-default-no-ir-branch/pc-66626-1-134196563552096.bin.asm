
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66626-1-134196563552096.bin:     file format binary


Disassembly of section .data:

00007a0d12802760 <.data>:
    7a0d12802760:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802767:	8b 88 18 00 10 00    	mov    ecx,DWORD PTR [rax+0x100018]
    7a0d1280276d:	ff c1                	inc    ecx
    7a0d1280276f:	89 88 18 00 10 00    	mov    DWORD PTR [rax+0x100018],ecx
    7a0d12802775:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280277b:	0f 84 ff 0e 00 18    	je     0x7a0d2a803680
    7a0d12802781:	50                   	push   rax
    7a0d12802782:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    7a0d12802787:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d1280278c:	09 c1                	or     ecx,eax
    7a0d1280278e:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7a0d12802792:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10442
    7a0d12802799:	42 04 01 00 
    7a0d1280279d:	0f 84 09 0f 00 18    	je     0x7a0d2a8036ac
    7a0d128027a3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10442
    7a0d128027aa:	42 04 01 00 
    7a0d128027ae:	0f 84 f8 0e 00 18    	je     0x7a0d2a8036ac
    7a0d128027b4:	58                   	pop    rax
    7a0d128027b5:	50                   	push   rax
    7a0d128027b6:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    7a0d128027bb:	c1 e0 10             	shl    eax,0x10
    7a0d128027be:	b9 9c 11 00 00       	mov    ecx,0x119c
    7a0d128027c3:	09 c1                	or     ecx,eax
    7a0d128027c5:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7a0d128027c9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10446
    7a0d128027d0:	46 04 01 00 
    7a0d128027d4:	0f 84 32 0f 00 18    	je     0x7a0d2a80370c
    7a0d128027da:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10446
    7a0d128027e1:	46 04 01 00 
    7a0d128027e5:	0f 84 21 0f 00 18    	je     0x7a0d2a80370c
    7a0d128027eb:	58                   	pop    rax
    7a0d128027ec:	50                   	push   rax
    7a0d128027ed:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    7a0d128027f1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128027f8:	c1 e0 02             	shl    eax,0x2
    7a0d128027fb:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    7a0d128027ff:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d12802803:	81 f9 4a 04 01 00    	cmp    ecx,0x1044a
    7a0d12802809:	0f 84 5d 0f 00 18    	je     0x7a0d2a80376c
    7a0d1280280f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044a
    7a0d12802816:	4a 04 01 00 
    7a0d1280281a:	0f 84 4c 0f 00 18    	je     0x7a0d2a80376c
    7a0d12802820:	58                   	pop    rax
    7a0d12802821:	50                   	push   rax
    7a0d12802822:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12802826:	f6 c1 03             	test   cl,0x3
    7a0d12802829:	0f 85 9d 0f 00 18    	jne    0x7a0d2a8037cc
    7a0d1280282f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12802836:	48 89 ca             	mov    rdx,rcx
    7a0d12802839:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d1280283d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12802841:	48 85 c0             	test   rax,rax
    7a0d12802844:	0f 84 d2 0f 00 18    	je     0x7a0d2a80381c
    7a0d1280284a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802850:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12802853:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d12802857:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044c
    7a0d1280285e:	4c 04 01 00 
    7a0d12802862:	0f 84 ef 0f 00 18    	je     0x7a0d2a803857
    7a0d12802868:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044c
    7a0d1280286f:	4c 04 01 00 
    7a0d12802873:	0f 84 de 0f 00 18    	je     0x7a0d2a803857
    7a0d12802879:	58                   	pop    rax
    7a0d1280287a:	50                   	push   rax
    7a0d1280287b:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    7a0d1280287f:	a8 01                	test   al,0x1
    7a0d12802881:	0f 85 19 10 00 18    	jne    0x7a0d2a8038a0
    7a0d12802887:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280288e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12802895:	01 
    7a0d12802896:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044e
    7a0d1280289d:	4e 04 01 00 
    7a0d128028a1:	0f 84 2f 10 00 18    	je     0x7a0d2a8038d6
    7a0d128028a7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044e
    7a0d128028ae:	4e 04 01 00 
    7a0d128028b2:	0f 84 1e 10 00 18    	je     0x7a0d2a8038d6
    7a0d128028b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d128028bf:	02 00 00 00 
    7a0d128028c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d128028ca:	05 00 00 00 
    7a0d128028ce:	58                   	pop    rax
    7a0d128028cf:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128028d6:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d128028dd:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d128028e4:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d128028eb:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d128028f2:	39 f1                	cmp    ecx,esi
    7a0d128028f4:	0f 83 09 10 00 18    	jae    0x7a0d2a803903
    7a0d128028fa:	81 fa 42 04 01 00    	cmp    edx,0x10442
    7a0d12802900:	75 14                	jne    0x7a0d12802916
    7a0d12802902:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802909:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802910:	00 
    7a0d12802911:	e9 4a fe ff ff       	jmp    0x7a0d12802760
    7a0d12802916:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d1280291d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12802923:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12802926:	0f 85 d7 0f 00 18    	jne    0x7a0d2a803903
    7a0d1280292c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802933:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d1280293a:	00 
    7a0d1280293b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12802940:	ff e0                	jmp    rax
