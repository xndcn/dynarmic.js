
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65904-0-134196563560416.bin:     file format binary


Disassembly of section .data:

00007a0d128047e0 <.data>:
    7a0d128047e0:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7a0d128047e7:	8d 82 8d fe fe ff    	lea    eax,[rdx-0x10173]
    7a0d128047ed:	83 f8 fc             	cmp    eax,0xfffffffc
    7a0d128047f0:	0f 87 77 15 00 18    	ja     0x7a0d2a805d6d
    7a0d128047f6:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    7a0d128047fd:	8d 81 8d fe fe ff    	lea    eax,[rcx-0x10173]
    7a0d12804803:	83 f8 fc             	cmp    eax,0xfffffffc
    7a0d12804806:	0f 87 61 15 00 18    	ja     0x7a0d2a805d6d
    7a0d1280480c:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7a0d12804813:	41 8b 75 00          	mov    esi,DWORD PTR [r13+0x0]
    7a0d12804817:	41 8b 7d 1c          	mov    edi,DWORD PTR [r13+0x1c]
    7a0d1280481b:	89 fb                	mov    ebx,edi
    7a0d1280481d:	c1 eb 1f             	shr    ebx,0x1f
    7a0d12804820:	89 f5                	mov    ebp,esi
    7a0d12804822:	c1 ed 1f             	shr    ebp,0x1f
    7a0d12804825:	31 c0                	xor    eax,eax
    7a0d12804827:	01 f7                	add    edi,esi
    7a0d12804829:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    7a0d1280482d:	0f 92 c0             	setb   al
    7a0d12804830:	89 fe                	mov    esi,edi
    7a0d12804832:	c1 ee 1f             	shr    esi,0x1f
    7a0d12804835:	31 f5                	xor    ebp,esi
    7a0d12804837:	31 f3                	xor    ebx,esi
    7a0d12804839:	21 eb                	and    ebx,ebp
    7a0d1280483b:	31 ed                	xor    ebp,ebp
    7a0d1280483d:	85 ff                	test   edi,edi
    7a0d1280483f:	40 0f 94 c5          	sete   bpl
    7a0d12804843:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    7a0d1280484a:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7a0d12804851:	41 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebx
    7a0d12804858:	41 89 9d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebx
    7a0d1280485f:	41 09 9d 00 01 00 00 	or     DWORD PTR [r13+0x100],ebx
    7a0d12804866:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    7a0d1280486d:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    7a0d12804874:	41 8b bd 98 00 00 00 	mov    edi,DWORD PTR [r13+0x98]
    7a0d1280487b:	be 76 01 01 00       	mov    esi,0x10176
    7a0d12804880:	bb 76 01 01 00       	mov    ebx,0x10176
    7a0d12804885:	81 fa 72 01 01 00    	cmp    edx,0x10172
    7a0d1280488b:	75 07                	jne    0x7a0d12804894
    7a0d1280488d:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    7a0d12804894:	83 ff 02             	cmp    edi,0x2
    7a0d12804897:	0f 43 f3             	cmovae esi,ebx
    7a0d1280489a:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    7a0d128048a1:	89 f7                	mov    edi,esi
    7a0d128048a3:	81 f9 72 01 01 00    	cmp    ecx,0x10172
    7a0d128048a9:	75 07                	jne    0x7a0d128048b2
    7a0d128048ab:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d128048b2:	83 fa 02             	cmp    edx,0x2
    7a0d128048b5:	0f 43 f7             	cmovae esi,edi
    7a0d128048b8:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    7a0d128048bf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d128048c6:	30 01 01 00 
    7a0d128048ca:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d128048d1:	83 c1 02             	add    ecx,0x2
    7a0d128048d4:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7a0d128048db:	39 c1                	cmp    ecx,eax
    7a0d128048dd:	0f 83 5e 14 00 18    	jae    0x7a0d2a805d41
    7a0d128048e3:	41 81 b8 80 09 08 00 	cmp    DWORD PTR [r8+0x80980],0x10130
    7a0d128048ea:	30 01 01 00 
    7a0d128048ee:	0f 85 4d 14 00 18    	jne    0x7a0d2a805d41
    7a0d128048f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d128048fb:	30 01 01 00 
    7a0d128048ff:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804906:	49 8b 80 88 09 08 00 	mov    rax,QWORD PTR [r8+0x80988]
    7a0d1280490d:	ff e0                	jmp    rax
