
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65868-1-134196966211008.bin:     file format binary


Disassembly of section .data:

00007a0d2a803dc0 <.data>:
    7a0d2a803dc0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a803dc6:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a803dc9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a803dcf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a803dd6:	0f 87 95 ee ff e7    	ja     0x7a0d12802c71
    7a0d2a803ddc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x8
    7a0d2a803de3:	08 00 00 00 
    7a0d2a803de7:	e9 85 ee ff e7       	jmp    0x7a0d12802c71
    7a0d2a803dec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803df3:	4c 01 01 00 
    7a0d2a803df7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803dfe:	02 00 00 00 
    7a0d2a803e02:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803e09:	01 00 00 00 
    7a0d2a803e0d:	ba 4c 01 01 00       	mov    edx,0x1014c
    7a0d2a803e12:	4c 89 ef             	mov    rdi,r13
    7a0d2a803e15:	4c 89 f6             	mov    rsi,r14
    7a0d2a803e18:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a803e1e:	e8 5d c2 ff e7       	call   0x7a0d12800080
    7a0d2a803e23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803e2a:	02 00 00 00 
    7a0d2a803e2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803e35:	01 00 00 00 
    7a0d2a803e39:	58                   	pop    rax
    7a0d2a803e3a:	e9 b6 f2 ff e7       	jmp    0x7a0d128030f5
    7a0d2a803e3f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803e46:	4c 01 01 00 
    7a0d2a803e4a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803e51:	02 00 00 00 
    7a0d2a803e55:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803e5c:	01 00 00 00 
    7a0d2a803e60:	4c 89 f7             	mov    rdi,r14
    7a0d2a803e63:	89 ce                	mov    esi,ecx
    7a0d2a803e65:	e8 06 c2 ff e7       	call   0x7a0d12800070
    7a0d2a803e6a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803e71:	00 
    7a0d2a803e72:	0f 84 38 ee ff e7    	je     0x7a0d12802cb0
    7a0d2a803e78:	eb a9                	jmp    0x7a0d2a803e23
    7a0d2a803e7a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803e81:	4c 01 01 00 
    7a0d2a803e85:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803e8c:	02 00 00 00 
    7a0d2a803e90:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803e97:	01 00 00 00 
    7a0d2a803e9b:	4c 89 f7             	mov    rdi,r14
    7a0d2a803e9e:	e8 cd c1 ff e7       	call   0x7a0d12800070
    7a0d2a803ea3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803eaa:	00 
    7a0d2a803eab:	0f 84 22 ee ff e7    	je     0x7a0d12802cd3
    7a0d2a803eb1:	e9 6d ff ff ff       	jmp    0x7a0d2a803e23
    7a0d2a803eb6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803ebd:	4c 01 01 00 
    7a0d2a803ec1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803ec8:	02 00 00 00 
    7a0d2a803ecc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803ed3:	01 00 00 00 
    7a0d2a803ed7:	4c 89 f7             	mov    rdi,r14
    7a0d2a803eda:	e8 91 c1 ff e7       	call   0x7a0d12800070
    7a0d2a803edf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803ee6:	00 
    7a0d2a803ee7:	0f 84 09 ee ff e7    	je     0x7a0d12802cf6
    7a0d2a803eed:	e9 31 ff ff ff       	jmp    0x7a0d2a803e23
    7a0d2a803ef2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803ef9:	4c 01 01 00 
    7a0d2a803efd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803f04:	02 00 00 00 
    7a0d2a803f08:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803f0f:	01 00 00 00 
    7a0d2a803f13:	4c 89 f7             	mov    rdi,r14
    7a0d2a803f16:	e8 55 c1 ff e7       	call   0x7a0d12800070
    7a0d2a803f1b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803f22:	00 
    7a0d2a803f23:	0f 84 f0 ed ff e7    	je     0x7a0d12802d19
    7a0d2a803f29:	e9 f5 fe ff ff       	jmp    0x7a0d2a803e23
    7a0d2a803f2e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803f35:	4c 01 01 00 
    7a0d2a803f39:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803f40:	02 00 00 00 
    7a0d2a803f44:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803f4b:	01 00 00 00 
    7a0d2a803f4f:	4c 89 f7             	mov    rdi,r14
    7a0d2a803f52:	89 de                	mov    esi,ebx
    7a0d2a803f54:	e8 17 c1 ff e7       	call   0x7a0d12800070
    7a0d2a803f59:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803f60:	00 
    7a0d2a803f61:	0f 84 d7 ed ff e7    	je     0x7a0d12802d3e
    7a0d2a803f67:	e9 b7 fe ff ff       	jmp    0x7a0d2a803e23
    7a0d2a803f6c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803f73:	4c 01 01 00 
    7a0d2a803f77:	b8 4c 01 01 00       	mov    eax,0x1014c
    7a0d2a803f7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803f83:	02 00 00 00 
    7a0d2a803f87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803f8e:	01 00 00 00 
    7a0d2a803f92:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803f95:	be 4c 01 01 00       	mov    esi,0x1014c
    7a0d2a803f9a:	4c 89 ef             	mov    rdi,r13
    7a0d2a803f9d:	e8 be c1 ff e7       	call   0x7a0d12800160
    7a0d2a803fa2:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a803fa6:	0f 84 c8 ed ff e7    	je     0x7a0d12802d74
    7a0d2a803fac:	eb 0f                	jmp    0x7a0d2a803fbd
    7a0d2a803fae:	b8 4c 01 01 00       	mov    eax,0x1014c
    7a0d2a803fb3:	83 c0 02             	add    eax,0x2
    7a0d2a803fb6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a803fbd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803fc4:	02 00 00 00 
    7a0d2a803fc8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803fcf:	01 00 00 00 
    7a0d2a803fd3:	4c 89 ef             	mov    rdi,r13
    7a0d2a803fd6:	e8 75 c1 ff e7       	call   0x7a0d12800150
    7a0d2a803fdb:	e9 94 ed ff e7       	jmp    0x7a0d12802d74
    7a0d2a803fe0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    7a0d2a803fe7:	4e 01 01 00 
    7a0d2a803feb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803ff2:	04 00 00 00 
    7a0d2a803ff6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a803ffd:	02 00 00 00 
    7a0d2a804001:	ba 4e 01 01 00       	mov    edx,0x1014e
    7a0d2a804006:	4c 89 ef             	mov    rdi,r13
    7a0d2a804009:	4c 89 f6             	mov    rsi,r14
    7a0d2a80400c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a804012:	e8 69 c0 ff e7       	call   0x7a0d12800080
    7a0d2a804017:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80401e:	04 00 00 00 
    7a0d2a804022:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804029:	02 00 00 00 
    7a0d2a80402d:	58                   	pop    rax
    7a0d2a80402e:	e9 c2 f0 ff e7       	jmp    0x7a0d128030f5
    7a0d2a804033:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    7a0d2a80403a:	4e 01 01 00 
    7a0d2a80403e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804045:	04 00 00 00 
    7a0d2a804049:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804050:	02 00 00 00 
    7a0d2a804054:	4c 89 f7             	mov    rdi,r14
    7a0d2a804057:	89 ce                	mov    esi,ecx
    7a0d2a804059:	e8 12 c0 ff e7       	call   0x7a0d12800070
    7a0d2a80405e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804065:	00 
    7a0d2a804066:	0f 84 5d ed ff e7    	je     0x7a0d12802dc9
    7a0d2a80406c:	eb a9                	jmp    0x7a0d2a804017
    7a0d2a80406e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    7a0d2a804075:	4e 01 01 00 
    7a0d2a804079:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804080:	04 00 00 00 
    7a0d2a804084:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80408b:	02 00 00 00 
    7a0d2a80408f:	4c 89 f7             	mov    rdi,r14
    7a0d2a804092:	89 de                	mov    esi,ebx
    7a0d2a804094:	44 89 e2             	mov    edx,r12d
    7a0d2a804097:	e8 d4 bf ff e7       	call   0x7a0d12800070
    7a0d2a80409c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8040a3:	00 
    7a0d2a8040a4:	0f 84 41 ed ff e7    	je     0x7a0d12802deb
    7a0d2a8040aa:	e9 68 ff ff ff       	jmp    0x7a0d2a804017
    7a0d2a8040af:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    7a0d2a8040b6:	4e 01 01 00 
    7a0d2a8040ba:	b8 4e 01 01 00       	mov    eax,0x1014e
    7a0d2a8040bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8040c6:	04 00 00 00 
    7a0d2a8040ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8040d1:	02 00 00 00 
    7a0d2a8040d5:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8040d8:	be 4e 01 01 00       	mov    esi,0x1014e
    7a0d2a8040dd:	4c 89 ef             	mov    rdi,r13
    7a0d2a8040e0:	e8 7b c0 ff e7       	call   0x7a0d12800160
    7a0d2a8040e5:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a8040e9:	0f 84 3d ed ff e7    	je     0x7a0d12802e2c
    7a0d2a8040ef:	eb 0f                	jmp    0x7a0d2a804100
    7a0d2a8040f1:	b8 4e 01 01 00       	mov    eax,0x1014e
    7a0d2a8040f6:	83 c0 04             	add    eax,0x4
    7a0d2a8040f9:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a804100:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804107:	04 00 00 00 
    7a0d2a80410b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804112:	02 00 00 00 
    7a0d2a804116:	4c 89 ef             	mov    rdi,r13
    7a0d2a804119:	e8 32 c0 ff e7       	call   0x7a0d12800150
    7a0d2a80411e:	e9 09 ed ff e7       	jmp    0x7a0d12802e2c
    7a0d2a804123:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10152
    7a0d2a80412a:	52 01 01 00 
    7a0d2a80412e:	b8 52 01 01 00       	mov    eax,0x10152
    7a0d2a804133:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80413a:	02 00 00 00 
    7a0d2a80413e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804145:	03 00 00 00 
    7a0d2a804149:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80414c:	be 52 01 01 00       	mov    esi,0x10152
    7a0d2a804151:	4c 89 ef             	mov    rdi,r13
    7a0d2a804154:	e8 07 c0 ff e7       	call   0x7a0d12800160
    7a0d2a804159:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804160:	00 
    7a0d2a804161:	0f 84 01 ed ff e7    	je     0x7a0d12802e68
    7a0d2a804167:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80416e:	02 00 00 00 
    7a0d2a804172:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804179:	03 00 00 00 
    7a0d2a80417d:	58                   	pop    rax
    7a0d2a80417e:	e9 72 ef ff e7       	jmp    0x7a0d128030f5
    7a0d2a804183:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10154
    7a0d2a80418a:	54 01 01 00 
    7a0d2a80418e:	b8 54 01 01 00       	mov    eax,0x10154
    7a0d2a804193:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80419a:	02 00 00 00 
    7a0d2a80419e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8041a5:	04 00 00 00 
    7a0d2a8041a9:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8041ac:	be 54 01 01 00       	mov    esi,0x10154
    7a0d2a8041b1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8041b4:	e8 a7 bf ff e7       	call   0x7a0d12800160
    7a0d2a8041b9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8041c0:	00 
    7a0d2a8041c1:	0f 84 fb ec ff e7    	je     0x7a0d12802ec2
    7a0d2a8041c7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8041ce:	02 00 00 00 
    7a0d2a8041d2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8041d9:	04 00 00 00 
    7a0d2a8041dd:	58                   	pop    rax
    7a0d2a8041de:	e9 12 ef ff e7       	jmp    0x7a0d128030f5
    7a0d2a8041e3:	b8 56 01 01 00       	mov    eax,0x10156
    7a0d2a8041e8:	83 c0 46             	add    eax,0x46
    7a0d2a8041eb:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8041f2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8041f9:	02 00 00 00 
    7a0d2a8041fd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804204:	05 00 00 00 
    7a0d2a804208:	be 56 01 01 00       	mov    esi,0x10156
    7a0d2a80420d:	ba 56 01 01 00       	mov    edx,0x10156
    7a0d2a804212:	4c 89 ef             	mov    rdi,r13
    7a0d2a804215:	e8 46 bf ff e7       	call   0x7a0d12800160
    7a0d2a80421a:	e9 d9 ec ff e7       	jmp    0x7a0d12802ef8
    7a0d2a80421f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10156
    7a0d2a804226:	56 01 01 00 
    7a0d2a80422a:	b8 56 01 01 00       	mov    eax,0x10156
    7a0d2a80422f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804236:	02 00 00 00 
    7a0d2a80423a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804241:	05 00 00 00 
    7a0d2a804245:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804248:	be 56 01 01 00       	mov    esi,0x10156
    7a0d2a80424d:	4c 89 ef             	mov    rdi,r13
    7a0d2a804250:	e8 0b bf ff e7       	call   0x7a0d12800160
    7a0d2a804255:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80425c:	00 
    7a0d2a80425d:	0f 84 e2 ec ff e7    	je     0x7a0d12802f45
    7a0d2a804263:	e9 9f ec ff e7       	jmp    0x7a0d12802f07
    7a0d2a804268:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10158
    7a0d2a80426f:	58 01 01 00 
    7a0d2a804273:	b8 58 01 01 00       	mov    eax,0x10158
    7a0d2a804278:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80427f:	04 00 00 00 
    7a0d2a804283:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a80428a:	06 00 00 00 
    7a0d2a80428e:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804291:	be 58 01 01 00       	mov    esi,0x10158
    7a0d2a804296:	4c 89 ef             	mov    rdi,r13
    7a0d2a804299:	e8 c2 be ff e7       	call   0x7a0d12800160
    7a0d2a80429e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8042a5:	00 
    7a0d2a8042a6:	0f 84 cd ec ff e7    	je     0x7a0d12802f79
    7a0d2a8042ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8042b3:	04 00 00 00 
    7a0d2a8042b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8042be:	06 00 00 00 
    7a0d2a8042c2:	58                   	pop    rax
    7a0d2a8042c3:	e9 2d ee ff e7       	jmp    0x7a0d128030f5
    7a0d2a8042c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1015c
    7a0d2a8042cf:	5c 01 01 00 
    7a0d2a8042d3:	b8 5c 01 01 00       	mov    eax,0x1015c
    7a0d2a8042d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8042df:	04 00 00 00 
    7a0d2a8042e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8042ea:	07 00 00 00 
    7a0d2a8042ee:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8042f1:	be 5c 01 01 00       	mov    esi,0x1015c
    7a0d2a8042f6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8042f9:	e8 62 be ff e7       	call   0x7a0d12800160
    7a0d2a8042fe:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804305:	00 
    7a0d2a804306:	0f 84 a1 ec ff e7    	je     0x7a0d12802fad
    7a0d2a80430c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804313:	04 00 00 00 
    7a0d2a804317:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a80431e:	07 00 00 00 
    7a0d2a804322:	58                   	pop    rax
    7a0d2a804323:	e9 cd ed ff e7       	jmp    0x7a0d128030f5
    7a0d2a804328:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10160
    7a0d2a80432f:	60 01 01 00 
    7a0d2a804333:	b8 60 01 01 00       	mov    eax,0x10160
    7a0d2a804338:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80433f:	02 00 00 00 
    7a0d2a804343:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a80434a:	08 00 00 00 
    7a0d2a80434e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804351:	be 60 01 01 00       	mov    esi,0x10160
    7a0d2a804356:	4c 89 ef             	mov    rdi,r13
    7a0d2a804359:	e8 02 be ff e7       	call   0x7a0d12800160
    7a0d2a80435e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804365:	00 
    7a0d2a804366:	0f 84 6f ec ff e7    	je     0x7a0d12802fdb
    7a0d2a80436c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804373:	02 00 00 00 
    7a0d2a804377:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a80437e:	08 00 00 00 
    7a0d2a804382:	58                   	pop    rax
    7a0d2a804383:	e9 6d ed ff e7       	jmp    0x7a0d128030f5
    7a0d2a804388:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10162
    7a0d2a80438f:	62 01 01 00 
    7a0d2a804393:	b8 62 01 01 00       	mov    eax,0x10162
    7a0d2a804398:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80439f:	02 00 00 00 
    7a0d2a8043a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8043aa:	09 00 00 00 
    7a0d2a8043ae:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8043b1:	be 62 01 01 00       	mov    esi,0x10162
    7a0d2a8043b6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8043b9:	e8 a2 bd ff e7       	call   0x7a0d12800160
    7a0d2a8043be:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8043c5:	00 
    7a0d2a8043c6:	0f 84 3d ec ff e7    	je     0x7a0d12803009
    7a0d2a8043cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8043d3:	02 00 00 00 
    7a0d2a8043d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8043de:	09 00 00 00 
    7a0d2a8043e2:	58                   	pop    rax
    7a0d2a8043e3:	e9 0d ed ff e7       	jmp    0x7a0d128030f5
    7a0d2a8043e8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10164
    7a0d2a8043ef:	64 01 01 00 
    7a0d2a8043f3:	b8 64 01 01 00       	mov    eax,0x10164
    7a0d2a8043f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8043ff:	02 00 00 00 
    7a0d2a804403:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a80440a:	0a 00 00 00 
    7a0d2a80440e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804411:	be 64 01 01 00       	mov    esi,0x10164
    7a0d2a804416:	4c 89 ef             	mov    rdi,r13
    7a0d2a804419:	e8 42 bd ff e7       	call   0x7a0d12800160
    7a0d2a80441e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804425:	00 
    7a0d2a804426:	0f 84 09 ec ff e7    	je     0x7a0d12803035
    7a0d2a80442c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804433:	02 00 00 00 
    7a0d2a804437:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a80443e:	0a 00 00 00 
    7a0d2a804442:	58                   	pop    rax
    7a0d2a804443:	e9 ad ec ff e7       	jmp    0x7a0d128030f5
    7a0d2a804448:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10166
    7a0d2a80444f:	66 01 01 00 
    7a0d2a804453:	b8 66 01 01 00       	mov    eax,0x10166
    7a0d2a804458:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80445f:	04 00 00 00 
    7a0d2a804463:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a80446a:	0b 00 00 00 
    7a0d2a80446e:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804471:	be 66 01 01 00       	mov    esi,0x10166
    7a0d2a804476:	4c 89 ef             	mov    rdi,r13
    7a0d2a804479:	e8 e2 bc ff e7       	call   0x7a0d12800160
    7a0d2a80447e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804485:	00 
    7a0d2a804486:	0f 84 e0 eb ff e7    	je     0x7a0d1280306c
    7a0d2a80448c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804493:	04 00 00 00 
    7a0d2a804497:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a80449e:	0b 00 00 00 
    7a0d2a8044a2:	58                   	pop    rax
    7a0d2a8044a3:	e9 4d ec ff e7       	jmp    0x7a0d128030f5
    7a0d2a8044a8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1016a
    7a0d2a8044af:	6a 01 01 00 
    7a0d2a8044b3:	b8 6a 01 01 00       	mov    eax,0x1016a
    7a0d2a8044b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8044bf:	04 00 00 00 
    7a0d2a8044c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8044ca:	0c 00 00 00 
    7a0d2a8044ce:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8044d1:	be 6a 01 01 00       	mov    esi,0x1016a
    7a0d2a8044d6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8044d9:	e8 82 bc ff e7       	call   0x7a0d12800160
    7a0d2a8044de:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8044e5:	00 
    7a0d2a8044e6:	0f 84 b7 eb ff e7    	je     0x7a0d128030a3
    7a0d2a8044ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8044f3:	04 00 00 00 
    7a0d2a8044f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8044fe:	0c 00 00 00 
    7a0d2a804502:	58                   	pop    rax
    7a0d2a804503:	e9 ed eb ff e7       	jmp    0x7a0d128030f5
    7a0d2a804508:	b8 6e 01 01 00       	mov    eax,0x1016e
    7a0d2a80450d:	83 c0 0e             	add    eax,0xe
    7a0d2a804510:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a804517:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80451e:	02 00 00 00 
    7a0d2a804522:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a804529:	0d 00 00 00 
    7a0d2a80452d:	be 6e 01 01 00       	mov    esi,0x1016e
    7a0d2a804532:	ba 6e 01 01 00       	mov    edx,0x1016e
    7a0d2a804537:	4c 89 ef             	mov    rdi,r13
    7a0d2a80453a:	e8 21 bc ff e7       	call   0x7a0d12800160
    7a0d2a80453f:	e9 8b eb ff e7       	jmp    0x7a0d128030cf
    7a0d2a804544:	c2 08 00             	ret    0x8
