
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65600-1-134196966198720.bin:     file format binary


Disassembly of section .data:

00007a0d2a800dc0 <.data>:
    7a0d2a800dc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    7a0d2a800dc7:	40 00 01 00 
    7a0d2a800dcb:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a800dd2:	01 
    7a0d2a800dd3:	c2 08 00             	ret    0x8
    7a0d2a800dd6:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a800ddc:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a800ddf:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a800de5:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a800dec:	0f 87 c8 fe ff e7    	ja     0x7a0d12800cba
    7a0d2a800df2:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x2
    7a0d2a800df9:	02 00 00 00 
    7a0d2a800dfd:	e9 b8 fe ff e7       	jmp    0x7a0d12800cba
    7a0d2a800e02:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    7a0d2a800e09:	40 00 01 00 
    7a0d2a800e0d:	b8 40 00 01 00       	mov    eax,0x10040
    7a0d2a800e12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800e19:	04 00 00 00 
    7a0d2a800e1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800e24:	01 00 00 00 
    7a0d2a800e28:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a800e2b:	be 40 00 01 00       	mov    esi,0x10040
    7a0d2a800e30:	4c 89 ef             	mov    rdi,r13
    7a0d2a800e33:	e8 28 f3 ff e7       	call   0x7a0d12800160
    7a0d2a800e38:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800e3f:	00 
    7a0d2a800e40:	0f 84 9f fe ff e7    	je     0x7a0d12800ce5
    7a0d2a800e46:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800e4d:	04 00 00 00 
    7a0d2a800e51:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800e58:	01 00 00 00 
    7a0d2a800e5c:	58                   	pop    rax
    7a0d2a800e5d:	e9 e0 05 00 e8       	jmp    0x7a0d12801442
    7a0d2a800e62:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10044
    7a0d2a800e69:	44 00 01 00 
    7a0d2a800e6d:	b8 44 00 01 00       	mov    eax,0x10044
    7a0d2a800e72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800e79:	02 00 00 00 
    7a0d2a800e7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a800e84:	02 00 00 00 
    7a0d2a800e88:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800e8b:	be 44 00 01 00       	mov    esi,0x10044
    7a0d2a800e90:	4c 89 ef             	mov    rdi,r13
    7a0d2a800e93:	e8 c8 f2 ff e7       	call   0x7a0d12800160
    7a0d2a800e98:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800e9f:	00 
    7a0d2a800ea0:	0f 84 68 fe ff e7    	je     0x7a0d12800d0e
    7a0d2a800ea6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800ead:	02 00 00 00 
    7a0d2a800eb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a800eb8:	02 00 00 00 
    7a0d2a800ebc:	58                   	pop    rax
    7a0d2a800ebd:	e9 80 05 00 e8       	jmp    0x7a0d12801442
    7a0d2a800ec2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    7a0d2a800ec9:	46 00 01 00 
    7a0d2a800ecd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800ed4:	02 00 00 00 
    7a0d2a800ed8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800edf:	03 00 00 00 
    7a0d2a800ee3:	ba 46 00 01 00       	mov    edx,0x10046
    7a0d2a800ee8:	4c 89 ef             	mov    rdi,r13
    7a0d2a800eeb:	4c 89 f6             	mov    rsi,r14
    7a0d2a800eee:	45 31 c0             	xor    r8d,r8d
    7a0d2a800ef1:	e8 8a f1 ff e7       	call   0x7a0d12800080
    7a0d2a800ef6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800efd:	02 00 00 00 
    7a0d2a800f01:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800f08:	03 00 00 00 
    7a0d2a800f0c:	58                   	pop    rax
    7a0d2a800f0d:	e9 30 05 00 e8       	jmp    0x7a0d12801442
    7a0d2a800f12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    7a0d2a800f19:	46 00 01 00 
    7a0d2a800f1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800f24:	02 00 00 00 
    7a0d2a800f28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800f2f:	03 00 00 00 
    7a0d2a800f33:	4c 89 f7             	mov    rdi,r14
    7a0d2a800f36:	89 ce                	mov    esi,ecx
    7a0d2a800f38:	e8 03 f1 ff e7       	call   0x7a0d12800040
    7a0d2a800f3d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800f44:	00 
    7a0d2a800f45:	0f 84 f6 fd ff e7    	je     0x7a0d12800d41
    7a0d2a800f4b:	eb a9                	jmp    0x7a0d2a800ef6
    7a0d2a800f4d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    7a0d2a800f54:	46 00 01 00 
    7a0d2a800f58:	b8 46 00 01 00       	mov    eax,0x10046
    7a0d2a800f5d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800f64:	02 00 00 00 
    7a0d2a800f68:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800f6f:	03 00 00 00 
    7a0d2a800f73:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800f76:	be 46 00 01 00       	mov    esi,0x10046
    7a0d2a800f7b:	4c 89 ef             	mov    rdi,r13
    7a0d2a800f7e:	e8 dd f1 ff e7       	call   0x7a0d12800160
    7a0d2a800f83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800f8a:	00 
    7a0d2a800f8b:	0f 84 d6 fd ff e7    	je     0x7a0d12800d67
    7a0d2a800f91:	e9 60 ff ff ff       	jmp    0x7a0d2a800ef6
    7a0d2a800f96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10048
    7a0d2a800f9d:	48 00 01 00 
    7a0d2a800fa1:	b8 48 00 01 00       	mov    eax,0x10048
    7a0d2a800fa6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800fad:	02 00 00 00 
    7a0d2a800fb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a800fb8:	04 00 00 00 
    7a0d2a800fbc:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800fbf:	be 48 00 01 00       	mov    esi,0x10048
    7a0d2a800fc4:	4c 89 ef             	mov    rdi,r13
    7a0d2a800fc7:	e8 94 f1 ff e7       	call   0x7a0d12800160
    7a0d2a800fcc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800fd3:	00 
    7a0d2a800fd4:	0f 84 b6 fd ff e7    	je     0x7a0d12800d90
    7a0d2a800fda:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800fe1:	02 00 00 00 
    7a0d2a800fe5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a800fec:	04 00 00 00 
    7a0d2a800ff0:	58                   	pop    rax
    7a0d2a800ff1:	e9 4c 04 00 e8       	jmp    0x7a0d12801442
    7a0d2a800ff6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    7a0d2a800ffd:	4a 00 01 00 
    7a0d2a801001:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801008:	02 00 00 00 
    7a0d2a80100c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a801013:	05 00 00 00 
    7a0d2a801017:	ba 4a 00 01 00       	mov    edx,0x1004a
    7a0d2a80101c:	4c 89 ef             	mov    rdi,r13
    7a0d2a80101f:	4c 89 f6             	mov    rsi,r14
    7a0d2a801022:	45 31 c0             	xor    r8d,r8d
    7a0d2a801025:	e8 56 f0 ff e7       	call   0x7a0d12800080
    7a0d2a80102a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801031:	02 00 00 00 
    7a0d2a801035:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80103c:	05 00 00 00 
    7a0d2a801040:	58                   	pop    rax
    7a0d2a801041:	e9 fc 03 00 e8       	jmp    0x7a0d12801442
    7a0d2a801046:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    7a0d2a80104d:	4a 00 01 00 
    7a0d2a801051:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801058:	02 00 00 00 
    7a0d2a80105c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a801063:	05 00 00 00 
    7a0d2a801067:	4c 89 f7             	mov    rdi,r14
    7a0d2a80106a:	89 ce                	mov    esi,ecx
    7a0d2a80106c:	e8 cf ef ff e7       	call   0x7a0d12800040
    7a0d2a801071:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801078:	00 
    7a0d2a801079:	0f 84 44 fd ff e7    	je     0x7a0d12800dc3
    7a0d2a80107f:	eb a9                	jmp    0x7a0d2a80102a
    7a0d2a801081:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    7a0d2a801088:	4a 00 01 00 
    7a0d2a80108c:	b8 4a 00 01 00       	mov    eax,0x1004a
    7a0d2a801091:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801098:	02 00 00 00 
    7a0d2a80109c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8010a3:	05 00 00 00 
    7a0d2a8010a7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8010aa:	be 4a 00 01 00       	mov    esi,0x1004a
    7a0d2a8010af:	4c 89 ef             	mov    rdi,r13
    7a0d2a8010b2:	e8 a9 f0 ff e7       	call   0x7a0d12800160
    7a0d2a8010b7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8010be:	00 
    7a0d2a8010bf:	0f 84 24 fd ff e7    	je     0x7a0d12800de9
    7a0d2a8010c5:	e9 60 ff ff ff       	jmp    0x7a0d2a80102a
    7a0d2a8010ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004c
    7a0d2a8010d1:	4c 00 01 00 
    7a0d2a8010d5:	b8 4c 00 01 00       	mov    eax,0x1004c
    7a0d2a8010da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8010e1:	02 00 00 00 
    7a0d2a8010e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8010ec:	06 00 00 00 
    7a0d2a8010f0:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8010f3:	be 4c 00 01 00       	mov    esi,0x1004c
    7a0d2a8010f8:	4c 89 ef             	mov    rdi,r13
    7a0d2a8010fb:	e8 60 f0 ff e7       	call   0x7a0d12800160
    7a0d2a801100:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801107:	00 
    7a0d2a801108:	0f 84 07 fd ff e7    	je     0x7a0d12800e15
    7a0d2a80110e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801115:	02 00 00 00 
    7a0d2a801119:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a801120:	06 00 00 00 
    7a0d2a801124:	58                   	pop    rax
    7a0d2a801125:	e9 18 03 00 e8       	jmp    0x7a0d12801442
    7a0d2a80112a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004e
    7a0d2a801131:	4e 00 01 00 
    7a0d2a801135:	b8 4e 00 01 00       	mov    eax,0x1004e
    7a0d2a80113a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801141:	04 00 00 00 
    7a0d2a801145:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a80114c:	07 00 00 00 
    7a0d2a801150:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801153:	be 4e 00 01 00       	mov    esi,0x1004e
    7a0d2a801158:	4c 89 ef             	mov    rdi,r13
    7a0d2a80115b:	e8 00 f0 ff e7       	call   0x7a0d12800160
    7a0d2a801160:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801167:	00 
    7a0d2a801168:	0f 84 d3 fc ff e7    	je     0x7a0d12800e41
    7a0d2a80116e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801175:	04 00 00 00 
    7a0d2a801179:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a801180:	07 00 00 00 
    7a0d2a801184:	58                   	pop    rax
    7a0d2a801185:	e9 b8 02 00 e8       	jmp    0x7a0d12801442
    7a0d2a80118a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10052
    7a0d2a801191:	52 00 01 00 
    7a0d2a801195:	b8 52 00 01 00       	mov    eax,0x10052
    7a0d2a80119a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8011a1:	02 00 00 00 
    7a0d2a8011a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8011ac:	08 00 00 00 
    7a0d2a8011b0:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8011b3:	be 52 00 01 00       	mov    esi,0x10052
    7a0d2a8011b8:	4c 89 ef             	mov    rdi,r13
    7a0d2a8011bb:	e8 a0 ef ff e7       	call   0x7a0d12800160
    7a0d2a8011c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8011c7:	00 
    7a0d2a8011c8:	0f 84 9c fc ff e7    	je     0x7a0d12800e6a
    7a0d2a8011ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8011d5:	02 00 00 00 
    7a0d2a8011d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8011e0:	08 00 00 00 
    7a0d2a8011e4:	58                   	pop    rax
    7a0d2a8011e5:	e9 58 02 00 e8       	jmp    0x7a0d12801442
    7a0d2a8011ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    7a0d2a8011f1:	54 00 01 00 
    7a0d2a8011f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8011fc:	02 00 00 00 
    7a0d2a801200:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a801207:	09 00 00 00 
    7a0d2a80120b:	ba 54 00 01 00       	mov    edx,0x10054
    7a0d2a801210:	4c 89 ef             	mov    rdi,r13
    7a0d2a801213:	4c 89 f6             	mov    rsi,r14
    7a0d2a801216:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80121c:	e8 5f ee ff e7       	call   0x7a0d12800080
    7a0d2a801221:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801228:	02 00 00 00 
    7a0d2a80122c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a801233:	09 00 00 00 
    7a0d2a801237:	58                   	pop    rax
    7a0d2a801238:	e9 05 02 00 e8       	jmp    0x7a0d12801442
    7a0d2a80123d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    7a0d2a801244:	54 00 01 00 
    7a0d2a801248:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80124f:	02 00 00 00 
    7a0d2a801253:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a80125a:	09 00 00 00 
    7a0d2a80125e:	4c 89 f7             	mov    rdi,r14
    7a0d2a801261:	89 ce                	mov    esi,ecx
    7a0d2a801263:	e8 08 ee ff e7       	call   0x7a0d12800070
    7a0d2a801268:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80126f:	00 
    7a0d2a801270:	0f 84 32 fc ff e7    	je     0x7a0d12800ea8
    7a0d2a801276:	eb a9                	jmp    0x7a0d2a801221
    7a0d2a801278:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    7a0d2a80127f:	54 00 01 00 
    7a0d2a801283:	b8 54 00 01 00       	mov    eax,0x10054
    7a0d2a801288:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80128f:	02 00 00 00 
    7a0d2a801293:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a80129a:	09 00 00 00 
    7a0d2a80129e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8012a1:	be 54 00 01 00       	mov    esi,0x10054
    7a0d2a8012a6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8012a9:	e8 b2 ee ff e7       	call   0x7a0d12800160
    7a0d2a8012ae:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a8012b1:	0f 84 22 fc ff e7    	je     0x7a0d12800ed9
    7a0d2a8012b7:	eb 0f                	jmp    0x7a0d2a8012c8
    7a0d2a8012b9:	b8 54 00 01 00       	mov    eax,0x10054
    7a0d2a8012be:	83 c0 02             	add    eax,0x2
    7a0d2a8012c1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8012c8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8012cf:	02 00 00 00 
    7a0d2a8012d3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8012da:	09 00 00 00 
    7a0d2a8012de:	4c 89 ef             	mov    rdi,r13
    7a0d2a8012e1:	e8 6a ee ff e7       	call   0x7a0d12800150
    7a0d2a8012e6:	e9 ee fb ff e7       	jmp    0x7a0d12800ed9
    7a0d2a8012eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    7a0d2a8012f2:	56 00 01 00 
    7a0d2a8012f6:	b8 56 00 01 00       	mov    eax,0x10056
    7a0d2a8012fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801302:	04 00 00 00 
    7a0d2a801306:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a80130d:	0a 00 00 00 
    7a0d2a801311:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801314:	be 56 00 01 00       	mov    esi,0x10056
    7a0d2a801319:	4c 89 ef             	mov    rdi,r13
    7a0d2a80131c:	e8 3f ee ff e7       	call   0x7a0d12800160
    7a0d2a801321:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801328:	00 
    7a0d2a801329:	0f 84 e4 fb ff e7    	je     0x7a0d12800f13
    7a0d2a80132f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801336:	04 00 00 00 
    7a0d2a80133a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a801341:	0a 00 00 00 
    7a0d2a801345:	58                   	pop    rax
    7a0d2a801346:	e9 f7 00 00 e8       	jmp    0x7a0d12801442
    7a0d2a80134b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005a
    7a0d2a801352:	5a 00 01 00 
    7a0d2a801356:	b8 5a 00 01 00       	mov    eax,0x1005a
    7a0d2a80135b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801362:	02 00 00 00 
    7a0d2a801366:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a80136d:	0b 00 00 00 
    7a0d2a801371:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801374:	be 5a 00 01 00       	mov    esi,0x1005a
    7a0d2a801379:	4c 89 ef             	mov    rdi,r13
    7a0d2a80137c:	e8 df ed ff e7       	call   0x7a0d12800160
    7a0d2a801381:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801388:	00 
    7a0d2a801389:	0f 84 ad fb ff e7    	je     0x7a0d12800f3c
    7a0d2a80138f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801396:	02 00 00 00 
    7a0d2a80139a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a8013a1:	0b 00 00 00 
    7a0d2a8013a5:	58                   	pop    rax
    7a0d2a8013a6:	e9 97 00 00 e8       	jmp    0x7a0d12801442
    7a0d2a8013ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    7a0d2a8013b2:	5c 00 01 00 
    7a0d2a8013b6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8013bd:	02 00 00 00 
    7a0d2a8013c1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8013c8:	0c 00 00 00 
    7a0d2a8013cc:	ba 5c 00 01 00       	mov    edx,0x1005c
    7a0d2a8013d1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8013d4:	4c 89 f6             	mov    rsi,r14
    7a0d2a8013d7:	45 31 c0             	xor    r8d,r8d
    7a0d2a8013da:	e8 a1 ec ff e7       	call   0x7a0d12800080
    7a0d2a8013df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8013e6:	02 00 00 00 
    7a0d2a8013ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8013f1:	0c 00 00 00 
    7a0d2a8013f5:	58                   	pop    rax
    7a0d2a8013f6:	e9 47 00 00 e8       	jmp    0x7a0d12801442
    7a0d2a8013fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    7a0d2a801402:	5c 00 01 00 
    7a0d2a801406:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80140d:	02 00 00 00 
    7a0d2a801411:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a801418:	0c 00 00 00 
    7a0d2a80141c:	4c 89 f7             	mov    rdi,r14
    7a0d2a80141f:	89 ce                	mov    esi,ecx
    7a0d2a801421:	e8 1a ec ff e7       	call   0x7a0d12800040
    7a0d2a801426:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80142d:	00 
    7a0d2a80142e:	0f 84 3b fb ff e7    	je     0x7a0d12800f6f
    7a0d2a801434:	eb a9                	jmp    0x7a0d2a8013df
    7a0d2a801436:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    7a0d2a80143d:	5c 00 01 00 
    7a0d2a801441:	b8 5c 00 01 00       	mov    eax,0x1005c
    7a0d2a801446:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80144d:	02 00 00 00 
    7a0d2a801451:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a801458:	0c 00 00 00 
    7a0d2a80145c:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80145f:	be 5c 00 01 00       	mov    esi,0x1005c
    7a0d2a801464:	4c 89 ef             	mov    rdi,r13
    7a0d2a801467:	e8 f4 ec ff e7       	call   0x7a0d12800160
    7a0d2a80146c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801473:	00 
    7a0d2a801474:	0f 84 1b fb ff e7    	je     0x7a0d12800f95
    7a0d2a80147a:	e9 60 ff ff ff       	jmp    0x7a0d2a8013df
    7a0d2a80147f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005e
    7a0d2a801486:	5e 00 01 00 
    7a0d2a80148a:	b8 5e 00 01 00       	mov    eax,0x1005e
    7a0d2a80148f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801496:	04 00 00 00 
    7a0d2a80149a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8014a1:	0d 00 00 00 
    7a0d2a8014a5:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8014a8:	be 5e 00 01 00       	mov    esi,0x1005e
    7a0d2a8014ad:	4c 89 ef             	mov    rdi,r13
    7a0d2a8014b0:	e8 ab ec ff e7       	call   0x7a0d12800160
    7a0d2a8014b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8014bc:	00 
    7a0d2a8014bd:	0f 84 06 fb ff e7    	je     0x7a0d12800fc9
    7a0d2a8014c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8014ca:	04 00 00 00 
    7a0d2a8014ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8014d5:	0d 00 00 00 
    7a0d2a8014d9:	58                   	pop    rax
    7a0d2a8014da:	e9 63 ff ff e7       	jmp    0x7a0d12801442
    7a0d2a8014df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10062
    7a0d2a8014e6:	62 00 01 00 
    7a0d2a8014ea:	b8 62 00 01 00       	mov    eax,0x10062
    7a0d2a8014ef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8014f6:	04 00 00 00 
    7a0d2a8014fa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a801501:	0e 00 00 00 
    7a0d2a801505:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801508:	be 62 00 01 00       	mov    esi,0x10062
    7a0d2a80150d:	4c 89 ef             	mov    rdi,r13
    7a0d2a801510:	e8 4b ec ff e7       	call   0x7a0d12800160
    7a0d2a801515:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80151c:	00 
    7a0d2a80151d:	0f 84 da fa ff e7    	je     0x7a0d12800ffd
    7a0d2a801523:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80152a:	04 00 00 00 
    7a0d2a80152e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a801535:	0e 00 00 00 
    7a0d2a801539:	58                   	pop    rax
    7a0d2a80153a:	e9 03 ff ff e7       	jmp    0x7a0d12801442
    7a0d2a80153f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10066
    7a0d2a801546:	66 00 01 00 
    7a0d2a80154a:	b8 66 00 01 00       	mov    eax,0x10066
    7a0d2a80154f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801556:	04 00 00 00 
    7a0d2a80155a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a801561:	0f 00 00 00 
    7a0d2a801565:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801568:	be 66 00 01 00       	mov    esi,0x10066
    7a0d2a80156d:	4c 89 ef             	mov    rdi,r13
    7a0d2a801570:	e8 eb eb ff e7       	call   0x7a0d12800160
    7a0d2a801575:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80157c:	00 
    7a0d2a80157d:	0f 84 b1 fa ff e7    	je     0x7a0d12801034
    7a0d2a801583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80158a:	04 00 00 00 
    7a0d2a80158e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a801595:	0f 00 00 00 
    7a0d2a801599:	58                   	pop    rax
    7a0d2a80159a:	e9 a3 fe ff e7       	jmp    0x7a0d12801442
    7a0d2a80159f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    7a0d2a8015a6:	6a 00 01 00 
    7a0d2a8015aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8015b1:	02 00 00 00 
    7a0d2a8015b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a8015bc:	10 00 00 00 
    7a0d2a8015c0:	ba 6a 00 01 00       	mov    edx,0x1006a
    7a0d2a8015c5:	4c 89 ef             	mov    rdi,r13
    7a0d2a8015c8:	4c 89 f6             	mov    rsi,r14
    7a0d2a8015cb:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a8015d1:	e8 aa ea ff e7       	call   0x7a0d12800080
    7a0d2a8015d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8015dd:	02 00 00 00 
    7a0d2a8015e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a8015e8:	10 00 00 00 
    7a0d2a8015ec:	58                   	pop    rax
    7a0d2a8015ed:	e9 50 fe ff e7       	jmp    0x7a0d12801442
    7a0d2a8015f2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    7a0d2a8015f9:	6a 00 01 00 
    7a0d2a8015fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801604:	02 00 00 00 
    7a0d2a801608:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a80160f:	10 00 00 00 
    7a0d2a801613:	4c 89 f7             	mov    rdi,r14
    7a0d2a801616:	89 ce                	mov    esi,ecx
    7a0d2a801618:	e8 53 ea ff e7       	call   0x7a0d12800070
    7a0d2a80161d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801624:	00 
    7a0d2a801625:	0f 84 47 fa ff e7    	je     0x7a0d12801072
    7a0d2a80162b:	eb a9                	jmp    0x7a0d2a8015d6
    7a0d2a80162d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    7a0d2a801634:	6a 00 01 00 
    7a0d2a801638:	b8 6a 00 01 00       	mov    eax,0x1006a
    7a0d2a80163d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801644:	02 00 00 00 
    7a0d2a801648:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a80164f:	10 00 00 00 
    7a0d2a801653:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801656:	be 6a 00 01 00       	mov    esi,0x1006a
    7a0d2a80165b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80165e:	e8 fd ea ff e7       	call   0x7a0d12800160
    7a0d2a801663:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a801666:	0f 84 37 fa ff e7    	je     0x7a0d128010a3
    7a0d2a80166c:	eb 0f                	jmp    0x7a0d2a80167d
    7a0d2a80166e:	b8 6a 00 01 00       	mov    eax,0x1006a
    7a0d2a801673:	83 c0 02             	add    eax,0x2
    7a0d2a801676:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80167d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801684:	02 00 00 00 
    7a0d2a801688:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a80168f:	10 00 00 00 
    7a0d2a801693:	4c 89 ef             	mov    rdi,r13
    7a0d2a801696:	e8 b5 ea ff e7       	call   0x7a0d12800150
    7a0d2a80169b:	e9 03 fa ff e7       	jmp    0x7a0d128010a3
    7a0d2a8016a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    7a0d2a8016a7:	6c 00 01 00 
    7a0d2a8016ab:	b8 6c 00 01 00       	mov    eax,0x1006c
    7a0d2a8016b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8016b7:	04 00 00 00 
    7a0d2a8016bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    7a0d2a8016c2:	11 00 00 00 
    7a0d2a8016c6:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8016c9:	be 6c 00 01 00       	mov    esi,0x1006c
    7a0d2a8016ce:	4c 89 ef             	mov    rdi,r13
    7a0d2a8016d1:	e8 8a ea ff e7       	call   0x7a0d12800160
    7a0d2a8016d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8016dd:	00 
    7a0d2a8016de:	0f 84 01 fa ff e7    	je     0x7a0d128010e5
    7a0d2a8016e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8016eb:	04 00 00 00 
    7a0d2a8016ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    7a0d2a8016f6:	11 00 00 00 
    7a0d2a8016fa:	58                   	pop    rax
    7a0d2a8016fb:	e9 42 fd ff e7       	jmp    0x7a0d12801442
    7a0d2a801700:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10070
    7a0d2a801707:	70 00 01 00 
    7a0d2a80170b:	b8 70 00 01 00       	mov    eax,0x10070
    7a0d2a801710:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801717:	04 00 00 00 
    7a0d2a80171b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    7a0d2a801722:	12 00 00 00 
    7a0d2a801726:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801729:	be 70 00 01 00       	mov    esi,0x10070
    7a0d2a80172e:	4c 89 ef             	mov    rdi,r13
    7a0d2a801731:	e8 2a ea ff e7       	call   0x7a0d12800160
    7a0d2a801736:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80173d:	00 
    7a0d2a80173e:	0f 84 d8 f9 ff e7    	je     0x7a0d1280111c
    7a0d2a801744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80174b:	04 00 00 00 
    7a0d2a80174f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    7a0d2a801756:	12 00 00 00 
    7a0d2a80175a:	58                   	pop    rax
    7a0d2a80175b:	e9 e2 fc ff e7       	jmp    0x7a0d12801442
    7a0d2a801760:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    7a0d2a801767:	74 00 01 00 
    7a0d2a80176b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801772:	02 00 00 00 
    7a0d2a801776:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a80177d:	13 00 00 00 
    7a0d2a801781:	ba 74 00 01 00       	mov    edx,0x10074
    7a0d2a801786:	4c 89 ef             	mov    rdi,r13
    7a0d2a801789:	4c 89 f6             	mov    rsi,r14
    7a0d2a80178c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a801792:	e8 e9 e8 ff e7       	call   0x7a0d12800080
    7a0d2a801797:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80179e:	02 00 00 00 
    7a0d2a8017a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a8017a9:	13 00 00 00 
    7a0d2a8017ad:	58                   	pop    rax
    7a0d2a8017ae:	e9 8f fc ff e7       	jmp    0x7a0d12801442
    7a0d2a8017b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    7a0d2a8017ba:	74 00 01 00 
    7a0d2a8017be:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8017c5:	02 00 00 00 
    7a0d2a8017c9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a8017d0:	13 00 00 00 
    7a0d2a8017d4:	4c 89 f7             	mov    rdi,r14
    7a0d2a8017d7:	89 ce                	mov    esi,ecx
    7a0d2a8017d9:	e8 92 e8 ff e7       	call   0x7a0d12800070
    7a0d2a8017de:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8017e5:	00 
    7a0d2a8017e6:	0f 84 6e f9 ff e7    	je     0x7a0d1280115a
    7a0d2a8017ec:	eb a9                	jmp    0x7a0d2a801797
    7a0d2a8017ee:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    7a0d2a8017f5:	74 00 01 00 
    7a0d2a8017f9:	b8 74 00 01 00       	mov    eax,0x10074
    7a0d2a8017fe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801805:	02 00 00 00 
    7a0d2a801809:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a801810:	13 00 00 00 
    7a0d2a801814:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801817:	be 74 00 01 00       	mov    esi,0x10074
    7a0d2a80181c:	4c 89 ef             	mov    rdi,r13
    7a0d2a80181f:	e8 3c e9 ff e7       	call   0x7a0d12800160
    7a0d2a801824:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a801827:	0f 84 5e f9 ff e7    	je     0x7a0d1280118b
    7a0d2a80182d:	eb 0f                	jmp    0x7a0d2a80183e
    7a0d2a80182f:	b8 74 00 01 00       	mov    eax,0x10074
    7a0d2a801834:	83 c0 02             	add    eax,0x2
    7a0d2a801837:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80183e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801845:	02 00 00 00 
    7a0d2a801849:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a801850:	13 00 00 00 
    7a0d2a801854:	4c 89 ef             	mov    rdi,r13
    7a0d2a801857:	e8 f4 e8 ff e7       	call   0x7a0d12800150
    7a0d2a80185c:	e9 2a f9 ff e7       	jmp    0x7a0d1280118b
    7a0d2a801861:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    7a0d2a801868:	76 00 01 00 
    7a0d2a80186c:	b8 76 00 01 00       	mov    eax,0x10076
    7a0d2a801871:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801878:	02 00 00 00 
    7a0d2a80187c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    7a0d2a801883:	14 00 00 00 
    7a0d2a801887:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80188a:	be 76 00 01 00       	mov    esi,0x10076
    7a0d2a80188f:	4c 89 ef             	mov    rdi,r13
    7a0d2a801892:	e8 c9 e8 ff e7       	call   0x7a0d12800160
    7a0d2a801897:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80189e:	00 
    7a0d2a80189f:	0f 84 20 f9 ff e7    	je     0x7a0d128011c5
    7a0d2a8018a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8018ac:	02 00 00 00 
    7a0d2a8018b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    7a0d2a8018b7:	14 00 00 00 
    7a0d2a8018bb:	58                   	pop    rax
    7a0d2a8018bc:	e9 81 fb ff e7       	jmp    0x7a0d12801442
    7a0d2a8018c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    7a0d2a8018c8:	78 00 01 00 
    7a0d2a8018cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8018d3:	02 00 00 00 
    7a0d2a8018d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a8018de:	15 00 00 00 
    7a0d2a8018e2:	ba 78 00 01 00       	mov    edx,0x10078
    7a0d2a8018e7:	4c 89 ef             	mov    rdi,r13
    7a0d2a8018ea:	4c 89 f6             	mov    rsi,r14
    7a0d2a8018ed:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a8018f3:	e8 88 e7 ff e7       	call   0x7a0d12800080
    7a0d2a8018f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8018ff:	02 00 00 00 
    7a0d2a801903:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a80190a:	15 00 00 00 
    7a0d2a80190e:	58                   	pop    rax
    7a0d2a80190f:	e9 2e fb ff e7       	jmp    0x7a0d12801442
    7a0d2a801914:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    7a0d2a80191b:	78 00 01 00 
    7a0d2a80191f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801926:	02 00 00 00 
    7a0d2a80192a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a801931:	15 00 00 00 
    7a0d2a801935:	4c 89 f7             	mov    rdi,r14
    7a0d2a801938:	89 ce                	mov    esi,ecx
    7a0d2a80193a:	e8 31 e7 ff e7       	call   0x7a0d12800070
    7a0d2a80193f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801946:	00 
    7a0d2a801947:	0f 84 b6 f8 ff e7    	je     0x7a0d12801203
    7a0d2a80194d:	eb a9                	jmp    0x7a0d2a8018f8
    7a0d2a80194f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    7a0d2a801956:	78 00 01 00 
    7a0d2a80195a:	b8 78 00 01 00       	mov    eax,0x10078
    7a0d2a80195f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801966:	02 00 00 00 
    7a0d2a80196a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a801971:	15 00 00 00 
    7a0d2a801975:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801978:	be 78 00 01 00       	mov    esi,0x10078
    7a0d2a80197d:	4c 89 ef             	mov    rdi,r13
    7a0d2a801980:	e8 db e7 ff e7       	call   0x7a0d12800160
    7a0d2a801985:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a801988:	0f 84 a6 f8 ff e7    	je     0x7a0d12801234
    7a0d2a80198e:	eb 0f                	jmp    0x7a0d2a80199f
    7a0d2a801990:	b8 78 00 01 00       	mov    eax,0x10078
    7a0d2a801995:	83 c0 02             	add    eax,0x2
    7a0d2a801998:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80199f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8019a6:	02 00 00 00 
    7a0d2a8019aa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a8019b1:	15 00 00 00 
    7a0d2a8019b5:	4c 89 ef             	mov    rdi,r13
    7a0d2a8019b8:	e8 93 e7 ff e7       	call   0x7a0d12800150
    7a0d2a8019bd:	e9 72 f8 ff e7       	jmp    0x7a0d12801234
    7a0d2a8019c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    7a0d2a8019c9:	7a 00 01 00 
    7a0d2a8019cd:	b8 7a 00 01 00       	mov    eax,0x1007a
    7a0d2a8019d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8019d9:	02 00 00 00 
    7a0d2a8019dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    7a0d2a8019e4:	16 00 00 00 
    7a0d2a8019e8:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8019eb:	be 7a 00 01 00       	mov    esi,0x1007a
    7a0d2a8019f0:	4c 89 ef             	mov    rdi,r13
    7a0d2a8019f3:	e8 68 e7 ff e7       	call   0x7a0d12800160
    7a0d2a8019f8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8019ff:	00 
    7a0d2a801a00:	0f 84 68 f8 ff e7    	je     0x7a0d1280126e
    7a0d2a801a06:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801a0d:	02 00 00 00 
    7a0d2a801a11:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    7a0d2a801a18:	16 00 00 00 
    7a0d2a801a1c:	58                   	pop    rax
    7a0d2a801a1d:	e9 20 fa ff e7       	jmp    0x7a0d12801442
    7a0d2a801a22:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007c
    7a0d2a801a29:	7c 00 01 00 
    7a0d2a801a2d:	b8 7c 00 01 00       	mov    eax,0x1007c
    7a0d2a801a32:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801a39:	04 00 00 00 
    7a0d2a801a3d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    7a0d2a801a44:	17 00 00 00 
    7a0d2a801a48:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801a4b:	be 7c 00 01 00       	mov    esi,0x1007c
    7a0d2a801a50:	4c 89 ef             	mov    rdi,r13
    7a0d2a801a53:	e8 08 e7 ff e7       	call   0x7a0d12800160
    7a0d2a801a58:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801a5f:	00 
    7a0d2a801a60:	0f 84 3f f8 ff e7    	je     0x7a0d128012a5
    7a0d2a801a66:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801a6d:	04 00 00 00 
    7a0d2a801a71:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    7a0d2a801a78:	17 00 00 00 
    7a0d2a801a7c:	58                   	pop    rax
    7a0d2a801a7d:	e9 c0 f9 ff e7       	jmp    0x7a0d12801442
    7a0d2a801a82:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10080
    7a0d2a801a89:	80 00 01 00 
    7a0d2a801a8d:	b8 80 00 01 00       	mov    eax,0x10080
    7a0d2a801a92:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801a99:	02 00 00 00 
    7a0d2a801a9d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    7a0d2a801aa4:	18 00 00 00 
    7a0d2a801aa8:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801aab:	be 80 00 01 00       	mov    esi,0x10080
    7a0d2a801ab0:	4c 89 ef             	mov    rdi,r13
    7a0d2a801ab3:	e8 a8 e6 ff e7       	call   0x7a0d12800160
    7a0d2a801ab8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801abf:	00 
    7a0d2a801ac0:	0f 84 0b f8 ff e7    	je     0x7a0d128012d1
    7a0d2a801ac6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801acd:	02 00 00 00 
    7a0d2a801ad1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    7a0d2a801ad8:	18 00 00 00 
    7a0d2a801adc:	58                   	pop    rax
    7a0d2a801add:	e9 60 f9 ff e7       	jmp    0x7a0d12801442
    7a0d2a801ae2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10082
    7a0d2a801ae9:	82 00 01 00 
    7a0d2a801aed:	b8 82 00 01 00       	mov    eax,0x10082
    7a0d2a801af2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801af9:	02 00 00 00 
    7a0d2a801afd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a801b04:	19 00 00 00 
    7a0d2a801b08:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801b0b:	be 82 00 01 00       	mov    esi,0x10082
    7a0d2a801b10:	4c 89 ef             	mov    rdi,r13
    7a0d2a801b13:	e8 48 e6 ff e7       	call   0x7a0d12800160
    7a0d2a801b18:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801b1f:	00 
    7a0d2a801b20:	0f 84 d7 f7 ff e7    	je     0x7a0d128012fd
    7a0d2a801b26:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801b2d:	02 00 00 00 
    7a0d2a801b31:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a801b38:	19 00 00 00 
    7a0d2a801b3c:	58                   	pop    rax
    7a0d2a801b3d:	e9 00 f9 ff e7       	jmp    0x7a0d12801442
    7a0d2a801b42:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7a0d2a801b49:	84 00 01 00 
    7a0d2a801b4d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a801b54:	08 00 00 00 
    7a0d2a801b58:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a801b5f:	1a 00 00 00 
    7a0d2a801b63:	ba 84 00 01 00       	mov    edx,0x10084
    7a0d2a801b68:	4c 89 ef             	mov    rdi,r13
    7a0d2a801b6b:	4c 89 f6             	mov    rsi,r14
    7a0d2a801b6e:	45 31 c0             	xor    r8d,r8d
    7a0d2a801b71:	e8 0a e5 ff e7       	call   0x7a0d12800080
    7a0d2a801b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a801b7d:	08 00 00 00 
    7a0d2a801b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a801b88:	1a 00 00 00 
    7a0d2a801b8c:	58                   	pop    rax
    7a0d2a801b8d:	e9 b0 f8 ff e7       	jmp    0x7a0d12801442
    7a0d2a801b92:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7a0d2a801b99:	84 00 01 00 
    7a0d2a801b9d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a801ba4:	08 00 00 00 
    7a0d2a801ba8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a801baf:	1a 00 00 00 
    7a0d2a801bb3:	4c 89 f7             	mov    rdi,r14
    7a0d2a801bb6:	89 ce                	mov    esi,ecx
    7a0d2a801bb8:	e8 83 e4 ff e7       	call   0x7a0d12800040
    7a0d2a801bbd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801bc4:	00 
    7a0d2a801bc5:	0f 84 65 f7 ff e7    	je     0x7a0d12801330
    7a0d2a801bcb:	eb a9                	jmp    0x7a0d2a801b76
    7a0d2a801bcd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a801bd4:	8c 00 01 00 
    7a0d2a801bd8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801bdf:	02 00 00 00 
    7a0d2a801be3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a801bea:	1b 00 00 00 
    7a0d2a801bee:	ba 8c 00 01 00       	mov    edx,0x1008c
    7a0d2a801bf3:	4c 89 ef             	mov    rdi,r13
    7a0d2a801bf6:	4c 89 f6             	mov    rsi,r14
    7a0d2a801bf9:	45 31 c0             	xor    r8d,r8d
    7a0d2a801bfc:	e8 7f e4 ff e7       	call   0x7a0d12800080
    7a0d2a801c01:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801c08:	02 00 00 00 
    7a0d2a801c0c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a801c13:	1b 00 00 00 
    7a0d2a801c17:	58                   	pop    rax
    7a0d2a801c18:	e9 25 f8 ff e7       	jmp    0x7a0d12801442
    7a0d2a801c1d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a801c24:	8c 00 01 00 
    7a0d2a801c28:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801c2f:	02 00 00 00 
    7a0d2a801c33:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a801c3a:	1b 00 00 00 
    7a0d2a801c3e:	4c 89 f7             	mov    rdi,r14
    7a0d2a801c41:	89 ce                	mov    esi,ecx
    7a0d2a801c43:	e8 f8 e3 ff e7       	call   0x7a0d12800040
    7a0d2a801c48:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801c4f:	00 
    7a0d2a801c50:	0f 84 2d f7 ff e7    	je     0x7a0d12801383
    7a0d2a801c56:	eb a9                	jmp    0x7a0d2a801c01
    7a0d2a801c58:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a801c5f:	8c 00 01 00 
    7a0d2a801c63:	b8 8c 00 01 00       	mov    eax,0x1008c
    7a0d2a801c68:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801c6f:	02 00 00 00 
    7a0d2a801c73:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a801c7a:	1b 00 00 00 
    7a0d2a801c7e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801c81:	be 8c 00 01 00       	mov    esi,0x1008c
    7a0d2a801c86:	4c 89 ef             	mov    rdi,r13
    7a0d2a801c89:	e8 d2 e4 ff e7       	call   0x7a0d12800160
    7a0d2a801c8e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801c95:	00 
    7a0d2a801c96:	0f 84 0d f7 ff e7    	je     0x7a0d128013a9
    7a0d2a801c9c:	e9 60 ff ff ff       	jmp    0x7a0d2a801c01
    7a0d2a801ca1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801ca8:	28 03 01 00 
    7a0d2a801cac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801cb3:	04 00 00 00 
    7a0d2a801cb7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    7a0d2a801cbe:	1c 00 00 00 
    7a0d2a801cc2:	be 8e 00 01 00       	mov    esi,0x1008e
    7a0d2a801cc7:	ba 8e 00 01 00       	mov    edx,0x1008e
    7a0d2a801ccc:	4c 89 ef             	mov    rdi,r13
    7a0d2a801ccf:	e8 8c e4 ff e7       	call   0x7a0d12800160
    7a0d2a801cd4:	e9 47 f7 ff e7       	jmp    0x7a0d12801420
    7a0d2a801cd9:	c2 08 00             	ret    0x8
