
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65916-1-134196563554672.bin:     file format binary


Disassembly of section .data:

00007a0d12803170 <.data>:
    7a0d12803170:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803177:	8b 88 24 00 10 00    	mov    ecx,DWORD PTR [rax+0x100024]
    7a0d1280317d:	ff c1                	inc    ecx
    7a0d1280317f:	89 88 24 00 10 00    	mov    DWORD PTR [rax+0x100024],ecx
    7a0d12803185:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280318b:	0f 84 bf 13 00 18    	je     0x7a0d2a804550
    7a0d12803191:	50                   	push   rax
    7a0d12803192:	41 8b 45 10          	mov    eax,DWORD PTR [r13+0x10]
    7a0d12803196:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d1280319d:	41 0f af 45 1c       	imul   eax,DWORD PTR [r13+0x1c]
    7a0d128031a2:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d128031a6:	81 f9 7c 01 01 00    	cmp    ecx,0x1017c
    7a0d128031ac:	0f 84 ca 13 00 18    	je     0x7a0d2a80457c
    7a0d128031b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017c
    7a0d128031b9:	7c 01 01 00 
    7a0d128031bd:	0f 84 b9 13 00 18    	je     0x7a0d2a80457c
    7a0d128031c3:	58                   	pop    rax
    7a0d128031c4:	50                   	push   rax
    7a0d128031c5:	41 8b 45 34          	mov    eax,DWORD PTR [r13+0x34]
    7a0d128031c9:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128031d0:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d128031d4:	81 f9 7e 01 01 00    	cmp    ecx,0x1017e
    7a0d128031da:	0f 84 fc 13 00 18    	je     0x7a0d2a8045dc
    7a0d128031e0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1017e
    7a0d128031e7:	7e 01 01 00 
    7a0d128031eb:	0f 84 eb 13 00 18    	je     0x7a0d2a8045dc
    7a0d128031f1:	58                   	pop    rax
    7a0d128031f2:	50                   	push   rax
    7a0d128031f3:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d128031f7:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    7a0d128031fb:	89 ca                	mov    edx,ecx
    7a0d128031fd:	c1 ea 1f             	shr    edx,0x1f
    7a0d12803200:	89 c6                	mov    esi,eax
    7a0d12803202:	c1 ee 1f             	shr    esi,0x1f
    7a0d12803205:	31 ff                	xor    edi,edi
    7a0d12803207:	01 c1                	add    ecx,eax
    7a0d12803209:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    7a0d1280320d:	40 0f 92 c7          	setb   dil
    7a0d12803211:	89 c8                	mov    eax,ecx
    7a0d12803213:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803216:	31 c6                	xor    esi,eax
    7a0d12803218:	31 c2                	xor    edx,eax
    7a0d1280321a:	21 f2                	and    edx,esi
    7a0d1280321c:	31 f6                	xor    esi,esi
    7a0d1280321e:	85 c9                	test   ecx,ecx
    7a0d12803220:	40 0f 94 c6          	sete   sil
    7a0d12803224:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d1280322b:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803232:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7a0d12803239:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7a0d12803240:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7a0d12803247:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d1280324e:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12803255:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10180
    7a0d1280325c:	80 01 01 00 
    7a0d12803260:	0f 84 d6 13 00 18    	je     0x7a0d2a80463c
    7a0d12803266:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10180
    7a0d1280326d:	80 01 01 00 
    7a0d12803271:	0f 84 c5 13 00 18    	je     0x7a0d2a80463c
    7a0d12803277:	58                   	pop    rax
    7a0d12803278:	50                   	push   rax
    7a0d12803279:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7a0d1280327d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803284:	31 d2                	xor    edx,edx
    7a0d12803286:	85 c0                	test   eax,eax
    7a0d12803288:	0f 94 c2             	sete   dl
    7a0d1280328b:	c1 e8 1f             	shr    eax,0x1f
    7a0d1280328e:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    7a0d12803295:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d1280329c:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128032a3:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d128032aa:	00 00 00 
    7a0d128032ad:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d128032b4:	81 f9 82 01 01 00    	cmp    ecx,0x10182
    7a0d128032ba:	0f 84 dc 13 00 18    	je     0x7a0d2a80469c
    7a0d128032c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10182
    7a0d128032c7:	82 01 01 00 
    7a0d128032cb:	0f 84 cb 13 00 18    	je     0x7a0d2a80469c
    7a0d128032d1:	58                   	pop    rax
    7a0d128032d2:	50                   	push   rax
    7a0d128032d3:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d128032da:	00 
    7a0d128032db:	74 28                	je     0x7a0d12803305
    7a0d128032dd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10184
    7a0d128032e4:	84 01 01 00 
    7a0d128032e8:	0f 84 0e 14 00 18    	je     0x7a0d2a8046fc
    7a0d128032ee:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10184
    7a0d128032f5:	84 01 01 00 
    7a0d128032f9:	0f 84 fd 13 00 18    	je     0x7a0d2a8046fc
    7a0d128032ff:	58                   	pop    rax
    7a0d12803300:	e9 55 00 00 00       	jmp    0x7a0d1280335a
    7a0d12803305:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d1280330c:	01 
    7a0d1280330d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10184
    7a0d12803314:	84 01 01 00 
    7a0d12803318:	0f 84 27 14 00 18    	je     0x7a0d2a804745
    7a0d1280331e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10184
    7a0d12803325:	84 01 01 00 
    7a0d12803329:	0f 84 16 14 00 18    	je     0x7a0d2a804745
    7a0d1280332f:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d12803334:	83 c0 ec             	add    eax,0xffffffec
    7a0d12803337:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280333e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12803345:	02 00 00 00 
    7a0d12803349:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d12803350:	05 00 00 00 
    7a0d12803354:	58                   	pop    rax
    7a0d12803355:	e9 f6 00 00 00       	jmp    0x7a0d12803450
    7a0d1280335a:	50                   	push   rax
    7a0d1280335b:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d1280335f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803366:	31 d2                	xor    edx,edx
    7a0d12803368:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    7a0d1280336c:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12803370:	0f 94 c2             	sete   dl
    7a0d12803373:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803376:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d1280337d:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803384:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d1280338b:	00 00 00 00 
    7a0d1280338f:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12803396:	00 00 00 00 
    7a0d1280339a:	81 f9 86 01 01 00    	cmp    ecx,0x10186
    7a0d128033a0:	0f 84 db 13 00 18    	je     0x7a0d2a804781
    7a0d128033a6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10186
    7a0d128033ad:	86 01 01 00 
    7a0d128033b1:	0f 84 ca 13 00 18    	je     0x7a0d2a804781
    7a0d128033b7:	58                   	pop    rax
    7a0d128033b8:	50                   	push   rax
    7a0d128033b9:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d128033c0:	b9 88 01 01 00       	mov    ecx,0x10188
    7a0d128033c5:	83 c1 04             	add    ecx,0x4
    7a0d128033c8:	89 ca                	mov    edx,ecx
    7a0d128033ca:	3d 88 01 01 00       	cmp    eax,0x10188
    7a0d128033cf:	75 07                	jne    0x7a0d128033d8
    7a0d128033d1:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d128033d8:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d128033df:	02 
    7a0d128033e0:	0f 43 ca             	cmovae ecx,edx
    7a0d128033e3:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d128033ea:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d128033f1:	89 cf                	mov    edi,ecx
    7a0d128033f3:	81 fa 88 01 01 00    	cmp    edx,0x10188
    7a0d128033f9:	75 07                	jne    0x7a0d12803402
    7a0d128033fb:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d12803402:	83 fe 02             	cmp    esi,0x2
    7a0d12803405:	0f 43 cf             	cmovae ecx,edi
    7a0d12803408:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d1280340f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12803416:	01 
    7a0d12803417:	3d 88 01 01 00       	cmp    eax,0x10188
    7a0d1280341c:	0f 84 bf 13 00 18    	je     0x7a0d2a8047e1
    7a0d12803422:	81 fa 88 01 01 00    	cmp    edx,0x10188
    7a0d12803428:	0f 84 b3 13 00 18    	je     0x7a0d2a8047e1
    7a0d1280342e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12803435:	10 01 01 00 
    7a0d12803439:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d12803440:	04 00 00 00 
    7a0d12803444:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d1280344b:	07 00 00 00 
    7a0d1280344f:	58                   	pop    rax
    7a0d12803450:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803457:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d1280345e:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12803465:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280346c:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12803473:	39 f1                	cmp    ecx,esi
    7a0d12803475:	0f 83 9e 13 00 18    	jae    0x7a0d2a804819
    7a0d1280347b:	81 fa 7c 01 01 00    	cmp    edx,0x1017c
    7a0d12803481:	75 14                	jne    0x7a0d12803497
    7a0d12803483:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280348a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803491:	00 
    7a0d12803492:	e9 d9 fc ff ff       	jmp    0x7a0d12803170
    7a0d12803497:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d1280349e:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d128034a4:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d128034a7:	0f 85 6c 13 00 18    	jne    0x7a0d2a804819
    7a0d128034ad:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d128034b4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128034bb:	00 
    7a0d128034bc:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d128034c1:	ff e0                	jmp    rax
