
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65840-1-134196563555984.bin:     file format binary


Disassembly of section .data:

00007a0d12803690 <.data>:
    7a0d12803690:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803697:	8b 88 2c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10002c]
    7a0d1280369d:	ff c1                	inc    ecx
    7a0d1280369f:	89 88 2c 00 10 00    	mov    DWORD PTR [rax+0x10002c],ecx
    7a0d128036a5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d128036ab:	0f 84 3f 12 00 18    	je     0x7a0d2a8048f0
    7a0d128036b1:	50                   	push   rax
    7a0d128036b2:	41 8b 85 00 00 00 00 	mov    eax,DWORD PTR [r13+0x0]
    7a0d128036b9:	31 c9                	xor    ecx,ecx
    7a0d128036bb:	c1 e0 05             	shl    eax,0x5
    7a0d128036be:	41 89 85 04 00 00 00 	mov    DWORD PTR [r13+0x4],eax
    7a0d128036c5:	0f 94 c1             	sete   cl
    7a0d128036c8:	c1 e8 1f             	shr    eax,0x1f
    7a0d128036cb:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7a0d128036d2:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128036d9:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d128036e0:	00 00 00 00 
    7a0d128036e4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10130
    7a0d128036eb:	30 01 01 00 
    7a0d128036ef:	0f 84 27 12 00 18    	je     0x7a0d2a80491c
    7a0d128036f5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10130
    7a0d128036fc:	30 01 01 00 
    7a0d12803700:	0f 84 16 12 00 18    	je     0x7a0d2a80491c
    7a0d12803706:	58                   	pop    rax
    7a0d12803707:	50                   	push   rax
    7a0d12803708:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d1280370c:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12803713:	89 c2                	mov    edx,eax
    7a0d12803715:	c1 ea 1b             	shr    edx,0x1b
    7a0d12803718:	41 89 55 00          	mov    DWORD PTR [r13+0x0],edx
    7a0d1280371c:	31 d2                	xor    edx,edx
    7a0d1280371e:	3d 00 00 00 08       	cmp    eax,0x8000000
    7a0d12803723:	0f 92 c2             	setb   dl
    7a0d12803726:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d1280372d:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    7a0d12803734:	00 00 00 00 
    7a0d12803738:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d1280373f:	00 00 00 00 
    7a0d12803743:	81 f9 34 01 01 00    	cmp    ecx,0x10134
    7a0d12803749:	0f 84 2d 12 00 18    	je     0x7a0d2a80497c
    7a0d1280374f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10134
    7a0d12803756:	34 01 01 00 
    7a0d1280375a:	0f 84 1c 12 00 18    	je     0x7a0d2a80497c
    7a0d12803760:	58                   	pop    rax
    7a0d12803761:	50                   	push   rax
    7a0d12803762:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12803766:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d1280376d:	31 d2                	xor    edx,edx
    7a0d1280376f:	41 0b 45 04          	or     eax,DWORD PTR [r13+0x4]
    7a0d12803773:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12803777:	0f 94 c2             	sete   dl
    7a0d1280377a:	c1 e8 1f             	shr    eax,0x1f
    7a0d1280377d:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12803784:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d1280378b:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12803792:	00 00 00 00 
    7a0d12803796:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d1280379d:	00 00 00 00 
    7a0d128037a1:	81 f9 36 01 01 00    	cmp    ecx,0x10136
    7a0d128037a7:	0f 84 2f 12 00 18    	je     0x7a0d2a8049dc
    7a0d128037ad:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10136
    7a0d128037b4:	36 01 01 00 
    7a0d128037b8:	0f 84 1e 12 00 18    	je     0x7a0d2a8049dc
    7a0d128037be:	58                   	pop    rax
    7a0d128037bf:	50                   	push   rax
    7a0d128037c0:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    7a0d128037c5:	b9 00 00 4a 7f       	mov    ecx,0x7f4a0000
    7a0d128037ca:	09 c1                	or     ecx,eax
    7a0d128037cc:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d128037d0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10138
    7a0d128037d7:	38 01 01 00 
    7a0d128037db:	0f 84 5b 12 00 18    	je     0x7a0d2a804a3c
    7a0d128037e1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10138
    7a0d128037e8:	38 01 01 00 
    7a0d128037ec:	0f 84 4a 12 00 18    	je     0x7a0d2a804a3c
    7a0d128037f2:	58                   	pop    rax
    7a0d128037f3:	50                   	push   rax
    7a0d128037f4:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d128037f8:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d128037fb:	f6 c3 03             	test   bl,0x3
    7a0d128037fe:	0f 85 98 12 00 18    	jne    0x7a0d2a804a9c
    7a0d12803804:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d1280380b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12803812:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d12803816:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d1280381d:	89 c8                	mov    eax,ecx
    7a0d1280381f:	c1 e8 0c             	shr    eax,0xc
    7a0d12803822:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12803827:	48 85 c0             	test   rax,rax
    7a0d1280382a:	0f 84 bf 12 00 18    	je     0x7a0d2a804aef
    7a0d12803830:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12803836:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12803839:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d1280383c:	89 d8                	mov    eax,ebx
    7a0d1280383e:	c1 e8 0c             	shr    eax,0xc
    7a0d12803841:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12803846:	48 85 c0             	test   rax,rax
    7a0d12803849:	0f 84 db 12 00 18    	je     0x7a0d2a804b2a
    7a0d1280384f:	89 d9                	mov    ecx,ebx
    7a0d12803851:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12803857:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d1280385b:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d1280385f:	b8 00 00 00 00       	mov    eax,0x0
    7a0d12803864:	29 c3                	sub    ebx,eax
    7a0d12803866:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d1280386a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1013c
    7a0d12803871:	3c 01 01 00 
    7a0d12803875:	0f 84 f0 12 00 18    	je     0x7a0d2a804b6b
    7a0d1280387b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1013c
    7a0d12803882:	3c 01 01 00 
    7a0d12803886:	0f 84 df 12 00 18    	je     0x7a0d2a804b6b
    7a0d1280388c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12803890:	0f 85 17 13 00 18    	jne    0x7a0d2a804bad
    7a0d12803896:	58                   	pop    rax
    7a0d12803897:	e9 0f 00 00 00       	jmp    0x7a0d128038ab
    7a0d1280389c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128038a3:	00 
    7a0d128038a4:	74 f0                	je     0x7a0d12803896
    7a0d128038a6:	e9 28 12 00 18       	jmp    0x7a0d2a804ad3
    7a0d128038ab:	50                   	push   rax
    7a0d128038ac:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    7a0d128038b1:	c1 e0 10             	shl    eax,0x10
    7a0d128038b4:	b9 15 7c 00 00       	mov    ecx,0x7c15
    7a0d128038b9:	09 c1                	or     ecx,eax
    7a0d128038bb:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d128038bf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10140
    7a0d128038c6:	40 01 01 00 
    7a0d128038ca:	0f 84 0f 13 00 18    	je     0x7a0d2a804bdf
    7a0d128038d0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10140
    7a0d128038d7:	40 01 01 00 
    7a0d128038db:	0f 84 fe 12 00 18    	je     0x7a0d2a804bdf
    7a0d128038e1:	58                   	pop    rax
    7a0d128038e2:	50                   	push   rax
    7a0d128038e3:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d128038e7:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    7a0d128038eb:	89 c2                	mov    edx,eax
    7a0d128038ed:	c1 ea 1f             	shr    edx,0x1f
    7a0d128038f0:	89 ce                	mov    esi,ecx
    7a0d128038f2:	c1 ee 1f             	shr    esi,0x1f
    7a0d128038f5:	31 ff                	xor    edi,edi
    7a0d128038f7:	01 c8                	add    eax,ecx
    7a0d128038f9:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d128038fd:	40 0f 92 c7          	setb   dil
    7a0d12803901:	89 c1                	mov    ecx,eax
    7a0d12803903:	c1 e9 1f             	shr    ecx,0x1f
    7a0d12803906:	31 ce                	xor    esi,ecx
    7a0d12803908:	31 ca                	xor    edx,ecx
    7a0d1280390a:	21 f2                	and    edx,esi
    7a0d1280390c:	31 f6                	xor    esi,esi
    7a0d1280390e:	85 c0                	test   eax,eax
    7a0d12803910:	40 0f 94 c6          	sete   sil
    7a0d12803914:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d1280391b:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7a0d12803922:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7a0d12803929:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7a0d12803930:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7a0d12803937:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d1280393e:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12803945:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10144
    7a0d1280394c:	44 01 01 00 
    7a0d12803950:	0f 84 e9 12 00 18    	je     0x7a0d2a804c3f
    7a0d12803956:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10144
    7a0d1280395d:	44 01 01 00 
    7a0d12803961:	0f 84 d8 12 00 18    	je     0x7a0d2a804c3f
    7a0d12803967:	58                   	pop    rax
    7a0d12803968:	50                   	push   rax
    7a0d12803969:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d1280396d:	f6 c3 03             	test   bl,0x3
    7a0d12803970:	0f 85 29 13 00 18    	jne    0x7a0d2a804c9f
    7a0d12803976:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d1280397d:	48 89 d8             	mov    rax,rbx
    7a0d12803980:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12803984:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12803989:	48 85 c0             	test   rax,rax
    7a0d1280398c:	0f 84 5f 13 00 18    	je     0x7a0d2a804cf1
    7a0d12803992:	89 d9                	mov    ecx,ebx
    7a0d12803994:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280399a:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d1280399e:	89 de                	mov    esi,ebx
    7a0d128039a0:	83 c6 04             	add    esi,0x4
    7a0d128039a3:	89 f0                	mov    eax,esi
    7a0d128039a5:	c1 e8 0c             	shr    eax,0xc
    7a0d128039a8:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128039ad:	48 85 c0             	test   rax,rax
    7a0d128039b0:	0f 84 78 13 00 18    	je     0x7a0d2a804d2e
    7a0d128039b6:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128039bc:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128039bf:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d128039c2:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d128039c6:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d128039cd:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d128039d1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10146
    7a0d128039d8:	46 01 01 00 
    7a0d128039dc:	0f 84 88 13 00 18    	je     0x7a0d2a804d6a
    7a0d128039e2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10146
    7a0d128039e9:	46 01 01 00 
    7a0d128039ed:	0f 84 77 13 00 18    	je     0x7a0d2a804d6a
    7a0d128039f3:	58                   	pop    rax
    7a0d128039f4:	50                   	push   rax
    7a0d128039f5:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d128039fc:	a8 01                	test   al,0x1
    7a0d128039fe:	0f 85 af 13 00 18    	jne    0x7a0d2a804db3
    7a0d12803a04:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12803a0b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12803a12:	01 
    7a0d12803a13:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1014a
    7a0d12803a1a:	4a 01 01 00 
    7a0d12803a1e:	0f 84 c5 13 00 18    	je     0x7a0d2a804de9
    7a0d12803a24:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1014a
    7a0d12803a2b:	4a 01 01 00 
    7a0d12803a2f:	0f 84 b4 13 00 18    	je     0x7a0d2a804de9
    7a0d12803a35:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12803a3c:	02 00 00 00 
    7a0d12803a40:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d12803a47:	09 00 00 00 
    7a0d12803a4b:	58                   	pop    rax
    7a0d12803a4c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803a53:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12803a5a:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12803a61:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12803a68:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12803a6f:	39 f1                	cmp    ecx,esi
    7a0d12803a71:	0f 83 9f 13 00 18    	jae    0x7a0d2a804e16
    7a0d12803a77:	81 fa 30 01 01 00    	cmp    edx,0x10130
    7a0d12803a7d:	75 14                	jne    0x7a0d12803a93
    7a0d12803a7f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803a86:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803a8d:	00 
    7a0d12803a8e:	e9 fd fb ff ff       	jmp    0x7a0d12803690
    7a0d12803a93:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12803a9a:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12803aa0:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12803aa3:	0f 85 6d 13 00 18    	jne    0x7a0d2a804e16
    7a0d12803aa9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803ab0:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803ab7:	00 
    7a0d12803ab8:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12803abd:	ff e0                	jmp    rax
