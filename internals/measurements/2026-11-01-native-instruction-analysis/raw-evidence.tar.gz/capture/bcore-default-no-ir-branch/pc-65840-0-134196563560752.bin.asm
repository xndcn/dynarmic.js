
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65840-0-134196563560752.bin:     file format binary


Disassembly of section .data:

00007a0d12804930 <.data>:
    7a0d12804930:	48 83 ec 38          	sub    rsp,0x38
    7a0d12804934:	b8 b5 fe fe ff       	mov    eax,0xfffefeb5
    7a0d12804939:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12804940:	01 c1                	add    ecx,eax
    7a0d12804942:	83 f9 e4             	cmp    ecx,0xffffffe4
    7a0d12804945:	0f 87 2d 14 00 18    	ja     0x7a0d2a805d78
    7a0d1280494b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7a0d12804952:	83 f8 e4             	cmp    eax,0xffffffe4
    7a0d12804955:	0f 87 1d 14 00 18    	ja     0x7a0d2a805d78
    7a0d1280495b:	4d 89 f3             	mov    r11,r14
    7a0d1280495e:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7a0d12804965:	4d 8b 95 38 01 00 00 	mov    r10,QWORD PTR [r13+0x138]
    7a0d1280496c:	49 8b b5 40 01 00 00 	mov    rsi,QWORD PTR [r13+0x140]
    7a0d12804973:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12804977:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    7a0d1280497b:	41 89 c7             	mov    r15d,eax
    7a0d1280497e:	41 c1 e7 05          	shl    r15d,0x5
    7a0d12804982:	41 0f b7 cf          	movzx  ecx,r15w
    7a0d12804986:	41 c1 ef 1f          	shr    r15d,0x1f
    7a0d1280498a:	c4 63 7b f0 f0 1b    	rorx   r14d,eax,0x1b
    7a0d12804990:	45 89 75 00          	mov    DWORD PTR [r13+0x0],r14d
    7a0d12804994:	31 d2                	xor    edx,edx
    7a0d12804996:	85 c0                	test   eax,eax
    7a0d12804998:	0f 94 c2             	sete   dl
    7a0d1280499b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d128049a2:	45 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r15d
    7a0d128049a9:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d128049b0:	00 00 00 00 
    7a0d128049b4:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d128049bb:	00 00 00 00 
    7a0d128049bf:	81 c9 00 00 4a 7f    	or     ecx,0x7f4a0000
    7a0d128049c5:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d128049c9:	41 8d 59 fc          	lea    ebx,[r9-0x4]
    7a0d128049cd:	41 f6 c1 03          	test   r9b,0x3
    7a0d128049d1:	0f 85 b0 13 00 18    	jne    0x7a0d2a805d87
    7a0d128049d7:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d128049de:	41 8b 7d 3c          	mov    edi,DWORD PTR [r13+0x3c]
    7a0d128049e2:	89 d8                	mov    eax,ebx
    7a0d128049e4:	c1 e8 0c             	shr    eax,0xc
    7a0d128049e7:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    7a0d128049ec:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    7a0d128049f0:	48 85 c0             	test   rax,rax
    7a0d128049f3:	0f 84 f8 13 00 18    	je     0x7a0d2a805df1
    7a0d128049f9:	89 d9                	mov    ecx,ebx
    7a0d128049fb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12804a01:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12804a04:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    7a0d12804a08:	41 89 ec             	mov    r12d,ebp
    7a0d12804a0b:	41 c1 ec 0c          	shr    r12d,0xc
    7a0d12804a0f:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    7a0d12804a13:	48 85 c0             	test   rax,rax
    7a0d12804a16:	0f 84 4e 14 00 18    	je     0x7a0d2a805e6a
    7a0d12804a1c:	89 e9                	mov    ecx,ebp
    7a0d12804a1e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12804a24:	89 3c 08             	mov    DWORD PTR [rax+rcx*1],edi
    7a0d12804a27:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7a0d12804a2b:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7a0d12804a2f:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    7a0d12804a32:	0f 85 aa 14 00 18    	jne    0x7a0d2a805ee2
    7a0d12804a38:	41 c7 45 04 15 7c 4a 	mov    DWORD PTR [r13+0x4],0x7f4a7c15
    7a0d12804a3f:	7f 
    7a0d12804a40:	41 8d 86 15 7c 4a 7f 	lea    eax,[r14+0x7f4a7c15]
    7a0d12804a47:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12804a4b:	89 c1                	mov    ecx,eax
    7a0d12804a4d:	c1 e9 1f             	shr    ecx,0x1f
    7a0d12804a50:	c4 e2 00 f2 d1       	andn   edx,r15d,ecx
    7a0d12804a55:	31 f6                	xor    esi,esi
    7a0d12804a57:	41 81 fe eb 83 b5 80 	cmp    r14d,0x80b583eb
    7a0d12804a5e:	40 0f 93 c6          	setae  sil
    7a0d12804a62:	31 ff                	xor    edi,edi
    7a0d12804a64:	85 c0                	test   eax,eax
    7a0d12804a66:	40 0f 94 c7          	sete   dil
    7a0d12804a6a:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    7a0d12804a71:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7a0d12804a78:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7a0d12804a7f:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7a0d12804a86:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7a0d12804a8d:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7a0d12804a94:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7a0d12804a9b:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    7a0d12804a9f:	48 85 c0             	test   rax,rax
    7a0d12804aa2:	0f 84 ae 14 00 18    	je     0x7a0d2a805f56
    7a0d12804aa8:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7a0d12804aae:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7a0d12804ab1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    7a0d12804ab6:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    7a0d12804aba:	48 85 c0             	test   rax,rax
    7a0d12804abd:	0f 84 fe 14 00 18    	je     0x7a0d2a805fc1
    7a0d12804ac3:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    7a0d12804ac9:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    7a0d12804acc:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7a0d12804ad0:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12804ad7:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    7a0d12804adb:	b1 01                	mov    cl,0x1
    7a0d12804add:	bb 09 00 00 00       	mov    ebx,0x9
    7a0d12804ae2:	bd 02 00 00 00       	mov    ebp,0x2
    7a0d12804ae7:	a8 01                	test   al,0x1
    7a0d12804ae9:	0f 85 2b 15 00 18    	jne    0x7a0d2a80601a
    7a0d12804aef:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7a0d12804af6:	01 da                	add    edx,ebx
    7a0d12804af8:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12804aff:	39 f2                	cmp    edx,esi
    7a0d12804b01:	73 37                	jae    0x7a0d12804b3a
    7a0d12804b03:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7a0d12804b0a:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12804b10:	41 39 04 30          	cmp    DWORD PTR [r8+rsi*1],eax
    7a0d12804b14:	75 24                	jne    0x7a0d12804b3a
    7a0d12804b16:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12804b1d:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7a0d12804b24:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12804b2b:	00 
    7a0d12804b2c:	49 8b 44 30 08       	mov    rax,QWORD PTR [r8+rsi*1+0x8]
    7a0d12804b31:	4d 89 de             	mov    r14,r11
    7a0d12804b34:	48 83 c4 38          	add    rsp,0x38
    7a0d12804b38:	ff e0                	jmp    rax
    7a0d12804b3a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12804b41:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    7a0d12804b48:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    7a0d12804b4f:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    7a0d12804b56:	48 83 c4 38          	add    rsp,0x38
    7a0d12804b5a:	c2 08 00             	ret    0x8
