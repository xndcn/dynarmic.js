
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66344-1-134196966202592.bin:     file format binary


Disassembly of section .data:

00007a0d2a801ce0 <.data>:
    7a0d2a801ce0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a801ce6:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a801ce9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a801cef:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a801cf6:	0f 87 e5 f7 ff e7    	ja     0x7a0d128014e1
    7a0d2a801cfc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x3
    7a0d2a801d03:	03 00 00 00 
    7a0d2a801d07:	e9 d5 f7 ff e7       	jmp    0x7a0d128014e1
    7a0d2a801d0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801d13:	28 03 01 00 
    7a0d2a801d17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801d1e:	02 00 00 00 
    7a0d2a801d22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801d29:	01 00 00 00 
    7a0d2a801d2d:	ba 28 03 01 00       	mov    edx,0x10328
    7a0d2a801d32:	4c 89 ef             	mov    rdi,r13
    7a0d2a801d35:	4c 89 f6             	mov    rsi,r14
    7a0d2a801d38:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a801d3e:	e8 3d e3 ff e7       	call   0x7a0d12800080
    7a0d2a801d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801d4a:	02 00 00 00 
    7a0d2a801d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801d55:	01 00 00 00 
    7a0d2a801d59:	58                   	pop    rax
    7a0d2a801d5a:	e9 10 03 00 e8       	jmp    0x7a0d1280206f
    7a0d2a801d5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801d66:	28 03 01 00 
    7a0d2a801d6a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801d71:	02 00 00 00 
    7a0d2a801d75:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801d7c:	01 00 00 00 
    7a0d2a801d80:	4c 89 f7             	mov    rdi,r14
    7a0d2a801d83:	89 ce                	mov    esi,ecx
    7a0d2a801d85:	e8 e6 e2 ff e7       	call   0x7a0d12800070
    7a0d2a801d8a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801d91:	00 
    7a0d2a801d92:	0f 84 88 f7 ff e7    	je     0x7a0d12801520
    7a0d2a801d98:	eb a9                	jmp    0x7a0d2a801d43
    7a0d2a801d9a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801da1:	28 03 01 00 
    7a0d2a801da5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801dac:	02 00 00 00 
    7a0d2a801db0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801db7:	01 00 00 00 
    7a0d2a801dbb:	4c 89 f7             	mov    rdi,r14
    7a0d2a801dbe:	e8 ad e2 ff e7       	call   0x7a0d12800070
    7a0d2a801dc3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801dca:	00 
    7a0d2a801dcb:	0f 84 72 f7 ff e7    	je     0x7a0d12801543
    7a0d2a801dd1:	e9 6d ff ff ff       	jmp    0x7a0d2a801d43
    7a0d2a801dd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801ddd:	28 03 01 00 
    7a0d2a801de1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801de8:	02 00 00 00 
    7a0d2a801dec:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801df3:	01 00 00 00 
    7a0d2a801df7:	4c 89 f7             	mov    rdi,r14
    7a0d2a801dfa:	e8 71 e2 ff e7       	call   0x7a0d12800070
    7a0d2a801dff:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801e06:	00 
    7a0d2a801e07:	0f 84 59 f7 ff e7    	je     0x7a0d12801566
    7a0d2a801e0d:	e9 31 ff ff ff       	jmp    0x7a0d2a801d43
    7a0d2a801e12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801e19:	28 03 01 00 
    7a0d2a801e1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801e24:	02 00 00 00 
    7a0d2a801e28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801e2f:	01 00 00 00 
    7a0d2a801e33:	4c 89 f7             	mov    rdi,r14
    7a0d2a801e36:	e8 35 e2 ff e7       	call   0x7a0d12800070
    7a0d2a801e3b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801e42:	00 
    7a0d2a801e43:	0f 84 40 f7 ff e7    	je     0x7a0d12801589
    7a0d2a801e49:	e9 f5 fe ff ff       	jmp    0x7a0d2a801d43
    7a0d2a801e4e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801e55:	28 03 01 00 
    7a0d2a801e59:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801e60:	02 00 00 00 
    7a0d2a801e64:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801e6b:	01 00 00 00 
    7a0d2a801e6f:	4c 89 f7             	mov    rdi,r14
    7a0d2a801e72:	89 de                	mov    esi,ebx
    7a0d2a801e74:	e8 f7 e1 ff e7       	call   0x7a0d12800070
    7a0d2a801e79:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801e80:	00 
    7a0d2a801e81:	0f 84 27 f7 ff e7    	je     0x7a0d128015ae
    7a0d2a801e87:	e9 b7 fe ff ff       	jmp    0x7a0d2a801d43
    7a0d2a801e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a801e93:	28 03 01 00 
    7a0d2a801e97:	b8 28 03 01 00       	mov    eax,0x10328
    7a0d2a801e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801ea3:	02 00 00 00 
    7a0d2a801ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801eae:	01 00 00 00 
    7a0d2a801eb2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a801eb5:	be 28 03 01 00       	mov    esi,0x10328
    7a0d2a801eba:	4c 89 ef             	mov    rdi,r13
    7a0d2a801ebd:	e8 9e e2 ff e7       	call   0x7a0d12800160
    7a0d2a801ec2:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a801ec6:	0f 84 18 f7 ff e7    	je     0x7a0d128015e4
    7a0d2a801ecc:	eb 0f                	jmp    0x7a0d2a801edd
    7a0d2a801ece:	b8 28 03 01 00       	mov    eax,0x10328
    7a0d2a801ed3:	83 c0 02             	add    eax,0x2
    7a0d2a801ed6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a801edd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a801ee4:	02 00 00 00 
    7a0d2a801ee8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a801eef:	01 00 00 00 
    7a0d2a801ef3:	4c 89 ef             	mov    rdi,r13
    7a0d2a801ef6:	e8 55 e2 ff e7       	call   0x7a0d12800150
    7a0d2a801efb:	e9 e4 f6 ff e7       	jmp    0x7a0d128015e4
    7a0d2a801f00:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    7a0d2a801f07:	2a 03 01 00 
    7a0d2a801f0b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801f12:	04 00 00 00 
    7a0d2a801f16:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a801f1d:	02 00 00 00 
    7a0d2a801f21:	ba 2a 03 01 00       	mov    edx,0x1032a
    7a0d2a801f26:	4c 89 ef             	mov    rdi,r13
    7a0d2a801f29:	4c 89 f6             	mov    rsi,r14
    7a0d2a801f2c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a801f32:	e8 49 e1 ff e7       	call   0x7a0d12800080
    7a0d2a801f37:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801f3e:	04 00 00 00 
    7a0d2a801f42:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a801f49:	02 00 00 00 
    7a0d2a801f4d:	58                   	pop    rax
    7a0d2a801f4e:	e9 1c 01 00 e8       	jmp    0x7a0d1280206f
    7a0d2a801f53:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    7a0d2a801f5a:	2a 03 01 00 
    7a0d2a801f5e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801f65:	04 00 00 00 
    7a0d2a801f69:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a801f70:	02 00 00 00 
    7a0d2a801f74:	4c 89 f7             	mov    rdi,r14
    7a0d2a801f77:	89 ce                	mov    esi,ecx
    7a0d2a801f79:	e8 f2 e0 ff e7       	call   0x7a0d12800070
    7a0d2a801f7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801f85:	00 
    7a0d2a801f86:	0f 84 ad f6 ff e7    	je     0x7a0d12801639
    7a0d2a801f8c:	eb a9                	jmp    0x7a0d2a801f37
    7a0d2a801f8e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    7a0d2a801f95:	2a 03 01 00 
    7a0d2a801f99:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801fa0:	04 00 00 00 
    7a0d2a801fa4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a801fab:	02 00 00 00 
    7a0d2a801faf:	4c 89 f7             	mov    rdi,r14
    7a0d2a801fb2:	89 de                	mov    esi,ebx
    7a0d2a801fb4:	44 89 e2             	mov    edx,r12d
    7a0d2a801fb7:	e8 b4 e0 ff e7       	call   0x7a0d12800070
    7a0d2a801fbc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a801fc3:	00 
    7a0d2a801fc4:	0f 84 91 f6 ff e7    	je     0x7a0d1280165b
    7a0d2a801fca:	e9 68 ff ff ff       	jmp    0x7a0d2a801f37
    7a0d2a801fcf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    7a0d2a801fd6:	2a 03 01 00 
    7a0d2a801fda:	b8 2a 03 01 00       	mov    eax,0x1032a
    7a0d2a801fdf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a801fe6:	04 00 00 00 
    7a0d2a801fea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a801ff1:	02 00 00 00 
    7a0d2a801ff5:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a801ff8:	be 2a 03 01 00       	mov    esi,0x1032a
    7a0d2a801ffd:	4c 89 ef             	mov    rdi,r13
    7a0d2a802000:	e8 5b e1 ff e7       	call   0x7a0d12800160
    7a0d2a802005:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a802009:	0f 84 8d f6 ff e7    	je     0x7a0d1280169c
    7a0d2a80200f:	eb 0f                	jmp    0x7a0d2a802020
    7a0d2a802011:	b8 2a 03 01 00       	mov    eax,0x1032a
    7a0d2a802016:	83 c0 04             	add    eax,0x4
    7a0d2a802019:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802020:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802027:	04 00 00 00 
    7a0d2a80202b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a802032:	02 00 00 00 
    7a0d2a802036:	4c 89 ef             	mov    rdi,r13
    7a0d2a802039:	e8 12 e1 ff e7       	call   0x7a0d12800150
    7a0d2a80203e:	e9 59 f6 ff e7       	jmp    0x7a0d1280169c
    7a0d2a802043:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    7a0d2a80204a:	2e 03 01 00 
    7a0d2a80204e:	b8 2e 03 01 00       	mov    eax,0x1032e
    7a0d2a802053:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80205a:	02 00 00 00 
    7a0d2a80205e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a802065:	03 00 00 00 
    7a0d2a802069:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80206c:	be 2e 03 01 00       	mov    esi,0x1032e
    7a0d2a802071:	4c 89 ef             	mov    rdi,r13
    7a0d2a802074:	e8 e7 e0 ff e7       	call   0x7a0d12800160
    7a0d2a802079:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802080:	00 
    7a0d2a802081:	0f 84 8c f6 ff e7    	je     0x7a0d12801713
    7a0d2a802087:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80208e:	02 00 00 00 
    7a0d2a802092:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a802099:	03 00 00 00 
    7a0d2a80209d:	58                   	pop    rax
    7a0d2a80209e:	e9 cc ff ff e7       	jmp    0x7a0d1280206f
    7a0d2a8020a3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10330
    7a0d2a8020aa:	30 03 01 00 
    7a0d2a8020ae:	b8 30 03 01 00       	mov    eax,0x10330
    7a0d2a8020b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8020ba:	02 00 00 00 
    7a0d2a8020be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8020c5:	04 00 00 00 
    7a0d2a8020c9:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8020cc:	be 30 03 01 00       	mov    esi,0x10330
    7a0d2a8020d1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8020d4:	e8 87 e0 ff e7       	call   0x7a0d12800160
    7a0d2a8020d9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8020e0:	00 
    7a0d2a8020e1:	0f 84 5a f6 ff e7    	je     0x7a0d12801741
    7a0d2a8020e7:	e9 94 f6 ff e7       	jmp    0x7a0d12801780
    7a0d2a8020ec:	b8 30 03 01 00       	mov    eax,0x10330
    7a0d2a8020f1:	83 c0 40             	add    eax,0x40
    7a0d2a8020f4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8020fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802102:	02 00 00 00 
    7a0d2a802106:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80210d:	04 00 00 00 
    7a0d2a802111:	be 30 03 01 00       	mov    esi,0x10330
    7a0d2a802116:	ba 30 03 01 00       	mov    edx,0x10330
    7a0d2a80211b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80211e:	e8 3d e0 ff e7       	call   0x7a0d12800160
    7a0d2a802123:	e9 49 f6 ff e7       	jmp    0x7a0d12801771
    7a0d2a802128:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10332
    7a0d2a80212f:	32 03 01 00 
    7a0d2a802133:	b8 32 03 01 00       	mov    eax,0x10332
    7a0d2a802138:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80213f:	02 00 00 00 
    7a0d2a802143:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80214a:	05 00 00 00 
    7a0d2a80214e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802151:	be 32 03 01 00       	mov    esi,0x10332
    7a0d2a802156:	4c 89 ef             	mov    rdi,r13
    7a0d2a802159:	e8 02 e0 ff e7       	call   0x7a0d12800160
    7a0d2a80215e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802165:	00 
    7a0d2a802166:	0f 84 89 f6 ff e7    	je     0x7a0d128017f5
    7a0d2a80216c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802173:	02 00 00 00 
    7a0d2a802177:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80217e:	05 00 00 00 
    7a0d2a802182:	58                   	pop    rax
    7a0d2a802183:	e9 e7 fe ff e7       	jmp    0x7a0d1280206f
    7a0d2a802188:	b8 34 03 01 00       	mov    eax,0x10334
    7a0d2a80218d:	83 c0 3c             	add    eax,0x3c
    7a0d2a802190:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802197:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80219e:	02 00 00 00 
    7a0d2a8021a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8021a9:	06 00 00 00 
    7a0d2a8021ad:	be 34 03 01 00       	mov    esi,0x10334
    7a0d2a8021b2:	ba 34 03 01 00       	mov    edx,0x10334
    7a0d2a8021b7:	4c 89 ef             	mov    rdi,r13
    7a0d2a8021ba:	e8 a1 df ff e7       	call   0x7a0d12800160
    7a0d2a8021bf:	e9 67 f6 ff e7       	jmp    0x7a0d1280182b
    7a0d2a8021c4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10334
    7a0d2a8021cb:	34 03 01 00 
    7a0d2a8021cf:	b8 34 03 01 00       	mov    eax,0x10334
    7a0d2a8021d4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8021db:	02 00 00 00 
    7a0d2a8021df:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8021e6:	06 00 00 00 
    7a0d2a8021ea:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8021ed:	be 34 03 01 00       	mov    esi,0x10334
    7a0d2a8021f2:	4c 89 ef             	mov    rdi,r13
    7a0d2a8021f5:	e8 66 df ff e7       	call   0x7a0d12800160
    7a0d2a8021fa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802201:	00 
    7a0d2a802202:	0f 84 70 f6 ff e7    	je     0x7a0d12801878
    7a0d2a802208:	e9 2d f6 ff e7       	jmp    0x7a0d1280183a
    7a0d2a80220d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10336
    7a0d2a802214:	36 03 01 00 
    7a0d2a802218:	b8 36 03 01 00       	mov    eax,0x10336
    7a0d2a80221d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802224:	04 00 00 00 
    7a0d2a802228:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a80222f:	07 00 00 00 
    7a0d2a802233:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a802236:	be 36 03 01 00       	mov    esi,0x10336
    7a0d2a80223b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80223e:	e8 1d df ff e7       	call   0x7a0d12800160
    7a0d2a802243:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80224a:	00 
    7a0d2a80224b:	0f 84 53 f6 ff e7    	je     0x7a0d128018a4
    7a0d2a802251:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802258:	04 00 00 00 
    7a0d2a80225c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a802263:	07 00 00 00 
    7a0d2a802267:	58                   	pop    rax
    7a0d2a802268:	e9 02 fe ff e7       	jmp    0x7a0d1280206f
    7a0d2a80226d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033a
    7a0d2a802274:	3a 03 01 00 
    7a0d2a802278:	b8 3a 03 01 00       	mov    eax,0x1033a
    7a0d2a80227d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802284:	02 00 00 00 
    7a0d2a802288:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a80228f:	08 00 00 00 
    7a0d2a802293:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802296:	be 3a 03 01 00       	mov    esi,0x1033a
    7a0d2a80229b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80229e:	e8 bd de ff e7       	call   0x7a0d12800160
    7a0d2a8022a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8022aa:	00 
    7a0d2a8022ab:	0f 84 45 f6 ff e7    	je     0x7a0d128018f6
    7a0d2a8022b1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8022b8:	02 00 00 00 
    7a0d2a8022bc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8022c3:	08 00 00 00 
    7a0d2a8022c7:	58                   	pop    rax
    7a0d2a8022c8:	e9 a2 fd ff e7       	jmp    0x7a0d1280206f
    7a0d2a8022cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033c
    7a0d2a8022d4:	3c 03 01 00 
    7a0d2a8022d8:	b8 3c 03 01 00       	mov    eax,0x1033c
    7a0d2a8022dd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8022e4:	02 00 00 00 
    7a0d2a8022e8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8022ef:	09 00 00 00 
    7a0d2a8022f3:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8022f6:	be 3c 03 01 00       	mov    esi,0x1033c
    7a0d2a8022fb:	4c 89 ef             	mov    rdi,r13
    7a0d2a8022fe:	e8 5d de ff e7       	call   0x7a0d12800160
    7a0d2a802303:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80230a:	00 
    7a0d2a80230b:	0f 84 4c f6 ff e7    	je     0x7a0d1280195d
    7a0d2a802311:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802318:	02 00 00 00 
    7a0d2a80231c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a802323:	09 00 00 00 
    7a0d2a802327:	58                   	pop    rax
    7a0d2a802328:	e9 42 fd ff e7       	jmp    0x7a0d1280206f
    7a0d2a80232d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033e
    7a0d2a802334:	3e 03 01 00 
    7a0d2a802338:	b8 3e 03 01 00       	mov    eax,0x1033e
    7a0d2a80233d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802344:	02 00 00 00 
    7a0d2a802348:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a80234f:	0a 00 00 00 
    7a0d2a802353:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802356:	be 3e 03 01 00       	mov    esi,0x1033e
    7a0d2a80235b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80235e:	e8 fd dd ff e7       	call   0x7a0d12800160
    7a0d2a802363:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80236a:	00 
    7a0d2a80236b:	0f 84 1a f6 ff e7    	je     0x7a0d1280198b
    7a0d2a802371:	e9 54 f6 ff e7       	jmp    0x7a0d128019ca
    7a0d2a802376:	b8 3e 03 01 00       	mov    eax,0x1033e
    7a0d2a80237b:	83 c0 32             	add    eax,0x32
    7a0d2a80237e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802385:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80238c:	02 00 00 00 
    7a0d2a802390:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a802397:	0a 00 00 00 
    7a0d2a80239b:	be 3e 03 01 00       	mov    esi,0x1033e
    7a0d2a8023a0:	ba 3e 03 01 00       	mov    edx,0x1033e
    7a0d2a8023a5:	4c 89 ef             	mov    rdi,r13
    7a0d2a8023a8:	e8 b3 dd ff e7       	call   0x7a0d12800160
    7a0d2a8023ad:	e9 09 f6 ff e7       	jmp    0x7a0d128019bb
    7a0d2a8023b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10340
    7a0d2a8023b9:	40 03 01 00 
    7a0d2a8023bd:	b8 40 03 01 00       	mov    eax,0x10340
    7a0d2a8023c2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8023c9:	04 00 00 00 
    7a0d2a8023cd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a8023d4:	0b 00 00 00 
    7a0d2a8023d8:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8023db:	be 40 03 01 00       	mov    esi,0x10340
    7a0d2a8023e0:	4c 89 ef             	mov    rdi,r13
    7a0d2a8023e3:	e8 78 dd ff e7       	call   0x7a0d12800160
    7a0d2a8023e8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8023ef:	00 
    7a0d2a8023f0:	0f 84 23 f6 ff e7    	je     0x7a0d12801a19
    7a0d2a8023f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8023fd:	04 00 00 00 
    7a0d2a802401:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a802408:	0b 00 00 00 
    7a0d2a80240c:	58                   	pop    rax
    7a0d2a80240d:	e9 5d fc ff e7       	jmp    0x7a0d1280206f
    7a0d2a802412:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10344
    7a0d2a802419:	44 03 01 00 
    7a0d2a80241d:	b8 44 03 01 00       	mov    eax,0x10344
    7a0d2a802422:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802429:	04 00 00 00 
    7a0d2a80242d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a802434:	0c 00 00 00 
    7a0d2a802438:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a80243b:	be 44 03 01 00       	mov    esi,0x10344
    7a0d2a802440:	4c 89 ef             	mov    rdi,r13
    7a0d2a802443:	e8 18 dd ff e7       	call   0x7a0d12800160
    7a0d2a802448:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80244f:	00 
    7a0d2a802450:	0f 84 fa f5 ff e7    	je     0x7a0d12801a50
    7a0d2a802456:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80245d:	04 00 00 00 
    7a0d2a802461:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a802468:	0c 00 00 00 
    7a0d2a80246c:	58                   	pop    rax
    7a0d2a80246d:	e9 fd fb ff e7       	jmp    0x7a0d1280206f
    7a0d2a802472:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    7a0d2a802479:	48 03 01 00 
    7a0d2a80247d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802484:	02 00 00 00 
    7a0d2a802488:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a80248f:	0d 00 00 00 
    7a0d2a802493:	ba 48 03 01 00       	mov    edx,0x10348
    7a0d2a802498:	4c 89 ef             	mov    rdi,r13
    7a0d2a80249b:	4c 89 f6             	mov    rsi,r14
    7a0d2a80249e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a8024a4:	e8 d7 db ff e7       	call   0x7a0d12800080
    7a0d2a8024a9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8024b0:	02 00 00 00 
    7a0d2a8024b4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8024bb:	0d 00 00 00 
    7a0d2a8024bf:	58                   	pop    rax
    7a0d2a8024c0:	e9 aa fb ff e7       	jmp    0x7a0d1280206f
    7a0d2a8024c5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    7a0d2a8024cc:	48 03 01 00 
    7a0d2a8024d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8024d7:	02 00 00 00 
    7a0d2a8024db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8024e2:	0d 00 00 00 
    7a0d2a8024e6:	4c 89 f7             	mov    rdi,r14
    7a0d2a8024e9:	89 ce                	mov    esi,ecx
    7a0d2a8024eb:	e8 80 db ff e7       	call   0x7a0d12800070
    7a0d2a8024f0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8024f7:	00 
    7a0d2a8024f8:	0f 84 90 f5 ff e7    	je     0x7a0d12801a8e
    7a0d2a8024fe:	eb a9                	jmp    0x7a0d2a8024a9
    7a0d2a802500:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    7a0d2a802507:	48 03 01 00 
    7a0d2a80250b:	b8 48 03 01 00       	mov    eax,0x10348
    7a0d2a802510:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802517:	02 00 00 00 
    7a0d2a80251b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a802522:	0d 00 00 00 
    7a0d2a802526:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802529:	be 48 03 01 00       	mov    esi,0x10348
    7a0d2a80252e:	4c 89 ef             	mov    rdi,r13
    7a0d2a802531:	e8 2a dc ff e7       	call   0x7a0d12800160
    7a0d2a802536:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a802539:	0f 84 80 f5 ff e7    	je     0x7a0d12801abf
    7a0d2a80253f:	eb 0f                	jmp    0x7a0d2a802550
    7a0d2a802541:	b8 48 03 01 00       	mov    eax,0x10348
    7a0d2a802546:	83 c0 02             	add    eax,0x2
    7a0d2a802549:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802550:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802557:	02 00 00 00 
    7a0d2a80255b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a802562:	0d 00 00 00 
    7a0d2a802566:	4c 89 ef             	mov    rdi,r13
    7a0d2a802569:	e8 e2 db ff e7       	call   0x7a0d12800150
    7a0d2a80256e:	e9 4c f5 ff e7       	jmp    0x7a0d12801abf
    7a0d2a802573:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    7a0d2a80257a:	4a 03 01 00 
    7a0d2a80257e:	b8 4a 03 01 00       	mov    eax,0x1034a
    7a0d2a802583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80258a:	04 00 00 00 
    7a0d2a80258e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a802595:	0e 00 00 00 
    7a0d2a802599:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a80259c:	be 4a 03 01 00       	mov    esi,0x1034a
    7a0d2a8025a1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8025a4:	e8 b7 db ff e7       	call   0x7a0d12800160
    7a0d2a8025a9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8025b0:	00 
    7a0d2a8025b1:	0f 84 4a f5 ff e7    	je     0x7a0d12801b01
    7a0d2a8025b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8025be:	04 00 00 00 
    7a0d2a8025c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a8025c9:	0e 00 00 00 
    7a0d2a8025cd:	58                   	pop    rax
    7a0d2a8025ce:	e9 9c fa ff e7       	jmp    0x7a0d1280206f
    7a0d2a8025d3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034e
    7a0d2a8025da:	4e 03 01 00 
    7a0d2a8025de:	b8 4e 03 01 00       	mov    eax,0x1034e
    7a0d2a8025e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8025ea:	04 00 00 00 
    7a0d2a8025ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a8025f5:	0f 00 00 00 
    7a0d2a8025f9:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8025fc:	be 4e 03 01 00       	mov    esi,0x1034e
    7a0d2a802601:	4c 89 ef             	mov    rdi,r13
    7a0d2a802604:	e8 57 db ff e7       	call   0x7a0d12800160
    7a0d2a802609:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802610:	00 
    7a0d2a802611:	0f 84 21 f5 ff e7    	je     0x7a0d12801b38
    7a0d2a802617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80261e:	04 00 00 00 
    7a0d2a802622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a802629:	0f 00 00 00 
    7a0d2a80262d:	58                   	pop    rax
    7a0d2a80262e:	e9 3c fa ff e7       	jmp    0x7a0d1280206f
    7a0d2a802633:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    7a0d2a80263a:	52 03 01 00 
    7a0d2a80263e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802645:	02 00 00 00 
    7a0d2a802649:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a802650:	10 00 00 00 
    7a0d2a802654:	ba 52 03 01 00       	mov    edx,0x10352
    7a0d2a802659:	4c 89 ef             	mov    rdi,r13
    7a0d2a80265c:	4c 89 f6             	mov    rsi,r14
    7a0d2a80265f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a802665:	e8 16 da ff e7       	call   0x7a0d12800080
    7a0d2a80266a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802671:	02 00 00 00 
    7a0d2a802675:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a80267c:	10 00 00 00 
    7a0d2a802680:	58                   	pop    rax
    7a0d2a802681:	e9 e9 f9 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802686:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    7a0d2a80268d:	52 03 01 00 
    7a0d2a802691:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802698:	02 00 00 00 
    7a0d2a80269c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a8026a3:	10 00 00 00 
    7a0d2a8026a7:	4c 89 f7             	mov    rdi,r14
    7a0d2a8026aa:	89 ce                	mov    esi,ecx
    7a0d2a8026ac:	e8 bf d9 ff e7       	call   0x7a0d12800070
    7a0d2a8026b1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8026b8:	00 
    7a0d2a8026b9:	0f 84 b7 f4 ff e7    	je     0x7a0d12801b76
    7a0d2a8026bf:	eb a9                	jmp    0x7a0d2a80266a
    7a0d2a8026c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    7a0d2a8026c8:	52 03 01 00 
    7a0d2a8026cc:	b8 52 03 01 00       	mov    eax,0x10352
    7a0d2a8026d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8026d8:	02 00 00 00 
    7a0d2a8026dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a8026e3:	10 00 00 00 
    7a0d2a8026e7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8026ea:	be 52 03 01 00       	mov    esi,0x10352
    7a0d2a8026ef:	4c 89 ef             	mov    rdi,r13
    7a0d2a8026f2:	e8 69 da ff e7       	call   0x7a0d12800160
    7a0d2a8026f7:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a8026fa:	0f 84 a7 f4 ff e7    	je     0x7a0d12801ba7
    7a0d2a802700:	eb 0f                	jmp    0x7a0d2a802711
    7a0d2a802702:	b8 52 03 01 00       	mov    eax,0x10352
    7a0d2a802707:	83 c0 02             	add    eax,0x2
    7a0d2a80270a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802711:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802718:	02 00 00 00 
    7a0d2a80271c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a802723:	10 00 00 00 
    7a0d2a802727:	4c 89 ef             	mov    rdi,r13
    7a0d2a80272a:	e8 21 da ff e7       	call   0x7a0d12800150
    7a0d2a80272f:	e9 73 f4 ff e7       	jmp    0x7a0d12801ba7
    7a0d2a802734:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    7a0d2a80273b:	54 03 01 00 
    7a0d2a80273f:	b8 54 03 01 00       	mov    eax,0x10354
    7a0d2a802744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80274b:	04 00 00 00 
    7a0d2a80274f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    7a0d2a802756:	11 00 00 00 
    7a0d2a80275a:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a80275d:	be 54 03 01 00       	mov    esi,0x10354
    7a0d2a802762:	4c 89 ef             	mov    rdi,r13
    7a0d2a802765:	e8 f6 d9 ff e7       	call   0x7a0d12800160
    7a0d2a80276a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802771:	00 
    7a0d2a802772:	0f 84 71 f4 ff e7    	je     0x7a0d12801be9
    7a0d2a802778:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80277f:	04 00 00 00 
    7a0d2a802783:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    7a0d2a80278a:	11 00 00 00 
    7a0d2a80278e:	58                   	pop    rax
    7a0d2a80278f:	e9 db f8 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802794:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10358
    7a0d2a80279b:	58 03 01 00 
    7a0d2a80279f:	b8 58 03 01 00       	mov    eax,0x10358
    7a0d2a8027a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8027ab:	04 00 00 00 
    7a0d2a8027af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    7a0d2a8027b6:	12 00 00 00 
    7a0d2a8027ba:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8027bd:	be 58 03 01 00       	mov    esi,0x10358
    7a0d2a8027c2:	4c 89 ef             	mov    rdi,r13
    7a0d2a8027c5:	e8 96 d9 ff e7       	call   0x7a0d12800160
    7a0d2a8027ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8027d1:	00 
    7a0d2a8027d2:	0f 84 48 f4 ff e7    	je     0x7a0d12801c20
    7a0d2a8027d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8027df:	04 00 00 00 
    7a0d2a8027e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    7a0d2a8027ea:	12 00 00 00 
    7a0d2a8027ee:	58                   	pop    rax
    7a0d2a8027ef:	e9 7b f8 ff e7       	jmp    0x7a0d1280206f
    7a0d2a8027f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    7a0d2a8027fb:	5c 03 01 00 
    7a0d2a8027ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802806:	02 00 00 00 
    7a0d2a80280a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a802811:	13 00 00 00 
    7a0d2a802815:	ba 5c 03 01 00       	mov    edx,0x1035c
    7a0d2a80281a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80281d:	4c 89 f6             	mov    rsi,r14
    7a0d2a802820:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a802826:	e8 55 d8 ff e7       	call   0x7a0d12800080
    7a0d2a80282b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802832:	02 00 00 00 
    7a0d2a802836:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a80283d:	13 00 00 00 
    7a0d2a802841:	58                   	pop    rax
    7a0d2a802842:	e9 28 f8 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802847:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    7a0d2a80284e:	5c 03 01 00 
    7a0d2a802852:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802859:	02 00 00 00 
    7a0d2a80285d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a802864:	13 00 00 00 
    7a0d2a802868:	4c 89 f7             	mov    rdi,r14
    7a0d2a80286b:	89 ce                	mov    esi,ecx
    7a0d2a80286d:	e8 fe d7 ff e7       	call   0x7a0d12800070
    7a0d2a802872:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802879:	00 
    7a0d2a80287a:	0f 84 de f3 ff e7    	je     0x7a0d12801c5e
    7a0d2a802880:	eb a9                	jmp    0x7a0d2a80282b
    7a0d2a802882:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    7a0d2a802889:	5c 03 01 00 
    7a0d2a80288d:	b8 5c 03 01 00       	mov    eax,0x1035c
    7a0d2a802892:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802899:	02 00 00 00 
    7a0d2a80289d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a8028a4:	13 00 00 00 
    7a0d2a8028a8:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8028ab:	be 5c 03 01 00       	mov    esi,0x1035c
    7a0d2a8028b0:	4c 89 ef             	mov    rdi,r13
    7a0d2a8028b3:	e8 a8 d8 ff e7       	call   0x7a0d12800160
    7a0d2a8028b8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a8028bb:	0f 84 ce f3 ff e7    	je     0x7a0d12801c8f
    7a0d2a8028c1:	eb 0f                	jmp    0x7a0d2a8028d2
    7a0d2a8028c3:	b8 5c 03 01 00       	mov    eax,0x1035c
    7a0d2a8028c8:	83 c0 02             	add    eax,0x2
    7a0d2a8028cb:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8028d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8028d9:	02 00 00 00 
    7a0d2a8028dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    7a0d2a8028e4:	13 00 00 00 
    7a0d2a8028e8:	4c 89 ef             	mov    rdi,r13
    7a0d2a8028eb:	e8 60 d8 ff e7       	call   0x7a0d12800150
    7a0d2a8028f0:	e9 9a f3 ff e7       	jmp    0x7a0d12801c8f
    7a0d2a8028f5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    7a0d2a8028fc:	5e 03 01 00 
    7a0d2a802900:	b8 5e 03 01 00       	mov    eax,0x1035e
    7a0d2a802905:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80290c:	02 00 00 00 
    7a0d2a802910:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    7a0d2a802917:	14 00 00 00 
    7a0d2a80291b:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80291e:	be 5e 03 01 00       	mov    esi,0x1035e
    7a0d2a802923:	4c 89 ef             	mov    rdi,r13
    7a0d2a802926:	e8 35 d8 ff e7       	call   0x7a0d12800160
    7a0d2a80292b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802932:	00 
    7a0d2a802933:	0f 84 c9 f3 ff e7    	je     0x7a0d12801d02
    7a0d2a802939:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802940:	02 00 00 00 
    7a0d2a802944:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    7a0d2a80294b:	14 00 00 00 
    7a0d2a80294f:	58                   	pop    rax
    7a0d2a802950:	e9 1a f7 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802955:	b8 60 03 01 00       	mov    eax,0x10360
    7a0d2a80295a:	83 c0 1a             	add    eax,0x1a
    7a0d2a80295d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802964:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80296b:	02 00 00 00 
    7a0d2a80296f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a802976:	15 00 00 00 
    7a0d2a80297a:	be 60 03 01 00       	mov    esi,0x10360
    7a0d2a80297f:	ba 60 03 01 00       	mov    edx,0x10360
    7a0d2a802984:	4c 89 ef             	mov    rdi,r13
    7a0d2a802987:	e8 d4 d7 ff e7       	call   0x7a0d12800160
    7a0d2a80298c:	e9 a7 f3 ff e7       	jmp    0x7a0d12801d38
    7a0d2a802991:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10360
    7a0d2a802998:	60 03 01 00 
    7a0d2a80299c:	b8 60 03 01 00       	mov    eax,0x10360
    7a0d2a8029a1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8029a8:	02 00 00 00 
    7a0d2a8029ac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d2a8029b3:	15 00 00 00 
    7a0d2a8029b7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8029ba:	be 60 03 01 00       	mov    esi,0x10360
    7a0d2a8029bf:	4c 89 ef             	mov    rdi,r13
    7a0d2a8029c2:	e8 99 d7 ff e7       	call   0x7a0d12800160
    7a0d2a8029c7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8029ce:	00 
    7a0d2a8029cf:	0f 84 b0 f3 ff e7    	je     0x7a0d12801d85
    7a0d2a8029d5:	e9 6d f3 ff e7       	jmp    0x7a0d12801d47
    7a0d2a8029da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10362
    7a0d2a8029e1:	62 03 01 00 
    7a0d2a8029e5:	b8 62 03 01 00       	mov    eax,0x10362
    7a0d2a8029ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8029f1:	02 00 00 00 
    7a0d2a8029f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    7a0d2a8029fc:	16 00 00 00 
    7a0d2a802a00:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802a03:	be 62 03 01 00       	mov    esi,0x10362
    7a0d2a802a08:	4c 89 ef             	mov    rdi,r13
    7a0d2a802a0b:	e8 50 d7 ff e7       	call   0x7a0d12800160
    7a0d2a802a10:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802a17:	00 
    7a0d2a802a18:	0f 84 cc f3 ff e7    	je     0x7a0d12801dea
    7a0d2a802a1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802a25:	02 00 00 00 
    7a0d2a802a29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    7a0d2a802a30:	16 00 00 00 
    7a0d2a802a34:	58                   	pop    rax
    7a0d2a802a35:	e9 35 f6 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802a3a:	b8 64 03 01 00       	mov    eax,0x10364
    7a0d2a802a3f:	83 c0 40             	add    eax,0x40
    7a0d2a802a42:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a802a49:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802a50:	02 00 00 00 
    7a0d2a802a54:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    7a0d2a802a5b:	17 00 00 00 
    7a0d2a802a5f:	be 64 03 01 00       	mov    esi,0x10364
    7a0d2a802a64:	ba 64 03 01 00       	mov    edx,0x10364
    7a0d2a802a69:	4c 89 ef             	mov    rdi,r13
    7a0d2a802a6c:	e8 ef d6 ff e7       	call   0x7a0d12800160
    7a0d2a802a71:	e9 aa f3 ff e7       	jmp    0x7a0d12801e20
    7a0d2a802a76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10364
    7a0d2a802a7d:	64 03 01 00 
    7a0d2a802a81:	b8 64 03 01 00       	mov    eax,0x10364
    7a0d2a802a86:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802a8d:	02 00 00 00 
    7a0d2a802a91:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    7a0d2a802a98:	17 00 00 00 
    7a0d2a802a9c:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802a9f:	be 64 03 01 00       	mov    esi,0x10364
    7a0d2a802aa4:	4c 89 ef             	mov    rdi,r13
    7a0d2a802aa7:	e8 b4 d6 ff e7       	call   0x7a0d12800160
    7a0d2a802aac:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802ab3:	00 
    7a0d2a802ab4:	0f 84 b3 f3 ff e7    	je     0x7a0d12801e6d
    7a0d2a802aba:	e9 70 f3 ff e7       	jmp    0x7a0d12801e2f
    7a0d2a802abf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10366
    7a0d2a802ac6:	66 03 01 00 
    7a0d2a802aca:	b8 66 03 01 00       	mov    eax,0x10366
    7a0d2a802acf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802ad6:	02 00 00 00 
    7a0d2a802ada:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    7a0d2a802ae1:	18 00 00 00 
    7a0d2a802ae5:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802ae8:	be 66 03 01 00       	mov    esi,0x10366
    7a0d2a802aed:	4c 89 ef             	mov    rdi,r13
    7a0d2a802af0:	e8 6b d6 ff e7       	call   0x7a0d12800160
    7a0d2a802af5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802afc:	00 
    7a0d2a802afd:	0f 84 96 f3 ff e7    	je     0x7a0d12801e99
    7a0d2a802b03:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802b0a:	02 00 00 00 
    7a0d2a802b0e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    7a0d2a802b15:	18 00 00 00 
    7a0d2a802b19:	58                   	pop    rax
    7a0d2a802b1a:	e9 50 f5 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802b1f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    7a0d2a802b26:	68 03 01 00 
    7a0d2a802b2a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802b31:	04 00 00 00 
    7a0d2a802b35:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a802b3c:	19 00 00 00 
    7a0d2a802b40:	ba 68 03 01 00       	mov    edx,0x10368
    7a0d2a802b45:	4c 89 ef             	mov    rdi,r13
    7a0d2a802b48:	4c 89 f6             	mov    rsi,r14
    7a0d2a802b4b:	89 d9                	mov    ecx,ebx
    7a0d2a802b4d:	45 31 c0             	xor    r8d,r8d
    7a0d2a802b50:	e8 2b d5 ff e7       	call   0x7a0d12800080
    7a0d2a802b55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802b5c:	04 00 00 00 
    7a0d2a802b60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a802b67:	19 00 00 00 
    7a0d2a802b6b:	58                   	pop    rax
    7a0d2a802b6c:	e9 fe f4 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802b71:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    7a0d2a802b78:	68 03 01 00 
    7a0d2a802b7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802b83:	04 00 00 00 
    7a0d2a802b87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a802b8e:	19 00 00 00 
    7a0d2a802b92:	4c 89 f7             	mov    rdi,r14
    7a0d2a802b95:	89 de                	mov    esi,ebx
    7a0d2a802b97:	e8 a4 d4 ff e7       	call   0x7a0d12800040
    7a0d2a802b9c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802ba3:	00 
    7a0d2a802ba4:	75 af                	jne    0x7a0d2a802b55
    7a0d2a802ba6:	41 89 c7             	mov    r15d,eax
    7a0d2a802ba9:	e9 22 f3 ff e7       	jmp    0x7a0d12801ed0
    7a0d2a802bae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    7a0d2a802bb5:	68 03 01 00 
    7a0d2a802bb9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802bc0:	04 00 00 00 
    7a0d2a802bc4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a802bcb:	19 00 00 00 
    7a0d2a802bcf:	4c 89 f7             	mov    rdi,r14
    7a0d2a802bd2:	e8 69 d4 ff e7       	call   0x7a0d12800040
    7a0d2a802bd7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802bde:	00 
    7a0d2a802bdf:	0f 84 0c f3 ff e7    	je     0x7a0d12801ef1
    7a0d2a802be5:	e9 6b ff ff ff       	jmp    0x7a0d2a802b55
    7a0d2a802bea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    7a0d2a802bf1:	68 03 01 00 
    7a0d2a802bf5:	b8 68 03 01 00       	mov    eax,0x10368
    7a0d2a802bfa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a802c01:	04 00 00 00 
    7a0d2a802c05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    7a0d2a802c0c:	19 00 00 00 
    7a0d2a802c10:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a802c13:	be 68 03 01 00       	mov    esi,0x10368
    7a0d2a802c18:	4c 89 ef             	mov    rdi,r13
    7a0d2a802c1b:	e8 40 d5 ff e7       	call   0x7a0d12800160
    7a0d2a802c20:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802c27:	00 
    7a0d2a802c28:	0f 84 f7 f2 ff e7    	je     0x7a0d12801f25
    7a0d2a802c2e:	e9 22 ff ff ff       	jmp    0x7a0d2a802b55
    7a0d2a802c33:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802c3a:	6c 03 01 00 
    7a0d2a802c3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802c45:	02 00 00 00 
    7a0d2a802c49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802c50:	1a 00 00 00 
    7a0d2a802c54:	ba 6c 03 01 00       	mov    edx,0x1036c
    7a0d2a802c59:	4c 89 ef             	mov    rdi,r13
    7a0d2a802c5c:	4c 89 f6             	mov    rsi,r14
    7a0d2a802c5f:	89 d9                	mov    ecx,ebx
    7a0d2a802c61:	45 31 c0             	xor    r8d,r8d
    7a0d2a802c64:	e8 17 d4 ff e7       	call   0x7a0d12800080
    7a0d2a802c69:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802c70:	02 00 00 00 
    7a0d2a802c74:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802c7b:	1a 00 00 00 
    7a0d2a802c7f:	58                   	pop    rax
    7a0d2a802c80:	e9 ea f3 ff e7       	jmp    0x7a0d1280206f
    7a0d2a802c85:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802c8c:	6c 03 01 00 
    7a0d2a802c90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802c97:	02 00 00 00 
    7a0d2a802c9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802ca2:	1a 00 00 00 
    7a0d2a802ca6:	4c 89 f7             	mov    rdi,r14
    7a0d2a802ca9:	89 de                	mov    esi,ebx
    7a0d2a802cab:	e8 90 d3 ff e7       	call   0x7a0d12800040
    7a0d2a802cb0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802cb7:	00 
    7a0d2a802cb8:	0f 84 9d f2 ff e7    	je     0x7a0d12801f5b
    7a0d2a802cbe:	eb a9                	jmp    0x7a0d2a802c69
    7a0d2a802cc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802cc7:	6c 03 01 00 
    7a0d2a802ccb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802cd2:	02 00 00 00 
    7a0d2a802cd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802cdd:	1a 00 00 00 
    7a0d2a802ce1:	4c 89 f7             	mov    rdi,r14
    7a0d2a802ce4:	e8 57 d3 ff e7       	call   0x7a0d12800040
    7a0d2a802ce9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802cf0:	00 
    7a0d2a802cf1:	0f 84 87 f2 ff e7    	je     0x7a0d12801f7e
    7a0d2a802cf7:	e9 6d ff ff ff       	jmp    0x7a0d2a802c69
    7a0d2a802cfc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802d03:	6c 03 01 00 
    7a0d2a802d07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802d0e:	02 00 00 00 
    7a0d2a802d12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802d19:	1a 00 00 00 
    7a0d2a802d1d:	4c 89 f7             	mov    rdi,r14
    7a0d2a802d20:	e8 1b d3 ff e7       	call   0x7a0d12800040
    7a0d2a802d25:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802d2c:	00 
    7a0d2a802d2d:	0f 84 6e f2 ff e7    	je     0x7a0d12801fa1
    7a0d2a802d33:	e9 31 ff ff ff       	jmp    0x7a0d2a802c69
    7a0d2a802d38:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802d3f:	6c 03 01 00 
    7a0d2a802d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802d4a:	02 00 00 00 
    7a0d2a802d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802d55:	1a 00 00 00 
    7a0d2a802d59:	4c 89 f7             	mov    rdi,r14
    7a0d2a802d5c:	e8 df d2 ff e7       	call   0x7a0d12800040
    7a0d2a802d61:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802d68:	00 
    7a0d2a802d69:	0f 84 55 f2 ff e7    	je     0x7a0d12801fc4
    7a0d2a802d6f:	e9 f5 fe ff ff       	jmp    0x7a0d2a802c69
    7a0d2a802d74:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802d7b:	6c 03 01 00 
    7a0d2a802d7f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802d86:	02 00 00 00 
    7a0d2a802d8a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802d91:	1a 00 00 00 
    7a0d2a802d95:	4c 89 f7             	mov    rdi,r14
    7a0d2a802d98:	e8 a3 d2 ff e7       	call   0x7a0d12800040
    7a0d2a802d9d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802da4:	00 
    7a0d2a802da5:	0f 84 3e f2 ff e7    	je     0x7a0d12801fe9
    7a0d2a802dab:	e9 b9 fe ff ff       	jmp    0x7a0d2a802c69
    7a0d2a802db0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    7a0d2a802db7:	6c 03 01 00 
    7a0d2a802dbb:	b8 6c 03 01 00       	mov    eax,0x1036c
    7a0d2a802dc0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802dc7:	02 00 00 00 
    7a0d2a802dcb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    7a0d2a802dd2:	1a 00 00 00 
    7a0d2a802dd6:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a802dd9:	be 6c 03 01 00       	mov    esi,0x1036c
    7a0d2a802dde:	4c 89 ef             	mov    rdi,r13
    7a0d2a802de1:	e8 7a d3 ff e7       	call   0x7a0d12800160
    7a0d2a802de6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a802ded:	00 
    7a0d2a802dee:	0f 84 22 f2 ff e7    	je     0x7a0d12802016
    7a0d2a802df4:	e9 70 fe ff ff       	jmp    0x7a0d2a802c69
    7a0d2a802df9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    7a0d2a802e00:	6e 03 01 00 
    7a0d2a802e04:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802e0b:	02 00 00 00 
    7a0d2a802e0f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a802e16:	1b 00 00 00 
    7a0d2a802e1a:	4c 89 ef             	mov    rdi,r13
    7a0d2a802e1d:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a802e22:	4c 89 f2             	mov    rdx,r14
    7a0d2a802e25:	e8 66 d2 ff e7       	call   0x7a0d12800090
    7a0d2a802e2a:	e9 29 f2 ff e7       	jmp    0x7a0d12802058
    7a0d2a802e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a802e36:	02 00 00 00 
    7a0d2a802e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d2a802e41:	1b 00 00 00 
    7a0d2a802e45:	be 6e 03 01 00       	mov    esi,0x1036e
    7a0d2a802e4a:	ba 6e 03 01 00       	mov    edx,0x1036e
    7a0d2a802e4f:	4c 89 ef             	mov    rdi,r13
    7a0d2a802e52:	e8 09 d3 ff e7       	call   0x7a0d12800160
    7a0d2a802e57:	e9 fc f1 ff e7       	jmp    0x7a0d12802058
    7a0d2a802e5c:	c2 08 00             	ret    0x8
