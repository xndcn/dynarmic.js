
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65808-1-134196966216256.bin:     file format binary


Disassembly of section .data:

00007a0d2a805240 <.data>:
    7a0d2a805240:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a805246:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a805249:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80524f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a805256:	0f 87 45 ed ff e7    	ja     0x7a0d12803fa1
    7a0d2a80525c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xd
    7a0d2a805263:	0d 00 00 00 
    7a0d2a805267:	e9 35 ed ff e7       	jmp    0x7a0d12803fa1
    7a0d2a80526c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d2a805273:	10 01 01 00 
    7a0d2a805277:	b8 10 01 01 00       	mov    eax,0x10110
    7a0d2a80527c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805283:	04 00 00 00 
    7a0d2a805287:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80528e:	01 00 00 00 
    7a0d2a805292:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a805295:	be 10 01 01 00       	mov    esi,0x10110
    7a0d2a80529a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80529d:	e8 be ae ff e7       	call   0x7a0d12800160
    7a0d2a8052a2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8052a9:	00 
    7a0d2a8052aa:	0f 84 4e ed ff e7    	je     0x7a0d12803ffe
    7a0d2a8052b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8052b7:	04 00 00 00 
    7a0d2a8052bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8052c2:	01 00 00 00 
    7a0d2a8052c6:	58                   	pop    rax
    7a0d2a8052c7:	e9 53 f0 ff e7       	jmp    0x7a0d1280431f
    7a0d2a8052cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10114
    7a0d2a8052d3:	14 01 01 00 
    7a0d2a8052d7:	b8 14 01 01 00       	mov    eax,0x10114
    7a0d2a8052dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8052e3:	02 00 00 00 
    7a0d2a8052e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8052ee:	02 00 00 00 
    7a0d2a8052f2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8052f5:	be 14 01 01 00       	mov    esi,0x10114
    7a0d2a8052fa:	4c 89 ef             	mov    rdi,r13
    7a0d2a8052fd:	e8 5e ae ff e7       	call   0x7a0d12800160
    7a0d2a805302:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805309:	00 
    7a0d2a80530a:	0f 84 4c ed ff e7    	je     0x7a0d1280405c
    7a0d2a805310:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805317:	02 00 00 00 
    7a0d2a80531b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a805322:	02 00 00 00 
    7a0d2a805326:	58                   	pop    rax
    7a0d2a805327:	e9 f3 ef ff e7       	jmp    0x7a0d1280431f
    7a0d2a80532c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10116
    7a0d2a805333:	16 01 01 00 
    7a0d2a805337:	b8 16 01 01 00       	mov    eax,0x10116
    7a0d2a80533c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805343:	02 00 00 00 
    7a0d2a805347:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80534e:	03 00 00 00 
    7a0d2a805352:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a805355:	be 16 01 01 00       	mov    esi,0x10116
    7a0d2a80535a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80535d:	e8 fe ad ff e7       	call   0x7a0d12800160
    7a0d2a805362:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805369:	00 
    7a0d2a80536a:	0f 84 1a ed ff e7    	je     0x7a0d1280408a
    7a0d2a805370:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805377:	02 00 00 00 
    7a0d2a80537b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a805382:	03 00 00 00 
    7a0d2a805386:	58                   	pop    rax
    7a0d2a805387:	e9 93 ef ff e7       	jmp    0x7a0d1280431f
    7a0d2a80538c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10118
    7a0d2a805393:	18 01 01 00 
    7a0d2a805397:	b8 18 01 01 00       	mov    eax,0x10118
    7a0d2a80539c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8053a3:	04 00 00 00 
    7a0d2a8053a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8053ae:	04 00 00 00 
    7a0d2a8053b2:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8053b5:	be 18 01 01 00       	mov    esi,0x10118
    7a0d2a8053ba:	4c 89 ef             	mov    rdi,r13
    7a0d2a8053bd:	e8 9e ad ff e7       	call   0x7a0d12800160
    7a0d2a8053c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8053c9:	00 
    7a0d2a8053ca:	0f 84 ee ec ff e7    	je     0x7a0d128040be
    7a0d2a8053d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8053d7:	04 00 00 00 
    7a0d2a8053db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8053e2:	04 00 00 00 
    7a0d2a8053e6:	58                   	pop    rax
    7a0d2a8053e7:	e9 33 ef ff e7       	jmp    0x7a0d1280431f
    7a0d2a8053ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1011c
    7a0d2a8053f3:	1c 01 01 00 
    7a0d2a8053f7:	b8 1c 01 01 00       	mov    eax,0x1011c
    7a0d2a8053fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805403:	04 00 00 00 
    7a0d2a805407:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80540e:	05 00 00 00 
    7a0d2a805412:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a805415:	be 1c 01 01 00       	mov    esi,0x1011c
    7a0d2a80541a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80541d:	e8 3e ad ff e7       	call   0x7a0d12800160
    7a0d2a805422:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805429:	00 
    7a0d2a80542a:	0f 84 c5 ec ff e7    	je     0x7a0d128040f5
    7a0d2a805430:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805437:	04 00 00 00 
    7a0d2a80543b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805442:	05 00 00 00 
    7a0d2a805446:	58                   	pop    rax
    7a0d2a805447:	e9 d3 ee ff e7       	jmp    0x7a0d1280431f
    7a0d2a80544c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a805453:	20 01 01 00 
    7a0d2a805457:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80545e:	04 00 00 00 
    7a0d2a805462:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805469:	06 00 00 00 
    7a0d2a80546d:	ba 20 01 01 00       	mov    edx,0x10120
    7a0d2a805472:	4c 89 ef             	mov    rdi,r13
    7a0d2a805475:	4c 89 f6             	mov    rsi,r14
    7a0d2a805478:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80547e:	e8 fd ab ff e7       	call   0x7a0d12800080
    7a0d2a805483:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80548a:	04 00 00 00 
    7a0d2a80548e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805495:	06 00 00 00 
    7a0d2a805499:	58                   	pop    rax
    7a0d2a80549a:	e9 80 ee ff e7       	jmp    0x7a0d1280431f
    7a0d2a80549f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a8054a6:	20 01 01 00 
    7a0d2a8054aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8054b1:	04 00 00 00 
    7a0d2a8054b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8054bc:	06 00 00 00 
    7a0d2a8054c0:	4c 89 f7             	mov    rdi,r14
    7a0d2a8054c3:	89 ce                	mov    esi,ecx
    7a0d2a8054c5:	e8 a6 ab ff e7       	call   0x7a0d12800070
    7a0d2a8054ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8054d1:	00 
    7a0d2a8054d2:	0f 84 64 ec ff e7    	je     0x7a0d1280413c
    7a0d2a8054d8:	eb a9                	jmp    0x7a0d2a805483
    7a0d2a8054da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a8054e1:	20 01 01 00 
    7a0d2a8054e5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8054ec:	04 00 00 00 
    7a0d2a8054f0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8054f7:	06 00 00 00 
    7a0d2a8054fb:	4c 89 f7             	mov    rdi,r14
    7a0d2a8054fe:	89 de                	mov    esi,ebx
    7a0d2a805500:	44 89 e2             	mov    edx,r12d
    7a0d2a805503:	e8 68 ab ff e7       	call   0x7a0d12800070
    7a0d2a805508:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80550f:	00 
    7a0d2a805510:	0f 84 48 ec ff e7    	je     0x7a0d1280415e
    7a0d2a805516:	e9 68 ff ff ff       	jmp    0x7a0d2a805483
    7a0d2a80551b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a805522:	20 01 01 00 
    7a0d2a805526:	b8 20 01 01 00       	mov    eax,0x10120
    7a0d2a80552b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805532:	04 00 00 00 
    7a0d2a805536:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a80553d:	06 00 00 00 
    7a0d2a805541:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a805544:	be 20 01 01 00       	mov    esi,0x10120
    7a0d2a805549:	4c 89 ef             	mov    rdi,r13
    7a0d2a80554c:	e8 0f ac ff e7       	call   0x7a0d12800160
    7a0d2a805551:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a805555:	0f 84 44 ec ff e7    	je     0x7a0d1280419f
    7a0d2a80555b:	eb 0f                	jmp    0x7a0d2a80556c
    7a0d2a80555d:	b8 20 01 01 00       	mov    eax,0x10120
    7a0d2a805562:	83 c0 04             	add    eax,0x4
    7a0d2a805565:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80556c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805573:	04 00 00 00 
    7a0d2a805577:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a80557e:	06 00 00 00 
    7a0d2a805582:	4c 89 ef             	mov    rdi,r13
    7a0d2a805585:	e8 c6 ab ff e7       	call   0x7a0d12800150
    7a0d2a80558a:	e9 10 ec ff e7       	jmp    0x7a0d1280419f
    7a0d2a80558f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a805596:	24 01 01 00 
    7a0d2a80559a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8055a1:	04 00 00 00 
    7a0d2a8055a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8055ac:	07 00 00 00 
    7a0d2a8055b0:	ba 24 01 01 00       	mov    edx,0x10124
    7a0d2a8055b5:	4c 89 ef             	mov    rdi,r13
    7a0d2a8055b8:	4c 89 f6             	mov    rsi,r14
    7a0d2a8055bb:	89 d9                	mov    ecx,ebx
    7a0d2a8055bd:	45 31 c0             	xor    r8d,r8d
    7a0d2a8055c0:	e8 bb aa ff e7       	call   0x7a0d12800080
    7a0d2a8055c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8055cc:	04 00 00 00 
    7a0d2a8055d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8055d7:	07 00 00 00 
    7a0d2a8055db:	58                   	pop    rax
    7a0d2a8055dc:	e9 3e ed ff e7       	jmp    0x7a0d1280431f
    7a0d2a8055e1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a8055e8:	24 01 01 00 
    7a0d2a8055ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8055f3:	04 00 00 00 
    7a0d2a8055f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8055fe:	07 00 00 00 
    7a0d2a805602:	4c 89 f7             	mov    rdi,r14
    7a0d2a805605:	89 de                	mov    esi,ebx
    7a0d2a805607:	e8 34 aa ff e7       	call   0x7a0d12800040
    7a0d2a80560c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805613:	00 
    7a0d2a805614:	75 af                	jne    0x7a0d2a8055c5
    7a0d2a805616:	41 89 c7             	mov    r15d,eax
    7a0d2a805619:	e9 c6 eb ff e7       	jmp    0x7a0d128041e4
    7a0d2a80561e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a805625:	24 01 01 00 
    7a0d2a805629:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805630:	04 00 00 00 
    7a0d2a805634:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a80563b:	07 00 00 00 
    7a0d2a80563f:	4c 89 f7             	mov    rdi,r14
    7a0d2a805642:	e8 f9 a9 ff e7       	call   0x7a0d12800040
    7a0d2a805647:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80564e:	00 
    7a0d2a80564f:	0f 84 b0 eb ff e7    	je     0x7a0d12804205
    7a0d2a805655:	e9 6b ff ff ff       	jmp    0x7a0d2a8055c5
    7a0d2a80565a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a805661:	24 01 01 00 
    7a0d2a805665:	b8 24 01 01 00       	mov    eax,0x10124
    7a0d2a80566a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805671:	04 00 00 00 
    7a0d2a805675:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a80567c:	07 00 00 00 
    7a0d2a805680:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a805683:	be 24 01 01 00       	mov    esi,0x10124
    7a0d2a805688:	4c 89 ef             	mov    rdi,r13
    7a0d2a80568b:	e8 d0 aa ff e7       	call   0x7a0d12800160
    7a0d2a805690:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805697:	00 
    7a0d2a805698:	0f 84 9b eb ff e7    	je     0x7a0d12804239
    7a0d2a80569e:	e9 22 ff ff ff       	jmp    0x7a0d2a8055c5
    7a0d2a8056a3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10128
    7a0d2a8056aa:	28 01 01 00 
    7a0d2a8056ae:	b8 28 01 01 00       	mov    eax,0x10128
    7a0d2a8056b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8056ba:	02 00 00 00 
    7a0d2a8056be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8056c5:	08 00 00 00 
    7a0d2a8056c9:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8056cc:	be 28 01 01 00       	mov    esi,0x10128
    7a0d2a8056d1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8056d4:	e8 87 aa ff e7       	call   0x7a0d12800160
    7a0d2a8056d9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8056e0:	00 
    7a0d2a8056e1:	0f 84 83 eb ff e7    	je     0x7a0d1280426a
    7a0d2a8056e7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8056ee:	02 00 00 00 
    7a0d2a8056f2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8056f9:	08 00 00 00 
    7a0d2a8056fd:	58                   	pop    rax
    7a0d2a8056fe:	e9 1c ec ff e7       	jmp    0x7a0d1280431f
    7a0d2a805703:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012a
    7a0d2a80570a:	2a 01 01 00 
    7a0d2a80570e:	b8 2a 01 01 00       	mov    eax,0x1012a
    7a0d2a805713:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80571a:	02 00 00 00 
    7a0d2a80571e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a805725:	09 00 00 00 
    7a0d2a805729:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80572c:	be 2a 01 01 00       	mov    esi,0x1012a
    7a0d2a805731:	4c 89 ef             	mov    rdi,r13
    7a0d2a805734:	e8 27 aa ff e7       	call   0x7a0d12800160
    7a0d2a805739:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a805740:	00 
    7a0d2a805741:	0f 84 51 eb ff e7    	je     0x7a0d12804298
    7a0d2a805747:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80574e:	02 00 00 00 
    7a0d2a805752:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a805759:	09 00 00 00 
    7a0d2a80575d:	58                   	pop    rax
    7a0d2a80575e:	e9 bc eb ff e7       	jmp    0x7a0d1280431f
    7a0d2a805763:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012c
    7a0d2a80576a:	2c 01 01 00 
    7a0d2a80576e:	b8 2c 01 01 00       	mov    eax,0x1012c
    7a0d2a805773:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80577a:	02 00 00 00 
    7a0d2a80577e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a805785:	0a 00 00 00 
    7a0d2a805789:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80578c:	be 2c 01 01 00       	mov    esi,0x1012c
    7a0d2a805791:	4c 89 ef             	mov    rdi,r13
    7a0d2a805794:	e8 c7 a9 ff e7       	call   0x7a0d12800160
    7a0d2a805799:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8057a0:	00 
    7a0d2a8057a1:	0f 84 1f eb ff e7    	je     0x7a0d128042c6
    7a0d2a8057a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8057ae:	02 00 00 00 
    7a0d2a8057b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a8057b9:	0a 00 00 00 
    7a0d2a8057bd:	58                   	pop    rax
    7a0d2a8057be:	e9 5c eb ff e7       	jmp    0x7a0d1280431f
    7a0d2a8057c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012e
    7a0d2a8057ca:	2e 01 01 00 
    7a0d2a8057ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8057d5:	02 00 00 00 
    7a0d2a8057d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a8057e0:	0b 00 00 00 
    7a0d2a8057e4:	4c 89 ef             	mov    rdi,r13
    7a0d2a8057e7:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a8057ec:	4c 89 f2             	mov    rdx,r14
    7a0d2a8057ef:	e8 9c a8 ff e7       	call   0x7a0d12800090
    7a0d2a8057f4:	e9 0f eb ff e7       	jmp    0x7a0d12804308
    7a0d2a8057f9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805800:	02 00 00 00 
    7a0d2a805804:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a80580b:	0b 00 00 00 
    7a0d2a80580f:	be 2e 01 01 00       	mov    esi,0x1012e
    7a0d2a805814:	ba 2e 01 01 00       	mov    edx,0x1012e
    7a0d2a805819:	4c 89 ef             	mov    rdi,r13
    7a0d2a80581c:	e8 3f a9 ff e7       	call   0x7a0d12800160
    7a0d2a805821:	e9 e2 ea ff e7       	jmp    0x7a0d12804308
    7a0d2a805826:	c2 08 00             	ret    0x8
