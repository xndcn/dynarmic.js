
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65556-1-134196563543152.bin:     file format binary


Disassembly of section .data:

00007a0d12800470 <.data>:
    7a0d12800470:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12800477:	8b 88 04 00 10 00    	mov    ecx,DWORD PTR [rax+0x100004]
    7a0d1280047d:	ff c1                	inc    ecx
    7a0d1280047f:	89 88 04 00 10 00    	mov    DWORD PTR [rax+0x100004],ecx
    7a0d12800485:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280048b:	0f 84 3f fc ff 17    	je     0x7a0d2a8000d0
    7a0d12800491:	50                   	push   rax
    7a0d12800492:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12800496:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d12800499:	f6 c3 03             	test   bl,0x3
    7a0d1280049c:	0f 85 5a fc ff 17    	jne    0x7a0d2a8000fc
    7a0d128004a2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d128004a9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d128004b0:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7a0d128004b4:	89 c8                	mov    eax,ecx
    7a0d128004b6:	c1 e8 0c             	shr    eax,0xc
    7a0d128004b9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128004be:	48 85 c0             	test   rax,rax
    7a0d128004c1:	0f 84 88 fc ff 17    	je     0x7a0d2a80014f
    7a0d128004c7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128004cd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d128004d0:	8d 73 f8             	lea    esi,[rbx-0x8]
    7a0d128004d3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7a0d128004d7:	89 f0                	mov    eax,esi
    7a0d128004d9:	c1 e8 0c             	shr    eax,0xc
    7a0d128004dc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128004e1:	48 85 c0             	test   rax,rax
    7a0d128004e4:	0f 84 a0 fc ff 17    	je     0x7a0d2a80018a
    7a0d128004ea:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128004f0:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d128004f3:	8d 73 f4             	lea    esi,[rbx-0xc]
    7a0d128004f6:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7a0d128004fa:	89 f0                	mov    eax,esi
    7a0d128004fc:	c1 e8 0c             	shr    eax,0xc
    7a0d128004ff:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800504:	48 85 c0             	test   rax,rax
    7a0d12800507:	0f 84 b9 fc ff 17    	je     0x7a0d2a8001c6
    7a0d1280050d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800513:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12800516:	8d 73 f0             	lea    esi,[rbx-0x10]
    7a0d12800519:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7a0d1280051d:	89 f0                	mov    eax,esi
    7a0d1280051f:	c1 e8 0c             	shr    eax,0xc
    7a0d12800522:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800527:	48 85 c0             	test   rax,rax
    7a0d1280052a:	0f 84 d2 fc ff 17    	je     0x7a0d2a800202
    7a0d12800530:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800536:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12800539:	8d 73 ec             	lea    esi,[rbx-0x14]
    7a0d1280053c:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    7a0d12800540:	89 f0                	mov    eax,esi
    7a0d12800542:	c1 e8 0c             	shr    eax,0xc
    7a0d12800545:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280054a:	48 85 c0             	test   rax,rax
    7a0d1280054d:	0f 84 eb fc ff 17    	je     0x7a0d2a80023e
    7a0d12800553:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800559:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d1280055c:	8d 73 e8             	lea    esi,[rbx-0x18]
    7a0d1280055f:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    7a0d12800563:	89 f0                	mov    eax,esi
    7a0d12800565:	c1 e8 0c             	shr    eax,0xc
    7a0d12800568:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280056d:	48 85 c0             	test   rax,rax
    7a0d12800570:	0f 84 04 fd ff 17    	je     0x7a0d2a80027a
    7a0d12800576:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d1280057c:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d1280057f:	83 c3 e4             	add    ebx,0xffffffe4
    7a0d12800582:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7a0d12800586:	89 d8                	mov    eax,ebx
    7a0d12800588:	c1 e8 0c             	shr    eax,0xc
    7a0d1280058b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800590:	48 85 c0             	test   rax,rax
    7a0d12800593:	0f 84 1d fd ff 17    	je     0x7a0d2a8002b6
    7a0d12800599:	89 d9                	mov    ecx,ebx
    7a0d1280059b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128005a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d128005a4:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d128005a8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10014
    7a0d128005af:	14 00 01 00 
    7a0d128005b3:	0f 84 3b fd ff 17    	je     0x7a0d2a8002f4
    7a0d128005b9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10014
    7a0d128005c0:	14 00 01 00 
    7a0d128005c4:	0f 84 2a fd ff 17    	je     0x7a0d2a8002f4
    7a0d128005ca:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d128005ce:	0f 85 62 fd ff 17    	jne    0x7a0d2a800336
    7a0d128005d4:	58                   	pop    rax
    7a0d128005d5:	e9 0f 00 00 00       	jmp    0x7a0d128005e9
    7a0d128005da:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128005e1:	00 
    7a0d128005e2:	74 f0                	je     0x7a0d128005d4
    7a0d128005e4:	e9 4a fb ff 17       	jmp    0x7a0d2a800133
    7a0d128005e9:	50                   	push   rax
    7a0d128005ea:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d128005ef:	b9 00 00 00 00       	mov    ecx,0x0
    7a0d128005f4:	09 c1                	or     ecx,eax
    7a0d128005f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128005fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10016
    7a0d12800601:	16 00 01 00 
    7a0d12800605:	0f 84 5d fd ff 17    	je     0x7a0d2a800368
    7a0d1280060b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10016
    7a0d12800612:	16 00 01 00 
    7a0d12800616:	0f 84 4c fd ff 17    	je     0x7a0d2a800368
    7a0d1280061c:	58                   	pop    rax
    7a0d1280061d:	50                   	push   rax
    7a0d1280061e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12800622:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d12800625:	f6 c3 03             	test   bl,0x3
    7a0d12800628:	0f 85 9a fd ff 17    	jne    0x7a0d2a8003c8
    7a0d1280062e:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d12800635:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d1280063c:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d12800640:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d12800647:	89 c8                	mov    eax,ecx
    7a0d12800649:	c1 e8 0c             	shr    eax,0xc
    7a0d1280064c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800651:	48 85 c0             	test   rax,rax
    7a0d12800654:	0f 84 c1 fd ff 17    	je     0x7a0d2a80041b
    7a0d1280065a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800660:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12800663:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d12800666:	89 d8                	mov    eax,ebx
    7a0d12800668:	c1 e8 0c             	shr    eax,0xc
    7a0d1280066b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800670:	48 85 c0             	test   rax,rax
    7a0d12800673:	0f 84 dd fd ff 17    	je     0x7a0d2a800456
    7a0d12800679:	89 d9                	mov    ecx,ebx
    7a0d1280067b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800681:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d12800685:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d12800689:	b8 14 00 00 00       	mov    eax,0x14
    7a0d1280068e:	29 c3                	sub    ebx,eax
    7a0d12800690:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d12800694:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001a
    7a0d1280069b:	1a 00 01 00 
    7a0d1280069f:	0f 84 f2 fd ff 17    	je     0x7a0d2a800497
    7a0d128006a5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001a
    7a0d128006ac:	1a 00 01 00 
    7a0d128006b0:	0f 84 e1 fd ff 17    	je     0x7a0d2a800497
    7a0d128006b6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d128006ba:	0f 85 19 fe ff 17    	jne    0x7a0d2a8004d9
    7a0d128006c0:	58                   	pop    rax
    7a0d128006c1:	e9 0f 00 00 00       	jmp    0x7a0d128006d5
    7a0d128006c6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128006cd:	00 
    7a0d128006ce:	74 f0                	je     0x7a0d128006c0
    7a0d128006d0:	e9 2a fd ff 17       	jmp    0x7a0d2a8003ff
    7a0d128006d5:	50                   	push   rax
    7a0d128006d6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d128006db:	c1 e0 10             	shl    eax,0x10
    7a0d128006de:	b9 00 f0 00 00       	mov    ecx,0xf000
    7a0d128006e3:	09 c1                	or     ecx,eax
    7a0d128006e5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128006e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001e
    7a0d128006f0:	1e 00 01 00 
    7a0d128006f4:	0f 84 11 fe ff 17    	je     0x7a0d2a80050b
    7a0d128006fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001e
    7a0d12800701:	1e 00 01 00 
    7a0d12800705:	0f 84 00 fe ff 17    	je     0x7a0d2a80050b
    7a0d1280070b:	58                   	pop    rax
    7a0d1280070c:	50                   	push   rax
    7a0d1280070d:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    7a0d12800712:	b9 00 00 42 43       	mov    ecx,0x43420000
    7a0d12800717:	09 c1                	or     ecx,eax
    7a0d12800719:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d1280071d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10022
    7a0d12800724:	22 00 01 00 
    7a0d12800728:	0f 84 3d fe ff 17    	je     0x7a0d2a80056b
    7a0d1280072e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10022
    7a0d12800735:	22 00 01 00 
    7a0d12800739:	0f 84 2c fe ff 17    	je     0x7a0d2a80056b
    7a0d1280073f:	58                   	pop    rax
    7a0d12800740:	50                   	push   rax
    7a0d12800741:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12800745:	f6 c1 03             	test   cl,0x3
    7a0d12800748:	0f 85 7d fe ff 17    	jne    0x7a0d2a8005cb
    7a0d1280074e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800755:	48 89 ca             	mov    rdx,rcx
    7a0d12800758:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d1280075c:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12800760:	48 85 c0             	test   rax,rax
    7a0d12800763:	0f 84 b2 fe ff 17    	je     0x7a0d2a80061b
    7a0d12800769:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280076f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12800772:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12800776:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10026
    7a0d1280077d:	26 00 01 00 
    7a0d12800781:	0f 84 cf fe ff 17    	je     0x7a0d2a800656
    7a0d12800787:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10026
    7a0d1280078e:	26 00 01 00 
    7a0d12800792:	0f 84 be fe ff 17    	je     0x7a0d2a800656
    7a0d12800798:	58                   	pop    rax
    7a0d12800799:	50                   	push   rax
    7a0d1280079a:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    7a0d1280079f:	c1 e0 10             	shl    eax,0x10
    7a0d128007a2:	b9 31 4e 00 00       	mov    ecx,0x4e31
    7a0d128007a7:	09 c1                	or     ecx,eax
    7a0d128007a9:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d128007ad:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10028
    7a0d128007b4:	28 00 01 00 
    7a0d128007b8:	0f 84 e1 fe ff 17    	je     0x7a0d2a80069f
    7a0d128007be:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10028
    7a0d128007c5:	28 00 01 00 
    7a0d128007c9:	0f 84 d0 fe ff 17    	je     0x7a0d2a80069f
    7a0d128007cf:	58                   	pop    rax
    7a0d128007d0:	50                   	push   rax
    7a0d128007d1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d128007d5:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    7a0d128007d9:	31 d2                	xor    edx,edx
    7a0d128007db:	31 f6                	xor    esi,esi
    7a0d128007dd:	89 c7                	mov    edi,eax
    7a0d128007df:	29 cf                	sub    edi,ecx
    7a0d128007e1:	0f 94 c2             	sete   dl
    7a0d128007e4:	40 0f 93 c6          	setae  sil
    7a0d128007e8:	c1 ef 1f             	shr    edi,0x1f
    7a0d128007eb:	c1 e8 1f             	shr    eax,0x1f
    7a0d128007ee:	c1 e9 1f             	shr    ecx,0x1f
    7a0d128007f1:	89 fb                	mov    ebx,edi
    7a0d128007f3:	31 c3                	xor    ebx,eax
    7a0d128007f5:	31 c1                	xor    ecx,eax
    7a0d128007f7:	21 d9                	and    ecx,ebx
    7a0d128007f9:	31 f9                	xor    ecx,edi
    7a0d128007fb:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12800802:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12800809:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7a0d12800810:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7a0d12800817:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7a0d1280081e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002c
    7a0d12800825:	2c 00 01 00 
    7a0d12800829:	0f 84 d0 fe ff 17    	je     0x7a0d2a8006ff
    7a0d1280082f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002c
    7a0d12800836:	2c 00 01 00 
    7a0d1280083a:	0f 84 bf fe ff 17    	je     0x7a0d2a8006ff
    7a0d12800840:	58                   	pop    rax
    7a0d12800841:	50                   	push   rax
    7a0d12800842:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12800849:	00 
    7a0d1280084a:	74 55                	je     0x7a0d128008a1
    7a0d1280084c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12800853:	01 
    7a0d12800854:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    7a0d1280085b:	2e 00 01 00 
    7a0d1280085f:	0f 84 fa fe ff 17    	je     0x7a0d2a80075f
    7a0d12800865:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    7a0d1280086c:	2e 00 01 00 
    7a0d12800870:	0f 84 e9 fe ff 17    	je     0x7a0d2a80075f
    7a0d12800876:	b8 2e 00 01 00       	mov    eax,0x1002e
    7a0d1280087b:	83 c0 12             	add    eax,0x12
    7a0d1280087e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12800885:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280088c:	02 00 00 00 
    7a0d12800890:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d12800897:	09 00 00 00 
    7a0d1280089b:	58                   	pop    rax
    7a0d1280089c:	e9 3c 03 00 00       	jmp    0x7a0d12800bdd
    7a0d128008a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    7a0d128008a8:	2e 00 01 00 
    7a0d128008ac:	0f 84 e9 fe ff 17    	je     0x7a0d2a80079b
    7a0d128008b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    7a0d128008b9:	2e 00 01 00 
    7a0d128008bd:	0f 84 d8 fe ff 17    	je     0x7a0d2a80079b
    7a0d128008c3:	58                   	pop    rax
    7a0d128008c4:	50                   	push   rax
    7a0d128008c5:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    7a0d128008cc:	00 
    7a0d128008cd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10030
    7a0d128008d4:	30 00 01 00 
    7a0d128008d8:	0f 84 06 ff ff 17    	je     0x7a0d2a8007e4
    7a0d128008de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10030
    7a0d128008e5:	30 00 01 00 
    7a0d128008e9:	0f 84 f5 fe ff 17    	je     0x7a0d2a8007e4
    7a0d128008ef:	58                   	pop    rax
    7a0d128008f0:	50                   	push   rax
    7a0d128008f1:	41 83 45 28 10       	add    DWORD PTR [r13+0x28],0x10
    7a0d128008f6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10032
    7a0d128008fd:	32 00 01 00 
    7a0d12800901:	0f 84 3d ff ff 17    	je     0x7a0d2a800844
    7a0d12800907:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10032
    7a0d1280090e:	32 00 01 00 
    7a0d12800912:	0f 84 2c ff ff 17    	je     0x7a0d2a800844
    7a0d12800918:	58                   	pop    rax
    7a0d12800919:	50                   	push   rax
    7a0d1280091a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d1280091e:	f6 c1 03             	test   cl,0x3
    7a0d12800921:	0f 85 7d ff ff 17    	jne    0x7a0d2a8008a4
    7a0d12800927:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d1280092e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12800932:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800939:	48 89 ce             	mov    rsi,rcx
    7a0d1280093c:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12800940:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12800944:	48 85 c0             	test   rax,rax
    7a0d12800947:	0f 84 aa ff ff 17    	je     0x7a0d2a8008f7
    7a0d1280094d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800953:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12800956:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10034
    7a0d1280095d:	34 00 01 00 
    7a0d12800961:	0f 84 cb ff ff 17    	je     0x7a0d2a800932
    7a0d12800967:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10034
    7a0d1280096e:	34 00 01 00 
    7a0d12800972:	0f 84 ba ff ff 17    	je     0x7a0d2a800932
    7a0d12800978:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d1280097b:	0f 85 f2 ff ff 17    	jne    0x7a0d2a800973
    7a0d12800981:	58                   	pop    rax
    7a0d12800982:	e9 0f 00 00 00       	jmp    0x7a0d12800996
    7a0d12800987:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d1280098e:	00 
    7a0d1280098f:	74 f0                	je     0x7a0d12800981
    7a0d12800991:	e9 45 ff ff 17       	jmp    0x7a0d2a8008db
    7a0d12800996:	50                   	push   rax
    7a0d12800997:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    7a0d1280099e:	00 
    7a0d1280099f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10036
    7a0d128009a6:	36 00 01 00 
    7a0d128009aa:	0f 84 f5 ff ff 17    	je     0x7a0d2a8009a5
    7a0d128009b0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10036
    7a0d128009b7:	36 00 01 00 
    7a0d128009bb:	0f 84 e4 ff ff 17    	je     0x7a0d2a8009a5
    7a0d128009c1:	58                   	pop    rax
    7a0d128009c2:	50                   	push   rax
    7a0d128009c3:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d128009c7:	f6 c3 03             	test   bl,0x3
    7a0d128009ca:	0f 85 35 00 00 18    	jne    0x7a0d2a800a05
    7a0d128009d0:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d128009d7:	48 89 d8             	mov    rax,rbx
    7a0d128009da:	48 c1 e8 0c          	shr    rax,0xc
    7a0d128009de:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128009e3:	48 85 c0             	test   rax,rax
    7a0d128009e6:	0f 84 6b 00 00 18    	je     0x7a0d2a800a57
    7a0d128009ec:	89 d9                	mov    ecx,ebx
    7a0d128009ee:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128009f4:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d128009f8:	89 de                	mov    esi,ebx
    7a0d128009fa:	83 c6 04             	add    esi,0x4
    7a0d128009fd:	89 f0                	mov    eax,esi
    7a0d128009ff:	c1 e8 0c             	shr    eax,0xc
    7a0d12800a02:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800a07:	48 85 c0             	test   rax,rax
    7a0d12800a0a:	0f 84 84 00 00 18    	je     0x7a0d2a800a94
    7a0d12800a10:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800a16:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800a19:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d12800a1c:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d12800a20:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12800a27:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d12800a2b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10038
    7a0d12800a32:	38 00 01 00 
    7a0d12800a36:	0f 84 94 00 00 18    	je     0x7a0d2a800ad0
    7a0d12800a3c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10038
    7a0d12800a43:	38 00 01 00 
    7a0d12800a47:	0f 84 83 00 00 18    	je     0x7a0d2a800ad0
    7a0d12800a4d:	58                   	pop    rax
    7a0d12800a4e:	50                   	push   rax
    7a0d12800a4f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12800a53:	f6 c3 03             	test   bl,0x3
    7a0d12800a56:	0f 85 bd 00 00 18    	jne    0x7a0d2a800b19
    7a0d12800a5c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12800a63:	48 89 d8             	mov    rax,rbx
    7a0d12800a66:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12800a6a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800a6f:	48 85 c0             	test   rax,rax
    7a0d12800a72:	0f 84 f3 00 00 18    	je     0x7a0d2a800b6b
    7a0d12800a78:	89 d9                	mov    ecx,ebx
    7a0d12800a7a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800a80:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12800a83:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7a0d12800a87:	8d 73 04             	lea    esi,[rbx+0x4]
    7a0d12800a8a:	89 f0                	mov    eax,esi
    7a0d12800a8c:	c1 e8 0c             	shr    eax,0xc
    7a0d12800a8f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800a94:	48 85 c0             	test   rax,rax
    7a0d12800a97:	0f 84 09 01 00 18    	je     0x7a0d2a800ba6
    7a0d12800a9d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800aa3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800aa6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7a0d12800aaa:	8d 73 08             	lea    esi,[rbx+0x8]
    7a0d12800aad:	89 f0                	mov    eax,esi
    7a0d12800aaf:	c1 e8 0c             	shr    eax,0xc
    7a0d12800ab2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800ab7:	48 85 c0             	test   rax,rax
    7a0d12800aba:	0f 84 22 01 00 18    	je     0x7a0d2a800be2
    7a0d12800ac0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800ac6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800ac9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7a0d12800acd:	8d 73 0c             	lea    esi,[rbx+0xc]
    7a0d12800ad0:	89 f0                	mov    eax,esi
    7a0d12800ad2:	c1 e8 0c             	shr    eax,0xc
    7a0d12800ad5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800ada:	48 85 c0             	test   rax,rax
    7a0d12800add:	0f 84 3b 01 00 18    	je     0x7a0d2a800c1e
    7a0d12800ae3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800ae9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800aec:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12800af0:	8d 73 10             	lea    esi,[rbx+0x10]
    7a0d12800af3:	89 f0                	mov    eax,esi
    7a0d12800af5:	c1 e8 0c             	shr    eax,0xc
    7a0d12800af8:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800afd:	48 85 c0             	test   rax,rax
    7a0d12800b00:	0f 84 54 01 00 18    	je     0x7a0d2a800c5a
    7a0d12800b06:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800b0c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800b0f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7a0d12800b13:	8d 73 14             	lea    esi,[rbx+0x14]
    7a0d12800b16:	89 f0                	mov    eax,esi
    7a0d12800b18:	c1 e8 0c             	shr    eax,0xc
    7a0d12800b1b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800b20:	48 85 c0             	test   rax,rax
    7a0d12800b23:	0f 84 6d 01 00 18    	je     0x7a0d2a800c96
    7a0d12800b29:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800b2f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800b32:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7a0d12800b36:	89 de                	mov    esi,ebx
    7a0d12800b38:	83 c6 18             	add    esi,0x18
    7a0d12800b3b:	89 f0                	mov    eax,esi
    7a0d12800b3d:	c1 e8 0c             	shr    eax,0xc
    7a0d12800b40:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12800b45:	48 85 c0             	test   rax,rax
    7a0d12800b48:	0f 84 84 01 00 18    	je     0x7a0d2a800cd2
    7a0d12800b4e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12800b54:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12800b57:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7a0d12800b5b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    7a0d12800b5e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7a0d12800b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003c
    7a0d12800b69:	3c 00 01 00 
    7a0d12800b6d:	0f 84 9b 01 00 18    	je     0x7a0d2a800d0e
    7a0d12800b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003c
    7a0d12800b7a:	3c 00 01 00 
    7a0d12800b7e:	0f 84 8a 01 00 18    	je     0x7a0d2a800d0e
    7a0d12800b84:	58                   	pop    rax
    7a0d12800b85:	50                   	push   rax
    7a0d12800b86:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d12800b8d:	a8 01                	test   al,0x1
    7a0d12800b8f:	0f 85 c2 01 00 18    	jne    0x7a0d2a800d57
    7a0d12800b95:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12800b9c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12800ba3:	01 
    7a0d12800ba4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003e
    7a0d12800bab:	3e 00 01 00 
    7a0d12800baf:	0f 84 d8 01 00 18    	je     0x7a0d2a800d8d
    7a0d12800bb5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003e
    7a0d12800bbc:	3e 00 01 00 
    7a0d12800bc0:	0f 84 c7 01 00 18    	je     0x7a0d2a800d8d
    7a0d12800bc6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12800bcd:	02 00 00 00 
    7a0d12800bd1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d12800bd8:	10 00 00 00 
    7a0d12800bdc:	58                   	pop    rax
    7a0d12800bdd:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12800be4:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12800beb:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12800bf2:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12800bf9:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12800c00:	39 f1                	cmp    ecx,esi
    7a0d12800c02:	0f 83 b2 01 00 18    	jae    0x7a0d2a800dba
    7a0d12800c08:	81 fa 14 00 01 00    	cmp    edx,0x10014
    7a0d12800c0e:	75 14                	jne    0x7a0d12800c24
    7a0d12800c10:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12800c17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12800c1e:	00 
    7a0d12800c1f:	e9 4c f8 ff ff       	jmp    0x7a0d12800470
    7a0d12800c24:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12800c2b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12800c31:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12800c34:	0f 85 80 01 00 18    	jne    0x7a0d2a800dba
    7a0d12800c3a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12800c41:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12800c48:	00 
    7a0d12800c49:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12800c4e:	ff e0                	jmp    rax
