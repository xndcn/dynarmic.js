
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65692-1-134196966222096.bin:     file format binary


Disassembly of section .data:

00007a0d2a806910 <.data>:
    7a0d2a806910:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a806916:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a806919:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80691f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a806926:	0f 87 65 ec ff e7    	ja     0x7a0d12805591
    7a0d2a80692c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xf
    7a0d2a806933:	0f 00 00 00 
    7a0d2a806937:	e9 55 ec ff e7       	jmp    0x7a0d12805591
    7a0d2a80693c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    7a0d2a806943:	9c 00 01 00 
    7a0d2a806947:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80694e:	02 00 00 00 
    7a0d2a806952:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a806959:	01 00 00 00 
    7a0d2a80695d:	ba 9c 00 01 00       	mov    edx,0x1009c
    7a0d2a806962:	4c 89 ef             	mov    rdi,r13
    7a0d2a806965:	4c 89 f6             	mov    rsi,r14
    7a0d2a806968:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80696e:	e8 0d 97 ff e7       	call   0x7a0d12800080
    7a0d2a806973:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80697a:	02 00 00 00 
    7a0d2a80697e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a806985:	01 00 00 00 
    7a0d2a806989:	58                   	pop    rax
    7a0d2a80698a:	e9 7e f2 ff e7       	jmp    0x7a0d12805c0d
    7a0d2a80698f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    7a0d2a806996:	9c 00 01 00 
    7a0d2a80699a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8069a1:	02 00 00 00 
    7a0d2a8069a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8069ac:	01 00 00 00 
    7a0d2a8069b0:	4c 89 f7             	mov    rdi,r14
    7a0d2a8069b3:	89 ce                	mov    esi,ecx
    7a0d2a8069b5:	e8 b6 96 ff e7       	call   0x7a0d12800070
    7a0d2a8069ba:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8069c1:	00 
    7a0d2a8069c2:	0f 84 06 ec ff e7    	je     0x7a0d128055ce
    7a0d2a8069c8:	eb a9                	jmp    0x7a0d2a806973
    7a0d2a8069ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    7a0d2a8069d1:	9c 00 01 00 
    7a0d2a8069d5:	b8 9c 00 01 00       	mov    eax,0x1009c
    7a0d2a8069da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8069e1:	02 00 00 00 
    7a0d2a8069e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8069ec:	01 00 00 00 
    7a0d2a8069f0:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8069f3:	be 9c 00 01 00       	mov    esi,0x1009c
    7a0d2a8069f8:	4c 89 ef             	mov    rdi,r13
    7a0d2a8069fb:	e8 60 97 ff e7       	call   0x7a0d12800160
    7a0d2a806a00:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a806a03:	0f 84 f6 eb ff e7    	je     0x7a0d128055ff
    7a0d2a806a09:	eb 0f                	jmp    0x7a0d2a806a1a
    7a0d2a806a0b:	b8 9c 00 01 00       	mov    eax,0x1009c
    7a0d2a806a10:	83 c0 02             	add    eax,0x2
    7a0d2a806a13:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a806a1a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806a21:	02 00 00 00 
    7a0d2a806a25:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a806a2c:	01 00 00 00 
    7a0d2a806a30:	4c 89 ef             	mov    rdi,r13
    7a0d2a806a33:	e8 18 97 ff e7       	call   0x7a0d12800150
    7a0d2a806a38:	e9 c2 eb ff e7       	jmp    0x7a0d128055ff
    7a0d2a806a3d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    7a0d2a806a44:	9e 00 01 00 
    7a0d2a806a48:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806a4f:	02 00 00 00 
    7a0d2a806a53:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a806a5a:	02 00 00 00 
    7a0d2a806a5e:	ba 9e 00 01 00       	mov    edx,0x1009e
    7a0d2a806a63:	4c 89 ef             	mov    rdi,r13
    7a0d2a806a66:	4c 89 f6             	mov    rsi,r14
    7a0d2a806a69:	89 d9                	mov    ecx,ebx
    7a0d2a806a6b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a806a71:	e8 0a 96 ff e7       	call   0x7a0d12800080
    7a0d2a806a76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806a7d:	02 00 00 00 
    7a0d2a806a81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a806a88:	02 00 00 00 
    7a0d2a806a8c:	58                   	pop    rax
    7a0d2a806a8d:	e9 7b f1 ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806a92:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    7a0d2a806a99:	9e 00 01 00 
    7a0d2a806a9d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806aa4:	02 00 00 00 
    7a0d2a806aa8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a806aaf:	02 00 00 00 
    7a0d2a806ab3:	4c 89 f7             	mov    rdi,r14
    7a0d2a806ab6:	89 de                	mov    esi,ebx
    7a0d2a806ab8:	e8 b3 95 ff e7       	call   0x7a0d12800070
    7a0d2a806abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806ac4:	00 
    7a0d2a806ac5:	0f 84 82 eb ff e7    	je     0x7a0d1280564d
    7a0d2a806acb:	eb a9                	jmp    0x7a0d2a806a76
    7a0d2a806acd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    7a0d2a806ad4:	9e 00 01 00 
    7a0d2a806ad8:	b8 9e 00 01 00       	mov    eax,0x1009e
    7a0d2a806add:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806ae4:	02 00 00 00 
    7a0d2a806ae8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a806aef:	02 00 00 00 
    7a0d2a806af3:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806af6:	be 9e 00 01 00       	mov    esi,0x1009e
    7a0d2a806afb:	4c 89 ef             	mov    rdi,r13
    7a0d2a806afe:	e8 5d 96 ff e7       	call   0x7a0d12800160
    7a0d2a806b03:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    7a0d2a806b07:	0f 84 79 eb ff e7    	je     0x7a0d12805686
    7a0d2a806b0d:	eb 0f                	jmp    0x7a0d2a806b1e
    7a0d2a806b0f:	b8 9e 00 01 00       	mov    eax,0x1009e
    7a0d2a806b14:	83 c0 02             	add    eax,0x2
    7a0d2a806b17:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a806b1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806b25:	02 00 00 00 
    7a0d2a806b29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a806b30:	02 00 00 00 
    7a0d2a806b34:	4c 89 ef             	mov    rdi,r13
    7a0d2a806b37:	e8 14 96 ff e7       	call   0x7a0d12800150
    7a0d2a806b3c:	e9 45 eb ff e7       	jmp    0x7a0d12805686
    7a0d2a806b41:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a0
    7a0d2a806b48:	a0 00 01 00 
    7a0d2a806b4c:	b8 a0 00 01 00       	mov    eax,0x100a0
    7a0d2a806b51:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806b58:	02 00 00 00 
    7a0d2a806b5c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a806b63:	03 00 00 00 
    7a0d2a806b67:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806b6a:	be a0 00 01 00       	mov    esi,0x100a0
    7a0d2a806b6f:	4c 89 ef             	mov    rdi,r13
    7a0d2a806b72:	e8 e9 95 ff e7       	call   0x7a0d12800160
    7a0d2a806b77:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806b7e:	00 
    7a0d2a806b7f:	0f 84 8a eb ff e7    	je     0x7a0d1280570f
    7a0d2a806b85:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806b8c:	02 00 00 00 
    7a0d2a806b90:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a806b97:	03 00 00 00 
    7a0d2a806b9b:	58                   	pop    rax
    7a0d2a806b9c:	e9 6c f0 ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806ba1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a2
    7a0d2a806ba8:	a2 00 01 00 
    7a0d2a806bac:	b8 a2 00 01 00       	mov    eax,0x100a2
    7a0d2a806bb1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806bb8:	02 00 00 00 
    7a0d2a806bbc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a806bc3:	04 00 00 00 
    7a0d2a806bc7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806bca:	be a2 00 01 00       	mov    esi,0x100a2
    7a0d2a806bcf:	4c 89 ef             	mov    rdi,r13
    7a0d2a806bd2:	e8 89 95 ff e7       	call   0x7a0d12800160
    7a0d2a806bd7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806bde:	00 
    7a0d2a806bdf:	0f 84 56 eb ff e7    	je     0x7a0d1280573b
    7a0d2a806be5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806bec:	02 00 00 00 
    7a0d2a806bf0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a806bf7:	04 00 00 00 
    7a0d2a806bfb:	58                   	pop    rax
    7a0d2a806bfc:	e9 0c f0 ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806c01:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    7a0d2a806c08:	a4 00 01 00 
    7a0d2a806c0c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806c13:	02 00 00 00 
    7a0d2a806c17:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806c1e:	05 00 00 00 
    7a0d2a806c22:	ba a4 00 01 00       	mov    edx,0x100a4
    7a0d2a806c27:	4c 89 ef             	mov    rdi,r13
    7a0d2a806c2a:	4c 89 f6             	mov    rsi,r14
    7a0d2a806c2d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a806c33:	e8 48 94 ff e7       	call   0x7a0d12800080
    7a0d2a806c38:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806c3f:	02 00 00 00 
    7a0d2a806c43:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806c4a:	05 00 00 00 
    7a0d2a806c4e:	58                   	pop    rax
    7a0d2a806c4f:	e9 b9 ef ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806c54:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    7a0d2a806c5b:	a4 00 01 00 
    7a0d2a806c5f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806c66:	02 00 00 00 
    7a0d2a806c6a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806c71:	05 00 00 00 
    7a0d2a806c75:	4c 89 f7             	mov    rdi,r14
    7a0d2a806c78:	89 ce                	mov    esi,ecx
    7a0d2a806c7a:	e8 f1 93 ff e7       	call   0x7a0d12800070
    7a0d2a806c7f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806c86:	00 
    7a0d2a806c87:	0f 84 ec ea ff e7    	je     0x7a0d12805779
    7a0d2a806c8d:	eb a9                	jmp    0x7a0d2a806c38
    7a0d2a806c8f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    7a0d2a806c96:	a4 00 01 00 
    7a0d2a806c9a:	b8 a4 00 01 00       	mov    eax,0x100a4
    7a0d2a806c9f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806ca6:	02 00 00 00 
    7a0d2a806caa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806cb1:	05 00 00 00 
    7a0d2a806cb5:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806cb8:	be a4 00 01 00       	mov    esi,0x100a4
    7a0d2a806cbd:	4c 89 ef             	mov    rdi,r13
    7a0d2a806cc0:	e8 9b 94 ff e7       	call   0x7a0d12800160
    7a0d2a806cc5:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a806cc8:	0f 84 dc ea ff e7    	je     0x7a0d128057aa
    7a0d2a806cce:	eb 0f                	jmp    0x7a0d2a806cdf
    7a0d2a806cd0:	b8 a4 00 01 00       	mov    eax,0x100a4
    7a0d2a806cd5:	83 c0 02             	add    eax,0x2
    7a0d2a806cd8:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a806cdf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806ce6:	02 00 00 00 
    7a0d2a806cea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806cf1:	05 00 00 00 
    7a0d2a806cf5:	4c 89 ef             	mov    rdi,r13
    7a0d2a806cf8:	e8 53 94 ff e7       	call   0x7a0d12800150
    7a0d2a806cfd:	e9 a8 ea ff e7       	jmp    0x7a0d128057aa
    7a0d2a806d02:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a6
    7a0d2a806d09:	a6 00 01 00 
    7a0d2a806d0d:	b8 a6 00 01 00       	mov    eax,0x100a6
    7a0d2a806d12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806d19:	02 00 00 00 
    7a0d2a806d1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806d24:	06 00 00 00 
    7a0d2a806d28:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806d2b:	be a6 00 01 00       	mov    esi,0x100a6
    7a0d2a806d30:	4c 89 ef             	mov    rdi,r13
    7a0d2a806d33:	e8 28 94 ff e7       	call   0x7a0d12800160
    7a0d2a806d38:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806d3f:	00 
    7a0d2a806d40:	0f 84 e3 ea ff e7    	je     0x7a0d12805829
    7a0d2a806d46:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806d4d:	02 00 00 00 
    7a0d2a806d51:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806d58:	06 00 00 00 
    7a0d2a806d5c:	58                   	pop    rax
    7a0d2a806d5d:	e9 ab ee ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806d62:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a8
    7a0d2a806d69:	a8 00 01 00 
    7a0d2a806d6d:	b8 a8 00 01 00       	mov    eax,0x100a8
    7a0d2a806d72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806d79:	02 00 00 00 
    7a0d2a806d7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a806d84:	07 00 00 00 
    7a0d2a806d88:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806d8b:	be a8 00 01 00       	mov    esi,0x100a8
    7a0d2a806d90:	4c 89 ef             	mov    rdi,r13
    7a0d2a806d93:	e8 c8 93 ff e7       	call   0x7a0d12800160
    7a0d2a806d98:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806d9f:	00 
    7a0d2a806da0:	0f 84 b1 ea ff e7    	je     0x7a0d12805857
    7a0d2a806da6:	e9 eb ea ff e7       	jmp    0x7a0d12805896
    7a0d2a806dab:	b8 a8 00 01 00       	mov    eax,0x100a8
    7a0d2a806db0:	83 c0 dc             	add    eax,0xffffffdc
    7a0d2a806db3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a806dba:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806dc1:	02 00 00 00 
    7a0d2a806dc5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a806dcc:	07 00 00 00 
    7a0d2a806dd0:	be a8 00 01 00       	mov    esi,0x100a8
    7a0d2a806dd5:	ba a8 00 01 00       	mov    edx,0x100a8
    7a0d2a806dda:	4c 89 ef             	mov    rdi,r13
    7a0d2a806ddd:	e8 7e 93 ff e7       	call   0x7a0d12800160
    7a0d2a806de2:	e9 a0 ea ff e7       	jmp    0x7a0d12805887
    7a0d2a806de7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100aa
    7a0d2a806dee:	aa 00 01 00 
    7a0d2a806df2:	b8 aa 00 01 00       	mov    eax,0x100aa
    7a0d2a806df7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806dfe:	04 00 00 00 
    7a0d2a806e02:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a806e09:	08 00 00 00 
    7a0d2a806e0d:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a806e10:	be aa 00 01 00       	mov    esi,0x100aa
    7a0d2a806e15:	4c 89 ef             	mov    rdi,r13
    7a0d2a806e18:	e8 43 93 ff e7       	call   0x7a0d12800160
    7a0d2a806e1d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806e24:	00 
    7a0d2a806e25:	0f 84 ba ea ff e7    	je     0x7a0d128058e5
    7a0d2a806e2b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806e32:	04 00 00 00 
    7a0d2a806e36:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a806e3d:	08 00 00 00 
    7a0d2a806e41:	58                   	pop    rax
    7a0d2a806e42:	e9 c6 ed ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806e47:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ae
    7a0d2a806e4e:	ae 00 01 00 
    7a0d2a806e52:	b8 ae 00 01 00       	mov    eax,0x100ae
    7a0d2a806e57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806e5e:	02 00 00 00 
    7a0d2a806e62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a806e69:	09 00 00 00 
    7a0d2a806e6d:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806e70:	be ae 00 01 00       	mov    esi,0x100ae
    7a0d2a806e75:	4c 89 ef             	mov    rdi,r13
    7a0d2a806e78:	e8 e3 92 ff e7       	call   0x7a0d12800160
    7a0d2a806e7d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806e84:	00 
    7a0d2a806e85:	0f 84 86 ea ff e7    	je     0x7a0d12805911
    7a0d2a806e8b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806e92:	02 00 00 00 
    7a0d2a806e96:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a806e9d:	09 00 00 00 
    7a0d2a806ea1:	58                   	pop    rax
    7a0d2a806ea2:	e9 66 ed ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806ea7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b0
    7a0d2a806eae:	b0 00 01 00 
    7a0d2a806eb2:	b8 b0 00 01 00       	mov    eax,0x100b0
    7a0d2a806eb7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806ebe:	04 00 00 00 
    7a0d2a806ec2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a806ec9:	0a 00 00 00 
    7a0d2a806ecd:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a806ed0:	be b0 00 01 00       	mov    esi,0x100b0
    7a0d2a806ed5:	4c 89 ef             	mov    rdi,r13
    7a0d2a806ed8:	e8 83 92 ff e7       	call   0x7a0d12800160
    7a0d2a806edd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806ee4:	00 
    7a0d2a806ee5:	0f 84 5d ea ff e7    	je     0x7a0d12805948
    7a0d2a806eeb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806ef2:	04 00 00 00 
    7a0d2a806ef6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a806efd:	0a 00 00 00 
    7a0d2a806f01:	58                   	pop    rax
    7a0d2a806f02:	e9 06 ed ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806f07:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    7a0d2a806f0e:	b4 00 01 00 
    7a0d2a806f12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806f19:	02 00 00 00 
    7a0d2a806f1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806f24:	0b 00 00 00 
    7a0d2a806f28:	ba b4 00 01 00       	mov    edx,0x100b4
    7a0d2a806f2d:	4c 89 ef             	mov    rdi,r13
    7a0d2a806f30:	4c 89 f6             	mov    rsi,r14
    7a0d2a806f33:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a806f39:	e8 42 91 ff e7       	call   0x7a0d12800080
    7a0d2a806f3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806f45:	02 00 00 00 
    7a0d2a806f49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806f50:	0b 00 00 00 
    7a0d2a806f54:	58                   	pop    rax
    7a0d2a806f55:	e9 b3 ec ff e7       	jmp    0x7a0d12805c0d
    7a0d2a806f5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    7a0d2a806f61:	b4 00 01 00 
    7a0d2a806f65:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806f6c:	02 00 00 00 
    7a0d2a806f70:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806f77:	0b 00 00 00 
    7a0d2a806f7b:	4c 89 f7             	mov    rdi,r14
    7a0d2a806f7e:	89 ce                	mov    esi,ecx
    7a0d2a806f80:	e8 eb 90 ff e7       	call   0x7a0d12800070
    7a0d2a806f85:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a806f8c:	00 
    7a0d2a806f8d:	0f 84 f3 e9 ff e7    	je     0x7a0d12805986
    7a0d2a806f93:	eb a9                	jmp    0x7a0d2a806f3e
    7a0d2a806f95:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    7a0d2a806f9c:	b4 00 01 00 
    7a0d2a806fa0:	b8 b4 00 01 00       	mov    eax,0x100b4
    7a0d2a806fa5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806fac:	02 00 00 00 
    7a0d2a806fb0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806fb7:	0b 00 00 00 
    7a0d2a806fbb:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a806fbe:	be b4 00 01 00       	mov    esi,0x100b4
    7a0d2a806fc3:	4c 89 ef             	mov    rdi,r13
    7a0d2a806fc6:	e8 95 91 ff e7       	call   0x7a0d12800160
    7a0d2a806fcb:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a806fce:	0f 84 e3 e9 ff e7    	je     0x7a0d128059b7
    7a0d2a806fd4:	eb 0f                	jmp    0x7a0d2a806fe5
    7a0d2a806fd6:	b8 b4 00 01 00       	mov    eax,0x100b4
    7a0d2a806fdb:	83 c0 02             	add    eax,0x2
    7a0d2a806fde:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a806fe5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806fec:	02 00 00 00 
    7a0d2a806ff0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806ff7:	0b 00 00 00 
    7a0d2a806ffb:	4c 89 ef             	mov    rdi,r13
    7a0d2a806ffe:	e8 4d 91 ff e7       	call   0x7a0d12800150
    7a0d2a807003:	e9 af e9 ff e7       	jmp    0x7a0d128059b7
    7a0d2a807008:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    7a0d2a80700f:	b6 00 01 00 
    7a0d2a807013:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80701a:	04 00 00 00 
    7a0d2a80701e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a807025:	0c 00 00 00 
    7a0d2a807029:	ba b6 00 01 00       	mov    edx,0x100b6
    7a0d2a80702e:	4c 89 ef             	mov    rdi,r13
    7a0d2a807031:	4c 89 f6             	mov    rsi,r14
    7a0d2a807034:	89 d9                	mov    ecx,ebx
    7a0d2a807036:	45 31 c0             	xor    r8d,r8d
    7a0d2a807039:	e8 42 90 ff e7       	call   0x7a0d12800080
    7a0d2a80703e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a807045:	04 00 00 00 
    7a0d2a807049:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a807050:	0c 00 00 00 
    7a0d2a807054:	58                   	pop    rax
    7a0d2a807055:	e9 b3 eb ff e7       	jmp    0x7a0d12805c0d
    7a0d2a80705a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    7a0d2a807061:	b6 00 01 00 
    7a0d2a807065:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80706c:	04 00 00 00 
    7a0d2a807070:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a807077:	0c 00 00 00 
    7a0d2a80707b:	4c 89 f7             	mov    rdi,r14
    7a0d2a80707e:	89 de                	mov    esi,ebx
    7a0d2a807080:	e8 bb 8f ff e7       	call   0x7a0d12800040
    7a0d2a807085:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80708c:	00 
    7a0d2a80708d:	75 af                	jne    0x7a0d2a80703e
    7a0d2a80708f:	41 89 c7             	mov    r15d,eax
    7a0d2a807092:	e9 65 e9 ff e7       	jmp    0x7a0d128059fc
    7a0d2a807097:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    7a0d2a80709e:	b6 00 01 00 
    7a0d2a8070a2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8070a9:	04 00 00 00 
    7a0d2a8070ad:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8070b4:	0c 00 00 00 
    7a0d2a8070b8:	4c 89 f7             	mov    rdi,r14
    7a0d2a8070bb:	e8 80 8f ff e7       	call   0x7a0d12800040
    7a0d2a8070c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8070c7:	00 
    7a0d2a8070c8:	0f 84 4f e9 ff e7    	je     0x7a0d12805a1d
    7a0d2a8070ce:	e9 6b ff ff ff       	jmp    0x7a0d2a80703e
    7a0d2a8070d3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    7a0d2a8070da:	b6 00 01 00 
    7a0d2a8070de:	b8 b6 00 01 00       	mov    eax,0x100b6
    7a0d2a8070e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8070ea:	04 00 00 00 
    7a0d2a8070ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8070f5:	0c 00 00 00 
    7a0d2a8070f9:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8070fc:	be b6 00 01 00       	mov    esi,0x100b6
    7a0d2a807101:	4c 89 ef             	mov    rdi,r13
    7a0d2a807104:	e8 57 90 ff e7       	call   0x7a0d12800160
    7a0d2a807109:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807110:	00 
    7a0d2a807111:	0f 84 3a e9 ff e7    	je     0x7a0d12805a51
    7a0d2a807117:	e9 22 ff ff ff       	jmp    0x7a0d2a80703e
    7a0d2a80711c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ba
    7a0d2a807123:	ba 00 01 00 
    7a0d2a807127:	b8 ba 00 01 00       	mov    eax,0x100ba
    7a0d2a80712c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807133:	02 00 00 00 
    7a0d2a807137:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a80713e:	0d 00 00 00 
    7a0d2a807142:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a807145:	be ba 00 01 00       	mov    esi,0x100ba
    7a0d2a80714a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80714d:	e8 0e 90 ff e7       	call   0x7a0d12800160
    7a0d2a807152:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807159:	00 
    7a0d2a80715a:	0f 84 1d e9 ff e7    	je     0x7a0d12805a7d
    7a0d2a807160:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807167:	02 00 00 00 
    7a0d2a80716b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a807172:	0d 00 00 00 
    7a0d2a807176:	58                   	pop    rax
    7a0d2a807177:	e9 91 ea ff e7       	jmp    0x7a0d12805c0d
    7a0d2a80717c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a807183:	bc 00 01 00 
    7a0d2a807187:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80718e:	02 00 00 00 
    7a0d2a807192:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807199:	0e 00 00 00 
    7a0d2a80719d:	ba bc 00 01 00       	mov    edx,0x100bc
    7a0d2a8071a2:	4c 89 ef             	mov    rdi,r13
    7a0d2a8071a5:	4c 89 f6             	mov    rsi,r14
    7a0d2a8071a8:	89 d9                	mov    ecx,ebx
    7a0d2a8071aa:	45 31 c0             	xor    r8d,r8d
    7a0d2a8071ad:	e8 ce 8e ff e7       	call   0x7a0d12800080
    7a0d2a8071b2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8071b9:	02 00 00 00 
    7a0d2a8071bd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a8071c4:	0e 00 00 00 
    7a0d2a8071c8:	58                   	pop    rax
    7a0d2a8071c9:	e9 3f ea ff e7       	jmp    0x7a0d12805c0d
    7a0d2a8071ce:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a8071d5:	bc 00 01 00 
    7a0d2a8071d9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8071e0:	02 00 00 00 
    7a0d2a8071e4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a8071eb:	0e 00 00 00 
    7a0d2a8071ef:	4c 89 f7             	mov    rdi,r14
    7a0d2a8071f2:	89 de                	mov    esi,ebx
    7a0d2a8071f4:	e8 47 8e ff e7       	call   0x7a0d12800040
    7a0d2a8071f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807200:	00 
    7a0d2a807201:	0f 84 ac e8 ff e7    	je     0x7a0d12805ab3
    7a0d2a807207:	eb a9                	jmp    0x7a0d2a8071b2
    7a0d2a807209:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a807210:	bc 00 01 00 
    7a0d2a807214:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80721b:	02 00 00 00 
    7a0d2a80721f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807226:	0e 00 00 00 
    7a0d2a80722a:	4c 89 f7             	mov    rdi,r14
    7a0d2a80722d:	e8 0e 8e ff e7       	call   0x7a0d12800040
    7a0d2a807232:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807239:	00 
    7a0d2a80723a:	0f 84 96 e8 ff e7    	je     0x7a0d12805ad6
    7a0d2a807240:	e9 6d ff ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a807245:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a80724c:	bc 00 01 00 
    7a0d2a807250:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807257:	02 00 00 00 
    7a0d2a80725b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807262:	0e 00 00 00 
    7a0d2a807266:	4c 89 f7             	mov    rdi,r14
    7a0d2a807269:	e8 d2 8d ff e7       	call   0x7a0d12800040
    7a0d2a80726e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807275:	00 
    7a0d2a807276:	0f 84 7d e8 ff e7    	je     0x7a0d12805af9
    7a0d2a80727c:	e9 31 ff ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a807281:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a807288:	bc 00 01 00 
    7a0d2a80728c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807293:	02 00 00 00 
    7a0d2a807297:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a80729e:	0e 00 00 00 
    7a0d2a8072a2:	4c 89 f7             	mov    rdi,r14
    7a0d2a8072a5:	e8 96 8d ff e7       	call   0x7a0d12800040
    7a0d2a8072aa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8072b1:	00 
    7a0d2a8072b2:	0f 84 64 e8 ff e7    	je     0x7a0d12805b1c
    7a0d2a8072b8:	e9 f5 fe ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a8072bd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a8072c4:	bc 00 01 00 
    7a0d2a8072c8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8072cf:	02 00 00 00 
    7a0d2a8072d3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a8072da:	0e 00 00 00 
    7a0d2a8072de:	4c 89 f7             	mov    rdi,r14
    7a0d2a8072e1:	e8 5a 8d ff e7       	call   0x7a0d12800040
    7a0d2a8072e6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8072ed:	00 
    7a0d2a8072ee:	0f 84 4b e8 ff e7    	je     0x7a0d12805b3f
    7a0d2a8072f4:	e9 b9 fe ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a8072f9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a807300:	bc 00 01 00 
    7a0d2a807304:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80730b:	02 00 00 00 
    7a0d2a80730f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807316:	0e 00 00 00 
    7a0d2a80731a:	4c 89 f7             	mov    rdi,r14
    7a0d2a80731d:	e8 1e 8d ff e7       	call   0x7a0d12800040
    7a0d2a807322:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807329:	00 
    7a0d2a80732a:	0f 84 32 e8 ff e7    	je     0x7a0d12805b62
    7a0d2a807330:	e9 7d fe ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a807335:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a80733c:	bc 00 01 00 
    7a0d2a807340:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807347:	02 00 00 00 
    7a0d2a80734b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807352:	0e 00 00 00 
    7a0d2a807356:	4c 89 f7             	mov    rdi,r14
    7a0d2a807359:	e8 e2 8c ff e7       	call   0x7a0d12800040
    7a0d2a80735e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807365:	00 
    7a0d2a807366:	0f 84 1b e8 ff e7    	je     0x7a0d12805b87
    7a0d2a80736c:	e9 41 fe ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a807371:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    7a0d2a807378:	bc 00 01 00 
    7a0d2a80737c:	b8 bc 00 01 00       	mov    eax,0x100bc
    7a0d2a807381:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807388:	02 00 00 00 
    7a0d2a80738c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a807393:	0e 00 00 00 
    7a0d2a807397:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80739a:	be bc 00 01 00       	mov    esi,0x100bc
    7a0d2a80739f:	4c 89 ef             	mov    rdi,r13
    7a0d2a8073a2:	e8 b9 8d ff e7       	call   0x7a0d12800160
    7a0d2a8073a7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8073ae:	00 
    7a0d2a8073af:	0f 84 ff e7 ff e7    	je     0x7a0d12805bb4
    7a0d2a8073b5:	e9 f8 fd ff ff       	jmp    0x7a0d2a8071b2
    7a0d2a8073ba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100be
    7a0d2a8073c1:	be 00 01 00 
    7a0d2a8073c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8073cc:	02 00 00 00 
    7a0d2a8073d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a8073d7:	0f 00 00 00 
    7a0d2a8073db:	4c 89 ef             	mov    rdi,r13
    7a0d2a8073de:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a8073e3:	4c 89 f2             	mov    rdx,r14
    7a0d2a8073e6:	e8 a5 8c ff e7       	call   0x7a0d12800090
    7a0d2a8073eb:	e9 06 e8 ff e7       	jmp    0x7a0d12805bf6
    7a0d2a8073f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8073f7:	02 00 00 00 
    7a0d2a8073fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a807402:	0f 00 00 00 
    7a0d2a807406:	be be 00 01 00       	mov    esi,0x100be
    7a0d2a80740b:	ba be 00 01 00       	mov    edx,0x100be
    7a0d2a807410:	4c 89 ef             	mov    rdi,r13
    7a0d2a807413:	e8 48 8d ff e7       	call   0x7a0d12800160
    7a0d2a807418:	e9 d9 e7 ff e7       	jmp    0x7a0d12805bf6
    7a0d2a80741d:	c2 08 00             	ret    0x8
