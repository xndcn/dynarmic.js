
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65868-1-134196563553360.bin:     file format binary


Disassembly of section .data:

00007a0d12802c50 <.data>:
    7a0d12802c50:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802c57:	8b 88 20 00 10 00    	mov    ecx,DWORD PTR [rax+0x100020]
    7a0d12802c5d:	ff c1                	inc    ecx
    7a0d12802c5f:	89 88 20 00 10 00    	mov    DWORD PTR [rax+0x100020],ecx
    7a0d12802c65:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d12802c6b:	0f 84 4f 11 00 18    	je     0x7a0d2a803dc0
    7a0d12802c71:	50                   	push   rax
    7a0d12802c72:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12802c76:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d12802c79:	f6 c3 03             	test   bl,0x3
    7a0d12802c7c:	0f 85 6a 11 00 18    	jne    0x7a0d2a803dec
    7a0d12802c82:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d12802c89:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12802c90:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7a0d12802c94:	89 c8                	mov    eax,ecx
    7a0d12802c96:	c1 e8 0c             	shr    eax,0xc
    7a0d12802c99:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802c9e:	48 85 c0             	test   rax,rax
    7a0d12802ca1:	0f 84 98 11 00 18    	je     0x7a0d2a803e3f
    7a0d12802ca7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802cad:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12802cb0:	8d 73 f8             	lea    esi,[rbx-0x8]
    7a0d12802cb3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7a0d12802cb7:	89 f0                	mov    eax,esi
    7a0d12802cb9:	c1 e8 0c             	shr    eax,0xc
    7a0d12802cbc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802cc1:	48 85 c0             	test   rax,rax
    7a0d12802cc4:	0f 84 b0 11 00 18    	je     0x7a0d2a803e7a
    7a0d12802cca:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12802cd0:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12802cd3:	8d 73 f4             	lea    esi,[rbx-0xc]
    7a0d12802cd6:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7a0d12802cda:	89 f0                	mov    eax,esi
    7a0d12802cdc:	c1 e8 0c             	shr    eax,0xc
    7a0d12802cdf:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802ce4:	48 85 c0             	test   rax,rax
    7a0d12802ce7:	0f 84 c9 11 00 18    	je     0x7a0d2a803eb6
    7a0d12802ced:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12802cf3:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12802cf6:	8d 73 f0             	lea    esi,[rbx-0x10]
    7a0d12802cf9:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7a0d12802cfd:	89 f0                	mov    eax,esi
    7a0d12802cff:	c1 e8 0c             	shr    eax,0xc
    7a0d12802d02:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802d07:	48 85 c0             	test   rax,rax
    7a0d12802d0a:	0f 84 e2 11 00 18    	je     0x7a0d2a803ef2
    7a0d12802d10:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12802d16:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12802d19:	83 c3 ec             	add    ebx,0xffffffec
    7a0d12802d1c:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7a0d12802d20:	89 d8                	mov    eax,ebx
    7a0d12802d22:	c1 e8 0c             	shr    eax,0xc
    7a0d12802d25:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802d2a:	48 85 c0             	test   rax,rax
    7a0d12802d2d:	0f 84 fb 11 00 18    	je     0x7a0d2a803f2e
    7a0d12802d33:	89 d9                	mov    ecx,ebx
    7a0d12802d35:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802d3b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12802d3e:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d12802d42:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1014c
    7a0d12802d49:	4c 01 01 00 
    7a0d12802d4d:	0f 84 19 12 00 18    	je     0x7a0d2a803f6c
    7a0d12802d53:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1014c
    7a0d12802d5a:	4c 01 01 00 
    7a0d12802d5e:	0f 84 08 12 00 18    	je     0x7a0d2a803f6c
    7a0d12802d64:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12802d68:	0f 85 40 12 00 18    	jne    0x7a0d2a803fae
    7a0d12802d6e:	58                   	pop    rax
    7a0d12802d6f:	e9 0f 00 00 00       	jmp    0x7a0d12802d83
    7a0d12802d74:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12802d7b:	00 
    7a0d12802d7c:	74 f0                	je     0x7a0d12802d6e
    7a0d12802d7e:	e9 a0 10 00 18       	jmp    0x7a0d2a803e23
    7a0d12802d83:	50                   	push   rax
    7a0d12802d84:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12802d88:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d12802d8b:	f6 c3 03             	test   bl,0x3
    7a0d12802d8e:	0f 85 4c 12 00 18    	jne    0x7a0d2a803fe0
    7a0d12802d94:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d12802d9b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12802da2:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d12802da6:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d12802dad:	89 c8                	mov    eax,ecx
    7a0d12802daf:	c1 e8 0c             	shr    eax,0xc
    7a0d12802db2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802db7:	48 85 c0             	test   rax,rax
    7a0d12802dba:	0f 84 73 12 00 18    	je     0x7a0d2a804033
    7a0d12802dc0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802dc6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12802dc9:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d12802dcc:	89 d8                	mov    eax,ebx
    7a0d12802dce:	c1 e8 0c             	shr    eax,0xc
    7a0d12802dd1:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802dd6:	48 85 c0             	test   rax,rax
    7a0d12802dd9:	0f 84 8f 12 00 18    	je     0x7a0d2a80406e
    7a0d12802ddf:	89 d9                	mov    ecx,ebx
    7a0d12802de1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802de7:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d12802deb:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d12802def:	b8 0c 00 00 00       	mov    eax,0xc
    7a0d12802df4:	29 c3                	sub    ebx,eax
    7a0d12802df6:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d12802dfa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1014e
    7a0d12802e01:	4e 01 01 00 
    7a0d12802e05:	0f 84 a4 12 00 18    	je     0x7a0d2a8040af
    7a0d12802e0b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1014e
    7a0d12802e12:	4e 01 01 00 
    7a0d12802e16:	0f 84 93 12 00 18    	je     0x7a0d2a8040af
    7a0d12802e1c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12802e20:	0f 85 cb 12 00 18    	jne    0x7a0d2a8040f1
    7a0d12802e26:	58                   	pop    rax
    7a0d12802e27:	e9 0f 00 00 00       	jmp    0x7a0d12802e3b
    7a0d12802e2c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12802e33:	00 
    7a0d12802e34:	74 f0                	je     0x7a0d12802e26
    7a0d12802e36:	e9 dc 11 00 18       	jmp    0x7a0d2a804017
    7a0d12802e3b:	50                   	push   rax
    7a0d12802e3c:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12802e40:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12802e47:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7a0d12802e4b:	81 f9 52 01 01 00    	cmp    ecx,0x10152
    7a0d12802e51:	0f 84 cc 12 00 18    	je     0x7a0d2a804123
    7a0d12802e57:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10152
    7a0d12802e5e:	52 01 01 00 
    7a0d12802e62:	0f 84 bb 12 00 18    	je     0x7a0d2a804123
    7a0d12802e68:	58                   	pop    rax
    7a0d12802e69:	50                   	push   rax
    7a0d12802e6a:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12802e6e:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12802e75:	31 d2                	xor    edx,edx
    7a0d12802e77:	85 c0                	test   eax,eax
    7a0d12802e79:	0f 94 c2             	sete   dl
    7a0d12802e7c:	c1 e8 1f             	shr    eax,0x1f
    7a0d12802e7f:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12802e86:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12802e8d:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12802e94:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d12802e9b:	00 00 00 
    7a0d12802e9e:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d12802ea5:	81 f9 54 01 01 00    	cmp    ecx,0x10154
    7a0d12802eab:	0f 84 d2 12 00 18    	je     0x7a0d2a804183
    7a0d12802eb1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10154
    7a0d12802eb8:	54 01 01 00 
    7a0d12802ebc:	0f 84 c1 12 00 18    	je     0x7a0d2a804183
    7a0d12802ec2:	58                   	pop    rax
    7a0d12802ec3:	50                   	push   rax
    7a0d12802ec4:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12802ecb:	00 
    7a0d12802ecc:	74 55                	je     0x7a0d12802f23
    7a0d12802ece:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12802ed5:	01 
    7a0d12802ed6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10156
    7a0d12802edd:	56 01 01 00 
    7a0d12802ee1:	0f 84 fc 12 00 18    	je     0x7a0d2a8041e3
    7a0d12802ee7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10156
    7a0d12802eee:	56 01 01 00 
    7a0d12802ef2:	0f 84 eb 12 00 18    	je     0x7a0d2a8041e3
    7a0d12802ef8:	b8 56 01 01 00       	mov    eax,0x10156
    7a0d12802efd:	83 c0 46             	add    eax,0x46
    7a0d12802f00:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12802f07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12802f0e:	02 00 00 00 
    7a0d12802f12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d12802f19:	05 00 00 00 
    7a0d12802f1d:	58                   	pop    rax
    7a0d12802f1e:	e9 d2 01 00 00       	jmp    0x7a0d128030f5
    7a0d12802f23:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10156
    7a0d12802f2a:	56 01 01 00 
    7a0d12802f2e:	0f 84 eb 12 00 18    	je     0x7a0d2a80421f
    7a0d12802f34:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10156
    7a0d12802f3b:	56 01 01 00 
    7a0d12802f3f:	0f 84 da 12 00 18    	je     0x7a0d2a80421f
    7a0d12802f45:	58                   	pop    rax
    7a0d12802f46:	50                   	push   rax
    7a0d12802f47:	41 0f b7 45 10       	movzx  eax,WORD PTR [r13+0x10]
    7a0d12802f4c:	b9 00 00 19 00       	mov    ecx,0x190000
    7a0d12802f51:	09 c1                	or     ecx,eax
    7a0d12802f53:	41 89 4d 10          	mov    DWORD PTR [r13+0x10],ecx
    7a0d12802f57:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10158
    7a0d12802f5e:	58 01 01 00 
    7a0d12802f62:	0f 84 00 13 00 18    	je     0x7a0d2a804268
    7a0d12802f68:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10158
    7a0d12802f6f:	58 01 01 00 
    7a0d12802f73:	0f 84 ef 12 00 18    	je     0x7a0d2a804268
    7a0d12802f79:	58                   	pop    rax
    7a0d12802f7a:	50                   	push   rax
    7a0d12802f7b:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    7a0d12802f80:	b9 00 00 6e 3c       	mov    ecx,0x3c6e0000
    7a0d12802f85:	09 c1                	or     ecx,eax
    7a0d12802f87:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    7a0d12802f8b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1015c
    7a0d12802f92:	5c 01 01 00 
    7a0d12802f96:	0f 84 2c 13 00 18    	je     0x7a0d2a8042c8
    7a0d12802f9c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1015c
    7a0d12802fa3:	5c 01 01 00 
    7a0d12802fa7:	0f 84 1b 13 00 18    	je     0x7a0d2a8042c8
    7a0d12802fad:	58                   	pop    rax
    7a0d12802fae:	50                   	push   rax
    7a0d12802faf:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d12802fb3:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12802fba:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12802fbe:	81 f9 60 01 01 00    	cmp    ecx,0x10160
    7a0d12802fc4:	0f 84 5e 13 00 18    	je     0x7a0d2a804328
    7a0d12802fca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10160
    7a0d12802fd1:	60 01 01 00 
    7a0d12802fd5:	0f 84 4d 13 00 18    	je     0x7a0d2a804328
    7a0d12802fdb:	58                   	pop    rax
    7a0d12802fdc:	50                   	push   rax
    7a0d12802fdd:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d12802fe1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12802fe8:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12802fec:	81 f9 62 01 01 00    	cmp    ecx,0x10162
    7a0d12802ff2:	0f 84 90 13 00 18    	je     0x7a0d2a804388
    7a0d12802ff8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10162
    7a0d12802fff:	62 01 01 00 
    7a0d12803003:	0f 84 7f 13 00 18    	je     0x7a0d2a804388
    7a0d12803009:	58                   	pop    rax
    7a0d1280300a:	50                   	push   rax
    7a0d1280300b:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    7a0d12803012:	00 
    7a0d12803013:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10164
    7a0d1280301a:	64 01 01 00 
    7a0d1280301e:	0f 84 c4 13 00 18    	je     0x7a0d2a8043e8
    7a0d12803024:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10164
    7a0d1280302b:	64 01 01 00 
    7a0d1280302f:	0f 84 b3 13 00 18    	je     0x7a0d2a8043e8
    7a0d12803035:	58                   	pop    rax
    7a0d12803036:	50                   	push   rax
    7a0d12803037:	41 0f b7 45 12       	movzx  eax,WORD PTR [r13+0x12]
    7a0d1280303c:	c1 e0 10             	shl    eax,0x10
    7a0d1280303f:	b9 0d 66 00 00       	mov    ecx,0x660d
    7a0d12803044:	09 c1                	or     ecx,eax
    7a0d12803046:	41 89 4d 10          	mov    DWORD PTR [r13+0x10],ecx
    7a0d1280304a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10166
    7a0d12803051:	66 01 01 00 
    7a0d12803055:	0f 84 ed 13 00 18    	je     0x7a0d2a804448
    7a0d1280305b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10166
    7a0d12803062:	66 01 01 00 
    7a0d12803066:	0f 84 dc 13 00 18    	je     0x7a0d2a804448
    7a0d1280306c:	58                   	pop    rax
    7a0d1280306d:	50                   	push   rax
    7a0d1280306e:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    7a0d12803073:	c1 e0 10             	shl    eax,0x10
    7a0d12803076:	b9 5f f3 00 00       	mov    ecx,0xf35f
    7a0d1280307b:	09 c1                	or     ecx,eax
    7a0d1280307d:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    7a0d12803081:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1016a
    7a0d12803088:	6a 01 01 00 
    7a0d1280308c:	0f 84 16 14 00 18    	je     0x7a0d2a8044a8
    7a0d12803092:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1016a
    7a0d12803099:	6a 01 01 00 
    7a0d1280309d:	0f 84 05 14 00 18    	je     0x7a0d2a8044a8
    7a0d128030a3:	58                   	pop    rax
    7a0d128030a4:	50                   	push   rax
    7a0d128030a5:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128030ac:	01 
    7a0d128030ad:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1016e
    7a0d128030b4:	6e 01 01 00 
    7a0d128030b8:	0f 84 4a 14 00 18    	je     0x7a0d2a804508
    7a0d128030be:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1016e
    7a0d128030c5:	6e 01 01 00 
    7a0d128030c9:	0f 84 39 14 00 18    	je     0x7a0d2a804508
    7a0d128030cf:	b8 6e 01 01 00       	mov    eax,0x1016e
    7a0d128030d4:	83 c0 0e             	add    eax,0xe
    7a0d128030d7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128030de:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d128030e5:	02 00 00 00 
    7a0d128030e9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d128030f0:	0d 00 00 00 
    7a0d128030f4:	58                   	pop    rax
    7a0d128030f5:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128030fc:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12803103:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d1280310a:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12803111:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12803118:	39 f1                	cmp    ecx,esi
    7a0d1280311a:	0f 83 24 14 00 18    	jae    0x7a0d2a804544
    7a0d12803120:	81 fa 4c 01 01 00    	cmp    edx,0x1014c
    7a0d12803126:	75 14                	jne    0x7a0d1280313c
    7a0d12803128:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280312f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803136:	00 
    7a0d12803137:	e9 14 fb ff ff       	jmp    0x7a0d12802c50
    7a0d1280313c:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12803143:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12803149:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d1280314c:	0f 85 f2 13 00 18    	jne    0x7a0d2a804544
    7a0d12803152:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803159:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803160:	00 
    7a0d12803161:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12803166:	ff e0                	jmp    rax
