
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65916-0-134196563562080.bin:     file format binary


Disassembly of section .data:

00007a0d12804e60 <.data>:
    7a0d12804e60:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7a0d12804e67:	8d 82 77 fe fe ff    	lea    eax,[rdx-0x10189]
    7a0d12804e6d:	83 f8 f2             	cmp    eax,0xfffffff2
    7a0d12804e70:	0f 87 05 13 00 18    	ja     0x7a0d2a80617b
    7a0d12804e76:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    7a0d12804e7d:	8d 81 77 fe fe ff    	lea    eax,[rcx-0x10189]
    7a0d12804e83:	83 f8 f2             	cmp    eax,0xfffffff2
    7a0d12804e86:	0f 87 ef 12 00 18    	ja     0x7a0d2a80617b
    7a0d12804e8c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12804e93:	41 8b 7d 1c          	mov    edi,DWORD PTR [r13+0x1c]
    7a0d12804e97:	41 8b 6d 34          	mov    ebp,DWORD PTR [r13+0x34]
    7a0d12804e9b:	41 0f af 7d 10       	imul   edi,DWORD PTR [r13+0x10]
    7a0d12804ea0:	41 89 6d 04          	mov    DWORD PTR [r13+0x4],ebp
    7a0d12804ea4:	8d 34 2f             	lea    esi,[rdi+rbp*1]
    7a0d12804ea7:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    7a0d12804eab:	c1 ef 1f             	shr    edi,0x1f
    7a0d12804eae:	c1 ed 1f             	shr    ebp,0x1f
    7a0d12804eb1:	89 f3                	mov    ebx,esi
    7a0d12804eb3:	c1 eb 1f             	shr    ebx,0x1f
    7a0d12804eb6:	31 dd                	xor    ebp,ebx
    7a0d12804eb8:	31 df                	xor    edi,ebx
    7a0d12804eba:	21 ef                	and    edi,ebp
    7a0d12804ebc:	41 09 bd 00 01 00 00 	or     DWORD PTR [r13+0x100],edi
    7a0d12804ec3:	31 ed                	xor    ebp,ebp
    7a0d12804ec5:	85 f6                	test   esi,esi
    7a0d12804ec7:	40 0f 94 c5          	sete   bpl
    7a0d12804ecb:	41 89 bd f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edi
    7a0d12804ed2:	41 89 bd fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edi
    7a0d12804ed9:	41 89 9d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ebx
    7a0d12804ee0:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    7a0d12804ee7:	41 89 9d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebx
    7a0d12804eee:	48 bf 01 00 00 00 01 	movabs rdi,0x100000001
    7a0d12804ef5:	00 00 00 
    7a0d12804ef8:	49 89 bd ec 00 00 00 	mov    QWORD PTR [r13+0xec],rdi
    7a0d12804eff:	78 4f                	js     0x7a0d12804f50
    7a0d12804f01:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d12804f08:	70 01 01 00 
    7a0d12804f0c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804f13:	83 c1 05             	add    ecx,0x5
    7a0d12804f16:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7a0d12804f1d:	39 d1                	cmp    ecx,edx
    7a0d12804f1f:	0f 83 2a 12 00 18    	jae    0x7a0d2a80614f
    7a0d12804f25:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    7a0d12804f2c:	01 01 00 
    7a0d12804f2f:	0f 85 1a 12 00 18    	jne    0x7a0d2a80614f
    7a0d12804f35:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d12804f3c:	70 01 01 00 
    7a0d12804f40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804f47:	48 8b 80 88 0b 08 00 	mov    rax,QWORD PTR [rax+0x80b88]
    7a0d12804f4e:	ff e0                	jmp    rax
    7a0d12804f50:	31 ff                	xor    edi,edi
    7a0d12804f52:	41 33 75 00          	xor    esi,DWORD PTR [r13+0x0]
    7a0d12804f56:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    7a0d12804f5a:	40 0f 94 c7          	sete   dil
    7a0d12804f5e:	c1 ee 1f             	shr    esi,0x1f
    7a0d12804f61:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    7a0d12804f68:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7a0d12804f6f:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12804f76:	00 00 00 00 
    7a0d12804f7a:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12804f81:	00 00 00 00 
    7a0d12804f85:	be 8c 01 01 00       	mov    esi,0x1018c
    7a0d12804f8a:	bf 8c 01 01 00       	mov    edi,0x1018c
    7a0d12804f8f:	81 fa 88 01 01 00    	cmp    edx,0x10188
    7a0d12804f95:	75 07                	jne    0x7a0d12804f9e
    7a0d12804f97:	41 8b bd 90 00 00 00 	mov    edi,DWORD PTR [r13+0x90]
    7a0d12804f9e:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    7a0d12804fa5:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12804fac:	02 
    7a0d12804fad:	0f 43 f7             	cmovae esi,edi
    7a0d12804fb0:	89 f7                	mov    edi,esi
    7a0d12804fb2:	81 f9 88 01 01 00    	cmp    ecx,0x10188
    7a0d12804fb8:	75 07                	jne    0x7a0d12804fc1
    7a0d12804fba:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d12804fc1:	83 fa 02             	cmp    edx,0x2
    7a0d12804fc4:	0f 43 f7             	cmovae esi,edi
    7a0d12804fc7:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    7a0d12804fce:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12804fd5:	10 01 01 00 
    7a0d12804fd9:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804fe0:	83 c1 07             	add    ecx,0x7
    7a0d12804fe3:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7a0d12804fea:	39 d1                	cmp    ecx,edx
    7a0d12804fec:	0f 83 94 11 00 18    	jae    0x7a0d2a806186
    7a0d12804ff2:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    7a0d12804ff9:	01 01 00 
    7a0d12804ffc:	0f 85 84 11 00 18    	jne    0x7a0d2a806186
    7a0d12805002:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12805009:	10 01 01 00 
    7a0d1280500d:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12805014:	48 8b 80 88 08 08 00 	mov    rax,QWORD PTR [rax+0x80888]
    7a0d1280501b:	ff e0                	jmp    rax
