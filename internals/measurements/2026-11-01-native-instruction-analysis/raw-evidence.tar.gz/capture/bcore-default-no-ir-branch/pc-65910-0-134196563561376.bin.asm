
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65910-0-134196563561376.bin:     file format binary


Disassembly of section .data:

00007a0d12804ba0 <.data>:
    7a0d12804ba0:	45 8b 95 a0 00 00 00 	mov    r10d,DWORD PTR [r13+0xa0]
    7a0d12804ba7:	41 8d 82 77 fe fe ff 	lea    eax,[r10-0x10189]
    7a0d12804bae:	83 f8 ec             	cmp    eax,0xffffffec
    7a0d12804bb1:	0f 87 09 15 00 18    	ja     0x7a0d2a8060c0
    7a0d12804bb7:	45 8b 85 a4 00 00 00 	mov    r8d,DWORD PTR [r13+0xa4]
    7a0d12804bbe:	41 8d 80 77 fe fe ff 	lea    eax,[r8-0x10189]
    7a0d12804bc5:	83 f8 ec             	cmp    eax,0xffffffec
    7a0d12804bc8:	0f 87 f2 14 00 18    	ja     0x7a0d2a8060c0
    7a0d12804bce:	4d 8b 8d 50 01 00 00 	mov    r9,QWORD PTR [r13+0x150]
    7a0d12804bd5:	41 8b 7d 14          	mov    edi,DWORD PTR [r13+0x14]
    7a0d12804bd9:	41 8b 75 18          	mov    esi,DWORD PTR [r13+0x18]
    7a0d12804bdd:	8d 5e 01             	lea    ebx,[rsi+0x1]
    7a0d12804be0:	41 89 5d 18          	mov    DWORD PTR [r13+0x18],ebx
    7a0d12804be4:	c1 ee 1f             	shr    esi,0x1f
    7a0d12804be7:	89 dd                	mov    ebp,ebx
    7a0d12804be9:	c1 ed 1f             	shr    ebp,0x1f
    7a0d12804bec:	c4 e2 48 f2 ed       	andn   ebp,esi,ebp
    7a0d12804bf1:	41 8b b5 00 01 00 00 	mov    esi,DWORD PTR [r13+0x100]
    7a0d12804bf8:	09 ee                	or     esi,ebp
    7a0d12804bfa:	41 89 ad f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebp
    7a0d12804c01:	41 89 ad fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebp
    7a0d12804c08:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    7a0d12804c0f:	31 ed                	xor    ebp,ebp
    7a0d12804c11:	31 c9                	xor    ecx,ecx
    7a0d12804c13:	31 c0                	xor    eax,eax
    7a0d12804c15:	31 d2                	xor    edx,edx
    7a0d12804c17:	39 fb                	cmp    ebx,edi
    7a0d12804c19:	40 0f 97 c5          	seta   bpl
    7a0d12804c1d:	0f 96 c1             	setbe  cl
    7a0d12804c20:	0f 93 c0             	setae  al
    7a0d12804c23:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    7a0d12804c2a:	0f 94 c2             	sete   dl
    7a0d12804c2d:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12804c34:	41 89 ad e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebp
    7a0d12804c3b:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    7a0d12804c42:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    7a0d12804c49:	72 50                	jb     0x7a0d12804c9b
    7a0d12804c4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7a0d12804c52:	92 01 01 00 
    7a0d12804c56:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804c5d:	83 c1 03             	add    ecx,0x3
    7a0d12804c60:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7a0d12804c67:	39 c1                	cmp    ecx,eax
    7a0d12804c69:	0f 83 5c 14 00 18    	jae    0x7a0d2a8060cb
    7a0d12804c6f:	41 81 b9 90 0c 08 00 	cmp    DWORD PTR [r9+0x80c90],0x10192
    7a0d12804c76:	92 01 01 00 
    7a0d12804c7a:	0f 85 4b 14 00 18    	jne    0x7a0d2a8060cb
    7a0d12804c80:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7a0d12804c87:	92 01 01 00 
    7a0d12804c8b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804c92:	49 8b 81 98 0c 08 00 	mov    rax,QWORD PTR [r9+0x80c98]
    7a0d12804c99:	ff e0                	jmp    rax
    7a0d12804c9b:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7a0d12804c9f:	41 8b 4d 34          	mov    ecx,DWORD PTR [r13+0x34]
    7a0d12804ca3:	41 0f af 45 10       	imul   eax,DWORD PTR [r13+0x10]
    7a0d12804ca8:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7a0d12804cac:	8d 3c 08             	lea    edi,[rax+rcx*1]
    7a0d12804caf:	41 89 7d 1c          	mov    DWORD PTR [r13+0x1c],edi
    7a0d12804cb3:	c1 e8 1f             	shr    eax,0x1f
    7a0d12804cb6:	c1 e9 1f             	shr    ecx,0x1f
    7a0d12804cb9:	89 fa                	mov    edx,edi
    7a0d12804cbb:	c1 ea 1f             	shr    edx,0x1f
    7a0d12804cbe:	31 d1                	xor    ecx,edx
    7a0d12804cc0:	31 d0                	xor    eax,edx
    7a0d12804cc2:	21 c8                	and    eax,ecx
    7a0d12804cc4:	09 c6                	or     esi,eax
    7a0d12804cc6:	31 c9                	xor    ecx,ecx
    7a0d12804cc8:	85 ff                	test   edi,edi
    7a0d12804cca:	0f 94 c1             	sete   cl
    7a0d12804ccd:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7a0d12804cd4:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7a0d12804cdb:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    7a0d12804ce2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12804ce9:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7a0d12804cf0:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7a0d12804cf7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d12804cfe:	00 00 00 
    7a0d12804d01:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d12804d08:	78 50                	js     0x7a0d12804d5a
    7a0d12804d0a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d12804d11:	70 01 01 00 
    7a0d12804d15:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804d1c:	83 c1 08             	add    ecx,0x8
    7a0d12804d1f:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7a0d12804d26:	39 c1                	cmp    ecx,eax
    7a0d12804d28:	0f 83 c9 13 00 18    	jae    0x7a0d2a8060f7
    7a0d12804d2e:	41 81 b9 80 0b 08 00 	cmp    DWORD PTR [r9+0x80b80],0x10170
    7a0d12804d35:	70 01 01 00 
    7a0d12804d39:	0f 85 b8 13 00 18    	jne    0x7a0d2a8060f7
    7a0d12804d3f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d12804d46:	70 01 01 00 
    7a0d12804d4a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804d51:	49 8b 81 88 0b 08 00 	mov    rax,QWORD PTR [r9+0x80b88]
    7a0d12804d58:	ff e0                	jmp    rax
    7a0d12804d5a:	31 c0                	xor    eax,eax
    7a0d12804d5c:	41 33 7d 00          	xor    edi,DWORD PTR [r13+0x0]
    7a0d12804d60:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    7a0d12804d64:	0f 94 c0             	sete   al
    7a0d12804d67:	c1 ef 1f             	shr    edi,0x1f
    7a0d12804d6a:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7a0d12804d71:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d12804d78:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12804d7f:	00 00 00 00 
    7a0d12804d83:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12804d8a:	00 00 00 00 
    7a0d12804d8e:	be 8c 01 01 00       	mov    esi,0x1018c
    7a0d12804d93:	bf 8c 01 01 00       	mov    edi,0x1018c
    7a0d12804d98:	41 81 fa 88 01 01 00 	cmp    r10d,0x10188
    7a0d12804d9f:	75 07                	jne    0x7a0d12804da8
    7a0d12804da1:	41 8b bd 90 00 00 00 	mov    edi,DWORD PTR [r13+0x90]
    7a0d12804da8:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    7a0d12804daf:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12804db6:	02 
    7a0d12804db7:	0f 43 f7             	cmovae esi,edi
    7a0d12804dba:	89 f7                	mov    edi,esi
    7a0d12804dbc:	41 81 f8 88 01 01 00 	cmp    r8d,0x10188
    7a0d12804dc3:	75 07                	jne    0x7a0d12804dcc
    7a0d12804dc5:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d12804dcc:	83 fa 02             	cmp    edx,0x2
    7a0d12804dcf:	0f 43 f7             	cmovae esi,edi
    7a0d12804dd2:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    7a0d12804dd9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12804de0:	10 01 01 00 
    7a0d12804de4:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804deb:	83 c1 0a             	add    ecx,0xa
    7a0d12804dee:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7a0d12804df5:	39 c1                	cmp    ecx,eax
    7a0d12804df7:	0f 83 26 13 00 18    	jae    0x7a0d2a806123
    7a0d12804dfd:	41 81 b9 80 08 08 00 	cmp    DWORD PTR [r9+0x80880],0x10110
    7a0d12804e04:	10 01 01 00 
    7a0d12804e08:	0f 85 15 13 00 18    	jne    0x7a0d2a806123
    7a0d12804e0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d12804e15:	10 01 01 00 
    7a0d12804e19:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804e20:	49 8b 81 88 08 08 00 	mov    rax,QWORD PTR [r9+0x80888]
    7a0d12804e27:	ff e0                	jmp    rax
