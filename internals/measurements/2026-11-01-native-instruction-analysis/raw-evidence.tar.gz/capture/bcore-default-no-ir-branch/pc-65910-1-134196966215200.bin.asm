
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65910-1-134196966215200.bin:     file format binary


Disassembly of section .data:

00007a0d2a804e20 <.data>:
    7a0d2a804e20:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a804e26:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a804e29:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a804e2f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a804e36:	0f 87 a5 ec ff e7    	ja     0x7a0d12803ae1
    7a0d2a804e3c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xc
    7a0d2a804e43:	0c 00 00 00 
    7a0d2a804e47:	e9 95 ec ff e7       	jmp    0x7a0d12803ae1
    7a0d2a804e4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10176
    7a0d2a804e53:	76 01 01 00 
    7a0d2a804e57:	b8 76 01 01 00       	mov    eax,0x10176
    7a0d2a804e5c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804e63:	02 00 00 00 
    7a0d2a804e67:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a804e6e:	01 00 00 00 
    7a0d2a804e72:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804e75:	be 76 01 01 00       	mov    esi,0x10176
    7a0d2a804e7a:	4c 89 ef             	mov    rdi,r13
    7a0d2a804e7d:	e8 de b2 ff e7       	call   0x7a0d12800160
    7a0d2a804e82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804e89:	00 
    7a0d2a804e8a:	0f 84 cb ec ff e7    	je     0x7a0d12803b5b
    7a0d2a804e90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804e97:	02 00 00 00 
    7a0d2a804e9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a804ea2:	01 00 00 00 
    7a0d2a804ea6:	58                   	pop    rax
    7a0d2a804ea7:	e9 59 f0 ff e7       	jmp    0x7a0d12803f05
    7a0d2a804eac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10178
    7a0d2a804eb3:	78 01 01 00 
    7a0d2a804eb7:	b8 78 01 01 00       	mov    eax,0x10178
    7a0d2a804ebc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804ec3:	02 00 00 00 
    7a0d2a804ec7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804ece:	02 00 00 00 
    7a0d2a804ed2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804ed5:	be 78 01 01 00       	mov    esi,0x10178
    7a0d2a804eda:	4c 89 ef             	mov    rdi,r13
    7a0d2a804edd:	e8 7e b2 ff e7       	call   0x7a0d12800160
    7a0d2a804ee2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804ee9:	00 
    7a0d2a804eea:	0f 84 d2 ec ff e7    	je     0x7a0d12803bc2
    7a0d2a804ef0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804ef7:	02 00 00 00 
    7a0d2a804efb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804f02:	02 00 00 00 
    7a0d2a804f06:	58                   	pop    rax
    7a0d2a804f07:	e9 f9 ef ff e7       	jmp    0x7a0d12803f05
    7a0d2a804f0c:	b8 7a 01 01 00       	mov    eax,0x1017a
    7a0d2a804f11:	83 c0 18             	add    eax,0x18
    7a0d2a804f14:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a804f1b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804f22:	02 00 00 00 
    7a0d2a804f26:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804f2d:	03 00 00 00 
    7a0d2a804f31:	be 7a 01 01 00       	mov    esi,0x1017a
    7a0d2a804f36:	ba 7a 01 01 00       	mov    edx,0x1017a
    7a0d2a804f3b:	4c 89 ef             	mov    rdi,r13
    7a0d2a804f3e:	e8 1d b2 ff e7       	call   0x7a0d12800160
    7a0d2a804f43:	e9 b0 ec ff e7       	jmp    0x7a0d12803bf8
    7a0d2a804f48:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017a
    7a0d2a804f4f:	7a 01 01 00 
    7a0d2a804f53:	b8 7a 01 01 00       	mov    eax,0x1017a
    7a0d2a804f58:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804f5f:	02 00 00 00 
    7a0d2a804f63:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804f6a:	03 00 00 00 
    7a0d2a804f6e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804f71:	be 7a 01 01 00       	mov    esi,0x1017a
    7a0d2a804f76:	4c 89 ef             	mov    rdi,r13
    7a0d2a804f79:	e8 e2 b1 ff e7       	call   0x7a0d12800160
    7a0d2a804f7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804f85:	00 
    7a0d2a804f86:	0f 84 b9 ec ff e7    	je     0x7a0d12803c45
    7a0d2a804f8c:	e9 76 ec ff e7       	jmp    0x7a0d12803c07
    7a0d2a804f91:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7a0d2a804f98:	7c 01 01 00 
    7a0d2a804f9c:	b8 7c 01 01 00       	mov    eax,0x1017c
    7a0d2a804fa1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804fa8:	02 00 00 00 
    7a0d2a804fac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a804fb3:	04 00 00 00 
    7a0d2a804fb7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804fba:	be 7c 01 01 00       	mov    esi,0x1017c
    7a0d2a804fbf:	4c 89 ef             	mov    rdi,r13
    7a0d2a804fc2:	e8 99 b1 ff e7       	call   0x7a0d12800160
    7a0d2a804fc7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804fce:	00 
    7a0d2a804fcf:	0f 84 a3 ec ff e7    	je     0x7a0d12803c78
    7a0d2a804fd5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804fdc:	02 00 00 00 
    7a0d2a804fe0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a804fe7:	04 00 00 00 
    7a0d2a804feb:	58                   	pop    rax
    7a0d2a804fec:	e9 14 ef ff e7       	jmp    0x7a0d12803f05
    7a0d2a804ff1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017e
    7a0d2a804ff8:	7e 01 01 00 
    7a0d2a804ffc:	b8 7e 01 01 00       	mov    eax,0x1017e
    7a0d2a805001:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805008:	02 00 00 00 
    7a0d2a80500c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805013:	05 00 00 00 
    7a0d2a805017:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80501a:	be 7e 01 01 00       	mov    esi,0x1017e
    7a0d2a80501f:	4c 89 ef             	mov    rdi,r13
    7a0d2a805022:	e8 39 b1 ff e7       	call   0x7a0d12800160
    7a0d2a805027:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80502e:	00 
    7a0d2a80502f:	0f 84 71 ec ff e7    	je     0x7a0d12803ca6
    7a0d2a805035:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80503c:	02 00 00 00 
    7a0d2a805040:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a805047:	05 00 00 00 
    7a0d2a80504b:	58                   	pop    rax
    7a0d2a80504c:	e9 b4 ee ff e7       	jmp    0x7a0d12803f05
    7a0d2a805051:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10180
    7a0d2a805058:	80 01 01 00 
    7a0d2a80505c:	b8 80 01 01 00       	mov    eax,0x10180
    7a0d2a805061:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805068:	02 00 00 00 
    7a0d2a80506c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a805073:	06 00 00 00 
    7a0d2a805077:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80507a:	be 80 01 01 00       	mov    esi,0x10180
    7a0d2a80507f:	4c 89 ef             	mov    rdi,r13
    7a0d2a805082:	e8 d9 b0 ff e7       	call   0x7a0d12800160
    7a0d2a805087:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80508e:	00 
    7a0d2a80508f:	0f 84 97 ec ff e7    	je     0x7a0d12803d2c
    7a0d2a805095:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80509c:	02 00 00 00 
    7a0d2a8050a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8050a7:	06 00 00 00 
    7a0d2a8050ab:	58                   	pop    rax
    7a0d2a8050ac:	e9 54 ee ff e7       	jmp    0x7a0d12803f05
    7a0d2a8050b1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10182
    7a0d2a8050b8:	82 01 01 00 
    7a0d2a8050bc:	b8 82 01 01 00       	mov    eax,0x10182
    7a0d2a8050c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8050c8:	02 00 00 00 
    7a0d2a8050cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8050d3:	07 00 00 00 
    7a0d2a8050d7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8050da:	be 82 01 01 00       	mov    esi,0x10182
    7a0d2a8050df:	4c 89 ef             	mov    rdi,r13
    7a0d2a8050e2:	e8 79 b0 ff e7       	call   0x7a0d12800160
    7a0d2a8050e7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8050ee:	00 
    7a0d2a8050ef:	0f 84 91 ec ff e7    	je     0x7a0d12803d86
    7a0d2a8050f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8050fc:	02 00 00 00 
    7a0d2a805100:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a805107:	07 00 00 00 
    7a0d2a80510b:	58                   	pop    rax
    7a0d2a80510c:	e9 f4 ed ff e7       	jmp    0x7a0d12803f05
    7a0d2a805111:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10184
    7a0d2a805118:	84 01 01 00 
    7a0d2a80511c:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d2a805121:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805128:	02 00 00 00 
    7a0d2a80512c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a805133:	08 00 00 00 
    7a0d2a805137:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80513a:	be 84 01 01 00       	mov    esi,0x10184
    7a0d2a80513f:	4c 89 ef             	mov    rdi,r13
    7a0d2a805142:	e8 19 b0 ff e7       	call   0x7a0d12800160
    7a0d2a805147:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80514e:	00 
    7a0d2a80514f:	0f 84 5f ec ff e7    	je     0x7a0d12803db4
    7a0d2a805155:	e9 99 ec ff e7       	jmp    0x7a0d12803df3
    7a0d2a80515a:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d2a80515f:	83 c0 ec             	add    eax,0xffffffec
    7a0d2a805162:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a805169:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a805170:	02 00 00 00 
    7a0d2a805174:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a80517b:	08 00 00 00 
    7a0d2a80517f:	be 84 01 01 00       	mov    esi,0x10184
    7a0d2a805184:	ba 84 01 01 00       	mov    edx,0x10184
    7a0d2a805189:	4c 89 ef             	mov    rdi,r13
    7a0d2a80518c:	e8 cf af ff e7       	call   0x7a0d12800160
    7a0d2a805191:	e9 4e ec ff e7       	jmp    0x7a0d12803de4
    7a0d2a805196:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10186
    7a0d2a80519d:	86 01 01 00 
    7a0d2a8051a1:	b8 86 01 01 00       	mov    eax,0x10186
    7a0d2a8051a6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8051ad:	02 00 00 00 
    7a0d2a8051b1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8051b8:	09 00 00 00 
    7a0d2a8051bc:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8051bf:	be 86 01 01 00       	mov    esi,0x10186
    7a0d2a8051c4:	4c 89 ef             	mov    rdi,r13
    7a0d2a8051c7:	e8 94 af ff e7       	call   0x7a0d12800160
    7a0d2a8051cc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8051d3:	00 
    7a0d2a8051d4:	0f 84 92 ec ff e7    	je     0x7a0d12803e6c
    7a0d2a8051da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8051e1:	02 00 00 00 
    7a0d2a8051e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8051ec:	09 00 00 00 
    7a0d2a8051f0:	58                   	pop    rax
    7a0d2a8051f1:	e9 0f ed ff e7       	jmp    0x7a0d12803f05
    7a0d2a8051f6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d2a8051fd:	10 01 01 00 
    7a0d2a805201:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a805208:	04 00 00 00 
    7a0d2a80520c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a805213:	0a 00 00 00 
    7a0d2a805217:	be 88 01 01 00       	mov    esi,0x10188
    7a0d2a80521c:	ba 88 01 01 00       	mov    edx,0x10188
    7a0d2a805221:	4c 89 ef             	mov    rdi,r13
    7a0d2a805224:	e8 37 af ff e7       	call   0x7a0d12800160
    7a0d2a805229:	e9 b5 ec ff e7       	jmp    0x7a0d12803ee3
    7a0d2a80522e:	c2 08 00             	ret    0x8
