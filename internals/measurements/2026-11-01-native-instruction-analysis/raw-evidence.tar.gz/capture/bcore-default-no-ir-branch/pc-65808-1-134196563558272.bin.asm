
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65808-1-134196563558272.bin:     file format binary


Disassembly of section .data:

00007a0d12803f80 <.data>:
    7a0d12803f80:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803f87:	8b 88 34 00 10 00    	mov    ecx,DWORD PTR [rax+0x100034]
    7a0d12803f8d:	ff c1                	inc    ecx
    7a0d12803f8f:	89 88 34 00 10 00    	mov    DWORD PTR [rax+0x100034],ecx
    7a0d12803f95:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d12803f9b:	0f 84 9f 12 00 18    	je     0x7a0d2a805240
    7a0d12803fa1:	50                   	push   rax
    7a0d12803fa2:	41 8b 85 00 00 00 00 	mov    eax,DWORD PTR [r13+0x0]
    7a0d12803fa9:	89 c1                	mov    ecx,eax
    7a0d12803fab:	c1 e9 07             	shr    ecx,0x7
    7a0d12803fae:	41 89 8d 04 00 00 00 	mov    DWORD PTR [r13+0x4],ecx
    7a0d12803fb5:	31 c9                	xor    ecx,ecx
    7a0d12803fb7:	3d 80 00 00 00       	cmp    eax,0x80
    7a0d12803fbc:	0f 92 c1             	setb   cl
    7a0d12803fbf:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7a0d12803fc6:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    7a0d12803fcd:	00 00 00 00 
    7a0d12803fd1:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12803fd8:	00 00 00 00 
    7a0d12803fdc:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10110
    7a0d12803fe3:	10 01 01 00 
    7a0d12803fe7:	0f 84 7f 12 00 18    	je     0x7a0d2a80526c
    7a0d12803fed:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10110
    7a0d12803ff4:	10 01 01 00 
    7a0d12803ff8:	0f 84 6e 12 00 18    	je     0x7a0d2a80526c
    7a0d12803ffe:	58                   	pop    rax
    7a0d12803fff:	50                   	push   rax
    7a0d12804000:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12804004:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d1280400b:	31 d2                	xor    edx,edx
    7a0d1280400d:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    7a0d12804011:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d12804015:	0f 94 c2             	sete   dl
    7a0d12804018:	c1 e8 1f             	shr    eax,0x1f
    7a0d1280401b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12804022:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12804029:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12804030:	00 00 00 00 
    7a0d12804034:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d1280403b:	00 00 00 00 
    7a0d1280403f:	81 f9 14 01 01 00    	cmp    ecx,0x10114
    7a0d12804045:	0f 84 81 12 00 18    	je     0x7a0d2a8052cc
    7a0d1280404b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10114
    7a0d12804052:	14 01 01 00 
    7a0d12804056:	0f 84 70 12 00 18    	je     0x7a0d2a8052cc
    7a0d1280405c:	58                   	pop    rax
    7a0d1280405d:	50                   	push   rax
    7a0d1280405e:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d12804062:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12804069:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d1280406d:	81 f9 16 01 01 00    	cmp    ecx,0x10116
    7a0d12804073:	0f 84 b3 12 00 18    	je     0x7a0d2a80532c
    7a0d12804079:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10116
    7a0d12804080:	16 01 01 00 
    7a0d12804084:	0f 84 a2 12 00 18    	je     0x7a0d2a80532c
    7a0d1280408a:	58                   	pop    rax
    7a0d1280408b:	50                   	push   rax
    7a0d1280408c:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    7a0d12804091:	b9 00 00 37 9e       	mov    ecx,0x9e370000
    7a0d12804096:	09 c1                	or     ecx,eax
    7a0d12804098:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7a0d1280409c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10118
    7a0d128040a3:	18 01 01 00 
    7a0d128040a7:	0f 84 df 12 00 18    	je     0x7a0d2a80538c
    7a0d128040ad:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10118
    7a0d128040b4:	18 01 01 00 
    7a0d128040b8:	0f 84 ce 12 00 18    	je     0x7a0d2a80538c
    7a0d128040be:	58                   	pop    rax
    7a0d128040bf:	50                   	push   rax
    7a0d128040c0:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    7a0d128040c5:	c1 e0 10             	shl    eax,0x10
    7a0d128040c8:	b9 b9 79 00 00       	mov    ecx,0x79b9
    7a0d128040cd:	09 c1                	or     ecx,eax
    7a0d128040cf:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7a0d128040d3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1011c
    7a0d128040da:	1c 01 01 00 
    7a0d128040de:	0f 84 08 13 00 18    	je     0x7a0d2a8053ec
    7a0d128040e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1011c
    7a0d128040eb:	1c 01 01 00 
    7a0d128040ef:	0f 84 f7 12 00 18    	je     0x7a0d2a8053ec
    7a0d128040f5:	58                   	pop    rax
    7a0d128040f6:	50                   	push   rax
    7a0d128040f7:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d128040fb:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d128040fe:	f6 c3 03             	test   bl,0x3
    7a0d12804101:	0f 85 45 13 00 18    	jne    0x7a0d2a80544c
    7a0d12804107:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d1280410e:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12804115:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d12804119:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d12804120:	89 c8                	mov    eax,ecx
    7a0d12804122:	c1 e8 0c             	shr    eax,0xc
    7a0d12804125:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280412a:	48 85 c0             	test   rax,rax
    7a0d1280412d:	0f 84 6c 13 00 18    	je     0x7a0d2a80549f
    7a0d12804133:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12804139:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d1280413c:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d1280413f:	89 d8                	mov    eax,ebx
    7a0d12804141:	c1 e8 0c             	shr    eax,0xc
    7a0d12804144:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12804149:	48 85 c0             	test   rax,rax
    7a0d1280414c:	0f 84 88 13 00 18    	je     0x7a0d2a8054da
    7a0d12804152:	89 d9                	mov    ecx,ebx
    7a0d12804154:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280415a:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d1280415e:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d12804162:	b8 00 00 00 00       	mov    eax,0x0
    7a0d12804167:	29 c3                	sub    ebx,eax
    7a0d12804169:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d1280416d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10120
    7a0d12804174:	20 01 01 00 
    7a0d12804178:	0f 84 9d 13 00 18    	je     0x7a0d2a80551b
    7a0d1280417e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10120
    7a0d12804185:	20 01 01 00 
    7a0d12804189:	0f 84 8c 13 00 18    	je     0x7a0d2a80551b
    7a0d1280418f:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12804193:	0f 85 c4 13 00 18    	jne    0x7a0d2a80555d
    7a0d12804199:	58                   	pop    rax
    7a0d1280419a:	e9 0f 00 00 00       	jmp    0x7a0d128041ae
    7a0d1280419f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128041a6:	00 
    7a0d128041a7:	74 f0                	je     0x7a0d12804199
    7a0d128041a9:	e9 d5 12 00 18       	jmp    0x7a0d2a805483
    7a0d128041ae:	50                   	push   rax
    7a0d128041af:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d128041b3:	f6 c3 03             	test   bl,0x3
    7a0d128041b6:	0f 85 d3 13 00 18    	jne    0x7a0d2a80558f
    7a0d128041bc:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d128041c3:	48 89 d8             	mov    rax,rbx
    7a0d128041c6:	48 c1 e8 0c          	shr    rax,0xc
    7a0d128041ca:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128041cf:	48 85 c0             	test   rax,rax
    7a0d128041d2:	0f 84 09 14 00 18    	je     0x7a0d2a8055e1
    7a0d128041d8:	89 d9                	mov    ecx,ebx
    7a0d128041da:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128041e0:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d128041e4:	89 de                	mov    esi,ebx
    7a0d128041e6:	83 c6 04             	add    esi,0x4
    7a0d128041e9:	89 f0                	mov    eax,esi
    7a0d128041eb:	c1 e8 0c             	shr    eax,0xc
    7a0d128041ee:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128041f3:	48 85 c0             	test   rax,rax
    7a0d128041f6:	0f 84 22 14 00 18    	je     0x7a0d2a80561e
    7a0d128041fc:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12804202:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12804205:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d12804208:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d1280420c:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12804213:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d12804217:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10124
    7a0d1280421e:	24 01 01 00 
    7a0d12804222:	0f 84 32 14 00 18    	je     0x7a0d2a80565a
    7a0d12804228:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10124
    7a0d1280422f:	24 01 01 00 
    7a0d12804233:	0f 84 21 14 00 18    	je     0x7a0d2a80565a
    7a0d12804239:	58                   	pop    rax
    7a0d1280423a:	50                   	push   rax
    7a0d1280423b:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    7a0d1280423f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12804246:	8d 04 40             	lea    eax,[rax+rax*2]
    7a0d12804249:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d1280424d:	81 f9 28 01 01 00    	cmp    ecx,0x10128
    7a0d12804253:	0f 84 4a 14 00 18    	je     0x7a0d2a8056a3
    7a0d12804259:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10128
    7a0d12804260:	28 01 01 00 
    7a0d12804264:	0f 84 39 14 00 18    	je     0x7a0d2a8056a3
    7a0d1280426a:	58                   	pop    rax
    7a0d1280426b:	50                   	push   rax
    7a0d1280426c:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    7a0d12804270:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12804277:	41 01 45 24          	add    DWORD PTR [r13+0x24],eax
    7a0d1280427b:	81 f9 2a 01 01 00    	cmp    ecx,0x1012a
    7a0d12804281:	0f 84 7c 14 00 18    	je     0x7a0d2a805703
    7a0d12804287:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1012a
    7a0d1280428e:	2a 01 01 00 
    7a0d12804292:	0f 84 6b 14 00 18    	je     0x7a0d2a805703
    7a0d12804298:	58                   	pop    rax
    7a0d12804299:	50                   	push   rax
    7a0d1280429a:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    7a0d1280429e:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128042a5:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d128042a9:	81 f9 2c 01 01 00    	cmp    ecx,0x1012c
    7a0d128042af:	0f 84 ae 14 00 18    	je     0x7a0d2a805763
    7a0d128042b5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1012c
    7a0d128042bc:	2c 01 01 00 
    7a0d128042c0:	0f 84 9d 14 00 18    	je     0x7a0d2a805763
    7a0d128042c6:	58                   	pop    rax
    7a0d128042c7:	50                   	push   rax
    7a0d128042c8:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d128042cf:	a8 01                	test   al,0x1
    7a0d128042d1:	0f 85 ec 14 00 18    	jne    0x7a0d2a8057c3
    7a0d128042d7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128042de:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128042e5:	01 
    7a0d128042e6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1012e
    7a0d128042ed:	2e 01 01 00 
    7a0d128042f1:	0f 84 02 15 00 18    	je     0x7a0d2a8057f9
    7a0d128042f7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1012e
    7a0d128042fe:	2e 01 01 00 
    7a0d12804302:	0f 84 f1 14 00 18    	je     0x7a0d2a8057f9
    7a0d12804308:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280430f:	02 00 00 00 
    7a0d12804313:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d1280431a:	0b 00 00 00 
    7a0d1280431e:	58                   	pop    rax
    7a0d1280431f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12804326:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d1280432d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804334:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280433b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12804342:	39 f1                	cmp    ecx,esi
    7a0d12804344:	0f 83 dc 14 00 18    	jae    0x7a0d2a805826
    7a0d1280434a:	81 fa 10 01 01 00    	cmp    edx,0x10110
    7a0d12804350:	75 14                	jne    0x7a0d12804366
    7a0d12804352:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804359:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12804360:	00 
    7a0d12804361:	e9 1a fc ff ff       	jmp    0x7a0d12803f80
    7a0d12804366:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d1280436d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12804373:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12804376:	0f 85 aa 14 00 18    	jne    0x7a0d2a805826
    7a0d1280437c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804383:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d1280438a:	00 
    7a0d1280438b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12804390:	ff e0                	jmp    rax
