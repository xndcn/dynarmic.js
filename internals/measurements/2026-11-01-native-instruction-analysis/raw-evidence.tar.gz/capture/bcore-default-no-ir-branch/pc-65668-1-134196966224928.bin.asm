
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65668-1-134196966224928.bin:     file format binary


Disassembly of section .data:

00007a0d2a807420 <.data>:
    7a0d2a807420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7a0d2a807427:	84 00 01 00 
    7a0d2a80742b:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a807432:	01 
    7a0d2a807433:	c2 08 00             	ret    0x8
    7a0d2a807436:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a80743c:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a80743f:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a807445:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a80744c:	0f 87 98 e8 ff e7    	ja     0x7a0d12805cea
    7a0d2a807452:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x10
    7a0d2a807459:	10 00 00 00 
    7a0d2a80745d:	e9 88 e8 ff e7       	jmp    0x7a0d12805cea
    7a0d2a807462:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7a0d2a807469:	84 00 01 00 
    7a0d2a80746d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a807474:	08 00 00 00 
    7a0d2a807478:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80747f:	01 00 00 00 
    7a0d2a807483:	ba 84 00 01 00       	mov    edx,0x10084
    7a0d2a807488:	4c 89 ef             	mov    rdi,r13
    7a0d2a80748b:	4c 89 f6             	mov    rsi,r14
    7a0d2a80748e:	45 31 c0             	xor    r8d,r8d
    7a0d2a807491:	e8 ea 8b ff e7       	call   0x7a0d12800080
    7a0d2a807496:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a80749d:	08 00 00 00 
    7a0d2a8074a1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8074a8:	01 00 00 00 
    7a0d2a8074ac:	58                   	pop    rax
    7a0d2a8074ad:	e9 7c e9 ff e7       	jmp    0x7a0d12805e2e
    7a0d2a8074b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7a0d2a8074b9:	84 00 01 00 
    7a0d2a8074bd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    7a0d2a8074c4:	08 00 00 00 
    7a0d2a8074c8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8074cf:	01 00 00 00 
    7a0d2a8074d3:	4c 89 f7             	mov    rdi,r14
    7a0d2a8074d6:	89 ce                	mov    esi,ecx
    7a0d2a8074d8:	e8 63 8b ff e7       	call   0x7a0d12800040
    7a0d2a8074dd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8074e4:	00 
    7a0d2a8074e5:	0f 84 31 e8 ff e7    	je     0x7a0d12805d1c
    7a0d2a8074eb:	eb a9                	jmp    0x7a0d2a807496
    7a0d2a8074ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a8074f4:	8c 00 01 00 
    7a0d2a8074f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8074ff:	02 00 00 00 
    7a0d2a807503:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80750a:	02 00 00 00 
    7a0d2a80750e:	ba 8c 00 01 00       	mov    edx,0x1008c
    7a0d2a807513:	4c 89 ef             	mov    rdi,r13
    7a0d2a807516:	4c 89 f6             	mov    rsi,r14
    7a0d2a807519:	45 31 c0             	xor    r8d,r8d
    7a0d2a80751c:	e8 5f 8b ff e7       	call   0x7a0d12800080
    7a0d2a807521:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807528:	02 00 00 00 
    7a0d2a80752c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a807533:	02 00 00 00 
    7a0d2a807537:	58                   	pop    rax
    7a0d2a807538:	e9 f1 e8 ff e7       	jmp    0x7a0d12805e2e
    7a0d2a80753d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a807544:	8c 00 01 00 
    7a0d2a807548:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80754f:	02 00 00 00 
    7a0d2a807553:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80755a:	02 00 00 00 
    7a0d2a80755e:	4c 89 f7             	mov    rdi,r14
    7a0d2a807561:	89 ce                	mov    esi,ecx
    7a0d2a807563:	e8 d8 8a ff e7       	call   0x7a0d12800040
    7a0d2a807568:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80756f:	00 
    7a0d2a807570:	0f 84 f9 e7 ff e7    	je     0x7a0d12805d6f
    7a0d2a807576:	eb a9                	jmp    0x7a0d2a807521
    7a0d2a807578:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    7a0d2a80757f:	8c 00 01 00 
    7a0d2a807583:	b8 8c 00 01 00       	mov    eax,0x1008c
    7a0d2a807588:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80758f:	02 00 00 00 
    7a0d2a807593:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80759a:	02 00 00 00 
    7a0d2a80759e:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8075a1:	be 8c 00 01 00       	mov    esi,0x1008c
    7a0d2a8075a6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8075a9:	e8 b2 8b ff e7       	call   0x7a0d12800160
    7a0d2a8075ae:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8075b5:	00 
    7a0d2a8075b6:	0f 84 d9 e7 ff e7    	je     0x7a0d12805d95
    7a0d2a8075bc:	e9 60 ff ff ff       	jmp    0x7a0d2a807521
    7a0d2a8075c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d2a8075c8:	28 03 01 00 
    7a0d2a8075cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8075d3:	04 00 00 00 
    7a0d2a8075d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8075de:	03 00 00 00 
    7a0d2a8075e2:	be 8e 00 01 00       	mov    esi,0x1008e
    7a0d2a8075e7:	ba 8e 00 01 00       	mov    edx,0x1008e
    7a0d2a8075ec:	4c 89 ef             	mov    rdi,r13
    7a0d2a8075ef:	e8 6c 8b ff e7       	call   0x7a0d12800160
    7a0d2a8075f4:	e9 13 e8 ff e7       	jmp    0x7a0d12805e0c
    7a0d2a8075f9:	c2 08 00             	ret    0x8
