
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66600-1-134196966207664.bin:     file format binary


Disassembly of section .data:

00007a0d2a8030b0 <.data>:
    7a0d2a8030b0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a8030b6:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a8030b9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a8030bf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a8030c6:	0f 87 d5 f2 ff e7    	ja     0x7a0d128023a1
    7a0d2a8030cc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x5
    7a0d2a8030d3:	05 00 00 00 
    7a0d2a8030d7:	e9 c5 f2 ff e7       	jmp    0x7a0d128023a1
    7a0d2a8030dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7a0d2a8030e3:	28 04 01 00 
    7a0d2a8030e7:	b8 28 04 01 00       	mov    eax,0x10428
    7a0d2a8030ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8030f3:	04 00 00 00 
    7a0d2a8030f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8030fe:	01 00 00 00 
    7a0d2a803102:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803105:	be 28 04 01 00       	mov    esi,0x10428
    7a0d2a80310a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80310d:	e8 4e d0 ff e7       	call   0x7a0d12800160
    7a0d2a803112:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803119:	00 
    7a0d2a80311a:	0f 84 b4 f2 ff e7    	je     0x7a0d128023d4
    7a0d2a803120:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803127:	04 00 00 00 
    7a0d2a80312b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803132:	01 00 00 00 
    7a0d2a803136:	58                   	pop    rax
    7a0d2a803137:	e9 ab f5 ff e7       	jmp    0x7a0d128026e7
    7a0d2a80313c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    7a0d2a803143:	2c 04 01 00 
    7a0d2a803147:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80314e:	04 00 00 00 
    7a0d2a803152:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a803159:	02 00 00 00 
    7a0d2a80315d:	ba 2c 04 01 00       	mov    edx,0x1042c
    7a0d2a803162:	4c 89 ef             	mov    rdi,r13
    7a0d2a803165:	4c 89 f6             	mov    rsi,r14
    7a0d2a803168:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80316e:	e8 0d cf ff e7       	call   0x7a0d12800080
    7a0d2a803173:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80317a:	04 00 00 00 
    7a0d2a80317e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a803185:	02 00 00 00 
    7a0d2a803189:	58                   	pop    rax
    7a0d2a80318a:	e9 58 f5 ff e7       	jmp    0x7a0d128026e7
    7a0d2a80318f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    7a0d2a803196:	2c 04 01 00 
    7a0d2a80319a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8031a1:	04 00 00 00 
    7a0d2a8031a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8031ac:	02 00 00 00 
    7a0d2a8031b0:	4c 89 f7             	mov    rdi,r14
    7a0d2a8031b3:	89 ce                	mov    esi,ecx
    7a0d2a8031b5:	e8 b6 ce ff e7       	call   0x7a0d12800070
    7a0d2a8031ba:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8031c1:	00 
    7a0d2a8031c2:	0f 84 53 f2 ff e7    	je     0x7a0d1280241b
    7a0d2a8031c8:	eb a9                	jmp    0x7a0d2a803173
    7a0d2a8031ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    7a0d2a8031d1:	2c 04 01 00 
    7a0d2a8031d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8031dc:	04 00 00 00 
    7a0d2a8031e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8031e7:	02 00 00 00 
    7a0d2a8031eb:	4c 89 f7             	mov    rdi,r14
    7a0d2a8031ee:	89 de                	mov    esi,ebx
    7a0d2a8031f0:	44 89 e2             	mov    edx,r12d
    7a0d2a8031f3:	e8 78 ce ff e7       	call   0x7a0d12800070
    7a0d2a8031f8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8031ff:	00 
    7a0d2a803200:	0f 84 37 f2 ff e7    	je     0x7a0d1280243d
    7a0d2a803206:	e9 68 ff ff ff       	jmp    0x7a0d2a803173
    7a0d2a80320b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    7a0d2a803212:	2c 04 01 00 
    7a0d2a803216:	b8 2c 04 01 00       	mov    eax,0x1042c
    7a0d2a80321b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803222:	04 00 00 00 
    7a0d2a803226:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80322d:	02 00 00 00 
    7a0d2a803231:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803234:	be 2c 04 01 00       	mov    esi,0x1042c
    7a0d2a803239:	4c 89 ef             	mov    rdi,r13
    7a0d2a80323c:	e8 1f cf ff e7       	call   0x7a0d12800160
    7a0d2a803241:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a803245:	0f 84 33 f2 ff e7    	je     0x7a0d1280247e
    7a0d2a80324b:	eb 0f                	jmp    0x7a0d2a80325c
    7a0d2a80324d:	b8 2c 04 01 00       	mov    eax,0x1042c
    7a0d2a803252:	83 c0 04             	add    eax,0x4
    7a0d2a803255:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80325c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803263:	04 00 00 00 
    7a0d2a803267:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80326e:	02 00 00 00 
    7a0d2a803272:	4c 89 ef             	mov    rdi,r13
    7a0d2a803275:	e8 d6 ce ff e7       	call   0x7a0d12800150
    7a0d2a80327a:	e9 ff f1 ff e7       	jmp    0x7a0d1280247e
    7a0d2a80327f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    7a0d2a803286:	30 04 01 00 
    7a0d2a80328a:	b8 30 04 01 00       	mov    eax,0x10430
    7a0d2a80328f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803296:	04 00 00 00 
    7a0d2a80329a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8032a1:	03 00 00 00 
    7a0d2a8032a5:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8032a8:	be 30 04 01 00       	mov    esi,0x10430
    7a0d2a8032ad:	4c 89 ef             	mov    rdi,r13
    7a0d2a8032b0:	e8 ab ce ff e7       	call   0x7a0d12800160
    7a0d2a8032b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8032bc:	00 
    7a0d2a8032bd:	0f 84 00 f2 ff e7    	je     0x7a0d128024c3
    7a0d2a8032c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8032ca:	04 00 00 00 
    7a0d2a8032ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8032d5:	03 00 00 00 
    7a0d2a8032d9:	58                   	pop    rax
    7a0d2a8032da:	e9 08 f4 ff e7       	jmp    0x7a0d128026e7
    7a0d2a8032df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    7a0d2a8032e6:	34 04 01 00 
    7a0d2a8032ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8032f1:	02 00 00 00 
    7a0d2a8032f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8032fc:	04 00 00 00 
    7a0d2a803300:	ba 34 04 01 00       	mov    edx,0x10434
    7a0d2a803305:	4c 89 ef             	mov    rdi,r13
    7a0d2a803308:	4c 89 f6             	mov    rsi,r14
    7a0d2a80330b:	45 31 c0             	xor    r8d,r8d
    7a0d2a80330e:	e8 6d cd ff e7       	call   0x7a0d12800080
    7a0d2a803313:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80331a:	02 00 00 00 
    7a0d2a80331e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803325:	04 00 00 00 
    7a0d2a803329:	58                   	pop    rax
    7a0d2a80332a:	e9 b8 f3 ff e7       	jmp    0x7a0d128026e7
    7a0d2a80332f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    7a0d2a803336:	34 04 01 00 
    7a0d2a80333a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803341:	02 00 00 00 
    7a0d2a803345:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80334c:	04 00 00 00 
    7a0d2a803350:	4c 89 f7             	mov    rdi,r14
    7a0d2a803353:	89 ce                	mov    esi,ecx
    7a0d2a803355:	e8 e6 cc ff e7       	call   0x7a0d12800040
    7a0d2a80335a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803361:	00 
    7a0d2a803362:	0f 84 8e f1 ff e7    	je     0x7a0d128024f6
    7a0d2a803368:	eb a9                	jmp    0x7a0d2a803313
    7a0d2a80336a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    7a0d2a803371:	34 04 01 00 
    7a0d2a803375:	b8 34 04 01 00       	mov    eax,0x10434
    7a0d2a80337a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803381:	02 00 00 00 
    7a0d2a803385:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80338c:	04 00 00 00 
    7a0d2a803390:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803393:	be 34 04 01 00       	mov    esi,0x10434
    7a0d2a803398:	4c 89 ef             	mov    rdi,r13
    7a0d2a80339b:	e8 c0 cd ff e7       	call   0x7a0d12800160
    7a0d2a8033a0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8033a7:	00 
    7a0d2a8033a8:	0f 84 6e f1 ff e7    	je     0x7a0d1280251c
    7a0d2a8033ae:	e9 60 ff ff ff       	jmp    0x7a0d2a803313
    7a0d2a8033b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10436
    7a0d2a8033ba:	36 04 01 00 
    7a0d2a8033be:	b8 36 04 01 00       	mov    eax,0x10436
    7a0d2a8033c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8033ca:	02 00 00 00 
    7a0d2a8033ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8033d5:	05 00 00 00 
    7a0d2a8033d9:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8033dc:	be 36 04 01 00       	mov    esi,0x10436
    7a0d2a8033e1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8033e4:	e8 77 cd ff e7       	call   0x7a0d12800160
    7a0d2a8033e9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8033f0:	00 
    7a0d2a8033f1:	0f 84 5c f1 ff e7    	je     0x7a0d12802553
    7a0d2a8033f7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8033fe:	02 00 00 00 
    7a0d2a803402:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a803409:	05 00 00 00 
    7a0d2a80340d:	58                   	pop    rax
    7a0d2a80340e:	e9 d4 f2 ff e7       	jmp    0x7a0d128026e7
    7a0d2a803413:	b8 38 04 01 00       	mov    eax,0x10438
    7a0d2a803418:	83 c0 0a             	add    eax,0xa
    7a0d2a80341b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a803422:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803429:	02 00 00 00 
    7a0d2a80342d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803434:	06 00 00 00 
    7a0d2a803438:	be 38 04 01 00       	mov    esi,0x10438
    7a0d2a80343d:	ba 38 04 01 00       	mov    edx,0x10438
    7a0d2a803442:	4c 89 ef             	mov    rdi,r13
    7a0d2a803445:	e8 16 cd ff e7       	call   0x7a0d12800160
    7a0d2a80344a:	e9 3a f1 ff e7       	jmp    0x7a0d12802589
    7a0d2a80344f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10438
    7a0d2a803456:	38 04 01 00 
    7a0d2a80345a:	b8 38 04 01 00       	mov    eax,0x10438
    7a0d2a80345f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803466:	02 00 00 00 
    7a0d2a80346a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803471:	06 00 00 00 
    7a0d2a803475:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803478:	be 38 04 01 00       	mov    esi,0x10438
    7a0d2a80347d:	4c 89 ef             	mov    rdi,r13
    7a0d2a803480:	e8 db cc ff e7       	call   0x7a0d12800160
    7a0d2a803485:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80348c:	00 
    7a0d2a80348d:	0f 84 43 f1 ff e7    	je     0x7a0d128025d6
    7a0d2a803493:	e9 00 f1 ff e7       	jmp    0x7a0d12802598
    7a0d2a803498:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043a
    7a0d2a80349f:	3a 04 01 00 
    7a0d2a8034a3:	b8 3a 04 01 00       	mov    eax,0x1043a
    7a0d2a8034a8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8034af:	02 00 00 00 
    7a0d2a8034b3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8034ba:	07 00 00 00 
    7a0d2a8034be:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8034c1:	be 3a 04 01 00       	mov    esi,0x1043a
    7a0d2a8034c6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8034c9:	e8 92 cc ff e7       	call   0x7a0d12800160
    7a0d2a8034ce:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8034d5:	00 
    7a0d2a8034d6:	0f 84 26 f1 ff e7    	je     0x7a0d12802602
    7a0d2a8034dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8034e3:	02 00 00 00 
    7a0d2a8034e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8034ee:	07 00 00 00 
    7a0d2a8034f2:	58                   	pop    rax
    7a0d2a8034f3:	e9 ef f1 ff e7       	jmp    0x7a0d128026e7
    7a0d2a8034f8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    7a0d2a8034ff:	3c 04 01 00 
    7a0d2a803503:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80350a:	04 00 00 00 
    7a0d2a80350e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a803515:	08 00 00 00 
    7a0d2a803519:	ba 3c 04 01 00       	mov    edx,0x1043c
    7a0d2a80351e:	4c 89 ef             	mov    rdi,r13
    7a0d2a803521:	4c 89 f6             	mov    rsi,r14
    7a0d2a803524:	89 d9                	mov    ecx,ebx
    7a0d2a803526:	45 31 c0             	xor    r8d,r8d
    7a0d2a803529:	e8 52 cb ff e7       	call   0x7a0d12800080
    7a0d2a80352e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803535:	04 00 00 00 
    7a0d2a803539:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a803540:	08 00 00 00 
    7a0d2a803544:	58                   	pop    rax
    7a0d2a803545:	e9 9d f1 ff e7       	jmp    0x7a0d128026e7
    7a0d2a80354a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    7a0d2a803551:	3c 04 01 00 
    7a0d2a803555:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80355c:	04 00 00 00 
    7a0d2a803560:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a803567:	08 00 00 00 
    7a0d2a80356b:	4c 89 f7             	mov    rdi,r14
    7a0d2a80356e:	89 de                	mov    esi,ebx
    7a0d2a803570:	e8 cb ca ff e7       	call   0x7a0d12800040
    7a0d2a803575:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80357c:	00 
    7a0d2a80357d:	75 af                	jne    0x7a0d2a80352e
    7a0d2a80357f:	41 89 c7             	mov    r15d,eax
    7a0d2a803582:	e9 b2 f0 ff e7       	jmp    0x7a0d12802639
    7a0d2a803587:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    7a0d2a80358e:	3c 04 01 00 
    7a0d2a803592:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803599:	04 00 00 00 
    7a0d2a80359d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8035a4:	08 00 00 00 
    7a0d2a8035a8:	4c 89 f7             	mov    rdi,r14
    7a0d2a8035ab:	e8 90 ca ff e7       	call   0x7a0d12800040
    7a0d2a8035b0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8035b7:	00 
    7a0d2a8035b8:	0f 84 9c f0 ff e7    	je     0x7a0d1280265a
    7a0d2a8035be:	e9 6b ff ff ff       	jmp    0x7a0d2a80352e
    7a0d2a8035c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    7a0d2a8035ca:	3c 04 01 00 
    7a0d2a8035ce:	b8 3c 04 01 00       	mov    eax,0x1043c
    7a0d2a8035d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8035da:	04 00 00 00 
    7a0d2a8035de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a8035e5:	08 00 00 00 
    7a0d2a8035e9:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8035ec:	be 3c 04 01 00       	mov    esi,0x1043c
    7a0d2a8035f1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8035f4:	e8 67 cb ff e7       	call   0x7a0d12800160
    7a0d2a8035f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803600:	00 
    7a0d2a803601:	0f 84 87 f0 ff e7    	je     0x7a0d1280268e
    7a0d2a803607:	e9 22 ff ff ff       	jmp    0x7a0d2a80352e
    7a0d2a80360c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    7a0d2a803613:	40 04 01 00 
    7a0d2a803617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80361e:	02 00 00 00 
    7a0d2a803622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a803629:	09 00 00 00 
    7a0d2a80362d:	4c 89 ef             	mov    rdi,r13
    7a0d2a803630:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a803635:	4c 89 f2             	mov    rdx,r14
    7a0d2a803638:	e8 53 ca ff e7       	call   0x7a0d12800090
    7a0d2a80363d:	e9 8e f0 ff e7       	jmp    0x7a0d128026d0
    7a0d2a803642:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803649:	02 00 00 00 
    7a0d2a80364d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a803654:	09 00 00 00 
    7a0d2a803658:	be 40 04 01 00       	mov    esi,0x10440
    7a0d2a80365d:	ba 40 04 01 00       	mov    edx,0x10440
    7a0d2a803662:	4c 89 ef             	mov    rdi,r13
    7a0d2a803665:	e8 f6 ca ff e7       	call   0x7a0d12800160
    7a0d2a80366a:	e9 61 f0 ff e7       	jmp    0x7a0d128026d0
    7a0d2a80366f:	c2 08 00             	ret    0x8
