
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65668-1-134196563565696.bin:     file format binary


Disassembly of section .data:

00007a0d12805c80 <.data>:
    7a0d12805c80:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12805c87:	3d 00 00 00 00       	cmp    eax,0x0
    7a0d12805c8c:	0f 95 c2             	setne  dl
    7a0d12805c8f:	b9 84 00 01 00       	mov    ecx,0x10084
    7a0d12805c94:	29 c8                	sub    eax,ecx
    7a0d12805c96:	3d 0a 00 00 00       	cmp    eax,0xa
    7a0d12805c9b:	0f 96 c3             	setbe  bl
    7a0d12805c9e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    7a0d12805ca5:	81 fe 00 00 00 00    	cmp    esi,0x0
    7a0d12805cab:	0f 94 c0             	sete   al
    7a0d12805cae:	29 ce                	sub    esi,ecx
    7a0d12805cb0:	81 fe 0a 00 00 00    	cmp    esi,0xa
    7a0d12805cb6:	0f 97 c1             	seta   cl
    7a0d12805cb9:	84 da                	test   dl,bl
    7a0d12805cbb:	0f 85 5f 17 00 18    	jne    0x7a0d2a807420
    7a0d12805cc1:	08 c8                	or     al,cl
    7a0d12805cc3:	0f 84 57 17 00 18    	je     0x7a0d2a807420
    7a0d12805cc9:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12805cd0:	8b 88 40 00 10 00    	mov    ecx,DWORD PTR [rax+0x100040]
    7a0d12805cd6:	ff c1                	inc    ecx
    7a0d12805cd8:	89 88 40 00 10 00    	mov    DWORD PTR [rax+0x100040],ecx
    7a0d12805cde:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d12805ce4:	0f 84 4c 17 00 18    	je     0x7a0d2a807436
    7a0d12805cea:	50                   	push   rax
    7a0d12805ceb:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d12805cef:	8d 48 fc             	lea    ecx,[rax-0x4]
    7a0d12805cf2:	a8 03                	test   al,0x3
    7a0d12805cf4:	0f 85 68 17 00 18    	jne    0x7a0d2a807462
    7a0d12805cfa:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12805d01:	89 ca                	mov    edx,ecx
    7a0d12805d03:	c1 ea 0c             	shr    edx,0xc
    7a0d12805d06:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12805d0a:	48 85 c0             	test   rax,rax
    7a0d12805d0d:	0f 84 9f 17 00 18    	je     0x7a0d2a8074b2
    7a0d12805d13:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805d19:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12805d1c:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    7a0d12805d23:	58                   	pop    rax
    7a0d12805d24:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    7a0d12805d2b:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    7a0d12805d32:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    7a0d12805d39:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d12805d3d:	50                   	push   rax
    7a0d12805d3e:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d12805d42:	8d 48 f8             	lea    ecx,[rax-0x8]
    7a0d12805d45:	a8 03                	test   al,0x3
    7a0d12805d47:	0f 85 a0 17 00 18    	jne    0x7a0d2a8074ed
    7a0d12805d4d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12805d54:	89 ca                	mov    edx,ecx
    7a0d12805d56:	c1 ea 0c             	shr    edx,0xc
    7a0d12805d59:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12805d5d:	48 85 c0             	test   rax,rax
    7a0d12805d60:	0f 84 d7 17 00 18    	je     0x7a0d2a80753d
    7a0d12805d66:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805d6c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12805d6f:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    7a0d12805d73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    7a0d12805d7a:	8c 00 01 00 
    7a0d12805d7e:	0f 84 f4 17 00 18    	je     0x7a0d2a807578
    7a0d12805d84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    7a0d12805d8b:	8c 00 01 00 
    7a0d12805d8f:	0f 84 e3 17 00 18    	je     0x7a0d2a807578
    7a0d12805d95:	58                   	pop    rax
    7a0d12805d96:	50                   	push   rax
    7a0d12805d97:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12805d9e:	b9 8e 00 01 00       	mov    ecx,0x1008e
    7a0d12805da3:	83 c1 04             	add    ecx,0x4
    7a0d12805da6:	89 ca                	mov    edx,ecx
    7a0d12805da8:	3d 8e 00 01 00       	cmp    eax,0x1008e
    7a0d12805dad:	75 07                	jne    0x7a0d12805db6
    7a0d12805daf:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d12805db6:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12805dbd:	02 
    7a0d12805dbe:	0f 43 ca             	cmovae ecx,edx
    7a0d12805dc1:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d12805dc8:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d12805dcf:	89 cf                	mov    edi,ecx
    7a0d12805dd1:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    7a0d12805dd7:	75 07                	jne    0x7a0d12805de0
    7a0d12805dd9:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d12805de0:	83 fe 02             	cmp    esi,0x2
    7a0d12805de3:	0f 43 cf             	cmovae ecx,edi
    7a0d12805de6:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d12805ded:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12805df4:	01 
    7a0d12805df5:	3d 8e 00 01 00       	cmp    eax,0x1008e
    7a0d12805dfa:	0f 84 c1 17 00 18    	je     0x7a0d2a8075c1
    7a0d12805e00:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    7a0d12805e06:	0f 84 b5 17 00 18    	je     0x7a0d2a8075c1
    7a0d12805e0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d12805e13:	28 03 01 00 
    7a0d12805e17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d12805e1e:	04 00 00 00 
    7a0d12805e22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d12805e29:	03 00 00 00 
    7a0d12805e2d:	58                   	pop    rax
    7a0d12805e2e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12805e35:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12805e3c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12805e43:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12805e4a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12805e51:	39 f1                	cmp    ecx,esi
    7a0d12805e53:	0f 83 a0 17 00 18    	jae    0x7a0d2a8075f9
    7a0d12805e59:	81 fa 84 00 01 00    	cmp    edx,0x10084
    7a0d12805e5f:	75 14                	jne    0x7a0d12805e75
    7a0d12805e61:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12805e68:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12805e6f:	00 
    7a0d12805e70:	e9 54 fe ff ff       	jmp    0x7a0d12805cc9
    7a0d12805e75:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12805e7c:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12805e82:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12805e85:	0f 85 6e 17 00 18    	jne    0x7a0d2a8075f9
    7a0d12805e8b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12805e92:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12805e99:	00 
    7a0d12805e9a:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12805e9f:	ff e0                	jmp    rax
