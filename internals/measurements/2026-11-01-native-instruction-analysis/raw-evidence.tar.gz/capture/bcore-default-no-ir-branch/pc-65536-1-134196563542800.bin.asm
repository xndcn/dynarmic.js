
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65536-1-134196563542800.bin:     file format binary


Disassembly of section .data:

00007a0d12800310 <.data>:
    7a0d12800310:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12800317:	8b 88 00 00 10 00    	mov    ecx,DWORD PTR [rax+0x100000]
    7a0d1280031d:	ff c1                	inc    ecx
    7a0d1280031f:	89 88 00 00 10 00    	mov    DWORD PTR [rax+0x100000],ecx
    7a0d12800325:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280032b:	0f 84 cf fc ff 17    	je     0x7a0d2a800000
    7a0d12800331:	50                   	push   rax
    7a0d12800332:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    7a0d12800337:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10000
    7a0d1280033e:	00 00 01 00 
    7a0d12800342:	0f 84 e4 fc ff 17    	je     0x7a0d2a80002c
    7a0d12800348:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10000
    7a0d1280034f:	00 00 01 00 
    7a0d12800353:	0f 84 d3 fc ff 17    	je     0x7a0d2a80002c
    7a0d12800359:	58                   	pop    rax
    7a0d1280035a:	50                   	push   rax
    7a0d1280035b:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12800362:	b9 02 00 01 00       	mov    ecx,0x10002
    7a0d12800367:	83 c1 04             	add    ecx,0x4
    7a0d1280036a:	89 ca                	mov    edx,ecx
    7a0d1280036c:	3d 02 00 01 00       	cmp    eax,0x10002
    7a0d12800371:	75 07                	jne    0x7a0d1280037a
    7a0d12800373:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d1280037a:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12800381:	02 
    7a0d12800382:	0f 43 ca             	cmovae ecx,edx
    7a0d12800385:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d1280038c:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d12800393:	89 cf                	mov    edi,ecx
    7a0d12800395:	81 fa 02 00 01 00    	cmp    edx,0x10002
    7a0d1280039b:	75 07                	jne    0x7a0d128003a4
    7a0d1280039d:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d128003a4:	83 fe 02             	cmp    esi,0x2
    7a0d128003a7:	0f 43 cf             	cmovae ecx,edi
    7a0d128003aa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d128003b1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128003b8:	01 
    7a0d128003b9:	3d 02 00 01 00       	cmp    eax,0x10002
    7a0d128003be:	0f 84 c8 fc ff 17    	je     0x7a0d2a80008c
    7a0d128003c4:	81 fa 02 00 01 00    	cmp    edx,0x10002
    7a0d128003ca:	0f 84 bc fc ff 17    	je     0x7a0d2a80008c
    7a0d128003d0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d128003d7:	14 00 01 00 
    7a0d128003db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d128003e2:	04 00 00 00 
    7a0d128003e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d128003ed:	02 00 00 00 
    7a0d128003f1:	58                   	pop    rax
    7a0d128003f2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128003f9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12800400:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12800407:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280040e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12800415:	39 f1                	cmp    ecx,esi
    7a0d12800417:	0f 83 a7 fc ff 17    	jae    0x7a0d2a8000c4
    7a0d1280041d:	81 fa 00 00 01 00    	cmp    edx,0x10000
    7a0d12800423:	75 14                	jne    0x7a0d12800439
    7a0d12800425:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280042c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12800433:	00 
    7a0d12800434:	e9 d7 fe ff ff       	jmp    0x7a0d12800310
    7a0d12800439:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12800440:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12800446:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12800449:	0f 85 75 fc ff 17    	jne    0x7a0d2a8000c4
    7a0d1280044f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12800456:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d1280045d:	00 
    7a0d1280045e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12800463:	ff e0                	jmp    rax
