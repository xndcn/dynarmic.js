
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66724-1-134196966209808.bin:     file format binary


Disassembly of section .data:

00007a0d2a803910 <.data>:
    7a0d2a803910:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a803916:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a803919:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80391f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a803926:	0f 87 45 f0 ff e7    	ja     0x7a0d12802971
    7a0d2a80392c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x7
    7a0d2a803933:	07 00 00 00 
    7a0d2a803937:	e9 35 f0 ff e7       	jmp    0x7a0d12802971
    7a0d2a80393c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104a4
    7a0d2a803943:	a4 04 01 00 
    7a0d2a803947:	b8 a4 04 01 00       	mov    eax,0x104a4
    7a0d2a80394c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803953:	04 00 00 00 
    7a0d2a803957:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80395e:	01 00 00 00 
    7a0d2a803962:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803965:	be a4 04 01 00       	mov    esi,0x104a4
    7a0d2a80396a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80396d:	e8 ee c7 ff e7       	call   0x7a0d12800160
    7a0d2a803972:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803979:	00 
    7a0d2a80397a:	0f 84 24 f0 ff e7    	je     0x7a0d128029a4
    7a0d2a803980:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803987:	04 00 00 00 
    7a0d2a80398b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803992:	01 00 00 00 
    7a0d2a803996:	58                   	pop    rax
    7a0d2a803997:	e9 36 f2 ff e7       	jmp    0x7a0d12802bd2
    7a0d2a80399c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104a8
    7a0d2a8039a3:	a8 04 01 00 
    7a0d2a8039a7:	b8 a8 04 01 00       	mov    eax,0x104a8
    7a0d2a8039ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8039b3:	04 00 00 00 
    7a0d2a8039b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8039be:	02 00 00 00 
    7a0d2a8039c2:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8039c5:	be a8 04 01 00       	mov    esi,0x104a8
    7a0d2a8039ca:	4c 89 ef             	mov    rdi,r13
    7a0d2a8039cd:	e8 8e c7 ff e7       	call   0x7a0d12800160
    7a0d2a8039d2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8039d9:	00 
    7a0d2a8039da:	0f 84 fb ef ff e7    	je     0x7a0d128029db
    7a0d2a8039e0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8039e7:	04 00 00 00 
    7a0d2a8039eb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8039f2:	02 00 00 00 
    7a0d2a8039f6:	58                   	pop    rax
    7a0d2a8039f7:	e9 d6 f1 ff e7       	jmp    0x7a0d12802bd2
    7a0d2a8039fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104ac
    7a0d2a803a03:	ac 04 01 00 
    7a0d2a803a07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803a0e:	02 00 00 00 
    7a0d2a803a12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803a19:	03 00 00 00 
    7a0d2a803a1d:	ba ac 04 01 00       	mov    edx,0x104ac
    7a0d2a803a22:	4c 89 ef             	mov    rdi,r13
    7a0d2a803a25:	4c 89 f6             	mov    rsi,r14
    7a0d2a803a28:	45 31 c0             	xor    r8d,r8d
    7a0d2a803a2b:	e8 50 c6 ff e7       	call   0x7a0d12800080
    7a0d2a803a30:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803a37:	02 00 00 00 
    7a0d2a803a3b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803a42:	03 00 00 00 
    7a0d2a803a46:	58                   	pop    rax
    7a0d2a803a47:	e9 86 f1 ff e7       	jmp    0x7a0d12802bd2
    7a0d2a803a4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104ac
    7a0d2a803a53:	ac 04 01 00 
    7a0d2a803a57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803a5e:	02 00 00 00 
    7a0d2a803a62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803a69:	03 00 00 00 
    7a0d2a803a6d:	4c 89 f7             	mov    rdi,r14
    7a0d2a803a70:	89 ce                	mov    esi,ecx
    7a0d2a803a72:	e8 c9 c5 ff e7       	call   0x7a0d12800040
    7a0d2a803a77:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803a7e:	00 
    7a0d2a803a7f:	0f 84 89 ef ff e7    	je     0x7a0d12802a0e
    7a0d2a803a85:	eb a9                	jmp    0x7a0d2a803a30
    7a0d2a803a87:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104ac
    7a0d2a803a8e:	ac 04 01 00 
    7a0d2a803a92:	b8 ac 04 01 00       	mov    eax,0x104ac
    7a0d2a803a97:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803a9e:	02 00 00 00 
    7a0d2a803aa2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a803aa9:	03 00 00 00 
    7a0d2a803aad:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803ab0:	be ac 04 01 00       	mov    esi,0x104ac
    7a0d2a803ab5:	4c 89 ef             	mov    rdi,r13
    7a0d2a803ab8:	e8 a3 c6 ff e7       	call   0x7a0d12800160
    7a0d2a803abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803ac4:	00 
    7a0d2a803ac5:	0f 84 69 ef ff e7    	je     0x7a0d12802a34
    7a0d2a803acb:	e9 60 ff ff ff       	jmp    0x7a0d2a803a30
    7a0d2a803ad0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104ae
    7a0d2a803ad7:	ae 04 01 00 
    7a0d2a803adb:	b8 ae 04 01 00       	mov    eax,0x104ae
    7a0d2a803ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803ae7:	04 00 00 00 
    7a0d2a803aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803af2:	04 00 00 00 
    7a0d2a803af6:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803af9:	be ae 04 01 00       	mov    esi,0x104ae
    7a0d2a803afe:	4c 89 ef             	mov    rdi,r13
    7a0d2a803b01:	e8 5a c6 ff e7       	call   0x7a0d12800160
    7a0d2a803b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803b0d:	00 
    7a0d2a803b0e:	0f 84 54 ef ff e7    	je     0x7a0d12802a68
    7a0d2a803b14:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803b1b:	04 00 00 00 
    7a0d2a803b1f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803b26:	04 00 00 00 
    7a0d2a803b2a:	58                   	pop    rax
    7a0d2a803b2b:	e9 a2 f0 ff e7       	jmp    0x7a0d12802bd2
    7a0d2a803b30:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b2
    7a0d2a803b37:	b2 04 01 00 
    7a0d2a803b3b:	b8 b2 04 01 00       	mov    eax,0x104b2
    7a0d2a803b40:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803b47:	04 00 00 00 
    7a0d2a803b4b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a803b52:	05 00 00 00 
    7a0d2a803b56:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803b59:	be b2 04 01 00       	mov    esi,0x104b2
    7a0d2a803b5e:	4c 89 ef             	mov    rdi,r13
    7a0d2a803b61:	e8 fa c5 ff e7       	call   0x7a0d12800160
    7a0d2a803b66:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803b6d:	00 
    7a0d2a803b6e:	0f 84 2b ef ff e7    	je     0x7a0d12802a9f
    7a0d2a803b74:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803b7b:	04 00 00 00 
    7a0d2a803b7f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a803b86:	05 00 00 00 
    7a0d2a803b8a:	58                   	pop    rax
    7a0d2a803b8b:	e9 42 f0 ff e7       	jmp    0x7a0d12802bd2
    7a0d2a803b90:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b6
    7a0d2a803b97:	b6 04 01 00 
    7a0d2a803b9b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803ba2:	02 00 00 00 
    7a0d2a803ba6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803bad:	06 00 00 00 
    7a0d2a803bb1:	ba b6 04 01 00       	mov    edx,0x104b6
    7a0d2a803bb6:	4c 89 ef             	mov    rdi,r13
    7a0d2a803bb9:	4c 89 f6             	mov    rsi,r14
    7a0d2a803bbc:	45 31 c0             	xor    r8d,r8d
    7a0d2a803bbf:	e8 bc c4 ff e7       	call   0x7a0d12800080
    7a0d2a803bc4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803bcb:	02 00 00 00 
    7a0d2a803bcf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803bd6:	06 00 00 00 
    7a0d2a803bda:	58                   	pop    rax
    7a0d2a803bdb:	e9 f2 ef ff e7       	jmp    0x7a0d12802bd2
    7a0d2a803be0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b6
    7a0d2a803be7:	b6 04 01 00 
    7a0d2a803beb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803bf2:	02 00 00 00 
    7a0d2a803bf6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803bfd:	06 00 00 00 
    7a0d2a803c01:	4c 89 f7             	mov    rdi,r14
    7a0d2a803c04:	89 ce                	mov    esi,ecx
    7a0d2a803c06:	e8 35 c4 ff e7       	call   0x7a0d12800040
    7a0d2a803c0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803c12:	00 
    7a0d2a803c13:	0f 84 b9 ee ff e7    	je     0x7a0d12802ad2
    7a0d2a803c19:	eb a9                	jmp    0x7a0d2a803bc4
    7a0d2a803c1b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b6
    7a0d2a803c22:	b6 04 01 00 
    7a0d2a803c26:	b8 b6 04 01 00       	mov    eax,0x104b6
    7a0d2a803c2b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803c32:	02 00 00 00 
    7a0d2a803c36:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a803c3d:	06 00 00 00 
    7a0d2a803c41:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803c44:	be b6 04 01 00       	mov    esi,0x104b6
    7a0d2a803c49:	4c 89 ef             	mov    rdi,r13
    7a0d2a803c4c:	e8 0f c5 ff e7       	call   0x7a0d12800160
    7a0d2a803c51:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803c58:	00 
    7a0d2a803c59:	0f 84 99 ee ff e7    	je     0x7a0d12802af8
    7a0d2a803c5f:	e9 60 ff ff ff       	jmp    0x7a0d2a803bc4
    7a0d2a803c64:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    7a0d2a803c6b:	b8 04 01 00 
    7a0d2a803c6f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803c76:	04 00 00 00 
    7a0d2a803c7a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a803c81:	07 00 00 00 
    7a0d2a803c85:	ba b8 04 01 00       	mov    edx,0x104b8
    7a0d2a803c8a:	4c 89 ef             	mov    rdi,r13
    7a0d2a803c8d:	4c 89 f6             	mov    rsi,r14
    7a0d2a803c90:	89 d9                	mov    ecx,ebx
    7a0d2a803c92:	45 31 c0             	xor    r8d,r8d
    7a0d2a803c95:	e8 e6 c3 ff e7       	call   0x7a0d12800080
    7a0d2a803c9a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803ca1:	04 00 00 00 
    7a0d2a803ca5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a803cac:	07 00 00 00 
    7a0d2a803cb0:	58                   	pop    rax
    7a0d2a803cb1:	e9 1c ef ff e7       	jmp    0x7a0d12802bd2
    7a0d2a803cb6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    7a0d2a803cbd:	b8 04 01 00 
    7a0d2a803cc1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803cc8:	04 00 00 00 
    7a0d2a803ccc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a803cd3:	07 00 00 00 
    7a0d2a803cd7:	4c 89 f7             	mov    rdi,r14
    7a0d2a803cda:	89 de                	mov    esi,ebx
    7a0d2a803cdc:	e8 5f c3 ff e7       	call   0x7a0d12800040
    7a0d2a803ce1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803ce8:	00 
    7a0d2a803ce9:	75 af                	jne    0x7a0d2a803c9a
    7a0d2a803ceb:	41 89 c7             	mov    r15d,eax
    7a0d2a803cee:	e9 3c ee ff e7       	jmp    0x7a0d12802b2f
    7a0d2a803cf3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    7a0d2a803cfa:	b8 04 01 00 
    7a0d2a803cfe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803d05:	04 00 00 00 
    7a0d2a803d09:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a803d10:	07 00 00 00 
    7a0d2a803d14:	4c 89 f7             	mov    rdi,r14
    7a0d2a803d17:	e8 24 c3 ff e7       	call   0x7a0d12800040
    7a0d2a803d1c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803d23:	00 
    7a0d2a803d24:	0f 84 26 ee ff e7    	je     0x7a0d12802b50
    7a0d2a803d2a:	e9 6b ff ff ff       	jmp    0x7a0d2a803c9a
    7a0d2a803d2f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    7a0d2a803d36:	b8 04 01 00 
    7a0d2a803d3a:	b8 b8 04 01 00       	mov    eax,0x104b8
    7a0d2a803d3f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803d46:	04 00 00 00 
    7a0d2a803d4a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a803d51:	07 00 00 00 
    7a0d2a803d55:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803d58:	be b8 04 01 00       	mov    esi,0x104b8
    7a0d2a803d5d:	4c 89 ef             	mov    rdi,r13
    7a0d2a803d60:	e8 fb c3 ff e7       	call   0x7a0d12800160
    7a0d2a803d65:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803d6c:	00 
    7a0d2a803d6d:	0f 84 11 ee ff e7    	je     0x7a0d12802b84
    7a0d2a803d73:	e9 22 ff ff ff       	jmp    0x7a0d2a803c9a
    7a0d2a803d78:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d2a803d7f:	4c 01 01 00 
    7a0d2a803d83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803d8a:	04 00 00 00 
    7a0d2a803d8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a803d95:	08 00 00 00 
    7a0d2a803d99:	be bc 04 01 00       	mov    esi,0x104bc
    7a0d2a803d9e:	ba bc 04 01 00       	mov    edx,0x104bc
    7a0d2a803da3:	4c 89 ef             	mov    rdi,r13
    7a0d2a803da6:	e8 b5 c3 ff e7       	call   0x7a0d12800160
    7a0d2a803dab:	e9 00 ee ff e7       	jmp    0x7a0d12802bb0
    7a0d2a803db0:	c2 08 00             	ret    0x8
