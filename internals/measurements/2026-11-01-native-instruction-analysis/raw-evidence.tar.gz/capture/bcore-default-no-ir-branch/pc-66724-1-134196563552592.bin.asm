
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66724-1-134196563552592.bin:     file format binary


Disassembly of section .data:

00007a0d12802950 <.data>:
    7a0d12802950:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802957:	8b 88 1c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10001c]
    7a0d1280295d:	ff c1                	inc    ecx
    7a0d1280295f:	89 88 1c 00 10 00    	mov    DWORD PTR [rax+0x10001c],ecx
    7a0d12802965:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280296b:	0f 84 9f 0f 00 18    	je     0x7a0d2a803910
    7a0d12802971:	50                   	push   rax
    7a0d12802972:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d12802977:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d1280297c:	09 c1                	or     ecx,eax
    7a0d1280297e:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12802982:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104a4
    7a0d12802989:	a4 04 01 00 
    7a0d1280298d:	0f 84 a9 0f 00 18    	je     0x7a0d2a80393c
    7a0d12802993:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104a4
    7a0d1280299a:	a4 04 01 00 
    7a0d1280299e:	0f 84 98 0f 00 18    	je     0x7a0d2a80393c
    7a0d128029a4:	58                   	pop    rax
    7a0d128029a5:	50                   	push   rax
    7a0d128029a6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d128029ab:	c1 e0 10             	shl    eax,0x10
    7a0d128029ae:	b9 f4 12 00 00       	mov    ecx,0x12f4
    7a0d128029b3:	09 c1                	or     ecx,eax
    7a0d128029b5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128029b9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104a8
    7a0d128029c0:	a8 04 01 00 
    7a0d128029c4:	0f 84 d2 0f 00 18    	je     0x7a0d2a80399c
    7a0d128029ca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104a8
    7a0d128029d1:	a8 04 01 00 
    7a0d128029d5:	0f 84 c1 0f 00 18    	je     0x7a0d2a80399c
    7a0d128029db:	58                   	pop    rax
    7a0d128029dc:	50                   	push   rax
    7a0d128029dd:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d128029e1:	f6 c1 03             	test   cl,0x3
    7a0d128029e4:	0f 85 12 10 00 18    	jne    0x7a0d2a8039fc
    7a0d128029ea:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d128029f1:	48 89 ca             	mov    rdx,rcx
    7a0d128029f4:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d128029f8:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d128029fc:	48 85 c0             	test   rax,rax
    7a0d128029ff:	0f 84 47 10 00 18    	je     0x7a0d2a803a4c
    7a0d12802a05:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802a0b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12802a0e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12802a12:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104ac
    7a0d12802a19:	ac 04 01 00 
    7a0d12802a1d:	0f 84 64 10 00 18    	je     0x7a0d2a803a87
    7a0d12802a23:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104ac
    7a0d12802a2a:	ac 04 01 00 
    7a0d12802a2e:	0f 84 53 10 00 18    	je     0x7a0d2a803a87
    7a0d12802a34:	58                   	pop    rax
    7a0d12802a35:	50                   	push   rax
    7a0d12802a36:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d12802a3b:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d12802a40:	09 c1                	or     ecx,eax
    7a0d12802a42:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12802a46:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104ae
    7a0d12802a4d:	ae 04 01 00 
    7a0d12802a51:	0f 84 79 10 00 18    	je     0x7a0d2a803ad0
    7a0d12802a57:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104ae
    7a0d12802a5e:	ae 04 01 00 
    7a0d12802a62:	0f 84 68 10 00 18    	je     0x7a0d2a803ad0
    7a0d12802a68:	58                   	pop    rax
    7a0d12802a69:	50                   	push   rax
    7a0d12802a6a:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12802a6f:	c1 e0 10             	shl    eax,0x10
    7a0d12802a72:	b9 f8 12 00 00       	mov    ecx,0x12f8
    7a0d12802a77:	09 c1                	or     ecx,eax
    7a0d12802a79:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12802a7d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104b2
    7a0d12802a84:	b2 04 01 00 
    7a0d12802a88:	0f 84 a2 10 00 18    	je     0x7a0d2a803b30
    7a0d12802a8e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104b2
    7a0d12802a95:	b2 04 01 00 
    7a0d12802a99:	0f 84 91 10 00 18    	je     0x7a0d2a803b30
    7a0d12802a9f:	58                   	pop    rax
    7a0d12802aa0:	50                   	push   rax
    7a0d12802aa1:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12802aa5:	f6 c1 03             	test   cl,0x3
    7a0d12802aa8:	0f 85 e2 10 00 18    	jne    0x7a0d2a803b90
    7a0d12802aae:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12802ab5:	48 89 ca             	mov    rdx,rcx
    7a0d12802ab8:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d12802abc:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12802ac0:	48 85 c0             	test   rax,rax
    7a0d12802ac3:	0f 84 17 11 00 18    	je     0x7a0d2a803be0
    7a0d12802ac9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802acf:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12802ad2:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d12802ad6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104b6
    7a0d12802add:	b6 04 01 00 
    7a0d12802ae1:	0f 84 34 11 00 18    	je     0x7a0d2a803c1b
    7a0d12802ae7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104b6
    7a0d12802aee:	b6 04 01 00 
    7a0d12802af2:	0f 84 23 11 00 18    	je     0x7a0d2a803c1b
    7a0d12802af8:	58                   	pop    rax
    7a0d12802af9:	50                   	push   rax
    7a0d12802afa:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d12802afe:	f6 c3 03             	test   bl,0x3
    7a0d12802b01:	0f 85 5d 11 00 18    	jne    0x7a0d2a803c64
    7a0d12802b07:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12802b0e:	48 89 d8             	mov    rax,rbx
    7a0d12802b11:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12802b15:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802b1a:	48 85 c0             	test   rax,rax
    7a0d12802b1d:	0f 84 93 11 00 18    	je     0x7a0d2a803cb6
    7a0d12802b23:	89 d9                	mov    ecx,ebx
    7a0d12802b25:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802b2b:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d12802b2f:	89 de                	mov    esi,ebx
    7a0d12802b31:	83 c6 04             	add    esi,0x4
    7a0d12802b34:	89 f0                	mov    eax,esi
    7a0d12802b36:	c1 e8 0c             	shr    eax,0xc
    7a0d12802b39:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802b3e:	48 85 c0             	test   rax,rax
    7a0d12802b41:	0f 84 ac 11 00 18    	je     0x7a0d2a803cf3
    7a0d12802b47:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12802b4d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12802b50:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d12802b53:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d12802b57:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12802b5e:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d12802b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104b8
    7a0d12802b69:	b8 04 01 00 
    7a0d12802b6d:	0f 84 bc 11 00 18    	je     0x7a0d2a803d2f
    7a0d12802b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104b8
    7a0d12802b7a:	b8 04 01 00 
    7a0d12802b7e:	0f 84 ab 11 00 18    	je     0x7a0d2a803d2f
    7a0d12802b84:	58                   	pop    rax
    7a0d12802b85:	50                   	push   rax
    7a0d12802b86:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12802b8d:	01 
    7a0d12802b8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104bc
    7a0d12802b95:	bc 04 01 00 
    7a0d12802b99:	0f 84 d9 11 00 18    	je     0x7a0d2a803d78
    7a0d12802b9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104bc
    7a0d12802ba6:	bc 04 01 00 
    7a0d12802baa:	0f 84 c8 11 00 18    	je     0x7a0d2a803d78
    7a0d12802bb0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    7a0d12802bb7:	4c 01 01 00 
    7a0d12802bbb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d12802bc2:	04 00 00 00 
    7a0d12802bc6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d12802bcd:	08 00 00 00 
    7a0d12802bd1:	58                   	pop    rax
    7a0d12802bd2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802bd9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12802be0:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12802be7:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12802bee:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12802bf5:	39 f1                	cmp    ecx,esi
    7a0d12802bf7:	0f 83 b3 11 00 18    	jae    0x7a0d2a803db0
    7a0d12802bfd:	81 fa a4 04 01 00    	cmp    edx,0x104a4
    7a0d12802c03:	75 14                	jne    0x7a0d12802c19
    7a0d12802c05:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802c0c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802c13:	00 
    7a0d12802c14:	e9 37 fd ff ff       	jmp    0x7a0d12802950
    7a0d12802c19:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12802c20:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12802c26:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12802c29:	0f 85 81 11 00 18    	jne    0x7a0d2a803db0
    7a0d12802c2f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802c36:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802c3d:	00 
    7a0d12802c3e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12802c43:	ff e0                	jmp    rax
