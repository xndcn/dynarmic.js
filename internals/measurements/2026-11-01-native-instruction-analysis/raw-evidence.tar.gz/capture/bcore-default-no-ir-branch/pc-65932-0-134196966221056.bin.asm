
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65932-0-134196966221056.bin:     file format binary


Disassembly of section .data:

00007a0d2a806500 <.data>:
    7a0d2a806500:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a806507:	01 
    7a0d2a806508:	48 83 c4 18          	add    rsp,0x18
    7a0d2a80650c:	c2 08 00             	ret    0x8
    7a0d2a80650f:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    7a0d2a806516:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    7a0d2a80651d:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    7a0d2a806524:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    7a0d2a80652b:	48 83 c4 18          	add    rsp,0x18
    7a0d2a80652f:	c2 08 00             	ret    0x8
    7a0d2a806532:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7a0d2a806539:	7c 01 01 00 
    7a0d2a80653d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806544:	02 00 00 00 
    7a0d2a806548:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80654f:	03 00 00 00 
    7a0d2a806553:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a80655a:	01 
    7a0d2a80655b:	48 83 c4 18          	add    rsp,0x18
    7a0d2a80655f:	c2 08 00             	ret    0x8
    7a0d2a806562:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a806569:	94 01 01 00 
    7a0d2a80656d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806574:	04 00 00 00 
    7a0d2a806578:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80657f:	05 00 00 00 
    7a0d2a806583:	48 b8 e0 b8 82 06 01 	movabs rax,0x65010682b8e0
    7a0d2a80658a:	65 00 00 
    7a0d2a80658d:	4c 89 ef             	mov    rdi,r13
    7a0d2a806590:	4c 89 f6             	mov    rsi,r14
    7a0d2a806593:	ba 94 01 01 00       	mov    edx,0x10194
    7a0d2a806598:	89 e9                	mov    ecx,ebp
    7a0d2a80659a:	4c 89 c3             	mov    rbx,r8
    7a0d2a80659d:	45 31 c0             	xor    r8d,r8d
    7a0d2a8065a0:	ff d0                	call   rax
    7a0d2a8065a2:	49 89 d8             	mov    r8,rbx
    7a0d2a8065a5:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    7a0d2a8065ac:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a8065b3:	00 
    7a0d2a8065b4:	bb 05 00 00 00       	mov    ebx,0x5
    7a0d2a8065b9:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a8065be:	e9 a2 ee ff e7       	jmp    0x7a0d12805465
    7a0d2a8065c3:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a8065c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a8065cf:	94 01 01 00 
    7a0d2a8065d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8065da:	04 00 00 00 
    7a0d2a8065de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8065e5:	05 00 00 00 
    7a0d2a8065e9:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a8065f0:	65 00 00 
    7a0d2a8065f3:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a8065f8:	4c 89 f7             	mov    rdi,r14
    7a0d2a8065fb:	89 ee                	mov    esi,ebp
    7a0d2a8065fd:	ff d0                	call   rax
    7a0d2a8065ff:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806606:	00 
    7a0d2a806607:	84 c9                	test   cl,cl
    7a0d2a806609:	0f 85 98 02 00 00    	jne    0x7a0d2a8068a7
    7a0d2a80660f:	89 c3                	mov    ebx,eax
    7a0d2a806611:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a806616:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a80661b:	e9 50 ed ff e7       	jmp    0x7a0d12805370
    7a0d2a806620:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a806625:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    7a0d2a80662c:	94 01 01 00 
    7a0d2a806630:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806637:	04 00 00 00 
    7a0d2a80663b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a806642:	05 00 00 00 
    7a0d2a806646:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a80664d:	65 00 00 
    7a0d2a806650:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a806655:	4c 89 f7             	mov    rdi,r14
    7a0d2a806658:	ff d0                	call   rax
    7a0d2a80665a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806661:	00 
    7a0d2a806662:	84 c9                	test   cl,cl
    7a0d2a806664:	0f 85 3d 02 00 00    	jne    0x7a0d2a8068a7
    7a0d2a80666a:	41 89 c7             	mov    r15d,eax
    7a0d2a80666d:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a806672:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a806677:	e9 13 ed ff e7       	jmp    0x7a0d1280538f
    7a0d2a80667c:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a806681:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a806688:	98 01 01 00 
    7a0d2a80668c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806693:	02 00 00 00 
    7a0d2a806697:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a80669e:	06 00 00 00 
    7a0d2a8066a2:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a8066a9:	65 00 00 
    7a0d2a8066ac:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a8066b1:	4c 89 f7             	mov    rdi,r14
    7a0d2a8066b4:	ff d0                	call   rax
    7a0d2a8066b6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a8066bd:	00 
    7a0d2a8066be:	84 c9                	test   cl,cl
    7a0d2a8066c0:	0f 85 c1 01 00 00    	jne    0x7a0d2a806887
    7a0d2a8066c6:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a8066cb:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a8066d0:	e9 e7 ec ff e7       	jmp    0x7a0d128053bc
    7a0d2a8066d5:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a8066da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a8066e1:	98 01 01 00 
    7a0d2a8066e5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8066ec:	02 00 00 00 
    7a0d2a8066f0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8066f7:	06 00 00 00 
    7a0d2a8066fb:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a806702:	65 00 00 
    7a0d2a806705:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a80670a:	4c 89 f7             	mov    rdi,r14
    7a0d2a80670d:	ff d0                	call   rax
    7a0d2a80670f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806716:	00 
    7a0d2a806717:	84 c9                	test   cl,cl
    7a0d2a806719:	0f 85 68 01 00 00    	jne    0x7a0d2a806887
    7a0d2a80671f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a806724:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a806729:	e9 b0 ec ff e7       	jmp    0x7a0d128053de
    7a0d2a80672e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a806733:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a80673a:	98 01 01 00 
    7a0d2a80673e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806745:	02 00 00 00 
    7a0d2a806749:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806750:	06 00 00 00 
    7a0d2a806754:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a80675b:	65 00 00 
    7a0d2a80675e:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a806763:	4c 89 f7             	mov    rdi,r14
    7a0d2a806766:	ff d0                	call   rax
    7a0d2a806768:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a80676f:	00 
    7a0d2a806770:	84 c9                	test   cl,cl
    7a0d2a806772:	0f 85 0f 01 00 00    	jne    0x7a0d2a806887
    7a0d2a806778:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a80677d:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a806782:	e9 79 ec ff e7       	jmp    0x7a0d12805400
    7a0d2a806787:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a80678c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a806793:	98 01 01 00 
    7a0d2a806797:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80679e:	02 00 00 00 
    7a0d2a8067a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8067a9:	06 00 00 00 
    7a0d2a8067ad:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a8067b4:	65 00 00 
    7a0d2a8067b7:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7a0d2a8067bc:	4c 89 f7             	mov    rdi,r14
    7a0d2a8067bf:	ff d0                	call   rax
    7a0d2a8067c1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a8067c8:	00 
    7a0d2a8067c9:	84 c9                	test   cl,cl
    7a0d2a8067cb:	0f 85 b6 00 00 00    	jne    0x7a0d2a806887
    7a0d2a8067d1:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a8067d6:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a8067db:	e9 42 ec ff e7       	jmp    0x7a0d12805422
    7a0d2a8067e0:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    7a0d2a8067e5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    7a0d2a8067ec:	98 01 01 00 
    7a0d2a8067f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8067f7:	02 00 00 00 
    7a0d2a8067fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806802:	06 00 00 00 
    7a0d2a806806:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a80680d:	65 00 00 
    7a0d2a806810:	4d 89 f4             	mov    r12,r14
    7a0d2a806813:	4c 89 f7             	mov    rdi,r14
    7a0d2a806816:	ff d0                	call   rax
    7a0d2a806818:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a80681f:	00 
    7a0d2a806820:	84 c9                	test   cl,cl
    7a0d2a806822:	0f 85 92 00 00 00    	jne    0x7a0d2a8068ba
    7a0d2a806828:	4d 89 e6             	mov    r14,r12
    7a0d2a80682b:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a806830:	e9 0f ec ff e7       	jmp    0x7a0d12805444
    7a0d2a806835:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019a
    7a0d2a80683c:	9a 01 01 00 
    7a0d2a806840:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806847:	02 00 00 00 
    7a0d2a80684b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a806852:	07 00 00 00 
    7a0d2a806856:	48 b8 e0 aa 82 06 01 	movabs rax,0x65010682aae0
    7a0d2a80685d:	65 00 00 
    7a0d2a806860:	4c 89 ef             	mov    rdi,r13
    7a0d2a806863:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a806868:	4c 89 f2             	mov    rdx,r14
    7a0d2a80686b:	4d 89 c7             	mov    r15,r8
    7a0d2a80686e:	ff d0                	call   rax
    7a0d2a806870:	4d 89 f8             	mov    r8,r15
    7a0d2a806873:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    7a0d2a80687a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806881:	00 
    7a0d2a806882:	e9 de eb ff e7       	jmp    0x7a0d12805465
    7a0d2a806887:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    7a0d2a80688e:	bb 06 00 00 00       	mov    ebx,0x6
    7a0d2a806893:	bd 02 00 00 00       	mov    ebp,0x2
    7a0d2a806898:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7a0d2a80689d:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    7a0d2a8068a2:	e9 be eb ff e7       	jmp    0x7a0d12805465
    7a0d2a8068a7:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    7a0d2a8068ae:	bb 05 00 00 00       	mov    ebx,0x5
    7a0d2a8068b3:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a8068b8:	eb de                	jmp    0x7a0d2a806898
    7a0d2a8068ba:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    7a0d2a8068c1:	bb 06 00 00 00       	mov    ebx,0x6
    7a0d2a8068c6:	bd 02 00 00 00       	mov    ebp,0x2
    7a0d2a8068cb:	4d 89 e6             	mov    r14,r12
    7a0d2a8068ce:	eb cd                	jmp    0x7a0d2a80689d
