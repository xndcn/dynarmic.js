
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65904-1-134196966213664.bin:     file format binary


Disassembly of section .data:

00007a0d2a804820 <.data>:
    7a0d2a804820:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a804826:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a804829:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80482f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a804836:	0f 87 b5 ec ff e7    	ja     0x7a0d128034f1
    7a0d2a80483c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xa
    7a0d2a804843:	0a 00 00 00 
    7a0d2a804847:	e9 a5 ec ff e7       	jmp    0x7a0d128034f1
    7a0d2a80484c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d2a804853:	70 01 01 00 
    7a0d2a804857:	b8 70 01 01 00       	mov    eax,0x10170
    7a0d2a80485c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804863:	02 00 00 00 
    7a0d2a804867:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80486e:	01 00 00 00 
    7a0d2a804872:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804875:	be 70 01 01 00       	mov    esi,0x10170
    7a0d2a80487a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80487d:	e8 de b8 ff e7       	call   0x7a0d12800160
    7a0d2a804882:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804889:	00 
    7a0d2a80488a:	0f 84 e6 ec ff e7    	je     0x7a0d12803576
    7a0d2a804890:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804897:	02 00 00 00 
    7a0d2a80489b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8048a2:	01 00 00 00 
    7a0d2a8048a6:	58                   	pop    rax
    7a0d2a8048a7:	e9 63 ed ff e7       	jmp    0x7a0d1280360f
    7a0d2a8048ac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d2a8048b3:	30 01 01 00 
    7a0d2a8048b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8048be:	04 00 00 00 
    7a0d2a8048c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8048c9:	02 00 00 00 
    7a0d2a8048cd:	be 72 01 01 00       	mov    esi,0x10172
    7a0d2a8048d2:	ba 72 01 01 00       	mov    edx,0x10172
    7a0d2a8048d7:	4c 89 ef             	mov    rdi,r13
    7a0d2a8048da:	e8 81 b8 ff e7       	call   0x7a0d12800160
    7a0d2a8048df:	e9 09 ed ff e7       	jmp    0x7a0d128035ed
    7a0d2a8048e4:	c2 08 00             	ret    0x8
