
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65692-1-134196563563888.bin:     file format binary


Disassembly of section .data:

00007a0d12805570 <.data>:
    7a0d12805570:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12805577:	8b 88 3c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10003c]
    7a0d1280557d:	ff c1                	inc    ecx
    7a0d1280557f:	89 88 3c 00 10 00    	mov    DWORD PTR [rax+0x10003c],ecx
    7a0d12805585:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280558b:	0f 84 7f 13 00 18    	je     0x7a0d2a806910
    7a0d12805591:	50                   	push   rax
    7a0d12805592:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    7a0d12805596:	f6 c1 03             	test   cl,0x3
    7a0d12805599:	0f 85 9d 13 00 18    	jne    0x7a0d2a80693c
    7a0d1280559f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d128055a6:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7a0d128055aa:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d128055b1:	48 89 ce             	mov    rsi,rcx
    7a0d128055b4:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d128055b8:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d128055bc:	48 85 c0             	test   rax,rax
    7a0d128055bf:	0f 84 ca 13 00 18    	je     0x7a0d2a80698f
    7a0d128055c5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128055cb:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d128055ce:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009c
    7a0d128055d5:	9c 00 01 00 
    7a0d128055d9:	0f 84 eb 13 00 18    	je     0x7a0d2a8069ca
    7a0d128055df:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009c
    7a0d128055e6:	9c 00 01 00 
    7a0d128055ea:	0f 84 da 13 00 18    	je     0x7a0d2a8069ca
    7a0d128055f0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d128055f3:	0f 85 12 14 00 18    	jne    0x7a0d2a806a0b
    7a0d128055f9:	58                   	pop    rax
    7a0d128055fa:	e9 0f 00 00 00       	jmp    0x7a0d1280560e
    7a0d128055ff:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12805606:	00 
    7a0d12805607:	74 f0                	je     0x7a0d128055f9
    7a0d12805609:	e9 65 13 00 18       	jmp    0x7a0d2a806973
    7a0d1280560e:	50                   	push   rax
    7a0d1280560f:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    7a0d12805613:	f6 c3 03             	test   bl,0x3
    7a0d12805616:	0f 85 21 14 00 18    	jne    0x7a0d2a806a3d
    7a0d1280561c:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    7a0d12805623:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12805627:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d1280562e:	48 89 d9             	mov    rcx,rbx
    7a0d12805631:	48 c1 e9 0c          	shr    rcx,0xc
    7a0d12805635:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7a0d12805639:	48 85 c0             	test   rax,rax
    7a0d1280563c:	0f 84 50 14 00 18    	je     0x7a0d2a806a92
    7a0d12805642:	89 d9                	mov    ecx,ebx
    7a0d12805644:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280564a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d1280564d:	83 c3 04             	add    ebx,0x4
    7a0d12805650:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    7a0d12805654:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009e
    7a0d1280565b:	9e 00 01 00 
    7a0d1280565f:	0f 84 68 14 00 18    	je     0x7a0d2a806acd
    7a0d12805665:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009e
    7a0d1280566c:	9e 00 01 00 
    7a0d12805670:	0f 84 57 14 00 18    	je     0x7a0d2a806acd
    7a0d12805676:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    7a0d1280567a:	0f 85 8f 14 00 18    	jne    0x7a0d2a806b0f
    7a0d12805680:	58                   	pop    rax
    7a0d12805681:	e9 0f 00 00 00       	jmp    0x7a0d12805695
    7a0d12805686:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d1280568d:	00 
    7a0d1280568e:	74 f0                	je     0x7a0d12805680
    7a0d12805690:	e9 e1 13 00 18       	jmp    0x7a0d2a806a76
    7a0d12805695:	50                   	push   rax
    7a0d12805696:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7a0d1280569a:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128056a1:	31 d2                	xor    edx,edx
    7a0d128056a3:	89 c6                	mov    esi,eax
    7a0d128056a5:	ff c6                	inc    esi
    7a0d128056a7:	0f 94 c2             	sete   dl
    7a0d128056aa:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    7a0d128056ae:	c1 e8 1f             	shr    eax,0x1f
    7a0d128056b1:	89 f7                	mov    edi,esi
    7a0d128056b3:	c1 ef 1f             	shr    edi,0x1f
    7a0d128056b6:	f7 d0                	not    eax
    7a0d128056b8:	21 f8                	and    eax,edi
    7a0d128056ba:	31 db                	xor    ebx,ebx
    7a0d128056bc:	85 f6                	test   esi,esi
    7a0d128056be:	0f 94 c3             	sete   bl
    7a0d128056c1:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7a0d128056c8:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d128056cf:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7a0d128056d6:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7a0d128056dd:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    7a0d128056e4:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7a0d128056eb:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7a0d128056f2:	81 f9 a0 00 01 00    	cmp    ecx,0x100a0
    7a0d128056f8:	0f 84 43 14 00 18    	je     0x7a0d2a806b41
    7a0d128056fe:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a0
    7a0d12805705:	a0 00 01 00 
    7a0d12805709:	0f 84 32 14 00 18    	je     0x7a0d2a806b41
    7a0d1280570f:	58                   	pop    rax
    7a0d12805710:	50                   	push   rax
    7a0d12805711:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    7a0d12805718:	00 
    7a0d12805719:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a2
    7a0d12805720:	a2 00 01 00 
    7a0d12805724:	0f 84 77 14 00 18    	je     0x7a0d2a806ba1
    7a0d1280572a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a2
    7a0d12805731:	a2 00 01 00 
    7a0d12805735:	0f 84 66 14 00 18    	je     0x7a0d2a806ba1
    7a0d1280573b:	58                   	pop    rax
    7a0d1280573c:	50                   	push   rax
    7a0d1280573d:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    7a0d12805741:	f6 c1 03             	test   cl,0x3
    7a0d12805744:	0f 85 b7 14 00 18    	jne    0x7a0d2a806c01
    7a0d1280574a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12805751:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7a0d12805755:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d1280575c:	48 89 ce             	mov    rsi,rcx
    7a0d1280575f:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12805763:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12805767:	48 85 c0             	test   rax,rax
    7a0d1280576a:	0f 84 e4 14 00 18    	je     0x7a0d2a806c54
    7a0d12805770:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805776:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12805779:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a4
    7a0d12805780:	a4 00 01 00 
    7a0d12805784:	0f 84 05 15 00 18    	je     0x7a0d2a806c8f
    7a0d1280578a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a4
    7a0d12805791:	a4 00 01 00 
    7a0d12805795:	0f 84 f4 14 00 18    	je     0x7a0d2a806c8f
    7a0d1280579b:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d1280579e:	0f 85 2c 15 00 18    	jne    0x7a0d2a806cd0
    7a0d128057a4:	58                   	pop    rax
    7a0d128057a5:	e9 0f 00 00 00       	jmp    0x7a0d128057b9
    7a0d128057aa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128057b1:	00 
    7a0d128057b2:	74 f0                	je     0x7a0d128057a4
    7a0d128057b4:	e9 7f 14 00 18       	jmp    0x7a0d2a806c38
    7a0d128057b9:	50                   	push   rax
    7a0d128057ba:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d128057be:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    7a0d128057c2:	31 d2                	xor    edx,edx
    7a0d128057c4:	31 f6                	xor    esi,esi
    7a0d128057c6:	89 cf                	mov    edi,ecx
    7a0d128057c8:	29 c7                	sub    edi,eax
    7a0d128057ca:	0f 94 c2             	sete   dl
    7a0d128057cd:	40 0f 93 c6          	setae  sil
    7a0d128057d1:	c1 ef 1f             	shr    edi,0x1f
    7a0d128057d4:	c1 e9 1f             	shr    ecx,0x1f
    7a0d128057d7:	c1 e8 1f             	shr    eax,0x1f
    7a0d128057da:	89 fb                	mov    ebx,edi
    7a0d128057dc:	31 cb                	xor    ebx,ecx
    7a0d128057de:	31 c8                	xor    eax,ecx
    7a0d128057e0:	21 d8                	and    eax,ebx
    7a0d128057e2:	31 f8                	xor    eax,edi
    7a0d128057e4:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d128057eb:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d128057f2:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128057f9:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7a0d12805800:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7a0d12805807:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a6
    7a0d1280580e:	a6 00 01 00 
    7a0d12805812:	0f 84 ea 14 00 18    	je     0x7a0d2a806d02
    7a0d12805818:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a6
    7a0d1280581f:	a6 00 01 00 
    7a0d12805823:	0f 84 d9 14 00 18    	je     0x7a0d2a806d02
    7a0d12805829:	58                   	pop    rax
    7a0d1280582a:	50                   	push   rax
    7a0d1280582b:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12805832:	00 
    7a0d12805833:	74 28                	je     0x7a0d1280585d
    7a0d12805835:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    7a0d1280583c:	a8 00 01 00 
    7a0d12805840:	0f 84 1c 15 00 18    	je     0x7a0d2a806d62
    7a0d12805846:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    7a0d1280584d:	a8 00 01 00 
    7a0d12805851:	0f 84 0b 15 00 18    	je     0x7a0d2a806d62
    7a0d12805857:	58                   	pop    rax
    7a0d12805858:	e9 55 00 00 00       	jmp    0x7a0d128058b2
    7a0d1280585d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12805864:	01 
    7a0d12805865:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    7a0d1280586c:	a8 00 01 00 
    7a0d12805870:	0f 84 35 15 00 18    	je     0x7a0d2a806dab
    7a0d12805876:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    7a0d1280587d:	a8 00 01 00 
    7a0d12805881:	0f 84 24 15 00 18    	je     0x7a0d2a806dab
    7a0d12805887:	b8 a8 00 01 00       	mov    eax,0x100a8
    7a0d1280588c:	83 c0 dc             	add    eax,0xffffffdc
    7a0d1280588f:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12805896:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280589d:	02 00 00 00 
    7a0d128058a1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d128058a8:	07 00 00 00 
    7a0d128058ac:	58                   	pop    rax
    7a0d128058ad:	e9 5b 03 00 00       	jmp    0x7a0d12805c0d
    7a0d128058b2:	50                   	push   rax
    7a0d128058b3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d128058b8:	b9 00 00 00 00       	mov    ecx,0x0
    7a0d128058bd:	09 c1                	or     ecx,eax
    7a0d128058bf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128058c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100aa
    7a0d128058ca:	aa 00 01 00 
    7a0d128058ce:	0f 84 13 15 00 18    	je     0x7a0d2a806de7
    7a0d128058d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100aa
    7a0d128058db:	aa 00 01 00 
    7a0d128058df:	0f 84 02 15 00 18    	je     0x7a0d2a806de7
    7a0d128058e5:	58                   	pop    rax
    7a0d128058e6:	50                   	push   rax
    7a0d128058e7:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    7a0d128058ee:	00 
    7a0d128058ef:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ae
    7a0d128058f6:	ae 00 01 00 
    7a0d128058fa:	0f 84 47 15 00 18    	je     0x7a0d2a806e47
    7a0d12805900:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ae
    7a0d12805907:	ae 00 01 00 
    7a0d1280590b:	0f 84 36 15 00 18    	je     0x7a0d2a806e47
    7a0d12805911:	58                   	pop    rax
    7a0d12805912:	50                   	push   rax
    7a0d12805913:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12805918:	c1 e0 10             	shl    eax,0x10
    7a0d1280591b:	b9 10 f0 00 00       	mov    ecx,0xf010
    7a0d12805920:	09 c1                	or     ecx,eax
    7a0d12805922:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12805926:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b0
    7a0d1280592d:	b0 00 01 00 
    7a0d12805931:	0f 84 70 15 00 18    	je     0x7a0d2a806ea7
    7a0d12805937:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b0
    7a0d1280593e:	b0 00 01 00 
    7a0d12805942:	0f 84 5f 15 00 18    	je     0x7a0d2a806ea7
    7a0d12805948:	58                   	pop    rax
    7a0d12805949:	50                   	push   rax
    7a0d1280594a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d1280594e:	f6 c1 03             	test   cl,0x3
    7a0d12805951:	0f 85 b0 15 00 18    	jne    0x7a0d2a806f07
    7a0d12805957:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d1280595e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12805962:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12805969:	48 89 ce             	mov    rsi,rcx
    7a0d1280596c:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12805970:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12805974:	48 85 c0             	test   rax,rax
    7a0d12805977:	0f 84 dd 15 00 18    	je     0x7a0d2a806f5a
    7a0d1280597d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805983:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12805986:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b4
    7a0d1280598d:	b4 00 01 00 
    7a0d12805991:	0f 84 fe 15 00 18    	je     0x7a0d2a806f95
    7a0d12805997:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b4
    7a0d1280599e:	b4 00 01 00 
    7a0d128059a2:	0f 84 ed 15 00 18    	je     0x7a0d2a806f95
    7a0d128059a8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d128059ab:	0f 85 25 16 00 18    	jne    0x7a0d2a806fd6
    7a0d128059b1:	58                   	pop    rax
    7a0d128059b2:	e9 0f 00 00 00       	jmp    0x7a0d128059c6
    7a0d128059b7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128059be:	00 
    7a0d128059bf:	74 f0                	je     0x7a0d128059b1
    7a0d128059c1:	e9 78 15 00 18       	jmp    0x7a0d2a806f3e
    7a0d128059c6:	50                   	push   rax
    7a0d128059c7:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d128059cb:	f6 c3 03             	test   bl,0x3
    7a0d128059ce:	0f 85 34 16 00 18    	jne    0x7a0d2a807008
    7a0d128059d4:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d128059db:	48 89 d8             	mov    rax,rbx
    7a0d128059de:	48 c1 e8 0c          	shr    rax,0xc
    7a0d128059e2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128059e7:	48 85 c0             	test   rax,rax
    7a0d128059ea:	0f 84 6a 16 00 18    	je     0x7a0d2a80705a
    7a0d128059f0:	89 d9                	mov    ecx,ebx
    7a0d128059f2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128059f8:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d128059fc:	89 de                	mov    esi,ebx
    7a0d128059fe:	83 c6 04             	add    esi,0x4
    7a0d12805a01:	89 f0                	mov    eax,esi
    7a0d12805a03:	c1 e8 0c             	shr    eax,0xc
    7a0d12805a06:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805a0b:	48 85 c0             	test   rax,rax
    7a0d12805a0e:	0f 84 83 16 00 18    	je     0x7a0d2a807097
    7a0d12805a14:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805a1a:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805a1d:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d12805a20:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d12805a24:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12805a2b:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d12805a2f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b6
    7a0d12805a36:	b6 00 01 00 
    7a0d12805a3a:	0f 84 93 16 00 18    	je     0x7a0d2a8070d3
    7a0d12805a40:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b6
    7a0d12805a47:	b6 00 01 00 
    7a0d12805a4b:	0f 84 82 16 00 18    	je     0x7a0d2a8070d3
    7a0d12805a51:	58                   	pop    rax
    7a0d12805a52:	50                   	push   rax
    7a0d12805a53:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7a0d12805a5a:	00 
    7a0d12805a5b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ba
    7a0d12805a62:	ba 00 01 00 
    7a0d12805a66:	0f 84 b0 16 00 18    	je     0x7a0d2a80711c
    7a0d12805a6c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ba
    7a0d12805a73:	ba 00 01 00 
    7a0d12805a77:	0f 84 9f 16 00 18    	je     0x7a0d2a80711c
    7a0d12805a7d:	58                   	pop    rax
    7a0d12805a7e:	50                   	push   rax
    7a0d12805a7f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12805a83:	f6 c3 03             	test   bl,0x3
    7a0d12805a86:	0f 85 f0 16 00 18    	jne    0x7a0d2a80717c
    7a0d12805a8c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12805a93:	48 89 d8             	mov    rax,rbx
    7a0d12805a96:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12805a9a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805a9f:	48 85 c0             	test   rax,rax
    7a0d12805aa2:	0f 84 26 17 00 18    	je     0x7a0d2a8071ce
    7a0d12805aa8:	89 d9                	mov    ecx,ebx
    7a0d12805aaa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805ab0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12805ab3:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7a0d12805ab7:	8d 73 04             	lea    esi,[rbx+0x4]
    7a0d12805aba:	89 f0                	mov    eax,esi
    7a0d12805abc:	c1 e8 0c             	shr    eax,0xc
    7a0d12805abf:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805ac4:	48 85 c0             	test   rax,rax
    7a0d12805ac7:	0f 84 3c 17 00 18    	je     0x7a0d2a807209
    7a0d12805acd:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805ad3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805ad6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7a0d12805ada:	8d 73 08             	lea    esi,[rbx+0x8]
    7a0d12805add:	89 f0                	mov    eax,esi
    7a0d12805adf:	c1 e8 0c             	shr    eax,0xc
    7a0d12805ae2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805ae7:	48 85 c0             	test   rax,rax
    7a0d12805aea:	0f 84 55 17 00 18    	je     0x7a0d2a807245
    7a0d12805af0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805af6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805af9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7a0d12805afd:	8d 73 0c             	lea    esi,[rbx+0xc]
    7a0d12805b00:	89 f0                	mov    eax,esi
    7a0d12805b02:	c1 e8 0c             	shr    eax,0xc
    7a0d12805b05:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805b0a:	48 85 c0             	test   rax,rax
    7a0d12805b0d:	0f 84 6e 17 00 18    	je     0x7a0d2a807281
    7a0d12805b13:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805b19:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805b1c:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12805b20:	8d 73 10             	lea    esi,[rbx+0x10]
    7a0d12805b23:	89 f0                	mov    eax,esi
    7a0d12805b25:	c1 e8 0c             	shr    eax,0xc
    7a0d12805b28:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805b2d:	48 85 c0             	test   rax,rax
    7a0d12805b30:	0f 84 87 17 00 18    	je     0x7a0d2a8072bd
    7a0d12805b36:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805b3c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805b3f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7a0d12805b43:	8d 73 14             	lea    esi,[rbx+0x14]
    7a0d12805b46:	89 f0                	mov    eax,esi
    7a0d12805b48:	c1 e8 0c             	shr    eax,0xc
    7a0d12805b4b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805b50:	48 85 c0             	test   rax,rax
    7a0d12805b53:	0f 84 a0 17 00 18    	je     0x7a0d2a8072f9
    7a0d12805b59:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805b5f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805b62:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7a0d12805b66:	89 de                	mov    esi,ebx
    7a0d12805b68:	83 c6 18             	add    esi,0x18
    7a0d12805b6b:	89 f0                	mov    eax,esi
    7a0d12805b6d:	c1 e8 0c             	shr    eax,0xc
    7a0d12805b70:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12805b75:	48 85 c0             	test   rax,rax
    7a0d12805b78:	0f 84 b7 17 00 18    	je     0x7a0d2a807335
    7a0d12805b7e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805b84:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805b87:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7a0d12805b8b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    7a0d12805b8e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7a0d12805b92:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100bc
    7a0d12805b99:	bc 00 01 00 
    7a0d12805b9d:	0f 84 ce 17 00 18    	je     0x7a0d2a807371
    7a0d12805ba3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100bc
    7a0d12805baa:	bc 00 01 00 
    7a0d12805bae:	0f 84 bd 17 00 18    	je     0x7a0d2a807371
    7a0d12805bb4:	58                   	pop    rax
    7a0d12805bb5:	50                   	push   rax
    7a0d12805bb6:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d12805bbd:	a8 01                	test   al,0x1
    7a0d12805bbf:	0f 85 f5 17 00 18    	jne    0x7a0d2a8073ba
    7a0d12805bc5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12805bcc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12805bd3:	01 
    7a0d12805bd4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100be
    7a0d12805bdb:	be 00 01 00 
    7a0d12805bdf:	0f 84 0b 18 00 18    	je     0x7a0d2a8073f0
    7a0d12805be5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100be
    7a0d12805bec:	be 00 01 00 
    7a0d12805bf0:	0f 84 fa 17 00 18    	je     0x7a0d2a8073f0
    7a0d12805bf6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12805bfd:	02 00 00 00 
    7a0d12805c01:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d12805c08:	0f 00 00 00 
    7a0d12805c0c:	58                   	pop    rax
    7a0d12805c0d:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12805c14:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12805c1b:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12805c22:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12805c29:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12805c30:	39 f1                	cmp    ecx,esi
    7a0d12805c32:	0f 83 e5 17 00 18    	jae    0x7a0d2a80741d
    7a0d12805c38:	81 fa 9c 00 01 00    	cmp    edx,0x1009c
    7a0d12805c3e:	75 14                	jne    0x7a0d12805c54
    7a0d12805c40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12805c47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12805c4e:	00 
    7a0d12805c4f:	e9 1c f9 ff ff       	jmp    0x7a0d12805570
    7a0d12805c54:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12805c5b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12805c61:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12805c64:	0f 85 b3 17 00 18    	jne    0x7a0d2a80741d
    7a0d12805c6a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12805c71:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12805c78:	00 
    7a0d12805c79:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12805c7e:	ff e0                	jmp    rax
