
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65808-0-134196563562576.bin:     file format binary


Disassembly of section .data:

00007a0d12805050 <.data>:
    7a0d12805050:	48 83 ec 28          	sub    rsp,0x28
    7a0d12805054:	b8 d1 fe fe ff       	mov    eax,0xfffefed1
    7a0d12805059:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12805060:	01 c1                	add    ecx,eax
    7a0d12805062:	83 f9 e0             	cmp    ecx,0xffffffe0
    7a0d12805065:	0f 87 47 11 00 18    	ja     0x7a0d2a8061b2
    7a0d1280506b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7a0d12805072:	83 f8 e0             	cmp    eax,0xffffffe0
    7a0d12805075:	0f 87 37 11 00 18    	ja     0x7a0d2a8061b2
    7a0d1280507b:	4d 89 f0             	mov    r8,r14
    7a0d1280507e:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7a0d12805085:	4d 8b 8d 38 01 00 00 	mov    r9,QWORD PTR [r13+0x138]
    7a0d1280508c:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    7a0d12805093:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12805097:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    7a0d1280509b:	41 89 c4             	mov    r12d,eax
    7a0d1280509e:	41 c1 ec 07          	shr    r12d,0x7
    7a0d128050a2:	31 c9                	xor    ecx,ecx
    7a0d128050a4:	41 31 c4             	xor    r12d,eax
    7a0d128050a7:	45 89 65 04          	mov    DWORD PTR [r13+0x4],r12d
    7a0d128050ab:	0f 94 c1             	sete   cl
    7a0d128050ae:	c1 e8 1f             	shr    eax,0x1f
    7a0d128050b1:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7a0d128050b8:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128050bf:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d128050c6:	00 00 00 00 
    7a0d128050ca:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d128050d1:	00 00 00 00 
    7a0d128050d5:	45 89 65 28          	mov    DWORD PTR [r13+0x28],r12d
    7a0d128050d9:	41 c7 45 24 b9 79 37 	mov    DWORD PTR [r13+0x24],0x9e3779b9
    7a0d128050e0:	9e 
    7a0d128050e1:	8d 5e fc             	lea    ebx,[rsi-0x4]
    7a0d128050e4:	40 f6 c6 03          	test   sil,0x3
    7a0d128050e8:	0f 85 d3 10 00 18    	jne    0x7a0d2a8061c1
    7a0d128050ee:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d128050f5:	45 8b 5d 3c          	mov    r11d,DWORD PTR [r13+0x3c]
    7a0d128050f9:	41 89 de             	mov    r14d,ebx
    7a0d128050fc:	41 c1 ee 0c          	shr    r14d,0xc
    7a0d12805100:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    7a0d12805104:	48 85 c0             	test   rax,rax
    7a0d12805107:	0f 84 1e 11 00 18    	je     0x7a0d2a80622b
    7a0d1280510d:	89 d9                	mov    ecx,ebx
    7a0d1280510f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805115:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12805118:	8d 6e f8             	lea    ebp,[rsi-0x8]
    7a0d1280511b:	41 89 ef             	mov    r15d,ebp
    7a0d1280511e:	41 c1 ef 0c          	shr    r15d,0xc
    7a0d12805122:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    7a0d12805126:	48 85 c0             	test   rax,rax
    7a0d12805129:	0f 84 75 11 00 18    	je     0x7a0d2a8062a4
    7a0d1280512f:	89 e9                	mov    ecx,ebp
    7a0d12805131:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805137:	44 89 1c 08          	mov    DWORD PTR [rax+rcx*1],r11d
    7a0d1280513b:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7a0d1280513f:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7a0d12805143:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    7a0d12805147:	0f 85 ce 11 00 18    	jne    0x7a0d2a80631b
    7a0d1280514d:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    7a0d12805151:	48 85 c0             	test   rax,rax
    7a0d12805154:	0f 84 39 12 00 18    	je     0x7a0d2a806393
    7a0d1280515a:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7a0d12805160:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7a0d12805163:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    7a0d12805167:	48 85 c0             	test   rax,rax
    7a0d1280516a:	0f 84 8e 12 00 18    	je     0x7a0d2a8063fe
    7a0d12805170:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    7a0d12805176:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    7a0d12805179:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7a0d1280517d:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12805184:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7a0d12805188:	43 8d 0c 64          	lea    ecx,[r12+r12*2]
    7a0d1280518c:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12805190:	43 8d 8c 64 b9 79 37 	lea    ecx,[r12+r12*2-0x61c88647]
    7a0d12805197:	9e 
    7a0d12805198:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7a0d1280519c:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    7a0d128051a0:	b1 01                	mov    cl,0x1
    7a0d128051a2:	bb 0b 00 00 00       	mov    ebx,0xb
    7a0d128051a7:	bd 02 00 00 00       	mov    ebp,0x2
    7a0d128051ac:	a8 01                	test   al,0x1
    7a0d128051ae:	0f 85 a5 12 00 18    	jne    0x7a0d2a806459
    7a0d128051b4:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7a0d128051bb:	01 da                	add    edx,ebx
    7a0d128051bd:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d128051c4:	39 f2                	cmp    edx,esi
    7a0d128051c6:	73 36                	jae    0x7a0d128051fe
    7a0d128051c8:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7a0d128051cf:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d128051d5:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    7a0d128051d8:	75 24                	jne    0x7a0d128051fe
    7a0d128051da:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128051e1:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7a0d128051e8:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128051ef:	00 
    7a0d128051f0:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    7a0d128051f5:	4d 89 c6             	mov    r14,r8
    7a0d128051f8:	48 83 c4 28          	add    rsp,0x28
    7a0d128051fc:	ff e0                	jmp    rax
    7a0d128051fe:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12805205:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    7a0d1280520c:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    7a0d12805213:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    7a0d1280521a:	48 83 c4 28          	add    rsp,0x28
    7a0d1280521e:	c2 08 00             	ret    0x8
