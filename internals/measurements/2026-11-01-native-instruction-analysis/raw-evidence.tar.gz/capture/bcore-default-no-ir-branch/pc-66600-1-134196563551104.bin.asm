
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66600-1-134196563551104.bin:     file format binary


Disassembly of section .data:

00007a0d12802380 <.data>:
    7a0d12802380:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802387:	8b 88 14 00 10 00    	mov    ecx,DWORD PTR [rax+0x100014]
    7a0d1280238d:	ff c1                	inc    ecx
    7a0d1280238f:	89 88 14 00 10 00    	mov    DWORD PTR [rax+0x100014],ecx
    7a0d12802395:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280239b:	0f 84 0f 0d 00 18    	je     0x7a0d2a8030b0
    7a0d128023a1:	50                   	push   rax
    7a0d128023a2:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d128023a7:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d128023ac:	09 c1                	or     ecx,eax
    7a0d128023ae:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128023b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10428
    7a0d128023b9:	28 04 01 00 
    7a0d128023bd:	0f 84 19 0d 00 18    	je     0x7a0d2a8030dc
    7a0d128023c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10428
    7a0d128023ca:	28 04 01 00 
    7a0d128023ce:	0f 84 08 0d 00 18    	je     0x7a0d2a8030dc
    7a0d128023d4:	58                   	pop    rax
    7a0d128023d5:	50                   	push   rax
    7a0d128023d6:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d128023da:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d128023dd:	f6 c3 03             	test   bl,0x3
    7a0d128023e0:	0f 85 56 0d 00 18    	jne    0x7a0d2a80313c
    7a0d128023e6:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d128023ed:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d128023f4:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d128023f8:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d128023ff:	89 c8                	mov    eax,ecx
    7a0d12802401:	c1 e8 0c             	shr    eax,0xc
    7a0d12802404:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802409:	48 85 c0             	test   rax,rax
    7a0d1280240c:	0f 84 7d 0d 00 18    	je     0x7a0d2a80318f
    7a0d12802412:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802418:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d1280241b:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d1280241e:	89 d8                	mov    eax,ebx
    7a0d12802420:	c1 e8 0c             	shr    eax,0xc
    7a0d12802423:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802428:	48 85 c0             	test   rax,rax
    7a0d1280242b:	0f 84 99 0d 00 18    	je     0x7a0d2a8031ca
    7a0d12802431:	89 d9                	mov    ecx,ebx
    7a0d12802433:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802439:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d1280243d:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d12802441:	b8 00 00 00 00       	mov    eax,0x0
    7a0d12802446:	29 c3                	sub    ebx,eax
    7a0d12802448:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d1280244c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1042c
    7a0d12802453:	2c 04 01 00 
    7a0d12802457:	0f 84 ae 0d 00 18    	je     0x7a0d2a80320b
    7a0d1280245d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1042c
    7a0d12802464:	2c 04 01 00 
    7a0d12802468:	0f 84 9d 0d 00 18    	je     0x7a0d2a80320b
    7a0d1280246e:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12802472:	0f 85 d5 0d 00 18    	jne    0x7a0d2a80324d
    7a0d12802478:	58                   	pop    rax
    7a0d12802479:	e9 0f 00 00 00       	jmp    0x7a0d1280248d
    7a0d1280247e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12802485:	00 
    7a0d12802486:	74 f0                	je     0x7a0d12802478
    7a0d12802488:	e9 e6 0c 00 18       	jmp    0x7a0d2a803173
    7a0d1280248d:	50                   	push   rax
    7a0d1280248e:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12802493:	c1 e0 10             	shl    eax,0x10
    7a0d12802496:	b9 f0 12 00 00       	mov    ecx,0x12f0
    7a0d1280249b:	09 c1                	or     ecx,eax
    7a0d1280249d:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128024a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10430
    7a0d128024a8:	30 04 01 00 
    7a0d128024ac:	0f 84 cd 0d 00 18    	je     0x7a0d2a80327f
    7a0d128024b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10430
    7a0d128024b9:	30 04 01 00 
    7a0d128024bd:	0f 84 bc 0d 00 18    	je     0x7a0d2a80327f
    7a0d128024c3:	58                   	pop    rax
    7a0d128024c4:	50                   	push   rax
    7a0d128024c5:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d128024c9:	f6 c1 03             	test   cl,0x3
    7a0d128024cc:	0f 85 0d 0e 00 18    	jne    0x7a0d2a8032df
    7a0d128024d2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d128024d9:	48 89 ca             	mov    rdx,rcx
    7a0d128024dc:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d128024e0:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d128024e4:	48 85 c0             	test   rax,rax
    7a0d128024e7:	0f 84 42 0e 00 18    	je     0x7a0d2a80332f
    7a0d128024ed:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128024f3:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d128024f6:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d128024fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10434
    7a0d12802501:	34 04 01 00 
    7a0d12802505:	0f 84 5f 0e 00 18    	je     0x7a0d2a80336a
    7a0d1280250b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10434
    7a0d12802512:	34 04 01 00 
    7a0d12802516:	0f 84 4e 0e 00 18    	je     0x7a0d2a80336a
    7a0d1280251c:	58                   	pop    rax
    7a0d1280251d:	50                   	push   rax
    7a0d1280251e:	31 c0                	xor    eax,eax
    7a0d12802520:	41 83 7d 28 05       	cmp    DWORD PTR [r13+0x28],0x5
    7a0d12802525:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d1280252c:	0f 92 c0             	setb   al
    7a0d1280252f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    7a0d12802536:	81 f9 36 04 01 00    	cmp    ecx,0x10436
    7a0d1280253c:	0f 84 71 0e 00 18    	je     0x7a0d2a8033b3
    7a0d12802542:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10436
    7a0d12802549:	36 04 01 00 
    7a0d1280254d:	0f 84 60 0e 00 18    	je     0x7a0d2a8033b3
    7a0d12802553:	58                   	pop    rax
    7a0d12802554:	50                   	push   rax
    7a0d12802555:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d1280255c:	00 
    7a0d1280255d:	74 55                	je     0x7a0d128025b4
    7a0d1280255f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12802566:	01 
    7a0d12802567:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    7a0d1280256e:	38 04 01 00 
    7a0d12802572:	0f 84 9b 0e 00 18    	je     0x7a0d2a803413
    7a0d12802578:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    7a0d1280257f:	38 04 01 00 
    7a0d12802583:	0f 84 8a 0e 00 18    	je     0x7a0d2a803413
    7a0d12802589:	b8 38 04 01 00       	mov    eax,0x10438
    7a0d1280258e:	83 c0 0a             	add    eax,0xa
    7a0d12802591:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12802598:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280259f:	02 00 00 00 
    7a0d128025a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d128025aa:	06 00 00 00 
    7a0d128025ae:	58                   	pop    rax
    7a0d128025af:	e9 33 01 00 00       	jmp    0x7a0d128026e7
    7a0d128025b4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    7a0d128025bb:	38 04 01 00 
    7a0d128025bf:	0f 84 8a 0e 00 18    	je     0x7a0d2a80344f
    7a0d128025c5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    7a0d128025cc:	38 04 01 00 
    7a0d128025d0:	0f 84 79 0e 00 18    	je     0x7a0d2a80344f
    7a0d128025d6:	58                   	pop    rax
    7a0d128025d7:	50                   	push   rax
    7a0d128025d8:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7a0d128025df:	00 
    7a0d128025e0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043a
    7a0d128025e7:	3a 04 01 00 
    7a0d128025eb:	0f 84 a7 0e 00 18    	je     0x7a0d2a803498
    7a0d128025f1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043a
    7a0d128025f8:	3a 04 01 00 
    7a0d128025fc:	0f 84 96 0e 00 18    	je     0x7a0d2a803498
    7a0d12802602:	58                   	pop    rax
    7a0d12802603:	50                   	push   rax
    7a0d12802604:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d12802608:	f6 c3 03             	test   bl,0x3
    7a0d1280260b:	0f 85 e7 0e 00 18    	jne    0x7a0d2a8034f8
    7a0d12802611:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12802618:	48 89 d8             	mov    rax,rbx
    7a0d1280261b:	48 c1 e8 0c          	shr    rax,0xc
    7a0d1280261f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802624:	48 85 c0             	test   rax,rax
    7a0d12802627:	0f 84 1d 0f 00 18    	je     0x7a0d2a80354a
    7a0d1280262d:	89 d9                	mov    ecx,ebx
    7a0d1280262f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12802635:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d12802639:	89 de                	mov    esi,ebx
    7a0d1280263b:	83 c6 04             	add    esi,0x4
    7a0d1280263e:	89 f0                	mov    eax,esi
    7a0d12802640:	c1 e8 0c             	shr    eax,0xc
    7a0d12802643:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12802648:	48 85 c0             	test   rax,rax
    7a0d1280264b:	0f 84 36 0f 00 18    	je     0x7a0d2a803587
    7a0d12802651:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12802657:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d1280265a:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d1280265d:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d12802661:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12802668:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d1280266c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043c
    7a0d12802673:	3c 04 01 00 
    7a0d12802677:	0f 84 46 0f 00 18    	je     0x7a0d2a8035c3
    7a0d1280267d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043c
    7a0d12802684:	3c 04 01 00 
    7a0d12802688:	0f 84 35 0f 00 18    	je     0x7a0d2a8035c3
    7a0d1280268e:	58                   	pop    rax
    7a0d1280268f:	50                   	push   rax
    7a0d12802690:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d12802697:	a8 01                	test   al,0x1
    7a0d12802699:	0f 85 6d 0f 00 18    	jne    0x7a0d2a80360c
    7a0d1280269f:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128026a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128026ad:	01 
    7a0d128026ae:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10440
    7a0d128026b5:	40 04 01 00 
    7a0d128026b9:	0f 84 83 0f 00 18    	je     0x7a0d2a803642
    7a0d128026bf:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10440
    7a0d128026c6:	40 04 01 00 
    7a0d128026ca:	0f 84 72 0f 00 18    	je     0x7a0d2a803642
    7a0d128026d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d128026d7:	02 00 00 00 
    7a0d128026db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d128026e2:	09 00 00 00 
    7a0d128026e6:	58                   	pop    rax
    7a0d128026e7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128026ee:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d128026f5:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d128026fc:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12802703:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d1280270a:	39 f1                	cmp    ecx,esi
    7a0d1280270c:	0f 83 5d 0f 00 18    	jae    0x7a0d2a80366f
    7a0d12802712:	81 fa 28 04 01 00    	cmp    edx,0x10428
    7a0d12802718:	75 14                	jne    0x7a0d1280272e
    7a0d1280271a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802721:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802728:	00 
    7a0d12802729:	e9 52 fc ff ff       	jmp    0x7a0d12802380
    7a0d1280272e:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12802735:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d1280273b:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d1280273e:	0f 85 2b 0f 00 18    	jne    0x7a0d2a80366f
    7a0d12802744:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280274b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802752:	00 
    7a0d12802753:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12802758:	ff e0                	jmp    rax
