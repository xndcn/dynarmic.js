
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65840-1-134196966213872.bin:     file format binary


Disassembly of section .data:

00007a0d2a8048f0 <.data>:
    7a0d2a8048f0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a8048f6:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a8048f9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a8048ff:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a804906:	0f 87 a5 ed ff e7    	ja     0x7a0d128036b1
    7a0d2a80490c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xb
    7a0d2a804913:	0b 00 00 00 
    7a0d2a804917:	e9 95 ed ff e7       	jmp    0x7a0d128036b1
    7a0d2a80491c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d2a804923:	30 01 01 00 
    7a0d2a804927:	b8 30 01 01 00       	mov    eax,0x10130
    7a0d2a80492c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804933:	04 00 00 00 
    7a0d2a804937:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80493e:	01 00 00 00 
    7a0d2a804942:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804945:	be 30 01 01 00       	mov    esi,0x10130
    7a0d2a80494a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80494d:	e8 0e b8 ff e7       	call   0x7a0d12800160
    7a0d2a804952:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804959:	00 
    7a0d2a80495a:	0f 84 a6 ed ff e7    	je     0x7a0d12803706
    7a0d2a804960:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804967:	04 00 00 00 
    7a0d2a80496b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a804972:	01 00 00 00 
    7a0d2a804976:	58                   	pop    rax
    7a0d2a804977:	e9 d0 f0 ff e7       	jmp    0x7a0d12803a4c
    7a0d2a80497c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10134
    7a0d2a804983:	34 01 01 00 
    7a0d2a804987:	b8 34 01 01 00       	mov    eax,0x10134
    7a0d2a80498c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804993:	02 00 00 00 
    7a0d2a804997:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80499e:	02 00 00 00 
    7a0d2a8049a2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8049a5:	be 34 01 01 00       	mov    esi,0x10134
    7a0d2a8049aa:	4c 89 ef             	mov    rdi,r13
    7a0d2a8049ad:	e8 ae b7 ff e7       	call   0x7a0d12800160
    7a0d2a8049b2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8049b9:	00 
    7a0d2a8049ba:	0f 84 a0 ed ff e7    	je     0x7a0d12803760
    7a0d2a8049c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8049c7:	02 00 00 00 
    7a0d2a8049cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8049d2:	02 00 00 00 
    7a0d2a8049d6:	58                   	pop    rax
    7a0d2a8049d7:	e9 70 f0 ff e7       	jmp    0x7a0d12803a4c
    7a0d2a8049dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10136
    7a0d2a8049e3:	36 01 01 00 
    7a0d2a8049e7:	b8 36 01 01 00       	mov    eax,0x10136
    7a0d2a8049ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8049f3:	02 00 00 00 
    7a0d2a8049f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8049fe:	03 00 00 00 
    7a0d2a804a02:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804a05:	be 36 01 01 00       	mov    esi,0x10136
    7a0d2a804a0a:	4c 89 ef             	mov    rdi,r13
    7a0d2a804a0d:	e8 4e b7 ff e7       	call   0x7a0d12800160
    7a0d2a804a12:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804a19:	00 
    7a0d2a804a1a:	0f 84 9e ed ff e7    	je     0x7a0d128037be
    7a0d2a804a20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804a27:	02 00 00 00 
    7a0d2a804a2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804a32:	03 00 00 00 
    7a0d2a804a36:	58                   	pop    rax
    7a0d2a804a37:	e9 10 f0 ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804a3c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10138
    7a0d2a804a43:	38 01 01 00 
    7a0d2a804a47:	b8 38 01 01 00       	mov    eax,0x10138
    7a0d2a804a4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804a53:	04 00 00 00 
    7a0d2a804a57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a804a5e:	04 00 00 00 
    7a0d2a804a62:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804a65:	be 38 01 01 00       	mov    esi,0x10138
    7a0d2a804a6a:	4c 89 ef             	mov    rdi,r13
    7a0d2a804a6d:	e8 ee b6 ff e7       	call   0x7a0d12800160
    7a0d2a804a72:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804a79:	00 
    7a0d2a804a7a:	0f 84 72 ed ff e7    	je     0x7a0d128037f2
    7a0d2a804a80:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804a87:	04 00 00 00 
    7a0d2a804a8b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a804a92:	04 00 00 00 
    7a0d2a804a96:	58                   	pop    rax
    7a0d2a804a97:	e9 b0 ef ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804a9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a804aa3:	3c 01 01 00 
    7a0d2a804aa7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804aae:	04 00 00 00 
    7a0d2a804ab2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804ab9:	05 00 00 00 
    7a0d2a804abd:	ba 3c 01 01 00       	mov    edx,0x1013c
    7a0d2a804ac2:	4c 89 ef             	mov    rdi,r13
    7a0d2a804ac5:	4c 89 f6             	mov    rsi,r14
    7a0d2a804ac8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a804ace:	e8 ad b5 ff e7       	call   0x7a0d12800080
    7a0d2a804ad3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804ada:	04 00 00 00 
    7a0d2a804ade:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804ae5:	05 00 00 00 
    7a0d2a804ae9:	58                   	pop    rax
    7a0d2a804aea:	e9 5d ef ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804aef:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a804af6:	3c 01 01 00 
    7a0d2a804afa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804b01:	04 00 00 00 
    7a0d2a804b05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804b0c:	05 00 00 00 
    7a0d2a804b10:	4c 89 f7             	mov    rdi,r14
    7a0d2a804b13:	89 ce                	mov    esi,ecx
    7a0d2a804b15:	e8 56 b5 ff e7       	call   0x7a0d12800070
    7a0d2a804b1a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804b21:	00 
    7a0d2a804b22:	0f 84 11 ed ff e7    	je     0x7a0d12803839
    7a0d2a804b28:	eb a9                	jmp    0x7a0d2a804ad3
    7a0d2a804b2a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a804b31:	3c 01 01 00 
    7a0d2a804b35:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804b3c:	04 00 00 00 
    7a0d2a804b40:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804b47:	05 00 00 00 
    7a0d2a804b4b:	4c 89 f7             	mov    rdi,r14
    7a0d2a804b4e:	89 de                	mov    esi,ebx
    7a0d2a804b50:	44 89 e2             	mov    edx,r12d
    7a0d2a804b53:	e8 18 b5 ff e7       	call   0x7a0d12800070
    7a0d2a804b58:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804b5f:	00 
    7a0d2a804b60:	0f 84 f5 ec ff e7    	je     0x7a0d1280385b
    7a0d2a804b66:	e9 68 ff ff ff       	jmp    0x7a0d2a804ad3
    7a0d2a804b6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    7a0d2a804b72:	3c 01 01 00 
    7a0d2a804b76:	b8 3c 01 01 00       	mov    eax,0x1013c
    7a0d2a804b7b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804b82:	04 00 00 00 
    7a0d2a804b86:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804b8d:	05 00 00 00 
    7a0d2a804b91:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804b94:	be 3c 01 01 00       	mov    esi,0x1013c
    7a0d2a804b99:	4c 89 ef             	mov    rdi,r13
    7a0d2a804b9c:	e8 bf b5 ff e7       	call   0x7a0d12800160
    7a0d2a804ba1:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a804ba5:	0f 84 f1 ec ff e7    	je     0x7a0d1280389c
    7a0d2a804bab:	eb 0f                	jmp    0x7a0d2a804bbc
    7a0d2a804bad:	b8 3c 01 01 00       	mov    eax,0x1013c
    7a0d2a804bb2:	83 c0 04             	add    eax,0x4
    7a0d2a804bb5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a804bbc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804bc3:	04 00 00 00 
    7a0d2a804bc7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804bce:	05 00 00 00 
    7a0d2a804bd2:	4c 89 ef             	mov    rdi,r13
    7a0d2a804bd5:	e8 76 b5 ff e7       	call   0x7a0d12800150
    7a0d2a804bda:	e9 bd ec ff e7       	jmp    0x7a0d1280389c
    7a0d2a804bdf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10140
    7a0d2a804be6:	40 01 01 00 
    7a0d2a804bea:	b8 40 01 01 00       	mov    eax,0x10140
    7a0d2a804bef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804bf6:	04 00 00 00 
    7a0d2a804bfa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a804c01:	06 00 00 00 
    7a0d2a804c05:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804c08:	be 40 01 01 00       	mov    esi,0x10140
    7a0d2a804c0d:	4c 89 ef             	mov    rdi,r13
    7a0d2a804c10:	e8 4b b5 ff e7       	call   0x7a0d12800160
    7a0d2a804c15:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804c1c:	00 
    7a0d2a804c1d:	0f 84 be ec ff e7    	je     0x7a0d128038e1
    7a0d2a804c23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804c2a:	04 00 00 00 
    7a0d2a804c2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a804c35:	06 00 00 00 
    7a0d2a804c39:	58                   	pop    rax
    7a0d2a804c3a:	e9 0d ee ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804c3f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10144
    7a0d2a804c46:	44 01 01 00 
    7a0d2a804c4a:	b8 44 01 01 00       	mov    eax,0x10144
    7a0d2a804c4f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804c56:	02 00 00 00 
    7a0d2a804c5a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a804c61:	07 00 00 00 
    7a0d2a804c65:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804c68:	be 44 01 01 00       	mov    esi,0x10144
    7a0d2a804c6d:	4c 89 ef             	mov    rdi,r13
    7a0d2a804c70:	e8 eb b4 ff e7       	call   0x7a0d12800160
    7a0d2a804c75:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804c7c:	00 
    7a0d2a804c7d:	0f 84 e4 ec ff e7    	je     0x7a0d12803967
    7a0d2a804c83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804c8a:	02 00 00 00 
    7a0d2a804c8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a804c95:	07 00 00 00 
    7a0d2a804c99:	58                   	pop    rax
    7a0d2a804c9a:	e9 ad ed ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804c9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a804ca6:	46 01 01 00 
    7a0d2a804caa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804cb1:	04 00 00 00 
    7a0d2a804cb5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a804cbc:	08 00 00 00 
    7a0d2a804cc0:	ba 46 01 01 00       	mov    edx,0x10146
    7a0d2a804cc5:	4c 89 ef             	mov    rdi,r13
    7a0d2a804cc8:	4c 89 f6             	mov    rsi,r14
    7a0d2a804ccb:	89 d9                	mov    ecx,ebx
    7a0d2a804ccd:	45 31 c0             	xor    r8d,r8d
    7a0d2a804cd0:	e8 ab b3 ff e7       	call   0x7a0d12800080
    7a0d2a804cd5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804cdc:	04 00 00 00 
    7a0d2a804ce0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a804ce7:	08 00 00 00 
    7a0d2a804ceb:	58                   	pop    rax
    7a0d2a804cec:	e9 5b ed ff e7       	jmp    0x7a0d12803a4c
    7a0d2a804cf1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a804cf8:	46 01 01 00 
    7a0d2a804cfc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804d03:	04 00 00 00 
    7a0d2a804d07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a804d0e:	08 00 00 00 
    7a0d2a804d12:	4c 89 f7             	mov    rdi,r14
    7a0d2a804d15:	89 de                	mov    esi,ebx
    7a0d2a804d17:	e8 24 b3 ff e7       	call   0x7a0d12800040
    7a0d2a804d1c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804d23:	00 
    7a0d2a804d24:	75 af                	jne    0x7a0d2a804cd5
    7a0d2a804d26:	41 89 c7             	mov    r15d,eax
    7a0d2a804d29:	e9 70 ec ff e7       	jmp    0x7a0d1280399e
    7a0d2a804d2e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a804d35:	46 01 01 00 
    7a0d2a804d39:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804d40:	04 00 00 00 
    7a0d2a804d44:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a804d4b:	08 00 00 00 
    7a0d2a804d4f:	4c 89 f7             	mov    rdi,r14
    7a0d2a804d52:	e8 e9 b2 ff e7       	call   0x7a0d12800040
    7a0d2a804d57:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804d5e:	00 
    7a0d2a804d5f:	0f 84 5a ec ff e7    	je     0x7a0d128039bf
    7a0d2a804d65:	e9 6b ff ff ff       	jmp    0x7a0d2a804cd5
    7a0d2a804d6a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    7a0d2a804d71:	46 01 01 00 
    7a0d2a804d75:	b8 46 01 01 00       	mov    eax,0x10146
    7a0d2a804d7a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a804d81:	04 00 00 00 
    7a0d2a804d85:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a804d8c:	08 00 00 00 
    7a0d2a804d90:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a804d93:	be 46 01 01 00       	mov    esi,0x10146
    7a0d2a804d98:	4c 89 ef             	mov    rdi,r13
    7a0d2a804d9b:	e8 c0 b3 ff e7       	call   0x7a0d12800160
    7a0d2a804da0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804da7:	00 
    7a0d2a804da8:	0f 84 45 ec ff e7    	je     0x7a0d128039f3
    7a0d2a804dae:	e9 22 ff ff ff       	jmp    0x7a0d2a804cd5
    7a0d2a804db3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014a
    7a0d2a804dba:	4a 01 01 00 
    7a0d2a804dbe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804dc5:	02 00 00 00 
    7a0d2a804dc9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a804dd0:	09 00 00 00 
    7a0d2a804dd4:	4c 89 ef             	mov    rdi,r13
    7a0d2a804dd7:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a804ddc:	4c 89 f2             	mov    rdx,r14
    7a0d2a804ddf:	e8 ac b2 ff e7       	call   0x7a0d12800090
    7a0d2a804de4:	e9 4c ec ff e7       	jmp    0x7a0d12803a35
    7a0d2a804de9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804df0:	02 00 00 00 
    7a0d2a804df4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a804dfb:	09 00 00 00 
    7a0d2a804dff:	be 4a 01 01 00       	mov    esi,0x1014a
    7a0d2a804e04:	ba 4a 01 01 00       	mov    edx,0x1014a
    7a0d2a804e09:	4c 89 ef             	mov    rdi,r13
    7a0d2a804e0c:	e8 4f b3 ff e7       	call   0x7a0d12800160
    7a0d2a804e11:	e9 1f ec ff e7       	jmp    0x7a0d12803a35
    7a0d2a804e16:	c2 08 00             	ret    0x8
