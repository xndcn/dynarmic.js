
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66344-1-134196563547328.bin:     file format binary


Disassembly of section .data:

00007a0d128014c0 <.data>:
    7a0d128014c0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128014c7:	8b 88 0c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10000c]
    7a0d128014cd:	ff c1                	inc    ecx
    7a0d128014cf:	89 88 0c 00 10 00    	mov    DWORD PTR [rax+0x10000c],ecx
    7a0d128014d5:	81 f9 c1 c5 00 00    	cmp    ecx,0xc5c1
    7a0d128014db:	0f 84 ff 07 00 18    	je     0x7a0d2a801ce0
    7a0d128014e1:	50                   	push   rax
    7a0d128014e2:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d128014e6:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d128014e9:	f6 c3 03             	test   bl,0x3
    7a0d128014ec:	0f 85 1a 08 00 18    	jne    0x7a0d2a801d0c
    7a0d128014f2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d128014f9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12801500:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7a0d12801504:	89 c8                	mov    eax,ecx
    7a0d12801506:	c1 e8 0c             	shr    eax,0xc
    7a0d12801509:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280150e:	48 85 c0             	test   rax,rax
    7a0d12801511:	0f 84 48 08 00 18    	je     0x7a0d2a801d5f
    7a0d12801517:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280151d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801520:	8d 73 f8             	lea    esi,[rbx-0x8]
    7a0d12801523:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7a0d12801527:	89 f0                	mov    eax,esi
    7a0d12801529:	c1 e8 0c             	shr    eax,0xc
    7a0d1280152c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801531:	48 85 c0             	test   rax,rax
    7a0d12801534:	0f 84 60 08 00 18    	je     0x7a0d2a801d9a
    7a0d1280153a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801540:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12801543:	8d 73 f4             	lea    esi,[rbx-0xc]
    7a0d12801546:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    7a0d1280154a:	89 f0                	mov    eax,esi
    7a0d1280154c:	c1 e8 0c             	shr    eax,0xc
    7a0d1280154f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801554:	48 85 c0             	test   rax,rax
    7a0d12801557:	0f 84 79 08 00 18    	je     0x7a0d2a801dd6
    7a0d1280155d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801563:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12801566:	8d 73 f0             	lea    esi,[rbx-0x10]
    7a0d12801569:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    7a0d1280156d:	89 f0                	mov    eax,esi
    7a0d1280156f:	c1 e8 0c             	shr    eax,0xc
    7a0d12801572:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801577:	48 85 c0             	test   rax,rax
    7a0d1280157a:	0f 84 92 08 00 18    	je     0x7a0d2a801e12
    7a0d12801580:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801586:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7a0d12801589:	83 c3 ec             	add    ebx,0xffffffec
    7a0d1280158c:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7a0d12801590:	89 d8                	mov    eax,ebx
    7a0d12801592:	c1 e8 0c             	shr    eax,0xc
    7a0d12801595:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280159a:	48 85 c0             	test   rax,rax
    7a0d1280159d:	0f 84 ab 08 00 18    	je     0x7a0d2a801e4e
    7a0d128015a3:	89 d9                	mov    ecx,ebx
    7a0d128015a5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128015ab:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d128015ae:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d128015b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10328
    7a0d128015b9:	28 03 01 00 
    7a0d128015bd:	0f 84 c9 08 00 18    	je     0x7a0d2a801e8c
    7a0d128015c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10328
    7a0d128015ca:	28 03 01 00 
    7a0d128015ce:	0f 84 b8 08 00 18    	je     0x7a0d2a801e8c
    7a0d128015d4:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d128015d8:	0f 85 f0 08 00 18    	jne    0x7a0d2a801ece
    7a0d128015de:	58                   	pop    rax
    7a0d128015df:	e9 0f 00 00 00       	jmp    0x7a0d128015f3
    7a0d128015e4:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128015eb:	00 
    7a0d128015ec:	74 f0                	je     0x7a0d128015de
    7a0d128015ee:	e9 50 07 00 18       	jmp    0x7a0d2a801d43
    7a0d128015f3:	50                   	push   rax
    7a0d128015f4:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d128015f8:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7a0d128015fb:	f6 c3 03             	test   bl,0x3
    7a0d128015fe:	0f 85 fc 08 00 18    	jne    0x7a0d2a801f00
    7a0d12801604:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7a0d1280160b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12801612:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    7a0d12801616:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7a0d1280161d:	89 c8                	mov    eax,ecx
    7a0d1280161f:	c1 e8 0c             	shr    eax,0xc
    7a0d12801622:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801627:	48 85 c0             	test   rax,rax
    7a0d1280162a:	0f 84 23 09 00 18    	je     0x7a0d2a801f53
    7a0d12801630:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801636:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801639:	83 c3 f8             	add    ebx,0xfffffff8
    7a0d1280163c:	89 d8                	mov    eax,ebx
    7a0d1280163e:	c1 e8 0c             	shr    eax,0xc
    7a0d12801641:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801646:	48 85 c0             	test   rax,rax
    7a0d12801649:	0f 84 3f 09 00 18    	je     0x7a0d2a801f8e
    7a0d1280164f:	89 d9                	mov    ecx,ebx
    7a0d12801651:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801657:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7a0d1280165b:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d1280165f:	b8 00 00 00 00       	mov    eax,0x0
    7a0d12801664:	29 c3                	sub    ebx,eax
    7a0d12801666:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7a0d1280166a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1032a
    7a0d12801671:	2a 03 01 00 
    7a0d12801675:	0f 84 54 09 00 18    	je     0x7a0d2a801fcf
    7a0d1280167b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032a
    7a0d12801682:	2a 03 01 00 
    7a0d12801686:	0f 84 43 09 00 18    	je     0x7a0d2a801fcf
    7a0d1280168c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d12801690:	0f 85 7b 09 00 18    	jne    0x7a0d2a802011
    7a0d12801696:	58                   	pop    rax
    7a0d12801697:	e9 0f 00 00 00       	jmp    0x7a0d128016ab
    7a0d1280169c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128016a3:	00 
    7a0d128016a4:	74 f0                	je     0x7a0d12801696
    7a0d128016a6:	e9 8c 08 00 18       	jmp    0x7a0d2a801f37
    7a0d128016ab:	50                   	push   rax
    7a0d128016ac:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d128016b0:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128016b7:	31 d2                	xor    edx,edx
    7a0d128016b9:	83 f8 05             	cmp    eax,0x5
    7a0d128016bc:	0f 92 c2             	setb   dl
    7a0d128016bf:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d128016c6:	31 d2                	xor    edx,edx
    7a0d128016c8:	31 f6                	xor    esi,esi
    7a0d128016ca:	31 ff                	xor    edi,edi
    7a0d128016cc:	83 f8 04             	cmp    eax,0x4
    7a0d128016cf:	0f 94 c2             	sete   dl
    7a0d128016d2:	40 0f 92 c6          	setb   sil
    7a0d128016d6:	40 0f 93 c7          	setae  dil
    7a0d128016da:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d128016e1:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7a0d128016e8:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d128016ef:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d128016f6:	81 f9 2e 03 01 00    	cmp    ecx,0x1032e
    7a0d128016fc:	0f 84 41 09 00 18    	je     0x7a0d2a802043
    7a0d12801702:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032e
    7a0d12801709:	2e 03 01 00 
    7a0d1280170d:	0f 84 30 09 00 18    	je     0x7a0d2a802043
    7a0d12801713:	58                   	pop    rax
    7a0d12801714:	50                   	push   rax
    7a0d12801715:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d1280171c:	00 
    7a0d1280171d:	74 28                	je     0x7a0d12801747
    7a0d1280171f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    7a0d12801726:	30 03 01 00 
    7a0d1280172a:	0f 84 73 09 00 18    	je     0x7a0d2a8020a3
    7a0d12801730:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    7a0d12801737:	30 03 01 00 
    7a0d1280173b:	0f 84 62 09 00 18    	je     0x7a0d2a8020a3
    7a0d12801741:	58                   	pop    rax
    7a0d12801742:	e9 55 00 00 00       	jmp    0x7a0d1280179c
    7a0d12801747:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d1280174e:	01 
    7a0d1280174f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    7a0d12801756:	30 03 01 00 
    7a0d1280175a:	0f 84 8c 09 00 18    	je     0x7a0d2a8020ec
    7a0d12801760:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    7a0d12801767:	30 03 01 00 
    7a0d1280176b:	0f 84 7b 09 00 18    	je     0x7a0d2a8020ec
    7a0d12801771:	b8 30 03 01 00       	mov    eax,0x10330
    7a0d12801776:	83 c0 40             	add    eax,0x40
    7a0d12801779:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12801780:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12801787:	02 00 00 00 
    7a0d1280178b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d12801792:	04 00 00 00 
    7a0d12801796:	58                   	pop    rax
    7a0d12801797:	e9 d3 08 00 00       	jmp    0x7a0d1280206f
    7a0d1280179c:	50                   	push   rax
    7a0d1280179d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d128017a1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128017a8:	31 d2                	xor    edx,edx
    7a0d128017aa:	85 c0                	test   eax,eax
    7a0d128017ac:	0f 94 c2             	sete   dl
    7a0d128017af:	c1 e8 1f             	shr    eax,0x1f
    7a0d128017b2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d128017b9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d128017c0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128017c7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d128017ce:	00 00 00 
    7a0d128017d1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d128017d8:	81 f9 32 03 01 00    	cmp    ecx,0x10332
    7a0d128017de:	0f 84 44 09 00 18    	je     0x7a0d2a802128
    7a0d128017e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10332
    7a0d128017eb:	32 03 01 00 
    7a0d128017ef:	0f 84 33 09 00 18    	je     0x7a0d2a802128
    7a0d128017f5:	58                   	pop    rax
    7a0d128017f6:	50                   	push   rax
    7a0d128017f7:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d128017fe:	00 
    7a0d128017ff:	74 55                	je     0x7a0d12801856
    7a0d12801801:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12801808:	01 
    7a0d12801809:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    7a0d12801810:	34 03 01 00 
    7a0d12801814:	0f 84 6e 09 00 18    	je     0x7a0d2a802188
    7a0d1280181a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    7a0d12801821:	34 03 01 00 
    7a0d12801825:	0f 84 5d 09 00 18    	je     0x7a0d2a802188
    7a0d1280182b:	b8 34 03 01 00       	mov    eax,0x10334
    7a0d12801830:	83 c0 3c             	add    eax,0x3c
    7a0d12801833:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280183a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12801841:	02 00 00 00 
    7a0d12801845:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d1280184c:	06 00 00 00 
    7a0d12801850:	58                   	pop    rax
    7a0d12801851:	e9 19 08 00 00       	jmp    0x7a0d1280206f
    7a0d12801856:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    7a0d1280185d:	34 03 01 00 
    7a0d12801861:	0f 84 5d 09 00 18    	je     0x7a0d2a8021c4
    7a0d12801867:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    7a0d1280186e:	34 03 01 00 
    7a0d12801872:	0f 84 4c 09 00 18    	je     0x7a0d2a8021c4
    7a0d12801878:	58                   	pop    rax
    7a0d12801879:	50                   	push   rax
    7a0d1280187a:	41 c7 45 0c 09 3d 00 	mov    DWORD PTR [r13+0xc],0x3d09
    7a0d12801881:	00 
    7a0d12801882:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10336
    7a0d12801889:	36 03 01 00 
    7a0d1280188d:	0f 84 7a 09 00 18    	je     0x7a0d2a80220d
    7a0d12801893:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10336
    7a0d1280189a:	36 03 01 00 
    7a0d1280189e:	0f 84 69 09 00 18    	je     0x7a0d2a80220d
    7a0d128018a4:	58                   	pop    rax
    7a0d128018a5:	50                   	push   rax
    7a0d128018a6:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    7a0d128018aa:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128018b1:	31 d2                	xor    edx,edx
    7a0d128018b3:	c1 e0 0b             	shl    eax,0xb
    7a0d128018b6:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    7a0d128018ba:	0f 94 c2             	sete   dl
    7a0d128018bd:	c1 e8 1f             	shr    eax,0x1f
    7a0d128018c0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d128018c7:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d128018ce:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d128018d5:	00 00 00 00 
    7a0d128018d9:	81 f9 3a 03 01 00    	cmp    ecx,0x1033a
    7a0d128018df:	0f 84 88 09 00 18    	je     0x7a0d2a80226d
    7a0d128018e5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033a
    7a0d128018ec:	3a 03 01 00 
    7a0d128018f0:	0f 84 77 09 00 18    	je     0x7a0d2a80226d
    7a0d128018f6:	58                   	pop    rax
    7a0d128018f7:	50                   	push   rax
    7a0d128018f8:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7a0d128018fc:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    7a0d12801900:	31 d2                	xor    edx,edx
    7a0d12801902:	31 f6                	xor    esi,esi
    7a0d12801904:	31 ff                	xor    edi,edi
    7a0d12801906:	31 db                	xor    ebx,ebx
    7a0d12801908:	39 c8                	cmp    eax,ecx
    7a0d1280190a:	0f 96 c2             	setbe  dl
    7a0d1280190d:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12801914:	40 0f 94 c6          	sete   sil
    7a0d12801918:	40 0f 92 c7          	setb   dil
    7a0d1280191c:	0f 93 c3             	setae  bl
    7a0d1280191f:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d12801926:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d1280192d:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    7a0d12801934:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    7a0d1280193b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033c
    7a0d12801942:	3c 03 01 00 
    7a0d12801946:	0f 84 81 09 00 18    	je     0x7a0d2a8022cd
    7a0d1280194c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033c
    7a0d12801953:	3c 03 01 00 
    7a0d12801957:	0f 84 70 09 00 18    	je     0x7a0d2a8022cd
    7a0d1280195d:	58                   	pop    rax
    7a0d1280195e:	50                   	push   rax
    7a0d1280195f:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12801966:	00 
    7a0d12801967:	74 28                	je     0x7a0d12801991
    7a0d12801969:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    7a0d12801970:	3e 03 01 00 
    7a0d12801974:	0f 84 b3 09 00 18    	je     0x7a0d2a80232d
    7a0d1280197a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    7a0d12801981:	3e 03 01 00 
    7a0d12801985:	0f 84 a2 09 00 18    	je     0x7a0d2a80232d
    7a0d1280198b:	58                   	pop    rax
    7a0d1280198c:	e9 55 00 00 00       	jmp    0x7a0d128019e6
    7a0d12801991:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12801998:	01 
    7a0d12801999:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    7a0d128019a0:	3e 03 01 00 
    7a0d128019a4:	0f 84 cc 09 00 18    	je     0x7a0d2a802376
    7a0d128019aa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    7a0d128019b1:	3e 03 01 00 
    7a0d128019b5:	0f 84 bb 09 00 18    	je     0x7a0d2a802376
    7a0d128019bb:	b8 3e 03 01 00       	mov    eax,0x1033e
    7a0d128019c0:	83 c0 32             	add    eax,0x32
    7a0d128019c3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128019ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d128019d1:	02 00 00 00 
    7a0d128019d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d128019dc:	0a 00 00 00 
    7a0d128019e0:	58                   	pop    rax
    7a0d128019e1:	e9 89 06 00 00       	jmp    0x7a0d1280206f
    7a0d128019e6:	50                   	push   rax
    7a0d128019e7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d128019ec:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d128019f1:	09 c1                	or     ecx,eax
    7a0d128019f3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128019f7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10340
    7a0d128019fe:	40 03 01 00 
    7a0d12801a02:	0f 84 aa 09 00 18    	je     0x7a0d2a8023b2
    7a0d12801a08:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10340
    7a0d12801a0f:	40 03 01 00 
    7a0d12801a13:	0f 84 99 09 00 18    	je     0x7a0d2a8023b2
    7a0d12801a19:	58                   	pop    rax
    7a0d12801a1a:	50                   	push   rax
    7a0d12801a1b:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12801a20:	c1 e0 10             	shl    eax,0x10
    7a0d12801a23:	b9 f0 12 00 00       	mov    ecx,0x12f0
    7a0d12801a28:	09 c1                	or     ecx,eax
    7a0d12801a2a:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12801a2e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10344
    7a0d12801a35:	44 03 01 00 
    7a0d12801a39:	0f 84 d3 09 00 18    	je     0x7a0d2a802412
    7a0d12801a3f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10344
    7a0d12801a46:	44 03 01 00 
    7a0d12801a4a:	0f 84 c2 09 00 18    	je     0x7a0d2a802412
    7a0d12801a50:	58                   	pop    rax
    7a0d12801a51:	50                   	push   rax
    7a0d12801a52:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12801a56:	f6 c1 03             	test   cl,0x3
    7a0d12801a59:	0f 85 13 0a 00 18    	jne    0x7a0d2a802472
    7a0d12801a5f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12801a66:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12801a6a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801a71:	48 89 ce             	mov    rsi,rcx
    7a0d12801a74:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12801a78:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12801a7c:	48 85 c0             	test   rax,rax
    7a0d12801a7f:	0f 84 40 0a 00 18    	je     0x7a0d2a8024c5
    7a0d12801a85:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801a8b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801a8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10348
    7a0d12801a95:	48 03 01 00 
    7a0d12801a99:	0f 84 61 0a 00 18    	je     0x7a0d2a802500
    7a0d12801a9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10348
    7a0d12801aa6:	48 03 01 00 
    7a0d12801aaa:	0f 84 50 0a 00 18    	je     0x7a0d2a802500
    7a0d12801ab0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12801ab3:	0f 85 88 0a 00 18    	jne    0x7a0d2a802541
    7a0d12801ab9:	58                   	pop    rax
    7a0d12801aba:	e9 0f 00 00 00       	jmp    0x7a0d12801ace
    7a0d12801abf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12801ac6:	00 
    7a0d12801ac7:	74 f0                	je     0x7a0d12801ab9
    7a0d12801ac9:	e9 db 09 00 18       	jmp    0x7a0d2a8024a9
    7a0d12801ace:	50                   	push   rax
    7a0d12801acf:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d12801ad4:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d12801ad9:	09 c1                	or     ecx,eax
    7a0d12801adb:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12801adf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034a
    7a0d12801ae6:	4a 03 01 00 
    7a0d12801aea:	0f 84 83 0a 00 18    	je     0x7a0d2a802573
    7a0d12801af0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034a
    7a0d12801af7:	4a 03 01 00 
    7a0d12801afb:	0f 84 72 0a 00 18    	je     0x7a0d2a802573
    7a0d12801b01:	58                   	pop    rax
    7a0d12801b02:	50                   	push   rax
    7a0d12801b03:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12801b08:	c1 e0 10             	shl    eax,0x10
    7a0d12801b0b:	b9 f4 12 00 00       	mov    ecx,0x12f4
    7a0d12801b10:	09 c1                	or     ecx,eax
    7a0d12801b12:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12801b16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034e
    7a0d12801b1d:	4e 03 01 00 
    7a0d12801b21:	0f 84 ac 0a 00 18    	je     0x7a0d2a8025d3
    7a0d12801b27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034e
    7a0d12801b2e:	4e 03 01 00 
    7a0d12801b32:	0f 84 9b 0a 00 18    	je     0x7a0d2a8025d3
    7a0d12801b38:	58                   	pop    rax
    7a0d12801b39:	50                   	push   rax
    7a0d12801b3a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12801b3e:	f6 c1 03             	test   cl,0x3
    7a0d12801b41:	0f 85 ec 0a 00 18    	jne    0x7a0d2a802633
    7a0d12801b47:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12801b4e:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    7a0d12801b52:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801b59:	48 89 ce             	mov    rsi,rcx
    7a0d12801b5c:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12801b60:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12801b64:	48 85 c0             	test   rax,rax
    7a0d12801b67:	0f 84 19 0b 00 18    	je     0x7a0d2a802686
    7a0d12801b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801b73:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801b76:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10352
    7a0d12801b7d:	52 03 01 00 
    7a0d12801b81:	0f 84 3a 0b 00 18    	je     0x7a0d2a8026c1
    7a0d12801b87:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10352
    7a0d12801b8e:	52 03 01 00 
    7a0d12801b92:	0f 84 29 0b 00 18    	je     0x7a0d2a8026c1
    7a0d12801b98:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12801b9b:	0f 85 61 0b 00 18    	jne    0x7a0d2a802702
    7a0d12801ba1:	58                   	pop    rax
    7a0d12801ba2:	e9 0f 00 00 00       	jmp    0x7a0d12801bb6
    7a0d12801ba7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12801bae:	00 
    7a0d12801baf:	74 f0                	je     0x7a0d12801ba1
    7a0d12801bb1:	e9 b4 0a 00 18       	jmp    0x7a0d2a80266a
    7a0d12801bb6:	50                   	push   rax
    7a0d12801bb7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d12801bbc:	b9 00 00 01 00       	mov    ecx,0x10000
    7a0d12801bc1:	09 c1                	or     ecx,eax
    7a0d12801bc3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12801bc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10354
    7a0d12801bce:	54 03 01 00 
    7a0d12801bd2:	0f 84 5c 0b 00 18    	je     0x7a0d2a802734
    7a0d12801bd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10354
    7a0d12801bdf:	54 03 01 00 
    7a0d12801be3:	0f 84 4b 0b 00 18    	je     0x7a0d2a802734
    7a0d12801be9:	58                   	pop    rax
    7a0d12801bea:	50                   	push   rax
    7a0d12801beb:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d12801bf0:	c1 e0 10             	shl    eax,0x10
    7a0d12801bf3:	b9 f8 12 00 00       	mov    ecx,0x12f8
    7a0d12801bf8:	09 c1                	or     ecx,eax
    7a0d12801bfa:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d12801bfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10358
    7a0d12801c05:	58 03 01 00 
    7a0d12801c09:	0f 84 85 0b 00 18    	je     0x7a0d2a802794
    7a0d12801c0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10358
    7a0d12801c16:	58 03 01 00 
    7a0d12801c1a:	0f 84 74 0b 00 18    	je     0x7a0d2a802794
    7a0d12801c20:	58                   	pop    rax
    7a0d12801c21:	50                   	push   rax
    7a0d12801c22:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12801c26:	f6 c1 03             	test   cl,0x3
    7a0d12801c29:	0f 85 c5 0b 00 18    	jne    0x7a0d2a8027f4
    7a0d12801c2f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12801c36:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    7a0d12801c3a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801c41:	48 89 ce             	mov    rsi,rcx
    7a0d12801c44:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12801c48:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12801c4c:	48 85 c0             	test   rax,rax
    7a0d12801c4f:	0f 84 f2 0b 00 18    	je     0x7a0d2a802847
    7a0d12801c55:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801c5b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801c5e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1035c
    7a0d12801c65:	5c 03 01 00 
    7a0d12801c69:	0f 84 13 0c 00 18    	je     0x7a0d2a802882
    7a0d12801c6f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035c
    7a0d12801c76:	5c 03 01 00 
    7a0d12801c7a:	0f 84 02 0c 00 18    	je     0x7a0d2a802882
    7a0d12801c80:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12801c83:	0f 85 3a 0c 00 18    	jne    0x7a0d2a8028c3
    7a0d12801c89:	58                   	pop    rax
    7a0d12801c8a:	e9 0f 00 00 00       	jmp    0x7a0d12801c9e
    7a0d12801c8f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12801c96:	00 
    7a0d12801c97:	74 f0                	je     0x7a0d12801c89
    7a0d12801c99:	e9 8d 0b 00 18       	jmp    0x7a0d2a80282b
    7a0d12801c9e:	50                   	push   rax
    7a0d12801c9f:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12801ca3:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12801caa:	31 d2                	xor    edx,edx
    7a0d12801cac:	89 c6                	mov    esi,eax
    7a0d12801cae:	83 c6 fe             	add    esi,0xfffffffe
    7a0d12801cb1:	0f 94 c2             	sete   dl
    7a0d12801cb4:	09 c6                	or     esi,eax
    7a0d12801cb6:	c1 ee 1f             	shr    esi,0x1f
    7a0d12801cb9:	31 ff                	xor    edi,edi
    7a0d12801cbb:	83 f8 02             	cmp    eax,0x2
    7a0d12801cbe:	40 0f 93 c7          	setae  dil
    7a0d12801cc2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12801cc9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12801cd0:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7a0d12801cd7:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d12801cde:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12801ce5:	81 f9 5e 03 01 00    	cmp    ecx,0x1035e
    7a0d12801ceb:	0f 84 04 0c 00 18    	je     0x7a0d2a8028f5
    7a0d12801cf1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035e
    7a0d12801cf8:	5e 03 01 00 
    7a0d12801cfc:	0f 84 f3 0b 00 18    	je     0x7a0d2a8028f5
    7a0d12801d02:	58                   	pop    rax
    7a0d12801d03:	50                   	push   rax
    7a0d12801d04:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12801d0b:	00 
    7a0d12801d0c:	74 55                	je     0x7a0d12801d63
    7a0d12801d0e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12801d15:	01 
    7a0d12801d16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    7a0d12801d1d:	60 03 01 00 
    7a0d12801d21:	0f 84 2e 0c 00 18    	je     0x7a0d2a802955
    7a0d12801d27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    7a0d12801d2e:	60 03 01 00 
    7a0d12801d32:	0f 84 1d 0c 00 18    	je     0x7a0d2a802955
    7a0d12801d38:	b8 60 03 01 00       	mov    eax,0x10360
    7a0d12801d3d:	83 c0 1a             	add    eax,0x1a
    7a0d12801d40:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12801d47:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12801d4e:	02 00 00 00 
    7a0d12801d52:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    7a0d12801d59:	15 00 00 00 
    7a0d12801d5d:	58                   	pop    rax
    7a0d12801d5e:	e9 0c 03 00 00       	jmp    0x7a0d1280206f
    7a0d12801d63:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    7a0d12801d6a:	60 03 01 00 
    7a0d12801d6e:	0f 84 1d 0c 00 18    	je     0x7a0d2a802991
    7a0d12801d74:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    7a0d12801d7b:	60 03 01 00 
    7a0d12801d7f:	0f 84 0c 0c 00 18    	je     0x7a0d2a802991
    7a0d12801d85:	58                   	pop    rax
    7a0d12801d86:	50                   	push   rax
    7a0d12801d87:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12801d8b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12801d92:	31 d2                	xor    edx,edx
    7a0d12801d94:	89 c6                	mov    esi,eax
    7a0d12801d96:	83 c6 fd             	add    esi,0xfffffffd
    7a0d12801d99:	0f 94 c2             	sete   dl
    7a0d12801d9c:	09 c6                	or     esi,eax
    7a0d12801d9e:	c1 ee 1f             	shr    esi,0x1f
    7a0d12801da1:	31 ff                	xor    edi,edi
    7a0d12801da3:	83 f8 03             	cmp    eax,0x3
    7a0d12801da6:	40 0f 93 c7          	setae  dil
    7a0d12801daa:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12801db1:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12801db8:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7a0d12801dbf:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d12801dc6:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12801dcd:	81 f9 62 03 01 00    	cmp    ecx,0x10362
    7a0d12801dd3:	0f 84 01 0c 00 18    	je     0x7a0d2a8029da
    7a0d12801dd9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10362
    7a0d12801de0:	62 03 01 00 
    7a0d12801de4:	0f 84 f0 0b 00 18    	je     0x7a0d2a8029da
    7a0d12801dea:	58                   	pop    rax
    7a0d12801deb:	50                   	push   rax
    7a0d12801dec:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12801df3:	00 
    7a0d12801df4:	74 55                	je     0x7a0d12801e4b
    7a0d12801df6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12801dfd:	01 
    7a0d12801dfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    7a0d12801e05:	64 03 01 00 
    7a0d12801e09:	0f 84 2b 0c 00 18    	je     0x7a0d2a802a3a
    7a0d12801e0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    7a0d12801e16:	64 03 01 00 
    7a0d12801e1a:	0f 84 1a 0c 00 18    	je     0x7a0d2a802a3a
    7a0d12801e20:	b8 64 03 01 00       	mov    eax,0x10364
    7a0d12801e25:	83 c0 40             	add    eax,0x40
    7a0d12801e28:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d12801e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12801e36:	02 00 00 00 
    7a0d12801e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    7a0d12801e41:	17 00 00 00 
    7a0d12801e45:	58                   	pop    rax
    7a0d12801e46:	e9 24 02 00 00       	jmp    0x7a0d1280206f
    7a0d12801e4b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    7a0d12801e52:	64 03 01 00 
    7a0d12801e56:	0f 84 1a 0c 00 18    	je     0x7a0d2a802a76
    7a0d12801e5c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    7a0d12801e63:	64 03 01 00 
    7a0d12801e67:	0f 84 09 0c 00 18    	je     0x7a0d2a802a76
    7a0d12801e6d:	58                   	pop    rax
    7a0d12801e6e:	50                   	push   rax
    7a0d12801e6f:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7a0d12801e76:	00 
    7a0d12801e77:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10366
    7a0d12801e7e:	66 03 01 00 
    7a0d12801e82:	0f 84 37 0c 00 18    	je     0x7a0d2a802abf
    7a0d12801e88:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10366
    7a0d12801e8f:	66 03 01 00 
    7a0d12801e93:	0f 84 26 0c 00 18    	je     0x7a0d2a802abf
    7a0d12801e99:	58                   	pop    rax
    7a0d12801e9a:	50                   	push   rax
    7a0d12801e9b:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d12801e9f:	f6 c3 03             	test   bl,0x3
    7a0d12801ea2:	0f 85 77 0c 00 18    	jne    0x7a0d2a802b1f
    7a0d12801ea8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12801eaf:	48 89 d8             	mov    rax,rbx
    7a0d12801eb2:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12801eb6:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801ebb:	48 85 c0             	test   rax,rax
    7a0d12801ebe:	0f 84 ad 0c 00 18    	je     0x7a0d2a802b71
    7a0d12801ec4:	89 d9                	mov    ecx,ebx
    7a0d12801ec6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801ecc:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d12801ed0:	89 de                	mov    esi,ebx
    7a0d12801ed2:	83 c6 04             	add    esi,0x4
    7a0d12801ed5:	89 f0                	mov    eax,esi
    7a0d12801ed7:	c1 e8 0c             	shr    eax,0xc
    7a0d12801eda:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801edf:	48 85 c0             	test   rax,rax
    7a0d12801ee2:	0f 84 c6 0c 00 18    	je     0x7a0d2a802bae
    7a0d12801ee8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801eee:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12801ef1:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d12801ef4:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d12801ef8:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d12801eff:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d12801f03:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    7a0d12801f0a:	68 03 01 00 
    7a0d12801f0e:	0f 84 d6 0c 00 18    	je     0x7a0d2a802bea
    7a0d12801f14:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    7a0d12801f1b:	68 03 01 00 
    7a0d12801f1f:	0f 84 c5 0c 00 18    	je     0x7a0d2a802bea
    7a0d12801f25:	58                   	pop    rax
    7a0d12801f26:	50                   	push   rax
    7a0d12801f27:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d12801f2b:	f6 c3 03             	test   bl,0x3
    7a0d12801f2e:	0f 85 ff 0c 00 18    	jne    0x7a0d2a802c33
    7a0d12801f34:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d12801f3b:	48 89 d8             	mov    rax,rbx
    7a0d12801f3e:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12801f42:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801f47:	48 85 c0             	test   rax,rax
    7a0d12801f4a:	0f 84 35 0d 00 18    	je     0x7a0d2a802c85
    7a0d12801f50:	89 d9                	mov    ecx,ebx
    7a0d12801f52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801f58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12801f5b:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7a0d12801f5f:	8d 73 04             	lea    esi,[rbx+0x4]
    7a0d12801f62:	89 f0                	mov    eax,esi
    7a0d12801f64:	c1 e8 0c             	shr    eax,0xc
    7a0d12801f67:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801f6c:	48 85 c0             	test   rax,rax
    7a0d12801f6f:	0f 84 4b 0d 00 18    	je     0x7a0d2a802cc0
    7a0d12801f75:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801f7b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12801f7e:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7a0d12801f82:	8d 73 08             	lea    esi,[rbx+0x8]
    7a0d12801f85:	89 f0                	mov    eax,esi
    7a0d12801f87:	c1 e8 0c             	shr    eax,0xc
    7a0d12801f8a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801f8f:	48 85 c0             	test   rax,rax
    7a0d12801f92:	0f 84 64 0d 00 18    	je     0x7a0d2a802cfc
    7a0d12801f98:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801f9e:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12801fa1:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7a0d12801fa5:	8d 73 0c             	lea    esi,[rbx+0xc]
    7a0d12801fa8:	89 f0                	mov    eax,esi
    7a0d12801faa:	c1 e8 0c             	shr    eax,0xc
    7a0d12801fad:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801fb2:	48 85 c0             	test   rax,rax
    7a0d12801fb5:	0f 84 7d 0d 00 18    	je     0x7a0d2a802d38
    7a0d12801fbb:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801fc1:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12801fc4:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12801fc8:	89 de                	mov    esi,ebx
    7a0d12801fca:	83 c6 10             	add    esi,0x10
    7a0d12801fcd:	89 f0                	mov    eax,esi
    7a0d12801fcf:	c1 e8 0c             	shr    eax,0xc
    7a0d12801fd2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12801fd7:	48 85 c0             	test   rax,rax
    7a0d12801fda:	0f 84 94 0d 00 18    	je     0x7a0d2a802d74
    7a0d12801fe0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12801fe6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12801fe9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7a0d12801fed:	8d 43 14             	lea    eax,[rbx+0x14]
    7a0d12801ff0:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7a0d12801ff4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    7a0d12801ffb:	6c 03 01 00 
    7a0d12801fff:	0f 84 ab 0d 00 18    	je     0x7a0d2a802db0
    7a0d12802005:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    7a0d1280200c:	6c 03 01 00 
    7a0d12802010:	0f 84 9a 0d 00 18    	je     0x7a0d2a802db0
    7a0d12802016:	58                   	pop    rax
    7a0d12802017:	50                   	push   rax
    7a0d12802018:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d1280201f:	a8 01                	test   al,0x1
    7a0d12802021:	0f 85 d2 0d 00 18    	jne    0x7a0d2a802df9
    7a0d12802027:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280202e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12802035:	01 
    7a0d12802036:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    7a0d1280203d:	6e 03 01 00 
    7a0d12802041:	0f 84 e8 0d 00 18    	je     0x7a0d2a802e2f
    7a0d12802047:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    7a0d1280204e:	6e 03 01 00 
    7a0d12802052:	0f 84 d7 0d 00 18    	je     0x7a0d2a802e2f
    7a0d12802058:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280205f:	02 00 00 00 
    7a0d12802063:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    7a0d1280206a:	1b 00 00 00 
    7a0d1280206e:	58                   	pop    rax
    7a0d1280206f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12802076:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d1280207d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12802084:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280208b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12802092:	39 f1                	cmp    ecx,esi
    7a0d12802094:	0f 83 c2 0d 00 18    	jae    0x7a0d2a802e5c
    7a0d1280209a:	81 fa 28 03 01 00    	cmp    edx,0x10328
    7a0d128020a0:	75 14                	jne    0x7a0d128020b6
    7a0d128020a2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d128020a9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128020b0:	00 
    7a0d128020b1:	e9 0a f4 ff ff       	jmp    0x7a0d128014c0
    7a0d128020b6:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d128020bd:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d128020c3:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d128020c6:	0f 85 90 0d 00 18    	jne    0x7a0d2a802e5c
    7a0d128020cc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d128020d3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128020da:	00 
    7a0d128020db:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d128020e0:	ff e0                	jmp    rax
