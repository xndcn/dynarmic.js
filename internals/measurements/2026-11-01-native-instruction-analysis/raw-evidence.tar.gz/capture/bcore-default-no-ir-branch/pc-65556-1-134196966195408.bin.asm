
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65556-1-134196966195408.bin:     file format binary


Disassembly of section .data:

00007a0d2a8000d0 <.data>:
    7a0d2a8000d0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a8000d6:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a8000d9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a8000df:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a8000e6:	0f 87 a5 03 00 e8    	ja     0x7a0d12800491
    7a0d2a8000ec:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x1
    7a0d2a8000f3:	01 00 00 00 
    7a0d2a8000f7:	e9 95 03 00 e8       	jmp    0x7a0d12800491
    7a0d2a8000fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800103:	14 00 01 00 
    7a0d2a800107:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80010e:	02 00 00 00 
    7a0d2a800112:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800119:	01 00 00 00 
    7a0d2a80011d:	ba 14 00 01 00       	mov    edx,0x10014
    7a0d2a800122:	4c 89 ef             	mov    rdi,r13
    7a0d2a800125:	4c 89 f6             	mov    rsi,r14
    7a0d2a800128:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80012e:	e8 4d ff ff e7       	call   0x7a0d12800080
    7a0d2a800133:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80013a:	02 00 00 00 
    7a0d2a80013e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800145:	01 00 00 00 
    7a0d2a800149:	58                   	pop    rax
    7a0d2a80014a:	e9 8e 0a 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a80014f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800156:	14 00 01 00 
    7a0d2a80015a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800161:	02 00 00 00 
    7a0d2a800165:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80016c:	01 00 00 00 
    7a0d2a800170:	4c 89 f7             	mov    rdi,r14
    7a0d2a800173:	89 ce                	mov    esi,ecx
    7a0d2a800175:	e8 f6 fe ff e7       	call   0x7a0d12800070
    7a0d2a80017a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800181:	00 
    7a0d2a800182:	0f 84 48 03 00 e8    	je     0x7a0d128004d0
    7a0d2a800188:	eb a9                	jmp    0x7a0d2a800133
    7a0d2a80018a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800191:	14 00 01 00 
    7a0d2a800195:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80019c:	02 00 00 00 
    7a0d2a8001a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8001a7:	01 00 00 00 
    7a0d2a8001ab:	4c 89 f7             	mov    rdi,r14
    7a0d2a8001ae:	e8 bd fe ff e7       	call   0x7a0d12800070
    7a0d2a8001b3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8001ba:	00 
    7a0d2a8001bb:	0f 84 32 03 00 e8    	je     0x7a0d128004f3
    7a0d2a8001c1:	e9 6d ff ff ff       	jmp    0x7a0d2a800133
    7a0d2a8001c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a8001cd:	14 00 01 00 
    7a0d2a8001d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8001d8:	02 00 00 00 
    7a0d2a8001dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8001e3:	01 00 00 00 
    7a0d2a8001e7:	4c 89 f7             	mov    rdi,r14
    7a0d2a8001ea:	e8 81 fe ff e7       	call   0x7a0d12800070
    7a0d2a8001ef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8001f6:	00 
    7a0d2a8001f7:	0f 84 19 03 00 e8    	je     0x7a0d12800516
    7a0d2a8001fd:	e9 31 ff ff ff       	jmp    0x7a0d2a800133
    7a0d2a800202:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800209:	14 00 01 00 
    7a0d2a80020d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800214:	02 00 00 00 
    7a0d2a800218:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80021f:	01 00 00 00 
    7a0d2a800223:	4c 89 f7             	mov    rdi,r14
    7a0d2a800226:	e8 45 fe ff e7       	call   0x7a0d12800070
    7a0d2a80022b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800232:	00 
    7a0d2a800233:	0f 84 00 03 00 e8    	je     0x7a0d12800539
    7a0d2a800239:	e9 f5 fe ff ff       	jmp    0x7a0d2a800133
    7a0d2a80023e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800245:	14 00 01 00 
    7a0d2a800249:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800250:	02 00 00 00 
    7a0d2a800254:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80025b:	01 00 00 00 
    7a0d2a80025f:	4c 89 f7             	mov    rdi,r14
    7a0d2a800262:	e8 09 fe ff e7       	call   0x7a0d12800070
    7a0d2a800267:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80026e:	00 
    7a0d2a80026f:	0f 84 e7 02 00 e8    	je     0x7a0d1280055c
    7a0d2a800275:	e9 b9 fe ff ff       	jmp    0x7a0d2a800133
    7a0d2a80027a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800281:	14 00 01 00 
    7a0d2a800285:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80028c:	02 00 00 00 
    7a0d2a800290:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800297:	01 00 00 00 
    7a0d2a80029b:	4c 89 f7             	mov    rdi,r14
    7a0d2a80029e:	e8 cd fd ff e7       	call   0x7a0d12800070
    7a0d2a8002a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8002aa:	00 
    7a0d2a8002ab:	0f 84 ce 02 00 e8    	je     0x7a0d1280057f
    7a0d2a8002b1:	e9 7d fe ff ff       	jmp    0x7a0d2a800133
    7a0d2a8002b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a8002bd:	14 00 01 00 
    7a0d2a8002c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8002c8:	02 00 00 00 
    7a0d2a8002cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8002d3:	01 00 00 00 
    7a0d2a8002d7:	4c 89 f7             	mov    rdi,r14
    7a0d2a8002da:	89 de                	mov    esi,ebx
    7a0d2a8002dc:	e8 8f fd ff e7       	call   0x7a0d12800070
    7a0d2a8002e1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8002e8:	00 
    7a0d2a8002e9:	0f 84 b5 02 00 e8    	je     0x7a0d128005a4
    7a0d2a8002ef:	e9 3f fe ff ff       	jmp    0x7a0d2a800133
    7a0d2a8002f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a8002fb:	14 00 01 00 
    7a0d2a8002ff:	b8 14 00 01 00       	mov    eax,0x10014
    7a0d2a800304:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80030b:	02 00 00 00 
    7a0d2a80030f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800316:	01 00 00 00 
    7a0d2a80031a:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80031d:	be 14 00 01 00       	mov    esi,0x10014
    7a0d2a800322:	4c 89 ef             	mov    rdi,r13
    7a0d2a800325:	e8 36 fe ff e7       	call   0x7a0d12800160
    7a0d2a80032a:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a80032e:	0f 84 a6 02 00 e8    	je     0x7a0d128005da
    7a0d2a800334:	eb 0f                	jmp    0x7a0d2a800345
    7a0d2a800336:	b8 14 00 01 00       	mov    eax,0x10014
    7a0d2a80033b:	83 c0 02             	add    eax,0x2
    7a0d2a80033e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a800345:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80034c:	02 00 00 00 
    7a0d2a800350:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800357:	01 00 00 00 
    7a0d2a80035b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80035e:	e8 ed fd ff e7       	call   0x7a0d12800150
    7a0d2a800363:	e9 72 02 00 e8       	jmp    0x7a0d128005da
    7a0d2a800368:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    7a0d2a80036f:	16 00 01 00 
    7a0d2a800373:	b8 16 00 01 00       	mov    eax,0x10016
    7a0d2a800378:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80037f:	04 00 00 00 
    7a0d2a800383:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80038a:	02 00 00 00 
    7a0d2a80038e:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a800391:	be 16 00 01 00       	mov    esi,0x10016
    7a0d2a800396:	4c 89 ef             	mov    rdi,r13
    7a0d2a800399:	e8 c2 fd ff e7       	call   0x7a0d12800160
    7a0d2a80039e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8003a5:	00 
    7a0d2a8003a6:	0f 84 70 02 00 e8    	je     0x7a0d1280061c
    7a0d2a8003ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8003b3:	04 00 00 00 
    7a0d2a8003b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8003be:	02 00 00 00 
    7a0d2a8003c2:	58                   	pop    rax
    7a0d2a8003c3:	e9 15 08 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a8003c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    7a0d2a8003cf:	1a 00 01 00 
    7a0d2a8003d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8003da:	04 00 00 00 
    7a0d2a8003de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8003e5:	03 00 00 00 
    7a0d2a8003e9:	ba 1a 00 01 00       	mov    edx,0x1001a
    7a0d2a8003ee:	4c 89 ef             	mov    rdi,r13
    7a0d2a8003f1:	4c 89 f6             	mov    rsi,r14
    7a0d2a8003f4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a8003fa:	e8 81 fc ff e7       	call   0x7a0d12800080
    7a0d2a8003ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800406:	04 00 00 00 
    7a0d2a80040a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800411:	03 00 00 00 
    7a0d2a800415:	58                   	pop    rax
    7a0d2a800416:	e9 c2 07 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a80041b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    7a0d2a800422:	1a 00 01 00 
    7a0d2a800426:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80042d:	04 00 00 00 
    7a0d2a800431:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800438:	03 00 00 00 
    7a0d2a80043c:	4c 89 f7             	mov    rdi,r14
    7a0d2a80043f:	89 ce                	mov    esi,ecx
    7a0d2a800441:	e8 2a fc ff e7       	call   0x7a0d12800070
    7a0d2a800446:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80044d:	00 
    7a0d2a80044e:	0f 84 0f 02 00 e8    	je     0x7a0d12800663
    7a0d2a800454:	eb a9                	jmp    0x7a0d2a8003ff
    7a0d2a800456:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    7a0d2a80045d:	1a 00 01 00 
    7a0d2a800461:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800468:	04 00 00 00 
    7a0d2a80046c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a800473:	03 00 00 00 
    7a0d2a800477:	4c 89 f7             	mov    rdi,r14
    7a0d2a80047a:	89 de                	mov    esi,ebx
    7a0d2a80047c:	44 89 e2             	mov    edx,r12d
    7a0d2a80047f:	e8 ec fb ff e7       	call   0x7a0d12800070
    7a0d2a800484:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80048b:	00 
    7a0d2a80048c:	0f 84 f3 01 00 e8    	je     0x7a0d12800685
    7a0d2a800492:	e9 68 ff ff ff       	jmp    0x7a0d2a8003ff
    7a0d2a800497:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    7a0d2a80049e:	1a 00 01 00 
    7a0d2a8004a2:	b8 1a 00 01 00       	mov    eax,0x1001a
    7a0d2a8004a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8004ae:	04 00 00 00 
    7a0d2a8004b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8004b9:	03 00 00 00 
    7a0d2a8004bd:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8004c0:	be 1a 00 01 00       	mov    esi,0x1001a
    7a0d2a8004c5:	4c 89 ef             	mov    rdi,r13
    7a0d2a8004c8:	e8 93 fc ff e7       	call   0x7a0d12800160
    7a0d2a8004cd:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7a0d2a8004d1:	0f 84 ef 01 00 e8    	je     0x7a0d128006c6
    7a0d2a8004d7:	eb 0f                	jmp    0x7a0d2a8004e8
    7a0d2a8004d9:	b8 1a 00 01 00       	mov    eax,0x1001a
    7a0d2a8004de:	83 c0 04             	add    eax,0x4
    7a0d2a8004e1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8004e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8004ef:	04 00 00 00 
    7a0d2a8004f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8004fa:	03 00 00 00 
    7a0d2a8004fe:	4c 89 ef             	mov    rdi,r13
    7a0d2a800501:	e8 4a fc ff e7       	call   0x7a0d12800150
    7a0d2a800506:	e9 bb 01 00 e8       	jmp    0x7a0d128006c6
    7a0d2a80050b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    7a0d2a800512:	1e 00 01 00 
    7a0d2a800516:	b8 1e 00 01 00       	mov    eax,0x1001e
    7a0d2a80051b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800522:	04 00 00 00 
    7a0d2a800526:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80052d:	04 00 00 00 
    7a0d2a800531:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a800534:	be 1e 00 01 00       	mov    esi,0x1001e
    7a0d2a800539:	4c 89 ef             	mov    rdi,r13
    7a0d2a80053c:	e8 1f fc ff e7       	call   0x7a0d12800160
    7a0d2a800541:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800548:	00 
    7a0d2a800549:	0f 84 bc 01 00 e8    	je     0x7a0d1280070b
    7a0d2a80054f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800556:	04 00 00 00 
    7a0d2a80055a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a800561:	04 00 00 00 
    7a0d2a800565:	58                   	pop    rax
    7a0d2a800566:	e9 72 06 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a80056b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10022
    7a0d2a800572:	22 00 01 00 
    7a0d2a800576:	b8 22 00 01 00       	mov    eax,0x10022
    7a0d2a80057b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800582:	04 00 00 00 
    7a0d2a800586:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80058d:	05 00 00 00 
    7a0d2a800591:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a800594:	be 22 00 01 00       	mov    esi,0x10022
    7a0d2a800599:	4c 89 ef             	mov    rdi,r13
    7a0d2a80059c:	e8 bf fb ff e7       	call   0x7a0d12800160
    7a0d2a8005a1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8005a8:	00 
    7a0d2a8005a9:	0f 84 90 01 00 e8    	je     0x7a0d1280073f
    7a0d2a8005af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8005b6:	04 00 00 00 
    7a0d2a8005ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8005c1:	05 00 00 00 
    7a0d2a8005c5:	58                   	pop    rax
    7a0d2a8005c6:	e9 12 06 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a8005cb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    7a0d2a8005d2:	26 00 01 00 
    7a0d2a8005d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8005dd:	02 00 00 00 
    7a0d2a8005e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8005e8:	06 00 00 00 
    7a0d2a8005ec:	ba 26 00 01 00       	mov    edx,0x10026
    7a0d2a8005f1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8005f4:	4c 89 f6             	mov    rsi,r14
    7a0d2a8005f7:	45 31 c0             	xor    r8d,r8d
    7a0d2a8005fa:	e8 81 fa ff e7       	call   0x7a0d12800080
    7a0d2a8005ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800606:	02 00 00 00 
    7a0d2a80060a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a800611:	06 00 00 00 
    7a0d2a800615:	58                   	pop    rax
    7a0d2a800616:	e9 c2 05 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a80061b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    7a0d2a800622:	26 00 01 00 
    7a0d2a800626:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80062d:	02 00 00 00 
    7a0d2a800631:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a800638:	06 00 00 00 
    7a0d2a80063c:	4c 89 f7             	mov    rdi,r14
    7a0d2a80063f:	89 ce                	mov    esi,ecx
    7a0d2a800641:	e8 fa f9 ff e7       	call   0x7a0d12800040
    7a0d2a800646:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80064d:	00 
    7a0d2a80064e:	0f 84 1e 01 00 e8    	je     0x7a0d12800772
    7a0d2a800654:	eb a9                	jmp    0x7a0d2a8005ff
    7a0d2a800656:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    7a0d2a80065d:	26 00 01 00 
    7a0d2a800661:	b8 26 00 01 00       	mov    eax,0x10026
    7a0d2a800666:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80066d:	02 00 00 00 
    7a0d2a800671:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a800678:	06 00 00 00 
    7a0d2a80067c:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80067f:	be 26 00 01 00       	mov    esi,0x10026
    7a0d2a800684:	4c 89 ef             	mov    rdi,r13
    7a0d2a800687:	e8 d4 fa ff e7       	call   0x7a0d12800160
    7a0d2a80068c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800693:	00 
    7a0d2a800694:	0f 84 fe 00 00 e8    	je     0x7a0d12800798
    7a0d2a80069a:	e9 60 ff ff ff       	jmp    0x7a0d2a8005ff
    7a0d2a80069f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10028
    7a0d2a8006a6:	28 00 01 00 
    7a0d2a8006aa:	b8 28 00 01 00       	mov    eax,0x10028
    7a0d2a8006af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8006b6:	04 00 00 00 
    7a0d2a8006ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8006c1:	07 00 00 00 
    7a0d2a8006c5:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8006c8:	be 28 00 01 00       	mov    esi,0x10028
    7a0d2a8006cd:	4c 89 ef             	mov    rdi,r13
    7a0d2a8006d0:	e8 8b fa ff e7       	call   0x7a0d12800160
    7a0d2a8006d5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8006dc:	00 
    7a0d2a8006dd:	0f 84 ec 00 00 e8    	je     0x7a0d128007cf
    7a0d2a8006e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8006ea:	04 00 00 00 
    7a0d2a8006ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8006f5:	07 00 00 00 
    7a0d2a8006f9:	58                   	pop    rax
    7a0d2a8006fa:	e9 de 04 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a8006ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002c
    7a0d2a800706:	2c 00 01 00 
    7a0d2a80070a:	b8 2c 00 01 00       	mov    eax,0x1002c
    7a0d2a80070f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800716:	02 00 00 00 
    7a0d2a80071a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a800721:	08 00 00 00 
    7a0d2a800725:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800728:	be 2c 00 01 00       	mov    esi,0x1002c
    7a0d2a80072d:	4c 89 ef             	mov    rdi,r13
    7a0d2a800730:	e8 2b fa ff e7       	call   0x7a0d12800160
    7a0d2a800735:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80073c:	00 
    7a0d2a80073d:	0f 84 fd 00 00 e8    	je     0x7a0d12800840
    7a0d2a800743:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80074a:	02 00 00 00 
    7a0d2a80074e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7a0d2a800755:	08 00 00 00 
    7a0d2a800759:	58                   	pop    rax
    7a0d2a80075a:	e9 7e 04 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a80075f:	b8 2e 00 01 00       	mov    eax,0x1002e
    7a0d2a800764:	83 c0 12             	add    eax,0x12
    7a0d2a800767:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a80076e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800775:	02 00 00 00 
    7a0d2a800779:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a800780:	09 00 00 00 
    7a0d2a800784:	be 2e 00 01 00       	mov    esi,0x1002e
    7a0d2a800789:	ba 2e 00 01 00       	mov    edx,0x1002e
    7a0d2a80078e:	4c 89 ef             	mov    rdi,r13
    7a0d2a800791:	e8 ca f9 ff e7       	call   0x7a0d12800160
    7a0d2a800796:	e9 db 00 00 e8       	jmp    0x7a0d12800876
    7a0d2a80079b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002e
    7a0d2a8007a2:	2e 00 01 00 
    7a0d2a8007a6:	b8 2e 00 01 00       	mov    eax,0x1002e
    7a0d2a8007ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8007b2:	02 00 00 00 
    7a0d2a8007b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    7a0d2a8007bd:	09 00 00 00 
    7a0d2a8007c1:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8007c4:	be 2e 00 01 00       	mov    esi,0x1002e
    7a0d2a8007c9:	4c 89 ef             	mov    rdi,r13
    7a0d2a8007cc:	e8 8f f9 ff e7       	call   0x7a0d12800160
    7a0d2a8007d1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8007d8:	00 
    7a0d2a8007d9:	0f 84 e4 00 00 e8    	je     0x7a0d128008c3
    7a0d2a8007df:	e9 a1 00 00 e8       	jmp    0x7a0d12800885
    7a0d2a8007e4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10030
    7a0d2a8007eb:	30 00 01 00 
    7a0d2a8007ef:	b8 30 00 01 00       	mov    eax,0x10030
    7a0d2a8007f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8007fb:	02 00 00 00 
    7a0d2a8007ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a800806:	0a 00 00 00 
    7a0d2a80080a:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80080d:	be 30 00 01 00       	mov    esi,0x10030
    7a0d2a800812:	4c 89 ef             	mov    rdi,r13
    7a0d2a800815:	e8 46 f9 ff e7       	call   0x7a0d12800160
    7a0d2a80081a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800821:	00 
    7a0d2a800822:	0f 84 c7 00 00 e8    	je     0x7a0d128008ef
    7a0d2a800828:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80082f:	02 00 00 00 
    7a0d2a800833:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7a0d2a80083a:	0a 00 00 00 
    7a0d2a80083e:	58                   	pop    rax
    7a0d2a80083f:	e9 99 03 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a800844:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10032
    7a0d2a80084b:	32 00 01 00 
    7a0d2a80084f:	b8 32 00 01 00       	mov    eax,0x10032
    7a0d2a800854:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80085b:	02 00 00 00 
    7a0d2a80085f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a800866:	0b 00 00 00 
    7a0d2a80086a:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80086d:	be 32 00 01 00       	mov    esi,0x10032
    7a0d2a800872:	4c 89 ef             	mov    rdi,r13
    7a0d2a800875:	e8 e6 f8 ff e7       	call   0x7a0d12800160
    7a0d2a80087a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800881:	00 
    7a0d2a800882:	0f 84 90 00 00 e8    	je     0x7a0d12800918
    7a0d2a800888:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80088f:	02 00 00 00 
    7a0d2a800893:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a80089a:	0b 00 00 00 
    7a0d2a80089e:	58                   	pop    rax
    7a0d2a80089f:	e9 39 03 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a8008a4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    7a0d2a8008ab:	34 00 01 00 
    7a0d2a8008af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8008b6:	02 00 00 00 
    7a0d2a8008ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8008c1:	0c 00 00 00 
    7a0d2a8008c5:	ba 34 00 01 00       	mov    edx,0x10034
    7a0d2a8008ca:	4c 89 ef             	mov    rdi,r13
    7a0d2a8008cd:	4c 89 f6             	mov    rsi,r14
    7a0d2a8008d0:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a8008d6:	e8 a5 f7 ff e7       	call   0x7a0d12800080
    7a0d2a8008db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8008e2:	02 00 00 00 
    7a0d2a8008e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a8008ed:	0c 00 00 00 
    7a0d2a8008f1:	58                   	pop    rax
    7a0d2a8008f2:	e9 e6 02 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a8008f7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    7a0d2a8008fe:	34 00 01 00 
    7a0d2a800902:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800909:	02 00 00 00 
    7a0d2a80090d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a800914:	0c 00 00 00 
    7a0d2a800918:	4c 89 f7             	mov    rdi,r14
    7a0d2a80091b:	89 ce                	mov    esi,ecx
    7a0d2a80091d:	e8 4e f7 ff e7       	call   0x7a0d12800070
    7a0d2a800922:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800929:	00 
    7a0d2a80092a:	0f 84 26 00 00 e8    	je     0x7a0d12800956
    7a0d2a800930:	eb a9                	jmp    0x7a0d2a8008db
    7a0d2a800932:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    7a0d2a800939:	34 00 01 00 
    7a0d2a80093d:	b8 34 00 01 00       	mov    eax,0x10034
    7a0d2a800942:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800949:	02 00 00 00 
    7a0d2a80094d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a800954:	0c 00 00 00 
    7a0d2a800958:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a80095b:	be 34 00 01 00       	mov    esi,0x10034
    7a0d2a800960:	4c 89 ef             	mov    rdi,r13
    7a0d2a800963:	e8 f8 f7 ff e7       	call   0x7a0d12800160
    7a0d2a800968:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a80096b:	0f 84 16 00 00 e8    	je     0x7a0d12800987
    7a0d2a800971:	eb 0f                	jmp    0x7a0d2a800982
    7a0d2a800973:	b8 34 00 01 00       	mov    eax,0x10034
    7a0d2a800978:	83 c0 02             	add    eax,0x2
    7a0d2a80097b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a800982:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800989:	02 00 00 00 
    7a0d2a80098d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    7a0d2a800994:	0c 00 00 00 
    7a0d2a800998:	4c 89 ef             	mov    rdi,r13
    7a0d2a80099b:	e8 b0 f7 ff e7       	call   0x7a0d12800150
    7a0d2a8009a0:	e9 e2 ff ff e7       	jmp    0x7a0d12800987
    7a0d2a8009a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    7a0d2a8009ac:	36 00 01 00 
    7a0d2a8009b0:	b8 36 00 01 00       	mov    eax,0x10036
    7a0d2a8009b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8009bc:	02 00 00 00 
    7a0d2a8009c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8009c7:	0d 00 00 00 
    7a0d2a8009cb:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8009ce:	be 36 00 01 00       	mov    esi,0x10036
    7a0d2a8009d3:	4c 89 ef             	mov    rdi,r13
    7a0d2a8009d6:	e8 85 f7 ff e7       	call   0x7a0d12800160
    7a0d2a8009db:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8009e2:	00 
    7a0d2a8009e3:	0f 84 d8 ff ff e7    	je     0x7a0d128009c1
    7a0d2a8009e9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8009f0:	02 00 00 00 
    7a0d2a8009f4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    7a0d2a8009fb:	0d 00 00 00 
    7a0d2a8009ff:	58                   	pop    rax
    7a0d2a800a00:	e9 d8 01 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a800a05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    7a0d2a800a0c:	38 00 01 00 
    7a0d2a800a10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800a17:	04 00 00 00 
    7a0d2a800a1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a800a22:	0e 00 00 00 
    7a0d2a800a26:	ba 38 00 01 00       	mov    edx,0x10038
    7a0d2a800a2b:	4c 89 ef             	mov    rdi,r13
    7a0d2a800a2e:	4c 89 f6             	mov    rsi,r14
    7a0d2a800a31:	89 d9                	mov    ecx,ebx
    7a0d2a800a33:	45 31 c0             	xor    r8d,r8d
    7a0d2a800a36:	e8 45 f6 ff e7       	call   0x7a0d12800080
    7a0d2a800a3b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800a42:	04 00 00 00 
    7a0d2a800a46:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a800a4d:	0e 00 00 00 
    7a0d2a800a51:	58                   	pop    rax
    7a0d2a800a52:	e9 86 01 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a800a57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    7a0d2a800a5e:	38 00 01 00 
    7a0d2a800a62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800a69:	04 00 00 00 
    7a0d2a800a6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a800a74:	0e 00 00 00 
    7a0d2a800a78:	4c 89 f7             	mov    rdi,r14
    7a0d2a800a7b:	89 de                	mov    esi,ebx
    7a0d2a800a7d:	e8 be f5 ff e7       	call   0x7a0d12800040
    7a0d2a800a82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800a89:	00 
    7a0d2a800a8a:	75 af                	jne    0x7a0d2a800a3b
    7a0d2a800a8c:	41 89 c7             	mov    r15d,eax
    7a0d2a800a8f:	e9 64 ff ff e7       	jmp    0x7a0d128009f8
    7a0d2a800a94:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    7a0d2a800a9b:	38 00 01 00 
    7a0d2a800a9f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800aa6:	04 00 00 00 
    7a0d2a800aaa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a800ab1:	0e 00 00 00 
    7a0d2a800ab5:	4c 89 f7             	mov    rdi,r14
    7a0d2a800ab8:	e8 83 f5 ff e7       	call   0x7a0d12800040
    7a0d2a800abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800ac4:	00 
    7a0d2a800ac5:	0f 84 4e ff ff e7    	je     0x7a0d12800a19
    7a0d2a800acb:	e9 6b ff ff ff       	jmp    0x7a0d2a800a3b
    7a0d2a800ad0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    7a0d2a800ad7:	38 00 01 00 
    7a0d2a800adb:	b8 38 00 01 00       	mov    eax,0x10038
    7a0d2a800ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a800ae7:	04 00 00 00 
    7a0d2a800aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    7a0d2a800af2:	0e 00 00 00 
    7a0d2a800af6:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a800af9:	be 38 00 01 00       	mov    esi,0x10038
    7a0d2a800afe:	4c 89 ef             	mov    rdi,r13
    7a0d2a800b01:	e8 5a f6 ff e7       	call   0x7a0d12800160
    7a0d2a800b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800b0d:	00 
    7a0d2a800b0e:	0f 84 39 ff ff e7    	je     0x7a0d12800a4d
    7a0d2a800b14:	e9 22 ff ff ff       	jmp    0x7a0d2a800a3b
    7a0d2a800b19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800b20:	3c 00 01 00 
    7a0d2a800b24:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800b2b:	02 00 00 00 
    7a0d2a800b2f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800b36:	0f 00 00 00 
    7a0d2a800b3a:	ba 3c 00 01 00       	mov    edx,0x1003c
    7a0d2a800b3f:	4c 89 ef             	mov    rdi,r13
    7a0d2a800b42:	4c 89 f6             	mov    rsi,r14
    7a0d2a800b45:	89 d9                	mov    ecx,ebx
    7a0d2a800b47:	45 31 c0             	xor    r8d,r8d
    7a0d2a800b4a:	e8 31 f5 ff e7       	call   0x7a0d12800080
    7a0d2a800b4f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800b56:	02 00 00 00 
    7a0d2a800b5a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800b61:	0f 00 00 00 
    7a0d2a800b65:	58                   	pop    rax
    7a0d2a800b66:	e9 72 00 00 e8       	jmp    0x7a0d12800bdd
    7a0d2a800b6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800b72:	3c 00 01 00 
    7a0d2a800b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800b7d:	02 00 00 00 
    7a0d2a800b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800b88:	0f 00 00 00 
    7a0d2a800b8c:	4c 89 f7             	mov    rdi,r14
    7a0d2a800b8f:	89 de                	mov    esi,ebx
    7a0d2a800b91:	e8 aa f4 ff e7       	call   0x7a0d12800040
    7a0d2a800b96:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800b9d:	00 
    7a0d2a800b9e:	0f 84 df fe ff e7    	je     0x7a0d12800a83
    7a0d2a800ba4:	eb a9                	jmp    0x7a0d2a800b4f
    7a0d2a800ba6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800bad:	3c 00 01 00 
    7a0d2a800bb1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800bb8:	02 00 00 00 
    7a0d2a800bbc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800bc3:	0f 00 00 00 
    7a0d2a800bc7:	4c 89 f7             	mov    rdi,r14
    7a0d2a800bca:	e8 71 f4 ff e7       	call   0x7a0d12800040
    7a0d2a800bcf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800bd6:	00 
    7a0d2a800bd7:	0f 84 c9 fe ff e7    	je     0x7a0d12800aa6
    7a0d2a800bdd:	e9 6d ff ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800be2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800be9:	3c 00 01 00 
    7a0d2a800bed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800bf4:	02 00 00 00 
    7a0d2a800bf8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800bff:	0f 00 00 00 
    7a0d2a800c03:	4c 89 f7             	mov    rdi,r14
    7a0d2a800c06:	e8 35 f4 ff e7       	call   0x7a0d12800040
    7a0d2a800c0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800c12:	00 
    7a0d2a800c13:	0f 84 b0 fe ff e7    	je     0x7a0d12800ac9
    7a0d2a800c19:	e9 31 ff ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800c1e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800c25:	3c 00 01 00 
    7a0d2a800c29:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800c30:	02 00 00 00 
    7a0d2a800c34:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800c3b:	0f 00 00 00 
    7a0d2a800c3f:	4c 89 f7             	mov    rdi,r14
    7a0d2a800c42:	e8 f9 f3 ff e7       	call   0x7a0d12800040
    7a0d2a800c47:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800c4e:	00 
    7a0d2a800c4f:	0f 84 97 fe ff e7    	je     0x7a0d12800aec
    7a0d2a800c55:	e9 f5 fe ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800c5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800c61:	3c 00 01 00 
    7a0d2a800c65:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800c6c:	02 00 00 00 
    7a0d2a800c70:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800c77:	0f 00 00 00 
    7a0d2a800c7b:	4c 89 f7             	mov    rdi,r14
    7a0d2a800c7e:	e8 bd f3 ff e7       	call   0x7a0d12800040
    7a0d2a800c83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800c8a:	00 
    7a0d2a800c8b:	0f 84 7e fe ff e7    	je     0x7a0d12800b0f
    7a0d2a800c91:	e9 b9 fe ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800c96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800c9d:	3c 00 01 00 
    7a0d2a800ca1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800ca8:	02 00 00 00 
    7a0d2a800cac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800cb3:	0f 00 00 00 
    7a0d2a800cb7:	4c 89 f7             	mov    rdi,r14
    7a0d2a800cba:	e8 81 f3 ff e7       	call   0x7a0d12800040
    7a0d2a800cbf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800cc6:	00 
    7a0d2a800cc7:	0f 84 65 fe ff e7    	je     0x7a0d12800b32
    7a0d2a800ccd:	e9 7d fe ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800cd2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800cd9:	3c 00 01 00 
    7a0d2a800cdd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800ce4:	02 00 00 00 
    7a0d2a800ce8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800cef:	0f 00 00 00 
    7a0d2a800cf3:	4c 89 f7             	mov    rdi,r14
    7a0d2a800cf6:	e8 45 f3 ff e7       	call   0x7a0d12800040
    7a0d2a800cfb:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800d02:	00 
    7a0d2a800d03:	0f 84 4e fe ff e7    	je     0x7a0d12800b57
    7a0d2a800d09:	e9 41 fe ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800d0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    7a0d2a800d15:	3c 00 01 00 
    7a0d2a800d19:	b8 3c 00 01 00       	mov    eax,0x1003c
    7a0d2a800d1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800d25:	02 00 00 00 
    7a0d2a800d29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    7a0d2a800d30:	0f 00 00 00 
    7a0d2a800d34:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800d37:	be 3c 00 01 00       	mov    esi,0x1003c
    7a0d2a800d3c:	4c 89 ef             	mov    rdi,r13
    7a0d2a800d3f:	e8 1c f4 ff e7       	call   0x7a0d12800160
    7a0d2a800d44:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800d4b:	00 
    7a0d2a800d4c:	0f 84 32 fe ff e7    	je     0x7a0d12800b84
    7a0d2a800d52:	e9 f8 fd ff ff       	jmp    0x7a0d2a800b4f
    7a0d2a800d57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    7a0d2a800d5e:	3e 00 01 00 
    7a0d2a800d62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800d69:	02 00 00 00 
    7a0d2a800d6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a800d74:	10 00 00 00 
    7a0d2a800d78:	4c 89 ef             	mov    rdi,r13
    7a0d2a800d7b:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a800d80:	4c 89 f2             	mov    rdx,r14
    7a0d2a800d83:	e8 08 f3 ff e7       	call   0x7a0d12800090
    7a0d2a800d88:	e9 39 fe ff e7       	jmp    0x7a0d12800bc6
    7a0d2a800d8d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800d94:	02 00 00 00 
    7a0d2a800d98:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    7a0d2a800d9f:	10 00 00 00 
    7a0d2a800da3:	be 3e 00 01 00       	mov    esi,0x1003e
    7a0d2a800da8:	ba 3e 00 01 00       	mov    edx,0x1003e
    7a0d2a800dad:	4c 89 ef             	mov    rdi,r13
    7a0d2a800db0:	e8 ab f3 ff e7       	call   0x7a0d12800160
    7a0d2a800db5:	e9 0c fe ff e7       	jmp    0x7a0d12800bc6
    7a0d2a800dba:	c2 08 00             	ret    0x8
