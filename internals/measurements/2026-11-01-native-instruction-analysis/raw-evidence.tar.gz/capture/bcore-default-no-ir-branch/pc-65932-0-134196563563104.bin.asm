
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65932-0-134196563563104.bin:     file format binary


Disassembly of section .data:

00007a0d12805260 <.data>:
    7a0d12805260:	48 83 ec 18          	sub    rsp,0x18
    7a0d12805264:	b8 65 fe fe ff       	mov    eax,0xfffefe65
    7a0d12805269:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12805270:	01 c1                	add    ecx,eax
    7a0d12805272:	83 f9 f0             	cmp    ecx,0xfffffff0
    7a0d12805275:	0f 87 85 12 00 18    	ja     0x7a0d2a806500
    7a0d1280527b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7a0d12805282:	83 f8 f0             	cmp    eax,0xfffffff0
    7a0d12805285:	0f 87 75 12 00 18    	ja     0x7a0d2a806500
    7a0d1280528b:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    7a0d12805292:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7a0d12805299:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    7a0d1280529d:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    7a0d128052a1:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d128052a4:	41 89 55 18          	mov    DWORD PTR [r13+0x18],edx
    7a0d128052a8:	c1 e9 1f             	shr    ecx,0x1f
    7a0d128052ab:	89 d6                	mov    esi,edx
    7a0d128052ad:	c1 ee 1f             	shr    esi,0x1f
    7a0d128052b0:	c4 e2 70 f2 ce       	andn   ecx,ecx,esi
    7a0d128052b5:	41 89 8d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ecx
    7a0d128052bc:	41 89 8d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ecx
    7a0d128052c3:	41 09 8d 00 01 00 00 	or     DWORD PTR [r13+0x100],ecx
    7a0d128052ca:	31 c9                	xor    ecx,ecx
    7a0d128052cc:	31 f6                	xor    esi,esi
    7a0d128052ce:	31 ff                	xor    edi,edi
    7a0d128052d0:	31 db                	xor    ebx,ebx
    7a0d128052d2:	39 c2                	cmp    edx,eax
    7a0d128052d4:	0f 97 c1             	seta   cl
    7a0d128052d7:	40 0f 96 c6          	setbe  sil
    7a0d128052db:	40 0f 93 c7          	setae  dil
    7a0d128052df:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    7a0d128052e6:	0f 94 c3             	sete   bl
    7a0d128052e9:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7a0d128052f0:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7a0d128052f7:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7a0d128052fe:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7a0d12805305:	0f 82 ab 01 00 00    	jb     0x7a0d128054b6
    7a0d1280530b:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d1280530f:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    7a0d12805313:	31 c9                	xor    ecx,ecx
    7a0d12805315:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    7a0d12805319:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d1280531d:	0f 94 c1             	sete   cl
    7a0d12805320:	c1 e8 1f             	shr    eax,0x1f
    7a0d12805323:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7a0d1280532a:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12805331:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d12805338:	00 00 00 00 
    7a0d1280533c:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12805343:	00 00 00 00 
    7a0d12805347:	40 f6 c5 03          	test   bpl,0x3
    7a0d1280534b:	0f 85 11 12 00 18    	jne    0x7a0d2a806562
    7a0d12805351:	48 89 e8             	mov    rax,rbp
    7a0d12805354:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12805358:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d1280535c:	48 85 c0             	test   rax,rax
    7a0d1280535f:	0f 84 5e 12 00 18    	je     0x7a0d2a8065c3
    7a0d12805365:	89 e9                	mov    ecx,ebp
    7a0d12805367:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280536d:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    7a0d12805370:	8d 75 04             	lea    esi,[rbp+0x4]
    7a0d12805373:	89 f0                	mov    eax,esi
    7a0d12805375:	c1 e8 0c             	shr    eax,0xc
    7a0d12805378:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d1280537c:	48 85 c0             	test   rax,rax
    7a0d1280537f:	0f 84 9b 12 00 18    	je     0x7a0d2a806620
    7a0d12805385:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d1280538b:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    7a0d1280538f:	8d 75 08             	lea    esi,[rbp+0x8]
    7a0d12805392:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7a0d12805396:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    7a0d1280539d:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7a0d128053a1:	89 f0                	mov    eax,esi
    7a0d128053a3:	c1 e8 0c             	shr    eax,0xc
    7a0d128053a6:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d128053aa:	48 85 c0             	test   rax,rax
    7a0d128053ad:	0f 84 c9 12 00 18    	je     0x7a0d2a80667c
    7a0d128053b3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128053b9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128053bc:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7a0d128053c0:	8d 75 0c             	lea    esi,[rbp+0xc]
    7a0d128053c3:	89 f0                	mov    eax,esi
    7a0d128053c5:	c1 e8 0c             	shr    eax,0xc
    7a0d128053c8:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d128053cc:	48 85 c0             	test   rax,rax
    7a0d128053cf:	0f 84 00 13 00 18    	je     0x7a0d2a8066d5
    7a0d128053d5:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128053db:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128053de:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d128053e2:	8d 75 10             	lea    esi,[rbp+0x10]
    7a0d128053e5:	89 f0                	mov    eax,esi
    7a0d128053e7:	c1 e8 0c             	shr    eax,0xc
    7a0d128053ea:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d128053ee:	48 85 c0             	test   rax,rax
    7a0d128053f1:	0f 84 37 13 00 18    	je     0x7a0d2a80672e
    7a0d128053f7:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128053fd:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805400:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7a0d12805404:	8d 75 14             	lea    esi,[rbp+0x14]
    7a0d12805407:	89 f0                	mov    eax,esi
    7a0d12805409:	c1 e8 0c             	shr    eax,0xc
    7a0d1280540c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d12805410:	48 85 c0             	test   rax,rax
    7a0d12805413:	0f 84 6e 13 00 18    	je     0x7a0d2a806787
    7a0d12805419:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d1280541f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805422:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7a0d12805426:	8d 75 18             	lea    esi,[rbp+0x18]
    7a0d12805429:	89 f0                	mov    eax,esi
    7a0d1280542b:	c1 e8 0c             	shr    eax,0xc
    7a0d1280542e:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7a0d12805432:	48 85 c0             	test   rax,rax
    7a0d12805435:	0f 84 a5 13 00 18    	je     0x7a0d2a8067e0
    7a0d1280543b:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d12805441:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12805444:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7a0d12805448:	83 c5 1c             	add    ebp,0x1c
    7a0d1280544b:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7a0d1280544f:	b1 01                	mov    cl,0x1
    7a0d12805451:	bb 07 00 00 00       	mov    ebx,0x7
    7a0d12805456:	bd 02 00 00 00       	mov    ebp,0x2
    7a0d1280545b:	41 f6 c7 01          	test   r15b,0x1
    7a0d1280545f:	0f 85 d0 13 00 18    	jne    0x7a0d2a806835
    7a0d12805465:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7a0d1280546c:	01 d8                	add    eax,ebx
    7a0d1280546e:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7a0d12805475:	39 d0                	cmp    eax,edx
    7a0d12805477:	0f 83 92 10 00 18    	jae    0x7a0d2a80650f
    7a0d1280547d:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    7a0d12805484:	00 
    7a0d12805485:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    7a0d1280548b:	45 39 3c 10          	cmp    DWORD PTR [r8+rdx*1],r15d
    7a0d1280548f:	0f 85 7a 10 00 18    	jne    0x7a0d2a80650f
    7a0d12805495:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    7a0d1280549c:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7a0d128054a3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128054aa:	00 
    7a0d128054ab:	49 8b 44 10 08       	mov    rax,QWORD PTR [r8+rdx*1+0x8]
    7a0d128054b0:	48 83 c4 18          	add    rsp,0x18
    7a0d128054b4:	ff e0                	jmp    rax
    7a0d128054b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7a0d128054bd:	7c 01 01 00 
    7a0d128054c1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7a0d128054c8:	83 c0 03             	add    eax,0x3
    7a0d128054cb:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7a0d128054d2:	39 c8                	cmp    eax,ecx
    7a0d128054d4:	0f 83 58 10 00 18    	jae    0x7a0d2a806532
    7a0d128054da:	41 81 b8 e0 0b 08 00 	cmp    DWORD PTR [r8+0x80be0],0x1017c
    7a0d128054e1:	7c 01 01 00 
    7a0d128054e5:	0f 85 47 10 00 18    	jne    0x7a0d2a806532
    7a0d128054eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7a0d128054f2:	7c 01 01 00 
    7a0d128054f6:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7a0d128054fd:	49 8b 80 e8 0b 08 00 	mov    rax,QWORD PTR [r8+0x80be8]
    7a0d12805504:	48 83 c4 18          	add    rsp,0x18
    7a0d12805508:	ff e0                	jmp    rax
