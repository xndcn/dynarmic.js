
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65808-0-134196966220210.bin:     file format binary


Disassembly of section .data:

00007a0d2a8061b2 <.data>:
    7a0d2a8061b2:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a8061b9:	01 
    7a0d2a8061ba:	48 83 c4 28          	add    rsp,0x28
    7a0d2a8061be:	c2 08 00             	ret    0x8
    7a0d2a8061c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a8061c8:	20 01 01 00 
    7a0d2a8061cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8061d3:	04 00 00 00 
    7a0d2a8061d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8061de:	06 00 00 00 
    7a0d2a8061e2:	48 b8 e0 b8 82 06 01 	movabs rax,0x65010682b8e0
    7a0d2a8061e9:	65 00 00 
    7a0d2a8061ec:	48 89 fd             	mov    rbp,rdi
    7a0d2a8061ef:	4c 89 ef             	mov    rdi,r13
    7a0d2a8061f2:	4c 89 c6             	mov    rsi,r8
    7a0d2a8061f5:	ba 20 01 01 00       	mov    edx,0x10120
    7a0d2a8061fa:	89 d9                	mov    ecx,ebx
    7a0d2a8061fc:	4d 89 c6             	mov    r14,r8
    7a0d2a8061ff:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a806205:	ff d0                	call   rax
    7a0d2a806207:	48 89 ef             	mov    rdi,rbp
    7a0d2a80620a:	4d 89 f0             	mov    r8,r14
    7a0d2a80620d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a806214:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a80621b:	00 
    7a0d2a80621c:	bb 06 00 00 00       	mov    ebx,0x6
    7a0d2a806221:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a806226:	e9 89 ef ff e7       	jmp    0x7a0d128051b4
    7a0d2a80622b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a806232:	20 01 01 00 
    7a0d2a806236:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80623d:	04 00 00 00 
    7a0d2a806241:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806248:	06 00 00 00 
    7a0d2a80624c:	48 b8 20 56 71 06 01 	movabs rax,0x650106715620
    7a0d2a806253:	65 00 00 
    7a0d2a806256:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    7a0d2a80625b:	4c 89 c7             	mov    rdi,r8
    7a0d2a80625e:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    7a0d2a806263:	89 de                	mov    esi,ebx
    7a0d2a806265:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    7a0d2a806269:	4c 89 cd             	mov    rbp,r9
    7a0d2a80626c:	4d 89 d7             	mov    r15,r10
    7a0d2a80626f:	44 89 5c 24 10       	mov    DWORD PTR [rsp+0x10],r11d
    7a0d2a806274:	ff d0                	call   rax
    7a0d2a806276:	44 8b 5c 24 10       	mov    r11d,DWORD PTR [rsp+0x10]
    7a0d2a80627b:	4d 89 fa             	mov    r10,r15
    7a0d2a80627e:	49 89 e9             	mov    r9,rbp
    7a0d2a806281:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    7a0d2a806286:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a80628b:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a80628f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806296:	00 
    7a0d2a806297:	84 c9                	test   cl,cl
    7a0d2a806299:	0f 84 79 ee ff e7    	je     0x7a0d12805118
    7a0d2a80629f:	e9 e3 00 00 00       	jmp    0x7a0d2a806387
    7a0d2a8062a4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    7a0d2a8062ab:	20 01 01 00 
    7a0d2a8062af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8062b6:	04 00 00 00 
    7a0d2a8062ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8062c1:	06 00 00 00 
    7a0d2a8062c5:	48 b8 20 56 71 06 01 	movabs rax,0x650106715620
    7a0d2a8062cc:	65 00 00 
    7a0d2a8062cf:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    7a0d2a8062d4:	4c 89 c7             	mov    rdi,r8
    7a0d2a8062d7:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    7a0d2a8062dc:	89 ee                	mov    esi,ebp
    7a0d2a8062de:	44 89 da             	mov    edx,r11d
    7a0d2a8062e1:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    7a0d2a8062e5:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    7a0d2a8062ea:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    7a0d2a8062ef:	ff d0                	call   rax
    7a0d2a8062f1:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    7a0d2a8062f6:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    7a0d2a8062fb:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    7a0d2a806300:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a806305:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a806309:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806310:	00 
    7a0d2a806311:	84 c9                	test   cl,cl
    7a0d2a806313:	0f 84 22 ee ff e7    	je     0x7a0d1280513b
    7a0d2a806319:	eb 6c                	jmp    0x7a0d2a806387
    7a0d2a80631b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a806322:	24 01 01 00 
    7a0d2a806326:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80632d:	04 00 00 00 
    7a0d2a806331:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a806338:	06 00 00 00 
    7a0d2a80633c:	48 b8 10 b6 82 06 01 	movabs rax,0x65010682b610
    7a0d2a806343:	65 00 00 
    7a0d2a806346:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    7a0d2a80634b:	4c 89 ef             	mov    rdi,r13
    7a0d2a80634e:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    7a0d2a806352:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    7a0d2a806357:	48 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],rbx
    7a0d2a80635c:	4c 89 cb             	mov    rbx,r9
    7a0d2a80635f:	ff d0                	call   rax
    7a0d2a806361:	49 89 d9             	mov    r9,rbx
    7a0d2a806364:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    7a0d2a806369:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    7a0d2a80636e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a806373:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a806377:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a80637e:	00 
    7a0d2a80637f:	84 c9                	test   cl,cl
    7a0d2a806381:	0f 84 c6 ed ff e7    	je     0x7a0d1280514d
    7a0d2a806387:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a80638e:	e9 89 fe ff ff       	jmp    0x7a0d2a80621c
    7a0d2a806393:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    7a0d2a806398:	49 89 f7             	mov    r15,rsi
    7a0d2a80639b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    7a0d2a8063a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a8063a7:	24 01 01 00 
    7a0d2a8063ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8063b2:	04 00 00 00 
    7a0d2a8063b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8063bd:	07 00 00 00 
    7a0d2a8063c1:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a8063c8:	65 00 00 
    7a0d2a8063cb:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    7a0d2a8063cf:	4c 89 c7             	mov    rdi,r8
    7a0d2a8063d2:	89 ee                	mov    esi,ebp
    7a0d2a8063d4:	ff d0                	call   rax
    7a0d2a8063d6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a8063dd:	00 
    7a0d2a8063de:	84 c9                	test   cl,cl
    7a0d2a8063e0:	0f 85 cb 00 00 00    	jne    0x7a0d2a8064b1
    7a0d2a8063e6:	89 c5                	mov    ebp,eax
    7a0d2a8063e8:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a8063ec:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a8063f1:	4c 89 fe             	mov    rsi,r15
    7a0d2a8063f4:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    7a0d2a8063f9:	e9 65 ed ff e7       	jmp    0x7a0d12805163
    7a0d2a8063fe:	49 89 f7             	mov    r15,rsi
    7a0d2a806401:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    7a0d2a806406:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    7a0d2a80640d:	24 01 01 00 
    7a0d2a806411:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806418:	04 00 00 00 
    7a0d2a80641c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a806423:	07 00 00 00 
    7a0d2a806427:	48 b8 f0 55 71 06 01 	movabs rax,0x6501067155f0
    7a0d2a80642e:	65 00 00 
    7a0d2a806431:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    7a0d2a806435:	4c 89 c7             	mov    rdi,r8
    7a0d2a806438:	89 de                	mov    esi,ebx
    7a0d2a80643a:	ff d0                	call   rax
    7a0d2a80643c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a806443:	00 
    7a0d2a806444:	84 c9                	test   cl,cl
    7a0d2a806446:	75 69                	jne    0x7a0d2a8064b1
    7a0d2a806448:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a80644c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a806451:	4c 89 fe             	mov    rsi,r15
    7a0d2a806454:	e9 20 ed ff e7       	jmp    0x7a0d12805179
    7a0d2a806459:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012e
    7a0d2a806460:	2e 01 01 00 
    7a0d2a806464:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80646b:	02 00 00 00 
    7a0d2a80646f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    7a0d2a806476:	0b 00 00 00 
    7a0d2a80647a:	48 b8 e0 aa 82 06 01 	movabs rax,0x65010682aae0
    7a0d2a806481:	65 00 00 
    7a0d2a806484:	49 89 ff             	mov    r15,rdi
    7a0d2a806487:	4c 89 ef             	mov    rdi,r13
    7a0d2a80648a:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a80648f:	4c 89 c2             	mov    rdx,r8
    7a0d2a806492:	4d 89 c6             	mov    r14,r8
    7a0d2a806495:	ff d0                	call   rax
    7a0d2a806497:	4c 89 ff             	mov    rdi,r15
    7a0d2a80649a:	4d 89 f0             	mov    r8,r14
    7a0d2a80649d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a8064a4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    7a0d2a8064ab:	00 
    7a0d2a8064ac:	e9 03 ed ff e7       	jmp    0x7a0d128051b4
    7a0d2a8064b1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    7a0d2a8064b8:	bb 07 00 00 00       	mov    ebx,0x7
    7a0d2a8064bd:	bd 04 00 00 00       	mov    ebp,0x4
    7a0d2a8064c2:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    7a0d2a8064c6:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7a0d2a8064cb:	e9 e4 ec ff e7       	jmp    0x7a0d128051b4
