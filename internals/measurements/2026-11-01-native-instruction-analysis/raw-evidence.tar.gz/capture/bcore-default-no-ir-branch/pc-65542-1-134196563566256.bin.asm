
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65542-1-134196563566256.bin:     file format binary


Disassembly of section .data:

00007a0d12805eb0 <.data>:
    7a0d12805eb0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12805eb7:	8b 88 44 00 10 00    	mov    ecx,DWORD PTR [rax+0x100044]
    7a0d12805ebd:	ff c1                	inc    ecx
    7a0d12805ebf:	89 88 44 00 10 00    	mov    DWORD PTR [rax+0x100044],ecx
    7a0d12805ec5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d12805ecb:	0f 84 2f 17 00 18    	je     0x7a0d2a807600
    7a0d12805ed1:	50                   	push   rax
    7a0d12805ed2:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    7a0d12805ed7:	b9 00 00 00 01       	mov    ecx,0x1000000
    7a0d12805edc:	09 c1                	or     ecx,eax
    7a0d12805ede:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    7a0d12805ee2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10006
    7a0d12805ee9:	06 00 01 00 
    7a0d12805eed:	0f 84 39 17 00 18    	je     0x7a0d2a80762c
    7a0d12805ef3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10006
    7a0d12805efa:	06 00 01 00 
    7a0d12805efe:	0f 84 28 17 00 18    	je     0x7a0d2a80762c
    7a0d12805f04:	58                   	pop    rax
    7a0d12805f05:	50                   	push   rax
    7a0d12805f06:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    7a0d12805f0b:	c1 e0 10             	shl    eax,0x10
    7a0d12805f0e:	b9 04 00 00 00       	mov    ecx,0x4
    7a0d12805f13:	09 c1                	or     ecx,eax
    7a0d12805f15:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    7a0d12805f19:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000a
    7a0d12805f20:	0a 00 01 00 
    7a0d12805f24:	0f 84 62 17 00 18    	je     0x7a0d2a80768c
    7a0d12805f2a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000a
    7a0d12805f31:	0a 00 01 00 
    7a0d12805f35:	0f 84 51 17 00 18    	je     0x7a0d2a80768c
    7a0d12805f3b:	58                   	pop    rax
    7a0d12805f3c:	50                   	push   rax
    7a0d12805f3d:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    7a0d12805f41:	f6 c1 03             	test   cl,0x3
    7a0d12805f44:	0f 85 a2 17 00 18    	jne    0x7a0d2a8076ec
    7a0d12805f4a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12805f51:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12805f55:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12805f5c:	48 89 ce             	mov    rsi,rcx
    7a0d12805f5f:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12805f63:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12805f67:	48 85 c0             	test   rax,rax
    7a0d12805f6a:	0f 84 cf 17 00 18    	je     0x7a0d2a80773f
    7a0d12805f70:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12805f76:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12805f79:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000e
    7a0d12805f80:	0e 00 01 00 
    7a0d12805f84:	0f 84 f0 17 00 18    	je     0x7a0d2a80777a
    7a0d12805f8a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000e
    7a0d12805f91:	0e 00 01 00 
    7a0d12805f95:	0f 84 df 17 00 18    	je     0x7a0d2a80777a
    7a0d12805f9b:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12805f9e:	0f 85 17 18 00 18    	jne    0x7a0d2a8077bb
    7a0d12805fa4:	58                   	pop    rax
    7a0d12805fa5:	e9 0f 00 00 00       	jmp    0x7a0d12805fb9
    7a0d12805faa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12805fb1:	00 
    7a0d12805fb2:	74 f0                	je     0x7a0d12805fa4
    7a0d12805fb4:	e9 6a 17 00 18       	jmp    0x7a0d2a807723
    7a0d12805fb9:	50                   	push   rax
    7a0d12805fba:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12805fc1:	01 
    7a0d12805fc2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10010
    7a0d12805fc9:	10 00 01 00 
    7a0d12805fcd:	0f 84 1a 18 00 18    	je     0x7a0d2a8077ed
    7a0d12805fd3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10010
    7a0d12805fda:	10 00 01 00 
    7a0d12805fde:	0f 84 09 18 00 18    	je     0x7a0d2a8077ed
    7a0d12805fe4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    7a0d12805feb:	10 00 01 00 
    7a0d12805fef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12805ff6:	02 00 00 00 
    7a0d12805ffa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d12806001:	04 00 00 00 
    7a0d12806005:	58                   	pop    rax
    7a0d12806006:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d1280600d:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12806014:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d1280601b:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12806022:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12806029:	39 f1                	cmp    ecx,esi
    7a0d1280602b:	0f 83 f4 17 00 18    	jae    0x7a0d2a807825
    7a0d12806031:	81 fa 06 00 01 00    	cmp    edx,0x10006
    7a0d12806037:	75 14                	jne    0x7a0d1280604d
    7a0d12806039:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12806040:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12806047:	00 
    7a0d12806048:	e9 63 fe ff ff       	jmp    0x7a0d12805eb0
    7a0d1280604d:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12806054:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d1280605a:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d1280605d:	0f 85 c2 17 00 18    	jne    0x7a0d2a807825
    7a0d12806063:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280606a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12806071:	00 
    7a0d12806072:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12806077:	ff e0                	jmp    rax
