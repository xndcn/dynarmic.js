
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65536-1-134196966195200.bin:     file format binary


Disassembly of section .data:

00007a0d2a800000 <.data>:
    7a0d2a800000:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a800006:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a800009:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80000f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a800016:	0f 87 15 03 00 e8    	ja     0x7a0d12800331
    7a0d2a80001c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x0
    7a0d2a800023:	00 00 00 00 
    7a0d2a800027:	e9 05 03 00 e8       	jmp    0x7a0d12800331
    7a0d2a80002c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10000
    7a0d2a800033:	00 00 01 00 
    7a0d2a800037:	b8 00 00 01 00       	mov    eax,0x10000
    7a0d2a80003c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800043:	02 00 00 00 
    7a0d2a800047:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80004e:	01 00 00 00 
    7a0d2a800052:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a800055:	be 00 00 01 00       	mov    esi,0x10000
    7a0d2a80005a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80005d:	e8 fe 00 00 e8       	call   0x7a0d12800160
    7a0d2a800062:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a800069:	00 
    7a0d2a80006a:	0f 84 e9 02 00 e8    	je     0x7a0d12800359
    7a0d2a800070:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a800077:	02 00 00 00 
    7a0d2a80007b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a800082:	01 00 00 00 
    7a0d2a800086:	58                   	pop    rax
    7a0d2a800087:	e9 66 03 00 e8       	jmp    0x7a0d128003f2
    7a0d2a80008c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7a0d2a800093:	14 00 01 00 
    7a0d2a800097:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a80009e:	04 00 00 00 
    7a0d2a8000a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8000a9:	02 00 00 00 
    7a0d2a8000ad:	be 02 00 01 00       	mov    esi,0x10002
    7a0d2a8000b2:	ba 02 00 01 00       	mov    edx,0x10002
    7a0d2a8000b7:	4c 89 ef             	mov    rdi,r13
    7a0d2a8000ba:	e8 a1 00 00 e8       	call   0x7a0d12800160
    7a0d2a8000bf:	e9 0c 03 00 e8       	jmp    0x7a0d128003d0
    7a0d2a8000c4:	c2 08 00             	ret    0x8
