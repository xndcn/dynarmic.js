
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65542-1-134196966225408.bin:     file format binary


Disassembly of section .data:

00007a0d2a807600 <.data>:
    7a0d2a807600:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a807606:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a807609:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80760f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a807616:	0f 87 b5 e8 ff e7    	ja     0x7a0d12805ed1
    7a0d2a80761c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x11
    7a0d2a807623:	11 00 00 00 
    7a0d2a807627:	e9 a5 e8 ff e7       	jmp    0x7a0d12805ed1
    7a0d2a80762c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10006
    7a0d2a807633:	06 00 01 00 
    7a0d2a807637:	b8 06 00 01 00       	mov    eax,0x10006
    7a0d2a80763c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a807643:	04 00 00 00 
    7a0d2a807647:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80764e:	01 00 00 00 
    7a0d2a807652:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a807655:	be 06 00 01 00       	mov    esi,0x10006
    7a0d2a80765a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80765d:	e8 fe 8a ff e7       	call   0x7a0d12800160
    7a0d2a807662:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807669:	00 
    7a0d2a80766a:	0f 84 94 e8 ff e7    	je     0x7a0d12805f04
    7a0d2a807670:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a807677:	04 00 00 00 
    7a0d2a80767b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a807682:	01 00 00 00 
    7a0d2a807686:	58                   	pop    rax
    7a0d2a807687:	e9 7a e9 ff e7       	jmp    0x7a0d12806006
    7a0d2a80768c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000a
    7a0d2a807693:	0a 00 01 00 
    7a0d2a807697:	b8 0a 00 01 00       	mov    eax,0x1000a
    7a0d2a80769c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8076a3:	04 00 00 00 
    7a0d2a8076a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8076ae:	02 00 00 00 
    7a0d2a8076b2:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8076b5:	be 0a 00 01 00       	mov    esi,0x1000a
    7a0d2a8076ba:	4c 89 ef             	mov    rdi,r13
    7a0d2a8076bd:	e8 9e 8a ff e7       	call   0x7a0d12800160
    7a0d2a8076c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8076c9:	00 
    7a0d2a8076ca:	0f 84 6b e8 ff e7    	je     0x7a0d12805f3b
    7a0d2a8076d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8076d7:	04 00 00 00 
    7a0d2a8076db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8076e2:	02 00 00 00 
    7a0d2a8076e6:	58                   	pop    rax
    7a0d2a8076e7:	e9 1a e9 ff e7       	jmp    0x7a0d12806006
    7a0d2a8076ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    7a0d2a8076f3:	0e 00 01 00 
    7a0d2a8076f7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8076fe:	02 00 00 00 
    7a0d2a807702:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a807709:	03 00 00 00 
    7a0d2a80770d:	ba 0e 00 01 00       	mov    edx,0x1000e
    7a0d2a807712:	4c 89 ef             	mov    rdi,r13
    7a0d2a807715:	4c 89 f6             	mov    rsi,r14
    7a0d2a807718:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7a0d2a80771e:	e8 5d 89 ff e7       	call   0x7a0d12800080
    7a0d2a807723:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80772a:	02 00 00 00 
    7a0d2a80772e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a807735:	03 00 00 00 
    7a0d2a807739:	58                   	pop    rax
    7a0d2a80773a:	e9 c7 e8 ff e7       	jmp    0x7a0d12806006
    7a0d2a80773f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    7a0d2a807746:	0e 00 01 00 
    7a0d2a80774a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807751:	02 00 00 00 
    7a0d2a807755:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80775c:	03 00 00 00 
    7a0d2a807760:	4c 89 f7             	mov    rdi,r14
    7a0d2a807763:	89 ce                	mov    esi,ecx
    7a0d2a807765:	e8 06 89 ff e7       	call   0x7a0d12800070
    7a0d2a80776a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a807771:	00 
    7a0d2a807772:	0f 84 01 e8 ff e7    	je     0x7a0d12805f79
    7a0d2a807778:	eb a9                	jmp    0x7a0d2a807723
    7a0d2a80777a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    7a0d2a807781:	0e 00 01 00 
    7a0d2a807785:	b8 0e 00 01 00       	mov    eax,0x1000e
    7a0d2a80778a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a807791:	02 00 00 00 
    7a0d2a807795:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80779c:	03 00 00 00 
    7a0d2a8077a0:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8077a3:	be 0e 00 01 00       	mov    esi,0x1000e
    7a0d2a8077a8:	4c 89 ef             	mov    rdi,r13
    7a0d2a8077ab:	e8 b0 89 ff e7       	call   0x7a0d12800160
    7a0d2a8077b0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d2a8077b3:	0f 84 f1 e7 ff e7    	je     0x7a0d12805faa
    7a0d2a8077b9:	eb 0f                	jmp    0x7a0d2a8077ca
    7a0d2a8077bb:	b8 0e 00 01 00       	mov    eax,0x1000e
    7a0d2a8077c0:	83 c0 02             	add    eax,0x2
    7a0d2a8077c3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a8077ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8077d1:	02 00 00 00 
    7a0d2a8077d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8077dc:	03 00 00 00 
    7a0d2a8077e0:	4c 89 ef             	mov    rdi,r13
    7a0d2a8077e3:	e8 68 89 ff e7       	call   0x7a0d12800150
    7a0d2a8077e8:	e9 bd e7 ff e7       	jmp    0x7a0d12805faa
    7a0d2a8077ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    7a0d2a8077f4:	10 00 01 00 
    7a0d2a8077f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8077ff:	02 00 00 00 
    7a0d2a807803:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a80780a:	04 00 00 00 
    7a0d2a80780e:	be 10 00 01 00       	mov    esi,0x10010
    7a0d2a807813:	ba 10 00 01 00       	mov    edx,0x10010
    7a0d2a807818:	4c 89 ef             	mov    rdi,r13
    7a0d2a80781b:	e8 40 89 ff e7       	call   0x7a0d12800160
    7a0d2a807820:	e9 bf e7 ff e7       	jmp    0x7a0d12805fe4
    7a0d2a807825:	c2 08 00             	ret    0x8
