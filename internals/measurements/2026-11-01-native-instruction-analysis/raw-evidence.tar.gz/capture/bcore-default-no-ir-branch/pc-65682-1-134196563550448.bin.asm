
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65682-1-134196563550448.bin:     file format binary


Disassembly of section .data:

00007a0d128020f0 <.data>:
    7a0d128020f0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128020f7:	8b 88 10 00 10 00    	mov    ecx,DWORD PTR [rax+0x100010]
    7a0d128020fd:	ff c1                	inc    ecx
    7a0d128020ff:	89 88 10 00 10 00    	mov    DWORD PTR [rax+0x100010],ecx
    7a0d12802105:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d1280210b:	0f 84 4f 0d 00 18    	je     0x7a0d2a802e60
    7a0d12802111:	50                   	push   rax
    7a0d12802112:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12802116:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d1280211d:	31 d2                	xor    edx,edx
    7a0d1280211f:	85 c0                	test   eax,eax
    7a0d12802121:	0f 94 c2             	sete   dl
    7a0d12802124:	c1 e8 1f             	shr    eax,0x1f
    7a0d12802127:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d1280212e:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d12802135:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d1280213c:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7a0d12802143:	00 00 00 
    7a0d12802146:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7a0d1280214d:	81 f9 92 00 01 00    	cmp    ecx,0x10092
    7a0d12802153:	0f 84 33 0d 00 18    	je     0x7a0d2a802e8c
    7a0d12802159:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10092
    7a0d12802160:	92 00 01 00 
    7a0d12802164:	0f 84 22 0d 00 18    	je     0x7a0d2a802e8c
    7a0d1280216a:	58                   	pop    rax
    7a0d1280216b:	50                   	push   rax
    7a0d1280216c:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d12802173:	00 
    7a0d12802174:	74 28                	je     0x7a0d1280219e
    7a0d12802176:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    7a0d1280217d:	94 00 01 00 
    7a0d12802181:	0f 84 65 0d 00 18    	je     0x7a0d2a802eec
    7a0d12802187:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    7a0d1280218e:	94 00 01 00 
    7a0d12802192:	0f 84 54 0d 00 18    	je     0x7a0d2a802eec
    7a0d12802198:	58                   	pop    rax
    7a0d12802199:	e9 55 00 00 00       	jmp    0x7a0d128021f3
    7a0d1280219e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128021a5:	01 
    7a0d128021a6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    7a0d128021ad:	94 00 01 00 
    7a0d128021b1:	0f 84 7e 0d 00 18    	je     0x7a0d2a802f35
    7a0d128021b7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    7a0d128021be:	94 00 01 00 
    7a0d128021c2:	0f 84 6d 0d 00 18    	je     0x7a0d2a802f35
    7a0d128021c8:	b8 94 00 01 00       	mov    eax,0x10094
    7a0d128021cd:	83 c0 2c             	add    eax,0x2c
    7a0d128021d0:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d128021d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d128021de:	02 00 00 00 
    7a0d128021e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d128021e9:	02 00 00 00 
    7a0d128021ed:	58                   	pop    rax
    7a0d128021ee:	e9 15 01 00 00       	jmp    0x7a0d12802308
    7a0d128021f3:	50                   	push   rax
    7a0d128021f4:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    7a0d128021f8:	f6 c1 03             	test   cl,0x3
    7a0d128021fb:	0f 85 70 0d 00 18    	jne    0x7a0d2a802f71
    7a0d12802201:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12802208:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7a0d1280220c:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12802213:	48 89 ce             	mov    rsi,rcx
    7a0d12802216:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d1280221a:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d1280221e:	48 85 c0             	test   rax,rax
    7a0d12802221:	0f 84 9d 0d 00 18    	je     0x7a0d2a802fc4
    7a0d12802227:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280222d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12802230:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10096
    7a0d12802237:	96 00 01 00 
    7a0d1280223b:	0f 84 be 0d 00 18    	je     0x7a0d2a802fff
    7a0d12802241:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10096
    7a0d12802248:	96 00 01 00 
    7a0d1280224c:	0f 84 ad 0d 00 18    	je     0x7a0d2a802fff
    7a0d12802252:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12802255:	0f 85 e5 0d 00 18    	jne    0x7a0d2a803040
    7a0d1280225b:	58                   	pop    rax
    7a0d1280225c:	e9 0f 00 00 00       	jmp    0x7a0d12802270
    7a0d12802261:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12802268:	00 
    7a0d12802269:	74 f0                	je     0x7a0d1280225b
    7a0d1280226b:	e9 38 0d 00 18       	jmp    0x7a0d2a802fa8
    7a0d12802270:	50                   	push   rax
    7a0d12802271:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12802278:	b9 98 00 01 00       	mov    ecx,0x10098
    7a0d1280227d:	83 c1 04             	add    ecx,0x4
    7a0d12802280:	89 ca                	mov    edx,ecx
    7a0d12802282:	3d 98 00 01 00       	cmp    eax,0x10098
    7a0d12802287:	75 07                	jne    0x7a0d12802290
    7a0d12802289:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d12802290:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d12802297:	02 
    7a0d12802298:	0f 43 ca             	cmovae ecx,edx
    7a0d1280229b:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d128022a2:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d128022a9:	89 cf                	mov    edi,ecx
    7a0d128022ab:	81 fa 98 00 01 00    	cmp    edx,0x10098
    7a0d128022b1:	75 07                	jne    0x7a0d128022ba
    7a0d128022b3:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d128022ba:	83 fe 02             	cmp    esi,0x2
    7a0d128022bd:	0f 43 cf             	cmovae ecx,edi
    7a0d128022c0:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d128022c7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128022ce:	01 
    7a0d128022cf:	3d 98 00 01 00       	cmp    eax,0x10098
    7a0d128022d4:	0f 84 98 0d 00 18    	je     0x7a0d2a803072
    7a0d128022da:	81 fa 98 00 01 00    	cmp    edx,0x10098
    7a0d128022e0:	0f 84 8c 0d 00 18    	je     0x7a0d2a803072
    7a0d128022e6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7a0d128022ed:	28 04 01 00 
    7a0d128022f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d128022f8:	04 00 00 00 
    7a0d128022fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d12802303:	04 00 00 00 
    7a0d12802307:	58                   	pop    rax
    7a0d12802308:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d1280230f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12802316:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d1280231d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d12802324:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d1280232b:	39 f1                	cmp    ecx,esi
    7a0d1280232d:	0f 83 77 0d 00 18    	jae    0x7a0d2a8030aa
    7a0d12802333:	81 fa 92 00 01 00    	cmp    edx,0x10092
    7a0d12802339:	75 14                	jne    0x7a0d1280234f
    7a0d1280233b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12802342:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802349:	00 
    7a0d1280234a:	e9 a1 fd ff ff       	jmp    0x7a0d128020f0
    7a0d1280234f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12802356:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d1280235c:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d1280235f:	0f 85 45 0d 00 18    	jne    0x7a0d2a8030aa
    7a0d12802365:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280236c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12802373:	00 
    7a0d12802374:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12802379:	ff e0                	jmp    rax
