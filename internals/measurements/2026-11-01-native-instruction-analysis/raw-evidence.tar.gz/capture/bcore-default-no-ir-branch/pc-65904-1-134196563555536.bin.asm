
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65904-1-134196563555536.bin:     file format binary


Disassembly of section .data:

00007a0d128034d0 <.data>:
    7a0d128034d0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128034d7:	8b 88 28 00 10 00    	mov    ecx,DWORD PTR [rax+0x100028]
    7a0d128034dd:	ff c1                	inc    ecx
    7a0d128034df:	89 88 28 00 10 00    	mov    DWORD PTR [rax+0x100028],ecx
    7a0d128034e5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d128034eb:	0f 84 2f 13 00 18    	je     0x7a0d2a804820
    7a0d128034f1:	50                   	push   rax
    7a0d128034f2:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d128034f6:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    7a0d128034fa:	89 ca                	mov    edx,ecx
    7a0d128034fc:	c1 ea 1f             	shr    edx,0x1f
    7a0d128034ff:	89 c6                	mov    esi,eax
    7a0d12803501:	c1 ee 1f             	shr    esi,0x1f
    7a0d12803504:	31 ff                	xor    edi,edi
    7a0d12803506:	01 c1                	add    ecx,eax
    7a0d12803508:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    7a0d1280350c:	40 0f 92 c7          	setb   dil
    7a0d12803510:	89 c8                	mov    eax,ecx
    7a0d12803512:	c1 e8 1f             	shr    eax,0x1f
    7a0d12803515:	31 c6                	xor    esi,eax
    7a0d12803517:	31 c2                	xor    edx,eax
    7a0d12803519:	21 f2                	and    edx,esi
    7a0d1280351b:	31 f6                	xor    esi,esi
    7a0d1280351d:	85 c9                	test   ecx,ecx
    7a0d1280351f:	40 0f 94 c6          	sete   sil
    7a0d12803523:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d1280352a:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12803531:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7a0d12803538:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7a0d1280353f:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7a0d12803546:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7a0d1280354d:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7a0d12803554:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10170
    7a0d1280355b:	70 01 01 00 
    7a0d1280355f:	0f 84 e7 12 00 18    	je     0x7a0d2a80484c
    7a0d12803565:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10170
    7a0d1280356c:	70 01 01 00 
    7a0d12803570:	0f 84 d6 12 00 18    	je     0x7a0d2a80484c
    7a0d12803576:	58                   	pop    rax
    7a0d12803577:	50                   	push   rax
    7a0d12803578:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d1280357f:	b9 72 01 01 00       	mov    ecx,0x10172
    7a0d12803584:	83 c1 04             	add    ecx,0x4
    7a0d12803587:	89 ca                	mov    edx,ecx
    7a0d12803589:	3d 72 01 01 00       	cmp    eax,0x10172
    7a0d1280358e:	75 07                	jne    0x7a0d12803597
    7a0d12803590:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d12803597:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d1280359e:	02 
    7a0d1280359f:	0f 43 ca             	cmovae ecx,edx
    7a0d128035a2:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d128035a9:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d128035b0:	89 cf                	mov    edi,ecx
    7a0d128035b2:	81 fa 72 01 01 00    	cmp    edx,0x10172
    7a0d128035b8:	75 07                	jne    0x7a0d128035c1
    7a0d128035ba:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d128035c1:	83 fe 02             	cmp    esi,0x2
    7a0d128035c4:	0f 43 cf             	cmovae ecx,edi
    7a0d128035c7:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d128035ce:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128035d5:	01 
    7a0d128035d6:	3d 72 01 01 00       	cmp    eax,0x10172
    7a0d128035db:	0f 84 cb 12 00 18    	je     0x7a0d2a8048ac
    7a0d128035e1:	81 fa 72 01 01 00    	cmp    edx,0x10172
    7a0d128035e7:	0f 84 bf 12 00 18    	je     0x7a0d2a8048ac
    7a0d128035ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7a0d128035f4:	30 01 01 00 
    7a0d128035f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d128035ff:	04 00 00 00 
    7a0d12803603:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d1280360a:	02 00 00 00 
    7a0d1280360e:	58                   	pop    rax
    7a0d1280360f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12803616:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d1280361d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12803624:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280362b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12803632:	39 f1                	cmp    ecx,esi
    7a0d12803634:	0f 83 aa 12 00 18    	jae    0x7a0d2a8048e4
    7a0d1280363a:	81 fa 70 01 01 00    	cmp    edx,0x10170
    7a0d12803640:	75 14                	jne    0x7a0d12803656
    7a0d12803642:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803649:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12803650:	00 
    7a0d12803651:	e9 7a fe ff ff       	jmp    0x7a0d128034d0
    7a0d12803656:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d1280365d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12803663:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12803666:	0f 85 78 12 00 18    	jne    0x7a0d2a8048e4
    7a0d1280366c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12803673:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d1280367a:	00 
    7a0d1280367b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d12803680:	ff e0                	jmp    rax
