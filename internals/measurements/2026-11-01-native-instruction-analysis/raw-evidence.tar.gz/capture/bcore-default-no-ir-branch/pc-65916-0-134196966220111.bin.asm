
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65916-0-134196966220111.bin:     file format binary


Disassembly of section .data:

00007a0d2a80614f <.data>:
    7a0d2a80614f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7a0d2a806156:	70 01 01 00 
    7a0d2a80615a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a806161:	02 00 00 00 
    7a0d2a806165:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80616c:	05 00 00 00 
    7a0d2a806170:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a806177:	01 
    7a0d2a806178:	c2 08 00             	ret    0x8
    7a0d2a80617b:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    7a0d2a806182:	01 
    7a0d2a806183:	c2 08 00             	ret    0x8
    7a0d2a806186:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d2a80618d:	10 01 01 00 
    7a0d2a806191:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a806198:	04 00 00 00 
    7a0d2a80619c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8061a3:	07 00 00 00 
    7a0d2a8061a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d2a8061ae:	01 
    7a0d2a8061af:	c2 08 00             	ret    0x8
