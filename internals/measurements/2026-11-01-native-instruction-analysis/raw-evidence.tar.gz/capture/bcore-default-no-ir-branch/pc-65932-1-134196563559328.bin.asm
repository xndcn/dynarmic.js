
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65932-1-134196563559328.bin:     file format binary


Disassembly of section .data:

00007a0d128043a0 <.data>:
    7a0d128043a0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d128043a7:	8b 88 38 00 10 00    	mov    ecx,DWORD PTR [rax+0x100038]
    7a0d128043ad:	ff c1                	inc    ecx
    7a0d128043af:	89 88 38 00 10 00    	mov    DWORD PTR [rax+0x100038],ecx
    7a0d128043b5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7a0d128043bb:	0f 84 6f 14 00 18    	je     0x7a0d2a805830
    7a0d128043c1:	50                   	push   rax
    7a0d128043c2:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
    7a0d128043c6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d128043cd:	31 d2                	xor    edx,edx
    7a0d128043cf:	89 c6                	mov    esi,eax
    7a0d128043d1:	ff c6                	inc    esi
    7a0d128043d3:	0f 94 c2             	sete   dl
    7a0d128043d6:	41 89 75 18          	mov    DWORD PTR [r13+0x18],esi
    7a0d128043da:	c1 e8 1f             	shr    eax,0x1f
    7a0d128043dd:	89 f7                	mov    edi,esi
    7a0d128043df:	c1 ef 1f             	shr    edi,0x1f
    7a0d128043e2:	f7 d0                	not    eax
    7a0d128043e4:	21 f8                	and    eax,edi
    7a0d128043e6:	31 db                	xor    ebx,ebx
    7a0d128043e8:	85 f6                	test   esi,esi
    7a0d128043ea:	0f 94 c3             	sete   bl
    7a0d128043ed:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7a0d128043f4:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d128043fb:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7a0d12804402:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7a0d12804409:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    7a0d12804410:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7a0d12804417:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7a0d1280441e:	81 f9 8c 01 01 00    	cmp    ecx,0x1018c
    7a0d12804424:	0f 84 32 14 00 18    	je     0x7a0d2a80585c
    7a0d1280442a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1018c
    7a0d12804431:	8c 01 01 00 
    7a0d12804435:	0f 84 21 14 00 18    	je     0x7a0d2a80585c
    7a0d1280443b:	58                   	pop    rax
    7a0d1280443c:	50                   	push   rax
    7a0d1280443d:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    7a0d12804441:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    7a0d12804445:	31 d2                	xor    edx,edx
    7a0d12804447:	31 f6                	xor    esi,esi
    7a0d12804449:	31 ff                	xor    edi,edi
    7a0d1280444b:	31 db                	xor    ebx,ebx
    7a0d1280444d:	39 c8                	cmp    eax,ecx
    7a0d1280444f:	0f 96 c2             	setbe  dl
    7a0d12804452:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7a0d12804459:	40 0f 94 c6          	sete   sil
    7a0d1280445d:	40 0f 92 c7          	setb   dil
    7a0d12804461:	0f 93 c3             	setae  bl
    7a0d12804464:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7a0d1280446b:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7a0d12804472:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    7a0d12804479:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    7a0d12804480:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1018e
    7a0d12804487:	8e 01 01 00 
    7a0d1280448b:	0f 84 2b 14 00 18    	je     0x7a0d2a8058bc
    7a0d12804491:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1018e
    7a0d12804498:	8e 01 01 00 
    7a0d1280449c:	0f 84 1a 14 00 18    	je     0x7a0d2a8058bc
    7a0d128044a2:	58                   	pop    rax
    7a0d128044a3:	50                   	push   rax
    7a0d128044a4:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7a0d128044ab:	00 
    7a0d128044ac:	74 28                	je     0x7a0d128044d6
    7a0d128044ae:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10190
    7a0d128044b5:	90 01 01 00 
    7a0d128044b9:	0f 84 5d 14 00 18    	je     0x7a0d2a80591c
    7a0d128044bf:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10190
    7a0d128044c6:	90 01 01 00 
    7a0d128044ca:	0f 84 4c 14 00 18    	je     0x7a0d2a80591c
    7a0d128044d0:	58                   	pop    rax
    7a0d128044d1:	e9 55 00 00 00       	jmp    0x7a0d1280452b
    7a0d128044d6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d128044dd:	01 
    7a0d128044de:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10190
    7a0d128044e5:	90 01 01 00 
    7a0d128044e9:	0f 84 76 14 00 18    	je     0x7a0d2a805965
    7a0d128044ef:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10190
    7a0d128044f6:	90 01 01 00 
    7a0d128044fa:	0f 84 65 14 00 18    	je     0x7a0d2a805965
    7a0d12804500:	b8 90 01 01 00       	mov    eax,0x10190
    7a0d12804505:	83 c0 ec             	add    eax,0xffffffec
    7a0d12804508:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280450f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d12804516:	02 00 00 00 
    7a0d1280451a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d12804521:	03 00 00 00 
    7a0d12804525:	58                   	pop    rax
    7a0d12804526:	e9 33 02 00 00       	jmp    0x7a0d1280475e
    7a0d1280452b:	50                   	push   rax
    7a0d1280452c:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7a0d12804530:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7a0d12804537:	31 d2                	xor    edx,edx
    7a0d12804539:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    7a0d1280453d:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7a0d12804541:	0f 94 c2             	sete   dl
    7a0d12804544:	c1 e8 1f             	shr    eax,0x1f
    7a0d12804547:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7a0d1280454e:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7a0d12804555:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7a0d1280455c:	00 00 00 00 
    7a0d12804560:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7a0d12804567:	00 00 00 00 
    7a0d1280456b:	81 f9 92 01 01 00    	cmp    ecx,0x10192
    7a0d12804571:	0f 84 2a 14 00 18    	je     0x7a0d2a8059a1
    7a0d12804577:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10192
    7a0d1280457e:	92 01 01 00 
    7a0d12804582:	0f 84 19 14 00 18    	je     0x7a0d2a8059a1
    7a0d12804588:	58                   	pop    rax
    7a0d12804589:	50                   	push   rax
    7a0d1280458a:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7a0d1280458e:	f6 c3 03             	test   bl,0x3
    7a0d12804591:	0f 85 6a 14 00 18    	jne    0x7a0d2a805a01
    7a0d12804597:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d1280459e:	48 89 d8             	mov    rax,rbx
    7a0d128045a1:	48 c1 e8 0c          	shr    rax,0xc
    7a0d128045a5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128045aa:	48 85 c0             	test   rax,rax
    7a0d128045ad:	0f 84 a0 14 00 18    	je     0x7a0d2a805a53
    7a0d128045b3:	89 d9                	mov    ecx,ebx
    7a0d128045b5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d128045bb:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7a0d128045bf:	89 de                	mov    esi,ebx
    7a0d128045c1:	83 c6 04             	add    esi,0x4
    7a0d128045c4:	89 f0                	mov    eax,esi
    7a0d128045c6:	c1 e8 0c             	shr    eax,0xc
    7a0d128045c9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128045ce:	48 85 c0             	test   rax,rax
    7a0d128045d1:	0f 84 b9 14 00 18    	je     0x7a0d2a805a90
    7a0d128045d7:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128045dd:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128045e0:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7a0d128045e3:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7a0d128045e7:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7a0d128045ee:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7a0d128045f2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10194
    7a0d128045f9:	94 01 01 00 
    7a0d128045fd:	0f 84 c9 14 00 18    	je     0x7a0d2a805acc
    7a0d12804603:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10194
    7a0d1280460a:	94 01 01 00 
    7a0d1280460e:	0f 84 b8 14 00 18    	je     0x7a0d2a805acc
    7a0d12804614:	58                   	pop    rax
    7a0d12804615:	50                   	push   rax
    7a0d12804616:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7a0d1280461a:	f6 c3 03             	test   bl,0x3
    7a0d1280461d:	0f 85 f2 14 00 18    	jne    0x7a0d2a805b15
    7a0d12804623:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7a0d1280462a:	48 89 d8             	mov    rax,rbx
    7a0d1280462d:	48 c1 e8 0c          	shr    rax,0xc
    7a0d12804631:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d12804636:	48 85 c0             	test   rax,rax
    7a0d12804639:	0f 84 28 15 00 18    	je     0x7a0d2a805b67
    7a0d1280463f:	89 d9                	mov    ecx,ebx
    7a0d12804641:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12804647:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d1280464a:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7a0d1280464e:	8d 73 04             	lea    esi,[rbx+0x4]
    7a0d12804651:	89 f0                	mov    eax,esi
    7a0d12804653:	c1 e8 0c             	shr    eax,0xc
    7a0d12804656:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280465b:	48 85 c0             	test   rax,rax
    7a0d1280465e:	0f 84 3e 15 00 18    	je     0x7a0d2a805ba2
    7a0d12804664:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d1280466a:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d1280466d:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7a0d12804671:	8d 73 08             	lea    esi,[rbx+0x8]
    7a0d12804674:	89 f0                	mov    eax,esi
    7a0d12804676:	c1 e8 0c             	shr    eax,0xc
    7a0d12804679:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d1280467e:	48 85 c0             	test   rax,rax
    7a0d12804681:	0f 84 57 15 00 18    	je     0x7a0d2a805bde
    7a0d12804687:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d1280468d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d12804690:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7a0d12804694:	8d 73 0c             	lea    esi,[rbx+0xc]
    7a0d12804697:	89 f0                	mov    eax,esi
    7a0d12804699:	c1 e8 0c             	shr    eax,0xc
    7a0d1280469c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128046a1:	48 85 c0             	test   rax,rax
    7a0d128046a4:	0f 84 70 15 00 18    	je     0x7a0d2a805c1a
    7a0d128046aa:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128046b0:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128046b3:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7a0d128046b7:	89 de                	mov    esi,ebx
    7a0d128046b9:	83 c6 10             	add    esi,0x10
    7a0d128046bc:	89 f0                	mov    eax,esi
    7a0d128046be:	c1 e8 0c             	shr    eax,0xc
    7a0d128046c1:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7a0d128046c6:	48 85 c0             	test   rax,rax
    7a0d128046c9:	0f 84 87 15 00 18    	je     0x7a0d2a805c56
    7a0d128046cf:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7a0d128046d5:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7a0d128046d8:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7a0d128046dc:	8d 43 14             	lea    eax,[rbx+0x14]
    7a0d128046df:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7a0d128046e3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10198
    7a0d128046ea:	98 01 01 00 
    7a0d128046ee:	0f 84 9e 15 00 18    	je     0x7a0d2a805c92
    7a0d128046f4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10198
    7a0d128046fb:	98 01 01 00 
    7a0d128046ff:	0f 84 8d 15 00 18    	je     0x7a0d2a805c92
    7a0d12804705:	58                   	pop    rax
    7a0d12804706:	50                   	push   rax
    7a0d12804707:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    7a0d1280470e:	a8 01                	test   al,0x1
    7a0d12804710:	0f 85 c5 15 00 18    	jne    0x7a0d2a805cdb
    7a0d12804716:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d1280471d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12804724:	01 
    7a0d12804725:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1019a
    7a0d1280472c:	9a 01 01 00 
    7a0d12804730:	0f 84 db 15 00 18    	je     0x7a0d2a805d11
    7a0d12804736:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1019a
    7a0d1280473d:	9a 01 01 00 
    7a0d12804741:	0f 84 ca 15 00 18    	je     0x7a0d2a805d11
    7a0d12804747:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d1280474e:	02 00 00 00 
    7a0d12804752:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d12804759:	07 00 00 00 
    7a0d1280475d:	58                   	pop    rax
    7a0d1280475e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12804765:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d1280476c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12804773:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280477a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12804781:	39 f1                	cmp    ecx,esi
    7a0d12804783:	0f 83 b5 15 00 18    	jae    0x7a0d2a805d3e
    7a0d12804789:	81 fa 8c 01 01 00    	cmp    edx,0x1018c
    7a0d1280478f:	75 14                	jne    0x7a0d128047a5
    7a0d12804791:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d12804798:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d1280479f:	00 
    7a0d128047a0:	e9 fb fb ff ff       	jmp    0x7a0d128043a0
    7a0d128047a5:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d128047ac:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d128047b2:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d128047b5:	0f 85 83 15 00 18    	jne    0x7a0d2a805d3e
    7a0d128047bb:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d128047c2:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128047c9:	00 
    7a0d128047ca:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d128047cf:	ff e0                	jmp    rax
