
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-66626-1-134196966209152.bin:     file format binary


Disassembly of section .data:

00007a0d2a803680 <.data>:
    7a0d2a803680:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a803686:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a803689:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80368f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a803696:	0f 87 e5 f0 ff e7    	ja     0x7a0d12802781
    7a0d2a80369c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x6
    7a0d2a8036a3:	06 00 00 00 
    7a0d2a8036a7:	e9 d5 f0 ff e7       	jmp    0x7a0d12802781
    7a0d2a8036ac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    7a0d2a8036b3:	42 04 01 00 
    7a0d2a8036b7:	b8 42 04 01 00       	mov    eax,0x10442
    7a0d2a8036bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8036c3:	04 00 00 00 
    7a0d2a8036c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8036ce:	01 00 00 00 
    7a0d2a8036d2:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a8036d5:	be 42 04 01 00       	mov    esi,0x10442
    7a0d2a8036da:	4c 89 ef             	mov    rdi,r13
    7a0d2a8036dd:	e8 7e ca ff e7       	call   0x7a0d12800160
    7a0d2a8036e2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8036e9:	00 
    7a0d2a8036ea:	0f 84 c4 f0 ff e7    	je     0x7a0d128027b4
    7a0d2a8036f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8036f7:	04 00 00 00 
    7a0d2a8036fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a803702:	01 00 00 00 
    7a0d2a803706:	58                   	pop    rax
    7a0d2a803707:	e9 c3 f1 ff e7       	jmp    0x7a0d128028cf
    7a0d2a80370c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10446
    7a0d2a803713:	46 04 01 00 
    7a0d2a803717:	b8 46 04 01 00       	mov    eax,0x10446
    7a0d2a80371c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803723:	04 00 00 00 
    7a0d2a803727:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a80372e:	02 00 00 00 
    7a0d2a803732:	8d 50 04             	lea    edx,[rax+0x4]
    7a0d2a803735:	be 46 04 01 00       	mov    esi,0x10446
    7a0d2a80373a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80373d:	e8 1e ca ff e7       	call   0x7a0d12800160
    7a0d2a803742:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803749:	00 
    7a0d2a80374a:	0f 84 9b f0 ff e7    	je     0x7a0d128027eb
    7a0d2a803750:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a803757:	04 00 00 00 
    7a0d2a80375b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a803762:	02 00 00 00 
    7a0d2a803766:	58                   	pop    rax
    7a0d2a803767:	e9 63 f1 ff e7       	jmp    0x7a0d128028cf
    7a0d2a80376c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044a
    7a0d2a803773:	4a 04 01 00 
    7a0d2a803777:	b8 4a 04 01 00       	mov    eax,0x1044a
    7a0d2a80377c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803783:	02 00 00 00 
    7a0d2a803787:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80378e:	03 00 00 00 
    7a0d2a803792:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803795:	be 4a 04 01 00       	mov    esi,0x1044a
    7a0d2a80379a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80379d:	e8 be c9 ff e7       	call   0x7a0d12800160
    7a0d2a8037a2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8037a9:	00 
    7a0d2a8037aa:	0f 84 70 f0 ff e7    	je     0x7a0d12802820
    7a0d2a8037b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8037b7:	02 00 00 00 
    7a0d2a8037bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a8037c2:	03 00 00 00 
    7a0d2a8037c6:	58                   	pop    rax
    7a0d2a8037c7:	e9 03 f1 ff e7       	jmp    0x7a0d128028cf
    7a0d2a8037cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    7a0d2a8037d3:	4c 04 01 00 
    7a0d2a8037d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8037de:	02 00 00 00 
    7a0d2a8037e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8037e9:	04 00 00 00 
    7a0d2a8037ed:	ba 4c 04 01 00       	mov    edx,0x1044c
    7a0d2a8037f2:	4c 89 ef             	mov    rdi,r13
    7a0d2a8037f5:	4c 89 f6             	mov    rsi,r14
    7a0d2a8037f8:	45 31 c0             	xor    r8d,r8d
    7a0d2a8037fb:	e8 80 c8 ff e7       	call   0x7a0d12800080
    7a0d2a803800:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a803807:	02 00 00 00 
    7a0d2a80380b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803812:	04 00 00 00 
    7a0d2a803816:	58                   	pop    rax
    7a0d2a803817:	e9 b3 f0 ff e7       	jmp    0x7a0d128028cf
    7a0d2a80381c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    7a0d2a803823:	4c 04 01 00 
    7a0d2a803827:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80382e:	02 00 00 00 
    7a0d2a803832:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803839:	04 00 00 00 
    7a0d2a80383d:	4c 89 f7             	mov    rdi,r14
    7a0d2a803840:	89 ce                	mov    esi,ecx
    7a0d2a803842:	e8 f9 c7 ff e7       	call   0x7a0d12800040
    7a0d2a803847:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a80384e:	00 
    7a0d2a80384f:	0f 84 fe ef ff e7    	je     0x7a0d12802853
    7a0d2a803855:	eb a9                	jmp    0x7a0d2a803800
    7a0d2a803857:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    7a0d2a80385e:	4c 04 01 00 
    7a0d2a803862:	b8 4c 04 01 00       	mov    eax,0x1044c
    7a0d2a803867:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80386e:	02 00 00 00 
    7a0d2a803872:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a803879:	04 00 00 00 
    7a0d2a80387d:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a803880:	be 4c 04 01 00       	mov    esi,0x1044c
    7a0d2a803885:	4c 89 ef             	mov    rdi,r13
    7a0d2a803888:	e8 d3 c8 ff e7       	call   0x7a0d12800160
    7a0d2a80388d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a803894:	00 
    7a0d2a803895:	0f 84 de ef ff e7    	je     0x7a0d12802879
    7a0d2a80389b:	e9 60 ff ff ff       	jmp    0x7a0d2a803800
    7a0d2a8038a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044e
    7a0d2a8038a7:	4e 04 01 00 
    7a0d2a8038ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8038b2:	02 00 00 00 
    7a0d2a8038b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8038bd:	05 00 00 00 
    7a0d2a8038c1:	4c 89 ef             	mov    rdi,r13
    7a0d2a8038c4:	be 2a 00 00 00       	mov    esi,0x2a
    7a0d2a8038c9:	4c 89 f2             	mov    rdx,r14
    7a0d2a8038cc:	e8 bf c7 ff e7       	call   0x7a0d12800090
    7a0d2a8038d1:	e9 e2 ef ff e7       	jmp    0x7a0d128028b8
    7a0d2a8038d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8038dd:	02 00 00 00 
    7a0d2a8038e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a8038e8:	05 00 00 00 
    7a0d2a8038ec:	be 4e 04 01 00       	mov    esi,0x1044e
    7a0d2a8038f1:	ba 4e 04 01 00       	mov    edx,0x1044e
    7a0d2a8038f6:	4c 89 ef             	mov    rdi,r13
    7a0d2a8038f9:	e8 62 c8 ff e7       	call   0x7a0d12800160
    7a0d2a8038fe:	e9 b5 ef ff e7       	jmp    0x7a0d128028b8
    7a0d2a803903:	c2 08 00             	ret    0x8
