
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65600-1-134196563545168.bin:     file format binary


Disassembly of section .data:

00007a0d12800c50 <.data>:
    7a0d12800c50:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d12800c57:	3d 00 00 00 00       	cmp    eax,0x0
    7a0d12800c5c:	0f 95 c2             	setne  dl
    7a0d12800c5f:	b9 40 00 01 00       	mov    ecx,0x10040
    7a0d12800c64:	29 c8                	sub    eax,ecx
    7a0d12800c66:	3d 4e 00 00 00       	cmp    eax,0x4e
    7a0d12800c6b:	0f 96 c3             	setbe  bl
    7a0d12800c6e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    7a0d12800c75:	81 fe 00 00 00 00    	cmp    esi,0x0
    7a0d12800c7b:	0f 94 c0             	sete   al
    7a0d12800c7e:	29 ce                	sub    esi,ecx
    7a0d12800c80:	81 fe 4e 00 00 00    	cmp    esi,0x4e
    7a0d12800c86:	0f 97 c1             	seta   cl
    7a0d12800c89:	84 da                	test   dl,bl
    7a0d12800c8b:	0f 85 2f 01 00 18    	jne    0x7a0d2a800dc0
    7a0d12800c91:	08 c8                	or     al,cl
    7a0d12800c93:	0f 84 27 01 00 18    	je     0x7a0d2a800dc0
    7a0d12800c99:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12800ca0:	8b 88 08 00 10 00    	mov    ecx,DWORD PTR [rax+0x100008]
    7a0d12800ca6:	ff c1                	inc    ecx
    7a0d12800ca8:	89 88 08 00 10 00    	mov    DWORD PTR [rax+0x100008],ecx
    7a0d12800cae:	81 f9 14 cd 00 00    	cmp    ecx,0xcd14
    7a0d12800cb4:	0f 84 1c 01 00 18    	je     0x7a0d2a800dd6
    7a0d12800cba:	50                   	push   rax
    7a0d12800cbb:	41 c7 45 28 01 3c 00 	mov    DWORD PTR [r13+0x28],0x3c01
    7a0d12800cc2:	00 
    7a0d12800cc3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10040
    7a0d12800cca:	40 00 01 00 
    7a0d12800cce:	0f 84 2e 01 00 18    	je     0x7a0d2a800e02
    7a0d12800cd4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10040
    7a0d12800cdb:	40 00 01 00 
    7a0d12800cdf:	0f 84 1d 01 00 18    	je     0x7a0d2a800e02
    7a0d12800ce5:	58                   	pop    rax
    7a0d12800ce6:	50                   	push   rax
    7a0d12800ce7:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    7a0d12800cec:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10044
    7a0d12800cf3:	44 00 01 00 
    7a0d12800cf7:	0f 84 65 01 00 18    	je     0x7a0d2a800e62
    7a0d12800cfd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10044
    7a0d12800d04:	44 00 01 00 
    7a0d12800d08:	0f 84 54 01 00 18    	je     0x7a0d2a800e62
    7a0d12800d0e:	58                   	pop    rax
    7a0d12800d0f:	50                   	push   rax
    7a0d12800d10:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12800d14:	f6 c1 03             	test   cl,0x3
    7a0d12800d17:	0f 85 a5 01 00 18    	jne    0x7a0d2a800ec2
    7a0d12800d1d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800d24:	48 89 ca             	mov    rdx,rcx
    7a0d12800d27:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d12800d2b:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12800d2f:	48 85 c0             	test   rax,rax
    7a0d12800d32:	0f 84 da 01 00 18    	je     0x7a0d2a800f12
    7a0d12800d38:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800d3e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12800d41:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7a0d12800d45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10046
    7a0d12800d4c:	46 00 01 00 
    7a0d12800d50:	0f 84 f7 01 00 18    	je     0x7a0d2a800f4d
    7a0d12800d56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10046
    7a0d12800d5d:	46 00 01 00 
    7a0d12800d61:	0f 84 e6 01 00 18    	je     0x7a0d2a800f4d
    7a0d12800d67:	58                   	pop    rax
    7a0d12800d68:	50                   	push   rax
    7a0d12800d69:	41 83 45 28 04       	add    DWORD PTR [r13+0x28],0x4
    7a0d12800d6e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10048
    7a0d12800d75:	48 00 01 00 
    7a0d12800d79:	0f 84 17 02 00 18    	je     0x7a0d2a800f96
    7a0d12800d7f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10048
    7a0d12800d86:	48 00 01 00 
    7a0d12800d8a:	0f 84 06 02 00 18    	je     0x7a0d2a800f96
    7a0d12800d90:	58                   	pop    rax
    7a0d12800d91:	50                   	push   rax
    7a0d12800d92:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12800d96:	f6 c1 03             	test   cl,0x3
    7a0d12800d99:	0f 85 57 02 00 18    	jne    0x7a0d2a800ff6
    7a0d12800d9f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800da6:	48 89 ca             	mov    rdx,rcx
    7a0d12800da9:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d12800dad:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12800db1:	48 85 c0             	test   rax,rax
    7a0d12800db4:	0f 84 8c 02 00 18    	je     0x7a0d2a801046
    7a0d12800dba:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800dc0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12800dc3:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d12800dc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004a
    7a0d12800dce:	4a 00 01 00 
    7a0d12800dd2:	0f 84 a9 02 00 18    	je     0x7a0d2a801081
    7a0d12800dd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004a
    7a0d12800ddf:	4a 00 01 00 
    7a0d12800de3:	0f 84 98 02 00 18    	je     0x7a0d2a801081
    7a0d12800de9:	58                   	pop    rax
    7a0d12800dea:	50                   	push   rax
    7a0d12800deb:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    7a0d12800df2:	00 
    7a0d12800df3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004c
    7a0d12800dfa:	4c 00 01 00 
    7a0d12800dfe:	0f 84 c6 02 00 18    	je     0x7a0d2a8010ca
    7a0d12800e04:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004c
    7a0d12800e0b:	4c 00 01 00 
    7a0d12800e0f:	0f 84 b5 02 00 18    	je     0x7a0d2a8010ca
    7a0d12800e15:	58                   	pop    rax
    7a0d12800e16:	50                   	push   rax
    7a0d12800e17:	41 c7 45 2c 05 3c 00 	mov    DWORD PTR [r13+0x2c],0x3c05
    7a0d12800e1e:	00 
    7a0d12800e1f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004e
    7a0d12800e26:	4e 00 01 00 
    7a0d12800e2a:	0f 84 fa 02 00 18    	je     0x7a0d2a80112a
    7a0d12800e30:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004e
    7a0d12800e37:	4e 00 01 00 
    7a0d12800e3b:	0f 84 e9 02 00 18    	je     0x7a0d2a80112a
    7a0d12800e41:	58                   	pop    rax
    7a0d12800e42:	50                   	push   rax
    7a0d12800e43:	41 c1 65 2c 02       	shl    DWORD PTR [r13+0x2c],0x2
    7a0d12800e48:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10052
    7a0d12800e4f:	52 00 01 00 
    7a0d12800e53:	0f 84 31 03 00 18    	je     0x7a0d2a80118a
    7a0d12800e59:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10052
    7a0d12800e60:	52 00 01 00 
    7a0d12800e64:	0f 84 20 03 00 18    	je     0x7a0d2a80118a
    7a0d12800e6a:	58                   	pop    rax
    7a0d12800e6b:	50                   	push   rax
    7a0d12800e6c:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d12800e70:	8d 48 fc             	lea    ecx,[rax-0x4]
    7a0d12800e73:	a8 03                	test   al,0x3
    7a0d12800e75:	0f 85 6f 03 00 18    	jne    0x7a0d2a8011ea
    7a0d12800e7b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12800e82:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    7a0d12800e86:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800e8d:	89 ce                	mov    esi,ecx
    7a0d12800e8f:	c1 ee 0c             	shr    esi,0xc
    7a0d12800e92:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12800e96:	48 85 c0             	test   rax,rax
    7a0d12800e99:	0f 84 9e 03 00 18    	je     0x7a0d2a80123d
    7a0d12800e9f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800ea5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12800ea8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10054
    7a0d12800eaf:	54 00 01 00 
    7a0d12800eb3:	0f 84 bf 03 00 18    	je     0x7a0d2a801278
    7a0d12800eb9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10054
    7a0d12800ec0:	54 00 01 00 
    7a0d12800ec4:	0f 84 ae 03 00 18    	je     0x7a0d2a801278
    7a0d12800eca:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12800ecd:	0f 85 e6 03 00 18    	jne    0x7a0d2a8012b9
    7a0d12800ed3:	58                   	pop    rax
    7a0d12800ed4:	e9 0f 00 00 00       	jmp    0x7a0d12800ee8
    7a0d12800ed9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12800ee0:	00 
    7a0d12800ee1:	74 f0                	je     0x7a0d12800ed3
    7a0d12800ee3:	e9 39 03 00 18       	jmp    0x7a0d2a801221
    7a0d12800ee8:	50                   	push   rax
    7a0d12800ee9:	41 c7 45 28 03 3c 00 	mov    DWORD PTR [r13+0x28],0x3c03
    7a0d12800ef0:	00 
    7a0d12800ef1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10056
    7a0d12800ef8:	56 00 01 00 
    7a0d12800efc:	0f 84 e9 03 00 18    	je     0x7a0d2a8012eb
    7a0d12800f02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10056
    7a0d12800f09:	56 00 01 00 
    7a0d12800f0d:	0f 84 d8 03 00 18    	je     0x7a0d2a8012eb
    7a0d12800f13:	58                   	pop    rax
    7a0d12800f14:	50                   	push   rax
    7a0d12800f15:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    7a0d12800f1a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005a
    7a0d12800f21:	5a 00 01 00 
    7a0d12800f25:	0f 84 20 04 00 18    	je     0x7a0d2a80134b
    7a0d12800f2b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005a
    7a0d12800f32:	5a 00 01 00 
    7a0d12800f36:	0f 84 0f 04 00 18    	je     0x7a0d2a80134b
    7a0d12800f3c:	58                   	pop    rax
    7a0d12800f3d:	50                   	push   rax
    7a0d12800f3e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12800f42:	f6 c1 03             	test   cl,0x3
    7a0d12800f45:	0f 85 60 04 00 18    	jne    0x7a0d2a8013ab
    7a0d12800f4b:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12800f52:	48 89 ca             	mov    rdx,rcx
    7a0d12800f55:	48 c1 ea 0c          	shr    rdx,0xc
    7a0d12800f59:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12800f5d:	48 85 c0             	test   rax,rax
    7a0d12800f60:	0f 84 95 04 00 18    	je     0x7a0d2a8013fb
    7a0d12800f66:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12800f6c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12800f6f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7a0d12800f73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005c
    7a0d12800f7a:	5c 00 01 00 
    7a0d12800f7e:	0f 84 b2 04 00 18    	je     0x7a0d2a801436
    7a0d12800f84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005c
    7a0d12800f8b:	5c 00 01 00 
    7a0d12800f8f:	0f 84 a1 04 00 18    	je     0x7a0d2a801436
    7a0d12800f95:	58                   	pop    rax
    7a0d12800f96:	50                   	push   rax
    7a0d12800f97:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    7a0d12800f9c:	b9 00 00 00 00       	mov    ecx,0x0
    7a0d12800fa1:	09 c1                	or     ecx,eax
    7a0d12800fa3:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    7a0d12800fa7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005e
    7a0d12800fae:	5e 00 01 00 
    7a0d12800fb2:	0f 84 c7 04 00 18    	je     0x7a0d2a80147f
    7a0d12800fb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005e
    7a0d12800fbf:	5e 00 01 00 
    7a0d12800fc3:	0f 84 b6 04 00 18    	je     0x7a0d2a80147f
    7a0d12800fc9:	58                   	pop    rax
    7a0d12800fca:	50                   	push   rax
    7a0d12800fcb:	41 0f b7 45 30       	movzx  eax,WORD PTR [r13+0x30]
    7a0d12800fd0:	b9 00 00 00 01       	mov    ecx,0x1000000
    7a0d12800fd5:	09 c1                	or     ecx,eax
    7a0d12800fd7:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    7a0d12800fdb:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10062
    7a0d12800fe2:	62 00 01 00 
    7a0d12800fe6:	0f 84 f3 04 00 18    	je     0x7a0d2a8014df
    7a0d12800fec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10062
    7a0d12800ff3:	62 00 01 00 
    7a0d12800ff7:	0f 84 e2 04 00 18    	je     0x7a0d2a8014df
    7a0d12800ffd:	58                   	pop    rax
    7a0d12800ffe:	50                   	push   rax
    7a0d12800fff:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    7a0d12801004:	c1 e0 10             	shl    eax,0x10
    7a0d12801007:	b9 18 f0 00 00       	mov    ecx,0xf018
    7a0d1280100c:	09 c1                	or     ecx,eax
    7a0d1280100e:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    7a0d12801012:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10066
    7a0d12801019:	66 00 01 00 
    7a0d1280101d:	0f 84 1c 05 00 18    	je     0x7a0d2a80153f
    7a0d12801023:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10066
    7a0d1280102a:	66 00 01 00 
    7a0d1280102e:	0f 84 0b 05 00 18    	je     0x7a0d2a80153f
    7a0d12801034:	58                   	pop    rax
    7a0d12801035:	50                   	push   rax
    7a0d12801036:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d1280103a:	8d 48 f8             	lea    ecx,[rax-0x8]
    7a0d1280103d:	a8 03                	test   al,0x3
    7a0d1280103f:	0f 85 5a 05 00 18    	jne    0x7a0d2a80159f
    7a0d12801045:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d1280104c:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    7a0d12801050:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801057:	89 ce                	mov    esi,ecx
    7a0d12801059:	c1 ee 0c             	shr    esi,0xc
    7a0d1280105c:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12801060:	48 85 c0             	test   rax,rax
    7a0d12801063:	0f 84 89 05 00 18    	je     0x7a0d2a8015f2
    7a0d12801069:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280106f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801072:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006a
    7a0d12801079:	6a 00 01 00 
    7a0d1280107d:	0f 84 aa 05 00 18    	je     0x7a0d2a80162d
    7a0d12801083:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006a
    7a0d1280108a:	6a 00 01 00 
    7a0d1280108e:	0f 84 99 05 00 18    	je     0x7a0d2a80162d
    7a0d12801094:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12801097:	0f 85 d1 05 00 18    	jne    0x7a0d2a80166e
    7a0d1280109d:	58                   	pop    rax
    7a0d1280109e:	e9 0f 00 00 00       	jmp    0x7a0d128010b2
    7a0d128010a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d128010aa:	00 
    7a0d128010ab:	74 f0                	je     0x7a0d1280109d
    7a0d128010ad:	e9 24 05 00 18       	jmp    0x7a0d2a8015d6
    7a0d128010b2:	50                   	push   rax
    7a0d128010b3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7a0d128010b8:	b9 00 00 00 00       	mov    ecx,0x0
    7a0d128010bd:	09 c1                	or     ecx,eax
    7a0d128010bf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128010c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006c
    7a0d128010ca:	6c 00 01 00 
    7a0d128010ce:	0f 84 cc 05 00 18    	je     0x7a0d2a8016a0
    7a0d128010d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006c
    7a0d128010db:	6c 00 01 00 
    7a0d128010df:	0f 84 bb 05 00 18    	je     0x7a0d2a8016a0
    7a0d128010e5:	58                   	pop    rax
    7a0d128010e6:	50                   	push   rax
    7a0d128010e7:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7a0d128010ec:	c1 e0 10             	shl    eax,0x10
    7a0d128010ef:	b9 10 f0 00 00       	mov    ecx,0xf010
    7a0d128010f4:	09 c1                	or     ecx,eax
    7a0d128010f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7a0d128010fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10070
    7a0d12801101:	70 00 01 00 
    7a0d12801105:	0f 84 f5 05 00 18    	je     0x7a0d2a801700
    7a0d1280110b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10070
    7a0d12801112:	70 00 01 00 
    7a0d12801116:	0f 84 e4 05 00 18    	je     0x7a0d2a801700
    7a0d1280111c:	58                   	pop    rax
    7a0d1280111d:	50                   	push   rax
    7a0d1280111e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7a0d12801122:	f6 c1 03             	test   cl,0x3
    7a0d12801125:	0f 85 35 06 00 18    	jne    0x7a0d2a801760
    7a0d1280112b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d12801132:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d12801136:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d1280113d:	48 89 ce             	mov    rsi,rcx
    7a0d12801140:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d12801144:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d12801148:	48 85 c0             	test   rax,rax
    7a0d1280114b:	0f 84 62 06 00 18    	je     0x7a0d2a8017b3
    7a0d12801151:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801157:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d1280115a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10074
    7a0d12801161:	74 00 01 00 
    7a0d12801165:	0f 84 83 06 00 18    	je     0x7a0d2a8017ee
    7a0d1280116b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10074
    7a0d12801172:	74 00 01 00 
    7a0d12801176:	0f 84 72 06 00 18    	je     0x7a0d2a8017ee
    7a0d1280117c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d1280117f:	0f 85 aa 06 00 18    	jne    0x7a0d2a80182f
    7a0d12801185:	58                   	pop    rax
    7a0d12801186:	e9 0f 00 00 00       	jmp    0x7a0d1280119a
    7a0d1280118b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d12801192:	00 
    7a0d12801193:	74 f0                	je     0x7a0d12801185
    7a0d12801195:	e9 fd 05 00 18       	jmp    0x7a0d2a801797
    7a0d1280119a:	50                   	push   rax
    7a0d1280119b:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7a0d128011a2:	00 
    7a0d128011a3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10076
    7a0d128011aa:	76 00 01 00 
    7a0d128011ae:	0f 84 ad 06 00 18    	je     0x7a0d2a801861
    7a0d128011b4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10076
    7a0d128011bb:	76 00 01 00 
    7a0d128011bf:	0f 84 9c 06 00 18    	je     0x7a0d2a801861
    7a0d128011c5:	58                   	pop    rax
    7a0d128011c6:	50                   	push   rax
    7a0d128011c7:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    7a0d128011cb:	f6 c1 03             	test   cl,0x3
    7a0d128011ce:	0f 85 ed 06 00 18    	jne    0x7a0d2a8018c1
    7a0d128011d4:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7a0d128011db:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7a0d128011df:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d128011e6:	48 89 ce             	mov    rsi,rcx
    7a0d128011e9:	48 c1 ee 0c          	shr    rsi,0xc
    7a0d128011ed:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7a0d128011f1:	48 85 c0             	test   rax,rax
    7a0d128011f4:	0f 84 1a 07 00 18    	je     0x7a0d2a801914
    7a0d128011fa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801200:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7a0d12801203:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10078
    7a0d1280120a:	78 00 01 00 
    7a0d1280120e:	0f 84 3b 07 00 18    	je     0x7a0d2a80194f
    7a0d12801214:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10078
    7a0d1280121b:	78 00 01 00 
    7a0d1280121f:	0f 84 2a 07 00 18    	je     0x7a0d2a80194f
    7a0d12801225:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7a0d12801228:	0f 85 62 07 00 18    	jne    0x7a0d2a801990
    7a0d1280122e:	58                   	pop    rax
    7a0d1280122f:	e9 0f 00 00 00       	jmp    0x7a0d12801243
    7a0d12801234:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d1280123b:	00 
    7a0d1280123c:	74 f0                	je     0x7a0d1280122e
    7a0d1280123e:	e9 b5 06 00 18       	jmp    0x7a0d2a8018f8
    7a0d12801243:	50                   	push   rax
    7a0d12801244:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    7a0d1280124b:	00 
    7a0d1280124c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007a
    7a0d12801253:	7a 00 01 00 
    7a0d12801257:	0f 84 65 07 00 18    	je     0x7a0d2a8019c2
    7a0d1280125d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007a
    7a0d12801264:	7a 00 01 00 
    7a0d12801268:	0f 84 54 07 00 18    	je     0x7a0d2a8019c2
    7a0d1280126e:	58                   	pop    rax
    7a0d1280126f:	50                   	push   rax
    7a0d12801270:	41 0f b7 45 32       	movzx  eax,WORD PTR [r13+0x32]
    7a0d12801275:	c1 e0 10             	shl    eax,0x10
    7a0d12801278:	b9 00 00 00 00       	mov    ecx,0x0
    7a0d1280127d:	09 c1                	or     ecx,eax
    7a0d1280127f:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    7a0d12801283:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007c
    7a0d1280128a:	7c 00 01 00 
    7a0d1280128e:	0f 84 8e 07 00 18    	je     0x7a0d2a801a22
    7a0d12801294:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007c
    7a0d1280129b:	7c 00 01 00 
    7a0d1280129f:	0f 84 7d 07 00 18    	je     0x7a0d2a801a22
    7a0d128012a5:	58                   	pop    rax
    7a0d128012a6:	50                   	push   rax
    7a0d128012a7:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    7a0d128012ae:	00 
    7a0d128012af:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10080
    7a0d128012b6:	80 00 01 00 
    7a0d128012ba:	0f 84 c2 07 00 18    	je     0x7a0d2a801a82
    7a0d128012c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10080
    7a0d128012c7:	80 00 01 00 
    7a0d128012cb:	0f 84 b1 07 00 18    	je     0x7a0d2a801a82
    7a0d128012d1:	58                   	pop    rax
    7a0d128012d2:	50                   	push   rax
    7a0d128012d3:	41 c7 45 14 01 00 00 	mov    DWORD PTR [r13+0x14],0x1
    7a0d128012da:	00 
    7a0d128012db:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10082
    7a0d128012e2:	82 00 01 00 
    7a0d128012e6:	0f 84 f6 07 00 18    	je     0x7a0d2a801ae2
    7a0d128012ec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10082
    7a0d128012f3:	82 00 01 00 
    7a0d128012f7:	0f 84 e5 07 00 18    	je     0x7a0d2a801ae2
    7a0d128012fd:	58                   	pop    rax
    7a0d128012fe:	50                   	push   rax
    7a0d128012ff:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d12801303:	8d 48 fc             	lea    ecx,[rax-0x4]
    7a0d12801306:	a8 03                	test   al,0x3
    7a0d12801308:	0f 85 34 08 00 18    	jne    0x7a0d2a801b42
    7a0d1280130e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801315:	89 ca                	mov    edx,ecx
    7a0d12801317:	c1 ea 0c             	shr    edx,0xc
    7a0d1280131a:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d1280131e:	48 85 c0             	test   rax,rax
    7a0d12801321:	0f 84 6b 08 00 18    	je     0x7a0d2a801b92
    7a0d12801327:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d1280132d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12801330:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    7a0d12801337:	58                   	pop    rax
    7a0d12801338:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    7a0d1280133f:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    7a0d12801346:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    7a0d1280134d:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7a0d12801351:	50                   	push   rax
    7a0d12801352:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    7a0d12801356:	8d 48 f8             	lea    ecx,[rax-0x8]
    7a0d12801359:	a8 03                	test   al,0x3
    7a0d1280135b:	0f 85 6c 08 00 18    	jne    0x7a0d2a801bcd
    7a0d12801361:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7a0d12801368:	89 ca                	mov    edx,ecx
    7a0d1280136a:	c1 ea 0c             	shr    edx,0xc
    7a0d1280136d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7a0d12801371:	48 85 c0             	test   rax,rax
    7a0d12801374:	0f 84 a3 08 00 18    	je     0x7a0d2a801c1d
    7a0d1280137a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7a0d12801380:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7a0d12801383:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    7a0d12801387:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    7a0d1280138e:	8c 00 01 00 
    7a0d12801392:	0f 84 c0 08 00 18    	je     0x7a0d2a801c58
    7a0d12801398:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    7a0d1280139f:	8c 00 01 00 
    7a0d128013a3:	0f 84 af 08 00 18    	je     0x7a0d2a801c58
    7a0d128013a9:	58                   	pop    rax
    7a0d128013aa:	50                   	push   rax
    7a0d128013ab:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7a0d128013b2:	b9 8e 00 01 00       	mov    ecx,0x1008e
    7a0d128013b7:	83 c1 04             	add    ecx,0x4
    7a0d128013ba:	89 ca                	mov    edx,ecx
    7a0d128013bc:	3d 8e 00 01 00       	cmp    eax,0x1008e
    7a0d128013c1:	75 07                	jne    0x7a0d128013ca
    7a0d128013c3:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7a0d128013ca:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7a0d128013d1:	02 
    7a0d128013d2:	0f 43 ca             	cmovae ecx,edx
    7a0d128013d5:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7a0d128013dc:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7a0d128013e3:	89 cf                	mov    edi,ecx
    7a0d128013e5:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    7a0d128013eb:	75 07                	jne    0x7a0d128013f4
    7a0d128013ed:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7a0d128013f4:	83 fe 02             	cmp    esi,0x2
    7a0d128013f7:	0f 43 cf             	cmovae ecx,edi
    7a0d128013fa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7a0d12801401:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7a0d12801408:	01 
    7a0d12801409:	3d 8e 00 01 00       	cmp    eax,0x1008e
    7a0d1280140e:	0f 84 8d 08 00 18    	je     0x7a0d2a801ca1
    7a0d12801414:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    7a0d1280141a:	0f 84 81 08 00 18    	je     0x7a0d2a801ca1
    7a0d12801420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7a0d12801427:	28 03 01 00 
    7a0d1280142b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d12801432:	04 00 00 00 
    7a0d12801436:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    7a0d1280143d:	1c 00 00 00 
    7a0d12801441:	58                   	pop    rax
    7a0d12801442:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7a0d12801449:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7a0d12801450:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7a0d12801457:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7a0d1280145e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7a0d12801465:	39 f1                	cmp    ecx,esi
    7a0d12801467:	0f 83 6c 08 00 18    	jae    0x7a0d2a801cd9
    7a0d1280146d:	81 fa 40 00 01 00    	cmp    edx,0x10040
    7a0d12801473:	75 14                	jne    0x7a0d12801489
    7a0d12801475:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d1280147c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d12801483:	00 
    7a0d12801484:	e9 10 f8 ff ff       	jmp    0x7a0d12800c99
    7a0d12801489:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7a0d12801490:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7a0d12801496:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7a0d12801499:	0f 85 3a 08 00 18    	jne    0x7a0d2a801cd9
    7a0d1280149f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7a0d128014a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7a0d128014ad:	00 
    7a0d128014ae:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7a0d128014b3:	ff e0                	jmp    rax
