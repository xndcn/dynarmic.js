
build-native-instruction-analysis/capture/bcore-default-no-ir-branch/pc-65916-1-134196966212944.bin:     file format binary


Disassembly of section .data:

00007a0d2a804550 <.data>:
    7a0d2a804550:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7a0d2a804556:	8d 51 01             	lea    edx,[rcx+0x1]
    7a0d2a804559:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7a0d2a80455f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7a0d2a804566:	0f 87 25 ec ff e7    	ja     0x7a0d12803191
    7a0d2a80456c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x9
    7a0d2a804573:	09 00 00 00 
    7a0d2a804577:	e9 15 ec ff e7       	jmp    0x7a0d12803191
    7a0d2a80457c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7a0d2a804583:	7c 01 01 00 
    7a0d2a804587:	b8 7c 01 01 00       	mov    eax,0x1017c
    7a0d2a80458c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804593:	02 00 00 00 
    7a0d2a804597:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a80459e:	01 00 00 00 
    7a0d2a8045a2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8045a5:	be 7c 01 01 00       	mov    esi,0x1017c
    7a0d2a8045aa:	4c 89 ef             	mov    rdi,r13
    7a0d2a8045ad:	e8 ae bb ff e7       	call   0x7a0d12800160
    7a0d2a8045b2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8045b9:	00 
    7a0d2a8045ba:	0f 84 03 ec ff e7    	je     0x7a0d128031c3
    7a0d2a8045c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8045c7:	02 00 00 00 
    7a0d2a8045cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    7a0d2a8045d2:	01 00 00 00 
    7a0d2a8045d6:	58                   	pop    rax
    7a0d2a8045d7:	e9 74 ee ff e7       	jmp    0x7a0d12803450
    7a0d2a8045dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017e
    7a0d2a8045e3:	7e 01 01 00 
    7a0d2a8045e7:	b8 7e 01 01 00       	mov    eax,0x1017e
    7a0d2a8045ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8045f3:	02 00 00 00 
    7a0d2a8045f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a8045fe:	02 00 00 00 
    7a0d2a804602:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804605:	be 7e 01 01 00       	mov    esi,0x1017e
    7a0d2a80460a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80460d:	e8 4e bb ff e7       	call   0x7a0d12800160
    7a0d2a804612:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804619:	00 
    7a0d2a80461a:	0f 84 d1 eb ff e7    	je     0x7a0d128031f1
    7a0d2a804620:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804627:	02 00 00 00 
    7a0d2a80462b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7a0d2a804632:	02 00 00 00 
    7a0d2a804636:	58                   	pop    rax
    7a0d2a804637:	e9 14 ee ff e7       	jmp    0x7a0d12803450
    7a0d2a80463c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10180
    7a0d2a804643:	80 01 01 00 
    7a0d2a804647:	b8 80 01 01 00       	mov    eax,0x10180
    7a0d2a80464c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804653:	02 00 00 00 
    7a0d2a804657:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a80465e:	03 00 00 00 
    7a0d2a804662:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804665:	be 80 01 01 00       	mov    esi,0x10180
    7a0d2a80466a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80466d:	e8 ee ba ff e7       	call   0x7a0d12800160
    7a0d2a804672:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804679:	00 
    7a0d2a80467a:	0f 84 f7 eb ff e7    	je     0x7a0d12803277
    7a0d2a804680:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804687:	02 00 00 00 
    7a0d2a80468b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7a0d2a804692:	03 00 00 00 
    7a0d2a804696:	58                   	pop    rax
    7a0d2a804697:	e9 b4 ed ff e7       	jmp    0x7a0d12803450
    7a0d2a80469c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10182
    7a0d2a8046a3:	82 01 01 00 
    7a0d2a8046a7:	b8 82 01 01 00       	mov    eax,0x10182
    7a0d2a8046ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8046b3:	02 00 00 00 
    7a0d2a8046b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8046be:	04 00 00 00 
    7a0d2a8046c2:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8046c5:	be 82 01 01 00       	mov    esi,0x10182
    7a0d2a8046ca:	4c 89 ef             	mov    rdi,r13
    7a0d2a8046cd:	e8 8e ba ff e7       	call   0x7a0d12800160
    7a0d2a8046d2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8046d9:	00 
    7a0d2a8046da:	0f 84 f1 eb ff e7    	je     0x7a0d128032d1
    7a0d2a8046e0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8046e7:	02 00 00 00 
    7a0d2a8046eb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7a0d2a8046f2:	04 00 00 00 
    7a0d2a8046f6:	58                   	pop    rax
    7a0d2a8046f7:	e9 54 ed ff e7       	jmp    0x7a0d12803450
    7a0d2a8046fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10184
    7a0d2a804703:	84 01 01 00 
    7a0d2a804707:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d2a80470c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804713:	02 00 00 00 
    7a0d2a804717:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a80471e:	05 00 00 00 
    7a0d2a804722:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a804725:	be 84 01 01 00       	mov    esi,0x10184
    7a0d2a80472a:	4c 89 ef             	mov    rdi,r13
    7a0d2a80472d:	e8 2e ba ff e7       	call   0x7a0d12800160
    7a0d2a804732:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a804739:	00 
    7a0d2a80473a:	0f 84 bf eb ff e7    	je     0x7a0d128032ff
    7a0d2a804740:	e9 f9 eb ff e7       	jmp    0x7a0d1280333e
    7a0d2a804745:	b8 84 01 01 00       	mov    eax,0x10184
    7a0d2a80474a:	83 c0 ec             	add    eax,0xffffffec
    7a0d2a80474d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7a0d2a804754:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a80475b:	02 00 00 00 
    7a0d2a80475f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    7a0d2a804766:	05 00 00 00 
    7a0d2a80476a:	be 84 01 01 00       	mov    esi,0x10184
    7a0d2a80476f:	ba 84 01 01 00       	mov    edx,0x10184
    7a0d2a804774:	4c 89 ef             	mov    rdi,r13
    7a0d2a804777:	e8 e4 b9 ff e7       	call   0x7a0d12800160
    7a0d2a80477c:	e9 ae eb ff e7       	jmp    0x7a0d1280332f
    7a0d2a804781:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10186
    7a0d2a804788:	86 01 01 00 
    7a0d2a80478c:	b8 86 01 01 00       	mov    eax,0x10186
    7a0d2a804791:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a804798:	02 00 00 00 
    7a0d2a80479c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8047a3:	06 00 00 00 
    7a0d2a8047a7:	8d 50 02             	lea    edx,[rax+0x2]
    7a0d2a8047aa:	be 86 01 01 00       	mov    esi,0x10186
    7a0d2a8047af:	4c 89 ef             	mov    rdi,r13
    7a0d2a8047b2:	e8 a9 b9 ff e7       	call   0x7a0d12800160
    7a0d2a8047b7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7a0d2a8047be:	00 
    7a0d2a8047bf:	0f 84 f2 eb ff e7    	je     0x7a0d128033b7
    7a0d2a8047c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7a0d2a8047cc:	02 00 00 00 
    7a0d2a8047d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    7a0d2a8047d7:	06 00 00 00 
    7a0d2a8047db:	58                   	pop    rax
    7a0d2a8047dc:	e9 6f ec ff e7       	jmp    0x7a0d12803450
    7a0d2a8047e1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7a0d2a8047e8:	10 01 01 00 
    7a0d2a8047ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7a0d2a8047f3:	04 00 00 00 
    7a0d2a8047f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    7a0d2a8047fe:	07 00 00 00 
    7a0d2a804802:	be 88 01 01 00       	mov    esi,0x10188
    7a0d2a804807:	ba 88 01 01 00       	mov    edx,0x10188
    7a0d2a80480c:	4c 89 ef             	mov    rdi,r13
    7a0d2a80480f:	e8 4c b9 ff e7       	call   0x7a0d12800160
    7a0d2a804814:	e9 15 ec ff e7       	jmp    0x7a0d1280342e
    7a0d2a804819:	c2 08 00             	ret    0x8
