
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66600-1-126629223346352.bin:     file format binary


Disassembly of section .data:

0000732b29e030b0 <.data>:
    732b29e030b0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e030b6:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e030b9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e030bf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e030c6:	0f 87 d5 f2 ff e7    	ja     0x732b11e023a1
    732b29e030cc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x5
    732b29e030d3:	05 00 00 00 
    732b29e030d7:	e9 c5 f2 ff e7       	jmp    0x732b11e023a1
    732b29e030dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    732b29e030e3:	28 04 01 00 
    732b29e030e7:	b8 28 04 01 00       	mov    eax,0x10428
    732b29e030ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e030f3:	04 00 00 00 
    732b29e030f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e030fe:	01 00 00 00 
    732b29e03102:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03105:	be 28 04 01 00       	mov    esi,0x10428
    732b29e0310a:	4c 89 ef             	mov    rdi,r13
    732b29e0310d:	e8 4e d0 ff e7       	call   0x732b11e00160
    732b29e03112:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03119:	00 
    732b29e0311a:	0f 84 b4 f2 ff e7    	je     0x732b11e023d4
    732b29e03120:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03127:	04 00 00 00 
    732b29e0312b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03132:	01 00 00 00 
    732b29e03136:	58                   	pop    rax
    732b29e03137:	e9 ab f5 ff e7       	jmp    0x732b11e026e7
    732b29e0313c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    732b29e03143:	2c 04 01 00 
    732b29e03147:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0314e:	04 00 00 00 
    732b29e03152:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03159:	02 00 00 00 
    732b29e0315d:	ba 2c 04 01 00       	mov    edx,0x1042c
    732b29e03162:	4c 89 ef             	mov    rdi,r13
    732b29e03165:	4c 89 f6             	mov    rsi,r14
    732b29e03168:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e0316e:	e8 0d cf ff e7       	call   0x732b11e00080
    732b29e03173:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0317a:	04 00 00 00 
    732b29e0317e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03185:	02 00 00 00 
    732b29e03189:	58                   	pop    rax
    732b29e0318a:	e9 58 f5 ff e7       	jmp    0x732b11e026e7
    732b29e0318f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    732b29e03196:	2c 04 01 00 
    732b29e0319a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e031a1:	04 00 00 00 
    732b29e031a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e031ac:	02 00 00 00 
    732b29e031b0:	4c 89 f7             	mov    rdi,r14
    732b29e031b3:	89 ce                	mov    esi,ecx
    732b29e031b5:	e8 b6 ce ff e7       	call   0x732b11e00070
    732b29e031ba:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e031c1:	00 
    732b29e031c2:	0f 84 53 f2 ff e7    	je     0x732b11e0241b
    732b29e031c8:	eb a9                	jmp    0x732b29e03173
    732b29e031ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    732b29e031d1:	2c 04 01 00 
    732b29e031d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e031dc:	04 00 00 00 
    732b29e031e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e031e7:	02 00 00 00 
    732b29e031eb:	4c 89 f7             	mov    rdi,r14
    732b29e031ee:	89 de                	mov    esi,ebx
    732b29e031f0:	44 89 e2             	mov    edx,r12d
    732b29e031f3:	e8 78 ce ff e7       	call   0x732b11e00070
    732b29e031f8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e031ff:	00 
    732b29e03200:	0f 84 37 f2 ff e7    	je     0x732b11e0243d
    732b29e03206:	e9 68 ff ff ff       	jmp    0x732b29e03173
    732b29e0320b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    732b29e03212:	2c 04 01 00 
    732b29e03216:	b8 2c 04 01 00       	mov    eax,0x1042c
    732b29e0321b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03222:	04 00 00 00 
    732b29e03226:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0322d:	02 00 00 00 
    732b29e03231:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03234:	be 2c 04 01 00       	mov    esi,0x1042c
    732b29e03239:	4c 89 ef             	mov    rdi,r13
    732b29e0323c:	e8 1f cf ff e7       	call   0x732b11e00160
    732b29e03241:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e03245:	0f 84 33 f2 ff e7    	je     0x732b11e0247e
    732b29e0324b:	eb 0f                	jmp    0x732b29e0325c
    732b29e0324d:	b8 2c 04 01 00       	mov    eax,0x1042c
    732b29e03252:	83 c0 04             	add    eax,0x4
    732b29e03255:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0325c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03263:	04 00 00 00 
    732b29e03267:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0326e:	02 00 00 00 
    732b29e03272:	4c 89 ef             	mov    rdi,r13
    732b29e03275:	e8 d6 ce ff e7       	call   0x732b11e00150
    732b29e0327a:	e9 ff f1 ff e7       	jmp    0x732b11e0247e
    732b29e0327f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    732b29e03286:	30 04 01 00 
    732b29e0328a:	b8 30 04 01 00       	mov    eax,0x10430
    732b29e0328f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03296:	04 00 00 00 
    732b29e0329a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e032a1:	03 00 00 00 
    732b29e032a5:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e032a8:	be 30 04 01 00       	mov    esi,0x10430
    732b29e032ad:	4c 89 ef             	mov    rdi,r13
    732b29e032b0:	e8 ab ce ff e7       	call   0x732b11e00160
    732b29e032b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e032bc:	00 
    732b29e032bd:	0f 84 00 f2 ff e7    	je     0x732b11e024c3
    732b29e032c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e032ca:	04 00 00 00 
    732b29e032ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e032d5:	03 00 00 00 
    732b29e032d9:	58                   	pop    rax
    732b29e032da:	e9 08 f4 ff e7       	jmp    0x732b11e026e7
    732b29e032df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    732b29e032e6:	34 04 01 00 
    732b29e032ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e032f1:	02 00 00 00 
    732b29e032f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e032fc:	04 00 00 00 
    732b29e03300:	ba 34 04 01 00       	mov    edx,0x10434
    732b29e03305:	4c 89 ef             	mov    rdi,r13
    732b29e03308:	4c 89 f6             	mov    rsi,r14
    732b29e0330b:	45 31 c0             	xor    r8d,r8d
    732b29e0330e:	e8 6d cd ff e7       	call   0x732b11e00080
    732b29e03313:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0331a:	02 00 00 00 
    732b29e0331e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03325:	04 00 00 00 
    732b29e03329:	58                   	pop    rax
    732b29e0332a:	e9 b8 f3 ff e7       	jmp    0x732b11e026e7
    732b29e0332f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    732b29e03336:	34 04 01 00 
    732b29e0333a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03341:	02 00 00 00 
    732b29e03345:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0334c:	04 00 00 00 
    732b29e03350:	4c 89 f7             	mov    rdi,r14
    732b29e03353:	89 ce                	mov    esi,ecx
    732b29e03355:	e8 e6 cc ff e7       	call   0x732b11e00040
    732b29e0335a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03361:	00 
    732b29e03362:	0f 84 8e f1 ff e7    	je     0x732b11e024f6
    732b29e03368:	eb a9                	jmp    0x732b29e03313
    732b29e0336a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    732b29e03371:	34 04 01 00 
    732b29e03375:	b8 34 04 01 00       	mov    eax,0x10434
    732b29e0337a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03381:	02 00 00 00 
    732b29e03385:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0338c:	04 00 00 00 
    732b29e03390:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03393:	be 34 04 01 00       	mov    esi,0x10434
    732b29e03398:	4c 89 ef             	mov    rdi,r13
    732b29e0339b:	e8 c0 cd ff e7       	call   0x732b11e00160
    732b29e033a0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e033a7:	00 
    732b29e033a8:	0f 84 6e f1 ff e7    	je     0x732b11e0251c
    732b29e033ae:	e9 60 ff ff ff       	jmp    0x732b29e03313
    732b29e033b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10436
    732b29e033ba:	36 04 01 00 
    732b29e033be:	b8 36 04 01 00       	mov    eax,0x10436
    732b29e033c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e033ca:	02 00 00 00 
    732b29e033ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e033d5:	05 00 00 00 
    732b29e033d9:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e033dc:	be 36 04 01 00       	mov    esi,0x10436
    732b29e033e1:	4c 89 ef             	mov    rdi,r13
    732b29e033e4:	e8 77 cd ff e7       	call   0x732b11e00160
    732b29e033e9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e033f0:	00 
    732b29e033f1:	0f 84 5c f1 ff e7    	je     0x732b11e02553
    732b29e033f7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e033fe:	02 00 00 00 
    732b29e03402:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e03409:	05 00 00 00 
    732b29e0340d:	58                   	pop    rax
    732b29e0340e:	e9 d4 f2 ff e7       	jmp    0x732b11e026e7
    732b29e03413:	b8 38 04 01 00       	mov    eax,0x10438
    732b29e03418:	83 c0 0a             	add    eax,0xa
    732b29e0341b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e03422:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03429:	02 00 00 00 
    732b29e0342d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03434:	06 00 00 00 
    732b29e03438:	be 38 04 01 00       	mov    esi,0x10438
    732b29e0343d:	ba 38 04 01 00       	mov    edx,0x10438
    732b29e03442:	4c 89 ef             	mov    rdi,r13
    732b29e03445:	e8 16 cd ff e7       	call   0x732b11e00160
    732b29e0344a:	e9 3a f1 ff e7       	jmp    0x732b11e02589
    732b29e0344f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10438
    732b29e03456:	38 04 01 00 
    732b29e0345a:	b8 38 04 01 00       	mov    eax,0x10438
    732b29e0345f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03466:	02 00 00 00 
    732b29e0346a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03471:	06 00 00 00 
    732b29e03475:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03478:	be 38 04 01 00       	mov    esi,0x10438
    732b29e0347d:	4c 89 ef             	mov    rdi,r13
    732b29e03480:	e8 db cc ff e7       	call   0x732b11e00160
    732b29e03485:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0348c:	00 
    732b29e0348d:	0f 84 43 f1 ff e7    	je     0x732b11e025d6
    732b29e03493:	e9 00 f1 ff e7       	jmp    0x732b11e02598
    732b29e03498:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043a
    732b29e0349f:	3a 04 01 00 
    732b29e034a3:	b8 3a 04 01 00       	mov    eax,0x1043a
    732b29e034a8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e034af:	02 00 00 00 
    732b29e034b3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e034ba:	07 00 00 00 
    732b29e034be:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e034c1:	be 3a 04 01 00       	mov    esi,0x1043a
    732b29e034c6:	4c 89 ef             	mov    rdi,r13
    732b29e034c9:	e8 92 cc ff e7       	call   0x732b11e00160
    732b29e034ce:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e034d5:	00 
    732b29e034d6:	0f 84 26 f1 ff e7    	je     0x732b11e02602
    732b29e034dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e034e3:	02 00 00 00 
    732b29e034e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e034ee:	07 00 00 00 
    732b29e034f2:	58                   	pop    rax
    732b29e034f3:	e9 ef f1 ff e7       	jmp    0x732b11e026e7
    732b29e034f8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    732b29e034ff:	3c 04 01 00 
    732b29e03503:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0350a:	04 00 00 00 
    732b29e0350e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e03515:	08 00 00 00 
    732b29e03519:	ba 3c 04 01 00       	mov    edx,0x1043c
    732b29e0351e:	4c 89 ef             	mov    rdi,r13
    732b29e03521:	4c 89 f6             	mov    rsi,r14
    732b29e03524:	89 d9                	mov    ecx,ebx
    732b29e03526:	45 31 c0             	xor    r8d,r8d
    732b29e03529:	e8 52 cb ff e7       	call   0x732b11e00080
    732b29e0352e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03535:	04 00 00 00 
    732b29e03539:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e03540:	08 00 00 00 
    732b29e03544:	58                   	pop    rax
    732b29e03545:	e9 9d f1 ff e7       	jmp    0x732b11e026e7
    732b29e0354a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    732b29e03551:	3c 04 01 00 
    732b29e03555:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0355c:	04 00 00 00 
    732b29e03560:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e03567:	08 00 00 00 
    732b29e0356b:	4c 89 f7             	mov    rdi,r14
    732b29e0356e:	89 de                	mov    esi,ebx
    732b29e03570:	e8 cb ca ff e7       	call   0x732b11e00040
    732b29e03575:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0357c:	00 
    732b29e0357d:	75 af                	jne    0x732b29e0352e
    732b29e0357f:	41 89 c7             	mov    r15d,eax
    732b29e03582:	e9 b2 f0 ff e7       	jmp    0x732b11e02639
    732b29e03587:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    732b29e0358e:	3c 04 01 00 
    732b29e03592:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03599:	04 00 00 00 
    732b29e0359d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e035a4:	08 00 00 00 
    732b29e035a8:	4c 89 f7             	mov    rdi,r14
    732b29e035ab:	e8 90 ca ff e7       	call   0x732b11e00040
    732b29e035b0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e035b7:	00 
    732b29e035b8:	0f 84 9c f0 ff e7    	je     0x732b11e0265a
    732b29e035be:	e9 6b ff ff ff       	jmp    0x732b29e0352e
    732b29e035c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    732b29e035ca:	3c 04 01 00 
    732b29e035ce:	b8 3c 04 01 00       	mov    eax,0x1043c
    732b29e035d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e035da:	04 00 00 00 
    732b29e035de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e035e5:	08 00 00 00 
    732b29e035e9:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e035ec:	be 3c 04 01 00       	mov    esi,0x1043c
    732b29e035f1:	4c 89 ef             	mov    rdi,r13
    732b29e035f4:	e8 67 cb ff e7       	call   0x732b11e00160
    732b29e035f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03600:	00 
    732b29e03601:	0f 84 87 f0 ff e7    	je     0x732b11e0268e
    732b29e03607:	e9 22 ff ff ff       	jmp    0x732b29e0352e
    732b29e0360c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    732b29e03613:	40 04 01 00 
    732b29e03617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0361e:	02 00 00 00 
    732b29e03622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e03629:	09 00 00 00 
    732b29e0362d:	4c 89 ef             	mov    rdi,r13
    732b29e03630:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e03635:	4c 89 f2             	mov    rdx,r14
    732b29e03638:	e8 53 ca ff e7       	call   0x732b11e00090
    732b29e0363d:	e9 8e f0 ff e7       	jmp    0x732b11e026d0
    732b29e03642:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03649:	02 00 00 00 
    732b29e0364d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e03654:	09 00 00 00 
    732b29e03658:	be 40 04 01 00       	mov    esi,0x10440
    732b29e0365d:	ba 40 04 01 00       	mov    edx,0x10440
    732b29e03662:	4c 89 ef             	mov    rdi,r13
    732b29e03665:	e8 f6 ca ff e7       	call   0x732b11e00160
    732b29e0366a:	e9 61 f0 ff e7       	jmp    0x732b11e026d0
    732b29e0366f:	c2 08 00             	ret    0x8
