
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66626-1-126629223347840.bin:     file format binary


Disassembly of section .data:

0000732b29e03680 <.data>:
    732b29e03680:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e03686:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e03689:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e0368f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e03696:	0f 87 e5 f0 ff e7    	ja     0x732b11e02781
    732b29e0369c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x6
    732b29e036a3:	06 00 00 00 
    732b29e036a7:	e9 d5 f0 ff e7       	jmp    0x732b11e02781
    732b29e036ac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    732b29e036b3:	42 04 01 00 
    732b29e036b7:	b8 42 04 01 00       	mov    eax,0x10442
    732b29e036bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e036c3:	04 00 00 00 
    732b29e036c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e036ce:	01 00 00 00 
    732b29e036d2:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e036d5:	be 42 04 01 00       	mov    esi,0x10442
    732b29e036da:	4c 89 ef             	mov    rdi,r13
    732b29e036dd:	e8 7e ca ff e7       	call   0x732b11e00160
    732b29e036e2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e036e9:	00 
    732b29e036ea:	0f 84 c4 f0 ff e7    	je     0x732b11e027b4
    732b29e036f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e036f7:	04 00 00 00 
    732b29e036fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03702:	01 00 00 00 
    732b29e03706:	58                   	pop    rax
    732b29e03707:	e9 c3 f1 ff e7       	jmp    0x732b11e028cf
    732b29e0370c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10446
    732b29e03713:	46 04 01 00 
    732b29e03717:	b8 46 04 01 00       	mov    eax,0x10446
    732b29e0371c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03723:	04 00 00 00 
    732b29e03727:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0372e:	02 00 00 00 
    732b29e03732:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03735:	be 46 04 01 00       	mov    esi,0x10446
    732b29e0373a:	4c 89 ef             	mov    rdi,r13
    732b29e0373d:	e8 1e ca ff e7       	call   0x732b11e00160
    732b29e03742:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03749:	00 
    732b29e0374a:	0f 84 9b f0 ff e7    	je     0x732b11e027eb
    732b29e03750:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03757:	04 00 00 00 
    732b29e0375b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03762:	02 00 00 00 
    732b29e03766:	58                   	pop    rax
    732b29e03767:	e9 63 f1 ff e7       	jmp    0x732b11e028cf
    732b29e0376c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044a
    732b29e03773:	4a 04 01 00 
    732b29e03777:	b8 4a 04 01 00       	mov    eax,0x1044a
    732b29e0377c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03783:	02 00 00 00 
    732b29e03787:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e0378e:	03 00 00 00 
    732b29e03792:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03795:	be 4a 04 01 00       	mov    esi,0x1044a
    732b29e0379a:	4c 89 ef             	mov    rdi,r13
    732b29e0379d:	e8 be c9 ff e7       	call   0x732b11e00160
    732b29e037a2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e037a9:	00 
    732b29e037aa:	0f 84 70 f0 ff e7    	je     0x732b11e02820
    732b29e037b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e037b7:	02 00 00 00 
    732b29e037bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e037c2:	03 00 00 00 
    732b29e037c6:	58                   	pop    rax
    732b29e037c7:	e9 03 f1 ff e7       	jmp    0x732b11e028cf
    732b29e037cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    732b29e037d3:	4c 04 01 00 
    732b29e037d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e037de:	02 00 00 00 
    732b29e037e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e037e9:	04 00 00 00 
    732b29e037ed:	ba 4c 04 01 00       	mov    edx,0x1044c
    732b29e037f2:	4c 89 ef             	mov    rdi,r13
    732b29e037f5:	4c 89 f6             	mov    rsi,r14
    732b29e037f8:	45 31 c0             	xor    r8d,r8d
    732b29e037fb:	e8 80 c8 ff e7       	call   0x732b11e00080
    732b29e03800:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03807:	02 00 00 00 
    732b29e0380b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03812:	04 00 00 00 
    732b29e03816:	58                   	pop    rax
    732b29e03817:	e9 b3 f0 ff e7       	jmp    0x732b11e028cf
    732b29e0381c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    732b29e03823:	4c 04 01 00 
    732b29e03827:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0382e:	02 00 00 00 
    732b29e03832:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03839:	04 00 00 00 
    732b29e0383d:	4c 89 f7             	mov    rdi,r14
    732b29e03840:	89 ce                	mov    esi,ecx
    732b29e03842:	e8 f9 c7 ff e7       	call   0x732b11e00040
    732b29e03847:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0384e:	00 
    732b29e0384f:	0f 84 fe ef ff e7    	je     0x732b11e02853
    732b29e03855:	eb a9                	jmp    0x732b29e03800
    732b29e03857:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    732b29e0385e:	4c 04 01 00 
    732b29e03862:	b8 4c 04 01 00       	mov    eax,0x1044c
    732b29e03867:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0386e:	02 00 00 00 
    732b29e03872:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03879:	04 00 00 00 
    732b29e0387d:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03880:	be 4c 04 01 00       	mov    esi,0x1044c
    732b29e03885:	4c 89 ef             	mov    rdi,r13
    732b29e03888:	e8 d3 c8 ff e7       	call   0x732b11e00160
    732b29e0388d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03894:	00 
    732b29e03895:	0f 84 de ef ff e7    	je     0x732b11e02879
    732b29e0389b:	e9 60 ff ff ff       	jmp    0x732b29e03800
    732b29e038a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044e
    732b29e038a7:	4e 04 01 00 
    732b29e038ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e038b2:	02 00 00 00 
    732b29e038b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e038bd:	05 00 00 00 
    732b29e038c1:	4c 89 ef             	mov    rdi,r13
    732b29e038c4:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e038c9:	4c 89 f2             	mov    rdx,r14
    732b29e038cc:	e8 bf c7 ff e7       	call   0x732b11e00090
    732b29e038d1:	e9 e2 ef ff e7       	jmp    0x732b11e028b8
    732b29e038d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e038dd:	02 00 00 00 
    732b29e038e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e038e8:	05 00 00 00 
    732b29e038ec:	be 4e 04 01 00       	mov    esi,0x1044e
    732b29e038f1:	ba 4e 04 01 00       	mov    edx,0x1044e
    732b29e038f6:	4c 89 ef             	mov    rdi,r13
    732b29e038f9:	e8 62 c8 ff e7       	call   0x732b11e00160
    732b29e038fe:	e9 b5 ef ff e7       	jmp    0x732b11e028b8
    732b29e03903:	c2 08 00             	ret    0x8
