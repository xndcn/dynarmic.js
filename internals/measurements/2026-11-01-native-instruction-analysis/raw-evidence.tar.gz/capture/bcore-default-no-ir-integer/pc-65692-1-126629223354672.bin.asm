
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65692-1-126629223354672.bin:     file format binary


Disassembly of section .data:

0000732b29e05130 <.data>:
    732b29e05130:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e05136:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e05139:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e0513f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e05146:	0f 87 85 f4 ff e7    	ja     0x732b11e045d1
    732b29e0514c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xa
    732b29e05153:	0a 00 00 00 
    732b29e05157:	e9 75 f4 ff e7       	jmp    0x732b11e045d1
    732b29e0515c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    732b29e05163:	9c 00 01 00 
    732b29e05167:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0516e:	02 00 00 00 
    732b29e05172:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05179:	01 00 00 00 
    732b29e0517d:	ba 9c 00 01 00       	mov    edx,0x1009c
    732b29e05182:	4c 89 ef             	mov    rdi,r13
    732b29e05185:	4c 89 f6             	mov    rsi,r14
    732b29e05188:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e0518e:	e8 ed ae ff e7       	call   0x732b11e00080
    732b29e05193:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0519a:	02 00 00 00 
    732b29e0519e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e051a5:	01 00 00 00 
    732b29e051a9:	58                   	pop    rax
    732b29e051aa:	e9 9e fa ff e7       	jmp    0x732b11e04c4d
    732b29e051af:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    732b29e051b6:	9c 00 01 00 
    732b29e051ba:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e051c1:	02 00 00 00 
    732b29e051c5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e051cc:	01 00 00 00 
    732b29e051d0:	4c 89 f7             	mov    rdi,r14
    732b29e051d3:	89 ce                	mov    esi,ecx
    732b29e051d5:	e8 96 ae ff e7       	call   0x732b11e00070
    732b29e051da:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e051e1:	00 
    732b29e051e2:	0f 84 26 f4 ff e7    	je     0x732b11e0460e
    732b29e051e8:	eb a9                	jmp    0x732b29e05193
    732b29e051ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009c
    732b29e051f1:	9c 00 01 00 
    732b29e051f5:	b8 9c 00 01 00       	mov    eax,0x1009c
    732b29e051fa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05201:	02 00 00 00 
    732b29e05205:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0520c:	01 00 00 00 
    732b29e05210:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05213:	be 9c 00 01 00       	mov    esi,0x1009c
    732b29e05218:	4c 89 ef             	mov    rdi,r13
    732b29e0521b:	e8 40 af ff e7       	call   0x732b11e00160
    732b29e05220:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e05223:	0f 84 16 f4 ff e7    	je     0x732b11e0463f
    732b29e05229:	eb 0f                	jmp    0x732b29e0523a
    732b29e0522b:	b8 9c 00 01 00       	mov    eax,0x1009c
    732b29e05230:	83 c0 02             	add    eax,0x2
    732b29e05233:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0523a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05241:	02 00 00 00 
    732b29e05245:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0524c:	01 00 00 00 
    732b29e05250:	4c 89 ef             	mov    rdi,r13
    732b29e05253:	e8 f8 ae ff e7       	call   0x732b11e00150
    732b29e05258:	e9 e2 f3 ff e7       	jmp    0x732b11e0463f
    732b29e0525d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    732b29e05264:	9e 00 01 00 
    732b29e05268:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0526f:	02 00 00 00 
    732b29e05273:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0527a:	02 00 00 00 
    732b29e0527e:	ba 9e 00 01 00       	mov    edx,0x1009e
    732b29e05283:	4c 89 ef             	mov    rdi,r13
    732b29e05286:	4c 89 f6             	mov    rsi,r14
    732b29e05289:	89 d9                	mov    ecx,ebx
    732b29e0528b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e05291:	e8 ea ad ff e7       	call   0x732b11e00080
    732b29e05296:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0529d:	02 00 00 00 
    732b29e052a1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e052a8:	02 00 00 00 
    732b29e052ac:	58                   	pop    rax
    732b29e052ad:	e9 9b f9 ff e7       	jmp    0x732b11e04c4d
    732b29e052b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    732b29e052b9:	9e 00 01 00 
    732b29e052bd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e052c4:	02 00 00 00 
    732b29e052c8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e052cf:	02 00 00 00 
    732b29e052d3:	4c 89 f7             	mov    rdi,r14
    732b29e052d6:	89 de                	mov    esi,ebx
    732b29e052d8:	e8 93 ad ff e7       	call   0x732b11e00070
    732b29e052dd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e052e4:	00 
    732b29e052e5:	0f 84 a2 f3 ff e7    	je     0x732b11e0468d
    732b29e052eb:	eb a9                	jmp    0x732b29e05296
    732b29e052ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    732b29e052f4:	9e 00 01 00 
    732b29e052f8:	b8 9e 00 01 00       	mov    eax,0x1009e
    732b29e052fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05304:	02 00 00 00 
    732b29e05308:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0530f:	02 00 00 00 
    732b29e05313:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05316:	be 9e 00 01 00       	mov    esi,0x1009e
    732b29e0531b:	4c 89 ef             	mov    rdi,r13
    732b29e0531e:	e8 3d ae ff e7       	call   0x732b11e00160
    732b29e05323:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    732b29e05327:	0f 84 99 f3 ff e7    	je     0x732b11e046c6
    732b29e0532d:	eb 0f                	jmp    0x732b29e0533e
    732b29e0532f:	b8 9e 00 01 00       	mov    eax,0x1009e
    732b29e05334:	83 c0 02             	add    eax,0x2
    732b29e05337:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0533e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05345:	02 00 00 00 
    732b29e05349:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05350:	02 00 00 00 
    732b29e05354:	4c 89 ef             	mov    rdi,r13
    732b29e05357:	e8 f4 ad ff e7       	call   0x732b11e00150
    732b29e0535c:	e9 65 f3 ff e7       	jmp    0x732b11e046c6
    732b29e05361:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a0
    732b29e05368:	a0 00 01 00 
    732b29e0536c:	b8 a0 00 01 00       	mov    eax,0x100a0
    732b29e05371:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05378:	02 00 00 00 
    732b29e0537c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05383:	03 00 00 00 
    732b29e05387:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0538a:	be a0 00 01 00       	mov    esi,0x100a0
    732b29e0538f:	4c 89 ef             	mov    rdi,r13
    732b29e05392:	e8 c9 ad ff e7       	call   0x732b11e00160
    732b29e05397:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0539e:	00 
    732b29e0539f:	0f 84 aa f3 ff e7    	je     0x732b11e0474f
    732b29e053a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e053ac:	02 00 00 00 
    732b29e053b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e053b7:	03 00 00 00 
    732b29e053bb:	58                   	pop    rax
    732b29e053bc:	e9 8c f8 ff e7       	jmp    0x732b11e04c4d
    732b29e053c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a2
    732b29e053c8:	a2 00 01 00 
    732b29e053cc:	b8 a2 00 01 00       	mov    eax,0x100a2
    732b29e053d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e053d8:	02 00 00 00 
    732b29e053dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e053e3:	04 00 00 00 
    732b29e053e7:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e053ea:	be a2 00 01 00       	mov    esi,0x100a2
    732b29e053ef:	4c 89 ef             	mov    rdi,r13
    732b29e053f2:	e8 69 ad ff e7       	call   0x732b11e00160
    732b29e053f7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e053fe:	00 
    732b29e053ff:	0f 84 76 f3 ff e7    	je     0x732b11e0477b
    732b29e05405:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0540c:	02 00 00 00 
    732b29e05410:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e05417:	04 00 00 00 
    732b29e0541b:	58                   	pop    rax
    732b29e0541c:	e9 2c f8 ff e7       	jmp    0x732b11e04c4d
    732b29e05421:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    732b29e05428:	a4 00 01 00 
    732b29e0542c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05433:	02 00 00 00 
    732b29e05437:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0543e:	05 00 00 00 
    732b29e05442:	ba a4 00 01 00       	mov    edx,0x100a4
    732b29e05447:	4c 89 ef             	mov    rdi,r13
    732b29e0544a:	4c 89 f6             	mov    rsi,r14
    732b29e0544d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e05453:	e8 28 ac ff e7       	call   0x732b11e00080
    732b29e05458:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0545f:	02 00 00 00 
    732b29e05463:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0546a:	05 00 00 00 
    732b29e0546e:	58                   	pop    rax
    732b29e0546f:	e9 d9 f7 ff e7       	jmp    0x732b11e04c4d
    732b29e05474:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    732b29e0547b:	a4 00 01 00 
    732b29e0547f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05486:	02 00 00 00 
    732b29e0548a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e05491:	05 00 00 00 
    732b29e05495:	4c 89 f7             	mov    rdi,r14
    732b29e05498:	89 ce                	mov    esi,ecx
    732b29e0549a:	e8 d1 ab ff e7       	call   0x732b11e00070
    732b29e0549f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e054a6:	00 
    732b29e054a7:	0f 84 0c f3 ff e7    	je     0x732b11e047b9
    732b29e054ad:	eb a9                	jmp    0x732b29e05458
    732b29e054af:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    732b29e054b6:	a4 00 01 00 
    732b29e054ba:	b8 a4 00 01 00       	mov    eax,0x100a4
    732b29e054bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e054c6:	02 00 00 00 
    732b29e054ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e054d1:	05 00 00 00 
    732b29e054d5:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e054d8:	be a4 00 01 00       	mov    esi,0x100a4
    732b29e054dd:	4c 89 ef             	mov    rdi,r13
    732b29e054e0:	e8 7b ac ff e7       	call   0x732b11e00160
    732b29e054e5:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e054e8:	0f 84 fc f2 ff e7    	je     0x732b11e047ea
    732b29e054ee:	eb 0f                	jmp    0x732b29e054ff
    732b29e054f0:	b8 a4 00 01 00       	mov    eax,0x100a4
    732b29e054f5:	83 c0 02             	add    eax,0x2
    732b29e054f8:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e054ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05506:	02 00 00 00 
    732b29e0550a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e05511:	05 00 00 00 
    732b29e05515:	4c 89 ef             	mov    rdi,r13
    732b29e05518:	e8 33 ac ff e7       	call   0x732b11e00150
    732b29e0551d:	e9 c8 f2 ff e7       	jmp    0x732b11e047ea
    732b29e05522:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a6
    732b29e05529:	a6 00 01 00 
    732b29e0552d:	b8 a6 00 01 00       	mov    eax,0x100a6
    732b29e05532:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05539:	02 00 00 00 
    732b29e0553d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e05544:	06 00 00 00 
    732b29e05548:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0554b:	be a6 00 01 00       	mov    esi,0x100a6
    732b29e05550:	4c 89 ef             	mov    rdi,r13
    732b29e05553:	e8 08 ac ff e7       	call   0x732b11e00160
    732b29e05558:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0555f:	00 
    732b29e05560:	0f 84 03 f3 ff e7    	je     0x732b11e04869
    732b29e05566:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0556d:	02 00 00 00 
    732b29e05571:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e05578:	06 00 00 00 
    732b29e0557c:	58                   	pop    rax
    732b29e0557d:	e9 cb f6 ff e7       	jmp    0x732b11e04c4d
    732b29e05582:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a8
    732b29e05589:	a8 00 01 00 
    732b29e0558d:	b8 a8 00 01 00       	mov    eax,0x100a8
    732b29e05592:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05599:	02 00 00 00 
    732b29e0559d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e055a4:	07 00 00 00 
    732b29e055a8:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e055ab:	be a8 00 01 00       	mov    esi,0x100a8
    732b29e055b0:	4c 89 ef             	mov    rdi,r13
    732b29e055b3:	e8 a8 ab ff e7       	call   0x732b11e00160
    732b29e055b8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e055bf:	00 
    732b29e055c0:	0f 84 d1 f2 ff e7    	je     0x732b11e04897
    732b29e055c6:	e9 0b f3 ff e7       	jmp    0x732b11e048d6
    732b29e055cb:	b8 a8 00 01 00       	mov    eax,0x100a8
    732b29e055d0:	83 c0 dc             	add    eax,0xffffffdc
    732b29e055d3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e055da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e055e1:	02 00 00 00 
    732b29e055e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e055ec:	07 00 00 00 
    732b29e055f0:	be a8 00 01 00       	mov    esi,0x100a8
    732b29e055f5:	ba a8 00 01 00       	mov    edx,0x100a8
    732b29e055fa:	4c 89 ef             	mov    rdi,r13
    732b29e055fd:	e8 5e ab ff e7       	call   0x732b11e00160
    732b29e05602:	e9 c0 f2 ff e7       	jmp    0x732b11e048c7
    732b29e05607:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100aa
    732b29e0560e:	aa 00 01 00 
    732b29e05612:	b8 aa 00 01 00       	mov    eax,0x100aa
    732b29e05617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0561e:	04 00 00 00 
    732b29e05622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e05629:	08 00 00 00 
    732b29e0562d:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e05630:	be aa 00 01 00       	mov    esi,0x100aa
    732b29e05635:	4c 89 ef             	mov    rdi,r13
    732b29e05638:	e8 23 ab ff e7       	call   0x732b11e00160
    732b29e0563d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05644:	00 
    732b29e05645:	0f 84 da f2 ff e7    	je     0x732b11e04925
    732b29e0564b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05652:	04 00 00 00 
    732b29e05656:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e0565d:	08 00 00 00 
    732b29e05661:	58                   	pop    rax
    732b29e05662:	e9 e6 f5 ff e7       	jmp    0x732b11e04c4d
    732b29e05667:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ae
    732b29e0566e:	ae 00 01 00 
    732b29e05672:	b8 ae 00 01 00       	mov    eax,0x100ae
    732b29e05677:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0567e:	02 00 00 00 
    732b29e05682:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e05689:	09 00 00 00 
    732b29e0568d:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05690:	be ae 00 01 00       	mov    esi,0x100ae
    732b29e05695:	4c 89 ef             	mov    rdi,r13
    732b29e05698:	e8 c3 aa ff e7       	call   0x732b11e00160
    732b29e0569d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e056a4:	00 
    732b29e056a5:	0f 84 a6 f2 ff e7    	je     0x732b11e04951
    732b29e056ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e056b2:	02 00 00 00 
    732b29e056b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e056bd:	09 00 00 00 
    732b29e056c1:	58                   	pop    rax
    732b29e056c2:	e9 86 f5 ff e7       	jmp    0x732b11e04c4d
    732b29e056c7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b0
    732b29e056ce:	b0 00 01 00 
    732b29e056d2:	b8 b0 00 01 00       	mov    eax,0x100b0
    732b29e056d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e056de:	04 00 00 00 
    732b29e056e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e056e9:	0a 00 00 00 
    732b29e056ed:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e056f0:	be b0 00 01 00       	mov    esi,0x100b0
    732b29e056f5:	4c 89 ef             	mov    rdi,r13
    732b29e056f8:	e8 63 aa ff e7       	call   0x732b11e00160
    732b29e056fd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05704:	00 
    732b29e05705:	0f 84 7d f2 ff e7    	je     0x732b11e04988
    732b29e0570b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05712:	04 00 00 00 
    732b29e05716:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e0571d:	0a 00 00 00 
    732b29e05721:	58                   	pop    rax
    732b29e05722:	e9 26 f5 ff e7       	jmp    0x732b11e04c4d
    732b29e05727:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    732b29e0572e:	b4 00 01 00 
    732b29e05732:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05739:	02 00 00 00 
    732b29e0573d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e05744:	0b 00 00 00 
    732b29e05748:	ba b4 00 01 00       	mov    edx,0x100b4
    732b29e0574d:	4c 89 ef             	mov    rdi,r13
    732b29e05750:	4c 89 f6             	mov    rsi,r14
    732b29e05753:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e05759:	e8 22 a9 ff e7       	call   0x732b11e00080
    732b29e0575e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05765:	02 00 00 00 
    732b29e05769:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e05770:	0b 00 00 00 
    732b29e05774:	58                   	pop    rax
    732b29e05775:	e9 d3 f4 ff e7       	jmp    0x732b11e04c4d
    732b29e0577a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    732b29e05781:	b4 00 01 00 
    732b29e05785:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0578c:	02 00 00 00 
    732b29e05790:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e05797:	0b 00 00 00 
    732b29e0579b:	4c 89 f7             	mov    rdi,r14
    732b29e0579e:	89 ce                	mov    esi,ecx
    732b29e057a0:	e8 cb a8 ff e7       	call   0x732b11e00070
    732b29e057a5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e057ac:	00 
    732b29e057ad:	0f 84 13 f2 ff e7    	je     0x732b11e049c6
    732b29e057b3:	eb a9                	jmp    0x732b29e0575e
    732b29e057b5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    732b29e057bc:	b4 00 01 00 
    732b29e057c0:	b8 b4 00 01 00       	mov    eax,0x100b4
    732b29e057c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e057cc:	02 00 00 00 
    732b29e057d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e057d7:	0b 00 00 00 
    732b29e057db:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e057de:	be b4 00 01 00       	mov    esi,0x100b4
    732b29e057e3:	4c 89 ef             	mov    rdi,r13
    732b29e057e6:	e8 75 a9 ff e7       	call   0x732b11e00160
    732b29e057eb:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e057ee:	0f 84 03 f2 ff e7    	je     0x732b11e049f7
    732b29e057f4:	eb 0f                	jmp    0x732b29e05805
    732b29e057f6:	b8 b4 00 01 00       	mov    eax,0x100b4
    732b29e057fb:	83 c0 02             	add    eax,0x2
    732b29e057fe:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e05805:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0580c:	02 00 00 00 
    732b29e05810:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e05817:	0b 00 00 00 
    732b29e0581b:	4c 89 ef             	mov    rdi,r13
    732b29e0581e:	e8 2d a9 ff e7       	call   0x732b11e00150
    732b29e05823:	e9 cf f1 ff e7       	jmp    0x732b11e049f7
    732b29e05828:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    732b29e0582f:	b6 00 01 00 
    732b29e05833:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0583a:	04 00 00 00 
    732b29e0583e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e05845:	0c 00 00 00 
    732b29e05849:	ba b6 00 01 00       	mov    edx,0x100b6
    732b29e0584e:	4c 89 ef             	mov    rdi,r13
    732b29e05851:	4c 89 f6             	mov    rsi,r14
    732b29e05854:	89 d9                	mov    ecx,ebx
    732b29e05856:	45 31 c0             	xor    r8d,r8d
    732b29e05859:	e8 22 a8 ff e7       	call   0x732b11e00080
    732b29e0585e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05865:	04 00 00 00 
    732b29e05869:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e05870:	0c 00 00 00 
    732b29e05874:	58                   	pop    rax
    732b29e05875:	e9 d3 f3 ff e7       	jmp    0x732b11e04c4d
    732b29e0587a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    732b29e05881:	b6 00 01 00 
    732b29e05885:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0588c:	04 00 00 00 
    732b29e05890:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e05897:	0c 00 00 00 
    732b29e0589b:	4c 89 f7             	mov    rdi,r14
    732b29e0589e:	89 de                	mov    esi,ebx
    732b29e058a0:	e8 9b a7 ff e7       	call   0x732b11e00040
    732b29e058a5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e058ac:	00 
    732b29e058ad:	75 af                	jne    0x732b29e0585e
    732b29e058af:	41 89 c7             	mov    r15d,eax
    732b29e058b2:	e9 85 f1 ff e7       	jmp    0x732b11e04a3c
    732b29e058b7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    732b29e058be:	b6 00 01 00 
    732b29e058c2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e058c9:	04 00 00 00 
    732b29e058cd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e058d4:	0c 00 00 00 
    732b29e058d8:	4c 89 f7             	mov    rdi,r14
    732b29e058db:	e8 60 a7 ff e7       	call   0x732b11e00040
    732b29e058e0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e058e7:	00 
    732b29e058e8:	0f 84 6f f1 ff e7    	je     0x732b11e04a5d
    732b29e058ee:	e9 6b ff ff ff       	jmp    0x732b29e0585e
    732b29e058f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    732b29e058fa:	b6 00 01 00 
    732b29e058fe:	b8 b6 00 01 00       	mov    eax,0x100b6
    732b29e05903:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0590a:	04 00 00 00 
    732b29e0590e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e05915:	0c 00 00 00 
    732b29e05919:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0591c:	be b6 00 01 00       	mov    esi,0x100b6
    732b29e05921:	4c 89 ef             	mov    rdi,r13
    732b29e05924:	e8 37 a8 ff e7       	call   0x732b11e00160
    732b29e05929:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05930:	00 
    732b29e05931:	0f 84 5a f1 ff e7    	je     0x732b11e04a91
    732b29e05937:	e9 22 ff ff ff       	jmp    0x732b29e0585e
    732b29e0593c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ba
    732b29e05943:	ba 00 01 00 
    732b29e05947:	b8 ba 00 01 00       	mov    eax,0x100ba
    732b29e0594c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05953:	02 00 00 00 
    732b29e05957:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e0595e:	0d 00 00 00 
    732b29e05962:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05965:	be ba 00 01 00       	mov    esi,0x100ba
    732b29e0596a:	4c 89 ef             	mov    rdi,r13
    732b29e0596d:	e8 ee a7 ff e7       	call   0x732b11e00160
    732b29e05972:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05979:	00 
    732b29e0597a:	0f 84 3d f1 ff e7    	je     0x732b11e04abd
    732b29e05980:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05987:	02 00 00 00 
    732b29e0598b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e05992:	0d 00 00 00 
    732b29e05996:	58                   	pop    rax
    732b29e05997:	e9 b1 f2 ff e7       	jmp    0x732b11e04c4d
    732b29e0599c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e059a3:	bc 00 01 00 
    732b29e059a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e059ae:	02 00 00 00 
    732b29e059b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e059b9:	0e 00 00 00 
    732b29e059bd:	ba bc 00 01 00       	mov    edx,0x100bc
    732b29e059c2:	4c 89 ef             	mov    rdi,r13
    732b29e059c5:	4c 89 f6             	mov    rsi,r14
    732b29e059c8:	89 d9                	mov    ecx,ebx
    732b29e059ca:	45 31 c0             	xor    r8d,r8d
    732b29e059cd:	e8 ae a6 ff e7       	call   0x732b11e00080
    732b29e059d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e059d9:	02 00 00 00 
    732b29e059dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e059e4:	0e 00 00 00 
    732b29e059e8:	58                   	pop    rax
    732b29e059e9:	e9 5f f2 ff e7       	jmp    0x732b11e04c4d
    732b29e059ee:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e059f5:	bc 00 01 00 
    732b29e059f9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05a00:	02 00 00 00 
    732b29e05a04:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05a0b:	0e 00 00 00 
    732b29e05a0f:	4c 89 f7             	mov    rdi,r14
    732b29e05a12:	89 de                	mov    esi,ebx
    732b29e05a14:	e8 27 a6 ff e7       	call   0x732b11e00040
    732b29e05a19:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05a20:	00 
    732b29e05a21:	0f 84 cc f0 ff e7    	je     0x732b11e04af3
    732b29e05a27:	eb a9                	jmp    0x732b29e059d2
    732b29e05a29:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05a30:	bc 00 01 00 
    732b29e05a34:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05a3b:	02 00 00 00 
    732b29e05a3f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05a46:	0e 00 00 00 
    732b29e05a4a:	4c 89 f7             	mov    rdi,r14
    732b29e05a4d:	e8 ee a5 ff e7       	call   0x732b11e00040
    732b29e05a52:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05a59:	00 
    732b29e05a5a:	0f 84 b6 f0 ff e7    	je     0x732b11e04b16
    732b29e05a60:	e9 6d ff ff ff       	jmp    0x732b29e059d2
    732b29e05a65:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05a6c:	bc 00 01 00 
    732b29e05a70:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05a77:	02 00 00 00 
    732b29e05a7b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05a82:	0e 00 00 00 
    732b29e05a86:	4c 89 f7             	mov    rdi,r14
    732b29e05a89:	e8 b2 a5 ff e7       	call   0x732b11e00040
    732b29e05a8e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05a95:	00 
    732b29e05a96:	0f 84 9d f0 ff e7    	je     0x732b11e04b39
    732b29e05a9c:	e9 31 ff ff ff       	jmp    0x732b29e059d2
    732b29e05aa1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05aa8:	bc 00 01 00 
    732b29e05aac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05ab3:	02 00 00 00 
    732b29e05ab7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05abe:	0e 00 00 00 
    732b29e05ac2:	4c 89 f7             	mov    rdi,r14
    732b29e05ac5:	e8 76 a5 ff e7       	call   0x732b11e00040
    732b29e05aca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05ad1:	00 
    732b29e05ad2:	0f 84 84 f0 ff e7    	je     0x732b11e04b5c
    732b29e05ad8:	e9 f5 fe ff ff       	jmp    0x732b29e059d2
    732b29e05add:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05ae4:	bc 00 01 00 
    732b29e05ae8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05aef:	02 00 00 00 
    732b29e05af3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05afa:	0e 00 00 00 
    732b29e05afe:	4c 89 f7             	mov    rdi,r14
    732b29e05b01:	e8 3a a5 ff e7       	call   0x732b11e00040
    732b29e05b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05b0d:	00 
    732b29e05b0e:	0f 84 6b f0 ff e7    	je     0x732b11e04b7f
    732b29e05b14:	e9 b9 fe ff ff       	jmp    0x732b29e059d2
    732b29e05b19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05b20:	bc 00 01 00 
    732b29e05b24:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05b2b:	02 00 00 00 
    732b29e05b2f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05b36:	0e 00 00 00 
    732b29e05b3a:	4c 89 f7             	mov    rdi,r14
    732b29e05b3d:	e8 fe a4 ff e7       	call   0x732b11e00040
    732b29e05b42:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05b49:	00 
    732b29e05b4a:	0f 84 52 f0 ff e7    	je     0x732b11e04ba2
    732b29e05b50:	e9 7d fe ff ff       	jmp    0x732b29e059d2
    732b29e05b55:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05b5c:	bc 00 01 00 
    732b29e05b60:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05b67:	02 00 00 00 
    732b29e05b6b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05b72:	0e 00 00 00 
    732b29e05b76:	4c 89 f7             	mov    rdi,r14
    732b29e05b79:	e8 c2 a4 ff e7       	call   0x732b11e00040
    732b29e05b7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05b85:	00 
    732b29e05b86:	0f 84 3b f0 ff e7    	je     0x732b11e04bc7
    732b29e05b8c:	e9 41 fe ff ff       	jmp    0x732b29e059d2
    732b29e05b91:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    732b29e05b98:	bc 00 01 00 
    732b29e05b9c:	b8 bc 00 01 00       	mov    eax,0x100bc
    732b29e05ba1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05ba8:	02 00 00 00 
    732b29e05bac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e05bb3:	0e 00 00 00 
    732b29e05bb7:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05bba:	be bc 00 01 00       	mov    esi,0x100bc
    732b29e05bbf:	4c 89 ef             	mov    rdi,r13
    732b29e05bc2:	e8 99 a5 ff e7       	call   0x732b11e00160
    732b29e05bc7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05bce:	00 
    732b29e05bcf:	0f 84 1f f0 ff e7    	je     0x732b11e04bf4
    732b29e05bd5:	e9 f8 fd ff ff       	jmp    0x732b29e059d2
    732b29e05bda:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100be
    732b29e05be1:	be 00 01 00 
    732b29e05be5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05bec:	02 00 00 00 
    732b29e05bf0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e05bf7:	0f 00 00 00 
    732b29e05bfb:	4c 89 ef             	mov    rdi,r13
    732b29e05bfe:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e05c03:	4c 89 f2             	mov    rdx,r14
    732b29e05c06:	e8 85 a4 ff e7       	call   0x732b11e00090
    732b29e05c0b:	e9 26 f0 ff e7       	jmp    0x732b11e04c36
    732b29e05c10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05c17:	02 00 00 00 
    732b29e05c1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e05c22:	0f 00 00 00 
    732b29e05c26:	be be 00 01 00       	mov    esi,0x100be
    732b29e05c2b:	ba be 00 01 00       	mov    edx,0x100be
    732b29e05c30:	4c 89 ef             	mov    rdi,r13
    732b29e05c33:	e8 28 a5 ff e7       	call   0x732b11e00160
    732b29e05c38:	e9 f9 ef ff e7       	jmp    0x732b11e04c36
    732b29e05c3d:	c2 08 00             	ret    0x8
