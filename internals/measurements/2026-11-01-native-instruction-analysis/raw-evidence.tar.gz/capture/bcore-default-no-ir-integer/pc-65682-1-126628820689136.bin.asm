
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65682-1-126628820689136.bin:     file format binary


Disassembly of section .data:

0000732b11e020f0 <.data>:
    732b11e020f0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e020f7:	8b 88 10 00 10 00    	mov    ecx,DWORD PTR [rax+0x100010]
    732b11e020fd:	ff c1                	inc    ecx
    732b11e020ff:	89 88 10 00 10 00    	mov    DWORD PTR [rax+0x100010],ecx
    732b11e02105:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0210b:	0f 84 4f 0d 00 18    	je     0x732b29e02e60
    732b11e02111:	50                   	push   rax
    732b11e02112:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e02116:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e0211d:	31 d2                	xor    edx,edx
    732b11e0211f:	85 c0                	test   eax,eax
    732b11e02121:	0f 94 c2             	sete   dl
    732b11e02124:	c1 e8 1f             	shr    eax,0x1f
    732b11e02127:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e0212e:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e02135:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e0213c:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    732b11e02143:	00 00 00 
    732b11e02146:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    732b11e0214d:	81 f9 92 00 01 00    	cmp    ecx,0x10092
    732b11e02153:	0f 84 33 0d 00 18    	je     0x732b29e02e8c
    732b11e02159:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10092
    732b11e02160:	92 00 01 00 
    732b11e02164:	0f 84 22 0d 00 18    	je     0x732b29e02e8c
    732b11e0216a:	58                   	pop    rax
    732b11e0216b:	50                   	push   rax
    732b11e0216c:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e02173:	00 
    732b11e02174:	74 28                	je     0x732b11e0219e
    732b11e02176:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    732b11e0217d:	94 00 01 00 
    732b11e02181:	0f 84 65 0d 00 18    	je     0x732b29e02eec
    732b11e02187:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    732b11e0218e:	94 00 01 00 
    732b11e02192:	0f 84 54 0d 00 18    	je     0x732b29e02eec
    732b11e02198:	58                   	pop    rax
    732b11e02199:	e9 55 00 00 00       	jmp    0x732b11e021f3
    732b11e0219e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e021a5:	01 
    732b11e021a6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    732b11e021ad:	94 00 01 00 
    732b11e021b1:	0f 84 7e 0d 00 18    	je     0x732b29e02f35
    732b11e021b7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    732b11e021be:	94 00 01 00 
    732b11e021c2:	0f 84 6d 0d 00 18    	je     0x732b29e02f35
    732b11e021c8:	b8 94 00 01 00       	mov    eax,0x10094
    732b11e021cd:	83 c0 2c             	add    eax,0x2c
    732b11e021d0:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e021d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e021de:	02 00 00 00 
    732b11e021e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b11e021e9:	02 00 00 00 
    732b11e021ed:	58                   	pop    rax
    732b11e021ee:	e9 15 01 00 00       	jmp    0x732b11e02308
    732b11e021f3:	50                   	push   rax
    732b11e021f4:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    732b11e021f8:	f6 c1 03             	test   cl,0x3
    732b11e021fb:	0f 85 70 0d 00 18    	jne    0x732b29e02f71
    732b11e02201:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e02208:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    732b11e0220c:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e02213:	48 89 ce             	mov    rsi,rcx
    732b11e02216:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e0221a:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e0221e:	48 85 c0             	test   rax,rax
    732b11e02221:	0f 84 9d 0d 00 18    	je     0x732b29e02fc4
    732b11e02227:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0222d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e02230:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10096
    732b11e02237:	96 00 01 00 
    732b11e0223b:	0f 84 be 0d 00 18    	je     0x732b29e02fff
    732b11e02241:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10096
    732b11e02248:	96 00 01 00 
    732b11e0224c:	0f 84 ad 0d 00 18    	je     0x732b29e02fff
    732b11e02252:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e02255:	0f 85 e5 0d 00 18    	jne    0x732b29e03040
    732b11e0225b:	58                   	pop    rax
    732b11e0225c:	e9 0f 00 00 00       	jmp    0x732b11e02270
    732b11e02261:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e02268:	00 
    732b11e02269:	74 f0                	je     0x732b11e0225b
    732b11e0226b:	e9 38 0d 00 18       	jmp    0x732b29e02fa8
    732b11e02270:	50                   	push   rax
    732b11e02271:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e02278:	b9 98 00 01 00       	mov    ecx,0x10098
    732b11e0227d:	83 c1 04             	add    ecx,0x4
    732b11e02280:	89 ca                	mov    edx,ecx
    732b11e02282:	3d 98 00 01 00       	cmp    eax,0x10098
    732b11e02287:	75 07                	jne    0x732b11e02290
    732b11e02289:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    732b11e02290:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    732b11e02297:	02 
    732b11e02298:	0f 43 ca             	cmovae ecx,edx
    732b11e0229b:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    732b11e022a2:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    732b11e022a9:	89 cf                	mov    edi,ecx
    732b11e022ab:	81 fa 98 00 01 00    	cmp    edx,0x10098
    732b11e022b1:	75 07                	jne    0x732b11e022ba
    732b11e022b3:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    732b11e022ba:	83 fe 02             	cmp    esi,0x2
    732b11e022bd:	0f 43 cf             	cmovae ecx,edi
    732b11e022c0:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    732b11e022c7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e022ce:	01 
    732b11e022cf:	3d 98 00 01 00       	cmp    eax,0x10098
    732b11e022d4:	0f 84 98 0d 00 18    	je     0x732b29e03072
    732b11e022da:	81 fa 98 00 01 00    	cmp    edx,0x10098
    732b11e022e0:	0f 84 8c 0d 00 18    	je     0x732b29e03072
    732b11e022e6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    732b11e022ed:	28 04 01 00 
    732b11e022f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b11e022f8:	04 00 00 00 
    732b11e022fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b11e02303:	04 00 00 00 
    732b11e02307:	58                   	pop    rax
    732b11e02308:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e0230f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e02316:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e0231d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e02324:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e0232b:	39 f1                	cmp    ecx,esi
    732b11e0232d:	0f 83 77 0d 00 18    	jae    0x732b29e030aa
    732b11e02333:	81 fa 92 00 01 00    	cmp    edx,0x10092
    732b11e02339:	75 14                	jne    0x732b11e0234f
    732b11e0233b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02342:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02349:	00 
    732b11e0234a:	e9 a1 fd ff ff       	jmp    0x732b11e020f0
    732b11e0234f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e02356:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e0235c:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e0235f:	0f 85 45 0d 00 18    	jne    0x732b29e030aa
    732b11e02365:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e0236c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02373:	00 
    732b11e02374:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e02379:	ff e0                	jmp    rax
