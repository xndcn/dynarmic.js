
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65772-0-126628820696016.bin:     file format binary


Disassembly of section .data:

0000732b11e03bd0 <.data>:
    732b11e03bd0:	48 83 ec 58          	sub    rsp,0x58
    732b11e03bd4:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    732b11e03bd9:	4d 89 e8             	mov    r8,r13
    732b11e03bdc:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e03be3:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    732b11e03be8:	45 8b 9d 58 01 00 00 	mov    r11d,DWORD PTR [r13+0x158]
    732b11e03bef:	b8 f3 fe fe ff       	mov    eax,0xfffefef3
    732b11e03bf4:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    732b11e03bfb:	01 c1                	add    ecx,eax
    732b11e03bfd:	83 f9 de             	cmp    ecx,0xffffffde
    732b11e03c00:	0f 87 07 15 00 18    	ja     0x732b29e0510d
    732b11e03c06:	41 03 80 a0 00 00 00 	add    eax,DWORD PTR [r8+0xa0]
    732b11e03c0d:	83 f8 de             	cmp    eax,0xffffffde
    732b11e03c10:	0f 87 f7 14 00 18    	ja     0x732b29e0510d
    732b11e03c16:	49 8b 80 38 01 00 00 	mov    rax,QWORD PTR [r8+0x138]
    732b11e03c1d:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    732b11e03c22:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    732b11e03c25:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    732b11e03c29:	41 8b 58 08          	mov    ebx,DWORD PTR [r8+0x8]
    732b11e03c2d:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    732b11e03c31:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    732b11e03c35:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    732b11e03c39:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    732b11e03c3e:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    732b11e03c45:	41 8b b0 5c 01 00 00 	mov    esi,DWORD PTR [r8+0x15c]
    732b11e03c4c:	4c 89 44 24 30       	mov    QWORD PTR [rsp+0x30],r8
    732b11e03c51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    732b11e03c58:	0f 1f 84 00 00 00 00 
    732b11e03c5f:	00 
    732b11e03c60:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    732b11e03c65:	44 89 ca             	mov    edx,r9d
    732b11e03c68:	c1 ea 1f             	shr    edx,0x1f
    732b11e03c6b:	89 df                	mov    edi,ebx
    732b11e03c6d:	ff c7                	inc    edi
    732b11e03c6f:	44 89 e9             	mov    ecx,r13d
    732b11e03c72:	41 39 fd             	cmp    r13d,edi
    732b11e03c75:	89 f8                	mov    eax,edi
    732b11e03c77:	41 0f 47 c5          	cmova  eax,r13d
    732b11e03c7b:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    732b11e03c7f:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    732b11e03c83:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    732b11e03c88:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    732b11e03c8f:	00 
    732b11e03c90:	41 89 f4             	mov    r12d,esi
    732b11e03c93:	89 f8                	mov    eax,edi
    732b11e03c95:	8d 70 ff             	lea    esi,[rax-0x1]
    732b11e03c98:	45 0f af f2          	imul   r14d,r10d
    732b11e03c9c:	43 8d 1c 0e          	lea    ebx,[r14+r9*1]
    732b11e03ca0:	41 c1 ee 1f          	shr    r14d,0x1f
    732b11e03ca4:	89 df                	mov    edi,ebx
    732b11e03ca6:	c1 ef 1f             	shr    edi,0x1f
    732b11e03ca9:	89 fd                	mov    ebp,edi
    732b11e03cab:	31 d5                	xor    ebp,edx
    732b11e03cad:	44 31 f7             	xor    edi,r14d
    732b11e03cb0:	21 ef                	and    edi,ebp
    732b11e03cb2:	41 89 de             	mov    r14d,ebx
    732b11e03cb5:	41 c1 ee 0d          	shr    r14d,0xd
    732b11e03cb9:	41 31 de             	xor    r14d,ebx
    732b11e03cbc:	44 89 f5             	mov    ebp,r14d
    732b11e03cbf:	c1 e5 07             	shl    ebp,0x7
    732b11e03cc2:	c1 ee 1f             	shr    esi,0x1f
    732b11e03cc5:	89 c1                	mov    ecx,eax
    732b11e03cc7:	c1 e9 1f             	shr    ecx,0x1f
    732b11e03cca:	c4 e2 48 f2 c9       	andn   ecx,esi,ecx
    732b11e03ccf:	41 09 cf             	or     r15d,ecx
    732b11e03cd2:	41 09 ff             	or     r15d,edi
    732b11e03cd5:	41 0f a4 de 07       	shld   r14d,ebx,0x7
    732b11e03cda:	41 39 c5             	cmp    r13d,eax
    732b11e03cdd:	76 21                	jbe    0x732b11e03d00
    732b11e03cdf:	41 8d 74 24 0a       	lea    esi,[r12+0xa]
    732b11e03ce4:	44 39 de             	cmp    esi,r11d
    732b11e03ce7:	0f 83 1c 02 00 00    	jae    0x732b11e03f09
    732b11e03ced:	41 8b 88 58 01 00 00 	mov    ecx,DWORD PTR [r8+0x158]
    732b11e03cf4:	8d 78 01             	lea    edi,[rax+0x1]
    732b11e03cf7:	85 c9                	test   ecx,ecx
    732b11e03cf9:	75 95                	jne    0x732b11e03c90
    732b11e03cfb:	e9 09 02 00 00       	jmp    0x732b11e03f09
    732b11e03d00:	0f 96 c0             	setbe  al
    732b11e03d03:	0f b6 c0             	movzx  eax,al
    732b11e03d06:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    732b11e03d0a:	31 db                	xor    ebx,ebx
    732b11e03d0c:	31 c0                	xor    eax,eax
    732b11e03d0e:	44 3b 6c 24 08       	cmp    r13d,DWORD PTR [rsp+0x8]
    732b11e03d13:	0f 93 c3             	setae  bl
    732b11e03d16:	0f 92 c0             	setb   al
    732b11e03d19:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    732b11e03d1d:	41 8b 78 3c          	mov    edi,DWORD PTR [r8+0x3c]
    732b11e03d21:	40 f6 c7 03          	test   dil,0x3
    732b11e03d25:	0f 85 10 03 00 00    	jne    0x732b11e0403b
    732b11e03d2b:	48 89 f8             	mov    rax,rdi
    732b11e03d2e:	48 c1 e8 0c          	shr    rax,0xc
    732b11e03d32:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    732b11e03d37:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    732b11e03d3b:	48 85 c0             	test   rax,rax
    732b11e03d3e:	89 5c 24 1c          	mov    DWORD PTR [rsp+0x1c],ebx
    732b11e03d42:	0f 84 a4 03 00 00    	je     0x732b11e040ec
    732b11e03d48:	89 f9                	mov    ecx,edi
    732b11e03d4a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e03d50:	8b 0c 08             	mov    ecx,DWORD PTR [rax+rcx*1]
    732b11e03d53:	8d 77 04             	lea    esi,[rdi+0x4]
    732b11e03d56:	89 f0                	mov    eax,esi
    732b11e03d58:	c1 e8 0c             	shr    eax,0xc
    732b11e03d5b:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    732b11e03d5f:	48 85 c0             	test   rax,rax
    732b11e03d62:	0f 84 61 04 00 00    	je     0x732b11e041c9
    732b11e03d68:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e03d6e:	44 8b 2c 30          	mov    r13d,DWORD PTR [rax+rsi*1]
    732b11e03d72:	8d 77 08             	lea    esi,[rdi+0x8]
    732b11e03d75:	41 89 48 3c          	mov    DWORD PTR [r8+0x3c],ecx
    732b11e03d79:	45 89 a8 a8 00 00 00 	mov    DWORD PTR [r8+0xa8],r13d
    732b11e03d80:	41 89 70 38          	mov    DWORD PTR [r8+0x38],esi
    732b11e03d84:	89 f0                	mov    eax,esi
    732b11e03d86:	c1 e8 0c             	shr    eax,0xc
    732b11e03d89:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    732b11e03d8d:	48 85 c0             	test   rax,rax
    732b11e03d90:	0f 84 16 05 00 00    	je     0x732b11e042ac
    732b11e03d96:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e03d9c:	8b 0c 30             	mov    ecx,DWORD PTR [rax+rsi*1]
    732b11e03d9f:	8d 77 0c             	lea    esi,[rdi+0xc]
    732b11e03da2:	89 f0                	mov    eax,esi
    732b11e03da4:	c1 e8 0c             	shr    eax,0xc
    732b11e03da7:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    732b11e03dab:	48 85 c0             	test   rax,rax
    732b11e03dae:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    732b11e03db3:	0f 84 c9 05 00 00    	je     0x732b11e04382
    732b11e03db9:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e03dbf:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e03dc2:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    732b11e03dc6:	83 c7 10             	add    edi,0x10
    732b11e03dc9:	41 89 78 38          	mov    DWORD PTR [r8+0x38],edi
    732b11e03dcd:	41 f6 c5 01          	test   r13b,0x1
    732b11e03dd1:	0f 85 74 06 00 00    	jne    0x732b11e0444b
    732b11e03dd7:	4d 89 e9             	mov    r9,r13
    732b11e03dda:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    732b11e03ddf:	c7 44 24 20 00 00 00 	mov    DWORD PTR [rsp+0x20],0x0
    732b11e03de6:	00 
    732b11e03de7:	bf 02 00 00 00       	mov    edi,0x2
    732b11e03dec:	b9 0e 00 00 00       	mov    ecx,0xe
    732b11e03df1:	c7 44 24 2c 00 00 00 	mov    DWORD PTR [rsp+0x2c],0x0
    732b11e03df8:	00 
    732b11e03df9:	89 d8                	mov    eax,ebx
    732b11e03dfb:	89 da                	mov    edx,ebx
    732b11e03dfd:	45 89 f5             	mov    r13d,r14d
    732b11e03e00:	42 8d 34 21          	lea    esi,[rcx+r12*1]
    732b11e03e04:	44 39 de             	cmp    esi,r11d
    732b11e03e07:	0f 83 98 01 00 00    	jae    0x732b11e03fa5
    732b11e03e0d:	48 8b 5c 24 30       	mov    rbx,QWORD PTR [rsp+0x30]
    732b11e03e12:	8b 9b 58 01 00 00    	mov    ebx,DWORD PTR [rbx+0x158]
    732b11e03e18:	85 db                	test   ebx,ebx
    732b11e03e1a:	0f 84 85 01 00 00    	je     0x732b11e03fa5
    732b11e03e20:	4d 89 ca             	mov    r10,r9
    732b11e03e23:	41 81 fa ec 00 01 00 	cmp    r10d,0x100ec
    732b11e03e2a:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e03e2f:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    732b11e03e33:	0f 84 27 fe ff ff    	je     0x732b11e03c60
    732b11e03e39:	46 8d 1c d5 00 00 00 	lea    r11d,[r10*8+0x0]
    732b11e03e40:	00 
    732b11e03e41:	41 81 e3 f0 ff 0f 00 	and    r11d,0xffff0
    732b11e03e48:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    732b11e03e4d:	46 39 14 1b          	cmp    DWORD PTR [rbx+r11*1],r10d
    732b11e03e51:	0f 85 4e 01 00 00    	jne    0x732b11e03fa5
    732b11e03e57:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    732b11e03e5c:	4e 8b 44 1b 08       	mov    r8,QWORD PTR [rbx+r11*1+0x8]
    732b11e03e61:	4c 8b 54 24 30       	mov    r10,QWORD PTR [rsp+0x30]
    732b11e03e66:	45 89 2a             	mov    DWORD PTR [r10],r13d
    732b11e03e69:	45 89 72 04          	mov    DWORD PTR [r10+0x4],r14d
    732b11e03e6d:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    732b11e03e71:	41 89 5a 08          	mov    DWORD PTR [r10+0x8],ebx
    732b11e03e75:	41 89 6a 0c          	mov    DWORD PTR [r10+0xc],ebp
    732b11e03e79:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    732b11e03e7d:	41 89 5a 18          	mov    DWORD PTR [r10+0x18],ebx
    732b11e03e81:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    732b11e03e86:	41 89 6a 1c          	mov    DWORD PTR [r10+0x1c],ebp
    732b11e03e8a:	45 89 8a bc 00 00 00 	mov    DWORD PTR [r10+0xbc],r9d
    732b11e03e91:	41 89 92 e4 00 00 00 	mov    DWORD PTR [r10+0xe4],edx
    732b11e03e98:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    732b11e03e9c:	41 89 92 e8 00 00 00 	mov    DWORD PTR [r10+0xe8],edx
    732b11e03ea3:	41 89 82 ec 00 00 00 	mov    DWORD PTR [r10+0xec],eax
    732b11e03eaa:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    732b11e03eae:	41 89 82 f0 00 00 00 	mov    DWORD PTR [r10+0xf0],eax
    732b11e03eb5:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    732b11e03eb9:	41 89 82 f8 00 00 00 	mov    DWORD PTR [r10+0xf8],eax
    732b11e03ec0:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    732b11e03ec4:	41 89 82 fc 00 00 00 	mov    DWORD PTR [r10+0xfc],eax
    732b11e03ecb:	45 89 ba 00 01 00 00 	mov    DWORD PTR [r10+0x100],r15d
    732b11e03ed2:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e03ed6:	41 89 82 14 01 00 00 	mov    DWORD PTR [r10+0x114],eax
    732b11e03edd:	41 89 ba 24 01 00 00 	mov    DWORD PTR [r10+0x124],edi
    732b11e03ee4:	41 c6 82 28 01 00 00 	mov    BYTE PTR [r10+0x128],0x0
    732b11e03eeb:	00 
    732b11e03eec:	41 89 8a 34 01 00 00 	mov    DWORD PTR [r10+0x134],ecx
    732b11e03ef3:	41 89 b2 5c 01 00 00 	mov    DWORD PTR [r10+0x15c],esi
    732b11e03efa:	4d 89 d5             	mov    r13,r10
    732b11e03efd:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    732b11e03f02:	48 83 c4 58          	add    rsp,0x58
    732b11e03f06:	41 ff e0             	jmp    r8
    732b11e03f09:	31 c9                	xor    ecx,ecx
    732b11e03f0b:	31 d2                	xor    edx,edx
    732b11e03f0d:	31 f6                	xor    esi,esi
    732b11e03f0f:	31 ff                	xor    edi,edi
    732b11e03f11:	41 39 c5             	cmp    r13d,eax
    732b11e03f14:	0f 96 c1             	setbe  cl
    732b11e03f17:	0f 94 c2             	sete   dl
    732b11e03f1a:	40 0f 92 c6          	setb   sil
    732b11e03f1e:	40 0f 93 c7          	setae  dil
    732b11e03f22:	45 89 28             	mov    DWORD PTR [r8],r13d
    732b11e03f25:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e03f29:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e03f2d:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e03f31:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e03f35:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    732b11e03f39:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x100ec
    732b11e03f40:	ec 00 01 00 
    732b11e03f44:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    732b11e03f4b:	41 89 b0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],esi
    732b11e03f52:	41 89 b8 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edi
    732b11e03f59:	41 89 b8 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edi
    732b11e03f60:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e03f67:	00 00 00 00 
    732b11e03f6b:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e03f72:	41 89 88 14 01 00 00 	mov    DWORD PTR [r8+0x114],ecx
    732b11e03f79:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    732b11e03f80:	02 00 00 00 
    732b11e03f84:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    732b11e03f8b:	01 
    732b11e03f8c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xa
    732b11e03f93:	0a 00 00 00 
    732b11e03f97:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e03f9e:	48 83 c4 58          	add    rsp,0x58
    732b11e03fa2:	c2 08 00             	ret    0x8
    732b11e03fa5:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    732b11e03faa:	44 89 2e             	mov    DWORD PTR [rsi],r13d
    732b11e03fad:	44 89 76 04          	mov    DWORD PTR [rsi+0x4],r14d
    732b11e03fb1:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    732b11e03fb5:	89 5e 08             	mov    DWORD PTR [rsi+0x8],ebx
    732b11e03fb8:	89 6e 0c             	mov    DWORD PTR [rsi+0xc],ebp
    732b11e03fbb:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    732b11e03fbf:	89 5e 18             	mov    DWORD PTR [rsi+0x18],ebx
    732b11e03fc2:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    732b11e03fc7:	89 6e 1c             	mov    DWORD PTR [rsi+0x1c],ebp
    732b11e03fca:	44 89 8e bc 00 00 00 	mov    DWORD PTR [rsi+0xbc],r9d
    732b11e03fd1:	89 96 e4 00 00 00    	mov    DWORD PTR [rsi+0xe4],edx
    732b11e03fd7:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    732b11e03fdb:	89 96 e8 00 00 00    	mov    DWORD PTR [rsi+0xe8],edx
    732b11e03fe1:	89 86 ec 00 00 00    	mov    DWORD PTR [rsi+0xec],eax
    732b11e03fe7:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    732b11e03feb:	89 86 f0 00 00 00    	mov    DWORD PTR [rsi+0xf0],eax
    732b11e03ff1:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    732b11e03ff5:	89 86 f8 00 00 00    	mov    DWORD PTR [rsi+0xf8],eax
    732b11e03ffb:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    732b11e03fff:	89 86 fc 00 00 00    	mov    DWORD PTR [rsi+0xfc],eax
    732b11e04005:	44 89 be 00 01 00 00 	mov    DWORD PTR [rsi+0x100],r15d
    732b11e0400c:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e04010:	89 86 14 01 00 00    	mov    DWORD PTR [rsi+0x114],eax
    732b11e04016:	89 be 24 01 00 00    	mov    DWORD PTR [rsi+0x124],edi
    732b11e0401c:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    732b11e04021:	88 86 28 01 00 00    	mov    BYTE PTR [rsi+0x128],al
    732b11e04027:	89 8e 34 01 00 00    	mov    DWORD PTR [rsi+0x134],ecx
    732b11e0402d:	44 89 a6 5c 01 00 00 	mov    DWORD PTR [rsi+0x15c],r12d
    732b11e04034:	48 83 c4 58          	add    rsp,0x58
    732b11e04038:	c2 08 00             	ret    0x8
    732b11e0403b:	89 d9                	mov    ecx,ebx
    732b11e0403d:	44 89 db             	mov    ebx,r11d
    732b11e04040:	45 89 28             	mov    DWORD PTR [r8],r13d
    732b11e04043:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e04047:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e0404b:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e0404f:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e04053:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e04057:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    732b11e0405b:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    732b11e04062:	04 01 01 00 
    732b11e04066:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    732b11e0406d:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e04071:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e04078:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    732b11e0407f:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    732b11e04086:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e0408d:	00 00 00 00 
    732b11e04091:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e04098:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e0409c:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e040a3:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    732b11e040aa:	04 00 00 00 
    732b11e040ae:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e040b5:	00 
    732b11e040b6:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    732b11e040bd:	0b 00 00 00 
    732b11e040c1:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e040c8:	48 b8 e0 38 df 00 a0 	movabs rax,0x5aa000df38e0
    732b11e040cf:	5a 00 00 
    732b11e040d2:	48 89 f9             	mov    rcx,rdi
    732b11e040d5:	4c 89 c7             	mov    rdi,r8
    732b11e040d8:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    732b11e040dd:	ba 04 01 01 00       	mov    edx,0x10104
    732b11e040e2:	45 31 c0             	xor    r8d,r8d
    732b11e040e5:	ff d0                	call   rax
    732b11e040e7:	e9 0e 04 00 00       	jmp    0x732b11e044fa
    732b11e040ec:	89 d9                	mov    ecx,ebx
    732b11e040ee:	44 89 db             	mov    ebx,r11d
    732b11e040f1:	45 89 28             	mov    DWORD PTR [r8],r13d
    732b11e040f4:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e040f8:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e040fc:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e04100:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e04104:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e04108:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    732b11e0410c:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    732b11e04113:	04 01 01 00 
    732b11e04117:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    732b11e0411e:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e04122:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e04129:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    732b11e04130:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    732b11e04137:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e0413e:	00 00 00 00 
    732b11e04142:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e04149:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e0414d:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e04154:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    732b11e0415b:	04 00 00 00 
    732b11e0415f:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e04166:	00 
    732b11e04167:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    732b11e0416e:	0b 00 00 00 
    732b11e04172:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e04179:	48 b8 f0 d5 cd 00 a0 	movabs rax,0x5aa000cdd5f0
    732b11e04180:	5a 00 00 
    732b11e04183:	48 89 fe             	mov    rsi,rdi
    732b11e04186:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    732b11e0418b:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    732b11e04190:	ff d0                	call   rax
    732b11e04192:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e04197:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    732b11e0419e:	00 
    732b11e0419f:	84 c9                	test   cl,cl
    732b11e041a1:	0f 85 60 03 00 00    	jne    0x732b11e04507
    732b11e041a7:	41 89 db             	mov    r11d,ebx
    732b11e041aa:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    732b11e041af:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    732b11e041b4:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    732b11e041b9:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    732b11e041bd:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    732b11e041c2:	89 c1                	mov    ecx,eax
    732b11e041c4:	e9 8a fb ff ff       	jmp    0x732b11e03d53
    732b11e041c9:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    732b11e041cd:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    732b11e041d2:	89 d9                	mov    ecx,ebx
    732b11e041d4:	44 89 db             	mov    ebx,r11d
    732b11e041d7:	45 89 28             	mov    DWORD PTR [r8],r13d
    732b11e041da:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e041de:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e041e2:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e041e6:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e041ea:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e041ee:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    732b11e041f2:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    732b11e041f9:	04 01 01 00 
    732b11e041fd:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    732b11e04204:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e04208:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e0420f:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    732b11e04216:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    732b11e0421d:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e04224:	00 00 00 00 
    732b11e04228:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e0422f:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e04233:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e0423a:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    732b11e04241:	04 00 00 00 
    732b11e04245:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e0424c:	00 
    732b11e0424d:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    732b11e04254:	0b 00 00 00 
    732b11e04258:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e0425f:	48 b8 f0 d5 cd 00 a0 	movabs rax,0x5aa000cdd5f0
    732b11e04266:	5a 00 00 
    732b11e04269:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    732b11e0426e:	ff d0                	call   rax
    732b11e04270:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e04275:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    732b11e0427c:	00 
    732b11e0427d:	84 c9                	test   cl,cl
    732b11e0427f:	0f 85 82 02 00 00    	jne    0x732b11e04507
    732b11e04285:	41 89 c5             	mov    r13d,eax
    732b11e04288:	41 89 db             	mov    r11d,ebx
    732b11e0428b:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    732b11e04290:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    732b11e04295:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    732b11e0429a:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    732b11e0429e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    732b11e042a3:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    732b11e042a7:	e9 c6 fa ff ff       	jmp    0x732b11e03d72
    732b11e042ac:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    732b11e042b1:	89 d9                	mov    ecx,ebx
    732b11e042b3:	44 89 db             	mov    ebx,r11d
    732b11e042b6:	45 89 30             	mov    DWORD PTR [r8],r14d
    732b11e042b9:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e042bd:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e042c1:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e042c5:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e042c9:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e042cd:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    732b11e042d1:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    732b11e042d8:	0a 01 01 00 
    732b11e042dc:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    732b11e042e3:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e042e7:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e042ee:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    732b11e042f5:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    732b11e042fc:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e04303:	00 00 00 00 
    732b11e04307:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e0430e:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e04312:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e04319:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    732b11e04320:	02 00 00 00 
    732b11e04324:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e0432b:	00 
    732b11e0432c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    732b11e04333:	0d 00 00 00 
    732b11e04337:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e0433e:	48 b8 f0 d5 cd 00 a0 	movabs rax,0x5aa000cdd5f0
    732b11e04345:	5a 00 00 
    732b11e04348:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    732b11e0434d:	ff d0                	call   rax
    732b11e0434f:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e04354:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    732b11e0435b:	00 
    732b11e0435c:	84 c9                	test   cl,cl
    732b11e0435e:	0f 85 a3 01 00 00    	jne    0x732b11e04507
    732b11e04364:	41 89 db             	mov    r11d,ebx
    732b11e04367:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    732b11e0436c:	48 89 c1             	mov    rcx,rax
    732b11e0436f:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    732b11e04374:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    732b11e04378:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    732b11e0437d:	e9 1d fa ff ff       	jmp    0x732b11e03d9f
    732b11e04382:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    732b11e04387:	89 da                	mov    edx,ebx
    732b11e04389:	44 89 db             	mov    ebx,r11d
    732b11e0438c:	45 89 30             	mov    DWORD PTR [r8],r14d
    732b11e0438f:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e04393:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e04397:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e0439b:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e0439f:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    732b11e043a3:	41 89 48 1c          	mov    DWORD PTR [r8+0x1c],ecx
    732b11e043a7:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    732b11e043ae:	0a 01 01 00 
    732b11e043b2:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    732b11e043b9:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e043bd:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e043c4:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    732b11e043cb:	41 89 90 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edx
    732b11e043d2:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e043d9:	00 00 00 00 
    732b11e043dd:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e043e4:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e043e8:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e043ef:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    732b11e043f6:	02 00 00 00 
    732b11e043fa:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e04401:	00 
    732b11e04402:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    732b11e04409:	0d 00 00 00 
    732b11e0440d:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e04414:	48 b8 f0 d5 cd 00 a0 	movabs rax,0x5aa000cdd5f0
    732b11e0441b:	5a 00 00 
    732b11e0441e:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    732b11e04423:	ff d0                	call   rax
    732b11e04425:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e0442a:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    732b11e04431:	00 
    732b11e04432:	84 c9                	test   cl,cl
    732b11e04434:	0f 85 cd 00 00 00    	jne    0x732b11e04507
    732b11e0443a:	41 89 db             	mov    r11d,ebx
    732b11e0443d:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    732b11e04441:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    732b11e04446:	e9 77 f9 ff ff       	jmp    0x732b11e03dc2
    732b11e0444b:	89 d9                	mov    ecx,ebx
    732b11e0444d:	44 89 db             	mov    ebx,r11d
    732b11e04450:	45 89 30             	mov    DWORD PTR [r8],r14d
    732b11e04453:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    732b11e04457:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    732b11e0445b:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    732b11e0445f:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    732b11e04463:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    732b11e04467:	41 89 40 18          	mov    DWORD PTR [r8+0x18],eax
    732b11e0446b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    732b11e04470:	41 89 40 1c          	mov    DWORD PTR [r8+0x1c],eax
    732b11e04474:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010c
    732b11e0447b:	0c 01 01 00 
    732b11e0447f:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    732b11e04486:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    732b11e0448a:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    732b11e04491:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    732b11e04498:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    732b11e0449f:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    732b11e044a6:	00 00 00 00 
    732b11e044aa:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    732b11e044b1:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    732b11e044b5:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    732b11e044bc:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    732b11e044c3:	02 00 00 00 
    732b11e044c7:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b11e044ce:	00 
    732b11e044cf:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xe
    732b11e044d6:	0e 00 00 00 
    732b11e044da:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    732b11e044e1:	48 b8 e0 2a df 00 a0 	movabs rax,0x5aa000df2ae0
    732b11e044e8:	5a 00 00 
    732b11e044eb:	4c 89 c7             	mov    rdi,r8
    732b11e044ee:	be 2a 00 00 00       	mov    esi,0x2a
    732b11e044f3:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    732b11e044f8:	ff d0                	call   rax
    732b11e044fa:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    732b11e044ff:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    732b11e04506:	00 
    732b11e04507:	88 4c 24 0f          	mov    BYTE PTR [rsp+0xf],cl
    732b11e0450b:	45 8b 88 bc 00 00 00 	mov    r9d,DWORD PTR [r8+0xbc]
    732b11e04512:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    732b11e04515:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    732b11e04519:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    732b11e0451d:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    732b11e04521:	41 8b 68 0c          	mov    ebp,DWORD PTR [r8+0xc]
    732b11e04525:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    732b11e04529:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    732b11e0452d:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    732b11e04531:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    732b11e04536:	41 8b 90 e4 00 00 00 	mov    edx,DWORD PTR [r8+0xe4]
    732b11e0453d:	41 8b 80 e8 00 00 00 	mov    eax,DWORD PTR [r8+0xe8]
    732b11e04544:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    732b11e04548:	41 8b 80 ec 00 00 00 	mov    eax,DWORD PTR [r8+0xec]
    732b11e0454f:	41 8b 88 f0 00 00 00 	mov    ecx,DWORD PTR [r8+0xf0]
    732b11e04556:	89 4c 24 1c          	mov    DWORD PTR [rsp+0x1c],ecx
    732b11e0455a:	41 8b 88 f8 00 00 00 	mov    ecx,DWORD PTR [r8+0xf8]
    732b11e04561:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    732b11e04565:	41 8b 88 fc 00 00 00 	mov    ecx,DWORD PTR [r8+0xfc]
    732b11e0456c:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    732b11e04570:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    732b11e04577:	41 8b 88 14 01 00 00 	mov    ecx,DWORD PTR [r8+0x114]
    732b11e0457e:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    732b11e04582:	41 8b b8 24 01 00 00 	mov    edi,DWORD PTR [r8+0x124]
    732b11e04589:	41 8b 88 34 01 00 00 	mov    ecx,DWORD PTR [r8+0x134]
    732b11e04590:	45 8b a0 5c 01 00 00 	mov    r12d,DWORD PTR [r8+0x15c]
    732b11e04597:	41 89 db             	mov    r11d,ebx
    732b11e0459a:	e9 61 f8 ff ff       	jmp    0x732b11e03e00
