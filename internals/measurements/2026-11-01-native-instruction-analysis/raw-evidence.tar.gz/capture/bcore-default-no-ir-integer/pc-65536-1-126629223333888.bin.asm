
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65536-1-126629223333888.bin:     file format binary


Disassembly of section .data:

0000732b29e00000 <.data>:
    732b29e00000:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e00006:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e00009:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e0000f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e00016:	0f 87 15 03 00 e8    	ja     0x732b11e00331
    732b29e0001c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x0
    732b29e00023:	00 00 00 00 
    732b29e00027:	e9 05 03 00 e8       	jmp    0x732b11e00331
    732b29e0002c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10000
    732b29e00033:	00 00 01 00 
    732b29e00037:	b8 00 00 01 00       	mov    eax,0x10000
    732b29e0003c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00043:	02 00 00 00 
    732b29e00047:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0004e:	01 00 00 00 
    732b29e00052:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00055:	be 00 00 01 00       	mov    esi,0x10000
    732b29e0005a:	4c 89 ef             	mov    rdi,r13
    732b29e0005d:	e8 fe 00 00 e8       	call   0x732b11e00160
    732b29e00062:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00069:	00 
    732b29e0006a:	0f 84 e9 02 00 e8    	je     0x732b11e00359
    732b29e00070:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00077:	02 00 00 00 
    732b29e0007b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00082:	01 00 00 00 
    732b29e00086:	58                   	pop    rax
    732b29e00087:	e9 66 03 00 e8       	jmp    0x732b11e003f2
    732b29e0008c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00093:	14 00 01 00 
    732b29e00097:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0009e:	04 00 00 00 
    732b29e000a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e000a9:	02 00 00 00 
    732b29e000ad:	be 02 00 01 00       	mov    esi,0x10002
    732b29e000b2:	ba 02 00 01 00       	mov    edx,0x10002
    732b29e000b7:	4c 89 ef             	mov    rdi,r13
    732b29e000ba:	e8 a1 00 00 e8       	call   0x732b11e00160
    732b29e000bf:	e9 0c 03 00 e8       	jmp    0x732b11e003d0
    732b29e000c4:	c2 08 00             	ret    0x8
