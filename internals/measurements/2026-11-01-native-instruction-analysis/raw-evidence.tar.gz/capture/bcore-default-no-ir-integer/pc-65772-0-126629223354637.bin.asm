
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65772-0-126629223354637.bin:     file format binary


Disassembly of section .data:

0000732b29e0510d <.data>:
    732b29e0510d:	41 c6 80 65 01 00 00 	mov    BYTE PTR [r8+0x165],0x1
    732b29e05114:	01 
    732b29e05115:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    732b29e0511c:	00 
    732b29e0511d:	48 83 c4 58          	add    rsp,0x58
    732b29e05121:	c2 08 00             	ret    0x8
