
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66344-1-126628820686016.bin:     file format binary


Disassembly of section .data:

0000732b11e014c0 <.data>:
    732b11e014c0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e014c7:	8b 88 0c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10000c]
    732b11e014cd:	ff c1                	inc    ecx
    732b11e014cf:	89 88 0c 00 10 00    	mov    DWORD PTR [rax+0x10000c],ecx
    732b11e014d5:	81 f9 c1 c5 00 00    	cmp    ecx,0xc5c1
    732b11e014db:	0f 84 ff 07 00 18    	je     0x732b29e01ce0
    732b11e014e1:	50                   	push   rax
    732b11e014e2:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e014e6:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e014e9:	f6 c3 03             	test   bl,0x3
    732b11e014ec:	0f 85 1a 08 00 18    	jne    0x732b29e01d0c
    732b11e014f2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e014f9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e01500:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    732b11e01504:	89 c8                	mov    eax,ecx
    732b11e01506:	c1 e8 0c             	shr    eax,0xc
    732b11e01509:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e0150e:	48 85 c0             	test   rax,rax
    732b11e01511:	0f 84 48 08 00 18    	je     0x732b29e01d5f
    732b11e01517:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0151d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01520:	8d 73 f8             	lea    esi,[rbx-0x8]
    732b11e01523:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    732b11e01527:	89 f0                	mov    eax,esi
    732b11e01529:	c1 e8 0c             	shr    eax,0xc
    732b11e0152c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01531:	48 85 c0             	test   rax,rax
    732b11e01534:	0f 84 60 08 00 18    	je     0x732b29e01d9a
    732b11e0153a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01540:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e01543:	8d 73 f4             	lea    esi,[rbx-0xc]
    732b11e01546:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    732b11e0154a:	89 f0                	mov    eax,esi
    732b11e0154c:	c1 e8 0c             	shr    eax,0xc
    732b11e0154f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01554:	48 85 c0             	test   rax,rax
    732b11e01557:	0f 84 79 08 00 18    	je     0x732b29e01dd6
    732b11e0155d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01563:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e01566:	8d 73 f0             	lea    esi,[rbx-0x10]
    732b11e01569:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    732b11e0156d:	89 f0                	mov    eax,esi
    732b11e0156f:	c1 e8 0c             	shr    eax,0xc
    732b11e01572:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01577:	48 85 c0             	test   rax,rax
    732b11e0157a:	0f 84 92 08 00 18    	je     0x732b29e01e12
    732b11e01580:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01586:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e01589:	83 c3 ec             	add    ebx,0xffffffec
    732b11e0158c:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    732b11e01590:	89 d8                	mov    eax,ebx
    732b11e01592:	c1 e8 0c             	shr    eax,0xc
    732b11e01595:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e0159a:	48 85 c0             	test   rax,rax
    732b11e0159d:	0f 84 ab 08 00 18    	je     0x732b29e01e4e
    732b11e015a3:	89 d9                	mov    ecx,ebx
    732b11e015a5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e015ab:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e015ae:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e015b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10328
    732b11e015b9:	28 03 01 00 
    732b11e015bd:	0f 84 c9 08 00 18    	je     0x732b29e01e8c
    732b11e015c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10328
    732b11e015ca:	28 03 01 00 
    732b11e015ce:	0f 84 b8 08 00 18    	je     0x732b29e01e8c
    732b11e015d4:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e015d8:	0f 85 f0 08 00 18    	jne    0x732b29e01ece
    732b11e015de:	58                   	pop    rax
    732b11e015df:	e9 0f 00 00 00       	jmp    0x732b11e015f3
    732b11e015e4:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e015eb:	00 
    732b11e015ec:	74 f0                	je     0x732b11e015de
    732b11e015ee:	e9 50 07 00 18       	jmp    0x732b29e01d43
    732b11e015f3:	50                   	push   rax
    732b11e015f4:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e015f8:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e015fb:	f6 c3 03             	test   bl,0x3
    732b11e015fe:	0f 85 fc 08 00 18    	jne    0x732b29e01f00
    732b11e01604:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e0160b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e01612:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    732b11e01616:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    732b11e0161d:	89 c8                	mov    eax,ecx
    732b11e0161f:	c1 e8 0c             	shr    eax,0xc
    732b11e01622:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01627:	48 85 c0             	test   rax,rax
    732b11e0162a:	0f 84 23 09 00 18    	je     0x732b29e01f53
    732b11e01630:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01636:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01639:	83 c3 f8             	add    ebx,0xfffffff8
    732b11e0163c:	89 d8                	mov    eax,ebx
    732b11e0163e:	c1 e8 0c             	shr    eax,0xc
    732b11e01641:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01646:	48 85 c0             	test   rax,rax
    732b11e01649:	0f 84 3f 09 00 18    	je     0x732b29e01f8e
    732b11e0164f:	89 d9                	mov    ecx,ebx
    732b11e01651:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01657:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    732b11e0165b:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    732b11e0165f:	b8 00 00 00 00       	mov    eax,0x0
    732b11e01664:	29 c3                	sub    ebx,eax
    732b11e01666:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e0166a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1032a
    732b11e01671:	2a 03 01 00 
    732b11e01675:	0f 84 54 09 00 18    	je     0x732b29e01fcf
    732b11e0167b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032a
    732b11e01682:	2a 03 01 00 
    732b11e01686:	0f 84 43 09 00 18    	je     0x732b29e01fcf
    732b11e0168c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e01690:	0f 85 7b 09 00 18    	jne    0x732b29e02011
    732b11e01696:	58                   	pop    rax
    732b11e01697:	e9 0f 00 00 00       	jmp    0x732b11e016ab
    732b11e0169c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e016a3:	00 
    732b11e016a4:	74 f0                	je     0x732b11e01696
    732b11e016a6:	e9 8c 08 00 18       	jmp    0x732b29e01f37
    732b11e016ab:	50                   	push   rax
    732b11e016ac:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e016b0:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e016b7:	31 d2                	xor    edx,edx
    732b11e016b9:	83 f8 05             	cmp    eax,0x5
    732b11e016bc:	0f 92 c2             	setb   dl
    732b11e016bf:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e016c6:	31 d2                	xor    edx,edx
    732b11e016c8:	31 f6                	xor    esi,esi
    732b11e016ca:	31 ff                	xor    edi,edi
    732b11e016cc:	83 f8 04             	cmp    eax,0x4
    732b11e016cf:	0f 94 c2             	sete   dl
    732b11e016d2:	40 0f 92 c6          	setb   sil
    732b11e016d6:	40 0f 93 c7          	setae  dil
    732b11e016da:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e016e1:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    732b11e016e8:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    732b11e016ef:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    732b11e016f6:	81 f9 2e 03 01 00    	cmp    ecx,0x1032e
    732b11e016fc:	0f 84 41 09 00 18    	je     0x732b29e02043
    732b11e01702:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032e
    732b11e01709:	2e 03 01 00 
    732b11e0170d:	0f 84 30 09 00 18    	je     0x732b29e02043
    732b11e01713:	58                   	pop    rax
    732b11e01714:	50                   	push   rax
    732b11e01715:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e0171c:	00 
    732b11e0171d:	74 28                	je     0x732b11e01747
    732b11e0171f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    732b11e01726:	30 03 01 00 
    732b11e0172a:	0f 84 73 09 00 18    	je     0x732b29e020a3
    732b11e01730:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    732b11e01737:	30 03 01 00 
    732b11e0173b:	0f 84 62 09 00 18    	je     0x732b29e020a3
    732b11e01741:	58                   	pop    rax
    732b11e01742:	e9 55 00 00 00       	jmp    0x732b11e0179c
    732b11e01747:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e0174e:	01 
    732b11e0174f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    732b11e01756:	30 03 01 00 
    732b11e0175a:	0f 84 8c 09 00 18    	je     0x732b29e020ec
    732b11e01760:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    732b11e01767:	30 03 01 00 
    732b11e0176b:	0f 84 7b 09 00 18    	je     0x732b29e020ec
    732b11e01771:	b8 30 03 01 00       	mov    eax,0x10330
    732b11e01776:	83 c0 40             	add    eax,0x40
    732b11e01779:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e01780:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e01787:	02 00 00 00 
    732b11e0178b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b11e01792:	04 00 00 00 
    732b11e01796:	58                   	pop    rax
    732b11e01797:	e9 d3 08 00 00       	jmp    0x732b11e0206f
    732b11e0179c:	50                   	push   rax
    732b11e0179d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e017a1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e017a8:	31 d2                	xor    edx,edx
    732b11e017aa:	85 c0                	test   eax,eax
    732b11e017ac:	0f 94 c2             	sete   dl
    732b11e017af:	c1 e8 1f             	shr    eax,0x1f
    732b11e017b2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e017b9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e017c0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e017c7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    732b11e017ce:	00 00 00 
    732b11e017d1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    732b11e017d8:	81 f9 32 03 01 00    	cmp    ecx,0x10332
    732b11e017de:	0f 84 44 09 00 18    	je     0x732b29e02128
    732b11e017e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10332
    732b11e017eb:	32 03 01 00 
    732b11e017ef:	0f 84 33 09 00 18    	je     0x732b29e02128
    732b11e017f5:	58                   	pop    rax
    732b11e017f6:	50                   	push   rax
    732b11e017f7:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e017fe:	00 
    732b11e017ff:	74 55                	je     0x732b11e01856
    732b11e01801:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e01808:	01 
    732b11e01809:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    732b11e01810:	34 03 01 00 
    732b11e01814:	0f 84 6e 09 00 18    	je     0x732b29e02188
    732b11e0181a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    732b11e01821:	34 03 01 00 
    732b11e01825:	0f 84 5d 09 00 18    	je     0x732b29e02188
    732b11e0182b:	b8 34 03 01 00       	mov    eax,0x10334
    732b11e01830:	83 c0 3c             	add    eax,0x3c
    732b11e01833:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e0183a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e01841:	02 00 00 00 
    732b11e01845:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b11e0184c:	06 00 00 00 
    732b11e01850:	58                   	pop    rax
    732b11e01851:	e9 19 08 00 00       	jmp    0x732b11e0206f
    732b11e01856:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    732b11e0185d:	34 03 01 00 
    732b11e01861:	0f 84 5d 09 00 18    	je     0x732b29e021c4
    732b11e01867:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    732b11e0186e:	34 03 01 00 
    732b11e01872:	0f 84 4c 09 00 18    	je     0x732b29e021c4
    732b11e01878:	58                   	pop    rax
    732b11e01879:	50                   	push   rax
    732b11e0187a:	41 c7 45 0c 09 3d 00 	mov    DWORD PTR [r13+0xc],0x3d09
    732b11e01881:	00 
    732b11e01882:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10336
    732b11e01889:	36 03 01 00 
    732b11e0188d:	0f 84 7a 09 00 18    	je     0x732b29e0220d
    732b11e01893:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10336
    732b11e0189a:	36 03 01 00 
    732b11e0189e:	0f 84 69 09 00 18    	je     0x732b29e0220d
    732b11e018a4:	58                   	pop    rax
    732b11e018a5:	50                   	push   rax
    732b11e018a6:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    732b11e018aa:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e018b1:	31 d2                	xor    edx,edx
    732b11e018b3:	c1 e0 0b             	shl    eax,0xb
    732b11e018b6:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    732b11e018ba:	0f 94 c2             	sete   dl
    732b11e018bd:	c1 e8 1f             	shr    eax,0x1f
    732b11e018c0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e018c7:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e018ce:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e018d5:	00 00 00 00 
    732b11e018d9:	81 f9 3a 03 01 00    	cmp    ecx,0x1033a
    732b11e018df:	0f 84 88 09 00 18    	je     0x732b29e0226d
    732b11e018e5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033a
    732b11e018ec:	3a 03 01 00 
    732b11e018f0:	0f 84 77 09 00 18    	je     0x732b29e0226d
    732b11e018f6:	58                   	pop    rax
    732b11e018f7:	50                   	push   rax
    732b11e018f8:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e018fc:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    732b11e01900:	31 d2                	xor    edx,edx
    732b11e01902:	31 f6                	xor    esi,esi
    732b11e01904:	31 ff                	xor    edi,edi
    732b11e01906:	31 db                	xor    ebx,ebx
    732b11e01908:	39 c8                	cmp    eax,ecx
    732b11e0190a:	0f 96 c2             	setbe  dl
    732b11e0190d:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e01914:	40 0f 94 c6          	sete   sil
    732b11e01918:	40 0f 92 c7          	setb   dil
    732b11e0191c:	0f 93 c3             	setae  bl
    732b11e0191f:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    732b11e01926:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e0192d:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    732b11e01934:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    732b11e0193b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033c
    732b11e01942:	3c 03 01 00 
    732b11e01946:	0f 84 81 09 00 18    	je     0x732b29e022cd
    732b11e0194c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033c
    732b11e01953:	3c 03 01 00 
    732b11e01957:	0f 84 70 09 00 18    	je     0x732b29e022cd
    732b11e0195d:	58                   	pop    rax
    732b11e0195e:	50                   	push   rax
    732b11e0195f:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e01966:	00 
    732b11e01967:	74 28                	je     0x732b11e01991
    732b11e01969:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    732b11e01970:	3e 03 01 00 
    732b11e01974:	0f 84 b3 09 00 18    	je     0x732b29e0232d
    732b11e0197a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    732b11e01981:	3e 03 01 00 
    732b11e01985:	0f 84 a2 09 00 18    	je     0x732b29e0232d
    732b11e0198b:	58                   	pop    rax
    732b11e0198c:	e9 55 00 00 00       	jmp    0x732b11e019e6
    732b11e01991:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e01998:	01 
    732b11e01999:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    732b11e019a0:	3e 03 01 00 
    732b11e019a4:	0f 84 cc 09 00 18    	je     0x732b29e02376
    732b11e019aa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    732b11e019b1:	3e 03 01 00 
    732b11e019b5:	0f 84 bb 09 00 18    	je     0x732b29e02376
    732b11e019bb:	b8 3e 03 01 00       	mov    eax,0x1033e
    732b11e019c0:	83 c0 32             	add    eax,0x32
    732b11e019c3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e019ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e019d1:	02 00 00 00 
    732b11e019d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b11e019dc:	0a 00 00 00 
    732b11e019e0:	58                   	pop    rax
    732b11e019e1:	e9 89 06 00 00       	jmp    0x732b11e0206f
    732b11e019e6:	50                   	push   rax
    732b11e019e7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e019ec:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e019f1:	09 c1                	or     ecx,eax
    732b11e019f3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e019f7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10340
    732b11e019fe:	40 03 01 00 
    732b11e01a02:	0f 84 aa 09 00 18    	je     0x732b29e023b2
    732b11e01a08:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10340
    732b11e01a0f:	40 03 01 00 
    732b11e01a13:	0f 84 99 09 00 18    	je     0x732b29e023b2
    732b11e01a19:	58                   	pop    rax
    732b11e01a1a:	50                   	push   rax
    732b11e01a1b:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e01a20:	c1 e0 10             	shl    eax,0x10
    732b11e01a23:	b9 f0 12 00 00       	mov    ecx,0x12f0
    732b11e01a28:	09 c1                	or     ecx,eax
    732b11e01a2a:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e01a2e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10344
    732b11e01a35:	44 03 01 00 
    732b11e01a39:	0f 84 d3 09 00 18    	je     0x732b29e02412
    732b11e01a3f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10344
    732b11e01a46:	44 03 01 00 
    732b11e01a4a:	0f 84 c2 09 00 18    	je     0x732b29e02412
    732b11e01a50:	58                   	pop    rax
    732b11e01a51:	50                   	push   rax
    732b11e01a52:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e01a56:	f6 c1 03             	test   cl,0x3
    732b11e01a59:	0f 85 13 0a 00 18    	jne    0x732b29e02472
    732b11e01a5f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e01a66:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e01a6a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01a71:	48 89 ce             	mov    rsi,rcx
    732b11e01a74:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e01a78:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e01a7c:	48 85 c0             	test   rax,rax
    732b11e01a7f:	0f 84 40 0a 00 18    	je     0x732b29e024c5
    732b11e01a85:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01a8b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01a8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10348
    732b11e01a95:	48 03 01 00 
    732b11e01a99:	0f 84 61 0a 00 18    	je     0x732b29e02500
    732b11e01a9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10348
    732b11e01aa6:	48 03 01 00 
    732b11e01aaa:	0f 84 50 0a 00 18    	je     0x732b29e02500
    732b11e01ab0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e01ab3:	0f 85 88 0a 00 18    	jne    0x732b29e02541
    732b11e01ab9:	58                   	pop    rax
    732b11e01aba:	e9 0f 00 00 00       	jmp    0x732b11e01ace
    732b11e01abf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e01ac6:	00 
    732b11e01ac7:	74 f0                	je     0x732b11e01ab9
    732b11e01ac9:	e9 db 09 00 18       	jmp    0x732b29e024a9
    732b11e01ace:	50                   	push   rax
    732b11e01acf:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e01ad4:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e01ad9:	09 c1                	or     ecx,eax
    732b11e01adb:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e01adf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034a
    732b11e01ae6:	4a 03 01 00 
    732b11e01aea:	0f 84 83 0a 00 18    	je     0x732b29e02573
    732b11e01af0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034a
    732b11e01af7:	4a 03 01 00 
    732b11e01afb:	0f 84 72 0a 00 18    	je     0x732b29e02573
    732b11e01b01:	58                   	pop    rax
    732b11e01b02:	50                   	push   rax
    732b11e01b03:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e01b08:	c1 e0 10             	shl    eax,0x10
    732b11e01b0b:	b9 f4 12 00 00       	mov    ecx,0x12f4
    732b11e01b10:	09 c1                	or     ecx,eax
    732b11e01b12:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e01b16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034e
    732b11e01b1d:	4e 03 01 00 
    732b11e01b21:	0f 84 ac 0a 00 18    	je     0x732b29e025d3
    732b11e01b27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034e
    732b11e01b2e:	4e 03 01 00 
    732b11e01b32:	0f 84 9b 0a 00 18    	je     0x732b29e025d3
    732b11e01b38:	58                   	pop    rax
    732b11e01b39:	50                   	push   rax
    732b11e01b3a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e01b3e:	f6 c1 03             	test   cl,0x3
    732b11e01b41:	0f 85 ec 0a 00 18    	jne    0x732b29e02633
    732b11e01b47:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e01b4e:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    732b11e01b52:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01b59:	48 89 ce             	mov    rsi,rcx
    732b11e01b5c:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e01b60:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e01b64:	48 85 c0             	test   rax,rax
    732b11e01b67:	0f 84 19 0b 00 18    	je     0x732b29e02686
    732b11e01b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01b73:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01b76:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10352
    732b11e01b7d:	52 03 01 00 
    732b11e01b81:	0f 84 3a 0b 00 18    	je     0x732b29e026c1
    732b11e01b87:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10352
    732b11e01b8e:	52 03 01 00 
    732b11e01b92:	0f 84 29 0b 00 18    	je     0x732b29e026c1
    732b11e01b98:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e01b9b:	0f 85 61 0b 00 18    	jne    0x732b29e02702
    732b11e01ba1:	58                   	pop    rax
    732b11e01ba2:	e9 0f 00 00 00       	jmp    0x732b11e01bb6
    732b11e01ba7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e01bae:	00 
    732b11e01baf:	74 f0                	je     0x732b11e01ba1
    732b11e01bb1:	e9 b4 0a 00 18       	jmp    0x732b29e0266a
    732b11e01bb6:	50                   	push   rax
    732b11e01bb7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e01bbc:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e01bc1:	09 c1                	or     ecx,eax
    732b11e01bc3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e01bc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10354
    732b11e01bce:	54 03 01 00 
    732b11e01bd2:	0f 84 5c 0b 00 18    	je     0x732b29e02734
    732b11e01bd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10354
    732b11e01bdf:	54 03 01 00 
    732b11e01be3:	0f 84 4b 0b 00 18    	je     0x732b29e02734
    732b11e01be9:	58                   	pop    rax
    732b11e01bea:	50                   	push   rax
    732b11e01beb:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e01bf0:	c1 e0 10             	shl    eax,0x10
    732b11e01bf3:	b9 f8 12 00 00       	mov    ecx,0x12f8
    732b11e01bf8:	09 c1                	or     ecx,eax
    732b11e01bfa:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e01bfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10358
    732b11e01c05:	58 03 01 00 
    732b11e01c09:	0f 84 85 0b 00 18    	je     0x732b29e02794
    732b11e01c0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10358
    732b11e01c16:	58 03 01 00 
    732b11e01c1a:	0f 84 74 0b 00 18    	je     0x732b29e02794
    732b11e01c20:	58                   	pop    rax
    732b11e01c21:	50                   	push   rax
    732b11e01c22:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e01c26:	f6 c1 03             	test   cl,0x3
    732b11e01c29:	0f 85 c5 0b 00 18    	jne    0x732b29e027f4
    732b11e01c2f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e01c36:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    732b11e01c3a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01c41:	48 89 ce             	mov    rsi,rcx
    732b11e01c44:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e01c48:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e01c4c:	48 85 c0             	test   rax,rax
    732b11e01c4f:	0f 84 f2 0b 00 18    	je     0x732b29e02847
    732b11e01c55:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01c5b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01c5e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1035c
    732b11e01c65:	5c 03 01 00 
    732b11e01c69:	0f 84 13 0c 00 18    	je     0x732b29e02882
    732b11e01c6f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035c
    732b11e01c76:	5c 03 01 00 
    732b11e01c7a:	0f 84 02 0c 00 18    	je     0x732b29e02882
    732b11e01c80:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e01c83:	0f 85 3a 0c 00 18    	jne    0x732b29e028c3
    732b11e01c89:	58                   	pop    rax
    732b11e01c8a:	e9 0f 00 00 00       	jmp    0x732b11e01c9e
    732b11e01c8f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e01c96:	00 
    732b11e01c97:	74 f0                	je     0x732b11e01c89
    732b11e01c99:	e9 8d 0b 00 18       	jmp    0x732b29e0282b
    732b11e01c9e:	50                   	push   rax
    732b11e01c9f:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e01ca3:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e01caa:	31 d2                	xor    edx,edx
    732b11e01cac:	89 c6                	mov    esi,eax
    732b11e01cae:	83 c6 fe             	add    esi,0xfffffffe
    732b11e01cb1:	0f 94 c2             	sete   dl
    732b11e01cb4:	09 c6                	or     esi,eax
    732b11e01cb6:	c1 ee 1f             	shr    esi,0x1f
    732b11e01cb9:	31 ff                	xor    edi,edi
    732b11e01cbb:	83 f8 02             	cmp    eax,0x2
    732b11e01cbe:	40 0f 93 c7          	setae  dil
    732b11e01cc2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e01cc9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e01cd0:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    732b11e01cd7:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    732b11e01cde:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    732b11e01ce5:	81 f9 5e 03 01 00    	cmp    ecx,0x1035e
    732b11e01ceb:	0f 84 04 0c 00 18    	je     0x732b29e028f5
    732b11e01cf1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035e
    732b11e01cf8:	5e 03 01 00 
    732b11e01cfc:	0f 84 f3 0b 00 18    	je     0x732b29e028f5
    732b11e01d02:	58                   	pop    rax
    732b11e01d03:	50                   	push   rax
    732b11e01d04:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e01d0b:	00 
    732b11e01d0c:	74 55                	je     0x732b11e01d63
    732b11e01d0e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e01d15:	01 
    732b11e01d16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    732b11e01d1d:	60 03 01 00 
    732b11e01d21:	0f 84 2e 0c 00 18    	je     0x732b29e02955
    732b11e01d27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    732b11e01d2e:	60 03 01 00 
    732b11e01d32:	0f 84 1d 0c 00 18    	je     0x732b29e02955
    732b11e01d38:	b8 60 03 01 00       	mov    eax,0x10360
    732b11e01d3d:	83 c0 1a             	add    eax,0x1a
    732b11e01d40:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e01d47:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e01d4e:	02 00 00 00 
    732b11e01d52:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b11e01d59:	15 00 00 00 
    732b11e01d5d:	58                   	pop    rax
    732b11e01d5e:	e9 0c 03 00 00       	jmp    0x732b11e0206f
    732b11e01d63:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    732b11e01d6a:	60 03 01 00 
    732b11e01d6e:	0f 84 1d 0c 00 18    	je     0x732b29e02991
    732b11e01d74:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    732b11e01d7b:	60 03 01 00 
    732b11e01d7f:	0f 84 0c 0c 00 18    	je     0x732b29e02991
    732b11e01d85:	58                   	pop    rax
    732b11e01d86:	50                   	push   rax
    732b11e01d87:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e01d8b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e01d92:	31 d2                	xor    edx,edx
    732b11e01d94:	89 c6                	mov    esi,eax
    732b11e01d96:	83 c6 fd             	add    esi,0xfffffffd
    732b11e01d99:	0f 94 c2             	sete   dl
    732b11e01d9c:	09 c6                	or     esi,eax
    732b11e01d9e:	c1 ee 1f             	shr    esi,0x1f
    732b11e01da1:	31 ff                	xor    edi,edi
    732b11e01da3:	83 f8 03             	cmp    eax,0x3
    732b11e01da6:	40 0f 93 c7          	setae  dil
    732b11e01daa:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e01db1:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e01db8:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    732b11e01dbf:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    732b11e01dc6:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    732b11e01dcd:	81 f9 62 03 01 00    	cmp    ecx,0x10362
    732b11e01dd3:	0f 84 01 0c 00 18    	je     0x732b29e029da
    732b11e01dd9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10362
    732b11e01de0:	62 03 01 00 
    732b11e01de4:	0f 84 f0 0b 00 18    	je     0x732b29e029da
    732b11e01dea:	58                   	pop    rax
    732b11e01deb:	50                   	push   rax
    732b11e01dec:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e01df3:	00 
    732b11e01df4:	74 55                	je     0x732b11e01e4b
    732b11e01df6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e01dfd:	01 
    732b11e01dfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    732b11e01e05:	64 03 01 00 
    732b11e01e09:	0f 84 2b 0c 00 18    	je     0x732b29e02a3a
    732b11e01e0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    732b11e01e16:	64 03 01 00 
    732b11e01e1a:	0f 84 1a 0c 00 18    	je     0x732b29e02a3a
    732b11e01e20:	b8 64 03 01 00       	mov    eax,0x10364
    732b11e01e25:	83 c0 40             	add    eax,0x40
    732b11e01e28:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e01e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e01e36:	02 00 00 00 
    732b11e01e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b11e01e41:	17 00 00 00 
    732b11e01e45:	58                   	pop    rax
    732b11e01e46:	e9 24 02 00 00       	jmp    0x732b11e0206f
    732b11e01e4b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    732b11e01e52:	64 03 01 00 
    732b11e01e56:	0f 84 1a 0c 00 18    	je     0x732b29e02a76
    732b11e01e5c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    732b11e01e63:	64 03 01 00 
    732b11e01e67:	0f 84 09 0c 00 18    	je     0x732b29e02a76
    732b11e01e6d:	58                   	pop    rax
    732b11e01e6e:	50                   	push   rax
    732b11e01e6f:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    732b11e01e76:	00 
    732b11e01e77:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10366
    732b11e01e7e:	66 03 01 00 
    732b11e01e82:	0f 84 37 0c 00 18    	je     0x732b29e02abf
    732b11e01e88:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10366
    732b11e01e8f:	66 03 01 00 
    732b11e01e93:	0f 84 26 0c 00 18    	je     0x732b29e02abf
    732b11e01e99:	58                   	pop    rax
    732b11e01e9a:	50                   	push   rax
    732b11e01e9b:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e01e9f:	f6 c3 03             	test   bl,0x3
    732b11e01ea2:	0f 85 77 0c 00 18    	jne    0x732b29e02b1f
    732b11e01ea8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e01eaf:	48 89 d8             	mov    rax,rbx
    732b11e01eb2:	48 c1 e8 0c          	shr    rax,0xc
    732b11e01eb6:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01ebb:	48 85 c0             	test   rax,rax
    732b11e01ebe:	0f 84 ad 0c 00 18    	je     0x732b29e02b71
    732b11e01ec4:	89 d9                	mov    ecx,ebx
    732b11e01ec6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01ecc:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e01ed0:	89 de                	mov    esi,ebx
    732b11e01ed2:	83 c6 04             	add    esi,0x4
    732b11e01ed5:	89 f0                	mov    eax,esi
    732b11e01ed7:	c1 e8 0c             	shr    eax,0xc
    732b11e01eda:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01edf:	48 85 c0             	test   rax,rax
    732b11e01ee2:	0f 84 c6 0c 00 18    	je     0x732b29e02bae
    732b11e01ee8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01eee:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e01ef1:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e01ef4:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e01ef8:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e01eff:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e01f03:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    732b11e01f0a:	68 03 01 00 
    732b11e01f0e:	0f 84 d6 0c 00 18    	je     0x732b29e02bea
    732b11e01f14:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    732b11e01f1b:	68 03 01 00 
    732b11e01f1f:	0f 84 c5 0c 00 18    	je     0x732b29e02bea
    732b11e01f25:	58                   	pop    rax
    732b11e01f26:	50                   	push   rax
    732b11e01f27:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e01f2b:	f6 c3 03             	test   bl,0x3
    732b11e01f2e:	0f 85 ff 0c 00 18    	jne    0x732b29e02c33
    732b11e01f34:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e01f3b:	48 89 d8             	mov    rax,rbx
    732b11e01f3e:	48 c1 e8 0c          	shr    rax,0xc
    732b11e01f42:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01f47:	48 85 c0             	test   rax,rax
    732b11e01f4a:	0f 84 35 0d 00 18    	je     0x732b29e02c85
    732b11e01f50:	89 d9                	mov    ecx,ebx
    732b11e01f52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01f58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e01f5b:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    732b11e01f5f:	8d 73 04             	lea    esi,[rbx+0x4]
    732b11e01f62:	89 f0                	mov    eax,esi
    732b11e01f64:	c1 e8 0c             	shr    eax,0xc
    732b11e01f67:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01f6c:	48 85 c0             	test   rax,rax
    732b11e01f6f:	0f 84 4b 0d 00 18    	je     0x732b29e02cc0
    732b11e01f75:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01f7b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e01f7e:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    732b11e01f82:	8d 73 08             	lea    esi,[rbx+0x8]
    732b11e01f85:	89 f0                	mov    eax,esi
    732b11e01f87:	c1 e8 0c             	shr    eax,0xc
    732b11e01f8a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01f8f:	48 85 c0             	test   rax,rax
    732b11e01f92:	0f 84 64 0d 00 18    	je     0x732b29e02cfc
    732b11e01f98:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01f9e:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e01fa1:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    732b11e01fa5:	8d 73 0c             	lea    esi,[rbx+0xc]
    732b11e01fa8:	89 f0                	mov    eax,esi
    732b11e01faa:	c1 e8 0c             	shr    eax,0xc
    732b11e01fad:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01fb2:	48 85 c0             	test   rax,rax
    732b11e01fb5:	0f 84 7d 0d 00 18    	je     0x732b29e02d38
    732b11e01fbb:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01fc1:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e01fc4:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    732b11e01fc8:	89 de                	mov    esi,ebx
    732b11e01fca:	83 c6 10             	add    esi,0x10
    732b11e01fcd:	89 f0                	mov    eax,esi
    732b11e01fcf:	c1 e8 0c             	shr    eax,0xc
    732b11e01fd2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e01fd7:	48 85 c0             	test   rax,rax
    732b11e01fda:	0f 84 94 0d 00 18    	je     0x732b29e02d74
    732b11e01fe0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e01fe6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e01fe9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    732b11e01fed:	8d 43 14             	lea    eax,[rbx+0x14]
    732b11e01ff0:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    732b11e01ff4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    732b11e01ffb:	6c 03 01 00 
    732b11e01fff:	0f 84 ab 0d 00 18    	je     0x732b29e02db0
    732b11e02005:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    732b11e0200c:	6c 03 01 00 
    732b11e02010:	0f 84 9a 0d 00 18    	je     0x732b29e02db0
    732b11e02016:	58                   	pop    rax
    732b11e02017:	50                   	push   rax
    732b11e02018:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e0201f:	a8 01                	test   al,0x1
    732b11e02021:	0f 85 d2 0d 00 18    	jne    0x732b29e02df9
    732b11e02027:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e0202e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e02035:	01 
    732b11e02036:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    732b11e0203d:	6e 03 01 00 
    732b11e02041:	0f 84 e8 0d 00 18    	je     0x732b29e02e2f
    732b11e02047:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    732b11e0204e:	6e 03 01 00 
    732b11e02052:	0f 84 d7 0d 00 18    	je     0x732b29e02e2f
    732b11e02058:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e0205f:	02 00 00 00 
    732b11e02063:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b11e0206a:	1b 00 00 00 
    732b11e0206e:	58                   	pop    rax
    732b11e0206f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02076:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e0207d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e02084:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e0208b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e02092:	39 f1                	cmp    ecx,esi
    732b11e02094:	0f 83 c2 0d 00 18    	jae    0x732b29e02e5c
    732b11e0209a:	81 fa 28 03 01 00    	cmp    edx,0x10328
    732b11e020a0:	75 14                	jne    0x732b11e020b6
    732b11e020a2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e020a9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e020b0:	00 
    732b11e020b1:	e9 0a f4 ff ff       	jmp    0x732b11e014c0
    732b11e020b6:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e020bd:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e020c3:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e020c6:	0f 85 90 0d 00 18    	jne    0x732b29e02e5c
    732b11e020cc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e020d3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e020da:	00 
    732b11e020db:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e020e0:	ff e0                	jmp    rax
