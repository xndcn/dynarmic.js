
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65556-1-126628820681840.bin:     file format binary


Disassembly of section .data:

0000732b11e00470 <.data>:
    732b11e00470:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e00477:	8b 88 04 00 10 00    	mov    ecx,DWORD PTR [rax+0x100004]
    732b11e0047d:	ff c1                	inc    ecx
    732b11e0047f:	89 88 04 00 10 00    	mov    DWORD PTR [rax+0x100004],ecx
    732b11e00485:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0048b:	0f 84 3f fc ff 17    	je     0x732b29e000d0
    732b11e00491:	50                   	push   rax
    732b11e00492:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e00496:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e00499:	f6 c3 03             	test   bl,0x3
    732b11e0049c:	0f 85 5a fc ff 17    	jne    0x732b29e000fc
    732b11e004a2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e004a9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e004b0:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    732b11e004b4:	89 c8                	mov    eax,ecx
    732b11e004b6:	c1 e8 0c             	shr    eax,0xc
    732b11e004b9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e004be:	48 85 c0             	test   rax,rax
    732b11e004c1:	0f 84 88 fc ff 17    	je     0x732b29e0014f
    732b11e004c7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e004cd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e004d0:	8d 73 f8             	lea    esi,[rbx-0x8]
    732b11e004d3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    732b11e004d7:	89 f0                	mov    eax,esi
    732b11e004d9:	c1 e8 0c             	shr    eax,0xc
    732b11e004dc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e004e1:	48 85 c0             	test   rax,rax
    732b11e004e4:	0f 84 a0 fc ff 17    	je     0x732b29e0018a
    732b11e004ea:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e004f0:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e004f3:	8d 73 f4             	lea    esi,[rbx-0xc]
    732b11e004f6:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    732b11e004fa:	89 f0                	mov    eax,esi
    732b11e004fc:	c1 e8 0c             	shr    eax,0xc
    732b11e004ff:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00504:	48 85 c0             	test   rax,rax
    732b11e00507:	0f 84 b9 fc ff 17    	je     0x732b29e001c6
    732b11e0050d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00513:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e00516:	8d 73 f0             	lea    esi,[rbx-0x10]
    732b11e00519:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    732b11e0051d:	89 f0                	mov    eax,esi
    732b11e0051f:	c1 e8 0c             	shr    eax,0xc
    732b11e00522:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00527:	48 85 c0             	test   rax,rax
    732b11e0052a:	0f 84 d2 fc ff 17    	je     0x732b29e00202
    732b11e00530:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00536:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e00539:	8d 73 ec             	lea    esi,[rbx-0x14]
    732b11e0053c:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    732b11e00540:	89 f0                	mov    eax,esi
    732b11e00542:	c1 e8 0c             	shr    eax,0xc
    732b11e00545:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e0054a:	48 85 c0             	test   rax,rax
    732b11e0054d:	0f 84 eb fc ff 17    	je     0x732b29e0023e
    732b11e00553:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00559:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e0055c:	8d 73 e8             	lea    esi,[rbx-0x18]
    732b11e0055f:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    732b11e00563:	89 f0                	mov    eax,esi
    732b11e00565:	c1 e8 0c             	shr    eax,0xc
    732b11e00568:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e0056d:	48 85 c0             	test   rax,rax
    732b11e00570:	0f 84 04 fd ff 17    	je     0x732b29e0027a
    732b11e00576:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e0057c:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    732b11e0057f:	83 c3 e4             	add    ebx,0xffffffe4
    732b11e00582:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    732b11e00586:	89 d8                	mov    eax,ebx
    732b11e00588:	c1 e8 0c             	shr    eax,0xc
    732b11e0058b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00590:	48 85 c0             	test   rax,rax
    732b11e00593:	0f 84 1d fd ff 17    	je     0x732b29e002b6
    732b11e00599:	89 d9                	mov    ecx,ebx
    732b11e0059b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e005a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e005a4:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e005a8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10014
    732b11e005af:	14 00 01 00 
    732b11e005b3:	0f 84 3b fd ff 17    	je     0x732b29e002f4
    732b11e005b9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10014
    732b11e005c0:	14 00 01 00 
    732b11e005c4:	0f 84 2a fd ff 17    	je     0x732b29e002f4
    732b11e005ca:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e005ce:	0f 85 62 fd ff 17    	jne    0x732b29e00336
    732b11e005d4:	58                   	pop    rax
    732b11e005d5:	e9 0f 00 00 00       	jmp    0x732b11e005e9
    732b11e005da:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e005e1:	00 
    732b11e005e2:	74 f0                	je     0x732b11e005d4
    732b11e005e4:	e9 4a fb ff 17       	jmp    0x732b29e00133
    732b11e005e9:	50                   	push   rax
    732b11e005ea:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e005ef:	b9 00 00 00 00       	mov    ecx,0x0
    732b11e005f4:	09 c1                	or     ecx,eax
    732b11e005f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e005fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10016
    732b11e00601:	16 00 01 00 
    732b11e00605:	0f 84 5d fd ff 17    	je     0x732b29e00368
    732b11e0060b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10016
    732b11e00612:	16 00 01 00 
    732b11e00616:	0f 84 4c fd ff 17    	je     0x732b29e00368
    732b11e0061c:	58                   	pop    rax
    732b11e0061d:	50                   	push   rax
    732b11e0061e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e00622:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e00625:	f6 c3 03             	test   bl,0x3
    732b11e00628:	0f 85 9a fd ff 17    	jne    0x732b29e003c8
    732b11e0062e:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e00635:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e0063c:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    732b11e00640:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    732b11e00647:	89 c8                	mov    eax,ecx
    732b11e00649:	c1 e8 0c             	shr    eax,0xc
    732b11e0064c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00651:	48 85 c0             	test   rax,rax
    732b11e00654:	0f 84 c1 fd ff 17    	je     0x732b29e0041b
    732b11e0065a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00660:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e00663:	83 c3 f8             	add    ebx,0xfffffff8
    732b11e00666:	89 d8                	mov    eax,ebx
    732b11e00668:	c1 e8 0c             	shr    eax,0xc
    732b11e0066b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00670:	48 85 c0             	test   rax,rax
    732b11e00673:	0f 84 dd fd ff 17    	je     0x732b29e00456
    732b11e00679:	89 d9                	mov    ecx,ebx
    732b11e0067b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00681:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    732b11e00685:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    732b11e00689:	b8 14 00 00 00       	mov    eax,0x14
    732b11e0068e:	29 c3                	sub    ebx,eax
    732b11e00690:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e00694:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001a
    732b11e0069b:	1a 00 01 00 
    732b11e0069f:	0f 84 f2 fd ff 17    	je     0x732b29e00497
    732b11e006a5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001a
    732b11e006ac:	1a 00 01 00 
    732b11e006b0:	0f 84 e1 fd ff 17    	je     0x732b29e00497
    732b11e006b6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e006ba:	0f 85 19 fe ff 17    	jne    0x732b29e004d9
    732b11e006c0:	58                   	pop    rax
    732b11e006c1:	e9 0f 00 00 00       	jmp    0x732b11e006d5
    732b11e006c6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e006cd:	00 
    732b11e006ce:	74 f0                	je     0x732b11e006c0
    732b11e006d0:	e9 2a fd ff 17       	jmp    0x732b29e003ff
    732b11e006d5:	50                   	push   rax
    732b11e006d6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e006db:	c1 e0 10             	shl    eax,0x10
    732b11e006de:	b9 00 f0 00 00       	mov    ecx,0xf000
    732b11e006e3:	09 c1                	or     ecx,eax
    732b11e006e5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e006e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001e
    732b11e006f0:	1e 00 01 00 
    732b11e006f4:	0f 84 11 fe ff 17    	je     0x732b29e0050b
    732b11e006fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001e
    732b11e00701:	1e 00 01 00 
    732b11e00705:	0f 84 00 fe ff 17    	je     0x732b29e0050b
    732b11e0070b:	58                   	pop    rax
    732b11e0070c:	50                   	push   rax
    732b11e0070d:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    732b11e00712:	b9 00 00 42 43       	mov    ecx,0x43420000
    732b11e00717:	09 c1                	or     ecx,eax
    732b11e00719:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    732b11e0071d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10022
    732b11e00724:	22 00 01 00 
    732b11e00728:	0f 84 3d fe ff 17    	je     0x732b29e0056b
    732b11e0072e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10022
    732b11e00735:	22 00 01 00 
    732b11e00739:	0f 84 2c fe ff 17    	je     0x732b29e0056b
    732b11e0073f:	58                   	pop    rax
    732b11e00740:	50                   	push   rax
    732b11e00741:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e00745:	f6 c1 03             	test   cl,0x3
    732b11e00748:	0f 85 7d fe ff 17    	jne    0x732b29e005cb
    732b11e0074e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00755:	48 89 ca             	mov    rdx,rcx
    732b11e00758:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e0075c:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e00760:	48 85 c0             	test   rax,rax
    732b11e00763:	0f 84 b2 fe ff 17    	je     0x732b29e0061b
    732b11e00769:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0076f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e00772:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    732b11e00776:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10026
    732b11e0077d:	26 00 01 00 
    732b11e00781:	0f 84 cf fe ff 17    	je     0x732b29e00656
    732b11e00787:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10026
    732b11e0078e:	26 00 01 00 
    732b11e00792:	0f 84 be fe ff 17    	je     0x732b29e00656
    732b11e00798:	58                   	pop    rax
    732b11e00799:	50                   	push   rax
    732b11e0079a:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    732b11e0079f:	c1 e0 10             	shl    eax,0x10
    732b11e007a2:	b9 31 4e 00 00       	mov    ecx,0x4e31
    732b11e007a7:	09 c1                	or     ecx,eax
    732b11e007a9:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    732b11e007ad:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10028
    732b11e007b4:	28 00 01 00 
    732b11e007b8:	0f 84 e1 fe ff 17    	je     0x732b29e0069f
    732b11e007be:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10028
    732b11e007c5:	28 00 01 00 
    732b11e007c9:	0f 84 d0 fe ff 17    	je     0x732b29e0069f
    732b11e007cf:	58                   	pop    rax
    732b11e007d0:	50                   	push   rax
    732b11e007d1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e007d5:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    732b11e007d9:	31 d2                	xor    edx,edx
    732b11e007db:	31 f6                	xor    esi,esi
    732b11e007dd:	89 c7                	mov    edi,eax
    732b11e007df:	29 cf                	sub    edi,ecx
    732b11e007e1:	0f 94 c2             	sete   dl
    732b11e007e4:	40 0f 93 c6          	setae  sil
    732b11e007e8:	c1 ef 1f             	shr    edi,0x1f
    732b11e007eb:	c1 e8 1f             	shr    eax,0x1f
    732b11e007ee:	c1 e9 1f             	shr    ecx,0x1f
    732b11e007f1:	89 fb                	mov    ebx,edi
    732b11e007f3:	31 c3                	xor    ebx,eax
    732b11e007f5:	31 c1                	xor    ecx,eax
    732b11e007f7:	21 d9                	and    ecx,ebx
    732b11e007f9:	31 f9                	xor    ecx,edi
    732b11e007fb:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e00802:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e00809:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    732b11e00810:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    732b11e00817:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    732b11e0081e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002c
    732b11e00825:	2c 00 01 00 
    732b11e00829:	0f 84 d0 fe ff 17    	je     0x732b29e006ff
    732b11e0082f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002c
    732b11e00836:	2c 00 01 00 
    732b11e0083a:	0f 84 bf fe ff 17    	je     0x732b29e006ff
    732b11e00840:	58                   	pop    rax
    732b11e00841:	50                   	push   rax
    732b11e00842:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e00849:	00 
    732b11e0084a:	74 55                	je     0x732b11e008a1
    732b11e0084c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e00853:	01 
    732b11e00854:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    732b11e0085b:	2e 00 01 00 
    732b11e0085f:	0f 84 fa fe ff 17    	je     0x732b29e0075f
    732b11e00865:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    732b11e0086c:	2e 00 01 00 
    732b11e00870:	0f 84 e9 fe ff 17    	je     0x732b29e0075f
    732b11e00876:	b8 2e 00 01 00       	mov    eax,0x1002e
    732b11e0087b:	83 c0 12             	add    eax,0x12
    732b11e0087e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e00885:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e0088c:	02 00 00 00 
    732b11e00890:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b11e00897:	09 00 00 00 
    732b11e0089b:	58                   	pop    rax
    732b11e0089c:	e9 3c 03 00 00       	jmp    0x732b11e00bdd
    732b11e008a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    732b11e008a8:	2e 00 01 00 
    732b11e008ac:	0f 84 e9 fe ff 17    	je     0x732b29e0079b
    732b11e008b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    732b11e008b9:	2e 00 01 00 
    732b11e008bd:	0f 84 d8 fe ff 17    	je     0x732b29e0079b
    732b11e008c3:	58                   	pop    rax
    732b11e008c4:	50                   	push   rax
    732b11e008c5:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    732b11e008cc:	00 
    732b11e008cd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10030
    732b11e008d4:	30 00 01 00 
    732b11e008d8:	0f 84 06 ff ff 17    	je     0x732b29e007e4
    732b11e008de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10030
    732b11e008e5:	30 00 01 00 
    732b11e008e9:	0f 84 f5 fe ff 17    	je     0x732b29e007e4
    732b11e008ef:	58                   	pop    rax
    732b11e008f0:	50                   	push   rax
    732b11e008f1:	41 83 45 28 10       	add    DWORD PTR [r13+0x28],0x10
    732b11e008f6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10032
    732b11e008fd:	32 00 01 00 
    732b11e00901:	0f 84 3d ff ff 17    	je     0x732b29e00844
    732b11e00907:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10032
    732b11e0090e:	32 00 01 00 
    732b11e00912:	0f 84 2c ff ff 17    	je     0x732b29e00844
    732b11e00918:	58                   	pop    rax
    732b11e00919:	50                   	push   rax
    732b11e0091a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e0091e:	f6 c1 03             	test   cl,0x3
    732b11e00921:	0f 85 7d ff ff 17    	jne    0x732b29e008a4
    732b11e00927:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e0092e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e00932:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00939:	48 89 ce             	mov    rsi,rcx
    732b11e0093c:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e00940:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e00944:	48 85 c0             	test   rax,rax
    732b11e00947:	0f 84 aa ff ff 17    	je     0x732b29e008f7
    732b11e0094d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00953:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e00956:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10034
    732b11e0095d:	34 00 01 00 
    732b11e00961:	0f 84 cb ff ff 17    	je     0x732b29e00932
    732b11e00967:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10034
    732b11e0096e:	34 00 01 00 
    732b11e00972:	0f 84 ba ff ff 17    	je     0x732b29e00932
    732b11e00978:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e0097b:	0f 85 f2 ff ff 17    	jne    0x732b29e00973
    732b11e00981:	58                   	pop    rax
    732b11e00982:	e9 0f 00 00 00       	jmp    0x732b11e00996
    732b11e00987:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e0098e:	00 
    732b11e0098f:	74 f0                	je     0x732b11e00981
    732b11e00991:	e9 45 ff ff 17       	jmp    0x732b29e008db
    732b11e00996:	50                   	push   rax
    732b11e00997:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    732b11e0099e:	00 
    732b11e0099f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10036
    732b11e009a6:	36 00 01 00 
    732b11e009aa:	0f 84 f5 ff ff 17    	je     0x732b29e009a5
    732b11e009b0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10036
    732b11e009b7:	36 00 01 00 
    732b11e009bb:	0f 84 e4 ff ff 17    	je     0x732b29e009a5
    732b11e009c1:	58                   	pop    rax
    732b11e009c2:	50                   	push   rax
    732b11e009c3:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e009c7:	f6 c3 03             	test   bl,0x3
    732b11e009ca:	0f 85 35 00 00 18    	jne    0x732b29e00a05
    732b11e009d0:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e009d7:	48 89 d8             	mov    rax,rbx
    732b11e009da:	48 c1 e8 0c          	shr    rax,0xc
    732b11e009de:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e009e3:	48 85 c0             	test   rax,rax
    732b11e009e6:	0f 84 6b 00 00 18    	je     0x732b29e00a57
    732b11e009ec:	89 d9                	mov    ecx,ebx
    732b11e009ee:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e009f4:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e009f8:	89 de                	mov    esi,ebx
    732b11e009fa:	83 c6 04             	add    esi,0x4
    732b11e009fd:	89 f0                	mov    eax,esi
    732b11e009ff:	c1 e8 0c             	shr    eax,0xc
    732b11e00a02:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00a07:	48 85 c0             	test   rax,rax
    732b11e00a0a:	0f 84 84 00 00 18    	je     0x732b29e00a94
    732b11e00a10:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00a16:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00a19:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e00a1c:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e00a20:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e00a27:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e00a2b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10038
    732b11e00a32:	38 00 01 00 
    732b11e00a36:	0f 84 94 00 00 18    	je     0x732b29e00ad0
    732b11e00a3c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10038
    732b11e00a43:	38 00 01 00 
    732b11e00a47:	0f 84 83 00 00 18    	je     0x732b29e00ad0
    732b11e00a4d:	58                   	pop    rax
    732b11e00a4e:	50                   	push   rax
    732b11e00a4f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e00a53:	f6 c3 03             	test   bl,0x3
    732b11e00a56:	0f 85 bd 00 00 18    	jne    0x732b29e00b19
    732b11e00a5c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e00a63:	48 89 d8             	mov    rax,rbx
    732b11e00a66:	48 c1 e8 0c          	shr    rax,0xc
    732b11e00a6a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00a6f:	48 85 c0             	test   rax,rax
    732b11e00a72:	0f 84 f3 00 00 18    	je     0x732b29e00b6b
    732b11e00a78:	89 d9                	mov    ecx,ebx
    732b11e00a7a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00a80:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e00a83:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    732b11e00a87:	8d 73 04             	lea    esi,[rbx+0x4]
    732b11e00a8a:	89 f0                	mov    eax,esi
    732b11e00a8c:	c1 e8 0c             	shr    eax,0xc
    732b11e00a8f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00a94:	48 85 c0             	test   rax,rax
    732b11e00a97:	0f 84 09 01 00 18    	je     0x732b29e00ba6
    732b11e00a9d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00aa3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00aa6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    732b11e00aaa:	8d 73 08             	lea    esi,[rbx+0x8]
    732b11e00aad:	89 f0                	mov    eax,esi
    732b11e00aaf:	c1 e8 0c             	shr    eax,0xc
    732b11e00ab2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00ab7:	48 85 c0             	test   rax,rax
    732b11e00aba:	0f 84 22 01 00 18    	je     0x732b29e00be2
    732b11e00ac0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00ac6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00ac9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    732b11e00acd:	8d 73 0c             	lea    esi,[rbx+0xc]
    732b11e00ad0:	89 f0                	mov    eax,esi
    732b11e00ad2:	c1 e8 0c             	shr    eax,0xc
    732b11e00ad5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00ada:	48 85 c0             	test   rax,rax
    732b11e00add:	0f 84 3b 01 00 18    	je     0x732b29e00c1e
    732b11e00ae3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00ae9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00aec:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    732b11e00af0:	8d 73 10             	lea    esi,[rbx+0x10]
    732b11e00af3:	89 f0                	mov    eax,esi
    732b11e00af5:	c1 e8 0c             	shr    eax,0xc
    732b11e00af8:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00afd:	48 85 c0             	test   rax,rax
    732b11e00b00:	0f 84 54 01 00 18    	je     0x732b29e00c5a
    732b11e00b06:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00b0c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00b0f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    732b11e00b13:	8d 73 14             	lea    esi,[rbx+0x14]
    732b11e00b16:	89 f0                	mov    eax,esi
    732b11e00b18:	c1 e8 0c             	shr    eax,0xc
    732b11e00b1b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00b20:	48 85 c0             	test   rax,rax
    732b11e00b23:	0f 84 6d 01 00 18    	je     0x732b29e00c96
    732b11e00b29:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00b2f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00b32:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    732b11e00b36:	89 de                	mov    esi,ebx
    732b11e00b38:	83 c6 18             	add    esi,0x18
    732b11e00b3b:	89 f0                	mov    eax,esi
    732b11e00b3d:	c1 e8 0c             	shr    eax,0xc
    732b11e00b40:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e00b45:	48 85 c0             	test   rax,rax
    732b11e00b48:	0f 84 84 01 00 18    	je     0x732b29e00cd2
    732b11e00b4e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e00b54:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e00b57:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    732b11e00b5b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    732b11e00b5e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    732b11e00b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003c
    732b11e00b69:	3c 00 01 00 
    732b11e00b6d:	0f 84 9b 01 00 18    	je     0x732b29e00d0e
    732b11e00b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003c
    732b11e00b7a:	3c 00 01 00 
    732b11e00b7e:	0f 84 8a 01 00 18    	je     0x732b29e00d0e
    732b11e00b84:	58                   	pop    rax
    732b11e00b85:	50                   	push   rax
    732b11e00b86:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e00b8d:	a8 01                	test   al,0x1
    732b11e00b8f:	0f 85 c2 01 00 18    	jne    0x732b29e00d57
    732b11e00b95:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e00b9c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e00ba3:	01 
    732b11e00ba4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003e
    732b11e00bab:	3e 00 01 00 
    732b11e00baf:	0f 84 d8 01 00 18    	je     0x732b29e00d8d
    732b11e00bb5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003e
    732b11e00bbc:	3e 00 01 00 
    732b11e00bc0:	0f 84 c7 01 00 18    	je     0x732b29e00d8d
    732b11e00bc6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e00bcd:	02 00 00 00 
    732b11e00bd1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b11e00bd8:	10 00 00 00 
    732b11e00bdc:	58                   	pop    rax
    732b11e00bdd:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e00be4:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e00beb:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e00bf2:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e00bf9:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e00c00:	39 f1                	cmp    ecx,esi
    732b11e00c02:	0f 83 b2 01 00 18    	jae    0x732b29e00dba
    732b11e00c08:	81 fa 14 00 01 00    	cmp    edx,0x10014
    732b11e00c0e:	75 14                	jne    0x732b11e00c24
    732b11e00c10:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e00c17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e00c1e:	00 
    732b11e00c1f:	e9 4c f8 ff ff       	jmp    0x732b11e00470
    732b11e00c24:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e00c2b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e00c31:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e00c34:	0f 85 80 01 00 18    	jne    0x732b29e00dba
    732b11e00c3a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e00c41:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e00c48:	00 
    732b11e00c49:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e00c4e:	ff e0                	jmp    rax
