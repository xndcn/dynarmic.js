
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65536-1-126628820681488.bin:     file format binary


Disassembly of section .data:

0000732b11e00310 <.data>:
    732b11e00310:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e00317:	8b 88 00 00 10 00    	mov    ecx,DWORD PTR [rax+0x100000]
    732b11e0031d:	ff c1                	inc    ecx
    732b11e0031f:	89 88 00 00 10 00    	mov    DWORD PTR [rax+0x100000],ecx
    732b11e00325:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0032b:	0f 84 cf fc ff 17    	je     0x732b29e00000
    732b11e00331:	50                   	push   rax
    732b11e00332:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    732b11e00337:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10000
    732b11e0033e:	00 00 01 00 
    732b11e00342:	0f 84 e4 fc ff 17    	je     0x732b29e0002c
    732b11e00348:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10000
    732b11e0034f:	00 00 01 00 
    732b11e00353:	0f 84 d3 fc ff 17    	je     0x732b29e0002c
    732b11e00359:	58                   	pop    rax
    732b11e0035a:	50                   	push   rax
    732b11e0035b:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e00362:	b9 02 00 01 00       	mov    ecx,0x10002
    732b11e00367:	83 c1 04             	add    ecx,0x4
    732b11e0036a:	89 ca                	mov    edx,ecx
    732b11e0036c:	3d 02 00 01 00       	cmp    eax,0x10002
    732b11e00371:	75 07                	jne    0x732b11e0037a
    732b11e00373:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    732b11e0037a:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    732b11e00381:	02 
    732b11e00382:	0f 43 ca             	cmovae ecx,edx
    732b11e00385:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    732b11e0038c:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    732b11e00393:	89 cf                	mov    edi,ecx
    732b11e00395:	81 fa 02 00 01 00    	cmp    edx,0x10002
    732b11e0039b:	75 07                	jne    0x732b11e003a4
    732b11e0039d:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    732b11e003a4:	83 fe 02             	cmp    esi,0x2
    732b11e003a7:	0f 43 cf             	cmovae ecx,edi
    732b11e003aa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    732b11e003b1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e003b8:	01 
    732b11e003b9:	3d 02 00 01 00       	cmp    eax,0x10002
    732b11e003be:	0f 84 c8 fc ff 17    	je     0x732b29e0008c
    732b11e003c4:	81 fa 02 00 01 00    	cmp    edx,0x10002
    732b11e003ca:	0f 84 bc fc ff 17    	je     0x732b29e0008c
    732b11e003d0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b11e003d7:	14 00 01 00 
    732b11e003db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b11e003e2:	04 00 00 00 
    732b11e003e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b11e003ed:	02 00 00 00 
    732b11e003f1:	58                   	pop    rax
    732b11e003f2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e003f9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e00400:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e00407:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e0040e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e00415:	39 f1                	cmp    ecx,esi
    732b11e00417:	0f 83 a7 fc ff 17    	jae    0x732b29e000c4
    732b11e0041d:	81 fa 00 00 01 00    	cmp    edx,0x10000
    732b11e00423:	75 14                	jne    0x732b11e00439
    732b11e00425:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e0042c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e00433:	00 
    732b11e00434:	e9 d7 fe ff ff       	jmp    0x732b11e00310
    732b11e00439:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e00440:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e00446:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e00449:	0f 85 75 fc ff 17    	jne    0x732b29e000c4
    732b11e0044f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e00456:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e0045d:	00 
    732b11e0045e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e00463:	ff e0                	jmp    rax
