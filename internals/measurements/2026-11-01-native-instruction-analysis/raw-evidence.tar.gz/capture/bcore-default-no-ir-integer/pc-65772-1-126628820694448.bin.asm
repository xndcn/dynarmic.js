
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65772-1-126628820694448.bin:     file format binary


Disassembly of section .data:

0000732b11e035b0 <.data>:
    732b11e035b0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e035b7:	8b 88 24 00 10 00    	mov    ecx,DWORD PTR [rax+0x100024]
    732b11e035bd:	ff c1                	inc    ecx
    732b11e035bf:	89 88 24 00 10 00    	mov    DWORD PTR [rax+0x100024],ecx
    732b11e035c5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e035cb:	0f 84 3f 14 00 18    	je     0x732b29e04a10
    732b11e035d1:	50                   	push   rax
    732b11e035d2:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
    732b11e035d6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e035dd:	41 0f af 45 04       	imul   eax,DWORD PTR [r13+0x4]
    732b11e035e2:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e035e6:	81 f9 ec 00 01 00    	cmp    ecx,0x100ec
    732b11e035ec:	0f 84 4a 14 00 18    	je     0x732b29e04a3c
    732b11e035f2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ec
    732b11e035f9:	ec 00 01 00 
    732b11e035fd:	0f 84 39 14 00 18    	je     0x732b29e04a3c
    732b11e03603:	58                   	pop    rax
    732b11e03604:	50                   	push   rax
    732b11e03605:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e03609:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    732b11e0360d:	89 c2                	mov    edx,eax
    732b11e0360f:	c1 ea 1f             	shr    edx,0x1f
    732b11e03612:	89 ce                	mov    esi,ecx
    732b11e03614:	c1 ee 1f             	shr    esi,0x1f
    732b11e03617:	31 ff                	xor    edi,edi
    732b11e03619:	01 c8                	add    eax,ecx
    732b11e0361b:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e0361f:	40 0f 92 c7          	setb   dil
    732b11e03623:	89 c1                	mov    ecx,eax
    732b11e03625:	c1 e9 1f             	shr    ecx,0x1f
    732b11e03628:	31 ce                	xor    esi,ecx
    732b11e0362a:	31 ca                	xor    edx,ecx
    732b11e0362c:	21 f2                	and    edx,esi
    732b11e0362e:	31 f6                	xor    esi,esi
    732b11e03630:	85 c0                	test   eax,eax
    732b11e03632:	40 0f 94 c6          	sete   sil
    732b11e03636:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    732b11e0363d:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    732b11e03644:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    732b11e0364b:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    732b11e03652:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    732b11e03659:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    732b11e03660:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    732b11e03667:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ee
    732b11e0366e:	ee 00 01 00 
    732b11e03672:	0f 84 24 14 00 18    	je     0x732b29e04a9c
    732b11e03678:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ee
    732b11e0367f:	ee 00 01 00 
    732b11e03683:	0f 84 13 14 00 18    	je     0x732b29e04a9c
    732b11e03689:	58                   	pop    rax
    732b11e0368a:	50                   	push   rax
    732b11e0368b:	41 8b 85 04 00 00 00 	mov    eax,DWORD PTR [r13+0x4]
    732b11e03692:	89 c1                	mov    ecx,eax
    732b11e03694:	c1 e9 0d             	shr    ecx,0xd
    732b11e03697:	41 89 8d 0c 00 00 00 	mov    DWORD PTR [r13+0xc],ecx
    732b11e0369e:	31 c9                	xor    ecx,ecx
    732b11e036a0:	3d 00 20 00 00       	cmp    eax,0x2000
    732b11e036a5:	0f 92 c1             	setb   cl
    732b11e036a8:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    732b11e036af:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    732b11e036b6:	00 00 00 00 
    732b11e036ba:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e036c1:	00 00 00 00 
    732b11e036c5:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100f0
    732b11e036cc:	f0 00 01 00 
    732b11e036d0:	0f 84 26 14 00 18    	je     0x732b29e04afc
    732b11e036d6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f0
    732b11e036dd:	f0 00 01 00 
    732b11e036e1:	0f 84 15 14 00 18    	je     0x732b29e04afc
    732b11e036e7:	58                   	pop    rax
    732b11e036e8:	50                   	push   rax
    732b11e036e9:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e036ed:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e036f4:	31 d2                	xor    edx,edx
    732b11e036f6:	41 33 45 0c          	xor    eax,DWORD PTR [r13+0xc]
    732b11e036fa:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e036fe:	0f 94 c2             	sete   dl
    732b11e03701:	c1 e8 1f             	shr    eax,0x1f
    732b11e03704:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e0370b:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e03712:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    732b11e03719:	00 00 00 00 
    732b11e0371d:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e03724:	00 00 00 00 
    732b11e03728:	81 f9 f4 00 01 00    	cmp    ecx,0x100f4
    732b11e0372e:	0f 84 28 14 00 18    	je     0x732b29e04b5c
    732b11e03734:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f4
    732b11e0373b:	f4 00 01 00 
    732b11e0373f:	0f 84 17 14 00 18    	je     0x732b29e04b5c
    732b11e03745:	58                   	pop    rax
    732b11e03746:	50                   	push   rax
    732b11e03747:	41 8b 85 04 00 00 00 	mov    eax,DWORD PTR [r13+0x4]
    732b11e0374e:	31 c9                	xor    ecx,ecx
    732b11e03750:	c1 e0 07             	shl    eax,0x7
    732b11e03753:	41 89 85 0c 00 00 00 	mov    DWORD PTR [r13+0xc],eax
    732b11e0375a:	0f 94 c1             	sete   cl
    732b11e0375d:	c1 e8 1f             	shr    eax,0x1f
    732b11e03760:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    732b11e03767:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e0376e:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e03775:	00 00 00 00 
    732b11e03779:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100f6
    732b11e03780:	f6 00 01 00 
    732b11e03784:	0f 84 32 14 00 18    	je     0x732b29e04bbc
    732b11e0378a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f6
    732b11e03791:	f6 00 01 00 
    732b11e03795:	0f 84 21 14 00 18    	je     0x732b29e04bbc
    732b11e0379b:	58                   	pop    rax
    732b11e0379c:	50                   	push   rax
    732b11e0379d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e037a1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e037a8:	89 c2                	mov    edx,eax
    732b11e037aa:	c1 ea 19             	shr    edx,0x19
    732b11e037ad:	41 89 55 04          	mov    DWORD PTR [r13+0x4],edx
    732b11e037b1:	31 d2                	xor    edx,edx
    732b11e037b3:	3d 00 00 00 02       	cmp    eax,0x2000000
    732b11e037b8:	0f 92 c2             	setb   dl
    732b11e037bb:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e037c2:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    732b11e037c9:	00 00 00 00 
    732b11e037cd:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e037d4:	00 00 00 00 
    732b11e037d8:	81 f9 fa 00 01 00    	cmp    ecx,0x100fa
    732b11e037de:	0f 84 38 14 00 18    	je     0x732b29e04c1c
    732b11e037e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fa
    732b11e037eb:	fa 00 01 00 
    732b11e037ef:	0f 84 27 14 00 18    	je     0x732b29e04c1c
    732b11e037f5:	58                   	pop    rax
    732b11e037f6:	50                   	push   rax
    732b11e037f7:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    732b11e037fb:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e03802:	31 d2                	xor    edx,edx
    732b11e03804:	89 c6                	mov    esi,eax
    732b11e03806:	ff c6                	inc    esi
    732b11e03808:	0f 94 c2             	sete   dl
    732b11e0380b:	41 89 75 08          	mov    DWORD PTR [r13+0x8],esi
    732b11e0380f:	c1 e8 1f             	shr    eax,0x1f
    732b11e03812:	89 f7                	mov    edi,esi
    732b11e03814:	c1 ef 1f             	shr    edi,0x1f
    732b11e03817:	f7 d0                	not    eax
    732b11e03819:	21 f8                	and    eax,edi
    732b11e0381b:	31 db                	xor    ebx,ebx
    732b11e0381d:	85 f6                	test   esi,esi
    732b11e0381f:	0f 94 c3             	sete   bl
    732b11e03822:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    732b11e03829:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e03830:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    732b11e03837:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    732b11e0383e:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    732b11e03845:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    732b11e0384c:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    732b11e03853:	81 f9 fc 00 01 00    	cmp    ecx,0x100fc
    732b11e03859:	0f 84 1d 14 00 18    	je     0x732b29e04c7c
    732b11e0385f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fc
    732b11e03866:	fc 00 01 00 
    732b11e0386a:	0f 84 0c 14 00 18    	je     0x732b29e04c7c
    732b11e03870:	58                   	pop    rax
    732b11e03871:	50                   	push   rax
    732b11e03872:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    732b11e03876:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e0387d:	31 d2                	xor    edx,edx
    732b11e0387f:	41 0b 45 04          	or     eax,DWORD PTR [r13+0x4]
    732b11e03883:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e03887:	0f 94 c2             	sete   dl
    732b11e0388a:	c1 e8 1f             	shr    eax,0x1f
    732b11e0388d:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e03894:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e0389b:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    732b11e038a2:	00 00 00 00 
    732b11e038a6:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e038ad:	00 00 00 00 
    732b11e038b1:	81 f9 fe 00 01 00    	cmp    ecx,0x100fe
    732b11e038b7:	0f 84 1f 14 00 18    	je     0x732b29e04cdc
    732b11e038bd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fe
    732b11e038c4:	fe 00 01 00 
    732b11e038c8:	0f 84 0e 14 00 18    	je     0x732b29e04cdc
    732b11e038ce:	58                   	pop    rax
    732b11e038cf:	50                   	push   rax
    732b11e038d0:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e038d4:	41 8b 4d 08          	mov    ecx,DWORD PTR [r13+0x8]
    732b11e038d8:	31 d2                	xor    edx,edx
    732b11e038da:	31 f6                	xor    esi,esi
    732b11e038dc:	31 ff                	xor    edi,edi
    732b11e038de:	31 db                	xor    ebx,ebx
    732b11e038e0:	39 c8                	cmp    eax,ecx
    732b11e038e2:	0f 96 c2             	setbe  dl
    732b11e038e5:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e038ec:	40 0f 94 c6          	sete   sil
    732b11e038f0:	40 0f 92 c7          	setb   dil
    732b11e038f4:	0f 93 c3             	setae  bl
    732b11e038f7:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    732b11e038fe:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e03905:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    732b11e0390c:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    732b11e03913:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10100
    732b11e0391a:	00 01 01 00 
    732b11e0391e:	0f 84 18 14 00 18    	je     0x732b29e04d3c
    732b11e03924:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10100
    732b11e0392b:	00 01 01 00 
    732b11e0392f:	0f 84 07 14 00 18    	je     0x732b29e04d3c
    732b11e03935:	58                   	pop    rax
    732b11e03936:	50                   	push   rax
    732b11e03937:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e0393e:	00 
    732b11e0393f:	74 28                	je     0x732b11e03969
    732b11e03941:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10102
    732b11e03948:	02 01 01 00 
    732b11e0394c:	0f 84 4a 14 00 18    	je     0x732b29e04d9c
    732b11e03952:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10102
    732b11e03959:	02 01 01 00 
    732b11e0395d:	0f 84 39 14 00 18    	je     0x732b29e04d9c
    732b11e03963:	58                   	pop    rax
    732b11e03964:	e9 55 00 00 00       	jmp    0x732b11e039be
    732b11e03969:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e03970:	01 
    732b11e03971:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10102
    732b11e03978:	02 01 01 00 
    732b11e0397c:	0f 84 63 14 00 18    	je     0x732b29e04de5
    732b11e03982:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10102
    732b11e03989:	02 01 01 00 
    732b11e0398d:	0f 84 52 14 00 18    	je     0x732b29e04de5
    732b11e03993:	b8 02 01 01 00       	mov    eax,0x10102
    732b11e03998:	83 c0 ea             	add    eax,0xffffffea
    732b11e0399b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e039a2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e039a9:	02 00 00 00 
    732b11e039ad:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b11e039b4:	0a 00 00 00 
    732b11e039b8:	58                   	pop    rax
    732b11e039b9:	e9 9a 01 00 00       	jmp    0x732b11e03b58
    732b11e039be:	50                   	push   rax
    732b11e039bf:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e039c3:	f6 c3 03             	test   bl,0x3
    732b11e039c6:	0f 85 55 14 00 18    	jne    0x732b29e04e21
    732b11e039cc:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e039d3:	48 89 d8             	mov    rax,rbx
    732b11e039d6:	48 c1 e8 0c          	shr    rax,0xc
    732b11e039da:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e039df:	48 85 c0             	test   rax,rax
    732b11e039e2:	0f 84 8b 14 00 18    	je     0x732b29e04e73
    732b11e039e8:	89 d9                	mov    ecx,ebx
    732b11e039ea:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e039f0:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e039f4:	89 de                	mov    esi,ebx
    732b11e039f6:	83 c6 04             	add    esi,0x4
    732b11e039f9:	89 f0                	mov    eax,esi
    732b11e039fb:	c1 e8 0c             	shr    eax,0xc
    732b11e039fe:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e03a03:	48 85 c0             	test   rax,rax
    732b11e03a06:	0f 84 a4 14 00 18    	je     0x732b29e04eb0
    732b11e03a0c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e03a12:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e03a15:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e03a18:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e03a1c:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e03a23:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e03a27:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10104
    732b11e03a2e:	04 01 01 00 
    732b11e03a32:	0f 84 b4 14 00 18    	je     0x732b29e04eec
    732b11e03a38:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10104
    732b11e03a3f:	04 01 01 00 
    732b11e03a43:	0f 84 a3 14 00 18    	je     0x732b29e04eec
    732b11e03a49:	58                   	pop    rax
    732b11e03a4a:	50                   	push   rax
    732b11e03a4b:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e03a4f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e03a56:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    732b11e03a5a:	81 f9 08 01 01 00    	cmp    ecx,0x10108
    732b11e03a60:	0f 84 cf 14 00 18    	je     0x732b29e04f35
    732b11e03a66:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10108
    732b11e03a6d:	08 01 01 00 
    732b11e03a71:	0f 84 be 14 00 18    	je     0x732b29e04f35
    732b11e03a77:	58                   	pop    rax
    732b11e03a78:	50                   	push   rax
    732b11e03a79:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e03a7d:	f6 c3 03             	test   bl,0x3
    732b11e03a80:	0f 85 0f 15 00 18    	jne    0x732b29e04f95
    732b11e03a86:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e03a8d:	48 89 d8             	mov    rax,rbx
    732b11e03a90:	48 c1 e8 0c          	shr    rax,0xc
    732b11e03a94:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e03a99:	48 85 c0             	test   rax,rax
    732b11e03a9c:	0f 84 45 15 00 18    	je     0x732b29e04fe7
    732b11e03aa2:	89 d9                	mov    ecx,ebx
    732b11e03aa4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e03aaa:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e03aad:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    732b11e03ab1:	89 de                	mov    esi,ebx
    732b11e03ab3:	83 c6 04             	add    esi,0x4
    732b11e03ab6:	89 f0                	mov    eax,esi
    732b11e03ab8:	c1 e8 0c             	shr    eax,0xc
    732b11e03abb:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e03ac0:	48 85 c0             	test   rax,rax
    732b11e03ac3:	0f 84 59 15 00 18    	je     0x732b29e05022
    732b11e03ac9:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e03acf:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e03ad2:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    732b11e03ad6:	8d 43 08             	lea    eax,[rbx+0x8]
    732b11e03ad9:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    732b11e03add:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1010a
    732b11e03ae4:	0a 01 01 00 
    732b11e03ae8:	0f 84 70 15 00 18    	je     0x732b29e0505e
    732b11e03aee:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1010a
    732b11e03af5:	0a 01 01 00 
    732b11e03af9:	0f 84 5f 15 00 18    	je     0x732b29e0505e
    732b11e03aff:	58                   	pop    rax
    732b11e03b00:	50                   	push   rax
    732b11e03b01:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e03b08:	a8 01                	test   al,0x1
    732b11e03b0a:	0f 85 97 15 00 18    	jne    0x732b29e050a7
    732b11e03b10:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e03b17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e03b1e:	01 
    732b11e03b1f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1010c
    732b11e03b26:	0c 01 01 00 
    732b11e03b2a:	0f 84 ad 15 00 18    	je     0x732b29e050dd
    732b11e03b30:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1010c
    732b11e03b37:	0c 01 01 00 
    732b11e03b3b:	0f 84 9c 15 00 18    	je     0x732b29e050dd
    732b11e03b41:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e03b48:	02 00 00 00 
    732b11e03b4c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b11e03b53:	0e 00 00 00 
    732b11e03b57:	58                   	pop    rax
    732b11e03b58:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e03b5f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e03b66:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e03b6d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e03b74:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e03b7b:	39 f1                	cmp    ecx,esi
    732b11e03b7d:	0f 83 87 15 00 18    	jae    0x732b29e0510a
    732b11e03b83:	81 fa ec 00 01 00    	cmp    edx,0x100ec
    732b11e03b89:	75 14                	jne    0x732b11e03b9f
    732b11e03b8b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e03b92:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e03b99:	00 
    732b11e03b9a:	e9 11 fa ff ff       	jmp    0x732b11e035b0
    732b11e03b9f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e03ba6:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e03bac:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e03baf:	0f 85 55 15 00 18    	jne    0x732b29e0510a
    732b11e03bb5:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e03bbc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e03bc3:	00 
    732b11e03bc4:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e03bc9:	ff e0                	jmp    rax
