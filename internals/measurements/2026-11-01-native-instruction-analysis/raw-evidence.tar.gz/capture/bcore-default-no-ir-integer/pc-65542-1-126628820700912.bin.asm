
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65542-1-126628820700912.bin:     file format binary


Disassembly of section .data:

0000732b11e04ef0 <.data>:
    732b11e04ef0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e04ef7:	8b 88 30 00 10 00    	mov    ecx,DWORD PTR [rax+0x100030]
    732b11e04efd:	ff c1                	inc    ecx
    732b11e04eff:	89 88 30 00 10 00    	mov    DWORD PTR [rax+0x100030],ecx
    732b11e04f05:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e04f0b:	0f 84 0f 0f 00 18    	je     0x732b29e05e20
    732b11e04f11:	50                   	push   rax
    732b11e04f12:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    732b11e04f17:	b9 00 00 00 01       	mov    ecx,0x1000000
    732b11e04f1c:	09 c1                	or     ecx,eax
    732b11e04f1e:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    732b11e04f22:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10006
    732b11e04f29:	06 00 01 00 
    732b11e04f2d:	0f 84 19 0f 00 18    	je     0x732b29e05e4c
    732b11e04f33:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10006
    732b11e04f3a:	06 00 01 00 
    732b11e04f3e:	0f 84 08 0f 00 18    	je     0x732b29e05e4c
    732b11e04f44:	58                   	pop    rax
    732b11e04f45:	50                   	push   rax
    732b11e04f46:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    732b11e04f4b:	c1 e0 10             	shl    eax,0x10
    732b11e04f4e:	b9 04 00 00 00       	mov    ecx,0x4
    732b11e04f53:	09 c1                	or     ecx,eax
    732b11e04f55:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    732b11e04f59:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000a
    732b11e04f60:	0a 00 01 00 
    732b11e04f64:	0f 84 42 0f 00 18    	je     0x732b29e05eac
    732b11e04f6a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000a
    732b11e04f71:	0a 00 01 00 
    732b11e04f75:	0f 84 31 0f 00 18    	je     0x732b29e05eac
    732b11e04f7b:	58                   	pop    rax
    732b11e04f7c:	50                   	push   rax
    732b11e04f7d:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    732b11e04f81:	f6 c1 03             	test   cl,0x3
    732b11e04f84:	0f 85 82 0f 00 18    	jne    0x732b29e05f0c
    732b11e04f8a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e04f91:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e04f95:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e04f9c:	48 89 ce             	mov    rsi,rcx
    732b11e04f9f:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e04fa3:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e04fa7:	48 85 c0             	test   rax,rax
    732b11e04faa:	0f 84 af 0f 00 18    	je     0x732b29e05f5f
    732b11e04fb0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e04fb6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e04fb9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000e
    732b11e04fc0:	0e 00 01 00 
    732b11e04fc4:	0f 84 d0 0f 00 18    	je     0x732b29e05f9a
    732b11e04fca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000e
    732b11e04fd1:	0e 00 01 00 
    732b11e04fd5:	0f 84 bf 0f 00 18    	je     0x732b29e05f9a
    732b11e04fdb:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e04fde:	0f 85 f7 0f 00 18    	jne    0x732b29e05fdb
    732b11e04fe4:	58                   	pop    rax
    732b11e04fe5:	e9 0f 00 00 00       	jmp    0x732b11e04ff9
    732b11e04fea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e04ff1:	00 
    732b11e04ff2:	74 f0                	je     0x732b11e04fe4
    732b11e04ff4:	e9 4a 0f 00 18       	jmp    0x732b29e05f43
    732b11e04ff9:	50                   	push   rax
    732b11e04ffa:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e05001:	01 
    732b11e05002:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10010
    732b11e05009:	10 00 01 00 
    732b11e0500d:	0f 84 fa 0f 00 18    	je     0x732b29e0600d
    732b11e05013:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10010
    732b11e0501a:	10 00 01 00 
    732b11e0501e:	0f 84 e9 0f 00 18    	je     0x732b29e0600d
    732b11e05024:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    732b11e0502b:	10 00 01 00 
    732b11e0502f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e05036:	02 00 00 00 
    732b11e0503a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b11e05041:	04 00 00 00 
    732b11e05045:	58                   	pop    rax
    732b11e05046:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e0504d:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e05054:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e0505b:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e05062:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e05069:	39 f1                	cmp    ecx,esi
    732b11e0506b:	0f 83 d4 0f 00 18    	jae    0x732b29e06045
    732b11e05071:	81 fa 06 00 01 00    	cmp    edx,0x10006
    732b11e05077:	75 14                	jne    0x732b11e0508d
    732b11e05079:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e05080:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e05087:	00 
    732b11e05088:	e9 63 fe ff ff       	jmp    0x732b11e04ef0
    732b11e0508d:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e05094:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e0509a:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e0509d:	0f 85 a2 0f 00 18    	jne    0x732b29e06045
    732b11e050a3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e050aa:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e050b1:	00 
    732b11e050b2:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e050b7:	ff e0                	jmp    rax
