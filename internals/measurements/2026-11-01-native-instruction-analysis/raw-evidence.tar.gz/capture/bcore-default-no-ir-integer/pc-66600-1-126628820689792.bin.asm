
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66600-1-126628820689792.bin:     file format binary


Disassembly of section .data:

0000732b11e02380 <.data>:
    732b11e02380:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02387:	8b 88 14 00 10 00    	mov    ecx,DWORD PTR [rax+0x100014]
    732b11e0238d:	ff c1                	inc    ecx
    732b11e0238f:	89 88 14 00 10 00    	mov    DWORD PTR [rax+0x100014],ecx
    732b11e02395:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0239b:	0f 84 0f 0d 00 18    	je     0x732b29e030b0
    732b11e023a1:	50                   	push   rax
    732b11e023a2:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e023a7:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e023ac:	09 c1                	or     ecx,eax
    732b11e023ae:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e023b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10428
    732b11e023b9:	28 04 01 00 
    732b11e023bd:	0f 84 19 0d 00 18    	je     0x732b29e030dc
    732b11e023c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10428
    732b11e023ca:	28 04 01 00 
    732b11e023ce:	0f 84 08 0d 00 18    	je     0x732b29e030dc
    732b11e023d4:	58                   	pop    rax
    732b11e023d5:	50                   	push   rax
    732b11e023d6:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e023da:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e023dd:	f6 c3 03             	test   bl,0x3
    732b11e023e0:	0f 85 56 0d 00 18    	jne    0x732b29e0313c
    732b11e023e6:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e023ed:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e023f4:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    732b11e023f8:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    732b11e023ff:	89 c8                	mov    eax,ecx
    732b11e02401:	c1 e8 0c             	shr    eax,0xc
    732b11e02404:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02409:	48 85 c0             	test   rax,rax
    732b11e0240c:	0f 84 7d 0d 00 18    	je     0x732b29e0318f
    732b11e02412:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02418:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e0241b:	83 c3 f8             	add    ebx,0xfffffff8
    732b11e0241e:	89 d8                	mov    eax,ebx
    732b11e02420:	c1 e8 0c             	shr    eax,0xc
    732b11e02423:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02428:	48 85 c0             	test   rax,rax
    732b11e0242b:	0f 84 99 0d 00 18    	je     0x732b29e031ca
    732b11e02431:	89 d9                	mov    ecx,ebx
    732b11e02433:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02439:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    732b11e0243d:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    732b11e02441:	b8 00 00 00 00       	mov    eax,0x0
    732b11e02446:	29 c3                	sub    ebx,eax
    732b11e02448:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e0244c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1042c
    732b11e02453:	2c 04 01 00 
    732b11e02457:	0f 84 ae 0d 00 18    	je     0x732b29e0320b
    732b11e0245d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1042c
    732b11e02464:	2c 04 01 00 
    732b11e02468:	0f 84 9d 0d 00 18    	je     0x732b29e0320b
    732b11e0246e:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e02472:	0f 85 d5 0d 00 18    	jne    0x732b29e0324d
    732b11e02478:	58                   	pop    rax
    732b11e02479:	e9 0f 00 00 00       	jmp    0x732b11e0248d
    732b11e0247e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e02485:	00 
    732b11e02486:	74 f0                	je     0x732b11e02478
    732b11e02488:	e9 e6 0c 00 18       	jmp    0x732b29e03173
    732b11e0248d:	50                   	push   rax
    732b11e0248e:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e02493:	c1 e0 10             	shl    eax,0x10
    732b11e02496:	b9 f0 12 00 00       	mov    ecx,0x12f0
    732b11e0249b:	09 c1                	or     ecx,eax
    732b11e0249d:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e024a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10430
    732b11e024a8:	30 04 01 00 
    732b11e024ac:	0f 84 cd 0d 00 18    	je     0x732b29e0327f
    732b11e024b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10430
    732b11e024b9:	30 04 01 00 
    732b11e024bd:	0f 84 bc 0d 00 18    	je     0x732b29e0327f
    732b11e024c3:	58                   	pop    rax
    732b11e024c4:	50                   	push   rax
    732b11e024c5:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e024c9:	f6 c1 03             	test   cl,0x3
    732b11e024cc:	0f 85 0d 0e 00 18    	jne    0x732b29e032df
    732b11e024d2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e024d9:	48 89 ca             	mov    rdx,rcx
    732b11e024dc:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e024e0:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e024e4:	48 85 c0             	test   rax,rax
    732b11e024e7:	0f 84 42 0e 00 18    	je     0x732b29e0332f
    732b11e024ed:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e024f3:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e024f6:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    732b11e024fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10434
    732b11e02501:	34 04 01 00 
    732b11e02505:	0f 84 5f 0e 00 18    	je     0x732b29e0336a
    732b11e0250b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10434
    732b11e02512:	34 04 01 00 
    732b11e02516:	0f 84 4e 0e 00 18    	je     0x732b29e0336a
    732b11e0251c:	58                   	pop    rax
    732b11e0251d:	50                   	push   rax
    732b11e0251e:	31 c0                	xor    eax,eax
    732b11e02520:	41 83 7d 28 05       	cmp    DWORD PTR [r13+0x28],0x5
    732b11e02525:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e0252c:	0f 92 c0             	setb   al
    732b11e0252f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    732b11e02536:	81 f9 36 04 01 00    	cmp    ecx,0x10436
    732b11e0253c:	0f 84 71 0e 00 18    	je     0x732b29e033b3
    732b11e02542:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10436
    732b11e02549:	36 04 01 00 
    732b11e0254d:	0f 84 60 0e 00 18    	je     0x732b29e033b3
    732b11e02553:	58                   	pop    rax
    732b11e02554:	50                   	push   rax
    732b11e02555:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e0255c:	00 
    732b11e0255d:	74 55                	je     0x732b11e025b4
    732b11e0255f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e02566:	01 
    732b11e02567:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    732b11e0256e:	38 04 01 00 
    732b11e02572:	0f 84 9b 0e 00 18    	je     0x732b29e03413
    732b11e02578:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    732b11e0257f:	38 04 01 00 
    732b11e02583:	0f 84 8a 0e 00 18    	je     0x732b29e03413
    732b11e02589:	b8 38 04 01 00       	mov    eax,0x10438
    732b11e0258e:	83 c0 0a             	add    eax,0xa
    732b11e02591:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e02598:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e0259f:	02 00 00 00 
    732b11e025a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b11e025aa:	06 00 00 00 
    732b11e025ae:	58                   	pop    rax
    732b11e025af:	e9 33 01 00 00       	jmp    0x732b11e026e7
    732b11e025b4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    732b11e025bb:	38 04 01 00 
    732b11e025bf:	0f 84 8a 0e 00 18    	je     0x732b29e0344f
    732b11e025c5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    732b11e025cc:	38 04 01 00 
    732b11e025d0:	0f 84 79 0e 00 18    	je     0x732b29e0344f
    732b11e025d6:	58                   	pop    rax
    732b11e025d7:	50                   	push   rax
    732b11e025d8:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    732b11e025df:	00 
    732b11e025e0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043a
    732b11e025e7:	3a 04 01 00 
    732b11e025eb:	0f 84 a7 0e 00 18    	je     0x732b29e03498
    732b11e025f1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043a
    732b11e025f8:	3a 04 01 00 
    732b11e025fc:	0f 84 96 0e 00 18    	je     0x732b29e03498
    732b11e02602:	58                   	pop    rax
    732b11e02603:	50                   	push   rax
    732b11e02604:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e02608:	f6 c3 03             	test   bl,0x3
    732b11e0260b:	0f 85 e7 0e 00 18    	jne    0x732b29e034f8
    732b11e02611:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e02618:	48 89 d8             	mov    rax,rbx
    732b11e0261b:	48 c1 e8 0c          	shr    rax,0xc
    732b11e0261f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02624:	48 85 c0             	test   rax,rax
    732b11e02627:	0f 84 1d 0f 00 18    	je     0x732b29e0354a
    732b11e0262d:	89 d9                	mov    ecx,ebx
    732b11e0262f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02635:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e02639:	89 de                	mov    esi,ebx
    732b11e0263b:	83 c6 04             	add    esi,0x4
    732b11e0263e:	89 f0                	mov    eax,esi
    732b11e02640:	c1 e8 0c             	shr    eax,0xc
    732b11e02643:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02648:	48 85 c0             	test   rax,rax
    732b11e0264b:	0f 84 36 0f 00 18    	je     0x732b29e03587
    732b11e02651:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e02657:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e0265a:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e0265d:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e02661:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e02668:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e0266c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043c
    732b11e02673:	3c 04 01 00 
    732b11e02677:	0f 84 46 0f 00 18    	je     0x732b29e035c3
    732b11e0267d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043c
    732b11e02684:	3c 04 01 00 
    732b11e02688:	0f 84 35 0f 00 18    	je     0x732b29e035c3
    732b11e0268e:	58                   	pop    rax
    732b11e0268f:	50                   	push   rax
    732b11e02690:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e02697:	a8 01                	test   al,0x1
    732b11e02699:	0f 85 6d 0f 00 18    	jne    0x732b29e0360c
    732b11e0269f:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e026a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e026ad:	01 
    732b11e026ae:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10440
    732b11e026b5:	40 04 01 00 
    732b11e026b9:	0f 84 83 0f 00 18    	je     0x732b29e03642
    732b11e026bf:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10440
    732b11e026c6:	40 04 01 00 
    732b11e026ca:	0f 84 72 0f 00 18    	je     0x732b29e03642
    732b11e026d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e026d7:	02 00 00 00 
    732b11e026db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b11e026e2:	09 00 00 00 
    732b11e026e6:	58                   	pop    rax
    732b11e026e7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e026ee:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e026f5:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e026fc:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e02703:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e0270a:	39 f1                	cmp    ecx,esi
    732b11e0270c:	0f 83 5d 0f 00 18    	jae    0x732b29e0366f
    732b11e02712:	81 fa 28 04 01 00    	cmp    edx,0x10428
    732b11e02718:	75 14                	jne    0x732b11e0272e
    732b11e0271a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02721:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02728:	00 
    732b11e02729:	e9 52 fc ff ff       	jmp    0x732b11e02380
    732b11e0272e:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e02735:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e0273b:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e0273e:	0f 85 2b 0f 00 18    	jne    0x732b29e0366f
    732b11e02744:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e0274b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02752:	00 
    732b11e02753:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e02758:	ff e0                	jmp    rax
