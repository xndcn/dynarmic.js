
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65772-1-126629223352848.bin:     file format binary


Disassembly of section .data:

0000732b29e04a10 <.data>:
    732b29e04a10:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e04a16:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e04a19:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e04a1f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e04a26:	0f 87 a5 eb ff e7    	ja     0x732b11e035d1
    732b29e04a2c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x9
    732b29e04a33:	09 00 00 00 
    732b29e04a37:	e9 95 eb ff e7       	jmp    0x732b11e035d1
    732b29e04a3c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    732b29e04a43:	ec 00 01 00 
    732b29e04a47:	b8 ec 00 01 00       	mov    eax,0x100ec
    732b29e04a4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04a53:	02 00 00 00 
    732b29e04a57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e04a5e:	01 00 00 00 
    732b29e04a62:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04a65:	be ec 00 01 00       	mov    esi,0x100ec
    732b29e04a6a:	4c 89 ef             	mov    rdi,r13
    732b29e04a6d:	e8 ee b6 ff e7       	call   0x732b11e00160
    732b29e04a72:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04a79:	00 
    732b29e04a7a:	0f 84 83 eb ff e7    	je     0x732b11e03603
    732b29e04a80:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04a87:	02 00 00 00 
    732b29e04a8b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e04a92:	01 00 00 00 
    732b29e04a96:	58                   	pop    rax
    732b29e04a97:	e9 bc f0 ff e7       	jmp    0x732b11e03b58
    732b29e04a9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ee
    732b29e04aa3:	ee 00 01 00 
    732b29e04aa7:	b8 ee 00 01 00       	mov    eax,0x100ee
    732b29e04aac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04ab3:	02 00 00 00 
    732b29e04ab7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e04abe:	02 00 00 00 
    732b29e04ac2:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04ac5:	be ee 00 01 00       	mov    esi,0x100ee
    732b29e04aca:	4c 89 ef             	mov    rdi,r13
    732b29e04acd:	e8 8e b6 ff e7       	call   0x732b11e00160
    732b29e04ad2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04ad9:	00 
    732b29e04ada:	0f 84 a9 eb ff e7    	je     0x732b11e03689
    732b29e04ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04ae7:	02 00 00 00 
    732b29e04aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e04af2:	02 00 00 00 
    732b29e04af6:	58                   	pop    rax
    732b29e04af7:	e9 5c f0 ff e7       	jmp    0x732b11e03b58
    732b29e04afc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f0
    732b29e04b03:	f0 00 01 00 
    732b29e04b07:	b8 f0 00 01 00       	mov    eax,0x100f0
    732b29e04b0c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04b13:	04 00 00 00 
    732b29e04b17:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e04b1e:	03 00 00 00 
    732b29e04b22:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e04b25:	be f0 00 01 00       	mov    esi,0x100f0
    732b29e04b2a:	4c 89 ef             	mov    rdi,r13
    732b29e04b2d:	e8 2e b6 ff e7       	call   0x732b11e00160
    732b29e04b32:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04b39:	00 
    732b29e04b3a:	0f 84 a7 eb ff e7    	je     0x732b11e036e7
    732b29e04b40:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04b47:	04 00 00 00 
    732b29e04b4b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e04b52:	03 00 00 00 
    732b29e04b56:	58                   	pop    rax
    732b29e04b57:	e9 fc ef ff e7       	jmp    0x732b11e03b58
    732b29e04b5c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f4
    732b29e04b63:	f4 00 01 00 
    732b29e04b67:	b8 f4 00 01 00       	mov    eax,0x100f4
    732b29e04b6c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04b73:	02 00 00 00 
    732b29e04b77:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e04b7e:	04 00 00 00 
    732b29e04b82:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04b85:	be f4 00 01 00       	mov    esi,0x100f4
    732b29e04b8a:	4c 89 ef             	mov    rdi,r13
    732b29e04b8d:	e8 ce b5 ff e7       	call   0x732b11e00160
    732b29e04b92:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04b99:	00 
    732b29e04b9a:	0f 84 a5 eb ff e7    	je     0x732b11e03745
    732b29e04ba0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04ba7:	02 00 00 00 
    732b29e04bab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e04bb2:	04 00 00 00 
    732b29e04bb6:	58                   	pop    rax
    732b29e04bb7:	e9 9c ef ff e7       	jmp    0x732b11e03b58
    732b29e04bbc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f6
    732b29e04bc3:	f6 00 01 00 
    732b29e04bc7:	b8 f6 00 01 00       	mov    eax,0x100f6
    732b29e04bcc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04bd3:	04 00 00 00 
    732b29e04bd7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e04bde:	05 00 00 00 
    732b29e04be2:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e04be5:	be f6 00 01 00       	mov    esi,0x100f6
    732b29e04bea:	4c 89 ef             	mov    rdi,r13
    732b29e04bed:	e8 6e b5 ff e7       	call   0x732b11e00160
    732b29e04bf2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04bf9:	00 
    732b29e04bfa:	0f 84 9b eb ff e7    	je     0x732b11e0379b
    732b29e04c00:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04c07:	04 00 00 00 
    732b29e04c0b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e04c12:	05 00 00 00 
    732b29e04c16:	58                   	pop    rax
    732b29e04c17:	e9 3c ef ff e7       	jmp    0x732b11e03b58
    732b29e04c1c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fa
    732b29e04c23:	fa 00 01 00 
    732b29e04c27:	b8 fa 00 01 00       	mov    eax,0x100fa
    732b29e04c2c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04c33:	02 00 00 00 
    732b29e04c37:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e04c3e:	06 00 00 00 
    732b29e04c42:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04c45:	be fa 00 01 00       	mov    esi,0x100fa
    732b29e04c4a:	4c 89 ef             	mov    rdi,r13
    732b29e04c4d:	e8 0e b5 ff e7       	call   0x732b11e00160
    732b29e04c52:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04c59:	00 
    732b29e04c5a:	0f 84 95 eb ff e7    	je     0x732b11e037f5
    732b29e04c60:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04c67:	02 00 00 00 
    732b29e04c6b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e04c72:	06 00 00 00 
    732b29e04c76:	58                   	pop    rax
    732b29e04c77:	e9 dc ee ff e7       	jmp    0x732b11e03b58
    732b29e04c7c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fc
    732b29e04c83:	fc 00 01 00 
    732b29e04c87:	b8 fc 00 01 00       	mov    eax,0x100fc
    732b29e04c8c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04c93:	02 00 00 00 
    732b29e04c97:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e04c9e:	07 00 00 00 
    732b29e04ca2:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04ca5:	be fc 00 01 00       	mov    esi,0x100fc
    732b29e04caa:	4c 89 ef             	mov    rdi,r13
    732b29e04cad:	e8 ae b4 ff e7       	call   0x732b11e00160
    732b29e04cb2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04cb9:	00 
    732b29e04cba:	0f 84 b0 eb ff e7    	je     0x732b11e03870
    732b29e04cc0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04cc7:	02 00 00 00 
    732b29e04ccb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e04cd2:	07 00 00 00 
    732b29e04cd6:	58                   	pop    rax
    732b29e04cd7:	e9 7c ee ff e7       	jmp    0x732b11e03b58
    732b29e04cdc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fe
    732b29e04ce3:	fe 00 01 00 
    732b29e04ce7:	b8 fe 00 01 00       	mov    eax,0x100fe
    732b29e04cec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04cf3:	02 00 00 00 
    732b29e04cf7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e04cfe:	08 00 00 00 
    732b29e04d02:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04d05:	be fe 00 01 00       	mov    esi,0x100fe
    732b29e04d0a:	4c 89 ef             	mov    rdi,r13
    732b29e04d0d:	e8 4e b4 ff e7       	call   0x732b11e00160
    732b29e04d12:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04d19:	00 
    732b29e04d1a:	0f 84 ae eb ff e7    	je     0x732b11e038ce
    732b29e04d20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04d27:	02 00 00 00 
    732b29e04d2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e04d32:	08 00 00 00 
    732b29e04d36:	58                   	pop    rax
    732b29e04d37:	e9 1c ee ff e7       	jmp    0x732b11e03b58
    732b29e04d3c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10100
    732b29e04d43:	00 01 01 00 
    732b29e04d47:	b8 00 01 01 00       	mov    eax,0x10100
    732b29e04d4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04d53:	02 00 00 00 
    732b29e04d57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e04d5e:	09 00 00 00 
    732b29e04d62:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04d65:	be 00 01 01 00       	mov    esi,0x10100
    732b29e04d6a:	4c 89 ef             	mov    rdi,r13
    732b29e04d6d:	e8 ee b3 ff e7       	call   0x732b11e00160
    732b29e04d72:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04d79:	00 
    732b29e04d7a:	0f 84 b5 eb ff e7    	je     0x732b11e03935
    732b29e04d80:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04d87:	02 00 00 00 
    732b29e04d8b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e04d92:	09 00 00 00 
    732b29e04d96:	58                   	pop    rax
    732b29e04d97:	e9 bc ed ff e7       	jmp    0x732b11e03b58
    732b29e04d9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10102
    732b29e04da3:	02 01 01 00 
    732b29e04da7:	b8 02 01 01 00       	mov    eax,0x10102
    732b29e04dac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04db3:	02 00 00 00 
    732b29e04db7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e04dbe:	0a 00 00 00 
    732b29e04dc2:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04dc5:	be 02 01 01 00       	mov    esi,0x10102
    732b29e04dca:	4c 89 ef             	mov    rdi,r13
    732b29e04dcd:	e8 8e b3 ff e7       	call   0x732b11e00160
    732b29e04dd2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04dd9:	00 
    732b29e04dda:	0f 84 83 eb ff e7    	je     0x732b11e03963
    732b29e04de0:	e9 bd eb ff e7       	jmp    0x732b11e039a2
    732b29e04de5:	b8 02 01 01 00       	mov    eax,0x10102
    732b29e04dea:	83 c0 ea             	add    eax,0xffffffea
    732b29e04ded:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e04df4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04dfb:	02 00 00 00 
    732b29e04dff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e04e06:	0a 00 00 00 
    732b29e04e0a:	be 02 01 01 00       	mov    esi,0x10102
    732b29e04e0f:	ba 02 01 01 00       	mov    edx,0x10102
    732b29e04e14:	4c 89 ef             	mov    rdi,r13
    732b29e04e17:	e8 44 b3 ff e7       	call   0x732b11e00160
    732b29e04e1c:	e9 72 eb ff e7       	jmp    0x732b11e03993
    732b29e04e21:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04e28:	04 01 01 00 
    732b29e04e2c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04e33:	04 00 00 00 
    732b29e04e37:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e04e3e:	0b 00 00 00 
    732b29e04e42:	ba 04 01 01 00       	mov    edx,0x10104
    732b29e04e47:	4c 89 ef             	mov    rdi,r13
    732b29e04e4a:	4c 89 f6             	mov    rsi,r14
    732b29e04e4d:	89 d9                	mov    ecx,ebx
    732b29e04e4f:	45 31 c0             	xor    r8d,r8d
    732b29e04e52:	e8 29 b2 ff e7       	call   0x732b11e00080
    732b29e04e57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04e5e:	04 00 00 00 
    732b29e04e62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e04e69:	0b 00 00 00 
    732b29e04e6d:	58                   	pop    rax
    732b29e04e6e:	e9 e5 ec ff e7       	jmp    0x732b11e03b58
    732b29e04e73:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04e7a:	04 01 01 00 
    732b29e04e7e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04e85:	04 00 00 00 
    732b29e04e89:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e04e90:	0b 00 00 00 
    732b29e04e94:	4c 89 f7             	mov    rdi,r14
    732b29e04e97:	89 de                	mov    esi,ebx
    732b29e04e99:	e8 a2 b1 ff e7       	call   0x732b11e00040
    732b29e04e9e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04ea5:	00 
    732b29e04ea6:	75 af                	jne    0x732b29e04e57
    732b29e04ea8:	41 89 c7             	mov    r15d,eax
    732b29e04eab:	e9 44 eb ff e7       	jmp    0x732b11e039f4
    732b29e04eb0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04eb7:	04 01 01 00 
    732b29e04ebb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04ec2:	04 00 00 00 
    732b29e04ec6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e04ecd:	0b 00 00 00 
    732b29e04ed1:	4c 89 f7             	mov    rdi,r14
    732b29e04ed4:	e8 67 b1 ff e7       	call   0x732b11e00040
    732b29e04ed9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04ee0:	00 
    732b29e04ee1:	0f 84 2e eb ff e7    	je     0x732b11e03a15
    732b29e04ee7:	e9 6b ff ff ff       	jmp    0x732b29e04e57
    732b29e04eec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04ef3:	04 01 01 00 
    732b29e04ef7:	b8 04 01 01 00       	mov    eax,0x10104
    732b29e04efc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04f03:	04 00 00 00 
    732b29e04f07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e04f0e:	0b 00 00 00 
    732b29e04f12:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e04f15:	be 04 01 01 00       	mov    esi,0x10104
    732b29e04f1a:	4c 89 ef             	mov    rdi,r13
    732b29e04f1d:	e8 3e b2 ff e7       	call   0x732b11e00160
    732b29e04f22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04f29:	00 
    732b29e04f2a:	0f 84 19 eb ff e7    	je     0x732b11e03a49
    732b29e04f30:	e9 22 ff ff ff       	jmp    0x732b29e04e57
    732b29e04f35:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10108
    732b29e04f3c:	08 01 01 00 
    732b29e04f40:	b8 08 01 01 00       	mov    eax,0x10108
    732b29e04f45:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04f4c:	02 00 00 00 
    732b29e04f50:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e04f57:	0c 00 00 00 
    732b29e04f5b:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04f5e:	be 08 01 01 00       	mov    esi,0x10108
    732b29e04f63:	4c 89 ef             	mov    rdi,r13
    732b29e04f66:	e8 f5 b1 ff e7       	call   0x732b11e00160
    732b29e04f6b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04f72:	00 
    732b29e04f73:	0f 84 fe ea ff e7    	je     0x732b11e03a77
    732b29e04f79:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04f80:	02 00 00 00 
    732b29e04f84:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e04f8b:	0c 00 00 00 
    732b29e04f8f:	58                   	pop    rax
    732b29e04f90:	e9 c3 eb ff e7       	jmp    0x732b11e03b58
    732b29e04f95:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e04f9c:	0a 01 01 00 
    732b29e04fa0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04fa7:	02 00 00 00 
    732b29e04fab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e04fb2:	0d 00 00 00 
    732b29e04fb6:	ba 0a 01 01 00       	mov    edx,0x1010a
    732b29e04fbb:	4c 89 ef             	mov    rdi,r13
    732b29e04fbe:	4c 89 f6             	mov    rsi,r14
    732b29e04fc1:	89 d9                	mov    ecx,ebx
    732b29e04fc3:	45 31 c0             	xor    r8d,r8d
    732b29e04fc6:	e8 b5 b0 ff e7       	call   0x732b11e00080
    732b29e04fcb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04fd2:	02 00 00 00 
    732b29e04fd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e04fdd:	0d 00 00 00 
    732b29e04fe1:	58                   	pop    rax
    732b29e04fe2:	e9 71 eb ff e7       	jmp    0x732b11e03b58
    732b29e04fe7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e04fee:	0a 01 01 00 
    732b29e04ff2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04ff9:	02 00 00 00 
    732b29e04ffd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e05004:	0d 00 00 00 
    732b29e05008:	4c 89 f7             	mov    rdi,r14
    732b29e0500b:	89 de                	mov    esi,ebx
    732b29e0500d:	e8 2e b0 ff e7       	call   0x732b11e00040
    732b29e05012:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05019:	00 
    732b29e0501a:	0f 84 8d ea ff e7    	je     0x732b11e03aad
    732b29e05020:	eb a9                	jmp    0x732b29e04fcb
    732b29e05022:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e05029:	0a 01 01 00 
    732b29e0502d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05034:	02 00 00 00 
    732b29e05038:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e0503f:	0d 00 00 00 
    732b29e05043:	4c 89 f7             	mov    rdi,r14
    732b29e05046:	e8 f5 af ff e7       	call   0x732b11e00040
    732b29e0504b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05052:	00 
    732b29e05053:	0f 84 79 ea ff e7    	je     0x732b11e03ad2
    732b29e05059:	e9 6d ff ff ff       	jmp    0x732b29e04fcb
    732b29e0505e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e05065:	0a 01 01 00 
    732b29e05069:	b8 0a 01 01 00       	mov    eax,0x1010a
    732b29e0506e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05075:	02 00 00 00 
    732b29e05079:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e05080:	0d 00 00 00 
    732b29e05084:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05087:	be 0a 01 01 00       	mov    esi,0x1010a
    732b29e0508c:	4c 89 ef             	mov    rdi,r13
    732b29e0508f:	e8 cc b0 ff e7       	call   0x732b11e00160
    732b29e05094:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0509b:	00 
    732b29e0509c:	0f 84 5d ea ff e7    	je     0x732b11e03aff
    732b29e050a2:	e9 24 ff ff ff       	jmp    0x732b29e04fcb
    732b29e050a7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010c
    732b29e050ae:	0c 01 01 00 
    732b29e050b2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e050b9:	02 00 00 00 
    732b29e050bd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e050c4:	0e 00 00 00 
    732b29e050c8:	4c 89 ef             	mov    rdi,r13
    732b29e050cb:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e050d0:	4c 89 f2             	mov    rdx,r14
    732b29e050d3:	e8 b8 af ff e7       	call   0x732b11e00090
    732b29e050d8:	e9 64 ea ff e7       	jmp    0x732b11e03b41
    732b29e050dd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e050e4:	02 00 00 00 
    732b29e050e8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e050ef:	0e 00 00 00 
    732b29e050f3:	be 0c 01 01 00       	mov    esi,0x1010c
    732b29e050f8:	ba 0c 01 01 00       	mov    edx,0x1010c
    732b29e050fd:	4c 89 ef             	mov    rdi,r13
    732b29e05100:	e8 5b b0 ff e7       	call   0x732b11e00160
    732b29e05105:	e9 37 ea ff e7       	jmp    0x732b11e03b41
    732b29e0510a:	c2 08 00             	ret    0x8
