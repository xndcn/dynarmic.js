
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65668-1-126629223357504.bin:     file format binary


Disassembly of section .data:

0000732b29e05c40 <.data>:
    732b29e05c40:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    732b29e05c47:	84 00 01 00 
    732b29e05c4b:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    732b29e05c52:	01 
    732b29e05c53:	c2 08 00             	ret    0x8
    732b29e05c56:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e05c5c:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e05c5f:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e05c65:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e05c6c:	0f 87 b8 f0 ff e7    	ja     0x732b11e04d2a
    732b29e05c72:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xb
    732b29e05c79:	0b 00 00 00 
    732b29e05c7d:	e9 a8 f0 ff e7       	jmp    0x732b11e04d2a
    732b29e05c82:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    732b29e05c89:	84 00 01 00 
    732b29e05c8d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e05c94:	08 00 00 00 
    732b29e05c98:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05c9f:	01 00 00 00 
    732b29e05ca3:	ba 84 00 01 00       	mov    edx,0x10084
    732b29e05ca8:	4c 89 ef             	mov    rdi,r13
    732b29e05cab:	4c 89 f6             	mov    rsi,r14
    732b29e05cae:	45 31 c0             	xor    r8d,r8d
    732b29e05cb1:	e8 ca a3 ff e7       	call   0x732b11e00080
    732b29e05cb6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e05cbd:	08 00 00 00 
    732b29e05cc1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05cc8:	01 00 00 00 
    732b29e05ccc:	58                   	pop    rax
    732b29e05ccd:	e9 9c f1 ff e7       	jmp    0x732b11e04e6e
    732b29e05cd2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    732b29e05cd9:	84 00 01 00 
    732b29e05cdd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e05ce4:	08 00 00 00 
    732b29e05ce8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05cef:	01 00 00 00 
    732b29e05cf3:	4c 89 f7             	mov    rdi,r14
    732b29e05cf6:	89 ce                	mov    esi,ecx
    732b29e05cf8:	e8 43 a3 ff e7       	call   0x732b11e00040
    732b29e05cfd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05d04:	00 
    732b29e05d05:	0f 84 51 f0 ff e7    	je     0x732b11e04d5c
    732b29e05d0b:	eb a9                	jmp    0x732b29e05cb6
    732b29e05d0d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e05d14:	8c 00 01 00 
    732b29e05d18:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05d1f:	02 00 00 00 
    732b29e05d23:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05d2a:	02 00 00 00 
    732b29e05d2e:	ba 8c 00 01 00       	mov    edx,0x1008c
    732b29e05d33:	4c 89 ef             	mov    rdi,r13
    732b29e05d36:	4c 89 f6             	mov    rsi,r14
    732b29e05d39:	45 31 c0             	xor    r8d,r8d
    732b29e05d3c:	e8 3f a3 ff e7       	call   0x732b11e00080
    732b29e05d41:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05d48:	02 00 00 00 
    732b29e05d4c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05d53:	02 00 00 00 
    732b29e05d57:	58                   	pop    rax
    732b29e05d58:	e9 11 f1 ff e7       	jmp    0x732b11e04e6e
    732b29e05d5d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e05d64:	8c 00 01 00 
    732b29e05d68:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05d6f:	02 00 00 00 
    732b29e05d73:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05d7a:	02 00 00 00 
    732b29e05d7e:	4c 89 f7             	mov    rdi,r14
    732b29e05d81:	89 ce                	mov    esi,ecx
    732b29e05d83:	e8 b8 a2 ff e7       	call   0x732b11e00040
    732b29e05d88:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05d8f:	00 
    732b29e05d90:	0f 84 19 f0 ff e7    	je     0x732b11e04daf
    732b29e05d96:	eb a9                	jmp    0x732b29e05d41
    732b29e05d98:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e05d9f:	8c 00 01 00 
    732b29e05da3:	b8 8c 00 01 00       	mov    eax,0x1008c
    732b29e05da8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05daf:	02 00 00 00 
    732b29e05db3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05dba:	02 00 00 00 
    732b29e05dbe:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05dc1:	be 8c 00 01 00       	mov    esi,0x1008c
    732b29e05dc6:	4c 89 ef             	mov    rdi,r13
    732b29e05dc9:	e8 92 a3 ff e7       	call   0x732b11e00160
    732b29e05dce:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05dd5:	00 
    732b29e05dd6:	0f 84 f9 ef ff e7    	je     0x732b11e04dd5
    732b29e05ddc:	e9 60 ff ff ff       	jmp    0x732b29e05d41
    732b29e05de1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e05de8:	28 03 01 00 
    732b29e05dec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05df3:	04 00 00 00 
    732b29e05df7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05dfe:	03 00 00 00 
    732b29e05e02:	be 8e 00 01 00       	mov    esi,0x1008e
    732b29e05e07:	ba 8e 00 01 00       	mov    edx,0x1008e
    732b29e05e0c:	4c 89 ef             	mov    rdi,r13
    732b29e05e0f:	e8 4c a3 ff e7       	call   0x732b11e00160
    732b29e05e14:	e9 33 f0 ff e7       	jmp    0x732b11e04e4c
    732b29e05e19:	c2 08 00             	ret    0x8
