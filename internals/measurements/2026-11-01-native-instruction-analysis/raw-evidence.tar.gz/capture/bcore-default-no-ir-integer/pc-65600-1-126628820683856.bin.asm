
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65600-1-126628820683856.bin:     file format binary


Disassembly of section .data:

0000732b11e00c50 <.data>:
    732b11e00c50:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e00c57:	3d 00 00 00 00       	cmp    eax,0x0
    732b11e00c5c:	0f 95 c2             	setne  dl
    732b11e00c5f:	b9 40 00 01 00       	mov    ecx,0x10040
    732b11e00c64:	29 c8                	sub    eax,ecx
    732b11e00c66:	3d 4e 00 00 00       	cmp    eax,0x4e
    732b11e00c6b:	0f 96 c3             	setbe  bl
    732b11e00c6e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    732b11e00c75:	81 fe 00 00 00 00    	cmp    esi,0x0
    732b11e00c7b:	0f 94 c0             	sete   al
    732b11e00c7e:	29 ce                	sub    esi,ecx
    732b11e00c80:	81 fe 4e 00 00 00    	cmp    esi,0x4e
    732b11e00c86:	0f 97 c1             	seta   cl
    732b11e00c89:	84 da                	test   dl,bl
    732b11e00c8b:	0f 85 2f 01 00 18    	jne    0x732b29e00dc0
    732b11e00c91:	08 c8                	or     al,cl
    732b11e00c93:	0f 84 27 01 00 18    	je     0x732b29e00dc0
    732b11e00c99:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e00ca0:	8b 88 08 00 10 00    	mov    ecx,DWORD PTR [rax+0x100008]
    732b11e00ca6:	ff c1                	inc    ecx
    732b11e00ca8:	89 88 08 00 10 00    	mov    DWORD PTR [rax+0x100008],ecx
    732b11e00cae:	81 f9 14 cd 00 00    	cmp    ecx,0xcd14
    732b11e00cb4:	0f 84 1c 01 00 18    	je     0x732b29e00dd6
    732b11e00cba:	50                   	push   rax
    732b11e00cbb:	41 c7 45 28 01 3c 00 	mov    DWORD PTR [r13+0x28],0x3c01
    732b11e00cc2:	00 
    732b11e00cc3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10040
    732b11e00cca:	40 00 01 00 
    732b11e00cce:	0f 84 2e 01 00 18    	je     0x732b29e00e02
    732b11e00cd4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10040
    732b11e00cdb:	40 00 01 00 
    732b11e00cdf:	0f 84 1d 01 00 18    	je     0x732b29e00e02
    732b11e00ce5:	58                   	pop    rax
    732b11e00ce6:	50                   	push   rax
    732b11e00ce7:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    732b11e00cec:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10044
    732b11e00cf3:	44 00 01 00 
    732b11e00cf7:	0f 84 65 01 00 18    	je     0x732b29e00e62
    732b11e00cfd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10044
    732b11e00d04:	44 00 01 00 
    732b11e00d08:	0f 84 54 01 00 18    	je     0x732b29e00e62
    732b11e00d0e:	58                   	pop    rax
    732b11e00d0f:	50                   	push   rax
    732b11e00d10:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e00d14:	f6 c1 03             	test   cl,0x3
    732b11e00d17:	0f 85 a5 01 00 18    	jne    0x732b29e00ec2
    732b11e00d1d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00d24:	48 89 ca             	mov    rdx,rcx
    732b11e00d27:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e00d2b:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e00d2f:	48 85 c0             	test   rax,rax
    732b11e00d32:	0f 84 da 01 00 18    	je     0x732b29e00f12
    732b11e00d38:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00d3e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e00d41:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    732b11e00d45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10046
    732b11e00d4c:	46 00 01 00 
    732b11e00d50:	0f 84 f7 01 00 18    	je     0x732b29e00f4d
    732b11e00d56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10046
    732b11e00d5d:	46 00 01 00 
    732b11e00d61:	0f 84 e6 01 00 18    	je     0x732b29e00f4d
    732b11e00d67:	58                   	pop    rax
    732b11e00d68:	50                   	push   rax
    732b11e00d69:	41 83 45 28 04       	add    DWORD PTR [r13+0x28],0x4
    732b11e00d6e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10048
    732b11e00d75:	48 00 01 00 
    732b11e00d79:	0f 84 17 02 00 18    	je     0x732b29e00f96
    732b11e00d7f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10048
    732b11e00d86:	48 00 01 00 
    732b11e00d8a:	0f 84 06 02 00 18    	je     0x732b29e00f96
    732b11e00d90:	58                   	pop    rax
    732b11e00d91:	50                   	push   rax
    732b11e00d92:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e00d96:	f6 c1 03             	test   cl,0x3
    732b11e00d99:	0f 85 57 02 00 18    	jne    0x732b29e00ff6
    732b11e00d9f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00da6:	48 89 ca             	mov    rdx,rcx
    732b11e00da9:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e00dad:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e00db1:	48 85 c0             	test   rax,rax
    732b11e00db4:	0f 84 8c 02 00 18    	je     0x732b29e01046
    732b11e00dba:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00dc0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e00dc3:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    732b11e00dc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004a
    732b11e00dce:	4a 00 01 00 
    732b11e00dd2:	0f 84 a9 02 00 18    	je     0x732b29e01081
    732b11e00dd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004a
    732b11e00ddf:	4a 00 01 00 
    732b11e00de3:	0f 84 98 02 00 18    	je     0x732b29e01081
    732b11e00de9:	58                   	pop    rax
    732b11e00dea:	50                   	push   rax
    732b11e00deb:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    732b11e00df2:	00 
    732b11e00df3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004c
    732b11e00dfa:	4c 00 01 00 
    732b11e00dfe:	0f 84 c6 02 00 18    	je     0x732b29e010ca
    732b11e00e04:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004c
    732b11e00e0b:	4c 00 01 00 
    732b11e00e0f:	0f 84 b5 02 00 18    	je     0x732b29e010ca
    732b11e00e15:	58                   	pop    rax
    732b11e00e16:	50                   	push   rax
    732b11e00e17:	41 c7 45 2c 05 3c 00 	mov    DWORD PTR [r13+0x2c],0x3c05
    732b11e00e1e:	00 
    732b11e00e1f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004e
    732b11e00e26:	4e 00 01 00 
    732b11e00e2a:	0f 84 fa 02 00 18    	je     0x732b29e0112a
    732b11e00e30:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004e
    732b11e00e37:	4e 00 01 00 
    732b11e00e3b:	0f 84 e9 02 00 18    	je     0x732b29e0112a
    732b11e00e41:	58                   	pop    rax
    732b11e00e42:	50                   	push   rax
    732b11e00e43:	41 c1 65 2c 02       	shl    DWORD PTR [r13+0x2c],0x2
    732b11e00e48:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10052
    732b11e00e4f:	52 00 01 00 
    732b11e00e53:	0f 84 31 03 00 18    	je     0x732b29e0118a
    732b11e00e59:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10052
    732b11e00e60:	52 00 01 00 
    732b11e00e64:	0f 84 20 03 00 18    	je     0x732b29e0118a
    732b11e00e6a:	58                   	pop    rax
    732b11e00e6b:	50                   	push   rax
    732b11e00e6c:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e00e70:	8d 48 fc             	lea    ecx,[rax-0x4]
    732b11e00e73:	a8 03                	test   al,0x3
    732b11e00e75:	0f 85 6f 03 00 18    	jne    0x732b29e011ea
    732b11e00e7b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e00e82:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    732b11e00e86:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00e8d:	89 ce                	mov    esi,ecx
    732b11e00e8f:	c1 ee 0c             	shr    esi,0xc
    732b11e00e92:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e00e96:	48 85 c0             	test   rax,rax
    732b11e00e99:	0f 84 9e 03 00 18    	je     0x732b29e0123d
    732b11e00e9f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00ea5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e00ea8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10054
    732b11e00eaf:	54 00 01 00 
    732b11e00eb3:	0f 84 bf 03 00 18    	je     0x732b29e01278
    732b11e00eb9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10054
    732b11e00ec0:	54 00 01 00 
    732b11e00ec4:	0f 84 ae 03 00 18    	je     0x732b29e01278
    732b11e00eca:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e00ecd:	0f 85 e6 03 00 18    	jne    0x732b29e012b9
    732b11e00ed3:	58                   	pop    rax
    732b11e00ed4:	e9 0f 00 00 00       	jmp    0x732b11e00ee8
    732b11e00ed9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e00ee0:	00 
    732b11e00ee1:	74 f0                	je     0x732b11e00ed3
    732b11e00ee3:	e9 39 03 00 18       	jmp    0x732b29e01221
    732b11e00ee8:	50                   	push   rax
    732b11e00ee9:	41 c7 45 28 03 3c 00 	mov    DWORD PTR [r13+0x28],0x3c03
    732b11e00ef0:	00 
    732b11e00ef1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10056
    732b11e00ef8:	56 00 01 00 
    732b11e00efc:	0f 84 e9 03 00 18    	je     0x732b29e012eb
    732b11e00f02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10056
    732b11e00f09:	56 00 01 00 
    732b11e00f0d:	0f 84 d8 03 00 18    	je     0x732b29e012eb
    732b11e00f13:	58                   	pop    rax
    732b11e00f14:	50                   	push   rax
    732b11e00f15:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    732b11e00f1a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005a
    732b11e00f21:	5a 00 01 00 
    732b11e00f25:	0f 84 20 04 00 18    	je     0x732b29e0134b
    732b11e00f2b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005a
    732b11e00f32:	5a 00 01 00 
    732b11e00f36:	0f 84 0f 04 00 18    	je     0x732b29e0134b
    732b11e00f3c:	58                   	pop    rax
    732b11e00f3d:	50                   	push   rax
    732b11e00f3e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e00f42:	f6 c1 03             	test   cl,0x3
    732b11e00f45:	0f 85 60 04 00 18    	jne    0x732b29e013ab
    732b11e00f4b:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e00f52:	48 89 ca             	mov    rdx,rcx
    732b11e00f55:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e00f59:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e00f5d:	48 85 c0             	test   rax,rax
    732b11e00f60:	0f 84 95 04 00 18    	je     0x732b29e013fb
    732b11e00f66:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e00f6c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e00f6f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    732b11e00f73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005c
    732b11e00f7a:	5c 00 01 00 
    732b11e00f7e:	0f 84 b2 04 00 18    	je     0x732b29e01436
    732b11e00f84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005c
    732b11e00f8b:	5c 00 01 00 
    732b11e00f8f:	0f 84 a1 04 00 18    	je     0x732b29e01436
    732b11e00f95:	58                   	pop    rax
    732b11e00f96:	50                   	push   rax
    732b11e00f97:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    732b11e00f9c:	b9 00 00 00 00       	mov    ecx,0x0
    732b11e00fa1:	09 c1                	or     ecx,eax
    732b11e00fa3:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    732b11e00fa7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005e
    732b11e00fae:	5e 00 01 00 
    732b11e00fb2:	0f 84 c7 04 00 18    	je     0x732b29e0147f
    732b11e00fb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005e
    732b11e00fbf:	5e 00 01 00 
    732b11e00fc3:	0f 84 b6 04 00 18    	je     0x732b29e0147f
    732b11e00fc9:	58                   	pop    rax
    732b11e00fca:	50                   	push   rax
    732b11e00fcb:	41 0f b7 45 30       	movzx  eax,WORD PTR [r13+0x30]
    732b11e00fd0:	b9 00 00 00 01       	mov    ecx,0x1000000
    732b11e00fd5:	09 c1                	or     ecx,eax
    732b11e00fd7:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    732b11e00fdb:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10062
    732b11e00fe2:	62 00 01 00 
    732b11e00fe6:	0f 84 f3 04 00 18    	je     0x732b29e014df
    732b11e00fec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10062
    732b11e00ff3:	62 00 01 00 
    732b11e00ff7:	0f 84 e2 04 00 18    	je     0x732b29e014df
    732b11e00ffd:	58                   	pop    rax
    732b11e00ffe:	50                   	push   rax
    732b11e00fff:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    732b11e01004:	c1 e0 10             	shl    eax,0x10
    732b11e01007:	b9 18 f0 00 00       	mov    ecx,0xf018
    732b11e0100c:	09 c1                	or     ecx,eax
    732b11e0100e:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    732b11e01012:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10066
    732b11e01019:	66 00 01 00 
    732b11e0101d:	0f 84 1c 05 00 18    	je     0x732b29e0153f
    732b11e01023:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10066
    732b11e0102a:	66 00 01 00 
    732b11e0102e:	0f 84 0b 05 00 18    	je     0x732b29e0153f
    732b11e01034:	58                   	pop    rax
    732b11e01035:	50                   	push   rax
    732b11e01036:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e0103a:	8d 48 f8             	lea    ecx,[rax-0x8]
    732b11e0103d:	a8 03                	test   al,0x3
    732b11e0103f:	0f 85 5a 05 00 18    	jne    0x732b29e0159f
    732b11e01045:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e0104c:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    732b11e01050:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01057:	89 ce                	mov    esi,ecx
    732b11e01059:	c1 ee 0c             	shr    esi,0xc
    732b11e0105c:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e01060:	48 85 c0             	test   rax,rax
    732b11e01063:	0f 84 89 05 00 18    	je     0x732b29e015f2
    732b11e01069:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0106f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01072:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006a
    732b11e01079:	6a 00 01 00 
    732b11e0107d:	0f 84 aa 05 00 18    	je     0x732b29e0162d
    732b11e01083:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006a
    732b11e0108a:	6a 00 01 00 
    732b11e0108e:	0f 84 99 05 00 18    	je     0x732b29e0162d
    732b11e01094:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e01097:	0f 85 d1 05 00 18    	jne    0x732b29e0166e
    732b11e0109d:	58                   	pop    rax
    732b11e0109e:	e9 0f 00 00 00       	jmp    0x732b11e010b2
    732b11e010a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e010aa:	00 
    732b11e010ab:	74 f0                	je     0x732b11e0109d
    732b11e010ad:	e9 24 05 00 18       	jmp    0x732b29e015d6
    732b11e010b2:	50                   	push   rax
    732b11e010b3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e010b8:	b9 00 00 00 00       	mov    ecx,0x0
    732b11e010bd:	09 c1                	or     ecx,eax
    732b11e010bf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e010c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006c
    732b11e010ca:	6c 00 01 00 
    732b11e010ce:	0f 84 cc 05 00 18    	je     0x732b29e016a0
    732b11e010d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006c
    732b11e010db:	6c 00 01 00 
    732b11e010df:	0f 84 bb 05 00 18    	je     0x732b29e016a0
    732b11e010e5:	58                   	pop    rax
    732b11e010e6:	50                   	push   rax
    732b11e010e7:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e010ec:	c1 e0 10             	shl    eax,0x10
    732b11e010ef:	b9 10 f0 00 00       	mov    ecx,0xf010
    732b11e010f4:	09 c1                	or     ecx,eax
    732b11e010f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e010fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10070
    732b11e01101:	70 00 01 00 
    732b11e01105:	0f 84 f5 05 00 18    	je     0x732b29e01700
    732b11e0110b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10070
    732b11e01112:	70 00 01 00 
    732b11e01116:	0f 84 e4 05 00 18    	je     0x732b29e01700
    732b11e0111c:	58                   	pop    rax
    732b11e0111d:	50                   	push   rax
    732b11e0111e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e01122:	f6 c1 03             	test   cl,0x3
    732b11e01125:	0f 85 35 06 00 18    	jne    0x732b29e01760
    732b11e0112b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e01132:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e01136:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e0113d:	48 89 ce             	mov    rsi,rcx
    732b11e01140:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e01144:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e01148:	48 85 c0             	test   rax,rax
    732b11e0114b:	0f 84 62 06 00 18    	je     0x732b29e017b3
    732b11e01151:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01157:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e0115a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10074
    732b11e01161:	74 00 01 00 
    732b11e01165:	0f 84 83 06 00 18    	je     0x732b29e017ee
    732b11e0116b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10074
    732b11e01172:	74 00 01 00 
    732b11e01176:	0f 84 72 06 00 18    	je     0x732b29e017ee
    732b11e0117c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e0117f:	0f 85 aa 06 00 18    	jne    0x732b29e0182f
    732b11e01185:	58                   	pop    rax
    732b11e01186:	e9 0f 00 00 00       	jmp    0x732b11e0119a
    732b11e0118b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e01192:	00 
    732b11e01193:	74 f0                	je     0x732b11e01185
    732b11e01195:	e9 fd 05 00 18       	jmp    0x732b29e01797
    732b11e0119a:	50                   	push   rax
    732b11e0119b:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    732b11e011a2:	00 
    732b11e011a3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10076
    732b11e011aa:	76 00 01 00 
    732b11e011ae:	0f 84 ad 06 00 18    	je     0x732b29e01861
    732b11e011b4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10076
    732b11e011bb:	76 00 01 00 
    732b11e011bf:	0f 84 9c 06 00 18    	je     0x732b29e01861
    732b11e011c5:	58                   	pop    rax
    732b11e011c6:	50                   	push   rax
    732b11e011c7:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    732b11e011cb:	f6 c1 03             	test   cl,0x3
    732b11e011ce:	0f 85 ed 06 00 18    	jne    0x732b29e018c1
    732b11e011d4:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e011db:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e011df:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e011e6:	48 89 ce             	mov    rsi,rcx
    732b11e011e9:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e011ed:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e011f1:	48 85 c0             	test   rax,rax
    732b11e011f4:	0f 84 1a 07 00 18    	je     0x732b29e01914
    732b11e011fa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01200:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e01203:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10078
    732b11e0120a:	78 00 01 00 
    732b11e0120e:	0f 84 3b 07 00 18    	je     0x732b29e0194f
    732b11e01214:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10078
    732b11e0121b:	78 00 01 00 
    732b11e0121f:	0f 84 2a 07 00 18    	je     0x732b29e0194f
    732b11e01225:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e01228:	0f 85 62 07 00 18    	jne    0x732b29e01990
    732b11e0122e:	58                   	pop    rax
    732b11e0122f:	e9 0f 00 00 00       	jmp    0x732b11e01243
    732b11e01234:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e0123b:	00 
    732b11e0123c:	74 f0                	je     0x732b11e0122e
    732b11e0123e:	e9 b5 06 00 18       	jmp    0x732b29e018f8
    732b11e01243:	50                   	push   rax
    732b11e01244:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    732b11e0124b:	00 
    732b11e0124c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007a
    732b11e01253:	7a 00 01 00 
    732b11e01257:	0f 84 65 07 00 18    	je     0x732b29e019c2
    732b11e0125d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007a
    732b11e01264:	7a 00 01 00 
    732b11e01268:	0f 84 54 07 00 18    	je     0x732b29e019c2
    732b11e0126e:	58                   	pop    rax
    732b11e0126f:	50                   	push   rax
    732b11e01270:	41 0f b7 45 32       	movzx  eax,WORD PTR [r13+0x32]
    732b11e01275:	c1 e0 10             	shl    eax,0x10
    732b11e01278:	b9 00 00 00 00       	mov    ecx,0x0
    732b11e0127d:	09 c1                	or     ecx,eax
    732b11e0127f:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    732b11e01283:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007c
    732b11e0128a:	7c 00 01 00 
    732b11e0128e:	0f 84 8e 07 00 18    	je     0x732b29e01a22
    732b11e01294:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007c
    732b11e0129b:	7c 00 01 00 
    732b11e0129f:	0f 84 7d 07 00 18    	je     0x732b29e01a22
    732b11e012a5:	58                   	pop    rax
    732b11e012a6:	50                   	push   rax
    732b11e012a7:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    732b11e012ae:	00 
    732b11e012af:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10080
    732b11e012b6:	80 00 01 00 
    732b11e012ba:	0f 84 c2 07 00 18    	je     0x732b29e01a82
    732b11e012c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10080
    732b11e012c7:	80 00 01 00 
    732b11e012cb:	0f 84 b1 07 00 18    	je     0x732b29e01a82
    732b11e012d1:	58                   	pop    rax
    732b11e012d2:	50                   	push   rax
    732b11e012d3:	41 c7 45 14 01 00 00 	mov    DWORD PTR [r13+0x14],0x1
    732b11e012da:	00 
    732b11e012db:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10082
    732b11e012e2:	82 00 01 00 
    732b11e012e6:	0f 84 f6 07 00 18    	je     0x732b29e01ae2
    732b11e012ec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10082
    732b11e012f3:	82 00 01 00 
    732b11e012f7:	0f 84 e5 07 00 18    	je     0x732b29e01ae2
    732b11e012fd:	58                   	pop    rax
    732b11e012fe:	50                   	push   rax
    732b11e012ff:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e01303:	8d 48 fc             	lea    ecx,[rax-0x4]
    732b11e01306:	a8 03                	test   al,0x3
    732b11e01308:	0f 85 34 08 00 18    	jne    0x732b29e01b42
    732b11e0130e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01315:	89 ca                	mov    edx,ecx
    732b11e01317:	c1 ea 0c             	shr    edx,0xc
    732b11e0131a:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e0131e:	48 85 c0             	test   rax,rax
    732b11e01321:	0f 84 6b 08 00 18    	je     0x732b29e01b92
    732b11e01327:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0132d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e01330:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    732b11e01337:	58                   	pop    rax
    732b11e01338:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    732b11e0133f:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    732b11e01346:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    732b11e0134d:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e01351:	50                   	push   rax
    732b11e01352:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e01356:	8d 48 f8             	lea    ecx,[rax-0x8]
    732b11e01359:	a8 03                	test   al,0x3
    732b11e0135b:	0f 85 6c 08 00 18    	jne    0x732b29e01bcd
    732b11e01361:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e01368:	89 ca                	mov    edx,ecx
    732b11e0136a:	c1 ea 0c             	shr    edx,0xc
    732b11e0136d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e01371:	48 85 c0             	test   rax,rax
    732b11e01374:	0f 84 a3 08 00 18    	je     0x732b29e01c1d
    732b11e0137a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e01380:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e01383:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    732b11e01387:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    732b11e0138e:	8c 00 01 00 
    732b11e01392:	0f 84 c0 08 00 18    	je     0x732b29e01c58
    732b11e01398:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    732b11e0139f:	8c 00 01 00 
    732b11e013a3:	0f 84 af 08 00 18    	je     0x732b29e01c58
    732b11e013a9:	58                   	pop    rax
    732b11e013aa:	50                   	push   rax
    732b11e013ab:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e013b2:	b9 8e 00 01 00       	mov    ecx,0x1008e
    732b11e013b7:	83 c1 04             	add    ecx,0x4
    732b11e013ba:	89 ca                	mov    edx,ecx
    732b11e013bc:	3d 8e 00 01 00       	cmp    eax,0x1008e
    732b11e013c1:	75 07                	jne    0x732b11e013ca
    732b11e013c3:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    732b11e013ca:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    732b11e013d1:	02 
    732b11e013d2:	0f 43 ca             	cmovae ecx,edx
    732b11e013d5:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    732b11e013dc:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    732b11e013e3:	89 cf                	mov    edi,ecx
    732b11e013e5:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    732b11e013eb:	75 07                	jne    0x732b11e013f4
    732b11e013ed:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    732b11e013f4:	83 fe 02             	cmp    esi,0x2
    732b11e013f7:	0f 43 cf             	cmovae ecx,edi
    732b11e013fa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    732b11e01401:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e01408:	01 
    732b11e01409:	3d 8e 00 01 00       	cmp    eax,0x1008e
    732b11e0140e:	0f 84 8d 08 00 18    	je     0x732b29e01ca1
    732b11e01414:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    732b11e0141a:	0f 84 81 08 00 18    	je     0x732b29e01ca1
    732b11e01420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b11e01427:	28 03 01 00 
    732b11e0142b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b11e01432:	04 00 00 00 
    732b11e01436:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    732b11e0143d:	1c 00 00 00 
    732b11e01441:	58                   	pop    rax
    732b11e01442:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e01449:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e01450:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e01457:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e0145e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e01465:	39 f1                	cmp    ecx,esi
    732b11e01467:	0f 83 6c 08 00 18    	jae    0x732b29e01cd9
    732b11e0146d:	81 fa 40 00 01 00    	cmp    edx,0x10040
    732b11e01473:	75 14                	jne    0x732b11e01489
    732b11e01475:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e0147c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e01483:	00 
    732b11e01484:	e9 10 f8 ff ff       	jmp    0x732b11e00c99
    732b11e01489:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e01490:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e01496:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e01499:	0f 85 3a 08 00 18    	jne    0x732b29e01cd9
    732b11e0149f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e014a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e014ad:	00 
    732b11e014ae:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e014b3:	ff e0                	jmp    rax
