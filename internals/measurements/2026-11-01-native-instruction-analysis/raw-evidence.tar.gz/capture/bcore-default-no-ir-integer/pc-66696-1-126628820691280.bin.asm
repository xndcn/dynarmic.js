
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66696-1-126628820691280.bin:     file format binary


Disassembly of section .data:

0000732b11e02950 <.data>:
    732b11e02950:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02957:	8b 88 1c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10001c]
    732b11e0295d:	ff c1                	inc    ecx
    732b11e0295f:	89 88 1c 00 10 00    	mov    DWORD PTR [rax+0x10001c],ecx
    732b11e02965:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0296b:	0f 84 9f 0f 00 18    	je     0x732b29e03910
    732b11e02971:	50                   	push   rax
    732b11e02972:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e02977:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e0297c:	09 c1                	or     ecx,eax
    732b11e0297e:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e02982:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10488
    732b11e02989:	88 04 01 00 
    732b11e0298d:	0f 84 a9 0f 00 18    	je     0x732b29e0393c
    732b11e02993:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10488
    732b11e0299a:	88 04 01 00 
    732b11e0299e:	0f 84 98 0f 00 18    	je     0x732b29e0393c
    732b11e029a4:	58                   	pop    rax
    732b11e029a5:	50                   	push   rax
    732b11e029a6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e029ab:	c1 e0 10             	shl    eax,0x10
    732b11e029ae:	b9 f4 12 00 00       	mov    ecx,0x12f4
    732b11e029b3:	09 c1                	or     ecx,eax
    732b11e029b5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e029b9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1048c
    732b11e029c0:	8c 04 01 00 
    732b11e029c4:	0f 84 d2 0f 00 18    	je     0x732b29e0399c
    732b11e029ca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1048c
    732b11e029d1:	8c 04 01 00 
    732b11e029d5:	0f 84 c1 0f 00 18    	je     0x732b29e0399c
    732b11e029db:	58                   	pop    rax
    732b11e029dc:	50                   	push   rax
    732b11e029dd:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e029e1:	f6 c1 03             	test   cl,0x3
    732b11e029e4:	0f 85 12 10 00 18    	jne    0x732b29e039fc
    732b11e029ea:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e029f1:	48 89 ca             	mov    rdx,rcx
    732b11e029f4:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e029f8:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e029fc:	48 85 c0             	test   rax,rax
    732b11e029ff:	0f 84 47 10 00 18    	je     0x732b29e03a4c
    732b11e02a05:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02a0b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e02a0e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    732b11e02a12:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10490
    732b11e02a19:	90 04 01 00 
    732b11e02a1d:	0f 84 64 10 00 18    	je     0x732b29e03a87
    732b11e02a23:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10490
    732b11e02a2a:	90 04 01 00 
    732b11e02a2e:	0f 84 53 10 00 18    	je     0x732b29e03a87
    732b11e02a34:	58                   	pop    rax
    732b11e02a35:	50                   	push   rax
    732b11e02a36:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e02a3b:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e02a40:	09 c1                	or     ecx,eax
    732b11e02a42:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e02a46:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10492
    732b11e02a4d:	92 04 01 00 
    732b11e02a51:	0f 84 79 10 00 18    	je     0x732b29e03ad0
    732b11e02a57:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10492
    732b11e02a5e:	92 04 01 00 
    732b11e02a62:	0f 84 68 10 00 18    	je     0x732b29e03ad0
    732b11e02a68:	58                   	pop    rax
    732b11e02a69:	50                   	push   rax
    732b11e02a6a:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e02a6f:	c1 e0 10             	shl    eax,0x10
    732b11e02a72:	b9 f8 12 00 00       	mov    ecx,0x12f8
    732b11e02a77:	09 c1                	or     ecx,eax
    732b11e02a79:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e02a7d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10496
    732b11e02a84:	96 04 01 00 
    732b11e02a88:	0f 84 a2 10 00 18    	je     0x732b29e03b30
    732b11e02a8e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10496
    732b11e02a95:	96 04 01 00 
    732b11e02a99:	0f 84 91 10 00 18    	je     0x732b29e03b30
    732b11e02a9f:	58                   	pop    rax
    732b11e02aa0:	50                   	push   rax
    732b11e02aa1:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e02aa5:	f6 c1 03             	test   cl,0x3
    732b11e02aa8:	0f 85 e2 10 00 18    	jne    0x732b29e03b90
    732b11e02aae:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e02ab5:	48 89 ca             	mov    rdx,rcx
    732b11e02ab8:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e02abc:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e02ac0:	48 85 c0             	test   rax,rax
    732b11e02ac3:	0f 84 17 11 00 18    	je     0x732b29e03be0
    732b11e02ac9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02acf:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e02ad2:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e02ad6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1049a
    732b11e02add:	9a 04 01 00 
    732b11e02ae1:	0f 84 34 11 00 18    	je     0x732b29e03c1b
    732b11e02ae7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1049a
    732b11e02aee:	9a 04 01 00 
    732b11e02af2:	0f 84 23 11 00 18    	je     0x732b29e03c1b
    732b11e02af8:	58                   	pop    rax
    732b11e02af9:	50                   	push   rax
    732b11e02afa:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e02afe:	f6 c3 03             	test   bl,0x3
    732b11e02b01:	0f 85 5d 11 00 18    	jne    0x732b29e03c64
    732b11e02b07:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e02b0e:	48 89 d8             	mov    rax,rbx
    732b11e02b11:	48 c1 e8 0c          	shr    rax,0xc
    732b11e02b15:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02b1a:	48 85 c0             	test   rax,rax
    732b11e02b1d:	0f 84 93 11 00 18    	je     0x732b29e03cb6
    732b11e02b23:	89 d9                	mov    ecx,ebx
    732b11e02b25:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02b2b:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e02b2f:	89 de                	mov    esi,ebx
    732b11e02b31:	83 c6 04             	add    esi,0x4
    732b11e02b34:	89 f0                	mov    eax,esi
    732b11e02b36:	c1 e8 0c             	shr    eax,0xc
    732b11e02b39:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02b3e:	48 85 c0             	test   rax,rax
    732b11e02b41:	0f 84 ac 11 00 18    	je     0x732b29e03cf3
    732b11e02b47:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e02b4d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e02b50:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e02b53:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e02b57:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e02b5e:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e02b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1049c
    732b11e02b69:	9c 04 01 00 
    732b11e02b6d:	0f 84 bc 11 00 18    	je     0x732b29e03d2f
    732b11e02b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1049c
    732b11e02b7a:	9c 04 01 00 
    732b11e02b7e:	0f 84 ab 11 00 18    	je     0x732b29e03d2f
    732b11e02b84:	58                   	pop    rax
    732b11e02b85:	50                   	push   rax
    732b11e02b86:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e02b8d:	01 
    732b11e02b8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104a0
    732b11e02b95:	a0 04 01 00 
    732b11e02b99:	0f 84 d9 11 00 18    	je     0x732b29e03d78
    732b11e02b9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104a0
    732b11e02ba6:	a0 04 01 00 
    732b11e02baa:	0f 84 c8 11 00 18    	je     0x732b29e03d78
    732b11e02bb0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b11e02bb7:	d0 00 01 00 
    732b11e02bbb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b11e02bc2:	04 00 00 00 
    732b11e02bc6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b11e02bcd:	08 00 00 00 
    732b11e02bd1:	58                   	pop    rax
    732b11e02bd2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02bd9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e02be0:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e02be7:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e02bee:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e02bf5:	39 f1                	cmp    ecx,esi
    732b11e02bf7:	0f 83 b3 11 00 18    	jae    0x732b29e03db0
    732b11e02bfd:	81 fa 88 04 01 00    	cmp    edx,0x10488
    732b11e02c03:	75 14                	jne    0x732b11e02c19
    732b11e02c05:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02c0c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02c13:	00 
    732b11e02c14:	e9 37 fd ff ff       	jmp    0x732b11e02950
    732b11e02c19:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e02c20:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e02c26:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e02c29:	0f 85 81 11 00 18    	jne    0x732b29e03db0
    732b11e02c2f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02c36:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02c3d:	00 
    732b11e02c3e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e02c43:	ff e0                	jmp    rax
