
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65744-1-126628820692048.bin:     file format binary


Disassembly of section .data:

0000732b11e02c50 <.data>:
    732b11e02c50:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02c57:	8b 88 20 00 10 00    	mov    ecx,DWORD PTR [rax+0x100020]
    732b11e02c5d:	ff c1                	inc    ecx
    732b11e02c5f:	89 88 20 00 10 00    	mov    DWORD PTR [rax+0x100020],ecx
    732b11e02c65:	81 f9 75 a8 00 00    	cmp    ecx,0xa875
    732b11e02c6b:	0f 84 4f 11 00 18    	je     0x732b29e03dc0
    732b11e02c71:	50                   	push   rax
    732b11e02c72:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e02c76:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e02c79:	f6 c3 03             	test   bl,0x3
    732b11e02c7c:	0f 85 6a 11 00 18    	jne    0x732b29e03dec
    732b11e02c82:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e02c89:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e02c90:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    732b11e02c94:	89 c8                	mov    eax,ecx
    732b11e02c96:	c1 e8 0c             	shr    eax,0xc
    732b11e02c99:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02c9e:	48 85 c0             	test   rax,rax
    732b11e02ca1:	0f 84 98 11 00 18    	je     0x732b29e03e3f
    732b11e02ca7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02cad:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e02cb0:	83 c3 f8             	add    ebx,0xfffffff8
    732b11e02cb3:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    732b11e02cb7:	89 d8                	mov    eax,ebx
    732b11e02cb9:	c1 e8 0c             	shr    eax,0xc
    732b11e02cbc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02cc1:	48 85 c0             	test   rax,rax
    732b11e02cc4:	0f 84 b0 11 00 18    	je     0x732b29e03e7a
    732b11e02cca:	89 d9                	mov    ecx,ebx
    732b11e02ccc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02cd2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e02cd5:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e02cd9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100d0
    732b11e02ce0:	d0 00 01 00 
    732b11e02ce4:	0f 84 ce 11 00 18    	je     0x732b29e03eb8
    732b11e02cea:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100d0
    732b11e02cf1:	d0 00 01 00 
    732b11e02cf5:	0f 84 bd 11 00 18    	je     0x732b29e03eb8
    732b11e02cfb:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e02cff:	0f 85 f5 11 00 18    	jne    0x732b29e03efa
    732b11e02d05:	58                   	pop    rax
    732b11e02d06:	e9 0f 00 00 00       	jmp    0x732b11e02d1a
    732b11e02d0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e02d12:	00 
    732b11e02d13:	74 f0                	je     0x732b11e02d05
    732b11e02d15:	e9 09 11 00 18       	jmp    0x732b29e03e23
    732b11e02d1a:	50                   	push   rax
    732b11e02d1b:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e02d1f:	8d 4b fc             	lea    ecx,[rbx-0x4]
    732b11e02d22:	f6 c3 03             	test   bl,0x3
    732b11e02d25:	0f 85 01 12 00 18    	jne    0x732b29e03f2c
    732b11e02d2b:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    732b11e02d32:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e02d39:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    732b11e02d3d:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    732b11e02d44:	89 c8                	mov    eax,ecx
    732b11e02d46:	c1 e8 0c             	shr    eax,0xc
    732b11e02d49:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02d4e:	48 85 c0             	test   rax,rax
    732b11e02d51:	0f 84 28 12 00 18    	je     0x732b29e03f7f
    732b11e02d57:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02d5d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e02d60:	83 c3 f8             	add    ebx,0xfffffff8
    732b11e02d63:	89 d8                	mov    eax,ebx
    732b11e02d65:	c1 e8 0c             	shr    eax,0xc
    732b11e02d68:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e02d6d:	48 85 c0             	test   rax,rax
    732b11e02d70:	0f 84 44 12 00 18    	je     0x732b29e03fba
    732b11e02d76:	89 d9                	mov    ecx,ebx
    732b11e02d78:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02d7e:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    732b11e02d82:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    732b11e02d86:	b8 00 00 00 00       	mov    eax,0x0
    732b11e02d8b:	29 c3                	sub    ebx,eax
    732b11e02d8d:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    732b11e02d91:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100d2
    732b11e02d98:	d2 00 01 00 
    732b11e02d9c:	0f 84 59 12 00 18    	je     0x732b29e03ffb
    732b11e02da2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100d2
    732b11e02da9:	d2 00 01 00 
    732b11e02dad:	0f 84 48 12 00 18    	je     0x732b29e03ffb
    732b11e02db3:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b11e02db7:	0f 85 80 12 00 18    	jne    0x732b29e0403d
    732b11e02dbd:	58                   	pop    rax
    732b11e02dbe:	e9 0f 00 00 00       	jmp    0x732b11e02dd2
    732b11e02dc3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e02dca:	00 
    732b11e02dcb:	74 f0                	je     0x732b11e02dbd
    732b11e02dcd:	e9 91 11 00 18       	jmp    0x732b29e03f63
    732b11e02dd2:	50                   	push   rax
    732b11e02dd3:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e02dd7:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e02dde:	31 d2                	xor    edx,edx
    732b11e02de0:	85 c0                	test   eax,eax
    732b11e02de2:	0f 94 c2             	sete   dl
    732b11e02de5:	c1 e8 1f             	shr    eax,0x1f
    732b11e02de8:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e02def:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e02df6:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e02dfd:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    732b11e02e04:	00 00 00 
    732b11e02e07:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    732b11e02e0e:	81 f9 d6 00 01 00    	cmp    ecx,0x100d6
    732b11e02e14:	0f 84 55 12 00 18    	je     0x732b29e0406f
    732b11e02e1a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100d6
    732b11e02e21:	d6 00 01 00 
    732b11e02e25:	0f 84 44 12 00 18    	je     0x732b29e0406f
    732b11e02e2b:	58                   	pop    rax
    732b11e02e2c:	50                   	push   rax
    732b11e02e2d:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e02e34:	00 
    732b11e02e35:	74 55                	je     0x732b11e02e8c
    732b11e02e37:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e02e3e:	01 
    732b11e02e3f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100d8
    732b11e02e46:	d8 00 01 00 
    732b11e02e4a:	0f 84 7f 12 00 18    	je     0x732b29e040cf
    732b11e02e50:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100d8
    732b11e02e57:	d8 00 01 00 
    732b11e02e5b:	0f 84 6e 12 00 18    	je     0x732b29e040cf
    732b11e02e61:	b8 d8 00 01 00       	mov    eax,0x100d8
    732b11e02e66:	83 c0 2c             	add    eax,0x2c
    732b11e02e69:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e02e70:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e02e77:	02 00 00 00 
    732b11e02e7b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b11e02e82:	04 00 00 00 
    732b11e02e86:	58                   	pop    rax
    732b11e02e87:	e9 ac 06 00 00       	jmp    0x732b11e03538
    732b11e02e8c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100d8
    732b11e02e93:	d8 00 01 00 
    732b11e02e97:	0f 84 6e 12 00 18    	je     0x732b29e0410b
    732b11e02e9d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100d8
    732b11e02ea4:	d8 00 01 00 
    732b11e02ea8:	0f 84 5d 12 00 18    	je     0x732b29e0410b
    732b11e02eae:	58                   	pop    rax
    732b11e02eaf:	50                   	push   rax
    732b11e02eb0:	41 0f b7 45 18       	movzx  eax,WORD PTR [r13+0x18]
    732b11e02eb5:	b9 00 00 19 00       	mov    ecx,0x190000
    732b11e02eba:	09 c1                	or     ecx,eax
    732b11e02ebc:	41 89 4d 18          	mov    DWORD PTR [r13+0x18],ecx
    732b11e02ec0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100da
    732b11e02ec7:	da 00 01 00 
    732b11e02ecb:	0f 84 83 12 00 18    	je     0x732b29e04154
    732b11e02ed1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100da
    732b11e02ed8:	da 00 01 00 
    732b11e02edc:	0f 84 72 12 00 18    	je     0x732b29e04154
    732b11e02ee2:	58                   	pop    rax
    732b11e02ee3:	50                   	push   rax
    732b11e02ee4:	41 0f b7 45 1c       	movzx  eax,WORD PTR [r13+0x1c]
    732b11e02ee9:	b9 00 00 6e 3c       	mov    ecx,0x3c6e0000
    732b11e02eee:	09 c1                	or     ecx,eax
    732b11e02ef0:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    732b11e02ef4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100de
    732b11e02efb:	de 00 01 00 
    732b11e02eff:	0f 84 af 12 00 18    	je     0x732b29e041b4
    732b11e02f05:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100de
    732b11e02f0c:	de 00 01 00 
    732b11e02f10:	0f 84 9e 12 00 18    	je     0x732b29e041b4
    732b11e02f16:	58                   	pop    rax
    732b11e02f17:	50                   	push   rax
    732b11e02f18:	41 c7 45 08 00 00 00 	mov    DWORD PTR [r13+0x8],0x0
    732b11e02f1f:	00 
    732b11e02f20:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100e2
    732b11e02f27:	e2 00 01 00 
    732b11e02f2b:	0f 84 e3 12 00 18    	je     0x732b29e04214
    732b11e02f31:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100e2
    732b11e02f38:	e2 00 01 00 
    732b11e02f3c:	0f 84 d2 12 00 18    	je     0x732b29e04214
    732b11e02f42:	58                   	pop    rax
    732b11e02f43:	50                   	push   rax
    732b11e02f44:	41 0f b7 45 1a       	movzx  eax,WORD PTR [r13+0x1a]
    732b11e02f49:	c1 e0 10             	shl    eax,0x10
    732b11e02f4c:	b9 0d 66 00 00       	mov    ecx,0x660d
    732b11e02f51:	09 c1                	or     ecx,eax
    732b11e02f53:	41 89 4d 18          	mov    DWORD PTR [r13+0x18],ecx
    732b11e02f57:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100e4
    732b11e02f5e:	e4 00 01 00 
    732b11e02f62:	0f 84 0c 13 00 18    	je     0x732b29e04274
    732b11e02f68:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100e4
    732b11e02f6f:	e4 00 01 00 
    732b11e02f73:	0f 84 fb 12 00 18    	je     0x732b29e04274
    732b11e02f79:	58                   	pop    rax
    732b11e02f7a:	50                   	push   rax
    732b11e02f7b:	41 0f b7 45 1e       	movzx  eax,WORD PTR [r13+0x1e]
    732b11e02f80:	c1 e0 10             	shl    eax,0x10
    732b11e02f83:	b9 5f f3 00 00       	mov    ecx,0xf35f
    732b11e02f88:	09 c1                	or     ecx,eax
    732b11e02f8a:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    732b11e02f8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100e8
    732b11e02f95:	e8 00 01 00 
    732b11e02f99:	0f 84 35 13 00 18    	je     0x732b29e042d4
    732b11e02f9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100e8
    732b11e02fa6:	e8 00 01 00 
    732b11e02faa:	0f 84 24 13 00 18    	je     0x732b29e042d4
    732b11e02fb0:	58                   	pop    rax
    732b11e02fb1:	50                   	push   rax
    732b11e02fb2:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
    732b11e02fb6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e02fbd:	41 0f af 45 04       	imul   eax,DWORD PTR [r13+0x4]
    732b11e02fc2:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e02fc6:	81 f9 ec 00 01 00    	cmp    ecx,0x100ec
    732b11e02fcc:	0f 84 62 13 00 18    	je     0x732b29e04334
    732b11e02fd2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ec
    732b11e02fd9:	ec 00 01 00 
    732b11e02fdd:	0f 84 51 13 00 18    	je     0x732b29e04334
    732b11e02fe3:	58                   	pop    rax
    732b11e02fe4:	50                   	push   rax
    732b11e02fe5:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e02fe9:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    732b11e02fed:	89 c2                	mov    edx,eax
    732b11e02fef:	c1 ea 1f             	shr    edx,0x1f
    732b11e02ff2:	89 ce                	mov    esi,ecx
    732b11e02ff4:	c1 ee 1f             	shr    esi,0x1f
    732b11e02ff7:	31 ff                	xor    edi,edi
    732b11e02ff9:	01 c8                	add    eax,ecx
    732b11e02ffb:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e02fff:	40 0f 92 c7          	setb   dil
    732b11e03003:	89 c1                	mov    ecx,eax
    732b11e03005:	c1 e9 1f             	shr    ecx,0x1f
    732b11e03008:	31 ce                	xor    esi,ecx
    732b11e0300a:	31 ca                	xor    edx,ecx
    732b11e0300c:	21 f2                	and    edx,esi
    732b11e0300e:	31 f6                	xor    esi,esi
    732b11e03010:	85 c0                	test   eax,eax
    732b11e03012:	40 0f 94 c6          	sete   sil
    732b11e03016:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    732b11e0301d:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    732b11e03024:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    732b11e0302b:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    732b11e03032:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    732b11e03039:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    732b11e03040:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    732b11e03047:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ee
    732b11e0304e:	ee 00 01 00 
    732b11e03052:	0f 84 3c 13 00 18    	je     0x732b29e04394
    732b11e03058:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ee
    732b11e0305f:	ee 00 01 00 
    732b11e03063:	0f 84 2b 13 00 18    	je     0x732b29e04394
    732b11e03069:	58                   	pop    rax
    732b11e0306a:	50                   	push   rax
    732b11e0306b:	41 8b 85 04 00 00 00 	mov    eax,DWORD PTR [r13+0x4]
    732b11e03072:	89 c1                	mov    ecx,eax
    732b11e03074:	c1 e9 0d             	shr    ecx,0xd
    732b11e03077:	41 89 8d 0c 00 00 00 	mov    DWORD PTR [r13+0xc],ecx
    732b11e0307e:	31 c9                	xor    ecx,ecx
    732b11e03080:	3d 00 20 00 00       	cmp    eax,0x2000
    732b11e03085:	0f 92 c1             	setb   cl
    732b11e03088:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    732b11e0308f:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    732b11e03096:	00 00 00 00 
    732b11e0309a:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e030a1:	00 00 00 00 
    732b11e030a5:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100f0
    732b11e030ac:	f0 00 01 00 
    732b11e030b0:	0f 84 3e 13 00 18    	je     0x732b29e043f4
    732b11e030b6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f0
    732b11e030bd:	f0 00 01 00 
    732b11e030c1:	0f 84 2d 13 00 18    	je     0x732b29e043f4
    732b11e030c7:	58                   	pop    rax
    732b11e030c8:	50                   	push   rax
    732b11e030c9:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e030cd:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e030d4:	31 d2                	xor    edx,edx
    732b11e030d6:	41 33 45 0c          	xor    eax,DWORD PTR [r13+0xc]
    732b11e030da:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e030de:	0f 94 c2             	sete   dl
    732b11e030e1:	c1 e8 1f             	shr    eax,0x1f
    732b11e030e4:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e030eb:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e030f2:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    732b11e030f9:	00 00 00 00 
    732b11e030fd:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e03104:	00 00 00 00 
    732b11e03108:	81 f9 f4 00 01 00    	cmp    ecx,0x100f4
    732b11e0310e:	0f 84 40 13 00 18    	je     0x732b29e04454
    732b11e03114:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f4
    732b11e0311b:	f4 00 01 00 
    732b11e0311f:	0f 84 2f 13 00 18    	je     0x732b29e04454
    732b11e03125:	58                   	pop    rax
    732b11e03126:	50                   	push   rax
    732b11e03127:	41 8b 85 04 00 00 00 	mov    eax,DWORD PTR [r13+0x4]
    732b11e0312e:	31 c9                	xor    ecx,ecx
    732b11e03130:	c1 e0 07             	shl    eax,0x7
    732b11e03133:	41 89 85 0c 00 00 00 	mov    DWORD PTR [r13+0xc],eax
    732b11e0313a:	0f 94 c1             	sete   cl
    732b11e0313d:	c1 e8 1f             	shr    eax,0x1f
    732b11e03140:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    732b11e03147:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e0314e:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e03155:	00 00 00 00 
    732b11e03159:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100f6
    732b11e03160:	f6 00 01 00 
    732b11e03164:	0f 84 4a 13 00 18    	je     0x732b29e044b4
    732b11e0316a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100f6
    732b11e03171:	f6 00 01 00 
    732b11e03175:	0f 84 39 13 00 18    	je     0x732b29e044b4
    732b11e0317b:	58                   	pop    rax
    732b11e0317c:	50                   	push   rax
    732b11e0317d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e03181:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e03188:	89 c2                	mov    edx,eax
    732b11e0318a:	c1 ea 19             	shr    edx,0x19
    732b11e0318d:	41 89 55 04          	mov    DWORD PTR [r13+0x4],edx
    732b11e03191:	31 d2                	xor    edx,edx
    732b11e03193:	3d 00 00 00 02       	cmp    eax,0x2000000
    732b11e03198:	0f 92 c2             	setb   dl
    732b11e0319b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e031a2:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    732b11e031a9:	00 00 00 00 
    732b11e031ad:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e031b4:	00 00 00 00 
    732b11e031b8:	81 f9 fa 00 01 00    	cmp    ecx,0x100fa
    732b11e031be:	0f 84 50 13 00 18    	je     0x732b29e04514
    732b11e031c4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fa
    732b11e031cb:	fa 00 01 00 
    732b11e031cf:	0f 84 3f 13 00 18    	je     0x732b29e04514
    732b11e031d5:	58                   	pop    rax
    732b11e031d6:	50                   	push   rax
    732b11e031d7:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    732b11e031db:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e031e2:	31 d2                	xor    edx,edx
    732b11e031e4:	89 c6                	mov    esi,eax
    732b11e031e6:	ff c6                	inc    esi
    732b11e031e8:	0f 94 c2             	sete   dl
    732b11e031eb:	41 89 75 08          	mov    DWORD PTR [r13+0x8],esi
    732b11e031ef:	c1 e8 1f             	shr    eax,0x1f
    732b11e031f2:	89 f7                	mov    edi,esi
    732b11e031f4:	c1 ef 1f             	shr    edi,0x1f
    732b11e031f7:	f7 d0                	not    eax
    732b11e031f9:	21 f8                	and    eax,edi
    732b11e031fb:	31 db                	xor    ebx,ebx
    732b11e031fd:	85 f6                	test   esi,esi
    732b11e031ff:	0f 94 c3             	sete   bl
    732b11e03202:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    732b11e03209:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e03210:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    732b11e03217:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    732b11e0321e:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    732b11e03225:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    732b11e0322c:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    732b11e03233:	81 f9 fc 00 01 00    	cmp    ecx,0x100fc
    732b11e03239:	0f 84 35 13 00 18    	je     0x732b29e04574
    732b11e0323f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fc
    732b11e03246:	fc 00 01 00 
    732b11e0324a:	0f 84 24 13 00 18    	je     0x732b29e04574
    732b11e03250:	58                   	pop    rax
    732b11e03251:	50                   	push   rax
    732b11e03252:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    732b11e03256:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e0325d:	31 d2                	xor    edx,edx
    732b11e0325f:	41 0b 45 04          	or     eax,DWORD PTR [r13+0x4]
    732b11e03263:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e03267:	0f 94 c2             	sete   dl
    732b11e0326a:	c1 e8 1f             	shr    eax,0x1f
    732b11e0326d:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e03274:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e0327b:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    732b11e03282:	00 00 00 00 
    732b11e03286:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    732b11e0328d:	00 00 00 00 
    732b11e03291:	81 f9 fe 00 01 00    	cmp    ecx,0x100fe
    732b11e03297:	0f 84 37 13 00 18    	je     0x732b29e045d4
    732b11e0329d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100fe
    732b11e032a4:	fe 00 01 00 
    732b11e032a8:	0f 84 26 13 00 18    	je     0x732b29e045d4
    732b11e032ae:	58                   	pop    rax
    732b11e032af:	50                   	push   rax
    732b11e032b0:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e032b4:	41 8b 4d 08          	mov    ecx,DWORD PTR [r13+0x8]
    732b11e032b8:	31 d2                	xor    edx,edx
    732b11e032ba:	31 f6                	xor    esi,esi
    732b11e032bc:	31 ff                	xor    edi,edi
    732b11e032be:	31 db                	xor    ebx,ebx
    732b11e032c0:	39 c8                	cmp    eax,ecx
    732b11e032c2:	0f 96 c2             	setbe  dl
    732b11e032c5:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e032cc:	40 0f 94 c6          	sete   sil
    732b11e032d0:	40 0f 92 c7          	setb   dil
    732b11e032d4:	0f 93 c3             	setae  bl
    732b11e032d7:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    732b11e032de:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e032e5:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    732b11e032ec:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    732b11e032f3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10100
    732b11e032fa:	00 01 01 00 
    732b11e032fe:	0f 84 30 13 00 18    	je     0x732b29e04634
    732b11e03304:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10100
    732b11e0330b:	00 01 01 00 
    732b11e0330f:	0f 84 1f 13 00 18    	je     0x732b29e04634
    732b11e03315:	58                   	pop    rax
    732b11e03316:	50                   	push   rax
    732b11e03317:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e0331e:	00 
    732b11e0331f:	74 28                	je     0x732b11e03349
    732b11e03321:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10102
    732b11e03328:	02 01 01 00 
    732b11e0332c:	0f 84 62 13 00 18    	je     0x732b29e04694
    732b11e03332:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10102
    732b11e03339:	02 01 01 00 
    732b11e0333d:	0f 84 51 13 00 18    	je     0x732b29e04694
    732b11e03343:	58                   	pop    rax
    732b11e03344:	e9 55 00 00 00       	jmp    0x732b11e0339e
    732b11e03349:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e03350:	01 
    732b11e03351:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10102
    732b11e03358:	02 01 01 00 
    732b11e0335c:	0f 84 7b 13 00 18    	je     0x732b29e046dd
    732b11e03362:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10102
    732b11e03369:	02 01 01 00 
    732b11e0336d:	0f 84 6a 13 00 18    	je     0x732b29e046dd
    732b11e03373:	b8 02 01 01 00       	mov    eax,0x10102
    732b11e03378:	83 c0 ea             	add    eax,0xffffffea
    732b11e0337b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e03382:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e03389:	02 00 00 00 
    732b11e0338d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b11e03394:	13 00 00 00 
    732b11e03398:	58                   	pop    rax
    732b11e03399:	e9 9a 01 00 00       	jmp    0x732b11e03538
    732b11e0339e:	50                   	push   rax
    732b11e0339f:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e033a3:	f6 c3 03             	test   bl,0x3
    732b11e033a6:	0f 85 6d 13 00 18    	jne    0x732b29e04719
    732b11e033ac:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e033b3:	48 89 d8             	mov    rax,rbx
    732b11e033b6:	48 c1 e8 0c          	shr    rax,0xc
    732b11e033ba:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e033bf:	48 85 c0             	test   rax,rax
    732b11e033c2:	0f 84 a3 13 00 18    	je     0x732b29e0476b
    732b11e033c8:	89 d9                	mov    ecx,ebx
    732b11e033ca:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e033d0:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e033d4:	89 de                	mov    esi,ebx
    732b11e033d6:	83 c6 04             	add    esi,0x4
    732b11e033d9:	89 f0                	mov    eax,esi
    732b11e033db:	c1 e8 0c             	shr    eax,0xc
    732b11e033de:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e033e3:	48 85 c0             	test   rax,rax
    732b11e033e6:	0f 84 bc 13 00 18    	je     0x732b29e047a8
    732b11e033ec:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e033f2:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e033f5:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e033f8:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e033fc:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e03403:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e03407:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10104
    732b11e0340e:	04 01 01 00 
    732b11e03412:	0f 84 cc 13 00 18    	je     0x732b29e047e4
    732b11e03418:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10104
    732b11e0341f:	04 01 01 00 
    732b11e03423:	0f 84 bb 13 00 18    	je     0x732b29e047e4
    732b11e03429:	58                   	pop    rax
    732b11e0342a:	50                   	push   rax
    732b11e0342b:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    732b11e0342f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e03436:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    732b11e0343a:	81 f9 08 01 01 00    	cmp    ecx,0x10108
    732b11e03440:	0f 84 e7 13 00 18    	je     0x732b29e0482d
    732b11e03446:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10108
    732b11e0344d:	08 01 01 00 
    732b11e03451:	0f 84 d6 13 00 18    	je     0x732b29e0482d
    732b11e03457:	58                   	pop    rax
    732b11e03458:	50                   	push   rax
    732b11e03459:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e0345d:	f6 c3 03             	test   bl,0x3
    732b11e03460:	0f 85 27 14 00 18    	jne    0x732b29e0488d
    732b11e03466:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e0346d:	48 89 d8             	mov    rax,rbx
    732b11e03470:	48 c1 e8 0c          	shr    rax,0xc
    732b11e03474:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e03479:	48 85 c0             	test   rax,rax
    732b11e0347c:	0f 84 5d 14 00 18    	je     0x732b29e048df
    732b11e03482:	89 d9                	mov    ecx,ebx
    732b11e03484:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0348a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e0348d:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    732b11e03491:	89 de                	mov    esi,ebx
    732b11e03493:	83 c6 04             	add    esi,0x4
    732b11e03496:	89 f0                	mov    eax,esi
    732b11e03498:	c1 e8 0c             	shr    eax,0xc
    732b11e0349b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e034a0:	48 85 c0             	test   rax,rax
    732b11e034a3:	0f 84 71 14 00 18    	je     0x732b29e0491a
    732b11e034a9:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e034af:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e034b2:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    732b11e034b6:	8d 43 08             	lea    eax,[rbx+0x8]
    732b11e034b9:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    732b11e034bd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1010a
    732b11e034c4:	0a 01 01 00 
    732b11e034c8:	0f 84 88 14 00 18    	je     0x732b29e04956
    732b11e034ce:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1010a
    732b11e034d5:	0a 01 01 00 
    732b11e034d9:	0f 84 77 14 00 18    	je     0x732b29e04956
    732b11e034df:	58                   	pop    rax
    732b11e034e0:	50                   	push   rax
    732b11e034e1:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e034e8:	a8 01                	test   al,0x1
    732b11e034ea:	0f 85 af 14 00 18    	jne    0x732b29e0499f
    732b11e034f0:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e034f7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e034fe:	01 
    732b11e034ff:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1010c
    732b11e03506:	0c 01 01 00 
    732b11e0350a:	0f 84 c5 14 00 18    	je     0x732b29e049d5
    732b11e03510:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1010c
    732b11e03517:	0c 01 01 00 
    732b11e0351b:	0f 84 b4 14 00 18    	je     0x732b29e049d5
    732b11e03521:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e03528:	02 00 00 00 
    732b11e0352c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b11e03533:	17 00 00 00 
    732b11e03537:	58                   	pop    rax
    732b11e03538:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e0353f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e03546:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e0354d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e03554:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e0355b:	39 f1                	cmp    ecx,esi
    732b11e0355d:	0f 83 9f 14 00 18    	jae    0x732b29e04a02
    732b11e03563:	81 fa d0 00 01 00    	cmp    edx,0x100d0
    732b11e03569:	75 14                	jne    0x732b11e0357f
    732b11e0356b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e03572:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e03579:	00 
    732b11e0357a:	e9 d1 f6 ff ff       	jmp    0x732b11e02c50
    732b11e0357f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e03586:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e0358c:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e0358f:	0f 85 6d 14 00 18    	jne    0x732b29e04a02
    732b11e03595:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e0359c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e035a3:	00 
    732b11e035a4:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e035a9:	ff e0                	jmp    rax
