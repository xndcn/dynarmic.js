
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66626-1-126628820690784.bin:     file format binary


Disassembly of section .data:

0000732b11e02760 <.data>:
    732b11e02760:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e02767:	8b 88 18 00 10 00    	mov    ecx,DWORD PTR [rax+0x100018]
    732b11e0276d:	ff c1                	inc    ecx
    732b11e0276f:	89 88 18 00 10 00    	mov    DWORD PTR [rax+0x100018],ecx
    732b11e02775:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e0277b:	0f 84 ff 0e 00 18    	je     0x732b29e03680
    732b11e02781:	50                   	push   rax
    732b11e02782:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    732b11e02787:	b9 00 00 01 00       	mov    ecx,0x10000
    732b11e0278c:	09 c1                	or     ecx,eax
    732b11e0278e:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    732b11e02792:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10442
    732b11e02799:	42 04 01 00 
    732b11e0279d:	0f 84 09 0f 00 18    	je     0x732b29e036ac
    732b11e027a3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10442
    732b11e027aa:	42 04 01 00 
    732b11e027ae:	0f 84 f8 0e 00 18    	je     0x732b29e036ac
    732b11e027b4:	58                   	pop    rax
    732b11e027b5:	50                   	push   rax
    732b11e027b6:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    732b11e027bb:	c1 e0 10             	shl    eax,0x10
    732b11e027be:	b9 9c 11 00 00       	mov    ecx,0x119c
    732b11e027c3:	09 c1                	or     ecx,eax
    732b11e027c5:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    732b11e027c9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10446
    732b11e027d0:	46 04 01 00 
    732b11e027d4:	0f 84 32 0f 00 18    	je     0x732b29e0370c
    732b11e027da:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10446
    732b11e027e1:	46 04 01 00 
    732b11e027e5:	0f 84 21 0f 00 18    	je     0x732b29e0370c
    732b11e027eb:	58                   	pop    rax
    732b11e027ec:	50                   	push   rax
    732b11e027ed:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    732b11e027f1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e027f8:	c1 e0 02             	shl    eax,0x2
    732b11e027fb:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    732b11e027ff:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    732b11e02803:	81 f9 4a 04 01 00    	cmp    ecx,0x1044a
    732b11e02809:	0f 84 5d 0f 00 18    	je     0x732b29e0376c
    732b11e0280f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044a
    732b11e02816:	4a 04 01 00 
    732b11e0281a:	0f 84 4c 0f 00 18    	je     0x732b29e0376c
    732b11e02820:	58                   	pop    rax
    732b11e02821:	50                   	push   rax
    732b11e02822:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e02826:	f6 c1 03             	test   cl,0x3
    732b11e02829:	0f 85 9d 0f 00 18    	jne    0x732b29e037cc
    732b11e0282f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e02836:	48 89 ca             	mov    rdx,rcx
    732b11e02839:	48 c1 ea 0c          	shr    rdx,0xc
    732b11e0283d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e02841:	48 85 c0             	test   rax,rax
    732b11e02844:	0f 84 d2 0f 00 18    	je     0x732b29e0381c
    732b11e0284a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e02850:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e02853:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    732b11e02857:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044c
    732b11e0285e:	4c 04 01 00 
    732b11e02862:	0f 84 ef 0f 00 18    	je     0x732b29e03857
    732b11e02868:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044c
    732b11e0286f:	4c 04 01 00 
    732b11e02873:	0f 84 de 0f 00 18    	je     0x732b29e03857
    732b11e02879:	58                   	pop    rax
    732b11e0287a:	50                   	push   rax
    732b11e0287b:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    732b11e0287f:	a8 01                	test   al,0x1
    732b11e02881:	0f 85 19 10 00 18    	jne    0x732b29e038a0
    732b11e02887:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e0288e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e02895:	01 
    732b11e02896:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044e
    732b11e0289d:	4e 04 01 00 
    732b11e028a1:	0f 84 2f 10 00 18    	je     0x732b29e038d6
    732b11e028a7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044e
    732b11e028ae:	4e 04 01 00 
    732b11e028b2:	0f 84 1e 10 00 18    	je     0x732b29e038d6
    732b11e028b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e028bf:	02 00 00 00 
    732b11e028c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b11e028ca:	05 00 00 00 
    732b11e028ce:	58                   	pop    rax
    732b11e028cf:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e028d6:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e028dd:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e028e4:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e028eb:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e028f2:	39 f1                	cmp    ecx,esi
    732b11e028f4:	0f 83 09 10 00 18    	jae    0x732b29e03903
    732b11e028fa:	81 fa 42 04 01 00    	cmp    edx,0x10442
    732b11e02900:	75 14                	jne    0x732b11e02916
    732b11e02902:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02909:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e02910:	00 
    732b11e02911:	e9 4a fe ff ff       	jmp    0x732b11e02760
    732b11e02916:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e0291d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e02923:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e02926:	0f 85 d7 0f 00 18    	jne    0x732b29e03903
    732b11e0292c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e02933:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e0293a:	00 
    732b11e0293b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e02940:	ff e0                	jmp    rax
