
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65668-1-126628820700352.bin:     file format binary


Disassembly of section .data:

0000732b11e04cc0 <.data>:
    732b11e04cc0:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e04cc7:	3d 00 00 00 00       	cmp    eax,0x0
    732b11e04ccc:	0f 95 c2             	setne  dl
    732b11e04ccf:	b9 84 00 01 00       	mov    ecx,0x10084
    732b11e04cd4:	29 c8                	sub    eax,ecx
    732b11e04cd6:	3d 0a 00 00 00       	cmp    eax,0xa
    732b11e04cdb:	0f 96 c3             	setbe  bl
    732b11e04cde:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    732b11e04ce5:	81 fe 00 00 00 00    	cmp    esi,0x0
    732b11e04ceb:	0f 94 c0             	sete   al
    732b11e04cee:	29 ce                	sub    esi,ecx
    732b11e04cf0:	81 fe 0a 00 00 00    	cmp    esi,0xa
    732b11e04cf6:	0f 97 c1             	seta   cl
    732b11e04cf9:	84 da                	test   dl,bl
    732b11e04cfb:	0f 85 3f 0f 00 18    	jne    0x732b29e05c40
    732b11e04d01:	08 c8                	or     al,cl
    732b11e04d03:	0f 84 37 0f 00 18    	je     0x732b29e05c40
    732b11e04d09:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e04d10:	8b 88 2c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10002c]
    732b11e04d16:	ff c1                	inc    ecx
    732b11e04d18:	89 88 2c 00 10 00    	mov    DWORD PTR [rax+0x10002c],ecx
    732b11e04d1e:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e04d24:	0f 84 2c 0f 00 18    	je     0x732b29e05c56
    732b11e04d2a:	50                   	push   rax
    732b11e04d2b:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e04d2f:	8d 48 fc             	lea    ecx,[rax-0x4]
    732b11e04d32:	a8 03                	test   al,0x3
    732b11e04d34:	0f 85 48 0f 00 18    	jne    0x732b29e05c82
    732b11e04d3a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e04d41:	89 ca                	mov    edx,ecx
    732b11e04d43:	c1 ea 0c             	shr    edx,0xc
    732b11e04d46:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e04d4a:	48 85 c0             	test   rax,rax
    732b11e04d4d:	0f 84 7f 0f 00 18    	je     0x732b29e05cd2
    732b11e04d53:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e04d59:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e04d5c:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    732b11e04d63:	58                   	pop    rax
    732b11e04d64:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    732b11e04d6b:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    732b11e04d72:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    732b11e04d79:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    732b11e04d7d:	50                   	push   rax
    732b11e04d7e:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    732b11e04d82:	8d 48 f8             	lea    ecx,[rax-0x8]
    732b11e04d85:	a8 03                	test   al,0x3
    732b11e04d87:	0f 85 80 0f 00 18    	jne    0x732b29e05d0d
    732b11e04d8d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e04d94:	89 ca                	mov    edx,ecx
    732b11e04d96:	c1 ea 0c             	shr    edx,0xc
    732b11e04d99:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    732b11e04d9d:	48 85 c0             	test   rax,rax
    732b11e04da0:	0f 84 b7 0f 00 18    	je     0x732b29e05d5d
    732b11e04da6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e04dac:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e04daf:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    732b11e04db3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    732b11e04dba:	8c 00 01 00 
    732b11e04dbe:	0f 84 d4 0f 00 18    	je     0x732b29e05d98
    732b11e04dc4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    732b11e04dcb:	8c 00 01 00 
    732b11e04dcf:	0f 84 c3 0f 00 18    	je     0x732b29e05d98
    732b11e04dd5:	58                   	pop    rax
    732b11e04dd6:	50                   	push   rax
    732b11e04dd7:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    732b11e04dde:	b9 8e 00 01 00       	mov    ecx,0x1008e
    732b11e04de3:	83 c1 04             	add    ecx,0x4
    732b11e04de6:	89 ca                	mov    edx,ecx
    732b11e04de8:	3d 8e 00 01 00       	cmp    eax,0x1008e
    732b11e04ded:	75 07                	jne    0x732b11e04df6
    732b11e04def:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    732b11e04df6:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    732b11e04dfd:	02 
    732b11e04dfe:	0f 43 ca             	cmovae ecx,edx
    732b11e04e01:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    732b11e04e08:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    732b11e04e0f:	89 cf                	mov    edi,ecx
    732b11e04e11:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    732b11e04e17:	75 07                	jne    0x732b11e04e20
    732b11e04e19:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    732b11e04e20:	83 fe 02             	cmp    esi,0x2
    732b11e04e23:	0f 43 cf             	cmovae ecx,edi
    732b11e04e26:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    732b11e04e2d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e04e34:	01 
    732b11e04e35:	3d 8e 00 01 00       	cmp    eax,0x1008e
    732b11e04e3a:	0f 84 a1 0f 00 18    	je     0x732b29e05de1
    732b11e04e40:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    732b11e04e46:	0f 84 95 0f 00 18    	je     0x732b29e05de1
    732b11e04e4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b11e04e53:	28 03 01 00 
    732b11e04e57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b11e04e5e:	04 00 00 00 
    732b11e04e62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b11e04e69:	03 00 00 00 
    732b11e04e6d:	58                   	pop    rax
    732b11e04e6e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e04e75:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e04e7c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e04e83:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e04e8a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e04e91:	39 f1                	cmp    ecx,esi
    732b11e04e93:	0f 83 80 0f 00 18    	jae    0x732b29e05e19
    732b11e04e99:	81 fa 84 00 01 00    	cmp    edx,0x10084
    732b11e04e9f:	75 14                	jne    0x732b11e04eb5
    732b11e04ea1:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e04ea8:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e04eaf:	00 
    732b11e04eb0:	e9 54 fe ff ff       	jmp    0x732b11e04d09
    732b11e04eb5:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e04ebc:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e04ec2:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e04ec5:	0f 85 4e 0f 00 18    	jne    0x732b29e05e19
    732b11e04ecb:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e04ed2:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e04ed9:	00 
    732b11e04eda:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e04edf:	ff e0                	jmp    rax
