
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65600-1-126629223337408.bin:     file format binary


Disassembly of section .data:

0000732b29e00dc0 <.data>:
    732b29e00dc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    732b29e00dc7:	40 00 01 00 
    732b29e00dcb:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    732b29e00dd2:	01 
    732b29e00dd3:	c2 08 00             	ret    0x8
    732b29e00dd6:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e00ddc:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e00ddf:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e00de5:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e00dec:	0f 87 c8 fe ff e7    	ja     0x732b11e00cba
    732b29e00df2:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x2
    732b29e00df9:	02 00 00 00 
    732b29e00dfd:	e9 b8 fe ff e7       	jmp    0x732b11e00cba
    732b29e00e02:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    732b29e00e09:	40 00 01 00 
    732b29e00e0d:	b8 40 00 01 00       	mov    eax,0x10040
    732b29e00e12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00e19:	04 00 00 00 
    732b29e00e1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00e24:	01 00 00 00 
    732b29e00e28:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e00e2b:	be 40 00 01 00       	mov    esi,0x10040
    732b29e00e30:	4c 89 ef             	mov    rdi,r13
    732b29e00e33:	e8 28 f3 ff e7       	call   0x732b11e00160
    732b29e00e38:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00e3f:	00 
    732b29e00e40:	0f 84 9f fe ff e7    	je     0x732b11e00ce5
    732b29e00e46:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00e4d:	04 00 00 00 
    732b29e00e51:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00e58:	01 00 00 00 
    732b29e00e5c:	58                   	pop    rax
    732b29e00e5d:	e9 e0 05 00 e8       	jmp    0x732b11e01442
    732b29e00e62:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10044
    732b29e00e69:	44 00 01 00 
    732b29e00e6d:	b8 44 00 01 00       	mov    eax,0x10044
    732b29e00e72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00e79:	02 00 00 00 
    732b29e00e7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e00e84:	02 00 00 00 
    732b29e00e88:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00e8b:	be 44 00 01 00       	mov    esi,0x10044
    732b29e00e90:	4c 89 ef             	mov    rdi,r13
    732b29e00e93:	e8 c8 f2 ff e7       	call   0x732b11e00160
    732b29e00e98:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00e9f:	00 
    732b29e00ea0:	0f 84 68 fe ff e7    	je     0x732b11e00d0e
    732b29e00ea6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00ead:	02 00 00 00 
    732b29e00eb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e00eb8:	02 00 00 00 
    732b29e00ebc:	58                   	pop    rax
    732b29e00ebd:	e9 80 05 00 e8       	jmp    0x732b11e01442
    732b29e00ec2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    732b29e00ec9:	46 00 01 00 
    732b29e00ecd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00ed4:	02 00 00 00 
    732b29e00ed8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00edf:	03 00 00 00 
    732b29e00ee3:	ba 46 00 01 00       	mov    edx,0x10046
    732b29e00ee8:	4c 89 ef             	mov    rdi,r13
    732b29e00eeb:	4c 89 f6             	mov    rsi,r14
    732b29e00eee:	45 31 c0             	xor    r8d,r8d
    732b29e00ef1:	e8 8a f1 ff e7       	call   0x732b11e00080
    732b29e00ef6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00efd:	02 00 00 00 
    732b29e00f01:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00f08:	03 00 00 00 
    732b29e00f0c:	58                   	pop    rax
    732b29e00f0d:	e9 30 05 00 e8       	jmp    0x732b11e01442
    732b29e00f12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    732b29e00f19:	46 00 01 00 
    732b29e00f1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00f24:	02 00 00 00 
    732b29e00f28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00f2f:	03 00 00 00 
    732b29e00f33:	4c 89 f7             	mov    rdi,r14
    732b29e00f36:	89 ce                	mov    esi,ecx
    732b29e00f38:	e8 03 f1 ff e7       	call   0x732b11e00040
    732b29e00f3d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00f44:	00 
    732b29e00f45:	0f 84 f6 fd ff e7    	je     0x732b11e00d41
    732b29e00f4b:	eb a9                	jmp    0x732b29e00ef6
    732b29e00f4d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    732b29e00f54:	46 00 01 00 
    732b29e00f58:	b8 46 00 01 00       	mov    eax,0x10046
    732b29e00f5d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00f64:	02 00 00 00 
    732b29e00f68:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00f6f:	03 00 00 00 
    732b29e00f73:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00f76:	be 46 00 01 00       	mov    esi,0x10046
    732b29e00f7b:	4c 89 ef             	mov    rdi,r13
    732b29e00f7e:	e8 dd f1 ff e7       	call   0x732b11e00160
    732b29e00f83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00f8a:	00 
    732b29e00f8b:	0f 84 d6 fd ff e7    	je     0x732b11e00d67
    732b29e00f91:	e9 60 ff ff ff       	jmp    0x732b29e00ef6
    732b29e00f96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10048
    732b29e00f9d:	48 00 01 00 
    732b29e00fa1:	b8 48 00 01 00       	mov    eax,0x10048
    732b29e00fa6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00fad:	02 00 00 00 
    732b29e00fb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e00fb8:	04 00 00 00 
    732b29e00fbc:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00fbf:	be 48 00 01 00       	mov    esi,0x10048
    732b29e00fc4:	4c 89 ef             	mov    rdi,r13
    732b29e00fc7:	e8 94 f1 ff e7       	call   0x732b11e00160
    732b29e00fcc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00fd3:	00 
    732b29e00fd4:	0f 84 b6 fd ff e7    	je     0x732b11e00d90
    732b29e00fda:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00fe1:	02 00 00 00 
    732b29e00fe5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e00fec:	04 00 00 00 
    732b29e00ff0:	58                   	pop    rax
    732b29e00ff1:	e9 4c 04 00 e8       	jmp    0x732b11e01442
    732b29e00ff6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    732b29e00ffd:	4a 00 01 00 
    732b29e01001:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01008:	02 00 00 00 
    732b29e0100c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e01013:	05 00 00 00 
    732b29e01017:	ba 4a 00 01 00       	mov    edx,0x1004a
    732b29e0101c:	4c 89 ef             	mov    rdi,r13
    732b29e0101f:	4c 89 f6             	mov    rsi,r14
    732b29e01022:	45 31 c0             	xor    r8d,r8d
    732b29e01025:	e8 56 f0 ff e7       	call   0x732b11e00080
    732b29e0102a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01031:	02 00 00 00 
    732b29e01035:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0103c:	05 00 00 00 
    732b29e01040:	58                   	pop    rax
    732b29e01041:	e9 fc 03 00 e8       	jmp    0x732b11e01442
    732b29e01046:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    732b29e0104d:	4a 00 01 00 
    732b29e01051:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01058:	02 00 00 00 
    732b29e0105c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e01063:	05 00 00 00 
    732b29e01067:	4c 89 f7             	mov    rdi,r14
    732b29e0106a:	89 ce                	mov    esi,ecx
    732b29e0106c:	e8 cf ef ff e7       	call   0x732b11e00040
    732b29e01071:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01078:	00 
    732b29e01079:	0f 84 44 fd ff e7    	je     0x732b11e00dc3
    732b29e0107f:	eb a9                	jmp    0x732b29e0102a
    732b29e01081:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    732b29e01088:	4a 00 01 00 
    732b29e0108c:	b8 4a 00 01 00       	mov    eax,0x1004a
    732b29e01091:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01098:	02 00 00 00 
    732b29e0109c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e010a3:	05 00 00 00 
    732b29e010a7:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e010aa:	be 4a 00 01 00       	mov    esi,0x1004a
    732b29e010af:	4c 89 ef             	mov    rdi,r13
    732b29e010b2:	e8 a9 f0 ff e7       	call   0x732b11e00160
    732b29e010b7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e010be:	00 
    732b29e010bf:	0f 84 24 fd ff e7    	je     0x732b11e00de9
    732b29e010c5:	e9 60 ff ff ff       	jmp    0x732b29e0102a
    732b29e010ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004c
    732b29e010d1:	4c 00 01 00 
    732b29e010d5:	b8 4c 00 01 00       	mov    eax,0x1004c
    732b29e010da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e010e1:	02 00 00 00 
    732b29e010e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e010ec:	06 00 00 00 
    732b29e010f0:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e010f3:	be 4c 00 01 00       	mov    esi,0x1004c
    732b29e010f8:	4c 89 ef             	mov    rdi,r13
    732b29e010fb:	e8 60 f0 ff e7       	call   0x732b11e00160
    732b29e01100:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01107:	00 
    732b29e01108:	0f 84 07 fd ff e7    	je     0x732b11e00e15
    732b29e0110e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01115:	02 00 00 00 
    732b29e01119:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e01120:	06 00 00 00 
    732b29e01124:	58                   	pop    rax
    732b29e01125:	e9 18 03 00 e8       	jmp    0x732b11e01442
    732b29e0112a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004e
    732b29e01131:	4e 00 01 00 
    732b29e01135:	b8 4e 00 01 00       	mov    eax,0x1004e
    732b29e0113a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01141:	04 00 00 00 
    732b29e01145:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e0114c:	07 00 00 00 
    732b29e01150:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01153:	be 4e 00 01 00       	mov    esi,0x1004e
    732b29e01158:	4c 89 ef             	mov    rdi,r13
    732b29e0115b:	e8 00 f0 ff e7       	call   0x732b11e00160
    732b29e01160:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01167:	00 
    732b29e01168:	0f 84 d3 fc ff e7    	je     0x732b11e00e41
    732b29e0116e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01175:	04 00 00 00 
    732b29e01179:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e01180:	07 00 00 00 
    732b29e01184:	58                   	pop    rax
    732b29e01185:	e9 b8 02 00 e8       	jmp    0x732b11e01442
    732b29e0118a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10052
    732b29e01191:	52 00 01 00 
    732b29e01195:	b8 52 00 01 00       	mov    eax,0x10052
    732b29e0119a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e011a1:	02 00 00 00 
    732b29e011a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e011ac:	08 00 00 00 
    732b29e011b0:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e011b3:	be 52 00 01 00       	mov    esi,0x10052
    732b29e011b8:	4c 89 ef             	mov    rdi,r13
    732b29e011bb:	e8 a0 ef ff e7       	call   0x732b11e00160
    732b29e011c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e011c7:	00 
    732b29e011c8:	0f 84 9c fc ff e7    	je     0x732b11e00e6a
    732b29e011ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e011d5:	02 00 00 00 
    732b29e011d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e011e0:	08 00 00 00 
    732b29e011e4:	58                   	pop    rax
    732b29e011e5:	e9 58 02 00 e8       	jmp    0x732b11e01442
    732b29e011ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    732b29e011f1:	54 00 01 00 
    732b29e011f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e011fc:	02 00 00 00 
    732b29e01200:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e01207:	09 00 00 00 
    732b29e0120b:	ba 54 00 01 00       	mov    edx,0x10054
    732b29e01210:	4c 89 ef             	mov    rdi,r13
    732b29e01213:	4c 89 f6             	mov    rsi,r14
    732b29e01216:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e0121c:	e8 5f ee ff e7       	call   0x732b11e00080
    732b29e01221:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01228:	02 00 00 00 
    732b29e0122c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e01233:	09 00 00 00 
    732b29e01237:	58                   	pop    rax
    732b29e01238:	e9 05 02 00 e8       	jmp    0x732b11e01442
    732b29e0123d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    732b29e01244:	54 00 01 00 
    732b29e01248:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0124f:	02 00 00 00 
    732b29e01253:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e0125a:	09 00 00 00 
    732b29e0125e:	4c 89 f7             	mov    rdi,r14
    732b29e01261:	89 ce                	mov    esi,ecx
    732b29e01263:	e8 08 ee ff e7       	call   0x732b11e00070
    732b29e01268:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0126f:	00 
    732b29e01270:	0f 84 32 fc ff e7    	je     0x732b11e00ea8
    732b29e01276:	eb a9                	jmp    0x732b29e01221
    732b29e01278:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    732b29e0127f:	54 00 01 00 
    732b29e01283:	b8 54 00 01 00       	mov    eax,0x10054
    732b29e01288:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0128f:	02 00 00 00 
    732b29e01293:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e0129a:	09 00 00 00 
    732b29e0129e:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e012a1:	be 54 00 01 00       	mov    esi,0x10054
    732b29e012a6:	4c 89 ef             	mov    rdi,r13
    732b29e012a9:	e8 b2 ee ff e7       	call   0x732b11e00160
    732b29e012ae:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e012b1:	0f 84 22 fc ff e7    	je     0x732b11e00ed9
    732b29e012b7:	eb 0f                	jmp    0x732b29e012c8
    732b29e012b9:	b8 54 00 01 00       	mov    eax,0x10054
    732b29e012be:	83 c0 02             	add    eax,0x2
    732b29e012c1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e012c8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e012cf:	02 00 00 00 
    732b29e012d3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e012da:	09 00 00 00 
    732b29e012de:	4c 89 ef             	mov    rdi,r13
    732b29e012e1:	e8 6a ee ff e7       	call   0x732b11e00150
    732b29e012e6:	e9 ee fb ff e7       	jmp    0x732b11e00ed9
    732b29e012eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    732b29e012f2:	56 00 01 00 
    732b29e012f6:	b8 56 00 01 00       	mov    eax,0x10056
    732b29e012fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01302:	04 00 00 00 
    732b29e01306:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e0130d:	0a 00 00 00 
    732b29e01311:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01314:	be 56 00 01 00       	mov    esi,0x10056
    732b29e01319:	4c 89 ef             	mov    rdi,r13
    732b29e0131c:	e8 3f ee ff e7       	call   0x732b11e00160
    732b29e01321:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01328:	00 
    732b29e01329:	0f 84 e4 fb ff e7    	je     0x732b11e00f13
    732b29e0132f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01336:	04 00 00 00 
    732b29e0133a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e01341:	0a 00 00 00 
    732b29e01345:	58                   	pop    rax
    732b29e01346:	e9 f7 00 00 e8       	jmp    0x732b11e01442
    732b29e0134b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005a
    732b29e01352:	5a 00 01 00 
    732b29e01356:	b8 5a 00 01 00       	mov    eax,0x1005a
    732b29e0135b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01362:	02 00 00 00 
    732b29e01366:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e0136d:	0b 00 00 00 
    732b29e01371:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01374:	be 5a 00 01 00       	mov    esi,0x1005a
    732b29e01379:	4c 89 ef             	mov    rdi,r13
    732b29e0137c:	e8 df ed ff e7       	call   0x732b11e00160
    732b29e01381:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01388:	00 
    732b29e01389:	0f 84 ad fb ff e7    	je     0x732b11e00f3c
    732b29e0138f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01396:	02 00 00 00 
    732b29e0139a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e013a1:	0b 00 00 00 
    732b29e013a5:	58                   	pop    rax
    732b29e013a6:	e9 97 00 00 e8       	jmp    0x732b11e01442
    732b29e013ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    732b29e013b2:	5c 00 01 00 
    732b29e013b6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e013bd:	02 00 00 00 
    732b29e013c1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e013c8:	0c 00 00 00 
    732b29e013cc:	ba 5c 00 01 00       	mov    edx,0x1005c
    732b29e013d1:	4c 89 ef             	mov    rdi,r13
    732b29e013d4:	4c 89 f6             	mov    rsi,r14
    732b29e013d7:	45 31 c0             	xor    r8d,r8d
    732b29e013da:	e8 a1 ec ff e7       	call   0x732b11e00080
    732b29e013df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e013e6:	02 00 00 00 
    732b29e013ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e013f1:	0c 00 00 00 
    732b29e013f5:	58                   	pop    rax
    732b29e013f6:	e9 47 00 00 e8       	jmp    0x732b11e01442
    732b29e013fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    732b29e01402:	5c 00 01 00 
    732b29e01406:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0140d:	02 00 00 00 
    732b29e01411:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e01418:	0c 00 00 00 
    732b29e0141c:	4c 89 f7             	mov    rdi,r14
    732b29e0141f:	89 ce                	mov    esi,ecx
    732b29e01421:	e8 1a ec ff e7       	call   0x732b11e00040
    732b29e01426:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0142d:	00 
    732b29e0142e:	0f 84 3b fb ff e7    	je     0x732b11e00f6f
    732b29e01434:	eb a9                	jmp    0x732b29e013df
    732b29e01436:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    732b29e0143d:	5c 00 01 00 
    732b29e01441:	b8 5c 00 01 00       	mov    eax,0x1005c
    732b29e01446:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0144d:	02 00 00 00 
    732b29e01451:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e01458:	0c 00 00 00 
    732b29e0145c:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0145f:	be 5c 00 01 00       	mov    esi,0x1005c
    732b29e01464:	4c 89 ef             	mov    rdi,r13
    732b29e01467:	e8 f4 ec ff e7       	call   0x732b11e00160
    732b29e0146c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01473:	00 
    732b29e01474:	0f 84 1b fb ff e7    	je     0x732b11e00f95
    732b29e0147a:	e9 60 ff ff ff       	jmp    0x732b29e013df
    732b29e0147f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005e
    732b29e01486:	5e 00 01 00 
    732b29e0148a:	b8 5e 00 01 00       	mov    eax,0x1005e
    732b29e0148f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01496:	04 00 00 00 
    732b29e0149a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e014a1:	0d 00 00 00 
    732b29e014a5:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e014a8:	be 5e 00 01 00       	mov    esi,0x1005e
    732b29e014ad:	4c 89 ef             	mov    rdi,r13
    732b29e014b0:	e8 ab ec ff e7       	call   0x732b11e00160
    732b29e014b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e014bc:	00 
    732b29e014bd:	0f 84 06 fb ff e7    	je     0x732b11e00fc9
    732b29e014c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e014ca:	04 00 00 00 
    732b29e014ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e014d5:	0d 00 00 00 
    732b29e014d9:	58                   	pop    rax
    732b29e014da:	e9 63 ff ff e7       	jmp    0x732b11e01442
    732b29e014df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10062
    732b29e014e6:	62 00 01 00 
    732b29e014ea:	b8 62 00 01 00       	mov    eax,0x10062
    732b29e014ef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e014f6:	04 00 00 00 
    732b29e014fa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e01501:	0e 00 00 00 
    732b29e01505:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01508:	be 62 00 01 00       	mov    esi,0x10062
    732b29e0150d:	4c 89 ef             	mov    rdi,r13
    732b29e01510:	e8 4b ec ff e7       	call   0x732b11e00160
    732b29e01515:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0151c:	00 
    732b29e0151d:	0f 84 da fa ff e7    	je     0x732b11e00ffd
    732b29e01523:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0152a:	04 00 00 00 
    732b29e0152e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e01535:	0e 00 00 00 
    732b29e01539:	58                   	pop    rax
    732b29e0153a:	e9 03 ff ff e7       	jmp    0x732b11e01442
    732b29e0153f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10066
    732b29e01546:	66 00 01 00 
    732b29e0154a:	b8 66 00 01 00       	mov    eax,0x10066
    732b29e0154f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01556:	04 00 00 00 
    732b29e0155a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e01561:	0f 00 00 00 
    732b29e01565:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01568:	be 66 00 01 00       	mov    esi,0x10066
    732b29e0156d:	4c 89 ef             	mov    rdi,r13
    732b29e01570:	e8 eb eb ff e7       	call   0x732b11e00160
    732b29e01575:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0157c:	00 
    732b29e0157d:	0f 84 b1 fa ff e7    	je     0x732b11e01034
    732b29e01583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0158a:	04 00 00 00 
    732b29e0158e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e01595:	0f 00 00 00 
    732b29e01599:	58                   	pop    rax
    732b29e0159a:	e9 a3 fe ff e7       	jmp    0x732b11e01442
    732b29e0159f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    732b29e015a6:	6a 00 01 00 
    732b29e015aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e015b1:	02 00 00 00 
    732b29e015b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e015bc:	10 00 00 00 
    732b29e015c0:	ba 6a 00 01 00       	mov    edx,0x1006a
    732b29e015c5:	4c 89 ef             	mov    rdi,r13
    732b29e015c8:	4c 89 f6             	mov    rsi,r14
    732b29e015cb:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e015d1:	e8 aa ea ff e7       	call   0x732b11e00080
    732b29e015d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e015dd:	02 00 00 00 
    732b29e015e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e015e8:	10 00 00 00 
    732b29e015ec:	58                   	pop    rax
    732b29e015ed:	e9 50 fe ff e7       	jmp    0x732b11e01442
    732b29e015f2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    732b29e015f9:	6a 00 01 00 
    732b29e015fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01604:	02 00 00 00 
    732b29e01608:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e0160f:	10 00 00 00 
    732b29e01613:	4c 89 f7             	mov    rdi,r14
    732b29e01616:	89 ce                	mov    esi,ecx
    732b29e01618:	e8 53 ea ff e7       	call   0x732b11e00070
    732b29e0161d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01624:	00 
    732b29e01625:	0f 84 47 fa ff e7    	je     0x732b11e01072
    732b29e0162b:	eb a9                	jmp    0x732b29e015d6
    732b29e0162d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    732b29e01634:	6a 00 01 00 
    732b29e01638:	b8 6a 00 01 00       	mov    eax,0x1006a
    732b29e0163d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01644:	02 00 00 00 
    732b29e01648:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e0164f:	10 00 00 00 
    732b29e01653:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01656:	be 6a 00 01 00       	mov    esi,0x1006a
    732b29e0165b:	4c 89 ef             	mov    rdi,r13
    732b29e0165e:	e8 fd ea ff e7       	call   0x732b11e00160
    732b29e01663:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e01666:	0f 84 37 fa ff e7    	je     0x732b11e010a3
    732b29e0166c:	eb 0f                	jmp    0x732b29e0167d
    732b29e0166e:	b8 6a 00 01 00       	mov    eax,0x1006a
    732b29e01673:	83 c0 02             	add    eax,0x2
    732b29e01676:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0167d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01684:	02 00 00 00 
    732b29e01688:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e0168f:	10 00 00 00 
    732b29e01693:	4c 89 ef             	mov    rdi,r13
    732b29e01696:	e8 b5 ea ff e7       	call   0x732b11e00150
    732b29e0169b:	e9 03 fa ff e7       	jmp    0x732b11e010a3
    732b29e016a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    732b29e016a7:	6c 00 01 00 
    732b29e016ab:	b8 6c 00 01 00       	mov    eax,0x1006c
    732b29e016b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e016b7:	04 00 00 00 
    732b29e016bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e016c2:	11 00 00 00 
    732b29e016c6:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e016c9:	be 6c 00 01 00       	mov    esi,0x1006c
    732b29e016ce:	4c 89 ef             	mov    rdi,r13
    732b29e016d1:	e8 8a ea ff e7       	call   0x732b11e00160
    732b29e016d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e016dd:	00 
    732b29e016de:	0f 84 01 fa ff e7    	je     0x732b11e010e5
    732b29e016e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e016eb:	04 00 00 00 
    732b29e016ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e016f6:	11 00 00 00 
    732b29e016fa:	58                   	pop    rax
    732b29e016fb:	e9 42 fd ff e7       	jmp    0x732b11e01442
    732b29e01700:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10070
    732b29e01707:	70 00 01 00 
    732b29e0170b:	b8 70 00 01 00       	mov    eax,0x10070
    732b29e01710:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01717:	04 00 00 00 
    732b29e0171b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e01722:	12 00 00 00 
    732b29e01726:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01729:	be 70 00 01 00       	mov    esi,0x10070
    732b29e0172e:	4c 89 ef             	mov    rdi,r13
    732b29e01731:	e8 2a ea ff e7       	call   0x732b11e00160
    732b29e01736:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0173d:	00 
    732b29e0173e:	0f 84 d8 f9 ff e7    	je     0x732b11e0111c
    732b29e01744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0174b:	04 00 00 00 
    732b29e0174f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e01756:	12 00 00 00 
    732b29e0175a:	58                   	pop    rax
    732b29e0175b:	e9 e2 fc ff e7       	jmp    0x732b11e01442
    732b29e01760:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    732b29e01767:	74 00 01 00 
    732b29e0176b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01772:	02 00 00 00 
    732b29e01776:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e0177d:	13 00 00 00 
    732b29e01781:	ba 74 00 01 00       	mov    edx,0x10074
    732b29e01786:	4c 89 ef             	mov    rdi,r13
    732b29e01789:	4c 89 f6             	mov    rsi,r14
    732b29e0178c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e01792:	e8 e9 e8 ff e7       	call   0x732b11e00080
    732b29e01797:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0179e:	02 00 00 00 
    732b29e017a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e017a9:	13 00 00 00 
    732b29e017ad:	58                   	pop    rax
    732b29e017ae:	e9 8f fc ff e7       	jmp    0x732b11e01442
    732b29e017b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    732b29e017ba:	74 00 01 00 
    732b29e017be:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e017c5:	02 00 00 00 
    732b29e017c9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e017d0:	13 00 00 00 
    732b29e017d4:	4c 89 f7             	mov    rdi,r14
    732b29e017d7:	89 ce                	mov    esi,ecx
    732b29e017d9:	e8 92 e8 ff e7       	call   0x732b11e00070
    732b29e017de:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e017e5:	00 
    732b29e017e6:	0f 84 6e f9 ff e7    	je     0x732b11e0115a
    732b29e017ec:	eb a9                	jmp    0x732b29e01797
    732b29e017ee:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    732b29e017f5:	74 00 01 00 
    732b29e017f9:	b8 74 00 01 00       	mov    eax,0x10074
    732b29e017fe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01805:	02 00 00 00 
    732b29e01809:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e01810:	13 00 00 00 
    732b29e01814:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01817:	be 74 00 01 00       	mov    esi,0x10074
    732b29e0181c:	4c 89 ef             	mov    rdi,r13
    732b29e0181f:	e8 3c e9 ff e7       	call   0x732b11e00160
    732b29e01824:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e01827:	0f 84 5e f9 ff e7    	je     0x732b11e0118b
    732b29e0182d:	eb 0f                	jmp    0x732b29e0183e
    732b29e0182f:	b8 74 00 01 00       	mov    eax,0x10074
    732b29e01834:	83 c0 02             	add    eax,0x2
    732b29e01837:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0183e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01845:	02 00 00 00 
    732b29e01849:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e01850:	13 00 00 00 
    732b29e01854:	4c 89 ef             	mov    rdi,r13
    732b29e01857:	e8 f4 e8 ff e7       	call   0x732b11e00150
    732b29e0185c:	e9 2a f9 ff e7       	jmp    0x732b11e0118b
    732b29e01861:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    732b29e01868:	76 00 01 00 
    732b29e0186c:	b8 76 00 01 00       	mov    eax,0x10076
    732b29e01871:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01878:	02 00 00 00 
    732b29e0187c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e01883:	14 00 00 00 
    732b29e01887:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0188a:	be 76 00 01 00       	mov    esi,0x10076
    732b29e0188f:	4c 89 ef             	mov    rdi,r13
    732b29e01892:	e8 c9 e8 ff e7       	call   0x732b11e00160
    732b29e01897:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0189e:	00 
    732b29e0189f:	0f 84 20 f9 ff e7    	je     0x732b11e011c5
    732b29e018a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e018ac:	02 00 00 00 
    732b29e018b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e018b7:	14 00 00 00 
    732b29e018bb:	58                   	pop    rax
    732b29e018bc:	e9 81 fb ff e7       	jmp    0x732b11e01442
    732b29e018c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    732b29e018c8:	78 00 01 00 
    732b29e018cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e018d3:	02 00 00 00 
    732b29e018d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e018de:	15 00 00 00 
    732b29e018e2:	ba 78 00 01 00       	mov    edx,0x10078
    732b29e018e7:	4c 89 ef             	mov    rdi,r13
    732b29e018ea:	4c 89 f6             	mov    rsi,r14
    732b29e018ed:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e018f3:	e8 88 e7 ff e7       	call   0x732b11e00080
    732b29e018f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e018ff:	02 00 00 00 
    732b29e01903:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e0190a:	15 00 00 00 
    732b29e0190e:	58                   	pop    rax
    732b29e0190f:	e9 2e fb ff e7       	jmp    0x732b11e01442
    732b29e01914:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    732b29e0191b:	78 00 01 00 
    732b29e0191f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01926:	02 00 00 00 
    732b29e0192a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e01931:	15 00 00 00 
    732b29e01935:	4c 89 f7             	mov    rdi,r14
    732b29e01938:	89 ce                	mov    esi,ecx
    732b29e0193a:	e8 31 e7 ff e7       	call   0x732b11e00070
    732b29e0193f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01946:	00 
    732b29e01947:	0f 84 b6 f8 ff e7    	je     0x732b11e01203
    732b29e0194d:	eb a9                	jmp    0x732b29e018f8
    732b29e0194f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    732b29e01956:	78 00 01 00 
    732b29e0195a:	b8 78 00 01 00       	mov    eax,0x10078
    732b29e0195f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01966:	02 00 00 00 
    732b29e0196a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e01971:	15 00 00 00 
    732b29e01975:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01978:	be 78 00 01 00       	mov    esi,0x10078
    732b29e0197d:	4c 89 ef             	mov    rdi,r13
    732b29e01980:	e8 db e7 ff e7       	call   0x732b11e00160
    732b29e01985:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e01988:	0f 84 a6 f8 ff e7    	je     0x732b11e01234
    732b29e0198e:	eb 0f                	jmp    0x732b29e0199f
    732b29e01990:	b8 78 00 01 00       	mov    eax,0x10078
    732b29e01995:	83 c0 02             	add    eax,0x2
    732b29e01998:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0199f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e019a6:	02 00 00 00 
    732b29e019aa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e019b1:	15 00 00 00 
    732b29e019b5:	4c 89 ef             	mov    rdi,r13
    732b29e019b8:	e8 93 e7 ff e7       	call   0x732b11e00150
    732b29e019bd:	e9 72 f8 ff e7       	jmp    0x732b11e01234
    732b29e019c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    732b29e019c9:	7a 00 01 00 
    732b29e019cd:	b8 7a 00 01 00       	mov    eax,0x1007a
    732b29e019d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e019d9:	02 00 00 00 
    732b29e019dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e019e4:	16 00 00 00 
    732b29e019e8:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e019eb:	be 7a 00 01 00       	mov    esi,0x1007a
    732b29e019f0:	4c 89 ef             	mov    rdi,r13
    732b29e019f3:	e8 68 e7 ff e7       	call   0x732b11e00160
    732b29e019f8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e019ff:	00 
    732b29e01a00:	0f 84 68 f8 ff e7    	je     0x732b11e0126e
    732b29e01a06:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01a0d:	02 00 00 00 
    732b29e01a11:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e01a18:	16 00 00 00 
    732b29e01a1c:	58                   	pop    rax
    732b29e01a1d:	e9 20 fa ff e7       	jmp    0x732b11e01442
    732b29e01a22:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007c
    732b29e01a29:	7c 00 01 00 
    732b29e01a2d:	b8 7c 00 01 00       	mov    eax,0x1007c
    732b29e01a32:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01a39:	04 00 00 00 
    732b29e01a3d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e01a44:	17 00 00 00 
    732b29e01a48:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01a4b:	be 7c 00 01 00       	mov    esi,0x1007c
    732b29e01a50:	4c 89 ef             	mov    rdi,r13
    732b29e01a53:	e8 08 e7 ff e7       	call   0x732b11e00160
    732b29e01a58:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01a5f:	00 
    732b29e01a60:	0f 84 3f f8 ff e7    	je     0x732b11e012a5
    732b29e01a66:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01a6d:	04 00 00 00 
    732b29e01a71:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e01a78:	17 00 00 00 
    732b29e01a7c:	58                   	pop    rax
    732b29e01a7d:	e9 c0 f9 ff e7       	jmp    0x732b11e01442
    732b29e01a82:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10080
    732b29e01a89:	80 00 01 00 
    732b29e01a8d:	b8 80 00 01 00       	mov    eax,0x10080
    732b29e01a92:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01a99:	02 00 00 00 
    732b29e01a9d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    732b29e01aa4:	18 00 00 00 
    732b29e01aa8:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01aab:	be 80 00 01 00       	mov    esi,0x10080
    732b29e01ab0:	4c 89 ef             	mov    rdi,r13
    732b29e01ab3:	e8 a8 e6 ff e7       	call   0x732b11e00160
    732b29e01ab8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01abf:	00 
    732b29e01ac0:	0f 84 0b f8 ff e7    	je     0x732b11e012d1
    732b29e01ac6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01acd:	02 00 00 00 
    732b29e01ad1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    732b29e01ad8:	18 00 00 00 
    732b29e01adc:	58                   	pop    rax
    732b29e01add:	e9 60 f9 ff e7       	jmp    0x732b11e01442
    732b29e01ae2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10082
    732b29e01ae9:	82 00 01 00 
    732b29e01aed:	b8 82 00 01 00       	mov    eax,0x10082
    732b29e01af2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01af9:	02 00 00 00 
    732b29e01afd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e01b04:	19 00 00 00 
    732b29e01b08:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01b0b:	be 82 00 01 00       	mov    esi,0x10082
    732b29e01b10:	4c 89 ef             	mov    rdi,r13
    732b29e01b13:	e8 48 e6 ff e7       	call   0x732b11e00160
    732b29e01b18:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01b1f:	00 
    732b29e01b20:	0f 84 d7 f7 ff e7    	je     0x732b11e012fd
    732b29e01b26:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01b2d:	02 00 00 00 
    732b29e01b31:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e01b38:	19 00 00 00 
    732b29e01b3c:	58                   	pop    rax
    732b29e01b3d:	e9 00 f9 ff e7       	jmp    0x732b11e01442
    732b29e01b42:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    732b29e01b49:	84 00 01 00 
    732b29e01b4d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e01b54:	08 00 00 00 
    732b29e01b58:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e01b5f:	1a 00 00 00 
    732b29e01b63:	ba 84 00 01 00       	mov    edx,0x10084
    732b29e01b68:	4c 89 ef             	mov    rdi,r13
    732b29e01b6b:	4c 89 f6             	mov    rsi,r14
    732b29e01b6e:	45 31 c0             	xor    r8d,r8d
    732b29e01b71:	e8 0a e5 ff e7       	call   0x732b11e00080
    732b29e01b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e01b7d:	08 00 00 00 
    732b29e01b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e01b88:	1a 00 00 00 
    732b29e01b8c:	58                   	pop    rax
    732b29e01b8d:	e9 b0 f8 ff e7       	jmp    0x732b11e01442
    732b29e01b92:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    732b29e01b99:	84 00 01 00 
    732b29e01b9d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    732b29e01ba4:	08 00 00 00 
    732b29e01ba8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e01baf:	1a 00 00 00 
    732b29e01bb3:	4c 89 f7             	mov    rdi,r14
    732b29e01bb6:	89 ce                	mov    esi,ecx
    732b29e01bb8:	e8 83 e4 ff e7       	call   0x732b11e00040
    732b29e01bbd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01bc4:	00 
    732b29e01bc5:	0f 84 65 f7 ff e7    	je     0x732b11e01330
    732b29e01bcb:	eb a9                	jmp    0x732b29e01b76
    732b29e01bcd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e01bd4:	8c 00 01 00 
    732b29e01bd8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01bdf:	02 00 00 00 
    732b29e01be3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e01bea:	1b 00 00 00 
    732b29e01bee:	ba 8c 00 01 00       	mov    edx,0x1008c
    732b29e01bf3:	4c 89 ef             	mov    rdi,r13
    732b29e01bf6:	4c 89 f6             	mov    rsi,r14
    732b29e01bf9:	45 31 c0             	xor    r8d,r8d
    732b29e01bfc:	e8 7f e4 ff e7       	call   0x732b11e00080
    732b29e01c01:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01c08:	02 00 00 00 
    732b29e01c0c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e01c13:	1b 00 00 00 
    732b29e01c17:	58                   	pop    rax
    732b29e01c18:	e9 25 f8 ff e7       	jmp    0x732b11e01442
    732b29e01c1d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e01c24:	8c 00 01 00 
    732b29e01c28:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01c2f:	02 00 00 00 
    732b29e01c33:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e01c3a:	1b 00 00 00 
    732b29e01c3e:	4c 89 f7             	mov    rdi,r14
    732b29e01c41:	89 ce                	mov    esi,ecx
    732b29e01c43:	e8 f8 e3 ff e7       	call   0x732b11e00040
    732b29e01c48:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01c4f:	00 
    732b29e01c50:	0f 84 2d f7 ff e7    	je     0x732b11e01383
    732b29e01c56:	eb a9                	jmp    0x732b29e01c01
    732b29e01c58:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    732b29e01c5f:	8c 00 01 00 
    732b29e01c63:	b8 8c 00 01 00       	mov    eax,0x1008c
    732b29e01c68:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01c6f:	02 00 00 00 
    732b29e01c73:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e01c7a:	1b 00 00 00 
    732b29e01c7e:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01c81:	be 8c 00 01 00       	mov    esi,0x1008c
    732b29e01c86:	4c 89 ef             	mov    rdi,r13
    732b29e01c89:	e8 d2 e4 ff e7       	call   0x732b11e00160
    732b29e01c8e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01c95:	00 
    732b29e01c96:	0f 84 0d f7 ff e7    	je     0x732b11e013a9
    732b29e01c9c:	e9 60 ff ff ff       	jmp    0x732b29e01c01
    732b29e01ca1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01ca8:	28 03 01 00 
    732b29e01cac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01cb3:	04 00 00 00 
    732b29e01cb7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    732b29e01cbe:	1c 00 00 00 
    732b29e01cc2:	be 8e 00 01 00       	mov    esi,0x1008e
    732b29e01cc7:	ba 8e 00 01 00       	mov    edx,0x1008e
    732b29e01ccc:	4c 89 ef             	mov    rdi,r13
    732b29e01ccf:	e8 8c e4 ff e7       	call   0x732b11e00160
    732b29e01cd4:	e9 47 f7 ff e7       	jmp    0x732b11e01420
    732b29e01cd9:	c2 08 00             	ret    0x8
