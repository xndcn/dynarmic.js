
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65556-1-126629223334096.bin:     file format binary


Disassembly of section .data:

0000732b29e000d0 <.data>:
    732b29e000d0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e000d6:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e000d9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e000df:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e000e6:	0f 87 a5 03 00 e8    	ja     0x732b11e00491
    732b29e000ec:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x1
    732b29e000f3:	01 00 00 00 
    732b29e000f7:	e9 95 03 00 e8       	jmp    0x732b11e00491
    732b29e000fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00103:	14 00 01 00 
    732b29e00107:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0010e:	02 00 00 00 
    732b29e00112:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00119:	01 00 00 00 
    732b29e0011d:	ba 14 00 01 00       	mov    edx,0x10014
    732b29e00122:	4c 89 ef             	mov    rdi,r13
    732b29e00125:	4c 89 f6             	mov    rsi,r14
    732b29e00128:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e0012e:	e8 4d ff ff e7       	call   0x732b11e00080
    732b29e00133:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0013a:	02 00 00 00 
    732b29e0013e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00145:	01 00 00 00 
    732b29e00149:	58                   	pop    rax
    732b29e0014a:	e9 8e 0a 00 e8       	jmp    0x732b11e00bdd
    732b29e0014f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00156:	14 00 01 00 
    732b29e0015a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00161:	02 00 00 00 
    732b29e00165:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0016c:	01 00 00 00 
    732b29e00170:	4c 89 f7             	mov    rdi,r14
    732b29e00173:	89 ce                	mov    esi,ecx
    732b29e00175:	e8 f6 fe ff e7       	call   0x732b11e00070
    732b29e0017a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00181:	00 
    732b29e00182:	0f 84 48 03 00 e8    	je     0x732b11e004d0
    732b29e00188:	eb a9                	jmp    0x732b29e00133
    732b29e0018a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00191:	14 00 01 00 
    732b29e00195:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0019c:	02 00 00 00 
    732b29e001a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e001a7:	01 00 00 00 
    732b29e001ab:	4c 89 f7             	mov    rdi,r14
    732b29e001ae:	e8 bd fe ff e7       	call   0x732b11e00070
    732b29e001b3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e001ba:	00 
    732b29e001bb:	0f 84 32 03 00 e8    	je     0x732b11e004f3
    732b29e001c1:	e9 6d ff ff ff       	jmp    0x732b29e00133
    732b29e001c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e001cd:	14 00 01 00 
    732b29e001d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e001d8:	02 00 00 00 
    732b29e001dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e001e3:	01 00 00 00 
    732b29e001e7:	4c 89 f7             	mov    rdi,r14
    732b29e001ea:	e8 81 fe ff e7       	call   0x732b11e00070
    732b29e001ef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e001f6:	00 
    732b29e001f7:	0f 84 19 03 00 e8    	je     0x732b11e00516
    732b29e001fd:	e9 31 ff ff ff       	jmp    0x732b29e00133
    732b29e00202:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00209:	14 00 01 00 
    732b29e0020d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00214:	02 00 00 00 
    732b29e00218:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0021f:	01 00 00 00 
    732b29e00223:	4c 89 f7             	mov    rdi,r14
    732b29e00226:	e8 45 fe ff e7       	call   0x732b11e00070
    732b29e0022b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00232:	00 
    732b29e00233:	0f 84 00 03 00 e8    	je     0x732b11e00539
    732b29e00239:	e9 f5 fe ff ff       	jmp    0x732b29e00133
    732b29e0023e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00245:	14 00 01 00 
    732b29e00249:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00250:	02 00 00 00 
    732b29e00254:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0025b:	01 00 00 00 
    732b29e0025f:	4c 89 f7             	mov    rdi,r14
    732b29e00262:	e8 09 fe ff e7       	call   0x732b11e00070
    732b29e00267:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0026e:	00 
    732b29e0026f:	0f 84 e7 02 00 e8    	je     0x732b11e0055c
    732b29e00275:	e9 b9 fe ff ff       	jmp    0x732b29e00133
    732b29e0027a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e00281:	14 00 01 00 
    732b29e00285:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0028c:	02 00 00 00 
    732b29e00290:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00297:	01 00 00 00 
    732b29e0029b:	4c 89 f7             	mov    rdi,r14
    732b29e0029e:	e8 cd fd ff e7       	call   0x732b11e00070
    732b29e002a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e002aa:	00 
    732b29e002ab:	0f 84 ce 02 00 e8    	je     0x732b11e0057f
    732b29e002b1:	e9 7d fe ff ff       	jmp    0x732b29e00133
    732b29e002b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e002bd:	14 00 01 00 
    732b29e002c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e002c8:	02 00 00 00 
    732b29e002cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e002d3:	01 00 00 00 
    732b29e002d7:	4c 89 f7             	mov    rdi,r14
    732b29e002da:	89 de                	mov    esi,ebx
    732b29e002dc:	e8 8f fd ff e7       	call   0x732b11e00070
    732b29e002e1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e002e8:	00 
    732b29e002e9:	0f 84 b5 02 00 e8    	je     0x732b11e005a4
    732b29e002ef:	e9 3f fe ff ff       	jmp    0x732b29e00133
    732b29e002f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    732b29e002fb:	14 00 01 00 
    732b29e002ff:	b8 14 00 01 00       	mov    eax,0x10014
    732b29e00304:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0030b:	02 00 00 00 
    732b29e0030f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00316:	01 00 00 00 
    732b29e0031a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0031d:	be 14 00 01 00       	mov    esi,0x10014
    732b29e00322:	4c 89 ef             	mov    rdi,r13
    732b29e00325:	e8 36 fe ff e7       	call   0x732b11e00160
    732b29e0032a:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e0032e:	0f 84 a6 02 00 e8    	je     0x732b11e005da
    732b29e00334:	eb 0f                	jmp    0x732b29e00345
    732b29e00336:	b8 14 00 01 00       	mov    eax,0x10014
    732b29e0033b:	83 c0 02             	add    eax,0x2
    732b29e0033e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e00345:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0034c:	02 00 00 00 
    732b29e00350:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e00357:	01 00 00 00 
    732b29e0035b:	4c 89 ef             	mov    rdi,r13
    732b29e0035e:	e8 ed fd ff e7       	call   0x732b11e00150
    732b29e00363:	e9 72 02 00 e8       	jmp    0x732b11e005da
    732b29e00368:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    732b29e0036f:	16 00 01 00 
    732b29e00373:	b8 16 00 01 00       	mov    eax,0x10016
    732b29e00378:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0037f:	04 00 00 00 
    732b29e00383:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0038a:	02 00 00 00 
    732b29e0038e:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e00391:	be 16 00 01 00       	mov    esi,0x10016
    732b29e00396:	4c 89 ef             	mov    rdi,r13
    732b29e00399:	e8 c2 fd ff e7       	call   0x732b11e00160
    732b29e0039e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e003a5:	00 
    732b29e003a6:	0f 84 70 02 00 e8    	je     0x732b11e0061c
    732b29e003ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e003b3:	04 00 00 00 
    732b29e003b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e003be:	02 00 00 00 
    732b29e003c2:	58                   	pop    rax
    732b29e003c3:	e9 15 08 00 e8       	jmp    0x732b11e00bdd
    732b29e003c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    732b29e003cf:	1a 00 01 00 
    732b29e003d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e003da:	04 00 00 00 
    732b29e003de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e003e5:	03 00 00 00 
    732b29e003e9:	ba 1a 00 01 00       	mov    edx,0x1001a
    732b29e003ee:	4c 89 ef             	mov    rdi,r13
    732b29e003f1:	4c 89 f6             	mov    rsi,r14
    732b29e003f4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e003fa:	e8 81 fc ff e7       	call   0x732b11e00080
    732b29e003ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00406:	04 00 00 00 
    732b29e0040a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00411:	03 00 00 00 
    732b29e00415:	58                   	pop    rax
    732b29e00416:	e9 c2 07 00 e8       	jmp    0x732b11e00bdd
    732b29e0041b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    732b29e00422:	1a 00 01 00 
    732b29e00426:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0042d:	04 00 00 00 
    732b29e00431:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00438:	03 00 00 00 
    732b29e0043c:	4c 89 f7             	mov    rdi,r14
    732b29e0043f:	89 ce                	mov    esi,ecx
    732b29e00441:	e8 2a fc ff e7       	call   0x732b11e00070
    732b29e00446:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0044d:	00 
    732b29e0044e:	0f 84 0f 02 00 e8    	je     0x732b11e00663
    732b29e00454:	eb a9                	jmp    0x732b29e003ff
    732b29e00456:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    732b29e0045d:	1a 00 01 00 
    732b29e00461:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00468:	04 00 00 00 
    732b29e0046c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e00473:	03 00 00 00 
    732b29e00477:	4c 89 f7             	mov    rdi,r14
    732b29e0047a:	89 de                	mov    esi,ebx
    732b29e0047c:	44 89 e2             	mov    edx,r12d
    732b29e0047f:	e8 ec fb ff e7       	call   0x732b11e00070
    732b29e00484:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0048b:	00 
    732b29e0048c:	0f 84 f3 01 00 e8    	je     0x732b11e00685
    732b29e00492:	e9 68 ff ff ff       	jmp    0x732b29e003ff
    732b29e00497:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    732b29e0049e:	1a 00 01 00 
    732b29e004a2:	b8 1a 00 01 00       	mov    eax,0x1001a
    732b29e004a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e004ae:	04 00 00 00 
    732b29e004b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e004b9:	03 00 00 00 
    732b29e004bd:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e004c0:	be 1a 00 01 00       	mov    esi,0x1001a
    732b29e004c5:	4c 89 ef             	mov    rdi,r13
    732b29e004c8:	e8 93 fc ff e7       	call   0x732b11e00160
    732b29e004cd:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e004d1:	0f 84 ef 01 00 e8    	je     0x732b11e006c6
    732b29e004d7:	eb 0f                	jmp    0x732b29e004e8
    732b29e004d9:	b8 1a 00 01 00       	mov    eax,0x1001a
    732b29e004de:	83 c0 04             	add    eax,0x4
    732b29e004e1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e004e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e004ef:	04 00 00 00 
    732b29e004f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e004fa:	03 00 00 00 
    732b29e004fe:	4c 89 ef             	mov    rdi,r13
    732b29e00501:	e8 4a fc ff e7       	call   0x732b11e00150
    732b29e00506:	e9 bb 01 00 e8       	jmp    0x732b11e006c6
    732b29e0050b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    732b29e00512:	1e 00 01 00 
    732b29e00516:	b8 1e 00 01 00       	mov    eax,0x1001e
    732b29e0051b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00522:	04 00 00 00 
    732b29e00526:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0052d:	04 00 00 00 
    732b29e00531:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e00534:	be 1e 00 01 00       	mov    esi,0x1001e
    732b29e00539:	4c 89 ef             	mov    rdi,r13
    732b29e0053c:	e8 1f fc ff e7       	call   0x732b11e00160
    732b29e00541:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00548:	00 
    732b29e00549:	0f 84 bc 01 00 e8    	je     0x732b11e0070b
    732b29e0054f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00556:	04 00 00 00 
    732b29e0055a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e00561:	04 00 00 00 
    732b29e00565:	58                   	pop    rax
    732b29e00566:	e9 72 06 00 e8       	jmp    0x732b11e00bdd
    732b29e0056b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10022
    732b29e00572:	22 00 01 00 
    732b29e00576:	b8 22 00 01 00       	mov    eax,0x10022
    732b29e0057b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00582:	04 00 00 00 
    732b29e00586:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0058d:	05 00 00 00 
    732b29e00591:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e00594:	be 22 00 01 00       	mov    esi,0x10022
    732b29e00599:	4c 89 ef             	mov    rdi,r13
    732b29e0059c:	e8 bf fb ff e7       	call   0x732b11e00160
    732b29e005a1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e005a8:	00 
    732b29e005a9:	0f 84 90 01 00 e8    	je     0x732b11e0073f
    732b29e005af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e005b6:	04 00 00 00 
    732b29e005ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e005c1:	05 00 00 00 
    732b29e005c5:	58                   	pop    rax
    732b29e005c6:	e9 12 06 00 e8       	jmp    0x732b11e00bdd
    732b29e005cb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    732b29e005d2:	26 00 01 00 
    732b29e005d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e005dd:	02 00 00 00 
    732b29e005e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e005e8:	06 00 00 00 
    732b29e005ec:	ba 26 00 01 00       	mov    edx,0x10026
    732b29e005f1:	4c 89 ef             	mov    rdi,r13
    732b29e005f4:	4c 89 f6             	mov    rsi,r14
    732b29e005f7:	45 31 c0             	xor    r8d,r8d
    732b29e005fa:	e8 81 fa ff e7       	call   0x732b11e00080
    732b29e005ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00606:	02 00 00 00 
    732b29e0060a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e00611:	06 00 00 00 
    732b29e00615:	58                   	pop    rax
    732b29e00616:	e9 c2 05 00 e8       	jmp    0x732b11e00bdd
    732b29e0061b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    732b29e00622:	26 00 01 00 
    732b29e00626:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0062d:	02 00 00 00 
    732b29e00631:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e00638:	06 00 00 00 
    732b29e0063c:	4c 89 f7             	mov    rdi,r14
    732b29e0063f:	89 ce                	mov    esi,ecx
    732b29e00641:	e8 fa f9 ff e7       	call   0x732b11e00040
    732b29e00646:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0064d:	00 
    732b29e0064e:	0f 84 1e 01 00 e8    	je     0x732b11e00772
    732b29e00654:	eb a9                	jmp    0x732b29e005ff
    732b29e00656:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    732b29e0065d:	26 00 01 00 
    732b29e00661:	b8 26 00 01 00       	mov    eax,0x10026
    732b29e00666:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0066d:	02 00 00 00 
    732b29e00671:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e00678:	06 00 00 00 
    732b29e0067c:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0067f:	be 26 00 01 00       	mov    esi,0x10026
    732b29e00684:	4c 89 ef             	mov    rdi,r13
    732b29e00687:	e8 d4 fa ff e7       	call   0x732b11e00160
    732b29e0068c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00693:	00 
    732b29e00694:	0f 84 fe 00 00 e8    	je     0x732b11e00798
    732b29e0069a:	e9 60 ff ff ff       	jmp    0x732b29e005ff
    732b29e0069f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10028
    732b29e006a6:	28 00 01 00 
    732b29e006aa:	b8 28 00 01 00       	mov    eax,0x10028
    732b29e006af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e006b6:	04 00 00 00 
    732b29e006ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e006c1:	07 00 00 00 
    732b29e006c5:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e006c8:	be 28 00 01 00       	mov    esi,0x10028
    732b29e006cd:	4c 89 ef             	mov    rdi,r13
    732b29e006d0:	e8 8b fa ff e7       	call   0x732b11e00160
    732b29e006d5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e006dc:	00 
    732b29e006dd:	0f 84 ec 00 00 e8    	je     0x732b11e007cf
    732b29e006e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e006ea:	04 00 00 00 
    732b29e006ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e006f5:	07 00 00 00 
    732b29e006f9:	58                   	pop    rax
    732b29e006fa:	e9 de 04 00 e8       	jmp    0x732b11e00bdd
    732b29e006ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002c
    732b29e00706:	2c 00 01 00 
    732b29e0070a:	b8 2c 00 01 00       	mov    eax,0x1002c
    732b29e0070f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00716:	02 00 00 00 
    732b29e0071a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e00721:	08 00 00 00 
    732b29e00725:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00728:	be 2c 00 01 00       	mov    esi,0x1002c
    732b29e0072d:	4c 89 ef             	mov    rdi,r13
    732b29e00730:	e8 2b fa ff e7       	call   0x732b11e00160
    732b29e00735:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0073c:	00 
    732b29e0073d:	0f 84 fd 00 00 e8    	je     0x732b11e00840
    732b29e00743:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0074a:	02 00 00 00 
    732b29e0074e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e00755:	08 00 00 00 
    732b29e00759:	58                   	pop    rax
    732b29e0075a:	e9 7e 04 00 e8       	jmp    0x732b11e00bdd
    732b29e0075f:	b8 2e 00 01 00       	mov    eax,0x1002e
    732b29e00764:	83 c0 12             	add    eax,0x12
    732b29e00767:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0076e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00775:	02 00 00 00 
    732b29e00779:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e00780:	09 00 00 00 
    732b29e00784:	be 2e 00 01 00       	mov    esi,0x1002e
    732b29e00789:	ba 2e 00 01 00       	mov    edx,0x1002e
    732b29e0078e:	4c 89 ef             	mov    rdi,r13
    732b29e00791:	e8 ca f9 ff e7       	call   0x732b11e00160
    732b29e00796:	e9 db 00 00 e8       	jmp    0x732b11e00876
    732b29e0079b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002e
    732b29e007a2:	2e 00 01 00 
    732b29e007a6:	b8 2e 00 01 00       	mov    eax,0x1002e
    732b29e007ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e007b2:	02 00 00 00 
    732b29e007b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e007bd:	09 00 00 00 
    732b29e007c1:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e007c4:	be 2e 00 01 00       	mov    esi,0x1002e
    732b29e007c9:	4c 89 ef             	mov    rdi,r13
    732b29e007cc:	e8 8f f9 ff e7       	call   0x732b11e00160
    732b29e007d1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e007d8:	00 
    732b29e007d9:	0f 84 e4 00 00 e8    	je     0x732b11e008c3
    732b29e007df:	e9 a1 00 00 e8       	jmp    0x732b11e00885
    732b29e007e4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10030
    732b29e007eb:	30 00 01 00 
    732b29e007ef:	b8 30 00 01 00       	mov    eax,0x10030
    732b29e007f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e007fb:	02 00 00 00 
    732b29e007ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e00806:	0a 00 00 00 
    732b29e0080a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0080d:	be 30 00 01 00       	mov    esi,0x10030
    732b29e00812:	4c 89 ef             	mov    rdi,r13
    732b29e00815:	e8 46 f9 ff e7       	call   0x732b11e00160
    732b29e0081a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00821:	00 
    732b29e00822:	0f 84 c7 00 00 e8    	je     0x732b11e008ef
    732b29e00828:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0082f:	02 00 00 00 
    732b29e00833:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e0083a:	0a 00 00 00 
    732b29e0083e:	58                   	pop    rax
    732b29e0083f:	e9 99 03 00 e8       	jmp    0x732b11e00bdd
    732b29e00844:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10032
    732b29e0084b:	32 00 01 00 
    732b29e0084f:	b8 32 00 01 00       	mov    eax,0x10032
    732b29e00854:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0085b:	02 00 00 00 
    732b29e0085f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e00866:	0b 00 00 00 
    732b29e0086a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0086d:	be 32 00 01 00       	mov    esi,0x10032
    732b29e00872:	4c 89 ef             	mov    rdi,r13
    732b29e00875:	e8 e6 f8 ff e7       	call   0x732b11e00160
    732b29e0087a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00881:	00 
    732b29e00882:	0f 84 90 00 00 e8    	je     0x732b11e00918
    732b29e00888:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0088f:	02 00 00 00 
    732b29e00893:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e0089a:	0b 00 00 00 
    732b29e0089e:	58                   	pop    rax
    732b29e0089f:	e9 39 03 00 e8       	jmp    0x732b11e00bdd
    732b29e008a4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    732b29e008ab:	34 00 01 00 
    732b29e008af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e008b6:	02 00 00 00 
    732b29e008ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e008c1:	0c 00 00 00 
    732b29e008c5:	ba 34 00 01 00       	mov    edx,0x10034
    732b29e008ca:	4c 89 ef             	mov    rdi,r13
    732b29e008cd:	4c 89 f6             	mov    rsi,r14
    732b29e008d0:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e008d6:	e8 a5 f7 ff e7       	call   0x732b11e00080
    732b29e008db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e008e2:	02 00 00 00 
    732b29e008e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e008ed:	0c 00 00 00 
    732b29e008f1:	58                   	pop    rax
    732b29e008f2:	e9 e6 02 00 e8       	jmp    0x732b11e00bdd
    732b29e008f7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    732b29e008fe:	34 00 01 00 
    732b29e00902:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00909:	02 00 00 00 
    732b29e0090d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e00914:	0c 00 00 00 
    732b29e00918:	4c 89 f7             	mov    rdi,r14
    732b29e0091b:	89 ce                	mov    esi,ecx
    732b29e0091d:	e8 4e f7 ff e7       	call   0x732b11e00070
    732b29e00922:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00929:	00 
    732b29e0092a:	0f 84 26 00 00 e8    	je     0x732b11e00956
    732b29e00930:	eb a9                	jmp    0x732b29e008db
    732b29e00932:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    732b29e00939:	34 00 01 00 
    732b29e0093d:	b8 34 00 01 00       	mov    eax,0x10034
    732b29e00942:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00949:	02 00 00 00 
    732b29e0094d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e00954:	0c 00 00 00 
    732b29e00958:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0095b:	be 34 00 01 00       	mov    esi,0x10034
    732b29e00960:	4c 89 ef             	mov    rdi,r13
    732b29e00963:	e8 f8 f7 ff e7       	call   0x732b11e00160
    732b29e00968:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e0096b:	0f 84 16 00 00 e8    	je     0x732b11e00987
    732b29e00971:	eb 0f                	jmp    0x732b29e00982
    732b29e00973:	b8 34 00 01 00       	mov    eax,0x10034
    732b29e00978:	83 c0 02             	add    eax,0x2
    732b29e0097b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e00982:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00989:	02 00 00 00 
    732b29e0098d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e00994:	0c 00 00 00 
    732b29e00998:	4c 89 ef             	mov    rdi,r13
    732b29e0099b:	e8 b0 f7 ff e7       	call   0x732b11e00150
    732b29e009a0:	e9 e2 ff ff e7       	jmp    0x732b11e00987
    732b29e009a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    732b29e009ac:	36 00 01 00 
    732b29e009b0:	b8 36 00 01 00       	mov    eax,0x10036
    732b29e009b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e009bc:	02 00 00 00 
    732b29e009c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e009c7:	0d 00 00 00 
    732b29e009cb:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e009ce:	be 36 00 01 00       	mov    esi,0x10036
    732b29e009d3:	4c 89 ef             	mov    rdi,r13
    732b29e009d6:	e8 85 f7 ff e7       	call   0x732b11e00160
    732b29e009db:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e009e2:	00 
    732b29e009e3:	0f 84 d8 ff ff e7    	je     0x732b11e009c1
    732b29e009e9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e009f0:	02 00 00 00 
    732b29e009f4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e009fb:	0d 00 00 00 
    732b29e009ff:	58                   	pop    rax
    732b29e00a00:	e9 d8 01 00 e8       	jmp    0x732b11e00bdd
    732b29e00a05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    732b29e00a0c:	38 00 01 00 
    732b29e00a10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00a17:	04 00 00 00 
    732b29e00a1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e00a22:	0e 00 00 00 
    732b29e00a26:	ba 38 00 01 00       	mov    edx,0x10038
    732b29e00a2b:	4c 89 ef             	mov    rdi,r13
    732b29e00a2e:	4c 89 f6             	mov    rsi,r14
    732b29e00a31:	89 d9                	mov    ecx,ebx
    732b29e00a33:	45 31 c0             	xor    r8d,r8d
    732b29e00a36:	e8 45 f6 ff e7       	call   0x732b11e00080
    732b29e00a3b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00a42:	04 00 00 00 
    732b29e00a46:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e00a4d:	0e 00 00 00 
    732b29e00a51:	58                   	pop    rax
    732b29e00a52:	e9 86 01 00 e8       	jmp    0x732b11e00bdd
    732b29e00a57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    732b29e00a5e:	38 00 01 00 
    732b29e00a62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00a69:	04 00 00 00 
    732b29e00a6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e00a74:	0e 00 00 00 
    732b29e00a78:	4c 89 f7             	mov    rdi,r14
    732b29e00a7b:	89 de                	mov    esi,ebx
    732b29e00a7d:	e8 be f5 ff e7       	call   0x732b11e00040
    732b29e00a82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00a89:	00 
    732b29e00a8a:	75 af                	jne    0x732b29e00a3b
    732b29e00a8c:	41 89 c7             	mov    r15d,eax
    732b29e00a8f:	e9 64 ff ff e7       	jmp    0x732b11e009f8
    732b29e00a94:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    732b29e00a9b:	38 00 01 00 
    732b29e00a9f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00aa6:	04 00 00 00 
    732b29e00aaa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e00ab1:	0e 00 00 00 
    732b29e00ab5:	4c 89 f7             	mov    rdi,r14
    732b29e00ab8:	e8 83 f5 ff e7       	call   0x732b11e00040
    732b29e00abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00ac4:	00 
    732b29e00ac5:	0f 84 4e ff ff e7    	je     0x732b11e00a19
    732b29e00acb:	e9 6b ff ff ff       	jmp    0x732b29e00a3b
    732b29e00ad0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    732b29e00ad7:	38 00 01 00 
    732b29e00adb:	b8 38 00 01 00       	mov    eax,0x10038
    732b29e00ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e00ae7:	04 00 00 00 
    732b29e00aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e00af2:	0e 00 00 00 
    732b29e00af6:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e00af9:	be 38 00 01 00       	mov    esi,0x10038
    732b29e00afe:	4c 89 ef             	mov    rdi,r13
    732b29e00b01:	e8 5a f6 ff e7       	call   0x732b11e00160
    732b29e00b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00b0d:	00 
    732b29e00b0e:	0f 84 39 ff ff e7    	je     0x732b11e00a4d
    732b29e00b14:	e9 22 ff ff ff       	jmp    0x732b29e00a3b
    732b29e00b19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00b20:	3c 00 01 00 
    732b29e00b24:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00b2b:	02 00 00 00 
    732b29e00b2f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00b36:	0f 00 00 00 
    732b29e00b3a:	ba 3c 00 01 00       	mov    edx,0x1003c
    732b29e00b3f:	4c 89 ef             	mov    rdi,r13
    732b29e00b42:	4c 89 f6             	mov    rsi,r14
    732b29e00b45:	89 d9                	mov    ecx,ebx
    732b29e00b47:	45 31 c0             	xor    r8d,r8d
    732b29e00b4a:	e8 31 f5 ff e7       	call   0x732b11e00080
    732b29e00b4f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00b56:	02 00 00 00 
    732b29e00b5a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00b61:	0f 00 00 00 
    732b29e00b65:	58                   	pop    rax
    732b29e00b66:	e9 72 00 00 e8       	jmp    0x732b11e00bdd
    732b29e00b6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00b72:	3c 00 01 00 
    732b29e00b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00b7d:	02 00 00 00 
    732b29e00b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00b88:	0f 00 00 00 
    732b29e00b8c:	4c 89 f7             	mov    rdi,r14
    732b29e00b8f:	89 de                	mov    esi,ebx
    732b29e00b91:	e8 aa f4 ff e7       	call   0x732b11e00040
    732b29e00b96:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00b9d:	00 
    732b29e00b9e:	0f 84 df fe ff e7    	je     0x732b11e00a83
    732b29e00ba4:	eb a9                	jmp    0x732b29e00b4f
    732b29e00ba6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00bad:	3c 00 01 00 
    732b29e00bb1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00bb8:	02 00 00 00 
    732b29e00bbc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00bc3:	0f 00 00 00 
    732b29e00bc7:	4c 89 f7             	mov    rdi,r14
    732b29e00bca:	e8 71 f4 ff e7       	call   0x732b11e00040
    732b29e00bcf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00bd6:	00 
    732b29e00bd7:	0f 84 c9 fe ff e7    	je     0x732b11e00aa6
    732b29e00bdd:	e9 6d ff ff ff       	jmp    0x732b29e00b4f
    732b29e00be2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00be9:	3c 00 01 00 
    732b29e00bed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00bf4:	02 00 00 00 
    732b29e00bf8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00bff:	0f 00 00 00 
    732b29e00c03:	4c 89 f7             	mov    rdi,r14
    732b29e00c06:	e8 35 f4 ff e7       	call   0x732b11e00040
    732b29e00c0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00c12:	00 
    732b29e00c13:	0f 84 b0 fe ff e7    	je     0x732b11e00ac9
    732b29e00c19:	e9 31 ff ff ff       	jmp    0x732b29e00b4f
    732b29e00c1e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00c25:	3c 00 01 00 
    732b29e00c29:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00c30:	02 00 00 00 
    732b29e00c34:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00c3b:	0f 00 00 00 
    732b29e00c3f:	4c 89 f7             	mov    rdi,r14
    732b29e00c42:	e8 f9 f3 ff e7       	call   0x732b11e00040
    732b29e00c47:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00c4e:	00 
    732b29e00c4f:	0f 84 97 fe ff e7    	je     0x732b11e00aec
    732b29e00c55:	e9 f5 fe ff ff       	jmp    0x732b29e00b4f
    732b29e00c5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00c61:	3c 00 01 00 
    732b29e00c65:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00c6c:	02 00 00 00 
    732b29e00c70:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00c77:	0f 00 00 00 
    732b29e00c7b:	4c 89 f7             	mov    rdi,r14
    732b29e00c7e:	e8 bd f3 ff e7       	call   0x732b11e00040
    732b29e00c83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00c8a:	00 
    732b29e00c8b:	0f 84 7e fe ff e7    	je     0x732b11e00b0f
    732b29e00c91:	e9 b9 fe ff ff       	jmp    0x732b29e00b4f
    732b29e00c96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00c9d:	3c 00 01 00 
    732b29e00ca1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00ca8:	02 00 00 00 
    732b29e00cac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00cb3:	0f 00 00 00 
    732b29e00cb7:	4c 89 f7             	mov    rdi,r14
    732b29e00cba:	e8 81 f3 ff e7       	call   0x732b11e00040
    732b29e00cbf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00cc6:	00 
    732b29e00cc7:	0f 84 65 fe ff e7    	je     0x732b11e00b32
    732b29e00ccd:	e9 7d fe ff ff       	jmp    0x732b29e00b4f
    732b29e00cd2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00cd9:	3c 00 01 00 
    732b29e00cdd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00ce4:	02 00 00 00 
    732b29e00ce8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00cef:	0f 00 00 00 
    732b29e00cf3:	4c 89 f7             	mov    rdi,r14
    732b29e00cf6:	e8 45 f3 ff e7       	call   0x732b11e00040
    732b29e00cfb:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00d02:	00 
    732b29e00d03:	0f 84 4e fe ff e7    	je     0x732b11e00b57
    732b29e00d09:	e9 41 fe ff ff       	jmp    0x732b29e00b4f
    732b29e00d0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    732b29e00d15:	3c 00 01 00 
    732b29e00d19:	b8 3c 00 01 00       	mov    eax,0x1003c
    732b29e00d1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00d25:	02 00 00 00 
    732b29e00d29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e00d30:	0f 00 00 00 
    732b29e00d34:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e00d37:	be 3c 00 01 00       	mov    esi,0x1003c
    732b29e00d3c:	4c 89 ef             	mov    rdi,r13
    732b29e00d3f:	e8 1c f4 ff e7       	call   0x732b11e00160
    732b29e00d44:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e00d4b:	00 
    732b29e00d4c:	0f 84 32 fe ff e7    	je     0x732b11e00b84
    732b29e00d52:	e9 f8 fd ff ff       	jmp    0x732b29e00b4f
    732b29e00d57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    732b29e00d5e:	3e 00 01 00 
    732b29e00d62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00d69:	02 00 00 00 
    732b29e00d6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e00d74:	10 00 00 00 
    732b29e00d78:	4c 89 ef             	mov    rdi,r13
    732b29e00d7b:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e00d80:	4c 89 f2             	mov    rdx,r14
    732b29e00d83:	e8 08 f3 ff e7       	call   0x732b11e00090
    732b29e00d88:	e9 39 fe ff e7       	jmp    0x732b11e00bc6
    732b29e00d8d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e00d94:	02 00 00 00 
    732b29e00d98:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e00d9f:	10 00 00 00 
    732b29e00da3:	be 3e 00 01 00       	mov    esi,0x1003e
    732b29e00da8:	ba 3e 00 01 00       	mov    edx,0x1003e
    732b29e00dad:	4c 89 ef             	mov    rdi,r13
    732b29e00db0:	e8 ab f3 ff e7       	call   0x732b11e00160
    732b29e00db5:	e9 0c fe ff e7       	jmp    0x732b11e00bc6
    732b29e00dba:	c2 08 00             	ret    0x8
