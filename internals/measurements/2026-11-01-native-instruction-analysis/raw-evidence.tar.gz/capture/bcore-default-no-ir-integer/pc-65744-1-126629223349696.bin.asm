
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65744-1-126629223349696.bin:     file format binary


Disassembly of section .data:

0000732b29e03dc0 <.data>:
    732b29e03dc0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e03dc6:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e03dc9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e03dcf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e03dd6:	0f 87 95 ee ff e7    	ja     0x732b11e02c71
    732b29e03ddc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x8
    732b29e03de3:	08 00 00 00 
    732b29e03de7:	e9 85 ee ff e7       	jmp    0x732b11e02c71
    732b29e03dec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b29e03df3:	d0 00 01 00 
    732b29e03df7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03dfe:	02 00 00 00 
    732b29e03e02:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03e09:	01 00 00 00 
    732b29e03e0d:	ba d0 00 01 00       	mov    edx,0x100d0
    732b29e03e12:	4c 89 ef             	mov    rdi,r13
    732b29e03e15:	4c 89 f6             	mov    rsi,r14
    732b29e03e18:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e03e1e:	e8 5d c2 ff e7       	call   0x732b11e00080
    732b29e03e23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03e2a:	02 00 00 00 
    732b29e03e2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03e35:	01 00 00 00 
    732b29e03e39:	58                   	pop    rax
    732b29e03e3a:	e9 f9 f6 ff e7       	jmp    0x732b11e03538
    732b29e03e3f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b29e03e46:	d0 00 01 00 
    732b29e03e4a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03e51:	02 00 00 00 
    732b29e03e55:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03e5c:	01 00 00 00 
    732b29e03e60:	4c 89 f7             	mov    rdi,r14
    732b29e03e63:	89 ce                	mov    esi,ecx
    732b29e03e65:	e8 06 c2 ff e7       	call   0x732b11e00070
    732b29e03e6a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03e71:	00 
    732b29e03e72:	0f 84 38 ee ff e7    	je     0x732b11e02cb0
    732b29e03e78:	eb a9                	jmp    0x732b29e03e23
    732b29e03e7a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b29e03e81:	d0 00 01 00 
    732b29e03e85:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03e8c:	02 00 00 00 
    732b29e03e90:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03e97:	01 00 00 00 
    732b29e03e9b:	4c 89 f7             	mov    rdi,r14
    732b29e03e9e:	89 de                	mov    esi,ebx
    732b29e03ea0:	e8 cb c1 ff e7       	call   0x732b11e00070
    732b29e03ea5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03eac:	00 
    732b29e03ead:	0f 84 22 ee ff e7    	je     0x732b11e02cd5
    732b29e03eb3:	e9 6b ff ff ff       	jmp    0x732b29e03e23
    732b29e03eb8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b29e03ebf:	d0 00 01 00 
    732b29e03ec3:	b8 d0 00 01 00       	mov    eax,0x100d0
    732b29e03ec8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03ecf:	02 00 00 00 
    732b29e03ed3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03eda:	01 00 00 00 
    732b29e03ede:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03ee1:	be d0 00 01 00       	mov    esi,0x100d0
    732b29e03ee6:	4c 89 ef             	mov    rdi,r13
    732b29e03ee9:	e8 72 c2 ff e7       	call   0x732b11e00160
    732b29e03eee:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e03ef2:	0f 84 13 ee ff e7    	je     0x732b11e02d0b
    732b29e03ef8:	eb 0f                	jmp    0x732b29e03f09
    732b29e03efa:	b8 d0 00 01 00       	mov    eax,0x100d0
    732b29e03eff:	83 c0 02             	add    eax,0x2
    732b29e03f02:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e03f09:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03f10:	02 00 00 00 
    732b29e03f14:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03f1b:	01 00 00 00 
    732b29e03f1f:	4c 89 ef             	mov    rdi,r13
    732b29e03f22:	e8 29 c2 ff e7       	call   0x732b11e00150
    732b29e03f27:	e9 df ed ff e7       	jmp    0x732b11e02d0b
    732b29e03f2c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    732b29e03f33:	d2 00 01 00 
    732b29e03f37:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03f3e:	04 00 00 00 
    732b29e03f42:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03f49:	02 00 00 00 
    732b29e03f4d:	ba d2 00 01 00       	mov    edx,0x100d2
    732b29e03f52:	4c 89 ef             	mov    rdi,r13
    732b29e03f55:	4c 89 f6             	mov    rsi,r14
    732b29e03f58:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e03f5e:	e8 1d c1 ff e7       	call   0x732b11e00080
    732b29e03f63:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03f6a:	04 00 00 00 
    732b29e03f6e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03f75:	02 00 00 00 
    732b29e03f79:	58                   	pop    rax
    732b29e03f7a:	e9 b9 f5 ff e7       	jmp    0x732b11e03538
    732b29e03f7f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    732b29e03f86:	d2 00 01 00 
    732b29e03f8a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03f91:	04 00 00 00 
    732b29e03f95:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03f9c:	02 00 00 00 
    732b29e03fa0:	4c 89 f7             	mov    rdi,r14
    732b29e03fa3:	89 ce                	mov    esi,ecx
    732b29e03fa5:	e8 c6 c0 ff e7       	call   0x732b11e00070
    732b29e03faa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03fb1:	00 
    732b29e03fb2:	0f 84 a8 ed ff e7    	je     0x732b11e02d60
    732b29e03fb8:	eb a9                	jmp    0x732b29e03f63
    732b29e03fba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    732b29e03fc1:	d2 00 01 00 
    732b29e03fc5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03fcc:	04 00 00 00 
    732b29e03fd0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e03fd7:	02 00 00 00 
    732b29e03fdb:	4c 89 f7             	mov    rdi,r14
    732b29e03fde:	89 de                	mov    esi,ebx
    732b29e03fe0:	44 89 e2             	mov    edx,r12d
    732b29e03fe3:	e8 88 c0 ff e7       	call   0x732b11e00070
    732b29e03fe8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03fef:	00 
    732b29e03ff0:	0f 84 8c ed ff e7    	je     0x732b11e02d82
    732b29e03ff6:	e9 68 ff ff ff       	jmp    0x732b29e03f63
    732b29e03ffb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    732b29e04002:	d2 00 01 00 
    732b29e04006:	b8 d2 00 01 00       	mov    eax,0x100d2
    732b29e0400b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04012:	04 00 00 00 
    732b29e04016:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0401d:	02 00 00 00 
    732b29e04021:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e04024:	be d2 00 01 00       	mov    esi,0x100d2
    732b29e04029:	4c 89 ef             	mov    rdi,r13
    732b29e0402c:	e8 2f c1 ff e7       	call   0x732b11e00160
    732b29e04031:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e04035:	0f 84 88 ed ff e7    	je     0x732b11e02dc3
    732b29e0403b:	eb 0f                	jmp    0x732b29e0404c
    732b29e0403d:	b8 d2 00 01 00       	mov    eax,0x100d2
    732b29e04042:	83 c0 04             	add    eax,0x4
    732b29e04045:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0404c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04053:	04 00 00 00 
    732b29e04057:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e0405e:	02 00 00 00 
    732b29e04062:	4c 89 ef             	mov    rdi,r13
    732b29e04065:	e8 e6 c0 ff e7       	call   0x732b11e00150
    732b29e0406a:	e9 54 ed ff e7       	jmp    0x732b11e02dc3
    732b29e0406f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d6
    732b29e04076:	d6 00 01 00 
    732b29e0407a:	b8 d6 00 01 00       	mov    eax,0x100d6
    732b29e0407f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04086:	02 00 00 00 
    732b29e0408a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e04091:	03 00 00 00 
    732b29e04095:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04098:	be d6 00 01 00       	mov    esi,0x100d6
    732b29e0409d:	4c 89 ef             	mov    rdi,r13
    732b29e040a0:	e8 bb c0 ff e7       	call   0x732b11e00160
    732b29e040a5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e040ac:	00 
    732b29e040ad:	0f 84 78 ed ff e7    	je     0x732b11e02e2b
    732b29e040b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e040ba:	02 00 00 00 
    732b29e040be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e040c5:	03 00 00 00 
    732b29e040c9:	58                   	pop    rax
    732b29e040ca:	e9 69 f4 ff e7       	jmp    0x732b11e03538
    732b29e040cf:	b8 d8 00 01 00       	mov    eax,0x100d8
    732b29e040d4:	83 c0 2c             	add    eax,0x2c
    732b29e040d7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e040de:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e040e5:	02 00 00 00 
    732b29e040e9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e040f0:	04 00 00 00 
    732b29e040f4:	be d8 00 01 00       	mov    esi,0x100d8
    732b29e040f9:	ba d8 00 01 00       	mov    edx,0x100d8
    732b29e040fe:	4c 89 ef             	mov    rdi,r13
    732b29e04101:	e8 5a c0 ff e7       	call   0x732b11e00160
    732b29e04106:	e9 56 ed ff e7       	jmp    0x732b11e02e61
    732b29e0410b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d8
    732b29e04112:	d8 00 01 00 
    732b29e04116:	b8 d8 00 01 00       	mov    eax,0x100d8
    732b29e0411b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04122:	02 00 00 00 
    732b29e04126:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0412d:	04 00 00 00 
    732b29e04131:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04134:	be d8 00 01 00       	mov    esi,0x100d8
    732b29e04139:	4c 89 ef             	mov    rdi,r13
    732b29e0413c:	e8 1f c0 ff e7       	call   0x732b11e00160
    732b29e04141:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04148:	00 
    732b29e04149:	0f 84 5f ed ff e7    	je     0x732b11e02eae
    732b29e0414f:	e9 1c ed ff e7       	jmp    0x732b11e02e70
    732b29e04154:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100da
    732b29e0415b:	da 00 01 00 
    732b29e0415f:	b8 da 00 01 00       	mov    eax,0x100da
    732b29e04164:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0416b:	04 00 00 00 
    732b29e0416f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e04176:	05 00 00 00 
    732b29e0417a:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0417d:	be da 00 01 00       	mov    esi,0x100da
    732b29e04182:	4c 89 ef             	mov    rdi,r13
    732b29e04185:	e8 d6 bf ff e7       	call   0x732b11e00160
    732b29e0418a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04191:	00 
    732b29e04192:	0f 84 4a ed ff e7    	je     0x732b11e02ee2
    732b29e04198:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0419f:	04 00 00 00 
    732b29e041a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e041aa:	05 00 00 00 
    732b29e041ae:	58                   	pop    rax
    732b29e041af:	e9 84 f3 ff e7       	jmp    0x732b11e03538
    732b29e041b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100de
    732b29e041bb:	de 00 01 00 
    732b29e041bf:	b8 de 00 01 00       	mov    eax,0x100de
    732b29e041c4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e041cb:	04 00 00 00 
    732b29e041cf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e041d6:	06 00 00 00 
    732b29e041da:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e041dd:	be de 00 01 00       	mov    esi,0x100de
    732b29e041e2:	4c 89 ef             	mov    rdi,r13
    732b29e041e5:	e8 76 bf ff e7       	call   0x732b11e00160
    732b29e041ea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e041f1:	00 
    732b29e041f2:	0f 84 1e ed ff e7    	je     0x732b11e02f16
    732b29e041f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e041ff:	04 00 00 00 
    732b29e04203:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e0420a:	06 00 00 00 
    732b29e0420e:	58                   	pop    rax
    732b29e0420f:	e9 24 f3 ff e7       	jmp    0x732b11e03538
    732b29e04214:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100e2
    732b29e0421b:	e2 00 01 00 
    732b29e0421f:	b8 e2 00 01 00       	mov    eax,0x100e2
    732b29e04224:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0422b:	02 00 00 00 
    732b29e0422f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e04236:	07 00 00 00 
    732b29e0423a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0423d:	be e2 00 01 00       	mov    esi,0x100e2
    732b29e04242:	4c 89 ef             	mov    rdi,r13
    732b29e04245:	e8 16 bf ff e7       	call   0x732b11e00160
    732b29e0424a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04251:	00 
    732b29e04252:	0f 84 ea ec ff e7    	je     0x732b11e02f42
    732b29e04258:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0425f:	02 00 00 00 
    732b29e04263:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e0426a:	07 00 00 00 
    732b29e0426e:	58                   	pop    rax
    732b29e0426f:	e9 c4 f2 ff e7       	jmp    0x732b11e03538
    732b29e04274:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100e4
    732b29e0427b:	e4 00 01 00 
    732b29e0427f:	b8 e4 00 01 00       	mov    eax,0x100e4
    732b29e04284:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0428b:	04 00 00 00 
    732b29e0428f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e04296:	08 00 00 00 
    732b29e0429a:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0429d:	be e4 00 01 00       	mov    esi,0x100e4
    732b29e042a2:	4c 89 ef             	mov    rdi,r13
    732b29e042a5:	e8 b6 be ff e7       	call   0x732b11e00160
    732b29e042aa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e042b1:	00 
    732b29e042b2:	0f 84 c1 ec ff e7    	je     0x732b11e02f79
    732b29e042b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e042bf:	04 00 00 00 
    732b29e042c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e042ca:	08 00 00 00 
    732b29e042ce:	58                   	pop    rax
    732b29e042cf:	e9 64 f2 ff e7       	jmp    0x732b11e03538
    732b29e042d4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100e8
    732b29e042db:	e8 00 01 00 
    732b29e042df:	b8 e8 00 01 00       	mov    eax,0x100e8
    732b29e042e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e042eb:	04 00 00 00 
    732b29e042ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e042f6:	09 00 00 00 
    732b29e042fa:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e042fd:	be e8 00 01 00       	mov    esi,0x100e8
    732b29e04302:	4c 89 ef             	mov    rdi,r13
    732b29e04305:	e8 56 be ff e7       	call   0x732b11e00160
    732b29e0430a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04311:	00 
    732b29e04312:	0f 84 98 ec ff e7    	je     0x732b11e02fb0
    732b29e04318:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0431f:	04 00 00 00 
    732b29e04323:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e0432a:	09 00 00 00 
    732b29e0432e:	58                   	pop    rax
    732b29e0432f:	e9 04 f2 ff e7       	jmp    0x732b11e03538
    732b29e04334:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    732b29e0433b:	ec 00 01 00 
    732b29e0433f:	b8 ec 00 01 00       	mov    eax,0x100ec
    732b29e04344:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0434b:	02 00 00 00 
    732b29e0434f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e04356:	0a 00 00 00 
    732b29e0435a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0435d:	be ec 00 01 00       	mov    esi,0x100ec
    732b29e04362:	4c 89 ef             	mov    rdi,r13
    732b29e04365:	e8 f6 bd ff e7       	call   0x732b11e00160
    732b29e0436a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04371:	00 
    732b29e04372:	0f 84 6b ec ff e7    	je     0x732b11e02fe3
    732b29e04378:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0437f:	02 00 00 00 
    732b29e04383:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e0438a:	0a 00 00 00 
    732b29e0438e:	58                   	pop    rax
    732b29e0438f:	e9 a4 f1 ff e7       	jmp    0x732b11e03538
    732b29e04394:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ee
    732b29e0439b:	ee 00 01 00 
    732b29e0439f:	b8 ee 00 01 00       	mov    eax,0x100ee
    732b29e043a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e043ab:	02 00 00 00 
    732b29e043af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e043b6:	0b 00 00 00 
    732b29e043ba:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e043bd:	be ee 00 01 00       	mov    esi,0x100ee
    732b29e043c2:	4c 89 ef             	mov    rdi,r13
    732b29e043c5:	e8 96 bd ff e7       	call   0x732b11e00160
    732b29e043ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e043d1:	00 
    732b29e043d2:	0f 84 91 ec ff e7    	je     0x732b11e03069
    732b29e043d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e043df:	02 00 00 00 
    732b29e043e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e043ea:	0b 00 00 00 
    732b29e043ee:	58                   	pop    rax
    732b29e043ef:	e9 44 f1 ff e7       	jmp    0x732b11e03538
    732b29e043f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f0
    732b29e043fb:	f0 00 01 00 
    732b29e043ff:	b8 f0 00 01 00       	mov    eax,0x100f0
    732b29e04404:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0440b:	04 00 00 00 
    732b29e0440f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e04416:	0c 00 00 00 
    732b29e0441a:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0441d:	be f0 00 01 00       	mov    esi,0x100f0
    732b29e04422:	4c 89 ef             	mov    rdi,r13
    732b29e04425:	e8 36 bd ff e7       	call   0x732b11e00160
    732b29e0442a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04431:	00 
    732b29e04432:	0f 84 8f ec ff e7    	je     0x732b11e030c7
    732b29e04438:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0443f:	04 00 00 00 
    732b29e04443:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e0444a:	0c 00 00 00 
    732b29e0444e:	58                   	pop    rax
    732b29e0444f:	e9 e4 f0 ff e7       	jmp    0x732b11e03538
    732b29e04454:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f4
    732b29e0445b:	f4 00 01 00 
    732b29e0445f:	b8 f4 00 01 00       	mov    eax,0x100f4
    732b29e04464:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0446b:	02 00 00 00 
    732b29e0446f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e04476:	0d 00 00 00 
    732b29e0447a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0447d:	be f4 00 01 00       	mov    esi,0x100f4
    732b29e04482:	4c 89 ef             	mov    rdi,r13
    732b29e04485:	e8 d6 bc ff e7       	call   0x732b11e00160
    732b29e0448a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04491:	00 
    732b29e04492:	0f 84 8d ec ff e7    	je     0x732b11e03125
    732b29e04498:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0449f:	02 00 00 00 
    732b29e044a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e044aa:	0d 00 00 00 
    732b29e044ae:	58                   	pop    rax
    732b29e044af:	e9 84 f0 ff e7       	jmp    0x732b11e03538
    732b29e044b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100f6
    732b29e044bb:	f6 00 01 00 
    732b29e044bf:	b8 f6 00 01 00       	mov    eax,0x100f6
    732b29e044c4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e044cb:	04 00 00 00 
    732b29e044cf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e044d6:	0e 00 00 00 
    732b29e044da:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e044dd:	be f6 00 01 00       	mov    esi,0x100f6
    732b29e044e2:	4c 89 ef             	mov    rdi,r13
    732b29e044e5:	e8 76 bc ff e7       	call   0x732b11e00160
    732b29e044ea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e044f1:	00 
    732b29e044f2:	0f 84 83 ec ff e7    	je     0x732b11e0317b
    732b29e044f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e044ff:	04 00 00 00 
    732b29e04503:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e0450a:	0e 00 00 00 
    732b29e0450e:	58                   	pop    rax
    732b29e0450f:	e9 24 f0 ff e7       	jmp    0x732b11e03538
    732b29e04514:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fa
    732b29e0451b:	fa 00 01 00 
    732b29e0451f:	b8 fa 00 01 00       	mov    eax,0x100fa
    732b29e04524:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0452b:	02 00 00 00 
    732b29e0452f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e04536:	0f 00 00 00 
    732b29e0453a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0453d:	be fa 00 01 00       	mov    esi,0x100fa
    732b29e04542:	4c 89 ef             	mov    rdi,r13
    732b29e04545:	e8 16 bc ff e7       	call   0x732b11e00160
    732b29e0454a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04551:	00 
    732b29e04552:	0f 84 7d ec ff e7    	je     0x732b11e031d5
    732b29e04558:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0455f:	02 00 00 00 
    732b29e04563:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e0456a:	0f 00 00 00 
    732b29e0456e:	58                   	pop    rax
    732b29e0456f:	e9 c4 ef ff e7       	jmp    0x732b11e03538
    732b29e04574:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fc
    732b29e0457b:	fc 00 01 00 
    732b29e0457f:	b8 fc 00 01 00       	mov    eax,0x100fc
    732b29e04584:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0458b:	02 00 00 00 
    732b29e0458f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e04596:	10 00 00 00 
    732b29e0459a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0459d:	be fc 00 01 00       	mov    esi,0x100fc
    732b29e045a2:	4c 89 ef             	mov    rdi,r13
    732b29e045a5:	e8 b6 bb ff e7       	call   0x732b11e00160
    732b29e045aa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e045b1:	00 
    732b29e045b2:	0f 84 98 ec ff e7    	je     0x732b11e03250
    732b29e045b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e045bf:	02 00 00 00 
    732b29e045c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e045ca:	10 00 00 00 
    732b29e045ce:	58                   	pop    rax
    732b29e045cf:	e9 64 ef ff e7       	jmp    0x732b11e03538
    732b29e045d4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100fe
    732b29e045db:	fe 00 01 00 
    732b29e045df:	b8 fe 00 01 00       	mov    eax,0x100fe
    732b29e045e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e045eb:	02 00 00 00 
    732b29e045ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e045f6:	11 00 00 00 
    732b29e045fa:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e045fd:	be fe 00 01 00       	mov    esi,0x100fe
    732b29e04602:	4c 89 ef             	mov    rdi,r13
    732b29e04605:	e8 56 bb ff e7       	call   0x732b11e00160
    732b29e0460a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04611:	00 
    732b29e04612:	0f 84 96 ec ff e7    	je     0x732b11e032ae
    732b29e04618:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0461f:	02 00 00 00 
    732b29e04623:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e0462a:	11 00 00 00 
    732b29e0462e:	58                   	pop    rax
    732b29e0462f:	e9 04 ef ff e7       	jmp    0x732b11e03538
    732b29e04634:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10100
    732b29e0463b:	00 01 01 00 
    732b29e0463f:	b8 00 01 01 00       	mov    eax,0x10100
    732b29e04644:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0464b:	02 00 00 00 
    732b29e0464f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e04656:	12 00 00 00 
    732b29e0465a:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0465d:	be 00 01 01 00       	mov    esi,0x10100
    732b29e04662:	4c 89 ef             	mov    rdi,r13
    732b29e04665:	e8 f6 ba ff e7       	call   0x732b11e00160
    732b29e0466a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04671:	00 
    732b29e04672:	0f 84 9d ec ff e7    	je     0x732b11e03315
    732b29e04678:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0467f:	02 00 00 00 
    732b29e04683:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e0468a:	12 00 00 00 
    732b29e0468e:	58                   	pop    rax
    732b29e0468f:	e9 a4 ee ff e7       	jmp    0x732b11e03538
    732b29e04694:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10102
    732b29e0469b:	02 01 01 00 
    732b29e0469f:	b8 02 01 01 00       	mov    eax,0x10102
    732b29e046a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e046ab:	02 00 00 00 
    732b29e046af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e046b6:	13 00 00 00 
    732b29e046ba:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e046bd:	be 02 01 01 00       	mov    esi,0x10102
    732b29e046c2:	4c 89 ef             	mov    rdi,r13
    732b29e046c5:	e8 96 ba ff e7       	call   0x732b11e00160
    732b29e046ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e046d1:	00 
    732b29e046d2:	0f 84 6b ec ff e7    	je     0x732b11e03343
    732b29e046d8:	e9 a5 ec ff e7       	jmp    0x732b11e03382
    732b29e046dd:	b8 02 01 01 00       	mov    eax,0x10102
    732b29e046e2:	83 c0 ea             	add    eax,0xffffffea
    732b29e046e5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e046ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e046f3:	02 00 00 00 
    732b29e046f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e046fe:	13 00 00 00 
    732b29e04702:	be 02 01 01 00       	mov    esi,0x10102
    732b29e04707:	ba 02 01 01 00       	mov    edx,0x10102
    732b29e0470c:	4c 89 ef             	mov    rdi,r13
    732b29e0470f:	e8 4c ba ff e7       	call   0x732b11e00160
    732b29e04714:	e9 5a ec ff e7       	jmp    0x732b11e03373
    732b29e04719:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04720:	04 01 01 00 
    732b29e04724:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0472b:	04 00 00 00 
    732b29e0472f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e04736:	14 00 00 00 
    732b29e0473a:	ba 04 01 01 00       	mov    edx,0x10104
    732b29e0473f:	4c 89 ef             	mov    rdi,r13
    732b29e04742:	4c 89 f6             	mov    rsi,r14
    732b29e04745:	89 d9                	mov    ecx,ebx
    732b29e04747:	45 31 c0             	xor    r8d,r8d
    732b29e0474a:	e8 31 b9 ff e7       	call   0x732b11e00080
    732b29e0474f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e04756:	04 00 00 00 
    732b29e0475a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e04761:	14 00 00 00 
    732b29e04765:	58                   	pop    rax
    732b29e04766:	e9 cd ed ff e7       	jmp    0x732b11e03538
    732b29e0476b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e04772:	04 01 01 00 
    732b29e04776:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0477d:	04 00 00 00 
    732b29e04781:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e04788:	14 00 00 00 
    732b29e0478c:	4c 89 f7             	mov    rdi,r14
    732b29e0478f:	89 de                	mov    esi,ebx
    732b29e04791:	e8 aa b8 ff e7       	call   0x732b11e00040
    732b29e04796:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0479d:	00 
    732b29e0479e:	75 af                	jne    0x732b29e0474f
    732b29e047a0:	41 89 c7             	mov    r15d,eax
    732b29e047a3:	e9 2c ec ff e7       	jmp    0x732b11e033d4
    732b29e047a8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e047af:	04 01 01 00 
    732b29e047b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e047ba:	04 00 00 00 
    732b29e047be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e047c5:	14 00 00 00 
    732b29e047c9:	4c 89 f7             	mov    rdi,r14
    732b29e047cc:	e8 6f b8 ff e7       	call   0x732b11e00040
    732b29e047d1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e047d8:	00 
    732b29e047d9:	0f 84 16 ec ff e7    	je     0x732b11e033f5
    732b29e047df:	e9 6b ff ff ff       	jmp    0x732b29e0474f
    732b29e047e4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    732b29e047eb:	04 01 01 00 
    732b29e047ef:	b8 04 01 01 00       	mov    eax,0x10104
    732b29e047f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e047fb:	04 00 00 00 
    732b29e047ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e04806:	14 00 00 00 
    732b29e0480a:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0480d:	be 04 01 01 00       	mov    esi,0x10104
    732b29e04812:	4c 89 ef             	mov    rdi,r13
    732b29e04815:	e8 46 b9 ff e7       	call   0x732b11e00160
    732b29e0481a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04821:	00 
    732b29e04822:	0f 84 01 ec ff e7    	je     0x732b11e03429
    732b29e04828:	e9 22 ff ff ff       	jmp    0x732b29e0474f
    732b29e0482d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10108
    732b29e04834:	08 01 01 00 
    732b29e04838:	b8 08 01 01 00       	mov    eax,0x10108
    732b29e0483d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04844:	02 00 00 00 
    732b29e04848:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e0484f:	15 00 00 00 
    732b29e04853:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e04856:	be 08 01 01 00       	mov    esi,0x10108
    732b29e0485b:	4c 89 ef             	mov    rdi,r13
    732b29e0485e:	e8 fd b8 ff e7       	call   0x732b11e00160
    732b29e04863:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0486a:	00 
    732b29e0486b:	0f 84 e6 eb ff e7    	je     0x732b11e03457
    732b29e04871:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e04878:	02 00 00 00 
    732b29e0487c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e04883:	15 00 00 00 
    732b29e04887:	58                   	pop    rax
    732b29e04888:	e9 ab ec ff e7       	jmp    0x732b11e03538
    732b29e0488d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e04894:	0a 01 01 00 
    732b29e04898:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0489f:	02 00 00 00 
    732b29e048a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e048aa:	16 00 00 00 
    732b29e048ae:	ba 0a 01 01 00       	mov    edx,0x1010a
    732b29e048b3:	4c 89 ef             	mov    rdi,r13
    732b29e048b6:	4c 89 f6             	mov    rsi,r14
    732b29e048b9:	89 d9                	mov    ecx,ebx
    732b29e048bb:	45 31 c0             	xor    r8d,r8d
    732b29e048be:	e8 bd b7 ff e7       	call   0x732b11e00080
    732b29e048c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e048ca:	02 00 00 00 
    732b29e048ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e048d5:	16 00 00 00 
    732b29e048d9:	58                   	pop    rax
    732b29e048da:	e9 59 ec ff e7       	jmp    0x732b11e03538
    732b29e048df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e048e6:	0a 01 01 00 
    732b29e048ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e048f1:	02 00 00 00 
    732b29e048f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e048fc:	16 00 00 00 
    732b29e04900:	4c 89 f7             	mov    rdi,r14
    732b29e04903:	89 de                	mov    esi,ebx
    732b29e04905:	e8 36 b7 ff e7       	call   0x732b11e00040
    732b29e0490a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04911:	00 
    732b29e04912:	0f 84 75 eb ff e7    	je     0x732b11e0348d
    732b29e04918:	eb a9                	jmp    0x732b29e048c3
    732b29e0491a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e04921:	0a 01 01 00 
    732b29e04925:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0492c:	02 00 00 00 
    732b29e04930:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e04937:	16 00 00 00 
    732b29e0493b:	4c 89 f7             	mov    rdi,r14
    732b29e0493e:	e8 fd b6 ff e7       	call   0x732b11e00040
    732b29e04943:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0494a:	00 
    732b29e0494b:	0f 84 61 eb ff e7    	je     0x732b11e034b2
    732b29e04951:	e9 6d ff ff ff       	jmp    0x732b29e048c3
    732b29e04956:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    732b29e0495d:	0a 01 01 00 
    732b29e04961:	b8 0a 01 01 00       	mov    eax,0x1010a
    732b29e04966:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0496d:	02 00 00 00 
    732b29e04971:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e04978:	16 00 00 00 
    732b29e0497c:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0497f:	be 0a 01 01 00       	mov    esi,0x1010a
    732b29e04984:	4c 89 ef             	mov    rdi,r13
    732b29e04987:	e8 d4 b7 ff e7       	call   0x732b11e00160
    732b29e0498c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e04993:	00 
    732b29e04994:	0f 84 45 eb ff e7    	je     0x732b11e034df
    732b29e0499a:	e9 24 ff ff ff       	jmp    0x732b29e048c3
    732b29e0499f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010c
    732b29e049a6:	0c 01 01 00 
    732b29e049aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e049b1:	02 00 00 00 
    732b29e049b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e049bc:	17 00 00 00 
    732b29e049c0:	4c 89 ef             	mov    rdi,r13
    732b29e049c3:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e049c8:	4c 89 f2             	mov    rdx,r14
    732b29e049cb:	e8 c0 b6 ff e7       	call   0x732b11e00090
    732b29e049d0:	e9 4c eb ff e7       	jmp    0x732b11e03521
    732b29e049d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e049dc:	02 00 00 00 
    732b29e049e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e049e7:	17 00 00 00 
    732b29e049eb:	be 0c 01 01 00       	mov    esi,0x1010c
    732b29e049f0:	ba 0c 01 01 00       	mov    edx,0x1010c
    732b29e049f5:	4c 89 ef             	mov    rdi,r13
    732b29e049f8:	e8 63 b7 ff e7       	call   0x732b11e00160
    732b29e049fd:	e9 1f eb ff e7       	jmp    0x732b11e03521
    732b29e04a02:	c2 08 00             	ret    0x8
