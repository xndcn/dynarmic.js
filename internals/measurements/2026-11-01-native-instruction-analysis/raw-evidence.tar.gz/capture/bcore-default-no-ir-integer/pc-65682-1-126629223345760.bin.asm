
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65682-1-126629223345760.bin:     file format binary


Disassembly of section .data:

0000732b29e02e60 <.data>:
    732b29e02e60:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e02e66:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e02e69:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e02e6f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e02e76:	0f 87 95 f2 ff e7    	ja     0x732b11e02111
    732b29e02e7c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x4
    732b29e02e83:	04 00 00 00 
    732b29e02e87:	e9 85 f2 ff e7       	jmp    0x732b11e02111
    732b29e02e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10092
    732b29e02e93:	92 00 01 00 
    732b29e02e97:	b8 92 00 01 00       	mov    eax,0x10092
    732b29e02e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02ea3:	02 00 00 00 
    732b29e02ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e02eae:	01 00 00 00 
    732b29e02eb2:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02eb5:	be 92 00 01 00       	mov    esi,0x10092
    732b29e02eba:	4c 89 ef             	mov    rdi,r13
    732b29e02ebd:	e8 9e d2 ff e7       	call   0x732b11e00160
    732b29e02ec2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02ec9:	00 
    732b29e02eca:	0f 84 9a f2 ff e7    	je     0x732b11e0216a
    732b29e02ed0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02ed7:	02 00 00 00 
    732b29e02edb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e02ee2:	01 00 00 00 
    732b29e02ee6:	58                   	pop    rax
    732b29e02ee7:	e9 1c f4 ff e7       	jmp    0x732b11e02308
    732b29e02eec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10094
    732b29e02ef3:	94 00 01 00 
    732b29e02ef7:	b8 94 00 01 00       	mov    eax,0x10094
    732b29e02efc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02f03:	02 00 00 00 
    732b29e02f07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e02f0e:	02 00 00 00 
    732b29e02f12:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02f15:	be 94 00 01 00       	mov    esi,0x10094
    732b29e02f1a:	4c 89 ef             	mov    rdi,r13
    732b29e02f1d:	e8 3e d2 ff e7       	call   0x732b11e00160
    732b29e02f22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02f29:	00 
    732b29e02f2a:	0f 84 68 f2 ff e7    	je     0x732b11e02198
    732b29e02f30:	e9 a2 f2 ff e7       	jmp    0x732b11e021d7
    732b29e02f35:	b8 94 00 01 00       	mov    eax,0x10094
    732b29e02f3a:	83 c0 2c             	add    eax,0x2c
    732b29e02f3d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02f44:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02f4b:	02 00 00 00 
    732b29e02f4f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e02f56:	02 00 00 00 
    732b29e02f5a:	be 94 00 01 00       	mov    esi,0x10094
    732b29e02f5f:	ba 94 00 01 00       	mov    edx,0x10094
    732b29e02f64:	4c 89 ef             	mov    rdi,r13
    732b29e02f67:	e8 f4 d1 ff e7       	call   0x732b11e00160
    732b29e02f6c:	e9 57 f2 ff e7       	jmp    0x732b11e021c8
    732b29e02f71:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    732b29e02f78:	96 00 01 00 
    732b29e02f7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02f83:	02 00 00 00 
    732b29e02f87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e02f8e:	03 00 00 00 
    732b29e02f92:	ba 96 00 01 00       	mov    edx,0x10096
    732b29e02f97:	4c 89 ef             	mov    rdi,r13
    732b29e02f9a:	4c 89 f6             	mov    rsi,r14
    732b29e02f9d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e02fa3:	e8 d8 d0 ff e7       	call   0x732b11e00080
    732b29e02fa8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02faf:	02 00 00 00 
    732b29e02fb3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e02fba:	03 00 00 00 
    732b29e02fbe:	58                   	pop    rax
    732b29e02fbf:	e9 44 f3 ff e7       	jmp    0x732b11e02308
    732b29e02fc4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    732b29e02fcb:	96 00 01 00 
    732b29e02fcf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02fd6:	02 00 00 00 
    732b29e02fda:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e02fe1:	03 00 00 00 
    732b29e02fe5:	4c 89 f7             	mov    rdi,r14
    732b29e02fe8:	89 ce                	mov    esi,ecx
    732b29e02fea:	e8 81 d0 ff e7       	call   0x732b11e00070
    732b29e02fef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02ff6:	00 
    732b29e02ff7:	0f 84 33 f2 ff e7    	je     0x732b11e02230
    732b29e02ffd:	eb a9                	jmp    0x732b29e02fa8
    732b29e02fff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    732b29e03006:	96 00 01 00 
    732b29e0300a:	b8 96 00 01 00       	mov    eax,0x10096
    732b29e0300f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03016:	02 00 00 00 
    732b29e0301a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03021:	03 00 00 00 
    732b29e03025:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03028:	be 96 00 01 00       	mov    esi,0x10096
    732b29e0302d:	4c 89 ef             	mov    rdi,r13
    732b29e03030:	e8 2b d1 ff e7       	call   0x732b11e00160
    732b29e03035:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e03038:	0f 84 23 f2 ff e7    	je     0x732b11e02261
    732b29e0303e:	eb 0f                	jmp    0x732b29e0304f
    732b29e03040:	b8 96 00 01 00       	mov    eax,0x10096
    732b29e03045:	83 c0 02             	add    eax,0x2
    732b29e03048:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e0304f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03056:	02 00 00 00 
    732b29e0305a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03061:	03 00 00 00 
    732b29e03065:	4c 89 ef             	mov    rdi,r13
    732b29e03068:	e8 e3 d0 ff e7       	call   0x732b11e00150
    732b29e0306d:	e9 ef f1 ff e7       	jmp    0x732b11e02261
    732b29e03072:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    732b29e03079:	28 04 01 00 
    732b29e0307d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03084:	04 00 00 00 
    732b29e03088:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0308f:	04 00 00 00 
    732b29e03093:	be 98 00 01 00       	mov    esi,0x10098
    732b29e03098:	ba 98 00 01 00       	mov    edx,0x10098
    732b29e0309d:	4c 89 ef             	mov    rdi,r13
    732b29e030a0:	e8 bb d0 ff e7       	call   0x732b11e00160
    732b29e030a5:	e9 3c f2 ff e7       	jmp    0x732b11e022e6
    732b29e030aa:	c2 08 00             	ret    0x8
