
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66344-1-126629223341280.bin:     file format binary


Disassembly of section .data:

0000732b29e01ce0 <.data>:
    732b29e01ce0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e01ce6:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e01ce9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e01cef:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e01cf6:	0f 87 e5 f7 ff e7    	ja     0x732b11e014e1
    732b29e01cfc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x3
    732b29e01d03:	03 00 00 00 
    732b29e01d07:	e9 d5 f7 ff e7       	jmp    0x732b11e014e1
    732b29e01d0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01d13:	28 03 01 00 
    732b29e01d17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01d1e:	02 00 00 00 
    732b29e01d22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01d29:	01 00 00 00 
    732b29e01d2d:	ba 28 03 01 00       	mov    edx,0x10328
    732b29e01d32:	4c 89 ef             	mov    rdi,r13
    732b29e01d35:	4c 89 f6             	mov    rsi,r14
    732b29e01d38:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e01d3e:	e8 3d e3 ff e7       	call   0x732b11e00080
    732b29e01d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01d4a:	02 00 00 00 
    732b29e01d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01d55:	01 00 00 00 
    732b29e01d59:	58                   	pop    rax
    732b29e01d5a:	e9 10 03 00 e8       	jmp    0x732b11e0206f
    732b29e01d5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01d66:	28 03 01 00 
    732b29e01d6a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01d71:	02 00 00 00 
    732b29e01d75:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01d7c:	01 00 00 00 
    732b29e01d80:	4c 89 f7             	mov    rdi,r14
    732b29e01d83:	89 ce                	mov    esi,ecx
    732b29e01d85:	e8 e6 e2 ff e7       	call   0x732b11e00070
    732b29e01d8a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01d91:	00 
    732b29e01d92:	0f 84 88 f7 ff e7    	je     0x732b11e01520
    732b29e01d98:	eb a9                	jmp    0x732b29e01d43
    732b29e01d9a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01da1:	28 03 01 00 
    732b29e01da5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01dac:	02 00 00 00 
    732b29e01db0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01db7:	01 00 00 00 
    732b29e01dbb:	4c 89 f7             	mov    rdi,r14
    732b29e01dbe:	e8 ad e2 ff e7       	call   0x732b11e00070
    732b29e01dc3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01dca:	00 
    732b29e01dcb:	0f 84 72 f7 ff e7    	je     0x732b11e01543
    732b29e01dd1:	e9 6d ff ff ff       	jmp    0x732b29e01d43
    732b29e01dd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01ddd:	28 03 01 00 
    732b29e01de1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01de8:	02 00 00 00 
    732b29e01dec:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01df3:	01 00 00 00 
    732b29e01df7:	4c 89 f7             	mov    rdi,r14
    732b29e01dfa:	e8 71 e2 ff e7       	call   0x732b11e00070
    732b29e01dff:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01e06:	00 
    732b29e01e07:	0f 84 59 f7 ff e7    	je     0x732b11e01566
    732b29e01e0d:	e9 31 ff ff ff       	jmp    0x732b29e01d43
    732b29e01e12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01e19:	28 03 01 00 
    732b29e01e1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01e24:	02 00 00 00 
    732b29e01e28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01e2f:	01 00 00 00 
    732b29e01e33:	4c 89 f7             	mov    rdi,r14
    732b29e01e36:	e8 35 e2 ff e7       	call   0x732b11e00070
    732b29e01e3b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01e42:	00 
    732b29e01e43:	0f 84 40 f7 ff e7    	je     0x732b11e01589
    732b29e01e49:	e9 f5 fe ff ff       	jmp    0x732b29e01d43
    732b29e01e4e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01e55:	28 03 01 00 
    732b29e01e59:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01e60:	02 00 00 00 
    732b29e01e64:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01e6b:	01 00 00 00 
    732b29e01e6f:	4c 89 f7             	mov    rdi,r14
    732b29e01e72:	89 de                	mov    esi,ebx
    732b29e01e74:	e8 f7 e1 ff e7       	call   0x732b11e00070
    732b29e01e79:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01e80:	00 
    732b29e01e81:	0f 84 27 f7 ff e7    	je     0x732b11e015ae
    732b29e01e87:	e9 b7 fe ff ff       	jmp    0x732b29e01d43
    732b29e01e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    732b29e01e93:	28 03 01 00 
    732b29e01e97:	b8 28 03 01 00       	mov    eax,0x10328
    732b29e01e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01ea3:	02 00 00 00 
    732b29e01ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01eae:	01 00 00 00 
    732b29e01eb2:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e01eb5:	be 28 03 01 00       	mov    esi,0x10328
    732b29e01eba:	4c 89 ef             	mov    rdi,r13
    732b29e01ebd:	e8 9e e2 ff e7       	call   0x732b11e00160
    732b29e01ec2:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e01ec6:	0f 84 18 f7 ff e7    	je     0x732b11e015e4
    732b29e01ecc:	eb 0f                	jmp    0x732b29e01edd
    732b29e01ece:	b8 28 03 01 00       	mov    eax,0x10328
    732b29e01ed3:	83 c0 02             	add    eax,0x2
    732b29e01ed6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e01edd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e01ee4:	02 00 00 00 
    732b29e01ee8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e01eef:	01 00 00 00 
    732b29e01ef3:	4c 89 ef             	mov    rdi,r13
    732b29e01ef6:	e8 55 e2 ff e7       	call   0x732b11e00150
    732b29e01efb:	e9 e4 f6 ff e7       	jmp    0x732b11e015e4
    732b29e01f00:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    732b29e01f07:	2a 03 01 00 
    732b29e01f0b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01f12:	04 00 00 00 
    732b29e01f16:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e01f1d:	02 00 00 00 
    732b29e01f21:	ba 2a 03 01 00       	mov    edx,0x1032a
    732b29e01f26:	4c 89 ef             	mov    rdi,r13
    732b29e01f29:	4c 89 f6             	mov    rsi,r14
    732b29e01f2c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e01f32:	e8 49 e1 ff e7       	call   0x732b11e00080
    732b29e01f37:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01f3e:	04 00 00 00 
    732b29e01f42:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e01f49:	02 00 00 00 
    732b29e01f4d:	58                   	pop    rax
    732b29e01f4e:	e9 1c 01 00 e8       	jmp    0x732b11e0206f
    732b29e01f53:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    732b29e01f5a:	2a 03 01 00 
    732b29e01f5e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01f65:	04 00 00 00 
    732b29e01f69:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e01f70:	02 00 00 00 
    732b29e01f74:	4c 89 f7             	mov    rdi,r14
    732b29e01f77:	89 ce                	mov    esi,ecx
    732b29e01f79:	e8 f2 e0 ff e7       	call   0x732b11e00070
    732b29e01f7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01f85:	00 
    732b29e01f86:	0f 84 ad f6 ff e7    	je     0x732b11e01639
    732b29e01f8c:	eb a9                	jmp    0x732b29e01f37
    732b29e01f8e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    732b29e01f95:	2a 03 01 00 
    732b29e01f99:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01fa0:	04 00 00 00 
    732b29e01fa4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e01fab:	02 00 00 00 
    732b29e01faf:	4c 89 f7             	mov    rdi,r14
    732b29e01fb2:	89 de                	mov    esi,ebx
    732b29e01fb4:	44 89 e2             	mov    edx,r12d
    732b29e01fb7:	e8 b4 e0 ff e7       	call   0x732b11e00070
    732b29e01fbc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e01fc3:	00 
    732b29e01fc4:	0f 84 91 f6 ff e7    	je     0x732b11e0165b
    732b29e01fca:	e9 68 ff ff ff       	jmp    0x732b29e01f37
    732b29e01fcf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    732b29e01fd6:	2a 03 01 00 
    732b29e01fda:	b8 2a 03 01 00       	mov    eax,0x1032a
    732b29e01fdf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e01fe6:	04 00 00 00 
    732b29e01fea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e01ff1:	02 00 00 00 
    732b29e01ff5:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e01ff8:	be 2a 03 01 00       	mov    esi,0x1032a
    732b29e01ffd:	4c 89 ef             	mov    rdi,r13
    732b29e02000:	e8 5b e1 ff e7       	call   0x732b11e00160
    732b29e02005:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    732b29e02009:	0f 84 8d f6 ff e7    	je     0x732b11e0169c
    732b29e0200f:	eb 0f                	jmp    0x732b29e02020
    732b29e02011:	b8 2a 03 01 00       	mov    eax,0x1032a
    732b29e02016:	83 c0 04             	add    eax,0x4
    732b29e02019:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02020:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02027:	04 00 00 00 
    732b29e0202b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e02032:	02 00 00 00 
    732b29e02036:	4c 89 ef             	mov    rdi,r13
    732b29e02039:	e8 12 e1 ff e7       	call   0x732b11e00150
    732b29e0203e:	e9 59 f6 ff e7       	jmp    0x732b11e0169c
    732b29e02043:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    732b29e0204a:	2e 03 01 00 
    732b29e0204e:	b8 2e 03 01 00       	mov    eax,0x1032e
    732b29e02053:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0205a:	02 00 00 00 
    732b29e0205e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e02065:	03 00 00 00 
    732b29e02069:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0206c:	be 2e 03 01 00       	mov    esi,0x1032e
    732b29e02071:	4c 89 ef             	mov    rdi,r13
    732b29e02074:	e8 e7 e0 ff e7       	call   0x732b11e00160
    732b29e02079:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02080:	00 
    732b29e02081:	0f 84 8c f6 ff e7    	je     0x732b11e01713
    732b29e02087:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0208e:	02 00 00 00 
    732b29e02092:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e02099:	03 00 00 00 
    732b29e0209d:	58                   	pop    rax
    732b29e0209e:	e9 cc ff ff e7       	jmp    0x732b11e0206f
    732b29e020a3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10330
    732b29e020aa:	30 03 01 00 
    732b29e020ae:	b8 30 03 01 00       	mov    eax,0x10330
    732b29e020b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e020ba:	02 00 00 00 
    732b29e020be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e020c5:	04 00 00 00 
    732b29e020c9:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e020cc:	be 30 03 01 00       	mov    esi,0x10330
    732b29e020d1:	4c 89 ef             	mov    rdi,r13
    732b29e020d4:	e8 87 e0 ff e7       	call   0x732b11e00160
    732b29e020d9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e020e0:	00 
    732b29e020e1:	0f 84 5a f6 ff e7    	je     0x732b11e01741
    732b29e020e7:	e9 94 f6 ff e7       	jmp    0x732b11e01780
    732b29e020ec:	b8 30 03 01 00       	mov    eax,0x10330
    732b29e020f1:	83 c0 40             	add    eax,0x40
    732b29e020f4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e020fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02102:	02 00 00 00 
    732b29e02106:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0210d:	04 00 00 00 
    732b29e02111:	be 30 03 01 00       	mov    esi,0x10330
    732b29e02116:	ba 30 03 01 00       	mov    edx,0x10330
    732b29e0211b:	4c 89 ef             	mov    rdi,r13
    732b29e0211e:	e8 3d e0 ff e7       	call   0x732b11e00160
    732b29e02123:	e9 49 f6 ff e7       	jmp    0x732b11e01771
    732b29e02128:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10332
    732b29e0212f:	32 03 01 00 
    732b29e02133:	b8 32 03 01 00       	mov    eax,0x10332
    732b29e02138:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0213f:	02 00 00 00 
    732b29e02143:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0214a:	05 00 00 00 
    732b29e0214e:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02151:	be 32 03 01 00       	mov    esi,0x10332
    732b29e02156:	4c 89 ef             	mov    rdi,r13
    732b29e02159:	e8 02 e0 ff e7       	call   0x732b11e00160
    732b29e0215e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02165:	00 
    732b29e02166:	0f 84 89 f6 ff e7    	je     0x732b11e017f5
    732b29e0216c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02173:	02 00 00 00 
    732b29e02177:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e0217e:	05 00 00 00 
    732b29e02182:	58                   	pop    rax
    732b29e02183:	e9 e7 fe ff e7       	jmp    0x732b11e0206f
    732b29e02188:	b8 34 03 01 00       	mov    eax,0x10334
    732b29e0218d:	83 c0 3c             	add    eax,0x3c
    732b29e02190:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02197:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0219e:	02 00 00 00 
    732b29e021a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e021a9:	06 00 00 00 
    732b29e021ad:	be 34 03 01 00       	mov    esi,0x10334
    732b29e021b2:	ba 34 03 01 00       	mov    edx,0x10334
    732b29e021b7:	4c 89 ef             	mov    rdi,r13
    732b29e021ba:	e8 a1 df ff e7       	call   0x732b11e00160
    732b29e021bf:	e9 67 f6 ff e7       	jmp    0x732b11e0182b
    732b29e021c4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10334
    732b29e021cb:	34 03 01 00 
    732b29e021cf:	b8 34 03 01 00       	mov    eax,0x10334
    732b29e021d4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e021db:	02 00 00 00 
    732b29e021df:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e021e6:	06 00 00 00 
    732b29e021ea:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e021ed:	be 34 03 01 00       	mov    esi,0x10334
    732b29e021f2:	4c 89 ef             	mov    rdi,r13
    732b29e021f5:	e8 66 df ff e7       	call   0x732b11e00160
    732b29e021fa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02201:	00 
    732b29e02202:	0f 84 70 f6 ff e7    	je     0x732b11e01878
    732b29e02208:	e9 2d f6 ff e7       	jmp    0x732b11e0183a
    732b29e0220d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10336
    732b29e02214:	36 03 01 00 
    732b29e02218:	b8 36 03 01 00       	mov    eax,0x10336
    732b29e0221d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02224:	04 00 00 00 
    732b29e02228:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e0222f:	07 00 00 00 
    732b29e02233:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e02236:	be 36 03 01 00       	mov    esi,0x10336
    732b29e0223b:	4c 89 ef             	mov    rdi,r13
    732b29e0223e:	e8 1d df ff e7       	call   0x732b11e00160
    732b29e02243:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0224a:	00 
    732b29e0224b:	0f 84 53 f6 ff e7    	je     0x732b11e018a4
    732b29e02251:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02258:	04 00 00 00 
    732b29e0225c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e02263:	07 00 00 00 
    732b29e02267:	58                   	pop    rax
    732b29e02268:	e9 02 fe ff e7       	jmp    0x732b11e0206f
    732b29e0226d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033a
    732b29e02274:	3a 03 01 00 
    732b29e02278:	b8 3a 03 01 00       	mov    eax,0x1033a
    732b29e0227d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02284:	02 00 00 00 
    732b29e02288:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e0228f:	08 00 00 00 
    732b29e02293:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02296:	be 3a 03 01 00       	mov    esi,0x1033a
    732b29e0229b:	4c 89 ef             	mov    rdi,r13
    732b29e0229e:	e8 bd de ff e7       	call   0x732b11e00160
    732b29e022a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e022aa:	00 
    732b29e022ab:	0f 84 45 f6 ff e7    	je     0x732b11e018f6
    732b29e022b1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e022b8:	02 00 00 00 
    732b29e022bc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e022c3:	08 00 00 00 
    732b29e022c7:	58                   	pop    rax
    732b29e022c8:	e9 a2 fd ff e7       	jmp    0x732b11e0206f
    732b29e022cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033c
    732b29e022d4:	3c 03 01 00 
    732b29e022d8:	b8 3c 03 01 00       	mov    eax,0x1033c
    732b29e022dd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e022e4:	02 00 00 00 
    732b29e022e8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e022ef:	09 00 00 00 
    732b29e022f3:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e022f6:	be 3c 03 01 00       	mov    esi,0x1033c
    732b29e022fb:	4c 89 ef             	mov    rdi,r13
    732b29e022fe:	e8 5d de ff e7       	call   0x732b11e00160
    732b29e02303:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0230a:	00 
    732b29e0230b:	0f 84 4c f6 ff e7    	je     0x732b11e0195d
    732b29e02311:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02318:	02 00 00 00 
    732b29e0231c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    732b29e02323:	09 00 00 00 
    732b29e02327:	58                   	pop    rax
    732b29e02328:	e9 42 fd ff e7       	jmp    0x732b11e0206f
    732b29e0232d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033e
    732b29e02334:	3e 03 01 00 
    732b29e02338:	b8 3e 03 01 00       	mov    eax,0x1033e
    732b29e0233d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02344:	02 00 00 00 
    732b29e02348:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e0234f:	0a 00 00 00 
    732b29e02353:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02356:	be 3e 03 01 00       	mov    esi,0x1033e
    732b29e0235b:	4c 89 ef             	mov    rdi,r13
    732b29e0235e:	e8 fd dd ff e7       	call   0x732b11e00160
    732b29e02363:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0236a:	00 
    732b29e0236b:	0f 84 1a f6 ff e7    	je     0x732b11e0198b
    732b29e02371:	e9 54 f6 ff e7       	jmp    0x732b11e019ca
    732b29e02376:	b8 3e 03 01 00       	mov    eax,0x1033e
    732b29e0237b:	83 c0 32             	add    eax,0x32
    732b29e0237e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02385:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0238c:	02 00 00 00 
    732b29e02390:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    732b29e02397:	0a 00 00 00 
    732b29e0239b:	be 3e 03 01 00       	mov    esi,0x1033e
    732b29e023a0:	ba 3e 03 01 00       	mov    edx,0x1033e
    732b29e023a5:	4c 89 ef             	mov    rdi,r13
    732b29e023a8:	e8 b3 dd ff e7       	call   0x732b11e00160
    732b29e023ad:	e9 09 f6 ff e7       	jmp    0x732b11e019bb
    732b29e023b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10340
    732b29e023b9:	40 03 01 00 
    732b29e023bd:	b8 40 03 01 00       	mov    eax,0x10340
    732b29e023c2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e023c9:	04 00 00 00 
    732b29e023cd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e023d4:	0b 00 00 00 
    732b29e023d8:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e023db:	be 40 03 01 00       	mov    esi,0x10340
    732b29e023e0:	4c 89 ef             	mov    rdi,r13
    732b29e023e3:	e8 78 dd ff e7       	call   0x732b11e00160
    732b29e023e8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e023ef:	00 
    732b29e023f0:	0f 84 23 f6 ff e7    	je     0x732b11e01a19
    732b29e023f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e023fd:	04 00 00 00 
    732b29e02401:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    732b29e02408:	0b 00 00 00 
    732b29e0240c:	58                   	pop    rax
    732b29e0240d:	e9 5d fc ff e7       	jmp    0x732b11e0206f
    732b29e02412:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10344
    732b29e02419:	44 03 01 00 
    732b29e0241d:	b8 44 03 01 00       	mov    eax,0x10344
    732b29e02422:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02429:	04 00 00 00 
    732b29e0242d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e02434:	0c 00 00 00 
    732b29e02438:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0243b:	be 44 03 01 00       	mov    esi,0x10344
    732b29e02440:	4c 89 ef             	mov    rdi,r13
    732b29e02443:	e8 18 dd ff e7       	call   0x732b11e00160
    732b29e02448:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e0244f:	00 
    732b29e02450:	0f 84 fa f5 ff e7    	je     0x732b11e01a50
    732b29e02456:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0245d:	04 00 00 00 
    732b29e02461:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    732b29e02468:	0c 00 00 00 
    732b29e0246c:	58                   	pop    rax
    732b29e0246d:	e9 fd fb ff e7       	jmp    0x732b11e0206f
    732b29e02472:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    732b29e02479:	48 03 01 00 
    732b29e0247d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02484:	02 00 00 00 
    732b29e02488:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e0248f:	0d 00 00 00 
    732b29e02493:	ba 48 03 01 00       	mov    edx,0x10348
    732b29e02498:	4c 89 ef             	mov    rdi,r13
    732b29e0249b:	4c 89 f6             	mov    rsi,r14
    732b29e0249e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e024a4:	e8 d7 db ff e7       	call   0x732b11e00080
    732b29e024a9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e024b0:	02 00 00 00 
    732b29e024b4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e024bb:	0d 00 00 00 
    732b29e024bf:	58                   	pop    rax
    732b29e024c0:	e9 aa fb ff e7       	jmp    0x732b11e0206f
    732b29e024c5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    732b29e024cc:	48 03 01 00 
    732b29e024d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e024d7:	02 00 00 00 
    732b29e024db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e024e2:	0d 00 00 00 
    732b29e024e6:	4c 89 f7             	mov    rdi,r14
    732b29e024e9:	89 ce                	mov    esi,ecx
    732b29e024eb:	e8 80 db ff e7       	call   0x732b11e00070
    732b29e024f0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e024f7:	00 
    732b29e024f8:	0f 84 90 f5 ff e7    	je     0x732b11e01a8e
    732b29e024fe:	eb a9                	jmp    0x732b29e024a9
    732b29e02500:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    732b29e02507:	48 03 01 00 
    732b29e0250b:	b8 48 03 01 00       	mov    eax,0x10348
    732b29e02510:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02517:	02 00 00 00 
    732b29e0251b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e02522:	0d 00 00 00 
    732b29e02526:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02529:	be 48 03 01 00       	mov    esi,0x10348
    732b29e0252e:	4c 89 ef             	mov    rdi,r13
    732b29e02531:	e8 2a dc ff e7       	call   0x732b11e00160
    732b29e02536:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e02539:	0f 84 80 f5 ff e7    	je     0x732b11e01abf
    732b29e0253f:	eb 0f                	jmp    0x732b29e02550
    732b29e02541:	b8 48 03 01 00       	mov    eax,0x10348
    732b29e02546:	83 c0 02             	add    eax,0x2
    732b29e02549:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02550:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02557:	02 00 00 00 
    732b29e0255b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    732b29e02562:	0d 00 00 00 
    732b29e02566:	4c 89 ef             	mov    rdi,r13
    732b29e02569:	e8 e2 db ff e7       	call   0x732b11e00150
    732b29e0256e:	e9 4c f5 ff e7       	jmp    0x732b11e01abf
    732b29e02573:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    732b29e0257a:	4a 03 01 00 
    732b29e0257e:	b8 4a 03 01 00       	mov    eax,0x1034a
    732b29e02583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0258a:	04 00 00 00 
    732b29e0258e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e02595:	0e 00 00 00 
    732b29e02599:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0259c:	be 4a 03 01 00       	mov    esi,0x1034a
    732b29e025a1:	4c 89 ef             	mov    rdi,r13
    732b29e025a4:	e8 b7 db ff e7       	call   0x732b11e00160
    732b29e025a9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e025b0:	00 
    732b29e025b1:	0f 84 4a f5 ff e7    	je     0x732b11e01b01
    732b29e025b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e025be:	04 00 00 00 
    732b29e025c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    732b29e025c9:	0e 00 00 00 
    732b29e025cd:	58                   	pop    rax
    732b29e025ce:	e9 9c fa ff e7       	jmp    0x732b11e0206f
    732b29e025d3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034e
    732b29e025da:	4e 03 01 00 
    732b29e025de:	b8 4e 03 01 00       	mov    eax,0x1034e
    732b29e025e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e025ea:	04 00 00 00 
    732b29e025ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e025f5:	0f 00 00 00 
    732b29e025f9:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e025fc:	be 4e 03 01 00       	mov    esi,0x1034e
    732b29e02601:	4c 89 ef             	mov    rdi,r13
    732b29e02604:	e8 57 db ff e7       	call   0x732b11e00160
    732b29e02609:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02610:	00 
    732b29e02611:	0f 84 21 f5 ff e7    	je     0x732b11e01b38
    732b29e02617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0261e:	04 00 00 00 
    732b29e02622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b29e02629:	0f 00 00 00 
    732b29e0262d:	58                   	pop    rax
    732b29e0262e:	e9 3c fa ff e7       	jmp    0x732b11e0206f
    732b29e02633:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    732b29e0263a:	52 03 01 00 
    732b29e0263e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02645:	02 00 00 00 
    732b29e02649:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e02650:	10 00 00 00 
    732b29e02654:	ba 52 03 01 00       	mov    edx,0x10352
    732b29e02659:	4c 89 ef             	mov    rdi,r13
    732b29e0265c:	4c 89 f6             	mov    rsi,r14
    732b29e0265f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e02665:	e8 16 da ff e7       	call   0x732b11e00080
    732b29e0266a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02671:	02 00 00 00 
    732b29e02675:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e0267c:	10 00 00 00 
    732b29e02680:	58                   	pop    rax
    732b29e02681:	e9 e9 f9 ff e7       	jmp    0x732b11e0206f
    732b29e02686:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    732b29e0268d:	52 03 01 00 
    732b29e02691:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02698:	02 00 00 00 
    732b29e0269c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e026a3:	10 00 00 00 
    732b29e026a7:	4c 89 f7             	mov    rdi,r14
    732b29e026aa:	89 ce                	mov    esi,ecx
    732b29e026ac:	e8 bf d9 ff e7       	call   0x732b11e00070
    732b29e026b1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e026b8:	00 
    732b29e026b9:	0f 84 b7 f4 ff e7    	je     0x732b11e01b76
    732b29e026bf:	eb a9                	jmp    0x732b29e0266a
    732b29e026c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    732b29e026c8:	52 03 01 00 
    732b29e026cc:	b8 52 03 01 00       	mov    eax,0x10352
    732b29e026d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e026d8:	02 00 00 00 
    732b29e026dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e026e3:	10 00 00 00 
    732b29e026e7:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e026ea:	be 52 03 01 00       	mov    esi,0x10352
    732b29e026ef:	4c 89 ef             	mov    rdi,r13
    732b29e026f2:	e8 69 da ff e7       	call   0x732b11e00160
    732b29e026f7:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e026fa:	0f 84 a7 f4 ff e7    	je     0x732b11e01ba7
    732b29e02700:	eb 0f                	jmp    0x732b29e02711
    732b29e02702:	b8 52 03 01 00       	mov    eax,0x10352
    732b29e02707:	83 c0 02             	add    eax,0x2
    732b29e0270a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02711:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02718:	02 00 00 00 
    732b29e0271c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    732b29e02723:	10 00 00 00 
    732b29e02727:	4c 89 ef             	mov    rdi,r13
    732b29e0272a:	e8 21 da ff e7       	call   0x732b11e00150
    732b29e0272f:	e9 73 f4 ff e7       	jmp    0x732b11e01ba7
    732b29e02734:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    732b29e0273b:	54 03 01 00 
    732b29e0273f:	b8 54 03 01 00       	mov    eax,0x10354
    732b29e02744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0274b:	04 00 00 00 
    732b29e0274f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e02756:	11 00 00 00 
    732b29e0275a:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e0275d:	be 54 03 01 00       	mov    esi,0x10354
    732b29e02762:	4c 89 ef             	mov    rdi,r13
    732b29e02765:	e8 f6 d9 ff e7       	call   0x732b11e00160
    732b29e0276a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02771:	00 
    732b29e02772:	0f 84 71 f4 ff e7    	je     0x732b11e01be9
    732b29e02778:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e0277f:	04 00 00 00 
    732b29e02783:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    732b29e0278a:	11 00 00 00 
    732b29e0278e:	58                   	pop    rax
    732b29e0278f:	e9 db f8 ff e7       	jmp    0x732b11e0206f
    732b29e02794:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10358
    732b29e0279b:	58 03 01 00 
    732b29e0279f:	b8 58 03 01 00       	mov    eax,0x10358
    732b29e027a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e027ab:	04 00 00 00 
    732b29e027af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e027b6:	12 00 00 00 
    732b29e027ba:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e027bd:	be 58 03 01 00       	mov    esi,0x10358
    732b29e027c2:	4c 89 ef             	mov    rdi,r13
    732b29e027c5:	e8 96 d9 ff e7       	call   0x732b11e00160
    732b29e027ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e027d1:	00 
    732b29e027d2:	0f 84 48 f4 ff e7    	je     0x732b11e01c20
    732b29e027d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e027df:	04 00 00 00 
    732b29e027e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    732b29e027ea:	12 00 00 00 
    732b29e027ee:	58                   	pop    rax
    732b29e027ef:	e9 7b f8 ff e7       	jmp    0x732b11e0206f
    732b29e027f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    732b29e027fb:	5c 03 01 00 
    732b29e027ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02806:	02 00 00 00 
    732b29e0280a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e02811:	13 00 00 00 
    732b29e02815:	ba 5c 03 01 00       	mov    edx,0x1035c
    732b29e0281a:	4c 89 ef             	mov    rdi,r13
    732b29e0281d:	4c 89 f6             	mov    rsi,r14
    732b29e02820:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e02826:	e8 55 d8 ff e7       	call   0x732b11e00080
    732b29e0282b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02832:	02 00 00 00 
    732b29e02836:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e0283d:	13 00 00 00 
    732b29e02841:	58                   	pop    rax
    732b29e02842:	e9 28 f8 ff e7       	jmp    0x732b11e0206f
    732b29e02847:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    732b29e0284e:	5c 03 01 00 
    732b29e02852:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02859:	02 00 00 00 
    732b29e0285d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e02864:	13 00 00 00 
    732b29e02868:	4c 89 f7             	mov    rdi,r14
    732b29e0286b:	89 ce                	mov    esi,ecx
    732b29e0286d:	e8 fe d7 ff e7       	call   0x732b11e00070
    732b29e02872:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02879:	00 
    732b29e0287a:	0f 84 de f3 ff e7    	je     0x732b11e01c5e
    732b29e02880:	eb a9                	jmp    0x732b29e0282b
    732b29e02882:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    732b29e02889:	5c 03 01 00 
    732b29e0288d:	b8 5c 03 01 00       	mov    eax,0x1035c
    732b29e02892:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02899:	02 00 00 00 
    732b29e0289d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e028a4:	13 00 00 00 
    732b29e028a8:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e028ab:	be 5c 03 01 00       	mov    esi,0x1035c
    732b29e028b0:	4c 89 ef             	mov    rdi,r13
    732b29e028b3:	e8 a8 d8 ff e7       	call   0x732b11e00160
    732b29e028b8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e028bb:	0f 84 ce f3 ff e7    	je     0x732b11e01c8f
    732b29e028c1:	eb 0f                	jmp    0x732b29e028d2
    732b29e028c3:	b8 5c 03 01 00       	mov    eax,0x1035c
    732b29e028c8:	83 c0 02             	add    eax,0x2
    732b29e028cb:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e028d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e028d9:	02 00 00 00 
    732b29e028dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    732b29e028e4:	13 00 00 00 
    732b29e028e8:	4c 89 ef             	mov    rdi,r13
    732b29e028eb:	e8 60 d8 ff e7       	call   0x732b11e00150
    732b29e028f0:	e9 9a f3 ff e7       	jmp    0x732b11e01c8f
    732b29e028f5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    732b29e028fc:	5e 03 01 00 
    732b29e02900:	b8 5e 03 01 00       	mov    eax,0x1035e
    732b29e02905:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0290c:	02 00 00 00 
    732b29e02910:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e02917:	14 00 00 00 
    732b29e0291b:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e0291e:	be 5e 03 01 00       	mov    esi,0x1035e
    732b29e02923:	4c 89 ef             	mov    rdi,r13
    732b29e02926:	e8 35 d8 ff e7       	call   0x732b11e00160
    732b29e0292b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02932:	00 
    732b29e02933:	0f 84 c9 f3 ff e7    	je     0x732b11e01d02
    732b29e02939:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02940:	02 00 00 00 
    732b29e02944:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    732b29e0294b:	14 00 00 00 
    732b29e0294f:	58                   	pop    rax
    732b29e02950:	e9 1a f7 ff e7       	jmp    0x732b11e0206f
    732b29e02955:	b8 60 03 01 00       	mov    eax,0x10360
    732b29e0295a:	83 c0 1a             	add    eax,0x1a
    732b29e0295d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02964:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0296b:	02 00 00 00 
    732b29e0296f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e02976:	15 00 00 00 
    732b29e0297a:	be 60 03 01 00       	mov    esi,0x10360
    732b29e0297f:	ba 60 03 01 00       	mov    edx,0x10360
    732b29e02984:	4c 89 ef             	mov    rdi,r13
    732b29e02987:	e8 d4 d7 ff e7       	call   0x732b11e00160
    732b29e0298c:	e9 a7 f3 ff e7       	jmp    0x732b11e01d38
    732b29e02991:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10360
    732b29e02998:	60 03 01 00 
    732b29e0299c:	b8 60 03 01 00       	mov    eax,0x10360
    732b29e029a1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e029a8:	02 00 00 00 
    732b29e029ac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    732b29e029b3:	15 00 00 00 
    732b29e029b7:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e029ba:	be 60 03 01 00       	mov    esi,0x10360
    732b29e029bf:	4c 89 ef             	mov    rdi,r13
    732b29e029c2:	e8 99 d7 ff e7       	call   0x732b11e00160
    732b29e029c7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e029ce:	00 
    732b29e029cf:	0f 84 b0 f3 ff e7    	je     0x732b11e01d85
    732b29e029d5:	e9 6d f3 ff e7       	jmp    0x732b11e01d47
    732b29e029da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10362
    732b29e029e1:	62 03 01 00 
    732b29e029e5:	b8 62 03 01 00       	mov    eax,0x10362
    732b29e029ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e029f1:	02 00 00 00 
    732b29e029f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e029fc:	16 00 00 00 
    732b29e02a00:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02a03:	be 62 03 01 00       	mov    esi,0x10362
    732b29e02a08:	4c 89 ef             	mov    rdi,r13
    732b29e02a0b:	e8 50 d7 ff e7       	call   0x732b11e00160
    732b29e02a10:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02a17:	00 
    732b29e02a18:	0f 84 cc f3 ff e7    	je     0x732b11e01dea
    732b29e02a1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02a25:	02 00 00 00 
    732b29e02a29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    732b29e02a30:	16 00 00 00 
    732b29e02a34:	58                   	pop    rax
    732b29e02a35:	e9 35 f6 ff e7       	jmp    0x732b11e0206f
    732b29e02a3a:	b8 64 03 01 00       	mov    eax,0x10364
    732b29e02a3f:	83 c0 40             	add    eax,0x40
    732b29e02a42:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e02a49:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02a50:	02 00 00 00 
    732b29e02a54:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e02a5b:	17 00 00 00 
    732b29e02a5f:	be 64 03 01 00       	mov    esi,0x10364
    732b29e02a64:	ba 64 03 01 00       	mov    edx,0x10364
    732b29e02a69:	4c 89 ef             	mov    rdi,r13
    732b29e02a6c:	e8 ef d6 ff e7       	call   0x732b11e00160
    732b29e02a71:	e9 aa f3 ff e7       	jmp    0x732b11e01e20
    732b29e02a76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10364
    732b29e02a7d:	64 03 01 00 
    732b29e02a81:	b8 64 03 01 00       	mov    eax,0x10364
    732b29e02a86:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02a8d:	02 00 00 00 
    732b29e02a91:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    732b29e02a98:	17 00 00 00 
    732b29e02a9c:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02a9f:	be 64 03 01 00       	mov    esi,0x10364
    732b29e02aa4:	4c 89 ef             	mov    rdi,r13
    732b29e02aa7:	e8 b4 d6 ff e7       	call   0x732b11e00160
    732b29e02aac:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02ab3:	00 
    732b29e02ab4:	0f 84 b3 f3 ff e7    	je     0x732b11e01e6d
    732b29e02aba:	e9 70 f3 ff e7       	jmp    0x732b11e01e2f
    732b29e02abf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10366
    732b29e02ac6:	66 03 01 00 
    732b29e02aca:	b8 66 03 01 00       	mov    eax,0x10366
    732b29e02acf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02ad6:	02 00 00 00 
    732b29e02ada:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    732b29e02ae1:	18 00 00 00 
    732b29e02ae5:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02ae8:	be 66 03 01 00       	mov    esi,0x10366
    732b29e02aed:	4c 89 ef             	mov    rdi,r13
    732b29e02af0:	e8 6b d6 ff e7       	call   0x732b11e00160
    732b29e02af5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02afc:	00 
    732b29e02afd:	0f 84 96 f3 ff e7    	je     0x732b11e01e99
    732b29e02b03:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02b0a:	02 00 00 00 
    732b29e02b0e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    732b29e02b15:	18 00 00 00 
    732b29e02b19:	58                   	pop    rax
    732b29e02b1a:	e9 50 f5 ff e7       	jmp    0x732b11e0206f
    732b29e02b1f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    732b29e02b26:	68 03 01 00 
    732b29e02b2a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02b31:	04 00 00 00 
    732b29e02b35:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e02b3c:	19 00 00 00 
    732b29e02b40:	ba 68 03 01 00       	mov    edx,0x10368
    732b29e02b45:	4c 89 ef             	mov    rdi,r13
    732b29e02b48:	4c 89 f6             	mov    rsi,r14
    732b29e02b4b:	89 d9                	mov    ecx,ebx
    732b29e02b4d:	45 31 c0             	xor    r8d,r8d
    732b29e02b50:	e8 2b d5 ff e7       	call   0x732b11e00080
    732b29e02b55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02b5c:	04 00 00 00 
    732b29e02b60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e02b67:	19 00 00 00 
    732b29e02b6b:	58                   	pop    rax
    732b29e02b6c:	e9 fe f4 ff e7       	jmp    0x732b11e0206f
    732b29e02b71:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    732b29e02b78:	68 03 01 00 
    732b29e02b7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02b83:	04 00 00 00 
    732b29e02b87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e02b8e:	19 00 00 00 
    732b29e02b92:	4c 89 f7             	mov    rdi,r14
    732b29e02b95:	89 de                	mov    esi,ebx
    732b29e02b97:	e8 a4 d4 ff e7       	call   0x732b11e00040
    732b29e02b9c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02ba3:	00 
    732b29e02ba4:	75 af                	jne    0x732b29e02b55
    732b29e02ba6:	41 89 c7             	mov    r15d,eax
    732b29e02ba9:	e9 22 f3 ff e7       	jmp    0x732b11e01ed0
    732b29e02bae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    732b29e02bb5:	68 03 01 00 
    732b29e02bb9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02bc0:	04 00 00 00 
    732b29e02bc4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e02bcb:	19 00 00 00 
    732b29e02bcf:	4c 89 f7             	mov    rdi,r14
    732b29e02bd2:	e8 69 d4 ff e7       	call   0x732b11e00040
    732b29e02bd7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02bde:	00 
    732b29e02bdf:	0f 84 0c f3 ff e7    	je     0x732b11e01ef1
    732b29e02be5:	e9 6b ff ff ff       	jmp    0x732b29e02b55
    732b29e02bea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    732b29e02bf1:	68 03 01 00 
    732b29e02bf5:	b8 68 03 01 00       	mov    eax,0x10368
    732b29e02bfa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e02c01:	04 00 00 00 
    732b29e02c05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    732b29e02c0c:	19 00 00 00 
    732b29e02c10:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e02c13:	be 68 03 01 00       	mov    esi,0x10368
    732b29e02c18:	4c 89 ef             	mov    rdi,r13
    732b29e02c1b:	e8 40 d5 ff e7       	call   0x732b11e00160
    732b29e02c20:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02c27:	00 
    732b29e02c28:	0f 84 f7 f2 ff e7    	je     0x732b11e01f25
    732b29e02c2e:	e9 22 ff ff ff       	jmp    0x732b29e02b55
    732b29e02c33:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02c3a:	6c 03 01 00 
    732b29e02c3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02c45:	02 00 00 00 
    732b29e02c49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02c50:	1a 00 00 00 
    732b29e02c54:	ba 6c 03 01 00       	mov    edx,0x1036c
    732b29e02c59:	4c 89 ef             	mov    rdi,r13
    732b29e02c5c:	4c 89 f6             	mov    rsi,r14
    732b29e02c5f:	89 d9                	mov    ecx,ebx
    732b29e02c61:	45 31 c0             	xor    r8d,r8d
    732b29e02c64:	e8 17 d4 ff e7       	call   0x732b11e00080
    732b29e02c69:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02c70:	02 00 00 00 
    732b29e02c74:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02c7b:	1a 00 00 00 
    732b29e02c7f:	58                   	pop    rax
    732b29e02c80:	e9 ea f3 ff e7       	jmp    0x732b11e0206f
    732b29e02c85:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02c8c:	6c 03 01 00 
    732b29e02c90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02c97:	02 00 00 00 
    732b29e02c9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02ca2:	1a 00 00 00 
    732b29e02ca6:	4c 89 f7             	mov    rdi,r14
    732b29e02ca9:	89 de                	mov    esi,ebx
    732b29e02cab:	e8 90 d3 ff e7       	call   0x732b11e00040
    732b29e02cb0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02cb7:	00 
    732b29e02cb8:	0f 84 9d f2 ff e7    	je     0x732b11e01f5b
    732b29e02cbe:	eb a9                	jmp    0x732b29e02c69
    732b29e02cc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02cc7:	6c 03 01 00 
    732b29e02ccb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02cd2:	02 00 00 00 
    732b29e02cd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02cdd:	1a 00 00 00 
    732b29e02ce1:	4c 89 f7             	mov    rdi,r14
    732b29e02ce4:	e8 57 d3 ff e7       	call   0x732b11e00040
    732b29e02ce9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02cf0:	00 
    732b29e02cf1:	0f 84 87 f2 ff e7    	je     0x732b11e01f7e
    732b29e02cf7:	e9 6d ff ff ff       	jmp    0x732b29e02c69
    732b29e02cfc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02d03:	6c 03 01 00 
    732b29e02d07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02d0e:	02 00 00 00 
    732b29e02d12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02d19:	1a 00 00 00 
    732b29e02d1d:	4c 89 f7             	mov    rdi,r14
    732b29e02d20:	e8 1b d3 ff e7       	call   0x732b11e00040
    732b29e02d25:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02d2c:	00 
    732b29e02d2d:	0f 84 6e f2 ff e7    	je     0x732b11e01fa1
    732b29e02d33:	e9 31 ff ff ff       	jmp    0x732b29e02c69
    732b29e02d38:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02d3f:	6c 03 01 00 
    732b29e02d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02d4a:	02 00 00 00 
    732b29e02d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02d55:	1a 00 00 00 
    732b29e02d59:	4c 89 f7             	mov    rdi,r14
    732b29e02d5c:	e8 df d2 ff e7       	call   0x732b11e00040
    732b29e02d61:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02d68:	00 
    732b29e02d69:	0f 84 55 f2 ff e7    	je     0x732b11e01fc4
    732b29e02d6f:	e9 f5 fe ff ff       	jmp    0x732b29e02c69
    732b29e02d74:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02d7b:	6c 03 01 00 
    732b29e02d7f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02d86:	02 00 00 00 
    732b29e02d8a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02d91:	1a 00 00 00 
    732b29e02d95:	4c 89 f7             	mov    rdi,r14
    732b29e02d98:	e8 a3 d2 ff e7       	call   0x732b11e00040
    732b29e02d9d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02da4:	00 
    732b29e02da5:	0f 84 3e f2 ff e7    	je     0x732b11e01fe9
    732b29e02dab:	e9 b9 fe ff ff       	jmp    0x732b29e02c69
    732b29e02db0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    732b29e02db7:	6c 03 01 00 
    732b29e02dbb:	b8 6c 03 01 00       	mov    eax,0x1036c
    732b29e02dc0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02dc7:	02 00 00 00 
    732b29e02dcb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    732b29e02dd2:	1a 00 00 00 
    732b29e02dd6:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e02dd9:	be 6c 03 01 00       	mov    esi,0x1036c
    732b29e02dde:	4c 89 ef             	mov    rdi,r13
    732b29e02de1:	e8 7a d3 ff e7       	call   0x732b11e00160
    732b29e02de6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e02ded:	00 
    732b29e02dee:	0f 84 22 f2 ff e7    	je     0x732b11e02016
    732b29e02df4:	e9 70 fe ff ff       	jmp    0x732b29e02c69
    732b29e02df9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    732b29e02e00:	6e 03 01 00 
    732b29e02e04:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02e0b:	02 00 00 00 
    732b29e02e0f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e02e16:	1b 00 00 00 
    732b29e02e1a:	4c 89 ef             	mov    rdi,r13
    732b29e02e1d:	be 2a 00 00 00       	mov    esi,0x2a
    732b29e02e22:	4c 89 f2             	mov    rdx,r14
    732b29e02e25:	e8 66 d2 ff e7       	call   0x732b11e00090
    732b29e02e2a:	e9 29 f2 ff e7       	jmp    0x732b11e02058
    732b29e02e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e02e36:	02 00 00 00 
    732b29e02e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    732b29e02e41:	1b 00 00 00 
    732b29e02e45:	be 6e 03 01 00       	mov    esi,0x1036e
    732b29e02e4a:	ba 6e 03 01 00       	mov    edx,0x1036e
    732b29e02e4f:	4c 89 ef             	mov    rdi,r13
    732b29e02e52:	e8 09 d3 ff e7       	call   0x732b11e00160
    732b29e02e57:	e9 fc f1 ff e7       	jmp    0x732b11e02058
    732b29e02e5c:	c2 08 00             	ret    0x8
