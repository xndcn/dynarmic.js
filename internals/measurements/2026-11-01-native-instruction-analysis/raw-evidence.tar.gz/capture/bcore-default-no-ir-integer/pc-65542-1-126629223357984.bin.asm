
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65542-1-126629223357984.bin:     file format binary


Disassembly of section .data:

0000732b29e05e20 <.data>:
    732b29e05e20:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e05e26:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e05e29:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e05e2f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e05e36:	0f 87 d5 f0 ff e7    	ja     0x732b11e04f11
    732b29e05e3c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xc
    732b29e05e43:	0c 00 00 00 
    732b29e05e47:	e9 c5 f0 ff e7       	jmp    0x732b11e04f11
    732b29e05e4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10006
    732b29e05e53:	06 00 01 00 
    732b29e05e57:	b8 06 00 01 00       	mov    eax,0x10006
    732b29e05e5c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05e63:	04 00 00 00 
    732b29e05e67:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05e6e:	01 00 00 00 
    732b29e05e72:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e05e75:	be 06 00 01 00       	mov    esi,0x10006
    732b29e05e7a:	4c 89 ef             	mov    rdi,r13
    732b29e05e7d:	e8 de a2 ff e7       	call   0x732b11e00160
    732b29e05e82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05e89:	00 
    732b29e05e8a:	0f 84 b4 f0 ff e7    	je     0x732b11e04f44
    732b29e05e90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05e97:	04 00 00 00 
    732b29e05e9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e05ea2:	01 00 00 00 
    732b29e05ea6:	58                   	pop    rax
    732b29e05ea7:	e9 9a f1 ff e7       	jmp    0x732b11e05046
    732b29e05eac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000a
    732b29e05eb3:	0a 00 01 00 
    732b29e05eb7:	b8 0a 00 01 00       	mov    eax,0x1000a
    732b29e05ebc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05ec3:	04 00 00 00 
    732b29e05ec7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05ece:	02 00 00 00 
    732b29e05ed2:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e05ed5:	be 0a 00 01 00       	mov    esi,0x1000a
    732b29e05eda:	4c 89 ef             	mov    rdi,r13
    732b29e05edd:	e8 7e a2 ff e7       	call   0x732b11e00160
    732b29e05ee2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05ee9:	00 
    732b29e05eea:	0f 84 8b f0 ff e7    	je     0x732b11e04f7b
    732b29e05ef0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e05ef7:	04 00 00 00 
    732b29e05efb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e05f02:	02 00 00 00 
    732b29e05f06:	58                   	pop    rax
    732b29e05f07:	e9 3a f1 ff e7       	jmp    0x732b11e05046
    732b29e05f0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    732b29e05f13:	0e 00 01 00 
    732b29e05f17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05f1e:	02 00 00 00 
    732b29e05f22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05f29:	03 00 00 00 
    732b29e05f2d:	ba 0e 00 01 00       	mov    edx,0x1000e
    732b29e05f32:	4c 89 ef             	mov    rdi,r13
    732b29e05f35:	4c 89 f6             	mov    rsi,r14
    732b29e05f38:	41 b8 00 00 01 00    	mov    r8d,0x10000
    732b29e05f3e:	e8 3d a1 ff e7       	call   0x732b11e00080
    732b29e05f43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05f4a:	02 00 00 00 
    732b29e05f4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05f55:	03 00 00 00 
    732b29e05f59:	58                   	pop    rax
    732b29e05f5a:	e9 e7 f0 ff e7       	jmp    0x732b11e05046
    732b29e05f5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    732b29e05f66:	0e 00 01 00 
    732b29e05f6a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05f71:	02 00 00 00 
    732b29e05f75:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05f7c:	03 00 00 00 
    732b29e05f80:	4c 89 f7             	mov    rdi,r14
    732b29e05f83:	89 ce                	mov    esi,ecx
    732b29e05f85:	e8 e6 a0 ff e7       	call   0x732b11e00070
    732b29e05f8a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e05f91:	00 
    732b29e05f92:	0f 84 21 f0 ff e7    	je     0x732b11e04fb9
    732b29e05f98:	eb a9                	jmp    0x732b29e05f43
    732b29e05f9a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    732b29e05fa1:	0e 00 01 00 
    732b29e05fa5:	b8 0e 00 01 00       	mov    eax,0x1000e
    732b29e05faa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05fb1:	02 00 00 00 
    732b29e05fb5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05fbc:	03 00 00 00 
    732b29e05fc0:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e05fc3:	be 0e 00 01 00       	mov    esi,0x1000e
    732b29e05fc8:	4c 89 ef             	mov    rdi,r13
    732b29e05fcb:	e8 90 a1 ff e7       	call   0x732b11e00160
    732b29e05fd0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b29e05fd3:	0f 84 11 f0 ff e7    	je     0x732b11e04fea
    732b29e05fd9:	eb 0f                	jmp    0x732b29e05fea
    732b29e05fdb:	b8 0e 00 01 00       	mov    eax,0x1000e
    732b29e05fe0:	83 c0 02             	add    eax,0x2
    732b29e05fe3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b29e05fea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e05ff1:	02 00 00 00 
    732b29e05ff5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e05ffc:	03 00 00 00 
    732b29e06000:	4c 89 ef             	mov    rdi,r13
    732b29e06003:	e8 48 a1 ff e7       	call   0x732b11e00150
    732b29e06008:	e9 dd ef ff e7       	jmp    0x732b11e04fea
    732b29e0600d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    732b29e06014:	10 00 01 00 
    732b29e06018:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e0601f:	02 00 00 00 
    732b29e06023:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e0602a:	04 00 00 00 
    732b29e0602e:	be 10 00 01 00       	mov    esi,0x10010
    732b29e06033:	ba 10 00 01 00       	mov    edx,0x10010
    732b29e06038:	4c 89 ef             	mov    rdi,r13
    732b29e0603b:	e8 20 a1 ff e7       	call   0x732b11e00160
    732b29e06040:	e9 df ef ff e7       	jmp    0x732b11e05024
    732b29e06045:	c2 08 00             	ret    0x8
