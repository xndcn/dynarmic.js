
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-66696-1-126629223348496.bin:     file format binary


Disassembly of section .data:

0000732b29e03910 <.data>:
    732b29e03910:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    732b29e03916:	8d 51 01             	lea    edx,[rcx+0x1]
    732b29e03919:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    732b29e0391f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    732b29e03926:	0f 87 45 f0 ff e7    	ja     0x732b11e02971
    732b29e0392c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x7
    732b29e03933:	07 00 00 00 
    732b29e03937:	e9 35 f0 ff e7       	jmp    0x732b11e02971
    732b29e0393c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10488
    732b29e03943:	88 04 01 00 
    732b29e03947:	b8 88 04 01 00       	mov    eax,0x10488
    732b29e0394c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03953:	04 00 00 00 
    732b29e03957:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e0395e:	01 00 00 00 
    732b29e03962:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03965:	be 88 04 01 00       	mov    esi,0x10488
    732b29e0396a:	4c 89 ef             	mov    rdi,r13
    732b29e0396d:	e8 ee c7 ff e7       	call   0x732b11e00160
    732b29e03972:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03979:	00 
    732b29e0397a:	0f 84 24 f0 ff e7    	je     0x732b11e029a4
    732b29e03980:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03987:	04 00 00 00 
    732b29e0398b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    732b29e03992:	01 00 00 00 
    732b29e03996:	58                   	pop    rax
    732b29e03997:	e9 36 f2 ff e7       	jmp    0x732b11e02bd2
    732b29e0399c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1048c
    732b29e039a3:	8c 04 01 00 
    732b29e039a7:	b8 8c 04 01 00       	mov    eax,0x1048c
    732b29e039ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e039b3:	04 00 00 00 
    732b29e039b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e039be:	02 00 00 00 
    732b29e039c2:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e039c5:	be 8c 04 01 00       	mov    esi,0x1048c
    732b29e039ca:	4c 89 ef             	mov    rdi,r13
    732b29e039cd:	e8 8e c7 ff e7       	call   0x732b11e00160
    732b29e039d2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e039d9:	00 
    732b29e039da:	0f 84 fb ef ff e7    	je     0x732b11e029db
    732b29e039e0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e039e7:	04 00 00 00 
    732b29e039eb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    732b29e039f2:	02 00 00 00 
    732b29e039f6:	58                   	pop    rax
    732b29e039f7:	e9 d6 f1 ff e7       	jmp    0x732b11e02bd2
    732b29e039fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10490
    732b29e03a03:	90 04 01 00 
    732b29e03a07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03a0e:	02 00 00 00 
    732b29e03a12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03a19:	03 00 00 00 
    732b29e03a1d:	ba 90 04 01 00       	mov    edx,0x10490
    732b29e03a22:	4c 89 ef             	mov    rdi,r13
    732b29e03a25:	4c 89 f6             	mov    rsi,r14
    732b29e03a28:	45 31 c0             	xor    r8d,r8d
    732b29e03a2b:	e8 50 c6 ff e7       	call   0x732b11e00080
    732b29e03a30:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03a37:	02 00 00 00 
    732b29e03a3b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03a42:	03 00 00 00 
    732b29e03a46:	58                   	pop    rax
    732b29e03a47:	e9 86 f1 ff e7       	jmp    0x732b11e02bd2
    732b29e03a4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10490
    732b29e03a53:	90 04 01 00 
    732b29e03a57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03a5e:	02 00 00 00 
    732b29e03a62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03a69:	03 00 00 00 
    732b29e03a6d:	4c 89 f7             	mov    rdi,r14
    732b29e03a70:	89 ce                	mov    esi,ecx
    732b29e03a72:	e8 c9 c5 ff e7       	call   0x732b11e00040
    732b29e03a77:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03a7e:	00 
    732b29e03a7f:	0f 84 89 ef ff e7    	je     0x732b11e02a0e
    732b29e03a85:	eb a9                	jmp    0x732b29e03a30
    732b29e03a87:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10490
    732b29e03a8e:	90 04 01 00 
    732b29e03a92:	b8 90 04 01 00       	mov    eax,0x10490
    732b29e03a97:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03a9e:	02 00 00 00 
    732b29e03aa2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    732b29e03aa9:	03 00 00 00 
    732b29e03aad:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03ab0:	be 90 04 01 00       	mov    esi,0x10490
    732b29e03ab5:	4c 89 ef             	mov    rdi,r13
    732b29e03ab8:	e8 a3 c6 ff e7       	call   0x732b11e00160
    732b29e03abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03ac4:	00 
    732b29e03ac5:	0f 84 69 ef ff e7    	je     0x732b11e02a34
    732b29e03acb:	e9 60 ff ff ff       	jmp    0x732b29e03a30
    732b29e03ad0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10492
    732b29e03ad7:	92 04 01 00 
    732b29e03adb:	b8 92 04 01 00       	mov    eax,0x10492
    732b29e03ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03ae7:	04 00 00 00 
    732b29e03aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03af2:	04 00 00 00 
    732b29e03af6:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03af9:	be 92 04 01 00       	mov    esi,0x10492
    732b29e03afe:	4c 89 ef             	mov    rdi,r13
    732b29e03b01:	e8 5a c6 ff e7       	call   0x732b11e00160
    732b29e03b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03b0d:	00 
    732b29e03b0e:	0f 84 54 ef ff e7    	je     0x732b11e02a68
    732b29e03b14:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03b1b:	04 00 00 00 
    732b29e03b1f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    732b29e03b26:	04 00 00 00 
    732b29e03b2a:	58                   	pop    rax
    732b29e03b2b:	e9 a2 f0 ff e7       	jmp    0x732b11e02bd2
    732b29e03b30:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10496
    732b29e03b37:	96 04 01 00 
    732b29e03b3b:	b8 96 04 01 00       	mov    eax,0x10496
    732b29e03b40:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03b47:	04 00 00 00 
    732b29e03b4b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e03b52:	05 00 00 00 
    732b29e03b56:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03b59:	be 96 04 01 00       	mov    esi,0x10496
    732b29e03b5e:	4c 89 ef             	mov    rdi,r13
    732b29e03b61:	e8 fa c5 ff e7       	call   0x732b11e00160
    732b29e03b66:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03b6d:	00 
    732b29e03b6e:	0f 84 2b ef ff e7    	je     0x732b11e02a9f
    732b29e03b74:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03b7b:	04 00 00 00 
    732b29e03b7f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    732b29e03b86:	05 00 00 00 
    732b29e03b8a:	58                   	pop    rax
    732b29e03b8b:	e9 42 f0 ff e7       	jmp    0x732b11e02bd2
    732b29e03b90:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049a
    732b29e03b97:	9a 04 01 00 
    732b29e03b9b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03ba2:	02 00 00 00 
    732b29e03ba6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03bad:	06 00 00 00 
    732b29e03bb1:	ba 9a 04 01 00       	mov    edx,0x1049a
    732b29e03bb6:	4c 89 ef             	mov    rdi,r13
    732b29e03bb9:	4c 89 f6             	mov    rsi,r14
    732b29e03bbc:	45 31 c0             	xor    r8d,r8d
    732b29e03bbf:	e8 bc c4 ff e7       	call   0x732b11e00080
    732b29e03bc4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03bcb:	02 00 00 00 
    732b29e03bcf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03bd6:	06 00 00 00 
    732b29e03bda:	58                   	pop    rax
    732b29e03bdb:	e9 f2 ef ff e7       	jmp    0x732b11e02bd2
    732b29e03be0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049a
    732b29e03be7:	9a 04 01 00 
    732b29e03beb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03bf2:	02 00 00 00 
    732b29e03bf6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03bfd:	06 00 00 00 
    732b29e03c01:	4c 89 f7             	mov    rdi,r14
    732b29e03c04:	89 ce                	mov    esi,ecx
    732b29e03c06:	e8 35 c4 ff e7       	call   0x732b11e00040
    732b29e03c0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03c12:	00 
    732b29e03c13:	0f 84 b9 ee ff e7    	je     0x732b11e02ad2
    732b29e03c19:	eb a9                	jmp    0x732b29e03bc4
    732b29e03c1b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049a
    732b29e03c22:	9a 04 01 00 
    732b29e03c26:	b8 9a 04 01 00       	mov    eax,0x1049a
    732b29e03c2b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b29e03c32:	02 00 00 00 
    732b29e03c36:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    732b29e03c3d:	06 00 00 00 
    732b29e03c41:	8d 50 02             	lea    edx,[rax+0x2]
    732b29e03c44:	be 9a 04 01 00       	mov    esi,0x1049a
    732b29e03c49:	4c 89 ef             	mov    rdi,r13
    732b29e03c4c:	e8 0f c5 ff e7       	call   0x732b11e00160
    732b29e03c51:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03c58:	00 
    732b29e03c59:	0f 84 99 ee ff e7    	je     0x732b11e02af8
    732b29e03c5f:	e9 60 ff ff ff       	jmp    0x732b29e03bc4
    732b29e03c64:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    732b29e03c6b:	9c 04 01 00 
    732b29e03c6f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03c76:	04 00 00 00 
    732b29e03c7a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e03c81:	07 00 00 00 
    732b29e03c85:	ba 9c 04 01 00       	mov    edx,0x1049c
    732b29e03c8a:	4c 89 ef             	mov    rdi,r13
    732b29e03c8d:	4c 89 f6             	mov    rsi,r14
    732b29e03c90:	89 d9                	mov    ecx,ebx
    732b29e03c92:	45 31 c0             	xor    r8d,r8d
    732b29e03c95:	e8 e6 c3 ff e7       	call   0x732b11e00080
    732b29e03c9a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03ca1:	04 00 00 00 
    732b29e03ca5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e03cac:	07 00 00 00 
    732b29e03cb0:	58                   	pop    rax
    732b29e03cb1:	e9 1c ef ff e7       	jmp    0x732b11e02bd2
    732b29e03cb6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    732b29e03cbd:	9c 04 01 00 
    732b29e03cc1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03cc8:	04 00 00 00 
    732b29e03ccc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e03cd3:	07 00 00 00 
    732b29e03cd7:	4c 89 f7             	mov    rdi,r14
    732b29e03cda:	89 de                	mov    esi,ebx
    732b29e03cdc:	e8 5f c3 ff e7       	call   0x732b11e00040
    732b29e03ce1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03ce8:	00 
    732b29e03ce9:	75 af                	jne    0x732b29e03c9a
    732b29e03ceb:	41 89 c7             	mov    r15d,eax
    732b29e03cee:	e9 3c ee ff e7       	jmp    0x732b11e02b2f
    732b29e03cf3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    732b29e03cfa:	9c 04 01 00 
    732b29e03cfe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03d05:	04 00 00 00 
    732b29e03d09:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e03d10:	07 00 00 00 
    732b29e03d14:	4c 89 f7             	mov    rdi,r14
    732b29e03d17:	e8 24 c3 ff e7       	call   0x732b11e00040
    732b29e03d1c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03d23:	00 
    732b29e03d24:	0f 84 26 ee ff e7    	je     0x732b11e02b50
    732b29e03d2a:	e9 6b ff ff ff       	jmp    0x732b29e03c9a
    732b29e03d2f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    732b29e03d36:	9c 04 01 00 
    732b29e03d3a:	b8 9c 04 01 00       	mov    eax,0x1049c
    732b29e03d3f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03d46:	04 00 00 00 
    732b29e03d4a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b29e03d51:	07 00 00 00 
    732b29e03d55:	8d 50 04             	lea    edx,[rax+0x4]
    732b29e03d58:	be 9c 04 01 00       	mov    esi,0x1049c
    732b29e03d5d:	4c 89 ef             	mov    rdi,r13
    732b29e03d60:	e8 fb c3 ff e7       	call   0x732b11e00160
    732b29e03d65:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b29e03d6c:	00 
    732b29e03d6d:	0f 84 11 ee ff e7    	je     0x732b11e02b84
    732b29e03d73:	e9 22 ff ff ff       	jmp    0x732b29e03c9a
    732b29e03d78:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    732b29e03d7f:	d0 00 01 00 
    732b29e03d83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    732b29e03d8a:	04 00 00 00 
    732b29e03d8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    732b29e03d95:	08 00 00 00 
    732b29e03d99:	be a0 04 01 00       	mov    esi,0x104a0
    732b29e03d9e:	ba a0 04 01 00       	mov    edx,0x104a0
    732b29e03da3:	4c 89 ef             	mov    rdi,r13
    732b29e03da6:	e8 b5 c3 ff e7       	call   0x732b11e00160
    732b29e03dab:	e9 00 ee ff e7       	jmp    0x732b11e02bb0
    732b29e03db0:	c2 08 00             	ret    0x8
