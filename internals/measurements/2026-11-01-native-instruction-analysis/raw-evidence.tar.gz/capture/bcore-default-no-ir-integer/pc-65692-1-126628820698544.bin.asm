
build-native-instruction-analysis/capture/bcore-default-no-ir-integer/pc-65692-1-126628820698544.bin:     file format binary


Disassembly of section .data:

0000732b11e045b0 <.data>:
    732b11e045b0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e045b7:	8b 88 28 00 10 00    	mov    ecx,DWORD PTR [rax+0x100028]
    732b11e045bd:	ff c1                	inc    ecx
    732b11e045bf:	89 88 28 00 10 00    	mov    DWORD PTR [rax+0x100028],ecx
    732b11e045c5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    732b11e045cb:	0f 84 5f 0b 00 18    	je     0x732b29e05130
    732b11e045d1:	50                   	push   rax
    732b11e045d2:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    732b11e045d6:	f6 c1 03             	test   cl,0x3
    732b11e045d9:	0f 85 7d 0b 00 18    	jne    0x732b29e0515c
    732b11e045df:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e045e6:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    732b11e045ea:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e045f1:	48 89 ce             	mov    rsi,rcx
    732b11e045f4:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e045f8:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e045fc:	48 85 c0             	test   rax,rax
    732b11e045ff:	0f 84 aa 0b 00 18    	je     0x732b29e051af
    732b11e04605:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0460b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e0460e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009c
    732b11e04615:	9c 00 01 00 
    732b11e04619:	0f 84 cb 0b 00 18    	je     0x732b29e051ea
    732b11e0461f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009c
    732b11e04626:	9c 00 01 00 
    732b11e0462a:	0f 84 ba 0b 00 18    	je     0x732b29e051ea
    732b11e04630:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e04633:	0f 85 f2 0b 00 18    	jne    0x732b29e0522b
    732b11e04639:	58                   	pop    rax
    732b11e0463a:	e9 0f 00 00 00       	jmp    0x732b11e0464e
    732b11e0463f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e04646:	00 
    732b11e04647:	74 f0                	je     0x732b11e04639
    732b11e04649:	e9 45 0b 00 18       	jmp    0x732b29e05193
    732b11e0464e:	50                   	push   rax
    732b11e0464f:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    732b11e04653:	f6 c3 03             	test   bl,0x3
    732b11e04656:	0f 85 01 0c 00 18    	jne    0x732b29e0525d
    732b11e0465c:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    732b11e04663:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e04667:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e0466e:	48 89 d9             	mov    rcx,rbx
    732b11e04671:	48 c1 e9 0c          	shr    rcx,0xc
    732b11e04675:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    732b11e04679:	48 85 c0             	test   rax,rax
    732b11e0467c:	0f 84 30 0c 00 18    	je     0x732b29e052b2
    732b11e04682:	89 d9                	mov    ecx,ebx
    732b11e04684:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e0468a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e0468d:	83 c3 04             	add    ebx,0x4
    732b11e04690:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    732b11e04694:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009e
    732b11e0469b:	9e 00 01 00 
    732b11e0469f:	0f 84 48 0c 00 18    	je     0x732b29e052ed
    732b11e046a5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009e
    732b11e046ac:	9e 00 01 00 
    732b11e046b0:	0f 84 37 0c 00 18    	je     0x732b29e052ed
    732b11e046b6:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    732b11e046ba:	0f 85 6f 0c 00 18    	jne    0x732b29e0532f
    732b11e046c0:	58                   	pop    rax
    732b11e046c1:	e9 0f 00 00 00       	jmp    0x732b11e046d5
    732b11e046c6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e046cd:	00 
    732b11e046ce:	74 f0                	je     0x732b11e046c0
    732b11e046d0:	e9 c1 0b 00 18       	jmp    0x732b29e05296
    732b11e046d5:	50                   	push   rax
    732b11e046d6:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    732b11e046da:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    732b11e046e1:	31 d2                	xor    edx,edx
    732b11e046e3:	89 c6                	mov    esi,eax
    732b11e046e5:	ff c6                	inc    esi
    732b11e046e7:	0f 94 c2             	sete   dl
    732b11e046ea:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    732b11e046ee:	c1 e8 1f             	shr    eax,0x1f
    732b11e046f1:	89 f7                	mov    edi,esi
    732b11e046f3:	c1 ef 1f             	shr    edi,0x1f
    732b11e046f6:	f7 d0                	not    eax
    732b11e046f8:	21 f8                	and    eax,edi
    732b11e046fa:	31 db                	xor    ebx,ebx
    732b11e046fc:	85 f6                	test   esi,esi
    732b11e046fe:	0f 94 c3             	sete   bl
    732b11e04701:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    732b11e04708:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    732b11e0470f:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    732b11e04716:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    732b11e0471d:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    732b11e04724:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    732b11e0472b:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    732b11e04732:	81 f9 a0 00 01 00    	cmp    ecx,0x100a0
    732b11e04738:	0f 84 23 0c 00 18    	je     0x732b29e05361
    732b11e0473e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a0
    732b11e04745:	a0 00 01 00 
    732b11e04749:	0f 84 12 0c 00 18    	je     0x732b29e05361
    732b11e0474f:	58                   	pop    rax
    732b11e04750:	50                   	push   rax
    732b11e04751:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    732b11e04758:	00 
    732b11e04759:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a2
    732b11e04760:	a2 00 01 00 
    732b11e04764:	0f 84 57 0c 00 18    	je     0x732b29e053c1
    732b11e0476a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a2
    732b11e04771:	a2 00 01 00 
    732b11e04775:	0f 84 46 0c 00 18    	je     0x732b29e053c1
    732b11e0477b:	58                   	pop    rax
    732b11e0477c:	50                   	push   rax
    732b11e0477d:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    732b11e04781:	f6 c1 03             	test   cl,0x3
    732b11e04784:	0f 85 97 0c 00 18    	jne    0x732b29e05421
    732b11e0478a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e04791:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    732b11e04795:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e0479c:	48 89 ce             	mov    rsi,rcx
    732b11e0479f:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e047a3:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e047a7:	48 85 c0             	test   rax,rax
    732b11e047aa:	0f 84 c4 0c 00 18    	je     0x732b29e05474
    732b11e047b0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e047b6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e047b9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a4
    732b11e047c0:	a4 00 01 00 
    732b11e047c4:	0f 84 e5 0c 00 18    	je     0x732b29e054af
    732b11e047ca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a4
    732b11e047d1:	a4 00 01 00 
    732b11e047d5:	0f 84 d4 0c 00 18    	je     0x732b29e054af
    732b11e047db:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e047de:	0f 85 0c 0d 00 18    	jne    0x732b29e054f0
    732b11e047e4:	58                   	pop    rax
    732b11e047e5:	e9 0f 00 00 00       	jmp    0x732b11e047f9
    732b11e047ea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e047f1:	00 
    732b11e047f2:	74 f0                	je     0x732b11e047e4
    732b11e047f4:	e9 5f 0c 00 18       	jmp    0x732b29e05458
    732b11e047f9:	50                   	push   rax
    732b11e047fa:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    732b11e047fe:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    732b11e04802:	31 d2                	xor    edx,edx
    732b11e04804:	31 f6                	xor    esi,esi
    732b11e04806:	89 cf                	mov    edi,ecx
    732b11e04808:	29 c7                	sub    edi,eax
    732b11e0480a:	0f 94 c2             	sete   dl
    732b11e0480d:	40 0f 93 c6          	setae  sil
    732b11e04811:	c1 ef 1f             	shr    edi,0x1f
    732b11e04814:	c1 e9 1f             	shr    ecx,0x1f
    732b11e04817:	c1 e8 1f             	shr    eax,0x1f
    732b11e0481a:	89 fb                	mov    ebx,edi
    732b11e0481c:	31 cb                	xor    ebx,ecx
    732b11e0481e:	31 c8                	xor    eax,ecx
    732b11e04820:	21 d8                	and    eax,ebx
    732b11e04822:	31 f8                	xor    eax,edi
    732b11e04824:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    732b11e0482b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    732b11e04832:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    732b11e04839:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    732b11e04840:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    732b11e04847:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a6
    732b11e0484e:	a6 00 01 00 
    732b11e04852:	0f 84 ca 0c 00 18    	je     0x732b29e05522
    732b11e04858:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a6
    732b11e0485f:	a6 00 01 00 
    732b11e04863:	0f 84 b9 0c 00 18    	je     0x732b29e05522
    732b11e04869:	58                   	pop    rax
    732b11e0486a:	50                   	push   rax
    732b11e0486b:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    732b11e04872:	00 
    732b11e04873:	74 28                	je     0x732b11e0489d
    732b11e04875:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    732b11e0487c:	a8 00 01 00 
    732b11e04880:	0f 84 fc 0c 00 18    	je     0x732b29e05582
    732b11e04886:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    732b11e0488d:	a8 00 01 00 
    732b11e04891:	0f 84 eb 0c 00 18    	je     0x732b29e05582
    732b11e04897:	58                   	pop    rax
    732b11e04898:	e9 55 00 00 00       	jmp    0x732b11e048f2
    732b11e0489d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e048a4:	01 
    732b11e048a5:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    732b11e048ac:	a8 00 01 00 
    732b11e048b0:	0f 84 15 0d 00 18    	je     0x732b29e055cb
    732b11e048b6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    732b11e048bd:	a8 00 01 00 
    732b11e048c1:	0f 84 04 0d 00 18    	je     0x732b29e055cb
    732b11e048c7:	b8 a8 00 01 00       	mov    eax,0x100a8
    732b11e048cc:	83 c0 dc             	add    eax,0xffffffdc
    732b11e048cf:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e048d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e048dd:	02 00 00 00 
    732b11e048e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    732b11e048e8:	07 00 00 00 
    732b11e048ec:	58                   	pop    rax
    732b11e048ed:	e9 5b 03 00 00       	jmp    0x732b11e04c4d
    732b11e048f2:	50                   	push   rax
    732b11e048f3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    732b11e048f8:	b9 00 00 00 00       	mov    ecx,0x0
    732b11e048fd:	09 c1                	or     ecx,eax
    732b11e048ff:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e04903:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100aa
    732b11e0490a:	aa 00 01 00 
    732b11e0490e:	0f 84 f3 0c 00 18    	je     0x732b29e05607
    732b11e04914:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100aa
    732b11e0491b:	aa 00 01 00 
    732b11e0491f:	0f 84 e2 0c 00 18    	je     0x732b29e05607
    732b11e04925:	58                   	pop    rax
    732b11e04926:	50                   	push   rax
    732b11e04927:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    732b11e0492e:	00 
    732b11e0492f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ae
    732b11e04936:	ae 00 01 00 
    732b11e0493a:	0f 84 27 0d 00 18    	je     0x732b29e05667
    732b11e04940:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ae
    732b11e04947:	ae 00 01 00 
    732b11e0494b:	0f 84 16 0d 00 18    	je     0x732b29e05667
    732b11e04951:	58                   	pop    rax
    732b11e04952:	50                   	push   rax
    732b11e04953:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    732b11e04958:	c1 e0 10             	shl    eax,0x10
    732b11e0495b:	b9 10 f0 00 00       	mov    ecx,0xf010
    732b11e04960:	09 c1                	or     ecx,eax
    732b11e04962:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    732b11e04966:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b0
    732b11e0496d:	b0 00 01 00 
    732b11e04971:	0f 84 50 0d 00 18    	je     0x732b29e056c7
    732b11e04977:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b0
    732b11e0497e:	b0 00 01 00 
    732b11e04982:	0f 84 3f 0d 00 18    	je     0x732b29e056c7
    732b11e04988:	58                   	pop    rax
    732b11e04989:	50                   	push   rax
    732b11e0498a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    732b11e0498e:	f6 c1 03             	test   cl,0x3
    732b11e04991:	0f 85 90 0d 00 18    	jne    0x732b29e05727
    732b11e04997:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    732b11e0499e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    732b11e049a2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    732b11e049a9:	48 89 ce             	mov    rsi,rcx
    732b11e049ac:	48 c1 ee 0c          	shr    rsi,0xc
    732b11e049b0:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    732b11e049b4:	48 85 c0             	test   rax,rax
    732b11e049b7:	0f 84 bd 0d 00 18    	je     0x732b29e0577a
    732b11e049bd:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e049c3:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    732b11e049c6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b4
    732b11e049cd:	b4 00 01 00 
    732b11e049d1:	0f 84 de 0d 00 18    	je     0x732b29e057b5
    732b11e049d7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b4
    732b11e049de:	b4 00 01 00 
    732b11e049e2:	0f 84 cd 0d 00 18    	je     0x732b29e057b5
    732b11e049e8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    732b11e049eb:	0f 85 05 0e 00 18    	jne    0x732b29e057f6
    732b11e049f1:	58                   	pop    rax
    732b11e049f2:	e9 0f 00 00 00       	jmp    0x732b11e04a06
    732b11e049f7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    732b11e049fe:	00 
    732b11e049ff:	74 f0                	je     0x732b11e049f1
    732b11e04a01:	e9 58 0d 00 18       	jmp    0x732b29e0575e
    732b11e04a06:	50                   	push   rax
    732b11e04a07:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    732b11e04a0b:	f6 c3 03             	test   bl,0x3
    732b11e04a0e:	0f 85 14 0e 00 18    	jne    0x732b29e05828
    732b11e04a14:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e04a1b:	48 89 d8             	mov    rax,rbx
    732b11e04a1e:	48 c1 e8 0c          	shr    rax,0xc
    732b11e04a22:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04a27:	48 85 c0             	test   rax,rax
    732b11e04a2a:	0f 84 4a 0e 00 18    	je     0x732b29e0587a
    732b11e04a30:	89 d9                	mov    ecx,ebx
    732b11e04a32:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e04a38:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    732b11e04a3c:	89 de                	mov    esi,ebx
    732b11e04a3e:	83 c6 04             	add    esi,0x4
    732b11e04a41:	89 f0                	mov    eax,esi
    732b11e04a43:	c1 e8 0c             	shr    eax,0xc
    732b11e04a46:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04a4b:	48 85 c0             	test   rax,rax
    732b11e04a4e:	0f 84 63 0e 00 18    	je     0x732b29e058b7
    732b11e04a54:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04a5a:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04a5d:	8d 4b 08             	lea    ecx,[rbx+0x8]
    732b11e04a60:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    732b11e04a64:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    732b11e04a6b:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    732b11e04a6f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b6
    732b11e04a76:	b6 00 01 00 
    732b11e04a7a:	0f 84 73 0e 00 18    	je     0x732b29e058f3
    732b11e04a80:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b6
    732b11e04a87:	b6 00 01 00 
    732b11e04a8b:	0f 84 62 0e 00 18    	je     0x732b29e058f3
    732b11e04a91:	58                   	pop    rax
    732b11e04a92:	50                   	push   rax
    732b11e04a93:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    732b11e04a9a:	00 
    732b11e04a9b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ba
    732b11e04aa2:	ba 00 01 00 
    732b11e04aa6:	0f 84 90 0e 00 18    	je     0x732b29e0593c
    732b11e04aac:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ba
    732b11e04ab3:	ba 00 01 00 
    732b11e04ab7:	0f 84 7f 0e 00 18    	je     0x732b29e0593c
    732b11e04abd:	58                   	pop    rax
    732b11e04abe:	50                   	push   rax
    732b11e04abf:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    732b11e04ac3:	f6 c3 03             	test   bl,0x3
    732b11e04ac6:	0f 85 d0 0e 00 18    	jne    0x732b29e0599c
    732b11e04acc:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    732b11e04ad3:	48 89 d8             	mov    rax,rbx
    732b11e04ad6:	48 c1 e8 0c          	shr    rax,0xc
    732b11e04ada:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04adf:	48 85 c0             	test   rax,rax
    732b11e04ae2:	0f 84 06 0f 00 18    	je     0x732b29e059ee
    732b11e04ae8:	89 d9                	mov    ecx,ebx
    732b11e04aea:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    732b11e04af0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    732b11e04af3:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    732b11e04af7:	8d 73 04             	lea    esi,[rbx+0x4]
    732b11e04afa:	89 f0                	mov    eax,esi
    732b11e04afc:	c1 e8 0c             	shr    eax,0xc
    732b11e04aff:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04b04:	48 85 c0             	test   rax,rax
    732b11e04b07:	0f 84 1c 0f 00 18    	je     0x732b29e05a29
    732b11e04b0d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04b13:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04b16:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    732b11e04b1a:	8d 73 08             	lea    esi,[rbx+0x8]
    732b11e04b1d:	89 f0                	mov    eax,esi
    732b11e04b1f:	c1 e8 0c             	shr    eax,0xc
    732b11e04b22:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04b27:	48 85 c0             	test   rax,rax
    732b11e04b2a:	0f 84 35 0f 00 18    	je     0x732b29e05a65
    732b11e04b30:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04b36:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04b39:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    732b11e04b3d:	8d 73 0c             	lea    esi,[rbx+0xc]
    732b11e04b40:	89 f0                	mov    eax,esi
    732b11e04b42:	c1 e8 0c             	shr    eax,0xc
    732b11e04b45:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04b4a:	48 85 c0             	test   rax,rax
    732b11e04b4d:	0f 84 4e 0f 00 18    	je     0x732b29e05aa1
    732b11e04b53:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04b59:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04b5c:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    732b11e04b60:	8d 73 10             	lea    esi,[rbx+0x10]
    732b11e04b63:	89 f0                	mov    eax,esi
    732b11e04b65:	c1 e8 0c             	shr    eax,0xc
    732b11e04b68:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04b6d:	48 85 c0             	test   rax,rax
    732b11e04b70:	0f 84 67 0f 00 18    	je     0x732b29e05add
    732b11e04b76:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04b7c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04b7f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    732b11e04b83:	8d 73 14             	lea    esi,[rbx+0x14]
    732b11e04b86:	89 f0                	mov    eax,esi
    732b11e04b88:	c1 e8 0c             	shr    eax,0xc
    732b11e04b8b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04b90:	48 85 c0             	test   rax,rax
    732b11e04b93:	0f 84 80 0f 00 18    	je     0x732b29e05b19
    732b11e04b99:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04b9f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04ba2:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    732b11e04ba6:	89 de                	mov    esi,ebx
    732b11e04ba8:	83 c6 18             	add    esi,0x18
    732b11e04bab:	89 f0                	mov    eax,esi
    732b11e04bad:	c1 e8 0c             	shr    eax,0xc
    732b11e04bb0:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    732b11e04bb5:	48 85 c0             	test   rax,rax
    732b11e04bb8:	0f 84 97 0f 00 18    	je     0x732b29e05b55
    732b11e04bbe:	81 e6 ff 0f 00 00    	and    esi,0xfff
    732b11e04bc4:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    732b11e04bc7:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    732b11e04bcb:	8d 43 1c             	lea    eax,[rbx+0x1c]
    732b11e04bce:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    732b11e04bd2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100bc
    732b11e04bd9:	bc 00 01 00 
    732b11e04bdd:	0f 84 ae 0f 00 18    	je     0x732b29e05b91
    732b11e04be3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100bc
    732b11e04bea:	bc 00 01 00 
    732b11e04bee:	0f 84 9d 0f 00 18    	je     0x732b29e05b91
    732b11e04bf4:	58                   	pop    rax
    732b11e04bf5:	50                   	push   rax
    732b11e04bf6:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    732b11e04bfd:	a8 01                	test   al,0x1
    732b11e04bff:	0f 85 d5 0f 00 18    	jne    0x732b29e05bda
    732b11e04c05:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    732b11e04c0c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    732b11e04c13:	01 
    732b11e04c14:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100be
    732b11e04c1b:	be 00 01 00 
    732b11e04c1f:	0f 84 eb 0f 00 18    	je     0x732b29e05c10
    732b11e04c25:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100be
    732b11e04c2c:	be 00 01 00 
    732b11e04c30:	0f 84 da 0f 00 18    	je     0x732b29e05c10
    732b11e04c36:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    732b11e04c3d:	02 00 00 00 
    732b11e04c41:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    732b11e04c48:	0f 00 00 00 
    732b11e04c4c:	58                   	pop    rax
    732b11e04c4d:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    732b11e04c54:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    732b11e04c5b:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    732b11e04c62:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    732b11e04c69:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    732b11e04c70:	39 f1                	cmp    ecx,esi
    732b11e04c72:	0f 83 c5 0f 00 18    	jae    0x732b29e05c3d
    732b11e04c78:	81 fa 9c 00 01 00    	cmp    edx,0x1009c
    732b11e04c7e:	75 14                	jne    0x732b11e04c94
    732b11e04c80:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e04c87:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e04c8e:	00 
    732b11e04c8f:	e9 1c f9 ff ff       	jmp    0x732b11e045b0
    732b11e04c94:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    732b11e04c9b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    732b11e04ca1:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    732b11e04ca4:	0f 85 93 0f 00 18    	jne    0x732b29e05c3d
    732b11e04caa:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    732b11e04cb1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    732b11e04cb8:	00 
    732b11e04cb9:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    732b11e04cbe:	ff e0                	jmp    rax
