
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66078-1-124302470964064.bin:     file format binary


Disassembly of section .data:

0000710d6ca06360 <.data>:
    710d6ca06360:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca06366:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca06369:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca0636f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca06376:	0f 87 05 e4 ff e7    	ja     0x710d54a04781
    710d6ca0637c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xe
    710d6ca06383:	0e 00 00 00 
    710d6ca06387:	e9 f5 e3 ff e7       	jmp    0x710d54a04781
    710d6ca0638c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1021e
    710d6ca06393:	1e 02 01 00 
    710d6ca06397:	b8 1e 02 01 00       	mov    eax,0x1021e
    710d6ca0639c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca063a3:	02 00 00 00 
    710d6ca063a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca063ae:	01 00 00 00 
    710d6ca063b2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca063b5:	be 1e 02 01 00       	mov    esi,0x1021e
    710d6ca063ba:	4c 89 ef             	mov    rdi,r13
    710d6ca063bd:	e8 9e 9d ff e7       	call   0x710d54a00160
    710d6ca063c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca063c9:	00 
    710d6ca063ca:	0f 84 de e3 ff e7    	je     0x710d54a047ae
    710d6ca063d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca063d7:	02 00 00 00 
    710d6ca063db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca063e2:	01 00 00 00 
    710d6ca063e6:	58                   	pop    rax
    710d6ca063e7:	e9 43 e8 ff e7       	jmp    0x710d54a04c2f
    710d6ca063ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10220
    710d6ca063f3:	20 02 01 00 
    710d6ca063f7:	b8 20 02 01 00       	mov    eax,0x10220
    710d6ca063fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06403:	02 00 00 00 
    710d6ca06407:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0640e:	02 00 00 00 
    710d6ca06412:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06415:	be 20 02 01 00       	mov    esi,0x10220
    710d6ca0641a:	4c 89 ef             	mov    rdi,r13
    710d6ca0641d:	e8 3e 9d ff e7       	call   0x710d54a00160
    710d6ca06422:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06429:	00 
    710d6ca0642a:	0f 84 f9 e3 ff e7    	je     0x710d54a04829
    710d6ca06430:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06437:	02 00 00 00 
    710d6ca0643b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca06442:	02 00 00 00 
    710d6ca06446:	58                   	pop    rax
    710d6ca06447:	e9 e3 e7 ff e7       	jmp    0x710d54a04c2f
    710d6ca0644c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10222
    710d6ca06453:	22 02 01 00 
    710d6ca06457:	b8 22 02 01 00       	mov    eax,0x10222
    710d6ca0645c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06463:	02 00 00 00 
    710d6ca06467:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca0646e:	03 00 00 00 
    710d6ca06472:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06475:	be 22 02 01 00       	mov    esi,0x10222
    710d6ca0647a:	4c 89 ef             	mov    rdi,r13
    710d6ca0647d:	e8 de 9c ff e7       	call   0x710d54a00160
    710d6ca06482:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06489:	00 
    710d6ca0648a:	0f 84 00 e4 ff e7    	je     0x710d54a04890
    710d6ca06490:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06497:	02 00 00 00 
    710d6ca0649b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca064a2:	03 00 00 00 
    710d6ca064a6:	58                   	pop    rax
    710d6ca064a7:	e9 83 e7 ff e7       	jmp    0x710d54a04c2f
    710d6ca064ac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10224
    710d6ca064b3:	24 02 01 00 
    710d6ca064b7:	b8 24 02 01 00       	mov    eax,0x10224
    710d6ca064bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca064c3:	02 00 00 00 
    710d6ca064c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca064ce:	04 00 00 00 
    710d6ca064d2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca064d5:	be 24 02 01 00       	mov    esi,0x10224
    710d6ca064da:	4c 89 ef             	mov    rdi,r13
    710d6ca064dd:	e8 7e 9c ff e7       	call   0x710d54a00160
    710d6ca064e2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca064e9:	00 
    710d6ca064ea:	0f 84 d5 e3 ff e7    	je     0x710d54a048c5
    710d6ca064f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca064f7:	02 00 00 00 
    710d6ca064fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca06502:	04 00 00 00 
    710d6ca06506:	58                   	pop    rax
    710d6ca06507:	e9 23 e7 ff e7       	jmp    0x710d54a04c2f
    710d6ca0650c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca06513:	26 02 01 00 
    710d6ca06517:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0651e:	02 00 00 00 
    710d6ca06522:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca06529:	05 00 00 00 
    710d6ca0652d:	ba 26 02 01 00       	mov    edx,0x10226
    710d6ca06532:	4c 89 ef             	mov    rdi,r13
    710d6ca06535:	4c 89 f6             	mov    rsi,r14
    710d6ca06538:	45 31 c0             	xor    r8d,r8d
    710d6ca0653b:	e8 40 9b ff e7       	call   0x710d54a00080
    710d6ca06540:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06547:	02 00 00 00 
    710d6ca0654b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca06552:	05 00 00 00 
    710d6ca06556:	58                   	pop    rax
    710d6ca06557:	e9 d3 e6 ff e7       	jmp    0x710d54a04c2f
    710d6ca0655c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca06563:	26 02 01 00 
    710d6ca06567:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0656e:	02 00 00 00 
    710d6ca06572:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca06579:	05 00 00 00 
    710d6ca0657d:	4c 89 f7             	mov    rdi,r14
    710d6ca06580:	89 ce                	mov    esi,ecx
    710d6ca06582:	e8 b9 9a ff e7       	call   0x710d54a00040
    710d6ca06587:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0658e:	00 
    710d6ca0658f:	0f 84 63 e3 ff e7    	je     0x710d54a048f8
    710d6ca06595:	eb a9                	jmp    0x710d6ca06540
    710d6ca06597:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca0659e:	26 02 01 00 
    710d6ca065a2:	b8 26 02 01 00       	mov    eax,0x10226
    710d6ca065a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca065ae:	02 00 00 00 
    710d6ca065b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca065b9:	05 00 00 00 
    710d6ca065bd:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca065c0:	be 26 02 01 00       	mov    esi,0x10226
    710d6ca065c5:	4c 89 ef             	mov    rdi,r13
    710d6ca065c8:	e8 93 9b ff e7       	call   0x710d54a00160
    710d6ca065cd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca065d4:	00 
    710d6ca065d5:	0f 84 43 e3 ff e7    	je     0x710d54a0491e
    710d6ca065db:	e9 60 ff ff ff       	jmp    0x710d6ca06540
    710d6ca065e0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10228
    710d6ca065e7:	28 02 01 00 
    710d6ca065eb:	b8 28 02 01 00       	mov    eax,0x10228
    710d6ca065f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca065f7:	02 00 00 00 
    710d6ca065fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca06602:	06 00 00 00 
    710d6ca06606:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06609:	be 28 02 01 00       	mov    esi,0x10228
    710d6ca0660e:	4c 89 ef             	mov    rdi,r13
    710d6ca06611:	e8 4a 9b ff e7       	call   0x710d54a00160
    710d6ca06616:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0661d:	00 
    710d6ca0661e:	0f 84 58 e3 ff e7    	je     0x710d54a0497c
    710d6ca06624:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0662b:	02 00 00 00 
    710d6ca0662f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca06636:	06 00 00 00 
    710d6ca0663a:	58                   	pop    rax
    710d6ca0663b:	e9 ef e5 ff e7       	jmp    0x710d54a04c2f
    710d6ca06640:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022a
    710d6ca06647:	2a 02 01 00 
    710d6ca0664b:	b8 2a 02 01 00       	mov    eax,0x1022a
    710d6ca06650:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06657:	02 00 00 00 
    710d6ca0665b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca06662:	07 00 00 00 
    710d6ca06666:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06669:	be 2a 02 01 00       	mov    esi,0x1022a
    710d6ca0666e:	4c 89 ef             	mov    rdi,r13
    710d6ca06671:	e8 ea 9a ff e7       	call   0x710d54a00160
    710d6ca06676:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0667d:	00 
    710d6ca0667e:	0f 84 7e e3 ff e7    	je     0x710d54a04a02
    710d6ca06684:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0668b:	02 00 00 00 
    710d6ca0668f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca06696:	07 00 00 00 
    710d6ca0669a:	58                   	pop    rax
    710d6ca0669b:	e9 8f e5 ff e7       	jmp    0x710d54a04c2f
    710d6ca066a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022c
    710d6ca066a7:	2c 02 01 00 
    710d6ca066ab:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d6ca066b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca066b7:	02 00 00 00 
    710d6ca066bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca066c2:	08 00 00 00 
    710d6ca066c6:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca066c9:	be 2c 02 01 00       	mov    esi,0x1022c
    710d6ca066ce:	4c 89 ef             	mov    rdi,r13
    710d6ca066d1:	e8 8a 9a ff e7       	call   0x710d54a00160
    710d6ca066d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca066dd:	00 
    710d6ca066de:	0f 84 4c e3 ff e7    	je     0x710d54a04a30
    710d6ca066e4:	e9 86 e3 ff e7       	jmp    0x710d54a04a6f
    710d6ca066e9:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d6ca066ee:	83 c0 f2             	add    eax,0xfffffff2
    710d6ca066f1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca066f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca066ff:	02 00 00 00 
    710d6ca06703:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca0670a:	08 00 00 00 
    710d6ca0670e:	be 2c 02 01 00       	mov    esi,0x1022c
    710d6ca06713:	ba 2c 02 01 00       	mov    edx,0x1022c
    710d6ca06718:	4c 89 ef             	mov    rdi,r13
    710d6ca0671b:	e8 40 9a ff e7       	call   0x710d54a00160
    710d6ca06720:	e9 3b e3 ff e7       	jmp    0x710d54a04a60
    710d6ca06725:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca0672c:	2e 02 01 00 
    710d6ca06730:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06737:	04 00 00 00 
    710d6ca0673b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca06742:	09 00 00 00 
    710d6ca06746:	ba 2e 02 01 00       	mov    edx,0x1022e
    710d6ca0674b:	4c 89 ef             	mov    rdi,r13
    710d6ca0674e:	4c 89 f6             	mov    rsi,r14
    710d6ca06751:	89 d9                	mov    ecx,ebx
    710d6ca06753:	45 31 c0             	xor    r8d,r8d
    710d6ca06756:	e8 25 99 ff e7       	call   0x710d54a00080
    710d6ca0675b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06762:	04 00 00 00 
    710d6ca06766:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca0676d:	09 00 00 00 
    710d6ca06771:	58                   	pop    rax
    710d6ca06772:	e9 b8 e4 ff e7       	jmp    0x710d54a04c2f
    710d6ca06777:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca0677e:	2e 02 01 00 
    710d6ca06782:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06789:	04 00 00 00 
    710d6ca0678d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca06794:	09 00 00 00 
    710d6ca06798:	4c 89 f7             	mov    rdi,r14
    710d6ca0679b:	89 de                	mov    esi,ebx
    710d6ca0679d:	e8 9e 98 ff e7       	call   0x710d54a00040
    710d6ca067a2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca067a9:	00 
    710d6ca067aa:	75 af                	jne    0x710d6ca0675b
    710d6ca067ac:	41 89 c7             	mov    r15d,eax
    710d6ca067af:	e9 0d e3 ff e7       	jmp    0x710d54a04ac1
    710d6ca067b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca067bb:	2e 02 01 00 
    710d6ca067bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca067c6:	04 00 00 00 
    710d6ca067ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca067d1:	09 00 00 00 
    710d6ca067d5:	4c 89 f7             	mov    rdi,r14
    710d6ca067d8:	e8 63 98 ff e7       	call   0x710d54a00040
    710d6ca067dd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca067e4:	00 
    710d6ca067e5:	0f 84 f7 e2 ff e7    	je     0x710d54a04ae2
    710d6ca067eb:	e9 6b ff ff ff       	jmp    0x710d6ca0675b
    710d6ca067f0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca067f7:	2e 02 01 00 
    710d6ca067fb:	b8 2e 02 01 00       	mov    eax,0x1022e
    710d6ca06800:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06807:	04 00 00 00 
    710d6ca0680b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca06812:	09 00 00 00 
    710d6ca06816:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca06819:	be 2e 02 01 00       	mov    esi,0x1022e
    710d6ca0681e:	4c 89 ef             	mov    rdi,r13
    710d6ca06821:	e8 3a 99 ff e7       	call   0x710d54a00160
    710d6ca06826:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0682d:	00 
    710d6ca0682e:	0f 84 e2 e2 ff e7    	je     0x710d54a04b16
    710d6ca06834:	e9 22 ff ff ff       	jmp    0x710d6ca0675b
    710d6ca06839:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10232
    710d6ca06840:	32 02 01 00 
    710d6ca06844:	b8 32 02 01 00       	mov    eax,0x10232
    710d6ca06849:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06850:	02 00 00 00 
    710d6ca06854:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0685b:	0a 00 00 00 
    710d6ca0685f:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06862:	be 32 02 01 00       	mov    esi,0x10232
    710d6ca06867:	4c 89 ef             	mov    rdi,r13
    710d6ca0686a:	e8 f1 98 ff e7       	call   0x710d54a00160
    710d6ca0686f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06876:	00 
    710d6ca06877:	0f 84 f7 e2 ff e7    	je     0x710d54a04b74
    710d6ca0687d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06884:	02 00 00 00 
    710d6ca06888:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0688f:	0a 00 00 00 
    710d6ca06893:	58                   	pop    rax
    710d6ca06894:	e9 96 e3 ff e7       	jmp    0x710d54a04c2f
    710d6ca06899:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca068a0:	34 02 01 00 
    710d6ca068a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca068ab:	02 00 00 00 
    710d6ca068af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca068b6:	0b 00 00 00 
    710d6ca068ba:	ba 34 02 01 00       	mov    edx,0x10234
    710d6ca068bf:	4c 89 ef             	mov    rdi,r13
    710d6ca068c2:	4c 89 f6             	mov    rsi,r14
    710d6ca068c5:	89 d9                	mov    ecx,ebx
    710d6ca068c7:	45 31 c0             	xor    r8d,r8d
    710d6ca068ca:	e8 b1 97 ff e7       	call   0x710d54a00080
    710d6ca068cf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca068d6:	02 00 00 00 
    710d6ca068da:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca068e1:	0b 00 00 00 
    710d6ca068e5:	58                   	pop    rax
    710d6ca068e6:	e9 44 e3 ff e7       	jmp    0x710d54a04c2f
    710d6ca068eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca068f2:	34 02 01 00 
    710d6ca068f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca068fd:	02 00 00 00 
    710d6ca06901:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca06908:	0b 00 00 00 
    710d6ca0690c:	4c 89 f7             	mov    rdi,r14
    710d6ca0690f:	89 de                	mov    esi,ebx
    710d6ca06911:	e8 2a 97 ff e7       	call   0x710d54a00040
    710d6ca06916:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0691d:	00 
    710d6ca0691e:	0f 84 85 e2 ff e7    	je     0x710d54a04ba9
    710d6ca06924:	eb a9                	jmp    0x710d6ca068cf
    710d6ca06926:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca0692d:	34 02 01 00 
    710d6ca06931:	b8 34 02 01 00       	mov    eax,0x10234
    710d6ca06936:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0693d:	02 00 00 00 
    710d6ca06941:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca06948:	0b 00 00 00 
    710d6ca0694c:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0694f:	be 34 02 01 00       	mov    esi,0x10234
    710d6ca06954:	4c 89 ef             	mov    rdi,r13
    710d6ca06957:	e8 04 98 ff e7       	call   0x710d54a00160
    710d6ca0695c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06963:	00 
    710d6ca06964:	0f 84 6c e2 ff e7    	je     0x710d54a04bd6
    710d6ca0696a:	e9 60 ff ff ff       	jmp    0x710d6ca068cf
    710d6ca0696f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10236
    710d6ca06976:	36 02 01 00 
    710d6ca0697a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06981:	02 00 00 00 
    710d6ca06985:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca0698c:	0c 00 00 00 
    710d6ca06990:	4c 89 ef             	mov    rdi,r13
    710d6ca06993:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca06998:	4c 89 f2             	mov    rdx,r14
    710d6ca0699b:	e8 f0 96 ff e7       	call   0x710d54a00090
    710d6ca069a0:	e9 73 e2 ff e7       	jmp    0x710d54a04c18
    710d6ca069a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca069ac:	02 00 00 00 
    710d6ca069b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca069b7:	0c 00 00 00 
    710d6ca069bb:	be 36 02 01 00       	mov    esi,0x10236
    710d6ca069c0:	ba 36 02 01 00       	mov    edx,0x10236
    710d6ca069c5:	4c 89 ef             	mov    rdi,r13
    710d6ca069c8:	e8 93 97 ff e7       	call   0x710d54a00160
    710d6ca069cd:	e9 46 e2 ff e7       	jmp    0x710d54a04c18
    710d6ca069d2:	c2 08 00             	ret    0x8
