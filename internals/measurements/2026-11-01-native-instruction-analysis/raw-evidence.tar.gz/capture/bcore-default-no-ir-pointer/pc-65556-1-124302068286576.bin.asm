
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65556-1-124302068286576.bin:     file format binary


Disassembly of section .data:

0000710d54a00470 <.data>:
    710d54a00470:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a00477:	8b 88 04 00 10 00    	mov    ecx,DWORD PTR [rax+0x100004]
    710d54a0047d:	ff c1                	inc    ecx
    710d54a0047f:	89 88 04 00 10 00    	mov    DWORD PTR [rax+0x100004],ecx
    710d54a00485:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0048b:	0f 84 3f fc ff 17    	je     0x710d6ca000d0
    710d54a00491:	50                   	push   rax
    710d54a00492:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a00496:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a00499:	f6 c3 03             	test   bl,0x3
    710d54a0049c:	0f 85 5a fc ff 17    	jne    0x710d6ca000fc
    710d54a004a2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a004a9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a004b0:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    710d54a004b4:	89 c8                	mov    eax,ecx
    710d54a004b6:	c1 e8 0c             	shr    eax,0xc
    710d54a004b9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a004be:	48 85 c0             	test   rax,rax
    710d54a004c1:	0f 84 88 fc ff 17    	je     0x710d6ca0014f
    710d54a004c7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a004cd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a004d0:	8d 73 f8             	lea    esi,[rbx-0x8]
    710d54a004d3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    710d54a004d7:	89 f0                	mov    eax,esi
    710d54a004d9:	c1 e8 0c             	shr    eax,0xc
    710d54a004dc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a004e1:	48 85 c0             	test   rax,rax
    710d54a004e4:	0f 84 a0 fc ff 17    	je     0x710d6ca0018a
    710d54a004ea:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a004f0:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a004f3:	8d 73 f4             	lea    esi,[rbx-0xc]
    710d54a004f6:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    710d54a004fa:	89 f0                	mov    eax,esi
    710d54a004fc:	c1 e8 0c             	shr    eax,0xc
    710d54a004ff:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00504:	48 85 c0             	test   rax,rax
    710d54a00507:	0f 84 b9 fc ff 17    	je     0x710d6ca001c6
    710d54a0050d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00513:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a00516:	8d 73 f0             	lea    esi,[rbx-0x10]
    710d54a00519:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    710d54a0051d:	89 f0                	mov    eax,esi
    710d54a0051f:	c1 e8 0c             	shr    eax,0xc
    710d54a00522:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00527:	48 85 c0             	test   rax,rax
    710d54a0052a:	0f 84 d2 fc ff 17    	je     0x710d6ca00202
    710d54a00530:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00536:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a00539:	8d 73 ec             	lea    esi,[rbx-0x14]
    710d54a0053c:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    710d54a00540:	89 f0                	mov    eax,esi
    710d54a00542:	c1 e8 0c             	shr    eax,0xc
    710d54a00545:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a0054a:	48 85 c0             	test   rax,rax
    710d54a0054d:	0f 84 eb fc ff 17    	je     0x710d6ca0023e
    710d54a00553:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00559:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a0055c:	8d 73 e8             	lea    esi,[rbx-0x18]
    710d54a0055f:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    710d54a00563:	89 f0                	mov    eax,esi
    710d54a00565:	c1 e8 0c             	shr    eax,0xc
    710d54a00568:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a0056d:	48 85 c0             	test   rax,rax
    710d54a00570:	0f 84 04 fd ff 17    	je     0x710d6ca0027a
    710d54a00576:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a0057c:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a0057f:	83 c3 e4             	add    ebx,0xffffffe4
    710d54a00582:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    710d54a00586:	89 d8                	mov    eax,ebx
    710d54a00588:	c1 e8 0c             	shr    eax,0xc
    710d54a0058b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00590:	48 85 c0             	test   rax,rax
    710d54a00593:	0f 84 1d fd ff 17    	je     0x710d6ca002b6
    710d54a00599:	89 d9                	mov    ecx,ebx
    710d54a0059b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a005a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a005a4:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a005a8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10014
    710d54a005af:	14 00 01 00 
    710d54a005b3:	0f 84 3b fd ff 17    	je     0x710d6ca002f4
    710d54a005b9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10014
    710d54a005c0:	14 00 01 00 
    710d54a005c4:	0f 84 2a fd ff 17    	je     0x710d6ca002f4
    710d54a005ca:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a005ce:	0f 85 62 fd ff 17    	jne    0x710d6ca00336
    710d54a005d4:	58                   	pop    rax
    710d54a005d5:	e9 0f 00 00 00       	jmp    0x710d54a005e9
    710d54a005da:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a005e1:	00 
    710d54a005e2:	74 f0                	je     0x710d54a005d4
    710d54a005e4:	e9 4a fb ff 17       	jmp    0x710d6ca00133
    710d54a005e9:	50                   	push   rax
    710d54a005ea:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a005ef:	b9 00 00 00 00       	mov    ecx,0x0
    710d54a005f4:	09 c1                	or     ecx,eax
    710d54a005f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a005fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10016
    710d54a00601:	16 00 01 00 
    710d54a00605:	0f 84 5d fd ff 17    	je     0x710d6ca00368
    710d54a0060b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10016
    710d54a00612:	16 00 01 00 
    710d54a00616:	0f 84 4c fd ff 17    	je     0x710d6ca00368
    710d54a0061c:	58                   	pop    rax
    710d54a0061d:	50                   	push   rax
    710d54a0061e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a00622:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a00625:	f6 c3 03             	test   bl,0x3
    710d54a00628:	0f 85 9a fd ff 17    	jne    0x710d6ca003c8
    710d54a0062e:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a00635:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a0063c:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    710d54a00640:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    710d54a00647:	89 c8                	mov    eax,ecx
    710d54a00649:	c1 e8 0c             	shr    eax,0xc
    710d54a0064c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00651:	48 85 c0             	test   rax,rax
    710d54a00654:	0f 84 c1 fd ff 17    	je     0x710d6ca0041b
    710d54a0065a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00660:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a00663:	83 c3 f8             	add    ebx,0xfffffff8
    710d54a00666:	89 d8                	mov    eax,ebx
    710d54a00668:	c1 e8 0c             	shr    eax,0xc
    710d54a0066b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00670:	48 85 c0             	test   rax,rax
    710d54a00673:	0f 84 dd fd ff 17    	je     0x710d6ca00456
    710d54a00679:	89 d9                	mov    ecx,ebx
    710d54a0067b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00681:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    710d54a00685:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    710d54a00689:	b8 14 00 00 00       	mov    eax,0x14
    710d54a0068e:	29 c3                	sub    ebx,eax
    710d54a00690:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a00694:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001a
    710d54a0069b:	1a 00 01 00 
    710d54a0069f:	0f 84 f2 fd ff 17    	je     0x710d6ca00497
    710d54a006a5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001a
    710d54a006ac:	1a 00 01 00 
    710d54a006b0:	0f 84 e1 fd ff 17    	je     0x710d6ca00497
    710d54a006b6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a006ba:	0f 85 19 fe ff 17    	jne    0x710d6ca004d9
    710d54a006c0:	58                   	pop    rax
    710d54a006c1:	e9 0f 00 00 00       	jmp    0x710d54a006d5
    710d54a006c6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a006cd:	00 
    710d54a006ce:	74 f0                	je     0x710d54a006c0
    710d54a006d0:	e9 2a fd ff 17       	jmp    0x710d6ca003ff
    710d54a006d5:	50                   	push   rax
    710d54a006d6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a006db:	c1 e0 10             	shl    eax,0x10
    710d54a006de:	b9 00 f0 00 00       	mov    ecx,0xf000
    710d54a006e3:	09 c1                	or     ecx,eax
    710d54a006e5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a006e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001e
    710d54a006f0:	1e 00 01 00 
    710d54a006f4:	0f 84 11 fe ff 17    	je     0x710d6ca0050b
    710d54a006fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001e
    710d54a00701:	1e 00 01 00 
    710d54a00705:	0f 84 00 fe ff 17    	je     0x710d6ca0050b
    710d54a0070b:	58                   	pop    rax
    710d54a0070c:	50                   	push   rax
    710d54a0070d:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    710d54a00712:	b9 00 00 42 43       	mov    ecx,0x43420000
    710d54a00717:	09 c1                	or     ecx,eax
    710d54a00719:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    710d54a0071d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10022
    710d54a00724:	22 00 01 00 
    710d54a00728:	0f 84 3d fe ff 17    	je     0x710d6ca0056b
    710d54a0072e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10022
    710d54a00735:	22 00 01 00 
    710d54a00739:	0f 84 2c fe ff 17    	je     0x710d6ca0056b
    710d54a0073f:	58                   	pop    rax
    710d54a00740:	50                   	push   rax
    710d54a00741:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a00745:	f6 c1 03             	test   cl,0x3
    710d54a00748:	0f 85 7d fe ff 17    	jne    0x710d6ca005cb
    710d54a0074e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00755:	48 89 ca             	mov    rdx,rcx
    710d54a00758:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a0075c:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a00760:	48 85 c0             	test   rax,rax
    710d54a00763:	0f 84 b2 fe ff 17    	je     0x710d6ca0061b
    710d54a00769:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0076f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a00772:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a00776:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10026
    710d54a0077d:	26 00 01 00 
    710d54a00781:	0f 84 cf fe ff 17    	je     0x710d6ca00656
    710d54a00787:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10026
    710d54a0078e:	26 00 01 00 
    710d54a00792:	0f 84 be fe ff 17    	je     0x710d6ca00656
    710d54a00798:	58                   	pop    rax
    710d54a00799:	50                   	push   rax
    710d54a0079a:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    710d54a0079f:	c1 e0 10             	shl    eax,0x10
    710d54a007a2:	b9 31 4e 00 00       	mov    ecx,0x4e31
    710d54a007a7:	09 c1                	or     ecx,eax
    710d54a007a9:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    710d54a007ad:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10028
    710d54a007b4:	28 00 01 00 
    710d54a007b8:	0f 84 e1 fe ff 17    	je     0x710d6ca0069f
    710d54a007be:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10028
    710d54a007c5:	28 00 01 00 
    710d54a007c9:	0f 84 d0 fe ff 17    	je     0x710d6ca0069f
    710d54a007cf:	58                   	pop    rax
    710d54a007d0:	50                   	push   rax
    710d54a007d1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a007d5:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    710d54a007d9:	31 d2                	xor    edx,edx
    710d54a007db:	31 f6                	xor    esi,esi
    710d54a007dd:	89 c7                	mov    edi,eax
    710d54a007df:	29 cf                	sub    edi,ecx
    710d54a007e1:	0f 94 c2             	sete   dl
    710d54a007e4:	40 0f 93 c6          	setae  sil
    710d54a007e8:	c1 ef 1f             	shr    edi,0x1f
    710d54a007eb:	c1 e8 1f             	shr    eax,0x1f
    710d54a007ee:	c1 e9 1f             	shr    ecx,0x1f
    710d54a007f1:	89 fb                	mov    ebx,edi
    710d54a007f3:	31 c3                	xor    ebx,eax
    710d54a007f5:	31 c1                	xor    ecx,eax
    710d54a007f7:	21 d9                	and    ecx,ebx
    710d54a007f9:	31 f9                	xor    ecx,edi
    710d54a007fb:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a00802:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a00809:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    710d54a00810:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    710d54a00817:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    710d54a0081e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002c
    710d54a00825:	2c 00 01 00 
    710d54a00829:	0f 84 d0 fe ff 17    	je     0x710d6ca006ff
    710d54a0082f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002c
    710d54a00836:	2c 00 01 00 
    710d54a0083a:	0f 84 bf fe ff 17    	je     0x710d6ca006ff
    710d54a00840:	58                   	pop    rax
    710d54a00841:	50                   	push   rax
    710d54a00842:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a00849:	00 
    710d54a0084a:	74 55                	je     0x710d54a008a1
    710d54a0084c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a00853:	01 
    710d54a00854:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    710d54a0085b:	2e 00 01 00 
    710d54a0085f:	0f 84 fa fe ff 17    	je     0x710d6ca0075f
    710d54a00865:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    710d54a0086c:	2e 00 01 00 
    710d54a00870:	0f 84 e9 fe ff 17    	je     0x710d6ca0075f
    710d54a00876:	b8 2e 00 01 00       	mov    eax,0x1002e
    710d54a0087b:	83 c0 12             	add    eax,0x12
    710d54a0087e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a00885:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a0088c:	02 00 00 00 
    710d54a00890:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d54a00897:	09 00 00 00 
    710d54a0089b:	58                   	pop    rax
    710d54a0089c:	e9 3c 03 00 00       	jmp    0x710d54a00bdd
    710d54a008a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    710d54a008a8:	2e 00 01 00 
    710d54a008ac:	0f 84 e9 fe ff 17    	je     0x710d6ca0079b
    710d54a008b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    710d54a008b9:	2e 00 01 00 
    710d54a008bd:	0f 84 d8 fe ff 17    	je     0x710d6ca0079b
    710d54a008c3:	58                   	pop    rax
    710d54a008c4:	50                   	push   rax
    710d54a008c5:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    710d54a008cc:	00 
    710d54a008cd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10030
    710d54a008d4:	30 00 01 00 
    710d54a008d8:	0f 84 06 ff ff 17    	je     0x710d6ca007e4
    710d54a008de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10030
    710d54a008e5:	30 00 01 00 
    710d54a008e9:	0f 84 f5 fe ff 17    	je     0x710d6ca007e4
    710d54a008ef:	58                   	pop    rax
    710d54a008f0:	50                   	push   rax
    710d54a008f1:	41 83 45 28 10       	add    DWORD PTR [r13+0x28],0x10
    710d54a008f6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10032
    710d54a008fd:	32 00 01 00 
    710d54a00901:	0f 84 3d ff ff 17    	je     0x710d6ca00844
    710d54a00907:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10032
    710d54a0090e:	32 00 01 00 
    710d54a00912:	0f 84 2c ff ff 17    	je     0x710d6ca00844
    710d54a00918:	58                   	pop    rax
    710d54a00919:	50                   	push   rax
    710d54a0091a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a0091e:	f6 c1 03             	test   cl,0x3
    710d54a00921:	0f 85 7d ff ff 17    	jne    0x710d6ca008a4
    710d54a00927:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a0092e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a00932:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00939:	48 89 ce             	mov    rsi,rcx
    710d54a0093c:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a00940:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a00944:	48 85 c0             	test   rax,rax
    710d54a00947:	0f 84 aa ff ff 17    	je     0x710d6ca008f7
    710d54a0094d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00953:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a00956:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10034
    710d54a0095d:	34 00 01 00 
    710d54a00961:	0f 84 cb ff ff 17    	je     0x710d6ca00932
    710d54a00967:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10034
    710d54a0096e:	34 00 01 00 
    710d54a00972:	0f 84 ba ff ff 17    	je     0x710d6ca00932
    710d54a00978:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a0097b:	0f 85 f2 ff ff 17    	jne    0x710d6ca00973
    710d54a00981:	58                   	pop    rax
    710d54a00982:	e9 0f 00 00 00       	jmp    0x710d54a00996
    710d54a00987:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a0098e:	00 
    710d54a0098f:	74 f0                	je     0x710d54a00981
    710d54a00991:	e9 45 ff ff 17       	jmp    0x710d6ca008db
    710d54a00996:	50                   	push   rax
    710d54a00997:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    710d54a0099e:	00 
    710d54a0099f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10036
    710d54a009a6:	36 00 01 00 
    710d54a009aa:	0f 84 f5 ff ff 17    	je     0x710d6ca009a5
    710d54a009b0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10036
    710d54a009b7:	36 00 01 00 
    710d54a009bb:	0f 84 e4 ff ff 17    	je     0x710d6ca009a5
    710d54a009c1:	58                   	pop    rax
    710d54a009c2:	50                   	push   rax
    710d54a009c3:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a009c7:	f6 c3 03             	test   bl,0x3
    710d54a009ca:	0f 85 35 00 00 18    	jne    0x710d6ca00a05
    710d54a009d0:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a009d7:	48 89 d8             	mov    rax,rbx
    710d54a009da:	48 c1 e8 0c          	shr    rax,0xc
    710d54a009de:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a009e3:	48 85 c0             	test   rax,rax
    710d54a009e6:	0f 84 6b 00 00 18    	je     0x710d6ca00a57
    710d54a009ec:	89 d9                	mov    ecx,ebx
    710d54a009ee:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a009f4:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a009f8:	89 de                	mov    esi,ebx
    710d54a009fa:	83 c6 04             	add    esi,0x4
    710d54a009fd:	89 f0                	mov    eax,esi
    710d54a009ff:	c1 e8 0c             	shr    eax,0xc
    710d54a00a02:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00a07:	48 85 c0             	test   rax,rax
    710d54a00a0a:	0f 84 84 00 00 18    	je     0x710d6ca00a94
    710d54a00a10:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00a16:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00a19:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a00a1c:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a00a20:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a00a27:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a00a2b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10038
    710d54a00a32:	38 00 01 00 
    710d54a00a36:	0f 84 94 00 00 18    	je     0x710d6ca00ad0
    710d54a00a3c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10038
    710d54a00a43:	38 00 01 00 
    710d54a00a47:	0f 84 83 00 00 18    	je     0x710d6ca00ad0
    710d54a00a4d:	58                   	pop    rax
    710d54a00a4e:	50                   	push   rax
    710d54a00a4f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a00a53:	f6 c3 03             	test   bl,0x3
    710d54a00a56:	0f 85 bd 00 00 18    	jne    0x710d6ca00b19
    710d54a00a5c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a00a63:	48 89 d8             	mov    rax,rbx
    710d54a00a66:	48 c1 e8 0c          	shr    rax,0xc
    710d54a00a6a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00a6f:	48 85 c0             	test   rax,rax
    710d54a00a72:	0f 84 f3 00 00 18    	je     0x710d6ca00b6b
    710d54a00a78:	89 d9                	mov    ecx,ebx
    710d54a00a7a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00a80:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a00a83:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    710d54a00a87:	8d 73 04             	lea    esi,[rbx+0x4]
    710d54a00a8a:	89 f0                	mov    eax,esi
    710d54a00a8c:	c1 e8 0c             	shr    eax,0xc
    710d54a00a8f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00a94:	48 85 c0             	test   rax,rax
    710d54a00a97:	0f 84 09 01 00 18    	je     0x710d6ca00ba6
    710d54a00a9d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00aa3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00aa6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a00aaa:	8d 73 08             	lea    esi,[rbx+0x8]
    710d54a00aad:	89 f0                	mov    eax,esi
    710d54a00aaf:	c1 e8 0c             	shr    eax,0xc
    710d54a00ab2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00ab7:	48 85 c0             	test   rax,rax
    710d54a00aba:	0f 84 22 01 00 18    	je     0x710d6ca00be2
    710d54a00ac0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00ac6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00ac9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    710d54a00acd:	8d 73 0c             	lea    esi,[rbx+0xc]
    710d54a00ad0:	89 f0                	mov    eax,esi
    710d54a00ad2:	c1 e8 0c             	shr    eax,0xc
    710d54a00ad5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00ada:	48 85 c0             	test   rax,rax
    710d54a00add:	0f 84 3b 01 00 18    	je     0x710d6ca00c1e
    710d54a00ae3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00ae9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00aec:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a00af0:	8d 73 10             	lea    esi,[rbx+0x10]
    710d54a00af3:	89 f0                	mov    eax,esi
    710d54a00af5:	c1 e8 0c             	shr    eax,0xc
    710d54a00af8:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00afd:	48 85 c0             	test   rax,rax
    710d54a00b00:	0f 84 54 01 00 18    	je     0x710d6ca00c5a
    710d54a00b06:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00b0c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00b0f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    710d54a00b13:	8d 73 14             	lea    esi,[rbx+0x14]
    710d54a00b16:	89 f0                	mov    eax,esi
    710d54a00b18:	c1 e8 0c             	shr    eax,0xc
    710d54a00b1b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00b20:	48 85 c0             	test   rax,rax
    710d54a00b23:	0f 84 6d 01 00 18    	je     0x710d6ca00c96
    710d54a00b29:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00b2f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00b32:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    710d54a00b36:	89 de                	mov    esi,ebx
    710d54a00b38:	83 c6 18             	add    esi,0x18
    710d54a00b3b:	89 f0                	mov    eax,esi
    710d54a00b3d:	c1 e8 0c             	shr    eax,0xc
    710d54a00b40:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a00b45:	48 85 c0             	test   rax,rax
    710d54a00b48:	0f 84 84 01 00 18    	je     0x710d6ca00cd2
    710d54a00b4e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a00b54:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a00b57:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    710d54a00b5b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    710d54a00b5e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    710d54a00b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003c
    710d54a00b69:	3c 00 01 00 
    710d54a00b6d:	0f 84 9b 01 00 18    	je     0x710d6ca00d0e
    710d54a00b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003c
    710d54a00b7a:	3c 00 01 00 
    710d54a00b7e:	0f 84 8a 01 00 18    	je     0x710d6ca00d0e
    710d54a00b84:	58                   	pop    rax
    710d54a00b85:	50                   	push   rax
    710d54a00b86:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a00b8d:	a8 01                	test   al,0x1
    710d54a00b8f:	0f 85 c2 01 00 18    	jne    0x710d6ca00d57
    710d54a00b95:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a00b9c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a00ba3:	01 
    710d54a00ba4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003e
    710d54a00bab:	3e 00 01 00 
    710d54a00baf:	0f 84 d8 01 00 18    	je     0x710d6ca00d8d
    710d54a00bb5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003e
    710d54a00bbc:	3e 00 01 00 
    710d54a00bc0:	0f 84 c7 01 00 18    	je     0x710d6ca00d8d
    710d54a00bc6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a00bcd:	02 00 00 00 
    710d54a00bd1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d54a00bd8:	10 00 00 00 
    710d54a00bdc:	58                   	pop    rax
    710d54a00bdd:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a00be4:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a00beb:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a00bf2:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a00bf9:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a00c00:	39 f1                	cmp    ecx,esi
    710d54a00c02:	0f 83 b2 01 00 18    	jae    0x710d6ca00dba
    710d54a00c08:	81 fa 14 00 01 00    	cmp    edx,0x10014
    710d54a00c0e:	75 14                	jne    0x710d54a00c24
    710d54a00c10:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a00c17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a00c1e:	00 
    710d54a00c1f:	e9 4c f8 ff ff       	jmp    0x710d54a00470
    710d54a00c24:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a00c2b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a00c31:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a00c34:	0f 85 80 01 00 18    	jne    0x710d6ca00dba
    710d54a00c3a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a00c41:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a00c48:	00 
    710d54a00c49:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a00c4e:	ff e0                	jmp    rax
