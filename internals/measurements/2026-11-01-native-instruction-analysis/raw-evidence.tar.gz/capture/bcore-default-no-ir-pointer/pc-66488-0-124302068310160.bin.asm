
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66488-0-124302068310160.bin:     file format binary


Disassembly of section .data:

0000710d54a06090 <.data>:
    710d54a06090:	48 83 ec 78          	sub    rsp,0x78
    710d54a06094:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    710d54a06099:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    710d54a060a0:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    710d54a060a7:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    710d54a060ab:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a060af:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a060b4:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    710d54a060b8:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a060bd:	45 8b bd 9c 00 00 00 	mov    r15d,DWORD PTR [r13+0x9c]
    710d54a060c4:	45 8b 8d a0 00 00 00 	mov    r9d,DWORD PTR [r13+0xa0]
    710d54a060cb:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    710d54a060d2:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    710d54a060d9:	41 8b 8d e4 00 00 00 	mov    ecx,DWORD PTR [r13+0xe4]
    710d54a060e0:	89 4c 24 04          	mov    DWORD PTR [rsp+0x4],ecx
    710d54a060e4:	45 8b b5 e8 00 00 00 	mov    r14d,DWORD PTR [r13+0xe8]
    710d54a060eb:	45 8b a5 ec 00 00 00 	mov    r12d,DWORD PTR [r13+0xec]
    710d54a060f2:	45 8b 9d f0 00 00 00 	mov    r11d,DWORD PTR [r13+0xf0]
    710d54a060f9:	45 8b 95 f8 00 00 00 	mov    r10d,DWORD PTR [r13+0xf8]
    710d54a06100:	41 8b 8d fc 00 00 00 	mov    ecx,DWORD PTR [r13+0xfc]
    710d54a06107:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    710d54a0610a:	45 8b 85 00 01 00 00 	mov    r8d,DWORD PTR [r13+0x100]
    710d54a06111:	41 8b ad 24 01 00 00 	mov    ebp,DWORD PTR [r13+0x124]
    710d54a06118:	41 8b bd 34 01 00 00 	mov    edi,DWORD PTR [r13+0x134]
    710d54a0611f:	4c 89 6c 24 08       	mov    QWORD PTR [rsp+0x8],r13
    710d54a06124:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0612b:	41 8d 91 1d fc fe ff 	lea    edx,[r9-0x103e3]
    710d54a06132:	83 fa d4             	cmp    edx,0xffffffd4
    710d54a06135:	0f 87 b2 15 00 18    	ja     0x710d6ca076ed
    710d54a0613b:	81 fe ba 03 01 00    	cmp    esi,0x103ba
    710d54a06141:	0f 85 a6 15 00 18    	jne    0x710d6ca076ed
    710d54a06147:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    710d54a0614c:	81 ba 94 00 00 00 b8 	cmp    DWORD PTR [rdx+0x94],0x103b8
    710d54a06153:	03 01 00 
    710d54a06156:	0f 85 91 15 00 18    	jne    0x710d6ca076ed
    710d54a0615c:	48 89 5c 24 68       	mov    QWORD PTR [rsp+0x68],rbx
    710d54a06161:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    710d54a06166:	48 8b b2 40 01 00 00 	mov    rsi,QWORD PTR [rdx+0x140]
    710d54a0616d:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    710d54a06172:	48 8b 92 38 01 00 00 	mov    rdx,QWORD PTR [rdx+0x138]
    710d54a06179:	48 89 54 24 40       	mov    QWORD PTR [rsp+0x40],rdx
    710d54a0617e:	66 90                	xchg   ax,ax
    710d54a06180:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    710d54a06185:	44 89 64 24 20       	mov    DWORD PTR [rsp+0x20],r12d
    710d54a0618a:	8d 71 02             	lea    esi,[rcx+0x2]
    710d54a0618d:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    710d54a06191:	39 f2                	cmp    edx,esi
    710d54a06193:	0f 47 f2             	cmova  esi,edx
    710d54a06196:	89 ca                	mov    edx,ecx
    710d54a06198:	f7 d2                	not    edx
    710d54a0619a:	01 f2                	add    edx,esi
    710d54a0619c:	d1 ea                	shr    edx,1
    710d54a0619e:	41 83 ff 01          	cmp    r15d,0x1
    710d54a061a2:	44 89 ff             	mov    edi,r15d
    710d54a061a5:	83 d7 ff             	adc    edi,0xffffffff
    710d54a061a8:	39 fa                	cmp    edx,edi
    710d54a061aa:	0f 42 fa             	cmovb  edi,edx
    710d54a061ad:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    710d54a061b2:	f6 c3 03             	test   bl,0x3
    710d54a061b5:	44 89 7c 24 3c       	mov    DWORD PTR [rsp+0x3c],r15d
    710d54a061ba:	0f 85 20 01 00 00    	jne    0x710d54a062e0
    710d54a061c0:	89 de                	mov    esi,ebx
    710d54a061c2:	48 8d 2c be          	lea    rbp,[rsi+rdi*4]
    710d54a061c6:	bb fc ff ff ff       	mov    ebx,0xfffffffc
    710d54a061cb:	48 39 dd             	cmp    rbp,rbx
    710d54a061ce:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    710d54a061d3:	0f 87 07 01 00 00    	ja     0x710d54a062e0
    710d54a061d9:	48 8d 3c be          	lea    rdi,[rsi+rdi*4]
    710d54a061dd:	48 83 c7 03          	add    rdi,0x3
    710d54a061e1:	48 31 f7             	xor    rdi,rsi
    710d54a061e4:	48 81 ff ff 0f 00 00 	cmp    rdi,0xfff
    710d54a061eb:	0f 87 ef 00 00 00    	ja     0x710d54a062e0
    710d54a061f1:	48 89 f7             	mov    rdi,rsi
    710d54a061f4:	48 c1 ef 0c          	shr    rdi,0xc
    710d54a061f8:	48 8b 6c 24 40       	mov    rbp,QWORD PTR [rsp+0x40]
    710d54a061fd:	48 8b 7c fd 00       	mov    rdi,QWORD PTR [rbp+rdi*8+0x0]
    710d54a06202:	48 85 ff             	test   rdi,rdi
    710d54a06205:	0f 84 d5 00 00 00    	je     0x710d54a062e0
    710d54a0620b:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a06211:	41 83 ff 01          	cmp    r15d,0x1
    710d54a06215:	44 89 f8             	mov    eax,r15d
    710d54a06218:	83 d0 ff             	adc    eax,0xffffffff
    710d54a0621b:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    710d54a06220:	89 d0                	mov    eax,edx
    710d54a06222:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    710d54a06227:	48 01 f7             	add    rdi,rsi
    710d54a0622a:	83 c3 04             	add    ebx,0x4
    710d54a0622d:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    710d54a06232:	89 d8                	mov    eax,ebx
    710d54a06234:	31 d2                	xor    edx,edx
    710d54a06236:	44 89 fb             	mov    ebx,r15d
    710d54a06239:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    710d54a0623e:	66 90                	xchg   ax,ax
    710d54a06240:	89 ce                	mov    esi,ecx
    710d54a06242:	49 89 d7             	mov    r15,rdx
    710d54a06245:	41 89 c5             	mov    r13d,eax
    710d54a06248:	49 8d 2c 14          	lea    rbp,[r12+rdx*1]
    710d54a0624c:	89 2c 97             	mov    DWORD PTR [rdi+rdx*4],ebp
    710d54a0624f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d54a06254:	80 38 00             	cmp    BYTE PTR [rax],0x0
    710d54a06257:	0f 85 29 04 00 00    	jne    0x710d54a06686
    710d54a0625d:	43 8d 04 3c          	lea    eax,[r12+r15*1]
    710d54a06261:	47 8d 34 3c          	lea    r14d,[r12+r15*1]
    710d54a06265:	41 ff c6             	inc    r14d
    710d54a06268:	89 e9                	mov    ecx,ebp
    710d54a0626a:	c1 e9 1f             	shr    ecx,0x1f
    710d54a0626d:	41 c1 ee 1f          	shr    r14d,0x1f
    710d54a06271:	c4 c2 70 f2 ce       	andn   ecx,ecx,r14d
    710d54a06276:	45 31 db             	xor    r11d,r11d
    710d54a06279:	83 fd ff             	cmp    ebp,0xffffffff
    710d54a0627c:	41 0f 94 c3          	sete   r11b
    710d54a06280:	45 31 c9             	xor    r9d,r9d
    710d54a06283:	83 f8 ff             	cmp    eax,0xffffffff
    710d54a06286:	41 0f 94 c1          	sete   r9b
    710d54a0628a:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    710d54a0628d:	41 09 c8             	or     r8d,ecx
    710d54a06290:	4c 39 7c 24 58       	cmp    QWORD PTR [rsp+0x58],r15
    710d54a06295:	0f 84 15 01 00 00    	je     0x710d54a063b0
    710d54a0629b:	4c 39 7c 24 50       	cmp    QWORD PTR [rsp+0x50],r15
    710d54a062a0:	0f 84 e9 02 00 00    	je     0x710d54a0658f
    710d54a062a6:	8d 4e 02             	lea    ecx,[rsi+0x2]
    710d54a062a9:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a062ae:	48 89 fd             	mov    rbp,rdi
    710d54a062b1:	48 89 f7             	mov    rdi,rsi
    710d54a062b4:	8b b0 58 01 00 00    	mov    esi,DWORD PTR [rax+0x158]
    710d54a062ba:	49 8d 57 01          	lea    rdx,[r15+0x1]
    710d54a062be:	41 8d 45 04          	lea    eax,[r13+0x4]
    710d54a062c2:	ff cb                	dec    ebx
    710d54a062c4:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    710d54a062c8:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    710d54a062cd:	85 f6                	test   esi,esi
    710d54a062cf:	48 89 fe             	mov    rsi,rdi
    710d54a062d2:	48 89 ef             	mov    rdi,rbp
    710d54a062d5:	0f 85 65 ff ff ff    	jne    0x710d54a06240
    710d54a062db:	e9 af 02 00 00       	jmp    0x710d54a0658f
    710d54a062e0:	31 d2                	xor    edx,edx
    710d54a062e2:	41 89 dd             	mov    r13d,ebx
    710d54a062e5:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    710d54a062ea:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a062ef:	90                   	nop
    710d54a062f0:	44 89 eb             	mov    ebx,r13d
    710d54a062f3:	89 ce                	mov    esi,ecx
    710d54a062f5:	41 89 d4             	mov    r12d,edx
    710d54a062f8:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    710d54a062fd:	42 8d 2c 21          	lea    ebp,[rcx+r12*1]
    710d54a06301:	f6 44 24 18 03       	test   BYTE PTR [rsp+0x18],0x3
    710d54a06306:	0f 85 33 04 00 00    	jne    0x710d54a0673f
    710d54a0630c:	89 d9                	mov    ecx,ebx
    710d54a0630e:	c1 e9 0c             	shr    ecx,0xc
    710d54a06311:	48 8b 0c cf          	mov    rcx,QWORD PTR [rdi+rcx*8]
    710d54a06315:	48 85 c9             	test   rcx,rcx
    710d54a06318:	44 89 54 24 58       	mov    DWORD PTR [rsp+0x58],r10d
    710d54a0631d:	0f 84 39 05 00 00    	je     0x710d54a0685c
    710d54a06323:	89 d8                	mov    eax,ebx
    710d54a06325:	25 ff 0f 00 00       	and    eax,0xfff
    710d54a0632a:	89 2c 01             	mov    DWORD PTR [rcx+rax*1],ebp
    710d54a0632d:	44 8d 6b 04          	lea    r13d,[rbx+0x4]
    710d54a06331:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d54a06336:	80 38 00             	cmp    BYTE PTR [rax],0x0
    710d54a06339:	0f 85 f0 05 00 00    	jne    0x710d54a0692f
    710d54a0633f:	45 31 c9             	xor    r9d,r9d
    710d54a06342:	41 89 ee             	mov    r14d,ebp
    710d54a06345:	41 ff c6             	inc    r14d
    710d54a06348:	41 0f 94 c1          	sete   r9b
    710d54a0634c:	89 e8                	mov    eax,ebp
    710d54a0634e:	c1 e8 1f             	shr    eax,0x1f
    710d54a06351:	41 c1 ee 1f          	shr    r14d,0x1f
    710d54a06355:	c4 c2 78 f2 c6       	andn   eax,eax,r14d
    710d54a0635a:	45 31 db             	xor    r11d,r11d
    710d54a0635d:	83 fd ff             	cmp    ebp,0xffffffff
    710d54a06360:	41 0f 94 c3          	sete   r11b
    710d54a06364:	89 04 24             	mov    DWORD PTR [rsp],eax
    710d54a06367:	41 09 c0             	or     r8d,eax
    710d54a0636a:	41 83 ff 02          	cmp    r15d,0x2
    710d54a0636e:	72 60                	jb     0x710d54a063d0
    710d54a06370:	48 89 f5             	mov    rbp,rsi
    710d54a06373:	8d 4e 02             	lea    ecx,[rsi+0x2]
    710d54a06376:	3b 4c 24 24          	cmp    ecx,DWORD PTR [rsp+0x24]
    710d54a0637a:	0f 83 48 02 00 00    	jae    0x710d54a065c8
    710d54a06380:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a06385:	8b b0 58 01 00 00    	mov    esi,DWORD PTR [rax+0x158]
    710d54a0638b:	41 8d 54 24 01       	lea    edx,[r12+0x1]
    710d54a06390:	41 ff cf             	dec    r15d
    710d54a06393:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d54a06398:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    710d54a0639c:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    710d54a063a1:	85 f6                	test   esi,esi
    710d54a063a3:	0f 85 47 ff ff ff    	jne    0x710d54a062f0
    710d54a063a9:	e9 1a 02 00 00       	jmp    0x710d54a065c8
    710d54a063ae:	66 90                	xchg   ax,ax
    710d54a063b0:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    710d54a063b5:	44 01 f8             	add    eax,r15d
    710d54a063b8:	ff c0                	inc    eax
    710d54a063ba:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a063bf:	eb 24                	jmp    0x710d54a063e5
    710d54a063c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    710d54a063c8:	0f 1f 84 00 00 00 00 
    710d54a063cf:	00 
    710d54a063d0:	83 c3 04             	add    ebx,0x4
    710d54a063d3:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    710d54a063d8:	44 01 e0             	add    eax,r12d
    710d54a063db:	ff c0                	inc    eax
    710d54a063dd:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a063e2:	41 89 dd             	mov    r13d,ebx
    710d54a063e5:	48 89 f5             	mov    rbp,rsi
    710d54a063e8:	4c 89 6c 24 18       	mov    QWORD PTR [rsp+0x18],r13
    710d54a063ed:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    710d54a063f2:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a063f7:	c7 40 20 fc 92 01 00 	mov    DWORD PTR [rax+0x20],0x192fc
    710d54a063fe:	c7 40 30 fc 92 01 00 	mov    DWORD PTR [rax+0x30],0x192fc
    710d54a06405:	48 b9 0d 66 19 00 5f 	movabs rcx,0x3c6ef35f0019660d
    710d54a0640c:	f3 6e 3c 
    710d54a0640f:	48 89 48 18          	mov    QWORD PTR [rax+0x18],rcx
    710d54a06413:	c7 40 0c ff 1f 00 00 	mov    DWORD PTR [rax+0xc],0x1fff
    710d54a0641a:	48 b9 00 20 00 00 fc 	movabs rcx,0x192fc00002000
    710d54a06421:	92 01 00 
    710d54a06424:	48 89 48 28          	mov    QWORD PTR [rax+0x28],rcx
    710d54a06428:	c7 40 50 fc 92 01 00 	mov    DWORD PTR [rax+0x50],0x192fc
    710d54a0642f:	c7 80 94 00 00 00 e6 	mov    DWORD PTR [rax+0x94],0x103e6
    710d54a06436:	03 01 00 
    710d54a06439:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    710d54a0643e:	41 81 f9 e2 03 01 00 	cmp    r9d,0x103e2
    710d54a06445:	0f 84 9c 05 00 00    	je     0x710d54a069e7
    710d54a0644b:	41 bf 00 20 00 00    	mov    r15d,0x2000
    710d54a06451:	be fa 03 01 00       	mov    esi,0x103fa
    710d54a06456:	b8 e6 03 01 00       	mov    eax,0x103e6
    710d54a0645b:	41 bd 04 00 00 00    	mov    r13d,0x4
    710d54a06461:	b2 01                	mov    dl,0x1
    710d54a06463:	bf 0e 00 00 00       	mov    edi,0xe
    710d54a06468:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    710d54a0646c:	45 89 dc             	mov    r12d,r11d
    710d54a0646f:	8d 0c 2f             	lea    ecx,[rdi+rbp*1]
    710d54a06472:	3b 4c 24 24          	cmp    ecx,DWORD PTR [rsp+0x24]
    710d54a06476:	73 54                	jae    0x710d54a064cc
    710d54a06478:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    710d54a0647d:	8b 9b 58 01 00 00    	mov    ebx,DWORD PTR [rbx+0x158]
    710d54a06483:	85 db                	test   ebx,ebx
    710d54a06485:	74 45                	je     0x710d54a064cc
    710d54a06487:	3d b8 03 01 00       	cmp    eax,0x103b8
    710d54a0648c:	75 4b                	jne    0x710d54a064d9
    710d54a0648e:	41 8d 91 1d fc fe ff 	lea    edx,[r9-0x103e3]
    710d54a06495:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d54a0649a:	83 fa d4             	cmp    edx,0xffffffd4
    710d54a0649d:	77 1d                	ja     0x710d54a064bc
    710d54a0649f:	81 fe ba 03 01 00    	cmp    esi,0x103ba
    710d54a064a5:	75 15                	jne    0x710d54a064bc
    710d54a064a7:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    710d54a064ac:	81 ba 94 00 00 00 b8 	cmp    DWORD PTR [rdx+0x94],0x103b8
    710d54a064b3:	03 01 00 
    710d54a064b6:	0f 84 c4 fc ff ff    	je     0x710d54a06180
    710d54a064bc:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    710d54a064c1:	c6 82 65 01 00 00 01 	mov    BYTE PTR [rdx+0x165],0x1
    710d54a064c8:	31 d2                	xor    edx,edx
    710d54a064ca:	89 cd                	mov    ebp,ecx
    710d54a064cc:	45 89 e9             	mov    r9d,r13d
    710d54a064cf:	4c 8b 6c 24 18       	mov    r13,QWORD PTR [rsp+0x18]
    710d54a064d4:	e9 34 01 00 00       	jmp    0x710d54a0660d
    710d54a064d9:	44 89 6c 24 30       	mov    DWORD PTR [rsp+0x30],r13d
    710d54a064de:	8d 1c c5 00 00 00 00 	lea    ebx,[rax*8+0x0]
    710d54a064e5:	81 e3 f0 ff 0f 00    	and    ebx,0xffff0
    710d54a064eb:	4c 8b 4c 24 68       	mov    r9,QWORD PTR [rsp+0x68]
    710d54a064f0:	41 39 04 19          	cmp    DWORD PTR [r9+rbx*1],eax
    710d54a064f4:	0f 85 fb 11 00 18    	jne    0x710d6ca076f5
    710d54a064fa:	49 8b 54 19 08       	mov    rdx,QWORD PTR [r9+rbx*1+0x8]
    710d54a064ff:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    710d54a06504:	4c 8b 6c 24 08       	mov    r13,QWORD PTR [rsp+0x8]
    710d54a06509:	41 89 5d 00          	mov    DWORD PTR [r13+0x0],ebx
    710d54a0650d:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    710d54a06512:	41 89 5d 24          	mov    DWORD PTR [r13+0x24],ebx
    710d54a06516:	45 89 bd 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],r15d
    710d54a0651d:	41 89 b5 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],esi
    710d54a06524:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a0652b:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a0652f:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    710d54a06536:	45 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r14d
    710d54a0653d:	45 89 a5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],r12d
    710d54a06544:	45 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],r11d
    710d54a0654b:	45 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],r10d
    710d54a06552:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06555:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a0655c:	45 89 85 00 01 00 00 	mov    DWORD PTR [r13+0x100],r8d
    710d54a06563:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    710d54a06567:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    710d54a0656e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a06575:	00 
    710d54a06576:	41 89 bd 34 01 00 00 	mov    DWORD PTR [r13+0x134],edi
    710d54a0657d:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a06584:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    710d54a06589:	48 83 c4 78          	add    rsp,0x78
    710d54a0658d:	ff e2                	jmp    rdx
    710d54a0658f:	48 89 f5             	mov    rbp,rsi
    710d54a06592:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    710d54a06597:	44 89 f8             	mov    eax,r15d
    710d54a0659a:	f7 d0                	not    eax
    710d54a0659c:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    710d54a065a0:	01 c1                	add    ecx,eax
    710d54a065a2:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    710d54a065a7:	44 01 f8             	add    eax,r15d
    710d54a065aa:	ff c0                	inc    eax
    710d54a065ac:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a065b1:	41 89 cf             	mov    r15d,ecx
    710d54a065b4:	b2 01                	mov    dl,0x1
    710d54a065b6:	41 b9 02 00 00 00    	mov    r9d,0x2
    710d54a065bc:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d54a065c1:	be ba 03 01 00       	mov    esi,0x103ba
    710d54a065c6:	eb 39                	jmp    0x710d54a06601
    710d54a065c8:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    710d54a065cd:	44 89 e0             	mov    eax,r12d
    710d54a065d0:	f7 d0                	not    eax
    710d54a065d2:	44 8b 7c 24 3c       	mov    r15d,DWORD PTR [rsp+0x3c]
    710d54a065d7:	41 01 c7             	add    r15d,eax
    710d54a065da:	83 c3 04             	add    ebx,0x4
    710d54a065dd:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    710d54a065e2:	44 01 e0             	add    eax,r12d
    710d54a065e5:	ff c0                	inc    eax
    710d54a065e7:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a065ec:	b2 01                	mov    dl,0x1
    710d54a065ee:	41 b9 02 00 00 00    	mov    r9d,0x2
    710d54a065f4:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d54a065f9:	be ba 03 01 00       	mov    esi,0x103ba
    710d54a065fe:	41 89 dd             	mov    r13d,ebx
    710d54a06601:	45 89 dc             	mov    r12d,r11d
    710d54a06604:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    710d54a06608:	bf 02 00 00 00       	mov    edi,0x2
    710d54a0660d:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    710d54a06612:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    710d54a06617:	89 0b                	mov    DWORD PTR [rbx],ecx
    710d54a06619:	44 89 6b 24          	mov    DWORD PTR [rbx+0x24],r13d
    710d54a0661d:	44 89 bb 9c 00 00 00 	mov    DWORD PTR [rbx+0x9c],r15d
    710d54a06624:	89 b3 a4 00 00 00    	mov    DWORD PTR [rbx+0xa4],esi
    710d54a0662a:	89 83 bc 00 00 00    	mov    DWORD PTR [rbx+0xbc],eax
    710d54a06630:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a06634:	89 83 e4 00 00 00    	mov    DWORD PTR [rbx+0xe4],eax
    710d54a0663a:	44 89 b3 e8 00 00 00 	mov    DWORD PTR [rbx+0xe8],r14d
    710d54a06641:	44 89 a3 ec 00 00 00 	mov    DWORD PTR [rbx+0xec],r12d
    710d54a06648:	44 89 9b f0 00 00 00 	mov    DWORD PTR [rbx+0xf0],r11d
    710d54a0664f:	44 89 93 f8 00 00 00 	mov    DWORD PTR [rbx+0xf8],r10d
    710d54a06656:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06659:	89 83 fc 00 00 00    	mov    DWORD PTR [rbx+0xfc],eax
    710d54a0665f:	44 89 83 00 01 00 00 	mov    DWORD PTR [rbx+0x100],r8d
    710d54a06666:	44 89 8b 24 01 00 00 	mov    DWORD PTR [rbx+0x124],r9d
    710d54a0666d:	88 93 28 01 00 00    	mov    BYTE PTR [rbx+0x128],dl
    710d54a06673:	89 bb 34 01 00 00    	mov    DWORD PTR [rbx+0x134],edi
    710d54a06679:	89 ab 5c 01 00 00    	mov    DWORD PTR [rbx+0x15c],ebp
    710d54a0667f:	48 83 c4 78          	add    rsp,0x78
    710d54a06683:	c2 08 00             	ret    0x8
    710d54a06686:	48 89 7c 24 18       	mov    QWORD PTR [rsp+0x18],rdi
    710d54a0668b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    710d54a06690:	89 2f                	mov    DWORD PTR [rdi],ebp
    710d54a06692:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    710d54a06696:	89 9f 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],ebx
    710d54a0669c:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    710d54a066a3:	03 01 00 
    710d54a066a6:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x103ba
    710d54a066ad:	03 01 00 
    710d54a066b0:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    710d54a066b7:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    710d54a066be:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a066c2:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    710d54a066c8:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    710d54a066cf:	44 89 97 f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r10d
    710d54a066d6:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a066d9:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a066df:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    710d54a066e6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a066ed:	00 00 00 
    710d54a066f0:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a066f7:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    710d54a066fe:	00 00 00 
    710d54a06701:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    710d54a06707:	45 89 c6             	mov    r14d,r8d
    710d54a0670a:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d54a06711:	56 00 00 
    710d54a06714:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    710d54a06719:	ff d0                	call   rax
    710d54a0671b:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    710d54a06720:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a06725:	45 89 f0             	mov    r8d,r14d
    710d54a06728:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a0672d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    710d54a06734:	0f 84 23 fb ff ff    	je     0x710d54a0625d
    710d54a0673a:	e9 9d 0f 00 18       	jmp    0x710d6ca076dc
    710d54a0673f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    710d54a06744:	89 2f                	mov    DWORD PTR [rdi],ebp
    710d54a06746:	89 5f 24             	mov    DWORD PTR [rdi+0x24],ebx
    710d54a06749:	44 89 bf 9c 00 00 00 	mov    DWORD PTR [rdi+0x9c],r15d
    710d54a06750:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    710d54a06757:	03 01 00 
    710d54a0675a:	89 87 bc 00 00 00    	mov    DWORD PTR [rdi+0xbc],eax
    710d54a06760:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    710d54a06767:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    710d54a0676e:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a06772:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    710d54a06778:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    710d54a0677f:	44 89 97 f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r10d
    710d54a06786:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06789:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a0678f:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    710d54a06796:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a0679d:	00 00 00 
    710d54a067a0:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a067a7:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    710d54a067ae:	00 00 00 
    710d54a067b1:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    710d54a067b7:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    710d54a067bc:	ba b8 03 01 00       	mov    edx,0x103b8
    710d54a067c1:	89 d9                	mov    ecx,ebx
    710d54a067c3:	49 89 fd             	mov    r13,rdi
    710d54a067c6:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d54a067cc:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a067d3:	56 00 00 
    710d54a067d6:	ff d0                	call   rax
    710d54a067d8:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    710d54a067df:	00 
    710d54a067e0:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    710d54a067e5:	8b 03                	mov    eax,DWORD PTR [rbx]
    710d54a067e7:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    710d54a067ec:	8b 43 24             	mov    eax,DWORD PTR [rbx+0x24]
    710d54a067ef:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a067f4:	44 8b bb 9c 00 00 00 	mov    r15d,DWORD PTR [rbx+0x9c]
    710d54a067fb:	44 8b 8b a0 00 00 00 	mov    r9d,DWORD PTR [rbx+0xa0]
    710d54a06802:	8b b3 a4 00 00 00    	mov    esi,DWORD PTR [rbx+0xa4]
    710d54a06808:	8b 83 bc 00 00 00    	mov    eax,DWORD PTR [rbx+0xbc]
    710d54a0680e:	8b 8b e4 00 00 00    	mov    ecx,DWORD PTR [rbx+0xe4]
    710d54a06814:	89 4c 24 04          	mov    DWORD PTR [rsp+0x4],ecx
    710d54a06818:	44 8b b3 e8 00 00 00 	mov    r14d,DWORD PTR [rbx+0xe8]
    710d54a0681f:	44 8b a3 ec 00 00 00 	mov    r12d,DWORD PTR [rbx+0xec]
    710d54a06826:	44 8b 9b f0 00 00 00 	mov    r11d,DWORD PTR [rbx+0xf0]
    710d54a0682d:	44 8b 93 f8 00 00 00 	mov    r10d,DWORD PTR [rbx+0xf8]
    710d54a06834:	8b 8b fc 00 00 00    	mov    ecx,DWORD PTR [rbx+0xfc]
    710d54a0683a:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    710d54a0683d:	44 8b 83 00 01 00 00 	mov    r8d,DWORD PTR [rbx+0x100]
    710d54a06844:	44 8b ab 24 01 00 00 	mov    r13d,DWORD PTR [rbx+0x124]
    710d54a0684b:	8b bb 34 01 00 00    	mov    edi,DWORD PTR [rbx+0x134]
    710d54a06851:	8b ab 5c 01 00 00    	mov    ebp,DWORD PTR [rbx+0x15c]
    710d54a06857:	e9 13 fc ff ff       	jmp    0x710d54a0646f
    710d54a0685c:	48 8b 4c 24 08       	mov    rcx,QWORD PTR [rsp+0x8]
    710d54a06861:	89 29                	mov    DWORD PTR [rcx],ebp
    710d54a06863:	89 59 24             	mov    DWORD PTR [rcx+0x24],ebx
    710d54a06866:	44 89 b9 9c 00 00 00 	mov    DWORD PTR [rcx+0x9c],r15d
    710d54a0686d:	c7 81 a4 00 00 00 ba 	mov    DWORD PTR [rcx+0xa4],0x103ba
    710d54a06874:	03 01 00 
    710d54a06877:	89 81 bc 00 00 00    	mov    DWORD PTR [rcx+0xbc],eax
    710d54a0687d:	44 89 89 e4 00 00 00 	mov    DWORD PTR [rcx+0xe4],r9d
    710d54a06884:	44 89 b1 e8 00 00 00 	mov    DWORD PTR [rcx+0xe8],r14d
    710d54a0688b:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a0688f:	89 81 ec 00 00 00    	mov    DWORD PTR [rcx+0xec],eax
    710d54a06895:	44 89 99 f0 00 00 00 	mov    DWORD PTR [rcx+0xf0],r11d
    710d54a0689c:	44 89 91 f8 00 00 00 	mov    DWORD PTR [rcx+0xf8],r10d
    710d54a068a3:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a068a6:	89 81 fc 00 00 00    	mov    DWORD PTR [rcx+0xfc],eax
    710d54a068ac:	44 89 81 00 01 00 00 	mov    DWORD PTR [rcx+0x100],r8d
    710d54a068b3:	c7 81 24 01 00 00 02 	mov    DWORD PTR [rcx+0x124],0x2
    710d54a068ba:	00 00 00 
    710d54a068bd:	c6 81 28 01 00 00 00 	mov    BYTE PTR [rcx+0x128],0x0
    710d54a068c4:	c7 81 34 01 00 00 01 	mov    DWORD PTR [rcx+0x134],0x1
    710d54a068cb:	00 00 00 
    710d54a068ce:	89 b1 5c 01 00 00    	mov    DWORD PTR [rcx+0x15c],esi
    710d54a068d4:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    710d54a068d9:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    710d54a068de:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    710d54a068e3:	89 de                	mov    esi,ebx
    710d54a068e5:	89 ea                	mov    edx,ebp
    710d54a068e7:	44 89 44 24 64       	mov    DWORD PTR [rsp+0x64],r8d
    710d54a068ec:	44 89 5c 24 50       	mov    DWORD PTR [rsp+0x50],r11d
    710d54a068f1:	48 b8 20 a6 90 86 66 	movabs rax,0x56668690a620
    710d54a068f8:	56 00 00 
    710d54a068fb:	ff d0                	call   rax
    710d54a068fd:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a06902:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a06907:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    710d54a0690c:	44 8b 5c 24 50       	mov    r11d,DWORD PTR [rsp+0x50]
    710d54a06911:	44 8b 44 24 64       	mov    r8d,DWORD PTR [rsp+0x64]
    710d54a06916:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a0691b:	0f b6 90 28 01 00 00 	movzx  edx,BYTE PTR [rax+0x128]
    710d54a06922:	84 d2                	test   dl,dl
    710d54a06924:	0f 84 03 fa ff ff    	je     0x710d54a0632d
    710d54a0692a:	e9 b1 fe ff ff       	jmp    0x710d54a067e0
    710d54a0692f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    710d54a06934:	89 2f                	mov    DWORD PTR [rdi],ebp
    710d54a06936:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    710d54a0693a:	44 89 bf 9c 00 00 00 	mov    DWORD PTR [rdi+0x9c],r15d
    710d54a06941:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    710d54a06948:	03 01 00 
    710d54a0694b:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x103ba
    710d54a06952:	03 01 00 
    710d54a06955:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    710d54a0695c:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    710d54a06963:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a06967:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    710d54a0696d:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    710d54a06974:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    710d54a06978:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    710d54a0697e:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06981:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a06987:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    710d54a0698e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a06995:	00 00 00 
    710d54a06998:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a0699f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    710d54a069a6:	00 00 00 
    710d54a069a9:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    710d54a069af:	45 89 c6             	mov    r14d,r8d
    710d54a069b2:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d54a069b9:	56 00 00 
    710d54a069bc:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    710d54a069c1:	ff d0                	call   rax
    710d54a069c3:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a069c8:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a069cd:	45 89 f0             	mov    r8d,r14d
    710d54a069d0:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d54a069d5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    710d54a069dc:	0f 84 5d f9 ff ff    	je     0x710d54a0633f
    710d54a069e2:	e9 f5 0c 00 18       	jmp    0x710d6ca076dc
    710d54a069e7:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    710d54a069ec:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    710d54a069f1:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a069f3:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a069f8:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    710d54a069fb:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x2000
    710d54a06a02:	20 00 00 
    710d54a06a05:	c7 87 a4 00 00 00 fa 	mov    DWORD PTR [rdi+0xa4],0x103fa
    710d54a06a0c:	03 01 00 
    710d54a06a0f:	c7 87 bc 00 00 00 e6 	mov    DWORD PTR [rdi+0xbc],0x103e6
    710d54a06a16:	03 01 00 
    710d54a06a19:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a06a1d:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a06a23:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    710d54a06a2a:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    710d54a06a31:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    710d54a06a38:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06a3b:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    710d54a06a41:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a06a47:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    710d54a06a4e:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    710d54a06a55:	00 00 00 
    710d54a06a58:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    710d54a06a5f:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    710d54a06a66:	00 00 00 
    710d54a06a69:	89 af 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ebp
    710d54a06a6f:	be e2 03 01 00       	mov    esi,0x103e2
    710d54a06a74:	ba e2 03 01 00       	mov    edx,0x103e2
    710d54a06a79:	49 89 fd             	mov    r13,rdi
    710d54a06a7c:	48 b8 30 0d a2 86 66 	movabs rax,0x566686a20d30
    710d54a06a83:	56 00 00 
    710d54a06a86:	ff d0                	call   rax
    710d54a06a88:	e9 4b fd ff ff       	jmp    0x710d54a067d8
