
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65536-1-124302470938624.bin:     file format binary


Disassembly of section .data:

0000710d6ca00000 <.data>:
    710d6ca00000:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca00006:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca00009:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca0000f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca00016:	0f 87 15 03 00 e8    	ja     0x710d54a00331
    710d6ca0001c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x0
    710d6ca00023:	00 00 00 00 
    710d6ca00027:	e9 05 03 00 e8       	jmp    0x710d54a00331
    710d6ca0002c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10000
    710d6ca00033:	00 00 01 00 
    710d6ca00037:	b8 00 00 01 00       	mov    eax,0x10000
    710d6ca0003c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00043:	02 00 00 00 
    710d6ca00047:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0004e:	01 00 00 00 
    710d6ca00052:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00055:	be 00 00 01 00       	mov    esi,0x10000
    710d6ca0005a:	4c 89 ef             	mov    rdi,r13
    710d6ca0005d:	e8 fe 00 00 e8       	call   0x710d54a00160
    710d6ca00062:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00069:	00 
    710d6ca0006a:	0f 84 e9 02 00 e8    	je     0x710d54a00359
    710d6ca00070:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00077:	02 00 00 00 
    710d6ca0007b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00082:	01 00 00 00 
    710d6ca00086:	58                   	pop    rax
    710d6ca00087:	e9 66 03 00 e8       	jmp    0x710d54a003f2
    710d6ca0008c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00093:	14 00 01 00 
    710d6ca00097:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0009e:	04 00 00 00 
    710d6ca000a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca000a9:	02 00 00 00 
    710d6ca000ad:	be 02 00 01 00       	mov    esi,0x10002
    710d6ca000b2:	ba 02 00 01 00       	mov    edx,0x10002
    710d6ca000b7:	4c 89 ef             	mov    rdi,r13
    710d6ca000ba:	e8 a1 00 00 e8       	call   0x710d54a00160
    710d6ca000bf:	e9 0c 03 00 e8       	jmp    0x710d54a003d0
    710d6ca000c4:	c2 08 00             	ret    0x8
