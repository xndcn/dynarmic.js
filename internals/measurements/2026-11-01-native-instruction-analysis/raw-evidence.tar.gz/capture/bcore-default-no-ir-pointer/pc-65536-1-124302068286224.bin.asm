
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65536-1-124302068286224.bin:     file format binary


Disassembly of section .data:

0000710d54a00310 <.data>:
    710d54a00310:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a00317:	8b 88 00 00 10 00    	mov    ecx,DWORD PTR [rax+0x100000]
    710d54a0031d:	ff c1                	inc    ecx
    710d54a0031f:	89 88 00 00 10 00    	mov    DWORD PTR [rax+0x100000],ecx
    710d54a00325:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0032b:	0f 84 cf fc ff 17    	je     0x710d6ca00000
    710d54a00331:	50                   	push   rax
    710d54a00332:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    710d54a00337:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10000
    710d54a0033e:	00 00 01 00 
    710d54a00342:	0f 84 e4 fc ff 17    	je     0x710d6ca0002c
    710d54a00348:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10000
    710d54a0034f:	00 00 01 00 
    710d54a00353:	0f 84 d3 fc ff 17    	je     0x710d6ca0002c
    710d54a00359:	58                   	pop    rax
    710d54a0035a:	50                   	push   rax
    710d54a0035b:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a00362:	b9 02 00 01 00       	mov    ecx,0x10002
    710d54a00367:	83 c1 04             	add    ecx,0x4
    710d54a0036a:	89 ca                	mov    edx,ecx
    710d54a0036c:	3d 02 00 01 00       	cmp    eax,0x10002
    710d54a00371:	75 07                	jne    0x710d54a0037a
    710d54a00373:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    710d54a0037a:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    710d54a00381:	02 
    710d54a00382:	0f 43 ca             	cmovae ecx,edx
    710d54a00385:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    710d54a0038c:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    710d54a00393:	89 cf                	mov    edi,ecx
    710d54a00395:	81 fa 02 00 01 00    	cmp    edx,0x10002
    710d54a0039b:	75 07                	jne    0x710d54a003a4
    710d54a0039d:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    710d54a003a4:	83 fe 02             	cmp    esi,0x2
    710d54a003a7:	0f 43 cf             	cmovae ecx,edi
    710d54a003aa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    710d54a003b1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a003b8:	01 
    710d54a003b9:	3d 02 00 01 00       	cmp    eax,0x10002
    710d54a003be:	0f 84 c8 fc ff 17    	je     0x710d6ca0008c
    710d54a003c4:	81 fa 02 00 01 00    	cmp    edx,0x10002
    710d54a003ca:	0f 84 bc fc ff 17    	je     0x710d6ca0008c
    710d54a003d0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d54a003d7:	14 00 01 00 
    710d54a003db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a003e2:	04 00 00 00 
    710d54a003e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d54a003ed:	02 00 00 00 
    710d54a003f1:	58                   	pop    rax
    710d54a003f2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a003f9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a00400:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a00407:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a0040e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a00415:	39 f1                	cmp    ecx,esi
    710d54a00417:	0f 83 a7 fc ff 17    	jae    0x710d6ca000c4
    710d54a0041d:	81 fa 00 00 01 00    	cmp    edx,0x10000
    710d54a00423:	75 14                	jne    0x710d54a00439
    710d54a00425:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0042c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a00433:	00 
    710d54a00434:	e9 d7 fe ff ff       	jmp    0x710d54a00310
    710d54a00439:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a00440:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a00446:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a00449:	0f 85 75 fc ff 17    	jne    0x710d6ca000c4
    710d54a0044f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a00456:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a0045d:	00 
    710d54a0045e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a00463:	ff e0                	jmp    rax
