
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66600-1-124302068299168.bin:     file format binary


Disassembly of section .data:

0000710d54a035a0 <.data>:
    710d54a035a0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a035a7:	8b 88 28 00 10 00    	mov    ecx,DWORD PTR [rax+0x100028]
    710d54a035ad:	ff c1                	inc    ecx
    710d54a035af:	89 88 28 00 10 00    	mov    DWORD PTR [rax+0x100028],ecx
    710d54a035b5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a035bb:	0f 84 3f 14 00 18    	je     0x710d6ca04a00
    710d54a035c1:	50                   	push   rax
    710d54a035c2:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a035c7:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a035cc:	09 c1                	or     ecx,eax
    710d54a035ce:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a035d2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10428
    710d54a035d9:	28 04 01 00 
    710d54a035dd:	0f 84 49 14 00 18    	je     0x710d6ca04a2c
    710d54a035e3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10428
    710d54a035ea:	28 04 01 00 
    710d54a035ee:	0f 84 38 14 00 18    	je     0x710d6ca04a2c
    710d54a035f4:	58                   	pop    rax
    710d54a035f5:	50                   	push   rax
    710d54a035f6:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a035fa:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a035fd:	f6 c3 03             	test   bl,0x3
    710d54a03600:	0f 85 86 14 00 18    	jne    0x710d6ca04a8c
    710d54a03606:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a0360d:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a03614:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    710d54a03618:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    710d54a0361f:	89 c8                	mov    eax,ecx
    710d54a03621:	c1 e8 0c             	shr    eax,0xc
    710d54a03624:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03629:	48 85 c0             	test   rax,rax
    710d54a0362c:	0f 84 ad 14 00 18    	je     0x710d6ca04adf
    710d54a03632:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03638:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a0363b:	83 c3 f8             	add    ebx,0xfffffff8
    710d54a0363e:	89 d8                	mov    eax,ebx
    710d54a03640:	c1 e8 0c             	shr    eax,0xc
    710d54a03643:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03648:	48 85 c0             	test   rax,rax
    710d54a0364b:	0f 84 c9 14 00 18    	je     0x710d6ca04b1a
    710d54a03651:	89 d9                	mov    ecx,ebx
    710d54a03653:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03659:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    710d54a0365d:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    710d54a03661:	b8 00 00 00 00       	mov    eax,0x0
    710d54a03666:	29 c3                	sub    ebx,eax
    710d54a03668:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a0366c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1042c
    710d54a03673:	2c 04 01 00 
    710d54a03677:	0f 84 de 14 00 18    	je     0x710d6ca04b5b
    710d54a0367d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1042c
    710d54a03684:	2c 04 01 00 
    710d54a03688:	0f 84 cd 14 00 18    	je     0x710d6ca04b5b
    710d54a0368e:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a03692:	0f 85 05 15 00 18    	jne    0x710d6ca04b9d
    710d54a03698:	58                   	pop    rax
    710d54a03699:	e9 0f 00 00 00       	jmp    0x710d54a036ad
    710d54a0369e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a036a5:	00 
    710d54a036a6:	74 f0                	je     0x710d54a03698
    710d54a036a8:	e9 16 14 00 18       	jmp    0x710d6ca04ac3
    710d54a036ad:	50                   	push   rax
    710d54a036ae:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a036b3:	c1 e0 10             	shl    eax,0x10
    710d54a036b6:	b9 f0 12 00 00       	mov    ecx,0x12f0
    710d54a036bb:	09 c1                	or     ecx,eax
    710d54a036bd:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a036c1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10430
    710d54a036c8:	30 04 01 00 
    710d54a036cc:	0f 84 fd 14 00 18    	je     0x710d6ca04bcf
    710d54a036d2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10430
    710d54a036d9:	30 04 01 00 
    710d54a036dd:	0f 84 ec 14 00 18    	je     0x710d6ca04bcf
    710d54a036e3:	58                   	pop    rax
    710d54a036e4:	50                   	push   rax
    710d54a036e5:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a036e9:	f6 c1 03             	test   cl,0x3
    710d54a036ec:	0f 85 3d 15 00 18    	jne    0x710d6ca04c2f
    710d54a036f2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a036f9:	48 89 ca             	mov    rdx,rcx
    710d54a036fc:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a03700:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a03704:	48 85 c0             	test   rax,rax
    710d54a03707:	0f 84 72 15 00 18    	je     0x710d6ca04c7f
    710d54a0370d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03713:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a03716:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a0371a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10434
    710d54a03721:	34 04 01 00 
    710d54a03725:	0f 84 8f 15 00 18    	je     0x710d6ca04cba
    710d54a0372b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10434
    710d54a03732:	34 04 01 00 
    710d54a03736:	0f 84 7e 15 00 18    	je     0x710d6ca04cba
    710d54a0373c:	58                   	pop    rax
    710d54a0373d:	50                   	push   rax
    710d54a0373e:	31 c0                	xor    eax,eax
    710d54a03740:	41 83 7d 28 05       	cmp    DWORD PTR [r13+0x28],0x5
    710d54a03745:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0374c:	0f 92 c0             	setb   al
    710d54a0374f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    710d54a03756:	81 f9 36 04 01 00    	cmp    ecx,0x10436
    710d54a0375c:	0f 84 a1 15 00 18    	je     0x710d6ca04d03
    710d54a03762:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10436
    710d54a03769:	36 04 01 00 
    710d54a0376d:	0f 84 90 15 00 18    	je     0x710d6ca04d03
    710d54a03773:	58                   	pop    rax
    710d54a03774:	50                   	push   rax
    710d54a03775:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a0377c:	00 
    710d54a0377d:	74 55                	je     0x710d54a037d4
    710d54a0377f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a03786:	01 
    710d54a03787:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    710d54a0378e:	38 04 01 00 
    710d54a03792:	0f 84 cb 15 00 18    	je     0x710d6ca04d63
    710d54a03798:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    710d54a0379f:	38 04 01 00 
    710d54a037a3:	0f 84 ba 15 00 18    	je     0x710d6ca04d63
    710d54a037a9:	b8 38 04 01 00       	mov    eax,0x10438
    710d54a037ae:	83 c0 0a             	add    eax,0xa
    710d54a037b1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a037b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a037bf:	02 00 00 00 
    710d54a037c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d54a037ca:	06 00 00 00 
    710d54a037ce:	58                   	pop    rax
    710d54a037cf:	e9 33 01 00 00       	jmp    0x710d54a03907
    710d54a037d4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    710d54a037db:	38 04 01 00 
    710d54a037df:	0f 84 ba 15 00 18    	je     0x710d6ca04d9f
    710d54a037e5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    710d54a037ec:	38 04 01 00 
    710d54a037f0:	0f 84 a9 15 00 18    	je     0x710d6ca04d9f
    710d54a037f6:	58                   	pop    rax
    710d54a037f7:	50                   	push   rax
    710d54a037f8:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a037ff:	00 
    710d54a03800:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043a
    710d54a03807:	3a 04 01 00 
    710d54a0380b:	0f 84 d7 15 00 18    	je     0x710d6ca04de8
    710d54a03811:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043a
    710d54a03818:	3a 04 01 00 
    710d54a0381c:	0f 84 c6 15 00 18    	je     0x710d6ca04de8
    710d54a03822:	58                   	pop    rax
    710d54a03823:	50                   	push   rax
    710d54a03824:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a03828:	f6 c3 03             	test   bl,0x3
    710d54a0382b:	0f 85 17 16 00 18    	jne    0x710d6ca04e48
    710d54a03831:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a03838:	48 89 d8             	mov    rax,rbx
    710d54a0383b:	48 c1 e8 0c          	shr    rax,0xc
    710d54a0383f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03844:	48 85 c0             	test   rax,rax
    710d54a03847:	0f 84 4d 16 00 18    	je     0x710d6ca04e9a
    710d54a0384d:	89 d9                	mov    ecx,ebx
    710d54a0384f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03855:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a03859:	89 de                	mov    esi,ebx
    710d54a0385b:	83 c6 04             	add    esi,0x4
    710d54a0385e:	89 f0                	mov    eax,esi
    710d54a03860:	c1 e8 0c             	shr    eax,0xc
    710d54a03863:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03868:	48 85 c0             	test   rax,rax
    710d54a0386b:	0f 84 66 16 00 18    	je     0x710d6ca04ed7
    710d54a03871:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a03877:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a0387a:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a0387d:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a03881:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a03888:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a0388c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043c
    710d54a03893:	3c 04 01 00 
    710d54a03897:	0f 84 76 16 00 18    	je     0x710d6ca04f13
    710d54a0389d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043c
    710d54a038a4:	3c 04 01 00 
    710d54a038a8:	0f 84 65 16 00 18    	je     0x710d6ca04f13
    710d54a038ae:	58                   	pop    rax
    710d54a038af:	50                   	push   rax
    710d54a038b0:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a038b7:	a8 01                	test   al,0x1
    710d54a038b9:	0f 85 9d 16 00 18    	jne    0x710d6ca04f5c
    710d54a038bf:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a038c6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a038cd:	01 
    710d54a038ce:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10440
    710d54a038d5:	40 04 01 00 
    710d54a038d9:	0f 84 b3 16 00 18    	je     0x710d6ca04f92
    710d54a038df:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10440
    710d54a038e6:	40 04 01 00 
    710d54a038ea:	0f 84 a2 16 00 18    	je     0x710d6ca04f92
    710d54a038f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a038f7:	02 00 00 00 
    710d54a038fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d54a03902:	09 00 00 00 
    710d54a03906:	58                   	pop    rax
    710d54a03907:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a0390e:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a03915:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0391c:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a03923:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a0392a:	39 f1                	cmp    ecx,esi
    710d54a0392c:	0f 83 8d 16 00 18    	jae    0x710d6ca04fbf
    710d54a03932:	81 fa 28 04 01 00    	cmp    edx,0x10428
    710d54a03938:	75 14                	jne    0x710d54a0394e
    710d54a0393a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03941:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03948:	00 
    710d54a03949:	e9 52 fc ff ff       	jmp    0x710d54a035a0
    710d54a0394e:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a03955:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a0395b:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a0395e:	0f 85 5b 16 00 18    	jne    0x710d6ca04fbf
    710d54a03964:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0396b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03972:	00 
    710d54a03973:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a03978:	ff e0                	jmp    rax
