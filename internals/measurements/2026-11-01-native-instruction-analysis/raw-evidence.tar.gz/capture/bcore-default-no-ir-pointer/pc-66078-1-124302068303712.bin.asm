
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66078-1-124302068303712.bin:     file format binary


Disassembly of section .data:

0000710d54a04760 <.data>:
    710d54a04760:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a04767:	8b 88 38 00 10 00    	mov    ecx,DWORD PTR [rax+0x100038]
    710d54a0476d:	ff c1                	inc    ecx
    710d54a0476f:	89 88 38 00 10 00    	mov    DWORD PTR [rax+0x100038],ecx
    710d54a04775:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0477b:	0f 84 df 1b 00 18    	je     0x710d6ca06360
    710d54a04781:	50                   	push   rax
    710d54a04782:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a04786:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0478d:	41 89 45 20          	mov    DWORD PTR [r13+0x20],eax
    710d54a04791:	81 f9 1e 02 01 00    	cmp    ecx,0x1021e
    710d54a04797:	0f 84 ef 1b 00 18    	je     0x710d6ca0638c
    710d54a0479d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1021e
    710d54a047a4:	1e 02 01 00 
    710d54a047a8:	0f 84 de 1b 00 18    	je     0x710d6ca0638c
    710d54a047ae:	58                   	pop    rax
    710d54a047af:	50                   	push   rax
    710d54a047b0:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    710d54a047b4:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a047bb:	31 d2                	xor    edx,edx
    710d54a047bd:	89 c6                	mov    esi,eax
    710d54a047bf:	ff c6                	inc    esi
    710d54a047c1:	0f 94 c2             	sete   dl
    710d54a047c4:	41 89 75 0c          	mov    DWORD PTR [r13+0xc],esi
    710d54a047c8:	c1 e8 1f             	shr    eax,0x1f
    710d54a047cb:	89 f7                	mov    edi,esi
    710d54a047cd:	c1 ef 1f             	shr    edi,0x1f
    710d54a047d0:	f7 d0                	not    eax
    710d54a047d2:	21 f8                	and    eax,edi
    710d54a047d4:	31 db                	xor    ebx,ebx
    710d54a047d6:	85 f6                	test   esi,esi
    710d54a047d8:	0f 94 c3             	sete   bl
    710d54a047db:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    710d54a047e2:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a047e9:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    710d54a047f0:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a047f7:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    710d54a047fe:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    710d54a04805:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    710d54a0480c:	81 f9 20 02 01 00    	cmp    ecx,0x10220
    710d54a04812:	0f 84 d4 1b 00 18    	je     0x710d6ca063ec
    710d54a04818:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10220
    710d54a0481f:	20 02 01 00 
    710d54a04823:	0f 84 c3 1b 00 18    	je     0x710d6ca063ec
    710d54a04829:	58                   	pop    rax
    710d54a0482a:	50                   	push   rax
    710d54a0482b:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a0482f:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    710d54a04833:	31 d2                	xor    edx,edx
    710d54a04835:	31 f6                	xor    esi,esi
    710d54a04837:	31 ff                	xor    edi,edi
    710d54a04839:	31 db                	xor    ebx,ebx
    710d54a0483b:	39 c8                	cmp    eax,ecx
    710d54a0483d:	0f 96 c2             	setbe  dl
    710d54a04840:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a04847:	40 0f 94 c6          	sete   sil
    710d54a0484b:	40 0f 92 c7          	setb   dil
    710d54a0484f:	0f 93 c3             	setae  bl
    710d54a04852:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a04859:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a04860:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    710d54a04867:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    710d54a0486e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10222
    710d54a04875:	22 02 01 00 
    710d54a04879:	0f 84 cd 1b 00 18    	je     0x710d6ca0644c
    710d54a0487f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10222
    710d54a04886:	22 02 01 00 
    710d54a0488a:	0f 84 bc 1b 00 18    	je     0x710d6ca0644c
    710d54a04890:	58                   	pop    rax
    710d54a04891:	50                   	push   rax
    710d54a04892:	41 8b 45 20          	mov    eax,DWORD PTR [r13+0x20]
    710d54a04896:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0489d:	c1 e0 02             	shl    eax,0x2
    710d54a048a0:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    710d54a048a4:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a048a8:	81 f9 24 02 01 00    	cmp    ecx,0x10224
    710d54a048ae:	0f 84 f8 1b 00 18    	je     0x710d6ca064ac
    710d54a048b4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10224
    710d54a048bb:	24 02 01 00 
    710d54a048bf:	0f 84 e7 1b 00 18    	je     0x710d6ca064ac
    710d54a048c5:	58                   	pop    rax
    710d54a048c6:	50                   	push   rax
    710d54a048c7:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a048cb:	f6 c1 03             	test   cl,0x3
    710d54a048ce:	0f 85 38 1c 00 18    	jne    0x710d6ca0650c
    710d54a048d4:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a048db:	48 89 ca             	mov    rdx,rcx
    710d54a048de:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a048e2:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a048e6:	48 85 c0             	test   rax,rax
    710d54a048e9:	0f 84 6d 1c 00 18    	je     0x710d6ca0655c
    710d54a048ef:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a048f5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a048f8:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a048fc:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10226
    710d54a04903:	26 02 01 00 
    710d54a04907:	0f 84 8a 1c 00 18    	je     0x710d6ca06597
    710d54a0490d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10226
    710d54a04914:	26 02 01 00 
    710d54a04918:	0f 84 79 1c 00 18    	je     0x710d6ca06597
    710d54a0491e:	58                   	pop    rax
    710d54a0491f:	50                   	push   rax
    710d54a04920:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a04924:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0492b:	31 d2                	xor    edx,edx
    710d54a0492d:	41 33 45 08          	xor    eax,DWORD PTR [r13+0x8]
    710d54a04931:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a04935:	0f 94 c2             	sete   dl
    710d54a04938:	c1 e8 1f             	shr    eax,0x1f
    710d54a0493b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a04942:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a04949:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a04950:	00 00 00 00 
    710d54a04954:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a0495b:	00 00 00 00 
    710d54a0495f:	81 f9 28 02 01 00    	cmp    ecx,0x10228
    710d54a04965:	0f 84 75 1c 00 18    	je     0x710d6ca065e0
    710d54a0496b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10228
    710d54a04972:	28 02 01 00 
    710d54a04976:	0f 84 64 1c 00 18    	je     0x710d6ca065e0
    710d54a0497c:	58                   	pop    rax
    710d54a0497d:	50                   	push   rax
    710d54a0497e:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a04982:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    710d54a04986:	89 c2                	mov    edx,eax
    710d54a04988:	c1 ea 1f             	shr    edx,0x1f
    710d54a0498b:	89 ce                	mov    esi,ecx
    710d54a0498d:	c1 ee 1f             	shr    esi,0x1f
    710d54a04990:	31 ff                	xor    edi,edi
    710d54a04992:	01 c8                	add    eax,ecx
    710d54a04994:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a04998:	40 0f 92 c7          	setb   dil
    710d54a0499c:	89 c1                	mov    ecx,eax
    710d54a0499e:	c1 e9 1f             	shr    ecx,0x1f
    710d54a049a1:	31 ce                	xor    esi,ecx
    710d54a049a3:	31 ca                	xor    edx,ecx
    710d54a049a5:	21 f2                	and    edx,esi
    710d54a049a7:	31 f6                	xor    esi,esi
    710d54a049a9:	85 c0                	test   eax,eax
    710d54a049ab:	40 0f 94 c6          	sete   sil
    710d54a049af:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a049b6:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    710d54a049bd:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    710d54a049c4:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    710d54a049cb:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    710d54a049d2:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a049d9:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a049e0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022a
    710d54a049e7:	2a 02 01 00 
    710d54a049eb:	0f 84 4f 1c 00 18    	je     0x710d6ca06640
    710d54a049f1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022a
    710d54a049f8:	2a 02 01 00 
    710d54a049fc:	0f 84 3e 1c 00 18    	je     0x710d6ca06640
    710d54a04a02:	58                   	pop    rax
    710d54a04a03:	50                   	push   rax
    710d54a04a04:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a04a0b:	00 
    710d54a04a0c:	74 28                	je     0x710d54a04a36
    710d54a04a0e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022c
    710d54a04a15:	2c 02 01 00 
    710d54a04a19:	0f 84 81 1c 00 18    	je     0x710d6ca066a0
    710d54a04a1f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022c
    710d54a04a26:	2c 02 01 00 
    710d54a04a2a:	0f 84 70 1c 00 18    	je     0x710d6ca066a0
    710d54a04a30:	58                   	pop    rax
    710d54a04a31:	e9 55 00 00 00       	jmp    0x710d54a04a8b
    710d54a04a36:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a04a3d:	01 
    710d54a04a3e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022c
    710d54a04a45:	2c 02 01 00 
    710d54a04a49:	0f 84 9a 1c 00 18    	je     0x710d6ca066e9
    710d54a04a4f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022c
    710d54a04a56:	2c 02 01 00 
    710d54a04a5a:	0f 84 89 1c 00 18    	je     0x710d6ca066e9
    710d54a04a60:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d54a04a65:	83 c0 f2             	add    eax,0xfffffff2
    710d54a04a68:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a04a6f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a04a76:	02 00 00 00 
    710d54a04a7a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d54a04a81:	08 00 00 00 
    710d54a04a85:	58                   	pop    rax
    710d54a04a86:	e9 a4 01 00 00       	jmp    0x710d54a04c2f
    710d54a04a8b:	50                   	push   rax
    710d54a04a8c:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a04a90:	f6 c3 03             	test   bl,0x3
    710d54a04a93:	0f 85 8c 1c 00 18    	jne    0x710d6ca06725
    710d54a04a99:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a04aa0:	48 89 d8             	mov    rax,rbx
    710d54a04aa3:	48 c1 e8 0c          	shr    rax,0xc
    710d54a04aa7:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a04aac:	48 85 c0             	test   rax,rax
    710d54a04aaf:	0f 84 c2 1c 00 18    	je     0x710d6ca06777
    710d54a04ab5:	89 d9                	mov    ecx,ebx
    710d54a04ab7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a04abd:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a04ac1:	89 de                	mov    esi,ebx
    710d54a04ac3:	83 c6 04             	add    esi,0x4
    710d54a04ac6:	89 f0                	mov    eax,esi
    710d54a04ac8:	c1 e8 0c             	shr    eax,0xc
    710d54a04acb:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a04ad0:	48 85 c0             	test   rax,rax
    710d54a04ad3:	0f 84 db 1c 00 18    	je     0x710d6ca067b4
    710d54a04ad9:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a04adf:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a04ae2:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a04ae5:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a04ae9:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a04af0:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a04af4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022e
    710d54a04afb:	2e 02 01 00 
    710d54a04aff:	0f 84 eb 1c 00 18    	je     0x710d6ca067f0
    710d54a04b05:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022e
    710d54a04b0c:	2e 02 01 00 
    710d54a04b10:	0f 84 da 1c 00 18    	je     0x710d6ca067f0
    710d54a04b16:	58                   	pop    rax
    710d54a04b17:	50                   	push   rax
    710d54a04b18:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a04b1c:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04b23:	31 d2                	xor    edx,edx
    710d54a04b25:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    710d54a04b29:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a04b2d:	0f 94 c2             	sete   dl
    710d54a04b30:	c1 e8 1f             	shr    eax,0x1f
    710d54a04b33:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a04b3a:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a04b41:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a04b48:	00 00 00 00 
    710d54a04b4c:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a04b53:	00 00 00 00 
    710d54a04b57:	81 f9 32 02 01 00    	cmp    ecx,0x10232
    710d54a04b5d:	0f 84 d6 1c 00 18    	je     0x710d6ca06839
    710d54a04b63:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10232
    710d54a04b6a:	32 02 01 00 
    710d54a04b6e:	0f 84 c5 1c 00 18    	je     0x710d6ca06839
    710d54a04b74:	58                   	pop    rax
    710d54a04b75:	50                   	push   rax
    710d54a04b76:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a04b7a:	f6 c3 03             	test   bl,0x3
    710d54a04b7d:	0f 85 16 1d 00 18    	jne    0x710d6ca06899
    710d54a04b83:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a04b8a:	48 89 d9             	mov    rcx,rbx
    710d54a04b8d:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a04b91:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a04b95:	48 85 c0             	test   rax,rax
    710d54a04b98:	0f 84 4d 1d 00 18    	je     0x710d6ca068eb
    710d54a04b9e:	89 d9                	mov    ecx,ebx
    710d54a04ba0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a04ba6:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a04ba9:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a04bad:	83 c3 04             	add    ebx,0x4
    710d54a04bb0:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a04bb4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10234
    710d54a04bbb:	34 02 01 00 
    710d54a04bbf:	0f 84 61 1d 00 18    	je     0x710d6ca06926
    710d54a04bc5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10234
    710d54a04bcc:	34 02 01 00 
    710d54a04bd0:	0f 84 50 1d 00 18    	je     0x710d6ca06926
    710d54a04bd6:	58                   	pop    rax
    710d54a04bd7:	50                   	push   rax
    710d54a04bd8:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a04bdf:	a8 01                	test   al,0x1
    710d54a04be1:	0f 85 88 1d 00 18    	jne    0x710d6ca0696f
    710d54a04be7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a04bee:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a04bf5:	01 
    710d54a04bf6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10236
    710d54a04bfd:	36 02 01 00 
    710d54a04c01:	0f 84 9e 1d 00 18    	je     0x710d6ca069a5
    710d54a04c07:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10236
    710d54a04c0e:	36 02 01 00 
    710d54a04c12:	0f 84 8d 1d 00 18    	je     0x710d6ca069a5
    710d54a04c18:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a04c1f:	02 00 00 00 
    710d54a04c23:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d54a04c2a:	0c 00 00 00 
    710d54a04c2e:	58                   	pop    rax
    710d54a04c2f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a04c36:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a04c3d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a04c44:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a04c4b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a04c52:	39 f1                	cmp    ecx,esi
    710d54a04c54:	0f 83 78 1d 00 18    	jae    0x710d6ca069d2
    710d54a04c5a:	81 fa 1e 02 01 00    	cmp    edx,0x1021e
    710d54a04c60:	75 14                	jne    0x710d54a04c76
    710d54a04c62:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a04c69:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a04c70:	00 
    710d54a04c71:	e9 ea fa ff ff       	jmp    0x710d54a04760
    710d54a04c76:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a04c7d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a04c83:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a04c86:	0f 85 46 1d 00 18    	jne    0x710d6ca069d2
    710d54a04c8c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a04c93:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a04c9a:	00 
    710d54a04c9b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a04ca0:	ff e0                	jmp    rax
