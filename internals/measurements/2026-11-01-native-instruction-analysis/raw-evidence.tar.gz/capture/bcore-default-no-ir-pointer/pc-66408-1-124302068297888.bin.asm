
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66408-1-124302068297888.bin:     file format binary


Disassembly of section .data:

0000710d54a030a0 <.data>:
    710d54a030a0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a030a7:	8b 88 20 00 10 00    	mov    ecx,DWORD PTR [rax+0x100020]
    710d54a030ad:	ff c1                	inc    ecx
    710d54a030af:	89 88 20 00 10 00    	mov    DWORD PTR [rax+0x100020],ecx
    710d54a030b5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a030bb:	0f 84 7f 13 00 18    	je     0x710d6ca04440
    710d54a030c1:	50                   	push   rax
    710d54a030c2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a030c6:	f6 c3 03             	test   bl,0x3
    710d54a030c9:	0f 85 9d 13 00 18    	jne    0x710d6ca0446c
    710d54a030cf:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a030d6:	48 89 d8             	mov    rax,rbx
    710d54a030d9:	48 c1 e8 0c          	shr    rax,0xc
    710d54a030dd:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a030e2:	48 85 c0             	test   rax,rax
    710d54a030e5:	0f 84 d3 13 00 18    	je     0x710d6ca044be
    710d54a030eb:	89 d9                	mov    ecx,ebx
    710d54a030ed:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a030f3:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a030f7:	89 de                	mov    esi,ebx
    710d54a030f9:	83 c6 04             	add    esi,0x4
    710d54a030fc:	89 f0                	mov    eax,esi
    710d54a030fe:	c1 e8 0c             	shr    eax,0xc
    710d54a03101:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03106:	48 85 c0             	test   rax,rax
    710d54a03109:	0f 84 ec 13 00 18    	je     0x710d6ca044fb
    710d54a0310f:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a03115:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a03118:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a0311b:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a0311f:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a03126:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a0312a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    710d54a03131:	68 03 01 00 
    710d54a03135:	0f 84 fc 13 00 18    	je     0x710d6ca04537
    710d54a0313b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    710d54a03142:	68 03 01 00 
    710d54a03146:	0f 84 eb 13 00 18    	je     0x710d6ca04537
    710d54a0314c:	58                   	pop    rax
    710d54a0314d:	50                   	push   rax
    710d54a0314e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a03152:	f6 c3 03             	test   bl,0x3
    710d54a03155:	0f 85 25 14 00 18    	jne    0x710d6ca04580
    710d54a0315b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a03162:	48 89 d8             	mov    rax,rbx
    710d54a03165:	48 c1 e8 0c          	shr    rax,0xc
    710d54a03169:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a0316e:	48 85 c0             	test   rax,rax
    710d54a03171:	0f 84 5b 14 00 18    	je     0x710d6ca045d2
    710d54a03177:	89 d9                	mov    ecx,ebx
    710d54a03179:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0317f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a03182:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    710d54a03186:	8d 73 04             	lea    esi,[rbx+0x4]
    710d54a03189:	89 f0                	mov    eax,esi
    710d54a0318b:	c1 e8 0c             	shr    eax,0xc
    710d54a0318e:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03193:	48 85 c0             	test   rax,rax
    710d54a03196:	0f 84 71 14 00 18    	je     0x710d6ca0460d
    710d54a0319c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a031a2:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a031a5:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a031a9:	8d 73 08             	lea    esi,[rbx+0x8]
    710d54a031ac:	89 f0                	mov    eax,esi
    710d54a031ae:	c1 e8 0c             	shr    eax,0xc
    710d54a031b1:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a031b6:	48 85 c0             	test   rax,rax
    710d54a031b9:	0f 84 8a 14 00 18    	je     0x710d6ca04649
    710d54a031bf:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a031c5:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a031c8:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    710d54a031cc:	8d 73 0c             	lea    esi,[rbx+0xc]
    710d54a031cf:	89 f0                	mov    eax,esi
    710d54a031d1:	c1 e8 0c             	shr    eax,0xc
    710d54a031d4:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a031d9:	48 85 c0             	test   rax,rax
    710d54a031dc:	0f 84 a3 14 00 18    	je     0x710d6ca04685
    710d54a031e2:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a031e8:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a031eb:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a031ef:	89 de                	mov    esi,ebx
    710d54a031f1:	83 c6 10             	add    esi,0x10
    710d54a031f4:	89 f0                	mov    eax,esi
    710d54a031f6:	c1 e8 0c             	shr    eax,0xc
    710d54a031f9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a031fe:	48 85 c0             	test   rax,rax
    710d54a03201:	0f 84 ba 14 00 18    	je     0x710d6ca046c1
    710d54a03207:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a0320d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a03210:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    710d54a03214:	8d 43 14             	lea    eax,[rbx+0x14]
    710d54a03217:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    710d54a0321b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    710d54a03222:	6c 03 01 00 
    710d54a03226:	0f 84 d1 14 00 18    	je     0x710d6ca046fd
    710d54a0322c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    710d54a03233:	6c 03 01 00 
    710d54a03237:	0f 84 c0 14 00 18    	je     0x710d6ca046fd
    710d54a0323d:	58                   	pop    rax
    710d54a0323e:	50                   	push   rax
    710d54a0323f:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a03246:	a8 01                	test   al,0x1
    710d54a03248:	0f 85 f8 14 00 18    	jne    0x710d6ca04746
    710d54a0324e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a03255:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a0325c:	01 
    710d54a0325d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    710d54a03264:	6e 03 01 00 
    710d54a03268:	0f 84 0e 15 00 18    	je     0x710d6ca0477c
    710d54a0326e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    710d54a03275:	6e 03 01 00 
    710d54a03279:	0f 84 fd 14 00 18    	je     0x710d6ca0477c
    710d54a0327f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a03286:	02 00 00 00 
    710d54a0328a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d54a03291:	03 00 00 00 
    710d54a03295:	58                   	pop    rax
    710d54a03296:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a0329d:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a032a4:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a032ab:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a032b2:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a032b9:	39 f1                	cmp    ecx,esi
    710d54a032bb:	0f 83 e8 14 00 18    	jae    0x710d6ca047a9
    710d54a032c1:	81 fa 68 03 01 00    	cmp    edx,0x10368
    710d54a032c7:	75 14                	jne    0x710d54a032dd
    710d54a032c9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a032d0:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a032d7:	00 
    710d54a032d8:	e9 c3 fd ff ff       	jmp    0x710d54a030a0
    710d54a032dd:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a032e4:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a032ea:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a032ed:	0f 85 b6 14 00 18    	jne    0x710d6ca047a9
    710d54a032f3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a032fa:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03301:	00 
    710d54a03302:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a03307:	ff e0                	jmp    rax
