
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66578-1-124302068296928.bin:     file format binary


Disassembly of section .data:

0000710d54a02ce0 <.data>:
    710d54a02ce0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a02ce7:	8b 88 1c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10001c]
    710d54a02ced:	ff c1                	inc    ecx
    710d54a02cef:	89 88 1c 00 10 00    	mov    DWORD PTR [rax+0x10001c],ecx
    710d54a02cf5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a02cfb:	0f 84 df 11 00 18    	je     0x710d6ca03ee0
    710d54a02d01:	50                   	push   rax
    710d54a02d02:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a02d06:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02d0d:	31 d2                	xor    edx,edx
    710d54a02d0f:	89 c6                	mov    esi,eax
    710d54a02d11:	ff c6                	inc    esi
    710d54a02d13:	0f 94 c2             	sete   dl
    710d54a02d16:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    710d54a02d1a:	c1 e8 1f             	shr    eax,0x1f
    710d54a02d1d:	89 f7                	mov    edi,esi
    710d54a02d1f:	c1 ef 1f             	shr    edi,0x1f
    710d54a02d22:	f7 d0                	not    eax
    710d54a02d24:	21 f8                	and    eax,edi
    710d54a02d26:	31 db                	xor    ebx,ebx
    710d54a02d28:	85 f6                	test   esi,esi
    710d54a02d2a:	0f 94 c3             	sete   bl
    710d54a02d2d:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    710d54a02d34:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a02d3b:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    710d54a02d42:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a02d49:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    710d54a02d50:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    710d54a02d57:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    710d54a02d5e:	81 f9 12 04 01 00    	cmp    ecx,0x10412
    710d54a02d64:	0f 84 a2 11 00 18    	je     0x710d6ca03f0c
    710d54a02d6a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10412
    710d54a02d71:	12 04 01 00 
    710d54a02d75:	0f 84 91 11 00 18    	je     0x710d6ca03f0c
    710d54a02d7b:	58                   	pop    rax
    710d54a02d7c:	50                   	push   rax
    710d54a02d7d:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a02d81:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02d88:	31 d2                	xor    edx,edx
    710d54a02d8a:	41 23 45 00          	and    eax,DWORD PTR [r13+0x0]
    710d54a02d8e:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a02d92:	0f 94 c2             	sete   dl
    710d54a02d95:	c1 e8 1f             	shr    eax,0x1f
    710d54a02d98:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a02d9f:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a02da6:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a02dad:	00 00 00 00 
    710d54a02db1:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a02db8:	00 00 00 00 
    710d54a02dbc:	81 f9 14 04 01 00    	cmp    ecx,0x10414
    710d54a02dc2:	0f 84 a4 11 00 18    	je     0x710d6ca03f6c
    710d54a02dc8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10414
    710d54a02dcf:	14 04 01 00 
    710d54a02dd3:	0f 84 93 11 00 18    	je     0x710d6ca03f6c
    710d54a02dd9:	58                   	pop    rax
    710d54a02dda:	50                   	push   rax
    710d54a02ddb:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a02ddf:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02de6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a02dea:	81 f9 16 04 01 00    	cmp    ecx,0x10416
    710d54a02df0:	0f 84 d6 11 00 18    	je     0x710d6ca03fcc
    710d54a02df6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10416
    710d54a02dfd:	16 04 01 00 
    710d54a02e01:	0f 84 c5 11 00 18    	je     0x710d6ca03fcc
    710d54a02e07:	58                   	pop    rax
    710d54a02e08:	50                   	push   rax
    710d54a02e09:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    710d54a02e0d:	f6 c3 03             	test   bl,0x3
    710d54a02e10:	0f 85 16 12 00 18    	jne    0x710d6ca0402c
    710d54a02e16:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02e1d:	48 89 d9             	mov    rcx,rbx
    710d54a02e20:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a02e24:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a02e28:	48 85 c0             	test   rax,rax
    710d54a02e2b:	0f 84 4d 12 00 18    	je     0x710d6ca0407e
    710d54a02e31:	89 d9                	mov    ecx,ebx
    710d54a02e33:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a02e39:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a02e3c:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    710d54a02e40:	83 c3 04             	add    ebx,0x4
    710d54a02e43:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    710d54a02e47:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10418
    710d54a02e4e:	18 04 01 00 
    710d54a02e52:	0f 84 61 12 00 18    	je     0x710d6ca040b9
    710d54a02e58:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10418
    710d54a02e5f:	18 04 01 00 
    710d54a02e63:	0f 84 50 12 00 18    	je     0x710d6ca040b9
    710d54a02e69:	58                   	pop    rax
    710d54a02e6a:	50                   	push   rax
    710d54a02e6b:	41 8b 45 30          	mov    eax,DWORD PTR [r13+0x30]
    710d54a02e6f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02e76:	c1 e0 02             	shl    eax,0x2
    710d54a02e79:	41 03 45 20          	add    eax,DWORD PTR [r13+0x20]
    710d54a02e7d:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a02e81:	81 f9 1a 04 01 00    	cmp    ecx,0x1041a
    710d54a02e87:	0f 84 75 12 00 18    	je     0x710d6ca04102
    710d54a02e8d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1041a
    710d54a02e94:	1a 04 01 00 
    710d54a02e98:	0f 84 64 12 00 18    	je     0x710d6ca04102
    710d54a02e9e:	58                   	pop    rax
    710d54a02e9f:	50                   	push   rax
    710d54a02ea0:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    710d54a02ea4:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02eab:	c1 e0 02             	shl    eax,0x2
    710d54a02eae:	41 03 45 2c          	add    eax,DWORD PTR [r13+0x2c]
    710d54a02eb2:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    710d54a02eb6:	81 f9 1c 04 01 00    	cmp    ecx,0x1041c
    710d54a02ebc:	0f 84 a0 12 00 18    	je     0x710d6ca04162
    710d54a02ec2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1041c
    710d54a02ec9:	1c 04 01 00 
    710d54a02ecd:	0f 84 8f 12 00 18    	je     0x710d6ca04162
    710d54a02ed3:	58                   	pop    rax
    710d54a02ed4:	50                   	push   rax
    710d54a02ed5:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    710d54a02ed9:	f6 c1 03             	test   cl,0x3
    710d54a02edc:	0f 85 e0 12 00 18    	jne    0x710d6ca041c2
    710d54a02ee2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02ee9:	48 89 ca             	mov    rdx,rcx
    710d54a02eec:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a02ef0:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a02ef4:	48 85 c0             	test   rax,rax
    710d54a02ef7:	0f 84 15 13 00 18    	je     0x710d6ca04212
    710d54a02efd:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a02f03:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a02f06:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a02f0a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1041e
    710d54a02f11:	1e 04 01 00 
    710d54a02f15:	0f 84 32 13 00 18    	je     0x710d6ca0424d
    710d54a02f1b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1041e
    710d54a02f22:	1e 04 01 00 
    710d54a02f26:	0f 84 21 13 00 18    	je     0x710d6ca0424d
    710d54a02f2c:	58                   	pop    rax
    710d54a02f2d:	50                   	push   rax
    710d54a02f2e:	41 8b 4d 24          	mov    ecx,DWORD PTR [r13+0x24]
    710d54a02f32:	f6 c1 03             	test   cl,0x3
    710d54a02f35:	0f 85 5b 13 00 18    	jne    0x710d6ca04296
    710d54a02f3b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a02f42:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    710d54a02f46:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02f4d:	48 89 ce             	mov    rsi,rcx
    710d54a02f50:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a02f54:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a02f58:	48 85 c0             	test   rax,rax
    710d54a02f5b:	0f 84 88 13 00 18    	je     0x710d6ca042e9
    710d54a02f61:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a02f67:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a02f6a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10420
    710d54a02f71:	20 04 01 00 
    710d54a02f75:	0f 84 a9 13 00 18    	je     0x710d6ca04324
    710d54a02f7b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10420
    710d54a02f82:	20 04 01 00 
    710d54a02f86:	0f 84 98 13 00 18    	je     0x710d6ca04324
    710d54a02f8c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a02f8f:	0f 85 d0 13 00 18    	jne    0x710d6ca04365
    710d54a02f95:	58                   	pop    rax
    710d54a02f96:	e9 0f 00 00 00       	jmp    0x710d54a02faa
    710d54a02f9b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a02fa2:	00 
    710d54a02fa3:	74 f0                	je     0x710d54a02f95
    710d54a02fa5:	e9 23 13 00 18       	jmp    0x710d6ca042cd
    710d54a02faa:	50                   	push   rax
    710d54a02fab:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a02fb2:	00 
    710d54a02fb3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10422
    710d54a02fba:	22 04 01 00 
    710d54a02fbe:	0f 84 d3 13 00 18    	je     0x710d6ca04397
    710d54a02fc4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10422
    710d54a02fcb:	22 04 01 00 
    710d54a02fcf:	0f 84 c2 13 00 18    	je     0x710d6ca04397
    710d54a02fd5:	58                   	pop    rax
    710d54a02fd6:	50                   	push   rax
    710d54a02fd7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a02fde:	01 
    710d54a02fdf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10424
    710d54a02fe6:	24 04 01 00 
    710d54a02fea:	0f 84 07 14 00 18    	je     0x710d6ca043f7
    710d54a02ff0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10424
    710d54a02ff7:	24 04 01 00 
    710d54a02ffb:	0f 84 f6 13 00 18    	je     0x710d6ca043f7
    710d54a03001:	b8 24 04 01 00       	mov    eax,0x10424
    710d54a03006:	05 44 ff ff ff       	add    eax,0xffffff44
    710d54a0300b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a03012:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a03019:	02 00 00 00 
    710d54a0301d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d54a03024:	0a 00 00 00 
    710d54a03028:	58                   	pop    rax
    710d54a03029:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03030:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a03037:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0303e:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a03045:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a0304c:	39 f1                	cmp    ecx,esi
    710d54a0304e:	0f 83 e1 13 00 18    	jae    0x710d6ca04435
    710d54a03054:	81 fa 12 04 01 00    	cmp    edx,0x10412
    710d54a0305a:	75 14                	jne    0x710d54a03070
    710d54a0305c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03063:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a0306a:	00 
    710d54a0306b:	e9 70 fc ff ff       	jmp    0x710d54a02ce0
    710d54a03070:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a03077:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a0307d:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a03080:	0f 85 af 13 00 18    	jne    0x710d6ca04435
    710d54a03086:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0308d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03094:	00 
    710d54a03095:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a0309a:	ff e0                	jmp    rax
