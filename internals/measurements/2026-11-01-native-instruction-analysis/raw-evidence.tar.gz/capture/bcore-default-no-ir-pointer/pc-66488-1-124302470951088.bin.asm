
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66488-1-124302470951088.bin:     file format binary


Disassembly of section .data:

0000710d6ca030b0 <.data>:
    710d6ca030b0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca030b6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca030b9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca030bf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca030c6:	0f 87 45 f2 ff e7    	ja     0x710d54a02311
    710d6ca030cc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x5
    710d6ca030d3:	05 00 00 00 
    710d6ca030d7:	e9 35 f2 ff e7       	jmp    0x710d54a02311
    710d6ca030dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103b8
    710d6ca030e3:	b8 03 01 00 
    710d6ca030e7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca030ee:	02 00 00 00 
    710d6ca030f2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca030f9:	01 00 00 00 
    710d6ca030fd:	ba b8 03 01 00       	mov    edx,0x103b8
    710d6ca03102:	4c 89 ef             	mov    rdi,r13
    710d6ca03105:	4c 89 f6             	mov    rsi,r14
    710d6ca03108:	89 d9                	mov    ecx,ebx
    710d6ca0310a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca03110:	e8 6b cf ff e7       	call   0x710d54a00080
    710d6ca03115:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0311c:	02 00 00 00 
    710d6ca03120:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca03127:	01 00 00 00 
    710d6ca0312b:	58                   	pop    rax
    710d6ca0312c:	e9 78 f5 ff e7       	jmp    0x710d54a026a9
    710d6ca03131:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103b8
    710d6ca03138:	b8 03 01 00 
    710d6ca0313c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03143:	02 00 00 00 
    710d6ca03147:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0314e:	01 00 00 00 
    710d6ca03152:	4c 89 f7             	mov    rdi,r14
    710d6ca03155:	89 de                	mov    esi,ebx
    710d6ca03157:	e8 14 cf ff e7       	call   0x710d54a00070
    710d6ca0315c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03163:	00 
    710d6ca03164:	0f 84 e6 f1 ff e7    	je     0x710d54a02350
    710d6ca0316a:	eb a9                	jmp    0x710d6ca03115
    710d6ca0316c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103b8
    710d6ca03173:	b8 03 01 00 
    710d6ca03177:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d6ca0317c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03183:	02 00 00 00 
    710d6ca03187:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0318e:	01 00 00 00 
    710d6ca03192:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03195:	be b8 03 01 00       	mov    esi,0x103b8
    710d6ca0319a:	4c 89 ef             	mov    rdi,r13
    710d6ca0319d:	e8 be cf ff e7       	call   0x710d54a00160
    710d6ca031a2:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d6ca031a6:	0f 84 dd f1 ff e7    	je     0x710d54a02389
    710d6ca031ac:	eb 0f                	jmp    0x710d6ca031bd
    710d6ca031ae:	b8 b8 03 01 00       	mov    eax,0x103b8
    710d6ca031b3:	83 c0 02             	add    eax,0x2
    710d6ca031b6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca031bd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca031c4:	02 00 00 00 
    710d6ca031c8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca031cf:	01 00 00 00 
    710d6ca031d3:	4c 89 ef             	mov    rdi,r13
    710d6ca031d6:	e8 75 cf ff e7       	call   0x710d54a00150
    710d6ca031db:	e9 a9 f1 ff e7       	jmp    0x710d54a02389
    710d6ca031e0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ba
    710d6ca031e7:	ba 03 01 00 
    710d6ca031eb:	b8 ba 03 01 00       	mov    eax,0x103ba
    710d6ca031f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca031f7:	02 00 00 00 
    710d6ca031fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca03202:	02 00 00 00 
    710d6ca03206:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03209:	be ba 03 01 00       	mov    esi,0x103ba
    710d6ca0320e:	4c 89 ef             	mov    rdi,r13
    710d6ca03211:	e8 4a cf ff e7       	call   0x710d54a00160
    710d6ca03216:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0321d:	00 
    710d6ca0321e:	0f 84 ee f1 ff e7    	je     0x710d54a02412
    710d6ca03224:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0322b:	02 00 00 00 
    710d6ca0322f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca03236:	02 00 00 00 
    710d6ca0323a:	58                   	pop    rax
    710d6ca0323b:	e9 69 f4 ff e7       	jmp    0x710d54a026a9
    710d6ca03240:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103bc
    710d6ca03247:	bc 03 01 00 
    710d6ca0324b:	b8 bc 03 01 00       	mov    eax,0x103bc
    710d6ca03250:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03257:	04 00 00 00 
    710d6ca0325b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca03262:	03 00 00 00 
    710d6ca03266:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03269:	be bc 03 01 00       	mov    esi,0x103bc
    710d6ca0326e:	4c 89 ef             	mov    rdi,r13
    710d6ca03271:	e8 ea ce ff e7       	call   0x710d54a00160
    710d6ca03276:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0327d:	00 
    710d6ca0327e:	0f 84 c2 f1 ff e7    	je     0x710d54a02446
    710d6ca03284:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0328b:	04 00 00 00 
    710d6ca0328f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca03296:	03 00 00 00 
    710d6ca0329a:	58                   	pop    rax
    710d6ca0329b:	e9 09 f4 ff e7       	jmp    0x710d54a026a9
    710d6ca032a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103c0
    710d6ca032a7:	c0 03 01 00 
    710d6ca032ab:	b8 c0 03 01 00       	mov    eax,0x103c0
    710d6ca032b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca032b7:	04 00 00 00 
    710d6ca032bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca032c2:	04 00 00 00 
    710d6ca032c6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca032c9:	be c0 03 01 00       	mov    esi,0x103c0
    710d6ca032ce:	4c 89 ef             	mov    rdi,r13
    710d6ca032d1:	e8 8a ce ff e7       	call   0x710d54a00160
    710d6ca032d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca032dd:	00 
    710d6ca032de:	0f 84 99 f1 ff e7    	je     0x710d54a0247d
    710d6ca032e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca032eb:	04 00 00 00 
    710d6ca032ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca032f6:	04 00 00 00 
    710d6ca032fa:	58                   	pop    rax
    710d6ca032fb:	e9 a9 f3 ff e7       	jmp    0x710d54a026a9
    710d6ca03300:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103c4
    710d6ca03307:	c4 03 01 00 
    710d6ca0330b:	b8 c4 03 01 00       	mov    eax,0x103c4
    710d6ca03310:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03317:	02 00 00 00 
    710d6ca0331b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca03322:	05 00 00 00 
    710d6ca03326:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03329:	be c4 03 01 00       	mov    esi,0x103c4
    710d6ca0332e:	4c 89 ef             	mov    rdi,r13
    710d6ca03331:	e8 2a ce ff e7       	call   0x710d54a00160
    710d6ca03336:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0333d:	00 
    710d6ca0333e:	0f 84 67 f1 ff e7    	je     0x710d54a024ab
    710d6ca03344:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0334b:	02 00 00 00 
    710d6ca0334f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca03356:	05 00 00 00 
    710d6ca0335a:	58                   	pop    rax
    710d6ca0335b:	e9 49 f3 ff e7       	jmp    0x710d54a026a9
    710d6ca03360:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103c6
    710d6ca03367:	c6 03 01 00 
    710d6ca0336b:	b8 c6 03 01 00       	mov    eax,0x103c6
    710d6ca03370:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03377:	04 00 00 00 
    710d6ca0337b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca03382:	06 00 00 00 
    710d6ca03386:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03389:	be c6 03 01 00       	mov    esi,0x103c6
    710d6ca0338e:	4c 89 ef             	mov    rdi,r13
    710d6ca03391:	e8 ca cd ff e7       	call   0x710d54a00160
    710d6ca03396:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0339d:	00 
    710d6ca0339e:	0f 84 3b f1 ff e7    	je     0x710d54a024df
    710d6ca033a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca033ab:	04 00 00 00 
    710d6ca033af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca033b6:	06 00 00 00 
    710d6ca033ba:	58                   	pop    rax
    710d6ca033bb:	e9 e9 f2 ff e7       	jmp    0x710d54a026a9
    710d6ca033c0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ca
    710d6ca033c7:	ca 03 01 00 
    710d6ca033cb:	b8 ca 03 01 00       	mov    eax,0x103ca
    710d6ca033d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca033d7:	04 00 00 00 
    710d6ca033db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca033e2:	07 00 00 00 
    710d6ca033e6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca033e9:	be ca 03 01 00       	mov    esi,0x103ca
    710d6ca033ee:	4c 89 ef             	mov    rdi,r13
    710d6ca033f1:	e8 6a cd ff e7       	call   0x710d54a00160
    710d6ca033f6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca033fd:	00 
    710d6ca033fe:	0f 84 0f f1 ff e7    	je     0x710d54a02513
    710d6ca03404:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0340b:	04 00 00 00 
    710d6ca0340f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca03416:	07 00 00 00 
    710d6ca0341a:	58                   	pop    rax
    710d6ca0341b:	e9 89 f2 ff e7       	jmp    0x710d54a026a9
    710d6ca03420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ce
    710d6ca03427:	ce 03 01 00 
    710d6ca0342b:	b8 ce 03 01 00       	mov    eax,0x103ce
    710d6ca03430:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03437:	02 00 00 00 
    710d6ca0343b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03442:	08 00 00 00 
    710d6ca03446:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03449:	be ce 03 01 00       	mov    esi,0x103ce
    710d6ca0344e:	4c 89 ef             	mov    rdi,r13
    710d6ca03451:	e8 0a cd ff e7       	call   0x710d54a00160
    710d6ca03456:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0345d:	00 
    710d6ca0345e:	0f 84 dd f0 ff e7    	je     0x710d54a02541
    710d6ca03464:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0346b:	02 00 00 00 
    710d6ca0346f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03476:	08 00 00 00 
    710d6ca0347a:	58                   	pop    rax
    710d6ca0347b:	e9 29 f2 ff e7       	jmp    0x710d54a026a9
    710d6ca03480:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103d0
    710d6ca03487:	d0 03 01 00 
    710d6ca0348b:	b8 d0 03 01 00       	mov    eax,0x103d0
    710d6ca03490:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03497:	04 00 00 00 
    710d6ca0349b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca034a2:	09 00 00 00 
    710d6ca034a6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca034a9:	be d0 03 01 00       	mov    esi,0x103d0
    710d6ca034ae:	4c 89 ef             	mov    rdi,r13
    710d6ca034b1:	e8 aa cc ff e7       	call   0x710d54a00160
    710d6ca034b6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca034bd:	00 
    710d6ca034be:	0f 84 b4 f0 ff e7    	je     0x710d54a02578
    710d6ca034c4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca034cb:	04 00 00 00 
    710d6ca034cf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca034d6:	09 00 00 00 
    710d6ca034da:	58                   	pop    rax
    710d6ca034db:	e9 c9 f1 ff e7       	jmp    0x710d54a026a9
    710d6ca034e0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103d4
    710d6ca034e7:	d4 03 01 00 
    710d6ca034eb:	b8 d4 03 01 00       	mov    eax,0x103d4
    710d6ca034f0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca034f7:	04 00 00 00 
    710d6ca034fb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03502:	0a 00 00 00 
    710d6ca03506:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03509:	be d4 03 01 00       	mov    esi,0x103d4
    710d6ca0350e:	4c 89 ef             	mov    rdi,r13
    710d6ca03511:	e8 4a cc ff e7       	call   0x710d54a00160
    710d6ca03516:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0351d:	00 
    710d6ca0351e:	0f 84 8b f0 ff e7    	je     0x710d54a025af
    710d6ca03524:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0352b:	04 00 00 00 
    710d6ca0352f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03536:	0a 00 00 00 
    710d6ca0353a:	58                   	pop    rax
    710d6ca0353b:	e9 69 f1 ff e7       	jmp    0x710d54a026a9
    710d6ca03540:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103d8
    710d6ca03547:	d8 03 01 00 
    710d6ca0354b:	b8 d8 03 01 00       	mov    eax,0x103d8
    710d6ca03550:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03557:	04 00 00 00 
    710d6ca0355b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca03562:	0b 00 00 00 
    710d6ca03566:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03569:	be d8 03 01 00       	mov    esi,0x103d8
    710d6ca0356e:	4c 89 ef             	mov    rdi,r13
    710d6ca03571:	e8 ea cb ff e7       	call   0x710d54a00160
    710d6ca03576:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0357d:	00 
    710d6ca0357e:	0f 84 57 f0 ff e7    	je     0x710d54a025db
    710d6ca03584:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0358b:	04 00 00 00 
    710d6ca0358f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca03596:	0b 00 00 00 
    710d6ca0359a:	58                   	pop    rax
    710d6ca0359b:	e9 09 f1 ff e7       	jmp    0x710d54a026a9
    710d6ca035a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103dc
    710d6ca035a7:	dc 03 01 00 
    710d6ca035ab:	b8 dc 03 01 00       	mov    eax,0x103dc
    710d6ca035b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca035b7:	04 00 00 00 
    710d6ca035bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca035c2:	0c 00 00 00 
    710d6ca035c6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca035c9:	be dc 03 01 00       	mov    esi,0x103dc
    710d6ca035ce:	4c 89 ef             	mov    rdi,r13
    710d6ca035d1:	e8 8a cb ff e7       	call   0x710d54a00160
    710d6ca035d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca035dd:	00 
    710d6ca035de:	0f 84 23 f0 ff e7    	je     0x710d54a02607
    710d6ca035e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca035eb:	04 00 00 00 
    710d6ca035ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca035f6:	0c 00 00 00 
    710d6ca035fa:	58                   	pop    rax
    710d6ca035fb:	e9 a9 f0 ff e7       	jmp    0x710d54a026a9
    710d6ca03600:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103e0
    710d6ca03607:	e0 03 01 00 
    710d6ca0360b:	b8 e0 03 01 00       	mov    eax,0x103e0
    710d6ca03610:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03617:	02 00 00 00 
    710d6ca0361b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca03622:	0d 00 00 00 
    710d6ca03626:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03629:	be e0 03 01 00       	mov    esi,0x103e0
    710d6ca0362e:	4c 89 ef             	mov    rdi,r13
    710d6ca03631:	e8 2a cb ff e7       	call   0x710d54a00160
    710d6ca03636:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0363d:	00 
    710d6ca0363e:	0f 84 f1 ef ff e7    	je     0x710d54a02635
    710d6ca03644:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0364b:	02 00 00 00 
    710d6ca0364f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca03656:	0d 00 00 00 
    710d6ca0365a:	58                   	pop    rax
    710d6ca0365b:	e9 49 f0 ff e7       	jmp    0x710d54a026a9
    710d6ca03660:	b8 e2 03 01 00       	mov    eax,0x103e2
    710d6ca03665:	83 c0 04             	add    eax,0x4
    710d6ca03668:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0366f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03676:	04 00 00 00 
    710d6ca0367a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca03681:	0e 00 00 00 
    710d6ca03685:	be e2 03 01 00       	mov    esi,0x103e2
    710d6ca0368a:	ba e2 03 01 00       	mov    edx,0x103e2
    710d6ca0368f:	4c 89 ef             	mov    rdi,r13
    710d6ca03692:	e8 c9 ca ff e7       	call   0x710d54a00160
    710d6ca03697:	e9 e7 ef ff e7       	jmp    0x710d54a02683
    710d6ca0369c:	c2 08 00             	ret    0x8
