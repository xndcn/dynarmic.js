
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65600-1-124302470942144.bin:     file format binary


Disassembly of section .data:

0000710d6ca00dc0 <.data>:
    710d6ca00dc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    710d6ca00dc7:	40 00 01 00 
    710d6ca00dcb:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    710d6ca00dd2:	01 
    710d6ca00dd3:	c2 08 00             	ret    0x8
    710d6ca00dd6:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca00ddc:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca00ddf:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca00de5:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca00dec:	0f 87 c8 fe ff e7    	ja     0x710d54a00cba
    710d6ca00df2:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x2
    710d6ca00df9:	02 00 00 00 
    710d6ca00dfd:	e9 b8 fe ff e7       	jmp    0x710d54a00cba
    710d6ca00e02:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    710d6ca00e09:	40 00 01 00 
    710d6ca00e0d:	b8 40 00 01 00       	mov    eax,0x10040
    710d6ca00e12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00e19:	04 00 00 00 
    710d6ca00e1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00e24:	01 00 00 00 
    710d6ca00e28:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca00e2b:	be 40 00 01 00       	mov    esi,0x10040
    710d6ca00e30:	4c 89 ef             	mov    rdi,r13
    710d6ca00e33:	e8 28 f3 ff e7       	call   0x710d54a00160
    710d6ca00e38:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00e3f:	00 
    710d6ca00e40:	0f 84 9f fe ff e7    	je     0x710d54a00ce5
    710d6ca00e46:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00e4d:	04 00 00 00 
    710d6ca00e51:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00e58:	01 00 00 00 
    710d6ca00e5c:	58                   	pop    rax
    710d6ca00e5d:	e9 e0 05 00 e8       	jmp    0x710d54a01442
    710d6ca00e62:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10044
    710d6ca00e69:	44 00 01 00 
    710d6ca00e6d:	b8 44 00 01 00       	mov    eax,0x10044
    710d6ca00e72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00e79:	02 00 00 00 
    710d6ca00e7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca00e84:	02 00 00 00 
    710d6ca00e88:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00e8b:	be 44 00 01 00       	mov    esi,0x10044
    710d6ca00e90:	4c 89 ef             	mov    rdi,r13
    710d6ca00e93:	e8 c8 f2 ff e7       	call   0x710d54a00160
    710d6ca00e98:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00e9f:	00 
    710d6ca00ea0:	0f 84 68 fe ff e7    	je     0x710d54a00d0e
    710d6ca00ea6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00ead:	02 00 00 00 
    710d6ca00eb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca00eb8:	02 00 00 00 
    710d6ca00ebc:	58                   	pop    rax
    710d6ca00ebd:	e9 80 05 00 e8       	jmp    0x710d54a01442
    710d6ca00ec2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    710d6ca00ec9:	46 00 01 00 
    710d6ca00ecd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00ed4:	02 00 00 00 
    710d6ca00ed8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00edf:	03 00 00 00 
    710d6ca00ee3:	ba 46 00 01 00       	mov    edx,0x10046
    710d6ca00ee8:	4c 89 ef             	mov    rdi,r13
    710d6ca00eeb:	4c 89 f6             	mov    rsi,r14
    710d6ca00eee:	45 31 c0             	xor    r8d,r8d
    710d6ca00ef1:	e8 8a f1 ff e7       	call   0x710d54a00080
    710d6ca00ef6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00efd:	02 00 00 00 
    710d6ca00f01:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00f08:	03 00 00 00 
    710d6ca00f0c:	58                   	pop    rax
    710d6ca00f0d:	e9 30 05 00 e8       	jmp    0x710d54a01442
    710d6ca00f12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    710d6ca00f19:	46 00 01 00 
    710d6ca00f1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00f24:	02 00 00 00 
    710d6ca00f28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00f2f:	03 00 00 00 
    710d6ca00f33:	4c 89 f7             	mov    rdi,r14
    710d6ca00f36:	89 ce                	mov    esi,ecx
    710d6ca00f38:	e8 03 f1 ff e7       	call   0x710d54a00040
    710d6ca00f3d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00f44:	00 
    710d6ca00f45:	0f 84 f6 fd ff e7    	je     0x710d54a00d41
    710d6ca00f4b:	eb a9                	jmp    0x710d6ca00ef6
    710d6ca00f4d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    710d6ca00f54:	46 00 01 00 
    710d6ca00f58:	b8 46 00 01 00       	mov    eax,0x10046
    710d6ca00f5d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00f64:	02 00 00 00 
    710d6ca00f68:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00f6f:	03 00 00 00 
    710d6ca00f73:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00f76:	be 46 00 01 00       	mov    esi,0x10046
    710d6ca00f7b:	4c 89 ef             	mov    rdi,r13
    710d6ca00f7e:	e8 dd f1 ff e7       	call   0x710d54a00160
    710d6ca00f83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00f8a:	00 
    710d6ca00f8b:	0f 84 d6 fd ff e7    	je     0x710d54a00d67
    710d6ca00f91:	e9 60 ff ff ff       	jmp    0x710d6ca00ef6
    710d6ca00f96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10048
    710d6ca00f9d:	48 00 01 00 
    710d6ca00fa1:	b8 48 00 01 00       	mov    eax,0x10048
    710d6ca00fa6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00fad:	02 00 00 00 
    710d6ca00fb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca00fb8:	04 00 00 00 
    710d6ca00fbc:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00fbf:	be 48 00 01 00       	mov    esi,0x10048
    710d6ca00fc4:	4c 89 ef             	mov    rdi,r13
    710d6ca00fc7:	e8 94 f1 ff e7       	call   0x710d54a00160
    710d6ca00fcc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00fd3:	00 
    710d6ca00fd4:	0f 84 b6 fd ff e7    	je     0x710d54a00d90
    710d6ca00fda:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00fe1:	02 00 00 00 
    710d6ca00fe5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca00fec:	04 00 00 00 
    710d6ca00ff0:	58                   	pop    rax
    710d6ca00ff1:	e9 4c 04 00 e8       	jmp    0x710d54a01442
    710d6ca00ff6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    710d6ca00ffd:	4a 00 01 00 
    710d6ca01001:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01008:	02 00 00 00 
    710d6ca0100c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca01013:	05 00 00 00 
    710d6ca01017:	ba 4a 00 01 00       	mov    edx,0x1004a
    710d6ca0101c:	4c 89 ef             	mov    rdi,r13
    710d6ca0101f:	4c 89 f6             	mov    rsi,r14
    710d6ca01022:	45 31 c0             	xor    r8d,r8d
    710d6ca01025:	e8 56 f0 ff e7       	call   0x710d54a00080
    710d6ca0102a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01031:	02 00 00 00 
    710d6ca01035:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0103c:	05 00 00 00 
    710d6ca01040:	58                   	pop    rax
    710d6ca01041:	e9 fc 03 00 e8       	jmp    0x710d54a01442
    710d6ca01046:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    710d6ca0104d:	4a 00 01 00 
    710d6ca01051:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01058:	02 00 00 00 
    710d6ca0105c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca01063:	05 00 00 00 
    710d6ca01067:	4c 89 f7             	mov    rdi,r14
    710d6ca0106a:	89 ce                	mov    esi,ecx
    710d6ca0106c:	e8 cf ef ff e7       	call   0x710d54a00040
    710d6ca01071:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01078:	00 
    710d6ca01079:	0f 84 44 fd ff e7    	je     0x710d54a00dc3
    710d6ca0107f:	eb a9                	jmp    0x710d6ca0102a
    710d6ca01081:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    710d6ca01088:	4a 00 01 00 
    710d6ca0108c:	b8 4a 00 01 00       	mov    eax,0x1004a
    710d6ca01091:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01098:	02 00 00 00 
    710d6ca0109c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca010a3:	05 00 00 00 
    710d6ca010a7:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca010aa:	be 4a 00 01 00       	mov    esi,0x1004a
    710d6ca010af:	4c 89 ef             	mov    rdi,r13
    710d6ca010b2:	e8 a9 f0 ff e7       	call   0x710d54a00160
    710d6ca010b7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca010be:	00 
    710d6ca010bf:	0f 84 24 fd ff e7    	je     0x710d54a00de9
    710d6ca010c5:	e9 60 ff ff ff       	jmp    0x710d6ca0102a
    710d6ca010ca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004c
    710d6ca010d1:	4c 00 01 00 
    710d6ca010d5:	b8 4c 00 01 00       	mov    eax,0x1004c
    710d6ca010da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca010e1:	02 00 00 00 
    710d6ca010e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca010ec:	06 00 00 00 
    710d6ca010f0:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca010f3:	be 4c 00 01 00       	mov    esi,0x1004c
    710d6ca010f8:	4c 89 ef             	mov    rdi,r13
    710d6ca010fb:	e8 60 f0 ff e7       	call   0x710d54a00160
    710d6ca01100:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01107:	00 
    710d6ca01108:	0f 84 07 fd ff e7    	je     0x710d54a00e15
    710d6ca0110e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01115:	02 00 00 00 
    710d6ca01119:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca01120:	06 00 00 00 
    710d6ca01124:	58                   	pop    rax
    710d6ca01125:	e9 18 03 00 e8       	jmp    0x710d54a01442
    710d6ca0112a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004e
    710d6ca01131:	4e 00 01 00 
    710d6ca01135:	b8 4e 00 01 00       	mov    eax,0x1004e
    710d6ca0113a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01141:	04 00 00 00 
    710d6ca01145:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca0114c:	07 00 00 00 
    710d6ca01150:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01153:	be 4e 00 01 00       	mov    esi,0x1004e
    710d6ca01158:	4c 89 ef             	mov    rdi,r13
    710d6ca0115b:	e8 00 f0 ff e7       	call   0x710d54a00160
    710d6ca01160:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01167:	00 
    710d6ca01168:	0f 84 d3 fc ff e7    	je     0x710d54a00e41
    710d6ca0116e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01175:	04 00 00 00 
    710d6ca01179:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca01180:	07 00 00 00 
    710d6ca01184:	58                   	pop    rax
    710d6ca01185:	e9 b8 02 00 e8       	jmp    0x710d54a01442
    710d6ca0118a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10052
    710d6ca01191:	52 00 01 00 
    710d6ca01195:	b8 52 00 01 00       	mov    eax,0x10052
    710d6ca0119a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca011a1:	02 00 00 00 
    710d6ca011a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca011ac:	08 00 00 00 
    710d6ca011b0:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca011b3:	be 52 00 01 00       	mov    esi,0x10052
    710d6ca011b8:	4c 89 ef             	mov    rdi,r13
    710d6ca011bb:	e8 a0 ef ff e7       	call   0x710d54a00160
    710d6ca011c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca011c7:	00 
    710d6ca011c8:	0f 84 9c fc ff e7    	je     0x710d54a00e6a
    710d6ca011ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca011d5:	02 00 00 00 
    710d6ca011d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca011e0:	08 00 00 00 
    710d6ca011e4:	58                   	pop    rax
    710d6ca011e5:	e9 58 02 00 e8       	jmp    0x710d54a01442
    710d6ca011ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    710d6ca011f1:	54 00 01 00 
    710d6ca011f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca011fc:	02 00 00 00 
    710d6ca01200:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca01207:	09 00 00 00 
    710d6ca0120b:	ba 54 00 01 00       	mov    edx,0x10054
    710d6ca01210:	4c 89 ef             	mov    rdi,r13
    710d6ca01213:	4c 89 f6             	mov    rsi,r14
    710d6ca01216:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca0121c:	e8 5f ee ff e7       	call   0x710d54a00080
    710d6ca01221:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01228:	02 00 00 00 
    710d6ca0122c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca01233:	09 00 00 00 
    710d6ca01237:	58                   	pop    rax
    710d6ca01238:	e9 05 02 00 e8       	jmp    0x710d54a01442
    710d6ca0123d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    710d6ca01244:	54 00 01 00 
    710d6ca01248:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0124f:	02 00 00 00 
    710d6ca01253:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca0125a:	09 00 00 00 
    710d6ca0125e:	4c 89 f7             	mov    rdi,r14
    710d6ca01261:	89 ce                	mov    esi,ecx
    710d6ca01263:	e8 08 ee ff e7       	call   0x710d54a00070
    710d6ca01268:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0126f:	00 
    710d6ca01270:	0f 84 32 fc ff e7    	je     0x710d54a00ea8
    710d6ca01276:	eb a9                	jmp    0x710d6ca01221
    710d6ca01278:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    710d6ca0127f:	54 00 01 00 
    710d6ca01283:	b8 54 00 01 00       	mov    eax,0x10054
    710d6ca01288:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0128f:	02 00 00 00 
    710d6ca01293:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca0129a:	09 00 00 00 
    710d6ca0129e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca012a1:	be 54 00 01 00       	mov    esi,0x10054
    710d6ca012a6:	4c 89 ef             	mov    rdi,r13
    710d6ca012a9:	e8 b2 ee ff e7       	call   0x710d54a00160
    710d6ca012ae:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca012b1:	0f 84 22 fc ff e7    	je     0x710d54a00ed9
    710d6ca012b7:	eb 0f                	jmp    0x710d6ca012c8
    710d6ca012b9:	b8 54 00 01 00       	mov    eax,0x10054
    710d6ca012be:	83 c0 02             	add    eax,0x2
    710d6ca012c1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca012c8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca012cf:	02 00 00 00 
    710d6ca012d3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca012da:	09 00 00 00 
    710d6ca012de:	4c 89 ef             	mov    rdi,r13
    710d6ca012e1:	e8 6a ee ff e7       	call   0x710d54a00150
    710d6ca012e6:	e9 ee fb ff e7       	jmp    0x710d54a00ed9
    710d6ca012eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    710d6ca012f2:	56 00 01 00 
    710d6ca012f6:	b8 56 00 01 00       	mov    eax,0x10056
    710d6ca012fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01302:	04 00 00 00 
    710d6ca01306:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0130d:	0a 00 00 00 
    710d6ca01311:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01314:	be 56 00 01 00       	mov    esi,0x10056
    710d6ca01319:	4c 89 ef             	mov    rdi,r13
    710d6ca0131c:	e8 3f ee ff e7       	call   0x710d54a00160
    710d6ca01321:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01328:	00 
    710d6ca01329:	0f 84 e4 fb ff e7    	je     0x710d54a00f13
    710d6ca0132f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01336:	04 00 00 00 
    710d6ca0133a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca01341:	0a 00 00 00 
    710d6ca01345:	58                   	pop    rax
    710d6ca01346:	e9 f7 00 00 e8       	jmp    0x710d54a01442
    710d6ca0134b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005a
    710d6ca01352:	5a 00 01 00 
    710d6ca01356:	b8 5a 00 01 00       	mov    eax,0x1005a
    710d6ca0135b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01362:	02 00 00 00 
    710d6ca01366:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca0136d:	0b 00 00 00 
    710d6ca01371:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01374:	be 5a 00 01 00       	mov    esi,0x1005a
    710d6ca01379:	4c 89 ef             	mov    rdi,r13
    710d6ca0137c:	e8 df ed ff e7       	call   0x710d54a00160
    710d6ca01381:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01388:	00 
    710d6ca01389:	0f 84 ad fb ff e7    	je     0x710d54a00f3c
    710d6ca0138f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01396:	02 00 00 00 
    710d6ca0139a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca013a1:	0b 00 00 00 
    710d6ca013a5:	58                   	pop    rax
    710d6ca013a6:	e9 97 00 00 e8       	jmp    0x710d54a01442
    710d6ca013ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    710d6ca013b2:	5c 00 01 00 
    710d6ca013b6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca013bd:	02 00 00 00 
    710d6ca013c1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca013c8:	0c 00 00 00 
    710d6ca013cc:	ba 5c 00 01 00       	mov    edx,0x1005c
    710d6ca013d1:	4c 89 ef             	mov    rdi,r13
    710d6ca013d4:	4c 89 f6             	mov    rsi,r14
    710d6ca013d7:	45 31 c0             	xor    r8d,r8d
    710d6ca013da:	e8 a1 ec ff e7       	call   0x710d54a00080
    710d6ca013df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca013e6:	02 00 00 00 
    710d6ca013ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca013f1:	0c 00 00 00 
    710d6ca013f5:	58                   	pop    rax
    710d6ca013f6:	e9 47 00 00 e8       	jmp    0x710d54a01442
    710d6ca013fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    710d6ca01402:	5c 00 01 00 
    710d6ca01406:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0140d:	02 00 00 00 
    710d6ca01411:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca01418:	0c 00 00 00 
    710d6ca0141c:	4c 89 f7             	mov    rdi,r14
    710d6ca0141f:	89 ce                	mov    esi,ecx
    710d6ca01421:	e8 1a ec ff e7       	call   0x710d54a00040
    710d6ca01426:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0142d:	00 
    710d6ca0142e:	0f 84 3b fb ff e7    	je     0x710d54a00f6f
    710d6ca01434:	eb a9                	jmp    0x710d6ca013df
    710d6ca01436:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    710d6ca0143d:	5c 00 01 00 
    710d6ca01441:	b8 5c 00 01 00       	mov    eax,0x1005c
    710d6ca01446:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0144d:	02 00 00 00 
    710d6ca01451:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca01458:	0c 00 00 00 
    710d6ca0145c:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0145f:	be 5c 00 01 00       	mov    esi,0x1005c
    710d6ca01464:	4c 89 ef             	mov    rdi,r13
    710d6ca01467:	e8 f4 ec ff e7       	call   0x710d54a00160
    710d6ca0146c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01473:	00 
    710d6ca01474:	0f 84 1b fb ff e7    	je     0x710d54a00f95
    710d6ca0147a:	e9 60 ff ff ff       	jmp    0x710d6ca013df
    710d6ca0147f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005e
    710d6ca01486:	5e 00 01 00 
    710d6ca0148a:	b8 5e 00 01 00       	mov    eax,0x1005e
    710d6ca0148f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01496:	04 00 00 00 
    710d6ca0149a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca014a1:	0d 00 00 00 
    710d6ca014a5:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca014a8:	be 5e 00 01 00       	mov    esi,0x1005e
    710d6ca014ad:	4c 89 ef             	mov    rdi,r13
    710d6ca014b0:	e8 ab ec ff e7       	call   0x710d54a00160
    710d6ca014b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca014bc:	00 
    710d6ca014bd:	0f 84 06 fb ff e7    	je     0x710d54a00fc9
    710d6ca014c3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca014ca:	04 00 00 00 
    710d6ca014ce:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca014d5:	0d 00 00 00 
    710d6ca014d9:	58                   	pop    rax
    710d6ca014da:	e9 63 ff ff e7       	jmp    0x710d54a01442
    710d6ca014df:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10062
    710d6ca014e6:	62 00 01 00 
    710d6ca014ea:	b8 62 00 01 00       	mov    eax,0x10062
    710d6ca014ef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca014f6:	04 00 00 00 
    710d6ca014fa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca01501:	0e 00 00 00 
    710d6ca01505:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01508:	be 62 00 01 00       	mov    esi,0x10062
    710d6ca0150d:	4c 89 ef             	mov    rdi,r13
    710d6ca01510:	e8 4b ec ff e7       	call   0x710d54a00160
    710d6ca01515:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0151c:	00 
    710d6ca0151d:	0f 84 da fa ff e7    	je     0x710d54a00ffd
    710d6ca01523:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0152a:	04 00 00 00 
    710d6ca0152e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca01535:	0e 00 00 00 
    710d6ca01539:	58                   	pop    rax
    710d6ca0153a:	e9 03 ff ff e7       	jmp    0x710d54a01442
    710d6ca0153f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10066
    710d6ca01546:	66 00 01 00 
    710d6ca0154a:	b8 66 00 01 00       	mov    eax,0x10066
    710d6ca0154f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01556:	04 00 00 00 
    710d6ca0155a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca01561:	0f 00 00 00 
    710d6ca01565:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01568:	be 66 00 01 00       	mov    esi,0x10066
    710d6ca0156d:	4c 89 ef             	mov    rdi,r13
    710d6ca01570:	e8 eb eb ff e7       	call   0x710d54a00160
    710d6ca01575:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0157c:	00 
    710d6ca0157d:	0f 84 b1 fa ff e7    	je     0x710d54a01034
    710d6ca01583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0158a:	04 00 00 00 
    710d6ca0158e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca01595:	0f 00 00 00 
    710d6ca01599:	58                   	pop    rax
    710d6ca0159a:	e9 a3 fe ff e7       	jmp    0x710d54a01442
    710d6ca0159f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    710d6ca015a6:	6a 00 01 00 
    710d6ca015aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca015b1:	02 00 00 00 
    710d6ca015b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca015bc:	10 00 00 00 
    710d6ca015c0:	ba 6a 00 01 00       	mov    edx,0x1006a
    710d6ca015c5:	4c 89 ef             	mov    rdi,r13
    710d6ca015c8:	4c 89 f6             	mov    rsi,r14
    710d6ca015cb:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca015d1:	e8 aa ea ff e7       	call   0x710d54a00080
    710d6ca015d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca015dd:	02 00 00 00 
    710d6ca015e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca015e8:	10 00 00 00 
    710d6ca015ec:	58                   	pop    rax
    710d6ca015ed:	e9 50 fe ff e7       	jmp    0x710d54a01442
    710d6ca015f2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    710d6ca015f9:	6a 00 01 00 
    710d6ca015fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01604:	02 00 00 00 
    710d6ca01608:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca0160f:	10 00 00 00 
    710d6ca01613:	4c 89 f7             	mov    rdi,r14
    710d6ca01616:	89 ce                	mov    esi,ecx
    710d6ca01618:	e8 53 ea ff e7       	call   0x710d54a00070
    710d6ca0161d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01624:	00 
    710d6ca01625:	0f 84 47 fa ff e7    	je     0x710d54a01072
    710d6ca0162b:	eb a9                	jmp    0x710d6ca015d6
    710d6ca0162d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    710d6ca01634:	6a 00 01 00 
    710d6ca01638:	b8 6a 00 01 00       	mov    eax,0x1006a
    710d6ca0163d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01644:	02 00 00 00 
    710d6ca01648:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca0164f:	10 00 00 00 
    710d6ca01653:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01656:	be 6a 00 01 00       	mov    esi,0x1006a
    710d6ca0165b:	4c 89 ef             	mov    rdi,r13
    710d6ca0165e:	e8 fd ea ff e7       	call   0x710d54a00160
    710d6ca01663:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca01666:	0f 84 37 fa ff e7    	je     0x710d54a010a3
    710d6ca0166c:	eb 0f                	jmp    0x710d6ca0167d
    710d6ca0166e:	b8 6a 00 01 00       	mov    eax,0x1006a
    710d6ca01673:	83 c0 02             	add    eax,0x2
    710d6ca01676:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0167d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01684:	02 00 00 00 
    710d6ca01688:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca0168f:	10 00 00 00 
    710d6ca01693:	4c 89 ef             	mov    rdi,r13
    710d6ca01696:	e8 b5 ea ff e7       	call   0x710d54a00150
    710d6ca0169b:	e9 03 fa ff e7       	jmp    0x710d54a010a3
    710d6ca016a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    710d6ca016a7:	6c 00 01 00 
    710d6ca016ab:	b8 6c 00 01 00       	mov    eax,0x1006c
    710d6ca016b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca016b7:	04 00 00 00 
    710d6ca016bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca016c2:	11 00 00 00 
    710d6ca016c6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca016c9:	be 6c 00 01 00       	mov    esi,0x1006c
    710d6ca016ce:	4c 89 ef             	mov    rdi,r13
    710d6ca016d1:	e8 8a ea ff e7       	call   0x710d54a00160
    710d6ca016d6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca016dd:	00 
    710d6ca016de:	0f 84 01 fa ff e7    	je     0x710d54a010e5
    710d6ca016e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca016eb:	04 00 00 00 
    710d6ca016ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca016f6:	11 00 00 00 
    710d6ca016fa:	58                   	pop    rax
    710d6ca016fb:	e9 42 fd ff e7       	jmp    0x710d54a01442
    710d6ca01700:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10070
    710d6ca01707:	70 00 01 00 
    710d6ca0170b:	b8 70 00 01 00       	mov    eax,0x10070
    710d6ca01710:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01717:	04 00 00 00 
    710d6ca0171b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca01722:	12 00 00 00 
    710d6ca01726:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01729:	be 70 00 01 00       	mov    esi,0x10070
    710d6ca0172e:	4c 89 ef             	mov    rdi,r13
    710d6ca01731:	e8 2a ea ff e7       	call   0x710d54a00160
    710d6ca01736:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0173d:	00 
    710d6ca0173e:	0f 84 d8 f9 ff e7    	je     0x710d54a0111c
    710d6ca01744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0174b:	04 00 00 00 
    710d6ca0174f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca01756:	12 00 00 00 
    710d6ca0175a:	58                   	pop    rax
    710d6ca0175b:	e9 e2 fc ff e7       	jmp    0x710d54a01442
    710d6ca01760:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    710d6ca01767:	74 00 01 00 
    710d6ca0176b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01772:	02 00 00 00 
    710d6ca01776:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca0177d:	13 00 00 00 
    710d6ca01781:	ba 74 00 01 00       	mov    edx,0x10074
    710d6ca01786:	4c 89 ef             	mov    rdi,r13
    710d6ca01789:	4c 89 f6             	mov    rsi,r14
    710d6ca0178c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca01792:	e8 e9 e8 ff e7       	call   0x710d54a00080
    710d6ca01797:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0179e:	02 00 00 00 
    710d6ca017a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca017a9:	13 00 00 00 
    710d6ca017ad:	58                   	pop    rax
    710d6ca017ae:	e9 8f fc ff e7       	jmp    0x710d54a01442
    710d6ca017b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    710d6ca017ba:	74 00 01 00 
    710d6ca017be:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca017c5:	02 00 00 00 
    710d6ca017c9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca017d0:	13 00 00 00 
    710d6ca017d4:	4c 89 f7             	mov    rdi,r14
    710d6ca017d7:	89 ce                	mov    esi,ecx
    710d6ca017d9:	e8 92 e8 ff e7       	call   0x710d54a00070
    710d6ca017de:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca017e5:	00 
    710d6ca017e6:	0f 84 6e f9 ff e7    	je     0x710d54a0115a
    710d6ca017ec:	eb a9                	jmp    0x710d6ca01797
    710d6ca017ee:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    710d6ca017f5:	74 00 01 00 
    710d6ca017f9:	b8 74 00 01 00       	mov    eax,0x10074
    710d6ca017fe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01805:	02 00 00 00 
    710d6ca01809:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca01810:	13 00 00 00 
    710d6ca01814:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01817:	be 74 00 01 00       	mov    esi,0x10074
    710d6ca0181c:	4c 89 ef             	mov    rdi,r13
    710d6ca0181f:	e8 3c e9 ff e7       	call   0x710d54a00160
    710d6ca01824:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca01827:	0f 84 5e f9 ff e7    	je     0x710d54a0118b
    710d6ca0182d:	eb 0f                	jmp    0x710d6ca0183e
    710d6ca0182f:	b8 74 00 01 00       	mov    eax,0x10074
    710d6ca01834:	83 c0 02             	add    eax,0x2
    710d6ca01837:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0183e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01845:	02 00 00 00 
    710d6ca01849:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca01850:	13 00 00 00 
    710d6ca01854:	4c 89 ef             	mov    rdi,r13
    710d6ca01857:	e8 f4 e8 ff e7       	call   0x710d54a00150
    710d6ca0185c:	e9 2a f9 ff e7       	jmp    0x710d54a0118b
    710d6ca01861:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    710d6ca01868:	76 00 01 00 
    710d6ca0186c:	b8 76 00 01 00       	mov    eax,0x10076
    710d6ca01871:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01878:	02 00 00 00 
    710d6ca0187c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca01883:	14 00 00 00 
    710d6ca01887:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0188a:	be 76 00 01 00       	mov    esi,0x10076
    710d6ca0188f:	4c 89 ef             	mov    rdi,r13
    710d6ca01892:	e8 c9 e8 ff e7       	call   0x710d54a00160
    710d6ca01897:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0189e:	00 
    710d6ca0189f:	0f 84 20 f9 ff e7    	je     0x710d54a011c5
    710d6ca018a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca018ac:	02 00 00 00 
    710d6ca018b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca018b7:	14 00 00 00 
    710d6ca018bb:	58                   	pop    rax
    710d6ca018bc:	e9 81 fb ff e7       	jmp    0x710d54a01442
    710d6ca018c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    710d6ca018c8:	78 00 01 00 
    710d6ca018cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca018d3:	02 00 00 00 
    710d6ca018d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca018de:	15 00 00 00 
    710d6ca018e2:	ba 78 00 01 00       	mov    edx,0x10078
    710d6ca018e7:	4c 89 ef             	mov    rdi,r13
    710d6ca018ea:	4c 89 f6             	mov    rsi,r14
    710d6ca018ed:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca018f3:	e8 88 e7 ff e7       	call   0x710d54a00080
    710d6ca018f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca018ff:	02 00 00 00 
    710d6ca01903:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca0190a:	15 00 00 00 
    710d6ca0190e:	58                   	pop    rax
    710d6ca0190f:	e9 2e fb ff e7       	jmp    0x710d54a01442
    710d6ca01914:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    710d6ca0191b:	78 00 01 00 
    710d6ca0191f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01926:	02 00 00 00 
    710d6ca0192a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca01931:	15 00 00 00 
    710d6ca01935:	4c 89 f7             	mov    rdi,r14
    710d6ca01938:	89 ce                	mov    esi,ecx
    710d6ca0193a:	e8 31 e7 ff e7       	call   0x710d54a00070
    710d6ca0193f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01946:	00 
    710d6ca01947:	0f 84 b6 f8 ff e7    	je     0x710d54a01203
    710d6ca0194d:	eb a9                	jmp    0x710d6ca018f8
    710d6ca0194f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    710d6ca01956:	78 00 01 00 
    710d6ca0195a:	b8 78 00 01 00       	mov    eax,0x10078
    710d6ca0195f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01966:	02 00 00 00 
    710d6ca0196a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca01971:	15 00 00 00 
    710d6ca01975:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01978:	be 78 00 01 00       	mov    esi,0x10078
    710d6ca0197d:	4c 89 ef             	mov    rdi,r13
    710d6ca01980:	e8 db e7 ff e7       	call   0x710d54a00160
    710d6ca01985:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca01988:	0f 84 a6 f8 ff e7    	je     0x710d54a01234
    710d6ca0198e:	eb 0f                	jmp    0x710d6ca0199f
    710d6ca01990:	b8 78 00 01 00       	mov    eax,0x10078
    710d6ca01995:	83 c0 02             	add    eax,0x2
    710d6ca01998:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0199f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca019a6:	02 00 00 00 
    710d6ca019aa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca019b1:	15 00 00 00 
    710d6ca019b5:	4c 89 ef             	mov    rdi,r13
    710d6ca019b8:	e8 93 e7 ff e7       	call   0x710d54a00150
    710d6ca019bd:	e9 72 f8 ff e7       	jmp    0x710d54a01234
    710d6ca019c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    710d6ca019c9:	7a 00 01 00 
    710d6ca019cd:	b8 7a 00 01 00       	mov    eax,0x1007a
    710d6ca019d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca019d9:	02 00 00 00 
    710d6ca019dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca019e4:	16 00 00 00 
    710d6ca019e8:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca019eb:	be 7a 00 01 00       	mov    esi,0x1007a
    710d6ca019f0:	4c 89 ef             	mov    rdi,r13
    710d6ca019f3:	e8 68 e7 ff e7       	call   0x710d54a00160
    710d6ca019f8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca019ff:	00 
    710d6ca01a00:	0f 84 68 f8 ff e7    	je     0x710d54a0126e
    710d6ca01a06:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01a0d:	02 00 00 00 
    710d6ca01a11:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca01a18:	16 00 00 00 
    710d6ca01a1c:	58                   	pop    rax
    710d6ca01a1d:	e9 20 fa ff e7       	jmp    0x710d54a01442
    710d6ca01a22:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007c
    710d6ca01a29:	7c 00 01 00 
    710d6ca01a2d:	b8 7c 00 01 00       	mov    eax,0x1007c
    710d6ca01a32:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01a39:	04 00 00 00 
    710d6ca01a3d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca01a44:	17 00 00 00 
    710d6ca01a48:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01a4b:	be 7c 00 01 00       	mov    esi,0x1007c
    710d6ca01a50:	4c 89 ef             	mov    rdi,r13
    710d6ca01a53:	e8 08 e7 ff e7       	call   0x710d54a00160
    710d6ca01a58:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01a5f:	00 
    710d6ca01a60:	0f 84 3f f8 ff e7    	je     0x710d54a012a5
    710d6ca01a66:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01a6d:	04 00 00 00 
    710d6ca01a71:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca01a78:	17 00 00 00 
    710d6ca01a7c:	58                   	pop    rax
    710d6ca01a7d:	e9 c0 f9 ff e7       	jmp    0x710d54a01442
    710d6ca01a82:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10080
    710d6ca01a89:	80 00 01 00 
    710d6ca01a8d:	b8 80 00 01 00       	mov    eax,0x10080
    710d6ca01a92:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01a99:	02 00 00 00 
    710d6ca01a9d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    710d6ca01aa4:	18 00 00 00 
    710d6ca01aa8:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01aab:	be 80 00 01 00       	mov    esi,0x10080
    710d6ca01ab0:	4c 89 ef             	mov    rdi,r13
    710d6ca01ab3:	e8 a8 e6 ff e7       	call   0x710d54a00160
    710d6ca01ab8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01abf:	00 
    710d6ca01ac0:	0f 84 0b f8 ff e7    	je     0x710d54a012d1
    710d6ca01ac6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01acd:	02 00 00 00 
    710d6ca01ad1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    710d6ca01ad8:	18 00 00 00 
    710d6ca01adc:	58                   	pop    rax
    710d6ca01add:	e9 60 f9 ff e7       	jmp    0x710d54a01442
    710d6ca01ae2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10082
    710d6ca01ae9:	82 00 01 00 
    710d6ca01aed:	b8 82 00 01 00       	mov    eax,0x10082
    710d6ca01af2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01af9:	02 00 00 00 
    710d6ca01afd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca01b04:	19 00 00 00 
    710d6ca01b08:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01b0b:	be 82 00 01 00       	mov    esi,0x10082
    710d6ca01b10:	4c 89 ef             	mov    rdi,r13
    710d6ca01b13:	e8 48 e6 ff e7       	call   0x710d54a00160
    710d6ca01b18:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01b1f:	00 
    710d6ca01b20:	0f 84 d7 f7 ff e7    	je     0x710d54a012fd
    710d6ca01b26:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01b2d:	02 00 00 00 
    710d6ca01b31:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca01b38:	19 00 00 00 
    710d6ca01b3c:	58                   	pop    rax
    710d6ca01b3d:	e9 00 f9 ff e7       	jmp    0x710d54a01442
    710d6ca01b42:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    710d6ca01b49:	84 00 01 00 
    710d6ca01b4d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca01b54:	08 00 00 00 
    710d6ca01b58:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca01b5f:	1a 00 00 00 
    710d6ca01b63:	ba 84 00 01 00       	mov    edx,0x10084
    710d6ca01b68:	4c 89 ef             	mov    rdi,r13
    710d6ca01b6b:	4c 89 f6             	mov    rsi,r14
    710d6ca01b6e:	45 31 c0             	xor    r8d,r8d
    710d6ca01b71:	e8 0a e5 ff e7       	call   0x710d54a00080
    710d6ca01b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca01b7d:	08 00 00 00 
    710d6ca01b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca01b88:	1a 00 00 00 
    710d6ca01b8c:	58                   	pop    rax
    710d6ca01b8d:	e9 b0 f8 ff e7       	jmp    0x710d54a01442
    710d6ca01b92:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    710d6ca01b99:	84 00 01 00 
    710d6ca01b9d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca01ba4:	08 00 00 00 
    710d6ca01ba8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca01baf:	1a 00 00 00 
    710d6ca01bb3:	4c 89 f7             	mov    rdi,r14
    710d6ca01bb6:	89 ce                	mov    esi,ecx
    710d6ca01bb8:	e8 83 e4 ff e7       	call   0x710d54a00040
    710d6ca01bbd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01bc4:	00 
    710d6ca01bc5:	0f 84 65 f7 ff e7    	je     0x710d54a01330
    710d6ca01bcb:	eb a9                	jmp    0x710d6ca01b76
    710d6ca01bcd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca01bd4:	8c 00 01 00 
    710d6ca01bd8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01bdf:	02 00 00 00 
    710d6ca01be3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca01bea:	1b 00 00 00 
    710d6ca01bee:	ba 8c 00 01 00       	mov    edx,0x1008c
    710d6ca01bf3:	4c 89 ef             	mov    rdi,r13
    710d6ca01bf6:	4c 89 f6             	mov    rsi,r14
    710d6ca01bf9:	45 31 c0             	xor    r8d,r8d
    710d6ca01bfc:	e8 7f e4 ff e7       	call   0x710d54a00080
    710d6ca01c01:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01c08:	02 00 00 00 
    710d6ca01c0c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca01c13:	1b 00 00 00 
    710d6ca01c17:	58                   	pop    rax
    710d6ca01c18:	e9 25 f8 ff e7       	jmp    0x710d54a01442
    710d6ca01c1d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca01c24:	8c 00 01 00 
    710d6ca01c28:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01c2f:	02 00 00 00 
    710d6ca01c33:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca01c3a:	1b 00 00 00 
    710d6ca01c3e:	4c 89 f7             	mov    rdi,r14
    710d6ca01c41:	89 ce                	mov    esi,ecx
    710d6ca01c43:	e8 f8 e3 ff e7       	call   0x710d54a00040
    710d6ca01c48:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01c4f:	00 
    710d6ca01c50:	0f 84 2d f7 ff e7    	je     0x710d54a01383
    710d6ca01c56:	eb a9                	jmp    0x710d6ca01c01
    710d6ca01c58:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca01c5f:	8c 00 01 00 
    710d6ca01c63:	b8 8c 00 01 00       	mov    eax,0x1008c
    710d6ca01c68:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01c6f:	02 00 00 00 
    710d6ca01c73:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca01c7a:	1b 00 00 00 
    710d6ca01c7e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01c81:	be 8c 00 01 00       	mov    esi,0x1008c
    710d6ca01c86:	4c 89 ef             	mov    rdi,r13
    710d6ca01c89:	e8 d2 e4 ff e7       	call   0x710d54a00160
    710d6ca01c8e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01c95:	00 
    710d6ca01c96:	0f 84 0d f7 ff e7    	je     0x710d54a013a9
    710d6ca01c9c:	e9 60 ff ff ff       	jmp    0x710d6ca01c01
    710d6ca01ca1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01ca8:	28 03 01 00 
    710d6ca01cac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01cb3:	04 00 00 00 
    710d6ca01cb7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    710d6ca01cbe:	1c 00 00 00 
    710d6ca01cc2:	be 8e 00 01 00       	mov    esi,0x1008e
    710d6ca01cc7:	ba 8e 00 01 00       	mov    edx,0x1008e
    710d6ca01ccc:	4c 89 ef             	mov    rdi,r13
    710d6ca01ccf:	e8 8c e4 ff e7       	call   0x710d54a00160
    710d6ca01cd4:	e9 47 f7 ff e7       	jmp    0x710d54a01420
    710d6ca01cd9:	c2 08 00             	ret    0x8
