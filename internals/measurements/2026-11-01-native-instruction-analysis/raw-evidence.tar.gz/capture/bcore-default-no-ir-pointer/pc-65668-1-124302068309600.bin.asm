
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65668-1-124302068309600.bin:     file format binary


Disassembly of section .data:

0000710d54a05e60 <.data>:
    710d54a05e60:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a05e67:	3d 00 00 00 00       	cmp    eax,0x0
    710d54a05e6c:	0f 95 c2             	setne  dl
    710d54a05e6f:	b9 84 00 01 00       	mov    ecx,0x10084
    710d54a05e74:	29 c8                	sub    eax,ecx
    710d54a05e76:	3d 0a 00 00 00       	cmp    eax,0xa
    710d54a05e7b:	0f 96 c3             	setbe  bl
    710d54a05e7e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    710d54a05e85:	81 fe 20 04 01 00    	cmp    esi,0x10420
    710d54a05e8b:	0f 94 c0             	sete   al
    710d54a05e8e:	29 ce                	sub    esi,ecx
    710d54a05e90:	81 fe 0a 00 00 00    	cmp    esi,0xa
    710d54a05e96:	0f 97 c1             	seta   cl
    710d54a05e99:	84 da                	test   dl,bl
    710d54a05e9b:	0f 85 5f 16 00 18    	jne    0x710d6ca07500
    710d54a05ea1:	08 c8                	or     al,cl
    710d54a05ea3:	0f 84 57 16 00 18    	je     0x710d6ca07500
    710d54a05ea9:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a05eb0:	8b 88 40 00 10 00    	mov    ecx,DWORD PTR [rax+0x100040]
    710d54a05eb6:	ff c1                	inc    ecx
    710d54a05eb8:	89 88 40 00 10 00    	mov    DWORD PTR [rax+0x100040],ecx
    710d54a05ebe:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a05ec4:	0f 84 4c 16 00 18    	je     0x710d6ca07516
    710d54a05eca:	50                   	push   rax
    710d54a05ecb:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a05ecf:	8d 48 fc             	lea    ecx,[rax-0x4]
    710d54a05ed2:	a8 03                	test   al,0x3
    710d54a05ed4:	0f 85 68 16 00 18    	jne    0x710d6ca07542
    710d54a05eda:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a05ee1:	89 ca                	mov    edx,ecx
    710d54a05ee3:	c1 ea 0c             	shr    edx,0xc
    710d54a05ee6:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a05eea:	48 85 c0             	test   rax,rax
    710d54a05eed:	0f 84 9f 16 00 18    	je     0x710d6ca07592
    710d54a05ef3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05ef9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a05efc:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    710d54a05f03:	58                   	pop    rax
    710d54a05f04:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    710d54a05f0b:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    710d54a05f12:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    710d54a05f19:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a05f1d:	50                   	push   rax
    710d54a05f1e:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a05f22:	8d 48 f8             	lea    ecx,[rax-0x8]
    710d54a05f25:	a8 03                	test   al,0x3
    710d54a05f27:	0f 85 a0 16 00 18    	jne    0x710d6ca075cd
    710d54a05f2d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a05f34:	89 ca                	mov    edx,ecx
    710d54a05f36:	c1 ea 0c             	shr    edx,0xc
    710d54a05f39:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a05f3d:	48 85 c0             	test   rax,rax
    710d54a05f40:	0f 84 d7 16 00 18    	je     0x710d6ca0761d
    710d54a05f46:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05f4c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a05f4f:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a05f53:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    710d54a05f5a:	8c 00 01 00 
    710d54a05f5e:	0f 84 f4 16 00 18    	je     0x710d6ca07658
    710d54a05f64:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    710d54a05f6b:	8c 00 01 00 
    710d54a05f6f:	0f 84 e3 16 00 18    	je     0x710d6ca07658
    710d54a05f75:	58                   	pop    rax
    710d54a05f76:	50                   	push   rax
    710d54a05f77:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a05f7e:	b9 8e 00 01 00       	mov    ecx,0x1008e
    710d54a05f83:	83 c1 04             	add    ecx,0x4
    710d54a05f86:	89 ca                	mov    edx,ecx
    710d54a05f88:	3d 8e 00 01 00       	cmp    eax,0x1008e
    710d54a05f8d:	75 07                	jne    0x710d54a05f96
    710d54a05f8f:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    710d54a05f96:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    710d54a05f9d:	02 
    710d54a05f9e:	0f 43 ca             	cmovae ecx,edx
    710d54a05fa1:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    710d54a05fa8:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    710d54a05faf:	89 cf                	mov    edi,ecx
    710d54a05fb1:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    710d54a05fb7:	75 07                	jne    0x710d54a05fc0
    710d54a05fb9:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    710d54a05fc0:	83 fe 02             	cmp    esi,0x2
    710d54a05fc3:	0f 43 cf             	cmovae ecx,edi
    710d54a05fc6:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    710d54a05fcd:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a05fd4:	01 
    710d54a05fd5:	3d 8e 00 01 00       	cmp    eax,0x1008e
    710d54a05fda:	0f 84 c1 16 00 18    	je     0x710d6ca076a1
    710d54a05fe0:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    710d54a05fe6:	0f 84 b5 16 00 18    	je     0x710d6ca076a1
    710d54a05fec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d54a05ff3:	28 03 01 00 
    710d54a05ff7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a05ffe:	04 00 00 00 
    710d54a06002:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d54a06009:	03 00 00 00 
    710d54a0600d:	58                   	pop    rax
    710d54a0600e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a06015:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a0601c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a06023:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a0602a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a06031:	39 f1                	cmp    ecx,esi
    710d54a06033:	0f 83 a0 16 00 18    	jae    0x710d6ca076d9
    710d54a06039:	81 fa 84 00 01 00    	cmp    edx,0x10084
    710d54a0603f:	75 14                	jne    0x710d54a06055
    710d54a06041:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a06048:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a0604f:	00 
    710d54a06050:	e9 54 fe ff ff       	jmp    0x710d54a05ea9
    710d54a06055:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a0605c:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a06062:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a06065:	0f 85 6e 16 00 18    	jne    0x710d6ca076d9
    710d54a0606b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a06072:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a06079:	00 
    710d54a0607a:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a0607f:	ff e0                	jmp    rax
