
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66578-1-124302470954720.bin:     file format binary


Disassembly of section .data:

0000710d6ca03ee0 <.data>:
    710d6ca03ee0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca03ee6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca03ee9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca03eef:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca03ef6:	0f 87 05 ee ff e7    	ja     0x710d54a02d01
    710d6ca03efc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x7
    710d6ca03f03:	07 00 00 00 
    710d6ca03f07:	e9 f5 ed ff e7       	jmp    0x710d54a02d01
    710d6ca03f0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10412
    710d6ca03f13:	12 04 01 00 
    710d6ca03f17:	b8 12 04 01 00       	mov    eax,0x10412
    710d6ca03f1c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03f23:	02 00 00 00 
    710d6ca03f27:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca03f2e:	01 00 00 00 
    710d6ca03f32:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03f35:	be 12 04 01 00       	mov    esi,0x10412
    710d6ca03f3a:	4c 89 ef             	mov    rdi,r13
    710d6ca03f3d:	e8 1e c2 ff e7       	call   0x710d54a00160
    710d6ca03f42:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03f49:	00 
    710d6ca03f4a:	0f 84 2b ee ff e7    	je     0x710d54a02d7b
    710d6ca03f50:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03f57:	02 00 00 00 
    710d6ca03f5b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca03f62:	01 00 00 00 
    710d6ca03f66:	58                   	pop    rax
    710d6ca03f67:	e9 bd f0 ff e7       	jmp    0x710d54a03029
    710d6ca03f6c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10414
    710d6ca03f73:	14 04 01 00 
    710d6ca03f77:	b8 14 04 01 00       	mov    eax,0x10414
    710d6ca03f7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03f83:	02 00 00 00 
    710d6ca03f87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca03f8e:	02 00 00 00 
    710d6ca03f92:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03f95:	be 14 04 01 00       	mov    esi,0x10414
    710d6ca03f9a:	4c 89 ef             	mov    rdi,r13
    710d6ca03f9d:	e8 be c1 ff e7       	call   0x710d54a00160
    710d6ca03fa2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03fa9:	00 
    710d6ca03faa:	0f 84 29 ee ff e7    	je     0x710d54a02dd9
    710d6ca03fb0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03fb7:	02 00 00 00 
    710d6ca03fbb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca03fc2:	02 00 00 00 
    710d6ca03fc6:	58                   	pop    rax
    710d6ca03fc7:	e9 5d f0 ff e7       	jmp    0x710d54a03029
    710d6ca03fcc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10416
    710d6ca03fd3:	16 04 01 00 
    710d6ca03fd7:	b8 16 04 01 00       	mov    eax,0x10416
    710d6ca03fdc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03fe3:	02 00 00 00 
    710d6ca03fe7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca03fee:	03 00 00 00 
    710d6ca03ff2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03ff5:	be 16 04 01 00       	mov    esi,0x10416
    710d6ca03ffa:	4c 89 ef             	mov    rdi,r13
    710d6ca03ffd:	e8 5e c1 ff e7       	call   0x710d54a00160
    710d6ca04002:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04009:	00 
    710d6ca0400a:	0f 84 f7 ed ff e7    	je     0x710d54a02e07
    710d6ca04010:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04017:	02 00 00 00 
    710d6ca0401b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04022:	03 00 00 00 
    710d6ca04026:	58                   	pop    rax
    710d6ca04027:	e9 fd ef ff e7       	jmp    0x710d54a03029
    710d6ca0402c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10418
    710d6ca04033:	18 04 01 00 
    710d6ca04037:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0403e:	02 00 00 00 
    710d6ca04042:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04049:	04 00 00 00 
    710d6ca0404d:	ba 18 04 01 00       	mov    edx,0x10418
    710d6ca04052:	4c 89 ef             	mov    rdi,r13
    710d6ca04055:	4c 89 f6             	mov    rsi,r14
    710d6ca04058:	89 d9                	mov    ecx,ebx
    710d6ca0405a:	45 31 c0             	xor    r8d,r8d
    710d6ca0405d:	e8 1e c0 ff e7       	call   0x710d54a00080
    710d6ca04062:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04069:	02 00 00 00 
    710d6ca0406d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04074:	04 00 00 00 
    710d6ca04078:	58                   	pop    rax
    710d6ca04079:	e9 ab ef ff e7       	jmp    0x710d54a03029
    710d6ca0407e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10418
    710d6ca04085:	18 04 01 00 
    710d6ca04089:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04090:	02 00 00 00 
    710d6ca04094:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca0409b:	04 00 00 00 
    710d6ca0409f:	4c 89 f7             	mov    rdi,r14
    710d6ca040a2:	89 de                	mov    esi,ebx
    710d6ca040a4:	e8 97 bf ff e7       	call   0x710d54a00040
    710d6ca040a9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca040b0:	00 
    710d6ca040b1:	0f 84 85 ed ff e7    	je     0x710d54a02e3c
    710d6ca040b7:	eb a9                	jmp    0x710d6ca04062
    710d6ca040b9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10418
    710d6ca040c0:	18 04 01 00 
    710d6ca040c4:	b8 18 04 01 00       	mov    eax,0x10418
    710d6ca040c9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca040d0:	02 00 00 00 
    710d6ca040d4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca040db:	04 00 00 00 
    710d6ca040df:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca040e2:	be 18 04 01 00       	mov    esi,0x10418
    710d6ca040e7:	4c 89 ef             	mov    rdi,r13
    710d6ca040ea:	e8 71 c0 ff e7       	call   0x710d54a00160
    710d6ca040ef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca040f6:	00 
    710d6ca040f7:	0f 84 6c ed ff e7    	je     0x710d54a02e69
    710d6ca040fd:	e9 60 ff ff ff       	jmp    0x710d6ca04062
    710d6ca04102:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1041a
    710d6ca04109:	1a 04 01 00 
    710d6ca0410d:	b8 1a 04 01 00       	mov    eax,0x1041a
    710d6ca04112:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04119:	02 00 00 00 
    710d6ca0411d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca04124:	05 00 00 00 
    710d6ca04128:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0412b:	be 1a 04 01 00       	mov    esi,0x1041a
    710d6ca04130:	4c 89 ef             	mov    rdi,r13
    710d6ca04133:	e8 28 c0 ff e7       	call   0x710d54a00160
    710d6ca04138:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0413f:	00 
    710d6ca04140:	0f 84 58 ed ff e7    	je     0x710d54a02e9e
    710d6ca04146:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0414d:	02 00 00 00 
    710d6ca04151:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca04158:	05 00 00 00 
    710d6ca0415c:	58                   	pop    rax
    710d6ca0415d:	e9 c7 ee ff e7       	jmp    0x710d54a03029
    710d6ca04162:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1041c
    710d6ca04169:	1c 04 01 00 
    710d6ca0416d:	b8 1c 04 01 00       	mov    eax,0x1041c
    710d6ca04172:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04179:	02 00 00 00 
    710d6ca0417d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca04184:	06 00 00 00 
    710d6ca04188:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0418b:	be 1c 04 01 00       	mov    esi,0x1041c
    710d6ca04190:	4c 89 ef             	mov    rdi,r13
    710d6ca04193:	e8 c8 bf ff e7       	call   0x710d54a00160
    710d6ca04198:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0419f:	00 
    710d6ca041a0:	0f 84 2d ed ff e7    	je     0x710d54a02ed3
    710d6ca041a6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca041ad:	02 00 00 00 
    710d6ca041b1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca041b8:	06 00 00 00 
    710d6ca041bc:	58                   	pop    rax
    710d6ca041bd:	e9 67 ee ff e7       	jmp    0x710d54a03029
    710d6ca041c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1041e
    710d6ca041c9:	1e 04 01 00 
    710d6ca041cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca041d4:	02 00 00 00 
    710d6ca041d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca041df:	07 00 00 00 
    710d6ca041e3:	ba 1e 04 01 00       	mov    edx,0x1041e
    710d6ca041e8:	4c 89 ef             	mov    rdi,r13
    710d6ca041eb:	4c 89 f6             	mov    rsi,r14
    710d6ca041ee:	45 31 c0             	xor    r8d,r8d
    710d6ca041f1:	e8 8a be ff e7       	call   0x710d54a00080
    710d6ca041f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca041fd:	02 00 00 00 
    710d6ca04201:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca04208:	07 00 00 00 
    710d6ca0420c:	58                   	pop    rax
    710d6ca0420d:	e9 17 ee ff e7       	jmp    0x710d54a03029
    710d6ca04212:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1041e
    710d6ca04219:	1e 04 01 00 
    710d6ca0421d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04224:	02 00 00 00 
    710d6ca04228:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca0422f:	07 00 00 00 
    710d6ca04233:	4c 89 f7             	mov    rdi,r14
    710d6ca04236:	89 ce                	mov    esi,ecx
    710d6ca04238:	e8 03 be ff e7       	call   0x710d54a00040
    710d6ca0423d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04244:	00 
    710d6ca04245:	0f 84 bb ec ff e7    	je     0x710d54a02f06
    710d6ca0424b:	eb a9                	jmp    0x710d6ca041f6
    710d6ca0424d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1041e
    710d6ca04254:	1e 04 01 00 
    710d6ca04258:	b8 1e 04 01 00       	mov    eax,0x1041e
    710d6ca0425d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04264:	02 00 00 00 
    710d6ca04268:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca0426f:	07 00 00 00 
    710d6ca04273:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04276:	be 1e 04 01 00       	mov    esi,0x1041e
    710d6ca0427b:	4c 89 ef             	mov    rdi,r13
    710d6ca0427e:	e8 dd be ff e7       	call   0x710d54a00160
    710d6ca04283:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0428a:	00 
    710d6ca0428b:	0f 84 9b ec ff e7    	je     0x710d54a02f2c
    710d6ca04291:	e9 60 ff ff ff       	jmp    0x710d6ca041f6
    710d6ca04296:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10420
    710d6ca0429d:	20 04 01 00 
    710d6ca042a1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca042a8:	02 00 00 00 
    710d6ca042ac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca042b3:	08 00 00 00 
    710d6ca042b7:	ba 20 04 01 00       	mov    edx,0x10420
    710d6ca042bc:	4c 89 ef             	mov    rdi,r13
    710d6ca042bf:	4c 89 f6             	mov    rsi,r14
    710d6ca042c2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca042c8:	e8 b3 bd ff e7       	call   0x710d54a00080
    710d6ca042cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca042d4:	02 00 00 00 
    710d6ca042d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca042df:	08 00 00 00 
    710d6ca042e3:	58                   	pop    rax
    710d6ca042e4:	e9 40 ed ff e7       	jmp    0x710d54a03029
    710d6ca042e9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10420
    710d6ca042f0:	20 04 01 00 
    710d6ca042f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca042fb:	02 00 00 00 
    710d6ca042ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04306:	08 00 00 00 
    710d6ca0430a:	4c 89 f7             	mov    rdi,r14
    710d6ca0430d:	89 ce                	mov    esi,ecx
    710d6ca0430f:	e8 5c bd ff e7       	call   0x710d54a00070
    710d6ca04314:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0431b:	00 
    710d6ca0431c:	0f 84 48 ec ff e7    	je     0x710d54a02f6a
    710d6ca04322:	eb a9                	jmp    0x710d6ca042cd
    710d6ca04324:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10420
    710d6ca0432b:	20 04 01 00 
    710d6ca0432f:	b8 20 04 01 00       	mov    eax,0x10420
    710d6ca04334:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0433b:	02 00 00 00 
    710d6ca0433f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04346:	08 00 00 00 
    710d6ca0434a:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0434d:	be 20 04 01 00       	mov    esi,0x10420
    710d6ca04352:	4c 89 ef             	mov    rdi,r13
    710d6ca04355:	e8 06 be ff e7       	call   0x710d54a00160
    710d6ca0435a:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca0435d:	0f 84 38 ec ff e7    	je     0x710d54a02f9b
    710d6ca04363:	eb 0f                	jmp    0x710d6ca04374
    710d6ca04365:	b8 20 04 01 00       	mov    eax,0x10420
    710d6ca0436a:	83 c0 02             	add    eax,0x2
    710d6ca0436d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca04374:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0437b:	02 00 00 00 
    710d6ca0437f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04386:	08 00 00 00 
    710d6ca0438a:	4c 89 ef             	mov    rdi,r13
    710d6ca0438d:	e8 be bd ff e7       	call   0x710d54a00150
    710d6ca04392:	e9 04 ec ff e7       	jmp    0x710d54a02f9b
    710d6ca04397:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10422
    710d6ca0439e:	22 04 01 00 
    710d6ca043a2:	b8 22 04 01 00       	mov    eax,0x10422
    710d6ca043a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca043ae:	02 00 00 00 
    710d6ca043b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca043b9:	09 00 00 00 
    710d6ca043bd:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca043c0:	be 22 04 01 00       	mov    esi,0x10422
    710d6ca043c5:	4c 89 ef             	mov    rdi,r13
    710d6ca043c8:	e8 93 bd ff e7       	call   0x710d54a00160
    710d6ca043cd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca043d4:	00 
    710d6ca043d5:	0f 84 fa eb ff e7    	je     0x710d54a02fd5
    710d6ca043db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca043e2:	02 00 00 00 
    710d6ca043e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca043ed:	09 00 00 00 
    710d6ca043f1:	58                   	pop    rax
    710d6ca043f2:	e9 32 ec ff e7       	jmp    0x710d54a03029
    710d6ca043f7:	b8 24 04 01 00       	mov    eax,0x10424
    710d6ca043fc:	05 44 ff ff ff       	add    eax,0xffffff44
    710d6ca04401:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca04408:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0440f:	02 00 00 00 
    710d6ca04413:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0441a:	0a 00 00 00 
    710d6ca0441e:	be 24 04 01 00       	mov    esi,0x10424
    710d6ca04423:	ba 24 04 01 00       	mov    edx,0x10424
    710d6ca04428:	4c 89 ef             	mov    rdi,r13
    710d6ca0442b:	e8 30 bd ff e7       	call   0x710d54a00160
    710d6ca04430:	e9 cc eb ff e7       	jmp    0x710d54a03001
    710d6ca04435:	c2 08 00             	ret    0x8
