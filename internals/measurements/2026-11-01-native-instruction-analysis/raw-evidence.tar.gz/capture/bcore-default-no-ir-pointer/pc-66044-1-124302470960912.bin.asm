
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66044-1-124302470960912.bin:     file format binary


Disassembly of section .data:

0000710d6ca05710 <.data>:
    710d6ca05710:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca05716:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca05719:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca0571f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca05726:	0f 87 65 e7 ff e7    	ja     0x710d54a03e91
    710d6ca0572c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xd
    710d6ca05733:	0d 00 00 00 
    710d6ca05737:	e9 55 e7 ff e7       	jmp    0x710d54a03e91
    710d6ca0573c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    710d6ca05743:	fc 01 01 00 
    710d6ca05747:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0574e:	02 00 00 00 
    710d6ca05752:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca05759:	01 00 00 00 
    710d6ca0575d:	ba fc 01 01 00       	mov    edx,0x101fc
    710d6ca05762:	4c 89 ef             	mov    rdi,r13
    710d6ca05765:	4c 89 f6             	mov    rsi,r14
    710d6ca05768:	89 d9                	mov    ecx,ebx
    710d6ca0576a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca05770:	e8 0b a9 ff e7       	call   0x710d54a00080
    710d6ca05775:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0577c:	02 00 00 00 
    710d6ca05780:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca05787:	01 00 00 00 
    710d6ca0578b:	58                   	pop    rax
    710d6ca0578c:	e9 53 ef ff e7       	jmp    0x710d54a046e4
    710d6ca05791:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    710d6ca05798:	fc 01 01 00 
    710d6ca0579c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca057a3:	02 00 00 00 
    710d6ca057a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca057ae:	01 00 00 00 
    710d6ca057b2:	4c 89 f7             	mov    rdi,r14
    710d6ca057b5:	89 de                	mov    esi,ebx
    710d6ca057b7:	e8 b4 a8 ff e7       	call   0x710d54a00070
    710d6ca057bc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca057c3:	00 
    710d6ca057c4:	0f 84 06 e7 ff e7    	je     0x710d54a03ed0
    710d6ca057ca:	eb a9                	jmp    0x710d6ca05775
    710d6ca057cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    710d6ca057d3:	fc 01 01 00 
    710d6ca057d7:	b8 fc 01 01 00       	mov    eax,0x101fc
    710d6ca057dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca057e3:	02 00 00 00 
    710d6ca057e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca057ee:	01 00 00 00 
    710d6ca057f2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca057f5:	be fc 01 01 00       	mov    esi,0x101fc
    710d6ca057fa:	4c 89 ef             	mov    rdi,r13
    710d6ca057fd:	e8 5e a9 ff e7       	call   0x710d54a00160
    710d6ca05802:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d6ca05806:	0f 84 fa e6 ff e7    	je     0x710d54a03f06
    710d6ca0580c:	eb 0f                	jmp    0x710d6ca0581d
    710d6ca0580e:	b8 fc 01 01 00       	mov    eax,0x101fc
    710d6ca05813:	83 c0 02             	add    eax,0x2
    710d6ca05816:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0581d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05824:	02 00 00 00 
    710d6ca05828:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0582f:	01 00 00 00 
    710d6ca05833:	4c 89 ef             	mov    rdi,r13
    710d6ca05836:	e8 15 a9 ff e7       	call   0x710d54a00150
    710d6ca0583b:	e9 c6 e6 ff e7       	jmp    0x710d54a03f06
    710d6ca05840:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fe
    710d6ca05847:	fe 01 01 00 
    710d6ca0584b:	b8 fe 01 01 00       	mov    eax,0x101fe
    710d6ca05850:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05857:	04 00 00 00 
    710d6ca0585b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca05862:	02 00 00 00 
    710d6ca05866:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05869:	be fe 01 01 00       	mov    esi,0x101fe
    710d6ca0586e:	4c 89 ef             	mov    rdi,r13
    710d6ca05871:	e8 ea a8 ff e7       	call   0x710d54a00160
    710d6ca05876:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0587d:	00 
    710d6ca0587e:	0f 84 bc e6 ff e7    	je     0x710d54a03f40
    710d6ca05884:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0588b:	04 00 00 00 
    710d6ca0588f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca05896:	02 00 00 00 
    710d6ca0589a:	58                   	pop    rax
    710d6ca0589b:	e9 44 ee ff e7       	jmp    0x710d54a046e4
    710d6ca058a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10202
    710d6ca058a7:	02 02 01 00 
    710d6ca058ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca058b2:	04 00 00 00 
    710d6ca058b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca058bd:	03 00 00 00 
    710d6ca058c1:	ba 02 02 01 00       	mov    edx,0x10202
    710d6ca058c6:	4c 89 ef             	mov    rdi,r13
    710d6ca058c9:	4c 89 f6             	mov    rsi,r14
    710d6ca058cc:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca058d2:	e8 a9 a7 ff e7       	call   0x710d54a00080
    710d6ca058d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca058de:	04 00 00 00 
    710d6ca058e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca058e9:	03 00 00 00 
    710d6ca058ed:	58                   	pop    rax
    710d6ca058ee:	e9 f1 ed ff e7       	jmp    0x710d54a046e4
    710d6ca058f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10202
    710d6ca058fa:	02 02 01 00 
    710d6ca058fe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05905:	04 00 00 00 
    710d6ca05909:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca05910:	03 00 00 00 
    710d6ca05914:	4c 89 f7             	mov    rdi,r14
    710d6ca05917:	89 ce                	mov    esi,ecx
    710d6ca05919:	e8 52 a7 ff e7       	call   0x710d54a00070
    710d6ca0591e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05925:	00 
    710d6ca05926:	0f 84 5b e6 ff e7    	je     0x710d54a03f87
    710d6ca0592c:	eb a9                	jmp    0x710d6ca058d7
    710d6ca0592e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10202
    710d6ca05935:	02 02 01 00 
    710d6ca05939:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05940:	04 00 00 00 
    710d6ca05944:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca0594b:	03 00 00 00 
    710d6ca0594f:	4c 89 f7             	mov    rdi,r14
    710d6ca05952:	89 de                	mov    esi,ebx
    710d6ca05954:	44 89 e2             	mov    edx,r12d
    710d6ca05957:	e8 14 a7 ff e7       	call   0x710d54a00070
    710d6ca0595c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05963:	00 
    710d6ca05964:	0f 84 3f e6 ff e7    	je     0x710d54a03fa9
    710d6ca0596a:	e9 68 ff ff ff       	jmp    0x710d6ca058d7
    710d6ca0596f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10202
    710d6ca05976:	02 02 01 00 
    710d6ca0597a:	b8 02 02 01 00       	mov    eax,0x10202
    710d6ca0597f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05986:	04 00 00 00 
    710d6ca0598a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca05991:	03 00 00 00 
    710d6ca05995:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05998:	be 02 02 01 00       	mov    esi,0x10202
    710d6ca0599d:	4c 89 ef             	mov    rdi,r13
    710d6ca059a0:	e8 bb a7 ff e7       	call   0x710d54a00160
    710d6ca059a5:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca059a9:	0f 84 3b e6 ff e7    	je     0x710d54a03fea
    710d6ca059af:	eb 0f                	jmp    0x710d6ca059c0
    710d6ca059b1:	b8 02 02 01 00       	mov    eax,0x10202
    710d6ca059b6:	83 c0 04             	add    eax,0x4
    710d6ca059b9:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca059c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca059c7:	04 00 00 00 
    710d6ca059cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca059d2:	03 00 00 00 
    710d6ca059d6:	4c 89 ef             	mov    rdi,r13
    710d6ca059d9:	e8 72 a7 ff e7       	call   0x710d54a00150
    710d6ca059de:	e9 07 e6 ff e7       	jmp    0x710d54a03fea
    710d6ca059e3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10206
    710d6ca059ea:	06 02 01 00 
    710d6ca059ee:	b8 06 02 01 00       	mov    eax,0x10206
    710d6ca059f3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca059fa:	02 00 00 00 
    710d6ca059fe:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05a05:	04 00 00 00 
    710d6ca05a09:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05a0c:	be 06 02 01 00       	mov    esi,0x10206
    710d6ca05a11:	4c 89 ef             	mov    rdi,r13
    710d6ca05a14:	e8 47 a7 ff e7       	call   0x710d54a00160
    710d6ca05a19:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05a20:	00 
    710d6ca05a21:	0f 84 2f e6 ff e7    	je     0x710d54a04056
    710d6ca05a27:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05a2e:	02 00 00 00 
    710d6ca05a32:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05a39:	04 00 00 00 
    710d6ca05a3d:	58                   	pop    rax
    710d6ca05a3e:	e9 a1 ec ff e7       	jmp    0x710d54a046e4
    710d6ca05a43:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10208
    710d6ca05a4a:	08 02 01 00 
    710d6ca05a4e:	b8 08 02 01 00       	mov    eax,0x10208
    710d6ca05a53:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05a5a:	02 00 00 00 
    710d6ca05a5e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca05a65:	05 00 00 00 
    710d6ca05a69:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05a6c:	be 08 02 01 00       	mov    esi,0x10208
    710d6ca05a71:	4c 89 ef             	mov    rdi,r13
    710d6ca05a74:	e8 e7 a6 ff e7       	call   0x710d54a00160
    710d6ca05a79:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05a80:	00 
    710d6ca05a81:	0f 84 29 e6 ff e7    	je     0x710d54a040b0
    710d6ca05a87:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05a8e:	02 00 00 00 
    710d6ca05a92:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca05a99:	05 00 00 00 
    710d6ca05a9d:	58                   	pop    rax
    710d6ca05a9e:	e9 41 ec ff e7       	jmp    0x710d54a046e4
    710d6ca05aa3:	b8 0a 02 01 00       	mov    eax,0x1020a
    710d6ca05aa8:	83 c0 24             	add    eax,0x24
    710d6ca05aab:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca05ab2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05ab9:	02 00 00 00 
    710d6ca05abd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca05ac4:	06 00 00 00 
    710d6ca05ac8:	be 0a 02 01 00       	mov    esi,0x1020a
    710d6ca05acd:	ba 0a 02 01 00       	mov    edx,0x1020a
    710d6ca05ad2:	4c 89 ef             	mov    rdi,r13
    710d6ca05ad5:	e8 86 a6 ff e7       	call   0x710d54a00160
    710d6ca05ada:	e9 07 e6 ff e7       	jmp    0x710d54a040e6
    710d6ca05adf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1020a
    710d6ca05ae6:	0a 02 01 00 
    710d6ca05aea:	b8 0a 02 01 00       	mov    eax,0x1020a
    710d6ca05aef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05af6:	02 00 00 00 
    710d6ca05afa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca05b01:	06 00 00 00 
    710d6ca05b05:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05b08:	be 0a 02 01 00       	mov    esi,0x1020a
    710d6ca05b0d:	4c 89 ef             	mov    rdi,r13
    710d6ca05b10:	e8 4b a6 ff e7       	call   0x710d54a00160
    710d6ca05b15:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05b1c:	00 
    710d6ca05b1d:	0f 84 10 e6 ff e7    	je     0x710d54a04133
    710d6ca05b23:	e9 cd e5 ff e7       	jmp    0x710d54a040f5
    710d6ca05b28:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1020c
    710d6ca05b2f:	0c 02 01 00 
    710d6ca05b33:	b8 0c 02 01 00       	mov    eax,0x1020c
    710d6ca05b38:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05b3f:	04 00 00 00 
    710d6ca05b43:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca05b4a:	07 00 00 00 
    710d6ca05b4e:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05b51:	be 0c 02 01 00       	mov    esi,0x1020c
    710d6ca05b56:	4c 89 ef             	mov    rdi,r13
    710d6ca05b59:	e8 02 a6 ff e7       	call   0x710d54a00160
    710d6ca05b5e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05b65:	00 
    710d6ca05b66:	0f 84 fb e5 ff e7    	je     0x710d54a04167
    710d6ca05b6c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05b73:	04 00 00 00 
    710d6ca05b77:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca05b7e:	07 00 00 00 
    710d6ca05b82:	58                   	pop    rax
    710d6ca05b83:	e9 5c eb ff e7       	jmp    0x710d54a046e4
    710d6ca05b88:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10210
    710d6ca05b8f:	10 02 01 00 
    710d6ca05b93:	b8 10 02 01 00       	mov    eax,0x10210
    710d6ca05b98:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05b9f:	04 00 00 00 
    710d6ca05ba3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca05baa:	08 00 00 00 
    710d6ca05bae:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05bb1:	be 10 02 01 00       	mov    esi,0x10210
    710d6ca05bb6:	4c 89 ef             	mov    rdi,r13
    710d6ca05bb9:	e8 a2 a5 ff e7       	call   0x710d54a00160
    710d6ca05bbe:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05bc5:	00 
    710d6ca05bc6:	0f 84 cf e5 ff e7    	je     0x710d54a0419b
    710d6ca05bcc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05bd3:	04 00 00 00 
    710d6ca05bd7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca05bde:	08 00 00 00 
    710d6ca05be2:	58                   	pop    rax
    710d6ca05be3:	e9 fc ea ff e7       	jmp    0x710d54a046e4
    710d6ca05be8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10214
    710d6ca05bef:	14 02 01 00 
    710d6ca05bf3:	b8 14 02 01 00       	mov    eax,0x10214
    710d6ca05bf8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05bff:	02 00 00 00 
    710d6ca05c03:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca05c0a:	09 00 00 00 
    710d6ca05c0e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05c11:	be 14 02 01 00       	mov    esi,0x10214
    710d6ca05c16:	4c 89 ef             	mov    rdi,r13
    710d6ca05c19:	e8 42 a5 ff e7       	call   0x710d54a00160
    710d6ca05c1e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05c25:	00 
    710d6ca05c26:	0f 84 9b e5 ff e7    	je     0x710d54a041c7
    710d6ca05c2c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05c33:	02 00 00 00 
    710d6ca05c37:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca05c3e:	09 00 00 00 
    710d6ca05c42:	58                   	pop    rax
    710d6ca05c43:	e9 9c ea ff e7       	jmp    0x710d54a046e4
    710d6ca05c48:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10216
    710d6ca05c4f:	16 02 01 00 
    710d6ca05c53:	b8 16 02 01 00       	mov    eax,0x10216
    710d6ca05c58:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05c5f:	04 00 00 00 
    710d6ca05c63:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca05c6a:	0a 00 00 00 
    710d6ca05c6e:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05c71:	be 16 02 01 00       	mov    esi,0x10216
    710d6ca05c76:	4c 89 ef             	mov    rdi,r13
    710d6ca05c79:	e8 e2 a4 ff e7       	call   0x710d54a00160
    710d6ca05c7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05c85:	00 
    710d6ca05c86:	0f 84 72 e5 ff e7    	je     0x710d54a041fe
    710d6ca05c8c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05c93:	04 00 00 00 
    710d6ca05c97:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca05c9e:	0a 00 00 00 
    710d6ca05ca2:	58                   	pop    rax
    710d6ca05ca3:	e9 3c ea ff e7       	jmp    0x710d54a046e4
    710d6ca05ca8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1021a
    710d6ca05caf:	1a 02 01 00 
    710d6ca05cb3:	b8 1a 02 01 00       	mov    eax,0x1021a
    710d6ca05cb8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05cbf:	04 00 00 00 
    710d6ca05cc3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca05cca:	0b 00 00 00 
    710d6ca05cce:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05cd1:	be 1a 02 01 00       	mov    esi,0x1021a
    710d6ca05cd6:	4c 89 ef             	mov    rdi,r13
    710d6ca05cd9:	e8 82 a4 ff e7       	call   0x710d54a00160
    710d6ca05cde:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05ce5:	00 
    710d6ca05ce6:	0f 84 49 e5 ff e7    	je     0x710d54a04235
    710d6ca05cec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05cf3:	04 00 00 00 
    710d6ca05cf7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca05cfe:	0b 00 00 00 
    710d6ca05d02:	58                   	pop    rax
    710d6ca05d03:	e9 dc e9 ff e7       	jmp    0x710d54a046e4
    710d6ca05d08:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1021e
    710d6ca05d0f:	1e 02 01 00 
    710d6ca05d13:	b8 1e 02 01 00       	mov    eax,0x1021e
    710d6ca05d18:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05d1f:	02 00 00 00 
    710d6ca05d23:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca05d2a:	0c 00 00 00 
    710d6ca05d2e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05d31:	be 1e 02 01 00       	mov    esi,0x1021e
    710d6ca05d36:	4c 89 ef             	mov    rdi,r13
    710d6ca05d39:	e8 22 a4 ff e7       	call   0x710d54a00160
    710d6ca05d3e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05d45:	00 
    710d6ca05d46:	0f 84 17 e5 ff e7    	je     0x710d54a04263
    710d6ca05d4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05d53:	02 00 00 00 
    710d6ca05d57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca05d5e:	0c 00 00 00 
    710d6ca05d62:	58                   	pop    rax
    710d6ca05d63:	e9 7c e9 ff e7       	jmp    0x710d54a046e4
    710d6ca05d68:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10220
    710d6ca05d6f:	20 02 01 00 
    710d6ca05d73:	b8 20 02 01 00       	mov    eax,0x10220
    710d6ca05d78:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05d7f:	02 00 00 00 
    710d6ca05d83:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca05d8a:	0d 00 00 00 
    710d6ca05d8e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05d91:	be 20 02 01 00       	mov    esi,0x10220
    710d6ca05d96:	4c 89 ef             	mov    rdi,r13
    710d6ca05d99:	e8 c2 a3 ff e7       	call   0x710d54a00160
    710d6ca05d9e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05da5:	00 
    710d6ca05da6:	0f 84 32 e5 ff e7    	je     0x710d54a042de
    710d6ca05dac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05db3:	02 00 00 00 
    710d6ca05db7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca05dbe:	0d 00 00 00 
    710d6ca05dc2:	58                   	pop    rax
    710d6ca05dc3:	e9 1c e9 ff e7       	jmp    0x710d54a046e4
    710d6ca05dc8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10222
    710d6ca05dcf:	22 02 01 00 
    710d6ca05dd3:	b8 22 02 01 00       	mov    eax,0x10222
    710d6ca05dd8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05ddf:	02 00 00 00 
    710d6ca05de3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca05dea:	0e 00 00 00 
    710d6ca05dee:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05df1:	be 22 02 01 00       	mov    esi,0x10222
    710d6ca05df6:	4c 89 ef             	mov    rdi,r13
    710d6ca05df9:	e8 62 a3 ff e7       	call   0x710d54a00160
    710d6ca05dfe:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05e05:	00 
    710d6ca05e06:	0f 84 39 e5 ff e7    	je     0x710d54a04345
    710d6ca05e0c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05e13:	02 00 00 00 
    710d6ca05e17:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca05e1e:	0e 00 00 00 
    710d6ca05e22:	58                   	pop    rax
    710d6ca05e23:	e9 bc e8 ff e7       	jmp    0x710d54a046e4
    710d6ca05e28:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10224
    710d6ca05e2f:	24 02 01 00 
    710d6ca05e33:	b8 24 02 01 00       	mov    eax,0x10224
    710d6ca05e38:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05e3f:	02 00 00 00 
    710d6ca05e43:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca05e4a:	0f 00 00 00 
    710d6ca05e4e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05e51:	be 24 02 01 00       	mov    esi,0x10224
    710d6ca05e56:	4c 89 ef             	mov    rdi,r13
    710d6ca05e59:	e8 02 a3 ff e7       	call   0x710d54a00160
    710d6ca05e5e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05e65:	00 
    710d6ca05e66:	0f 84 0e e5 ff e7    	je     0x710d54a0437a
    710d6ca05e6c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05e73:	02 00 00 00 
    710d6ca05e77:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca05e7e:	0f 00 00 00 
    710d6ca05e82:	58                   	pop    rax
    710d6ca05e83:	e9 5c e8 ff e7       	jmp    0x710d54a046e4
    710d6ca05e88:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca05e8f:	26 02 01 00 
    710d6ca05e93:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05e9a:	02 00 00 00 
    710d6ca05e9e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca05ea5:	10 00 00 00 
    710d6ca05ea9:	ba 26 02 01 00       	mov    edx,0x10226
    710d6ca05eae:	4c 89 ef             	mov    rdi,r13
    710d6ca05eb1:	4c 89 f6             	mov    rsi,r14
    710d6ca05eb4:	45 31 c0             	xor    r8d,r8d
    710d6ca05eb7:	e8 c4 a1 ff e7       	call   0x710d54a00080
    710d6ca05ebc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05ec3:	02 00 00 00 
    710d6ca05ec7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca05ece:	10 00 00 00 
    710d6ca05ed2:	58                   	pop    rax
    710d6ca05ed3:	e9 0c e8 ff e7       	jmp    0x710d54a046e4
    710d6ca05ed8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca05edf:	26 02 01 00 
    710d6ca05ee3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05eea:	02 00 00 00 
    710d6ca05eee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca05ef5:	10 00 00 00 
    710d6ca05ef9:	4c 89 f7             	mov    rdi,r14
    710d6ca05efc:	89 ce                	mov    esi,ecx
    710d6ca05efe:	e8 3d a1 ff e7       	call   0x710d54a00040
    710d6ca05f03:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05f0a:	00 
    710d6ca05f0b:	0f 84 9c e4 ff e7    	je     0x710d54a043ad
    710d6ca05f11:	eb a9                	jmp    0x710d6ca05ebc
    710d6ca05f13:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10226
    710d6ca05f1a:	26 02 01 00 
    710d6ca05f1e:	b8 26 02 01 00       	mov    eax,0x10226
    710d6ca05f23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05f2a:	02 00 00 00 
    710d6ca05f2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca05f35:	10 00 00 00 
    710d6ca05f39:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05f3c:	be 26 02 01 00       	mov    esi,0x10226
    710d6ca05f41:	4c 89 ef             	mov    rdi,r13
    710d6ca05f44:	e8 17 a2 ff e7       	call   0x710d54a00160
    710d6ca05f49:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05f50:	00 
    710d6ca05f51:	0f 84 7c e4 ff e7    	je     0x710d54a043d3
    710d6ca05f57:	e9 60 ff ff ff       	jmp    0x710d6ca05ebc
    710d6ca05f5c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10228
    710d6ca05f63:	28 02 01 00 
    710d6ca05f67:	b8 28 02 01 00       	mov    eax,0x10228
    710d6ca05f6c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05f73:	02 00 00 00 
    710d6ca05f77:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca05f7e:	11 00 00 00 
    710d6ca05f82:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05f85:	be 28 02 01 00       	mov    esi,0x10228
    710d6ca05f8a:	4c 89 ef             	mov    rdi,r13
    710d6ca05f8d:	e8 ce a1 ff e7       	call   0x710d54a00160
    710d6ca05f92:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05f99:	00 
    710d6ca05f9a:	0f 84 91 e4 ff e7    	je     0x710d54a04431
    710d6ca05fa0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05fa7:	02 00 00 00 
    710d6ca05fab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca05fb2:	11 00 00 00 
    710d6ca05fb6:	58                   	pop    rax
    710d6ca05fb7:	e9 28 e7 ff e7       	jmp    0x710d54a046e4
    710d6ca05fbc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022a
    710d6ca05fc3:	2a 02 01 00 
    710d6ca05fc7:	b8 2a 02 01 00       	mov    eax,0x1022a
    710d6ca05fcc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05fd3:	02 00 00 00 
    710d6ca05fd7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca05fde:	12 00 00 00 
    710d6ca05fe2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05fe5:	be 2a 02 01 00       	mov    esi,0x1022a
    710d6ca05fea:	4c 89 ef             	mov    rdi,r13
    710d6ca05fed:	e8 6e a1 ff e7       	call   0x710d54a00160
    710d6ca05ff2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05ff9:	00 
    710d6ca05ffa:	0f 84 b7 e4 ff e7    	je     0x710d54a044b7
    710d6ca06000:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06007:	02 00 00 00 
    710d6ca0600b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca06012:	12 00 00 00 
    710d6ca06016:	58                   	pop    rax
    710d6ca06017:	e9 c8 e6 ff e7       	jmp    0x710d54a046e4
    710d6ca0601c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022c
    710d6ca06023:	2c 02 01 00 
    710d6ca06027:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d6ca0602c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06033:	02 00 00 00 
    710d6ca06037:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca0603e:	13 00 00 00 
    710d6ca06042:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca06045:	be 2c 02 01 00       	mov    esi,0x1022c
    710d6ca0604a:	4c 89 ef             	mov    rdi,r13
    710d6ca0604d:	e8 0e a1 ff e7       	call   0x710d54a00160
    710d6ca06052:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06059:	00 
    710d6ca0605a:	0f 84 85 e4 ff e7    	je     0x710d54a044e5
    710d6ca06060:	e9 bf e4 ff e7       	jmp    0x710d54a04524
    710d6ca06065:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d6ca0606a:	83 c0 f2             	add    eax,0xfffffff2
    710d6ca0606d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca06074:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0607b:	02 00 00 00 
    710d6ca0607f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca06086:	13 00 00 00 
    710d6ca0608a:	be 2c 02 01 00       	mov    esi,0x1022c
    710d6ca0608f:	ba 2c 02 01 00       	mov    edx,0x1022c
    710d6ca06094:	4c 89 ef             	mov    rdi,r13
    710d6ca06097:	e8 c4 a0 ff e7       	call   0x710d54a00160
    710d6ca0609c:	e9 74 e4 ff e7       	jmp    0x710d54a04515
    710d6ca060a1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca060a8:	2e 02 01 00 
    710d6ca060ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca060b3:	04 00 00 00 
    710d6ca060b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca060be:	14 00 00 00 
    710d6ca060c2:	ba 2e 02 01 00       	mov    edx,0x1022e
    710d6ca060c7:	4c 89 ef             	mov    rdi,r13
    710d6ca060ca:	4c 89 f6             	mov    rsi,r14
    710d6ca060cd:	89 d9                	mov    ecx,ebx
    710d6ca060cf:	45 31 c0             	xor    r8d,r8d
    710d6ca060d2:	e8 a9 9f ff e7       	call   0x710d54a00080
    710d6ca060d7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca060de:	04 00 00 00 
    710d6ca060e2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca060e9:	14 00 00 00 
    710d6ca060ed:	58                   	pop    rax
    710d6ca060ee:	e9 f1 e5 ff e7       	jmp    0x710d54a046e4
    710d6ca060f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca060fa:	2e 02 01 00 
    710d6ca060fe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06105:	04 00 00 00 
    710d6ca06109:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca06110:	14 00 00 00 
    710d6ca06114:	4c 89 f7             	mov    rdi,r14
    710d6ca06117:	89 de                	mov    esi,ebx
    710d6ca06119:	e8 22 9f ff e7       	call   0x710d54a00040
    710d6ca0611e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06125:	00 
    710d6ca06126:	75 af                	jne    0x710d6ca060d7
    710d6ca06128:	41 89 c7             	mov    r15d,eax
    710d6ca0612b:	e9 46 e4 ff e7       	jmp    0x710d54a04576
    710d6ca06130:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca06137:	2e 02 01 00 
    710d6ca0613b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06142:	04 00 00 00 
    710d6ca06146:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca0614d:	14 00 00 00 
    710d6ca06151:	4c 89 f7             	mov    rdi,r14
    710d6ca06154:	e8 e7 9e ff e7       	call   0x710d54a00040
    710d6ca06159:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06160:	00 
    710d6ca06161:	0f 84 30 e4 ff e7    	je     0x710d54a04597
    710d6ca06167:	e9 6b ff ff ff       	jmp    0x710d6ca060d7
    710d6ca0616c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    710d6ca06173:	2e 02 01 00 
    710d6ca06177:	b8 2e 02 01 00       	mov    eax,0x1022e
    710d6ca0617c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca06183:	04 00 00 00 
    710d6ca06187:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca0618e:	14 00 00 00 
    710d6ca06192:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca06195:	be 2e 02 01 00       	mov    esi,0x1022e
    710d6ca0619a:	4c 89 ef             	mov    rdi,r13
    710d6ca0619d:	e8 be 9f ff e7       	call   0x710d54a00160
    710d6ca061a2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca061a9:	00 
    710d6ca061aa:	0f 84 1b e4 ff e7    	je     0x710d54a045cb
    710d6ca061b0:	e9 22 ff ff ff       	jmp    0x710d6ca060d7
    710d6ca061b5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10232
    710d6ca061bc:	32 02 01 00 
    710d6ca061c0:	b8 32 02 01 00       	mov    eax,0x10232
    710d6ca061c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca061cc:	02 00 00 00 
    710d6ca061d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca061d7:	15 00 00 00 
    710d6ca061db:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca061de:	be 32 02 01 00       	mov    esi,0x10232
    710d6ca061e3:	4c 89 ef             	mov    rdi,r13
    710d6ca061e6:	e8 75 9f ff e7       	call   0x710d54a00160
    710d6ca061eb:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca061f2:	00 
    710d6ca061f3:	0f 84 30 e4 ff e7    	je     0x710d54a04629
    710d6ca061f9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06200:	02 00 00 00 
    710d6ca06204:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca0620b:	15 00 00 00 
    710d6ca0620f:	58                   	pop    rax
    710d6ca06210:	e9 cf e4 ff e7       	jmp    0x710d54a046e4
    710d6ca06215:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca0621c:	34 02 01 00 
    710d6ca06220:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06227:	02 00 00 00 
    710d6ca0622b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca06232:	16 00 00 00 
    710d6ca06236:	ba 34 02 01 00       	mov    edx,0x10234
    710d6ca0623b:	4c 89 ef             	mov    rdi,r13
    710d6ca0623e:	4c 89 f6             	mov    rsi,r14
    710d6ca06241:	89 d9                	mov    ecx,ebx
    710d6ca06243:	45 31 c0             	xor    r8d,r8d
    710d6ca06246:	e8 35 9e ff e7       	call   0x710d54a00080
    710d6ca0624b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06252:	02 00 00 00 
    710d6ca06256:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca0625d:	16 00 00 00 
    710d6ca06261:	58                   	pop    rax
    710d6ca06262:	e9 7d e4 ff e7       	jmp    0x710d54a046e4
    710d6ca06267:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca0626e:	34 02 01 00 
    710d6ca06272:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06279:	02 00 00 00 
    710d6ca0627d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca06284:	16 00 00 00 
    710d6ca06288:	4c 89 f7             	mov    rdi,r14
    710d6ca0628b:	89 de                	mov    esi,ebx
    710d6ca0628d:	e8 ae 9d ff e7       	call   0x710d54a00040
    710d6ca06292:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca06299:	00 
    710d6ca0629a:	0f 84 be e3 ff e7    	je     0x710d54a0465e
    710d6ca062a0:	eb a9                	jmp    0x710d6ca0624b
    710d6ca062a2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10234
    710d6ca062a9:	34 02 01 00 
    710d6ca062ad:	b8 34 02 01 00       	mov    eax,0x10234
    710d6ca062b2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca062b9:	02 00 00 00 
    710d6ca062bd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca062c4:	16 00 00 00 
    710d6ca062c8:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca062cb:	be 34 02 01 00       	mov    esi,0x10234
    710d6ca062d0:	4c 89 ef             	mov    rdi,r13
    710d6ca062d3:	e8 88 9e ff e7       	call   0x710d54a00160
    710d6ca062d8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca062df:	00 
    710d6ca062e0:	0f 84 a5 e3 ff e7    	je     0x710d54a0468b
    710d6ca062e6:	e9 60 ff ff ff       	jmp    0x710d6ca0624b
    710d6ca062eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10236
    710d6ca062f2:	36 02 01 00 
    710d6ca062f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca062fd:	02 00 00 00 
    710d6ca06301:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca06308:	17 00 00 00 
    710d6ca0630c:	4c 89 ef             	mov    rdi,r13
    710d6ca0630f:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca06314:	4c 89 f2             	mov    rdx,r14
    710d6ca06317:	e8 74 9d ff e7       	call   0x710d54a00090
    710d6ca0631c:	e9 ac e3 ff e7       	jmp    0x710d54a046cd
    710d6ca06321:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca06328:	02 00 00 00 
    710d6ca0632c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca06333:	17 00 00 00 
    710d6ca06337:	be 36 02 01 00       	mov    esi,0x10236
    710d6ca0633c:	ba 36 02 01 00       	mov    edx,0x10236
    710d6ca06341:	4c 89 ef             	mov    rdi,r13
    710d6ca06344:	e8 17 9e ff e7       	call   0x710d54a00160
    710d6ca06349:	e9 7f e3 ff e7       	jmp    0x710d54a046cd
    710d6ca0634e:	c2 08 00             	ret    0x8
