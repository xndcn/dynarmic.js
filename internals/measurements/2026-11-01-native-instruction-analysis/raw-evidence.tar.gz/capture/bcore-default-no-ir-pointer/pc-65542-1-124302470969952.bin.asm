
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65542-1-124302470969952.bin:     file format binary


Disassembly of section .data:

0000710d6ca07a60 <.data>:
    710d6ca07a60:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca07a66:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca07a69:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca07a6f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca07a76:	0f 87 d5 08 00 e8    	ja     0x710d54a08351
    710d6ca07a7c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x11
    710d6ca07a83:	11 00 00 00 
    710d6ca07a87:	e9 c5 08 00 e8       	jmp    0x710d54a08351
    710d6ca07a8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10006
    710d6ca07a93:	06 00 01 00 
    710d6ca07a97:	b8 06 00 01 00       	mov    eax,0x10006
    710d6ca07a9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca07aa3:	04 00 00 00 
    710d6ca07aa7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca07aae:	01 00 00 00 
    710d6ca07ab2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca07ab5:	be 06 00 01 00       	mov    esi,0x10006
    710d6ca07aba:	4c 89 ef             	mov    rdi,r13
    710d6ca07abd:	e8 9e 86 ff e7       	call   0x710d54a00160
    710d6ca07ac2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca07ac9:	00 
    710d6ca07aca:	0f 84 b4 08 00 e8    	je     0x710d54a08384
    710d6ca07ad0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca07ad7:	04 00 00 00 
    710d6ca07adb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca07ae2:	01 00 00 00 
    710d6ca07ae6:	58                   	pop    rax
    710d6ca07ae7:	e9 9a 09 00 e8       	jmp    0x710d54a08486
    710d6ca07aec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000a
    710d6ca07af3:	0a 00 01 00 
    710d6ca07af7:	b8 0a 00 01 00       	mov    eax,0x1000a
    710d6ca07afc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca07b03:	04 00 00 00 
    710d6ca07b07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca07b0e:	02 00 00 00 
    710d6ca07b12:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca07b15:	be 0a 00 01 00       	mov    esi,0x1000a
    710d6ca07b1a:	4c 89 ef             	mov    rdi,r13
    710d6ca07b1d:	e8 3e 86 ff e7       	call   0x710d54a00160
    710d6ca07b22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca07b29:	00 
    710d6ca07b2a:	0f 84 8b 08 00 e8    	je     0x710d54a083bb
    710d6ca07b30:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca07b37:	04 00 00 00 
    710d6ca07b3b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca07b42:	02 00 00 00 
    710d6ca07b46:	58                   	pop    rax
    710d6ca07b47:	e9 3a 09 00 e8       	jmp    0x710d54a08486
    710d6ca07b4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    710d6ca07b53:	0e 00 01 00 
    710d6ca07b57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07b5e:	02 00 00 00 
    710d6ca07b62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca07b69:	03 00 00 00 
    710d6ca07b6d:	ba 0e 00 01 00       	mov    edx,0x1000e
    710d6ca07b72:	4c 89 ef             	mov    rdi,r13
    710d6ca07b75:	4c 89 f6             	mov    rsi,r14
    710d6ca07b78:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca07b7e:	e8 fd 84 ff e7       	call   0x710d54a00080
    710d6ca07b83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07b8a:	02 00 00 00 
    710d6ca07b8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca07b95:	03 00 00 00 
    710d6ca07b99:	58                   	pop    rax
    710d6ca07b9a:	e9 e7 08 00 e8       	jmp    0x710d54a08486
    710d6ca07b9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    710d6ca07ba6:	0e 00 01 00 
    710d6ca07baa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07bb1:	02 00 00 00 
    710d6ca07bb5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca07bbc:	03 00 00 00 
    710d6ca07bc0:	4c 89 f7             	mov    rdi,r14
    710d6ca07bc3:	89 ce                	mov    esi,ecx
    710d6ca07bc5:	e8 a6 84 ff e7       	call   0x710d54a00070
    710d6ca07bca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca07bd1:	00 
    710d6ca07bd2:	0f 84 21 08 00 e8    	je     0x710d54a083f9
    710d6ca07bd8:	eb a9                	jmp    0x710d6ca07b83
    710d6ca07bda:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    710d6ca07be1:	0e 00 01 00 
    710d6ca07be5:	b8 0e 00 01 00       	mov    eax,0x1000e
    710d6ca07bea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07bf1:	02 00 00 00 
    710d6ca07bf5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca07bfc:	03 00 00 00 
    710d6ca07c00:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca07c03:	be 0e 00 01 00       	mov    esi,0x1000e
    710d6ca07c08:	4c 89 ef             	mov    rdi,r13
    710d6ca07c0b:	e8 50 85 ff e7       	call   0x710d54a00160
    710d6ca07c10:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca07c13:	0f 84 11 08 00 e8    	je     0x710d54a0842a
    710d6ca07c19:	eb 0f                	jmp    0x710d6ca07c2a
    710d6ca07c1b:	b8 0e 00 01 00       	mov    eax,0x1000e
    710d6ca07c20:	83 c0 02             	add    eax,0x2
    710d6ca07c23:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca07c2a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07c31:	02 00 00 00 
    710d6ca07c35:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca07c3c:	03 00 00 00 
    710d6ca07c40:	4c 89 ef             	mov    rdi,r13
    710d6ca07c43:	e8 08 85 ff e7       	call   0x710d54a00150
    710d6ca07c48:	e9 dd 07 00 e8       	jmp    0x710d54a0842a
    710d6ca07c4d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    710d6ca07c54:	10 00 01 00 
    710d6ca07c58:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07c5f:	02 00 00 00 
    710d6ca07c63:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca07c6a:	04 00 00 00 
    710d6ca07c6e:	be 10 00 01 00       	mov    esi,0x10010
    710d6ca07c73:	ba 10 00 01 00       	mov    edx,0x10010
    710d6ca07c78:	4c 89 ef             	mov    rdi,r13
    710d6ca07c7b:	e8 e0 84 ff e7       	call   0x710d54a00160
    710d6ca07c80:	e9 df 07 00 e8       	jmp    0x710d54a08464
    710d6ca07c85:	c2 08 00             	ret    0x8
