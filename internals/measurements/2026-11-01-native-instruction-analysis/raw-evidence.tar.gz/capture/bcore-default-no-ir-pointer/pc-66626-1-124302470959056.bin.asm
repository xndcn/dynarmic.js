
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66626-1-124302470959056.bin:     file format binary


Disassembly of section .data:

0000710d6ca04fd0 <.data>:
    710d6ca04fd0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca04fd6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca04fd9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca04fdf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca04fe6:	0f 87 b5 e9 ff e7    	ja     0x710d54a039a1
    710d6ca04fec:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xb
    710d6ca04ff3:	0b 00 00 00 
    710d6ca04ff7:	e9 a5 e9 ff e7       	jmp    0x710d54a039a1
    710d6ca04ffc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    710d6ca05003:	42 04 01 00 
    710d6ca05007:	b8 42 04 01 00       	mov    eax,0x10442
    710d6ca0500c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05013:	04 00 00 00 
    710d6ca05017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0501e:	01 00 00 00 
    710d6ca05022:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05025:	be 42 04 01 00       	mov    esi,0x10442
    710d6ca0502a:	4c 89 ef             	mov    rdi,r13
    710d6ca0502d:	e8 2e b1 ff e7       	call   0x710d54a00160
    710d6ca05032:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05039:	00 
    710d6ca0503a:	0f 84 94 e9 ff e7    	je     0x710d54a039d4
    710d6ca05040:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05047:	04 00 00 00 
    710d6ca0504b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca05052:	01 00 00 00 
    710d6ca05056:	58                   	pop    rax
    710d6ca05057:	e9 93 ea ff e7       	jmp    0x710d54a03aef
    710d6ca0505c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10446
    710d6ca05063:	46 04 01 00 
    710d6ca05067:	b8 46 04 01 00       	mov    eax,0x10446
    710d6ca0506c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05073:	04 00 00 00 
    710d6ca05077:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0507e:	02 00 00 00 
    710d6ca05082:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05085:	be 46 04 01 00       	mov    esi,0x10446
    710d6ca0508a:	4c 89 ef             	mov    rdi,r13
    710d6ca0508d:	e8 ce b0 ff e7       	call   0x710d54a00160
    710d6ca05092:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05099:	00 
    710d6ca0509a:	0f 84 6b e9 ff e7    	je     0x710d54a03a0b
    710d6ca050a0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca050a7:	04 00 00 00 
    710d6ca050ab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca050b2:	02 00 00 00 
    710d6ca050b6:	58                   	pop    rax
    710d6ca050b7:	e9 33 ea ff e7       	jmp    0x710d54a03aef
    710d6ca050bc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044a
    710d6ca050c3:	4a 04 01 00 
    710d6ca050c7:	b8 4a 04 01 00       	mov    eax,0x1044a
    710d6ca050cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca050d3:	02 00 00 00 
    710d6ca050d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca050de:	03 00 00 00 
    710d6ca050e2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca050e5:	be 4a 04 01 00       	mov    esi,0x1044a
    710d6ca050ea:	4c 89 ef             	mov    rdi,r13
    710d6ca050ed:	e8 6e b0 ff e7       	call   0x710d54a00160
    710d6ca050f2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca050f9:	00 
    710d6ca050fa:	0f 84 40 e9 ff e7    	je     0x710d54a03a40
    710d6ca05100:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05107:	02 00 00 00 
    710d6ca0510b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca05112:	03 00 00 00 
    710d6ca05116:	58                   	pop    rax
    710d6ca05117:	e9 d3 e9 ff e7       	jmp    0x710d54a03aef
    710d6ca0511c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    710d6ca05123:	4c 04 01 00 
    710d6ca05127:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0512e:	02 00 00 00 
    710d6ca05132:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05139:	04 00 00 00 
    710d6ca0513d:	ba 4c 04 01 00       	mov    edx,0x1044c
    710d6ca05142:	4c 89 ef             	mov    rdi,r13
    710d6ca05145:	4c 89 f6             	mov    rsi,r14
    710d6ca05148:	45 31 c0             	xor    r8d,r8d
    710d6ca0514b:	e8 30 af ff e7       	call   0x710d54a00080
    710d6ca05150:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05157:	02 00 00 00 
    710d6ca0515b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05162:	04 00 00 00 
    710d6ca05166:	58                   	pop    rax
    710d6ca05167:	e9 83 e9 ff e7       	jmp    0x710d54a03aef
    710d6ca0516c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    710d6ca05173:	4c 04 01 00 
    710d6ca05177:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0517e:	02 00 00 00 
    710d6ca05182:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05189:	04 00 00 00 
    710d6ca0518d:	4c 89 f7             	mov    rdi,r14
    710d6ca05190:	89 ce                	mov    esi,ecx
    710d6ca05192:	e8 a9 ae ff e7       	call   0x710d54a00040
    710d6ca05197:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0519e:	00 
    710d6ca0519f:	0f 84 ce e8 ff e7    	je     0x710d54a03a73
    710d6ca051a5:	eb a9                	jmp    0x710d6ca05150
    710d6ca051a7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    710d6ca051ae:	4c 04 01 00 
    710d6ca051b2:	b8 4c 04 01 00       	mov    eax,0x1044c
    710d6ca051b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca051be:	02 00 00 00 
    710d6ca051c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca051c9:	04 00 00 00 
    710d6ca051cd:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca051d0:	be 4c 04 01 00       	mov    esi,0x1044c
    710d6ca051d5:	4c 89 ef             	mov    rdi,r13
    710d6ca051d8:	e8 83 af ff e7       	call   0x710d54a00160
    710d6ca051dd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca051e4:	00 
    710d6ca051e5:	0f 84 ae e8 ff e7    	je     0x710d54a03a99
    710d6ca051eb:	e9 60 ff ff ff       	jmp    0x710d6ca05150
    710d6ca051f0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044e
    710d6ca051f7:	4e 04 01 00 
    710d6ca051fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05202:	02 00 00 00 
    710d6ca05206:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0520d:	05 00 00 00 
    710d6ca05211:	4c 89 ef             	mov    rdi,r13
    710d6ca05214:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca05219:	4c 89 f2             	mov    rdx,r14
    710d6ca0521c:	e8 6f ae ff e7       	call   0x710d54a00090
    710d6ca05221:	e9 b2 e8 ff e7       	jmp    0x710d54a03ad8
    710d6ca05226:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0522d:	02 00 00 00 
    710d6ca05231:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca05238:	05 00 00 00 
    710d6ca0523c:	be 4e 04 01 00       	mov    esi,0x1044e
    710d6ca05241:	ba 4e 04 01 00       	mov    edx,0x1044e
    710d6ca05246:	4c 89 ef             	mov    rdi,r13
    710d6ca05249:	e8 12 af ff e7       	call   0x710d54a00160
    710d6ca0524e:	e9 85 e8 ff e7       	jmp    0x710d54a03ad8
    710d6ca05253:	c2 08 00             	ret    0x8
