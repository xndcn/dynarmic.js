
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66344-1-124302470946016.bin:     file format binary


Disassembly of section .data:

0000710d6ca01ce0 <.data>:
    710d6ca01ce0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca01ce6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca01ce9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca01cef:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca01cf6:	0f 87 e5 f7 ff e7    	ja     0x710d54a014e1
    710d6ca01cfc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x3
    710d6ca01d03:	03 00 00 00 
    710d6ca01d07:	e9 d5 f7 ff e7       	jmp    0x710d54a014e1
    710d6ca01d0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01d13:	28 03 01 00 
    710d6ca01d17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01d1e:	02 00 00 00 
    710d6ca01d22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01d29:	01 00 00 00 
    710d6ca01d2d:	ba 28 03 01 00       	mov    edx,0x10328
    710d6ca01d32:	4c 89 ef             	mov    rdi,r13
    710d6ca01d35:	4c 89 f6             	mov    rsi,r14
    710d6ca01d38:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca01d3e:	e8 3d e3 ff e7       	call   0x710d54a00080
    710d6ca01d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01d4a:	02 00 00 00 
    710d6ca01d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01d55:	01 00 00 00 
    710d6ca01d59:	58                   	pop    rax
    710d6ca01d5a:	e9 10 03 00 e8       	jmp    0x710d54a0206f
    710d6ca01d5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01d66:	28 03 01 00 
    710d6ca01d6a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01d71:	02 00 00 00 
    710d6ca01d75:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01d7c:	01 00 00 00 
    710d6ca01d80:	4c 89 f7             	mov    rdi,r14
    710d6ca01d83:	89 ce                	mov    esi,ecx
    710d6ca01d85:	e8 e6 e2 ff e7       	call   0x710d54a00070
    710d6ca01d8a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01d91:	00 
    710d6ca01d92:	0f 84 88 f7 ff e7    	je     0x710d54a01520
    710d6ca01d98:	eb a9                	jmp    0x710d6ca01d43
    710d6ca01d9a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01da1:	28 03 01 00 
    710d6ca01da5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01dac:	02 00 00 00 
    710d6ca01db0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01db7:	01 00 00 00 
    710d6ca01dbb:	4c 89 f7             	mov    rdi,r14
    710d6ca01dbe:	e8 ad e2 ff e7       	call   0x710d54a00070
    710d6ca01dc3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01dca:	00 
    710d6ca01dcb:	0f 84 72 f7 ff e7    	je     0x710d54a01543
    710d6ca01dd1:	e9 6d ff ff ff       	jmp    0x710d6ca01d43
    710d6ca01dd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01ddd:	28 03 01 00 
    710d6ca01de1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01de8:	02 00 00 00 
    710d6ca01dec:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01df3:	01 00 00 00 
    710d6ca01df7:	4c 89 f7             	mov    rdi,r14
    710d6ca01dfa:	e8 71 e2 ff e7       	call   0x710d54a00070
    710d6ca01dff:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01e06:	00 
    710d6ca01e07:	0f 84 59 f7 ff e7    	je     0x710d54a01566
    710d6ca01e0d:	e9 31 ff ff ff       	jmp    0x710d6ca01d43
    710d6ca01e12:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01e19:	28 03 01 00 
    710d6ca01e1d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01e24:	02 00 00 00 
    710d6ca01e28:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01e2f:	01 00 00 00 
    710d6ca01e33:	4c 89 f7             	mov    rdi,r14
    710d6ca01e36:	e8 35 e2 ff e7       	call   0x710d54a00070
    710d6ca01e3b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01e42:	00 
    710d6ca01e43:	0f 84 40 f7 ff e7    	je     0x710d54a01589
    710d6ca01e49:	e9 f5 fe ff ff       	jmp    0x710d6ca01d43
    710d6ca01e4e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01e55:	28 03 01 00 
    710d6ca01e59:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01e60:	02 00 00 00 
    710d6ca01e64:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01e6b:	01 00 00 00 
    710d6ca01e6f:	4c 89 f7             	mov    rdi,r14
    710d6ca01e72:	89 de                	mov    esi,ebx
    710d6ca01e74:	e8 f7 e1 ff e7       	call   0x710d54a00070
    710d6ca01e79:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01e80:	00 
    710d6ca01e81:	0f 84 27 f7 ff e7    	je     0x710d54a015ae
    710d6ca01e87:	e9 b7 fe ff ff       	jmp    0x710d6ca01d43
    710d6ca01e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca01e93:	28 03 01 00 
    710d6ca01e97:	b8 28 03 01 00       	mov    eax,0x10328
    710d6ca01e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01ea3:	02 00 00 00 
    710d6ca01ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01eae:	01 00 00 00 
    710d6ca01eb2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca01eb5:	be 28 03 01 00       	mov    esi,0x10328
    710d6ca01eba:	4c 89 ef             	mov    rdi,r13
    710d6ca01ebd:	e8 9e e2 ff e7       	call   0x710d54a00160
    710d6ca01ec2:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca01ec6:	0f 84 18 f7 ff e7    	je     0x710d54a015e4
    710d6ca01ecc:	eb 0f                	jmp    0x710d6ca01edd
    710d6ca01ece:	b8 28 03 01 00       	mov    eax,0x10328
    710d6ca01ed3:	83 c0 02             	add    eax,0x2
    710d6ca01ed6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca01edd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca01ee4:	02 00 00 00 
    710d6ca01ee8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca01eef:	01 00 00 00 
    710d6ca01ef3:	4c 89 ef             	mov    rdi,r13
    710d6ca01ef6:	e8 55 e2 ff e7       	call   0x710d54a00150
    710d6ca01efb:	e9 e4 f6 ff e7       	jmp    0x710d54a015e4
    710d6ca01f00:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    710d6ca01f07:	2a 03 01 00 
    710d6ca01f0b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01f12:	04 00 00 00 
    710d6ca01f16:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca01f1d:	02 00 00 00 
    710d6ca01f21:	ba 2a 03 01 00       	mov    edx,0x1032a
    710d6ca01f26:	4c 89 ef             	mov    rdi,r13
    710d6ca01f29:	4c 89 f6             	mov    rsi,r14
    710d6ca01f2c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca01f32:	e8 49 e1 ff e7       	call   0x710d54a00080
    710d6ca01f37:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01f3e:	04 00 00 00 
    710d6ca01f42:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca01f49:	02 00 00 00 
    710d6ca01f4d:	58                   	pop    rax
    710d6ca01f4e:	e9 1c 01 00 e8       	jmp    0x710d54a0206f
    710d6ca01f53:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    710d6ca01f5a:	2a 03 01 00 
    710d6ca01f5e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01f65:	04 00 00 00 
    710d6ca01f69:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca01f70:	02 00 00 00 
    710d6ca01f74:	4c 89 f7             	mov    rdi,r14
    710d6ca01f77:	89 ce                	mov    esi,ecx
    710d6ca01f79:	e8 f2 e0 ff e7       	call   0x710d54a00070
    710d6ca01f7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01f85:	00 
    710d6ca01f86:	0f 84 ad f6 ff e7    	je     0x710d54a01639
    710d6ca01f8c:	eb a9                	jmp    0x710d6ca01f37
    710d6ca01f8e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    710d6ca01f95:	2a 03 01 00 
    710d6ca01f99:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01fa0:	04 00 00 00 
    710d6ca01fa4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca01fab:	02 00 00 00 
    710d6ca01faf:	4c 89 f7             	mov    rdi,r14
    710d6ca01fb2:	89 de                	mov    esi,ebx
    710d6ca01fb4:	44 89 e2             	mov    edx,r12d
    710d6ca01fb7:	e8 b4 e0 ff e7       	call   0x710d54a00070
    710d6ca01fbc:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca01fc3:	00 
    710d6ca01fc4:	0f 84 91 f6 ff e7    	je     0x710d54a0165b
    710d6ca01fca:	e9 68 ff ff ff       	jmp    0x710d6ca01f37
    710d6ca01fcf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    710d6ca01fd6:	2a 03 01 00 
    710d6ca01fda:	b8 2a 03 01 00       	mov    eax,0x1032a
    710d6ca01fdf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca01fe6:	04 00 00 00 
    710d6ca01fea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca01ff1:	02 00 00 00 
    710d6ca01ff5:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca01ff8:	be 2a 03 01 00       	mov    esi,0x1032a
    710d6ca01ffd:	4c 89 ef             	mov    rdi,r13
    710d6ca02000:	e8 5b e1 ff e7       	call   0x710d54a00160
    710d6ca02005:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca02009:	0f 84 8d f6 ff e7    	je     0x710d54a0169c
    710d6ca0200f:	eb 0f                	jmp    0x710d6ca02020
    710d6ca02011:	b8 2a 03 01 00       	mov    eax,0x1032a
    710d6ca02016:	83 c0 04             	add    eax,0x4
    710d6ca02019:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02020:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02027:	04 00 00 00 
    710d6ca0202b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca02032:	02 00 00 00 
    710d6ca02036:	4c 89 ef             	mov    rdi,r13
    710d6ca02039:	e8 12 e1 ff e7       	call   0x710d54a00150
    710d6ca0203e:	e9 59 f6 ff e7       	jmp    0x710d54a0169c
    710d6ca02043:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    710d6ca0204a:	2e 03 01 00 
    710d6ca0204e:	b8 2e 03 01 00       	mov    eax,0x1032e
    710d6ca02053:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0205a:	02 00 00 00 
    710d6ca0205e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca02065:	03 00 00 00 
    710d6ca02069:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0206c:	be 2e 03 01 00       	mov    esi,0x1032e
    710d6ca02071:	4c 89 ef             	mov    rdi,r13
    710d6ca02074:	e8 e7 e0 ff e7       	call   0x710d54a00160
    710d6ca02079:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02080:	00 
    710d6ca02081:	0f 84 8c f6 ff e7    	je     0x710d54a01713
    710d6ca02087:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0208e:	02 00 00 00 
    710d6ca02092:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca02099:	03 00 00 00 
    710d6ca0209d:	58                   	pop    rax
    710d6ca0209e:	e9 cc ff ff e7       	jmp    0x710d54a0206f
    710d6ca020a3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10330
    710d6ca020aa:	30 03 01 00 
    710d6ca020ae:	b8 30 03 01 00       	mov    eax,0x10330
    710d6ca020b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca020ba:	02 00 00 00 
    710d6ca020be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca020c5:	04 00 00 00 
    710d6ca020c9:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca020cc:	be 30 03 01 00       	mov    esi,0x10330
    710d6ca020d1:	4c 89 ef             	mov    rdi,r13
    710d6ca020d4:	e8 87 e0 ff e7       	call   0x710d54a00160
    710d6ca020d9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca020e0:	00 
    710d6ca020e1:	0f 84 5a f6 ff e7    	je     0x710d54a01741
    710d6ca020e7:	e9 94 f6 ff e7       	jmp    0x710d54a01780
    710d6ca020ec:	b8 30 03 01 00       	mov    eax,0x10330
    710d6ca020f1:	83 c0 40             	add    eax,0x40
    710d6ca020f4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca020fb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02102:	02 00 00 00 
    710d6ca02106:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca0210d:	04 00 00 00 
    710d6ca02111:	be 30 03 01 00       	mov    esi,0x10330
    710d6ca02116:	ba 30 03 01 00       	mov    edx,0x10330
    710d6ca0211b:	4c 89 ef             	mov    rdi,r13
    710d6ca0211e:	e8 3d e0 ff e7       	call   0x710d54a00160
    710d6ca02123:	e9 49 f6 ff e7       	jmp    0x710d54a01771
    710d6ca02128:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10332
    710d6ca0212f:	32 03 01 00 
    710d6ca02133:	b8 32 03 01 00       	mov    eax,0x10332
    710d6ca02138:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0213f:	02 00 00 00 
    710d6ca02143:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0214a:	05 00 00 00 
    710d6ca0214e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02151:	be 32 03 01 00       	mov    esi,0x10332
    710d6ca02156:	4c 89 ef             	mov    rdi,r13
    710d6ca02159:	e8 02 e0 ff e7       	call   0x710d54a00160
    710d6ca0215e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02165:	00 
    710d6ca02166:	0f 84 89 f6 ff e7    	je     0x710d54a017f5
    710d6ca0216c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02173:	02 00 00 00 
    710d6ca02177:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0217e:	05 00 00 00 
    710d6ca02182:	58                   	pop    rax
    710d6ca02183:	e9 e7 fe ff e7       	jmp    0x710d54a0206f
    710d6ca02188:	b8 34 03 01 00       	mov    eax,0x10334
    710d6ca0218d:	83 c0 3c             	add    eax,0x3c
    710d6ca02190:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02197:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0219e:	02 00 00 00 
    710d6ca021a2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca021a9:	06 00 00 00 
    710d6ca021ad:	be 34 03 01 00       	mov    esi,0x10334
    710d6ca021b2:	ba 34 03 01 00       	mov    edx,0x10334
    710d6ca021b7:	4c 89 ef             	mov    rdi,r13
    710d6ca021ba:	e8 a1 df ff e7       	call   0x710d54a00160
    710d6ca021bf:	e9 67 f6 ff e7       	jmp    0x710d54a0182b
    710d6ca021c4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10334
    710d6ca021cb:	34 03 01 00 
    710d6ca021cf:	b8 34 03 01 00       	mov    eax,0x10334
    710d6ca021d4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca021db:	02 00 00 00 
    710d6ca021df:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca021e6:	06 00 00 00 
    710d6ca021ea:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca021ed:	be 34 03 01 00       	mov    esi,0x10334
    710d6ca021f2:	4c 89 ef             	mov    rdi,r13
    710d6ca021f5:	e8 66 df ff e7       	call   0x710d54a00160
    710d6ca021fa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02201:	00 
    710d6ca02202:	0f 84 70 f6 ff e7    	je     0x710d54a01878
    710d6ca02208:	e9 2d f6 ff e7       	jmp    0x710d54a0183a
    710d6ca0220d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10336
    710d6ca02214:	36 03 01 00 
    710d6ca02218:	b8 36 03 01 00       	mov    eax,0x10336
    710d6ca0221d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02224:	04 00 00 00 
    710d6ca02228:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca0222f:	07 00 00 00 
    710d6ca02233:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca02236:	be 36 03 01 00       	mov    esi,0x10336
    710d6ca0223b:	4c 89 ef             	mov    rdi,r13
    710d6ca0223e:	e8 1d df ff e7       	call   0x710d54a00160
    710d6ca02243:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0224a:	00 
    710d6ca0224b:	0f 84 53 f6 ff e7    	je     0x710d54a018a4
    710d6ca02251:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02258:	04 00 00 00 
    710d6ca0225c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca02263:	07 00 00 00 
    710d6ca02267:	58                   	pop    rax
    710d6ca02268:	e9 02 fe ff e7       	jmp    0x710d54a0206f
    710d6ca0226d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033a
    710d6ca02274:	3a 03 01 00 
    710d6ca02278:	b8 3a 03 01 00       	mov    eax,0x1033a
    710d6ca0227d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02284:	02 00 00 00 
    710d6ca02288:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca0228f:	08 00 00 00 
    710d6ca02293:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02296:	be 3a 03 01 00       	mov    esi,0x1033a
    710d6ca0229b:	4c 89 ef             	mov    rdi,r13
    710d6ca0229e:	e8 bd de ff e7       	call   0x710d54a00160
    710d6ca022a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca022aa:	00 
    710d6ca022ab:	0f 84 45 f6 ff e7    	je     0x710d54a018f6
    710d6ca022b1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca022b8:	02 00 00 00 
    710d6ca022bc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca022c3:	08 00 00 00 
    710d6ca022c7:	58                   	pop    rax
    710d6ca022c8:	e9 a2 fd ff e7       	jmp    0x710d54a0206f
    710d6ca022cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033c
    710d6ca022d4:	3c 03 01 00 
    710d6ca022d8:	b8 3c 03 01 00       	mov    eax,0x1033c
    710d6ca022dd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca022e4:	02 00 00 00 
    710d6ca022e8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca022ef:	09 00 00 00 
    710d6ca022f3:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca022f6:	be 3c 03 01 00       	mov    esi,0x1033c
    710d6ca022fb:	4c 89 ef             	mov    rdi,r13
    710d6ca022fe:	e8 5d de ff e7       	call   0x710d54a00160
    710d6ca02303:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0230a:	00 
    710d6ca0230b:	0f 84 4c f6 ff e7    	je     0x710d54a0195d
    710d6ca02311:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02318:	02 00 00 00 
    710d6ca0231c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca02323:	09 00 00 00 
    710d6ca02327:	58                   	pop    rax
    710d6ca02328:	e9 42 fd ff e7       	jmp    0x710d54a0206f
    710d6ca0232d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1033e
    710d6ca02334:	3e 03 01 00 
    710d6ca02338:	b8 3e 03 01 00       	mov    eax,0x1033e
    710d6ca0233d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02344:	02 00 00 00 
    710d6ca02348:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0234f:	0a 00 00 00 
    710d6ca02353:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02356:	be 3e 03 01 00       	mov    esi,0x1033e
    710d6ca0235b:	4c 89 ef             	mov    rdi,r13
    710d6ca0235e:	e8 fd dd ff e7       	call   0x710d54a00160
    710d6ca02363:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0236a:	00 
    710d6ca0236b:	0f 84 1a f6 ff e7    	je     0x710d54a0198b
    710d6ca02371:	e9 54 f6 ff e7       	jmp    0x710d54a019ca
    710d6ca02376:	b8 3e 03 01 00       	mov    eax,0x1033e
    710d6ca0237b:	83 c0 32             	add    eax,0x32
    710d6ca0237e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02385:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0238c:	02 00 00 00 
    710d6ca02390:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca02397:	0a 00 00 00 
    710d6ca0239b:	be 3e 03 01 00       	mov    esi,0x1033e
    710d6ca023a0:	ba 3e 03 01 00       	mov    edx,0x1033e
    710d6ca023a5:	4c 89 ef             	mov    rdi,r13
    710d6ca023a8:	e8 b3 dd ff e7       	call   0x710d54a00160
    710d6ca023ad:	e9 09 f6 ff e7       	jmp    0x710d54a019bb
    710d6ca023b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10340
    710d6ca023b9:	40 03 01 00 
    710d6ca023bd:	b8 40 03 01 00       	mov    eax,0x10340
    710d6ca023c2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca023c9:	04 00 00 00 
    710d6ca023cd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca023d4:	0b 00 00 00 
    710d6ca023d8:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca023db:	be 40 03 01 00       	mov    esi,0x10340
    710d6ca023e0:	4c 89 ef             	mov    rdi,r13
    710d6ca023e3:	e8 78 dd ff e7       	call   0x710d54a00160
    710d6ca023e8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca023ef:	00 
    710d6ca023f0:	0f 84 23 f6 ff e7    	je     0x710d54a01a19
    710d6ca023f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca023fd:	04 00 00 00 
    710d6ca02401:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca02408:	0b 00 00 00 
    710d6ca0240c:	58                   	pop    rax
    710d6ca0240d:	e9 5d fc ff e7       	jmp    0x710d54a0206f
    710d6ca02412:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10344
    710d6ca02419:	44 03 01 00 
    710d6ca0241d:	b8 44 03 01 00       	mov    eax,0x10344
    710d6ca02422:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02429:	04 00 00 00 
    710d6ca0242d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca02434:	0c 00 00 00 
    710d6ca02438:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca0243b:	be 44 03 01 00       	mov    esi,0x10344
    710d6ca02440:	4c 89 ef             	mov    rdi,r13
    710d6ca02443:	e8 18 dd ff e7       	call   0x710d54a00160
    710d6ca02448:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0244f:	00 
    710d6ca02450:	0f 84 fa f5 ff e7    	je     0x710d54a01a50
    710d6ca02456:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0245d:	04 00 00 00 
    710d6ca02461:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca02468:	0c 00 00 00 
    710d6ca0246c:	58                   	pop    rax
    710d6ca0246d:	e9 fd fb ff e7       	jmp    0x710d54a0206f
    710d6ca02472:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    710d6ca02479:	48 03 01 00 
    710d6ca0247d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02484:	02 00 00 00 
    710d6ca02488:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca0248f:	0d 00 00 00 
    710d6ca02493:	ba 48 03 01 00       	mov    edx,0x10348
    710d6ca02498:	4c 89 ef             	mov    rdi,r13
    710d6ca0249b:	4c 89 f6             	mov    rsi,r14
    710d6ca0249e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca024a4:	e8 d7 db ff e7       	call   0x710d54a00080
    710d6ca024a9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca024b0:	02 00 00 00 
    710d6ca024b4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca024bb:	0d 00 00 00 
    710d6ca024bf:	58                   	pop    rax
    710d6ca024c0:	e9 aa fb ff e7       	jmp    0x710d54a0206f
    710d6ca024c5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    710d6ca024cc:	48 03 01 00 
    710d6ca024d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca024d7:	02 00 00 00 
    710d6ca024db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca024e2:	0d 00 00 00 
    710d6ca024e6:	4c 89 f7             	mov    rdi,r14
    710d6ca024e9:	89 ce                	mov    esi,ecx
    710d6ca024eb:	e8 80 db ff e7       	call   0x710d54a00070
    710d6ca024f0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca024f7:	00 
    710d6ca024f8:	0f 84 90 f5 ff e7    	je     0x710d54a01a8e
    710d6ca024fe:	eb a9                	jmp    0x710d6ca024a9
    710d6ca02500:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    710d6ca02507:	48 03 01 00 
    710d6ca0250b:	b8 48 03 01 00       	mov    eax,0x10348
    710d6ca02510:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02517:	02 00 00 00 
    710d6ca0251b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca02522:	0d 00 00 00 
    710d6ca02526:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02529:	be 48 03 01 00       	mov    esi,0x10348
    710d6ca0252e:	4c 89 ef             	mov    rdi,r13
    710d6ca02531:	e8 2a dc ff e7       	call   0x710d54a00160
    710d6ca02536:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca02539:	0f 84 80 f5 ff e7    	je     0x710d54a01abf
    710d6ca0253f:	eb 0f                	jmp    0x710d6ca02550
    710d6ca02541:	b8 48 03 01 00       	mov    eax,0x10348
    710d6ca02546:	83 c0 02             	add    eax,0x2
    710d6ca02549:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02550:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02557:	02 00 00 00 
    710d6ca0255b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca02562:	0d 00 00 00 
    710d6ca02566:	4c 89 ef             	mov    rdi,r13
    710d6ca02569:	e8 e2 db ff e7       	call   0x710d54a00150
    710d6ca0256e:	e9 4c f5 ff e7       	jmp    0x710d54a01abf
    710d6ca02573:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    710d6ca0257a:	4a 03 01 00 
    710d6ca0257e:	b8 4a 03 01 00       	mov    eax,0x1034a
    710d6ca02583:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0258a:	04 00 00 00 
    710d6ca0258e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca02595:	0e 00 00 00 
    710d6ca02599:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca0259c:	be 4a 03 01 00       	mov    esi,0x1034a
    710d6ca025a1:	4c 89 ef             	mov    rdi,r13
    710d6ca025a4:	e8 b7 db ff e7       	call   0x710d54a00160
    710d6ca025a9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca025b0:	00 
    710d6ca025b1:	0f 84 4a f5 ff e7    	je     0x710d54a01b01
    710d6ca025b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca025be:	04 00 00 00 
    710d6ca025c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca025c9:	0e 00 00 00 
    710d6ca025cd:	58                   	pop    rax
    710d6ca025ce:	e9 9c fa ff e7       	jmp    0x710d54a0206f
    710d6ca025d3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034e
    710d6ca025da:	4e 03 01 00 
    710d6ca025de:	b8 4e 03 01 00       	mov    eax,0x1034e
    710d6ca025e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca025ea:	04 00 00 00 
    710d6ca025ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca025f5:	0f 00 00 00 
    710d6ca025f9:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca025fc:	be 4e 03 01 00       	mov    esi,0x1034e
    710d6ca02601:	4c 89 ef             	mov    rdi,r13
    710d6ca02604:	e8 57 db ff e7       	call   0x710d54a00160
    710d6ca02609:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02610:	00 
    710d6ca02611:	0f 84 21 f5 ff e7    	je     0x710d54a01b38
    710d6ca02617:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0261e:	04 00 00 00 
    710d6ca02622:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca02629:	0f 00 00 00 
    710d6ca0262d:	58                   	pop    rax
    710d6ca0262e:	e9 3c fa ff e7       	jmp    0x710d54a0206f
    710d6ca02633:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    710d6ca0263a:	52 03 01 00 
    710d6ca0263e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02645:	02 00 00 00 
    710d6ca02649:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca02650:	10 00 00 00 
    710d6ca02654:	ba 52 03 01 00       	mov    edx,0x10352
    710d6ca02659:	4c 89 ef             	mov    rdi,r13
    710d6ca0265c:	4c 89 f6             	mov    rsi,r14
    710d6ca0265f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca02665:	e8 16 da ff e7       	call   0x710d54a00080
    710d6ca0266a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02671:	02 00 00 00 
    710d6ca02675:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca0267c:	10 00 00 00 
    710d6ca02680:	58                   	pop    rax
    710d6ca02681:	e9 e9 f9 ff e7       	jmp    0x710d54a0206f
    710d6ca02686:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    710d6ca0268d:	52 03 01 00 
    710d6ca02691:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02698:	02 00 00 00 
    710d6ca0269c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca026a3:	10 00 00 00 
    710d6ca026a7:	4c 89 f7             	mov    rdi,r14
    710d6ca026aa:	89 ce                	mov    esi,ecx
    710d6ca026ac:	e8 bf d9 ff e7       	call   0x710d54a00070
    710d6ca026b1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca026b8:	00 
    710d6ca026b9:	0f 84 b7 f4 ff e7    	je     0x710d54a01b76
    710d6ca026bf:	eb a9                	jmp    0x710d6ca0266a
    710d6ca026c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    710d6ca026c8:	52 03 01 00 
    710d6ca026cc:	b8 52 03 01 00       	mov    eax,0x10352
    710d6ca026d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca026d8:	02 00 00 00 
    710d6ca026dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca026e3:	10 00 00 00 
    710d6ca026e7:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca026ea:	be 52 03 01 00       	mov    esi,0x10352
    710d6ca026ef:	4c 89 ef             	mov    rdi,r13
    710d6ca026f2:	e8 69 da ff e7       	call   0x710d54a00160
    710d6ca026f7:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca026fa:	0f 84 a7 f4 ff e7    	je     0x710d54a01ba7
    710d6ca02700:	eb 0f                	jmp    0x710d6ca02711
    710d6ca02702:	b8 52 03 01 00       	mov    eax,0x10352
    710d6ca02707:	83 c0 02             	add    eax,0x2
    710d6ca0270a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02711:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02718:	02 00 00 00 
    710d6ca0271c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca02723:	10 00 00 00 
    710d6ca02727:	4c 89 ef             	mov    rdi,r13
    710d6ca0272a:	e8 21 da ff e7       	call   0x710d54a00150
    710d6ca0272f:	e9 73 f4 ff e7       	jmp    0x710d54a01ba7
    710d6ca02734:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    710d6ca0273b:	54 03 01 00 
    710d6ca0273f:	b8 54 03 01 00       	mov    eax,0x10354
    710d6ca02744:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0274b:	04 00 00 00 
    710d6ca0274f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca02756:	11 00 00 00 
    710d6ca0275a:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca0275d:	be 54 03 01 00       	mov    esi,0x10354
    710d6ca02762:	4c 89 ef             	mov    rdi,r13
    710d6ca02765:	e8 f6 d9 ff e7       	call   0x710d54a00160
    710d6ca0276a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02771:	00 
    710d6ca02772:	0f 84 71 f4 ff e7    	je     0x710d54a01be9
    710d6ca02778:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0277f:	04 00 00 00 
    710d6ca02783:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x11
    710d6ca0278a:	11 00 00 00 
    710d6ca0278e:	58                   	pop    rax
    710d6ca0278f:	e9 db f8 ff e7       	jmp    0x710d54a0206f
    710d6ca02794:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10358
    710d6ca0279b:	58 03 01 00 
    710d6ca0279f:	b8 58 03 01 00       	mov    eax,0x10358
    710d6ca027a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca027ab:	04 00 00 00 
    710d6ca027af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca027b6:	12 00 00 00 
    710d6ca027ba:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca027bd:	be 58 03 01 00       	mov    esi,0x10358
    710d6ca027c2:	4c 89 ef             	mov    rdi,r13
    710d6ca027c5:	e8 96 d9 ff e7       	call   0x710d54a00160
    710d6ca027ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca027d1:	00 
    710d6ca027d2:	0f 84 48 f4 ff e7    	je     0x710d54a01c20
    710d6ca027d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca027df:	04 00 00 00 
    710d6ca027e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x12
    710d6ca027ea:	12 00 00 00 
    710d6ca027ee:	58                   	pop    rax
    710d6ca027ef:	e9 7b f8 ff e7       	jmp    0x710d54a0206f
    710d6ca027f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    710d6ca027fb:	5c 03 01 00 
    710d6ca027ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02806:	02 00 00 00 
    710d6ca0280a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca02811:	13 00 00 00 
    710d6ca02815:	ba 5c 03 01 00       	mov    edx,0x1035c
    710d6ca0281a:	4c 89 ef             	mov    rdi,r13
    710d6ca0281d:	4c 89 f6             	mov    rsi,r14
    710d6ca02820:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca02826:	e8 55 d8 ff e7       	call   0x710d54a00080
    710d6ca0282b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02832:	02 00 00 00 
    710d6ca02836:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca0283d:	13 00 00 00 
    710d6ca02841:	58                   	pop    rax
    710d6ca02842:	e9 28 f8 ff e7       	jmp    0x710d54a0206f
    710d6ca02847:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    710d6ca0284e:	5c 03 01 00 
    710d6ca02852:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02859:	02 00 00 00 
    710d6ca0285d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca02864:	13 00 00 00 
    710d6ca02868:	4c 89 f7             	mov    rdi,r14
    710d6ca0286b:	89 ce                	mov    esi,ecx
    710d6ca0286d:	e8 fe d7 ff e7       	call   0x710d54a00070
    710d6ca02872:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02879:	00 
    710d6ca0287a:	0f 84 de f3 ff e7    	je     0x710d54a01c5e
    710d6ca02880:	eb a9                	jmp    0x710d6ca0282b
    710d6ca02882:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    710d6ca02889:	5c 03 01 00 
    710d6ca0288d:	b8 5c 03 01 00       	mov    eax,0x1035c
    710d6ca02892:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02899:	02 00 00 00 
    710d6ca0289d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca028a4:	13 00 00 00 
    710d6ca028a8:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca028ab:	be 5c 03 01 00       	mov    esi,0x1035c
    710d6ca028b0:	4c 89 ef             	mov    rdi,r13
    710d6ca028b3:	e8 a8 d8 ff e7       	call   0x710d54a00160
    710d6ca028b8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca028bb:	0f 84 ce f3 ff e7    	je     0x710d54a01c8f
    710d6ca028c1:	eb 0f                	jmp    0x710d6ca028d2
    710d6ca028c3:	b8 5c 03 01 00       	mov    eax,0x1035c
    710d6ca028c8:	83 c0 02             	add    eax,0x2
    710d6ca028cb:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca028d2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca028d9:	02 00 00 00 
    710d6ca028dd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d6ca028e4:	13 00 00 00 
    710d6ca028e8:	4c 89 ef             	mov    rdi,r13
    710d6ca028eb:	e8 60 d8 ff e7       	call   0x710d54a00150
    710d6ca028f0:	e9 9a f3 ff e7       	jmp    0x710d54a01c8f
    710d6ca028f5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    710d6ca028fc:	5e 03 01 00 
    710d6ca02900:	b8 5e 03 01 00       	mov    eax,0x1035e
    710d6ca02905:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0290c:	02 00 00 00 
    710d6ca02910:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca02917:	14 00 00 00 
    710d6ca0291b:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0291e:	be 5e 03 01 00       	mov    esi,0x1035e
    710d6ca02923:	4c 89 ef             	mov    rdi,r13
    710d6ca02926:	e8 35 d8 ff e7       	call   0x710d54a00160
    710d6ca0292b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02932:	00 
    710d6ca02933:	0f 84 c9 f3 ff e7    	je     0x710d54a01d02
    710d6ca02939:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02940:	02 00 00 00 
    710d6ca02944:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    710d6ca0294b:	14 00 00 00 
    710d6ca0294f:	58                   	pop    rax
    710d6ca02950:	e9 1a f7 ff e7       	jmp    0x710d54a0206f
    710d6ca02955:	b8 60 03 01 00       	mov    eax,0x10360
    710d6ca0295a:	83 c0 1a             	add    eax,0x1a
    710d6ca0295d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02964:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0296b:	02 00 00 00 
    710d6ca0296f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca02976:	15 00 00 00 
    710d6ca0297a:	be 60 03 01 00       	mov    esi,0x10360
    710d6ca0297f:	ba 60 03 01 00       	mov    edx,0x10360
    710d6ca02984:	4c 89 ef             	mov    rdi,r13
    710d6ca02987:	e8 d4 d7 ff e7       	call   0x710d54a00160
    710d6ca0298c:	e9 a7 f3 ff e7       	jmp    0x710d54a01d38
    710d6ca02991:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10360
    710d6ca02998:	60 03 01 00 
    710d6ca0299c:	b8 60 03 01 00       	mov    eax,0x10360
    710d6ca029a1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca029a8:	02 00 00 00 
    710d6ca029ac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d6ca029b3:	15 00 00 00 
    710d6ca029b7:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca029ba:	be 60 03 01 00       	mov    esi,0x10360
    710d6ca029bf:	4c 89 ef             	mov    rdi,r13
    710d6ca029c2:	e8 99 d7 ff e7       	call   0x710d54a00160
    710d6ca029c7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca029ce:	00 
    710d6ca029cf:	0f 84 b0 f3 ff e7    	je     0x710d54a01d85
    710d6ca029d5:	e9 6d f3 ff e7       	jmp    0x710d54a01d47
    710d6ca029da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10362
    710d6ca029e1:	62 03 01 00 
    710d6ca029e5:	b8 62 03 01 00       	mov    eax,0x10362
    710d6ca029ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca029f1:	02 00 00 00 
    710d6ca029f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca029fc:	16 00 00 00 
    710d6ca02a00:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02a03:	be 62 03 01 00       	mov    esi,0x10362
    710d6ca02a08:	4c 89 ef             	mov    rdi,r13
    710d6ca02a0b:	e8 50 d7 ff e7       	call   0x710d54a00160
    710d6ca02a10:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02a17:	00 
    710d6ca02a18:	0f 84 cc f3 ff e7    	je     0x710d54a01dea
    710d6ca02a1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02a25:	02 00 00 00 
    710d6ca02a29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    710d6ca02a30:	16 00 00 00 
    710d6ca02a34:	58                   	pop    rax
    710d6ca02a35:	e9 35 f6 ff e7       	jmp    0x710d54a0206f
    710d6ca02a3a:	b8 64 03 01 00       	mov    eax,0x10364
    710d6ca02a3f:	83 c0 40             	add    eax,0x40
    710d6ca02a42:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca02a49:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02a50:	02 00 00 00 
    710d6ca02a54:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca02a5b:	17 00 00 00 
    710d6ca02a5f:	be 64 03 01 00       	mov    esi,0x10364
    710d6ca02a64:	ba 64 03 01 00       	mov    edx,0x10364
    710d6ca02a69:	4c 89 ef             	mov    rdi,r13
    710d6ca02a6c:	e8 ef d6 ff e7       	call   0x710d54a00160
    710d6ca02a71:	e9 aa f3 ff e7       	jmp    0x710d54a01e20
    710d6ca02a76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10364
    710d6ca02a7d:	64 03 01 00 
    710d6ca02a81:	b8 64 03 01 00       	mov    eax,0x10364
    710d6ca02a86:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02a8d:	02 00 00 00 
    710d6ca02a91:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d6ca02a98:	17 00 00 00 
    710d6ca02a9c:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02a9f:	be 64 03 01 00       	mov    esi,0x10364
    710d6ca02aa4:	4c 89 ef             	mov    rdi,r13
    710d6ca02aa7:	e8 b4 d6 ff e7       	call   0x710d54a00160
    710d6ca02aac:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02ab3:	00 
    710d6ca02ab4:	0f 84 b3 f3 ff e7    	je     0x710d54a01e6d
    710d6ca02aba:	e9 70 f3 ff e7       	jmp    0x710d54a01e2f
    710d6ca02abf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10366
    710d6ca02ac6:	66 03 01 00 
    710d6ca02aca:	b8 66 03 01 00       	mov    eax,0x10366
    710d6ca02acf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02ad6:	02 00 00 00 
    710d6ca02ada:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    710d6ca02ae1:	18 00 00 00 
    710d6ca02ae5:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02ae8:	be 66 03 01 00       	mov    esi,0x10366
    710d6ca02aed:	4c 89 ef             	mov    rdi,r13
    710d6ca02af0:	e8 6b d6 ff e7       	call   0x710d54a00160
    710d6ca02af5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02afc:	00 
    710d6ca02afd:	0f 84 96 f3 ff e7    	je     0x710d54a01e99
    710d6ca02b03:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02b0a:	02 00 00 00 
    710d6ca02b0e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    710d6ca02b15:	18 00 00 00 
    710d6ca02b19:	58                   	pop    rax
    710d6ca02b1a:	e9 50 f5 ff e7       	jmp    0x710d54a0206f
    710d6ca02b1f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca02b26:	68 03 01 00 
    710d6ca02b2a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02b31:	04 00 00 00 
    710d6ca02b35:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca02b3c:	19 00 00 00 
    710d6ca02b40:	ba 68 03 01 00       	mov    edx,0x10368
    710d6ca02b45:	4c 89 ef             	mov    rdi,r13
    710d6ca02b48:	4c 89 f6             	mov    rsi,r14
    710d6ca02b4b:	89 d9                	mov    ecx,ebx
    710d6ca02b4d:	45 31 c0             	xor    r8d,r8d
    710d6ca02b50:	e8 2b d5 ff e7       	call   0x710d54a00080
    710d6ca02b55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02b5c:	04 00 00 00 
    710d6ca02b60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca02b67:	19 00 00 00 
    710d6ca02b6b:	58                   	pop    rax
    710d6ca02b6c:	e9 fe f4 ff e7       	jmp    0x710d54a0206f
    710d6ca02b71:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca02b78:	68 03 01 00 
    710d6ca02b7c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02b83:	04 00 00 00 
    710d6ca02b87:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca02b8e:	19 00 00 00 
    710d6ca02b92:	4c 89 f7             	mov    rdi,r14
    710d6ca02b95:	89 de                	mov    esi,ebx
    710d6ca02b97:	e8 a4 d4 ff e7       	call   0x710d54a00040
    710d6ca02b9c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02ba3:	00 
    710d6ca02ba4:	75 af                	jne    0x710d6ca02b55
    710d6ca02ba6:	41 89 c7             	mov    r15d,eax
    710d6ca02ba9:	e9 22 f3 ff e7       	jmp    0x710d54a01ed0
    710d6ca02bae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca02bb5:	68 03 01 00 
    710d6ca02bb9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02bc0:	04 00 00 00 
    710d6ca02bc4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca02bcb:	19 00 00 00 
    710d6ca02bcf:	4c 89 f7             	mov    rdi,r14
    710d6ca02bd2:	e8 69 d4 ff e7       	call   0x710d54a00040
    710d6ca02bd7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02bde:	00 
    710d6ca02bdf:	0f 84 0c f3 ff e7    	je     0x710d54a01ef1
    710d6ca02be5:	e9 6b ff ff ff       	jmp    0x710d6ca02b55
    710d6ca02bea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca02bf1:	68 03 01 00 
    710d6ca02bf5:	b8 68 03 01 00       	mov    eax,0x10368
    710d6ca02bfa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02c01:	04 00 00 00 
    710d6ca02c05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    710d6ca02c0c:	19 00 00 00 
    710d6ca02c10:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca02c13:	be 68 03 01 00       	mov    esi,0x10368
    710d6ca02c18:	4c 89 ef             	mov    rdi,r13
    710d6ca02c1b:	e8 40 d5 ff e7       	call   0x710d54a00160
    710d6ca02c20:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02c27:	00 
    710d6ca02c28:	0f 84 f7 f2 ff e7    	je     0x710d54a01f25
    710d6ca02c2e:	e9 22 ff ff ff       	jmp    0x710d6ca02b55
    710d6ca02c33:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02c3a:	6c 03 01 00 
    710d6ca02c3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02c45:	02 00 00 00 
    710d6ca02c49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02c50:	1a 00 00 00 
    710d6ca02c54:	ba 6c 03 01 00       	mov    edx,0x1036c
    710d6ca02c59:	4c 89 ef             	mov    rdi,r13
    710d6ca02c5c:	4c 89 f6             	mov    rsi,r14
    710d6ca02c5f:	89 d9                	mov    ecx,ebx
    710d6ca02c61:	45 31 c0             	xor    r8d,r8d
    710d6ca02c64:	e8 17 d4 ff e7       	call   0x710d54a00080
    710d6ca02c69:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02c70:	02 00 00 00 
    710d6ca02c74:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02c7b:	1a 00 00 00 
    710d6ca02c7f:	58                   	pop    rax
    710d6ca02c80:	e9 ea f3 ff e7       	jmp    0x710d54a0206f
    710d6ca02c85:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02c8c:	6c 03 01 00 
    710d6ca02c90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02c97:	02 00 00 00 
    710d6ca02c9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02ca2:	1a 00 00 00 
    710d6ca02ca6:	4c 89 f7             	mov    rdi,r14
    710d6ca02ca9:	89 de                	mov    esi,ebx
    710d6ca02cab:	e8 90 d3 ff e7       	call   0x710d54a00040
    710d6ca02cb0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02cb7:	00 
    710d6ca02cb8:	0f 84 9d f2 ff e7    	je     0x710d54a01f5b
    710d6ca02cbe:	eb a9                	jmp    0x710d6ca02c69
    710d6ca02cc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02cc7:	6c 03 01 00 
    710d6ca02ccb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02cd2:	02 00 00 00 
    710d6ca02cd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02cdd:	1a 00 00 00 
    710d6ca02ce1:	4c 89 f7             	mov    rdi,r14
    710d6ca02ce4:	e8 57 d3 ff e7       	call   0x710d54a00040
    710d6ca02ce9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02cf0:	00 
    710d6ca02cf1:	0f 84 87 f2 ff e7    	je     0x710d54a01f7e
    710d6ca02cf7:	e9 6d ff ff ff       	jmp    0x710d6ca02c69
    710d6ca02cfc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02d03:	6c 03 01 00 
    710d6ca02d07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02d0e:	02 00 00 00 
    710d6ca02d12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02d19:	1a 00 00 00 
    710d6ca02d1d:	4c 89 f7             	mov    rdi,r14
    710d6ca02d20:	e8 1b d3 ff e7       	call   0x710d54a00040
    710d6ca02d25:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02d2c:	00 
    710d6ca02d2d:	0f 84 6e f2 ff e7    	je     0x710d54a01fa1
    710d6ca02d33:	e9 31 ff ff ff       	jmp    0x710d6ca02c69
    710d6ca02d38:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02d3f:	6c 03 01 00 
    710d6ca02d43:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02d4a:	02 00 00 00 
    710d6ca02d4e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02d55:	1a 00 00 00 
    710d6ca02d59:	4c 89 f7             	mov    rdi,r14
    710d6ca02d5c:	e8 df d2 ff e7       	call   0x710d54a00040
    710d6ca02d61:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02d68:	00 
    710d6ca02d69:	0f 84 55 f2 ff e7    	je     0x710d54a01fc4
    710d6ca02d6f:	e9 f5 fe ff ff       	jmp    0x710d6ca02c69
    710d6ca02d74:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02d7b:	6c 03 01 00 
    710d6ca02d7f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02d86:	02 00 00 00 
    710d6ca02d8a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02d91:	1a 00 00 00 
    710d6ca02d95:	4c 89 f7             	mov    rdi,r14
    710d6ca02d98:	e8 a3 d2 ff e7       	call   0x710d54a00040
    710d6ca02d9d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02da4:	00 
    710d6ca02da5:	0f 84 3e f2 ff e7    	je     0x710d54a01fe9
    710d6ca02dab:	e9 b9 fe ff ff       	jmp    0x710d6ca02c69
    710d6ca02db0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca02db7:	6c 03 01 00 
    710d6ca02dbb:	b8 6c 03 01 00       	mov    eax,0x1036c
    710d6ca02dc0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02dc7:	02 00 00 00 
    710d6ca02dcb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    710d6ca02dd2:	1a 00 00 00 
    710d6ca02dd6:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02dd9:	be 6c 03 01 00       	mov    esi,0x1036c
    710d6ca02dde:	4c 89 ef             	mov    rdi,r13
    710d6ca02de1:	e8 7a d3 ff e7       	call   0x710d54a00160
    710d6ca02de6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02ded:	00 
    710d6ca02dee:	0f 84 22 f2 ff e7    	je     0x710d54a02016
    710d6ca02df4:	e9 70 fe ff ff       	jmp    0x710d6ca02c69
    710d6ca02df9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    710d6ca02e00:	6e 03 01 00 
    710d6ca02e04:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02e0b:	02 00 00 00 
    710d6ca02e0f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca02e16:	1b 00 00 00 
    710d6ca02e1a:	4c 89 ef             	mov    rdi,r13
    710d6ca02e1d:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca02e22:	4c 89 f2             	mov    rdx,r14
    710d6ca02e25:	e8 66 d2 ff e7       	call   0x710d54a00090
    710d6ca02e2a:	e9 29 f2 ff e7       	jmp    0x710d54a02058
    710d6ca02e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02e36:	02 00 00 00 
    710d6ca02e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d6ca02e41:	1b 00 00 00 
    710d6ca02e45:	be 6e 03 01 00       	mov    esi,0x1036e
    710d6ca02e4a:	ba 6e 03 01 00       	mov    edx,0x1036e
    710d6ca02e4f:	4c 89 ef             	mov    rdi,r13
    710d6ca02e52:	e8 09 d3 ff e7       	call   0x710d54a00160
    710d6ca02e57:	e9 fc f1 ff e7       	jmp    0x710d54a02058
    710d6ca02e5c:	c2 08 00             	ret    0x8
