
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66578-0-124302068316256.bin:     file format binary


Disassembly of section .data:

0000710d54a07860 <.data>:
    710d54a07860:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    710d54a07867:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    710d54a0786c:	4d 89 e8             	mov    r8,r13
    710d54a0786f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a07876:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    710d54a0787b:	45 8b 95 58 01 00 00 	mov    r10d,DWORD PTR [r13+0x158]
    710d54a07882:	b8 db fb fe ff       	mov    eax,0xfffefbdb
    710d54a07887:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    710d54a0788e:	83 f8 ec             	cmp    eax,0xffffffec
    710d54a07891:	0f 87 c5 00 00 18    	ja     0x710d6ca0795c
    710d54a07897:	41 81 b8 a4 00 00 00 	cmp    DWORD PTR [r8+0xa4],0x10420
    710d54a0789e:	20 04 01 00 
    710d54a078a2:	0f 85 b4 00 00 18    	jne    0x710d6ca0795c
    710d54a078a8:	41 81 b8 94 00 00 00 	cmp    DWORD PTR [r8+0x94],0x10412
    710d54a078af:	12 04 01 00 
    710d54a078b3:	0f 85 a3 00 00 18    	jne    0x710d6ca0795c
    710d54a078b9:	4d 8b 98 40 01 00 00 	mov    r11,QWORD PTR [r8+0x140]
    710d54a078c0:	49 8b b8 38 01 00 00 	mov    rdi,QWORD PTR [r8+0x138]
    710d54a078c7:	41 8b 40 34          	mov    eax,DWORD PTR [r8+0x34]
    710d54a078cb:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    710d54a078d0:	41 8b 40 24          	mov    eax,DWORD PTR [r8+0x24]
    710d54a078d4:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    710d54a078d9:	41 8b 00             	mov    eax,DWORD PTR [r8]
    710d54a078dc:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    710d54a078e0:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    710d54a078e4:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    710d54a078e8:	41 8b 40 20          	mov    eax,DWORD PTR [r8+0x20]
    710d54a078ec:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    710d54a078f3:	00 
    710d54a078f4:	41 8b 40 2c          	mov    eax,DWORD PTR [r8+0x2c]
    710d54a078f8:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    710d54a078fd:	45 8b a0 9c 00 00 00 	mov    r12d,DWORD PTR [r8+0x9c]
    710d54a07904:	45 8b b0 00 01 00 00 	mov    r14d,DWORD PTR [r8+0x100]
    710d54a0790b:	45 8b b8 5c 01 00 00 	mov    r15d,DWORD PTR [r8+0x15c]
    710d54a07912:	48 89 7c 24 68       	mov    QWORD PTR [rsp+0x68],rdi
    710d54a07917:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    710d54a0791e:	00 00 
    710d54a07920:	44 89 64 24 10       	mov    DWORD PTR [rsp+0x10],r12d
    710d54a07925:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d54a07929:	44 89 f1             	mov    ecx,r14d
    710d54a0792c:	8d 70 01             	lea    esi,[rax+0x1]
    710d54a0792f:	c1 e8 1f             	shr    eax,0x1f
    710d54a07932:	89 f2                	mov    edx,esi
    710d54a07934:	c1 ea 1f             	shr    edx,0x1f
    710d54a07937:	c4 62 78 f2 f2       	andn   r14d,eax,edx
    710d54a0793c:	41 09 ce             	or     r14d,ecx
    710d54a0793f:	45 31 c9             	xor    r9d,r9d
    710d54a07942:	89 f3                	mov    ebx,esi
    710d54a07944:	23 5c 24 5c          	and    ebx,DWORD PTR [rsp+0x5c]
    710d54a07948:	41 0f 94 c1          	sete   r9b
    710d54a0794c:	41 89 dc             	mov    r12d,ebx
    710d54a0794f:	41 c1 ec 1f          	shr    r12d,0x1f
    710d54a07953:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    710d54a07958:	40 f6 c5 03          	test   bpl,0x3
    710d54a0795c:	0f 85 78 03 00 00    	jne    0x710d54a07cda
    710d54a07962:	89 e8                	mov    eax,ebp
    710d54a07964:	c1 e8 0c             	shr    eax,0xc
    710d54a07967:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    710d54a0796b:	48 85 c0             	test   rax,rax
    710d54a0796e:	44 89 4c 24 14       	mov    DWORD PTR [rsp+0x14],r9d
    710d54a07973:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    710d54a07977:	0f 84 f9 03 00 00    	je     0x710d54a07d76
    710d54a0797d:	89 e9                	mov    ecx,ebp
    710d54a0797f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a07985:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a07988:	83 c5 04             	add    ebp,0x4
    710d54a0798b:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    710d54a07992:	00 
    710d54a07993:	44 8d 2c 99          	lea    r13d,[rcx+rbx*4]
    710d54a07997:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    710d54a0799c:	8d 0c 81             	lea    ecx,[rcx+rax*4]
    710d54a0799f:	41 f6 c5 03          	test   r13b,0x3
    710d54a079a3:	0f 85 a7 04 00 00    	jne    0x710d54a07e50
    710d54a079a9:	44 89 e8             	mov    eax,r13d
    710d54a079ac:	c1 e8 0c             	shr    eax,0xc
    710d54a079af:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    710d54a079b3:	48 85 c0             	test   rax,rax
    710d54a079b6:	44 89 64 24 20       	mov    DWORD PTR [rsp+0x20],r12d
    710d54a079bb:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a079c0:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    710d54a079c5:	0f 84 eb 05 00 00    	je     0x710d54a07fb6
    710d54a079cb:	44 89 eb             	mov    ebx,r13d
    710d54a079ce:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    710d54a079d4:	8b 14 18             	mov    edx,DWORD PTR [rax+rbx*1]
    710d54a079d7:	44 89 74 24 18       	mov    DWORD PTR [rsp+0x18],r14d
    710d54a079dc:	f6 c1 03             	test   cl,0x3
    710d54a079df:	0f 85 ad 06 00 00    	jne    0x710d54a08092
    710d54a079e5:	89 c8                	mov    eax,ecx
    710d54a079e7:	c1 e8 0c             	shr    eax,0xc
    710d54a079ea:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    710d54a079ee:	48 85 c0             	test   rax,rax
    710d54a079f1:	89 54 24 24          	mov    DWORD PTR [rsp+0x24],edx
    710d54a079f5:	0f 84 39 07 00 00    	je     0x710d54a08134
    710d54a079fb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a07a01:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a07a04:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    710d54a07a09:	41 83 fc 02          	cmp    r12d,0x2
    710d54a07a0d:	72 74                	jb     0x710d54a07a83
    710d54a07a0f:	41 ff cc             	dec    r12d
    710d54a07a12:	41 be 12 04 01 00    	mov    r14d,0x10412
    710d54a07a18:	bd 08 00 00 00       	mov    ebp,0x8
    710d54a07a1d:	41 80 3b 00          	cmp    BYTE PTR [r11],0x0
    710d54a07a21:	0f 85 df 07 00 00    	jne    0x710d54a08206
    710d54a07a27:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    710d54a07a2c:	c7 44 24 44 00 00 00 	mov    DWORD PTR [rsp+0x44],0x0
    710d54a07a33:	00 
    710d54a07a34:	c7 44 24 10 02 00 00 	mov    DWORD PTR [rsp+0x10],0x2
    710d54a07a3b:	00 
    710d54a07a3c:	44 89 f9             	mov    ecx,r15d
    710d54a07a3f:	31 f6                	xor    esi,esi
    710d54a07a41:	31 c0                	xor    eax,eax
    710d54a07a43:	31 d2                	xor    edx,edx
    710d54a07a45:	48 89 eb             	mov    rbx,rbp
    710d54a07a48:	44 8d 3c 29          	lea    r15d,[rcx+rbp*1]
    710d54a07a4c:	45 39 d7             	cmp    r15d,r10d
    710d54a07a4f:	0f 83 e2 01 00 00    	jae    0x710d54a07c37
    710d54a07a55:	41 8b b8 58 01 00 00 	mov    edi,DWORD PTR [r8+0x158]
    710d54a07a5c:	85 ff                	test   edi,edi
    710d54a07a5e:	0f 84 d3 01 00 00    	je     0x710d54a07c37
    710d54a07a64:	41 81 fe 12 04 01 00 	cmp    r14d,0x10412
    710d54a07a6b:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    710d54a07a70:	4c 89 f5             	mov    rbp,r14
    710d54a07a73:	44 8b 74 24 18       	mov    r14d,DWORD PTR [rsp+0x18]
    710d54a07a78:	0f 84 a2 fe ff ff    	je     0x710d54a07920
    710d54a07a7e:	e9 e3 00 00 00       	jmp    0x710d54a07b66
    710d54a07a83:	41 80 3b 00          	cmp    BYTE PTR [r11],0x0
    710d54a07a87:	0f 85 e9 fe ff 17    	jne    0x710d6ca07976
    710d54a07a8d:	41 8d 47 0a          	lea    eax,[r15+0xa]
    710d54a07a91:	44 39 d0             	cmp    eax,r10d
    710d54a07a94:	0f 83 21 fe ff 17    	jae    0x710d6ca078bb
    710d54a07a9a:	41 8b 88 58 01 00 00 	mov    ecx,DWORD PTR [r8+0x158]
    710d54a07aa1:	85 c9                	test   ecx,ecx
    710d54a07aa3:	0f 84 12 fe ff 17    	je     0x710d6ca078bb
    710d54a07aa9:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    710d54a07aae:	81 b9 40 1b 08 00 68 	cmp    DWORD PTR [rcx+0x81b40],0x10368
    710d54a07ab5:	03 01 00 
    710d54a07ab8:	0f 85 fd fd ff 17    	jne    0x710d6ca078bb
    710d54a07abe:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    710d54a07ac3:	48 8b 89 48 1b 08 00 	mov    rcx,QWORD PTR [rcx+0x81b48]
    710d54a07aca:	41 c7 00 00 00 00 00 	mov    DWORD PTR [r8],0x0
    710d54a07ad1:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    710d54a07ad5:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    710d54a07ad9:	48 8b 54 24 30       	mov    rdx,QWORD PTR [rsp+0x30]
    710d54a07ade:	41 89 50 24          	mov    DWORD PTR [r8+0x24],edx
    710d54a07ae2:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a07ae6:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    710d54a07aeb:	41 89 50 34          	mov    DWORD PTR [r8+0x34],edx
    710d54a07aef:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    710d54a07af6:	00 00 00 00 
    710d54a07afa:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10368
    710d54a07b01:	68 03 01 00 
    710d54a07b05:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    710d54a07b09:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    710d54a07b10:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    710d54a07b14:	41 89 90 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edx
    710d54a07b1b:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a07b22:	00 00 00 00 
    710d54a07b26:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a07b2d:	00 00 00 00 
    710d54a07b31:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    710d54a07b35:	41 89 90 00 01 00 00 	mov    DWORD PTR [r8+0x100],edx
    710d54a07b3c:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a07b43:	02 00 00 00 
    710d54a07b47:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a07b4e:	00 
    710d54a07b4f:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x9
    710d54a07b56:	09 00 00 00 
    710d54a07b5a:	41 89 80 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],eax
    710d54a07b61:	e9 c0 00 00 00       	jmp    0x710d54a07c26
    710d54a07b66:	44 8d 0c ed 00 00 00 	lea    r9d,[rbp*8+0x0]
    710d54a07b6d:	00 
    710d54a07b6e:	41 81 e1 f0 ff 0f 00 	and    r9d,0xffff0
    710d54a07b75:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    710d54a07b7a:	42 39 2c 0f          	cmp    DWORD PTR [rdi+r9*1],ebp
    710d54a07b7e:	49 89 ee             	mov    r14,rbp
    710d54a07b81:	0f 85 b0 00 00 00    	jne    0x710d54a07c37
    710d54a07b87:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    710d54a07b8c:	4a 8b 4c 09 08       	mov    rcx,QWORD PTR [rcx+r9*1+0x8]
    710d54a07b91:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    710d54a07b95:	41 89 38             	mov    DWORD PTR [r8],edi
    710d54a07b98:	8b 7c 24 24          	mov    edi,DWORD PTR [rsp+0x24]
    710d54a07b9c:	41 89 78 04          	mov    DWORD PTR [r8+0x4],edi
    710d54a07ba0:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
    710d54a07ba5:	41 89 78 24          	mov    DWORD PTR [r8+0x24],edi
    710d54a07ba9:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a07bad:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    710d54a07bb2:	41 89 78 34          	mov    DWORD PTR [r8+0x34],edi
    710d54a07bb6:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    710d54a07bbd:	45 89 b0 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],r14d
    710d54a07bc4:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    710d54a07bc8:	41 89 b8 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edi
    710d54a07bcf:	8b 7c 24 20          	mov    edi,DWORD PTR [rsp+0x20]
    710d54a07bd3:	41 89 b8 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edi
    710d54a07bda:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    710d54a07be1:	41 89 80 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],eax
    710d54a07be8:	41 89 b0 f8 00 00 00 	mov    DWORD PTR [r8+0xf8],esi
    710d54a07bef:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    710d54a07bf3:	41 89 80 fc 00 00 00 	mov    DWORD PTR [r8+0xfc],eax
    710d54a07bfa:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a07bfe:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d54a07c05:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07c09:	41 89 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],eax
    710d54a07c10:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a07c17:	00 
    710d54a07c18:	41 89 98 34 01 00 00 	mov    DWORD PTR [r8+0x134],ebx
    710d54a07c1f:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a07c26:	4d 89 c5             	mov    r13,r8
    710d54a07c29:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    710d54a07c2e:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d54a07c35:	ff e1                	jmp    rcx
    710d54a07c37:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    710d54a07c3b:	41 89 38             	mov    DWORD PTR [r8],edi
    710d54a07c3e:	8b 7c 24 24          	mov    edi,DWORD PTR [rsp+0x24]
    710d54a07c42:	41 89 78 04          	mov    DWORD PTR [r8+0x4],edi
    710d54a07c46:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
    710d54a07c4b:	41 89 78 24          	mov    DWORD PTR [r8+0x24],edi
    710d54a07c4f:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a07c53:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    710d54a07c58:	41 89 78 34          	mov    DWORD PTR [r8+0x34],edi
    710d54a07c5c:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    710d54a07c63:	45 89 b0 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],r14d
    710d54a07c6a:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    710d54a07c6e:	41 89 b8 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edi
    710d54a07c75:	8b 7c 24 20          	mov    edi,DWORD PTR [rsp+0x20]
    710d54a07c79:	41 89 b8 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edi
    710d54a07c80:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    710d54a07c87:	41 89 80 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],eax
    710d54a07c8e:	41 89 b0 f8 00 00 00 	mov    DWORD PTR [r8+0xf8],esi
    710d54a07c95:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    710d54a07c99:	41 89 80 fc 00 00 00 	mov    DWORD PTR [r8+0xfc],eax
    710d54a07ca0:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a07ca4:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d54a07cab:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07caf:	41 89 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],eax
    710d54a07cb6:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    710d54a07cbb:	41 88 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],al
    710d54a07cc2:	41 89 98 34 01 00 00 	mov    DWORD PTR [r8+0x134],ebx
    710d54a07cc9:	41 89 88 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],ecx
    710d54a07cd0:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d54a07cd7:	c2 08 00             	ret    0x8
    710d54a07cda:	41 89 30             	mov    DWORD PTR [r8],esi
    710d54a07cdd:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    710d54a07ce1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d54a07ce6:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    710d54a07cea:	41 89 58 30          	mov    DWORD PTR [r8+0x30],ebx
    710d54a07cee:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    710d54a07cf2:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07cf6:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    710d54a07cfd:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10418
    710d54a07d04:	18 04 01 00 
    710d54a07d08:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    710d54a07d0f:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    710d54a07d16:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a07d1d:	00 00 00 00 
    710d54a07d21:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a07d28:	00 00 00 00 
    710d54a07d2c:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    710d54a07d33:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a07d3a:	02 00 00 00 
    710d54a07d3e:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a07d45:	00 
    710d54a07d46:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x4
    710d54a07d4d:	04 00 00 00 
    710d54a07d51:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a07d58:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a07d5f:	56 00 00 
    710d54a07d62:	4c 89 c7             	mov    rdi,r8
    710d54a07d65:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    710d54a07d6a:	ba 18 04 01 00       	mov    edx,0x10418
    710d54a07d6f:	89 e9                	mov    ecx,ebp
    710d54a07d71:	e9 6d 01 00 00       	jmp    0x710d54a07ee3
    710d54a07d76:	41 89 30             	mov    DWORD PTR [r8],esi
    710d54a07d79:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    710d54a07d7d:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d54a07d82:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    710d54a07d86:	41 89 58 30          	mov    DWORD PTR [r8+0x30],ebx
    710d54a07d8a:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    710d54a07d8e:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07d92:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    710d54a07d99:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10418
    710d54a07da0:	18 04 01 00 
    710d54a07da4:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    710d54a07dab:	45 89 e5             	mov    r13d,r12d
    710d54a07dae:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    710d54a07db5:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a07dbc:	00 00 00 00 
    710d54a07dc0:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a07dc7:	00 00 00 00 
    710d54a07dcb:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    710d54a07dd2:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a07dd9:	02 00 00 00 
    710d54a07ddd:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a07de4:	00 
    710d54a07de5:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x4
    710d54a07dec:	04 00 00 00 
    710d54a07df0:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a07df7:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a07dfe:	56 00 00 
    710d54a07e01:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    710d54a07e06:	89 ee                	mov    esi,ebp
    710d54a07e08:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    710d54a07e0d:	44 89 d5             	mov    ebp,r10d
    710d54a07e10:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    710d54a07e15:	ff d0                	call   rax
    710d54a07e17:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    710d54a07e1c:	41 89 ea             	mov    r10d,ebp
    710d54a07e1f:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    710d54a07e24:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    710d54a07e2b:	00 
    710d54a07e2c:	40 84 ff             	test   dil,dil
    710d54a07e2f:	0f 85 cd 00 00 00    	jne    0x710d54a07f02
    710d54a07e35:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    710d54a07e3a:	44 8b 4c 24 14       	mov    r9d,DWORD PTR [rsp+0x14]
    710d54a07e3f:	45 89 ec             	mov    r12d,r13d
    710d54a07e42:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    710d54a07e46:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    710d54a07e4b:	e9 38 fb ff ff       	jmp    0x710d54a07988
    710d54a07e50:	41 89 30             	mov    DWORD PTR [r8],esi
    710d54a07e53:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    710d54a07e57:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    710d54a07e5b:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a07e5f:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    710d54a07e63:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07e67:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    710d54a07e6e:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1041e
    710d54a07e75:	1e 04 01 00 
    710d54a07e79:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    710d54a07e80:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    710d54a07e87:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a07e8e:	00 00 00 00 
    710d54a07e92:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a07e99:	00 00 00 00 
    710d54a07e9d:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    710d54a07ea4:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a07eab:	02 00 00 00 
    710d54a07eaf:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a07eb6:	00 
    710d54a07eb7:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x7
    710d54a07ebe:	07 00 00 00 
    710d54a07ec2:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a07ec9:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a07ed0:	56 00 00 
    710d54a07ed3:	4c 89 c7             	mov    rdi,r8
    710d54a07ed6:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    710d54a07edb:	ba 1e 04 01 00       	mov    edx,0x1041e
    710d54a07ee0:	44 89 e9             	mov    ecx,r13d
    710d54a07ee3:	4d 89 c5             	mov    r13,r8
    710d54a07ee6:	45 31 c0             	xor    r8d,r8d
    710d54a07ee9:	44 89 d5             	mov    ebp,r10d
    710d54a07eec:	4d 89 df             	mov    r15,r11
    710d54a07eef:	ff d0                	call   rax
    710d54a07ef1:	4d 89 fb             	mov    r11,r15
    710d54a07ef4:	41 89 ea             	mov    r10d,ebp
    710d54a07ef7:	4d 89 e8             	mov    r8,r13
    710d54a07efa:	41 0f b6 bd 28 01 00 	movzx  edi,BYTE PTR [r13+0x128]
    710d54a07f01:	00 
    710d54a07f02:	41 8b 00             	mov    eax,DWORD PTR [r8]
    710d54a07f05:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    710d54a07f09:	41 8b 40 04          	mov    eax,DWORD PTR [r8+0x4]
    710d54a07f0d:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    710d54a07f11:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    710d54a07f15:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    710d54a07f19:	41 8b 40 20          	mov    eax,DWORD PTR [r8+0x20]
    710d54a07f1d:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    710d54a07f24:	00 
    710d54a07f25:	41 8b 40 24          	mov    eax,DWORD PTR [r8+0x24]
    710d54a07f29:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    710d54a07f2e:	41 8b 40 2c          	mov    eax,DWORD PTR [r8+0x2c]
    710d54a07f32:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    710d54a07f37:	45 8b 68 30          	mov    r13d,DWORD PTR [r8+0x30]
    710d54a07f3b:	41 8b 40 34          	mov    eax,DWORD PTR [r8+0x34]
    710d54a07f3f:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    710d54a07f44:	45 8b a0 9c 00 00 00 	mov    r12d,DWORD PTR [r8+0x9c]
    710d54a07f4b:	45 8b b0 bc 00 00 00 	mov    r14d,DWORD PTR [r8+0xbc]
    710d54a07f52:	41 8b 80 e4 00 00 00 	mov    eax,DWORD PTR [r8+0xe4]
    710d54a07f59:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    710d54a07f5d:	41 8b 80 e8 00 00 00 	mov    eax,DWORD PTR [r8+0xe8]
    710d54a07f64:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    710d54a07f68:	41 8b 90 ec 00 00 00 	mov    edx,DWORD PTR [r8+0xec]
    710d54a07f6f:	41 8b 80 f0 00 00 00 	mov    eax,DWORD PTR [r8+0xf0]
    710d54a07f76:	40 88 7c 24 0f       	mov    BYTE PTR [rsp+0xf],dil
    710d54a07f7b:	41 8b b0 f8 00 00 00 	mov    esi,DWORD PTR [r8+0xf8]
    710d54a07f82:	41 8b 88 fc 00 00 00 	mov    ecx,DWORD PTR [r8+0xfc]
    710d54a07f89:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    710d54a07f8d:	41 8b 88 00 01 00 00 	mov    ecx,DWORD PTR [r8+0x100]
    710d54a07f94:	89 4c 24 18          	mov    DWORD PTR [rsp+0x18],ecx
    710d54a07f98:	41 8b 88 24 01 00 00 	mov    ecx,DWORD PTR [r8+0x124]
    710d54a07f9f:	89 4c 24 10          	mov    DWORD PTR [rsp+0x10],ecx
    710d54a07fa3:	41 8b a8 34 01 00 00 	mov    ebp,DWORD PTR [r8+0x134]
    710d54a07faa:	41 8b 88 5c 01 00 00 	mov    ecx,DWORD PTR [r8+0x15c]
    710d54a07fb1:	e9 8f fa ff ff       	jmp    0x710d54a07a45
    710d54a07fb6:	41 89 30             	mov    DWORD PTR [r8],esi
    710d54a07fb9:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    710d54a07fbd:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    710d54a07fc1:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a07fc5:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    710d54a07fc9:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a07fcd:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    710d54a07fd4:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1041e
    710d54a07fdb:	1e 04 01 00 
    710d54a07fdf:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    710d54a07fe6:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    710d54a07fed:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a07ff4:	00 00 00 00 
    710d54a07ff8:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a07fff:	00 00 00 00 
    710d54a08003:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    710d54a0800a:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a08011:	02 00 00 00 
    710d54a08015:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a0801c:	00 
    710d54a0801d:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x7
    710d54a08024:	07 00 00 00 
    710d54a08028:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a0802f:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a08036:	56 00 00 
    710d54a08039:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    710d54a0803e:	44 89 ee             	mov    esi,r13d
    710d54a08041:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    710d54a08046:	44 89 d3             	mov    ebx,r10d
    710d54a08049:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    710d54a0804e:	ff d0                	call   rax
    710d54a08050:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    710d54a08055:	41 89 da             	mov    r10d,ebx
    710d54a08058:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    710d54a0805d:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    710d54a08064:	00 
    710d54a08065:	40 84 ff             	test   dil,dil
    710d54a08068:	0f 85 94 fe ff ff    	jne    0x710d54a07f02
    710d54a0806e:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    710d54a08073:	44 8b 4c 24 14       	mov    r9d,DWORD PTR [rsp+0x14]
    710d54a08078:	44 8b 64 24 20       	mov    r12d,DWORD PTR [rsp+0x20]
    710d54a0807d:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a08082:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    710d54a08086:	89 c2                	mov    edx,eax
    710d54a08088:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    710d54a0808d:	e9 45 f9 ff ff       	jmp    0x710d54a079d7
    710d54a08092:	41 89 30             	mov    DWORD PTR [r8],esi
    710d54a08095:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    710d54a08099:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    710d54a0809d:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a080a1:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    710d54a080a5:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a080a9:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    710d54a080b0:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10420
    710d54a080b7:	20 04 01 00 
    710d54a080bb:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    710d54a080c2:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    710d54a080c9:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a080d0:	00 00 00 00 
    710d54a080d4:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a080db:	00 00 00 00 
    710d54a080df:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a080e3:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d54a080ea:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a080f1:	02 00 00 00 
    710d54a080f5:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a080fc:	00 
    710d54a080fd:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    710d54a08104:	08 00 00 00 
    710d54a08108:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a0810f:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a08116:	56 00 00 
    710d54a08119:	4c 89 c7             	mov    rdi,r8
    710d54a0811c:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    710d54a08121:	ba 20 04 01 00       	mov    edx,0x10420
    710d54a08126:	4d 89 c5             	mov    r13,r8
    710d54a08129:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d54a0812f:	e9 b5 fd ff ff       	jmp    0x710d54a07ee9
    710d54a08134:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d54a08138:	41 89 00             	mov    DWORD PTR [r8],eax
    710d54a0813b:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    710d54a0813f:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    710d54a08143:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a08147:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a0814c:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    710d54a08150:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    710d54a08155:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    710d54a0815c:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10420
    710d54a08163:	20 04 01 00 
    710d54a08167:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a0816b:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    710d54a08172:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a08176:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    710d54a0817d:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a08184:	00 00 00 00 
    710d54a08188:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a0818f:	00 00 00 00 
    710d54a08193:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a08197:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d54a0819e:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a081a5:	02 00 00 00 
    710d54a081a9:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d54a081b0:	00 
    710d54a081b1:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    710d54a081b8:	08 00 00 00 
    710d54a081bc:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a081c3:	48 b8 20 a6 90 86 66 	movabs rax,0x56668690a620
    710d54a081ca:	56 00 00 
    710d54a081cd:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    710d54a081d2:	89 ce                	mov    esi,ecx
    710d54a081d4:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    710d54a081d9:	44 89 d3             	mov    ebx,r10d
    710d54a081dc:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    710d54a081e1:	ff d0                	call   rax
    710d54a081e3:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    710d54a081e8:	41 89 da             	mov    r10d,ebx
    710d54a081eb:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    710d54a081f0:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    710d54a081f7:	00 
    710d54a081f8:	40 84 ff             	test   dil,dil
    710d54a081fb:	0f 84 08 f8 ff ff    	je     0x710d54a07a09
    710d54a08201:	e9 fc fc ff ff       	jmp    0x710d54a07f02
    710d54a08206:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    710d54a0820b:	c7 44 24 44 00 00 00 	mov    DWORD PTR [rsp+0x44],0x0
    710d54a08212:	00 
    710d54a08213:	c7 44 24 10 02 00 00 	mov    DWORD PTR [rsp+0x10],0x2
    710d54a0821a:	00 
    710d54a0821b:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d54a0821f:	41 89 00             	mov    DWORD PTR [r8],eax
    710d54a08222:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    710d54a08226:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    710d54a0822a:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d54a0822f:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    710d54a08233:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d54a08237:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a0823c:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    710d54a08240:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    710d54a08247:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10412
    710d54a0824e:	12 04 01 00 
    710d54a08252:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a08256:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    710d54a0825d:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d54a08261:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    710d54a08268:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d54a0826f:	00 00 00 00 
    710d54a08273:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d54a0827a:	00 00 00 00 
    710d54a0827e:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a08282:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d54a08289:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d54a08290:	02 00 00 00 
    710d54a08294:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    710d54a0829b:	01 
    710d54a0829c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    710d54a082a3:	08 00 00 00 
    710d54a082a7:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d54a082ae:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d54a082b5:	56 00 00 
    710d54a082b8:	4c 89 c7             	mov    rdi,r8
    710d54a082bb:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    710d54a082c0:	44 89 54 24 74       	mov    DWORD PTR [rsp+0x74],r10d
    710d54a082c5:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    710d54a082ca:	ff d0                	call   rax
    710d54a082cc:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    710d54a082d1:	44 8b 54 24 74       	mov    r10d,DWORD PTR [rsp+0x74]
    710d54a082d6:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    710d54a082db:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    710d54a082e2:	00 
    710d54a082e3:	44 89 f9             	mov    ecx,r15d
    710d54a082e6:	be 00 00 00 00       	mov    esi,0x0
    710d54a082eb:	b8 00 00 00 00       	mov    eax,0x0
    710d54a082f0:	ba 00 00 00 00       	mov    edx,0x0
    710d54a082f5:	40 84 ff             	test   dil,dil
    710d54a082f8:	0f 84 47 f7 ff ff    	je     0x710d54a07a45
    710d54a082fe:	e9 ff fb ff ff       	jmp    0x710d54a07f02
