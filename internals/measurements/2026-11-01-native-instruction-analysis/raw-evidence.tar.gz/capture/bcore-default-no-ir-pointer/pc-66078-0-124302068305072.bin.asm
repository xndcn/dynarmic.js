
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66078-0-124302068305072.bin:     file format binary


Disassembly of section .data:

0000710d54a04cb0 <.data>:
    710d54a04cb0:	48 83 ec 78          	sub    rsp,0x78
    710d54a04cb4:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    710d54a04cb9:	4c 89 ee             	mov    rsi,r13
    710d54a04cbc:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a04cc3:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    710d54a04cc8:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    710d54a04ccf:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    710d54a04cd3:	b8 c9 fd fe ff       	mov    eax,0xfffefdc9
    710d54a04cd8:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    710d54a04cdf:	01 c1                	add    ecx,eax
    710d54a04ce1:	83 f9 e6             	cmp    ecx,0xffffffe6
    710d54a04ce4:	0f 87 eb 1c 00 18    	ja     0x710d6ca069d5
    710d54a04cea:	03 86 a0 00 00 00    	add    eax,DWORD PTR [rsi+0xa0]
    710d54a04cf0:	83 f8 e6             	cmp    eax,0xffffffe6
    710d54a04cf3:	0f 87 dc 1c 00 18    	ja     0x710d6ca069d5
    710d54a04cf9:	48 8b 86 38 01 00 00 	mov    rax,QWORD PTR [rsi+0x138]
    710d54a04d00:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    710d54a04d05:	8b 06                	mov    eax,DWORD PTR [rsi]
    710d54a04d07:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    710d54a04d0b:	8b 46 04             	mov    eax,DWORD PTR [rsi+0x4]
    710d54a04d0e:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    710d54a04d12:	44 8b 6e 08          	mov    r13d,DWORD PTR [rsi+0x8]
    710d54a04d16:	44 8b 7e 0c          	mov    r15d,DWORD PTR [rsi+0xc]
    710d54a04d1a:	8b 46 1c             	mov    eax,DWORD PTR [rsi+0x1c]
    710d54a04d1d:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a04d22:	8b 46 24             	mov    eax,DWORD PTR [rsi+0x24]
    710d54a04d25:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    710d54a04d2a:	44 8b b6 00 01 00 00 	mov    r14d,DWORD PTR [rsi+0x100]
    710d54a04d31:	8b 96 5c 01 00 00    	mov    edx,DWORD PTR [rsi+0x15c]
    710d54a04d37:	48 89 f7             	mov    rdi,rsi
    710d54a04d3a:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    710d54a04d3f:	90                   	nop
    710d54a04d40:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a04d45:	c1 e8 1f             	shr    eax,0x1f
    710d54a04d48:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a04d4c:	41 ff c7             	inc    r15d
    710d54a04d4f:	44 89 f9             	mov    ecx,r15d
    710d54a04d52:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    710d54a04d57:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    710d54a04d5c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    710d54a04d60:	41 89 cf             	mov    r15d,ecx
    710d54a04d63:	41 8d 47 ff          	lea    eax,[r15-0x1]
    710d54a04d67:	c1 e8 1f             	shr    eax,0x1f
    710d54a04d6a:	c1 e9 1f             	shr    ecx,0x1f
    710d54a04d6d:	c4 e2 78 f2 c1       	andn   eax,eax,ecx
    710d54a04d72:	41 09 c6             	or     r14d,eax
    710d54a04d75:	45 31 e4             	xor    r12d,r12d
    710d54a04d78:	45 31 d2             	xor    r10d,r10d
    710d54a04d7b:	31 f6                	xor    esi,esi
    710d54a04d7d:	31 db                	xor    ebx,ebx
    710d54a04d7f:	44 39 7c 24 08       	cmp    DWORD PTR [rsp+0x8],r15d
    710d54a04d84:	41 0f 96 c4          	setbe  r12b
    710d54a04d88:	44 89 ed             	mov    ebp,r13d
    710d54a04d8b:	41 89 d1             	mov    r9d,edx
    710d54a04d8e:	41 0f 94 c2          	sete   r10b
    710d54a04d92:	40 0f 92 c6          	setb   sil
    710d54a04d96:	0f 93 c3             	setae  bl
    710d54a04d99:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    710d54a04d9e:	8d 0c a9             	lea    ecx,[rcx+rbp*4]
    710d54a04da1:	f6 c1 03             	test   cl,0x3
    710d54a04da4:	0f 85 12 03 00 00    	jne    0x710d54a050bc
    710d54a04daa:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    710d54a04daf:	89 ca                	mov    edx,ecx
    710d54a04db1:	c1 ea 0c             	shr    edx,0xc
    710d54a04db4:	49 8b 14 d0          	mov    rdx,QWORD PTR [r8+rdx*8]
    710d54a04db8:	48 85 d2             	test   rdx,rdx
    710d54a04dbb:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    710d54a04dc0:	0f 84 32 04 00 00    	je     0x710d54a051f8
    710d54a04dc6:	89 c8                	mov    eax,ecx
    710d54a04dc8:	25 ff 0f 00 00       	and    eax,0xfff
    710d54a04dcd:	8b 14 02             	mov    edx,DWORD PTR [rdx+rax*1]
    710d54a04dd0:	44 89 d8             	mov    eax,r11d
    710d54a04dd3:	31 d0                	xor    eax,edx
    710d54a04dd5:	48 8b 4c 24 18       	mov    rcx,QWORD PTR [rsp+0x18]
    710d54a04dda:	44 8d 1c 08          	lea    r11d,[rax+rcx*1]
    710d54a04dde:	89 c5                	mov    ebp,eax
    710d54a04de0:	c1 ed 1f             	shr    ebp,0x1f
    710d54a04de3:	44 89 db             	mov    ebx,r11d
    710d54a04de6:	c1 eb 1f             	shr    ebx,0x1f
    710d54a04de9:	89 d9                	mov    ecx,ebx
    710d54a04deb:	33 4c 24 10          	xor    ecx,DWORD PTR [rsp+0x10]
    710d54a04def:	31 dd                	xor    ebp,ebx
    710d54a04df1:	21 cd                	and    ebp,ecx
    710d54a04df3:	41 09 ee             	or     r14d,ebp
    710d54a04df6:	44 39 7c 24 08       	cmp    DWORD PTR [rsp+0x8],r15d
    710d54a04dfb:	41 89 d5             	mov    r13d,edx
    710d54a04dfe:	76 30                	jbe    0x710d54a04e30
    710d54a04e00:	41 8d 51 08          	lea    edx,[r9+0x8]
    710d54a04e04:	3b 54 24 54          	cmp    edx,DWORD PTR [rsp+0x54]
    710d54a04e08:	0f 83 10 02 00 00    	jae    0x710d54a0501e
    710d54a04e0e:	8b b7 58 01 00 00    	mov    esi,DWORD PTR [rdi+0x158]
    710d54a04e14:	41 8d 4f 01          	lea    ecx,[r15+0x1]
    710d54a04e18:	85 f6                	test   esi,esi
    710d54a04e1a:	0f 85 40 ff ff ff    	jne    0x710d54a04d60
    710d54a04e20:	e9 f9 01 00 00       	jmp    0x710d54a0501e
    710d54a04e25:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    710d54a04e2c:	00 00 00 00 
    710d54a04e30:	45 31 d2             	xor    r10d,r10d
    710d54a04e33:	03 44 24 18          	add    eax,DWORD PTR [rsp+0x18]
    710d54a04e37:	41 0f 92 c2          	setb   r10b
    710d54a04e3b:	31 f6                	xor    esi,esi
    710d54a04e3d:	45 85 db             	test   r11d,r11d
    710d54a04e40:	40 0f 94 c6          	sete   sil
    710d54a04e44:	8b 4f 3c             	mov    ecx,DWORD PTR [rdi+0x3c]
    710d54a04e47:	f6 c1 03             	test   cl,0x3
    710d54a04e4a:	0f 85 0d 05 00 00    	jne    0x710d54a0535d
    710d54a04e50:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    710d54a04e54:	48 89 c8             	mov    rax,rcx
    710d54a04e57:	48 c1 e8 0c          	shr    rax,0xc
    710d54a04e5b:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    710d54a04e5f:	48 85 c0             	test   rax,rax
    710d54a04e62:	44 89 5c 24 0c       	mov    DWORD PTR [rsp+0xc],r11d
    710d54a04e67:	0f 84 92 05 00 00    	je     0x710d54a053ff
    710d54a04e6d:	89 ce                	mov    esi,ecx
    710d54a04e6f:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a04e75:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a04e78:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a04e7c:	8d 71 04             	lea    esi,[rcx+0x4]
    710d54a04e7f:	89 f0                	mov    eax,esi
    710d54a04e81:	c1 e8 0c             	shr    eax,0xc
    710d54a04e84:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    710d54a04e88:	48 85 c0             	test   rax,rax
    710d54a04e8b:	0f 84 58 06 00 00    	je     0x710d54a054e9
    710d54a04e91:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a04e97:	8b 2c 30             	mov    ebp,DWORD PTR [rax+rsi*1]
    710d54a04e9a:	8d 71 08             	lea    esi,[rcx+0x8]
    710d54a04e9d:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a04ea1:	89 47 3c             	mov    DWORD PTR [rdi+0x3c],eax
    710d54a04ea4:	89 af a8 00 00 00    	mov    DWORD PTR [rdi+0xa8],ebp
    710d54a04eaa:	89 77 38             	mov    DWORD PTR [rdi+0x38],esi
    710d54a04ead:	31 db                	xor    ebx,ebx
    710d54a04eaf:	44 89 d8             	mov    eax,r11d
    710d54a04eb2:	31 d0                	xor    eax,edx
    710d54a04eb4:	0f 94 c3             	sete   bl
    710d54a04eb7:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    710d54a04ebb:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    710d54a04ebf:	c1 e8 1f             	shr    eax,0x1f
    710d54a04ec2:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    710d54a04ec6:	89 f0                	mov    eax,esi
    710d54a04ec8:	c1 e8 0c             	shr    eax,0xc
    710d54a04ecb:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    710d54a04ecf:	48 85 c0             	test   rax,rax
    710d54a04ed2:	0f 84 ea 06 00 00    	je     0x710d54a055c2
    710d54a04ed8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a04ede:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a04ee1:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a04ee6:	4d 89 cb             	mov    r11,r9
    710d54a04ee9:	83 c1 0c             	add    ecx,0xc
    710d54a04eec:	89 4f 38             	mov    DWORD PTR [rdi+0x38],ecx
    710d54a04eef:	40 f6 c5 01          	test   bpl,0x1
    710d54a04ef3:	0f 85 97 07 00 00    	jne    0x710d54a05690
    710d54a04ef9:	49 89 e9             	mov    r9,rbp
    710d54a04efc:	b3 01                	mov    bl,0x1
    710d54a04efe:	31 c0                	xor    eax,eax
    710d54a04f00:	41 ba 02 00 00 00    	mov    r10d,0x2
    710d54a04f06:	b9 0c 00 00 00       	mov    ecx,0xc
    710d54a04f0b:	31 ed                	xor    ebp,ebp
    710d54a04f0d:	c7 44 24 30 00 00 00 	mov    DWORD PTR [rsp+0x30],0x0
    710d54a04f14:	00 
    710d54a04f15:	c7 44 24 48 00 00 00 	mov    DWORD PTR [rsp+0x48],0x0
    710d54a04f1c:	00 
    710d54a04f1d:	42 8d 14 19          	lea    edx,[rcx+r11*1]
    710d54a04f21:	3b 54 24 54          	cmp    edx,DWORD PTR [rsp+0x54]
    710d54a04f25:	0f 83 96 03 00 00    	jae    0x710d54a052c1
    710d54a04f2b:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    710d54a04f30:	8b b6 58 01 00 00    	mov    esi,DWORD PTR [rsi+0x158]
    710d54a04f36:	85 f6                	test   esi,esi
    710d54a04f38:	0f 84 83 03 00 00    	je     0x710d54a052c1
    710d54a04f3e:	4d 89 c8             	mov    r8,r9
    710d54a04f41:	41 81 f8 1e 02 01 00 	cmp    r8d,0x1021e
    710d54a04f48:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a04f4d:	0f 84 ed fd ff ff    	je     0x710d54a04d40
    710d54a04f53:	42 8d 3c c5 00 00 00 	lea    edi,[r8*8+0x0]
    710d54a04f5a:	00 
    710d54a04f5b:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    710d54a04f61:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    710d54a04f66:	44 39 04 3e          	cmp    DWORD PTR [rsi+rdi*1],r8d
    710d54a04f6a:	0f 85 51 03 00 00    	jne    0x710d54a052c1
    710d54a04f70:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    710d54a04f75:	4c 8b 44 3e 08       	mov    r8,QWORD PTR [rsi+rdi*1+0x8]
    710d54a04f7a:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a04f7f:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    710d54a04f83:	89 37                	mov    DWORD PTR [rdi],esi
    710d54a04f85:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    710d54a04f89:	89 77 04             	mov    DWORD PTR [rdi+0x4],esi
    710d54a04f8c:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    710d54a04f90:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a04f94:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    710d54a04f99:	89 77 1c             	mov    DWORD PTR [rdi+0x1c],esi
    710d54a04f9c:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a04fa1:	89 77 20             	mov    DWORD PTR [rdi+0x20],esi
    710d54a04fa4:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    710d54a04fa9:	89 77 28             	mov    DWORD PTR [rdi+0x28],esi
    710d54a04fac:	44 89 8f bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r9d
    710d54a04fb3:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    710d54a04fb7:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    710d54a04fbd:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    710d54a04fc1:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    710d54a04fc7:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    710d54a04fcb:	89 b7 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],esi
    710d54a04fd1:	8b 74 24 30          	mov    esi,DWORD PTR [rsp+0x30]
    710d54a04fd5:	89 b7 f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],esi
    710d54a04fdb:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    710d54a04fe1:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a04fe7:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a04fee:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a04ff5:	44 89 97 24 01 00 00 	mov    DWORD PTR [rdi+0x124],r10d
    710d54a04ffc:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a05003:	89 8f 34 01 00 00    	mov    DWORD PTR [rdi+0x134],ecx
    710d54a05009:	89 97 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],edx
    710d54a0500f:	49 89 fd             	mov    r13,rdi
    710d54a05012:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    710d54a05017:	48 83 c4 78          	add    rsp,0x78
    710d54a0501b:	41 ff e0             	jmp    r8
    710d54a0501e:	31 c9                	xor    ecx,ecx
    710d54a05020:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    710d54a05025:	01 d0                	add    eax,edx
    710d54a05027:	0f 92 c1             	setb   cl
    710d54a0502a:	31 c0                	xor    eax,eax
    710d54a0502c:	45 85 db             	test   r11d,r11d
    710d54a0502f:	0f 94 c0             	sete   al
    710d54a05032:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    710d54a05036:	89 37                	mov    DWORD PTR [rdi],esi
    710d54a05038:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a0503c:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    710d54a05040:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a05044:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    710d54a05047:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    710d54a0504c:	89 57 20             	mov    DWORD PTR [rdi+0x20],edx
    710d54a0504f:	48 8b 54 24 38       	mov    rdx,QWORD PTR [rsp+0x38]
    710d54a05054:	89 57 28             	mov    DWORD PTR [rdi+0x28],edx
    710d54a05057:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1021e
    710d54a0505e:	02 01 00 
    710d54a05061:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a05067:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    710d54a0506d:	89 8f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ecx
    710d54a05073:	89 8f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ecx
    710d54a05079:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    710d54a0507f:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    710d54a05085:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a0508c:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a05093:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a0509a:	00 00 00 
    710d54a0509d:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    710d54a050a4:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    710d54a050ab:	00 00 00 
    710d54a050ae:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a050b5:	48 83 c4 78          	add    rsp,0x78
    710d54a050b9:	c2 08 00             	ret    0x8
    710d54a050bc:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    710d54a050c0:	89 17                	mov    DWORD PTR [rdi],edx
    710d54a050c2:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a050c6:	89 6f 08             	mov    DWORD PTR [rdi+0x8],ebp
    710d54a050c9:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a050cd:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    710d54a050d2:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    710d54a050d5:	89 6f 20             	mov    DWORD PTR [rdi+0x20],ebp
    710d54a050d8:	89 4f 28             	mov    DWORD PTR [rdi+0x28],ecx
    710d54a050db:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    710d54a050e2:	02 01 00 
    710d54a050e5:	44 89 97 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r10d
    710d54a050ec:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    710d54a050f2:	89 9f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ebx
    710d54a050f8:	89 9f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ebx
    710d54a050fe:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    710d54a05104:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a0510a:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a05111:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a05118:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a0511f:	00 00 00 
    710d54a05122:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a05129:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    710d54a05130:	00 00 00 
    710d54a05133:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a0513a:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a05141:	56 00 00 
    710d54a05144:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    710d54a05149:	ba 26 02 01 00       	mov    edx,0x10226
    710d54a0514e:	45 31 c0             	xor    r8d,r8d
    710d54a05151:	ff d0                	call   rax
    710d54a05153:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a05158:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    710d54a0515f:	44 8b 8f bc 00 00 00 	mov    r9d,DWORD PTR [rdi+0xbc]
    710d54a05166:	8b 07                	mov    eax,DWORD PTR [rdi]
    710d54a05168:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    710d54a0516c:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    710d54a0516f:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    710d54a05173:	44 8b 6f 08          	mov    r13d,DWORD PTR [rdi+0x8]
    710d54a05177:	44 8b 7f 0c          	mov    r15d,DWORD PTR [rdi+0xc]
    710d54a0517b:	8b 47 1c             	mov    eax,DWORD PTR [rdi+0x1c]
    710d54a0517e:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a05183:	8b 47 20             	mov    eax,DWORD PTR [rdi+0x20]
    710d54a05186:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    710d54a0518b:	8b 47 24             	mov    eax,DWORD PTR [rdi+0x24]
    710d54a0518e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    710d54a05193:	8b 47 28             	mov    eax,DWORD PTR [rdi+0x28]
    710d54a05196:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    710d54a0519b:	8b 87 e4 00 00 00    	mov    eax,DWORD PTR [rdi+0xe4]
    710d54a051a1:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a051a5:	8b 87 e8 00 00 00    	mov    eax,DWORD PTR [rdi+0xe8]
    710d54a051ab:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    710d54a051af:	8b 87 ec 00 00 00    	mov    eax,DWORD PTR [rdi+0xec]
    710d54a051b5:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    710d54a051b9:	8b 87 f0 00 00 00    	mov    eax,DWORD PTR [rdi+0xf0]
    710d54a051bf:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    710d54a051c3:	8b af f8 00 00 00    	mov    ebp,DWORD PTR [rdi+0xf8]
    710d54a051c9:	8b 87 fc 00 00 00    	mov    eax,DWORD PTR [rdi+0xfc]
    710d54a051cf:	44 8b b7 00 01 00 00 	mov    r14d,DWORD PTR [rdi+0x100]
    710d54a051d6:	44 8b a7 14 01 00 00 	mov    r12d,DWORD PTR [rdi+0x114]
    710d54a051dd:	44 8b 97 24 01 00 00 	mov    r10d,DWORD PTR [rdi+0x124]
    710d54a051e4:	8b 8f 34 01 00 00    	mov    ecx,DWORD PTR [rdi+0x134]
    710d54a051ea:	44 8b 9f 5c 01 00 00 	mov    r11d,DWORD PTR [rdi+0x15c]
    710d54a051f1:	89 f3                	mov    ebx,esi
    710d54a051f3:	e9 25 fd ff ff       	jmp    0x710d54a04f1d
    710d54a051f8:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    710d54a051fc:	89 17                	mov    DWORD PTR [rdi],edx
    710d54a051fe:	44 89 5c 24 0c       	mov    DWORD PTR [rsp+0xc],r11d
    710d54a05203:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a05207:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    710d54a0520c:	89 6f 08             	mov    DWORD PTR [rdi+0x8],ebp
    710d54a0520f:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a05213:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    710d54a05218:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    710d54a0521b:	89 6f 20             	mov    DWORD PTR [rdi+0x20],ebp
    710d54a0521e:	89 4f 28             	mov    DWORD PTR [rdi+0x28],ecx
    710d54a05221:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    710d54a05228:	02 01 00 
    710d54a0522b:	44 89 97 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r10d
    710d54a05232:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    710d54a05238:	89 9f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ebx
    710d54a0523e:	89 9f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ebx
    710d54a05244:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    710d54a0524a:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    710d54a05250:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a05257:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a0525e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a05265:	00 00 00 
    710d54a05268:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a0526f:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    710d54a05276:	00 00 00 
    710d54a05279:	48 89 ce             	mov    rsi,rcx
    710d54a0527c:	4c 89 cb             	mov    rbx,r9
    710d54a0527f:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a05286:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a0528d:	56 00 00 
    710d54a05290:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a05295:	ff d0                	call   rax
    710d54a05297:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a0529c:	89 c2                	mov    edx,eax
    710d54a0529e:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    710d54a052a5:	89 c6                	mov    esi,eax
    710d54a052a7:	84 c0                	test   al,al
    710d54a052a9:	0f 85 b0 fe ff ff    	jne    0x710d54a0515f
    710d54a052af:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    710d54a052b4:	49 89 d9             	mov    r9,rbx
    710d54a052b7:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    710d54a052bc:	e9 0f fb ff ff       	jmp    0x710d54a04dd0
    710d54a052c1:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    710d54a052c6:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    710d54a052ca:	89 32                	mov    DWORD PTR [rdx],esi
    710d54a052cc:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    710d54a052d0:	89 72 04             	mov    DWORD PTR [rdx+0x4],esi
    710d54a052d3:	44 89 6a 08          	mov    DWORD PTR [rdx+0x8],r13d
    710d54a052d7:	44 89 7a 0c          	mov    DWORD PTR [rdx+0xc],r15d
    710d54a052db:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    710d54a052e0:	89 72 1c             	mov    DWORD PTR [rdx+0x1c],esi
    710d54a052e3:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a052e8:	89 72 20             	mov    DWORD PTR [rdx+0x20],esi
    710d54a052eb:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    710d54a052f0:	89 72 28             	mov    DWORD PTR [rdx+0x28],esi
    710d54a052f3:	44 89 8a bc 00 00 00 	mov    DWORD PTR [rdx+0xbc],r9d
    710d54a052fa:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    710d54a052fe:	89 b2 e4 00 00 00    	mov    DWORD PTR [rdx+0xe4],esi
    710d54a05304:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    710d54a05308:	89 b2 e8 00 00 00    	mov    DWORD PTR [rdx+0xe8],esi
    710d54a0530e:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    710d54a05312:	89 b2 ec 00 00 00    	mov    DWORD PTR [rdx+0xec],esi
    710d54a05318:	8b 74 24 30          	mov    esi,DWORD PTR [rsp+0x30]
    710d54a0531c:	89 b2 f0 00 00 00    	mov    DWORD PTR [rdx+0xf0],esi
    710d54a05322:	89 aa f8 00 00 00    	mov    DWORD PTR [rdx+0xf8],ebp
    710d54a05328:	89 82 fc 00 00 00    	mov    DWORD PTR [rdx+0xfc],eax
    710d54a0532e:	44 89 b2 00 01 00 00 	mov    DWORD PTR [rdx+0x100],r14d
    710d54a05335:	44 89 a2 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r12d
    710d54a0533c:	44 89 92 24 01 00 00 	mov    DWORD PTR [rdx+0x124],r10d
    710d54a05343:	88 9a 28 01 00 00    	mov    BYTE PTR [rdx+0x128],bl
    710d54a05349:	89 8a 34 01 00 00    	mov    DWORD PTR [rdx+0x134],ecx
    710d54a0534f:	44 89 9a 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r11d
    710d54a05356:	48 83 c4 78          	add    rsp,0x78
    710d54a0535a:	c2 08 00             	ret    0x8
    710d54a0535d:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a05361:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a05363:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a05367:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    710d54a0536a:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a0536e:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a05373:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    710d54a05376:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a0537b:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    710d54a0537e:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    710d54a05383:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    710d54a05386:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    710d54a0538d:	02 01 00 
    710d54a05390:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    710d54a05396:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    710d54a0539c:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    710d54a053a3:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    710d54a053aa:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    710d54a053b0:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    710d54a053b6:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a053bd:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a053c4:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    710d54a053cb:	00 00 00 
    710d54a053ce:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a053d5:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    710d54a053dc:	00 00 00 
    710d54a053df:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a053e6:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a053ed:	56 00 00 
    710d54a053f0:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    710d54a053f5:	ba 2e 02 01 00       	mov    edx,0x1022e
    710d54a053fa:	e9 4f fd ff ff       	jmp    0x710d54a0514e
    710d54a053ff:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a05403:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a05405:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a05409:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    710d54a0540c:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a05410:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a05415:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    710d54a05418:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a0541d:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    710d54a05420:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    710d54a05425:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    710d54a05428:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    710d54a0542f:	02 01 00 
    710d54a05432:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a05436:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a0543c:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    710d54a05442:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    710d54a05449:	44 89 54 24 64       	mov    DWORD PTR [rsp+0x64],r10d
    710d54a0544e:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    710d54a05455:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    710d54a0545b:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    710d54a05461:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a05468:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a0546f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    710d54a05476:	00 00 00 
    710d54a05479:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a05480:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    710d54a05487:	00 00 00 
    710d54a0548a:	4c 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],r9
    710d54a0548f:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a05496:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a0549d:	56 00 00 
    710d54a054a0:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a054a5:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a054aa:	89 ce                	mov    esi,ecx
    710d54a054ac:	ff d0                	call   rax
    710d54a054ae:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a054b3:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a054b7:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    710d54a054be:	89 c6                	mov    esi,eax
    710d54a054c0:	84 c0                	test   al,al
    710d54a054c2:	0f 85 97 fc ff ff    	jne    0x710d54a0515f
    710d54a054c8:	44 89 ea             	mov    edx,r13d
    710d54a054cb:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    710d54a054d0:	4c 8b 4c 24 48       	mov    r9,QWORD PTR [rsp+0x48]
    710d54a054d5:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    710d54a054da:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a054df:	44 8b 54 24 64       	mov    r10d,DWORD PTR [rsp+0x64]
    710d54a054e4:	e9 93 f9 ff ff       	jmp    0x710d54a04e7c
    710d54a054e9:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a054ee:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a054f2:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a054f4:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a054f8:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    710d54a054fb:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a054ff:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a05504:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    710d54a05507:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a0550c:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    710d54a0550f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    710d54a05514:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    710d54a05517:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    710d54a0551e:	02 01 00 
    710d54a05521:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a05525:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a0552b:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    710d54a05531:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    710d54a05538:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    710d54a0553f:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    710d54a05545:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    710d54a0554b:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a05552:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a05559:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    710d54a05560:	00 00 00 
    710d54a05563:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a0556a:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    710d54a05571:	00 00 00 
    710d54a05574:	4c 89 cb             	mov    rbx,r9
    710d54a05577:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a0557e:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a05585:	56 00 00 
    710d54a05588:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a0558d:	ff d0                	call   rax
    710d54a0558f:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a05594:	0f b6 8f 28 01 00 00 	movzx  ecx,BYTE PTR [rdi+0x128]
    710d54a0559b:	89 ce                	mov    esi,ecx
    710d54a0559d:	84 c9                	test   cl,cl
    710d54a0559f:	0f 85 ba fb ff ff    	jne    0x710d54a0515f
    710d54a055a5:	44 89 ea             	mov    edx,r13d
    710d54a055a8:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    710d54a055ad:	49 89 d9             	mov    r9,rbx
    710d54a055b0:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    710d54a055b5:	48 89 c5             	mov    rbp,rax
    710d54a055b8:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a055bd:	e9 d8 f8 ff ff       	jmp    0x710d54a04e9a
    710d54a055c2:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a055c7:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a055cb:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a055cd:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    710d54a055d1:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    710d54a055d4:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a055d8:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a055dd:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    710d54a055e0:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a055e5:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    710d54a055e8:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    710d54a055ed:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    710d54a055f0:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10234
    710d54a055f7:	02 01 00 
    710d54a055fa:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a055fe:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a05604:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a05608:	89 87 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],eax
    710d54a0560e:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    710d54a05615:	00 00 00 00 
    710d54a05619:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    710d54a05620:	00 00 00 00 
    710d54a05624:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a0562b:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a05632:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a05639:	00 00 00 
    710d54a0563c:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a05643:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    710d54a0564a:	00 00 00 
    710d54a0564d:	4c 89 cb             	mov    rbx,r9
    710d54a05650:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    710d54a05657:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a0565e:	56 00 00 
    710d54a05661:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a05666:	ff d0                	call   rax
    710d54a05668:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    710d54a0566d:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    710d54a05672:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    710d54a05679:	89 c6                	mov    esi,eax
    710d54a0567b:	84 c0                	test   al,al
    710d54a0567d:	0f 85 dc fa ff ff    	jne    0x710d54a0515f
    710d54a05683:	49 89 d9             	mov    r9,rbx
    710d54a05686:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a0568b:	e9 56 f8 ff ff       	jmp    0x710d54a04ee6
    710d54a05690:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a05694:	89 07                	mov    DWORD PTR [rdi],eax
    710d54a05696:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    710d54a0569a:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    710d54a0569d:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    710d54a056a1:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    710d54a056a5:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    710d54a056aa:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    710d54a056ad:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a056b2:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    710d54a056b5:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    710d54a056ba:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    710d54a056bd:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10236
    710d54a056c4:	02 01 00 
    710d54a056c7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a056cb:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    710d54a056d1:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d54a056d5:	89 87 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],eax
    710d54a056db:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    710d54a056e2:	00 00 00 00 
    710d54a056e6:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    710d54a056ed:	00 00 00 00 
    710d54a056f1:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    710d54a056f8:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    710d54a056ff:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    710d54a05706:	00 00 00 
    710d54a05709:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    710d54a05710:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    710d54a05717:	00 00 00 
    710d54a0571a:	44 89 9f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r11d
    710d54a05721:	48 b8 e0 fa a1 86 66 	movabs rax,0x566686a1fae0
    710d54a05728:	56 00 00 
    710d54a0572b:	be 2a 00 00 00       	mov    esi,0x2a
    710d54a05730:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    710d54a05735:	ff d0                	call   rax
    710d54a05737:	e9 17 fa ff ff       	jmp    0x710d54a05153
