
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66044-1-124302068301424.bin:     file format binary


Disassembly of section .data:

0000710d54a03e70 <.data>:
    710d54a03e70:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03e77:	8b 88 34 00 10 00    	mov    ecx,DWORD PTR [rax+0x100034]
    710d54a03e7d:	ff c1                	inc    ecx
    710d54a03e7f:	89 88 34 00 10 00    	mov    DWORD PTR [rax+0x100034],ecx
    710d54a03e85:	81 f9 75 a8 00 00    	cmp    ecx,0xa875
    710d54a03e8b:	0f 84 7f 18 00 18    	je     0x710d6ca05710
    710d54a03e91:	50                   	push   rax
    710d54a03e92:	41 8b 45 38          	mov    eax,DWORD PTR [r13+0x38]
    710d54a03e96:	8d 58 fc             	lea    ebx,[rax-0x4]
    710d54a03e99:	a8 03                	test   al,0x3
    710d54a03e9b:	0f 85 9b 18 00 18    	jne    0x710d6ca0573c
    710d54a03ea1:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    710d54a03ea8:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    710d54a03eac:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a03eb3:	89 d9                	mov    ecx,ebx
    710d54a03eb5:	c1 e9 0c             	shr    ecx,0xc
    710d54a03eb8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a03ebc:	48 85 c0             	test   rax,rax
    710d54a03ebf:	0f 84 cc 18 00 18    	je     0x710d6ca05791
    710d54a03ec5:	89 d9                	mov    ecx,ebx
    710d54a03ec7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03ecd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a03ed0:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a03ed4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101fc
    710d54a03edb:	fc 01 01 00 
    710d54a03edf:	0f 84 e7 18 00 18    	je     0x710d6ca057cc
    710d54a03ee5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101fc
    710d54a03eec:	fc 01 01 00 
    710d54a03ef0:	0f 84 d6 18 00 18    	je     0x710d6ca057cc
    710d54a03ef6:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d54a03efa:	0f 85 0e 19 00 18    	jne    0x710d6ca0580e
    710d54a03f00:	58                   	pop    rax
    710d54a03f01:	e9 0f 00 00 00       	jmp    0x710d54a03f15
    710d54a03f06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a03f0d:	00 
    710d54a03f0e:	74 f0                	je     0x710d54a03f00
    710d54a03f10:	e9 60 18 00 18       	jmp    0x710d6ca05775
    710d54a03f15:	50                   	push   rax
    710d54a03f16:	41 c7 45 08 ff 1f 00 	mov    DWORD PTR [r13+0x8],0x1fff
    710d54a03f1d:	00 
    710d54a03f1e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101fe
    710d54a03f25:	fe 01 01 00 
    710d54a03f29:	0f 84 11 19 00 18    	je     0x710d6ca05840
    710d54a03f2f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101fe
    710d54a03f36:	fe 01 01 00 
    710d54a03f3a:	0f 84 00 19 00 18    	je     0x710d6ca05840
    710d54a03f40:	58                   	pop    rax
    710d54a03f41:	50                   	push   rax
    710d54a03f42:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a03f46:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a03f49:	f6 c3 03             	test   bl,0x3
    710d54a03f4c:	0f 85 4e 19 00 18    	jne    0x710d6ca058a0
    710d54a03f52:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a03f59:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a03f60:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    710d54a03f64:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    710d54a03f6b:	89 c8                	mov    eax,ecx
    710d54a03f6d:	c1 e8 0c             	shr    eax,0xc
    710d54a03f70:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03f75:	48 85 c0             	test   rax,rax
    710d54a03f78:	0f 84 75 19 00 18    	je     0x710d6ca058f3
    710d54a03f7e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03f84:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a03f87:	83 c3 f8             	add    ebx,0xfffffff8
    710d54a03f8a:	89 d8                	mov    eax,ebx
    710d54a03f8c:	c1 e8 0c             	shr    eax,0xc
    710d54a03f8f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03f94:	48 85 c0             	test   rax,rax
    710d54a03f97:	0f 84 91 19 00 18    	je     0x710d6ca0592e
    710d54a03f9d:	89 d9                	mov    ecx,ebx
    710d54a03f9f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03fa5:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    710d54a03fa9:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    710d54a03fad:	b8 00 00 00 00       	mov    eax,0x0
    710d54a03fb2:	29 c3                	sub    ebx,eax
    710d54a03fb4:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a03fb8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10202
    710d54a03fbf:	02 02 01 00 
    710d54a03fc3:	0f 84 a6 19 00 18    	je     0x710d6ca0596f
    710d54a03fc9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10202
    710d54a03fd0:	02 02 01 00 
    710d54a03fd4:	0f 84 95 19 00 18    	je     0x710d6ca0596f
    710d54a03fda:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a03fde:	0f 85 cd 19 00 18    	jne    0x710d6ca059b1
    710d54a03fe4:	58                   	pop    rax
    710d54a03fe5:	e9 0f 00 00 00       	jmp    0x710d54a03ff9
    710d54a03fea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a03ff1:	00 
    710d54a03ff2:	74 f0                	je     0x710d54a03fe4
    710d54a03ff4:	e9 de 18 00 18       	jmp    0x710d6ca058d7
    710d54a03ff9:	50                   	push   rax
    710d54a03ffa:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a03ffe:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04005:	31 d2                	xor    edx,edx
    710d54a04007:	41 23 45 04          	and    eax,DWORD PTR [r13+0x4]
    710d54a0400b:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a0400f:	0f 94 c2             	sete   dl
    710d54a04012:	c1 e8 1f             	shr    eax,0x1f
    710d54a04015:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a0401c:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a04023:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a0402a:	00 00 00 00 
    710d54a0402e:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a04035:	00 00 00 00 
    710d54a04039:	81 f9 06 02 01 00    	cmp    ecx,0x10206
    710d54a0403f:	0f 84 9e 19 00 18    	je     0x710d6ca059e3
    710d54a04045:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10206
    710d54a0404c:	06 02 01 00 
    710d54a04050:	0f 84 8d 19 00 18    	je     0x710d6ca059e3
    710d54a04056:	58                   	pop    rax
    710d54a04057:	50                   	push   rax
    710d54a04058:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a0405c:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04063:	31 d2                	xor    edx,edx
    710d54a04065:	85 c0                	test   eax,eax
    710d54a04067:	0f 94 c2             	sete   dl
    710d54a0406a:	c1 e8 1f             	shr    eax,0x1f
    710d54a0406d:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a04074:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a0407b:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a04082:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    710d54a04089:	00 00 00 
    710d54a0408c:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    710d54a04093:	81 f9 08 02 01 00    	cmp    ecx,0x10208
    710d54a04099:	0f 84 a4 19 00 18    	je     0x710d6ca05a43
    710d54a0409f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10208
    710d54a040a6:	08 02 01 00 
    710d54a040aa:	0f 84 93 19 00 18    	je     0x710d6ca05a43
    710d54a040b0:	58                   	pop    rax
    710d54a040b1:	50                   	push   rax
    710d54a040b2:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a040b9:	00 
    710d54a040ba:	74 55                	je     0x710d54a04111
    710d54a040bc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a040c3:	01 
    710d54a040c4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1020a
    710d54a040cb:	0a 02 01 00 
    710d54a040cf:	0f 84 ce 19 00 18    	je     0x710d6ca05aa3
    710d54a040d5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1020a
    710d54a040dc:	0a 02 01 00 
    710d54a040e0:	0f 84 bd 19 00 18    	je     0x710d6ca05aa3
    710d54a040e6:	b8 0a 02 01 00       	mov    eax,0x1020a
    710d54a040eb:	83 c0 24             	add    eax,0x24
    710d54a040ee:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a040f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a040fc:	02 00 00 00 
    710d54a04100:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d54a04107:	06 00 00 00 
    710d54a0410b:	58                   	pop    rax
    710d54a0410c:	e9 d3 05 00 00       	jmp    0x710d54a046e4
    710d54a04111:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1020a
    710d54a04118:	0a 02 01 00 
    710d54a0411c:	0f 84 bd 19 00 18    	je     0x710d6ca05adf
    710d54a04122:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1020a
    710d54a04129:	0a 02 01 00 
    710d54a0412d:	0f 84 ac 19 00 18    	je     0x710d6ca05adf
    710d54a04133:	58                   	pop    rax
    710d54a04134:	50                   	push   rax
    710d54a04135:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    710d54a0413a:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a0413f:	09 c1                	or     ecx,eax
    710d54a04141:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    710d54a04145:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1020c
    710d54a0414c:	0c 02 01 00 
    710d54a04150:	0f 84 d2 19 00 18    	je     0x710d6ca05b28
    710d54a04156:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1020c
    710d54a0415d:	0c 02 01 00 
    710d54a04161:	0f 84 c1 19 00 18    	je     0x710d6ca05b28
    710d54a04167:	58                   	pop    rax
    710d54a04168:	50                   	push   rax
    710d54a04169:	41 0f b7 45 1c       	movzx  eax,WORD PTR [r13+0x1c]
    710d54a0416e:	b9 00 00 37 9e       	mov    ecx,0x9e370000
    710d54a04173:	09 c1                	or     ecx,eax
    710d54a04175:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    710d54a04179:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10210
    710d54a04180:	10 02 01 00 
    710d54a04184:	0f 84 fe 19 00 18    	je     0x710d6ca05b88
    710d54a0418a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10210
    710d54a04191:	10 02 01 00 
    710d54a04195:	0f 84 ed 19 00 18    	je     0x710d6ca05b88
    710d54a0419b:	58                   	pop    rax
    710d54a0419c:	50                   	push   rax
    710d54a0419d:	41 c7 45 0c 00 00 00 	mov    DWORD PTR [r13+0xc],0x0
    710d54a041a4:	00 
    710d54a041a5:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10214
    710d54a041ac:	14 02 01 00 
    710d54a041b0:	0f 84 32 1a 00 18    	je     0x710d6ca05be8
    710d54a041b6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10214
    710d54a041bd:	14 02 01 00 
    710d54a041c1:	0f 84 21 1a 00 18    	je     0x710d6ca05be8
    710d54a041c7:	58                   	pop    rax
    710d54a041c8:	50                   	push   rax
    710d54a041c9:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    710d54a041ce:	c1 e0 10             	shl    eax,0x10
    710d54a041d1:	b9 fc 12 00 00       	mov    ecx,0x12fc
    710d54a041d6:	09 c1                	or     ecx,eax
    710d54a041d8:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    710d54a041dc:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10216
    710d54a041e3:	16 02 01 00 
    710d54a041e7:	0f 84 5b 1a 00 18    	je     0x710d6ca05c48
    710d54a041ed:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10216
    710d54a041f4:	16 02 01 00 
    710d54a041f8:	0f 84 4a 1a 00 18    	je     0x710d6ca05c48
    710d54a041fe:	58                   	pop    rax
    710d54a041ff:	50                   	push   rax
    710d54a04200:	41 0f b7 45 1e       	movzx  eax,WORD PTR [r13+0x1e]
    710d54a04205:	c1 e0 10             	shl    eax,0x10
    710d54a04208:	b9 b9 79 00 00       	mov    ecx,0x79b9
    710d54a0420d:	09 c1                	or     ecx,eax
    710d54a0420f:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    710d54a04213:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1021a
    710d54a0421a:	1a 02 01 00 
    710d54a0421e:	0f 84 84 1a 00 18    	je     0x710d6ca05ca8
    710d54a04224:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1021a
    710d54a0422b:	1a 02 01 00 
    710d54a0422f:	0f 84 73 1a 00 18    	je     0x710d6ca05ca8
    710d54a04235:	58                   	pop    rax
    710d54a04236:	50                   	push   rax
    710d54a04237:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a0423b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04242:	41 89 45 20          	mov    DWORD PTR [r13+0x20],eax
    710d54a04246:	81 f9 1e 02 01 00    	cmp    ecx,0x1021e
    710d54a0424c:	0f 84 b6 1a 00 18    	je     0x710d6ca05d08
    710d54a04252:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1021e
    710d54a04259:	1e 02 01 00 
    710d54a0425d:	0f 84 a5 1a 00 18    	je     0x710d6ca05d08
    710d54a04263:	58                   	pop    rax
    710d54a04264:	50                   	push   rax
    710d54a04265:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    710d54a04269:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04270:	31 d2                	xor    edx,edx
    710d54a04272:	89 c6                	mov    esi,eax
    710d54a04274:	ff c6                	inc    esi
    710d54a04276:	0f 94 c2             	sete   dl
    710d54a04279:	41 89 75 0c          	mov    DWORD PTR [r13+0xc],esi
    710d54a0427d:	c1 e8 1f             	shr    eax,0x1f
    710d54a04280:	89 f7                	mov    edi,esi
    710d54a04282:	c1 ef 1f             	shr    edi,0x1f
    710d54a04285:	f7 d0                	not    eax
    710d54a04287:	21 f8                	and    eax,edi
    710d54a04289:	31 db                	xor    ebx,ebx
    710d54a0428b:	85 f6                	test   esi,esi
    710d54a0428d:	0f 94 c3             	sete   bl
    710d54a04290:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    710d54a04297:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a0429e:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    710d54a042a5:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a042ac:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    710d54a042b3:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    710d54a042ba:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    710d54a042c1:	81 f9 20 02 01 00    	cmp    ecx,0x10220
    710d54a042c7:	0f 84 9b 1a 00 18    	je     0x710d6ca05d68
    710d54a042cd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10220
    710d54a042d4:	20 02 01 00 
    710d54a042d8:	0f 84 8a 1a 00 18    	je     0x710d6ca05d68
    710d54a042de:	58                   	pop    rax
    710d54a042df:	50                   	push   rax
    710d54a042e0:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a042e4:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    710d54a042e8:	31 d2                	xor    edx,edx
    710d54a042ea:	31 f6                	xor    esi,esi
    710d54a042ec:	31 ff                	xor    edi,edi
    710d54a042ee:	31 db                	xor    ebx,ebx
    710d54a042f0:	39 c8                	cmp    eax,ecx
    710d54a042f2:	0f 96 c2             	setbe  dl
    710d54a042f5:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a042fc:	40 0f 94 c6          	sete   sil
    710d54a04300:	40 0f 92 c7          	setb   dil
    710d54a04304:	0f 93 c3             	setae  bl
    710d54a04307:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a0430e:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a04315:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    710d54a0431c:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    710d54a04323:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10222
    710d54a0432a:	22 02 01 00 
    710d54a0432e:	0f 84 94 1a 00 18    	je     0x710d6ca05dc8
    710d54a04334:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10222
    710d54a0433b:	22 02 01 00 
    710d54a0433f:	0f 84 83 1a 00 18    	je     0x710d6ca05dc8
    710d54a04345:	58                   	pop    rax
    710d54a04346:	50                   	push   rax
    710d54a04347:	41 8b 45 20          	mov    eax,DWORD PTR [r13+0x20]
    710d54a0434b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a04352:	c1 e0 02             	shl    eax,0x2
    710d54a04355:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    710d54a04359:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a0435d:	81 f9 24 02 01 00    	cmp    ecx,0x10224
    710d54a04363:	0f 84 bf 1a 00 18    	je     0x710d6ca05e28
    710d54a04369:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10224
    710d54a04370:	24 02 01 00 
    710d54a04374:	0f 84 ae 1a 00 18    	je     0x710d6ca05e28
    710d54a0437a:	58                   	pop    rax
    710d54a0437b:	50                   	push   rax
    710d54a0437c:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a04380:	f6 c1 03             	test   cl,0x3
    710d54a04383:	0f 85 ff 1a 00 18    	jne    0x710d6ca05e88
    710d54a04389:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a04390:	48 89 ca             	mov    rdx,rcx
    710d54a04393:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a04397:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a0439b:	48 85 c0             	test   rax,rax
    710d54a0439e:	0f 84 34 1b 00 18    	je     0x710d6ca05ed8
    710d54a043a4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a043aa:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a043ad:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a043b1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10226
    710d54a043b8:	26 02 01 00 
    710d54a043bc:	0f 84 51 1b 00 18    	je     0x710d6ca05f13
    710d54a043c2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10226
    710d54a043c9:	26 02 01 00 
    710d54a043cd:	0f 84 40 1b 00 18    	je     0x710d6ca05f13
    710d54a043d3:	58                   	pop    rax
    710d54a043d4:	50                   	push   rax
    710d54a043d5:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a043d9:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a043e0:	31 d2                	xor    edx,edx
    710d54a043e2:	41 33 45 08          	xor    eax,DWORD PTR [r13+0x8]
    710d54a043e6:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a043ea:	0f 94 c2             	sete   dl
    710d54a043ed:	c1 e8 1f             	shr    eax,0x1f
    710d54a043f0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a043f7:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a043fe:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a04405:	00 00 00 00 
    710d54a04409:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a04410:	00 00 00 00 
    710d54a04414:	81 f9 28 02 01 00    	cmp    ecx,0x10228
    710d54a0441a:	0f 84 3c 1b 00 18    	je     0x710d6ca05f5c
    710d54a04420:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10228
    710d54a04427:	28 02 01 00 
    710d54a0442b:	0f 84 2b 1b 00 18    	je     0x710d6ca05f5c
    710d54a04431:	58                   	pop    rax
    710d54a04432:	50                   	push   rax
    710d54a04433:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a04437:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    710d54a0443b:	89 c2                	mov    edx,eax
    710d54a0443d:	c1 ea 1f             	shr    edx,0x1f
    710d54a04440:	89 ce                	mov    esi,ecx
    710d54a04442:	c1 ee 1f             	shr    esi,0x1f
    710d54a04445:	31 ff                	xor    edi,edi
    710d54a04447:	01 c8                	add    eax,ecx
    710d54a04449:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a0444d:	40 0f 92 c7          	setb   dil
    710d54a04451:	89 c1                	mov    ecx,eax
    710d54a04453:	c1 e9 1f             	shr    ecx,0x1f
    710d54a04456:	31 ce                	xor    esi,ecx
    710d54a04458:	31 ca                	xor    edx,ecx
    710d54a0445a:	21 f2                	and    edx,esi
    710d54a0445c:	31 f6                	xor    esi,esi
    710d54a0445e:	85 c0                	test   eax,eax
    710d54a04460:	40 0f 94 c6          	sete   sil
    710d54a04464:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a0446b:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    710d54a04472:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    710d54a04479:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    710d54a04480:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    710d54a04487:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a0448e:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a04495:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022a
    710d54a0449c:	2a 02 01 00 
    710d54a044a0:	0f 84 16 1b 00 18    	je     0x710d6ca05fbc
    710d54a044a6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022a
    710d54a044ad:	2a 02 01 00 
    710d54a044b1:	0f 84 05 1b 00 18    	je     0x710d6ca05fbc
    710d54a044b7:	58                   	pop    rax
    710d54a044b8:	50                   	push   rax
    710d54a044b9:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a044c0:	00 
    710d54a044c1:	74 28                	je     0x710d54a044eb
    710d54a044c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022c
    710d54a044ca:	2c 02 01 00 
    710d54a044ce:	0f 84 48 1b 00 18    	je     0x710d6ca0601c
    710d54a044d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022c
    710d54a044db:	2c 02 01 00 
    710d54a044df:	0f 84 37 1b 00 18    	je     0x710d6ca0601c
    710d54a044e5:	58                   	pop    rax
    710d54a044e6:	e9 55 00 00 00       	jmp    0x710d54a04540
    710d54a044eb:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a044f2:	01 
    710d54a044f3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022c
    710d54a044fa:	2c 02 01 00 
    710d54a044fe:	0f 84 61 1b 00 18    	je     0x710d6ca06065
    710d54a04504:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022c
    710d54a0450b:	2c 02 01 00 
    710d54a0450f:	0f 84 50 1b 00 18    	je     0x710d6ca06065
    710d54a04515:	b8 2c 02 01 00       	mov    eax,0x1022c
    710d54a0451a:	83 c0 f2             	add    eax,0xfffffff2
    710d54a0451d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a04524:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a0452b:	02 00 00 00 
    710d54a0452f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    710d54a04536:	13 00 00 00 
    710d54a0453a:	58                   	pop    rax
    710d54a0453b:	e9 a4 01 00 00       	jmp    0x710d54a046e4
    710d54a04540:	50                   	push   rax
    710d54a04541:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a04545:	f6 c3 03             	test   bl,0x3
    710d54a04548:	0f 85 53 1b 00 18    	jne    0x710d6ca060a1
    710d54a0454e:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a04555:	48 89 d8             	mov    rax,rbx
    710d54a04558:	48 c1 e8 0c          	shr    rax,0xc
    710d54a0455c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a04561:	48 85 c0             	test   rax,rax
    710d54a04564:	0f 84 89 1b 00 18    	je     0x710d6ca060f3
    710d54a0456a:	89 d9                	mov    ecx,ebx
    710d54a0456c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a04572:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a04576:	89 de                	mov    esi,ebx
    710d54a04578:	83 c6 04             	add    esi,0x4
    710d54a0457b:	89 f0                	mov    eax,esi
    710d54a0457d:	c1 e8 0c             	shr    eax,0xc
    710d54a04580:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a04585:	48 85 c0             	test   rax,rax
    710d54a04588:	0f 84 a2 1b 00 18    	je     0x710d6ca06130
    710d54a0458e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a04594:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a04597:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a0459a:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a0459e:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a045a5:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a045a9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1022e
    710d54a045b0:	2e 02 01 00 
    710d54a045b4:	0f 84 b2 1b 00 18    	je     0x710d6ca0616c
    710d54a045ba:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1022e
    710d54a045c1:	2e 02 01 00 
    710d54a045c5:	0f 84 a1 1b 00 18    	je     0x710d6ca0616c
    710d54a045cb:	58                   	pop    rax
    710d54a045cc:	50                   	push   rax
    710d54a045cd:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a045d1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a045d8:	31 d2                	xor    edx,edx
    710d54a045da:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    710d54a045de:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a045e2:	0f 94 c2             	sete   dl
    710d54a045e5:	c1 e8 1f             	shr    eax,0x1f
    710d54a045e8:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a045ef:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a045f6:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a045fd:	00 00 00 00 
    710d54a04601:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a04608:	00 00 00 00 
    710d54a0460c:	81 f9 32 02 01 00    	cmp    ecx,0x10232
    710d54a04612:	0f 84 9d 1b 00 18    	je     0x710d6ca061b5
    710d54a04618:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10232
    710d54a0461f:	32 02 01 00 
    710d54a04623:	0f 84 8c 1b 00 18    	je     0x710d6ca061b5
    710d54a04629:	58                   	pop    rax
    710d54a0462a:	50                   	push   rax
    710d54a0462b:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a0462f:	f6 c3 03             	test   bl,0x3
    710d54a04632:	0f 85 dd 1b 00 18    	jne    0x710d6ca06215
    710d54a04638:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a0463f:	48 89 d9             	mov    rcx,rbx
    710d54a04642:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a04646:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a0464a:	48 85 c0             	test   rax,rax
    710d54a0464d:	0f 84 14 1c 00 18    	je     0x710d6ca06267
    710d54a04653:	89 d9                	mov    ecx,ebx
    710d54a04655:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0465b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a0465e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a04662:	83 c3 04             	add    ebx,0x4
    710d54a04665:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a04669:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10234
    710d54a04670:	34 02 01 00 
    710d54a04674:	0f 84 28 1c 00 18    	je     0x710d6ca062a2
    710d54a0467a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10234
    710d54a04681:	34 02 01 00 
    710d54a04685:	0f 84 17 1c 00 18    	je     0x710d6ca062a2
    710d54a0468b:	58                   	pop    rax
    710d54a0468c:	50                   	push   rax
    710d54a0468d:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a04694:	a8 01                	test   al,0x1
    710d54a04696:	0f 85 4f 1c 00 18    	jne    0x710d6ca062eb
    710d54a0469c:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a046a3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a046aa:	01 
    710d54a046ab:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10236
    710d54a046b2:	36 02 01 00 
    710d54a046b6:	0f 84 65 1c 00 18    	je     0x710d6ca06321
    710d54a046bc:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10236
    710d54a046c3:	36 02 01 00 
    710d54a046c7:	0f 84 54 1c 00 18    	je     0x710d6ca06321
    710d54a046cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a046d4:	02 00 00 00 
    710d54a046d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d54a046df:	17 00 00 00 
    710d54a046e3:	58                   	pop    rax
    710d54a046e4:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a046eb:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a046f2:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a046f9:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a04700:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a04707:	39 f1                	cmp    ecx,esi
    710d54a04709:	0f 83 3f 1c 00 18    	jae    0x710d6ca0634e
    710d54a0470f:	81 fa fc 01 01 00    	cmp    edx,0x101fc
    710d54a04715:	75 14                	jne    0x710d54a0472b
    710d54a04717:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0471e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a04725:	00 
    710d54a04726:	e9 45 f7 ff ff       	jmp    0x710d54a03e70
    710d54a0472b:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a04732:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a04738:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a0473b:	0f 85 0d 1c 00 18    	jne    0x710d6ca0634e
    710d54a04741:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a04748:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a0474f:	00 
    710d54a04750:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a04755:	ff e0                	jmp    rax
