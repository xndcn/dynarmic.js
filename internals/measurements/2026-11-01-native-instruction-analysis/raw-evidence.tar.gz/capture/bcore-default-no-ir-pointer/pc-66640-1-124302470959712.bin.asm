
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66640-1-124302470959712.bin:     file format binary


Disassembly of section .data:

0000710d6ca05260 <.data>:
    710d6ca05260:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca05266:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca05269:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca0526f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca05276:	0f 87 15 e9 ff e7    	ja     0x710d54a03b91
    710d6ca0527c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xc
    710d6ca05283:	0c 00 00 00 
    710d6ca05287:	e9 05 e9 ff e7       	jmp    0x710d54a03b91
    710d6ca0528c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10450
    710d6ca05293:	50 04 01 00 
    710d6ca05297:	b8 50 04 01 00       	mov    eax,0x10450
    710d6ca0529c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca052a3:	04 00 00 00 
    710d6ca052a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca052ae:	01 00 00 00 
    710d6ca052b2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca052b5:	be 50 04 01 00       	mov    esi,0x10450
    710d6ca052ba:	4c 89 ef             	mov    rdi,r13
    710d6ca052bd:	e8 9e ae ff e7       	call   0x710d54a00160
    710d6ca052c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca052c9:	00 
    710d6ca052ca:	0f 84 f4 e8 ff e7    	je     0x710d54a03bc4
    710d6ca052d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca052d7:	04 00 00 00 
    710d6ca052db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca052e2:	01 00 00 00 
    710d6ca052e6:	58                   	pop    rax
    710d6ca052e7:	e9 06 eb ff e7       	jmp    0x710d54a03df2
    710d6ca052ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10454
    710d6ca052f3:	54 04 01 00 
    710d6ca052f7:	b8 54 04 01 00       	mov    eax,0x10454
    710d6ca052fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05303:	04 00 00 00 
    710d6ca05307:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0530e:	02 00 00 00 
    710d6ca05312:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05315:	be 54 04 01 00       	mov    esi,0x10454
    710d6ca0531a:	4c 89 ef             	mov    rdi,r13
    710d6ca0531d:	e8 3e ae ff e7       	call   0x710d54a00160
    710d6ca05322:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05329:	00 
    710d6ca0532a:	0f 84 cb e8 ff e7    	je     0x710d54a03bfb
    710d6ca05330:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05337:	04 00 00 00 
    710d6ca0533b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca05342:	02 00 00 00 
    710d6ca05346:	58                   	pop    rax
    710d6ca05347:	e9 a6 ea ff e7       	jmp    0x710d54a03df2
    710d6ca0534c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10458
    710d6ca05353:	58 04 01 00 
    710d6ca05357:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0535e:	02 00 00 00 
    710d6ca05362:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca05369:	03 00 00 00 
    710d6ca0536d:	ba 58 04 01 00       	mov    edx,0x10458
    710d6ca05372:	4c 89 ef             	mov    rdi,r13
    710d6ca05375:	4c 89 f6             	mov    rsi,r14
    710d6ca05378:	45 31 c0             	xor    r8d,r8d
    710d6ca0537b:	e8 00 ad ff e7       	call   0x710d54a00080
    710d6ca05380:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05387:	02 00 00 00 
    710d6ca0538b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca05392:	03 00 00 00 
    710d6ca05396:	58                   	pop    rax
    710d6ca05397:	e9 56 ea ff e7       	jmp    0x710d54a03df2
    710d6ca0539c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10458
    710d6ca053a3:	58 04 01 00 
    710d6ca053a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca053ae:	02 00 00 00 
    710d6ca053b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca053b9:	03 00 00 00 
    710d6ca053bd:	4c 89 f7             	mov    rdi,r14
    710d6ca053c0:	89 ce                	mov    esi,ecx
    710d6ca053c2:	e8 79 ac ff e7       	call   0x710d54a00040
    710d6ca053c7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca053ce:	00 
    710d6ca053cf:	0f 84 59 e8 ff e7    	je     0x710d54a03c2e
    710d6ca053d5:	eb a9                	jmp    0x710d6ca05380
    710d6ca053d7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10458
    710d6ca053de:	58 04 01 00 
    710d6ca053e2:	b8 58 04 01 00       	mov    eax,0x10458
    710d6ca053e7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca053ee:	02 00 00 00 
    710d6ca053f2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca053f9:	03 00 00 00 
    710d6ca053fd:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05400:	be 58 04 01 00       	mov    esi,0x10458
    710d6ca05405:	4c 89 ef             	mov    rdi,r13
    710d6ca05408:	e8 53 ad ff e7       	call   0x710d54a00160
    710d6ca0540d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05414:	00 
    710d6ca05415:	0f 84 39 e8 ff e7    	je     0x710d54a03c54
    710d6ca0541b:	e9 60 ff ff ff       	jmp    0x710d6ca05380
    710d6ca05420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1045a
    710d6ca05427:	5a 04 01 00 
    710d6ca0542b:	b8 5a 04 01 00       	mov    eax,0x1045a
    710d6ca05430:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05437:	04 00 00 00 
    710d6ca0543b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05442:	04 00 00 00 
    710d6ca05446:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca05449:	be 5a 04 01 00       	mov    esi,0x1045a
    710d6ca0544e:	4c 89 ef             	mov    rdi,r13
    710d6ca05451:	e8 0a ad ff e7       	call   0x710d54a00160
    710d6ca05456:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0545d:	00 
    710d6ca0545e:	0f 84 24 e8 ff e7    	je     0x710d54a03c88
    710d6ca05464:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0546b:	04 00 00 00 
    710d6ca0546f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca05476:	04 00 00 00 
    710d6ca0547a:	58                   	pop    rax
    710d6ca0547b:	e9 72 e9 ff e7       	jmp    0x710d54a03df2
    710d6ca05480:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1045e
    710d6ca05487:	5e 04 01 00 
    710d6ca0548b:	b8 5e 04 01 00       	mov    eax,0x1045e
    710d6ca05490:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05497:	04 00 00 00 
    710d6ca0549b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca054a2:	05 00 00 00 
    710d6ca054a6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca054a9:	be 5e 04 01 00       	mov    esi,0x1045e
    710d6ca054ae:	4c 89 ef             	mov    rdi,r13
    710d6ca054b1:	e8 aa ac ff e7       	call   0x710d54a00160
    710d6ca054b6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca054bd:	00 
    710d6ca054be:	0f 84 fb e7 ff e7    	je     0x710d54a03cbf
    710d6ca054c4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca054cb:	04 00 00 00 
    710d6ca054cf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca054d6:	05 00 00 00 
    710d6ca054da:	58                   	pop    rax
    710d6ca054db:	e9 12 e9 ff e7       	jmp    0x710d54a03df2
    710d6ca054e0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10462
    710d6ca054e7:	62 04 01 00 
    710d6ca054eb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca054f2:	02 00 00 00 
    710d6ca054f6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca054fd:	06 00 00 00 
    710d6ca05501:	ba 62 04 01 00       	mov    edx,0x10462
    710d6ca05506:	4c 89 ef             	mov    rdi,r13
    710d6ca05509:	4c 89 f6             	mov    rsi,r14
    710d6ca0550c:	45 31 c0             	xor    r8d,r8d
    710d6ca0550f:	e8 6c ab ff e7       	call   0x710d54a00080
    710d6ca05514:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0551b:	02 00 00 00 
    710d6ca0551f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca05526:	06 00 00 00 
    710d6ca0552a:	58                   	pop    rax
    710d6ca0552b:	e9 c2 e8 ff e7       	jmp    0x710d54a03df2
    710d6ca05530:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10462
    710d6ca05537:	62 04 01 00 
    710d6ca0553b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05542:	02 00 00 00 
    710d6ca05546:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca0554d:	06 00 00 00 
    710d6ca05551:	4c 89 f7             	mov    rdi,r14
    710d6ca05554:	89 ce                	mov    esi,ecx
    710d6ca05556:	e8 e5 aa ff e7       	call   0x710d54a00040
    710d6ca0555b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05562:	00 
    710d6ca05563:	0f 84 89 e7 ff e7    	je     0x710d54a03cf2
    710d6ca05569:	eb a9                	jmp    0x710d6ca05514
    710d6ca0556b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10462
    710d6ca05572:	62 04 01 00 
    710d6ca05576:	b8 62 04 01 00       	mov    eax,0x10462
    710d6ca0557b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca05582:	02 00 00 00 
    710d6ca05586:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca0558d:	06 00 00 00 
    710d6ca05591:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca05594:	be 62 04 01 00       	mov    esi,0x10462
    710d6ca05599:	4c 89 ef             	mov    rdi,r13
    710d6ca0559c:	e8 bf ab ff e7       	call   0x710d54a00160
    710d6ca055a1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca055a8:	00 
    710d6ca055a9:	0f 84 69 e7 ff e7    	je     0x710d54a03d18
    710d6ca055af:	e9 60 ff ff ff       	jmp    0x710d6ca05514
    710d6ca055b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10464
    710d6ca055bb:	64 04 01 00 
    710d6ca055bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca055c6:	04 00 00 00 
    710d6ca055ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca055d1:	07 00 00 00 
    710d6ca055d5:	ba 64 04 01 00       	mov    edx,0x10464
    710d6ca055da:	4c 89 ef             	mov    rdi,r13
    710d6ca055dd:	4c 89 f6             	mov    rsi,r14
    710d6ca055e0:	89 d9                	mov    ecx,ebx
    710d6ca055e2:	45 31 c0             	xor    r8d,r8d
    710d6ca055e5:	e8 96 aa ff e7       	call   0x710d54a00080
    710d6ca055ea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca055f1:	04 00 00 00 
    710d6ca055f5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca055fc:	07 00 00 00 
    710d6ca05600:	58                   	pop    rax
    710d6ca05601:	e9 ec e7 ff e7       	jmp    0x710d54a03df2
    710d6ca05606:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10464
    710d6ca0560d:	64 04 01 00 
    710d6ca05611:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05618:	04 00 00 00 
    710d6ca0561c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca05623:	07 00 00 00 
    710d6ca05627:	4c 89 f7             	mov    rdi,r14
    710d6ca0562a:	89 de                	mov    esi,ebx
    710d6ca0562c:	e8 0f aa ff e7       	call   0x710d54a00040
    710d6ca05631:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05638:	00 
    710d6ca05639:	75 af                	jne    0x710d6ca055ea
    710d6ca0563b:	41 89 c7             	mov    r15d,eax
    710d6ca0563e:	e9 0c e7 ff e7       	jmp    0x710d54a03d4f
    710d6ca05643:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10464
    710d6ca0564a:	64 04 01 00 
    710d6ca0564e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05655:	04 00 00 00 
    710d6ca05659:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca05660:	07 00 00 00 
    710d6ca05664:	4c 89 f7             	mov    rdi,r14
    710d6ca05667:	e8 d4 a9 ff e7       	call   0x710d54a00040
    710d6ca0566c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca05673:	00 
    710d6ca05674:	0f 84 f6 e6 ff e7    	je     0x710d54a03d70
    710d6ca0567a:	e9 6b ff ff ff       	jmp    0x710d6ca055ea
    710d6ca0567f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10464
    710d6ca05686:	64 04 01 00 
    710d6ca0568a:	b8 64 04 01 00       	mov    eax,0x10464
    710d6ca0568f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca05696:	04 00 00 00 
    710d6ca0569a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca056a1:	07 00 00 00 
    710d6ca056a5:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca056a8:	be 64 04 01 00       	mov    esi,0x10464
    710d6ca056ad:	4c 89 ef             	mov    rdi,r13
    710d6ca056b0:	e8 ab aa ff e7       	call   0x710d54a00160
    710d6ca056b5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca056bc:	00 
    710d6ca056bd:	0f 84 e1 e6 ff e7    	je     0x710d54a03da4
    710d6ca056c3:	e9 22 ff ff ff       	jmp    0x710d6ca055ea
    710d6ca056c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    710d6ca056cf:	fc 01 01 00 
    710d6ca056d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca056da:	04 00 00 00 
    710d6ca056de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca056e5:	08 00 00 00 
    710d6ca056e9:	be 68 04 01 00       	mov    esi,0x10468
    710d6ca056ee:	ba 68 04 01 00       	mov    edx,0x10468
    710d6ca056f3:	4c 89 ef             	mov    rdi,r13
    710d6ca056f6:	e8 65 aa ff e7       	call   0x710d54a00160
    710d6ca056fb:	e9 d0 e6 ff e7       	jmp    0x710d54a03dd0
    710d6ca05700:	c2 08 00             	ret    0x8
