
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65682-1-124302068298512.bin:     file format binary


Disassembly of section .data:

0000710d54a03310 <.data>:
    710d54a03310:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03317:	8b 88 24 00 10 00    	mov    ecx,DWORD PTR [rax+0x100024]
    710d54a0331d:	ff c1                	inc    ecx
    710d54a0331f:	89 88 24 00 10 00    	mov    DWORD PTR [rax+0x100024],ecx
    710d54a03325:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0332b:	0f 84 7f 14 00 18    	je     0x710d6ca047b0
    710d54a03331:	50                   	push   rax
    710d54a03332:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a03336:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0333d:	31 d2                	xor    edx,edx
    710d54a0333f:	85 c0                	test   eax,eax
    710d54a03341:	0f 94 c2             	sete   dl
    710d54a03344:	c1 e8 1f             	shr    eax,0x1f
    710d54a03347:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a0334e:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a03355:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a0335c:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    710d54a03363:	00 00 00 
    710d54a03366:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    710d54a0336d:	81 f9 92 00 01 00    	cmp    ecx,0x10092
    710d54a03373:	0f 84 63 14 00 18    	je     0x710d6ca047dc
    710d54a03379:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10092
    710d54a03380:	92 00 01 00 
    710d54a03384:	0f 84 52 14 00 18    	je     0x710d6ca047dc
    710d54a0338a:	58                   	pop    rax
    710d54a0338b:	50                   	push   rax
    710d54a0338c:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a03393:	00 
    710d54a03394:	74 28                	je     0x710d54a033be
    710d54a03396:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    710d54a0339d:	94 00 01 00 
    710d54a033a1:	0f 84 95 14 00 18    	je     0x710d6ca0483c
    710d54a033a7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    710d54a033ae:	94 00 01 00 
    710d54a033b2:	0f 84 84 14 00 18    	je     0x710d6ca0483c
    710d54a033b8:	58                   	pop    rax
    710d54a033b9:	e9 55 00 00 00       	jmp    0x710d54a03413
    710d54a033be:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a033c5:	01 
    710d54a033c6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    710d54a033cd:	94 00 01 00 
    710d54a033d1:	0f 84 ae 14 00 18    	je     0x710d6ca04885
    710d54a033d7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    710d54a033de:	94 00 01 00 
    710d54a033e2:	0f 84 9d 14 00 18    	je     0x710d6ca04885
    710d54a033e8:	b8 94 00 01 00       	mov    eax,0x10094
    710d54a033ed:	83 c0 2c             	add    eax,0x2c
    710d54a033f0:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a033f7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a033fe:	02 00 00 00 
    710d54a03402:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d54a03409:	02 00 00 00 
    710d54a0340d:	58                   	pop    rax
    710d54a0340e:	e9 15 01 00 00       	jmp    0x710d54a03528
    710d54a03413:	50                   	push   rax
    710d54a03414:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    710d54a03418:	f6 c1 03             	test   cl,0x3
    710d54a0341b:	0f 85 a0 14 00 18    	jne    0x710d6ca048c1
    710d54a03421:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a03428:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    710d54a0342c:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a03433:	48 89 ce             	mov    rsi,rcx
    710d54a03436:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a0343a:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a0343e:	48 85 c0             	test   rax,rax
    710d54a03441:	0f 84 cd 14 00 18    	je     0x710d6ca04914
    710d54a03447:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0344d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a03450:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10096
    710d54a03457:	96 00 01 00 
    710d54a0345b:	0f 84 ee 14 00 18    	je     0x710d6ca0494f
    710d54a03461:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10096
    710d54a03468:	96 00 01 00 
    710d54a0346c:	0f 84 dd 14 00 18    	je     0x710d6ca0494f
    710d54a03472:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a03475:	0f 85 15 15 00 18    	jne    0x710d6ca04990
    710d54a0347b:	58                   	pop    rax
    710d54a0347c:	e9 0f 00 00 00       	jmp    0x710d54a03490
    710d54a03481:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a03488:	00 
    710d54a03489:	74 f0                	je     0x710d54a0347b
    710d54a0348b:	e9 68 14 00 18       	jmp    0x710d6ca048f8
    710d54a03490:	50                   	push   rax
    710d54a03491:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a03498:	b9 98 00 01 00       	mov    ecx,0x10098
    710d54a0349d:	83 c1 04             	add    ecx,0x4
    710d54a034a0:	89 ca                	mov    edx,ecx
    710d54a034a2:	3d 98 00 01 00       	cmp    eax,0x10098
    710d54a034a7:	75 07                	jne    0x710d54a034b0
    710d54a034a9:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    710d54a034b0:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    710d54a034b7:	02 
    710d54a034b8:	0f 43 ca             	cmovae ecx,edx
    710d54a034bb:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    710d54a034c2:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    710d54a034c9:	89 cf                	mov    edi,ecx
    710d54a034cb:	81 fa 98 00 01 00    	cmp    edx,0x10098
    710d54a034d1:	75 07                	jne    0x710d54a034da
    710d54a034d3:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    710d54a034da:	83 fe 02             	cmp    esi,0x2
    710d54a034dd:	0f 43 cf             	cmovae ecx,edi
    710d54a034e0:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    710d54a034e7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a034ee:	01 
    710d54a034ef:	3d 98 00 01 00       	cmp    eax,0x10098
    710d54a034f4:	0f 84 c8 14 00 18    	je     0x710d6ca049c2
    710d54a034fa:	81 fa 98 00 01 00    	cmp    edx,0x10098
    710d54a03500:	0f 84 bc 14 00 18    	je     0x710d6ca049c2
    710d54a03506:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    710d54a0350d:	28 04 01 00 
    710d54a03511:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a03518:	04 00 00 00 
    710d54a0351c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d54a03523:	04 00 00 00 
    710d54a03527:	58                   	pop    rax
    710d54a03528:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a0352f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a03536:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0353d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a03544:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a0354b:	39 f1                	cmp    ecx,esi
    710d54a0354d:	0f 83 a7 14 00 18    	jae    0x710d6ca049fa
    710d54a03553:	81 fa 92 00 01 00    	cmp    edx,0x10092
    710d54a03559:	75 14                	jne    0x710d54a0356f
    710d54a0355b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03562:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03569:	00 
    710d54a0356a:	e9 a1 fd ff ff       	jmp    0x710d54a03310
    710d54a0356f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a03576:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a0357c:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a0357f:	0f 85 75 14 00 18    	jne    0x710d6ca049fa
    710d54a03585:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0358c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03593:	00 
    710d54a03594:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a03599:	ff e0                	jmp    rax
