
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65556-1-124302470938832.bin:     file format binary


Disassembly of section .data:

0000710d6ca000d0 <.data>:
    710d6ca000d0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca000d6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca000d9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca000df:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca000e6:	0f 87 a5 03 00 e8    	ja     0x710d54a00491
    710d6ca000ec:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x1
    710d6ca000f3:	01 00 00 00 
    710d6ca000f7:	e9 95 03 00 e8       	jmp    0x710d54a00491
    710d6ca000fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00103:	14 00 01 00 
    710d6ca00107:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0010e:	02 00 00 00 
    710d6ca00112:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00119:	01 00 00 00 
    710d6ca0011d:	ba 14 00 01 00       	mov    edx,0x10014
    710d6ca00122:	4c 89 ef             	mov    rdi,r13
    710d6ca00125:	4c 89 f6             	mov    rsi,r14
    710d6ca00128:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca0012e:	e8 4d ff ff e7       	call   0x710d54a00080
    710d6ca00133:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0013a:	02 00 00 00 
    710d6ca0013e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00145:	01 00 00 00 
    710d6ca00149:	58                   	pop    rax
    710d6ca0014a:	e9 8e 0a 00 e8       	jmp    0x710d54a00bdd
    710d6ca0014f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00156:	14 00 01 00 
    710d6ca0015a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00161:	02 00 00 00 
    710d6ca00165:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0016c:	01 00 00 00 
    710d6ca00170:	4c 89 f7             	mov    rdi,r14
    710d6ca00173:	89 ce                	mov    esi,ecx
    710d6ca00175:	e8 f6 fe ff e7       	call   0x710d54a00070
    710d6ca0017a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00181:	00 
    710d6ca00182:	0f 84 48 03 00 e8    	je     0x710d54a004d0
    710d6ca00188:	eb a9                	jmp    0x710d6ca00133
    710d6ca0018a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00191:	14 00 01 00 
    710d6ca00195:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0019c:	02 00 00 00 
    710d6ca001a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca001a7:	01 00 00 00 
    710d6ca001ab:	4c 89 f7             	mov    rdi,r14
    710d6ca001ae:	e8 bd fe ff e7       	call   0x710d54a00070
    710d6ca001b3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca001ba:	00 
    710d6ca001bb:	0f 84 32 03 00 e8    	je     0x710d54a004f3
    710d6ca001c1:	e9 6d ff ff ff       	jmp    0x710d6ca00133
    710d6ca001c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca001cd:	14 00 01 00 
    710d6ca001d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca001d8:	02 00 00 00 
    710d6ca001dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca001e3:	01 00 00 00 
    710d6ca001e7:	4c 89 f7             	mov    rdi,r14
    710d6ca001ea:	e8 81 fe ff e7       	call   0x710d54a00070
    710d6ca001ef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca001f6:	00 
    710d6ca001f7:	0f 84 19 03 00 e8    	je     0x710d54a00516
    710d6ca001fd:	e9 31 ff ff ff       	jmp    0x710d6ca00133
    710d6ca00202:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00209:	14 00 01 00 
    710d6ca0020d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00214:	02 00 00 00 
    710d6ca00218:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0021f:	01 00 00 00 
    710d6ca00223:	4c 89 f7             	mov    rdi,r14
    710d6ca00226:	e8 45 fe ff e7       	call   0x710d54a00070
    710d6ca0022b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00232:	00 
    710d6ca00233:	0f 84 00 03 00 e8    	je     0x710d54a00539
    710d6ca00239:	e9 f5 fe ff ff       	jmp    0x710d6ca00133
    710d6ca0023e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00245:	14 00 01 00 
    710d6ca00249:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00250:	02 00 00 00 
    710d6ca00254:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0025b:	01 00 00 00 
    710d6ca0025f:	4c 89 f7             	mov    rdi,r14
    710d6ca00262:	e8 09 fe ff e7       	call   0x710d54a00070
    710d6ca00267:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0026e:	00 
    710d6ca0026f:	0f 84 e7 02 00 e8    	je     0x710d54a0055c
    710d6ca00275:	e9 b9 fe ff ff       	jmp    0x710d6ca00133
    710d6ca0027a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca00281:	14 00 01 00 
    710d6ca00285:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0028c:	02 00 00 00 
    710d6ca00290:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00297:	01 00 00 00 
    710d6ca0029b:	4c 89 f7             	mov    rdi,r14
    710d6ca0029e:	e8 cd fd ff e7       	call   0x710d54a00070
    710d6ca002a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca002aa:	00 
    710d6ca002ab:	0f 84 ce 02 00 e8    	je     0x710d54a0057f
    710d6ca002b1:	e9 7d fe ff ff       	jmp    0x710d6ca00133
    710d6ca002b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca002bd:	14 00 01 00 
    710d6ca002c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca002c8:	02 00 00 00 
    710d6ca002cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca002d3:	01 00 00 00 
    710d6ca002d7:	4c 89 f7             	mov    rdi,r14
    710d6ca002da:	89 de                	mov    esi,ebx
    710d6ca002dc:	e8 8f fd ff e7       	call   0x710d54a00070
    710d6ca002e1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca002e8:	00 
    710d6ca002e9:	0f 84 b5 02 00 e8    	je     0x710d54a005a4
    710d6ca002ef:	e9 3f fe ff ff       	jmp    0x710d6ca00133
    710d6ca002f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    710d6ca002fb:	14 00 01 00 
    710d6ca002ff:	b8 14 00 01 00       	mov    eax,0x10014
    710d6ca00304:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0030b:	02 00 00 00 
    710d6ca0030f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00316:	01 00 00 00 
    710d6ca0031a:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0031d:	be 14 00 01 00       	mov    esi,0x10014
    710d6ca00322:	4c 89 ef             	mov    rdi,r13
    710d6ca00325:	e8 36 fe ff e7       	call   0x710d54a00160
    710d6ca0032a:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca0032e:	0f 84 a6 02 00 e8    	je     0x710d54a005da
    710d6ca00334:	eb 0f                	jmp    0x710d6ca00345
    710d6ca00336:	b8 14 00 01 00       	mov    eax,0x10014
    710d6ca0033b:	83 c0 02             	add    eax,0x2
    710d6ca0033e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca00345:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0034c:	02 00 00 00 
    710d6ca00350:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca00357:	01 00 00 00 
    710d6ca0035b:	4c 89 ef             	mov    rdi,r13
    710d6ca0035e:	e8 ed fd ff e7       	call   0x710d54a00150
    710d6ca00363:	e9 72 02 00 e8       	jmp    0x710d54a005da
    710d6ca00368:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    710d6ca0036f:	16 00 01 00 
    710d6ca00373:	b8 16 00 01 00       	mov    eax,0x10016
    710d6ca00378:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0037f:	04 00 00 00 
    710d6ca00383:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0038a:	02 00 00 00 
    710d6ca0038e:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca00391:	be 16 00 01 00       	mov    esi,0x10016
    710d6ca00396:	4c 89 ef             	mov    rdi,r13
    710d6ca00399:	e8 c2 fd ff e7       	call   0x710d54a00160
    710d6ca0039e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca003a5:	00 
    710d6ca003a6:	0f 84 70 02 00 e8    	je     0x710d54a0061c
    710d6ca003ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca003b3:	04 00 00 00 
    710d6ca003b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca003be:	02 00 00 00 
    710d6ca003c2:	58                   	pop    rax
    710d6ca003c3:	e9 15 08 00 e8       	jmp    0x710d54a00bdd
    710d6ca003c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    710d6ca003cf:	1a 00 01 00 
    710d6ca003d3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca003da:	04 00 00 00 
    710d6ca003de:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca003e5:	03 00 00 00 
    710d6ca003e9:	ba 1a 00 01 00       	mov    edx,0x1001a
    710d6ca003ee:	4c 89 ef             	mov    rdi,r13
    710d6ca003f1:	4c 89 f6             	mov    rsi,r14
    710d6ca003f4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca003fa:	e8 81 fc ff e7       	call   0x710d54a00080
    710d6ca003ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00406:	04 00 00 00 
    710d6ca0040a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00411:	03 00 00 00 
    710d6ca00415:	58                   	pop    rax
    710d6ca00416:	e9 c2 07 00 e8       	jmp    0x710d54a00bdd
    710d6ca0041b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    710d6ca00422:	1a 00 01 00 
    710d6ca00426:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0042d:	04 00 00 00 
    710d6ca00431:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00438:	03 00 00 00 
    710d6ca0043c:	4c 89 f7             	mov    rdi,r14
    710d6ca0043f:	89 ce                	mov    esi,ecx
    710d6ca00441:	e8 2a fc ff e7       	call   0x710d54a00070
    710d6ca00446:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0044d:	00 
    710d6ca0044e:	0f 84 0f 02 00 e8    	je     0x710d54a00663
    710d6ca00454:	eb a9                	jmp    0x710d6ca003ff
    710d6ca00456:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    710d6ca0045d:	1a 00 01 00 
    710d6ca00461:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00468:	04 00 00 00 
    710d6ca0046c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca00473:	03 00 00 00 
    710d6ca00477:	4c 89 f7             	mov    rdi,r14
    710d6ca0047a:	89 de                	mov    esi,ebx
    710d6ca0047c:	44 89 e2             	mov    edx,r12d
    710d6ca0047f:	e8 ec fb ff e7       	call   0x710d54a00070
    710d6ca00484:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0048b:	00 
    710d6ca0048c:	0f 84 f3 01 00 e8    	je     0x710d54a00685
    710d6ca00492:	e9 68 ff ff ff       	jmp    0x710d6ca003ff
    710d6ca00497:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    710d6ca0049e:	1a 00 01 00 
    710d6ca004a2:	b8 1a 00 01 00       	mov    eax,0x1001a
    710d6ca004a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca004ae:	04 00 00 00 
    710d6ca004b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca004b9:	03 00 00 00 
    710d6ca004bd:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca004c0:	be 1a 00 01 00       	mov    esi,0x1001a
    710d6ca004c5:	4c 89 ef             	mov    rdi,r13
    710d6ca004c8:	e8 93 fc ff e7       	call   0x710d54a00160
    710d6ca004cd:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca004d1:	0f 84 ef 01 00 e8    	je     0x710d54a006c6
    710d6ca004d7:	eb 0f                	jmp    0x710d6ca004e8
    710d6ca004d9:	b8 1a 00 01 00       	mov    eax,0x1001a
    710d6ca004de:	83 c0 04             	add    eax,0x4
    710d6ca004e1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca004e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca004ef:	04 00 00 00 
    710d6ca004f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca004fa:	03 00 00 00 
    710d6ca004fe:	4c 89 ef             	mov    rdi,r13
    710d6ca00501:	e8 4a fc ff e7       	call   0x710d54a00150
    710d6ca00506:	e9 bb 01 00 e8       	jmp    0x710d54a006c6
    710d6ca0050b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    710d6ca00512:	1e 00 01 00 
    710d6ca00516:	b8 1e 00 01 00       	mov    eax,0x1001e
    710d6ca0051b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00522:	04 00 00 00 
    710d6ca00526:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca0052d:	04 00 00 00 
    710d6ca00531:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca00534:	be 1e 00 01 00       	mov    esi,0x1001e
    710d6ca00539:	4c 89 ef             	mov    rdi,r13
    710d6ca0053c:	e8 1f fc ff e7       	call   0x710d54a00160
    710d6ca00541:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00548:	00 
    710d6ca00549:	0f 84 bc 01 00 e8    	je     0x710d54a0070b
    710d6ca0054f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00556:	04 00 00 00 
    710d6ca0055a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca00561:	04 00 00 00 
    710d6ca00565:	58                   	pop    rax
    710d6ca00566:	e9 72 06 00 e8       	jmp    0x710d54a00bdd
    710d6ca0056b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10022
    710d6ca00572:	22 00 01 00 
    710d6ca00576:	b8 22 00 01 00       	mov    eax,0x10022
    710d6ca0057b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00582:	04 00 00 00 
    710d6ca00586:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0058d:	05 00 00 00 
    710d6ca00591:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca00594:	be 22 00 01 00       	mov    esi,0x10022
    710d6ca00599:	4c 89 ef             	mov    rdi,r13
    710d6ca0059c:	e8 bf fb ff e7       	call   0x710d54a00160
    710d6ca005a1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca005a8:	00 
    710d6ca005a9:	0f 84 90 01 00 e8    	je     0x710d54a0073f
    710d6ca005af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca005b6:	04 00 00 00 
    710d6ca005ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca005c1:	05 00 00 00 
    710d6ca005c5:	58                   	pop    rax
    710d6ca005c6:	e9 12 06 00 e8       	jmp    0x710d54a00bdd
    710d6ca005cb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    710d6ca005d2:	26 00 01 00 
    710d6ca005d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca005dd:	02 00 00 00 
    710d6ca005e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca005e8:	06 00 00 00 
    710d6ca005ec:	ba 26 00 01 00       	mov    edx,0x10026
    710d6ca005f1:	4c 89 ef             	mov    rdi,r13
    710d6ca005f4:	4c 89 f6             	mov    rsi,r14
    710d6ca005f7:	45 31 c0             	xor    r8d,r8d
    710d6ca005fa:	e8 81 fa ff e7       	call   0x710d54a00080
    710d6ca005ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00606:	02 00 00 00 
    710d6ca0060a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca00611:	06 00 00 00 
    710d6ca00615:	58                   	pop    rax
    710d6ca00616:	e9 c2 05 00 e8       	jmp    0x710d54a00bdd
    710d6ca0061b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    710d6ca00622:	26 00 01 00 
    710d6ca00626:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0062d:	02 00 00 00 
    710d6ca00631:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca00638:	06 00 00 00 
    710d6ca0063c:	4c 89 f7             	mov    rdi,r14
    710d6ca0063f:	89 ce                	mov    esi,ecx
    710d6ca00641:	e8 fa f9 ff e7       	call   0x710d54a00040
    710d6ca00646:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0064d:	00 
    710d6ca0064e:	0f 84 1e 01 00 e8    	je     0x710d54a00772
    710d6ca00654:	eb a9                	jmp    0x710d6ca005ff
    710d6ca00656:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    710d6ca0065d:	26 00 01 00 
    710d6ca00661:	b8 26 00 01 00       	mov    eax,0x10026
    710d6ca00666:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0066d:	02 00 00 00 
    710d6ca00671:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca00678:	06 00 00 00 
    710d6ca0067c:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0067f:	be 26 00 01 00       	mov    esi,0x10026
    710d6ca00684:	4c 89 ef             	mov    rdi,r13
    710d6ca00687:	e8 d4 fa ff e7       	call   0x710d54a00160
    710d6ca0068c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00693:	00 
    710d6ca00694:	0f 84 fe 00 00 e8    	je     0x710d54a00798
    710d6ca0069a:	e9 60 ff ff ff       	jmp    0x710d6ca005ff
    710d6ca0069f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10028
    710d6ca006a6:	28 00 01 00 
    710d6ca006aa:	b8 28 00 01 00       	mov    eax,0x10028
    710d6ca006af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca006b6:	04 00 00 00 
    710d6ca006ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca006c1:	07 00 00 00 
    710d6ca006c5:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca006c8:	be 28 00 01 00       	mov    esi,0x10028
    710d6ca006cd:	4c 89 ef             	mov    rdi,r13
    710d6ca006d0:	e8 8b fa ff e7       	call   0x710d54a00160
    710d6ca006d5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca006dc:	00 
    710d6ca006dd:	0f 84 ec 00 00 e8    	je     0x710d54a007cf
    710d6ca006e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca006ea:	04 00 00 00 
    710d6ca006ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca006f5:	07 00 00 00 
    710d6ca006f9:	58                   	pop    rax
    710d6ca006fa:	e9 de 04 00 e8       	jmp    0x710d54a00bdd
    710d6ca006ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002c
    710d6ca00706:	2c 00 01 00 
    710d6ca0070a:	b8 2c 00 01 00       	mov    eax,0x1002c
    710d6ca0070f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00716:	02 00 00 00 
    710d6ca0071a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca00721:	08 00 00 00 
    710d6ca00725:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00728:	be 2c 00 01 00       	mov    esi,0x1002c
    710d6ca0072d:	4c 89 ef             	mov    rdi,r13
    710d6ca00730:	e8 2b fa ff e7       	call   0x710d54a00160
    710d6ca00735:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0073c:	00 
    710d6ca0073d:	0f 84 fd 00 00 e8    	je     0x710d54a00840
    710d6ca00743:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0074a:	02 00 00 00 
    710d6ca0074e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca00755:	08 00 00 00 
    710d6ca00759:	58                   	pop    rax
    710d6ca0075a:	e9 7e 04 00 e8       	jmp    0x710d54a00bdd
    710d6ca0075f:	b8 2e 00 01 00       	mov    eax,0x1002e
    710d6ca00764:	83 c0 12             	add    eax,0x12
    710d6ca00767:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0076e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00775:	02 00 00 00 
    710d6ca00779:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca00780:	09 00 00 00 
    710d6ca00784:	be 2e 00 01 00       	mov    esi,0x1002e
    710d6ca00789:	ba 2e 00 01 00       	mov    edx,0x1002e
    710d6ca0078e:	4c 89 ef             	mov    rdi,r13
    710d6ca00791:	e8 ca f9 ff e7       	call   0x710d54a00160
    710d6ca00796:	e9 db 00 00 e8       	jmp    0x710d54a00876
    710d6ca0079b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1002e
    710d6ca007a2:	2e 00 01 00 
    710d6ca007a6:	b8 2e 00 01 00       	mov    eax,0x1002e
    710d6ca007ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca007b2:	02 00 00 00 
    710d6ca007b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca007bd:	09 00 00 00 
    710d6ca007c1:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca007c4:	be 2e 00 01 00       	mov    esi,0x1002e
    710d6ca007c9:	4c 89 ef             	mov    rdi,r13
    710d6ca007cc:	e8 8f f9 ff e7       	call   0x710d54a00160
    710d6ca007d1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca007d8:	00 
    710d6ca007d9:	0f 84 e4 00 00 e8    	je     0x710d54a008c3
    710d6ca007df:	e9 a1 00 00 e8       	jmp    0x710d54a00885
    710d6ca007e4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10030
    710d6ca007eb:	30 00 01 00 
    710d6ca007ef:	b8 30 00 01 00       	mov    eax,0x10030
    710d6ca007f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca007fb:	02 00 00 00 
    710d6ca007ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca00806:	0a 00 00 00 
    710d6ca0080a:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0080d:	be 30 00 01 00       	mov    esi,0x10030
    710d6ca00812:	4c 89 ef             	mov    rdi,r13
    710d6ca00815:	e8 46 f9 ff e7       	call   0x710d54a00160
    710d6ca0081a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00821:	00 
    710d6ca00822:	0f 84 c7 00 00 e8    	je     0x710d54a008ef
    710d6ca00828:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0082f:	02 00 00 00 
    710d6ca00833:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca0083a:	0a 00 00 00 
    710d6ca0083e:	58                   	pop    rax
    710d6ca0083f:	e9 99 03 00 e8       	jmp    0x710d54a00bdd
    710d6ca00844:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10032
    710d6ca0084b:	32 00 01 00 
    710d6ca0084f:	b8 32 00 01 00       	mov    eax,0x10032
    710d6ca00854:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0085b:	02 00 00 00 
    710d6ca0085f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca00866:	0b 00 00 00 
    710d6ca0086a:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0086d:	be 32 00 01 00       	mov    esi,0x10032
    710d6ca00872:	4c 89 ef             	mov    rdi,r13
    710d6ca00875:	e8 e6 f8 ff e7       	call   0x710d54a00160
    710d6ca0087a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00881:	00 
    710d6ca00882:	0f 84 90 00 00 e8    	je     0x710d54a00918
    710d6ca00888:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0088f:	02 00 00 00 
    710d6ca00893:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca0089a:	0b 00 00 00 
    710d6ca0089e:	58                   	pop    rax
    710d6ca0089f:	e9 39 03 00 e8       	jmp    0x710d54a00bdd
    710d6ca008a4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    710d6ca008ab:	34 00 01 00 
    710d6ca008af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca008b6:	02 00 00 00 
    710d6ca008ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca008c1:	0c 00 00 00 
    710d6ca008c5:	ba 34 00 01 00       	mov    edx,0x10034
    710d6ca008ca:	4c 89 ef             	mov    rdi,r13
    710d6ca008cd:	4c 89 f6             	mov    rsi,r14
    710d6ca008d0:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca008d6:	e8 a5 f7 ff e7       	call   0x710d54a00080
    710d6ca008db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca008e2:	02 00 00 00 
    710d6ca008e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca008ed:	0c 00 00 00 
    710d6ca008f1:	58                   	pop    rax
    710d6ca008f2:	e9 e6 02 00 e8       	jmp    0x710d54a00bdd
    710d6ca008f7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    710d6ca008fe:	34 00 01 00 
    710d6ca00902:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00909:	02 00 00 00 
    710d6ca0090d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca00914:	0c 00 00 00 
    710d6ca00918:	4c 89 f7             	mov    rdi,r14
    710d6ca0091b:	89 ce                	mov    esi,ecx
    710d6ca0091d:	e8 4e f7 ff e7       	call   0x710d54a00070
    710d6ca00922:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00929:	00 
    710d6ca0092a:	0f 84 26 00 00 e8    	je     0x710d54a00956
    710d6ca00930:	eb a9                	jmp    0x710d6ca008db
    710d6ca00932:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    710d6ca00939:	34 00 01 00 
    710d6ca0093d:	b8 34 00 01 00       	mov    eax,0x10034
    710d6ca00942:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00949:	02 00 00 00 
    710d6ca0094d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca00954:	0c 00 00 00 
    710d6ca00958:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca0095b:	be 34 00 01 00       	mov    esi,0x10034
    710d6ca00960:	4c 89 ef             	mov    rdi,r13
    710d6ca00963:	e8 f8 f7 ff e7       	call   0x710d54a00160
    710d6ca00968:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca0096b:	0f 84 16 00 00 e8    	je     0x710d54a00987
    710d6ca00971:	eb 0f                	jmp    0x710d6ca00982
    710d6ca00973:	b8 34 00 01 00       	mov    eax,0x10034
    710d6ca00978:	83 c0 02             	add    eax,0x2
    710d6ca0097b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca00982:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00989:	02 00 00 00 
    710d6ca0098d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca00994:	0c 00 00 00 
    710d6ca00998:	4c 89 ef             	mov    rdi,r13
    710d6ca0099b:	e8 b0 f7 ff e7       	call   0x710d54a00150
    710d6ca009a0:	e9 e2 ff ff e7       	jmp    0x710d54a00987
    710d6ca009a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    710d6ca009ac:	36 00 01 00 
    710d6ca009b0:	b8 36 00 01 00       	mov    eax,0x10036
    710d6ca009b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca009bc:	02 00 00 00 
    710d6ca009c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca009c7:	0d 00 00 00 
    710d6ca009cb:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca009ce:	be 36 00 01 00       	mov    esi,0x10036
    710d6ca009d3:	4c 89 ef             	mov    rdi,r13
    710d6ca009d6:	e8 85 f7 ff e7       	call   0x710d54a00160
    710d6ca009db:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca009e2:	00 
    710d6ca009e3:	0f 84 d8 ff ff e7    	je     0x710d54a009c1
    710d6ca009e9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca009f0:	02 00 00 00 
    710d6ca009f4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca009fb:	0d 00 00 00 
    710d6ca009ff:	58                   	pop    rax
    710d6ca00a00:	e9 d8 01 00 e8       	jmp    0x710d54a00bdd
    710d6ca00a05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    710d6ca00a0c:	38 00 01 00 
    710d6ca00a10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00a17:	04 00 00 00 
    710d6ca00a1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca00a22:	0e 00 00 00 
    710d6ca00a26:	ba 38 00 01 00       	mov    edx,0x10038
    710d6ca00a2b:	4c 89 ef             	mov    rdi,r13
    710d6ca00a2e:	4c 89 f6             	mov    rsi,r14
    710d6ca00a31:	89 d9                	mov    ecx,ebx
    710d6ca00a33:	45 31 c0             	xor    r8d,r8d
    710d6ca00a36:	e8 45 f6 ff e7       	call   0x710d54a00080
    710d6ca00a3b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00a42:	04 00 00 00 
    710d6ca00a46:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca00a4d:	0e 00 00 00 
    710d6ca00a51:	58                   	pop    rax
    710d6ca00a52:	e9 86 01 00 e8       	jmp    0x710d54a00bdd
    710d6ca00a57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    710d6ca00a5e:	38 00 01 00 
    710d6ca00a62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00a69:	04 00 00 00 
    710d6ca00a6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca00a74:	0e 00 00 00 
    710d6ca00a78:	4c 89 f7             	mov    rdi,r14
    710d6ca00a7b:	89 de                	mov    esi,ebx
    710d6ca00a7d:	e8 be f5 ff e7       	call   0x710d54a00040
    710d6ca00a82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00a89:	00 
    710d6ca00a8a:	75 af                	jne    0x710d6ca00a3b
    710d6ca00a8c:	41 89 c7             	mov    r15d,eax
    710d6ca00a8f:	e9 64 ff ff e7       	jmp    0x710d54a009f8
    710d6ca00a94:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    710d6ca00a9b:	38 00 01 00 
    710d6ca00a9f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00aa6:	04 00 00 00 
    710d6ca00aaa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca00ab1:	0e 00 00 00 
    710d6ca00ab5:	4c 89 f7             	mov    rdi,r14
    710d6ca00ab8:	e8 83 f5 ff e7       	call   0x710d54a00040
    710d6ca00abd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00ac4:	00 
    710d6ca00ac5:	0f 84 4e ff ff e7    	je     0x710d54a00a19
    710d6ca00acb:	e9 6b ff ff ff       	jmp    0x710d6ca00a3b
    710d6ca00ad0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    710d6ca00ad7:	38 00 01 00 
    710d6ca00adb:	b8 38 00 01 00       	mov    eax,0x10038
    710d6ca00ae0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca00ae7:	04 00 00 00 
    710d6ca00aeb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca00af2:	0e 00 00 00 
    710d6ca00af6:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca00af9:	be 38 00 01 00       	mov    esi,0x10038
    710d6ca00afe:	4c 89 ef             	mov    rdi,r13
    710d6ca00b01:	e8 5a f6 ff e7       	call   0x710d54a00160
    710d6ca00b06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00b0d:	00 
    710d6ca00b0e:	0f 84 39 ff ff e7    	je     0x710d54a00a4d
    710d6ca00b14:	e9 22 ff ff ff       	jmp    0x710d6ca00a3b
    710d6ca00b19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00b20:	3c 00 01 00 
    710d6ca00b24:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00b2b:	02 00 00 00 
    710d6ca00b2f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00b36:	0f 00 00 00 
    710d6ca00b3a:	ba 3c 00 01 00       	mov    edx,0x1003c
    710d6ca00b3f:	4c 89 ef             	mov    rdi,r13
    710d6ca00b42:	4c 89 f6             	mov    rsi,r14
    710d6ca00b45:	89 d9                	mov    ecx,ebx
    710d6ca00b47:	45 31 c0             	xor    r8d,r8d
    710d6ca00b4a:	e8 31 f5 ff e7       	call   0x710d54a00080
    710d6ca00b4f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00b56:	02 00 00 00 
    710d6ca00b5a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00b61:	0f 00 00 00 
    710d6ca00b65:	58                   	pop    rax
    710d6ca00b66:	e9 72 00 00 e8       	jmp    0x710d54a00bdd
    710d6ca00b6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00b72:	3c 00 01 00 
    710d6ca00b76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00b7d:	02 00 00 00 
    710d6ca00b81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00b88:	0f 00 00 00 
    710d6ca00b8c:	4c 89 f7             	mov    rdi,r14
    710d6ca00b8f:	89 de                	mov    esi,ebx
    710d6ca00b91:	e8 aa f4 ff e7       	call   0x710d54a00040
    710d6ca00b96:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00b9d:	00 
    710d6ca00b9e:	0f 84 df fe ff e7    	je     0x710d54a00a83
    710d6ca00ba4:	eb a9                	jmp    0x710d6ca00b4f
    710d6ca00ba6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00bad:	3c 00 01 00 
    710d6ca00bb1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00bb8:	02 00 00 00 
    710d6ca00bbc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00bc3:	0f 00 00 00 
    710d6ca00bc7:	4c 89 f7             	mov    rdi,r14
    710d6ca00bca:	e8 71 f4 ff e7       	call   0x710d54a00040
    710d6ca00bcf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00bd6:	00 
    710d6ca00bd7:	0f 84 c9 fe ff e7    	je     0x710d54a00aa6
    710d6ca00bdd:	e9 6d ff ff ff       	jmp    0x710d6ca00b4f
    710d6ca00be2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00be9:	3c 00 01 00 
    710d6ca00bed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00bf4:	02 00 00 00 
    710d6ca00bf8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00bff:	0f 00 00 00 
    710d6ca00c03:	4c 89 f7             	mov    rdi,r14
    710d6ca00c06:	e8 35 f4 ff e7       	call   0x710d54a00040
    710d6ca00c0b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00c12:	00 
    710d6ca00c13:	0f 84 b0 fe ff e7    	je     0x710d54a00ac9
    710d6ca00c19:	e9 31 ff ff ff       	jmp    0x710d6ca00b4f
    710d6ca00c1e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00c25:	3c 00 01 00 
    710d6ca00c29:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00c30:	02 00 00 00 
    710d6ca00c34:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00c3b:	0f 00 00 00 
    710d6ca00c3f:	4c 89 f7             	mov    rdi,r14
    710d6ca00c42:	e8 f9 f3 ff e7       	call   0x710d54a00040
    710d6ca00c47:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00c4e:	00 
    710d6ca00c4f:	0f 84 97 fe ff e7    	je     0x710d54a00aec
    710d6ca00c55:	e9 f5 fe ff ff       	jmp    0x710d6ca00b4f
    710d6ca00c5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00c61:	3c 00 01 00 
    710d6ca00c65:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00c6c:	02 00 00 00 
    710d6ca00c70:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00c77:	0f 00 00 00 
    710d6ca00c7b:	4c 89 f7             	mov    rdi,r14
    710d6ca00c7e:	e8 bd f3 ff e7       	call   0x710d54a00040
    710d6ca00c83:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00c8a:	00 
    710d6ca00c8b:	0f 84 7e fe ff e7    	je     0x710d54a00b0f
    710d6ca00c91:	e9 b9 fe ff ff       	jmp    0x710d6ca00b4f
    710d6ca00c96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00c9d:	3c 00 01 00 
    710d6ca00ca1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00ca8:	02 00 00 00 
    710d6ca00cac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00cb3:	0f 00 00 00 
    710d6ca00cb7:	4c 89 f7             	mov    rdi,r14
    710d6ca00cba:	e8 81 f3 ff e7       	call   0x710d54a00040
    710d6ca00cbf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00cc6:	00 
    710d6ca00cc7:	0f 84 65 fe ff e7    	je     0x710d54a00b32
    710d6ca00ccd:	e9 7d fe ff ff       	jmp    0x710d6ca00b4f
    710d6ca00cd2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00cd9:	3c 00 01 00 
    710d6ca00cdd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00ce4:	02 00 00 00 
    710d6ca00ce8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00cef:	0f 00 00 00 
    710d6ca00cf3:	4c 89 f7             	mov    rdi,r14
    710d6ca00cf6:	e8 45 f3 ff e7       	call   0x710d54a00040
    710d6ca00cfb:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00d02:	00 
    710d6ca00d03:	0f 84 4e fe ff e7    	je     0x710d54a00b57
    710d6ca00d09:	e9 41 fe ff ff       	jmp    0x710d6ca00b4f
    710d6ca00d0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    710d6ca00d15:	3c 00 01 00 
    710d6ca00d19:	b8 3c 00 01 00       	mov    eax,0x1003c
    710d6ca00d1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00d25:	02 00 00 00 
    710d6ca00d29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca00d30:	0f 00 00 00 
    710d6ca00d34:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca00d37:	be 3c 00 01 00       	mov    esi,0x1003c
    710d6ca00d3c:	4c 89 ef             	mov    rdi,r13
    710d6ca00d3f:	e8 1c f4 ff e7       	call   0x710d54a00160
    710d6ca00d44:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca00d4b:	00 
    710d6ca00d4c:	0f 84 32 fe ff e7    	je     0x710d54a00b84
    710d6ca00d52:	e9 f8 fd ff ff       	jmp    0x710d6ca00b4f
    710d6ca00d57:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    710d6ca00d5e:	3e 00 01 00 
    710d6ca00d62:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00d69:	02 00 00 00 
    710d6ca00d6d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca00d74:	10 00 00 00 
    710d6ca00d78:	4c 89 ef             	mov    rdi,r13
    710d6ca00d7b:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca00d80:	4c 89 f2             	mov    rdx,r14
    710d6ca00d83:	e8 08 f3 ff e7       	call   0x710d54a00090
    710d6ca00d88:	e9 39 fe ff e7       	jmp    0x710d54a00bc6
    710d6ca00d8d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca00d94:	02 00 00 00 
    710d6ca00d98:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca00d9f:	10 00 00 00 
    710d6ca00da3:	be 3e 00 01 00       	mov    esi,0x1003e
    710d6ca00da8:	ba 3e 00 01 00       	mov    edx,0x1003e
    710d6ca00dad:	4c 89 ef             	mov    rdi,r13
    710d6ca00db0:	e8 ab f3 ff e7       	call   0x710d54a00160
    710d6ca00db5:	e9 0c fe ff e7       	jmp    0x710d54a00bc6
    710d6ca00dba:	c2 08 00             	ret    0x8
