
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66078-0-124302470965717.bin:     file format binary


Disassembly of section .data:

0000710d6ca069d5 <.data>:
    710d6ca069d5:	c6 86 65 01 00 00 01 	mov    BYTE PTR [rsi+0x165],0x1
    710d6ca069dc:	c6 86 28 01 00 00 00 	mov    BYTE PTR [rsi+0x128],0x0
    710d6ca069e3:	48 83 c4 78          	add    rsp,0x78
    710d6ca069e7:	c2 08 00             	ret    0x8
