
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66578-0-124302470969531.bin:     file format binary


Disassembly of section .data:

0000710d6ca078bb <.data>:
    710d6ca078bb:	41 c7 00 00 00 00 00 	mov    DWORD PTR [r8],0x0
    710d6ca078c2:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    710d6ca078c6:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    710d6ca078ca:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d6ca078cf:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    710d6ca078d3:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d6ca078d7:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d6ca078dc:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    710d6ca078e0:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    710d6ca078e7:	00 00 00 00 
    710d6ca078eb:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10368
    710d6ca078f2:	68 03 01 00 
    710d6ca078f6:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d6ca078fa:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    710d6ca07901:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d6ca07905:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    710d6ca0790c:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d6ca07913:	00 00 00 00 
    710d6ca07917:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d6ca0791e:	00 00 00 00 
    710d6ca07922:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d6ca07926:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d6ca0792d:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d6ca07934:	02 00 00 00 
    710d6ca07938:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    710d6ca0793f:	01 
    710d6ca07940:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xa
    710d6ca07947:	0a 00 00 00 
    710d6ca0794b:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d6ca07952:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d6ca07959:	c2 08 00             	ret    0x8
    710d6ca0795c:	41 c6 80 65 01 00 00 	mov    BYTE PTR [r8+0x165],0x1
    710d6ca07963:	01 
    710d6ca07964:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d6ca0796b:	00 
    710d6ca0796c:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d6ca07973:	c2 08 00             	ret    0x8
    710d6ca07976:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d6ca0797a:	41 89 00             	mov    DWORD PTR [r8],eax
    710d6ca0797d:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    710d6ca07981:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    710d6ca07985:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    710d6ca0798a:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    710d6ca0798e:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    710d6ca07992:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d6ca07997:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    710d6ca0799b:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    710d6ca079a2:	00 00 00 00 
    710d6ca079a6:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10422
    710d6ca079ad:	22 04 01 00 
    710d6ca079b1:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    710d6ca079b5:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    710d6ca079bc:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    710d6ca079c0:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    710d6ca079c7:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    710d6ca079ce:	00 00 00 00 
    710d6ca079d2:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    710d6ca079d9:	00 00 00 00 
    710d6ca079dd:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d6ca079e1:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    710d6ca079e8:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    710d6ca079ef:	02 00 00 00 
    710d6ca079f3:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    710d6ca079fa:	00 
    710d6ca079fb:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    710d6ca07a02:	08 00 00 00 
    710d6ca07a06:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    710d6ca07a0d:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d6ca07a14:	56 00 00 
    710d6ca07a17:	4c 89 c7             	mov    rdi,r8
    710d6ca07a1a:	4c 89 c5             	mov    rbp,r8
    710d6ca07a1d:	44 89 d3             	mov    ebx,r10d
    710d6ca07a20:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    710d6ca07a25:	ff d0                	call   rax
    710d6ca07a27:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    710d6ca07a2c:	41 89 da             	mov    r10d,ebx
    710d6ca07a2f:	49 89 e8             	mov    r8,rbp
    710d6ca07a32:	0f b6 bd 28 01 00 00 	movzx  edi,BYTE PTR [rbp+0x128]
    710d6ca07a39:	40 84 ff             	test   dil,dil
    710d6ca07a3c:	0f 84 4b 00 00 e8    	je     0x710d54a07a8d
    710d6ca07a42:	e9 bb 04 00 e8       	jmp    0x710d54a07f02
