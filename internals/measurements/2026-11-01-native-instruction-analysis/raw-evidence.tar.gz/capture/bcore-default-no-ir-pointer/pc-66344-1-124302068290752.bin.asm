
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66344-1-124302068290752.bin:     file format binary


Disassembly of section .data:

0000710d54a014c0 <.data>:
    710d54a014c0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a014c7:	8b 88 0c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10000c]
    710d54a014cd:	ff c1                	inc    ecx
    710d54a014cf:	89 88 0c 00 10 00    	mov    DWORD PTR [rax+0x10000c],ecx
    710d54a014d5:	81 f9 c1 c5 00 00    	cmp    ecx,0xc5c1
    710d54a014db:	0f 84 ff 07 00 18    	je     0x710d6ca01ce0
    710d54a014e1:	50                   	push   rax
    710d54a014e2:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a014e6:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a014e9:	f6 c3 03             	test   bl,0x3
    710d54a014ec:	0f 85 1a 08 00 18    	jne    0x710d6ca01d0c
    710d54a014f2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a014f9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a01500:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    710d54a01504:	89 c8                	mov    eax,ecx
    710d54a01506:	c1 e8 0c             	shr    eax,0xc
    710d54a01509:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a0150e:	48 85 c0             	test   rax,rax
    710d54a01511:	0f 84 48 08 00 18    	je     0x710d6ca01d5f
    710d54a01517:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0151d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01520:	8d 73 f8             	lea    esi,[rbx-0x8]
    710d54a01523:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    710d54a01527:	89 f0                	mov    eax,esi
    710d54a01529:	c1 e8 0c             	shr    eax,0xc
    710d54a0152c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01531:	48 85 c0             	test   rax,rax
    710d54a01534:	0f 84 60 08 00 18    	je     0x710d6ca01d9a
    710d54a0153a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01540:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a01543:	8d 73 f4             	lea    esi,[rbx-0xc]
    710d54a01546:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    710d54a0154a:	89 f0                	mov    eax,esi
    710d54a0154c:	c1 e8 0c             	shr    eax,0xc
    710d54a0154f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01554:	48 85 c0             	test   rax,rax
    710d54a01557:	0f 84 79 08 00 18    	je     0x710d6ca01dd6
    710d54a0155d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01563:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a01566:	8d 73 f0             	lea    esi,[rbx-0x10]
    710d54a01569:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    710d54a0156d:	89 f0                	mov    eax,esi
    710d54a0156f:	c1 e8 0c             	shr    eax,0xc
    710d54a01572:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01577:	48 85 c0             	test   rax,rax
    710d54a0157a:	0f 84 92 08 00 18    	je     0x710d6ca01e12
    710d54a01580:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01586:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    710d54a01589:	83 c3 ec             	add    ebx,0xffffffec
    710d54a0158c:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    710d54a01590:	89 d8                	mov    eax,ebx
    710d54a01592:	c1 e8 0c             	shr    eax,0xc
    710d54a01595:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a0159a:	48 85 c0             	test   rax,rax
    710d54a0159d:	0f 84 ab 08 00 18    	je     0x710d6ca01e4e
    710d54a015a3:	89 d9                	mov    ecx,ebx
    710d54a015a5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a015ab:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a015ae:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a015b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10328
    710d54a015b9:	28 03 01 00 
    710d54a015bd:	0f 84 c9 08 00 18    	je     0x710d6ca01e8c
    710d54a015c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10328
    710d54a015ca:	28 03 01 00 
    710d54a015ce:	0f 84 b8 08 00 18    	je     0x710d6ca01e8c
    710d54a015d4:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a015d8:	0f 85 f0 08 00 18    	jne    0x710d6ca01ece
    710d54a015de:	58                   	pop    rax
    710d54a015df:	e9 0f 00 00 00       	jmp    0x710d54a015f3
    710d54a015e4:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a015eb:	00 
    710d54a015ec:	74 f0                	je     0x710d54a015de
    710d54a015ee:	e9 50 07 00 18       	jmp    0x710d6ca01d43
    710d54a015f3:	50                   	push   rax
    710d54a015f4:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a015f8:	8d 4b fc             	lea    ecx,[rbx-0x4]
    710d54a015fb:	f6 c3 03             	test   bl,0x3
    710d54a015fe:	0f 85 fc 08 00 18    	jne    0x710d6ca01f00
    710d54a01604:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    710d54a0160b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a01612:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    710d54a01616:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    710d54a0161d:	89 c8                	mov    eax,ecx
    710d54a0161f:	c1 e8 0c             	shr    eax,0xc
    710d54a01622:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01627:	48 85 c0             	test   rax,rax
    710d54a0162a:	0f 84 23 09 00 18    	je     0x710d6ca01f53
    710d54a01630:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01636:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01639:	83 c3 f8             	add    ebx,0xfffffff8
    710d54a0163c:	89 d8                	mov    eax,ebx
    710d54a0163e:	c1 e8 0c             	shr    eax,0xc
    710d54a01641:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01646:	48 85 c0             	test   rax,rax
    710d54a01649:	0f 84 3f 09 00 18    	je     0x710d6ca01f8e
    710d54a0164f:	89 d9                	mov    ecx,ebx
    710d54a01651:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01657:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    710d54a0165b:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    710d54a0165f:	b8 00 00 00 00       	mov    eax,0x0
    710d54a01664:	29 c3                	sub    ebx,eax
    710d54a01666:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    710d54a0166a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1032a
    710d54a01671:	2a 03 01 00 
    710d54a01675:	0f 84 54 09 00 18    	je     0x710d6ca01fcf
    710d54a0167b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032a
    710d54a01682:	2a 03 01 00 
    710d54a01686:	0f 84 43 09 00 18    	je     0x710d6ca01fcf
    710d54a0168c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d54a01690:	0f 85 7b 09 00 18    	jne    0x710d6ca02011
    710d54a01696:	58                   	pop    rax
    710d54a01697:	e9 0f 00 00 00       	jmp    0x710d54a016ab
    710d54a0169c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a016a3:	00 
    710d54a016a4:	74 f0                	je     0x710d54a01696
    710d54a016a6:	e9 8c 08 00 18       	jmp    0x710d6ca01f37
    710d54a016ab:	50                   	push   rax
    710d54a016ac:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a016b0:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a016b7:	31 d2                	xor    edx,edx
    710d54a016b9:	83 f8 05             	cmp    eax,0x5
    710d54a016bc:	0f 92 c2             	setb   dl
    710d54a016bf:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a016c6:	31 d2                	xor    edx,edx
    710d54a016c8:	31 f6                	xor    esi,esi
    710d54a016ca:	31 ff                	xor    edi,edi
    710d54a016cc:	83 f8 04             	cmp    eax,0x4
    710d54a016cf:	0f 94 c2             	sete   dl
    710d54a016d2:	40 0f 92 c6          	setb   sil
    710d54a016d6:	40 0f 93 c7          	setae  dil
    710d54a016da:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a016e1:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    710d54a016e8:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a016ef:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a016f6:	81 f9 2e 03 01 00    	cmp    ecx,0x1032e
    710d54a016fc:	0f 84 41 09 00 18    	je     0x710d6ca02043
    710d54a01702:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032e
    710d54a01709:	2e 03 01 00 
    710d54a0170d:	0f 84 30 09 00 18    	je     0x710d6ca02043
    710d54a01713:	58                   	pop    rax
    710d54a01714:	50                   	push   rax
    710d54a01715:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a0171c:	00 
    710d54a0171d:	74 28                	je     0x710d54a01747
    710d54a0171f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    710d54a01726:	30 03 01 00 
    710d54a0172a:	0f 84 73 09 00 18    	je     0x710d6ca020a3
    710d54a01730:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    710d54a01737:	30 03 01 00 
    710d54a0173b:	0f 84 62 09 00 18    	je     0x710d6ca020a3
    710d54a01741:	58                   	pop    rax
    710d54a01742:	e9 55 00 00 00       	jmp    0x710d54a0179c
    710d54a01747:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a0174e:	01 
    710d54a0174f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    710d54a01756:	30 03 01 00 
    710d54a0175a:	0f 84 8c 09 00 18    	je     0x710d6ca020ec
    710d54a01760:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    710d54a01767:	30 03 01 00 
    710d54a0176b:	0f 84 7b 09 00 18    	je     0x710d6ca020ec
    710d54a01771:	b8 30 03 01 00       	mov    eax,0x10330
    710d54a01776:	83 c0 40             	add    eax,0x40
    710d54a01779:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a01780:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a01787:	02 00 00 00 
    710d54a0178b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d54a01792:	04 00 00 00 
    710d54a01796:	58                   	pop    rax
    710d54a01797:	e9 d3 08 00 00       	jmp    0x710d54a0206f
    710d54a0179c:	50                   	push   rax
    710d54a0179d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a017a1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a017a8:	31 d2                	xor    edx,edx
    710d54a017aa:	85 c0                	test   eax,eax
    710d54a017ac:	0f 94 c2             	sete   dl
    710d54a017af:	c1 e8 1f             	shr    eax,0x1f
    710d54a017b2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a017b9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a017c0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a017c7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    710d54a017ce:	00 00 00 
    710d54a017d1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    710d54a017d8:	81 f9 32 03 01 00    	cmp    ecx,0x10332
    710d54a017de:	0f 84 44 09 00 18    	je     0x710d6ca02128
    710d54a017e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10332
    710d54a017eb:	32 03 01 00 
    710d54a017ef:	0f 84 33 09 00 18    	je     0x710d6ca02128
    710d54a017f5:	58                   	pop    rax
    710d54a017f6:	50                   	push   rax
    710d54a017f7:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a017fe:	00 
    710d54a017ff:	74 55                	je     0x710d54a01856
    710d54a01801:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a01808:	01 
    710d54a01809:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    710d54a01810:	34 03 01 00 
    710d54a01814:	0f 84 6e 09 00 18    	je     0x710d6ca02188
    710d54a0181a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    710d54a01821:	34 03 01 00 
    710d54a01825:	0f 84 5d 09 00 18    	je     0x710d6ca02188
    710d54a0182b:	b8 34 03 01 00       	mov    eax,0x10334
    710d54a01830:	83 c0 3c             	add    eax,0x3c
    710d54a01833:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a0183a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a01841:	02 00 00 00 
    710d54a01845:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d54a0184c:	06 00 00 00 
    710d54a01850:	58                   	pop    rax
    710d54a01851:	e9 19 08 00 00       	jmp    0x710d54a0206f
    710d54a01856:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    710d54a0185d:	34 03 01 00 
    710d54a01861:	0f 84 5d 09 00 18    	je     0x710d6ca021c4
    710d54a01867:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    710d54a0186e:	34 03 01 00 
    710d54a01872:	0f 84 4c 09 00 18    	je     0x710d6ca021c4
    710d54a01878:	58                   	pop    rax
    710d54a01879:	50                   	push   rax
    710d54a0187a:	41 c7 45 0c 09 3d 00 	mov    DWORD PTR [r13+0xc],0x3d09
    710d54a01881:	00 
    710d54a01882:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10336
    710d54a01889:	36 03 01 00 
    710d54a0188d:	0f 84 7a 09 00 18    	je     0x710d6ca0220d
    710d54a01893:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10336
    710d54a0189a:	36 03 01 00 
    710d54a0189e:	0f 84 69 09 00 18    	je     0x710d6ca0220d
    710d54a018a4:	58                   	pop    rax
    710d54a018a5:	50                   	push   rax
    710d54a018a6:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    710d54a018aa:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a018b1:	31 d2                	xor    edx,edx
    710d54a018b3:	c1 e0 0b             	shl    eax,0xb
    710d54a018b6:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    710d54a018ba:	0f 94 c2             	sete   dl
    710d54a018bd:	c1 e8 1f             	shr    eax,0x1f
    710d54a018c0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a018c7:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a018ce:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a018d5:	00 00 00 00 
    710d54a018d9:	81 f9 3a 03 01 00    	cmp    ecx,0x1033a
    710d54a018df:	0f 84 88 09 00 18    	je     0x710d6ca0226d
    710d54a018e5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033a
    710d54a018ec:	3a 03 01 00 
    710d54a018f0:	0f 84 77 09 00 18    	je     0x710d6ca0226d
    710d54a018f6:	58                   	pop    rax
    710d54a018f7:	50                   	push   rax
    710d54a018f8:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    710d54a018fc:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    710d54a01900:	31 d2                	xor    edx,edx
    710d54a01902:	31 f6                	xor    esi,esi
    710d54a01904:	31 ff                	xor    edi,edi
    710d54a01906:	31 db                	xor    ebx,ebx
    710d54a01908:	39 c8                	cmp    eax,ecx
    710d54a0190a:	0f 96 c2             	setbe  dl
    710d54a0190d:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a01914:	40 0f 94 c6          	sete   sil
    710d54a01918:	40 0f 92 c7          	setb   dil
    710d54a0191c:	0f 93 c3             	setae  bl
    710d54a0191f:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a01926:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a0192d:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    710d54a01934:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    710d54a0193b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033c
    710d54a01942:	3c 03 01 00 
    710d54a01946:	0f 84 81 09 00 18    	je     0x710d6ca022cd
    710d54a0194c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033c
    710d54a01953:	3c 03 01 00 
    710d54a01957:	0f 84 70 09 00 18    	je     0x710d6ca022cd
    710d54a0195d:	58                   	pop    rax
    710d54a0195e:	50                   	push   rax
    710d54a0195f:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a01966:	00 
    710d54a01967:	74 28                	je     0x710d54a01991
    710d54a01969:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    710d54a01970:	3e 03 01 00 
    710d54a01974:	0f 84 b3 09 00 18    	je     0x710d6ca0232d
    710d54a0197a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    710d54a01981:	3e 03 01 00 
    710d54a01985:	0f 84 a2 09 00 18    	je     0x710d6ca0232d
    710d54a0198b:	58                   	pop    rax
    710d54a0198c:	e9 55 00 00 00       	jmp    0x710d54a019e6
    710d54a01991:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a01998:	01 
    710d54a01999:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    710d54a019a0:	3e 03 01 00 
    710d54a019a4:	0f 84 cc 09 00 18    	je     0x710d6ca02376
    710d54a019aa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    710d54a019b1:	3e 03 01 00 
    710d54a019b5:	0f 84 bb 09 00 18    	je     0x710d6ca02376
    710d54a019bb:	b8 3e 03 01 00       	mov    eax,0x1033e
    710d54a019c0:	83 c0 32             	add    eax,0x32
    710d54a019c3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a019ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a019d1:	02 00 00 00 
    710d54a019d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d54a019dc:	0a 00 00 00 
    710d54a019e0:	58                   	pop    rax
    710d54a019e1:	e9 89 06 00 00       	jmp    0x710d54a0206f
    710d54a019e6:	50                   	push   rax
    710d54a019e7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a019ec:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a019f1:	09 c1                	or     ecx,eax
    710d54a019f3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a019f7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10340
    710d54a019fe:	40 03 01 00 
    710d54a01a02:	0f 84 aa 09 00 18    	je     0x710d6ca023b2
    710d54a01a08:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10340
    710d54a01a0f:	40 03 01 00 
    710d54a01a13:	0f 84 99 09 00 18    	je     0x710d6ca023b2
    710d54a01a19:	58                   	pop    rax
    710d54a01a1a:	50                   	push   rax
    710d54a01a1b:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a01a20:	c1 e0 10             	shl    eax,0x10
    710d54a01a23:	b9 f0 12 00 00       	mov    ecx,0x12f0
    710d54a01a28:	09 c1                	or     ecx,eax
    710d54a01a2a:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a01a2e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10344
    710d54a01a35:	44 03 01 00 
    710d54a01a39:	0f 84 d3 09 00 18    	je     0x710d6ca02412
    710d54a01a3f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10344
    710d54a01a46:	44 03 01 00 
    710d54a01a4a:	0f 84 c2 09 00 18    	je     0x710d6ca02412
    710d54a01a50:	58                   	pop    rax
    710d54a01a51:	50                   	push   rax
    710d54a01a52:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a01a56:	f6 c1 03             	test   cl,0x3
    710d54a01a59:	0f 85 13 0a 00 18    	jne    0x710d6ca02472
    710d54a01a5f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a01a66:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a01a6a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01a71:	48 89 ce             	mov    rsi,rcx
    710d54a01a74:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a01a78:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a01a7c:	48 85 c0             	test   rax,rax
    710d54a01a7f:	0f 84 40 0a 00 18    	je     0x710d6ca024c5
    710d54a01a85:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01a8b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01a8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10348
    710d54a01a95:	48 03 01 00 
    710d54a01a99:	0f 84 61 0a 00 18    	je     0x710d6ca02500
    710d54a01a9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10348
    710d54a01aa6:	48 03 01 00 
    710d54a01aaa:	0f 84 50 0a 00 18    	je     0x710d6ca02500
    710d54a01ab0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a01ab3:	0f 85 88 0a 00 18    	jne    0x710d6ca02541
    710d54a01ab9:	58                   	pop    rax
    710d54a01aba:	e9 0f 00 00 00       	jmp    0x710d54a01ace
    710d54a01abf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a01ac6:	00 
    710d54a01ac7:	74 f0                	je     0x710d54a01ab9
    710d54a01ac9:	e9 db 09 00 18       	jmp    0x710d6ca024a9
    710d54a01ace:	50                   	push   rax
    710d54a01acf:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a01ad4:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a01ad9:	09 c1                	or     ecx,eax
    710d54a01adb:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a01adf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034a
    710d54a01ae6:	4a 03 01 00 
    710d54a01aea:	0f 84 83 0a 00 18    	je     0x710d6ca02573
    710d54a01af0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034a
    710d54a01af7:	4a 03 01 00 
    710d54a01afb:	0f 84 72 0a 00 18    	je     0x710d6ca02573
    710d54a01b01:	58                   	pop    rax
    710d54a01b02:	50                   	push   rax
    710d54a01b03:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a01b08:	c1 e0 10             	shl    eax,0x10
    710d54a01b0b:	b9 f4 12 00 00       	mov    ecx,0x12f4
    710d54a01b10:	09 c1                	or     ecx,eax
    710d54a01b12:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a01b16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034e
    710d54a01b1d:	4e 03 01 00 
    710d54a01b21:	0f 84 ac 0a 00 18    	je     0x710d6ca025d3
    710d54a01b27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034e
    710d54a01b2e:	4e 03 01 00 
    710d54a01b32:	0f 84 9b 0a 00 18    	je     0x710d6ca025d3
    710d54a01b38:	58                   	pop    rax
    710d54a01b39:	50                   	push   rax
    710d54a01b3a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a01b3e:	f6 c1 03             	test   cl,0x3
    710d54a01b41:	0f 85 ec 0a 00 18    	jne    0x710d6ca02633
    710d54a01b47:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a01b4e:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    710d54a01b52:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01b59:	48 89 ce             	mov    rsi,rcx
    710d54a01b5c:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a01b60:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a01b64:	48 85 c0             	test   rax,rax
    710d54a01b67:	0f 84 19 0b 00 18    	je     0x710d6ca02686
    710d54a01b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01b73:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01b76:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10352
    710d54a01b7d:	52 03 01 00 
    710d54a01b81:	0f 84 3a 0b 00 18    	je     0x710d6ca026c1
    710d54a01b87:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10352
    710d54a01b8e:	52 03 01 00 
    710d54a01b92:	0f 84 29 0b 00 18    	je     0x710d6ca026c1
    710d54a01b98:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a01b9b:	0f 85 61 0b 00 18    	jne    0x710d6ca02702
    710d54a01ba1:	58                   	pop    rax
    710d54a01ba2:	e9 0f 00 00 00       	jmp    0x710d54a01bb6
    710d54a01ba7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a01bae:	00 
    710d54a01baf:	74 f0                	je     0x710d54a01ba1
    710d54a01bb1:	e9 b4 0a 00 18       	jmp    0x710d6ca0266a
    710d54a01bb6:	50                   	push   rax
    710d54a01bb7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a01bbc:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a01bc1:	09 c1                	or     ecx,eax
    710d54a01bc3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a01bc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10354
    710d54a01bce:	54 03 01 00 
    710d54a01bd2:	0f 84 5c 0b 00 18    	je     0x710d6ca02734
    710d54a01bd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10354
    710d54a01bdf:	54 03 01 00 
    710d54a01be3:	0f 84 4b 0b 00 18    	je     0x710d6ca02734
    710d54a01be9:	58                   	pop    rax
    710d54a01bea:	50                   	push   rax
    710d54a01beb:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a01bf0:	c1 e0 10             	shl    eax,0x10
    710d54a01bf3:	b9 f8 12 00 00       	mov    ecx,0x12f8
    710d54a01bf8:	09 c1                	or     ecx,eax
    710d54a01bfa:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a01bfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10358
    710d54a01c05:	58 03 01 00 
    710d54a01c09:	0f 84 85 0b 00 18    	je     0x710d6ca02794
    710d54a01c0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10358
    710d54a01c16:	58 03 01 00 
    710d54a01c1a:	0f 84 74 0b 00 18    	je     0x710d6ca02794
    710d54a01c20:	58                   	pop    rax
    710d54a01c21:	50                   	push   rax
    710d54a01c22:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a01c26:	f6 c1 03             	test   cl,0x3
    710d54a01c29:	0f 85 c5 0b 00 18    	jne    0x710d6ca027f4
    710d54a01c2f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a01c36:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    710d54a01c3a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01c41:	48 89 ce             	mov    rsi,rcx
    710d54a01c44:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a01c48:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a01c4c:	48 85 c0             	test   rax,rax
    710d54a01c4f:	0f 84 f2 0b 00 18    	je     0x710d6ca02847
    710d54a01c55:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01c5b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01c5e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1035c
    710d54a01c65:	5c 03 01 00 
    710d54a01c69:	0f 84 13 0c 00 18    	je     0x710d6ca02882
    710d54a01c6f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035c
    710d54a01c76:	5c 03 01 00 
    710d54a01c7a:	0f 84 02 0c 00 18    	je     0x710d6ca02882
    710d54a01c80:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a01c83:	0f 85 3a 0c 00 18    	jne    0x710d6ca028c3
    710d54a01c89:	58                   	pop    rax
    710d54a01c8a:	e9 0f 00 00 00       	jmp    0x710d54a01c9e
    710d54a01c8f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a01c96:	00 
    710d54a01c97:	74 f0                	je     0x710d54a01c89
    710d54a01c99:	e9 8d 0b 00 18       	jmp    0x710d6ca0282b
    710d54a01c9e:	50                   	push   rax
    710d54a01c9f:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a01ca3:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a01caa:	31 d2                	xor    edx,edx
    710d54a01cac:	89 c6                	mov    esi,eax
    710d54a01cae:	83 c6 fe             	add    esi,0xfffffffe
    710d54a01cb1:	0f 94 c2             	sete   dl
    710d54a01cb4:	09 c6                	or     esi,eax
    710d54a01cb6:	c1 ee 1f             	shr    esi,0x1f
    710d54a01cb9:	31 ff                	xor    edi,edi
    710d54a01cbb:	83 f8 02             	cmp    eax,0x2
    710d54a01cbe:	40 0f 93 c7          	setae  dil
    710d54a01cc2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a01cc9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a01cd0:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    710d54a01cd7:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a01cde:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a01ce5:	81 f9 5e 03 01 00    	cmp    ecx,0x1035e
    710d54a01ceb:	0f 84 04 0c 00 18    	je     0x710d6ca028f5
    710d54a01cf1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035e
    710d54a01cf8:	5e 03 01 00 
    710d54a01cfc:	0f 84 f3 0b 00 18    	je     0x710d6ca028f5
    710d54a01d02:	58                   	pop    rax
    710d54a01d03:	50                   	push   rax
    710d54a01d04:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a01d0b:	00 
    710d54a01d0c:	74 55                	je     0x710d54a01d63
    710d54a01d0e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a01d15:	01 
    710d54a01d16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    710d54a01d1d:	60 03 01 00 
    710d54a01d21:	0f 84 2e 0c 00 18    	je     0x710d6ca02955
    710d54a01d27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    710d54a01d2e:	60 03 01 00 
    710d54a01d32:	0f 84 1d 0c 00 18    	je     0x710d6ca02955
    710d54a01d38:	b8 60 03 01 00       	mov    eax,0x10360
    710d54a01d3d:	83 c0 1a             	add    eax,0x1a
    710d54a01d40:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a01d47:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a01d4e:	02 00 00 00 
    710d54a01d52:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    710d54a01d59:	15 00 00 00 
    710d54a01d5d:	58                   	pop    rax
    710d54a01d5e:	e9 0c 03 00 00       	jmp    0x710d54a0206f
    710d54a01d63:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    710d54a01d6a:	60 03 01 00 
    710d54a01d6e:	0f 84 1d 0c 00 18    	je     0x710d6ca02991
    710d54a01d74:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    710d54a01d7b:	60 03 01 00 
    710d54a01d7f:	0f 84 0c 0c 00 18    	je     0x710d6ca02991
    710d54a01d85:	58                   	pop    rax
    710d54a01d86:	50                   	push   rax
    710d54a01d87:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a01d8b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a01d92:	31 d2                	xor    edx,edx
    710d54a01d94:	89 c6                	mov    esi,eax
    710d54a01d96:	83 c6 fd             	add    esi,0xfffffffd
    710d54a01d99:	0f 94 c2             	sete   dl
    710d54a01d9c:	09 c6                	or     esi,eax
    710d54a01d9e:	c1 ee 1f             	shr    esi,0x1f
    710d54a01da1:	31 ff                	xor    edi,edi
    710d54a01da3:	83 f8 03             	cmp    eax,0x3
    710d54a01da6:	40 0f 93 c7          	setae  dil
    710d54a01daa:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a01db1:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a01db8:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    710d54a01dbf:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a01dc6:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a01dcd:	81 f9 62 03 01 00    	cmp    ecx,0x10362
    710d54a01dd3:	0f 84 01 0c 00 18    	je     0x710d6ca029da
    710d54a01dd9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10362
    710d54a01de0:	62 03 01 00 
    710d54a01de4:	0f 84 f0 0b 00 18    	je     0x710d6ca029da
    710d54a01dea:	58                   	pop    rax
    710d54a01deb:	50                   	push   rax
    710d54a01dec:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a01df3:	00 
    710d54a01df4:	74 55                	je     0x710d54a01e4b
    710d54a01df6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a01dfd:	01 
    710d54a01dfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    710d54a01e05:	64 03 01 00 
    710d54a01e09:	0f 84 2b 0c 00 18    	je     0x710d6ca02a3a
    710d54a01e0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    710d54a01e16:	64 03 01 00 
    710d54a01e1a:	0f 84 1a 0c 00 18    	je     0x710d6ca02a3a
    710d54a01e20:	b8 64 03 01 00       	mov    eax,0x10364
    710d54a01e25:	83 c0 40             	add    eax,0x40
    710d54a01e28:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a01e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a01e36:	02 00 00 00 
    710d54a01e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    710d54a01e41:	17 00 00 00 
    710d54a01e45:	58                   	pop    rax
    710d54a01e46:	e9 24 02 00 00       	jmp    0x710d54a0206f
    710d54a01e4b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    710d54a01e52:	64 03 01 00 
    710d54a01e56:	0f 84 1a 0c 00 18    	je     0x710d6ca02a76
    710d54a01e5c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    710d54a01e63:	64 03 01 00 
    710d54a01e67:	0f 84 09 0c 00 18    	je     0x710d6ca02a76
    710d54a01e6d:	58                   	pop    rax
    710d54a01e6e:	50                   	push   rax
    710d54a01e6f:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a01e76:	00 
    710d54a01e77:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10366
    710d54a01e7e:	66 03 01 00 
    710d54a01e82:	0f 84 37 0c 00 18    	je     0x710d6ca02abf
    710d54a01e88:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10366
    710d54a01e8f:	66 03 01 00 
    710d54a01e93:	0f 84 26 0c 00 18    	je     0x710d6ca02abf
    710d54a01e99:	58                   	pop    rax
    710d54a01e9a:	50                   	push   rax
    710d54a01e9b:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a01e9f:	f6 c3 03             	test   bl,0x3
    710d54a01ea2:	0f 85 77 0c 00 18    	jne    0x710d6ca02b1f
    710d54a01ea8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a01eaf:	48 89 d8             	mov    rax,rbx
    710d54a01eb2:	48 c1 e8 0c          	shr    rax,0xc
    710d54a01eb6:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01ebb:	48 85 c0             	test   rax,rax
    710d54a01ebe:	0f 84 ad 0c 00 18    	je     0x710d6ca02b71
    710d54a01ec4:	89 d9                	mov    ecx,ebx
    710d54a01ec6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01ecc:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a01ed0:	89 de                	mov    esi,ebx
    710d54a01ed2:	83 c6 04             	add    esi,0x4
    710d54a01ed5:	89 f0                	mov    eax,esi
    710d54a01ed7:	c1 e8 0c             	shr    eax,0xc
    710d54a01eda:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01edf:	48 85 c0             	test   rax,rax
    710d54a01ee2:	0f 84 c6 0c 00 18    	je     0x710d6ca02bae
    710d54a01ee8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01eee:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a01ef1:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a01ef4:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a01ef8:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a01eff:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a01f03:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    710d54a01f0a:	68 03 01 00 
    710d54a01f0e:	0f 84 d6 0c 00 18    	je     0x710d6ca02bea
    710d54a01f14:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    710d54a01f1b:	68 03 01 00 
    710d54a01f1f:	0f 84 c5 0c 00 18    	je     0x710d6ca02bea
    710d54a01f25:	58                   	pop    rax
    710d54a01f26:	50                   	push   rax
    710d54a01f27:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a01f2b:	f6 c3 03             	test   bl,0x3
    710d54a01f2e:	0f 85 ff 0c 00 18    	jne    0x710d6ca02c33
    710d54a01f34:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a01f3b:	48 89 d8             	mov    rax,rbx
    710d54a01f3e:	48 c1 e8 0c          	shr    rax,0xc
    710d54a01f42:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01f47:	48 85 c0             	test   rax,rax
    710d54a01f4a:	0f 84 35 0d 00 18    	je     0x710d6ca02c85
    710d54a01f50:	89 d9                	mov    ecx,ebx
    710d54a01f52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01f58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a01f5b:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    710d54a01f5f:	8d 73 04             	lea    esi,[rbx+0x4]
    710d54a01f62:	89 f0                	mov    eax,esi
    710d54a01f64:	c1 e8 0c             	shr    eax,0xc
    710d54a01f67:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01f6c:	48 85 c0             	test   rax,rax
    710d54a01f6f:	0f 84 4b 0d 00 18    	je     0x710d6ca02cc0
    710d54a01f75:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01f7b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a01f7e:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a01f82:	8d 73 08             	lea    esi,[rbx+0x8]
    710d54a01f85:	89 f0                	mov    eax,esi
    710d54a01f87:	c1 e8 0c             	shr    eax,0xc
    710d54a01f8a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01f8f:	48 85 c0             	test   rax,rax
    710d54a01f92:	0f 84 64 0d 00 18    	je     0x710d6ca02cfc
    710d54a01f98:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01f9e:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a01fa1:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    710d54a01fa5:	8d 73 0c             	lea    esi,[rbx+0xc]
    710d54a01fa8:	89 f0                	mov    eax,esi
    710d54a01faa:	c1 e8 0c             	shr    eax,0xc
    710d54a01fad:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01fb2:	48 85 c0             	test   rax,rax
    710d54a01fb5:	0f 84 7d 0d 00 18    	je     0x710d6ca02d38
    710d54a01fbb:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01fc1:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a01fc4:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a01fc8:	89 de                	mov    esi,ebx
    710d54a01fca:	83 c6 10             	add    esi,0x10
    710d54a01fcd:	89 f0                	mov    eax,esi
    710d54a01fcf:	c1 e8 0c             	shr    eax,0xc
    710d54a01fd2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a01fd7:	48 85 c0             	test   rax,rax
    710d54a01fda:	0f 84 94 0d 00 18    	je     0x710d6ca02d74
    710d54a01fe0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a01fe6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a01fe9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    710d54a01fed:	8d 43 14             	lea    eax,[rbx+0x14]
    710d54a01ff0:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    710d54a01ff4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    710d54a01ffb:	6c 03 01 00 
    710d54a01fff:	0f 84 ab 0d 00 18    	je     0x710d6ca02db0
    710d54a02005:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    710d54a0200c:	6c 03 01 00 
    710d54a02010:	0f 84 9a 0d 00 18    	je     0x710d6ca02db0
    710d54a02016:	58                   	pop    rax
    710d54a02017:	50                   	push   rax
    710d54a02018:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a0201f:	a8 01                	test   al,0x1
    710d54a02021:	0f 85 d2 0d 00 18    	jne    0x710d6ca02df9
    710d54a02027:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a0202e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a02035:	01 
    710d54a02036:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    710d54a0203d:	6e 03 01 00 
    710d54a02041:	0f 84 e8 0d 00 18    	je     0x710d6ca02e2f
    710d54a02047:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    710d54a0204e:	6e 03 01 00 
    710d54a02052:	0f 84 d7 0d 00 18    	je     0x710d6ca02e2f
    710d54a02058:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a0205f:	02 00 00 00 
    710d54a02063:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    710d54a0206a:	1b 00 00 00 
    710d54a0206e:	58                   	pop    rax
    710d54a0206f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a02076:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a0207d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a02084:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a0208b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a02092:	39 f1                	cmp    ecx,esi
    710d54a02094:	0f 83 c2 0d 00 18    	jae    0x710d6ca02e5c
    710d54a0209a:	81 fa 28 03 01 00    	cmp    edx,0x10328
    710d54a020a0:	75 14                	jne    0x710d54a020b6
    710d54a020a2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a020a9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a020b0:	00 
    710d54a020b1:	e9 0a f4 ff ff       	jmp    0x710d54a014c0
    710d54a020b6:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a020bd:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a020c3:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a020c6:	0f 85 90 0d 00 18    	jne    0x710d6ca02e5c
    710d54a020cc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a020d3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a020da:	00 
    710d54a020db:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a020e0:	ff e0                	jmp    rax
