
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66534-1-124302068295456.bin:     file format binary


Disassembly of section .data:

0000710d54a02720 <.data>:
    710d54a02720:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a02727:	8b 88 18 00 10 00    	mov    ecx,DWORD PTR [rax+0x100018]
    710d54a0272d:	ff c1                	inc    ecx
    710d54a0272f:	89 88 18 00 10 00    	mov    DWORD PTR [rax+0x100018],ecx
    710d54a02735:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0273b:	0f 84 5f 0f 00 18    	je     0x710d6ca036a0
    710d54a02741:	50                   	push   rax
    710d54a02742:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
    710d54a02746:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0274d:	41 0f af 45 08       	imul   eax,DWORD PTR [r13+0x8]
    710d54a02752:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a02756:	81 f9 e6 03 01 00    	cmp    ecx,0x103e6
    710d54a0275c:	0f 84 6a 0f 00 18    	je     0x710d6ca036cc
    710d54a02762:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103e6
    710d54a02769:	e6 03 01 00 
    710d54a0276d:	0f 84 59 0f 00 18    	je     0x710d6ca036cc
    710d54a02773:	58                   	pop    rax
    710d54a02774:	50                   	push   rax
    710d54a02775:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    710d54a02779:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    710d54a0277d:	89 c2                	mov    edx,eax
    710d54a0277f:	c1 ea 1f             	shr    edx,0x1f
    710d54a02782:	89 ce                	mov    esi,ecx
    710d54a02784:	c1 ee 1f             	shr    esi,0x1f
    710d54a02787:	31 ff                	xor    edi,edi
    710d54a02789:	01 c8                	add    eax,ecx
    710d54a0278b:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a0278f:	40 0f 92 c7          	setb   dil
    710d54a02793:	89 c1                	mov    ecx,eax
    710d54a02795:	c1 e9 1f             	shr    ecx,0x1f
    710d54a02798:	31 ce                	xor    esi,ecx
    710d54a0279a:	31 ca                	xor    edx,ecx
    710d54a0279c:	21 f2                	and    edx,esi
    710d54a0279e:	31 f6                	xor    esi,esi
    710d54a027a0:	85 c0                	test   eax,eax
    710d54a027a2:	40 0f 94 c6          	sete   sil
    710d54a027a6:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    710d54a027ad:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    710d54a027b4:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    710d54a027bb:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    710d54a027c2:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    710d54a027c9:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    710d54a027d0:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    710d54a027d7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103e8
    710d54a027de:	e8 03 01 00 
    710d54a027e2:	0f 84 44 0f 00 18    	je     0x710d6ca0372c
    710d54a027e8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103e8
    710d54a027ef:	e8 03 01 00 
    710d54a027f3:	0f 84 33 0f 00 18    	je     0x710d6ca0372c
    710d54a027f9:	58                   	pop    rax
    710d54a027fa:	50                   	push   rax
    710d54a027fb:	41 8b 85 08 00 00 00 	mov    eax,DWORD PTR [r13+0x8]
    710d54a02802:	89 c1                	mov    ecx,eax
    710d54a02804:	c1 e9 08             	shr    ecx,0x8
    710d54a02807:	41 89 8d 00 00 00 00 	mov    DWORD PTR [r13+0x0],ecx
    710d54a0280e:	31 c9                	xor    ecx,ecx
    710d54a02810:	3d 00 01 00 00       	cmp    eax,0x100
    710d54a02815:	0f 92 c1             	setb   cl
    710d54a02818:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    710d54a0281f:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    710d54a02826:	00 00 00 00 
    710d54a0282a:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a02831:	00 00 00 00 
    710d54a02835:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103ea
    710d54a0283c:	ea 03 01 00 
    710d54a02840:	0f 84 46 0f 00 18    	je     0x710d6ca0378c
    710d54a02846:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ea
    710d54a0284d:	ea 03 01 00 
    710d54a02851:	0f 84 35 0f 00 18    	je     0x710d6ca0378c
    710d54a02857:	58                   	pop    rax
    710d54a02858:	50                   	push   rax
    710d54a02859:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    710d54a0285d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02864:	31 d2                	xor    edx,edx
    710d54a02866:	41 23 45 00          	and    eax,DWORD PTR [r13+0x0]
    710d54a0286a:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a0286e:	0f 94 c2             	sete   dl
    710d54a02871:	c1 e8 1f             	shr    eax,0x1f
    710d54a02874:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a0287b:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a02882:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    710d54a02889:	00 00 00 00 
    710d54a0288d:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    710d54a02894:	00 00 00 00 
    710d54a02898:	81 f9 ee 03 01 00    	cmp    ecx,0x103ee
    710d54a0289e:	0f 84 48 0f 00 18    	je     0x710d6ca037ec
    710d54a028a4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ee
    710d54a028ab:	ee 03 01 00 
    710d54a028af:	0f 84 37 0f 00 18    	je     0x710d6ca037ec
    710d54a028b5:	58                   	pop    rax
    710d54a028b6:	50                   	push   rax
    710d54a028b7:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a028bb:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a028c2:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    710d54a028c6:	81 f9 f0 03 01 00    	cmp    ecx,0x103f0
    710d54a028cc:	0f 84 7a 0f 00 18    	je     0x710d6ca0384c
    710d54a028d2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103f0
    710d54a028d9:	f0 03 01 00 
    710d54a028dd:	0f 84 69 0f 00 18    	je     0x710d6ca0384c
    710d54a028e3:	58                   	pop    rax
    710d54a028e4:	50                   	push   rax
    710d54a028e5:	41 8b 4d 50          	mov    ecx,DWORD PTR [r13+0x50]
    710d54a028e9:	f6 c1 03             	test   cl,0x3
    710d54a028ec:	0f 85 ba 0f 00 18    	jne    0x710d6ca038ac
    710d54a028f2:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a028f9:	48 89 ca             	mov    rdx,rcx
    710d54a028fc:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a02900:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a02904:	48 85 c0             	test   rax,rax
    710d54a02907:	0f 84 ef 0f 00 18    	je     0x710d6ca038fc
    710d54a0290d:	89 ca                	mov    edx,ecx
    710d54a0290f:	81 e2 ff 0f 00 00    	and    edx,0xfff
    710d54a02915:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    710d54a02918:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a0291c:	41 8b 45 70          	mov    eax,DWORD PTR [r13+0x70]
    710d54a02920:	41 8b 95 80 00 00 00 	mov    edx,DWORD PTR [r13+0x80]
    710d54a02927:	89 c9                	mov    ecx,ecx
    710d54a02929:	48 83 c1 04          	add    rcx,0x4
    710d54a0292d:	48 01 d0             	add    rax,rdx
    710d54a02930:	89 ce                	mov    esi,ecx
    710d54a02932:	29 d6                	sub    esi,edx
    710d54a02934:	48 89 c2             	mov    rdx,rax
    710d54a02937:	48 31 ca             	xor    rdx,rcx
    710d54a0293a:	48 c1 ea 20          	shr    rdx,0x20
    710d54a0293e:	39 c1                	cmp    ecx,eax
    710d54a02940:	89 f0                	mov    eax,esi
    710d54a02942:	0f 42 c1             	cmovb  eax,ecx
    710d54a02945:	0f 43 f1             	cmovae esi,ecx
    710d54a02948:	48 85 d2             	test   rdx,rdx
    710d54a0294b:	0f 44 f0             	cmove  esi,eax
    710d54a0294e:	41 89 75 50          	mov    DWORD PTR [r13+0x50],esi
    710d54a02952:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103f2
    710d54a02959:	f2 03 01 00 
    710d54a0295d:	0f 84 d7 0f 00 18    	je     0x710d6ca0393a
    710d54a02963:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103f2
    710d54a0296a:	f2 03 01 00 
    710d54a0296e:	0f 84 c6 0f 00 18    	je     0x710d6ca0393a
    710d54a02974:	58                   	pop    rax
    710d54a02975:	50                   	push   rax
    710d54a02976:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    710d54a0297a:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02981:	c1 e0 02             	shl    eax,0x2
    710d54a02984:	41 03 45 20          	add    eax,DWORD PTR [r13+0x20]
    710d54a02988:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    710d54a0298c:	81 f9 f4 03 01 00    	cmp    ecx,0x103f4
    710d54a02992:	0f 84 eb 0f 00 18    	je     0x710d6ca03983
    710d54a02998:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103f4
    710d54a0299f:	f4 03 01 00 
    710d54a029a3:	0f 84 da 0f 00 18    	je     0x710d6ca03983
    710d54a029a9:	58                   	pop    rax
    710d54a029aa:	50                   	push   rax
    710d54a029ab:	41 8b 4d 24          	mov    ecx,DWORD PTR [r13+0x24]
    710d54a029af:	f6 c1 03             	test   cl,0x3
    710d54a029b2:	0f 85 2b 10 00 18    	jne    0x710d6ca039e3
    710d54a029b8:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a029bf:	48 89 ca             	mov    rdx,rcx
    710d54a029c2:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a029c6:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a029ca:	48 85 c0             	test   rax,rax
    710d54a029cd:	0f 84 60 10 00 18    	je     0x710d6ca03a33
    710d54a029d3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a029d9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a029dc:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a029e0:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103f6
    710d54a029e7:	f6 03 01 00 
    710d54a029eb:	0f 84 7d 10 00 18    	je     0x710d6ca03a6e
    710d54a029f1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103f6
    710d54a029f8:	f6 03 01 00 
    710d54a029fc:	0f 84 6c 10 00 18    	je     0x710d6ca03a6e
    710d54a02a02:	58                   	pop    rax
    710d54a02a03:	50                   	push   rax
    710d54a02a04:	41 8b 5d 2c          	mov    ebx,DWORD PTR [r13+0x2c]
    710d54a02a08:	f6 c3 03             	test   bl,0x3
    710d54a02a0b:	0f 85 a6 10 00 18    	jne    0x710d6ca03ab7
    710d54a02a11:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    710d54a02a18:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    710d54a02a1c:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02a23:	48 89 d9             	mov    rcx,rbx
    710d54a02a26:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a02a2a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a02a2e:	48 85 c0             	test   rax,rax
    710d54a02a31:	0f 84 d5 10 00 18    	je     0x710d6ca03b0c
    710d54a02a37:	89 d9                	mov    ecx,ebx
    710d54a02a39:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a02a3f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a02a42:	83 c3 04             	add    ebx,0x4
    710d54a02a45:	41 89 5d 2c          	mov    DWORD PTR [r13+0x2c],ebx
    710d54a02a49:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103f8
    710d54a02a50:	f8 03 01 00 
    710d54a02a54:	0f 84 ed 10 00 18    	je     0x710d6ca03b47
    710d54a02a5a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103f8
    710d54a02a61:	f8 03 01 00 
    710d54a02a65:	0f 84 dc 10 00 18    	je     0x710d6ca03b47
    710d54a02a6b:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d54a02a6f:	0f 85 14 11 00 18    	jne    0x710d6ca03b89
    710d54a02a75:	58                   	pop    rax
    710d54a02a76:	e9 0f 00 00 00       	jmp    0x710d54a02a8a
    710d54a02a7b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a02a82:	00 
    710d54a02a83:	74 f0                	je     0x710d54a02a75
    710d54a02a85:	e9 66 10 00 18       	jmp    0x710d6ca03af0
    710d54a02a8a:	50                   	push   rax
    710d54a02a8b:	41 8b 4d 24          	mov    ecx,DWORD PTR [r13+0x24]
    710d54a02a8f:	f6 c1 03             	test   cl,0x3
    710d54a02a92:	0f 85 23 11 00 18    	jne    0x710d6ca03bbb
    710d54a02a98:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a02a9f:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a02aa3:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02aaa:	48 89 ce             	mov    rsi,rcx
    710d54a02aad:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a02ab1:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a02ab5:	48 85 c0             	test   rax,rax
    710d54a02ab8:	0f 84 50 11 00 18    	je     0x710d6ca03c0e
    710d54a02abe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a02ac4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a02ac7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103fa
    710d54a02ace:	fa 03 01 00 
    710d54a02ad2:	0f 84 71 11 00 18    	je     0x710d6ca03c49
    710d54a02ad8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103fa
    710d54a02adf:	fa 03 01 00 
    710d54a02ae3:	0f 84 60 11 00 18    	je     0x710d6ca03c49
    710d54a02ae9:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a02aec:	0f 85 98 11 00 18    	jne    0x710d6ca03c8a
    710d54a02af2:	58                   	pop    rax
    710d54a02af3:	e9 0f 00 00 00       	jmp    0x710d54a02b07
    710d54a02af8:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a02aff:	00 
    710d54a02b00:	74 f0                	je     0x710d54a02af2
    710d54a02b02:	e9 eb 10 00 18       	jmp    0x710d6ca03bf2
    710d54a02b07:	50                   	push   rax
    710d54a02b08:	41 0f b7 45 2c       	movzx  eax,WORD PTR [r13+0x2c]
    710d54a02b0d:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a02b12:	09 c1                	or     ecx,eax
    710d54a02b14:	41 89 4d 2c          	mov    DWORD PTR [r13+0x2c],ecx
    710d54a02b18:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103fc
    710d54a02b1f:	fc 03 01 00 
    710d54a02b23:	0f 84 93 11 00 18    	je     0x710d6ca03cbc
    710d54a02b29:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103fc
    710d54a02b30:	fc 03 01 00 
    710d54a02b34:	0f 84 82 11 00 18    	je     0x710d6ca03cbc
    710d54a02b3a:	58                   	pop    rax
    710d54a02b3b:	50                   	push   rax
    710d54a02b3c:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a02b43:	00 
    710d54a02b44:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10400
    710d54a02b4b:	00 04 01 00 
    710d54a02b4f:	0f 84 c7 11 00 18    	je     0x710d6ca03d1c
    710d54a02b55:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10400
    710d54a02b5c:	00 04 01 00 
    710d54a02b60:	0f 84 b6 11 00 18    	je     0x710d6ca03d1c
    710d54a02b66:	58                   	pop    rax
    710d54a02b67:	50                   	push   rax
    710d54a02b68:	41 0f b7 45 2e       	movzx  eax,WORD PTR [r13+0x2e]
    710d54a02b6d:	c1 e0 10             	shl    eax,0x10
    710d54a02b70:	b9 fc 12 00 00       	mov    ecx,0x12fc
    710d54a02b75:	09 c1                	or     ecx,eax
    710d54a02b77:	41 89 4d 2c          	mov    DWORD PTR [r13+0x2c],ecx
    710d54a02b7b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10402
    710d54a02b82:	02 04 01 00 
    710d54a02b86:	0f 84 f0 11 00 18    	je     0x710d6ca03d7c
    710d54a02b8c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10402
    710d54a02b93:	02 04 01 00 
    710d54a02b97:	0f 84 df 11 00 18    	je     0x710d6ca03d7c
    710d54a02b9d:	58                   	pop    rax
    710d54a02b9e:	50                   	push   rax
    710d54a02b9f:	41 c7 45 08 ff 1f 00 	mov    DWORD PTR [r13+0x8],0x1fff
    710d54a02ba6:	00 
    710d54a02ba7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10406
    710d54a02bae:	06 04 01 00 
    710d54a02bb2:	0f 84 24 12 00 18    	je     0x710d6ca03ddc
    710d54a02bb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10406
    710d54a02bbf:	06 04 01 00 
    710d54a02bc3:	0f 84 13 12 00 18    	je     0x710d6ca03ddc
    710d54a02bc9:	58                   	pop    rax
    710d54a02bca:	50                   	push   rax
    710d54a02bcb:	41 c7 45 28 00 20 00 	mov    DWORD PTR [r13+0x28],0x2000
    710d54a02bd2:	00 
    710d54a02bd3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1040a
    710d54a02bda:	0a 04 01 00 
    710d54a02bde:	0f 84 58 12 00 18    	je     0x710d6ca03e3c
    710d54a02be4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1040a
    710d54a02beb:	0a 04 01 00 
    710d54a02bef:	0f 84 47 12 00 18    	je     0x710d6ca03e3c
    710d54a02bf5:	58                   	pop    rax
    710d54a02bf6:	50                   	push   rax
    710d54a02bf7:	41 c7 85 94 00 00 00 	mov    DWORD PTR [r13+0x94],0x10412
    710d54a02bfe:	12 04 01 00 
    710d54a02c02:	41 c7 85 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],0x10420
    710d54a02c09:	20 04 01 00 
    710d54a02c0d:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    710d54a02c11:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02c18:	41 89 85 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],eax
    710d54a02c1f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a02c26:	01 
    710d54a02c27:	81 f9 0e 04 01 00    	cmp    ecx,0x1040e
    710d54a02c2d:	0f 84 69 12 00 18    	je     0x710d6ca03e9c
    710d54a02c33:	b8 20 04 01 00       	mov    eax,0x10420
    710d54a02c38:	3d 0e 04 01 00       	cmp    eax,0x1040e
    710d54a02c3d:	0f 84 59 12 00 18    	je     0x710d6ca03e9c
    710d54a02c43:	b8 0e 04 01 00       	mov    eax,0x1040e
    710d54a02c48:	83 c0 04             	add    eax,0x4
    710d54a02c4b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a02c52:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a02c59:	04 00 00 00 
    710d54a02c5d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d54a02c64:	10 00 00 00 
    710d54a02c68:	58                   	pop    rax
    710d54a02c69:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a02c70:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a02c77:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a02c7e:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a02c85:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a02c8c:	39 f1                	cmp    ecx,esi
    710d54a02c8e:	0f 83 44 12 00 18    	jae    0x710d6ca03ed8
    710d54a02c94:	81 fa e6 03 01 00    	cmp    edx,0x103e6
    710d54a02c9a:	75 14                	jne    0x710d54a02cb0
    710d54a02c9c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a02ca3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a02caa:	00 
    710d54a02cab:	e9 70 fa ff ff       	jmp    0x710d54a02720
    710d54a02cb0:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a02cb7:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a02cbd:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a02cc0:	0f 85 12 12 00 18    	jne    0x710d6ca03ed8
    710d54a02cc6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a02ccd:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a02cd4:	00 
    710d54a02cd5:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a02cda:	ff e0                	jmp    rax
