
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66488-1-124302068294384.bin:     file format binary


Disassembly of section .data:

0000710d54a022f0 <.data>:
    710d54a022f0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a022f7:	8b 88 14 00 10 00    	mov    ecx,DWORD PTR [rax+0x100014]
    710d54a022fd:	ff c1                	inc    ecx
    710d54a022ff:	89 88 14 00 10 00    	mov    DWORD PTR [rax+0x100014],ecx
    710d54a02305:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0230b:	0f 84 9f 0d 00 18    	je     0x710d6ca030b0
    710d54a02311:	50                   	push   rax
    710d54a02312:	41 8b 5d 24          	mov    ebx,DWORD PTR [r13+0x24]
    710d54a02316:	f6 c3 03             	test   bl,0x3
    710d54a02319:	0f 85 bd 0d 00 18    	jne    0x710d6ca030dc
    710d54a0231f:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    710d54a02326:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a0232a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a02331:	48 89 d9             	mov    rcx,rbx
    710d54a02334:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a02338:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a0233c:	48 85 c0             	test   rax,rax
    710d54a0233f:	0f 84 ec 0d 00 18    	je     0x710d6ca03131
    710d54a02345:	89 d9                	mov    ecx,ebx
    710d54a02347:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0234d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a02350:	83 c3 04             	add    ebx,0x4
    710d54a02353:	41 89 5d 24          	mov    DWORD PTR [r13+0x24],ebx
    710d54a02357:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103b8
    710d54a0235e:	b8 03 01 00 
    710d54a02362:	0f 84 04 0e 00 18    	je     0x710d6ca0316c
    710d54a02368:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103b8
    710d54a0236f:	b8 03 01 00 
    710d54a02373:	0f 84 f3 0d 00 18    	je     0x710d6ca0316c
    710d54a02379:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d54a0237d:	0f 85 2b 0e 00 18    	jne    0x710d6ca031ae
    710d54a02383:	58                   	pop    rax
    710d54a02384:	e9 0f 00 00 00       	jmp    0x710d54a02398
    710d54a02389:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a02390:	00 
    710d54a02391:	74 f0                	je     0x710d54a02383
    710d54a02393:	e9 7d 0d 00 18       	jmp    0x710d6ca03115
    710d54a02398:	50                   	push   rax
    710d54a02399:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a0239d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a023a4:	31 d2                	xor    edx,edx
    710d54a023a6:	89 c6                	mov    esi,eax
    710d54a023a8:	ff c6                	inc    esi
    710d54a023aa:	0f 94 c2             	sete   dl
    710d54a023ad:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    710d54a023b1:	c1 e8 1f             	shr    eax,0x1f
    710d54a023b4:	89 f7                	mov    edi,esi
    710d54a023b6:	c1 ef 1f             	shr    edi,0x1f
    710d54a023b9:	f7 d0                	not    eax
    710d54a023bb:	21 f8                	and    eax,edi
    710d54a023bd:	31 db                	xor    ebx,ebx
    710d54a023bf:	85 f6                	test   esi,esi
    710d54a023c1:	0f 94 c3             	sete   bl
    710d54a023c4:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    710d54a023cb:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a023d2:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    710d54a023d9:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a023e0:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    710d54a023e7:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    710d54a023ee:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    710d54a023f5:	81 f9 ba 03 01 00    	cmp    ecx,0x103ba
    710d54a023fb:	0f 84 df 0d 00 18    	je     0x710d6ca031e0
    710d54a02401:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ba
    710d54a02408:	ba 03 01 00 
    710d54a0240c:	0f 84 ce 0d 00 18    	je     0x710d6ca031e0
    710d54a02412:	58                   	pop    rax
    710d54a02413:	50                   	push   rax
    710d54a02414:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    710d54a02419:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a0241e:	09 c1                	or     ecx,eax
    710d54a02420:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    710d54a02424:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103bc
    710d54a0242b:	bc 03 01 00 
    710d54a0242f:	0f 84 0b 0e 00 18    	je     0x710d6ca03240
    710d54a02435:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103bc
    710d54a0243c:	bc 03 01 00 
    710d54a02440:	0f 84 fa 0d 00 18    	je     0x710d6ca03240
    710d54a02446:	58                   	pop    rax
    710d54a02447:	50                   	push   rax
    710d54a02448:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    710d54a0244d:	c1 e0 10             	shl    eax,0x10
    710d54a02450:	b9 fc 92 00 00       	mov    ecx,0x92fc
    710d54a02455:	09 c1                	or     ecx,eax
    710d54a02457:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    710d54a0245b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103c0
    710d54a02462:	c0 03 01 00 
    710d54a02466:	0f 84 34 0e 00 18    	je     0x710d6ca032a0
    710d54a0246c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103c0
    710d54a02473:	c0 03 01 00 
    710d54a02477:	0f 84 23 0e 00 18    	je     0x710d6ca032a0
    710d54a0247d:	58                   	pop    rax
    710d54a0247e:	50                   	push   rax
    710d54a0247f:	41 8b 45 20          	mov    eax,DWORD PTR [r13+0x20]
    710d54a02483:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a0248a:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a0248e:	81 f9 c4 03 01 00    	cmp    ecx,0x103c4
    710d54a02494:	0f 84 66 0e 00 18    	je     0x710d6ca03300
    710d54a0249a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103c4
    710d54a024a1:	c4 03 01 00 
    710d54a024a5:	0f 84 55 0e 00 18    	je     0x710d6ca03300
    710d54a024ab:	58                   	pop    rax
    710d54a024ac:	50                   	push   rax
    710d54a024ad:	41 0f b7 45 18       	movzx  eax,WORD PTR [r13+0x18]
    710d54a024b2:	b9 00 00 19 00       	mov    ecx,0x190000
    710d54a024b7:	09 c1                	or     ecx,eax
    710d54a024b9:	41 89 4d 18          	mov    DWORD PTR [r13+0x18],ecx
    710d54a024bd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103c6
    710d54a024c4:	c6 03 01 00 
    710d54a024c8:	0f 84 92 0e 00 18    	je     0x710d6ca03360
    710d54a024ce:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103c6
    710d54a024d5:	c6 03 01 00 
    710d54a024d9:	0f 84 81 0e 00 18    	je     0x710d6ca03360
    710d54a024df:	58                   	pop    rax
    710d54a024e0:	50                   	push   rax
    710d54a024e1:	41 0f b7 45 1c       	movzx  eax,WORD PTR [r13+0x1c]
    710d54a024e6:	b9 00 00 6e 3c       	mov    ecx,0x3c6e0000
    710d54a024eb:	09 c1                	or     ecx,eax
    710d54a024ed:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    710d54a024f1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103ca
    710d54a024f8:	ca 03 01 00 
    710d54a024fc:	0f 84 be 0e 00 18    	je     0x710d6ca033c0
    710d54a02502:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ca
    710d54a02509:	ca 03 01 00 
    710d54a0250d:	0f 84 ad 0e 00 18    	je     0x710d6ca033c0
    710d54a02513:	58                   	pop    rax
    710d54a02514:	50                   	push   rax
    710d54a02515:	41 8b 45 20          	mov    eax,DWORD PTR [r13+0x20]
    710d54a02519:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02520:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    710d54a02524:	81 f9 ce 03 01 00    	cmp    ecx,0x103ce
    710d54a0252a:	0f 84 f0 0e 00 18    	je     0x710d6ca03420
    710d54a02530:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ce
    710d54a02537:	ce 03 01 00 
    710d54a0253b:	0f 84 df 0e 00 18    	je     0x710d6ca03420
    710d54a02541:	58                   	pop    rax
    710d54a02542:	50                   	push   rax
    710d54a02543:	41 0f b7 45 1a       	movzx  eax,WORD PTR [r13+0x1a]
    710d54a02548:	c1 e0 10             	shl    eax,0x10
    710d54a0254b:	b9 0d 66 00 00       	mov    ecx,0x660d
    710d54a02550:	09 c1                	or     ecx,eax
    710d54a02552:	41 89 4d 18          	mov    DWORD PTR [r13+0x18],ecx
    710d54a02556:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103d0
    710d54a0255d:	d0 03 01 00 
    710d54a02561:	0f 84 19 0f 00 18    	je     0x710d6ca03480
    710d54a02567:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103d0
    710d54a0256e:	d0 03 01 00 
    710d54a02572:	0f 84 08 0f 00 18    	je     0x710d6ca03480
    710d54a02578:	58                   	pop    rax
    710d54a02579:	50                   	push   rax
    710d54a0257a:	41 0f b7 45 1e       	movzx  eax,WORD PTR [r13+0x1e]
    710d54a0257f:	c1 e0 10             	shl    eax,0x10
    710d54a02582:	b9 5f f3 00 00       	mov    ecx,0xf35f
    710d54a02587:	09 c1                	or     ecx,eax
    710d54a02589:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    710d54a0258d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103d4
    710d54a02594:	d4 03 01 00 
    710d54a02598:	0f 84 42 0f 00 18    	je     0x710d6ca034e0
    710d54a0259e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103d4
    710d54a025a5:	d4 03 01 00 
    710d54a025a9:	0f 84 31 0f 00 18    	je     0x710d6ca034e0
    710d54a025af:	58                   	pop    rax
    710d54a025b0:	50                   	push   rax
    710d54a025b1:	41 c7 45 0c ff 1f 00 	mov    DWORD PTR [r13+0xc],0x1fff
    710d54a025b8:	00 
    710d54a025b9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103d8
    710d54a025c0:	d8 03 01 00 
    710d54a025c4:	0f 84 76 0f 00 18    	je     0x710d6ca03540
    710d54a025ca:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103d8
    710d54a025d1:	d8 03 01 00 
    710d54a025d5:	0f 84 65 0f 00 18    	je     0x710d6ca03540
    710d54a025db:	58                   	pop    rax
    710d54a025dc:	50                   	push   rax
    710d54a025dd:	41 c7 45 28 00 20 00 	mov    DWORD PTR [r13+0x28],0x2000
    710d54a025e4:	00 
    710d54a025e5:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103dc
    710d54a025ec:	dc 03 01 00 
    710d54a025f0:	0f 84 aa 0f 00 18    	je     0x710d6ca035a0
    710d54a025f6:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103dc
    710d54a025fd:	dc 03 01 00 
    710d54a02601:	0f 84 99 0f 00 18    	je     0x710d6ca035a0
    710d54a02607:	58                   	pop    rax
    710d54a02608:	50                   	push   rax
    710d54a02609:	41 8b 45 30          	mov    eax,DWORD PTR [r13+0x30]
    710d54a0260d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02614:	41 89 45 50          	mov    DWORD PTR [r13+0x50],eax
    710d54a02618:	81 f9 e0 03 01 00    	cmp    ecx,0x103e0
    710d54a0261e:	0f 84 dc 0f 00 18    	je     0x710d6ca03600
    710d54a02624:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103e0
    710d54a0262b:	e0 03 01 00 
    710d54a0262f:	0f 84 cb 0f 00 18    	je     0x710d6ca03600
    710d54a02635:	58                   	pop    rax
    710d54a02636:	50                   	push   rax
    710d54a02637:	41 c7 85 94 00 00 00 	mov    DWORD PTR [r13+0x94],0x103e6
    710d54a0263e:	e6 03 01 00 
    710d54a02642:	41 c7 85 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],0x103fa
    710d54a02649:	fa 03 01 00 
    710d54a0264d:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    710d54a02651:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02658:	41 89 85 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],eax
    710d54a0265f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a02666:	01 
    710d54a02667:	81 f9 e2 03 01 00    	cmp    ecx,0x103e2
    710d54a0266d:	0f 84 ed 0f 00 18    	je     0x710d6ca03660
    710d54a02673:	b8 fa 03 01 00       	mov    eax,0x103fa
    710d54a02678:	3d e2 03 01 00       	cmp    eax,0x103e2
    710d54a0267d:	0f 84 dd 0f 00 18    	je     0x710d6ca03660
    710d54a02683:	b8 e2 03 01 00       	mov    eax,0x103e2
    710d54a02688:	83 c0 04             	add    eax,0x4
    710d54a0268b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a02692:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a02699:	04 00 00 00 
    710d54a0269d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d54a026a4:	0e 00 00 00 
    710d54a026a8:	58                   	pop    rax
    710d54a026a9:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a026b0:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a026b7:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a026be:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a026c5:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a026cc:	39 f1                	cmp    ecx,esi
    710d54a026ce:	0f 83 c8 0f 00 18    	jae    0x710d6ca0369c
    710d54a026d4:	81 fa b8 03 01 00    	cmp    edx,0x103b8
    710d54a026da:	75 14                	jne    0x710d54a026f0
    710d54a026dc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a026e3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a026ea:	00 
    710d54a026eb:	e9 00 fc ff ff       	jmp    0x710d54a022f0
    710d54a026f0:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a026f7:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a026fd:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a02700:	0f 85 96 0f 00 18    	jne    0x710d6ca0369c
    710d54a02706:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0270d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a02714:	00 
    710d54a02715:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a0271a:	ff e0                	jmp    rax
