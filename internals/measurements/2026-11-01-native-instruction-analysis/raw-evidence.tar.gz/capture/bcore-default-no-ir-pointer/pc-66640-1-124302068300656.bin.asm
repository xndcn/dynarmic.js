
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66640-1-124302068300656.bin:     file format binary


Disassembly of section .data:

0000710d54a03b70 <.data>:
    710d54a03b70:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03b77:	8b 88 30 00 10 00    	mov    ecx,DWORD PTR [rax+0x100030]
    710d54a03b7d:	ff c1                	inc    ecx
    710d54a03b7f:	89 88 30 00 10 00    	mov    DWORD PTR [rax+0x100030],ecx
    710d54a03b85:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a03b8b:	0f 84 cf 16 00 18    	je     0x710d6ca05260
    710d54a03b91:	50                   	push   rax
    710d54a03b92:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a03b97:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a03b9c:	09 c1                	or     ecx,eax
    710d54a03b9e:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a03ba2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10450
    710d54a03ba9:	50 04 01 00 
    710d54a03bad:	0f 84 d9 16 00 18    	je     0x710d6ca0528c
    710d54a03bb3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10450
    710d54a03bba:	50 04 01 00 
    710d54a03bbe:	0f 84 c8 16 00 18    	je     0x710d6ca0528c
    710d54a03bc4:	58                   	pop    rax
    710d54a03bc5:	50                   	push   rax
    710d54a03bc6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a03bcb:	c1 e0 10             	shl    eax,0x10
    710d54a03bce:	b9 f4 12 00 00       	mov    ecx,0x12f4
    710d54a03bd3:	09 c1                	or     ecx,eax
    710d54a03bd5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a03bd9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10454
    710d54a03be0:	54 04 01 00 
    710d54a03be4:	0f 84 02 17 00 18    	je     0x710d6ca052ec
    710d54a03bea:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10454
    710d54a03bf1:	54 04 01 00 
    710d54a03bf5:	0f 84 f1 16 00 18    	je     0x710d6ca052ec
    710d54a03bfb:	58                   	pop    rax
    710d54a03bfc:	50                   	push   rax
    710d54a03bfd:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a03c01:	f6 c1 03             	test   cl,0x3
    710d54a03c04:	0f 85 42 17 00 18    	jne    0x710d6ca0534c
    710d54a03c0a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a03c11:	48 89 ca             	mov    rdx,rcx
    710d54a03c14:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a03c18:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a03c1c:	48 85 c0             	test   rax,rax
    710d54a03c1f:	0f 84 77 17 00 18    	je     0x710d6ca0539c
    710d54a03c25:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03c2b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a03c2e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    710d54a03c32:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10458
    710d54a03c39:	58 04 01 00 
    710d54a03c3d:	0f 84 94 17 00 18    	je     0x710d6ca053d7
    710d54a03c43:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10458
    710d54a03c4a:	58 04 01 00 
    710d54a03c4e:	0f 84 83 17 00 18    	je     0x710d6ca053d7
    710d54a03c54:	58                   	pop    rax
    710d54a03c55:	50                   	push   rax
    710d54a03c56:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a03c5b:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a03c60:	09 c1                	or     ecx,eax
    710d54a03c62:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a03c66:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1045a
    710d54a03c6d:	5a 04 01 00 
    710d54a03c71:	0f 84 a9 17 00 18    	je     0x710d6ca05420
    710d54a03c77:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1045a
    710d54a03c7e:	5a 04 01 00 
    710d54a03c82:	0f 84 98 17 00 18    	je     0x710d6ca05420
    710d54a03c88:	58                   	pop    rax
    710d54a03c89:	50                   	push   rax
    710d54a03c8a:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a03c8f:	c1 e0 10             	shl    eax,0x10
    710d54a03c92:	b9 f8 12 00 00       	mov    ecx,0x12f8
    710d54a03c97:	09 c1                	or     ecx,eax
    710d54a03c99:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a03c9d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1045e
    710d54a03ca4:	5e 04 01 00 
    710d54a03ca8:	0f 84 d2 17 00 18    	je     0x710d6ca05480
    710d54a03cae:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1045e
    710d54a03cb5:	5e 04 01 00 
    710d54a03cb9:	0f 84 c1 17 00 18    	je     0x710d6ca05480
    710d54a03cbf:	58                   	pop    rax
    710d54a03cc0:	50                   	push   rax
    710d54a03cc1:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a03cc5:	f6 c1 03             	test   cl,0x3
    710d54a03cc8:	0f 85 12 18 00 18    	jne    0x710d6ca054e0
    710d54a03cce:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a03cd5:	48 89 ca             	mov    rdx,rcx
    710d54a03cd8:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a03cdc:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a03ce0:	48 85 c0             	test   rax,rax
    710d54a03ce3:	0f 84 47 18 00 18    	je     0x710d6ca05530
    710d54a03ce9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03cef:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a03cf2:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a03cf6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10462
    710d54a03cfd:	62 04 01 00 
    710d54a03d01:	0f 84 64 18 00 18    	je     0x710d6ca0556b
    710d54a03d07:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10462
    710d54a03d0e:	62 04 01 00 
    710d54a03d12:	0f 84 53 18 00 18    	je     0x710d6ca0556b
    710d54a03d18:	58                   	pop    rax
    710d54a03d19:	50                   	push   rax
    710d54a03d1a:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a03d1e:	f6 c3 03             	test   bl,0x3
    710d54a03d21:	0f 85 8d 18 00 18    	jne    0x710d6ca055b4
    710d54a03d27:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a03d2e:	48 89 d8             	mov    rax,rbx
    710d54a03d31:	48 c1 e8 0c          	shr    rax,0xc
    710d54a03d35:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03d3a:	48 85 c0             	test   rax,rax
    710d54a03d3d:	0f 84 c3 18 00 18    	je     0x710d6ca05606
    710d54a03d43:	89 d9                	mov    ecx,ebx
    710d54a03d45:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03d4b:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a03d4f:	89 de                	mov    esi,ebx
    710d54a03d51:	83 c6 04             	add    esi,0x4
    710d54a03d54:	89 f0                	mov    eax,esi
    710d54a03d56:	c1 e8 0c             	shr    eax,0xc
    710d54a03d59:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a03d5e:	48 85 c0             	test   rax,rax
    710d54a03d61:	0f 84 dc 18 00 18    	je     0x710d6ca05643
    710d54a03d67:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a03d6d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a03d70:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a03d73:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a03d77:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a03d7e:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a03d82:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10464
    710d54a03d89:	64 04 01 00 
    710d54a03d8d:	0f 84 ec 18 00 18    	je     0x710d6ca0567f
    710d54a03d93:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10464
    710d54a03d9a:	64 04 01 00 
    710d54a03d9e:	0f 84 db 18 00 18    	je     0x710d6ca0567f
    710d54a03da4:	58                   	pop    rax
    710d54a03da5:	50                   	push   rax
    710d54a03da6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a03dad:	01 
    710d54a03dae:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10468
    710d54a03db5:	68 04 01 00 
    710d54a03db9:	0f 84 09 19 00 18    	je     0x710d6ca056c8
    710d54a03dbf:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10468
    710d54a03dc6:	68 04 01 00 
    710d54a03dca:	0f 84 f8 18 00 18    	je     0x710d6ca056c8
    710d54a03dd0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    710d54a03dd7:	fc 01 01 00 
    710d54a03ddb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a03de2:	04 00 00 00 
    710d54a03de6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d54a03ded:	08 00 00 00 
    710d54a03df1:	58                   	pop    rax
    710d54a03df2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03df9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a03e00:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a03e07:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a03e0e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a03e15:	39 f1                	cmp    ecx,esi
    710d54a03e17:	0f 83 e3 18 00 18    	jae    0x710d6ca05700
    710d54a03e1d:	81 fa 50 04 01 00    	cmp    edx,0x10450
    710d54a03e23:	75 14                	jne    0x710d54a03e39
    710d54a03e25:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03e2c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03e33:	00 
    710d54a03e34:	e9 37 fd ff ff       	jmp    0x710d54a03b70
    710d54a03e39:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a03e40:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a03e46:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a03e49:	0f 85 b1 18 00 18    	jne    0x710d6ca05700
    710d54a03e4f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03e56:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03e5d:	00 
    710d54a03e5e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a03e63:	ff e0                	jmp    rax
