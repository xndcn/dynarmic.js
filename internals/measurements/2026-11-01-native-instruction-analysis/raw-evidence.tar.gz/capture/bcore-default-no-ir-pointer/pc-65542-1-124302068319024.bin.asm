
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65542-1-124302068319024.bin:     file format binary


Disassembly of section .data:

0000710d54a08330 <.data>:
    710d54a08330:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a08337:	8b 88 44 00 10 00    	mov    ecx,DWORD PTR [rax+0x100044]
    710d54a0833d:	ff c1                	inc    ecx
    710d54a0833f:	89 88 44 00 10 00    	mov    DWORD PTR [rax+0x100044],ecx
    710d54a08345:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0834b:	0f 84 0f f7 ff 17    	je     0x710d6ca07a60
    710d54a08351:	50                   	push   rax
    710d54a08352:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    710d54a08357:	b9 00 00 00 01       	mov    ecx,0x1000000
    710d54a0835c:	09 c1                	or     ecx,eax
    710d54a0835e:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    710d54a08362:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10006
    710d54a08369:	06 00 01 00 
    710d54a0836d:	0f 84 19 f7 ff 17    	je     0x710d6ca07a8c
    710d54a08373:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10006
    710d54a0837a:	06 00 01 00 
    710d54a0837e:	0f 84 08 f7 ff 17    	je     0x710d6ca07a8c
    710d54a08384:	58                   	pop    rax
    710d54a08385:	50                   	push   rax
    710d54a08386:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    710d54a0838b:	c1 e0 10             	shl    eax,0x10
    710d54a0838e:	b9 04 00 00 00       	mov    ecx,0x4
    710d54a08393:	09 c1                	or     ecx,eax
    710d54a08395:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    710d54a08399:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000a
    710d54a083a0:	0a 00 01 00 
    710d54a083a4:	0f 84 42 f7 ff 17    	je     0x710d6ca07aec
    710d54a083aa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000a
    710d54a083b1:	0a 00 01 00 
    710d54a083b5:	0f 84 31 f7 ff 17    	je     0x710d6ca07aec
    710d54a083bb:	58                   	pop    rax
    710d54a083bc:	50                   	push   rax
    710d54a083bd:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    710d54a083c1:	f6 c1 03             	test   cl,0x3
    710d54a083c4:	0f 85 82 f7 ff 17    	jne    0x710d6ca07b4c
    710d54a083ca:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a083d1:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a083d5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a083dc:	48 89 ce             	mov    rsi,rcx
    710d54a083df:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a083e3:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a083e7:	48 85 c0             	test   rax,rax
    710d54a083ea:	0f 84 af f7 ff 17    	je     0x710d6ca07b9f
    710d54a083f0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a083f6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a083f9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000e
    710d54a08400:	0e 00 01 00 
    710d54a08404:	0f 84 d0 f7 ff 17    	je     0x710d6ca07bda
    710d54a0840a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000e
    710d54a08411:	0e 00 01 00 
    710d54a08415:	0f 84 bf f7 ff 17    	je     0x710d6ca07bda
    710d54a0841b:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a0841e:	0f 85 f7 f7 ff 17    	jne    0x710d6ca07c1b
    710d54a08424:	58                   	pop    rax
    710d54a08425:	e9 0f 00 00 00       	jmp    0x710d54a08439
    710d54a0842a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a08431:	00 
    710d54a08432:	74 f0                	je     0x710d54a08424
    710d54a08434:	e9 4a f7 ff 17       	jmp    0x710d6ca07b83
    710d54a08439:	50                   	push   rax
    710d54a0843a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a08441:	01 
    710d54a08442:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10010
    710d54a08449:	10 00 01 00 
    710d54a0844d:	0f 84 fa f7 ff 17    	je     0x710d6ca07c4d
    710d54a08453:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10010
    710d54a0845a:	10 00 01 00 
    710d54a0845e:	0f 84 e9 f7 ff 17    	je     0x710d6ca07c4d
    710d54a08464:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    710d54a0846b:	10 00 01 00 
    710d54a0846f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a08476:	02 00 00 00 
    710d54a0847a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d54a08481:	04 00 00 00 
    710d54a08485:	58                   	pop    rax
    710d54a08486:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a0848d:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a08494:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0849b:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a084a2:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a084a9:	39 f1                	cmp    ecx,esi
    710d54a084ab:	0f 83 d4 f7 ff 17    	jae    0x710d6ca07c85
    710d54a084b1:	81 fa 06 00 01 00    	cmp    edx,0x10006
    710d54a084b7:	75 14                	jne    0x710d54a084cd
    710d54a084b9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a084c0:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a084c7:	00 
    710d54a084c8:	e9 63 fe ff ff       	jmp    0x710d54a08330
    710d54a084cd:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a084d4:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a084da:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a084dd:	0f 85 a2 f7 ff 17    	jne    0x710d6ca07c85
    710d54a084e3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a084ea:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a084f1:	00 
    710d54a084f2:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a084f7:	ff e0                	jmp    rax
