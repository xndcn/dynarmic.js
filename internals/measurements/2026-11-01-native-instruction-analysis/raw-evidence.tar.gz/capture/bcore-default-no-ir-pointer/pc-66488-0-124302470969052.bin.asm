
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66488-0-124302470969052.bin:     file format binary


Disassembly of section .data:

0000710d6ca076dc <.data>:
    710d6ca076dc:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    710d6ca076e1:	0f b6 90 28 01 00 00 	movzx  edx,BYTE PTR [rax+0x128]
    710d6ca076e8:	e9 f3 f0 ff e7       	jmp    0x710d54a067e0
    710d6ca076ed:	41 89 ed             	mov    r13d,ebp
    710d6ca076f0:	e9 c7 ed ff e7       	jmp    0x710d54a064bc
    710d6ca076f5:	4c 8b 6c 24 18       	mov    r13,QWORD PTR [rsp+0x18]
    710d6ca076fa:	44 8b 4c 24 30       	mov    r9d,DWORD PTR [rsp+0x30]
    710d6ca076ff:	e9 09 ef ff e7       	jmp    0x710d54a0660d
