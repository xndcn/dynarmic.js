
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66600-1-124302470957568.bin:     file format binary


Disassembly of section .data:

0000710d6ca04a00 <.data>:
    710d6ca04a00:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca04a06:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca04a09:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca04a0f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca04a16:	0f 87 a5 eb ff e7    	ja     0x710d54a035c1
    710d6ca04a1c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xa
    710d6ca04a23:	0a 00 00 00 
    710d6ca04a27:	e9 95 eb ff e7       	jmp    0x710d54a035c1
    710d6ca04a2c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    710d6ca04a33:	28 04 01 00 
    710d6ca04a37:	b8 28 04 01 00       	mov    eax,0x10428
    710d6ca04a3c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04a43:	04 00 00 00 
    710d6ca04a47:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04a4e:	01 00 00 00 
    710d6ca04a52:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca04a55:	be 28 04 01 00       	mov    esi,0x10428
    710d6ca04a5a:	4c 89 ef             	mov    rdi,r13
    710d6ca04a5d:	e8 fe b6 ff e7       	call   0x710d54a00160
    710d6ca04a62:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04a69:	00 
    710d6ca04a6a:	0f 84 84 eb ff e7    	je     0x710d54a035f4
    710d6ca04a70:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04a77:	04 00 00 00 
    710d6ca04a7b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04a82:	01 00 00 00 
    710d6ca04a86:	58                   	pop    rax
    710d6ca04a87:	e9 7b ee ff e7       	jmp    0x710d54a03907
    710d6ca04a8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    710d6ca04a93:	2c 04 01 00 
    710d6ca04a97:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04a9e:	04 00 00 00 
    710d6ca04aa2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04aa9:	02 00 00 00 
    710d6ca04aad:	ba 2c 04 01 00       	mov    edx,0x1042c
    710d6ca04ab2:	4c 89 ef             	mov    rdi,r13
    710d6ca04ab5:	4c 89 f6             	mov    rsi,r14
    710d6ca04ab8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca04abe:	e8 bd b5 ff e7       	call   0x710d54a00080
    710d6ca04ac3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04aca:	04 00 00 00 
    710d6ca04ace:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04ad5:	02 00 00 00 
    710d6ca04ad9:	58                   	pop    rax
    710d6ca04ada:	e9 28 ee ff e7       	jmp    0x710d54a03907
    710d6ca04adf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    710d6ca04ae6:	2c 04 01 00 
    710d6ca04aea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04af1:	04 00 00 00 
    710d6ca04af5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04afc:	02 00 00 00 
    710d6ca04b00:	4c 89 f7             	mov    rdi,r14
    710d6ca04b03:	89 ce                	mov    esi,ecx
    710d6ca04b05:	e8 66 b5 ff e7       	call   0x710d54a00070
    710d6ca04b0a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04b11:	00 
    710d6ca04b12:	0f 84 23 eb ff e7    	je     0x710d54a0363b
    710d6ca04b18:	eb a9                	jmp    0x710d6ca04ac3
    710d6ca04b1a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    710d6ca04b21:	2c 04 01 00 
    710d6ca04b25:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04b2c:	04 00 00 00 
    710d6ca04b30:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04b37:	02 00 00 00 
    710d6ca04b3b:	4c 89 f7             	mov    rdi,r14
    710d6ca04b3e:	89 de                	mov    esi,ebx
    710d6ca04b40:	44 89 e2             	mov    edx,r12d
    710d6ca04b43:	e8 28 b5 ff e7       	call   0x710d54a00070
    710d6ca04b48:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04b4f:	00 
    710d6ca04b50:	0f 84 07 eb ff e7    	je     0x710d54a0365d
    710d6ca04b56:	e9 68 ff ff ff       	jmp    0x710d6ca04ac3
    710d6ca04b5b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    710d6ca04b62:	2c 04 01 00 
    710d6ca04b66:	b8 2c 04 01 00       	mov    eax,0x1042c
    710d6ca04b6b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04b72:	04 00 00 00 
    710d6ca04b76:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04b7d:	02 00 00 00 
    710d6ca04b81:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca04b84:	be 2c 04 01 00       	mov    esi,0x1042c
    710d6ca04b89:	4c 89 ef             	mov    rdi,r13
    710d6ca04b8c:	e8 cf b5 ff e7       	call   0x710d54a00160
    710d6ca04b91:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    710d6ca04b95:	0f 84 03 eb ff e7    	je     0x710d54a0369e
    710d6ca04b9b:	eb 0f                	jmp    0x710d6ca04bac
    710d6ca04b9d:	b8 2c 04 01 00       	mov    eax,0x1042c
    710d6ca04ba2:	83 c0 04             	add    eax,0x4
    710d6ca04ba5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca04bac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04bb3:	04 00 00 00 
    710d6ca04bb7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04bbe:	02 00 00 00 
    710d6ca04bc2:	4c 89 ef             	mov    rdi,r13
    710d6ca04bc5:	e8 86 b5 ff e7       	call   0x710d54a00150
    710d6ca04bca:	e9 cf ea ff e7       	jmp    0x710d54a0369e
    710d6ca04bcf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    710d6ca04bd6:	30 04 01 00 
    710d6ca04bda:	b8 30 04 01 00       	mov    eax,0x10430
    710d6ca04bdf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04be6:	04 00 00 00 
    710d6ca04bea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04bf1:	03 00 00 00 
    710d6ca04bf5:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca04bf8:	be 30 04 01 00       	mov    esi,0x10430
    710d6ca04bfd:	4c 89 ef             	mov    rdi,r13
    710d6ca04c00:	e8 5b b5 ff e7       	call   0x710d54a00160
    710d6ca04c05:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04c0c:	00 
    710d6ca04c0d:	0f 84 d0 ea ff e7    	je     0x710d54a036e3
    710d6ca04c13:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04c1a:	04 00 00 00 
    710d6ca04c1e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04c25:	03 00 00 00 
    710d6ca04c29:	58                   	pop    rax
    710d6ca04c2a:	e9 d8 ec ff e7       	jmp    0x710d54a03907
    710d6ca04c2f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    710d6ca04c36:	34 04 01 00 
    710d6ca04c3a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04c41:	02 00 00 00 
    710d6ca04c45:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04c4c:	04 00 00 00 
    710d6ca04c50:	ba 34 04 01 00       	mov    edx,0x10434
    710d6ca04c55:	4c 89 ef             	mov    rdi,r13
    710d6ca04c58:	4c 89 f6             	mov    rsi,r14
    710d6ca04c5b:	45 31 c0             	xor    r8d,r8d
    710d6ca04c5e:	e8 1d b4 ff e7       	call   0x710d54a00080
    710d6ca04c63:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04c6a:	02 00 00 00 
    710d6ca04c6e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04c75:	04 00 00 00 
    710d6ca04c79:	58                   	pop    rax
    710d6ca04c7a:	e9 88 ec ff e7       	jmp    0x710d54a03907
    710d6ca04c7f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    710d6ca04c86:	34 04 01 00 
    710d6ca04c8a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04c91:	02 00 00 00 
    710d6ca04c95:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04c9c:	04 00 00 00 
    710d6ca04ca0:	4c 89 f7             	mov    rdi,r14
    710d6ca04ca3:	89 ce                	mov    esi,ecx
    710d6ca04ca5:	e8 96 b3 ff e7       	call   0x710d54a00040
    710d6ca04caa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04cb1:	00 
    710d6ca04cb2:	0f 84 5e ea ff e7    	je     0x710d54a03716
    710d6ca04cb8:	eb a9                	jmp    0x710d6ca04c63
    710d6ca04cba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    710d6ca04cc1:	34 04 01 00 
    710d6ca04cc5:	b8 34 04 01 00       	mov    eax,0x10434
    710d6ca04cca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04cd1:	02 00 00 00 
    710d6ca04cd5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca04cdc:	04 00 00 00 
    710d6ca04ce0:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04ce3:	be 34 04 01 00       	mov    esi,0x10434
    710d6ca04ce8:	4c 89 ef             	mov    rdi,r13
    710d6ca04ceb:	e8 70 b4 ff e7       	call   0x710d54a00160
    710d6ca04cf0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04cf7:	00 
    710d6ca04cf8:	0f 84 3e ea ff e7    	je     0x710d54a0373c
    710d6ca04cfe:	e9 60 ff ff ff       	jmp    0x710d6ca04c63
    710d6ca04d03:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10436
    710d6ca04d0a:	36 04 01 00 
    710d6ca04d0e:	b8 36 04 01 00       	mov    eax,0x10436
    710d6ca04d13:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04d1a:	02 00 00 00 
    710d6ca04d1e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca04d25:	05 00 00 00 
    710d6ca04d29:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04d2c:	be 36 04 01 00       	mov    esi,0x10436
    710d6ca04d31:	4c 89 ef             	mov    rdi,r13
    710d6ca04d34:	e8 27 b4 ff e7       	call   0x710d54a00160
    710d6ca04d39:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04d40:	00 
    710d6ca04d41:	0f 84 2c ea ff e7    	je     0x710d54a03773
    710d6ca04d47:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04d4e:	02 00 00 00 
    710d6ca04d52:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca04d59:	05 00 00 00 
    710d6ca04d5d:	58                   	pop    rax
    710d6ca04d5e:	e9 a4 eb ff e7       	jmp    0x710d54a03907
    710d6ca04d63:	b8 38 04 01 00       	mov    eax,0x10438
    710d6ca04d68:	83 c0 0a             	add    eax,0xa
    710d6ca04d6b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca04d72:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04d79:	02 00 00 00 
    710d6ca04d7d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca04d84:	06 00 00 00 
    710d6ca04d88:	be 38 04 01 00       	mov    esi,0x10438
    710d6ca04d8d:	ba 38 04 01 00       	mov    edx,0x10438
    710d6ca04d92:	4c 89 ef             	mov    rdi,r13
    710d6ca04d95:	e8 c6 b3 ff e7       	call   0x710d54a00160
    710d6ca04d9a:	e9 0a ea ff e7       	jmp    0x710d54a037a9
    710d6ca04d9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10438
    710d6ca04da6:	38 04 01 00 
    710d6ca04daa:	b8 38 04 01 00       	mov    eax,0x10438
    710d6ca04daf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04db6:	02 00 00 00 
    710d6ca04dba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca04dc1:	06 00 00 00 
    710d6ca04dc5:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04dc8:	be 38 04 01 00       	mov    esi,0x10438
    710d6ca04dcd:	4c 89 ef             	mov    rdi,r13
    710d6ca04dd0:	e8 8b b3 ff e7       	call   0x710d54a00160
    710d6ca04dd5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04ddc:	00 
    710d6ca04ddd:	0f 84 13 ea ff e7    	je     0x710d54a037f6
    710d6ca04de3:	e9 d0 e9 ff e7       	jmp    0x710d54a037b8
    710d6ca04de8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043a
    710d6ca04def:	3a 04 01 00 
    710d6ca04df3:	b8 3a 04 01 00       	mov    eax,0x1043a
    710d6ca04df8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04dff:	02 00 00 00 
    710d6ca04e03:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca04e0a:	07 00 00 00 
    710d6ca04e0e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04e11:	be 3a 04 01 00       	mov    esi,0x1043a
    710d6ca04e16:	4c 89 ef             	mov    rdi,r13
    710d6ca04e19:	e8 42 b3 ff e7       	call   0x710d54a00160
    710d6ca04e1e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04e25:	00 
    710d6ca04e26:	0f 84 f6 e9 ff e7    	je     0x710d54a03822
    710d6ca04e2c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04e33:	02 00 00 00 
    710d6ca04e37:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca04e3e:	07 00 00 00 
    710d6ca04e42:	58                   	pop    rax
    710d6ca04e43:	e9 bf ea ff e7       	jmp    0x710d54a03907
    710d6ca04e48:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    710d6ca04e4f:	3c 04 01 00 
    710d6ca04e53:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04e5a:	04 00 00 00 
    710d6ca04e5e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04e65:	08 00 00 00 
    710d6ca04e69:	ba 3c 04 01 00       	mov    edx,0x1043c
    710d6ca04e6e:	4c 89 ef             	mov    rdi,r13
    710d6ca04e71:	4c 89 f6             	mov    rsi,r14
    710d6ca04e74:	89 d9                	mov    ecx,ebx
    710d6ca04e76:	45 31 c0             	xor    r8d,r8d
    710d6ca04e79:	e8 02 b2 ff e7       	call   0x710d54a00080
    710d6ca04e7e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04e85:	04 00 00 00 
    710d6ca04e89:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04e90:	08 00 00 00 
    710d6ca04e94:	58                   	pop    rax
    710d6ca04e95:	e9 6d ea ff e7       	jmp    0x710d54a03907
    710d6ca04e9a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    710d6ca04ea1:	3c 04 01 00 
    710d6ca04ea5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04eac:	04 00 00 00 
    710d6ca04eb0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04eb7:	08 00 00 00 
    710d6ca04ebb:	4c 89 f7             	mov    rdi,r14
    710d6ca04ebe:	89 de                	mov    esi,ebx
    710d6ca04ec0:	e8 7b b1 ff e7       	call   0x710d54a00040
    710d6ca04ec5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04ecc:	00 
    710d6ca04ecd:	75 af                	jne    0x710d6ca04e7e
    710d6ca04ecf:	41 89 c7             	mov    r15d,eax
    710d6ca04ed2:	e9 82 e9 ff e7       	jmp    0x710d54a03859
    710d6ca04ed7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    710d6ca04ede:	3c 04 01 00 
    710d6ca04ee2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04ee9:	04 00 00 00 
    710d6ca04eed:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04ef4:	08 00 00 00 
    710d6ca04ef8:	4c 89 f7             	mov    rdi,r14
    710d6ca04efb:	e8 40 b1 ff e7       	call   0x710d54a00040
    710d6ca04f00:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04f07:	00 
    710d6ca04f08:	0f 84 6c e9 ff e7    	je     0x710d54a0387a
    710d6ca04f0e:	e9 6b ff ff ff       	jmp    0x710d6ca04e7e
    710d6ca04f13:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    710d6ca04f1a:	3c 04 01 00 
    710d6ca04f1e:	b8 3c 04 01 00       	mov    eax,0x1043c
    710d6ca04f23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca04f2a:	04 00 00 00 
    710d6ca04f2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca04f35:	08 00 00 00 
    710d6ca04f39:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca04f3c:	be 3c 04 01 00       	mov    esi,0x1043c
    710d6ca04f41:	4c 89 ef             	mov    rdi,r13
    710d6ca04f44:	e8 17 b2 ff e7       	call   0x710d54a00160
    710d6ca04f49:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04f50:	00 
    710d6ca04f51:	0f 84 57 e9 ff e7    	je     0x710d54a038ae
    710d6ca04f57:	e9 22 ff ff ff       	jmp    0x710d6ca04e7e
    710d6ca04f5c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    710d6ca04f63:	40 04 01 00 
    710d6ca04f67:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04f6e:	02 00 00 00 
    710d6ca04f72:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca04f79:	09 00 00 00 
    710d6ca04f7d:	4c 89 ef             	mov    rdi,r13
    710d6ca04f80:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca04f85:	4c 89 f2             	mov    rdx,r14
    710d6ca04f88:	e8 03 b1 ff e7       	call   0x710d54a00090
    710d6ca04f8d:	e9 5e e9 ff e7       	jmp    0x710d54a038f0
    710d6ca04f92:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04f99:	02 00 00 00 
    710d6ca04f9d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca04fa4:	09 00 00 00 
    710d6ca04fa8:	be 40 04 01 00       	mov    esi,0x10440
    710d6ca04fad:	ba 40 04 01 00       	mov    edx,0x10440
    710d6ca04fb2:	4c 89 ef             	mov    rdi,r13
    710d6ca04fb5:	e8 a6 b1 ff e7       	call   0x710d54a00160
    710d6ca04fba:	e9 31 e9 ff e7       	jmp    0x710d54a038f0
    710d6ca04fbf:	c2 08 00             	ret    0x8
