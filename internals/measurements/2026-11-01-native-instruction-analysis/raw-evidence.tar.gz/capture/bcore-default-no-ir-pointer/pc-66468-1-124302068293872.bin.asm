
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66468-1-124302068293872.bin:     file format binary


Disassembly of section .data:

0000710d54a020f0 <.data>:
    710d54a020f0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a020f7:	8b 88 10 00 10 00    	mov    ecx,DWORD PTR [rax+0x100010]
    710d54a020fd:	ff c1                	inc    ecx
    710d54a020ff:	89 88 10 00 10 00    	mov    DWORD PTR [rax+0x100010],ecx
    710d54a02105:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0210b:	0f 84 4f 0d 00 18    	je     0x710d6ca02e60
    710d54a02111:	50                   	push   rax
    710d54a02112:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    710d54a02117:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a0211c:	09 c1                	or     ecx,eax
    710d54a0211e:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    710d54a02122:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103a4
    710d54a02129:	a4 03 01 00 
    710d54a0212d:	0f 84 59 0d 00 18    	je     0x710d6ca02e8c
    710d54a02133:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103a4
    710d54a0213a:	a4 03 01 00 
    710d54a0213e:	0f 84 48 0d 00 18    	je     0x710d6ca02e8c
    710d54a02144:	58                   	pop    rax
    710d54a02145:	50                   	push   rax
    710d54a02146:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    710d54a0214b:	c1 e0 10             	shl    eax,0x10
    710d54a0214e:	b9 fc 92 00 00       	mov    ecx,0x92fc
    710d54a02153:	09 c1                	or     ecx,eax
    710d54a02155:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    710d54a02159:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103a8
    710d54a02160:	a8 03 01 00 
    710d54a02164:	0f 84 82 0d 00 18    	je     0x710d6ca02eec
    710d54a0216a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103a8
    710d54a02171:	a8 03 01 00 
    710d54a02175:	0f 84 71 0d 00 18    	je     0x710d6ca02eec
    710d54a0217b:	58                   	pop    rax
    710d54a0217c:	50                   	push   rax
    710d54a0217d:	41 8b 45 34          	mov    eax,DWORD PTR [r13+0x34]
    710d54a02181:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02188:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    710d54a0218c:	81 f9 ac 03 01 00    	cmp    ecx,0x103ac
    710d54a02192:	0f 84 b4 0d 00 18    	je     0x710d6ca02f4c
    710d54a02198:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ac
    710d54a0219f:	ac 03 01 00 
    710d54a021a3:	0f 84 a3 0d 00 18    	je     0x710d6ca02f4c
    710d54a021a9:	58                   	pop    rax
    710d54a021aa:	50                   	push   rax
    710d54a021ab:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a021b2:	00 
    710d54a021b3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103ae
    710d54a021ba:	ae 03 01 00 
    710d54a021be:	0f 84 e8 0d 00 18    	je     0x710d6ca02fac
    710d54a021c4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103ae
    710d54a021cb:	ae 03 01 00 
    710d54a021cf:	0f 84 d7 0d 00 18    	je     0x710d6ca02fac
    710d54a021d5:	58                   	pop    rax
    710d54a021d6:	50                   	push   rax
    710d54a021d7:	41 c7 45 28 00 20 00 	mov    DWORD PTR [r13+0x28],0x2000
    710d54a021de:	00 
    710d54a021df:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103b0
    710d54a021e6:	b0 03 01 00 
    710d54a021ea:	0f 84 1c 0e 00 18    	je     0x710d6ca0300c
    710d54a021f0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103b0
    710d54a021f7:	b0 03 01 00 
    710d54a021fb:	0f 84 0b 0e 00 18    	je     0x710d6ca0300c
    710d54a02201:	58                   	pop    rax
    710d54a02202:	50                   	push   rax
    710d54a02203:	41 c7 85 94 00 00 00 	mov    DWORD PTR [r13+0x94],0x103b8
    710d54a0220a:	b8 03 01 00 
    710d54a0220e:	41 c7 85 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],0x103ba
    710d54a02215:	ba 03 01 00 
    710d54a02219:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    710d54a0221d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a02224:	41 89 85 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],eax
    710d54a0222b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a02232:	01 
    710d54a02233:	81 f9 b4 03 01 00    	cmp    ecx,0x103b4
    710d54a02239:	0f 84 2d 0e 00 18    	je     0x710d6ca0306c
    710d54a0223f:	b8 ba 03 01 00       	mov    eax,0x103ba
    710d54a02244:	3d b4 03 01 00       	cmp    eax,0x103b4
    710d54a02249:	0f 84 1d 0e 00 18    	je     0x710d6ca0306c
    710d54a0224f:	b8 b4 03 01 00       	mov    eax,0x103b4
    710d54a02254:	83 c0 04             	add    eax,0x4
    710d54a02257:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a0225e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a02265:	04 00 00 00 
    710d54a02269:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d54a02270:	06 00 00 00 
    710d54a02274:	58                   	pop    rax
    710d54a02275:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a0227c:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a02283:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a0228a:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a02291:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a02298:	39 f1                	cmp    ecx,esi
    710d54a0229a:	0f 83 08 0e 00 18    	jae    0x710d6ca030a8
    710d54a022a0:	81 fa a4 03 01 00    	cmp    edx,0x103a4
    710d54a022a6:	75 14                	jne    0x710d54a022bc
    710d54a022a8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a022af:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a022b6:	00 
    710d54a022b7:	e9 34 fe ff ff       	jmp    0x710d54a020f0
    710d54a022bc:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a022c3:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a022c9:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a022cc:	0f 85 d6 0d 00 18    	jne    0x710d6ca030a8
    710d54a022d2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a022d9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a022e0:	00 
    710d54a022e1:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a022e6:	ff e0                	jmp    rax
