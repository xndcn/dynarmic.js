
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66534-1-124302470952608.bin:     file format binary


Disassembly of section .data:

0000710d6ca036a0 <.data>:
    710d6ca036a0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca036a6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca036a9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca036af:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca036b6:	0f 87 85 f0 ff e7    	ja     0x710d54a02741
    710d6ca036bc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x6
    710d6ca036c3:	06 00 00 00 
    710d6ca036c7:	e9 75 f0 ff e7       	jmp    0x710d54a02741
    710d6ca036cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103e6
    710d6ca036d3:	e6 03 01 00 
    710d6ca036d7:	b8 e6 03 01 00       	mov    eax,0x103e6
    710d6ca036dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca036e3:	02 00 00 00 
    710d6ca036e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca036ee:	01 00 00 00 
    710d6ca036f2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca036f5:	be e6 03 01 00       	mov    esi,0x103e6
    710d6ca036fa:	4c 89 ef             	mov    rdi,r13
    710d6ca036fd:	e8 5e ca ff e7       	call   0x710d54a00160
    710d6ca03702:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03709:	00 
    710d6ca0370a:	0f 84 63 f0 ff e7    	je     0x710d54a02773
    710d6ca03710:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03717:	02 00 00 00 
    710d6ca0371b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca03722:	01 00 00 00 
    710d6ca03726:	58                   	pop    rax
    710d6ca03727:	e9 3d f5 ff e7       	jmp    0x710d54a02c69
    710d6ca0372c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103e8
    710d6ca03733:	e8 03 01 00 
    710d6ca03737:	b8 e8 03 01 00       	mov    eax,0x103e8
    710d6ca0373c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03743:	02 00 00 00 
    710d6ca03747:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0374e:	02 00 00 00 
    710d6ca03752:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03755:	be e8 03 01 00       	mov    esi,0x103e8
    710d6ca0375a:	4c 89 ef             	mov    rdi,r13
    710d6ca0375d:	e8 fe c9 ff e7       	call   0x710d54a00160
    710d6ca03762:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03769:	00 
    710d6ca0376a:	0f 84 89 f0 ff e7    	je     0x710d54a027f9
    710d6ca03770:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03777:	02 00 00 00 
    710d6ca0377b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca03782:	02 00 00 00 
    710d6ca03786:	58                   	pop    rax
    710d6ca03787:	e9 dd f4 ff e7       	jmp    0x710d54a02c69
    710d6ca0378c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ea
    710d6ca03793:	ea 03 01 00 
    710d6ca03797:	b8 ea 03 01 00       	mov    eax,0x103ea
    710d6ca0379c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca037a3:	04 00 00 00 
    710d6ca037a7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca037ae:	03 00 00 00 
    710d6ca037b2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca037b5:	be ea 03 01 00       	mov    esi,0x103ea
    710d6ca037ba:	4c 89 ef             	mov    rdi,r13
    710d6ca037bd:	e8 9e c9 ff e7       	call   0x710d54a00160
    710d6ca037c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca037c9:	00 
    710d6ca037ca:	0f 84 87 f0 ff e7    	je     0x710d54a02857
    710d6ca037d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca037d7:	04 00 00 00 
    710d6ca037db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca037e2:	03 00 00 00 
    710d6ca037e6:	58                   	pop    rax
    710d6ca037e7:	e9 7d f4 ff e7       	jmp    0x710d54a02c69
    710d6ca037ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ee
    710d6ca037f3:	ee 03 01 00 
    710d6ca037f7:	b8 ee 03 01 00       	mov    eax,0x103ee
    710d6ca037fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03803:	02 00 00 00 
    710d6ca03807:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca0380e:	04 00 00 00 
    710d6ca03812:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03815:	be ee 03 01 00       	mov    esi,0x103ee
    710d6ca0381a:	4c 89 ef             	mov    rdi,r13
    710d6ca0381d:	e8 3e c9 ff e7       	call   0x710d54a00160
    710d6ca03822:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03829:	00 
    710d6ca0382a:	0f 84 85 f0 ff e7    	je     0x710d54a028b5
    710d6ca03830:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03837:	02 00 00 00 
    710d6ca0383b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca03842:	04 00 00 00 
    710d6ca03846:	58                   	pop    rax
    710d6ca03847:	e9 1d f4 ff e7       	jmp    0x710d54a02c69
    710d6ca0384c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f0
    710d6ca03853:	f0 03 01 00 
    710d6ca03857:	b8 f0 03 01 00       	mov    eax,0x103f0
    710d6ca0385c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03863:	02 00 00 00 
    710d6ca03867:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0386e:	05 00 00 00 
    710d6ca03872:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03875:	be f0 03 01 00       	mov    esi,0x103f0
    710d6ca0387a:	4c 89 ef             	mov    rdi,r13
    710d6ca0387d:	e8 de c8 ff e7       	call   0x710d54a00160
    710d6ca03882:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03889:	00 
    710d6ca0388a:	0f 84 53 f0 ff e7    	je     0x710d54a028e3
    710d6ca03890:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03897:	02 00 00 00 
    710d6ca0389b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca038a2:	05 00 00 00 
    710d6ca038a6:	58                   	pop    rax
    710d6ca038a7:	e9 bd f3 ff e7       	jmp    0x710d54a02c69
    710d6ca038ac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f2
    710d6ca038b3:	f2 03 01 00 
    710d6ca038b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca038be:	02 00 00 00 
    710d6ca038c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca038c9:	06 00 00 00 
    710d6ca038cd:	ba f2 03 01 00       	mov    edx,0x103f2
    710d6ca038d2:	4c 89 ef             	mov    rdi,r13
    710d6ca038d5:	4c 89 f6             	mov    rsi,r14
    710d6ca038d8:	45 31 c0             	xor    r8d,r8d
    710d6ca038db:	e8 a0 c7 ff e7       	call   0x710d54a00080
    710d6ca038e0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca038e7:	02 00 00 00 
    710d6ca038eb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca038f2:	06 00 00 00 
    710d6ca038f6:	58                   	pop    rax
    710d6ca038f7:	e9 6d f3 ff e7       	jmp    0x710d54a02c69
    710d6ca038fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f2
    710d6ca03903:	f2 03 01 00 
    710d6ca03907:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0390e:	02 00 00 00 
    710d6ca03912:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca03919:	06 00 00 00 
    710d6ca0391d:	4c 89 f7             	mov    rdi,r14
    710d6ca03920:	89 ce                	mov    esi,ecx
    710d6ca03922:	e8 19 c7 ff e7       	call   0x710d54a00040
    710d6ca03927:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0392e:	00 
    710d6ca0392f:	75 af                	jne    0x710d6ca038e0
    710d6ca03931:	41 8b 4d 50          	mov    ecx,DWORD PTR [r13+0x50]
    710d6ca03935:	e9 de ef ff e7       	jmp    0x710d54a02918
    710d6ca0393a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f2
    710d6ca03941:	f2 03 01 00 
    710d6ca03945:	b8 f2 03 01 00       	mov    eax,0x103f2
    710d6ca0394a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03951:	02 00 00 00 
    710d6ca03955:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca0395c:	06 00 00 00 
    710d6ca03960:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03963:	be f2 03 01 00       	mov    esi,0x103f2
    710d6ca03968:	4c 89 ef             	mov    rdi,r13
    710d6ca0396b:	e8 f0 c7 ff e7       	call   0x710d54a00160
    710d6ca03970:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03977:	00 
    710d6ca03978:	0f 84 f6 ef ff e7    	je     0x710d54a02974
    710d6ca0397e:	e9 5d ff ff ff       	jmp    0x710d6ca038e0
    710d6ca03983:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f4
    710d6ca0398a:	f4 03 01 00 
    710d6ca0398e:	b8 f4 03 01 00       	mov    eax,0x103f4
    710d6ca03993:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0399a:	02 00 00 00 
    710d6ca0399e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca039a5:	07 00 00 00 
    710d6ca039a9:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca039ac:	be f4 03 01 00       	mov    esi,0x103f4
    710d6ca039b1:	4c 89 ef             	mov    rdi,r13
    710d6ca039b4:	e8 a7 c7 ff e7       	call   0x710d54a00160
    710d6ca039b9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca039c0:	00 
    710d6ca039c1:	0f 84 e2 ef ff e7    	je     0x710d54a029a9
    710d6ca039c7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca039ce:	02 00 00 00 
    710d6ca039d2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d6ca039d9:	07 00 00 00 
    710d6ca039dd:	58                   	pop    rax
    710d6ca039de:	e9 86 f2 ff e7       	jmp    0x710d54a02c69
    710d6ca039e3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f6
    710d6ca039ea:	f6 03 01 00 
    710d6ca039ee:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca039f5:	02 00 00 00 
    710d6ca039f9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03a00:	08 00 00 00 
    710d6ca03a04:	ba f6 03 01 00       	mov    edx,0x103f6
    710d6ca03a09:	4c 89 ef             	mov    rdi,r13
    710d6ca03a0c:	4c 89 f6             	mov    rsi,r14
    710d6ca03a0f:	45 31 c0             	xor    r8d,r8d
    710d6ca03a12:	e8 69 c6 ff e7       	call   0x710d54a00080
    710d6ca03a17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03a1e:	02 00 00 00 
    710d6ca03a22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03a29:	08 00 00 00 
    710d6ca03a2d:	58                   	pop    rax
    710d6ca03a2e:	e9 36 f2 ff e7       	jmp    0x710d54a02c69
    710d6ca03a33:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f6
    710d6ca03a3a:	f6 03 01 00 
    710d6ca03a3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03a45:	02 00 00 00 
    710d6ca03a49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03a50:	08 00 00 00 
    710d6ca03a54:	4c 89 f7             	mov    rdi,r14
    710d6ca03a57:	89 ce                	mov    esi,ecx
    710d6ca03a59:	e8 e2 c5 ff e7       	call   0x710d54a00040
    710d6ca03a5e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03a65:	00 
    710d6ca03a66:	0f 84 70 ef ff e7    	je     0x710d54a029dc
    710d6ca03a6c:	eb a9                	jmp    0x710d6ca03a17
    710d6ca03a6e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f6
    710d6ca03a75:	f6 03 01 00 
    710d6ca03a79:	b8 f6 03 01 00       	mov    eax,0x103f6
    710d6ca03a7e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03a85:	02 00 00 00 
    710d6ca03a89:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    710d6ca03a90:	08 00 00 00 
    710d6ca03a94:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03a97:	be f6 03 01 00       	mov    esi,0x103f6
    710d6ca03a9c:	4c 89 ef             	mov    rdi,r13
    710d6ca03a9f:	e8 bc c6 ff e7       	call   0x710d54a00160
    710d6ca03aa4:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03aab:	00 
    710d6ca03aac:	0f 84 50 ef ff e7    	je     0x710d54a02a02
    710d6ca03ab2:	e9 60 ff ff ff       	jmp    0x710d6ca03a17
    710d6ca03ab7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f8
    710d6ca03abe:	f8 03 01 00 
    710d6ca03ac2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03ac9:	02 00 00 00 
    710d6ca03acd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca03ad4:	09 00 00 00 
    710d6ca03ad8:	ba f8 03 01 00       	mov    edx,0x103f8
    710d6ca03add:	4c 89 ef             	mov    rdi,r13
    710d6ca03ae0:	4c 89 f6             	mov    rsi,r14
    710d6ca03ae3:	89 d9                	mov    ecx,ebx
    710d6ca03ae5:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca03aeb:	e8 90 c5 ff e7       	call   0x710d54a00080
    710d6ca03af0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03af7:	02 00 00 00 
    710d6ca03afb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca03b02:	09 00 00 00 
    710d6ca03b06:	58                   	pop    rax
    710d6ca03b07:	e9 5d f1 ff e7       	jmp    0x710d54a02c69
    710d6ca03b0c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f8
    710d6ca03b13:	f8 03 01 00 
    710d6ca03b17:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03b1e:	02 00 00 00 
    710d6ca03b22:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca03b29:	09 00 00 00 
    710d6ca03b2d:	4c 89 f7             	mov    rdi,r14
    710d6ca03b30:	89 de                	mov    esi,ebx
    710d6ca03b32:	e8 39 c5 ff e7       	call   0x710d54a00070
    710d6ca03b37:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03b3e:	00 
    710d6ca03b3f:	0f 84 fd ee ff e7    	je     0x710d54a02a42
    710d6ca03b45:	eb a9                	jmp    0x710d6ca03af0
    710d6ca03b47:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103f8
    710d6ca03b4e:	f8 03 01 00 
    710d6ca03b52:	b8 f8 03 01 00       	mov    eax,0x103f8
    710d6ca03b57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03b5e:	02 00 00 00 
    710d6ca03b62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca03b69:	09 00 00 00 
    710d6ca03b6d:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03b70:	be f8 03 01 00       	mov    esi,0x103f8
    710d6ca03b75:	4c 89 ef             	mov    rdi,r13
    710d6ca03b78:	e8 e3 c5 ff e7       	call   0x710d54a00160
    710d6ca03b7d:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d6ca03b81:	0f 84 f4 ee ff e7    	je     0x710d54a02a7b
    710d6ca03b87:	eb 0f                	jmp    0x710d6ca03b98
    710d6ca03b89:	b8 f8 03 01 00       	mov    eax,0x103f8
    710d6ca03b8e:	83 c0 02             	add    eax,0x2
    710d6ca03b91:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca03b98:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03b9f:	02 00 00 00 
    710d6ca03ba3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    710d6ca03baa:	09 00 00 00 
    710d6ca03bae:	4c 89 ef             	mov    rdi,r13
    710d6ca03bb1:	e8 9a c5 ff e7       	call   0x710d54a00150
    710d6ca03bb6:	e9 c0 ee ff e7       	jmp    0x710d54a02a7b
    710d6ca03bbb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103fa
    710d6ca03bc2:	fa 03 01 00 
    710d6ca03bc6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03bcd:	02 00 00 00 
    710d6ca03bd1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03bd8:	0a 00 00 00 
    710d6ca03bdc:	ba fa 03 01 00       	mov    edx,0x103fa
    710d6ca03be1:	4c 89 ef             	mov    rdi,r13
    710d6ca03be4:	4c 89 f6             	mov    rsi,r14
    710d6ca03be7:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca03bed:	e8 8e c4 ff e7       	call   0x710d54a00080
    710d6ca03bf2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03bf9:	02 00 00 00 
    710d6ca03bfd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03c04:	0a 00 00 00 
    710d6ca03c08:	58                   	pop    rax
    710d6ca03c09:	e9 5b f0 ff e7       	jmp    0x710d54a02c69
    710d6ca03c0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103fa
    710d6ca03c15:	fa 03 01 00 
    710d6ca03c19:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03c20:	02 00 00 00 
    710d6ca03c24:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03c2b:	0a 00 00 00 
    710d6ca03c2f:	4c 89 f7             	mov    rdi,r14
    710d6ca03c32:	89 ce                	mov    esi,ecx
    710d6ca03c34:	e8 37 c4 ff e7       	call   0x710d54a00070
    710d6ca03c39:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03c40:	00 
    710d6ca03c41:	0f 84 80 ee ff e7    	je     0x710d54a02ac7
    710d6ca03c47:	eb a9                	jmp    0x710d6ca03bf2
    710d6ca03c49:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103fa
    710d6ca03c50:	fa 03 01 00 
    710d6ca03c54:	b8 fa 03 01 00       	mov    eax,0x103fa
    710d6ca03c59:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03c60:	02 00 00 00 
    710d6ca03c64:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03c6b:	0a 00 00 00 
    710d6ca03c6f:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03c72:	be fa 03 01 00       	mov    esi,0x103fa
    710d6ca03c77:	4c 89 ef             	mov    rdi,r13
    710d6ca03c7a:	e8 e1 c4 ff e7       	call   0x710d54a00160
    710d6ca03c7f:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca03c82:	0f 84 70 ee ff e7    	je     0x710d54a02af8
    710d6ca03c88:	eb 0f                	jmp    0x710d6ca03c99
    710d6ca03c8a:	b8 fa 03 01 00       	mov    eax,0x103fa
    710d6ca03c8f:	83 c0 02             	add    eax,0x2
    710d6ca03c92:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca03c99:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03ca0:	02 00 00 00 
    710d6ca03ca4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    710d6ca03cab:	0a 00 00 00 
    710d6ca03caf:	4c 89 ef             	mov    rdi,r13
    710d6ca03cb2:	e8 99 c4 ff e7       	call   0x710d54a00150
    710d6ca03cb7:	e9 3c ee ff e7       	jmp    0x710d54a02af8
    710d6ca03cbc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103fc
    710d6ca03cc3:	fc 03 01 00 
    710d6ca03cc7:	b8 fc 03 01 00       	mov    eax,0x103fc
    710d6ca03ccc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03cd3:	04 00 00 00 
    710d6ca03cd7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca03cde:	0b 00 00 00 
    710d6ca03ce2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03ce5:	be fc 03 01 00       	mov    esi,0x103fc
    710d6ca03cea:	4c 89 ef             	mov    rdi,r13
    710d6ca03ced:	e8 6e c4 ff e7       	call   0x710d54a00160
    710d6ca03cf2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03cf9:	00 
    710d6ca03cfa:	0f 84 3a ee ff e7    	je     0x710d54a02b3a
    710d6ca03d00:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03d07:	04 00 00 00 
    710d6ca03d0b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    710d6ca03d12:	0b 00 00 00 
    710d6ca03d16:	58                   	pop    rax
    710d6ca03d17:	e9 4d ef ff e7       	jmp    0x710d54a02c69
    710d6ca03d1c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10400
    710d6ca03d23:	00 04 01 00 
    710d6ca03d27:	b8 00 04 01 00       	mov    eax,0x10400
    710d6ca03d2c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03d33:	02 00 00 00 
    710d6ca03d37:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca03d3e:	0c 00 00 00 
    710d6ca03d42:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca03d45:	be 00 04 01 00       	mov    esi,0x10400
    710d6ca03d4a:	4c 89 ef             	mov    rdi,r13
    710d6ca03d4d:	e8 0e c4 ff e7       	call   0x710d54a00160
    710d6ca03d52:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03d59:	00 
    710d6ca03d5a:	0f 84 06 ee ff e7    	je     0x710d54a02b66
    710d6ca03d60:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca03d67:	02 00 00 00 
    710d6ca03d6b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    710d6ca03d72:	0c 00 00 00 
    710d6ca03d76:	58                   	pop    rax
    710d6ca03d77:	e9 ed ee ff e7       	jmp    0x710d54a02c69
    710d6ca03d7c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10402
    710d6ca03d83:	02 04 01 00 
    710d6ca03d87:	b8 02 04 01 00       	mov    eax,0x10402
    710d6ca03d8c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03d93:	04 00 00 00 
    710d6ca03d97:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca03d9e:	0d 00 00 00 
    710d6ca03da2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03da5:	be 02 04 01 00       	mov    esi,0x10402
    710d6ca03daa:	4c 89 ef             	mov    rdi,r13
    710d6ca03dad:	e8 ae c3 ff e7       	call   0x710d54a00160
    710d6ca03db2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03db9:	00 
    710d6ca03dba:	0f 84 dd ed ff e7    	je     0x710d54a02b9d
    710d6ca03dc0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03dc7:	04 00 00 00 
    710d6ca03dcb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    710d6ca03dd2:	0d 00 00 00 
    710d6ca03dd6:	58                   	pop    rax
    710d6ca03dd7:	e9 8d ee ff e7       	jmp    0x710d54a02c69
    710d6ca03ddc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10406
    710d6ca03de3:	06 04 01 00 
    710d6ca03de7:	b8 06 04 01 00       	mov    eax,0x10406
    710d6ca03dec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03df3:	04 00 00 00 
    710d6ca03df7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca03dfe:	0e 00 00 00 
    710d6ca03e02:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03e05:	be 06 04 01 00       	mov    esi,0x10406
    710d6ca03e0a:	4c 89 ef             	mov    rdi,r13
    710d6ca03e0d:	e8 4e c3 ff e7       	call   0x710d54a00160
    710d6ca03e12:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03e19:	00 
    710d6ca03e1a:	0f 84 a9 ed ff e7    	je     0x710d54a02bc9
    710d6ca03e20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03e27:	04 00 00 00 
    710d6ca03e2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    710d6ca03e32:	0e 00 00 00 
    710d6ca03e36:	58                   	pop    rax
    710d6ca03e37:	e9 2d ee ff e7       	jmp    0x710d54a02c69
    710d6ca03e3c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1040a
    710d6ca03e43:	0a 04 01 00 
    710d6ca03e47:	b8 0a 04 01 00       	mov    eax,0x1040a
    710d6ca03e4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03e53:	04 00 00 00 
    710d6ca03e57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca03e5e:	0f 00 00 00 
    710d6ca03e62:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03e65:	be 0a 04 01 00       	mov    esi,0x1040a
    710d6ca03e6a:	4c 89 ef             	mov    rdi,r13
    710d6ca03e6d:	e8 ee c2 ff e7       	call   0x710d54a00160
    710d6ca03e72:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03e79:	00 
    710d6ca03e7a:	0f 84 75 ed ff e7    	je     0x710d54a02bf5
    710d6ca03e80:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03e87:	04 00 00 00 
    710d6ca03e8b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d6ca03e92:	0f 00 00 00 
    710d6ca03e96:	58                   	pop    rax
    710d6ca03e97:	e9 cd ed ff e7       	jmp    0x710d54a02c69
    710d6ca03e9c:	b8 0e 04 01 00       	mov    eax,0x1040e
    710d6ca03ea1:	83 c0 04             	add    eax,0x4
    710d6ca03ea4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca03eab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03eb2:	04 00 00 00 
    710d6ca03eb6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    710d6ca03ebd:	10 00 00 00 
    710d6ca03ec1:	be 0e 04 01 00       	mov    esi,0x1040e
    710d6ca03ec6:	ba 0e 04 01 00       	mov    edx,0x1040e
    710d6ca03ecb:	4c 89 ef             	mov    rdi,r13
    710d6ca03ece:	e8 8d c2 ff e7       	call   0x710d54a00160
    710d6ca03ed3:	e9 6b ed ff e7       	jmp    0x710d54a02c43
    710d6ca03ed8:	c2 08 00             	ret    0x8
