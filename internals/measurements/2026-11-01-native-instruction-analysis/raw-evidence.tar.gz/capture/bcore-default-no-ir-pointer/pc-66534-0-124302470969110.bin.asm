
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66534-0-124302470969110.bin:     file format binary


Disassembly of section .data:

0000710d6ca07716 <.data>:
    710d6ca07716:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d6ca0771a:	41 89 01             	mov    DWORD PTR [r9],eax
    710d6ca0771d:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d6ca07721:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d6ca07725:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    710d6ca07729:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d6ca0772e:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    710d6ca07732:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d6ca07736:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d6ca0773a:	41 c7 81 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],0x0
    710d6ca07741:	00 00 00 00 
    710d6ca07745:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d6ca0774c:	fa 03 01 00 
    710d6ca07750:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fc
    710d6ca07757:	fc 03 01 00 
    710d6ca0775b:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d6ca0775e:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d6ca07765:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d6ca0776c:	00 00 00 00 
    710d6ca07770:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d6ca07777:	00 00 00 00 
    710d6ca0777b:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d6ca07782:	00 00 00 00 
    710d6ca07786:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d6ca0778d:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d6ca07794:	02 00 00 00 
    710d6ca07798:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d6ca0779f:	00 
    710d6ca077a0:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    710d6ca077a7:	0a 00 00 00 
    710d6ca077ab:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d6ca077b2:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d6ca077b9:	56 00 00 
    710d6ca077bc:	4c 89 cf             	mov    rdi,r9
    710d6ca077bf:	4d 89 cd             	mov    r13,r9
    710d6ca077c2:	48 89 cb             	mov    rbx,rcx
    710d6ca077c5:	44 89 d5             	mov    ebp,r10d
    710d6ca077c8:	ff d0                	call   rax
    710d6ca077ca:	41 89 ea             	mov    r10d,ebp
    710d6ca077cd:	48 89 d9             	mov    rcx,rbx
    710d6ca077d0:	4d 89 e9             	mov    r9,r13
    710d6ca077d3:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    710d6ca077da:	00 
    710d6ca077db:	84 d2                	test   dl,dl
    710d6ca077dd:	0f 84 00 f6 ff e7    	je     0x710d54a06de3
    710d6ca077e3:	e9 85 f9 ff e7       	jmp    0x710d54a0716d
    710d6ca077e8:	41 c7 01 00 00 00 00 	mov    DWORD PTR [r9],0x0
    710d6ca077ef:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d6ca077f3:	41 c7 41 08 ff 1f 00 	mov    DWORD PTR [r9+0x8],0x1fff
    710d6ca077fa:	00 
    710d6ca077fb:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d6ca07800:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    710d6ca07804:	41 c7 41 2c fc 12 01 	mov    DWORD PTR [r9+0x2c],0x112fc
    710d6ca0780b:	00 
    710d6ca0780c:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d6ca07810:	41 c7 81 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],0x2000
    710d6ca07817:	00 20 00 00 
    710d6ca0781b:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x10420
    710d6ca07822:	20 04 01 00 
    710d6ca07826:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x10412
    710d6ca0782d:	12 04 01 00 
    710d6ca07831:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d6ca07834:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d6ca0783b:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d6ca07842:	00 00 00 00 
    710d6ca07846:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d6ca0784d:	00 00 00 00 
    710d6ca07851:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d6ca07858:	00 00 00 00 
    710d6ca0785c:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d6ca07863:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x4
    710d6ca0786a:	04 00 00 00 
    710d6ca0786e:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x1
    710d6ca07875:	01 
    710d6ca07876:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x10
    710d6ca0787d:	10 00 00 00 
    710d6ca07881:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d6ca07888:	48 b8 30 0d a2 86 66 	movabs rax,0x566686a20d30
    710d6ca0788f:	56 00 00 
    710d6ca07892:	4c 89 cf             	mov    rdi,r9
    710d6ca07895:	be 0e 04 01 00       	mov    esi,0x1040e
    710d6ca0789a:	ba 0e 04 01 00       	mov    edx,0x1040e
    710d6ca0789f:	4d 89 cd             	mov    r13,r9
    710d6ca078a2:	ff d0                	call   rax
    710d6ca078a4:	e9 b9 f8 ff e7       	jmp    0x710d54a07162
