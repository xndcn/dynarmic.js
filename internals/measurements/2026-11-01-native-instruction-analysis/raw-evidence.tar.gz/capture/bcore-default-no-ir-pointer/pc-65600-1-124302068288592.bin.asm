
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65600-1-124302068288592.bin:     file format binary


Disassembly of section .data:

0000710d54a00c50 <.data>:
    710d54a00c50:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a00c57:	3d 00 00 00 00       	cmp    eax,0x0
    710d54a00c5c:	0f 95 c2             	setne  dl
    710d54a00c5f:	b9 40 00 01 00       	mov    ecx,0x10040
    710d54a00c64:	29 c8                	sub    eax,ecx
    710d54a00c66:	3d 4e 00 00 00       	cmp    eax,0x4e
    710d54a00c6b:	0f 96 c3             	setbe  bl
    710d54a00c6e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    710d54a00c75:	81 fe 00 00 00 00    	cmp    esi,0x0
    710d54a00c7b:	0f 94 c0             	sete   al
    710d54a00c7e:	29 ce                	sub    esi,ecx
    710d54a00c80:	81 fe 4e 00 00 00    	cmp    esi,0x4e
    710d54a00c86:	0f 97 c1             	seta   cl
    710d54a00c89:	84 da                	test   dl,bl
    710d54a00c8b:	0f 85 2f 01 00 18    	jne    0x710d6ca00dc0
    710d54a00c91:	08 c8                	or     al,cl
    710d54a00c93:	0f 84 27 01 00 18    	je     0x710d6ca00dc0
    710d54a00c99:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a00ca0:	8b 88 08 00 10 00    	mov    ecx,DWORD PTR [rax+0x100008]
    710d54a00ca6:	ff c1                	inc    ecx
    710d54a00ca8:	89 88 08 00 10 00    	mov    DWORD PTR [rax+0x100008],ecx
    710d54a00cae:	81 f9 14 cd 00 00    	cmp    ecx,0xcd14
    710d54a00cb4:	0f 84 1c 01 00 18    	je     0x710d6ca00dd6
    710d54a00cba:	50                   	push   rax
    710d54a00cbb:	41 c7 45 28 01 3c 00 	mov    DWORD PTR [r13+0x28],0x3c01
    710d54a00cc2:	00 
    710d54a00cc3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10040
    710d54a00cca:	40 00 01 00 
    710d54a00cce:	0f 84 2e 01 00 18    	je     0x710d6ca00e02
    710d54a00cd4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10040
    710d54a00cdb:	40 00 01 00 
    710d54a00cdf:	0f 84 1d 01 00 18    	je     0x710d6ca00e02
    710d54a00ce5:	58                   	pop    rax
    710d54a00ce6:	50                   	push   rax
    710d54a00ce7:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    710d54a00cec:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10044
    710d54a00cf3:	44 00 01 00 
    710d54a00cf7:	0f 84 65 01 00 18    	je     0x710d6ca00e62
    710d54a00cfd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10044
    710d54a00d04:	44 00 01 00 
    710d54a00d08:	0f 84 54 01 00 18    	je     0x710d6ca00e62
    710d54a00d0e:	58                   	pop    rax
    710d54a00d0f:	50                   	push   rax
    710d54a00d10:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a00d14:	f6 c1 03             	test   cl,0x3
    710d54a00d17:	0f 85 a5 01 00 18    	jne    0x710d6ca00ec2
    710d54a00d1d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00d24:	48 89 ca             	mov    rdx,rcx
    710d54a00d27:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a00d2b:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a00d2f:	48 85 c0             	test   rax,rax
    710d54a00d32:	0f 84 da 01 00 18    	je     0x710d6ca00f12
    710d54a00d38:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00d3e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a00d41:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    710d54a00d45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10046
    710d54a00d4c:	46 00 01 00 
    710d54a00d50:	0f 84 f7 01 00 18    	je     0x710d6ca00f4d
    710d54a00d56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10046
    710d54a00d5d:	46 00 01 00 
    710d54a00d61:	0f 84 e6 01 00 18    	je     0x710d6ca00f4d
    710d54a00d67:	58                   	pop    rax
    710d54a00d68:	50                   	push   rax
    710d54a00d69:	41 83 45 28 04       	add    DWORD PTR [r13+0x28],0x4
    710d54a00d6e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10048
    710d54a00d75:	48 00 01 00 
    710d54a00d79:	0f 84 17 02 00 18    	je     0x710d6ca00f96
    710d54a00d7f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10048
    710d54a00d86:	48 00 01 00 
    710d54a00d8a:	0f 84 06 02 00 18    	je     0x710d6ca00f96
    710d54a00d90:	58                   	pop    rax
    710d54a00d91:	50                   	push   rax
    710d54a00d92:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a00d96:	f6 c1 03             	test   cl,0x3
    710d54a00d99:	0f 85 57 02 00 18    	jne    0x710d6ca00ff6
    710d54a00d9f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00da6:	48 89 ca             	mov    rdx,rcx
    710d54a00da9:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a00dad:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a00db1:	48 85 c0             	test   rax,rax
    710d54a00db4:	0f 84 8c 02 00 18    	je     0x710d6ca01046
    710d54a00dba:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00dc0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a00dc3:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a00dc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004a
    710d54a00dce:	4a 00 01 00 
    710d54a00dd2:	0f 84 a9 02 00 18    	je     0x710d6ca01081
    710d54a00dd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004a
    710d54a00ddf:	4a 00 01 00 
    710d54a00de3:	0f 84 98 02 00 18    	je     0x710d6ca01081
    710d54a00de9:	58                   	pop    rax
    710d54a00dea:	50                   	push   rax
    710d54a00deb:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    710d54a00df2:	00 
    710d54a00df3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004c
    710d54a00dfa:	4c 00 01 00 
    710d54a00dfe:	0f 84 c6 02 00 18    	je     0x710d6ca010ca
    710d54a00e04:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004c
    710d54a00e0b:	4c 00 01 00 
    710d54a00e0f:	0f 84 b5 02 00 18    	je     0x710d6ca010ca
    710d54a00e15:	58                   	pop    rax
    710d54a00e16:	50                   	push   rax
    710d54a00e17:	41 c7 45 2c 05 3c 00 	mov    DWORD PTR [r13+0x2c],0x3c05
    710d54a00e1e:	00 
    710d54a00e1f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004e
    710d54a00e26:	4e 00 01 00 
    710d54a00e2a:	0f 84 fa 02 00 18    	je     0x710d6ca0112a
    710d54a00e30:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004e
    710d54a00e37:	4e 00 01 00 
    710d54a00e3b:	0f 84 e9 02 00 18    	je     0x710d6ca0112a
    710d54a00e41:	58                   	pop    rax
    710d54a00e42:	50                   	push   rax
    710d54a00e43:	41 c1 65 2c 02       	shl    DWORD PTR [r13+0x2c],0x2
    710d54a00e48:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10052
    710d54a00e4f:	52 00 01 00 
    710d54a00e53:	0f 84 31 03 00 18    	je     0x710d6ca0118a
    710d54a00e59:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10052
    710d54a00e60:	52 00 01 00 
    710d54a00e64:	0f 84 20 03 00 18    	je     0x710d6ca0118a
    710d54a00e6a:	58                   	pop    rax
    710d54a00e6b:	50                   	push   rax
    710d54a00e6c:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a00e70:	8d 48 fc             	lea    ecx,[rax-0x4]
    710d54a00e73:	a8 03                	test   al,0x3
    710d54a00e75:	0f 85 6f 03 00 18    	jne    0x710d6ca011ea
    710d54a00e7b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a00e82:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    710d54a00e86:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00e8d:	89 ce                	mov    esi,ecx
    710d54a00e8f:	c1 ee 0c             	shr    esi,0xc
    710d54a00e92:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a00e96:	48 85 c0             	test   rax,rax
    710d54a00e99:	0f 84 9e 03 00 18    	je     0x710d6ca0123d
    710d54a00e9f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00ea5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a00ea8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10054
    710d54a00eaf:	54 00 01 00 
    710d54a00eb3:	0f 84 bf 03 00 18    	je     0x710d6ca01278
    710d54a00eb9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10054
    710d54a00ec0:	54 00 01 00 
    710d54a00ec4:	0f 84 ae 03 00 18    	je     0x710d6ca01278
    710d54a00eca:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a00ecd:	0f 85 e6 03 00 18    	jne    0x710d6ca012b9
    710d54a00ed3:	58                   	pop    rax
    710d54a00ed4:	e9 0f 00 00 00       	jmp    0x710d54a00ee8
    710d54a00ed9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a00ee0:	00 
    710d54a00ee1:	74 f0                	je     0x710d54a00ed3
    710d54a00ee3:	e9 39 03 00 18       	jmp    0x710d6ca01221
    710d54a00ee8:	50                   	push   rax
    710d54a00ee9:	41 c7 45 28 03 3c 00 	mov    DWORD PTR [r13+0x28],0x3c03
    710d54a00ef0:	00 
    710d54a00ef1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10056
    710d54a00ef8:	56 00 01 00 
    710d54a00efc:	0f 84 e9 03 00 18    	je     0x710d6ca012eb
    710d54a00f02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10056
    710d54a00f09:	56 00 01 00 
    710d54a00f0d:	0f 84 d8 03 00 18    	je     0x710d6ca012eb
    710d54a00f13:	58                   	pop    rax
    710d54a00f14:	50                   	push   rax
    710d54a00f15:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    710d54a00f1a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005a
    710d54a00f21:	5a 00 01 00 
    710d54a00f25:	0f 84 20 04 00 18    	je     0x710d6ca0134b
    710d54a00f2b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005a
    710d54a00f32:	5a 00 01 00 
    710d54a00f36:	0f 84 0f 04 00 18    	je     0x710d6ca0134b
    710d54a00f3c:	58                   	pop    rax
    710d54a00f3d:	50                   	push   rax
    710d54a00f3e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a00f42:	f6 c1 03             	test   cl,0x3
    710d54a00f45:	0f 85 60 04 00 18    	jne    0x710d6ca013ab
    710d54a00f4b:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a00f52:	48 89 ca             	mov    rdx,rcx
    710d54a00f55:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a00f59:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a00f5d:	48 85 c0             	test   rax,rax
    710d54a00f60:	0f 84 95 04 00 18    	je     0x710d6ca013fb
    710d54a00f66:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a00f6c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a00f6f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a00f73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005c
    710d54a00f7a:	5c 00 01 00 
    710d54a00f7e:	0f 84 b2 04 00 18    	je     0x710d6ca01436
    710d54a00f84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005c
    710d54a00f8b:	5c 00 01 00 
    710d54a00f8f:	0f 84 a1 04 00 18    	je     0x710d6ca01436
    710d54a00f95:	58                   	pop    rax
    710d54a00f96:	50                   	push   rax
    710d54a00f97:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    710d54a00f9c:	b9 00 00 00 00       	mov    ecx,0x0
    710d54a00fa1:	09 c1                	or     ecx,eax
    710d54a00fa3:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    710d54a00fa7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005e
    710d54a00fae:	5e 00 01 00 
    710d54a00fb2:	0f 84 c7 04 00 18    	je     0x710d6ca0147f
    710d54a00fb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005e
    710d54a00fbf:	5e 00 01 00 
    710d54a00fc3:	0f 84 b6 04 00 18    	je     0x710d6ca0147f
    710d54a00fc9:	58                   	pop    rax
    710d54a00fca:	50                   	push   rax
    710d54a00fcb:	41 0f b7 45 30       	movzx  eax,WORD PTR [r13+0x30]
    710d54a00fd0:	b9 00 00 00 01       	mov    ecx,0x1000000
    710d54a00fd5:	09 c1                	or     ecx,eax
    710d54a00fd7:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    710d54a00fdb:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10062
    710d54a00fe2:	62 00 01 00 
    710d54a00fe6:	0f 84 f3 04 00 18    	je     0x710d6ca014df
    710d54a00fec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10062
    710d54a00ff3:	62 00 01 00 
    710d54a00ff7:	0f 84 e2 04 00 18    	je     0x710d6ca014df
    710d54a00ffd:	58                   	pop    rax
    710d54a00ffe:	50                   	push   rax
    710d54a00fff:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    710d54a01004:	c1 e0 10             	shl    eax,0x10
    710d54a01007:	b9 18 f0 00 00       	mov    ecx,0xf018
    710d54a0100c:	09 c1                	or     ecx,eax
    710d54a0100e:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    710d54a01012:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10066
    710d54a01019:	66 00 01 00 
    710d54a0101d:	0f 84 1c 05 00 18    	je     0x710d6ca0153f
    710d54a01023:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10066
    710d54a0102a:	66 00 01 00 
    710d54a0102e:	0f 84 0b 05 00 18    	je     0x710d6ca0153f
    710d54a01034:	58                   	pop    rax
    710d54a01035:	50                   	push   rax
    710d54a01036:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a0103a:	8d 48 f8             	lea    ecx,[rax-0x8]
    710d54a0103d:	a8 03                	test   al,0x3
    710d54a0103f:	0f 85 5a 05 00 18    	jne    0x710d6ca0159f
    710d54a01045:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a0104c:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    710d54a01050:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01057:	89 ce                	mov    esi,ecx
    710d54a01059:	c1 ee 0c             	shr    esi,0xc
    710d54a0105c:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a01060:	48 85 c0             	test   rax,rax
    710d54a01063:	0f 84 89 05 00 18    	je     0x710d6ca015f2
    710d54a01069:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0106f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01072:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006a
    710d54a01079:	6a 00 01 00 
    710d54a0107d:	0f 84 aa 05 00 18    	je     0x710d6ca0162d
    710d54a01083:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006a
    710d54a0108a:	6a 00 01 00 
    710d54a0108e:	0f 84 99 05 00 18    	je     0x710d6ca0162d
    710d54a01094:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a01097:	0f 85 d1 05 00 18    	jne    0x710d6ca0166e
    710d54a0109d:	58                   	pop    rax
    710d54a0109e:	e9 0f 00 00 00       	jmp    0x710d54a010b2
    710d54a010a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a010aa:	00 
    710d54a010ab:	74 f0                	je     0x710d54a0109d
    710d54a010ad:	e9 24 05 00 18       	jmp    0x710d6ca015d6
    710d54a010b2:	50                   	push   rax
    710d54a010b3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a010b8:	b9 00 00 00 00       	mov    ecx,0x0
    710d54a010bd:	09 c1                	or     ecx,eax
    710d54a010bf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a010c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006c
    710d54a010ca:	6c 00 01 00 
    710d54a010ce:	0f 84 cc 05 00 18    	je     0x710d6ca016a0
    710d54a010d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006c
    710d54a010db:	6c 00 01 00 
    710d54a010df:	0f 84 bb 05 00 18    	je     0x710d6ca016a0
    710d54a010e5:	58                   	pop    rax
    710d54a010e6:	50                   	push   rax
    710d54a010e7:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a010ec:	c1 e0 10             	shl    eax,0x10
    710d54a010ef:	b9 10 f0 00 00       	mov    ecx,0xf010
    710d54a010f4:	09 c1                	or     ecx,eax
    710d54a010f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a010fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10070
    710d54a01101:	70 00 01 00 
    710d54a01105:	0f 84 f5 05 00 18    	je     0x710d6ca01700
    710d54a0110b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10070
    710d54a01112:	70 00 01 00 
    710d54a01116:	0f 84 e4 05 00 18    	je     0x710d6ca01700
    710d54a0111c:	58                   	pop    rax
    710d54a0111d:	50                   	push   rax
    710d54a0111e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a01122:	f6 c1 03             	test   cl,0x3
    710d54a01125:	0f 85 35 06 00 18    	jne    0x710d6ca01760
    710d54a0112b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a01132:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a01136:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a0113d:	48 89 ce             	mov    rsi,rcx
    710d54a01140:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a01144:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a01148:	48 85 c0             	test   rax,rax
    710d54a0114b:	0f 84 62 06 00 18    	je     0x710d6ca017b3
    710d54a01151:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01157:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a0115a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10074
    710d54a01161:	74 00 01 00 
    710d54a01165:	0f 84 83 06 00 18    	je     0x710d6ca017ee
    710d54a0116b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10074
    710d54a01172:	74 00 01 00 
    710d54a01176:	0f 84 72 06 00 18    	je     0x710d6ca017ee
    710d54a0117c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a0117f:	0f 85 aa 06 00 18    	jne    0x710d6ca0182f
    710d54a01185:	58                   	pop    rax
    710d54a01186:	e9 0f 00 00 00       	jmp    0x710d54a0119a
    710d54a0118b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a01192:	00 
    710d54a01193:	74 f0                	je     0x710d54a01185
    710d54a01195:	e9 fd 05 00 18       	jmp    0x710d6ca01797
    710d54a0119a:	50                   	push   rax
    710d54a0119b:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a011a2:	00 
    710d54a011a3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10076
    710d54a011aa:	76 00 01 00 
    710d54a011ae:	0f 84 ad 06 00 18    	je     0x710d6ca01861
    710d54a011b4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10076
    710d54a011bb:	76 00 01 00 
    710d54a011bf:	0f 84 9c 06 00 18    	je     0x710d6ca01861
    710d54a011c5:	58                   	pop    rax
    710d54a011c6:	50                   	push   rax
    710d54a011c7:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    710d54a011cb:	f6 c1 03             	test   cl,0x3
    710d54a011ce:	0f 85 ed 06 00 18    	jne    0x710d6ca018c1
    710d54a011d4:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a011db:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a011df:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a011e6:	48 89 ce             	mov    rsi,rcx
    710d54a011e9:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a011ed:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a011f1:	48 85 c0             	test   rax,rax
    710d54a011f4:	0f 84 1a 07 00 18    	je     0x710d6ca01914
    710d54a011fa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01200:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a01203:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10078
    710d54a0120a:	78 00 01 00 
    710d54a0120e:	0f 84 3b 07 00 18    	je     0x710d6ca0194f
    710d54a01214:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10078
    710d54a0121b:	78 00 01 00 
    710d54a0121f:	0f 84 2a 07 00 18    	je     0x710d6ca0194f
    710d54a01225:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a01228:	0f 85 62 07 00 18    	jne    0x710d6ca01990
    710d54a0122e:	58                   	pop    rax
    710d54a0122f:	e9 0f 00 00 00       	jmp    0x710d54a01243
    710d54a01234:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a0123b:	00 
    710d54a0123c:	74 f0                	je     0x710d54a0122e
    710d54a0123e:	e9 b5 06 00 18       	jmp    0x710d6ca018f8
    710d54a01243:	50                   	push   rax
    710d54a01244:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    710d54a0124b:	00 
    710d54a0124c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007a
    710d54a01253:	7a 00 01 00 
    710d54a01257:	0f 84 65 07 00 18    	je     0x710d6ca019c2
    710d54a0125d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007a
    710d54a01264:	7a 00 01 00 
    710d54a01268:	0f 84 54 07 00 18    	je     0x710d6ca019c2
    710d54a0126e:	58                   	pop    rax
    710d54a0126f:	50                   	push   rax
    710d54a01270:	41 0f b7 45 32       	movzx  eax,WORD PTR [r13+0x32]
    710d54a01275:	c1 e0 10             	shl    eax,0x10
    710d54a01278:	b9 00 00 00 00       	mov    ecx,0x0
    710d54a0127d:	09 c1                	or     ecx,eax
    710d54a0127f:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    710d54a01283:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007c
    710d54a0128a:	7c 00 01 00 
    710d54a0128e:	0f 84 8e 07 00 18    	je     0x710d6ca01a22
    710d54a01294:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007c
    710d54a0129b:	7c 00 01 00 
    710d54a0129f:	0f 84 7d 07 00 18    	je     0x710d6ca01a22
    710d54a012a5:	58                   	pop    rax
    710d54a012a6:	50                   	push   rax
    710d54a012a7:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    710d54a012ae:	00 
    710d54a012af:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10080
    710d54a012b6:	80 00 01 00 
    710d54a012ba:	0f 84 c2 07 00 18    	je     0x710d6ca01a82
    710d54a012c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10080
    710d54a012c7:	80 00 01 00 
    710d54a012cb:	0f 84 b1 07 00 18    	je     0x710d6ca01a82
    710d54a012d1:	58                   	pop    rax
    710d54a012d2:	50                   	push   rax
    710d54a012d3:	41 c7 45 14 01 00 00 	mov    DWORD PTR [r13+0x14],0x1
    710d54a012da:	00 
    710d54a012db:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10082
    710d54a012e2:	82 00 01 00 
    710d54a012e6:	0f 84 f6 07 00 18    	je     0x710d6ca01ae2
    710d54a012ec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10082
    710d54a012f3:	82 00 01 00 
    710d54a012f7:	0f 84 e5 07 00 18    	je     0x710d6ca01ae2
    710d54a012fd:	58                   	pop    rax
    710d54a012fe:	50                   	push   rax
    710d54a012ff:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a01303:	8d 48 fc             	lea    ecx,[rax-0x4]
    710d54a01306:	a8 03                	test   al,0x3
    710d54a01308:	0f 85 34 08 00 18    	jne    0x710d6ca01b42
    710d54a0130e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01315:	89 ca                	mov    edx,ecx
    710d54a01317:	c1 ea 0c             	shr    edx,0xc
    710d54a0131a:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a0131e:	48 85 c0             	test   rax,rax
    710d54a01321:	0f 84 6b 08 00 18    	je     0x710d6ca01b92
    710d54a01327:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0132d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a01330:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    710d54a01337:	58                   	pop    rax
    710d54a01338:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    710d54a0133f:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    710d54a01346:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    710d54a0134d:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    710d54a01351:	50                   	push   rax
    710d54a01352:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    710d54a01356:	8d 48 f8             	lea    ecx,[rax-0x8]
    710d54a01359:	a8 03                	test   al,0x3
    710d54a0135b:	0f 85 6c 08 00 18    	jne    0x710d6ca01bcd
    710d54a01361:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a01368:	89 ca                	mov    edx,ecx
    710d54a0136a:	c1 ea 0c             	shr    edx,0xc
    710d54a0136d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a01371:	48 85 c0             	test   rax,rax
    710d54a01374:	0f 84 a3 08 00 18    	je     0x710d6ca01c1d
    710d54a0137a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a01380:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a01383:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    710d54a01387:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    710d54a0138e:	8c 00 01 00 
    710d54a01392:	0f 84 c0 08 00 18    	je     0x710d6ca01c58
    710d54a01398:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    710d54a0139f:	8c 00 01 00 
    710d54a013a3:	0f 84 af 08 00 18    	je     0x710d6ca01c58
    710d54a013a9:	58                   	pop    rax
    710d54a013aa:	50                   	push   rax
    710d54a013ab:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    710d54a013b2:	b9 8e 00 01 00       	mov    ecx,0x1008e
    710d54a013b7:	83 c1 04             	add    ecx,0x4
    710d54a013ba:	89 ca                	mov    edx,ecx
    710d54a013bc:	3d 8e 00 01 00       	cmp    eax,0x1008e
    710d54a013c1:	75 07                	jne    0x710d54a013ca
    710d54a013c3:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    710d54a013ca:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    710d54a013d1:	02 
    710d54a013d2:	0f 43 ca             	cmovae ecx,edx
    710d54a013d5:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    710d54a013dc:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    710d54a013e3:	89 cf                	mov    edi,ecx
    710d54a013e5:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    710d54a013eb:	75 07                	jne    0x710d54a013f4
    710d54a013ed:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    710d54a013f4:	83 fe 02             	cmp    esi,0x2
    710d54a013f7:	0f 43 cf             	cmovae ecx,edi
    710d54a013fa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    710d54a01401:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a01408:	01 
    710d54a01409:	3d 8e 00 01 00       	cmp    eax,0x1008e
    710d54a0140e:	0f 84 8d 08 00 18    	je     0x710d6ca01ca1
    710d54a01414:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    710d54a0141a:	0f 84 81 08 00 18    	je     0x710d6ca01ca1
    710d54a01420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d54a01427:	28 03 01 00 
    710d54a0142b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d54a01432:	04 00 00 00 
    710d54a01436:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    710d54a0143d:	1c 00 00 00 
    710d54a01441:	58                   	pop    rax
    710d54a01442:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a01449:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a01450:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a01457:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a0145e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a01465:	39 f1                	cmp    ecx,esi
    710d54a01467:	0f 83 6c 08 00 18    	jae    0x710d6ca01cd9
    710d54a0146d:	81 fa 40 00 01 00    	cmp    edx,0x10040
    710d54a01473:	75 14                	jne    0x710d54a01489
    710d54a01475:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a0147c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a01483:	00 
    710d54a01484:	e9 10 f8 ff ff       	jmp    0x710d54a00c99
    710d54a01489:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a01490:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a01496:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a01499:	0f 85 3a 08 00 18    	jne    0x710d6ca01cd9
    710d54a0149f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a014a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a014ad:	00 
    710d54a014ae:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a014b3:	ff e0                	jmp    rax
