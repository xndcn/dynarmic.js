
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65692-1-124302068307792.bin:     file format binary


Disassembly of section .data:

0000710d54a05750 <.data>:
    710d54a05750:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a05757:	8b 88 3c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10003c]
    710d54a0575d:	ff c1                	inc    ecx
    710d54a0575f:	89 88 3c 00 10 00    	mov    DWORD PTR [rax+0x10003c],ecx
    710d54a05765:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0576b:	0f 84 7f 12 00 18    	je     0x710d6ca069f0
    710d54a05771:	50                   	push   rax
    710d54a05772:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    710d54a05776:	f6 c1 03             	test   cl,0x3
    710d54a05779:	0f 85 9d 12 00 18    	jne    0x710d6ca06a1c
    710d54a0577f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a05786:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    710d54a0578a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a05791:	48 89 ce             	mov    rsi,rcx
    710d54a05794:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a05798:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a0579c:	48 85 c0             	test   rax,rax
    710d54a0579f:	0f 84 ca 12 00 18    	je     0x710d6ca06a6f
    710d54a057a5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a057ab:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a057ae:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009c
    710d54a057b5:	9c 00 01 00 
    710d54a057b9:	0f 84 eb 12 00 18    	je     0x710d6ca06aaa
    710d54a057bf:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009c
    710d54a057c6:	9c 00 01 00 
    710d54a057ca:	0f 84 da 12 00 18    	je     0x710d6ca06aaa
    710d54a057d0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a057d3:	0f 85 12 13 00 18    	jne    0x710d6ca06aeb
    710d54a057d9:	58                   	pop    rax
    710d54a057da:	e9 0f 00 00 00       	jmp    0x710d54a057ee
    710d54a057df:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a057e6:	00 
    710d54a057e7:	74 f0                	je     0x710d54a057d9
    710d54a057e9:	e9 65 12 00 18       	jmp    0x710d6ca06a53
    710d54a057ee:	50                   	push   rax
    710d54a057ef:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    710d54a057f3:	f6 c3 03             	test   bl,0x3
    710d54a057f6:	0f 85 21 13 00 18    	jne    0x710d6ca06b1d
    710d54a057fc:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    710d54a05803:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a05807:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a0580e:	48 89 d9             	mov    rcx,rbx
    710d54a05811:	48 c1 e9 0c          	shr    rcx,0xc
    710d54a05815:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    710d54a05819:	48 85 c0             	test   rax,rax
    710d54a0581c:	0f 84 50 13 00 18    	je     0x710d6ca06b72
    710d54a05822:	89 d9                	mov    ecx,ebx
    710d54a05824:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a0582a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a0582d:	83 c3 04             	add    ebx,0x4
    710d54a05830:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    710d54a05834:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009e
    710d54a0583b:	9e 00 01 00 
    710d54a0583f:	0f 84 68 13 00 18    	je     0x710d6ca06bad
    710d54a05845:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009e
    710d54a0584c:	9e 00 01 00 
    710d54a05850:	0f 84 57 13 00 18    	je     0x710d6ca06bad
    710d54a05856:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    710d54a0585a:	0f 85 8f 13 00 18    	jne    0x710d6ca06bef
    710d54a05860:	58                   	pop    rax
    710d54a05861:	e9 0f 00 00 00       	jmp    0x710d54a05875
    710d54a05866:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a0586d:	00 
    710d54a0586e:	74 f0                	je     0x710d54a05860
    710d54a05870:	e9 e1 12 00 18       	jmp    0x710d6ca06b56
    710d54a05875:	50                   	push   rax
    710d54a05876:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    710d54a0587a:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a05881:	31 d2                	xor    edx,edx
    710d54a05883:	89 c6                	mov    esi,eax
    710d54a05885:	ff c6                	inc    esi
    710d54a05887:	0f 94 c2             	sete   dl
    710d54a0588a:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    710d54a0588e:	c1 e8 1f             	shr    eax,0x1f
    710d54a05891:	89 f7                	mov    edi,esi
    710d54a05893:	c1 ef 1f             	shr    edi,0x1f
    710d54a05896:	f7 d0                	not    eax
    710d54a05898:	21 f8                	and    eax,edi
    710d54a0589a:	31 db                	xor    ebx,ebx
    710d54a0589c:	85 f6                	test   esi,esi
    710d54a0589e:	0f 94 c3             	sete   bl
    710d54a058a1:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    710d54a058a8:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    710d54a058af:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    710d54a058b6:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    710d54a058bd:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    710d54a058c4:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    710d54a058cb:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    710d54a058d2:	81 f9 a0 00 01 00    	cmp    ecx,0x100a0
    710d54a058d8:	0f 84 43 13 00 18    	je     0x710d6ca06c21
    710d54a058de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a0
    710d54a058e5:	a0 00 01 00 
    710d54a058e9:	0f 84 32 13 00 18    	je     0x710d6ca06c21
    710d54a058ef:	58                   	pop    rax
    710d54a058f0:	50                   	push   rax
    710d54a058f1:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    710d54a058f8:	00 
    710d54a058f9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a2
    710d54a05900:	a2 00 01 00 
    710d54a05904:	0f 84 77 13 00 18    	je     0x710d6ca06c81
    710d54a0590a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a2
    710d54a05911:	a2 00 01 00 
    710d54a05915:	0f 84 66 13 00 18    	je     0x710d6ca06c81
    710d54a0591b:	58                   	pop    rax
    710d54a0591c:	50                   	push   rax
    710d54a0591d:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    710d54a05921:	f6 c1 03             	test   cl,0x3
    710d54a05924:	0f 85 b7 13 00 18    	jne    0x710d6ca06ce1
    710d54a0592a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a05931:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    710d54a05935:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a0593c:	48 89 ce             	mov    rsi,rcx
    710d54a0593f:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a05943:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a05947:	48 85 c0             	test   rax,rax
    710d54a0594a:	0f 84 e4 13 00 18    	je     0x710d6ca06d34
    710d54a05950:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05956:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a05959:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a4
    710d54a05960:	a4 00 01 00 
    710d54a05964:	0f 84 05 14 00 18    	je     0x710d6ca06d6f
    710d54a0596a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a4
    710d54a05971:	a4 00 01 00 
    710d54a05975:	0f 84 f4 13 00 18    	je     0x710d6ca06d6f
    710d54a0597b:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a0597e:	0f 85 2c 14 00 18    	jne    0x710d6ca06db0
    710d54a05984:	58                   	pop    rax
    710d54a05985:	e9 0f 00 00 00       	jmp    0x710d54a05999
    710d54a0598a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a05991:	00 
    710d54a05992:	74 f0                	je     0x710d54a05984
    710d54a05994:	e9 7f 13 00 18       	jmp    0x710d6ca06d18
    710d54a05999:	50                   	push   rax
    710d54a0599a:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a0599e:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    710d54a059a2:	31 d2                	xor    edx,edx
    710d54a059a4:	31 f6                	xor    esi,esi
    710d54a059a6:	89 cf                	mov    edi,ecx
    710d54a059a8:	29 c7                	sub    edi,eax
    710d54a059aa:	0f 94 c2             	sete   dl
    710d54a059ad:	40 0f 93 c6          	setae  sil
    710d54a059b1:	c1 ef 1f             	shr    edi,0x1f
    710d54a059b4:	c1 e9 1f             	shr    ecx,0x1f
    710d54a059b7:	c1 e8 1f             	shr    eax,0x1f
    710d54a059ba:	89 fb                	mov    ebx,edi
    710d54a059bc:	31 cb                	xor    ebx,ecx
    710d54a059be:	31 c8                	xor    eax,ecx
    710d54a059c0:	21 d8                	and    eax,ebx
    710d54a059c2:	31 f8                	xor    eax,edi
    710d54a059c4:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    710d54a059cb:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    710d54a059d2:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    710d54a059d9:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    710d54a059e0:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    710d54a059e7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a6
    710d54a059ee:	a6 00 01 00 
    710d54a059f2:	0f 84 ea 13 00 18    	je     0x710d6ca06de2
    710d54a059f8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a6
    710d54a059ff:	a6 00 01 00 
    710d54a05a03:	0f 84 d9 13 00 18    	je     0x710d6ca06de2
    710d54a05a09:	58                   	pop    rax
    710d54a05a0a:	50                   	push   rax
    710d54a05a0b:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    710d54a05a12:	00 
    710d54a05a13:	74 28                	je     0x710d54a05a3d
    710d54a05a15:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    710d54a05a1c:	a8 00 01 00 
    710d54a05a20:	0f 84 1c 14 00 18    	je     0x710d6ca06e42
    710d54a05a26:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    710d54a05a2d:	a8 00 01 00 
    710d54a05a31:	0f 84 0b 14 00 18    	je     0x710d6ca06e42
    710d54a05a37:	58                   	pop    rax
    710d54a05a38:	e9 55 00 00 00       	jmp    0x710d54a05a92
    710d54a05a3d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a05a44:	01 
    710d54a05a45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    710d54a05a4c:	a8 00 01 00 
    710d54a05a50:	0f 84 35 14 00 18    	je     0x710d6ca06e8b
    710d54a05a56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    710d54a05a5d:	a8 00 01 00 
    710d54a05a61:	0f 84 24 14 00 18    	je     0x710d6ca06e8b
    710d54a05a67:	b8 a8 00 01 00       	mov    eax,0x100a8
    710d54a05a6c:	83 c0 dc             	add    eax,0xffffffdc
    710d54a05a6f:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a05a76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a05a7d:	02 00 00 00 
    710d54a05a81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    710d54a05a88:	07 00 00 00 
    710d54a05a8c:	58                   	pop    rax
    710d54a05a8d:	e9 5b 03 00 00       	jmp    0x710d54a05ded
    710d54a05a92:	50                   	push   rax
    710d54a05a93:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    710d54a05a98:	b9 00 00 00 00       	mov    ecx,0x0
    710d54a05a9d:	09 c1                	or     ecx,eax
    710d54a05a9f:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a05aa3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100aa
    710d54a05aaa:	aa 00 01 00 
    710d54a05aae:	0f 84 13 14 00 18    	je     0x710d6ca06ec7
    710d54a05ab4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100aa
    710d54a05abb:	aa 00 01 00 
    710d54a05abf:	0f 84 02 14 00 18    	je     0x710d6ca06ec7
    710d54a05ac5:	58                   	pop    rax
    710d54a05ac6:	50                   	push   rax
    710d54a05ac7:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    710d54a05ace:	00 
    710d54a05acf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ae
    710d54a05ad6:	ae 00 01 00 
    710d54a05ada:	0f 84 47 14 00 18    	je     0x710d6ca06f27
    710d54a05ae0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ae
    710d54a05ae7:	ae 00 01 00 
    710d54a05aeb:	0f 84 36 14 00 18    	je     0x710d6ca06f27
    710d54a05af1:	58                   	pop    rax
    710d54a05af2:	50                   	push   rax
    710d54a05af3:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    710d54a05af8:	c1 e0 10             	shl    eax,0x10
    710d54a05afb:	b9 10 f0 00 00       	mov    ecx,0xf010
    710d54a05b00:	09 c1                	or     ecx,eax
    710d54a05b02:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    710d54a05b06:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b0
    710d54a05b0d:	b0 00 01 00 
    710d54a05b11:	0f 84 70 14 00 18    	je     0x710d6ca06f87
    710d54a05b17:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b0
    710d54a05b1e:	b0 00 01 00 
    710d54a05b22:	0f 84 5f 14 00 18    	je     0x710d6ca06f87
    710d54a05b28:	58                   	pop    rax
    710d54a05b29:	50                   	push   rax
    710d54a05b2a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a05b2e:	f6 c1 03             	test   cl,0x3
    710d54a05b31:	0f 85 b0 14 00 18    	jne    0x710d6ca06fe7
    710d54a05b37:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    710d54a05b3e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    710d54a05b42:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a05b49:	48 89 ce             	mov    rsi,rcx
    710d54a05b4c:	48 c1 ee 0c          	shr    rsi,0xc
    710d54a05b50:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    710d54a05b54:	48 85 c0             	test   rax,rax
    710d54a05b57:	0f 84 dd 14 00 18    	je     0x710d6ca0703a
    710d54a05b5d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05b63:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    710d54a05b66:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b4
    710d54a05b6d:	b4 00 01 00 
    710d54a05b71:	0f 84 fe 14 00 18    	je     0x710d6ca07075
    710d54a05b77:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b4
    710d54a05b7e:	b4 00 01 00 
    710d54a05b82:	0f 84 ed 14 00 18    	je     0x710d6ca07075
    710d54a05b88:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d54a05b8b:	0f 85 25 15 00 18    	jne    0x710d6ca070b6
    710d54a05b91:	58                   	pop    rax
    710d54a05b92:	e9 0f 00 00 00       	jmp    0x710d54a05ba6
    710d54a05b97:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d54a05b9e:	00 
    710d54a05b9f:	74 f0                	je     0x710d54a05b91
    710d54a05ba1:	e9 78 14 00 18       	jmp    0x710d6ca0701e
    710d54a05ba6:	50                   	push   rax
    710d54a05ba7:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    710d54a05bab:	f6 c3 03             	test   bl,0x3
    710d54a05bae:	0f 85 34 15 00 18    	jne    0x710d6ca070e8
    710d54a05bb4:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a05bbb:	48 89 d8             	mov    rax,rbx
    710d54a05bbe:	48 c1 e8 0c          	shr    rax,0xc
    710d54a05bc2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05bc7:	48 85 c0             	test   rax,rax
    710d54a05bca:	0f 84 6a 15 00 18    	je     0x710d6ca0713a
    710d54a05bd0:	89 d9                	mov    ecx,ebx
    710d54a05bd2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05bd8:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    710d54a05bdc:	89 de                	mov    esi,ebx
    710d54a05bde:	83 c6 04             	add    esi,0x4
    710d54a05be1:	89 f0                	mov    eax,esi
    710d54a05be3:	c1 e8 0c             	shr    eax,0xc
    710d54a05be6:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05beb:	48 85 c0             	test   rax,rax
    710d54a05bee:	0f 84 83 15 00 18    	je     0x710d6ca07177
    710d54a05bf4:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05bfa:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05bfd:	8d 4b 08             	lea    ecx,[rbx+0x8]
    710d54a05c00:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    710d54a05c04:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    710d54a05c0b:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    710d54a05c0f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b6
    710d54a05c16:	b6 00 01 00 
    710d54a05c1a:	0f 84 93 15 00 18    	je     0x710d6ca071b3
    710d54a05c20:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b6
    710d54a05c27:	b6 00 01 00 
    710d54a05c2b:	0f 84 82 15 00 18    	je     0x710d6ca071b3
    710d54a05c31:	58                   	pop    rax
    710d54a05c32:	50                   	push   rax
    710d54a05c33:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    710d54a05c3a:	00 
    710d54a05c3b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ba
    710d54a05c42:	ba 00 01 00 
    710d54a05c46:	0f 84 b0 15 00 18    	je     0x710d6ca071fc
    710d54a05c4c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ba
    710d54a05c53:	ba 00 01 00 
    710d54a05c57:	0f 84 9f 15 00 18    	je     0x710d6ca071fc
    710d54a05c5d:	58                   	pop    rax
    710d54a05c5e:	50                   	push   rax
    710d54a05c5f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    710d54a05c63:	f6 c3 03             	test   bl,0x3
    710d54a05c66:	0f 85 f0 15 00 18    	jne    0x710d6ca0725c
    710d54a05c6c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    710d54a05c73:	48 89 d8             	mov    rax,rbx
    710d54a05c76:	48 c1 e8 0c          	shr    rax,0xc
    710d54a05c7a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05c7f:	48 85 c0             	test   rax,rax
    710d54a05c82:	0f 84 26 16 00 18    	je     0x710d6ca072ae
    710d54a05c88:	89 d9                	mov    ecx,ebx
    710d54a05c8a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a05c90:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a05c93:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    710d54a05c97:	8d 73 04             	lea    esi,[rbx+0x4]
    710d54a05c9a:	89 f0                	mov    eax,esi
    710d54a05c9c:	c1 e8 0c             	shr    eax,0xc
    710d54a05c9f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05ca4:	48 85 c0             	test   rax,rax
    710d54a05ca7:	0f 84 3c 16 00 18    	je     0x710d6ca072e9
    710d54a05cad:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05cb3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05cb6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    710d54a05cba:	8d 73 08             	lea    esi,[rbx+0x8]
    710d54a05cbd:	89 f0                	mov    eax,esi
    710d54a05cbf:	c1 e8 0c             	shr    eax,0xc
    710d54a05cc2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05cc7:	48 85 c0             	test   rax,rax
    710d54a05cca:	0f 84 55 16 00 18    	je     0x710d6ca07325
    710d54a05cd0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05cd6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05cd9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    710d54a05cdd:	8d 73 0c             	lea    esi,[rbx+0xc]
    710d54a05ce0:	89 f0                	mov    eax,esi
    710d54a05ce2:	c1 e8 0c             	shr    eax,0xc
    710d54a05ce5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05cea:	48 85 c0             	test   rax,rax
    710d54a05ced:	0f 84 6e 16 00 18    	je     0x710d6ca07361
    710d54a05cf3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05cf9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05cfc:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    710d54a05d00:	8d 73 10             	lea    esi,[rbx+0x10]
    710d54a05d03:	89 f0                	mov    eax,esi
    710d54a05d05:	c1 e8 0c             	shr    eax,0xc
    710d54a05d08:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05d0d:	48 85 c0             	test   rax,rax
    710d54a05d10:	0f 84 87 16 00 18    	je     0x710d6ca0739d
    710d54a05d16:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05d1c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05d1f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    710d54a05d23:	8d 73 14             	lea    esi,[rbx+0x14]
    710d54a05d26:	89 f0                	mov    eax,esi
    710d54a05d28:	c1 e8 0c             	shr    eax,0xc
    710d54a05d2b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05d30:	48 85 c0             	test   rax,rax
    710d54a05d33:	0f 84 a0 16 00 18    	je     0x710d6ca073d9
    710d54a05d39:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05d3f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05d42:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    710d54a05d46:	89 de                	mov    esi,ebx
    710d54a05d48:	83 c6 18             	add    esi,0x18
    710d54a05d4b:	89 f0                	mov    eax,esi
    710d54a05d4d:	c1 e8 0c             	shr    eax,0xc
    710d54a05d50:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    710d54a05d55:	48 85 c0             	test   rax,rax
    710d54a05d58:	0f 84 b7 16 00 18    	je     0x710d6ca07415
    710d54a05d5e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    710d54a05d64:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    710d54a05d67:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    710d54a05d6b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    710d54a05d6e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    710d54a05d72:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100bc
    710d54a05d79:	bc 00 01 00 
    710d54a05d7d:	0f 84 ce 16 00 18    	je     0x710d6ca07451
    710d54a05d83:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100bc
    710d54a05d8a:	bc 00 01 00 
    710d54a05d8e:	0f 84 bd 16 00 18    	je     0x710d6ca07451
    710d54a05d94:	58                   	pop    rax
    710d54a05d95:	50                   	push   rax
    710d54a05d96:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    710d54a05d9d:	a8 01                	test   al,0x1
    710d54a05d9f:	0f 85 f5 16 00 18    	jne    0x710d6ca0749a
    710d54a05da5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a05dac:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a05db3:	01 
    710d54a05db4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100be
    710d54a05dbb:	be 00 01 00 
    710d54a05dbf:	0f 84 0b 17 00 18    	je     0x710d6ca074d0
    710d54a05dc5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100be
    710d54a05dcc:	be 00 01 00 
    710d54a05dd0:	0f 84 fa 16 00 18    	je     0x710d6ca074d0
    710d54a05dd6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a05ddd:	02 00 00 00 
    710d54a05de1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    710d54a05de8:	0f 00 00 00 
    710d54a05dec:	58                   	pop    rax
    710d54a05ded:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a05df4:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a05dfb:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a05e02:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a05e09:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a05e10:	39 f1                	cmp    ecx,esi
    710d54a05e12:	0f 83 e5 16 00 18    	jae    0x710d6ca074fd
    710d54a05e18:	81 fa 9c 00 01 00    	cmp    edx,0x1009c
    710d54a05e1e:	75 14                	jne    0x710d54a05e34
    710d54a05e20:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a05e27:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a05e2e:	00 
    710d54a05e2f:	e9 1c f9 ff ff       	jmp    0x710d54a05750
    710d54a05e34:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a05e3b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a05e41:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a05e44:	0f 85 b3 16 00 18    	jne    0x710d6ca074fd
    710d54a05e4a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a05e51:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a05e58:	00 
    710d54a05e59:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a05e5e:	ff e0                	jmp    rax
