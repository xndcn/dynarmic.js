
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65668-1-124302470968576.bin:     file format binary


Disassembly of section .data:

0000710d6ca07500 <.data>:
    710d6ca07500:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    710d6ca07507:	84 00 01 00 
    710d6ca0750b:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    710d6ca07512:	01 
    710d6ca07513:	c2 08 00             	ret    0x8
    710d6ca07516:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca0751c:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca0751f:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca07525:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca0752c:	0f 87 98 e9 ff e7    	ja     0x710d54a05eca
    710d6ca07532:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x10
    710d6ca07539:	10 00 00 00 
    710d6ca0753d:	e9 88 e9 ff e7       	jmp    0x710d54a05eca
    710d6ca07542:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    710d6ca07549:	84 00 01 00 
    710d6ca0754d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca07554:	08 00 00 00 
    710d6ca07558:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca0755f:	01 00 00 00 
    710d6ca07563:	ba 84 00 01 00       	mov    edx,0x10084
    710d6ca07568:	4c 89 ef             	mov    rdi,r13
    710d6ca0756b:	4c 89 f6             	mov    rsi,r14
    710d6ca0756e:	45 31 c0             	xor    r8d,r8d
    710d6ca07571:	e8 0a 8b ff e7       	call   0x710d54a00080
    710d6ca07576:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca0757d:	08 00 00 00 
    710d6ca07581:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca07588:	01 00 00 00 
    710d6ca0758c:	58                   	pop    rax
    710d6ca0758d:	e9 7c ea ff e7       	jmp    0x710d54a0600e
    710d6ca07592:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    710d6ca07599:	84 00 01 00 
    710d6ca0759d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    710d6ca075a4:	08 00 00 00 
    710d6ca075a8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca075af:	01 00 00 00 
    710d6ca075b3:	4c 89 f7             	mov    rdi,r14
    710d6ca075b6:	89 ce                	mov    esi,ecx
    710d6ca075b8:	e8 83 8a ff e7       	call   0x710d54a00040
    710d6ca075bd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca075c4:	00 
    710d6ca075c5:	0f 84 31 e9 ff e7    	je     0x710d54a05efc
    710d6ca075cb:	eb a9                	jmp    0x710d6ca07576
    710d6ca075cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca075d4:	8c 00 01 00 
    710d6ca075d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca075df:	02 00 00 00 
    710d6ca075e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca075ea:	02 00 00 00 
    710d6ca075ee:	ba 8c 00 01 00       	mov    edx,0x1008c
    710d6ca075f3:	4c 89 ef             	mov    rdi,r13
    710d6ca075f6:	4c 89 f6             	mov    rsi,r14
    710d6ca075f9:	45 31 c0             	xor    r8d,r8d
    710d6ca075fc:	e8 7f 8a ff e7       	call   0x710d54a00080
    710d6ca07601:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca07608:	02 00 00 00 
    710d6ca0760c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca07613:	02 00 00 00 
    710d6ca07617:	58                   	pop    rax
    710d6ca07618:	e9 f1 e9 ff e7       	jmp    0x710d54a0600e
    710d6ca0761d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca07624:	8c 00 01 00 
    710d6ca07628:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0762f:	02 00 00 00 
    710d6ca07633:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0763a:	02 00 00 00 
    710d6ca0763e:	4c 89 f7             	mov    rdi,r14
    710d6ca07641:	89 ce                	mov    esi,ecx
    710d6ca07643:	e8 f8 89 ff e7       	call   0x710d54a00040
    710d6ca07648:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0764f:	00 
    710d6ca07650:	0f 84 f9 e8 ff e7    	je     0x710d54a05f4f
    710d6ca07656:	eb a9                	jmp    0x710d6ca07601
    710d6ca07658:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    710d6ca0765f:	8c 00 01 00 
    710d6ca07663:	b8 8c 00 01 00       	mov    eax,0x1008c
    710d6ca07668:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0766f:	02 00 00 00 
    710d6ca07673:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0767a:	02 00 00 00 
    710d6ca0767e:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca07681:	be 8c 00 01 00       	mov    esi,0x1008c
    710d6ca07686:	4c 89 ef             	mov    rdi,r13
    710d6ca07689:	e8 d2 8a ff e7       	call   0x710d54a00160
    710d6ca0768e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca07695:	00 
    710d6ca07696:	0f 84 d9 e8 ff e7    	je     0x710d54a05f75
    710d6ca0769c:	e9 60 ff ff ff       	jmp    0x710d6ca07601
    710d6ca076a1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    710d6ca076a8:	28 03 01 00 
    710d6ca076ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca076b3:	04 00 00 00 
    710d6ca076b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca076be:	03 00 00 00 
    710d6ca076c2:	be 8e 00 01 00       	mov    esi,0x1008e
    710d6ca076c7:	ba 8e 00 01 00       	mov    edx,0x1008e
    710d6ca076cc:	4c 89 ef             	mov    rdi,r13
    710d6ca076cf:	e8 8c 8a ff e7       	call   0x710d54a00160
    710d6ca076d4:	e9 13 e9 ff e7       	jmp    0x710d54a05fec
    710d6ca076d9:	c2 08 00             	ret    0x8
