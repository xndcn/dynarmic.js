
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-65682-1-124302470956976.bin:     file format binary


Disassembly of section .data:

0000710d6ca047b0 <.data>:
    710d6ca047b0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca047b6:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca047b9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca047bf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca047c6:	0f 87 65 eb ff e7    	ja     0x710d54a03331
    710d6ca047cc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x9
    710d6ca047d3:	09 00 00 00 
    710d6ca047d7:	e9 55 eb ff e7       	jmp    0x710d54a03331
    710d6ca047dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10092
    710d6ca047e3:	92 00 01 00 
    710d6ca047e7:	b8 92 00 01 00       	mov    eax,0x10092
    710d6ca047ec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca047f3:	02 00 00 00 
    710d6ca047f7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca047fe:	01 00 00 00 
    710d6ca04802:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04805:	be 92 00 01 00       	mov    esi,0x10092
    710d6ca0480a:	4c 89 ef             	mov    rdi,r13
    710d6ca0480d:	e8 4e b9 ff e7       	call   0x710d54a00160
    710d6ca04812:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04819:	00 
    710d6ca0481a:	0f 84 6a eb ff e7    	je     0x710d54a0338a
    710d6ca04820:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04827:	02 00 00 00 
    710d6ca0482b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04832:	01 00 00 00 
    710d6ca04836:	58                   	pop    rax
    710d6ca04837:	e9 ec ec ff e7       	jmp    0x710d54a03528
    710d6ca0483c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10094
    710d6ca04843:	94 00 01 00 
    710d6ca04847:	b8 94 00 01 00       	mov    eax,0x10094
    710d6ca0484c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04853:	02 00 00 00 
    710d6ca04857:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0485e:	02 00 00 00 
    710d6ca04862:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04865:	be 94 00 01 00       	mov    esi,0x10094
    710d6ca0486a:	4c 89 ef             	mov    rdi,r13
    710d6ca0486d:	e8 ee b8 ff e7       	call   0x710d54a00160
    710d6ca04872:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04879:	00 
    710d6ca0487a:	0f 84 38 eb ff e7    	je     0x710d54a033b8
    710d6ca04880:	e9 72 eb ff e7       	jmp    0x710d54a033f7
    710d6ca04885:	b8 94 00 01 00       	mov    eax,0x10094
    710d6ca0488a:	83 c0 2c             	add    eax,0x2c
    710d6ca0488d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca04894:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0489b:	02 00 00 00 
    710d6ca0489f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca048a6:	02 00 00 00 
    710d6ca048aa:	be 94 00 01 00       	mov    esi,0x10094
    710d6ca048af:	ba 94 00 01 00       	mov    edx,0x10094
    710d6ca048b4:	4c 89 ef             	mov    rdi,r13
    710d6ca048b7:	e8 a4 b8 ff e7       	call   0x710d54a00160
    710d6ca048bc:	e9 27 eb ff e7       	jmp    0x710d54a033e8
    710d6ca048c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    710d6ca048c8:	96 00 01 00 
    710d6ca048cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca048d3:	02 00 00 00 
    710d6ca048d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca048de:	03 00 00 00 
    710d6ca048e2:	ba 96 00 01 00       	mov    edx,0x10096
    710d6ca048e7:	4c 89 ef             	mov    rdi,r13
    710d6ca048ea:	4c 89 f6             	mov    rsi,r14
    710d6ca048ed:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d6ca048f3:	e8 88 b7 ff e7       	call   0x710d54a00080
    710d6ca048f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca048ff:	02 00 00 00 
    710d6ca04903:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca0490a:	03 00 00 00 
    710d6ca0490e:	58                   	pop    rax
    710d6ca0490f:	e9 14 ec ff e7       	jmp    0x710d54a03528
    710d6ca04914:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    710d6ca0491b:	96 00 01 00 
    710d6ca0491f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04926:	02 00 00 00 
    710d6ca0492a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04931:	03 00 00 00 
    710d6ca04935:	4c 89 f7             	mov    rdi,r14
    710d6ca04938:	89 ce                	mov    esi,ecx
    710d6ca0493a:	e8 31 b7 ff e7       	call   0x710d54a00070
    710d6ca0493f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04946:	00 
    710d6ca04947:	0f 84 03 eb ff e7    	je     0x710d54a03450
    710d6ca0494d:	eb a9                	jmp    0x710d6ca048f8
    710d6ca0494f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    710d6ca04956:	96 00 01 00 
    710d6ca0495a:	b8 96 00 01 00       	mov    eax,0x10096
    710d6ca0495f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04966:	02 00 00 00 
    710d6ca0496a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04971:	03 00 00 00 
    710d6ca04975:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04978:	be 96 00 01 00       	mov    esi,0x10096
    710d6ca0497d:	4c 89 ef             	mov    rdi,r13
    710d6ca04980:	e8 db b7 ff e7       	call   0x710d54a00160
    710d6ca04985:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    710d6ca04988:	0f 84 f3 ea ff e7    	je     0x710d54a03481
    710d6ca0498e:	eb 0f                	jmp    0x710d6ca0499f
    710d6ca04990:	b8 96 00 01 00       	mov    eax,0x10096
    710d6ca04995:	83 c0 02             	add    eax,0x2
    710d6ca04998:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0499f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca049a6:	02 00 00 00 
    710d6ca049aa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca049b1:	03 00 00 00 
    710d6ca049b5:	4c 89 ef             	mov    rdi,r13
    710d6ca049b8:	e8 93 b7 ff e7       	call   0x710d54a00150
    710d6ca049bd:	e9 bf ea ff e7       	jmp    0x710d54a03481
    710d6ca049c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    710d6ca049c9:	28 04 01 00 
    710d6ca049cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca049d4:	04 00 00 00 
    710d6ca049d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca049df:	04 00 00 00 
    710d6ca049e3:	be 98 00 01 00       	mov    esi,0x10098
    710d6ca049e8:	ba 98 00 01 00       	mov    edx,0x10098
    710d6ca049ed:	4c 89 ef             	mov    rdi,r13
    710d6ca049f0:	e8 6b b7 ff e7       	call   0x710d54a00160
    710d6ca049f5:	e9 0c eb ff e7       	jmp    0x710d54a03506
    710d6ca049fa:	c2 08 00             	ret    0x8
