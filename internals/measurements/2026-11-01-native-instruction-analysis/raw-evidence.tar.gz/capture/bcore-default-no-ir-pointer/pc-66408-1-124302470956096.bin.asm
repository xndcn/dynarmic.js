
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66408-1-124302470956096.bin:     file format binary


Disassembly of section .data:

0000710d6ca04440 <.data>:
    710d6ca04440:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca04446:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca04449:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca0444f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca04456:	0f 87 65 ec ff e7    	ja     0x710d54a030c1
    710d6ca0445c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x8
    710d6ca04463:	08 00 00 00 
    710d6ca04467:	e9 55 ec ff e7       	jmp    0x710d54a030c1
    710d6ca0446c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca04473:	68 03 01 00 
    710d6ca04477:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0447e:	04 00 00 00 
    710d6ca04482:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04489:	01 00 00 00 
    710d6ca0448d:	ba 68 03 01 00       	mov    edx,0x10368
    710d6ca04492:	4c 89 ef             	mov    rdi,r13
    710d6ca04495:	4c 89 f6             	mov    rsi,r14
    710d6ca04498:	89 d9                	mov    ecx,ebx
    710d6ca0449a:	45 31 c0             	xor    r8d,r8d
    710d6ca0449d:	e8 de bb ff e7       	call   0x710d54a00080
    710d6ca044a2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca044a9:	04 00 00 00 
    710d6ca044ad:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca044b4:	01 00 00 00 
    710d6ca044b8:	58                   	pop    rax
    710d6ca044b9:	e9 d8 ed ff e7       	jmp    0x710d54a03296
    710d6ca044be:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca044c5:	68 03 01 00 
    710d6ca044c9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca044d0:	04 00 00 00 
    710d6ca044d4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca044db:	01 00 00 00 
    710d6ca044df:	4c 89 f7             	mov    rdi,r14
    710d6ca044e2:	89 de                	mov    esi,ebx
    710d6ca044e4:	e8 57 bb ff e7       	call   0x710d54a00040
    710d6ca044e9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca044f0:	00 
    710d6ca044f1:	75 af                	jne    0x710d6ca044a2
    710d6ca044f3:	41 89 c7             	mov    r15d,eax
    710d6ca044f6:	e9 fc eb ff e7       	jmp    0x710d54a030f7
    710d6ca044fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca04502:	68 03 01 00 
    710d6ca04506:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0450d:	04 00 00 00 
    710d6ca04511:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04518:	01 00 00 00 
    710d6ca0451c:	4c 89 f7             	mov    rdi,r14
    710d6ca0451f:	e8 1c bb ff e7       	call   0x710d54a00040
    710d6ca04524:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0452b:	00 
    710d6ca0452c:	0f 84 e6 eb ff e7    	je     0x710d54a03118
    710d6ca04532:	e9 6b ff ff ff       	jmp    0x710d6ca044a2
    710d6ca04537:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    710d6ca0453e:	68 03 01 00 
    710d6ca04542:	b8 68 03 01 00       	mov    eax,0x10368
    710d6ca04547:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca0454e:	04 00 00 00 
    710d6ca04552:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca04559:	01 00 00 00 
    710d6ca0455d:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca04560:	be 68 03 01 00       	mov    esi,0x10368
    710d6ca04565:	4c 89 ef             	mov    rdi,r13
    710d6ca04568:	e8 f3 bb ff e7       	call   0x710d54a00160
    710d6ca0456d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04574:	00 
    710d6ca04575:	0f 84 d1 eb ff e7    	je     0x710d54a0314c
    710d6ca0457b:	e9 22 ff ff ff       	jmp    0x710d6ca044a2
    710d6ca04580:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca04587:	6c 03 01 00 
    710d6ca0458b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04592:	02 00 00 00 
    710d6ca04596:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0459d:	02 00 00 00 
    710d6ca045a1:	ba 6c 03 01 00       	mov    edx,0x1036c
    710d6ca045a6:	4c 89 ef             	mov    rdi,r13
    710d6ca045a9:	4c 89 f6             	mov    rsi,r14
    710d6ca045ac:	89 d9                	mov    ecx,ebx
    710d6ca045ae:	45 31 c0             	xor    r8d,r8d
    710d6ca045b1:	e8 ca ba ff e7       	call   0x710d54a00080
    710d6ca045b6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca045bd:	02 00 00 00 
    710d6ca045c1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca045c8:	02 00 00 00 
    710d6ca045cc:	58                   	pop    rax
    710d6ca045cd:	e9 c4 ec ff e7       	jmp    0x710d54a03296
    710d6ca045d2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca045d9:	6c 03 01 00 
    710d6ca045dd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca045e4:	02 00 00 00 
    710d6ca045e8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca045ef:	02 00 00 00 
    710d6ca045f3:	4c 89 f7             	mov    rdi,r14
    710d6ca045f6:	89 de                	mov    esi,ebx
    710d6ca045f8:	e8 43 ba ff e7       	call   0x710d54a00040
    710d6ca045fd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04604:	00 
    710d6ca04605:	0f 84 77 eb ff e7    	je     0x710d54a03182
    710d6ca0460b:	eb a9                	jmp    0x710d6ca045b6
    710d6ca0460d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca04614:	6c 03 01 00 
    710d6ca04618:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0461f:	02 00 00 00 
    710d6ca04623:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0462a:	02 00 00 00 
    710d6ca0462e:	4c 89 f7             	mov    rdi,r14
    710d6ca04631:	e8 0a ba ff e7       	call   0x710d54a00040
    710d6ca04636:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0463d:	00 
    710d6ca0463e:	0f 84 61 eb ff e7    	je     0x710d54a031a5
    710d6ca04644:	e9 6d ff ff ff       	jmp    0x710d6ca045b6
    710d6ca04649:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca04650:	6c 03 01 00 
    710d6ca04654:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca0465b:	02 00 00 00 
    710d6ca0465f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca04666:	02 00 00 00 
    710d6ca0466a:	4c 89 f7             	mov    rdi,r14
    710d6ca0466d:	e8 ce b9 ff e7       	call   0x710d54a00040
    710d6ca04672:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca04679:	00 
    710d6ca0467a:	0f 84 48 eb ff e7    	je     0x710d54a031c8
    710d6ca04680:	e9 31 ff ff ff       	jmp    0x710d6ca045b6
    710d6ca04685:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca0468c:	6c 03 01 00 
    710d6ca04690:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04697:	02 00 00 00 
    710d6ca0469b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca046a2:	02 00 00 00 
    710d6ca046a6:	4c 89 f7             	mov    rdi,r14
    710d6ca046a9:	e8 92 b9 ff e7       	call   0x710d54a00040
    710d6ca046ae:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca046b5:	00 
    710d6ca046b6:	0f 84 2f eb ff e7    	je     0x710d54a031eb
    710d6ca046bc:	e9 f5 fe ff ff       	jmp    0x710d6ca045b6
    710d6ca046c1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca046c8:	6c 03 01 00 
    710d6ca046cc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca046d3:	02 00 00 00 
    710d6ca046d7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca046de:	02 00 00 00 
    710d6ca046e2:	4c 89 f7             	mov    rdi,r14
    710d6ca046e5:	e8 56 b9 ff e7       	call   0x710d54a00040
    710d6ca046ea:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca046f1:	00 
    710d6ca046f2:	0f 84 18 eb ff e7    	je     0x710d54a03210
    710d6ca046f8:	e9 b9 fe ff ff       	jmp    0x710d6ca045b6
    710d6ca046fd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    710d6ca04704:	6c 03 01 00 
    710d6ca04708:	b8 6c 03 01 00       	mov    eax,0x1036c
    710d6ca0470d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04714:	02 00 00 00 
    710d6ca04718:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca0471f:	02 00 00 00 
    710d6ca04723:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca04726:	be 6c 03 01 00       	mov    esi,0x1036c
    710d6ca0472b:	4c 89 ef             	mov    rdi,r13
    710d6ca0472e:	e8 2d ba ff e7       	call   0x710d54a00160
    710d6ca04733:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca0473a:	00 
    710d6ca0473b:	0f 84 fc ea ff e7    	je     0x710d54a0323d
    710d6ca04741:	e9 70 fe ff ff       	jmp    0x710d6ca045b6
    710d6ca04746:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    710d6ca0474d:	6e 03 01 00 
    710d6ca04751:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04758:	02 00 00 00 
    710d6ca0475c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca04763:	03 00 00 00 
    710d6ca04767:	4c 89 ef             	mov    rdi,r13
    710d6ca0476a:	be 2a 00 00 00       	mov    esi,0x2a
    710d6ca0476f:	4c 89 f2             	mov    rdx,r14
    710d6ca04772:	e8 19 b9 ff e7       	call   0x710d54a00090
    710d6ca04777:	e9 03 eb ff e7       	jmp    0x710d54a0327f
    710d6ca0477c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca04783:	02 00 00 00 
    710d6ca04787:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca0478e:	03 00 00 00 
    710d6ca04792:	be 6e 03 01 00       	mov    esi,0x1036e
    710d6ca04797:	ba 6e 03 01 00       	mov    edx,0x1036e
    710d6ca0479c:	4c 89 ef             	mov    rdi,r13
    710d6ca0479f:	e8 bc b9 ff e7       	call   0x710d54a00160
    710d6ca047a4:	e9 d6 ea ff e7       	jmp    0x710d54a0327f
    710d6ca047a9:	c2 08 00             	ret    0x8
