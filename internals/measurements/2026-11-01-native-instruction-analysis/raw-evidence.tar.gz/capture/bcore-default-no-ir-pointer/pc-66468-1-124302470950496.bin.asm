
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66468-1-124302470950496.bin:     file format binary


Disassembly of section .data:

0000710d6ca02e60 <.data>:
    710d6ca02e60:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    710d6ca02e66:	8d 51 01             	lea    edx,[rcx+0x1]
    710d6ca02e69:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    710d6ca02e6f:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    710d6ca02e76:	0f 87 95 f2 ff e7    	ja     0x710d54a02111
    710d6ca02e7c:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x4
    710d6ca02e83:	04 00 00 00 
    710d6ca02e87:	e9 85 f2 ff e7       	jmp    0x710d54a02111
    710d6ca02e8c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    710d6ca02e93:	a4 03 01 00 
    710d6ca02e97:	b8 a4 03 01 00       	mov    eax,0x103a4
    710d6ca02e9c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02ea3:	04 00 00 00 
    710d6ca02ea7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca02eae:	01 00 00 00 
    710d6ca02eb2:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca02eb5:	be a4 03 01 00       	mov    esi,0x103a4
    710d6ca02eba:	4c 89 ef             	mov    rdi,r13
    710d6ca02ebd:	e8 9e d2 ff e7       	call   0x710d54a00160
    710d6ca02ec2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02ec9:	00 
    710d6ca02eca:	0f 84 74 f2 ff e7    	je     0x710d54a02144
    710d6ca02ed0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02ed7:	04 00 00 00 
    710d6ca02edb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    710d6ca02ee2:	01 00 00 00 
    710d6ca02ee6:	58                   	pop    rax
    710d6ca02ee7:	e9 89 f3 ff e7       	jmp    0x710d54a02275
    710d6ca02eec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a8
    710d6ca02ef3:	a8 03 01 00 
    710d6ca02ef7:	b8 a8 03 01 00       	mov    eax,0x103a8
    710d6ca02efc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02f03:	04 00 00 00 
    710d6ca02f07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca02f0e:	02 00 00 00 
    710d6ca02f12:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca02f15:	be a8 03 01 00       	mov    esi,0x103a8
    710d6ca02f1a:	4c 89 ef             	mov    rdi,r13
    710d6ca02f1d:	e8 3e d2 ff e7       	call   0x710d54a00160
    710d6ca02f22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02f29:	00 
    710d6ca02f2a:	0f 84 4b f2 ff e7    	je     0x710d54a0217b
    710d6ca02f30:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca02f37:	04 00 00 00 
    710d6ca02f3b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    710d6ca02f42:	02 00 00 00 
    710d6ca02f46:	58                   	pop    rax
    710d6ca02f47:	e9 29 f3 ff e7       	jmp    0x710d54a02275
    710d6ca02f4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ac
    710d6ca02f53:	ac 03 01 00 
    710d6ca02f57:	b8 ac 03 01 00       	mov    eax,0x103ac
    710d6ca02f5c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02f63:	02 00 00 00 
    710d6ca02f67:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca02f6e:	03 00 00 00 
    710d6ca02f72:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02f75:	be ac 03 01 00       	mov    esi,0x103ac
    710d6ca02f7a:	4c 89 ef             	mov    rdi,r13
    710d6ca02f7d:	e8 de d1 ff e7       	call   0x710d54a00160
    710d6ca02f82:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02f89:	00 
    710d6ca02f8a:	0f 84 19 f2 ff e7    	je     0x710d54a021a9
    710d6ca02f90:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02f97:	02 00 00 00 
    710d6ca02f9b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    710d6ca02fa2:	03 00 00 00 
    710d6ca02fa6:	58                   	pop    rax
    710d6ca02fa7:	e9 c9 f2 ff e7       	jmp    0x710d54a02275
    710d6ca02fac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103ae
    710d6ca02fb3:	ae 03 01 00 
    710d6ca02fb7:	b8 ae 03 01 00       	mov    eax,0x103ae
    710d6ca02fbc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02fc3:	02 00 00 00 
    710d6ca02fc7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca02fce:	04 00 00 00 
    710d6ca02fd2:	8d 50 02             	lea    edx,[rax+0x2]
    710d6ca02fd5:	be ae 03 01 00       	mov    esi,0x103ae
    710d6ca02fda:	4c 89 ef             	mov    rdi,r13
    710d6ca02fdd:	e8 7e d1 ff e7       	call   0x710d54a00160
    710d6ca02fe2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca02fe9:	00 
    710d6ca02fea:	0f 84 e5 f1 ff e7    	je     0x710d54a021d5
    710d6ca02ff0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d6ca02ff7:	02 00 00 00 
    710d6ca02ffb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    710d6ca03002:	04 00 00 00 
    710d6ca03006:	58                   	pop    rax
    710d6ca03007:	e9 69 f2 ff e7       	jmp    0x710d54a02275
    710d6ca0300c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103b0
    710d6ca03013:	b0 03 01 00 
    710d6ca03017:	b8 b0 03 01 00       	mov    eax,0x103b0
    710d6ca0301c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03023:	04 00 00 00 
    710d6ca03027:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca0302e:	05 00 00 00 
    710d6ca03032:	8d 50 04             	lea    edx,[rax+0x4]
    710d6ca03035:	be b0 03 01 00       	mov    esi,0x103b0
    710d6ca0303a:	4c 89 ef             	mov    rdi,r13
    710d6ca0303d:	e8 1e d1 ff e7       	call   0x710d54a00160
    710d6ca03042:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    710d6ca03049:	00 
    710d6ca0304a:	0f 84 b1 f1 ff e7    	je     0x710d54a02201
    710d6ca03050:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03057:	04 00 00 00 
    710d6ca0305b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d6ca03062:	05 00 00 00 
    710d6ca03066:	58                   	pop    rax
    710d6ca03067:	e9 09 f2 ff e7       	jmp    0x710d54a02275
    710d6ca0306c:	b8 b4 03 01 00       	mov    eax,0x103b4
    710d6ca03071:	83 c0 04             	add    eax,0x4
    710d6ca03074:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d6ca0307b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    710d6ca03082:	04 00 00 00 
    710d6ca03086:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    710d6ca0308d:	06 00 00 00 
    710d6ca03091:	be b4 03 01 00       	mov    esi,0x103b4
    710d6ca03096:	ba b4 03 01 00       	mov    edx,0x103b4
    710d6ca0309b:	4c 89 ef             	mov    rdi,r13
    710d6ca0309e:	e8 bd d0 ff e7       	call   0x710d54a00160
    710d6ca030a3:	e9 a7 f1 ff e7       	jmp    0x710d54a0224f
    710d6ca030a8:	c2 08 00             	ret    0x8
