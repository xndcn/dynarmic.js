
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66626-1-124302068300160.bin:     file format binary


Disassembly of section .data:

0000710d54a03980 <.data>:
    710d54a03980:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03987:	8b 88 2c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10002c]
    710d54a0398d:	ff c1                	inc    ecx
    710d54a0398f:	89 88 2c 00 10 00    	mov    DWORD PTR [rax+0x10002c],ecx
    710d54a03995:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    710d54a0399b:	0f 84 2f 16 00 18    	je     0x710d6ca04fd0
    710d54a039a1:	50                   	push   rax
    710d54a039a2:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    710d54a039a7:	b9 00 00 01 00       	mov    ecx,0x10000
    710d54a039ac:	09 c1                	or     ecx,eax
    710d54a039ae:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    710d54a039b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10442
    710d54a039b9:	42 04 01 00 
    710d54a039bd:	0f 84 39 16 00 18    	je     0x710d6ca04ffc
    710d54a039c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10442
    710d54a039ca:	42 04 01 00 
    710d54a039ce:	0f 84 28 16 00 18    	je     0x710d6ca04ffc
    710d54a039d4:	58                   	pop    rax
    710d54a039d5:	50                   	push   rax
    710d54a039d6:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    710d54a039db:	c1 e0 10             	shl    eax,0x10
    710d54a039de:	b9 9c 11 00 00       	mov    ecx,0x119c
    710d54a039e3:	09 c1                	or     ecx,eax
    710d54a039e5:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    710d54a039e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10446
    710d54a039f0:	46 04 01 00 
    710d54a039f4:	0f 84 62 16 00 18    	je     0x710d6ca0505c
    710d54a039fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10446
    710d54a03a01:	46 04 01 00 
    710d54a03a05:	0f 84 51 16 00 18    	je     0x710d6ca0505c
    710d54a03a0b:	58                   	pop    rax
    710d54a03a0c:	50                   	push   rax
    710d54a03a0d:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    710d54a03a11:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    710d54a03a18:	c1 e0 02             	shl    eax,0x2
    710d54a03a1b:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    710d54a03a1f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a03a23:	81 f9 4a 04 01 00    	cmp    ecx,0x1044a
    710d54a03a29:	0f 84 8d 16 00 18    	je     0x710d6ca050bc
    710d54a03a2f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044a
    710d54a03a36:	4a 04 01 00 
    710d54a03a3a:	0f 84 7c 16 00 18    	je     0x710d6ca050bc
    710d54a03a40:	58                   	pop    rax
    710d54a03a41:	50                   	push   rax
    710d54a03a42:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    710d54a03a46:	f6 c1 03             	test   cl,0x3
    710d54a03a49:	0f 85 cd 16 00 18    	jne    0x710d6ca0511c
    710d54a03a4f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    710d54a03a56:	48 89 ca             	mov    rdx,rcx
    710d54a03a59:	48 c1 ea 0c          	shr    rdx,0xc
    710d54a03a5d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    710d54a03a61:	48 85 c0             	test   rax,rax
    710d54a03a64:	0f 84 02 17 00 18    	je     0x710d6ca0516c
    710d54a03a6a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    710d54a03a70:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    710d54a03a73:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    710d54a03a77:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044c
    710d54a03a7e:	4c 04 01 00 
    710d54a03a82:	0f 84 1f 17 00 18    	je     0x710d6ca051a7
    710d54a03a88:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044c
    710d54a03a8f:	4c 04 01 00 
    710d54a03a93:	0f 84 0e 17 00 18    	je     0x710d6ca051a7
    710d54a03a99:	58                   	pop    rax
    710d54a03a9a:	50                   	push   rax
    710d54a03a9b:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    710d54a03a9f:	a8 01                	test   al,0x1
    710d54a03aa1:	0f 85 49 17 00 18    	jne    0x710d6ca051f0
    710d54a03aa7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    710d54a03aae:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    710d54a03ab5:	01 
    710d54a03ab6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044e
    710d54a03abd:	4e 04 01 00 
    710d54a03ac1:	0f 84 5f 17 00 18    	je     0x710d6ca05226
    710d54a03ac7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044e
    710d54a03ace:	4e 04 01 00 
    710d54a03ad2:	0f 84 4e 17 00 18    	je     0x710d6ca05226
    710d54a03ad8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    710d54a03adf:	02 00 00 00 
    710d54a03ae3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    710d54a03aea:	05 00 00 00 
    710d54a03aee:	58                   	pop    rax
    710d54a03aef:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    710d54a03af6:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    710d54a03afd:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    710d54a03b04:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    710d54a03b0b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    710d54a03b12:	39 f1                	cmp    ecx,esi
    710d54a03b14:	0f 83 39 17 00 18    	jae    0x710d6ca05253
    710d54a03b1a:	81 fa 42 04 01 00    	cmp    edx,0x10442
    710d54a03b20:	75 14                	jne    0x710d54a03b36
    710d54a03b22:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03b29:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03b30:	00 
    710d54a03b31:	e9 4a fe ff ff       	jmp    0x710d54a03980
    710d54a03b36:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    710d54a03b3d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    710d54a03b43:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    710d54a03b46:	0f 85 07 17 00 18    	jne    0x710d6ca05253
    710d54a03b4c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    710d54a03b53:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    710d54a03b5a:	00 
    710d54a03b5b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    710d54a03b60:	ff e0                	jmp    rax
