
build-native-instruction-analysis/capture/bcore-default-no-ir-pointer/pc-66534-0-124302068312768.bin:     file format binary


Disassembly of section .data:

0000710d54a06ac0 <.data>:
    710d54a06ac0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    710d54a06ac7:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    710d54a06acc:	4d 89 e9             	mov    r9,r13
    710d54a06acf:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    710d54a06ad6:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    710d54a06add:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    710d54a06ae1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    710d54a06ae5:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    710d54a06ae9:	45 8b 55 04          	mov    r10d,DWORD PTR [r13+0x4]
    710d54a06aed:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    710d54a06af1:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    710d54a06af5:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    710d54a06afa:	45 8b 7d 2c          	mov    r15d,DWORD PTR [r13+0x2c]
    710d54a06afe:	41 8b 4d 50          	mov    ecx,DWORD PTR [r13+0x50]
    710d54a06b02:	45 8b 9d 9c 00 00 00 	mov    r11d,DWORD PTR [r13+0x9c]
    710d54a06b09:	41 8b bd a0 00 00 00 	mov    edi,DWORD PTR [r13+0xa0]
    710d54a06b10:	41 8b 85 a4 00 00 00 	mov    eax,DWORD PTR [r13+0xa4]
    710d54a06b17:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    710d54a06b1b:	41 8b ad bc 00 00 00 	mov    ebp,DWORD PTR [r13+0xbc]
    710d54a06b22:	41 8b 85 e4 00 00 00 	mov    eax,DWORD PTR [r13+0xe4]
    710d54a06b29:	89 04 24             	mov    DWORD PTR [rsp],eax
    710d54a06b2c:	41 8b b5 e8 00 00 00 	mov    esi,DWORD PTR [r13+0xe8]
    710d54a06b33:	45 8b 85 ec 00 00 00 	mov    r8d,DWORD PTR [r13+0xec]
    710d54a06b3a:	41 8b 85 f0 00 00 00 	mov    eax,DWORD PTR [r13+0xf0]
    710d54a06b41:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    710d54a06b45:	41 8b 85 f8 00 00 00 	mov    eax,DWORD PTR [r13+0xf8]
    710d54a06b4c:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    710d54a06b50:	41 8b 85 fc 00 00 00 	mov    eax,DWORD PTR [r13+0xfc]
    710d54a06b57:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a06b5b:	45 8b b5 00 01 00 00 	mov    r14d,DWORD PTR [r13+0x100]
    710d54a06b62:	41 8b 85 24 01 00 00 	mov    eax,DWORD PTR [r13+0x124]
    710d54a06b69:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    710d54a06b6d:	45 8b ad 34 01 00 00 	mov    r13d,DWORD PTR [r13+0x134]
    710d54a06b74:	45 8b a1 5c 01 00 00 	mov    r12d,DWORD PTR [r9+0x15c]
    710d54a06b7b:	48 89 7c 24 50       	mov    QWORD PTR [rsp+0x50],rdi
    710d54a06b80:	81 c7 f1 fb fe ff    	add    edi,0xfffefbf1
    710d54a06b86:	83 ff d6             	cmp    edi,0xffffffd6
    710d54a06b89:	0f 87 13 0a 00 00    	ja     0x710d54a075a2
    710d54a06b8f:	41 83 b9 80 00 00 00 	cmp    DWORD PTR [r9+0x80],0x0
    710d54a06b96:	00 
    710d54a06b97:	0f 85 05 0a 00 00    	jne    0x710d54a075a2
    710d54a06b9d:	81 7c 24 30 fa 03 01 	cmp    DWORD PTR [rsp+0x30],0x103fa
    710d54a06ba4:	00 
    710d54a06ba5:	0f 85 f7 09 00 00    	jne    0x710d54a075a2
    710d54a06bab:	41 81 b9 94 00 00 00 	cmp    DWORD PTR [r9+0x94],0x103e6
    710d54a06bb2:	e6 03 01 00 
    710d54a06bb6:	0f 85 e6 09 00 00    	jne    0x710d54a075a2
    710d54a06bbc:	49 8b 81 40 01 00 00 	mov    rax,QWORD PTR [r9+0x140]
    710d54a06bc3:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    710d54a06bc8:	49 8b 81 38 01 00 00 	mov    rax,QWORD PTR [r9+0x138]
    710d54a06bcf:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    710d54a06bd4:	41 8b 41 20          	mov    eax,DWORD PTR [r9+0x20]
    710d54a06bd8:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    710d54a06bdd:	41 8b 41 1c          	mov    eax,DWORD PTR [r9+0x1c]
    710d54a06be1:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    710d54a06be6:	41 8b 41 0c          	mov    eax,DWORD PTR [r9+0xc]
    710d54a06bea:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    710d54a06bee:	41 8b 41 18          	mov    eax,DWORD PTR [r9+0x18]
    710d54a06bf2:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    710d54a06bf6:	48 89 9c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rbx
    710d54a06bfd:	00 
    710d54a06bfe:	66 90                	xchg   ax,ax
    710d54a06c00:	44 89 f0             	mov    eax,r14d
    710d54a06c03:	89 d6                	mov    esi,edx
    710d54a06c05:	0f af 74 24 48       	imul   esi,DWORD PTR [rsp+0x48]
    710d54a06c0a:	48 8b 54 24 78       	mov    rdx,QWORD PTR [rsp+0x78]
    710d54a06c0f:	8d 3c 16             	lea    edi,[rsi+rdx*1]
    710d54a06c12:	c1 ee 1f             	shr    esi,0x1f
    710d54a06c15:	c1 ea 1f             	shr    edx,0x1f
    710d54a06c18:	41 89 fe             	mov    r14d,edi
    710d54a06c1b:	41 c1 ee 1f          	shr    r14d,0x1f
    710d54a06c1f:	44 31 f2             	xor    edx,r14d
    710d54a06c22:	41 31 f6             	xor    r14d,esi
    710d54a06c25:	41 21 d6             	and    r14d,edx
    710d54a06c28:	41 09 c6             	or     r14d,eax
    710d54a06c2b:	89 fb                	mov    ebx,edi
    710d54a06c2d:	c1 eb 08             	shr    ebx,0x8
    710d54a06c30:	31 c0                	xor    eax,eax
    710d54a06c32:	23 5c 24 4c          	and    ebx,DWORD PTR [rsp+0x4c]
    710d54a06c36:	0f 94 c0             	sete   al
    710d54a06c39:	89 04 24             	mov    DWORD PTR [rsp],eax
    710d54a06c3c:	f6 c1 03             	test   cl,0x3
    710d54a06c3f:	0f 85 e6 02 00 00    	jne    0x710d54a06f2b
    710d54a06c45:	89 c8                	mov    eax,ecx
    710d54a06c47:	c1 e8 0c             	shr    eax,0xc
    710d54a06c4a:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    710d54a06c4f:	48 8b 04 c6          	mov    rax,QWORD PTR [rsi+rax*8]
    710d54a06c53:	48 85 c0             	test   rax,rax
    710d54a06c56:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    710d54a06c5a:	0f 84 72 03 00 00    	je     0x710d54a06fd2
    710d54a06c60:	89 ca                	mov    edx,ecx
    710d54a06c62:	81 e2 ff 0f 00 00    	and    edx,0xfff
    710d54a06c68:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    710d54a06c6b:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    710d54a06c6f:	83 c1 04             	add    ecx,0x4
    710d54a06c72:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    710d54a06c77:	8d 2c 98             	lea    ebp,[rax+rbx*4]
    710d54a06c7a:	40 f6 c5 03          	test   bpl,0x3
    710d54a06c7e:	0f 85 2e 04 00 00    	jne    0x710d54a070b2
    710d54a06c84:	89 e8                	mov    eax,ebp
    710d54a06c86:	c1 e8 0c             	shr    eax,0xc
    710d54a06c89:	48 8b 1c c6          	mov    rbx,QWORD PTR [rsi+rax*8]
    710d54a06c8d:	41 89 ed             	mov    r13d,ebp
    710d54a06c90:	41 81 e5 ff 0f 00 00 	and    r13d,0xfff
    710d54a06c97:	48 85 db             	test   rbx,rbx
    710d54a06c9a:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    710d54a06c9f:	0f 84 97 05 00 00    	je     0x710d54a0723c
    710d54a06ca5:	46 8b 14 2b          	mov    r10d,DWORD PTR [rbx+r13*1]
    710d54a06ca9:	41 f6 c7 03          	test   r15b,0x3
    710d54a06cad:	0f 85 6b 06 00 00    	jne    0x710d54a0731e
    710d54a06cb3:	44 89 f8             	mov    eax,r15d
    710d54a06cb6:	c1 e8 0c             	shr    eax,0xc
    710d54a06cb9:	48 8b 04 c6          	mov    rax,QWORD PTR [rsi+rax*8]
    710d54a06cbd:	48 85 c0             	test   rax,rax
    710d54a06cc0:	0f 84 0c 07 00 00    	je     0x710d54a073d2
    710d54a06cc6:	44 89 fa             	mov    edx,r15d
    710d54a06cc9:	81 e2 ff 0f 00 00    	and    edx,0xfff
    710d54a06ccf:	44 89 14 10          	mov    DWORD PTR [rax+rdx*1],r10d
    710d54a06cd3:	41 83 c7 04          	add    r15d,0x4
    710d54a06cd7:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    710d54a06cdc:	80 38 00             	cmp    BYTE PTR [rax],0x0
    710d54a06cdf:	0f 85 d9 07 00 00    	jne    0x710d54a074be
    710d54a06ce5:	48 85 db             	test   rbx,rbx
    710d54a06ce8:	0f 84 cc 08 00 00    	je     0x710d54a075ba
    710d54a06cee:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a06cf2:	42 89 04 2b          	mov    DWORD PTR [rbx+r13*1],eax
    710d54a06cf6:	41 83 fb 02          	cmp    r11d,0x2
    710d54a06cfa:	0f 82 d5 00 00 00    	jb     0x710d54a06dd5
    710d54a06d00:	41 ff cb             	dec    r11d
    710d54a06d03:	c7 44 24 30 fa 03 01 	mov    DWORD PTR [rsp+0x30],0x103fa
    710d54a06d0a:	00 
    710d54a06d0b:	bd e6 03 01 00       	mov    ebp,0x103e6
    710d54a06d10:	c7 44 24 10 00 00 00 	mov    DWORD PTR [rsp+0x10],0x0
    710d54a06d17:	00 
    710d54a06d18:	c7 44 24 3c 02 00 00 	mov    DWORD PTR [rsp+0x3c],0x2
    710d54a06d1f:	00 
    710d54a06d20:	bb 0a 00 00 00       	mov    ebx,0xa
    710d54a06d25:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    710d54a06d2a:	80 38 00             	cmp    BYTE PTR [rax],0x0
    710d54a06d2d:	0f 85 11 0a 00 00    	jne    0x710d54a07744
    710d54a06d33:	b0 01                	mov    al,0x1
    710d54a06d35:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    710d54a06d39:	44 89 e7             	mov    edi,r12d
    710d54a06d3c:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    710d54a06d43:	00 
    710d54a06d44:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    710d54a06d4b:	00 
    710d54a06d4c:	45 31 c0             	xor    r8d,r8d
    710d54a06d4f:	31 f6                	xor    esi,esi
    710d54a06d51:	49 89 dd             	mov    r13,rbx
    710d54a06d54:	44 8d 24 3b          	lea    r12d,[rbx+rdi*1]
    710d54a06d58:	44 3b 64 24 6c       	cmp    r12d,DWORD PTR [rsp+0x6c]
    710d54a06d5d:	0f 83 35 09 00 00    	jae    0x710d54a07698
    710d54a06d63:	41 8b 99 58 01 00 00 	mov    ebx,DWORD PTR [r9+0x158]
    710d54a06d6a:	85 db                	test   ebx,ebx
    710d54a06d6c:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    710d54a06d70:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    710d54a06d77:	00 
    710d54a06d78:	0f 84 1e 09 00 00    	je     0x710d54a0769c
    710d54a06d7e:	81 fd e6 03 01 00    	cmp    ebp,0x103e6
    710d54a06d84:	0f 85 db 00 00 00    	jne    0x710d54a06e65
    710d54a06d8a:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    710d54a06d8f:	8d b8 f1 fb fe ff    	lea    edi,[rax-0x1040f]
    710d54a06d95:	bd e6 03 01 00       	mov    ebp,0x103e6
    710d54a06d9a:	83 ff d6             	cmp    edi,0xffffffd6
    710d54a06d9d:	0f 87 ff 07 00 00    	ja     0x710d54a075a2
    710d54a06da3:	41 83 b9 80 00 00 00 	cmp    DWORD PTR [r9+0x80],0x0
    710d54a06daa:	00 
    710d54a06dab:	0f 85 f1 07 00 00    	jne    0x710d54a075a2
    710d54a06db1:	81 7c 24 30 fa 03 01 	cmp    DWORD PTR [rsp+0x30],0x103fa
    710d54a06db8:	00 
    710d54a06db9:	0f 85 e3 07 00 00    	jne    0x710d54a075a2
    710d54a06dbf:	41 81 b9 94 00 00 00 	cmp    DWORD PTR [r9+0x94],0x103e6
    710d54a06dc6:	e6 03 01 00 
    710d54a06dca:	0f 84 30 fe ff ff    	je     0x710d54a06c00
    710d54a06dd0:	e9 cd 07 00 00       	jmp    0x710d54a075a2
    710d54a06dd5:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    710d54a06dda:	80 38 00             	cmp    BYTE PTR [rax],0x0
    710d54a06ddd:	0f 85 33 09 00 18    	jne    0x710d6ca07716
    710d54a06de3:	41 c7 41 28 00 20 00 	mov    DWORD PTR [r9+0x28],0x2000
    710d54a06dea:	00 
    710d54a06deb:	41 c7 81 94 00 00 00 	mov    DWORD PTR [r9+0x94],0x10412
    710d54a06df2:	12 04 01 00 
    710d54a06df6:	81 7c 24 50 0e 04 01 	cmp    DWORD PTR [rsp+0x50],0x1040e
    710d54a06dfd:	00 
    710d54a06dfe:	0f 84 e4 09 00 18    	je     0x710d6ca077e8
    710d54a06e04:	c7 44 24 08 ff 1f 00 	mov    DWORD PTR [rsp+0x8],0x1fff
    710d54a06e0b:	00 
    710d54a06e0c:	41 bf fc 12 01 00    	mov    r15d,0x112fc
    710d54a06e12:	41 bb 00 20 00 00    	mov    r11d,0x2000
    710d54a06e18:	c7 44 24 30 20 04 01 	mov    DWORD PTR [rsp+0x30],0x10420
    710d54a06e1f:	00 
    710d54a06e20:	bd 12 04 01 00       	mov    ebp,0x10412
    710d54a06e25:	c7 44 24 10 00 00 00 	mov    DWORD PTR [rsp+0x10],0x0
    710d54a06e2c:	00 
    710d54a06e2d:	c7 44 24 3c 04 00 00 	mov    DWORD PTR [rsp+0x3c],0x4
    710d54a06e34:	00 
    710d54a06e35:	b0 01                	mov    al,0x1
    710d54a06e37:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    710d54a06e3b:	bb 10 00 00 00       	mov    ebx,0x10
    710d54a06e40:	44 89 e7             	mov    edi,r12d
    710d54a06e43:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    710d54a06e4a:	00 
    710d54a06e4b:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    710d54a06e52:	00 
    710d54a06e53:	45 31 c0             	xor    r8d,r8d
    710d54a06e56:	31 f6                	xor    esi,esi
    710d54a06e58:	c7 44 24 04 00 00 00 	mov    DWORD PTR [rsp+0x4],0x0
    710d54a06e5f:	00 
    710d54a06e60:	e9 ec fe ff ff       	jmp    0x710d54a06d51
    710d54a06e65:	8d 1c ed 00 00 00 00 	lea    ebx,[rbp*8+0x0]
    710d54a06e6c:	81 e3 f0 ff 0f 00    	and    ebx,0xffff0
    710d54a06e72:	39 2c 18             	cmp    DWORD PTR [rax+rbx*1],ebp
    710d54a06e75:	0f 85 21 08 00 00    	jne    0x710d54a0769c
    710d54a06e7b:	48 8b 7c 18 08       	mov    rdi,QWORD PTR [rax+rbx*1+0x8]
    710d54a06e80:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a06e84:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a06e87:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a06e8b:	41 89 51 08          	mov    DWORD PTR [r9+0x8],edx
    710d54a06e8f:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    710d54a06e94:	41 89 51 24          	mov    DWORD PTR [r9+0x24],edx
    710d54a06e98:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a06e9c:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a06ea0:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a06ea7:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    710d54a06eab:	41 89 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],eax
    710d54a06eb2:	41 89 a9 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],ebp
    710d54a06eb9:	8b 0c 24             	mov    ecx,DWORD PTR [rsp]
    710d54a06ebc:	41 89 89 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],ecx
    710d54a06ec3:	41 89 b1 e8 00 00 00 	mov    DWORD PTR [r9+0xe8],esi
    710d54a06eca:	45 89 81 ec 00 00 00 	mov    DWORD PTR [r9+0xec],r8d
    710d54a06ed1:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a06ed5:	41 89 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],eax
    710d54a06edc:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d54a06ee0:	41 89 81 f8 00 00 00 	mov    DWORD PTR [r9+0xf8],eax
    710d54a06ee7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    710d54a06eeb:	41 89 81 fc 00 00 00 	mov    DWORD PTR [r9+0xfc],eax
    710d54a06ef2:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a06ef9:	8b 44 24 3c          	mov    eax,DWORD PTR [rsp+0x3c]
    710d54a06efd:	41 89 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],eax
    710d54a06f04:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a06f0b:	00 
    710d54a06f0c:	45 89 a9 34 01 00 00 	mov    DWORD PTR [r9+0x134],r13d
    710d54a06f13:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a06f1a:	4d 89 cd             	mov    r13,r9
    710d54a06f1d:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    710d54a06f22:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d54a06f29:	ff e7                	jmp    rdi
    710d54a06f2b:	41 89 19             	mov    DWORD PTR [r9],ebx
    710d54a06f2e:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a06f32:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    710d54a06f36:	41 89 59 24          	mov    DWORD PTR [r9+0x24],ebx
    710d54a06f3a:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a06f3e:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a06f42:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a06f49:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a06f50:	fa 03 01 00 
    710d54a06f54:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f2
    710d54a06f5b:	f2 03 01 00 
    710d54a06f5f:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a06f62:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a06f69:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a06f70:	00 00 00 00 
    710d54a06f74:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a06f7b:	00 00 00 00 
    710d54a06f7f:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a06f86:	00 00 00 00 
    710d54a06f8a:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a06f91:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a06f98:	02 00 00 00 
    710d54a06f9c:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a06fa3:	00 
    710d54a06fa4:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x6
    710d54a06fab:	06 00 00 00 
    710d54a06faf:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a06fb6:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a06fbd:	56 00 00 
    710d54a06fc0:	4c 89 cf             	mov    rdi,r9
    710d54a06fc3:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    710d54a06fc8:	ba f2 03 01 00       	mov    edx,0x103f2
    710d54a06fcd:	e9 88 01 00 00       	jmp    0x710d54a0715a
    710d54a06fd2:	41 89 19             	mov    DWORD PTR [r9],ebx
    710d54a06fd5:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a06fd9:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    710d54a06fdd:	41 89 59 24          	mov    DWORD PTR [r9+0x24],ebx
    710d54a06fe1:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a06fe5:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a06fe9:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a06ff0:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a06ff7:	fa 03 01 00 
    710d54a06ffb:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f2
    710d54a07002:	f2 03 01 00 
    710d54a07006:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a07009:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a07010:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a07017:	00 00 00 00 
    710d54a0701b:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a07022:	00 00 00 00 
    710d54a07026:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a0702d:	00 00 00 00 
    710d54a07031:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a07038:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a0703f:	02 00 00 00 
    710d54a07043:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a0704a:	00 
    710d54a0704b:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x6
    710d54a07052:	06 00 00 00 
    710d54a07056:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a0705d:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a07064:	56 00 00 
    710d54a07067:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a0706c:	89 ce                	mov    esi,ecx
    710d54a0706e:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a07073:	48 89 cd             	mov    rbp,rcx
    710d54a07076:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    710d54a0707b:	45 89 dd             	mov    r13d,r11d
    710d54a0707e:	ff d0                	call   rax
    710d54a07080:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    710d54a07085:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a0708a:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    710d54a0708e:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a07095:	00 
    710d54a07096:	84 d2                	test   dl,dl
    710d54a07098:	0f 85 cf 00 00 00    	jne    0x710d54a0716d
    710d54a0709e:	45 89 eb             	mov    r11d,r13d
    710d54a070a1:	48 89 e9             	mov    rcx,rbp
    710d54a070a4:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    710d54a070a8:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    710d54a070ad:	e9 bd fb ff ff       	jmp    0x710d54a06c6f
    710d54a070b2:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a070b6:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a070b9:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a070bd:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    710d54a070c1:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    710d54a070c5:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a070c9:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a070cd:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a070d4:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a070db:	fa 03 01 00 
    710d54a070df:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f6
    710d54a070e6:	f6 03 01 00 
    710d54a070ea:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a070ed:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a070f4:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a070fb:	00 00 00 00 
    710d54a070ff:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a07106:	00 00 00 00 
    710d54a0710a:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a07111:	00 00 00 00 
    710d54a07115:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a0711c:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a07123:	02 00 00 00 
    710d54a07127:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a0712e:	00 
    710d54a0712f:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x8
    710d54a07136:	08 00 00 00 
    710d54a0713a:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a07141:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a07148:	56 00 00 
    710d54a0714b:	4c 89 cf             	mov    rdi,r9
    710d54a0714e:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    710d54a07153:	ba f6 03 01 00       	mov    edx,0x103f6
    710d54a07158:	89 e9                	mov    ecx,ebp
    710d54a0715a:	45 31 c0             	xor    r8d,r8d
    710d54a0715d:	4d 89 cd             	mov    r13,r9
    710d54a07160:	ff d0                	call   rax
    710d54a07162:	4d 89 e9             	mov    r9,r13
    710d54a07165:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    710d54a0716c:	00 
    710d54a0716d:	41 8b 01             	mov    eax,DWORD PTR [r9]
    710d54a07170:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    710d54a07174:	45 8b 51 04          	mov    r10d,DWORD PTR [r9+0x4]
    710d54a07178:	41 8b 41 08          	mov    eax,DWORD PTR [r9+0x8]
    710d54a0717c:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    710d54a07180:	41 8b 41 0c          	mov    eax,DWORD PTR [r9+0xc]
    710d54a07184:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    710d54a07188:	41 8b 41 18          	mov    eax,DWORD PTR [r9+0x18]
    710d54a0718c:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    710d54a07190:	41 8b 41 1c          	mov    eax,DWORD PTR [r9+0x1c]
    710d54a07194:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    710d54a07199:	41 8b 41 20          	mov    eax,DWORD PTR [r9+0x20]
    710d54a0719d:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    710d54a071a2:	41 8b 41 24          	mov    eax,DWORD PTR [r9+0x24]
    710d54a071a6:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    710d54a071ab:	45 8b 79 2c          	mov    r15d,DWORD PTR [r9+0x2c]
    710d54a071af:	41 8b 49 50          	mov    ecx,DWORD PTR [r9+0x50]
    710d54a071b3:	45 8b 99 9c 00 00 00 	mov    r11d,DWORD PTR [r9+0x9c]
    710d54a071ba:	41 8b 81 a0 00 00 00 	mov    eax,DWORD PTR [r9+0xa0]
    710d54a071c1:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    710d54a071c6:	41 8b 81 a4 00 00 00 	mov    eax,DWORD PTR [r9+0xa4]
    710d54a071cd:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    710d54a071d1:	41 8b a9 bc 00 00 00 	mov    ebp,DWORD PTR [r9+0xbc]
    710d54a071d8:	89 d0                	mov    eax,edx
    710d54a071da:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    710d54a071de:	41 8b 81 e4 00 00 00 	mov    eax,DWORD PTR [r9+0xe4]
    710d54a071e5:	89 04 24             	mov    DWORD PTR [rsp],eax
    710d54a071e8:	41 8b b1 e8 00 00 00 	mov    esi,DWORD PTR [r9+0xe8]
    710d54a071ef:	45 8b 81 ec 00 00 00 	mov    r8d,DWORD PTR [r9+0xec]
    710d54a071f6:	41 8b 81 f0 00 00 00 	mov    eax,DWORD PTR [r9+0xf0]
    710d54a071fd:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    710d54a07201:	41 8b 81 f8 00 00 00 	mov    eax,DWORD PTR [r9+0xf8]
    710d54a07208:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    710d54a0720c:	41 8b 81 fc 00 00 00 	mov    eax,DWORD PTR [r9+0xfc]
    710d54a07213:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    710d54a07217:	45 8b b1 00 01 00 00 	mov    r14d,DWORD PTR [r9+0x100]
    710d54a0721e:	41 8b 81 24 01 00 00 	mov    eax,DWORD PTR [r9+0x124]
    710d54a07225:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    710d54a07229:	41 8b 99 34 01 00 00 	mov    ebx,DWORD PTR [r9+0x134]
    710d54a07230:	41 8b b9 5c 01 00 00 	mov    edi,DWORD PTR [r9+0x15c]
    710d54a07237:	e9 15 fb ff ff       	jmp    0x710d54a06d51
    710d54a0723c:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a07240:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a07243:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a07247:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    710d54a0724b:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    710d54a0724f:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a07253:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a07257:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a0725e:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a07265:	fa 03 01 00 
    710d54a07269:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f6
    710d54a07270:	f6 03 01 00 
    710d54a07274:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a07277:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a0727e:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a07285:	00 00 00 00 
    710d54a07289:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a07290:	00 00 00 00 
    710d54a07294:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a0729b:	00 00 00 00 
    710d54a0729f:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a072a6:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a072ad:	02 00 00 00 
    710d54a072b1:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a072b8:	00 
    710d54a072b9:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x8
    710d54a072c0:	08 00 00 00 
    710d54a072c4:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a072cb:	48 b8 f0 a5 90 86 66 	movabs rax,0x56668690a5f0
    710d54a072d2:	56 00 00 
    710d54a072d5:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a072da:	89 ee                	mov    esi,ebp
    710d54a072dc:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a072e1:	48 89 cd             	mov    rbp,rcx
    710d54a072e4:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    710d54a072e9:	ff d0                	call   rax
    710d54a072eb:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    710d54a072f0:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a072f5:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a072fc:	00 
    710d54a072fd:	84 d2                	test   dl,dl
    710d54a072ff:	0f 85 68 fe ff ff    	jne    0x710d54a0716d
    710d54a07305:	48 89 e9             	mov    rcx,rbp
    710d54a07308:	41 89 c2             	mov    r10d,eax
    710d54a0730b:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    710d54a0730f:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    710d54a07314:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    710d54a07319:	e9 8b f9 ff ff       	jmp    0x710d54a06ca9
    710d54a0731e:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a07322:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a07325:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a07329:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    710d54a0732d:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    710d54a07331:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a07335:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a07339:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a07340:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a07347:	fa 03 01 00 
    710d54a0734b:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f8
    710d54a07352:	f8 03 01 00 
    710d54a07356:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a07359:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a07360:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a07367:	00 00 00 00 
    710d54a0736b:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a07372:	00 00 00 00 
    710d54a07376:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a0737d:	00 00 00 00 
    710d54a07381:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a07388:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a0738f:	02 00 00 00 
    710d54a07393:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a0739a:	00 
    710d54a0739b:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    710d54a073a2:	09 00 00 00 
    710d54a073a6:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a073ad:	48 b8 e0 08 a2 86 66 	movabs rax,0x566686a208e0
    710d54a073b4:	56 00 00 
    710d54a073b7:	4c 89 cf             	mov    rdi,r9
    710d54a073ba:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    710d54a073bf:	ba f8 03 01 00       	mov    edx,0x103f8
    710d54a073c4:	44 89 f9             	mov    ecx,r15d
    710d54a073c7:	41 b8 00 00 01 00    	mov    r8d,0x10000
    710d54a073cd:	e9 8b fd ff ff       	jmp    0x710d54a0715d
    710d54a073d2:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a073d6:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a073d9:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a073dd:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a073e1:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    710d54a073e5:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a073ea:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    710d54a073ee:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a073f2:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a073f6:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a073fd:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a07404:	fa 03 01 00 
    710d54a07408:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f8
    710d54a0740f:	f8 03 01 00 
    710d54a07413:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a07416:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a0741d:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a07424:	00 00 00 00 
    710d54a07428:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a0742f:	00 00 00 00 
    710d54a07433:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a0743a:	00 00 00 00 
    710d54a0743e:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a07445:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a0744c:	02 00 00 00 
    710d54a07450:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a07457:	00 
    710d54a07458:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    710d54a0745f:	09 00 00 00 
    710d54a07463:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a0746a:	48 b8 20 a6 90 86 66 	movabs rax,0x56668690a620
    710d54a07471:	56 00 00 
    710d54a07474:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a07479:	44 89 fe             	mov    esi,r15d
    710d54a0747c:	44 89 d2             	mov    edx,r10d
    710d54a0747f:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a07484:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a07489:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    710d54a0748e:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    710d54a07493:	ff d0                	call   rax
    710d54a07495:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    710d54a0749a:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    710d54a0749f:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a074a4:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a074a9:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a074b0:	00 
    710d54a074b1:	84 d2                	test   dl,dl
    710d54a074b3:	0f 84 1a f8 ff ff    	je     0x710d54a06cd3
    710d54a074b9:	e9 af fc ff ff       	jmp    0x710d54a0716d
    710d54a074be:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a074c2:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a074c5:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a074c9:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a074cd:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    710d54a074d1:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a074d6:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    710d54a074da:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a074de:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a074e2:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a074e9:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a074f0:	fa 03 01 00 
    710d54a074f4:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fa
    710d54a074fb:	fa 03 01 00 
    710d54a074ff:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a07502:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a07509:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a07510:	00 00 00 00 
    710d54a07514:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a0751b:	00 00 00 00 
    710d54a0751f:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a07526:	00 00 00 00 
    710d54a0752a:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a07531:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a07538:	02 00 00 00 
    710d54a0753c:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a07543:	00 
    710d54a07544:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    710d54a0754b:	09 00 00 00 
    710d54a0754f:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a07556:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d54a0755d:	56 00 00 
    710d54a07560:	4c 89 cf             	mov    rdi,r9
    710d54a07563:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a07568:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    710d54a0756d:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    710d54a07572:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    710d54a07577:	ff d0                	call   rax
    710d54a07579:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    710d54a0757e:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    710d54a07583:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    710d54a07588:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a0758d:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a07594:	00 
    710d54a07595:	84 d2                	test   dl,dl
    710d54a07597:	0f 84 48 f7 ff ff    	je     0x710d54a06ce5
    710d54a0759d:	e9 cb fb ff ff       	jmp    0x710d54a0716d
    710d54a075a2:	41 c6 81 65 01 00 00 	mov    BYTE PTR [r9+0x165],0x1
    710d54a075a9:	01 
    710d54a075aa:	c7 44 24 38 00 00 00 	mov    DWORD PTR [rsp+0x38],0x0
    710d54a075b1:	00 
    710d54a075b2:	44 89 e7             	mov    edi,r12d
    710d54a075b5:	e9 e2 00 00 00       	jmp    0x710d54a0769c
    710d54a075ba:	8b 54 24 04          	mov    edx,DWORD PTR [rsp+0x4]
    710d54a075be:	41 89 11             	mov    DWORD PTR [r9],edx
    710d54a075c1:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a075c5:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a075c9:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    710d54a075cd:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    710d54a075d2:	41 89 71 24          	mov    DWORD PTR [r9+0x24],esi
    710d54a075d6:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a075da:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a075de:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a075e5:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a075ec:	fa 03 01 00 
    710d54a075f0:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fa
    710d54a075f7:	fa 03 01 00 
    710d54a075fb:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a075fe:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a07605:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a0760c:	00 00 00 00 
    710d54a07610:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a07617:	00 00 00 00 
    710d54a0761b:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a07622:	00 00 00 00 
    710d54a07626:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a0762d:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a07634:	02 00 00 00 
    710d54a07638:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    710d54a0763f:	00 
    710d54a07640:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    710d54a07647:	0a 00 00 00 
    710d54a0764b:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a07652:	48 b8 20 a6 90 86 66 	movabs rax,0x56668690a620
    710d54a07659:	56 00 00 
    710d54a0765c:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    710d54a07661:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a07666:	48 89 cb             	mov    rbx,rcx
    710d54a07669:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    710d54a0766e:	44 89 dd             	mov    ebp,r11d
    710d54a07671:	ff d0                	call   rax
    710d54a07673:	41 89 eb             	mov    r11d,ebp
    710d54a07676:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    710d54a0767b:	48 89 d9             	mov    rcx,rbx
    710d54a0767e:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a07683:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a0768a:	00 
    710d54a0768b:	84 d2                	test   dl,dl
    710d54a0768d:	0f 84 63 f6 ff ff    	je     0x710d54a06cf6
    710d54a07693:	e9 d5 fa ff ff       	jmp    0x710d54a0716d
    710d54a07698:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    710d54a0769c:	8b 1c 24             	mov    ebx,DWORD PTR [rsp]
    710d54a0769f:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    710d54a076a4:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a076a8:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a076ab:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a076af:	41 89 51 08          	mov    DWORD PTR [r9+0x8],edx
    710d54a076b3:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    710d54a076b8:	41 89 51 24          	mov    DWORD PTR [r9+0x24],edx
    710d54a076bc:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a076c0:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a076c4:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a076cb:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    710d54a076cf:	41 89 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],eax
    710d54a076d6:	41 89 a9 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],ebp
    710d54a076dd:	41 89 99 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],ebx
    710d54a076e4:	41 89 b1 e8 00 00 00 	mov    DWORD PTR [r9+0xe8],esi
    710d54a076eb:	45 89 81 ec 00 00 00 	mov    DWORD PTR [r9+0xec],r8d
    710d54a076f2:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    710d54a076f6:	41 89 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],eax
    710d54a076fd:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    710d54a07701:	41 89 81 f8 00 00 00 	mov    DWORD PTR [r9+0xf8],eax
    710d54a07708:	45 89 a1 fc 00 00 00 	mov    DWORD PTR [r9+0xfc],r12d
    710d54a0770f:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a07716:	8b 44 24 3c          	mov    eax,DWORD PTR [rsp+0x3c]
    710d54a0771a:	41 89 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],eax
    710d54a07721:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    710d54a07725:	41 88 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],al
    710d54a0772c:	45 89 a9 34 01 00 00 	mov    DWORD PTR [r9+0x134],r13d
    710d54a07733:	41 89 b9 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],edi
    710d54a0773a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    710d54a07741:	c2 08 00             	ret    0x8
    710d54a07744:	b0 01                	mov    al,0x1
    710d54a07746:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    710d54a0774a:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    710d54a0774e:	41 89 01             	mov    DWORD PTR [r9],eax
    710d54a07751:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    710d54a07755:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    710d54a07759:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    710d54a0775d:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    710d54a07762:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    710d54a07766:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    710d54a0776a:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    710d54a0776e:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    710d54a07775:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    710d54a0777c:	fa 03 01 00 
    710d54a07780:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103e6
    710d54a07787:	e6 03 01 00 
    710d54a0778b:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    710d54a0778e:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    710d54a07795:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    710d54a0779c:	00 00 00 00 
    710d54a077a0:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    710d54a077a7:	00 00 00 00 
    710d54a077ab:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    710d54a077b2:	00 00 00 00 
    710d54a077b6:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    710d54a077bd:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    710d54a077c4:	02 00 00 00 
    710d54a077c8:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x1
    710d54a077cf:	01 
    710d54a077d0:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    710d54a077d7:	0a 00 00 00 
    710d54a077db:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    710d54a077e2:	48 b8 10 06 a2 86 66 	movabs rax,0x566686a20610
    710d54a077e9:	56 00 00 
    710d54a077ec:	4c 89 cf             	mov    rdi,r9
    710d54a077ef:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    710d54a077f4:	48 89 cb             	mov    rbx,rcx
    710d54a077f7:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    710d54a077fc:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    710d54a07801:	ff d0                	call   rax
    710d54a07803:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    710d54a07808:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    710d54a0780d:	48 89 d9             	mov    rcx,rbx
    710d54a07810:	bb 0a 00 00 00       	mov    ebx,0xa
    710d54a07815:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    710d54a0781a:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    710d54a07821:	00 
    710d54a07822:	44 89 e7             	mov    edi,r12d
    710d54a07825:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    710d54a0782c:	00 
    710d54a0782d:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    710d54a07834:	00 
    710d54a07835:	41 b8 00 00 00 00    	mov    r8d,0x0
    710d54a0783b:	be 00 00 00 00       	mov    esi,0x0
    710d54a07840:	84 d2                	test   dl,dl
    710d54a07842:	0f 84 09 f5 ff ff    	je     0x710d54a06d51
    710d54a07848:	e9 20 f9 ff ff       	jmp    0x710d54a0716d
