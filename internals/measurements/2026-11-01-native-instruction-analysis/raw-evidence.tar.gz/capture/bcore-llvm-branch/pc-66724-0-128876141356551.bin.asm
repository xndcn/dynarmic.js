
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66724-0-128876141356551.bin:     file format binary


Disassembly of section .data:

0000753650a02607 <.data>:
    753650a02607:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a0260e:	01 
    753650a0260f:	58                   	pop    rax
    753650a02610:	c2 08 00             	ret    0x8
    753650a02613:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104ac
    753650a0261a:	ac 04 01 00 
    753650a0261e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02625:	02 00 00 00 
    753650a02629:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a02630:	03 00 00 00 
    753650a02634:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0263b:	62 00 00 
    753650a0263e:	4c 89 f7             	mov    rdi,r14
    753650a02641:	be f4 12 01 00       	mov    esi,0x112f4
    753650a02646:	ff d0                	call   rax
    753650a02648:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a0264f:	00 
    753650a02650:	0f 84 be f0 ff e7    	je     0x753638a01714
    753650a02656:	b8 02 00 00 00       	mov    eax,0x2
    753650a0265b:	b9 03 00 00 00       	mov    ecx,0x3
    753650a02660:	e9 96 00 00 00       	jmp    0x753650a026fb
    753650a02665:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b6
    753650a0266c:	b6 04 01 00 
    753650a02670:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02677:	02 00 00 00 
    753650a0267b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a02682:	06 00 00 00 
    753650a02686:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0268d:	62 00 00 
    753650a02690:	4c 89 f7             	mov    rdi,r14
    753650a02693:	be f8 12 01 00       	mov    esi,0x112f8
    753650a02698:	ff d0                	call   rax
    753650a0269a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a026a1:	00 
    753650a026a2:	0f 84 8e f0 ff e7    	je     0x753638a01736
    753650a026a8:	b8 02 00 00 00       	mov    eax,0x2
    753650a026ad:	b9 06 00 00 00       	mov    ecx,0x6
    753650a026b2:	eb 47                	jmp    0x753650a026fb
    753650a026b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    753650a026bb:	b8 04 01 00 
    753650a026bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a026c6:	04 00 00 00 
    753650a026ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a026d1:	07 00 00 00 
    753650a026d5:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a026dc:	62 00 00 
    753650a026df:	4c 89 ef             	mov    rdi,r13
    753650a026e2:	4c 89 f6             	mov    rsi,r14
    753650a026e5:	ba b8 04 01 00       	mov    edx,0x104b8
    753650a026ea:	89 d9                	mov    ecx,ebx
    753650a026ec:	45 31 c0             	xor    r8d,r8d
    753650a026ef:	ff d0                	call   rax
    753650a026f1:	b8 04 00 00 00       	mov    eax,0x4
    753650a026f6:	b9 07 00 00 00       	mov    ecx,0x7
    753650a026fb:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    753650a02702:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753650a02709:	01 ca                	add    edx,ecx
    753650a0270b:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    753650a02712:	39 fa                	cmp    edx,edi
    753650a02714:	0f 83 b9 00 00 00    	jae    0x753650a027d3
    753650a0271a:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    753650a02721:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    753650a02727:	41 39 34 3f          	cmp    DWORD PTR [r15+rdi*1],esi
    753650a0272b:	0f 85 a2 00 00 00    	jne    0x753650a027d3
    753650a02731:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753650a02738:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a0273f:	00 
    753650a02740:	49 8b 44 3f 08       	mov    rax,QWORD PTR [r15+rdi*1+0x8]
    753650a02745:	59                   	pop    rcx
    753650a02746:	ff e0                	jmp    rax
    753650a02748:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    753650a0274f:	b8 04 01 00 
    753650a02753:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0275a:	04 00 00 00 
    753650a0275e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a02765:	07 00 00 00 
    753650a02769:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02770:	62 00 00 
    753650a02773:	4c 89 f7             	mov    rdi,r14
    753650a02776:	89 de                	mov    esi,ebx
    753650a02778:	ff d0                	call   rax
    753650a0277a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02781:	00 
    753650a02782:	0f 85 69 ff ff ff    	jne    0x753650a026f1
    753650a02788:	41 89 c4             	mov    r12d,eax
    753650a0278b:	e9 d8 ef ff e7       	jmp    0x753638a01768
    753650a02790:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x104b8
    753650a02797:	b8 04 01 00 
    753650a0279b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a027a2:	04 00 00 00 
    753650a027a6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a027ad:	07 00 00 00 
    753650a027b1:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a027b8:	62 00 00 
    753650a027bb:	4c 89 f7             	mov    rdi,r14
    753650a027be:	ff d0                	call   rax
    753650a027c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a027c7:	00 
    753650a027c8:	0f 84 b9 ef ff e7    	je     0x753638a01787
    753650a027ce:	e9 1e ff ff ff       	jmp    0x753650a026f1
    753650a027d3:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    753650a027da:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    753650a027e1:	58                   	pop    rax
    753650a027e2:	c2 08 00             	ret    0x8
