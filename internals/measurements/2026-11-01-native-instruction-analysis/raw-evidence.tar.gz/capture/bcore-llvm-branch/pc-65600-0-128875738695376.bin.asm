
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65600-0-128875738695376.bin:     file format binary


Disassembly of section .data:

0000753638a006d0 <.data>:
    753638a006d0:	48 83 ec 38          	sub    rsp,0x38
    753638a006d4:	45 8b 85 a0 00 00 00 	mov    r8d,DWORD PTR [r13+0xa0]
    753638a006db:	41 8d 80 71 ff fe ff 	lea    eax,[r8-0x1008f]
    753638a006e2:	83 f8 b0             	cmp    eax,0xffffffb0
    753638a006e5:	0f 87 64 05 00 18    	ja     0x753650a00c4f
    753638a006eb:	41 8b bd a4 00 00 00 	mov    edi,DWORD PTR [r13+0xa4]
    753638a006f2:	8d 87 71 ff fe ff    	lea    eax,[rdi-0x1008f]
    753638a006f8:	83 f8 b0             	cmp    eax,0xffffffb0
    753638a006fb:	0f 87 4e 05 00 18    	ja     0x753650a00c4f
    753638a00701:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    753638a00708:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    753638a0070f:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    753638a00716:	41 c7 45 28 04 f0 00 	mov    DWORD PTR [r13+0x28],0xf004
    753638a0071d:	00 
    753638a0071e:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a00723:	48 85 c0             	test   rax,rax
    753638a00726:	0f 84 32 05 00 18    	je     0x753650a00c5e
    753638a0072c:	44 8b 48 04          	mov    r9d,DWORD PTR [rax+0x4]
    753638a00730:	45 89 4d 10          	mov    DWORD PTR [r13+0x10],r9d
    753638a00734:	41 c7 45 28 08 f0 00 	mov    DWORD PTR [r13+0x28],0xf008
    753638a0073b:	00 
    753638a0073c:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a00741:	48 85 c0             	test   rax,rax
    753638a00744:	0f 84 83 05 00 18    	je     0x753650a00ccd
    753638a0074a:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    753638a0074d:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    753638a00751:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    753638a00758:	00 
    753638a00759:	41 c7 45 2c 14 f0 00 	mov    DWORD PTR [r13+0x2c],0xf014
    753638a00760:	00 
    753638a00761:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    753638a00765:	8d 5d fc             	lea    ebx,[rbp-0x4]
    753638a00768:	40 f6 c5 03          	test   bpl,0x3
    753638a0076c:	0f 85 d1 05 00 18    	jne    0x753650a00d43
    753638a00772:	41 89 db             	mov    r11d,ebx
    753638a00775:	41 c1 eb 0c          	shr    r11d,0xc
    753638a00779:	4b 8b 0c dc          	mov    rcx,QWORD PTR [r12+r11*8]
    753638a0077d:	48 85 c9             	test   rcx,rcx
    753638a00780:	0f 84 6d 06 00 18    	je     0x753650a00df3
    753638a00786:	89 da                	mov    edx,ebx
    753638a00788:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a0078e:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    753638a00791:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    753638a00795:	0f 85 db 06 00 18    	jne    0x753650a00e76
    753638a0079b:	41 c7 45 28 0c f0 00 	mov    DWORD PTR [r13+0x28],0xf00c
    753638a007a2:	00 
    753638a007a3:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a007a8:	48 85 c0             	test   rax,rax
    753638a007ab:	0f 84 44 07 00 18    	je     0x753650a00ef5
    753638a007b1:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    753638a007b4:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    753638a007b8:	66 41 c7 45 32 00 01 	mov    WORD PTR [r13+0x32],0x100
    753638a007bf:	41 c7 45 34 18 f0 00 	mov    DWORD PTR [r13+0x34],0xf018
    753638a007c6:	00 
    753638a007c7:	83 c5 f8             	add    ebp,0xfffffff8
    753638a007ca:	41 89 ef             	mov    r15d,ebp
    753638a007cd:	41 c1 ef 0c          	shr    r15d,0xc
    753638a007d1:	4b 8b 0c fc          	mov    rcx,QWORD PTR [r12+r15*8]
    753638a007d5:	48 85 c9             	test   rcx,rcx
    753638a007d8:	0f 84 9f 07 00 18    	je     0x753650a00f7d
    753638a007de:	89 ea                	mov    edx,ebp
    753638a007e0:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a007e6:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    753638a007e9:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    753638a007ed:	0f 85 0e 08 00 18    	jne    0x753650a01001
    753638a007f3:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    753638a007fa:	00 
    753638a007fb:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a00800:	48 85 c0             	test   rax,rax
    753638a00803:	0f 84 85 08 00 18    	je     0x753650a0108e
    753638a00809:	c7 40 10 01 00 00 00 	mov    DWORD PTR [rax+0x10],0x1
    753638a00810:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    753638a00814:	0f 85 fe 08 00 18    	jne    0x753650a01118
    753638a0081a:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    753638a00821:	00 
    753638a00822:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a00827:	48 85 c0             	test   rax,rax
    753638a0082a:	0f 84 75 09 00 18    	je     0x753650a011a5
    753638a00830:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    753638a00837:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    753638a0083b:	0f 85 eb 09 00 18    	jne    0x753650a0122c
    753638a00841:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    753638a00848:	00 
    753638a00849:	41 c7 45 30 00 00 00 	mov    DWORD PTR [r13+0x30],0x1000000
    753638a00850:	01 
    753638a00851:	49 c7 45 14 01 00 00 	mov    QWORD PTR [r13+0x14],0x1
    753638a00858:	00 
    753638a00859:	4b 8b 04 dc          	mov    rax,QWORD PTR [r12+r11*8]
    753638a0085d:	48 85 c0             	test   rax,rax
    753638a00860:	0f 84 49 0a 00 18    	je     0x753650a012af
    753638a00866:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    753638a0086c:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    753638a0086f:	45 89 4d 00          	mov    DWORD PTR [r13+0x0],r9d
    753638a00873:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    753638a00877:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    753638a0087b:	48 85 c0             	test   rax,rax
    753638a0087e:	0f 84 a0 0a 00 18    	je     0x753650a01324
    753638a00884:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    753638a0088a:	8b 04 28             	mov    eax,DWORD PTR [rax+rbp*1]
    753638a0088d:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    753638a00891:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    753638a00898:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a0089f:	02 
    753638a008a0:	b8 92 00 01 00       	mov    eax,0x10092
    753638a008a5:	ba 92 00 01 00       	mov    edx,0x10092
    753638a008aa:	72 07                	jb     0x753638a008b3
    753638a008ac:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    753638a008b3:	41 81 f8 8e 00 01 00 	cmp    r8d,0x1008e
    753638a008ba:	0f 44 c2             	cmove  eax,edx
    753638a008bd:	89 c2                	mov    edx,eax
    753638a008bf:	83 f9 02             	cmp    ecx,0x2
    753638a008c2:	72 07                	jb     0x753638a008cb
    753638a008c4:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a008cb:	81 ff 8e 00 01 00    	cmp    edi,0x1008e
    753638a008d1:	0f 44 c2             	cmove  eax,edx
    753638a008d4:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a008db:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a008e2:	28 03 01 00 
    753638a008e6:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a008ed:	83 c0 1c             	add    eax,0x1c
    753638a008f0:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a008f7:	39 c8                	cmp    eax,ecx
    753638a008f9:	73 2b                	jae    0x753638a00926
    753638a008fb:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    753638a00902:	03 01 00 
    753638a00905:	75 1f                	jne    0x753638a00926
    753638a00907:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a0090e:	28 03 01 00 
    753638a00912:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a00919:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    753638a00920:	48 83 c4 38          	add    rsp,0x38
    753638a00924:	ff e0                	jmp    rax
    753638a00926:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a0092d:	28 03 01 00 
    753638a00931:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753638a00938:	04 00 00 00 
    753638a0093c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    753638a00943:	1c 00 00 00 
    753638a00947:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a0094e:	01 
    753638a0094f:	48 83 c4 38          	add    rsp,0x38
    753638a00953:	c2 08 00             	ret    0x8
