; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010176(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = add i32 %guard_lb, -65929
  %3 = icmp ult i32 %2, -19
  %4 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb23 = load i32, ptr %4, align 4
  %5 = add i32 %guard_lb23, -65929
  %6 = icmp ult i32 %5, -19
  %7 = and i1 %3, %6
  br i1 %7, label %insn_0x00010176, label %common.ret, !prof !0

insn_0x00010176:                                  ; preds = %entry
  %8 = getelementptr i8, ptr %cpu, i64 24
  %rd = load i32, ptr %8, align 4
  %rd_add = add i32 %rd, 1
  store i32 %rd_add, ptr %8, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %9 = xor i32 %flgs, -1
  %overflow = and i32 %flgn, %9
  %10 = getelementptr i8, ptr %cpu, i64 228
  %11 = getelementptr i8, ptr %cpu, i64 232
  %12 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %12, align 4
  %13 = or i32 %vs_cur, %overflow
  %14 = getelementptr i8, ptr %cpu, i64 248
  store i32 %overflow, ptr %14, align 4
  %15 = getelementptr i8, ptr %cpu, i64 252
  store i32 %overflow, ptr %15, align 4
  store i32 %13, ptr %12, align 4
  %16 = getelementptr i8, ptr %cpu, i64 236
  %17 = getelementptr i8, ptr %cpu, i64 240
  %18 = getelementptr i8, ptr %cpu, i64 20
  %rx = load i32, ptr %18, align 4
  %19 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %19 to i32
  %20 = getelementptr i8, ptr %cpu, i64 276
  store i32 %cc, ptr %20, align 4
  %21 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %21 to i32
  %22 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %22 to i32
  %23 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %23 to i32
  store i32 %az1, ptr %10, align 4
  store i32 %an2, ptr %11, align 4
  store i32 %ac03, ptr %16, align 4
  store i32 %ac03, ptr %17, align 4
  br i1 %19, label %brt_taken, label %insn_0x0001017c

brt_taken:                                        ; preds = %insn_0x00010176
  %24 = getelementptr i8, ptr %cpu, i64 188
  store i32 65938, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %25, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %26 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %26 monotonic, align 4, !range !1
  %27 = icmp ult i32 %chain_total, %chain_budget
  br i1 %27, label %chain_go, label %chain_leave24, !prof !0

insn_0x0001017c:                                  ; preds = %insn_0x00010176
  %28 = getelementptr i8, ptr %cpu, i64 28
  %a = load i32, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i64 16
  %b = load i32, ptr %29, align 4
  %mul = mul i32 %b, %a
  %30 = getelementptr i8, ptr %cpu, i64 52
  %regmv_src = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 4
  store i32 %regmv_src, ptr %31, align 4
  %add32 = add i32 %regmv_src, %mul
  store i32 %add32, ptr %28, align 4
  %flgs4 = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn5 = lshr i32 %add32, 31
  %32 = xor i32 %flgn5, %flgo
  %33 = xor i32 %flgn5, %flgs4
  %34 = and i32 %33, %32
  %35 = icmp eq i32 %add32, 0
  %az7 = zext i1 %35 to i32
  %36 = or i32 %34, %13
  store i32 %34, ptr %14, align 4
  store i32 %34, ptr %15, align 4
  store i32 %36, ptr %12, align 4
  store i32 %flgn5, ptr %20, align 4
  store i32 %az7, ptr %10, align 4
  store i32 %flgn5, ptr %11, align 4
  store i32 1, ptr %16, align 4
  store i32 1, ptr %17, align 4
  %cc_false = icmp sgt i32 %add32, -1
  br i1 %cc_false, label %brcc_taken, label %insn_0x00010186

brcc_taken:                                       ; preds = %insn_0x0001017c
  %37 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %38, align 4
  %chain_total28 = add nuw i32 %chain_packets27, 8
  %39 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %39 monotonic, align 4, !range !1
  %40 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %40, label %chain_go25, label %chain_leave26, !prof !0

insn_0x00010186:                                  ; preds = %insn_0x0001017c
  %rt = load i32, ptr %cpu, align 4
  %xor32 = xor i32 %rt, %add32
  store i32 %xor32, ptr %cpu, align 4
  %41 = icmp eq i32 %xor32, 0
  %az15 = zext i1 %41 to i32
  %an16 = lshr i32 %xor32, 31
  store i32 %az15, ptr %10, align 4
  store i32 %an16, ptr %11, align 4
  store i32 0, ptr %16, align 4
  store i32 0, ptr %17, align 4
  store i32 0, ptr %14, align 4
  store i32 0, ptr %15, align 4
  %42 = getelementptr i8, ptr %cpu, i64 152
  %lc = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 144
  %lt = load i32, ptr %43, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %guard_lb, 65928
  %hwloop_cond = and i1 %at_lb, %lc_gt1
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65932
  %44 = getelementptr i8, ptr %cpu, i64 156
  %lc17 = load i32, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i64 148
  %lt18 = load i32, ptr %45, align 4
  %lc_gt119 = icmp ugt i32 %lc17, 1
  %at_lb20 = icmp eq i32 %guard_lb23, 65928
  %hwloop_cond21 = and i1 %at_lb20, %lc_gt119
  %hwloop_rets22 = select i1 %hwloop_cond21, i32 %lt18, i32 %hwloop_rets
  %46 = getelementptr i8, ptr %cpu, i64 168
  store i32 %hwloop_rets22, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets36 = load i32, ptr %48, align 4
  %chain_total37 = add nuw i32 %chain_packets36, 10
  %49 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget38 = load atomic i32, ptr %49 monotonic, align 4, !range !1
  %50 = icmp ult i32 %chain_total37, %chain_budget38
  br i1 %50, label %chain_go34, label %chain_leave35, !prof !0

common.ret.sink.split:                            ; preds = %chain_leave24, %chain_leave26, %chain_leave35
  %.sink45 = phi i32 [ 4, %chain_leave35 ], [ 2, %chain_leave26 ], [ 2, %chain_leave24 ]
  %.sink = phi i32 [ 10, %chain_leave35 ], [ 8, %chain_leave26 ], [ 3, %chain_leave24 ]
  %51 = getelementptr i8, ptr %cpu, i64 292
  store i32 %.sink45, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 308
  store i32 %.sink, ptr %52, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink43 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %53 = getelementptr i8, ptr %cpu, i64 %.sink43
  store i8 1, ptr %53, align 1
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527504
  %slot_pc = load i32, ptr %chain_slot, align 4
  %54 = icmp eq i32 %slot_pc, 65938
  br i1 %54, label %chain_hit, label %chain_leave24, !prof !0

chain_leave24:                                    ; preds = %chain_go, %brt_taken
  store i32 65938, ptr %24, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65938, ptr %24, align 4
  store i32 %chain_total, ptr %25, align 4
  %55 = getelementptr i8, ptr %chain_table, i64 527512
  %chain_fn = load ptr, ptr %55, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go25:                                       ; preds = %brcc_taken
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 527232
  %slot_pc31 = load i32, ptr %chain_slot30, align 4
  %56 = icmp eq i32 %slot_pc31, 65904
  br i1 %56, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_go25, %brcc_taken
  store i32 65904, ptr %37, align 4
  br label %common.ret.sink.split

chain_hit32:                                      ; preds = %chain_go25
  store i32 65904, ptr %37, align 4
  store i32 %chain_total28, ptr %38, align 4
  %57 = getelementptr i8, ptr %chain_table, i64 527240
  %chain_fn33 = load ptr, ptr %57, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go34:                                       ; preds = %insn_0x00010186
  %chain_slot39 = getelementptr i8, ptr %chain_table, i64 526464
  %slot_pc40 = load i32, ptr %chain_slot39, align 4
  %58 = icmp eq i32 %slot_pc40, 65808
  br i1 %58, label %chain_hit41, label %chain_leave35, !prof !0

chain_leave35:                                    ; preds = %chain_go34, %insn_0x00010186
  store i32 65808, ptr %47, align 4
  br label %common.ret.sink.split

chain_hit41:                                      ; preds = %chain_go34
  store i32 65808, ptr %47, align 4
  store i32 %chain_total37, ptr %48, align 4
  %59 = getelementptr i8, ptr %chain_table, i64 526472
  %chain_fn42 = load ptr, ptr %59, align 8
  musttail call swifttailcc void %chain_fn42(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
