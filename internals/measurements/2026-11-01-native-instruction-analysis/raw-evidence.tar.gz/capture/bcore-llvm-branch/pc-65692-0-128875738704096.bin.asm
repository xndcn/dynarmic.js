
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65692-0-128875738704096.bin:     file format binary


Disassembly of section .data:

0000753638a028e0 <.data>:
    753638a028e0:	48 83 ec 18          	sub    rsp,0x18
    753638a028e4:	ba 41 ff fe ff       	mov    edx,0xfffeff41
    753638a028e9:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a028f0:	01 d6                	add    esi,edx
    753638a028f2:	b1 01                	mov    cl,0x1
    753638a028f4:	b8 65 01 00 00       	mov    eax,0x165
    753638a028f9:	83 fe dc             	cmp    esi,0xffffffdc
    753638a028fc:	0f 87 c9 03 00 00    	ja     0x753638a02ccb
    753638a02902:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a02909:	83 fa dc             	cmp    edx,0xffffffdc
    753638a0290c:	0f 87 b9 03 00 00    	ja     0x753638a02ccb
    753638a02912:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    753638a02919:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    753638a0291d:	f6 c1 03             	test   cl,0x3
    753638a02920:	0f 85 5e 0e 00 18    	jne    0x753650a03784
    753638a02926:	4d 8b 85 38 01 00 00 	mov    r8,QWORD PTR [r13+0x138]
    753638a0292d:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    753638a02934:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    753638a02938:	48 89 c8             	mov    rax,rcx
    753638a0293b:	48 c1 e8 0c          	shr    rax,0xc
    753638a0293f:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02943:	48 85 c0             	test   rax,rax
    753638a02946:	0f 84 8f 0e 00 18    	je     0x753650a037db
    753638a0294c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a02952:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a02955:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    753638a02959:	0f 85 c1 0e 00 18    	jne    0x753650a03820
    753638a0295f:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    753638a02963:	f6 c3 03             	test   bl,0x3
    753638a02966:	0f 85 0c 0f 00 18    	jne    0x753650a03878
    753638a0296c:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    753638a02970:	48 89 d8             	mov    rax,rbx
    753638a02973:	48 c1 e8 0c          	shr    rax,0xc
    753638a02977:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a0297b:	48 85 c0             	test   rax,rax
    753638a0297e:	0f 84 58 0f 00 18    	je     0x753650a038dc
    753638a02984:	89 d9                	mov    ecx,ebx
    753638a02986:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a0298c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0298f:	83 c3 04             	add    ebx,0x4
    753638a02992:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    753638a02996:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    753638a0299a:	0f 85 8c 0f 00 18    	jne    0x753650a0392c
    753638a029a0:	41 8b 6d 1c          	mov    ebp,DWORD PTR [r13+0x1c]
    753638a029a4:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    753638a029a8:	31 c0                	xor    eax,eax
    753638a029aa:	89 eb                	mov    ebx,ebp
    753638a029ac:	ff c3                	inc    ebx
    753638a029ae:	0f 94 c0             	sete   al
    753638a029b1:	41 89 5d 1c          	mov    DWORD PTR [r13+0x1c],ebx
    753638a029b5:	89 ea                	mov    edx,ebp
    753638a029b7:	c1 ea 1f             	shr    edx,0x1f
    753638a029ba:	41 89 dc             	mov    r12d,ebx
    753638a029bd:	41 c1 ec 1f          	shr    r12d,0x1f
    753638a029c1:	c4 c2 68 f2 d4       	andn   edx,edx,r12d
    753638a029c6:	31 f6                	xor    esi,esi
    753638a029c8:	85 db                	test   ebx,ebx
    753638a029ca:	40 0f 94 c6          	sete   sil
    753638a029ce:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    753638a029d5:	45 89 a5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r12d
    753638a029dc:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    753638a029e3:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    753638a029ea:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    753638a029f1:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    753638a029f8:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    753638a029ff:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    753638a02a06:	00 
    753638a02a07:	f6 c1 03             	test   cl,0x3
    753638a02a0a:	0f 85 74 0f 00 18    	jne    0x753650a03984
    753638a02a10:	48 89 c8             	mov    rax,rcx
    753638a02a13:	48 c1 e8 0c          	shr    rax,0xc
    753638a02a17:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02a1b:	48 85 c0             	test   rax,rax
    753638a02a1e:	0f 84 c2 0f 00 18    	je     0x753650a039e6
    753638a02a24:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a02a2a:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    753638a02a2d:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    753638a02a31:	0f 85 0f 10 00 18    	jne    0x753650a03a46
    753638a02a37:	83 c5 fb             	add    ebp,0xfffffffb
    753638a02a3a:	89 e8                	mov    eax,ebp
    753638a02a3c:	c1 e8 1f             	shr    eax,0x1f
    753638a02a3f:	44 09 e0             	or     eax,r12d
    753638a02a42:	31 c9                	xor    ecx,ecx
    753638a02a44:	83 fb 06             	cmp    ebx,0x6
    753638a02a47:	0f 93 c1             	setae  cl
    753638a02a4a:	31 d2                	xor    edx,edx
    753638a02a4c:	85 ed                	test   ebp,ebp
    753638a02a4e:	0f 94 c2             	sete   dl
    753638a02a51:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    753638a02a58:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    753638a02a5f:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    753638a02a66:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    753638a02a6d:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    753638a02a74:	74 53                	je     0x753638a02ac9
    753638a02a76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    753638a02a7d:	84 00 01 00 
    753638a02a81:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a02a88:	83 c0 07             	add    eax,0x7
    753638a02a8b:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a02a92:	39 c8                	cmp    eax,ecx
    753638a02a94:	0f 83 ce 0c 00 18    	jae    0x753650a03768
    753638a02a9a:	81 bf 20 04 08 00 84 	cmp    DWORD PTR [rdi+0x80420],0x10084
    753638a02aa1:	00 01 00 
    753638a02aa4:	0f 85 be 0c 00 18    	jne    0x753650a03768
    753638a02aaa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    753638a02ab1:	84 00 01 00 
    753638a02ab5:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a02abc:	48 8b 87 28 04 08 00 	mov    rax,QWORD PTR [rdi+0x80428]
    753638a02ac3:	48 83 c4 18          	add    rsp,0x18
    753638a02ac7:	ff e0                	jmp    rax
    753638a02ac9:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    753638a02ad0:	00 
    753638a02ad1:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    753638a02ad8:	00 
    753638a02ad9:	49 8b 40 78          	mov    rax,QWORD PTR [r8+0x78]
    753638a02add:	48 85 c0             	test   rax,rax
    753638a02ae0:	0f 84 d2 0f 00 18    	je     0x753650a03ab8
    753638a02ae6:	c7 40 10 02 00 00 00 	mov    DWORD PTR [rax+0x10],0x2
    753638a02aed:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    753638a02af1:	0f 85 25 10 00 18    	jne    0x753650a03b1c
    753638a02af7:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    753638a02afb:	40 f6 c5 03          	test   bpl,0x3
    753638a02aff:	0f 85 79 10 00 18    	jne    0x753650a03b7e
    753638a02b05:	48 89 e8             	mov    rax,rbp
    753638a02b08:	48 c1 e8 0c          	shr    rax,0xc
    753638a02b0c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02b10:	48 85 c0             	test   rax,rax
    753638a02b13:	0f 84 c6 10 00 18    	je     0x753650a03bdf
    753638a02b19:	89 e9                	mov    ecx,ebp
    753638a02b1b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a02b21:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    753638a02b24:	8d 75 04             	lea    esi,[rbp+0x4]
    753638a02b27:	89 f0                	mov    eax,esi
    753638a02b29:	c1 e8 0c             	shr    eax,0xc
    753638a02b2c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02b30:	48 85 c0             	test   rax,rax
    753638a02b33:	0f 84 05 11 00 18    	je     0x753650a03c3e
    753638a02b39:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02b3f:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    753638a02b43:	8d 75 08             	lea    esi,[rbp+0x8]
    753638a02b46:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    753638a02b4a:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    753638a02b51:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a02b55:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    753638a02b5c:	00 
    753638a02b5d:	89 f0                	mov    eax,esi
    753638a02b5f:	c1 e8 0c             	shr    eax,0xc
    753638a02b62:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02b66:	48 85 c0             	test   rax,rax
    753638a02b69:	0f 84 31 11 00 18    	je     0x753650a03ca0
    753638a02b6f:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02b75:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02b78:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    753638a02b7c:	8d 75 0c             	lea    esi,[rbp+0xc]
    753638a02b7f:	89 f0                	mov    eax,esi
    753638a02b81:	c1 e8 0c             	shr    eax,0xc
    753638a02b84:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02b88:	48 85 c0             	test   rax,rax
    753638a02b8b:	0f 84 6a 11 00 18    	je     0x753650a03cfb
    753638a02b91:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02b97:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02b9a:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    753638a02b9e:	8d 75 10             	lea    esi,[rbp+0x10]
    753638a02ba1:	89 f0                	mov    eax,esi
    753638a02ba3:	c1 e8 0c             	shr    eax,0xc
    753638a02ba6:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02baa:	48 85 c0             	test   rax,rax
    753638a02bad:	0f 84 a3 11 00 18    	je     0x753650a03d56
    753638a02bb3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02bb9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02bbc:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    753638a02bc0:	8d 75 14             	lea    esi,[rbp+0x14]
    753638a02bc3:	89 f0                	mov    eax,esi
    753638a02bc5:	c1 e8 0c             	shr    eax,0xc
    753638a02bc8:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02bcc:	48 85 c0             	test   rax,rax
    753638a02bcf:	0f 84 dc 11 00 18    	je     0x753650a03db1
    753638a02bd5:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02bdb:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02bde:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    753638a02be2:	8d 75 18             	lea    esi,[rbp+0x18]
    753638a02be5:	89 f0                	mov    eax,esi
    753638a02be7:	c1 e8 0c             	shr    eax,0xc
    753638a02bea:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02bee:	48 85 c0             	test   rax,rax
    753638a02bf1:	0f 84 15 12 00 18    	je     0x753650a03e0c
    753638a02bf7:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02bfd:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02c00:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    753638a02c04:	8d 75 1c             	lea    esi,[rbp+0x1c]
    753638a02c07:	89 f0                	mov    eax,esi
    753638a02c09:	c1 e8 0c             	shr    eax,0xc
    753638a02c0c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02c10:	48 85 c0             	test   rax,rax
    753638a02c13:	0f 84 4e 12 00 18    	je     0x753650a03e67
    753638a02c19:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02c1f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02c22:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    753638a02c26:	89 ee                	mov    esi,ebp
    753638a02c28:	83 c6 20             	add    esi,0x20
    753638a02c2b:	89 f0                	mov    eax,esi
    753638a02c2d:	c1 e8 0c             	shr    eax,0xc
    753638a02c30:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    753638a02c34:	48 85 c0             	test   rax,rax
    753638a02c37:	0f 84 85 12 00 18    	je     0x753650a03ec2
    753638a02c3d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02c43:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02c46:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    753638a02c4a:	8d 45 24             	lea    eax,[rbp+0x24]
    753638a02c4d:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    753638a02c51:	b1 01                	mov    cl,0x1
    753638a02c53:	bb 02 00 00 00       	mov    ebx,0x2
    753638a02c58:	bd 0f 00 00 00       	mov    ebp,0xf
    753638a02c5d:	41 f6 c7 01          	test   r15b,0x1
    753638a02c61:	0f 85 ac 12 00 18    	jne    0x753650a03f13
    753638a02c67:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a02c6e:	01 e8                	add    eax,ebp
    753638a02c70:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a02c77:	39 d0                	cmp    eax,edx
    753638a02c79:	0f 83 2d 0e 00 18    	jae    0x753650a03aac
    753638a02c7f:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    753638a02c86:	00 
    753638a02c87:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753638a02c8d:	44 39 3c 17          	cmp    DWORD PTR [rdi+rdx*1],r15d
    753638a02c91:	0f 85 15 0e 00 18    	jne    0x753650a03aac
    753638a02c97:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    753638a02c9e:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a02ca5:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a02cac:	00 
    753638a02cad:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    753638a02cb2:	48 83 c4 18          	add    rsp,0x18
    753638a02cb6:	ff e0                	jmp    rax
    753638a02cb8:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a02cbf:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a02cc6:	b8 28 01 00 00       	mov    eax,0x128
    753638a02ccb:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a02cd0:	48 83 c4 18          	add    rsp,0x18
    753638a02cd4:	c2 08 00             	ret    0x8
