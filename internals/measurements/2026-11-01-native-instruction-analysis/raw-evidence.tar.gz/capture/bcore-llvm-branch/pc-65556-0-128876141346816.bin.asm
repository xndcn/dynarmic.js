
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65556-0-128876141346816.bin:     file format binary


Disassembly of section .data:

0000753650a00000 <.data>:
    753650a00000:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    753650a00007:	e9 f1 05 00 e8       	jmp    0x753638a005fd
    753650a0000c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00013:	02 00 00 00 
    753650a00017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0001e:	01 00 00 00 
    753650a00022:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a00029:	62 00 00 
    753650a0002c:	48 89 fb             	mov    rbx,rdi
    753650a0002f:	4c 89 ef             	mov    rdi,r13
    753650a00032:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    753650a00037:	ba 14 00 01 00       	mov    edx,0x10014
    753650a0003c:	44 89 c9             	mov    ecx,r9d
    753650a0003f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a00045:	ff d0                	call   rax
    753650a00047:	48 89 df             	mov    rdi,rbx
    753650a0004a:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00051:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00058:	00 
    753650a00059:	41 bc 02 00 00 00    	mov    r12d,0x2
    753650a0005f:	bd 01 00 00 00       	mov    ebp,0x1
    753650a00064:	e9 ee 04 00 e8       	jmp    0x753638a00557
    753650a00069:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00070:	02 00 00 00 
    753650a00074:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0007b:	01 00 00 00 
    753650a0007f:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a00086:	62 00 00 
    753650a00089:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0008e:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00093:	44 89 ce             	mov    esi,r9d
    753650a00096:	4c 89 c5             	mov    rbp,r8
    753650a00099:	49 89 de             	mov    r14,rbx
    753650a0009c:	4c 89 cb             	mov    rbx,r9
    753650a0009f:	4d 89 d7             	mov    r15,r10
    753650a000a2:	ff d0                	call   rax
    753650a000a4:	4d 89 fa             	mov    r10,r15
    753650a000a7:	49 89 d9             	mov    r9,rbx
    753650a000aa:	4c 89 f3             	mov    rbx,r14
    753650a000ad:	49 89 e8             	mov    r8,rbp
    753650a000b0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a000b5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a000bc:	00 
    753650a000bd:	84 c9                	test   cl,cl
    753650a000bf:	0f 84 e0 00 00 e8    	je     0x753638a001a5
    753650a000c5:	e9 db 02 00 00       	jmp    0x753650a003a5
    753650a000ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a000d1:	02 00 00 00 
    753650a000d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a000dc:	01 00 00 00 
    753650a000e0:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a000e7:	62 00 00 
    753650a000ea:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a000ef:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a000f4:	44 89 de             	mov    esi,r11d
    753650a000f7:	4c 89 c5             	mov    rbp,r8
    753650a000fa:	49 89 de             	mov    r14,rbx
    753650a000fd:	4c 89 cb             	mov    rbx,r9
    753650a00100:	4d 89 d7             	mov    r15,r10
    753650a00103:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00108:	ff d0                	call   rax
    753650a0010a:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a0010f:	4d 89 fa             	mov    r10,r15
    753650a00112:	49 89 d9             	mov    r9,rbx
    753650a00115:	4c 89 f3             	mov    rbx,r14
    753650a00118:	49 89 e8             	mov    r8,rbp
    753650a0011b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00120:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00127:	00 
    753650a00128:	84 c9                	test   cl,cl
    753650a0012a:	0f 84 a4 00 00 e8    	je     0x753638a001d4
    753650a00130:	e9 70 02 00 00       	jmp    0x753650a003a5
    753650a00135:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0013c:	02 00 00 00 
    753650a00140:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a00147:	01 00 00 00 
    753650a0014b:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a00152:	62 00 00 
    753650a00155:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0015a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a0015f:	4c 89 c5             	mov    rbp,r8
    753650a00162:	49 89 de             	mov    r14,rbx
    753650a00165:	4c 89 cb             	mov    rbx,r9
    753650a00168:	4d 89 d7             	mov    r15,r10
    753650a0016b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00170:	ff d0                	call   rax
    753650a00172:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00177:	4d 89 fa             	mov    r10,r15
    753650a0017a:	49 89 d9             	mov    r9,rbx
    753650a0017d:	4c 89 f3             	mov    rbx,r14
    753650a00180:	49 89 e8             	mov    r8,rbp
    753650a00183:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00188:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0018f:	00 
    753650a00190:	84 c9                	test   cl,cl
    753650a00192:	0f 84 6f 00 00 e8    	je     0x753638a00207
    753650a00198:	e9 08 02 00 00       	jmp    0x753650a003a5
    753650a0019d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a001a4:	02 00 00 00 
    753650a001a8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a001af:	01 00 00 00 
    753650a001b3:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a001ba:	62 00 00 
    753650a001bd:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a001c2:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a001c7:	4c 89 c5             	mov    rbp,r8
    753650a001ca:	49 89 de             	mov    r14,rbx
    753650a001cd:	4c 89 cb             	mov    rbx,r9
    753650a001d0:	4d 89 d7             	mov    r15,r10
    753650a001d3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a001d8:	ff d0                	call   rax
    753650a001da:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a001df:	4d 89 fa             	mov    r10,r15
    753650a001e2:	49 89 d9             	mov    r9,rbx
    753650a001e5:	4c 89 f3             	mov    rbx,r14
    753650a001e8:	49 89 e8             	mov    r8,rbp
    753650a001eb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a001f0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a001f7:	00 
    753650a001f8:	84 c9                	test   cl,cl
    753650a001fa:	0f 84 3a 00 00 e8    	je     0x753638a0023a
    753650a00200:	e9 a0 01 00 00       	jmp    0x753650a003a5
    753650a00205:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0020c:	02 00 00 00 
    753650a00210:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a00217:	01 00 00 00 
    753650a0021b:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a00222:	62 00 00 
    753650a00225:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0022a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a0022f:	4c 89 c5             	mov    rbp,r8
    753650a00232:	49 89 de             	mov    r14,rbx
    753650a00235:	4c 89 cb             	mov    rbx,r9
    753650a00238:	4d 89 d7             	mov    r15,r10
    753650a0023b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00240:	ff d0                	call   rax
    753650a00242:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00247:	4d 89 fa             	mov    r10,r15
    753650a0024a:	49 89 d9             	mov    r9,rbx
    753650a0024d:	4c 89 f3             	mov    rbx,r14
    753650a00250:	49 89 e8             	mov    r8,rbp
    753650a00253:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00258:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0025f:	00 
    753650a00260:	84 c9                	test   cl,cl
    753650a00262:	0f 84 02 00 00 e8    	je     0x753638a0026a
    753650a00268:	e9 38 01 00 00       	jmp    0x753650a003a5
    753650a0026d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00274:	02 00 00 00 
    753650a00278:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0027f:	01 00 00 00 
    753650a00283:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0028a:	62 00 00 
    753650a0028d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00292:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00297:	4c 89 c5             	mov    rbp,r8
    753650a0029a:	49 89 de             	mov    r14,rbx
    753650a0029d:	4c 89 cb             	mov    rbx,r9
    753650a002a0:	4d 89 d7             	mov    r15,r10
    753650a002a3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a002a8:	ff d0                	call   rax
    753650a002aa:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a002af:	4d 89 fa             	mov    r10,r15
    753650a002b2:	49 89 d9             	mov    r9,rbx
    753650a002b5:	4c 89 f3             	mov    rbx,r14
    753650a002b8:	49 89 e8             	mov    r8,rbp
    753650a002bb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a002c0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a002c7:	00 
    753650a002c8:	84 c9                	test   cl,cl
    753650a002ca:	0f 84 ca ff ff e7    	je     0x753638a0029a
    753650a002d0:	e9 d0 00 00 00       	jmp    0x753650a003a5
    753650a002d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a002dc:	02 00 00 00 
    753650a002e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a002e7:	01 00 00 00 
    753650a002eb:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a002f2:	62 00 00 
    753650a002f5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a002fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a002ff:	4c 89 c5             	mov    rbp,r8
    753650a00302:	49 89 de             	mov    r14,rbx
    753650a00305:	4c 89 cb             	mov    rbx,r9
    753650a00308:	4d 89 d7             	mov    r15,r10
    753650a0030b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00310:	ff d0                	call   rax
    753650a00312:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00317:	4d 89 fa             	mov    r10,r15
    753650a0031a:	49 89 d9             	mov    r9,rbx
    753650a0031d:	4c 89 f3             	mov    rbx,r14
    753650a00320:	49 89 e8             	mov    r8,rbp
    753650a00323:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    753650a00328:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0032d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00334:	00 
    753650a00335:	84 c9                	test   cl,cl
    753650a00337:	0f 84 8c ff ff e7    	je     0x753638a002c9
    753650a0033d:	eb 66                	jmp    0x753650a003a5
    753650a0033f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    753650a00346:	16 00 01 00 
    753650a0034a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00351:	02 00 00 00 
    753650a00355:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0035c:	01 00 00 00 
    753650a00360:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a00367:	62 00 00 
    753650a0036a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0036f:	4c 89 ef             	mov    rdi,r13
    753650a00372:	4c 89 c5             	mov    rbp,r8
    753650a00375:	4c 89 cb             	mov    rbx,r9
    753650a00378:	4d 89 d7             	mov    r15,r10
    753650a0037b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00380:	ff d0                	call   rax
    753650a00382:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00387:	4d 89 fa             	mov    r10,r15
    753650a0038a:	49 89 d9             	mov    r9,rbx
    753650a0038d:	49 89 e8             	mov    r8,rbp
    753650a00390:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00395:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0039c:	00 
    753650a0039d:	84 c9                	test   cl,cl
    753650a0039f:	0f 84 34 ff ff e7    	je     0x753638a002d9
    753650a003a5:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a003ac:	e9 a8 fc ff ff       	jmp    0x753650a00059
    753650a003b1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    753650a003b8:	1a 00 01 00 
    753650a003bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a003c3:	04 00 00 00 
    753650a003c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a003ce:	03 00 00 00 
    753650a003d2:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a003d9:	62 00 00 
    753650a003dc:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a003e1:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a003e6:	4c 89 c5             	mov    rbp,r8
    753650a003e9:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a003ee:	4d 89 d7             	mov    r15,r10
    753650a003f1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a003f6:	ff d0                	call   rax
    753650a003f8:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a003fd:	4d 89 fa             	mov    r10,r15
    753650a00400:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a00405:	49 89 e8             	mov    r8,rbp
    753650a00408:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0040d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00414:	00 
    753650a00415:	84 c9                	test   cl,cl
    753650a00417:	0f 84 fc fe ff e7    	je     0x753638a00319
    753650a0041d:	e9 e7 00 00 00       	jmp    0x753650a00509
    753650a00422:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    753650a00429:	1a 00 01 00 
    753650a0042d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a00434:	04 00 00 00 
    753650a00438:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a0043f:	03 00 00 00 
    753650a00443:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0044a:	62 00 00 
    753650a0044d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00452:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00457:	89 ee                	mov    esi,ebp
    753650a00459:	89 da                	mov    edx,ebx
    753650a0045b:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    753650a00460:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a00465:	4c 89 d3             	mov    rbx,r10
    753650a00468:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a0046d:	ff d0                	call   rax
    753650a0046f:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00474:	49 89 da             	mov    r10,rbx
    753650a00477:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a0047c:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a00481:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00486:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0048d:	00 
    753650a0048e:	84 c9                	test   cl,cl
    753650a00490:	0f 84 a6 fe ff e7    	je     0x753638a0033c
    753650a00496:	eb 71                	jmp    0x753650a00509
    753650a00498:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    753650a0049f:	1e 00 01 00 
    753650a004a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a004aa:	04 00 00 00 
    753650a004ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a004b5:	03 00 00 00 
    753650a004b9:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a004c0:	62 00 00 
    753650a004c3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a004c8:	4c 89 ef             	mov    rdi,r13
    753650a004cb:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    753650a004d0:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a004d5:	4c 89 d3             	mov    rbx,r10
    753650a004d8:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a004dd:	ff d0                	call   rax
    753650a004df:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a004e4:	49 89 da             	mov    r10,rbx
    753650a004e7:	4c 89 f3             	mov    rbx,r14
    753650a004ea:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a004ef:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a004f4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a004f9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00500:	00 
    753650a00501:	84 c9                	test   cl,cl
    753650a00503:	0f 84 4c fe ff e7    	je     0x753638a00355
    753650a00509:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00510:	41 bc 04 00 00 00    	mov    r12d,0x4
    753650a00516:	bd 03 00 00 00       	mov    ebp,0x3
    753650a0051b:	e9 37 00 00 e8       	jmp    0x753638a00557
    753650a00520:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00525:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a0052a:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a0052f:	4c 89 c3             	mov    rbx,r8
    753650a00532:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00537:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    753650a0053e:	26 00 01 00 
    753650a00542:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00549:	02 00 00 00 
    753650a0054d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a00554:	06 00 00 00 
    753650a00558:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0055f:	62 00 00 
    753650a00562:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00567:	be 00 f0 00 00       	mov    esi,0xf000
    753650a0056c:	ff d0                	call   rax
    753650a0056e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00575:	00 
    753650a00576:	84 c9                	test   cl,cl
    753650a00578:	0f 85 09 06 00 00    	jne    0x753650a00b87
    753650a0057e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00583:	49 89 d8             	mov    r8,rbx
    753650a00586:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a0058b:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00590:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00595:	4c 89 f3             	mov    rbx,r14
    753650a00598:	e9 d7 fd ff e7       	jmp    0x753638a00374
    753650a0059d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    753650a005a4:	40 00 01 00 
    753650a005a8:	b1 01                	mov    cl,0x1
    753650a005aa:	bd 09 00 00 00       	mov    ebp,0x9
    753650a005af:	41 bc 02 00 00 00    	mov    r12d,0x2
    753650a005b5:	e9 43 00 00 e8       	jmp    0x753638a005fd
    753650a005ba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    753650a005c1:	34 00 01 00 
    753650a005c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a005cc:	02 00 00 00 
    753650a005d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a005d7:	0c 00 00 00 
    753650a005db:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a005e2:	62 00 00 
    753650a005e5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a005ea:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a005ef:	be 10 f0 00 00       	mov    esi,0xf010
    753650a005f4:	ba 03 00 00 00       	mov    edx,0x3
    753650a005f9:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    753650a005fe:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a00603:	4c 89 d3             	mov    rbx,r10
    753650a00606:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a0060b:	ff d0                	call   rax
    753650a0060d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00612:	49 89 da             	mov    r10,rbx
    753650a00615:	4c 89 f3             	mov    rbx,r14
    753650a00618:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a0061d:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a00622:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00627:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0062e:	00 
    753650a0062f:	84 c9                	test   cl,cl
    753650a00631:	0f 84 b6 fd ff e7    	je     0x753638a003ed
    753650a00637:	eb 6a                	jmp    0x753650a006a3
    753650a00639:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    753650a00640:	36 00 01 00 
    753650a00644:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0064b:	02 00 00 00 
    753650a0064f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a00656:	0c 00 00 00 
    753650a0065a:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a00661:	62 00 00 
    753650a00664:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00669:	4c 89 ef             	mov    rdi,r13
    753650a0066c:	4d 89 c6             	mov    r14,r8
    753650a0066f:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a00674:	4c 89 d3             	mov    rbx,r10
    753650a00677:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a0067c:	ff d0                	call   rax
    753650a0067e:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00683:	49 89 da             	mov    r10,rbx
    753650a00686:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a0068b:	4d 89 f0             	mov    r8,r14
    753650a0068e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00693:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0069a:	00 
    753650a0069b:	84 c9                	test   cl,cl
    753650a0069d:	0f 84 53 fd ff e7    	je     0x753638a003f6
    753650a006a3:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a006aa:	41 bc 02 00 00 00    	mov    r12d,0x2
    753650a006b0:	bd 0c 00 00 00       	mov    ebp,0xc
    753650a006b5:	e9 9d fe ff e7       	jmp    0x753638a00557
    753650a006ba:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a006bf:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a006c4:	4d 89 cf             	mov    r15,r9
    753650a006c7:	4c 89 c3             	mov    rbx,r8
    753650a006ca:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a006cf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    753650a006d6:	38 00 01 00 
    753650a006da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a006e1:	04 00 00 00 
    753650a006e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a006ec:	0e 00 00 00 
    753650a006f0:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a006f7:	62 00 00 
    753650a006fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a006ff:	89 ee                	mov    esi,ebp
    753650a00701:	ff d0                	call   rax
    753650a00703:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0070a:	00 
    753650a0070b:	84 c9                	test   cl,cl
    753650a0070d:	0f 85 60 04 00 00    	jne    0x753650a00b73
    753650a00713:	89 c5                	mov    ebp,eax
    753650a00715:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0071a:	49 89 d8             	mov    r8,rbx
    753650a0071d:	4d 89 f9             	mov    r9,r15
    753650a00720:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00725:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a0072a:	e9 e5 fc ff e7       	jmp    0x753638a00414
    753650a0072f:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00734:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00739:	4d 89 cf             	mov    r15,r9
    753650a0073c:	4c 89 c3             	mov    rbx,r8
    753650a0073f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00744:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    753650a0074b:	38 00 01 00 
    753650a0074f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a00756:	04 00 00 00 
    753650a0075a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a00761:	0e 00 00 00 
    753650a00765:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0076c:	62 00 00 
    753650a0076f:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00774:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    753650a00779:	ff d0                	call   rax
    753650a0077b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00782:	00 
    753650a00783:	84 c9                	test   cl,cl
    753650a00785:	0f 85 e8 03 00 00    	jne    0x753650a00b73
    753650a0078b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00790:	49 89 d8             	mov    r8,rbx
    753650a00793:	4d 89 f9             	mov    r9,r15
    753650a00796:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a0079b:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a007a0:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753650a007a5:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    753650a007aa:	48 89 c3             	mov    rbx,rax
    753650a007ad:	e9 8c fc ff e7       	jmp    0x753638a0043e
    753650a007b2:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a007b7:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a007bc:	4d 89 d7             	mov    r15,r10
    753650a007bf:	48 89 d6             	mov    rsi,rdx
    753650a007c2:	4c 89 cd             	mov    rbp,r9
    753650a007c5:	4c 89 c3             	mov    rbx,r8
    753650a007c8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a007cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a007d4:	3c 00 01 00 
    753650a007d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a007df:	02 00 00 00 
    753650a007e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a007ea:	0f 00 00 00 
    753650a007ee:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a007f5:	62 00 00 
    753650a007f8:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a007fd:	ff d0                	call   rax
    753650a007ff:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00806:	00 
    753650a00807:	84 c9                	test   cl,cl
    753650a00809:	0f 85 48 03 00 00    	jne    0x753650a00b57
    753650a0080f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00814:	49 89 d8             	mov    r8,rbx
    753650a00817:	49 89 e9             	mov    r9,rbp
    753650a0081a:	4d 89 fa             	mov    r10,r15
    753650a0081d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00822:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753650a00827:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    753650a0082c:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a00831:	e9 37 fc ff e7       	jmp    0x753638a0046d
    753650a00836:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a0083b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a00840:	4d 89 d7             	mov    r15,r10
    753650a00843:	4c 89 cd             	mov    rbp,r9
    753650a00846:	4c 89 c3             	mov    rbx,r8
    753650a00849:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0084e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a00855:	3c 00 01 00 
    753650a00859:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00860:	02 00 00 00 
    753650a00864:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a0086b:	0f 00 00 00 
    753650a0086f:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00876:	62 00 00 
    753650a00879:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a0087e:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    753650a00883:	ff d0                	call   rax
    753650a00885:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0088c:	00 
    753650a0088d:	84 c9                	test   cl,cl
    753650a0088f:	0f 85 c2 02 00 00    	jne    0x753650a00b57
    753650a00895:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0089a:	49 89 d8             	mov    r8,rbx
    753650a0089d:	49 89 e9             	mov    r9,rbp
    753650a008a0:	4d 89 fa             	mov    r10,r15
    753650a008a3:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a008a8:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753650a008ad:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    753650a008b2:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a008b7:	e9 d5 fb ff e7       	jmp    0x753638a00491
    753650a008bc:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a008c1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a008c6:	4d 89 d7             	mov    r15,r10
    753650a008c9:	4c 89 cd             	mov    rbp,r9
    753650a008cc:	4c 89 c3             	mov    rbx,r8
    753650a008cf:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a008d4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a008db:	3c 00 01 00 
    753650a008df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a008e6:	02 00 00 00 
    753650a008ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a008f1:	0f 00 00 00 
    753650a008f5:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a008fc:	62 00 00 
    753650a008ff:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00904:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    753650a00909:	ff d0                	call   rax
    753650a0090b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00912:	00 
    753650a00913:	84 c9                	test   cl,cl
    753650a00915:	0f 85 3c 02 00 00    	jne    0x753650a00b57
    753650a0091b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00920:	49 89 d8             	mov    r8,rbx
    753650a00923:	49 89 e9             	mov    r9,rbp
    753650a00926:	4d 89 fa             	mov    r10,r15
    753650a00929:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a0092e:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753650a00933:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    753650a00938:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a0093d:	e9 73 fb ff e7       	jmp    0x753638a004b5
    753650a00942:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a00947:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a0094c:	4d 89 d7             	mov    r15,r10
    753650a0094f:	4c 89 cd             	mov    rbp,r9
    753650a00952:	4c 89 c3             	mov    rbx,r8
    753650a00955:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0095a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a00961:	3c 00 01 00 
    753650a00965:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0096c:	02 00 00 00 
    753650a00970:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a00977:	0f 00 00 00 
    753650a0097b:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00982:	62 00 00 
    753650a00985:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a0098a:	89 ce                	mov    esi,ecx
    753650a0098c:	ff d0                	call   rax
    753650a0098e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00995:	00 
    753650a00996:	84 c9                	test   cl,cl
    753650a00998:	0f 85 b9 01 00 00    	jne    0x753650a00b57
    753650a0099e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a009a3:	49 89 d8             	mov    r8,rbx
    753650a009a6:	49 89 e9             	mov    r9,rbp
    753650a009a9:	4d 89 fa             	mov    r10,r15
    753650a009ac:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a009b1:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753650a009b6:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a009bb:	e9 17 fb ff e7       	jmp    0x753638a004d7
    753650a009c0:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a009c5:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    753650a009ca:	4d 89 d7             	mov    r15,r10
    753650a009cd:	4c 89 cd             	mov    rbp,r9
    753650a009d0:	4c 89 c3             	mov    rbx,r8
    753650a009d3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a009d8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a009df:	3c 00 01 00 
    753650a009e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a009ea:	02 00 00 00 
    753650a009ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a009f5:	0f 00 00 00 
    753650a009f9:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00a00:	62 00 00 
    753650a00a03:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00a08:	ff d0                	call   rax
    753650a00a0a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00a11:	00 
    753650a00a12:	84 c9                	test   cl,cl
    753650a00a14:	0f 85 3d 01 00 00    	jne    0x753650a00b57
    753650a00a1a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00a1f:	49 89 d8             	mov    r8,rbx
    753650a00a22:	49 89 e9             	mov    r9,rbp
    753650a00a25:	4d 89 fa             	mov    r10,r15
    753650a00a28:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    753650a00a2d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a00a32:	e9 c2 fa ff e7       	jmp    0x753638a004f9
    753650a00a37:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    753650a00a3c:	4d 89 d7             	mov    r15,r10
    753650a00a3f:	4c 89 cd             	mov    rbp,r9
    753650a00a42:	4c 89 c3             	mov    rbx,r8
    753650a00a45:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00a4a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a00a51:	3c 00 01 00 
    753650a00a55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00a5c:	02 00 00 00 
    753650a00a60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a00a67:	0f 00 00 00 
    753650a00a6b:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00a72:	62 00 00 
    753650a00a75:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00a7a:	44 89 de             	mov    esi,r11d
    753650a00a7d:	ff d0                	call   rax
    753650a00a7f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00a86:	00 
    753650a00a87:	84 c9                	test   cl,cl
    753650a00a89:	0f 85 c8 00 00 00    	jne    0x753650a00b57
    753650a00a8f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00a94:	49 89 d8             	mov    r8,rbx
    753650a00a97:	49 89 e9             	mov    r9,rbp
    753650a00a9a:	4d 89 fa             	mov    r10,r15
    753650a00a9d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    753650a00aa2:	e9 76 fa ff e7       	jmp    0x753638a0051d
    753650a00aa7:	48 89 dd             	mov    rbp,rbx
    753650a00aaa:	4c 89 c3             	mov    rbx,r8
    753650a00aad:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a00ab2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    753650a00ab9:	3c 00 01 00 
    753650a00abd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00ac4:	02 00 00 00 
    753650a00ac8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a00acf:	0f 00 00 00 
    753650a00ad3:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00ada:	62 00 00 
    753650a00add:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    753650a00ae2:	44 89 ce             	mov    esi,r9d
    753650a00ae5:	ff d0                	call   rax
    753650a00ae7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00aee:	00 
    753650a00aef:	84 c9                	test   cl,cl
    753650a00af1:	75 64                	jne    0x753650a00b57
    753650a00af3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00af8:	49 89 d8             	mov    r8,rbx
    753650a00afb:	48 89 eb             	mov    rbx,rbp
    753650a00afe:	e9 36 fa ff e7       	jmp    0x753638a00539
    753650a00b03:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    753650a00b0a:	3e 00 01 00 
    753650a00b0e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00b15:	02 00 00 00 
    753650a00b19:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    753650a00b20:	10 00 00 00 
    753650a00b24:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a00b2b:	62 00 00 
    753650a00b2e:	49 89 ff             	mov    r15,rdi
    753650a00b31:	4c 89 ef             	mov    rdi,r13
    753650a00b34:	be 2a 00 00 00       	mov    esi,0x2a
    753650a00b39:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    753650a00b3e:	ff d0                	call   rax
    753650a00b40:	4c 89 ff             	mov    rdi,r15
    753650a00b43:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00b4a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a00b51:	00 
    753650a00b52:	e9 00 fa ff e7       	jmp    0x753638a00557
    753650a00b57:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00b5e:	41 bc 02 00 00 00    	mov    r12d,0x2
    753650a00b64:	bd 0f 00 00 00       	mov    ebp,0xf
    753650a00b69:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a00b6e:	e9 e4 f9 ff e7       	jmp    0x753638a00557
    753650a00b73:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00b7a:	41 bc 04 00 00 00    	mov    r12d,0x4
    753650a00b80:	bd 0e 00 00 00       	mov    ebp,0xe
    753650a00b85:	eb e2                	jmp    0x753650a00b69
    753650a00b87:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    753650a00b8e:	41 bc 02 00 00 00    	mov    r12d,0x2
    753650a00b94:	bd 06 00 00 00       	mov    ebp,0x6
    753650a00b99:	eb ce                	jmp    0x753650a00b69
