
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66626-0-128875738699200.bin:     file format binary


Disassembly of section .data:

0000753638a015c0 <.data>:
    753638a015c0:	50                   	push   rax
    753638a015c1:	ba b1 fb fe ff       	mov    edx,0xfffefbb1
    753638a015c6:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a015cd:	01 d6                	add    esi,edx
    753638a015cf:	b1 01                	mov    cl,0x1
    753638a015d1:	b8 65 01 00 00       	mov    eax,0x165
    753638a015d6:	83 fe f2             	cmp    esi,0xfffffff2
    753638a015d9:	0f 87 c5 00 00 00    	ja     0x753638a016a4
    753638a015df:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a015e6:	83 fa f2             	cmp    edx,0xfffffff2
    753638a015e9:	0f 87 b5 00 00 00    	ja     0x753638a016a4
    753638a015ef:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    753638a015f6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753638a015fd:	41 c7 45 24 9c 11 01 	mov    DWORD PTR [r13+0x24],0x1119c
    753638a01604:	00 
    753638a01605:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    753638a01609:	8d 34 8d 9c 11 01 00 	lea    esi,[rcx*4+0x1119c]
    753638a01610:	41 89 75 28          	mov    DWORD PTR [r13+0x28],esi
    753638a01614:	89 f1                	mov    ecx,esi
    753638a01616:	c1 e9 0c             	shr    ecx,0xc
    753638a01619:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753638a0161d:	48 85 c0             	test   rax,rax
    753638a01620:	0f 84 32 0f 00 18    	je     0x753650a02558
    753638a01626:	81 e6 fc 0f 00 00    	and    esi,0xffc
    753638a0162c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a0162f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    753638a01633:	b1 01                	mov    cl,0x1
    753638a01635:	bd 05 00 00 00       	mov    ebp,0x5
    753638a0163a:	a8 01                	test   al,0x1
    753638a0163c:	0f 85 67 0f 00 18    	jne    0x753650a025a9
    753638a01642:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753638a01649:	01 ea                	add    edx,ebp
    753638a0164b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    753638a01652:	39 f2                	cmp    edx,esi
    753638a01654:	73 30                	jae    0x753638a01686
    753638a01656:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    753638a0165d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    753638a01663:	39 04 33             	cmp    DWORD PTR [rbx+rsi*1],eax
    753638a01666:	75 1e                	jne    0x753638a01686
    753638a01668:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a0166f:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753638a01676:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a0167d:	00 
    753638a0167e:	48 8b 44 33 08       	mov    rax,QWORD PTR [rbx+rsi*1+0x8]
    753638a01683:	59                   	pop    rcx
    753638a01684:	ff e0                	jmp    rax
    753638a01686:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a0168d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753638a01694:	02 00 00 00 
    753638a01698:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a0169f:	b8 28 01 00 00       	mov    eax,0x128
    753638a016a4:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a016a9:	58                   	pop    rax
    753638a016aa:	c2 08 00             	ret    0x8
