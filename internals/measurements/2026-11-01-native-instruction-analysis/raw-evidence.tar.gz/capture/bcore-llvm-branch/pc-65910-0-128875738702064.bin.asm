
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65910-0-128875738702064.bin:     file format binary


Disassembly of section .data:

0000753638a020f0 <.data>:
    753638a020f0:	45 8b 8d a0 00 00 00 	mov    r9d,DWORD PTR [r13+0xa0]
    753638a020f7:	41 8d 89 77 fe fe ff 	lea    ecx,[r9-0x10189]
    753638a020fe:	b8 65 01 00 00       	mov    eax,0x165
    753638a02103:	83 f9 ec             	cmp    ecx,0xffffffec
    753638a02106:	0f 87 72 02 00 00    	ja     0x753638a0237e
    753638a0210c:	45 8b 85 a4 00 00 00 	mov    r8d,DWORD PTR [r13+0xa4]
    753638a02113:	41 8d b0 77 fe fe ff 	lea    esi,[r8-0x10189]
    753638a0211a:	83 fe ec             	cmp    esi,0xffffffec
    753638a0211d:	0f 87 5b 02 00 00    	ja     0x753638a0237e
    753638a02123:	4d 8b 95 50 01 00 00 	mov    r10,QWORD PTR [r13+0x150]
    753638a0212a:	41 8b 7d 14          	mov    edi,DWORD PTR [r13+0x14]
    753638a0212e:	41 8b 75 18          	mov    esi,DWORD PTR [r13+0x18]
    753638a02132:	8d 5e 01             	lea    ebx,[rsi+0x1]
    753638a02135:	41 89 5d 18          	mov    DWORD PTR [r13+0x18],ebx
    753638a02139:	c1 ee 1f             	shr    esi,0x1f
    753638a0213c:	89 dd                	mov    ebp,ebx
    753638a0213e:	c1 ed 1f             	shr    ebp,0x1f
    753638a02141:	c4 e2 48 f2 ed       	andn   ebp,esi,ebp
    753638a02146:	41 8b b5 00 01 00 00 	mov    esi,DWORD PTR [r13+0x100]
    753638a0214d:	09 ee                	or     esi,ebp
    753638a0214f:	41 89 ad f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebp
    753638a02156:	41 89 ad fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebp
    753638a0215d:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    753638a02164:	31 ed                	xor    ebp,ebp
    753638a02166:	31 c9                	xor    ecx,ecx
    753638a02168:	31 d2                	xor    edx,edx
    753638a0216a:	31 c0                	xor    eax,eax
    753638a0216c:	39 fb                	cmp    ebx,edi
    753638a0216e:	40 0f 97 c5          	seta   bpl
    753638a02172:	0f 96 c1             	setbe  cl
    753638a02175:	0f 93 c2             	setae  dl
    753638a02178:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    753638a0217f:	0f 94 c0             	sete   al
    753638a02182:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    753638a02189:	41 89 ad e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebp
    753638a02190:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    753638a02197:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    753638a0219e:	72 50                	jb     0x753638a021f0
    753638a021a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    753638a021a7:	92 01 01 00 
    753638a021ab:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a021b2:	83 c1 03             	add    ecx,0x3
    753638a021b5:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    753638a021bc:	39 c1                	cmp    ecx,eax
    753638a021be:	0f 83 2b 0e 00 18    	jae    0x753650a02fef
    753638a021c4:	41 81 ba 90 0c 08 00 	cmp    DWORD PTR [r10+0x80c90],0x10192
    753638a021cb:	92 01 01 00 
    753638a021cf:	0f 85 1a 0e 00 18    	jne    0x753650a02fef
    753638a021d5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    753638a021dc:	92 01 01 00 
    753638a021e0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a021e7:	49 8b 82 98 0c 08 00 	mov    rax,QWORD PTR [r10+0x80c98]
    753638a021ee:	ff e0                	jmp    rax
    753638a021f0:	41 8b 45 10          	mov    eax,DWORD PTR [r13+0x10]
    753638a021f4:	41 8b 4d 34          	mov    ecx,DWORD PTR [r13+0x34]
    753638a021f8:	41 0f af 45 1c       	imul   eax,DWORD PTR [r13+0x1c]
    753638a021fd:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    753638a02201:	8d 3c 01             	lea    edi,[rcx+rax*1]
    753638a02204:	41 89 7d 1c          	mov    DWORD PTR [r13+0x1c],edi
    753638a02208:	c1 e8 1f             	shr    eax,0x1f
    753638a0220b:	c1 e9 1f             	shr    ecx,0x1f
    753638a0220e:	89 fa                	mov    edx,edi
    753638a02210:	c1 ea 1f             	shr    edx,0x1f
    753638a02213:	31 d1                	xor    ecx,edx
    753638a02215:	31 d0                	xor    eax,edx
    753638a02217:	21 c8                	and    eax,ecx
    753638a02219:	09 c6                	or     esi,eax
    753638a0221b:	31 c9                	xor    ecx,ecx
    753638a0221d:	85 ff                	test   edi,edi
    753638a0221f:	0f 94 c1             	sete   cl
    753638a02222:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    753638a02229:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    753638a02230:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    753638a02237:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    753638a0223e:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    753638a02245:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    753638a0224c:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    753638a02253:	00 00 00 
    753638a02256:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    753638a0225d:	78 50                	js     0x753638a022af
    753638a0225f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753638a02266:	70 01 01 00 
    753638a0226a:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a02271:	83 c1 08             	add    ecx,0x8
    753638a02274:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    753638a0227b:	39 c1                	cmp    ecx,eax
    753638a0227d:	0f 83 99 0d 00 18    	jae    0x753650a0301c
    753638a02283:	41 81 ba 80 0b 08 00 	cmp    DWORD PTR [r10+0x80b80],0x10170
    753638a0228a:	70 01 01 00 
    753638a0228e:	0f 85 88 0d 00 18    	jne    0x753650a0301c
    753638a02294:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753638a0229b:	70 01 01 00 
    753638a0229f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a022a6:	49 8b 82 88 0b 08 00 	mov    rax,QWORD PTR [r10+0x80b88]
    753638a022ad:	ff e0                	jmp    rax
    753638a022af:	31 c0                	xor    eax,eax
    753638a022b1:	41 33 7d 00          	xor    edi,DWORD PTR [r13+0x0]
    753638a022b5:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    753638a022b9:	0f 94 c0             	sete   al
    753638a022bc:	c1 ef 1f             	shr    edi,0x1f
    753638a022bf:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    753638a022c6:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    753638a022cd:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    753638a022d4:	00 00 00 00 
    753638a022d8:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a022df:	00 00 00 00 
    753638a022e3:	41 8b bd 9c 00 00 00 	mov    edi,DWORD PTR [r13+0x9c]
    753638a022ea:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a022f1:	02 
    753638a022f2:	be 8c 01 01 00       	mov    esi,0x1018c
    753638a022f7:	bb 8c 01 01 00       	mov    ebx,0x1018c
    753638a022fc:	72 07                	jb     0x753638a02305
    753638a022fe:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    753638a02305:	41 81 f9 88 01 01 00 	cmp    r9d,0x10188
    753638a0230c:	0f 44 f3             	cmove  esi,ebx
    753638a0230f:	89 f2                	mov    edx,esi
    753638a02311:	83 ff 02             	cmp    edi,0x2
    753638a02314:	72 07                	jb     0x753638a0231d
    753638a02316:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a0231d:	41 81 f8 88 01 01 00 	cmp    r8d,0x10188
    753638a02324:	0f 44 f2             	cmove  esi,edx
    753638a02327:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    753638a0232e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753638a02335:	10 01 01 00 
    753638a02339:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a02340:	83 c1 0a             	add    ecx,0xa
    753638a02343:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    753638a0234a:	39 c1                	cmp    ecx,eax
    753638a0234c:	0f 83 dc 0c 00 18    	jae    0x753650a0302e
    753638a02352:	41 81 ba 80 08 08 00 	cmp    DWORD PTR [r10+0x80880],0x10110
    753638a02359:	10 01 01 00 
    753638a0235d:	0f 85 cb 0c 00 18    	jne    0x753650a0302e
    753638a02363:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753638a0236a:	10 01 01 00 
    753638a0236e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a02375:	49 8b 82 88 08 08 00 	mov    rax,QWORD PTR [r10+0x80888]
    753638a0237c:	ff e0                	jmp    rax
    753638a0237e:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    753638a02384:	c2 08 00             	ret    0x8
