
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65932-0-128875738703296.bin:     file format binary


Disassembly of section .data:

0000753638a025c0 <.data>:
    753638a025c0:	48 83 ec 18          	sub    rsp,0x18
    753638a025c4:	ba 65 fe fe ff       	mov    edx,0xfffefe65
    753638a025c9:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a025d0:	01 d6                	add    esi,edx
    753638a025d2:	b1 01                	mov    cl,0x1
    753638a025d4:	b8 65 01 00 00       	mov    eax,0x165
    753638a025d9:	83 fe f0             	cmp    esi,0xfffffff0
    753638a025dc:	0f 87 a2 02 00 00    	ja     0x753638a02884
    753638a025e2:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a025e9:	83 fa f0             	cmp    edx,0xfffffff0
    753638a025ec:	0f 87 92 02 00 00    	ja     0x753638a02884
    753638a025f2:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    753638a025f9:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    753638a02600:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    753638a02604:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    753638a02608:	8d 51 01             	lea    edx,[rcx+0x1]
    753638a0260b:	41 89 55 18          	mov    DWORD PTR [r13+0x18],edx
    753638a0260f:	c1 e9 1f             	shr    ecx,0x1f
    753638a02612:	89 d6                	mov    esi,edx
    753638a02614:	c1 ee 1f             	shr    esi,0x1f
    753638a02617:	c4 e2 70 f2 ce       	andn   ecx,ecx,esi
    753638a0261c:	41 89 8d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ecx
    753638a02623:	41 89 8d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ecx
    753638a0262a:	41 09 8d 00 01 00 00 	or     DWORD PTR [r13+0x100],ecx
    753638a02631:	31 c9                	xor    ecx,ecx
    753638a02633:	31 f6                	xor    esi,esi
    753638a02635:	31 ff                	xor    edi,edi
    753638a02637:	31 db                	xor    ebx,ebx
    753638a02639:	39 c2                	cmp    edx,eax
    753638a0263b:	0f 97 c1             	seta   cl
    753638a0263e:	40 0f 96 c6          	setbe  sil
    753638a02642:	40 0f 93 c7          	setae  dil
    753638a02646:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    753638a0264d:	0f 94 c3             	sete   bl
    753638a02650:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    753638a02657:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    753638a0265e:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    753638a02665:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    753638a0266c:	0f 82 ab 01 00 00    	jb     0x753638a0281d
    753638a02672:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    753638a02676:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    753638a0267a:	31 c9                	xor    ecx,ecx
    753638a0267c:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    753638a02680:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    753638a02684:	0f 94 c1             	sete   cl
    753638a02687:	c1 e8 1f             	shr    eax,0x1f
    753638a0268a:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    753638a02691:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    753638a02698:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    753638a0269f:	00 00 00 00 
    753638a026a3:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a026aa:	00 00 00 00 
    753638a026ae:	40 f6 c5 03          	test   bpl,0x3
    753638a026b2:	0f 85 fa 0c 00 18    	jne    0x753650a033b2
    753638a026b8:	48 89 e8             	mov    rax,rbp
    753638a026bb:	48 c1 e8 0c          	shr    rax,0xc
    753638a026bf:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a026c3:	48 85 c0             	test   rax,rax
    753638a026c6:	0f 84 47 0d 00 18    	je     0x753650a03413
    753638a026cc:	89 e9                	mov    ecx,ebp
    753638a026ce:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a026d4:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    753638a026d7:	8d 75 04             	lea    esi,[rbp+0x4]
    753638a026da:	89 f0                	mov    eax,esi
    753638a026dc:	c1 e8 0c             	shr    eax,0xc
    753638a026df:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a026e3:	48 85 c0             	test   rax,rax
    753638a026e6:	0f 84 84 0d 00 18    	je     0x753650a03470
    753638a026ec:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a026f2:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    753638a026f6:	8d 75 08             	lea    esi,[rbp+0x8]
    753638a026f9:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    753638a026fd:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    753638a02704:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a02708:	89 f0                	mov    eax,esi
    753638a0270a:	c1 e8 0c             	shr    eax,0xc
    753638a0270d:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a02711:	48 85 c0             	test   rax,rax
    753638a02714:	0f 84 b2 0d 00 18    	je     0x753650a034cc
    753638a0271a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02720:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02723:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    753638a02727:	8d 75 0c             	lea    esi,[rbp+0xc]
    753638a0272a:	89 f0                	mov    eax,esi
    753638a0272c:	c1 e8 0c             	shr    eax,0xc
    753638a0272f:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a02733:	48 85 c0             	test   rax,rax
    753638a02736:	0f 84 e9 0d 00 18    	je     0x753650a03525
    753638a0273c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02742:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02745:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    753638a02749:	8d 75 10             	lea    esi,[rbp+0x10]
    753638a0274c:	89 f0                	mov    eax,esi
    753638a0274e:	c1 e8 0c             	shr    eax,0xc
    753638a02751:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a02755:	48 85 c0             	test   rax,rax
    753638a02758:	0f 84 20 0e 00 18    	je     0x753650a0357e
    753638a0275e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02764:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02767:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    753638a0276b:	8d 75 14             	lea    esi,[rbp+0x14]
    753638a0276e:	89 f0                	mov    eax,esi
    753638a02770:	c1 e8 0c             	shr    eax,0xc
    753638a02773:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a02777:	48 85 c0             	test   rax,rax
    753638a0277a:	0f 84 57 0e 00 18    	je     0x753650a035d7
    753638a02780:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a02786:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a02789:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    753638a0278d:	8d 75 18             	lea    esi,[rbp+0x18]
    753638a02790:	89 f0                	mov    eax,esi
    753638a02792:	c1 e8 0c             	shr    eax,0xc
    753638a02795:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a02799:	48 85 c0             	test   rax,rax
    753638a0279c:	0f 84 8e 0e 00 18    	je     0x753650a03630
    753638a027a2:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a027a8:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a027ab:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    753638a027af:	83 c5 1c             	add    ebp,0x1c
    753638a027b2:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    753638a027b6:	b1 01                	mov    cl,0x1
    753638a027b8:	bb 02 00 00 00       	mov    ebx,0x2
    753638a027bd:	bd 07 00 00 00       	mov    ebp,0x7
    753638a027c2:	41 f6 c7 01          	test   r15b,0x1
    753638a027c6:	0f 85 b9 0e 00 18    	jne    0x753650a03685
    753638a027cc:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a027d3:	01 e8                	add    eax,ebp
    753638a027d5:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a027dc:	39 d0                	cmp    eax,edx
    753638a027de:	0f 83 a6 0b 00 18    	jae    0x753650a0338a
    753638a027e4:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    753638a027eb:	00 
    753638a027ec:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753638a027f2:	45 39 3c 10          	cmp    DWORD PTR [r8+rdx*1],r15d
    753638a027f6:	0f 85 8e 0b 00 18    	jne    0x753650a0338a
    753638a027fc:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    753638a02803:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a0280a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a02811:	00 
    753638a02812:	49 8b 44 10 08       	mov    rax,QWORD PTR [r8+rdx*1+0x8]
    753638a02817:	48 83 c4 18          	add    rsp,0x18
    753638a0281b:	ff e0                	jmp    rax
    753638a0281d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753638a02824:	7c 01 01 00 
    753638a02828:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a0282f:	83 c0 03             	add    eax,0x3
    753638a02832:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a02839:	39 c8                	cmp    eax,ecx
    753638a0283b:	0f 83 55 0b 00 18    	jae    0x753650a03396
    753638a02841:	41 81 b8 e0 0b 08 00 	cmp    DWORD PTR [r8+0x80be0],0x1017c
    753638a02848:	7c 01 01 00 
    753638a0284c:	0f 85 44 0b 00 18    	jne    0x753650a03396
    753638a02852:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753638a02859:	7c 01 01 00 
    753638a0285d:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a02864:	49 8b 80 e8 0b 08 00 	mov    rax,QWORD PTR [r8+0x80be8]
    753638a0286b:	48 83 c4 18          	add    rsp,0x18
    753638a0286f:	ff e0                	jmp    rax
    753638a02871:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a02878:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a0287f:	b8 28 01 00 00       	mov    eax,0x128
    753638a02884:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a02889:	48 83 c4 18          	add    rsp,0x18
    753638a0288d:	c2 08 00             	ret    0x8
