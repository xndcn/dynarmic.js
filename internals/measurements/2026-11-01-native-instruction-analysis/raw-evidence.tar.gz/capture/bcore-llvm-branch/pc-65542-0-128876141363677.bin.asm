
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65542-0-128876141363677.bin:     file format binary


Disassembly of section .data:

0000753650a041dd <.data>:
    753650a041dd:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a041e4:	01 
    753650a041e5:	58                   	pop    rax
    753650a041e6:	c2 08 00             	ret    0x8
    753650a041e9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    753650a041f0:	0e 00 01 00 
    753650a041f4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a041fb:	02 00 00 00 
    753650a041ff:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a04206:	03 00 00 00 
    753650a0420a:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a04211:	62 00 00 
    753650a04214:	4c 89 f7             	mov    rdi,r14
    753650a04217:	be 04 00 00 01       	mov    esi,0x1000004
    753650a0421c:	ff d0                	call   rax
    753650a0421e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a04225:	00 
    753650a04226:	0f 84 40 ed ff e7    	je     0x753638a02f6c
    753650a0422c:	eb 3e                	jmp    0x753650a0426c
    753650a0422e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    753650a04235:	10 00 01 00 
    753650a04239:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a04240:	02 00 00 00 
    753650a04244:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a0424b:	03 00 00 00 
    753650a0424f:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a04256:	62 00 00 
    753650a04259:	4c 89 ef             	mov    rdi,r13
    753650a0425c:	ff d0                	call   rax
    753650a0425e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a04265:	00 
    753650a04266:	0f 84 0a ed ff e7    	je     0x753638a02f76
    753650a0426c:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    753650a04273:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753650a0427a:	83 c0 03             	add    eax,0x3
    753650a0427d:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753650a04284:	39 d0                	cmp    eax,edx
    753650a04286:	73 29                	jae    0x753650a042b1
    753650a04288:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    753650a0428f:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753650a04295:	39 0c 13             	cmp    DWORD PTR [rbx+rdx*1],ecx
    753650a04298:	75 17                	jne    0x753650a042b1
    753650a0429a:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753650a042a1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a042a8:	00 
    753650a042a9:	48 8b 44 13 08       	mov    rax,QWORD PTR [rbx+rdx*1+0x8]
    753650a042ae:	59                   	pop    rcx
    753650a042af:	ff e0                	jmp    rax
    753650a042b1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a042b8:	02 00 00 00 
    753650a042bc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a042c3:	03 00 00 00 
    753650a042c7:	58                   	pop    rax
    753650a042c8:	c2 08 00             	ret    0x8
