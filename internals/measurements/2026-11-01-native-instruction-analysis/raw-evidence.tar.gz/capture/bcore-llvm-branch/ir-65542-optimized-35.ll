; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010006(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = add i32 %guard_lb, -65553
  %4 = icmp ult i32 %3, -11
  %5 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb5 = load i32, ptr %5, align 4
  %6 = add i32 %guard_lb5, -65553
  %7 = icmp ult i32 %6, -11
  %8 = and i1 %4, %7
  br i1 %8, label %insn_0x00010006, label %lb_guard_miss, !prof !0

insn_0x00010006:                                  ; preds = %entry
  %9 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %9, align 8
  %10 = getelementptr i8, ptr %cpu, i64 32
  store i32 16777220, ptr %10, align 4
  %val = load i32, ptr %cpu, align 4
  %page_slot = getelementptr ptr, ptr %page_table, i64 4096
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %insn_0x00010006
  %11 = getelementptr i8, ptr %page, i64 4
  store i32 %val, ptr %11, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %insn_0x00010006
  %12 = getelementptr i8, ptr %cpu, i64 188
  store i32 65550, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %14, align 4
  tail call void @mem_write32(ptr %mem, i32 16777220, i32 %val)
  %15 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %15, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %chain_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not = icmp eq i8 %cec_pending, 0
  br i1 %.not, label %insn_0x00010010, label %cec_check, !prof !0

cec_check:                                        ; preds = %page_wr_done
  %16 = getelementptr i8, ptr %cpu, i64 188
  store i32 65552, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %18, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %19 = getelementptr i8, ptr %cpu, i64 296
  %dj3 = load i8, ptr %19, align 1
  %dj_set4.not = icmp eq i8 %dj3, 0
  br i1 %dj_set4.not, label %insn_0x00010010, label %chain_exit, !prof !0

insn_0x00010010:                                  ; preds = %page_wr_done, %cec_check
  %20 = getelementptr i8, ptr %cpu, i64 188
  store i32 65552, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %21, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %22 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %22 monotonic, align 4, !range !2
  %23 = icmp ult i32 %chain_total, %chain_budget
  br i1 %23, label %chain_go, label %chain_leave8, !prof !0

common.ret:                                       ; preds = %chain_leave11, %chain_leave8, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %24 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %24, align 1
  br label %common.ret

chain_go:                                         ; preds = %insn_0x00010010
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524416
  %slot_pc = load i32, ptr %chain_slot, align 4
  %25 = icmp eq i32 %slot_pc, 65552
  br i1 %25, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010010
  store i32 65552, ptr %20, align 4
  %26 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %28, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65552, ptr %20, align 4
  store i32 %chain_total, ptr %21, align 4
  %29 = getelementptr i8, ptr %chain_table, i64 524424
  %chain_fn = load ptr, ptr %29, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %cec_check, %page_wr_slow
  %next_pc9.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc9 = load i32, ptr %next_pc9.in, align 4
  %30 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets12 = load i32, ptr %30, align 4
  %chain_total13 = add nuw i32 %chain_packets12, 3
  %31 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget14 = load atomic i32, ptr %31 monotonic, align 4, !range !2
  %32 = icmp ult i32 %chain_total13, %chain_budget14
  br i1 %32, label %chain_lookup, label %chain_leave11, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %33 = shl i32 %next_pc9, 3
  %34 = and i32 %33, 1048560
  %35 = zext i32 %34 to i64
  %chain_slot15 = getelementptr i8, ptr %chain_table, i64 %35
  %slot_pc16 = load i32, ptr %chain_slot15, align 4
  %36 = icmp eq i32 %slot_pc16, %next_pc9
  br i1 %36, label %chain_hit17, label %chain_leave11, !prof !0

chain_leave11:                                    ; preds = %chain_lookup, %chain_exit
  %37 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %38, align 4
  br label %common.ret

chain_hit17:                                      ; preds = %chain_lookup
  store i32 %chain_total13, ptr %30, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %39, align 1
  %40 = getelementptr i8, ptr %chain_slot15, i64 8
  %chain_fn18 = load ptr, ptr %40, align 8
  musttail call swifttailcc void %chain_fn18(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
