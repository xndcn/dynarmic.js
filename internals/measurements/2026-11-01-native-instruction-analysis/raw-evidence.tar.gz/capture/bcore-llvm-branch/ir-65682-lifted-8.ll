; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010092(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65682
  %6 = icmp ugt i32 %5, 6
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb11 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb11, 0
  %11 = sub i32 %guard_lb11, 65682
  %12 = icmp ugt i32 %11, 6
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010092_entry, label %lb_guard_miss, !prof !0

insn_0x00010092_entry:                            ; preds = %lb_guard
  br label %insn_0x00010092

insn_0x00010092:                                  ; preds = %insn_0x00010092_entry
  %15 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %15, align 4
  %diff = sub i32 %rx, 0
  %16 = icmp eq i32 %diff, 0
  %az = zext i1 %16 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %17 = xor i32 %flgn, %flgs
  %18 = xor i32 %flgs, 0
  %overflow = and i32 %18, %17
  %an = xor i32 %flgn, %overflow
  %19 = icmp ule i32 0, %rx
  %ac0 = zext i1 %19 to i32
  %20 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %26, align 4
  br label %insn_0x00010094_entry

insn_0x00010094_entry:                            ; preds = %insn_0x00010092
  br label %insn_0x00010094

insn_0x00010094:                                  ; preds = %insn_0x00010094_entry
  %cc_false = icmp eq i32 %az, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010094
  %27 = getelementptr i8, ptr %cpu, i32 188
  store i32 65728, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %28, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %29 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %29 monotonic, align 4, !range !1
  %30 = icmp ult i32 %chain_total, %chain_budget
  br i1 %30, label %chain_go, label %chain_leave12, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010094
  br label %insn_0x00010096_entry

insn_0x00010096_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010096

insn_0x00010096:                                  ; preds = %insn_0x00010096_entry
  %31 = getelementptr i8, ptr %cpu, i32 48
  %ptr = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 24
  %val = load i32, ptr %32, align 4
  %33 = and i32 %ptr, 3
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %data_misaligned, label %data_aligned, !prof !2

data_misaligned:                                  ; preds = %insn_0x00010096
  %35 = getelementptr i8, ptr %cpu, i32 188
  store i32 65686, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %37, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65686, i32 %ptr, i32 65536)
  %38 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %38, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010096
  %39 = lshr i32 %ptr, 12
  %page_index = zext i32 %39 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %40 = and i32 %ptr, 4095
  %page_offset = zext i32 %40 to i64
  %41 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %41, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %42 = getelementptr i8, ptr %cpu, i32 188
  store i32 65686, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %44, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %45 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %45, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !2

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %46 = icmp ne i8 %cec_pending, 0
  br i1 %46, label %cec_check, label %cec_checked, !prof !2

did_jump_exit:                                    ; preds = %page_wr_slow
  %47 = getelementptr i8, ptr %cpu, i64 188
  %next_pc13 = load i32, ptr %47, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %48 = getelementptr i8, ptr %cpu, i32 188
  store i32 65688, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %50, align 4
  call void @cec_check_pending(ptr %cpu)
  %51 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %51, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !2

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x00010098_entry

did_jump_exit1:                                   ; preds = %cec_check
  %52 = getelementptr i8, ptr %cpu, i64 188
  %next_pc14 = load i32, ptr %52, align 4
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x00010098_entry:                            ; preds = %cec_checked
  br label %insn_0x00010098

insn_0x00010098:                                  ; preds = %insn_0x00010098_entry
  %53 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %54, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65688
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65692
  %55 = getelementptr i8, ptr %cpu, i32 156
  %lc5 = load i32, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 148
  %lt6 = load i32, ptr %56, align 4
  %lc_gt17 = icmp ugt i32 %lc5, 1
  %at_lb8 = icmp eq i32 %lb1, 65688
  %hwloop_cond9 = and i1 %lc_gt17, %at_lb8
  %hwloop_rets10 = select i1 %hwloop_cond9, i32 %lt6, i32 %hwloop_rets
  %57 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets10, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 188
  store i32 66600, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets17 = load i32, ptr %59, align 4
  %chain_total18 = add nuw i32 %chain_packets17, 4
  %60 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget19 = load atomic i32, ptr %60 monotonic, align 4, !range !1
  %61 = icmp ult i32 %chain_total18, %chain_budget19
  br i1 %61, label %chain_go15, label %chain_leave16, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %62 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %62, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525824
  %63 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %63, align 4
  %64 = icmp eq i32 %slot_pc, 65728
  br i1 %64, label %chain_hit, label %chain_leave12, !prof !0

chain_leave12:                                    ; preds = %chain_go, %brcc_taken
  %65 = getelementptr i8, ptr %cpu, i64 188
  store i32 65728, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %68, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %69 = getelementptr i8, ptr %cpu, i64 188
  store i32 65728, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %70, align 4
  %71 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %71, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go15:                                       ; preds = %insn_0x00010098
  %chain_slot20 = getelementptr i8, ptr %chain_table, i64 532800
  %72 = getelementptr i8, ptr %chain_slot20, i64 0
  %slot_pc21 = load i32, ptr %72, align 4
  %73 = icmp eq i32 %slot_pc21, 66600
  br i1 %73, label %chain_hit22, label %chain_leave16, !prof !0

chain_leave16:                                    ; preds = %chain_go15, %insn_0x00010098
  %74 = getelementptr i8, ptr %cpu, i64 188
  store i32 66600, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %77, align 1
  ret void

chain_hit22:                                      ; preds = %chain_go15
  %78 = getelementptr i8, ptr %cpu, i64 188
  store i32 66600, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total18, ptr %79, align 4
  %80 = getelementptr i8, ptr %chain_slot20, i64 8
  %chain_fn23 = load ptr, ptr %80, align 8
  musttail call swifttailcc void %chain_fn23(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc24 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc13, %did_jump_exit ], [ %next_pc14, %did_jump_exit1 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ]
  %tail25 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %81 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %81, align 4
  %chain_total28 = add nuw i32 %chain_packets27, %packets
  %82 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %82 monotonic, align 4, !range !1
  %83 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %83, label %chain_lookup, label %chain_leave26, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %84 = lshr i32 %next_pc24, 1
  %85 = and i32 %84, 65535
  %86 = zext i32 %85 to i64
  %87 = mul i64 %86, 16
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 %87
  %88 = getelementptr i8, ptr %chain_slot30, i64 0
  %slot_pc31 = load i32, ptr %88, align 4
  %89 = icmp eq i32 %slot_pc31, %next_pc24
  br i1 %89, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_lookup, %chain_exit
  %90 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail25, ptr %91, align 4
  ret void

chain_hit32:                                      ; preds = %chain_lookup
  %92 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %93, align 1
  %94 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %94, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
!2 = !{!"branch_weights", i32 1, i32 1048576}
