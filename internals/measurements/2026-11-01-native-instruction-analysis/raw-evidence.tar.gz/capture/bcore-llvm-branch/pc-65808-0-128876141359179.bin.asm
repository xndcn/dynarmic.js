
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65808-0-128876141359179.bin:     file format binary


Disassembly of section .data:

0000753650a0304b <.data>:
    753650a0304b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    753650a03052:	20 01 01 00 
    753650a03056:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0305d:	04 00 00 00 
    753650a03061:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a03068:	06 00 00 00 
    753650a0306c:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a03073:	62 00 00 
    753650a03076:	48 89 fd             	mov    rbp,rdi
    753650a03079:	4c 89 ef             	mov    rdi,r13
    753650a0307c:	4c 89 c6             	mov    rsi,r8
    753650a0307f:	ba 20 01 01 00       	mov    edx,0x10120
    753650a03084:	89 d9                	mov    ecx,ebx
    753650a03086:	4d 89 c6             	mov    r14,r8
    753650a03089:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a0308f:	ff d0                	call   rax
    753650a03091:	48 89 ef             	mov    rdi,rbp
    753650a03094:	4d 89 f0             	mov    r8,r14
    753650a03097:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a0309e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a030a5:	00 
    753650a030a6:	bb 04 00 00 00       	mov    ebx,0x4
    753650a030ab:	bd 06 00 00 00       	mov    ebp,0x6
    753650a030b0:	e9 66 f4 ff e7       	jmp    0x753638a0251b
    753650a030b5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    753650a030bc:	20 01 01 00 
    753650a030c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a030c7:	04 00 00 00 
    753650a030cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a030d2:	06 00 00 00 
    753650a030d6:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a030dd:	62 00 00 
    753650a030e0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a030e5:	4c 89 c7             	mov    rdi,r8
    753650a030e8:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    753650a030ed:	89 de                	mov    esi,ebx
    753650a030ef:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    753650a030f3:	4c 89 cd             	mov    rbp,r9
    753650a030f6:	4d 89 d7             	mov    r15,r10
    753650a030f9:	44 89 5c 24 10       	mov    DWORD PTR [rsp+0x10],r11d
    753650a030fe:	ff d0                	call   rax
    753650a03100:	44 8b 5c 24 10       	mov    r11d,DWORD PTR [rsp+0x10]
    753650a03105:	4d 89 fa             	mov    r10,r15
    753650a03108:	49 89 e9             	mov    r9,rbp
    753650a0310b:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    753650a03110:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03115:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a03119:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03120:	00 
    753650a03121:	84 c9                	test   cl,cl
    753650a03123:	0f 84 56 f3 ff e7    	je     0x753638a0247f
    753650a03129:	e9 e3 00 00 00       	jmp    0x753650a03211
    753650a0312e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    753650a03135:	20 01 01 00 
    753650a03139:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a03140:	04 00 00 00 
    753650a03144:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a0314b:	06 00 00 00 
    753650a0314f:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a03156:	62 00 00 
    753650a03159:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0315e:	4c 89 c7             	mov    rdi,r8
    753650a03161:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    753650a03166:	89 ee                	mov    esi,ebp
    753650a03168:	44 89 da             	mov    edx,r11d
    753650a0316b:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    753650a0316f:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a03174:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    753650a03179:	ff d0                	call   rax
    753650a0317b:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    753650a03180:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a03185:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    753650a0318a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0318f:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a03193:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0319a:	00 
    753650a0319b:	84 c9                	test   cl,cl
    753650a0319d:	0f 84 ff f2 ff e7    	je     0x753638a024a2
    753650a031a3:	eb 6c                	jmp    0x753650a03211
    753650a031a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    753650a031ac:	24 01 01 00 
    753650a031b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a031b7:	04 00 00 00 
    753650a031bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a031c2:	06 00 00 00 
    753650a031c6:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a031cd:	62 00 00 
    753650a031d0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a031d5:	4c 89 ef             	mov    rdi,r13
    753650a031d8:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    753650a031dc:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    753650a031e1:	48 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],rbx
    753650a031e6:	4c 89 cb             	mov    rbx,r9
    753650a031e9:	ff d0                	call   rax
    753650a031eb:	49 89 d9             	mov    r9,rbx
    753650a031ee:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    753650a031f3:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    753650a031f8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a031fd:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a03201:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03208:	00 
    753650a03209:	84 c9                	test   cl,cl
    753650a0320b:	0f 84 a3 f2 ff e7    	je     0x753638a024b4
    753650a03211:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a03218:	e9 89 fe ff ff       	jmp    0x753650a030a6
    753650a0321d:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a03222:	49 89 f7             	mov    r15,rsi
    753650a03225:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0322a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    753650a03231:	24 01 01 00 
    753650a03235:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0323c:	04 00 00 00 
    753650a03240:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a03247:	07 00 00 00 
    753650a0324b:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03252:	62 00 00 
    753650a03255:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    753650a03259:	4c 89 c7             	mov    rdi,r8
    753650a0325c:	89 ee                	mov    esi,ebp
    753650a0325e:	ff d0                	call   rax
    753650a03260:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03267:	00 
    753650a03268:	84 c9                	test   cl,cl
    753650a0326a:	0f 85 cb 00 00 00    	jne    0x753650a0333b
    753650a03270:	89 c5                	mov    ebp,eax
    753650a03272:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a03276:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0327b:	4c 89 fe             	mov    rsi,r15
    753650a0327e:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a03283:	e9 42 f2 ff e7       	jmp    0x753638a024ca
    753650a03288:	49 89 f7             	mov    r15,rsi
    753650a0328b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03290:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    753650a03297:	24 01 01 00 
    753650a0329b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a032a2:	04 00 00 00 
    753650a032a6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a032ad:	07 00 00 00 
    753650a032b1:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a032b8:	62 00 00 
    753650a032bb:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    753650a032bf:	4c 89 c7             	mov    rdi,r8
    753650a032c2:	89 de                	mov    esi,ebx
    753650a032c4:	ff d0                	call   rax
    753650a032c6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a032cd:	00 
    753650a032ce:	84 c9                	test   cl,cl
    753650a032d0:	75 69                	jne    0x753650a0333b
    753650a032d2:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a032d6:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a032db:	4c 89 fe             	mov    rsi,r15
    753650a032de:	e9 fd f1 ff e7       	jmp    0x753638a024e0
    753650a032e3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012e
    753650a032ea:	2e 01 01 00 
    753650a032ee:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a032f5:	02 00 00 00 
    753650a032f9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    753650a03300:	0b 00 00 00 
    753650a03304:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a0330b:	62 00 00 
    753650a0330e:	49 89 ff             	mov    r15,rdi
    753650a03311:	4c 89 ef             	mov    rdi,r13
    753650a03314:	be 2a 00 00 00       	mov    esi,0x2a
    753650a03319:	4c 89 c2             	mov    rdx,r8
    753650a0331c:	4d 89 c6             	mov    r14,r8
    753650a0331f:	ff d0                	call   rax
    753650a03321:	4c 89 ff             	mov    rdi,r15
    753650a03324:	4d 89 f0             	mov    r8,r14
    753650a03327:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a0332e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03335:	00 
    753650a03336:	e9 e0 f1 ff e7       	jmp    0x753638a0251b
    753650a0333b:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a03342:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03347:	bd 07 00 00 00       	mov    ebp,0x7
    753650a0334c:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    753650a03350:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03355:	e9 c1 f1 ff e7       	jmp    0x753638a0251b
