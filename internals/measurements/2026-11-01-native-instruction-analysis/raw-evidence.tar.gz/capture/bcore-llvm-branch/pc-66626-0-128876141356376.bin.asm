
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66626-0-128876141356376.bin:     file format binary


Disassembly of section .data:

0000753650a02558 <.data>:
    753650a02558:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    753650a0255f:	4c 04 01 00 
    753650a02563:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0256a:	02 00 00 00 
    753650a0256e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    753650a02575:	04 00 00 00 
    753650a02579:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02580:	62 00 00 
    753650a02583:	4c 89 f7             	mov    rdi,r14
    753650a02586:	ff d0                	call   rax
    753650a02588:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0258f:	00 
    753650a02590:	84 c9                	test   cl,cl
    753650a02592:	0f 84 97 f0 ff e7    	je     0x753638a0162f
    753650a02598:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a0259f:	bd 04 00 00 00       	mov    ebp,0x4
    753650a025a4:	e9 99 f0 ff e7       	jmp    0x753638a01642
    753650a025a9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044e
    753650a025b0:	4e 04 01 00 
    753650a025b4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a025bb:	02 00 00 00 
    753650a025bf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a025c6:	05 00 00 00 
    753650a025ca:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a025d1:	62 00 00 
    753650a025d4:	4c 89 ef             	mov    rdi,r13
    753650a025d7:	be 2a 00 00 00       	mov    esi,0x2a
    753650a025dc:	4c 89 f2             	mov    rdx,r14
    753650a025df:	ff d0                	call   rax
    753650a025e1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a025e8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a025ef:	00 
    753650a025f0:	e9 4d f0 ff e7       	jmp    0x753638a01642
