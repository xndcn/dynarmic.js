; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010170(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = add i32 %guard_lb, -65907
  %3 = icmp ult i32 %2, -3
  %4 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb7 = load i32, ptr %4, align 4
  %5 = add i32 %guard_lb7, -65907
  %6 = icmp ult i32 %5, -3
  %7 = and i1 %3, %6
  br i1 %7, label %insn_0x00010170, label %common.ret, !prof !0

insn_0x00010170:                                  ; preds = %entry
  %8 = getelementptr i8, ptr %cpu, i64 28
  %rs = load i32, ptr %8, align 4
  %rt = load i32, ptr %cpu, align 4
  %add32 = add i32 %rt, %rs
  store i32 %add32, ptr %cpu, align 4
  %flgs = lshr i32 %rs, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %9 = xor i32 %flgn, %flgo
  %10 = xor i32 %flgn, %flgs
  %11 = and i32 %10, %9
  %12 = xor i32 %rs, -1
  %13 = icmp ugt i32 %rt, %12
  %ac0 = zext i1 %13 to i32
  %14 = icmp eq i32 %add32, 0
  %az = zext i1 %14 to i32
  %15 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 232
  store i32 %flgn, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %17, align 4
  %18 = or i32 %vs_cur, %11
  %19 = getelementptr i8, ptr %cpu, i64 248
  store i32 %11, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i64 252
  store i32 %11, ptr %20, align 4
  store i32 %18, ptr %17, align 4
  %21 = getelementptr i8, ptr %cpu, i64 236
  store i32 %ac0, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 240
  store i32 %ac0, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i64 152
  %lc = load i32, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i64 144
  %lt = load i32, ptr %24, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %guard_lb, 65906
  %hwloop_cond = and i1 %at_lb, %lc_gt1
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65910
  %25 = getelementptr i8, ptr %cpu, i64 156
  %lc1 = load i32, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 148
  %lt2 = load i32, ptr %26, align 4
  %lc_gt13 = icmp ugt i32 %lc1, 1
  %at_lb4 = icmp eq i32 %guard_lb7, 65906
  %hwloop_cond5 = and i1 %at_lb4, %lc_gt13
  %hwloop_rets6 = select i1 %hwloop_cond5, i32 %lt2, i32 %hwloop_rets
  %27 = getelementptr i8, ptr %cpu, i64 168
  store i32 %hwloop_rets6, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 188
  store i32 65840, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %29, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %30 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %30 monotonic, align 4, !range !1
  %31 = icmp ult i32 %chain_total, %chain_budget
  br i1 %31, label %chain_go, label %chain_leave8, !prof !0

common.ret:                                       ; preds = %entry, %chain_leave8
  %.sink9 = phi i64 [ 296, %chain_leave8 ], [ 357, %entry ]
  %32 = getelementptr i8, ptr %cpu, i64 %.sink9
  store i8 1, ptr %32, align 1
  ret void

chain_go:                                         ; preds = %insn_0x00010170
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526720
  %slot_pc = load i32, ptr %chain_slot, align 4
  %33 = icmp eq i32 %slot_pc, 65840
  br i1 %33, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010170
  store i32 65840, ptr %28, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %35, align 4
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65840, ptr %28, align 4
  store i32 %chain_total, ptr %29, align 4
  %36 = getelementptr i8, ptr %chain_table, i64 526728
  %chain_fn = load ptr, ptr %36, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
