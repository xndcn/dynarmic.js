
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65668-0-128876141363288.bin:     file format binary


Disassembly of section .data:

0000753650a04058 <.data>:
    753650a04058:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a0405f:	01 
    753650a04060:	48 83 c4 18          	add    rsp,0x18
    753650a04064:	c2 08 00             	ret    0x8
    753650a04067:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753650a0406c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    753650a04073:	08 00 00 00 
    753650a04077:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0407e:	01 00 00 00 
    753650a04082:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a04089:	62 00 00 
    753650a0408c:	4c 89 ef             	mov    rdi,r13
    753650a0408f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a04094:	4c 89 f6             	mov    rsi,r14
    753650a04097:	ba 84 00 01 00       	mov    edx,0x10084
    753650a0409c:	45 31 c0             	xor    r8d,r8d
    753650a0409f:	ff d0                	call   rax
    753650a040a1:	b9 08 00 00 00       	mov    ecx,0x8
    753650a040a6:	b8 01 00 00 00       	mov    eax,0x1
    753650a040ab:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    753650a040b2:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753650a040b9:	01 c2                	add    edx,eax
    753650a040bb:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    753650a040c2:	39 fa                	cmp    edx,edi
    753650a040c4:	0f 83 e3 00 00 00    	jae    0x753650a041ad
    753650a040ca:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    753650a040d1:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    753650a040d7:	48 8b 6c 24 08       	mov    rbp,QWORD PTR [rsp+0x8]
    753650a040dc:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    753650a040e0:	0f 85 c7 00 00 00    	jne    0x753650a041ad
    753650a040e6:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753650a040ed:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a040f4:	00 
    753650a040f5:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753650a040fa:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    753650a040ff:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a04104:	48 83 c4 18          	add    rsp,0x18
    753650a04108:	ff e0                	jmp    rax
    753650a0410a:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753650a0410f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    753650a04116:	08 00 00 00 
    753650a0411a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a04121:	01 00 00 00 
    753650a04125:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0412c:	62 00 00 
    753650a0412f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a04134:	4c 89 f7             	mov    rdi,r14
    753650a04137:	89 ce                	mov    esi,ecx
    753650a04139:	ff d0                	call   rax
    753650a0413b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a04142:	00 
    753650a04143:	0f 85 58 ff ff ff    	jne    0x753650a040a1
    753650a04149:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a0414e:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    753650a04153:	e9 90 ec ff e7       	jmp    0x753638a02de8
    753650a04158:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753650a0415d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    753650a04164:	8c 00 01 00 
    753650a04168:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0416f:	02 00 00 00 
    753650a04173:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a0417a:	02 00 00 00 
    753650a0417e:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a04185:	62 00 00 
    753650a04188:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a0418d:	4c 89 f7             	mov    rdi,r14
    753650a04190:	89 de                	mov    esi,ebx
    753650a04192:	ff d0                	call   rax
    753650a04194:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a0419b:	00 
    753650a0419c:	75 24                	jne    0x753650a041c2
    753650a0419e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a041a3:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    753650a041a8:	e9 6f ec ff e7       	jmp    0x753638a02e1c
    753650a041ad:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    753650a041b4:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    753650a041bb:	48 83 c4 18          	add    rsp,0x18
    753650a041bf:	c2 08 00             	ret    0x8
    753650a041c2:	b8 02 00 00 00       	mov    eax,0x2
    753650a041c7:	b9 02 00 00 00       	mov    ecx,0x2
    753650a041cc:	e9 da fe ff ff       	jmp    0x753650a040ab
