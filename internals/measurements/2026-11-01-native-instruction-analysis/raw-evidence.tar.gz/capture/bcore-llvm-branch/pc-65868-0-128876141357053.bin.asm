
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65868-0-128876141357053.bin:     file format binary


Disassembly of section .data:

0000753650a027fd <.data>:
    753650a027fd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753650a02804:	7c 01 01 00 
    753650a02808:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0280f:	02 00 00 00 
    753650a02813:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    753650a0281a:	0d 00 00 00 
    753650a0281e:	e9 98 f2 ff e7       	jmp    0x753638a01abb
    753650a02823:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a0282a:	01 
    753650a0282b:	48 83 c4 18          	add    rsp,0x18
    753650a0282f:	c2 08 00             	ret    0x8
    753650a02832:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02837:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0283e:	02 00 00 00 
    753650a02842:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a02849:	01 00 00 00 
    753650a0284d:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a02854:	62 00 00 
    753650a02857:	4c 89 ef             	mov    rdi,r13
    753650a0285a:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a0285f:	4c 89 f6             	mov    rsi,r14
    753650a02862:	ba 4c 01 01 00       	mov    edx,0x1014c
    753650a02867:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a0286d:	ff d0                	call   rax
    753650a0286f:	b8 02 00 00 00       	mov    eax,0x2
    753650a02874:	b9 01 00 00 00       	mov    ecx,0x1
    753650a02879:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    753650a02880:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753650a02887:	01 ca                	add    edx,ecx
    753650a02889:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    753650a02890:	39 fa                	cmp    edx,edi
    753650a02892:	0f 83 7d 03 00 00    	jae    0x753650a02c15
    753650a02898:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    753650a0289f:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    753650a028a5:	48 8b 6c 24 08       	mov    rbp,QWORD PTR [rsp+0x8]
    753650a028aa:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    753650a028ae:	0f 85 61 03 00 00    	jne    0x753650a02c15
    753650a028b4:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753650a028bb:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a028c2:	00 
    753650a028c3:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753650a028c8:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    753650a028cd:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a028d2:	48 83 c4 18          	add    rsp,0x18
    753650a028d6:	ff e0                	jmp    rax
    753650a028d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a028df:	02 00 00 00 
    753650a028e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a028ea:	01 00 00 00 
    753650a028ee:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a028f5:	62 00 00 
    753650a028f8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a028fd:	4c 89 f7             	mov    rdi,r14
    753650a02900:	89 ce                	mov    esi,ecx
    753650a02902:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02907:	4c 89 c3             	mov    rbx,r8
    753650a0290a:	ff d0                	call   rax
    753650a0290c:	49 89 d8             	mov    r8,rbx
    753650a0290f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02914:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02919:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02920:	00 
    753650a02921:	0f 84 8b ef ff e7    	je     0x753638a018b2
    753650a02927:	e9 43 ff ff ff       	jmp    0x753650a0286f
    753650a0292c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02933:	02 00 00 00 
    753650a02937:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0293e:	01 00 00 00 
    753650a02942:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02949:	62 00 00 
    753650a0294c:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02951:	4c 89 f7             	mov    rdi,r14
    753650a02954:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02959:	4c 89 c3             	mov    rbx,r8
    753650a0295c:	ff d0                	call   rax
    753650a0295e:	49 89 d8             	mov    r8,rbx
    753650a02961:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02966:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a0296b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02972:	00 
    753650a02973:	0f 84 5d ef ff e7    	je     0x753638a018d6
    753650a02979:	e9 f1 fe ff ff       	jmp    0x753650a0286f
    753650a0297e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02985:	02 00 00 00 
    753650a02989:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a02990:	01 00 00 00 
    753650a02994:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0299b:	62 00 00 
    753650a0299e:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a029a3:	4c 89 f7             	mov    rdi,r14
    753650a029a6:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a029ab:	4c 89 c3             	mov    rbx,r8
    753650a029ae:	ff d0                	call   rax
    753650a029b0:	49 89 d8             	mov    r8,rbx
    753650a029b3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a029b8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a029bd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a029c4:	00 
    753650a029c5:	0f 84 2f ef ff e7    	je     0x753638a018fa
    753650a029cb:	e9 9f fe ff ff       	jmp    0x753650a0286f
    753650a029d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a029d7:	02 00 00 00 
    753650a029db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a029e2:	01 00 00 00 
    753650a029e6:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a029ed:	62 00 00 
    753650a029f0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a029f5:	4c 89 f7             	mov    rdi,r14
    753650a029f8:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a029fd:	4c 89 c3             	mov    rbx,r8
    753650a02a00:	ff d0                	call   rax
    753650a02a02:	49 89 d8             	mov    r8,rbx
    753650a02a05:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02a0a:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02a0f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02a16:	00 
    753650a02a17:	0f 84 01 ef ff e7    	je     0x753638a0191e
    753650a02a1d:	e9 4d fe ff ff       	jmp    0x753650a0286f
    753650a02a22:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02a29:	02 00 00 00 
    753650a02a2d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a02a34:	01 00 00 00 
    753650a02a38:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02a3f:	62 00 00 
    753650a02a42:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02a47:	4c 89 f7             	mov    rdi,r14
    753650a02a4a:	89 de                	mov    esi,ebx
    753650a02a4c:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02a51:	4c 89 c5             	mov    rbp,r8
    753650a02a54:	ff d0                	call   rax
    753650a02a56:	49 89 e8             	mov    r8,rbp
    753650a02a59:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02a5e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02a63:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02a6a:	00 
    753650a02a6b:	0f 84 d3 ee ff e7    	je     0x753638a01944
    753650a02a71:	e9 f9 fd ff ff       	jmp    0x753650a0286f
    753650a02a76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    753650a02a7d:	4e 01 01 00 
    753650a02a81:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02a88:	02 00 00 00 
    753650a02a8c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a02a93:	01 00 00 00 
    753650a02a97:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a02a9e:	62 00 00 
    753650a02aa1:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02aa6:	4c 89 ef             	mov    rdi,r13
    753650a02aa9:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02aae:	4c 89 c3             	mov    rbx,r8
    753650a02ab1:	ff d0                	call   rax
    753650a02ab3:	49 89 d8             	mov    r8,rbx
    753650a02ab6:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02abb:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02ac0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02ac7:	00 
    753650a02ac8:	0f 84 84 ee ff e7    	je     0x753638a01952
    753650a02ace:	e9 9c fd ff ff       	jmp    0x753650a0286f
    753650a02ad3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    753650a02ada:	4e 01 01 00 
    753650a02ade:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02ae5:	04 00 00 00 
    753650a02ae9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a02af0:	02 00 00 00 
    753650a02af4:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02afb:	62 00 00 
    753650a02afe:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02b03:	4c 89 f7             	mov    rdi,r14
    753650a02b06:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02b0b:	4c 89 c5             	mov    rbp,r8
    753650a02b0e:	ff d0                	call   rax
    753650a02b10:	49 89 e8             	mov    r8,rbp
    753650a02b13:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02b18:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02b1d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02b24:	00 
    753650a02b25:	0f 84 52 ee ff e7    	je     0x753638a0197d
    753650a02b2b:	e9 b0 00 00 00       	jmp    0x753650a02be0
    753650a02b30:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    753650a02b37:	4e 01 01 00 
    753650a02b3b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02b42:	04 00 00 00 
    753650a02b46:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a02b4d:	02 00 00 00 
    753650a02b51:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02b58:	62 00 00 
    753650a02b5b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02b60:	4c 89 f7             	mov    rdi,r14
    753650a02b63:	89 ee                	mov    esi,ebp
    753650a02b65:	89 da                	mov    edx,ebx
    753650a02b67:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02b6c:	4c 89 c3             	mov    rbx,r8
    753650a02b6f:	ff d0                	call   rax
    753650a02b71:	49 89 d8             	mov    r8,rbx
    753650a02b74:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02b79:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02b7e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02b85:	00 
    753650a02b86:	0f 84 13 ee ff e7    	je     0x753638a0199f
    753650a02b8c:	eb 52                	jmp    0x753650a02be0
    753650a02b8e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10152
    753650a02b95:	52 01 01 00 
    753650a02b99:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02ba0:	04 00 00 00 
    753650a02ba4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a02bab:	02 00 00 00 
    753650a02baf:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a02bb6:	62 00 00 
    753650a02bb9:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02bbe:	4c 89 ef             	mov    rdi,r13
    753650a02bc1:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a02bc6:	ff d0                	call   rax
    753650a02bc8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02bcd:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a02bd2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02bd9:	00 
    753650a02bda:	0f 84 d5 ed ff e7    	je     0x753638a019b5
    753650a02be0:	b8 04 00 00 00       	mov    eax,0x4
    753650a02be5:	b9 02 00 00 00       	mov    ecx,0x2
    753650a02bea:	e9 8a fc ff ff       	jmp    0x753650a02879
    753650a02bef:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    753650a02bf6:	9c 01 01 00 
    753650a02bfa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02c01:	02 00 00 00 
    753650a02c05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a02c0c:	05 00 00 00 
    753650a02c10:	e9 a6 ee ff e7       	jmp    0x753638a01abb
    753650a02c15:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    753650a02c1c:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    753650a02c23:	48 83 c4 18          	add    rsp,0x18
    753650a02c27:	c2 08 00             	ret    0x8
