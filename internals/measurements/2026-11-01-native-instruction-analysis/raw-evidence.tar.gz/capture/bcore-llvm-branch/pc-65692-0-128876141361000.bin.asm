
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65692-0-128876141361000.bin:     file format binary


Disassembly of section .data:

0000753650a03768 <.data>:
    753650a03768:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    753650a0376f:	84 00 01 00 
    753650a03773:	b1 01                	mov    cl,0x1
    753650a03775:	bd 07 00 00 00       	mov    ebp,0x7
    753650a0377a:	bb 02 00 00 00       	mov    ebx,0x2
    753650a0377f:	e9 34 f5 ff e7       	jmp    0x753638a02cb8
    753650a03784:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0378b:	02 00 00 00 
    753650a0378f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a03796:	01 00 00 00 
    753650a0379a:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a037a1:	62 00 00 
    753650a037a4:	48 89 fb             	mov    rbx,rdi
    753650a037a7:	4c 89 ef             	mov    rdi,r13
    753650a037aa:	4c 89 f6             	mov    rsi,r14
    753650a037ad:	ba 9c 00 01 00       	mov    edx,0x1009c
    753650a037b2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a037b8:	ff d0                	call   rax
    753650a037ba:	48 89 df             	mov    rdi,rbx
    753650a037bd:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a037c4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a037cb:	00 
    753650a037cc:	bb 02 00 00 00       	mov    ebx,0x2
    753650a037d1:	bd 01 00 00 00       	mov    ebp,0x1
    753650a037d6:	e9 8c f4 ff e7       	jmp    0x753638a02c67
    753650a037db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a037e2:	02 00 00 00 
    753650a037e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a037ed:	01 00 00 00 
    753650a037f1:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a037f8:	62 00 00 
    753650a037fb:	48 89 fb             	mov    rbx,rdi
    753650a037fe:	4c 89 f7             	mov    rdi,r14
    753650a03801:	89 ce                	mov    esi,ecx
    753650a03803:	4c 89 c5             	mov    rbp,r8
    753650a03806:	ff d0                	call   rax
    753650a03808:	49 89 e8             	mov    r8,rbp
    753650a0380b:	48 89 df             	mov    rdi,rbx
    753650a0380e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03815:	00 
    753650a03816:	84 c9                	test   cl,cl
    753650a03818:	0f 84 37 f1 ff e7    	je     0x753638a02955
    753650a0381e:	eb 4c                	jmp    0x753650a0386c
    753650a03820:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    753650a03827:	9e 00 01 00 
    753650a0382b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03832:	02 00 00 00 
    753650a03836:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0383d:	01 00 00 00 
    753650a03841:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a03848:	62 00 00 
    753650a0384b:	48 89 fb             	mov    rbx,rdi
    753650a0384e:	4c 89 ef             	mov    rdi,r13
    753650a03851:	4c 89 c5             	mov    rbp,r8
    753650a03854:	ff d0                	call   rax
    753650a03856:	49 89 e8             	mov    r8,rbp
    753650a03859:	48 89 df             	mov    rdi,rbx
    753650a0385c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03863:	00 
    753650a03864:	84 c9                	test   cl,cl
    753650a03866:	0f 84 f3 f0 ff e7    	je     0x753638a0295f
    753650a0386c:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03873:	e9 54 ff ff ff       	jmp    0x753650a037cc
    753650a03878:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    753650a0387f:	9e 00 01 00 
    753650a03883:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0388a:	02 00 00 00 
    753650a0388e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a03895:	02 00 00 00 
    753650a03899:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a038a0:	62 00 00 
    753650a038a3:	48 89 fd             	mov    rbp,rdi
    753650a038a6:	4c 89 ef             	mov    rdi,r13
    753650a038a9:	4c 89 f6             	mov    rsi,r14
    753650a038ac:	ba 9e 00 01 00       	mov    edx,0x1009e
    753650a038b1:	89 d9                	mov    ecx,ebx
    753650a038b3:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a038b9:	ff d0                	call   rax
    753650a038bb:	48 89 ef             	mov    rdi,rbp
    753650a038be:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a038c5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a038cc:	00 
    753650a038cd:	bd 02 00 00 00       	mov    ebp,0x2
    753650a038d2:	bb 02 00 00 00       	mov    ebx,0x2
    753650a038d7:	e9 8b f3 ff e7       	jmp    0x753638a02c67
    753650a038dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    753650a038e3:	9e 00 01 00 
    753650a038e7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a038ee:	02 00 00 00 
    753650a038f2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a038f9:	02 00 00 00 
    753650a038fd:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a03904:	62 00 00 
    753650a03907:	49 89 fc             	mov    r12,rdi
    753650a0390a:	4c 89 f7             	mov    rdi,r14
    753650a0390d:	89 de                	mov    esi,ebx
    753650a0390f:	4c 89 c5             	mov    rbp,r8
    753650a03912:	ff d0                	call   rax
    753650a03914:	49 89 e8             	mov    r8,rbp
    753650a03917:	4c 89 e7             	mov    rdi,r12
    753650a0391a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03921:	00 
    753650a03922:	84 c9                	test   cl,cl
    753650a03924:	0f 84 65 f0 ff e7    	je     0x753638a0298f
    753650a0392a:	eb 4c                	jmp    0x753650a03978
    753650a0392c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a0
    753650a03933:	a0 00 01 00 
    753650a03937:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0393e:	02 00 00 00 
    753650a03942:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a03949:	02 00 00 00 
    753650a0394d:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a03954:	62 00 00 
    753650a03957:	48 89 fb             	mov    rbx,rdi
    753650a0395a:	4c 89 ef             	mov    rdi,r13
    753650a0395d:	4c 89 c5             	mov    rbp,r8
    753650a03960:	ff d0                	call   rax
    753650a03962:	49 89 e8             	mov    r8,rbp
    753650a03965:	48 89 df             	mov    rdi,rbx
    753650a03968:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0396f:	00 
    753650a03970:	84 c9                	test   cl,cl
    753650a03972:	0f 84 28 f0 ff e7    	je     0x753638a029a0
    753650a03978:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a0397f:	e9 49 ff ff ff       	jmp    0x753650a038cd
    753650a03984:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    753650a0398b:	a4 00 01 00 
    753650a0398f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03996:	02 00 00 00 
    753650a0399a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a039a1:	05 00 00 00 
    753650a039a5:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a039ac:	62 00 00 
    753650a039af:	48 89 fb             	mov    rbx,rdi
    753650a039b2:	4c 89 ef             	mov    rdi,r13
    753650a039b5:	4c 89 f6             	mov    rsi,r14
    753650a039b8:	ba a4 00 01 00       	mov    edx,0x100a4
    753650a039bd:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a039c3:	ff d0                	call   rax
    753650a039c5:	48 89 df             	mov    rdi,rbx
    753650a039c8:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a039cf:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a039d6:	00 
    753650a039d7:	bb 02 00 00 00       	mov    ebx,0x2
    753650a039dc:	bd 05 00 00 00       	mov    ebp,0x5
    753650a039e1:	e9 81 f2 ff e7       	jmp    0x753638a02c67
    753650a039e6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    753650a039ed:	a4 00 01 00 
    753650a039f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a039f8:	02 00 00 00 
    753650a039fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a03a03:	05 00 00 00 
    753650a03a07:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a03a0e:	62 00 00 
    753650a03a11:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03a16:	4c 89 f7             	mov    rdi,r14
    753650a03a19:	89 ce                	mov    esi,ecx
    753650a03a1b:	89 da                	mov    edx,ebx
    753650a03a1d:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a03a22:	4d 89 c6             	mov    r14,r8
    753650a03a25:	ff d0                	call   rax
    753650a03a27:	4d 89 f0             	mov    r8,r14
    753650a03a2a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03a2f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03a34:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03a3b:	00 
    753650a03a3c:	84 c9                	test   cl,cl
    753650a03a3e:	0f 84 e9 ef ff e7    	je     0x753638a02a2d
    753650a03a44:	eb 5a                	jmp    0x753650a03aa0
    753650a03a46:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a6
    753650a03a4d:	a6 00 01 00 
    753650a03a51:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03a58:	02 00 00 00 
    753650a03a5c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a03a63:	05 00 00 00 
    753650a03a67:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a03a6e:	62 00 00 
    753650a03a71:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03a76:	4c 89 ef             	mov    rdi,r13
    753650a03a79:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a03a7e:	4d 89 c6             	mov    r14,r8
    753650a03a81:	ff d0                	call   rax
    753650a03a83:	4d 89 f0             	mov    r8,r14
    753650a03a86:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03a8b:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03a90:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03a97:	00 
    753650a03a98:	84 c9                	test   cl,cl
    753650a03a9a:	0f 84 97 ef ff e7    	je     0x753638a02a37
    753650a03aa0:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03aa7:	e9 2b ff ff ff       	jmp    0x753650a039d7
    753650a03aac:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    753650a03ab3:	e9 00 f2 ff e7       	jmp    0x753638a02cb8
    753650a03ab8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    753650a03abf:	b4 00 01 00 
    753650a03ac3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03aca:	02 00 00 00 
    753650a03ace:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    753650a03ad5:	0b 00 00 00 
    753650a03ad9:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a03ae0:	62 00 00 
    753650a03ae3:	bb 02 00 00 00       	mov    ebx,0x2
    753650a03ae8:	49 89 fc             	mov    r12,rdi
    753650a03aeb:	4c 89 f7             	mov    rdi,r14
    753650a03aee:	be 10 f0 00 00       	mov    esi,0xf010
    753650a03af3:	ba 02 00 00 00       	mov    edx,0x2
    753650a03af8:	4c 89 c5             	mov    rbp,r8
    753650a03afb:	ff d0                	call   rax
    753650a03afd:	49 89 e8             	mov    r8,rbp
    753650a03b00:	4c 89 e7             	mov    rdi,r12
    753650a03b03:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03b0a:	00 
    753650a03b0b:	84 c9                	test   cl,cl
    753650a03b0d:	0f 84 da ef ff e7    	je     0x753638a02aed
    753650a03b13:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03b1a:	eb 58                	jmp    0x753650a03b74
    753650a03b1c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    753650a03b23:	b6 00 01 00 
    753650a03b27:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03b2e:	02 00 00 00 
    753650a03b32:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    753650a03b39:	0b 00 00 00 
    753650a03b3d:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a03b44:	62 00 00 
    753650a03b47:	48 89 fb             	mov    rbx,rdi
    753650a03b4a:	4c 89 ef             	mov    rdi,r13
    753650a03b4d:	4c 89 c5             	mov    rbp,r8
    753650a03b50:	ff d0                	call   rax
    753650a03b52:	49 89 e8             	mov    r8,rbp
    753650a03b55:	48 89 df             	mov    rdi,rbx
    753650a03b58:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03b5f:	00 
    753650a03b60:	84 c9                	test   cl,cl
    753650a03b62:	0f 84 8f ef ff e7    	je     0x753638a02af7
    753650a03b68:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03b6f:	bb 02 00 00 00       	mov    ebx,0x2
    753650a03b74:	bd 0b 00 00 00       	mov    ebp,0xb
    753650a03b79:	e9 e9 f0 ff e7       	jmp    0x753638a02c67
    753650a03b7e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    753650a03b85:	b6 00 01 00 
    753650a03b89:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a03b90:	04 00 00 00 
    753650a03b94:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a03b9b:	0c 00 00 00 
    753650a03b9f:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a03ba6:	62 00 00 
    753650a03ba9:	48 89 fb             	mov    rbx,rdi
    753650a03bac:	4c 89 ef             	mov    rdi,r13
    753650a03baf:	4c 89 f6             	mov    rsi,r14
    753650a03bb2:	ba b6 00 01 00       	mov    edx,0x100b6
    753650a03bb7:	89 e9                	mov    ecx,ebp
    753650a03bb9:	45 31 c0             	xor    r8d,r8d
    753650a03bbc:	ff d0                	call   rax
    753650a03bbe:	48 89 df             	mov    rdi,rbx
    753650a03bc1:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03bc8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03bcf:	00 
    753650a03bd0:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03bd5:	bd 0c 00 00 00       	mov    ebp,0xc
    753650a03bda:	e9 88 f0 ff e7       	jmp    0x753638a02c67
    753650a03bdf:	4d 89 c7             	mov    r15,r8
    753650a03be2:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03be7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    753650a03bee:	b6 00 01 00 
    753650a03bf2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a03bf9:	04 00 00 00 
    753650a03bfd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a03c04:	0c 00 00 00 
    753650a03c08:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03c0f:	62 00 00 
    753650a03c12:	4d 89 f4             	mov    r12,r14
    753650a03c15:	4c 89 f7             	mov    rdi,r14
    753650a03c18:	89 ee                	mov    esi,ebp
    753650a03c1a:	ff d0                	call   rax
    753650a03c1c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03c23:	00 
    753650a03c24:	84 c9                	test   cl,cl
    753650a03c26:	0f 85 57 03 00 00    	jne    0x753650a03f83
    753650a03c2c:	89 c3                	mov    ebx,eax
    753650a03c2e:	4d 89 e6             	mov    r14,r12
    753650a03c31:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03c36:	4d 89 f8             	mov    r8,r15
    753650a03c39:	e9 e6 ee ff e7       	jmp    0x753638a02b24
    753650a03c3e:	4d 89 c4             	mov    r12,r8
    753650a03c41:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03c46:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    753650a03c4d:	b6 00 01 00 
    753650a03c51:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a03c58:	04 00 00 00 
    753650a03c5c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a03c63:	0c 00 00 00 
    753650a03c67:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03c6e:	62 00 00 
    753650a03c71:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a03c76:	4c 89 f7             	mov    rdi,r14
    753650a03c79:	ff d0                	call   rax
    753650a03c7b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03c82:	00 
    753650a03c83:	84 c9                	test   cl,cl
    753650a03c85:	0f 85 0b 03 00 00    	jne    0x753650a03f96
    753650a03c8b:	41 89 c7             	mov    r15d,eax
    753650a03c8e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03c93:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03c98:	4d 89 e0             	mov    r8,r12
    753650a03c9b:	e9 a3 ee ff e7       	jmp    0x753638a02b43
    753650a03ca0:	4c 89 c3             	mov    rbx,r8
    753650a03ca3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03ca8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03caf:	bc 00 01 00 
    753650a03cb3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03cba:	02 00 00 00 
    753650a03cbe:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03cc5:	0e 00 00 00 
    753650a03cc9:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03cd0:	62 00 00 
    753650a03cd3:	4d 89 f4             	mov    r12,r14
    753650a03cd6:	4c 89 f7             	mov    rdi,r14
    753650a03cd9:	ff d0                	call   rax
    753650a03cdb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03ce2:	00 
    753650a03ce3:	84 c9                	test   cl,cl
    753650a03ce5:	0f 85 7a 02 00 00    	jne    0x753650a03f65
    753650a03ceb:	4d 89 e6             	mov    r14,r12
    753650a03cee:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03cf3:	49 89 d8             	mov    r8,rbx
    753650a03cf6:	e9 7d ee ff e7       	jmp    0x753638a02b78
    753650a03cfb:	4c 89 c3             	mov    rbx,r8
    753650a03cfe:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03d03:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03d0a:	bc 00 01 00 
    753650a03d0e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03d15:	02 00 00 00 
    753650a03d19:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03d20:	0e 00 00 00 
    753650a03d24:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03d2b:	62 00 00 
    753650a03d2e:	4d 89 f4             	mov    r12,r14
    753650a03d31:	4c 89 f7             	mov    rdi,r14
    753650a03d34:	ff d0                	call   rax
    753650a03d36:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03d3d:	00 
    753650a03d3e:	84 c9                	test   cl,cl
    753650a03d40:	0f 85 1f 02 00 00    	jne    0x753650a03f65
    753650a03d46:	4d 89 e6             	mov    r14,r12
    753650a03d49:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03d4e:	49 89 d8             	mov    r8,rbx
    753650a03d51:	e9 44 ee ff e7       	jmp    0x753638a02b9a
    753650a03d56:	4c 89 c3             	mov    rbx,r8
    753650a03d59:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03d5e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03d65:	bc 00 01 00 
    753650a03d69:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03d70:	02 00 00 00 
    753650a03d74:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03d7b:	0e 00 00 00 
    753650a03d7f:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03d86:	62 00 00 
    753650a03d89:	4d 89 f4             	mov    r12,r14
    753650a03d8c:	4c 89 f7             	mov    rdi,r14
    753650a03d8f:	ff d0                	call   rax
    753650a03d91:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03d98:	00 
    753650a03d99:	84 c9                	test   cl,cl
    753650a03d9b:	0f 85 c4 01 00 00    	jne    0x753650a03f65
    753650a03da1:	4d 89 e6             	mov    r14,r12
    753650a03da4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03da9:	49 89 d8             	mov    r8,rbx
    753650a03dac:	e9 0b ee ff e7       	jmp    0x753638a02bbc
    753650a03db1:	4c 89 c3             	mov    rbx,r8
    753650a03db4:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03db9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03dc0:	bc 00 01 00 
    753650a03dc4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03dcb:	02 00 00 00 
    753650a03dcf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03dd6:	0e 00 00 00 
    753650a03dda:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03de1:	62 00 00 
    753650a03de4:	4d 89 f4             	mov    r12,r14
    753650a03de7:	4c 89 f7             	mov    rdi,r14
    753650a03dea:	ff d0                	call   rax
    753650a03dec:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03df3:	00 
    753650a03df4:	84 c9                	test   cl,cl
    753650a03df6:	0f 85 69 01 00 00    	jne    0x753650a03f65
    753650a03dfc:	4d 89 e6             	mov    r14,r12
    753650a03dff:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03e04:	49 89 d8             	mov    r8,rbx
    753650a03e07:	e9 d2 ed ff e7       	jmp    0x753638a02bde
    753650a03e0c:	4c 89 c3             	mov    rbx,r8
    753650a03e0f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03e14:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03e1b:	bc 00 01 00 
    753650a03e1f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03e26:	02 00 00 00 
    753650a03e2a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03e31:	0e 00 00 00 
    753650a03e35:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03e3c:	62 00 00 
    753650a03e3f:	4d 89 f4             	mov    r12,r14
    753650a03e42:	4c 89 f7             	mov    rdi,r14
    753650a03e45:	ff d0                	call   rax
    753650a03e47:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03e4e:	00 
    753650a03e4f:	84 c9                	test   cl,cl
    753650a03e51:	0f 85 0e 01 00 00    	jne    0x753650a03f65
    753650a03e57:	4d 89 e6             	mov    r14,r12
    753650a03e5a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03e5f:	49 89 d8             	mov    r8,rbx
    753650a03e62:	e9 99 ed ff e7       	jmp    0x753638a02c00
    753650a03e67:	4c 89 c3             	mov    rbx,r8
    753650a03e6a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03e6f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03e76:	bc 00 01 00 
    753650a03e7a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03e81:	02 00 00 00 
    753650a03e85:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03e8c:	0e 00 00 00 
    753650a03e90:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03e97:	62 00 00 
    753650a03e9a:	4d 89 f4             	mov    r12,r14
    753650a03e9d:	4c 89 f7             	mov    rdi,r14
    753650a03ea0:	ff d0                	call   rax
    753650a03ea2:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03ea9:	00 
    753650a03eaa:	84 c9                	test   cl,cl
    753650a03eac:	0f 85 b3 00 00 00    	jne    0x753650a03f65
    753650a03eb2:	4d 89 e6             	mov    r14,r12
    753650a03eb5:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03eba:	49 89 d8             	mov    r8,rbx
    753650a03ebd:	e9 60 ed ff e7       	jmp    0x753638a02c22
    753650a03ec2:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a03ec7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    753650a03ece:	bc 00 01 00 
    753650a03ed2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03ed9:	02 00 00 00 
    753650a03edd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    753650a03ee4:	0e 00 00 00 
    753650a03ee8:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03eef:	62 00 00 
    753650a03ef2:	4d 89 f4             	mov    r12,r14
    753650a03ef5:	4c 89 f7             	mov    rdi,r14
    753650a03ef8:	ff d0                	call   rax
    753650a03efa:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03f01:	00 
    753650a03f02:	84 c9                	test   cl,cl
    753650a03f04:	75 5f                	jne    0x753650a03f65
    753650a03f06:	4d 89 e6             	mov    r14,r12
    753650a03f09:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03f0e:	e9 33 ed ff e7       	jmp    0x753638a02c46
    753650a03f13:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100be
    753650a03f1a:	be 00 01 00 
    753650a03f1e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03f25:	02 00 00 00 
    753650a03f29:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    753650a03f30:	0f 00 00 00 
    753650a03f34:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a03f3b:	62 00 00 
    753650a03f3e:	49 89 ff             	mov    r15,rdi
    753650a03f41:	4c 89 ef             	mov    rdi,r13
    753650a03f44:	be 2a 00 00 00       	mov    esi,0x2a
    753650a03f49:	4c 89 f2             	mov    rdx,r14
    753650a03f4c:	ff d0                	call   rax
    753650a03f4e:	4c 89 ff             	mov    rdi,r15
    753650a03f51:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03f58:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03f5f:	00 
    753650a03f60:	e9 02 ed ff e7       	jmp    0x753638a02c67
    753650a03f65:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03f6c:	bb 02 00 00 00       	mov    ebx,0x2
    753650a03f71:	bd 0e 00 00 00       	mov    ebp,0xe
    753650a03f76:	4d 89 e6             	mov    r14,r12
    753650a03f79:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03f7e:	e9 e4 ec ff e7       	jmp    0x753638a02c67
    753650a03f83:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03f8a:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03f8f:	bd 0c 00 00 00       	mov    ebp,0xc
    753650a03f94:	eb e0                	jmp    0x753650a03f76
    753650a03f96:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03f9d:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03fa2:	bd 0c 00 00 00       	mov    ebp,0xc
    753650a03fa7:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03fac:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a03fb1:	e9 b1 ec ff e7       	jmp    0x753638a02c67
