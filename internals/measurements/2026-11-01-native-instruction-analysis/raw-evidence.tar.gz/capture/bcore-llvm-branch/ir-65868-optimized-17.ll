; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001014c(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65903
  %5 = icmp ult i32 %4, -35
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb108 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb108, -65903
  %8 = icmp ult i32 %7, -35
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x0001014c, label %lb_guard_miss, !prof !0

insn_0x0001014c:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %10, align 4
  %sp_dec = add i32 %sp, -4
  %11 = getelementptr i8, ptr %cpu, i64 16
  %r = load i32, ptr %11, align 4
  %12 = and i32 %sp, 3
  %.not = icmp eq i32 %12, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x0001014c
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %14, align 4
  tail call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec, i32 65536)
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001014c
  %15 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %15 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %16 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %16 to i64
  %17 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %17, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %18 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %19, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %20 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %20, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %chain_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %sp_dec1 = add i32 %sp, -8
  %21 = getelementptr i8, ptr %cpu, i64 20
  %r2 = load i32, ptr %21, align 4
  %22 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %22 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11.not = icmp eq ptr %page10, null
  br i1 %page_mapped11.not, label %page_wr_slow6, label %page_wr_fast5, !prof !1

page_wr_fast5:                                    ; preds = %page_wr_done
  %23 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %23 to i64
  %24 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %24, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %page_wr_done
  %25 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %26, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %27 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %27, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_wr_done7, label %chain_exit, !prof !0

page_wr_done7:                                    ; preds = %page_wr_slow6, %page_wr_fast5
  %sp_dec17 = add i32 %sp, -12
  %28 = getelementptr i8, ptr %cpu, i64 24
  %r18 = load i32, ptr %28, align 4
  %29 = lshr i32 %sp_dec17, 12
  %page_index24 = zext i32 %29 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27.not = icmp eq ptr %page26, null
  br i1 %page_mapped27.not, label %page_wr_slow22, label %page_wr_fast21, !prof !1

page_wr_fast21:                                   ; preds = %page_wr_done7
  %30 = and i32 %sp_dec17, 4095
  %page_offset28 = zext i32 %30 to i64
  %31 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %r18, ptr %31, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %page_wr_done7
  %32 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %33, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %r18)
  %34 = getelementptr i8, ptr %cpu, i64 296
  %dj31 = load i8, ptr %34, align 1
  %dj_set32.not = icmp eq i8 %dj31, 0
  br i1 %dj_set32.not, label %page_wr_done23, label %chain_exit, !prof !0

page_wr_done23:                                   ; preds = %page_wr_slow22, %page_wr_fast21
  %sp_dec33 = add i32 %sp, -16
  %35 = getelementptr i8, ptr %cpu, i64 28
  %r34 = load i32, ptr %35, align 4
  %36 = lshr i32 %sp_dec33, 12
  %page_index40 = zext i32 %36 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43.not = icmp eq ptr %page42, null
  br i1 %page_mapped43.not, label %page_wr_slow38, label %page_wr_fast37, !prof !1

page_wr_fast37:                                   ; preds = %page_wr_done23
  %37 = and i32 %sp_dec33, 4095
  %page_offset44 = zext i32 %37 to i64
  %38 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %r34, ptr %38, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %page_wr_done23
  %39 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %40, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec33, i32 %r34)
  %41 = getelementptr i8, ptr %cpu, i64 296
  %dj47 = load i8, ptr %41, align 1
  %dj_set48.not = icmp eq i8 %dj47, 0
  br i1 %dj_set48.not, label %page_wr_done39, label %chain_exit, !prof !0

page_wr_done39:                                   ; preds = %page_wr_slow38, %page_wr_fast37
  %sp_dec49 = add i32 %sp, -20
  %42 = getelementptr i8, ptr %cpu, i64 52
  %p = load i32, ptr %42, align 4
  %43 = lshr i32 %sp_dec49, 12
  %page_index55 = zext i32 %43 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58.not = icmp eq ptr %page57, null
  br i1 %page_mapped58.not, label %page_wr_slow53, label %page_wr_fast52, !prof !1

page_wr_fast52:                                   ; preds = %page_wr_done39
  %44 = and i32 %sp_dec49, 4095
  %page_offset59 = zext i32 %44 to i64
  %45 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p, ptr %45, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %page_wr_done39
  %46 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %47, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec49, i32 %p)
  %48 = getelementptr i8, ptr %cpu, i64 296
  %dj62 = load i8, ptr %48, align 1
  %dj_set63.not = icmp eq i8 %dj62, 0
  br i1 %dj_set63.not, label %page_wr_done54, label %chain_exit, !prof !0

page_wr_done54:                                   ; preds = %page_wr_slow53, %page_wr_fast52
  store i32 %sp_dec49, ptr %10, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not148 = icmp eq i8 %cec_pending, 0
  br i1 %.not148, label %insn_0x0001014e, label %cec_check, !prof !0

cec_check:                                        ; preds = %page_wr_done54
  %49 = getelementptr i8, ptr %cpu, i64 188
  store i32 65870, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %51, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %52 = getelementptr i8, ptr %cpu, i64 296
  %dj66 = load i8, ptr %52, align 1
  %dj_set67.not = icmp eq i8 %dj66, 0
  br i1 %dj_set67.not, label %insn_0x0001014e, label %chain_exit, !prof !0

insn_0x0001014e:                                  ; preds = %page_wr_done54, %cec_check
  %53 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %54, align 4
  %sp1 = add i32 %sp, -24
  %55 = lshr i32 %sp1, 12
  %page_index73 = zext i32 %55 to i64
  %page_slot74 = getelementptr ptr, ptr %page_table, i64 %page_index73
  %page75 = load ptr, ptr %page_slot74, align 8
  %page_mapped76.not = icmp eq ptr %page75, null
  br i1 %page_mapped76.not, label %page_wr_slow71, label %page_wr_fast70, !prof !1

page_wr_fast70:                                   ; preds = %insn_0x0001014e
  %56 = and i32 %sp1, 4095
  %page_offset77 = zext i32 %56 to i64
  %57 = getelementptr i8, ptr %page75, i64 %page_offset77
  store i32 %rets, ptr %57, align 4
  br label %page_wr_done72

page_wr_slow71:                                   ; preds = %insn_0x0001014e
  %58 = getelementptr i8, ptr %cpu, i64 188
  store i32 65870, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %60, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %61 = getelementptr i8, ptr %cpu, i64 296
  %dj80 = load i8, ptr %61, align 1
  %dj_set81.not = icmp eq i8 %dj80, 0
  br i1 %dj_set81.not, label %page_wr_done72, label %chain_exit, !prof !0

page_wr_done72:                                   ; preds = %page_wr_slow71, %page_wr_fast70
  %sp2 = add i32 %sp, -28
  %62 = lshr i32 %sp2, 12
  %page_index87 = zext i32 %62 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90.not = icmp eq ptr %page89, null
  br i1 %page_mapped90.not, label %page_wr_slow85, label %page_wr_fast84, !prof !1

page_wr_fast84:                                   ; preds = %page_wr_done72
  %63 = and i32 %sp2, 4095
  %page_offset91 = zext i32 %63 to i64
  %64 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %fp, ptr %64, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %page_wr_done72
  %65 = getelementptr i8, ptr %cpu, i64 188
  store i32 65870, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %67, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %68 = getelementptr i8, ptr %cpu, i64 296
  %dj94 = load i8, ptr %68, align 1
  %dj_set95.not = icmp eq i8 %dj94, 0
  br i1 %dj_set95.not, label %page_wr_done86, label %chain_exit, !prof !0

page_wr_done86:                                   ; preds = %page_wr_slow85, %page_wr_fast84
  store i32 %sp2, ptr %54, align 4
  %sp3 = add i32 %sp, -40
  store i32 %sp3, ptr %10, align 4
  %cec_pending96 = load i8, ptr %cec_pending_flag, align 1
  %.not151 = icmp eq i8 %cec_pending96, 0
  br i1 %.not151, label %insn_0x00010152, label %cec_check97, !prof !0

cec_check97:                                      ; preds = %page_wr_done86
  %69 = getelementptr i8, ptr %cpu, i64 188
  store i32 65874, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %71, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %72 = getelementptr i8, ptr %cpu, i64 296
  %dj101 = load i8, ptr %72, align 1
  %dj_set102.not = icmp eq i8 %dj101, 0
  br i1 %dj_set102.not, label %insn_0x00010152, label %chain_exit, !prof !0

insn_0x00010152:                                  ; preds = %page_wr_done86, %cec_check97
  %regmv_src = load i32, ptr %cpu, align 4
  store i32 %regmv_src, ptr %21, align 4
  %73 = icmp eq i32 %regmv_src, 0
  %az = zext i1 %73 to i32
  %flgn = lshr i32 %regmv_src, 31
  %74 = getelementptr i8, ptr %cpu, i64 276
  store i32 %az, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i64 232
  store i32 %flgn, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i64 236
  store i32 1, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 240
  store i32 1, ptr %78, align 4
  br i1 %73, label %brt_taken, label %insn_0x00010158

brt_taken:                                        ; preds = %insn_0x00010152
  %79 = getelementptr i8, ptr %cpu, i64 188
  store i32 65948, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %80, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %81 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %81 monotonic, align 4, !range !2
  %82 = icmp ult i32 %chain_total, %chain_budget
  br i1 %82, label %chain_go, label %chain_leave124, !prof !0

insn_0x00010158:                                  ; preds = %insn_0x00010152
  %83 = getelementptr i8, ptr %cpu, i64 4
  %regmv_src105 = load i32, ptr %83, align 4
  store i32 %regmv_src105, ptr %35, align 4
  store i32 %regmv_src105, ptr %cpu, align 4
  store i32 0, ptr %28, align 4
  store i32 1664525, ptr %11, align 4
  store i32 1013904223, ptr %42, align 4
  %84 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets127 = load i32, ptr %85, align 4
  %chain_total128 = add nuw i32 %chain_packets127, 13
  %86 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget129 = load atomic i32, ptr %86 monotonic, align 4, !range !2
  %87 = icmp ult i32 %chain_total128, %chain_budget129
  br i1 %87, label %chain_go125, label %chain_leave126, !prof !0

common.ret:                                       ; preds = %chain_leave136, %chain_leave126, %chain_leave124, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %88 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %88, align 1
  br label %common.ret

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527584
  %slot_pc = load i32, ptr %chain_slot, align 4
  %89 = icmp eq i32 %slot_pc, 65948
  br i1 %89, label %chain_hit, label %chain_leave124, !prof !0

chain_leave124:                                   ; preds = %chain_go, %brt_taken
  store i32 65948, ptr %79, align 4
  %90 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %92, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65948, ptr %79, align 4
  store i32 %chain_total, ptr %80, align 4
  %93 = getelementptr i8, ptr %chain_table, i64 527592
  %chain_fn = load ptr, ptr %93, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go125:                                      ; preds = %insn_0x00010158
  %chain_slot130 = getelementptr i8, ptr %chain_table, i64 527328
  %slot_pc131 = load i32, ptr %chain_slot130, align 4
  %94 = icmp eq i32 %slot_pc131, 65916
  br i1 %94, label %chain_hit132, label %chain_leave126, !prof !0

chain_leave126:                                   ; preds = %chain_go125, %insn_0x00010158
  store i32 65916, ptr %84, align 4
  %95 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 308
  store i32 13, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %97, align 1
  br label %common.ret

chain_hit132:                                     ; preds = %chain_go125
  store i32 65916, ptr %84, align 4
  store i32 %chain_total128, ptr %85, align 4
  %98 = getelementptr i8, ptr %chain_table, i64 527336
  %chain_fn133 = load ptr, ptr %98, align 8
  musttail call swifttailcc void %chain_fn133(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %cec_check97, %page_wr_slow85, %page_wr_slow71, %cec_check, %page_wr_slow53, %page_wr_slow38, %page_wr_slow22, %page_wr_slow6, %page_wr_slow, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %page_wr_slow ], [ 1, %page_wr_slow6 ], [ 1, %page_wr_slow22 ], [ 1, %page_wr_slow38 ], [ 1, %page_wr_slow53 ], [ 1, %cec_check ], [ 2, %page_wr_slow71 ], [ 2, %page_wr_slow85 ], [ 2, %cec_check97 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %page_wr_slow ], [ 2, %page_wr_slow6 ], [ 2, %page_wr_slow22 ], [ 2, %page_wr_slow38 ], [ 2, %page_wr_slow53 ], [ 2, %cec_check ], [ 4, %page_wr_slow71 ], [ 4, %page_wr_slow85 ], [ 4, %cec_check97 ]
  %next_pc134.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc134 = load i32, ptr %next_pc134.in, align 4
  %99 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets137 = load i32, ptr %99, align 4
  %chain_total138 = add nuw i32 %chain_packets137, %packets
  %100 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget139 = load atomic i32, ptr %100 monotonic, align 4, !range !2
  %101 = icmp ult i32 %chain_total138, %chain_budget139
  br i1 %101, label %chain_lookup, label %chain_leave136, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %102 = shl i32 %next_pc134, 3
  %103 = and i32 %102, 1048560
  %104 = zext i32 %103 to i64
  %chain_slot140 = getelementptr i8, ptr %chain_table, i64 %104
  %slot_pc141 = load i32, ptr %chain_slot140, align 4
  %105 = icmp eq i32 %slot_pc141, %next_pc134
  br i1 %105, label %chain_hit142, label %chain_leave136, !prof !0

chain_leave136:                                   ; preds = %chain_lookup, %chain_exit
  %106 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %107, align 4
  br label %common.ret

chain_hit142:                                     ; preds = %chain_lookup
  store i32 %chain_total138, ptr %99, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %108, align 1
  %109 = getelementptr i8, ptr %chain_slot140, i64 8
  %chain_fn143 = load ptr, ptr %109, align 8
  musttail call swifttailcc void %chain_fn143(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
