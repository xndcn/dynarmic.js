; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010006(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65542
  %6 = icmp ugt i32 %5, 10
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb5 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb5, 0
  %11 = sub i32 %guard_lb5, 65542
  %12 = icmp ugt i32 %11, 10
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010006_entry, label %lb_guard_miss, !prof !0

insn_0x00010006_entry:                            ; preds = %lb_guard
  br label %insn_0x00010006

insn_0x00010006:                                  ; preds = %insn_0x00010006_entry
  %15 = getelementptr i8, ptr %cpu, i32 32
  %old = load i32, ptr %15, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 16777216
  %16 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_hi, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %18, align 4
  br label %insn_0x0001000a_entry

insn_0x0001000a_entry:                            ; preds = %insn_0x00010006
  br label %insn_0x0001000a

insn_0x0001000a:                                  ; preds = %insn_0x0001000a_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4
  %19 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_lo, ptr %19, align 4
  br label %insn_0x0001000e_entry

insn_0x0001000e_entry:                            ; preds = %insn_0x0001000a
  br label %insn_0x0001000e

insn_0x0001000e:                                  ; preds = %insn_0x0001000e_entry
  %20 = getelementptr i8, ptr %cpu, i32 0
  %val = load i32, ptr %20, align 4
  %21 = and i32 %with_lo, 3
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001000e
  %23 = getelementptr i8, ptr %cpu, i32 188
  store i32 65550, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %25, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65550, i32 %with_lo, i32 65536)
  %26 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %26, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001000e
  %27 = lshr i32 %with_lo, 12
  %page_index = zext i32 %27 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %28 = and i32 %with_lo, 4095
  %page_offset = zext i32 %28 to i64
  %29 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %29, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %30 = getelementptr i8, ptr %cpu, i32 188
  store i32 65550, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %32, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo, i32 %val)
  %33 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %33, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %34 = icmp ne i8 %cec_pending, 0
  br i1 %34, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc6 = load i32, ptr %35, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %36 = getelementptr i8, ptr %cpu, i32 188
  store i32 65552, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %38, align 4
  call void @cec_check_pending(ptr %cpu)
  %39 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %39, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x00010010_entry

did_jump_exit1:                                   ; preds = %cec_check
  %40 = getelementptr i8, ptr %cpu, i64 188
  %next_pc7 = load i32, ptr %40, align 4
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x00010010_entry:                            ; preds = %cec_checked
  br label %insn_0x00010010

insn_0x00010010:                                  ; preds = %insn_0x00010010_entry
  %41 = getelementptr i8, ptr %cpu, i32 188
  store i32 65552, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %42, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %43 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %43 monotonic, align 4, !range !2
  %44 = icmp ult i32 %chain_total, %chain_budget
  br i1 %44, label %chain_go, label %chain_leave8, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %45 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %45, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %insn_0x00010010
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524416
  %46 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %46, align 4
  %47 = icmp eq i32 %slot_pc, 65552
  br i1 %47, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010010
  %48 = getelementptr i8, ptr %cpu, i64 188
  store i32 65552, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %51, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %52 = getelementptr i8, ptr %cpu, i64 188
  store i32 65552, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %53, align 4
  %54 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %54, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc9 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc6, %did_jump_exit ], [ %next_pc7, %did_jump_exit1 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ]
  %tail10 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %55 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets12 = load i32, ptr %55, align 4
  %chain_total13 = add nuw i32 %chain_packets12, %packets
  %56 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget14 = load atomic i32, ptr %56 monotonic, align 4, !range !2
  %57 = icmp ult i32 %chain_total13, %chain_budget14
  br i1 %57, label %chain_lookup, label %chain_leave11, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %58 = lshr i32 %next_pc9, 1
  %59 = and i32 %58, 65535
  %60 = zext i32 %59 to i64
  %61 = mul i64 %60, 16
  %chain_slot15 = getelementptr i8, ptr %chain_table, i64 %61
  %62 = getelementptr i8, ptr %chain_slot15, i64 0
  %slot_pc16 = load i32, ptr %62, align 4
  %63 = icmp eq i32 %slot_pc16, %next_pc9
  br i1 %63, label %chain_hit17, label %chain_leave11, !prof !0

chain_leave11:                                    ; preds = %chain_lookup, %chain_exit
  %64 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail10, ptr %65, align 4
  ret void

chain_hit17:                                      ; preds = %chain_lookup
  %66 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total13, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %67, align 1
  %68 = getelementptr i8, ptr %chain_slot15, i64 8
  %chain_fn18 = load ptr, ptr %68, align 8
  musttail call swifttailcc void %chain_fn18(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
