
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65904-0-128875738701088.bin:     file format binary


Disassembly of section .data:

0000753638a01d20 <.data>:
    753638a01d20:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    753638a01d27:	8d 8a 8d fe fe ff    	lea    ecx,[rdx-0x10173]
    753638a01d2d:	b8 65 01 00 00       	mov    eax,0x165
    753638a01d32:	83 f9 fc             	cmp    ecx,0xfffffffc
    753638a01d35:	0f 87 33 01 00 00    	ja     0x753638a01e6e
    753638a01d3b:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    753638a01d42:	8d b1 8d fe fe ff    	lea    esi,[rcx-0x10173]
    753638a01d48:	83 fe fc             	cmp    esi,0xfffffffc
    753638a01d4b:	0f 87 1d 01 00 00    	ja     0x753638a01e6e
    753638a01d51:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    753638a01d58:	41 8b 75 00          	mov    esi,DWORD PTR [r13+0x0]
    753638a01d5c:	41 8b 7d 1c          	mov    edi,DWORD PTR [r13+0x1c]
    753638a01d60:	89 fb                	mov    ebx,edi
    753638a01d62:	c1 eb 1f             	shr    ebx,0x1f
    753638a01d65:	89 f5                	mov    ebp,esi
    753638a01d67:	c1 ed 1f             	shr    ebp,0x1f
    753638a01d6a:	31 c0                	xor    eax,eax
    753638a01d6c:	01 f7                	add    edi,esi
    753638a01d6e:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    753638a01d72:	0f 92 c0             	setb   al
    753638a01d75:	89 fe                	mov    esi,edi
    753638a01d77:	c1 ee 1f             	shr    esi,0x1f
    753638a01d7a:	31 f5                	xor    ebp,esi
    753638a01d7c:	31 f3                	xor    ebx,esi
    753638a01d7e:	21 eb                	and    ebx,ebp
    753638a01d80:	31 ed                	xor    ebp,ebp
    753638a01d82:	85 ff                	test   edi,edi
    753638a01d84:	40 0f 94 c5          	sete   bpl
    753638a01d88:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    753638a01d8f:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    753638a01d96:	41 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebx
    753638a01d9d:	41 89 9d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebx
    753638a01da4:	41 09 9d 00 01 00 00 	or     DWORD PTR [r13+0x100],ebx
    753638a01dab:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    753638a01db2:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    753638a01db9:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a01dc0:	02 
    753638a01dc1:	be 76 01 01 00       	mov    esi,0x10176
    753638a01dc6:	bf 76 01 01 00       	mov    edi,0x10176
    753638a01dcb:	72 07                	jb     0x753638a01dd4
    753638a01dcd:	41 8b bd 90 00 00 00 	mov    edi,DWORD PTR [r13+0x90]
    753638a01dd4:	81 fa 72 01 01 00    	cmp    edx,0x10172
    753638a01dda:	0f 44 f7             	cmove  esi,edi
    753638a01ddd:	41 83 bd 9c 00 00 00 	cmp    DWORD PTR [r13+0x9c],0x2
    753638a01de4:	02 
    753638a01de5:	89 f2                	mov    edx,esi
    753638a01de7:	72 07                	jb     0x753638a01df0
    753638a01de9:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a01df0:	81 f9 72 01 01 00    	cmp    ecx,0x10172
    753638a01df6:	0f 44 f2             	cmove  esi,edx
    753638a01df9:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    753638a01e00:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    753638a01e07:	30 01 01 00 
    753638a01e0b:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a01e12:	83 c1 02             	add    ecx,0x2
    753638a01e15:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    753638a01e1c:	39 c1                	cmp    ecx,eax
    753638a01e1e:	73 28                	jae    0x753638a01e48
    753638a01e20:	41 81 b8 80 09 08 00 	cmp    DWORD PTR [r8+0x80980],0x10130
    753638a01e27:	30 01 01 00 
    753638a01e2b:	75 1b                	jne    0x753638a01e48
    753638a01e2d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    753638a01e34:	30 01 01 00 
    753638a01e38:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a01e3f:	49 8b 80 88 09 08 00 	mov    rax,QWORD PTR [r8+0x80988]
    753638a01e46:	ff e0                	jmp    rax
    753638a01e48:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    753638a01e4f:	30 01 01 00 
    753638a01e53:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753638a01e5a:	04 00 00 00 
    753638a01e5e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753638a01e65:	02 00 00 00 
    753638a01e69:	b8 28 01 00 00       	mov    eax,0x128
    753638a01e6e:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    753638a01e74:	c2 08 00             	ret    0x8
