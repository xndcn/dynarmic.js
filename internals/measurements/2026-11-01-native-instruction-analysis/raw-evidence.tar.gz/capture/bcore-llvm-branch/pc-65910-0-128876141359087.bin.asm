
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65910-0-128876141359087.bin:     file format binary


Disassembly of section .data:

0000753650a02fef <.data>:
    753650a02fef:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    753650a02ff6:	92 01 01 00 
    753650a02ffa:	b8 03 00 00 00       	mov    eax,0x3
    753650a02fff:	b9 02 00 00 00       	mov    ecx,0x2
    753650a03004:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    753650a0300b:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    753650a03012:	b8 28 01 00 00       	mov    eax,0x128
    753650a03017:	e9 62 f3 ff e7       	jmp    0x753638a0237e
    753650a0301c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753650a03023:	70 01 01 00 
    753650a03027:	b8 08 00 00 00       	mov    eax,0x8
    753650a0302c:	eb d1                	jmp    0x753650a02fff
    753650a0302e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753650a03035:	10 01 01 00 
    753650a03039:	b8 0a 00 00 00       	mov    eax,0xa
    753650a0303e:	b9 04 00 00 00       	mov    ecx,0x4
    753650a03043:	eb bf                	jmp    0x753650a03004
