
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66344-0-128876141351985.bin:     file format binary


Disassembly of section .data:

0000753650a01431 <.data>:
    753650a01431:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753650a01438:	70 03 01 00 
    753650a0143c:	b1 01                	mov    cl,0x1
    753650a0143e:	bd 06 00 00 00       	mov    ebp,0x6
    753650a01443:	e9 53 04 00 00       	jmp    0x753650a0189b
    753650a01448:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753650a0144f:	70 03 01 00 
    753650a01453:	b1 01                	mov    cl,0x1
    753650a01455:	bd 0a 00 00 00       	mov    ebp,0xa
    753650a0145a:	e9 3c 04 00 00       	jmp    0x753650a0189b
    753650a0145f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01466:	02 00 00 00 
    753650a0146a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a01471:	01 00 00 00 
    753650a01475:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a0147c:	62 00 00 
    753650a0147f:	4c 89 ef             	mov    rdi,r13
    753650a01482:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    753650a01487:	ba 28 03 01 00       	mov    edx,0x10328
    753650a0148c:	44 89 d1             	mov    ecx,r10d
    753650a0148f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a01495:	ff d0                	call   rax
    753650a01497:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a0149e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a014a5:	00 
    753650a014a6:	bb 02 00 00 00       	mov    ebx,0x2
    753650a014ab:	bd 01 00 00 00       	mov    ebp,0x1
    753650a014b0:	e9 d3 f9 ff e7       	jmp    0x753638a00e88
    753650a014b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a014bc:	02 00 00 00 
    753650a014c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a014c7:	01 00 00 00 
    753650a014cb:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a014d2:	62 00 00 
    753650a014d5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a014da:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a014df:	44 89 d6             	mov    esi,r10d
    753650a014e2:	4d 89 cf             	mov    r15,r9
    753650a014e5:	4c 89 d5             	mov    rbp,r10
    753650a014e8:	4d 89 dc             	mov    r12,r11
    753650a014eb:	ff d0                	call   rax
    753650a014ed:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a014f2:	4d 89 e3             	mov    r11,r12
    753650a014f5:	49 89 ea             	mov    r10,rbp
    753650a014f8:	4d 89 f9             	mov    r9,r15
    753650a014fb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01502:	00 
    753650a01503:	84 c9                	test   cl,cl
    753650a01505:	0f 84 43 f5 ff e7    	je     0x753638a00a4e
    753650a0150b:	e9 f7 01 00 00       	jmp    0x753650a01707
    753650a01510:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01517:	02 00 00 00 
    753650a0151b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a01522:	01 00 00 00 
    753650a01526:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0152d:	62 00 00 
    753650a01530:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01535:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a0153a:	89 ee                	mov    esi,ebp
    753650a0153c:	4d 89 cf             	mov    r15,r9
    753650a0153f:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a01544:	4c 89 d5             	mov    rbp,r10
    753650a01547:	4d 89 dc             	mov    r12,r11
    753650a0154a:	ff d0                	call   rax
    753650a0154c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01551:	4d 89 e3             	mov    r11,r12
    753650a01554:	49 89 ea             	mov    r10,rbp
    753650a01557:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a0155c:	4d 89 f9             	mov    r9,r15
    753650a0155f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01566:	00 
    753650a01567:	84 c9                	test   cl,cl
    753650a01569:	0f 84 0c f5 ff e7    	je     0x753638a00a7b
    753650a0156f:	e9 93 01 00 00       	jmp    0x753650a01707
    753650a01574:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0157b:	02 00 00 00 
    753650a0157f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a01586:	01 00 00 00 
    753650a0158a:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a01591:	62 00 00 
    753650a01594:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01599:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a0159e:	4d 89 cf             	mov    r15,r9
    753650a015a1:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a015a6:	4c 89 d5             	mov    rbp,r10
    753650a015a9:	4d 89 dc             	mov    r12,r11
    753650a015ac:	ff d0                	call   rax
    753650a015ae:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a015b3:	4d 89 e3             	mov    r11,r12
    753650a015b6:	49 89 ea             	mov    r10,rbp
    753650a015b9:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a015be:	4d 89 f9             	mov    r9,r15
    753650a015c1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a015c8:	00 
    753650a015c9:	84 c9                	test   cl,cl
    753650a015cb:	0f 84 da f4 ff e7    	je     0x753638a00aab
    753650a015d1:	e9 31 01 00 00       	jmp    0x753650a01707
    753650a015d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a015dd:	02 00 00 00 
    753650a015e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a015e8:	01 00 00 00 
    753650a015ec:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a015f3:	62 00 00 
    753650a015f6:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a015fb:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01600:	4d 89 cf             	mov    r15,r9
    753650a01603:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a01608:	4c 89 d5             	mov    rbp,r10
    753650a0160b:	4d 89 dc             	mov    r12,r11
    753650a0160e:	ff d0                	call   rax
    753650a01610:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01615:	4d 89 e3             	mov    r11,r12
    753650a01618:	49 89 ea             	mov    r10,rbp
    753650a0161b:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a01620:	4d 89 f9             	mov    r9,r15
    753650a01623:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0162a:	00 
    753650a0162b:	84 c9                	test   cl,cl
    753650a0162d:	0f 84 a8 f4 ff e7    	je     0x753638a00adb
    753650a01633:	e9 cf 00 00 00       	jmp    0x753650a01707
    753650a01638:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0163f:	02 00 00 00 
    753650a01643:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a0164a:	01 00 00 00 
    753650a0164e:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a01655:	62 00 00 
    753650a01658:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0165d:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01662:	4d 89 cf             	mov    r15,r9
    753650a01665:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a0166a:	4c 89 d5             	mov    rbp,r10
    753650a0166d:	4d 89 dc             	mov    r12,r11
    753650a01670:	ff d0                	call   rax
    753650a01672:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01677:	4d 89 e3             	mov    r11,r12
    753650a0167a:	49 89 ea             	mov    r10,rbp
    753650a0167d:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a01682:	4d 89 f9             	mov    r9,r15
    753650a01685:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    753650a0168a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01691:	00 
    753650a01692:	84 c9                	test   cl,cl
    753650a01694:	0f 84 70 f4 ff e7    	je     0x753638a00b0a
    753650a0169a:	eb 6b                	jmp    0x753650a01707
    753650a0169c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    753650a016a3:	2a 03 01 00 
    753650a016a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a016ae:	02 00 00 00 
    753650a016b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    753650a016b9:	01 00 00 00 
    753650a016bd:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a016c4:	62 00 00 
    753650a016c7:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a016cc:	4c 89 ef             	mov    rdi,r13
    753650a016cf:	4d 89 cf             	mov    r15,r9
    753650a016d2:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a016d7:	4c 89 d5             	mov    rbp,r10
    753650a016da:	4d 89 dc             	mov    r12,r11
    753650a016dd:	ff d0                	call   rax
    753650a016df:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a016e4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a016e9:	4d 89 e3             	mov    r11,r12
    753650a016ec:	49 89 ea             	mov    r10,rbp
    753650a016ef:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a016f4:	4d 89 f9             	mov    r9,r15
    753650a016f7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a016fe:	00 
    753650a016ff:	84 c9                	test   cl,cl
    753650a01701:	0f 84 16 f4 ff e7    	je     0x753638a00b1d
    753650a01707:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a0170e:	e9 93 fd ff ff       	jmp    0x753650a014a6
    753650a01713:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    753650a0171a:	2a 03 01 00 
    753650a0171e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a01725:	04 00 00 00 
    753650a01729:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a01730:	02 00 00 00 
    753650a01734:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0173b:	62 00 00 
    753650a0173e:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01743:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01748:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a0174d:	4d 89 cf             	mov    r15,r9
    753650a01750:	4d 89 d4             	mov    r12,r10
    753650a01753:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01758:	ff d0                	call   rax
    753650a0175a:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a0175f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01764:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01769:	4d 89 e2             	mov    r10,r12
    753650a0176c:	4d 89 f9             	mov    r9,r15
    753650a0176f:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a01774:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0177b:	00 
    753650a0177c:	84 c9                	test   cl,cl
    753650a0177e:	0f 84 ce f3 ff e7    	je     0x753638a00b52
    753650a01784:	e9 ea 00 00 00       	jmp    0x753650a01873
    753650a01789:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    753650a01790:	2a 03 01 00 
    753650a01794:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0179b:	04 00 00 00 
    753650a0179f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a017a6:	02 00 00 00 
    753650a017aa:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a017b1:	62 00 00 
    753650a017b4:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a017b9:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a017be:	44 89 e6             	mov    esi,r12d
    753650a017c1:	89 da                	mov    edx,ebx
    753650a017c3:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a017c8:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a017cd:	4c 89 d5             	mov    rbp,r10
    753650a017d0:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a017d5:	ff d0                	call   rax
    753650a017d7:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753650a017dc:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a017e1:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a017e6:	49 89 ea             	mov    r10,rbp
    753650a017e9:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a017ee:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a017f3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a017fa:	00 
    753650a017fb:	84 c9                	test   cl,cl
    753650a017fd:	0f 84 73 f3 ff e7    	je     0x753638a00b76
    753650a01803:	eb 6e                	jmp    0x753650a01873
    753650a01805:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    753650a0180c:	2e 03 01 00 
    753650a01810:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a01817:	04 00 00 00 
    753650a0181b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a01822:	02 00 00 00 
    753650a01826:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a0182d:	62 00 00 
    753650a01830:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01835:	4c 89 ef             	mov    rdi,r13
    753650a01838:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a0183d:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753650a01842:	4c 89 d5             	mov    rbp,r10
    753650a01845:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a0184a:	ff d0                	call   rax
    753650a0184c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01851:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01856:	49 89 ea             	mov    r10,rbp
    753650a01859:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    753650a0185e:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01863:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0186a:	00 
    753650a0186b:	84 c9                	test   cl,cl
    753650a0186d:	0f 84 15 f3 ff e7    	je     0x753638a00b88
    753650a01873:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a0187a:	bb 04 00 00 00       	mov    ebx,0x4
    753650a0187f:	bd 02 00 00 00       	mov    ebp,0x2
    753650a01884:	e9 ff f5 ff e7       	jmp    0x753638a00e88
    753650a01889:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753650a01890:	70 03 01 00 
    753650a01894:	b1 01                	mov    cl,0x1
    753650a01896:	bd 04 00 00 00       	mov    ebp,0x4
    753650a0189b:	bb 02 00 00 00       	mov    ebx,0x2
    753650a018a0:	e9 cd f7 ff e7       	jmp    0x753638a01072
    753650a018a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    753650a018ac:	48 03 01 00 
    753650a018b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a018b7:	02 00 00 00 
    753650a018bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    753650a018c2:	0d 00 00 00 
    753650a018c6:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a018cd:	62 00 00 
    753650a018d0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a018d5:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a018da:	be f0 12 01 00       	mov    esi,0x112f0
    753650a018df:	89 da                	mov    edx,ebx
    753650a018e1:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a018e6:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    753650a018eb:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a018f0:	ff d0                	call   rax
    753650a018f2:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a018f7:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a018fc:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    753650a01901:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01906:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0190d:	00 
    753650a0190e:	84 c9                	test   cl,cl
    753650a01910:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753650a01915:	0f 84 6d f3 ff e7    	je     0x753638a00c88
    753650a0191b:	eb 6d                	jmp    0x753650a0198a
    753650a0191d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    753650a01924:	4a 03 01 00 
    753650a01928:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0192f:	02 00 00 00 
    753650a01933:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    753650a0193a:	0d 00 00 00 
    753650a0193e:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01945:	62 00 00 
    753650a01948:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a0194d:	4c 89 ef             	mov    rdi,r13
    753650a01950:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a01955:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    753650a0195a:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a0195f:	ff d0                	call   rax
    753650a01961:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753650a01966:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0196b:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01970:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    753650a01975:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a0197a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01981:	00 
    753650a01982:	84 c9                	test   cl,cl
    753650a01984:	0f 84 07 f3 ff e7    	je     0x753638a00c91
    753650a0198a:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01991:	bb 02 00 00 00       	mov    ebx,0x2
    753650a01996:	bd 0d 00 00 00       	mov    ebp,0xd
    753650a0199b:	e9 e8 f4 ff e7       	jmp    0x753638a00e88
    753650a019a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    753650a019a7:	52 03 01 00 
    753650a019ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a019b2:	02 00 00 00 
    753650a019b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    753650a019bd:	10 00 00 00 
    753650a019c1:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a019c8:	62 00 00 
    753650a019cb:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a019d0:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a019d5:	be f4 12 01 00       	mov    esi,0x112f4
    753650a019da:	89 ea                	mov    edx,ebp
    753650a019dc:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a019e1:	4c 89 d5             	mov    rbp,r10
    753650a019e4:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a019e9:	ff d0                	call   rax
    753650a019eb:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753650a019f0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a019f5:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a019fa:	49 89 ea             	mov    r10,rbp
    753650a019fd:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01a02:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01a09:	00 
    753650a01a0a:	84 c9                	test   cl,cl
    753650a01a0c:	0f 84 9d f2 ff e7    	je     0x753638a00caf
    753650a01a12:	eb 69                	jmp    0x753650a01a7d
    753650a01a14:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    753650a01a1b:	54 03 01 00 
    753650a01a1f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01a26:	02 00 00 00 
    753650a01a2a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    753650a01a31:	10 00 00 00 
    753650a01a35:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01a3c:	62 00 00 
    753650a01a3f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01a44:	4c 89 ef             	mov    rdi,r13
    753650a01a47:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a01a4c:	4c 89 d5             	mov    rbp,r10
    753650a01a4f:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01a54:	ff d0                	call   rax
    753650a01a56:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753650a01a5b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01a60:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01a65:	49 89 ea             	mov    r10,rbp
    753650a01a68:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01a6d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01a74:	00 
    753650a01a75:	84 c9                	test   cl,cl
    753650a01a77:	0f 84 3b f2 ff e7    	je     0x753638a00cb8
    753650a01a7d:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01a84:	bb 02 00 00 00       	mov    ebx,0x2
    753650a01a89:	bd 10 00 00 00       	mov    ebp,0x10
    753650a01a8e:	e9 f5 f3 ff e7       	jmp    0x753638a00e88
    753650a01a93:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    753650a01a9a:	5c 03 01 00 
    753650a01a9e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01aa5:	02 00 00 00 
    753650a01aa9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    753650a01ab0:	13 00 00 00 
    753650a01ab4:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a01abb:	62 00 00 
    753650a01abe:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a01ac3:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01ac8:	be f8 12 01 00       	mov    esi,0x112f8
    753650a01acd:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a01ad2:	4c 89 d5             	mov    rbp,r10
    753650a01ad5:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01ada:	ff d0                	call   rax
    753650a01adc:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753650a01ae1:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a01ae6:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01aeb:	49 89 ea             	mov    r10,rbp
    753650a01aee:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01af3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01afa:	00 
    753650a01afb:	84 c9                	test   cl,cl
    753650a01afd:	0f 84 d7 f1 ff e7    	je     0x753638a00cda
    753650a01b03:	eb 5e                	jmp    0x753650a01b63
    753650a01b05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    753650a01b0c:	5e 03 01 00 
    753650a01b10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01b17:	02 00 00 00 
    753650a01b1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    753650a01b22:	13 00 00 00 
    753650a01b26:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01b2d:	62 00 00 
    753650a01b30:	4c 89 ef             	mov    rdi,r13
    753650a01b33:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a01b38:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    753650a01b3d:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01b42:	ff d0                	call   rax
    753650a01b44:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01b49:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    753650a01b4e:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01b53:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01b5a:	00 
    753650a01b5b:	84 c9                	test   cl,cl
    753650a01b5d:	0f 84 83 f1 ff e7    	je     0x753638a00ce6
    753650a01b63:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01b6a:	bb 02 00 00 00       	mov    ebx,0x2
    753650a01b6f:	bd 13 00 00 00       	mov    ebp,0x13
    753650a01b74:	e9 0f f3 ff e7       	jmp    0x753638a00e88
    753650a01b79:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    753650a01b80:	e9 ed f4 ff e7       	jmp    0x753638a01072
    753650a01b85:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    753650a01b8c:	7a 03 01 00 
    753650a01b90:	b1 01                	mov    cl,0x1
    753650a01b92:	bd 15 00 00 00       	mov    ebp,0x15
    753650a01b97:	e9 ff fc ff ff       	jmp    0x753650a0189b
    753650a01b9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    753650a01ba3:	a4 03 01 00 
    753650a01ba7:	b1 01                	mov    cl,0x1
    753650a01ba9:	bd 17 00 00 00       	mov    ebp,0x17
    753650a01bae:	e9 e8 fc ff ff       	jmp    0x753650a0189b
    753650a01bb3:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01bb8:	4d 89 d7             	mov    r15,r10
    753650a01bbb:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    753650a01bc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    753650a01bc7:	68 03 01 00 
    753650a01bcb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a01bd2:	04 00 00 00 
    753650a01bd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    753650a01bdd:	19 00 00 00 
    753650a01be1:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01be8:	62 00 00 
    753650a01beb:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01bf0:	44 89 e6             	mov    esi,r12d
    753650a01bf3:	ff d0                	call   rax
    753650a01bf5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01bfc:	00 
    753650a01bfd:	84 c9                	test   cl,cl
    753650a01bff:	0f 85 d9 02 00 00    	jne    0x753650a01ede
    753650a01c05:	89 c3                	mov    ebx,eax
    753650a01c07:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    753650a01c0c:	4d 89 fa             	mov    r10,r15
    753650a01c0f:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01c14:	e9 79 f1 ff e7       	jmp    0x753638a00d92
    753650a01c19:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a01c1e:	4d 89 d4             	mov    r12,r10
    753650a01c21:	4d 89 cf             	mov    r15,r9
    753650a01c24:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    753650a01c2b:	68 03 01 00 
    753650a01c2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a01c36:	04 00 00 00 
    753650a01c3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    753650a01c41:	19 00 00 00 
    753650a01c45:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01c4c:	62 00 00 
    753650a01c4f:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01c54:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    753650a01c59:	ff d0                	call   rax
    753650a01c5b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01c62:	00 
    753650a01c63:	84 c9                	test   cl,cl
    753650a01c65:	0f 85 73 02 00 00    	jne    0x753650a01ede
    753650a01c6b:	4d 89 f9             	mov    r9,r15
    753650a01c6e:	4d 89 e2             	mov    r10,r12
    753650a01c71:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a01c76:	48 89 e9             	mov    rcx,rbp
    753650a01c79:	48 89 c7             	mov    rdi,rax
    753650a01c7c:	e9 2f f1 ff e7       	jmp    0x753638a00db0
    753650a01c81:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    753650a01c86:	4d 89 dc             	mov    r12,r11
    753650a01c89:	4d 89 d7             	mov    r15,r10
    753650a01c8c:	4c 89 cb             	mov    rbx,r9
    753650a01c8f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    753650a01c96:	6c 03 01 00 
    753650a01c9a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01ca1:	02 00 00 00 
    753650a01ca5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a01cac:	1a 00 00 00 
    753650a01cb0:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01cb7:	62 00 00 
    753650a01cba:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01cbf:	ff d0                	call   rax
    753650a01cc1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01cc8:	00 
    753650a01cc9:	84 c9                	test   cl,cl
    753650a01ccb:	0f 85 f7 01 00 00    	jne    0x753650a01ec8
    753650a01cd1:	49 89 d9             	mov    r9,rbx
    753650a01cd4:	4d 89 fa             	mov    r10,r15
    753650a01cd7:	4d 89 e3             	mov    r11,r12
    753650a01cda:	48 89 e9             	mov    rcx,rbp
    753650a01cdd:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    753650a01ce2:	e9 f8 f0 ff e7       	jmp    0x753638a00ddf
    753650a01ce7:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    753650a01cec:	4d 89 dc             	mov    r12,r11
    753650a01cef:	4d 89 d7             	mov    r15,r10
    753650a01cf2:	4c 89 cb             	mov    rbx,r9
    753650a01cf5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    753650a01cfc:	6c 03 01 00 
    753650a01d00:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01d07:	02 00 00 00 
    753650a01d0b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a01d12:	1a 00 00 00 
    753650a01d16:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01d1d:	62 00 00 
    753650a01d20:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01d25:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    753650a01d2a:	ff d0                	call   rax
    753650a01d2c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01d33:	00 
    753650a01d34:	84 c9                	test   cl,cl
    753650a01d36:	0f 85 8c 01 00 00    	jne    0x753650a01ec8
    753650a01d3c:	49 89 d9             	mov    r9,rbx
    753650a01d3f:	4d 89 fa             	mov    r10,r15
    753650a01d42:	4d 89 e3             	mov    r11,r12
    753650a01d45:	48 89 e9             	mov    rcx,rbp
    753650a01d48:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    753650a01d4d:	e9 b1 f0 ff e7       	jmp    0x753638a00e03
    753650a01d52:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    753650a01d57:	4d 89 dc             	mov    r12,r11
    753650a01d5a:	4d 89 d7             	mov    r15,r10
    753650a01d5d:	4c 89 cb             	mov    rbx,r9
    753650a01d60:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    753650a01d67:	6c 03 01 00 
    753650a01d6b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01d72:	02 00 00 00 
    753650a01d76:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a01d7d:	1a 00 00 00 
    753650a01d81:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01d88:	62 00 00 
    753650a01d8b:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01d90:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    753650a01d95:	ff d0                	call   rax
    753650a01d97:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01d9e:	00 
    753650a01d9f:	84 c9                	test   cl,cl
    753650a01da1:	0f 85 21 01 00 00    	jne    0x753650a01ec8
    753650a01da7:	49 89 d9             	mov    r9,rbx
    753650a01daa:	4d 89 fa             	mov    r10,r15
    753650a01dad:	4d 89 e3             	mov    r11,r12
    753650a01db0:	48 89 e9             	mov    rcx,rbp
    753650a01db3:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    753650a01db8:	e9 6a f0 ff e7       	jmp    0x753638a00e27
    753650a01dbd:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    753650a01dc2:	4d 89 dc             	mov    r12,r11
    753650a01dc5:	4d 89 d7             	mov    r15,r10
    753650a01dc8:	4c 89 cb             	mov    rbx,r9
    753650a01dcb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    753650a01dd2:	6c 03 01 00 
    753650a01dd6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01ddd:	02 00 00 00 
    753650a01de1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a01de8:	1a 00 00 00 
    753650a01dec:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01df3:	62 00 00 
    753650a01df6:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01dfb:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a01e00:	ff d0                	call   rax
    753650a01e02:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01e09:	00 
    753650a01e0a:	84 c9                	test   cl,cl
    753650a01e0c:	0f 85 b6 00 00 00    	jne    0x753650a01ec8
    753650a01e12:	49 89 d9             	mov    r9,rbx
    753650a01e15:	4d 89 fa             	mov    r10,r15
    753650a01e18:	4d 89 e3             	mov    r11,r12
    753650a01e1b:	48 89 e9             	mov    rcx,rbp
    753650a01e1e:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    753650a01e23:	e9 26 f0 ff e7       	jmp    0x753638a00e4e
    753650a01e28:	48 89 fd             	mov    rbp,rdi
    753650a01e2b:	4c 89 cb             	mov    rbx,r9
    753650a01e2e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    753650a01e35:	6c 03 01 00 
    753650a01e39:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01e40:	02 00 00 00 
    753650a01e44:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a01e4b:	1a 00 00 00 
    753650a01e4f:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01e56:	62 00 00 
    753650a01e59:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    753650a01e5e:	44 89 d6             	mov    esi,r10d
    753650a01e61:	ff d0                	call   rax
    753650a01e63:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01e6a:	00 
    753650a01e6b:	84 c9                	test   cl,cl
    753650a01e6d:	75 59                	jne    0x753650a01ec8
    753650a01e6f:	49 89 d9             	mov    r9,rbx
    753650a01e72:	48 89 ef             	mov    rdi,rbp
    753650a01e75:	e9 f0 ef ff e7       	jmp    0x753638a00e6a
    753650a01e7a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    753650a01e81:	6e 03 01 00 
    753650a01e85:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01e8c:	02 00 00 00 
    753650a01e90:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    753650a01e97:	1b 00 00 00 
    753650a01e9b:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a01ea2:	62 00 00 
    753650a01ea5:	4c 89 ef             	mov    rdi,r13
    753650a01ea8:	be 2a 00 00 00       	mov    esi,0x2a
    753650a01ead:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    753650a01eb2:	ff d0                	call   rax
    753650a01eb4:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01ebb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a01ec2:	00 
    753650a01ec3:	e9 c0 ef ff e7       	jmp    0x753638a00e88
    753650a01ec8:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01ecf:	bb 02 00 00 00       	mov    ebx,0x2
    753650a01ed4:	bd 1a 00 00 00       	mov    ebp,0x1a
    753650a01ed9:	e9 aa ef ff e7       	jmp    0x753638a00e88
    753650a01ede:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    753650a01ee5:	bb 04 00 00 00       	mov    ebx,0x4
    753650a01eea:	bd 19 00 00 00       	mov    ebp,0x19
    753650a01eef:	e9 94 ef ff e7       	jmp    0x753638a00e88
