
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65808-0-128875738702768.bin:     file format binary


Disassembly of section .data:

0000753638a023b0 <.data>:
    753638a023b0:	48 83 ec 28          	sub    rsp,0x28
    753638a023b4:	ba d1 fe fe ff       	mov    edx,0xfffefed1
    753638a023b9:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a023c0:	01 d6                	add    esi,edx
    753638a023c2:	b1 01                	mov    cl,0x1
    753638a023c4:	b8 65 01 00 00       	mov    eax,0x165
    753638a023c9:	83 fe e0             	cmp    esi,0xffffffe0
    753638a023cc:	0f 87 ad 01 00 00    	ja     0x753638a0257f
    753638a023d2:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a023d9:	83 fa e0             	cmp    edx,0xffffffe0
    753638a023dc:	0f 87 9d 01 00 00    	ja     0x753638a0257f
    753638a023e2:	4d 89 f0             	mov    r8,r14
    753638a023e5:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    753638a023ec:	4d 8b 8d 38 01 00 00 	mov    r9,QWORD PTR [r13+0x138]
    753638a023f3:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    753638a023fa:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    753638a023fe:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    753638a02402:	41 89 c4             	mov    r12d,eax
    753638a02405:	41 c1 ec 07          	shr    r12d,0x7
    753638a02409:	31 c9                	xor    ecx,ecx
    753638a0240b:	41 31 c4             	xor    r12d,eax
    753638a0240e:	45 89 65 04          	mov    DWORD PTR [r13+0x4],r12d
    753638a02412:	0f 94 c1             	sete   cl
    753638a02415:	c1 e8 1f             	shr    eax,0x1f
    753638a02418:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    753638a0241f:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    753638a02426:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    753638a0242d:	00 00 00 00 
    753638a02431:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a02438:	00 00 00 00 
    753638a0243c:	45 89 65 28          	mov    DWORD PTR [r13+0x28],r12d
    753638a02440:	41 c7 45 24 b9 79 37 	mov    DWORD PTR [r13+0x24],0x9e3779b9
    753638a02447:	9e 
    753638a02448:	8d 5e fc             	lea    ebx,[rsi-0x4]
    753638a0244b:	40 f6 c6 03          	test   sil,0x3
    753638a0244f:	0f 85 f6 0b 00 18    	jne    0x753650a0304b
    753638a02455:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a0245c:	45 8b 5d 3c          	mov    r11d,DWORD PTR [r13+0x3c]
    753638a02460:	41 89 de             	mov    r14d,ebx
    753638a02463:	41 c1 ee 0c          	shr    r14d,0xc
    753638a02467:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    753638a0246b:	48 85 c0             	test   rax,rax
    753638a0246e:	0f 84 41 0c 00 18    	je     0x753650a030b5
    753638a02474:	89 d9                	mov    ecx,ebx
    753638a02476:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a0247c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0247f:	8d 6e f8             	lea    ebp,[rsi-0x8]
    753638a02482:	41 89 ef             	mov    r15d,ebp
    753638a02485:	41 c1 ef 0c          	shr    r15d,0xc
    753638a02489:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    753638a0248d:	48 85 c0             	test   rax,rax
    753638a02490:	0f 84 98 0c 00 18    	je     0x753650a0312e
    753638a02496:	89 e9                	mov    ecx,ebp
    753638a02498:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a0249e:	44 89 1c 08          	mov    DWORD PTR [rax+rcx*1],r11d
    753638a024a2:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a024a6:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    753638a024aa:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    753638a024ae:	0f 85 f1 0c 00 18    	jne    0x753650a031a5
    753638a024b4:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    753638a024b8:	48 85 c0             	test   rax,rax
    753638a024bb:	0f 84 5c 0d 00 18    	je     0x753650a0321d
    753638a024c1:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    753638a024c7:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    753638a024ca:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    753638a024ce:	48 85 c0             	test   rax,rax
    753638a024d1:	0f 84 b1 0d 00 18    	je     0x753650a03288
    753638a024d7:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    753638a024dd:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    753638a024e0:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a024e4:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a024eb:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a024ef:	43 8d 0c 64          	lea    ecx,[r12+r12*2]
    753638a024f3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    753638a024f7:	43 8d 8c 64 b9 79 37 	lea    ecx,[r12+r12*2-0x61c88647]
    753638a024fe:	9e 
    753638a024ff:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    753638a02503:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    753638a02507:	b1 01                	mov    cl,0x1
    753638a02509:	bb 02 00 00 00       	mov    ebx,0x2
    753638a0250e:	bd 0b 00 00 00       	mov    ebp,0xb
    753638a02513:	a8 01                	test   al,0x1
    753638a02515:	0f 85 c8 0d 00 18    	jne    0x753650a032e3
    753638a0251b:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753638a02522:	01 ea                	add    edx,ebp
    753638a02524:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    753638a0252b:	39 f2                	cmp    edx,esi
    753638a0252d:	73 36                	jae    0x753638a02565
    753638a0252f:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    753638a02536:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    753638a0253c:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    753638a0253f:	75 24                	jne    0x753638a02565
    753638a02541:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a02548:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753638a0254f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a02556:	00 
    753638a02557:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    753638a0255c:	4d 89 c6             	mov    r14,r8
    753638a0255f:	48 83 c4 28          	add    rsp,0x28
    753638a02563:	ff e0                	jmp    rax
    753638a02565:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a0256c:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a02573:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a0257a:	b8 28 01 00 00       	mov    eax,0x128
    753638a0257f:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a02584:	48 83 c4 28          	add    rsp,0x28
    753638a02588:	c2 08 00             	ret    0x8
