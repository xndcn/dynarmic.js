; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010084(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 65668
  %5 = icmp ugt i32 %4, 10
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb24 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb24, 0
  %10 = sub i32 %guard_lb24, 65668
  %11 = icmp ugt i32 %10, 10
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x00010084_entry, label %lb_guard_miss, !prof !0

insn_0x00010084_entry:                            ; preds = %lb_guard
  br label %insn_0x00010084

insn_0x00010084:                                  ; preds = %insn_0x00010084_entry
  %14 = getelementptr i8, ptr %cpu, i32 16
  %rs = load i32, ptr %14, align 4
  %15 = getelementptr i8, ptr %cpu, i32 276
  %cc_old = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %16, align 4
  %addr = add i32 %fp, -4
  %17 = and i32 %addr, 3
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010084
  %19 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %20, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65668, i32 %addr, i32 0)
  %21 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %21, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010084
  %22 = lshr i32 %addr, 12
  %page_index = zext i32 %22 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %23 = and i32 %addr, 4095
  %page_offset = zext i32 %23 to i64
  %24 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %24, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %25 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %26, align 4
  %27 = call i32 @mem_read32(ptr %mem, i32 %addr)
  %28 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %28, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %27, %did_jump_cont ]
  %29 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rs, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %32, align 4
  br label %insn_0x0001008c_entry

did_jump_exit:                                    ; preds = %page_slow
  %33 = getelementptr i8, ptr %cpu, i64 188
  %next_pc25 = load i32, ptr %33, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x0001008c_entry:                            ; preds = %page_done
  br label %insn_0x0001008c

insn_0x0001008c:                                  ; preds = %insn_0x0001008c_entry
  %addr1 = add i32 %fp, -8
  %34 = and i32 %addr1, 3
  %35 = icmp ne i32 %34, 0
  br i1 %35, label %data_misaligned2, label %data_aligned3, !prof !1

data_misaligned2:                                 ; preds = %insn_0x0001008c
  %36 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %38, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65676, i32 %addr1, i32 0)
  %39 = getelementptr i8, ptr %cpu, i64 188
  %next_pc26 = load i32, ptr %39, align 4
  br label %chain_exit

data_aligned3:                                    ; preds = %insn_0x0001008c
  %40 = lshr i32 %addr1, 12
  %page_index7 = zext i32 %40 to i64
  %page_slot8 = getelementptr ptr, ptr %page_table, i64 %page_index7
  %page9 = load ptr, ptr %page_slot8, align 8
  %page_mapped10 = icmp ne ptr %page9, null
  br i1 %page_mapped10, label %page_fast4, label %page_slow5, !prof !0

page_fast4:                                       ; preds = %data_aligned3
  %41 = and i32 %addr1, 4095
  %page_offset11 = zext i32 %41 to i64
  %42 = getelementptr i8, ptr %page9, i64 %page_offset11
  %page_val12 = load i32, ptr %42, align 4
  br label %page_done6

page_slow5:                                       ; preds = %data_aligned3
  %43 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %45, align 4
  %46 = call i32 @mem_read32(ptr %mem, i32 %addr1)
  %47 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %47, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_done6:                                       ; preds = %did_jump_cont14, %page_fast4
  %mem_val17 = phi i32 [ %page_val12, %page_fast4 ], [ %46, %did_jump_cont14 ]
  %48 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mem_val17, ptr %48, align 4
  br label %insn_0x0001008e_entry

did_jump_exit13:                                  ; preds = %page_slow5
  %49 = getelementptr i8, ptr %cpu, i64 188
  %next_pc27 = load i32, ptr %49, align 4
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_slow5
  br label %page_done6

insn_0x0001008e_entry:                            ; preds = %page_done6
  br label %insn_0x0001008e

insn_0x0001008e:                                  ; preds = %insn_0x0001008e_entry
  %50 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %51, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65678
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65682
  %52 = getelementptr i8, ptr %cpu, i32 156
  %lc18 = load i32, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 148
  %lt19 = load i32, ptr %53, align 4
  %lc_gt120 = icmp ugt i32 %lc18, 1
  %at_lb21 = icmp eq i32 %lb1, 65678
  %hwloop_cond22 = and i1 %lc_gt120, %at_lb21
  %hwloop_rets23 = select i1 %hwloop_cond22, i32 %lt19, i32 %hwloop_rets
  %54 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets23, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 188
  store i32 66344, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %56, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %57 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %57 monotonic, align 4, !range !2
  %58 = icmp ult i32 %chain_total, %chain_budget
  br i1 %58, label %chain_go, label %chain_leave28, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %59 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %59, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %insn_0x0001008e
  %chain_slot = getelementptr i8, ptr %chain_table, i64 530752
  %60 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %60, align 4
  %61 = icmp eq i32 %slot_pc, 66344
  br i1 %61, label %chain_hit, label %chain_leave28, !prof !0

chain_leave28:                                    ; preds = %chain_go, %insn_0x0001008e
  %62 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %65, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %66 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %67, align 4
  %68 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %68, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit13, %data_misaligned2, %did_jump_exit, %data_misaligned
  %next_pc29 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc25, %did_jump_exit ], [ %next_pc26, %data_misaligned2 ], [ %next_pc27, %did_jump_exit13 ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %tail = phi i32 [ 8, %data_misaligned ], [ 8, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %tail30 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %69 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets32 = load i32, ptr %69, align 4
  %chain_total33 = add nuw i32 %chain_packets32, %packets
  %70 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget34 = load atomic i32, ptr %70 monotonic, align 4, !range !2
  %71 = icmp ult i32 %chain_total33, %chain_budget34
  br i1 %71, label %chain_lookup, label %chain_leave31, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %72 = lshr i32 %next_pc29, 1
  %73 = and i32 %72, 65535
  %74 = zext i32 %73 to i64
  %75 = mul i64 %74, 16
  %chain_slot35 = getelementptr i8, ptr %chain_table, i64 %75
  %76 = getelementptr i8, ptr %chain_slot35, i64 0
  %slot_pc36 = load i32, ptr %76, align 4
  %77 = icmp eq i32 %slot_pc36, %next_pc29
  br i1 %77, label %chain_hit37, label %chain_leave31, !prof !0

chain_leave31:                                    ; preds = %chain_lookup, %chain_exit
  %78 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail30, ptr %79, align 4
  ret void

chain_hit37:                                      ; preds = %chain_lookup
  %80 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total33, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %81, align 1
  %82 = getelementptr i8, ptr %chain_slot35, i64 8
  %chain_fn38 = load ptr, ptr %82, align 8
  musttail call swifttailcc void %chain_fn38(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
