; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010110(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65808
  %6 = icmp ugt i32 %5, 30
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb50 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb50, 0
  %11 = sub i32 %guard_lb50, 65808
  %12 = icmp ugt i32 %11, 30
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010110_entry, label %lb_guard_miss, !prof !0

insn_0x00010110_entry:                            ; preds = %lb_guard
  br label %insn_0x00010110

insn_0x00010110:                                  ; preds = %insn_0x00010110_entry
  %15 = getelementptr i8, ptr %cpu, i32 0
  %rs = load i32, ptr %15, align 4
  %lsr32 = lshr i32 %rs, 7
  %16 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr32, ptr %16, align 4
  %17 = icmp eq i32 %lsr32, 0
  %az = zext i1 %17 to i32
  %an = lshr i32 %lsr32, 31
  %18 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %23, align 4
  br label %insn_0x00010114_entry

insn_0x00010114_entry:                            ; preds = %insn_0x00010110
  br label %insn_0x00010114

insn_0x00010114:                                  ; preds = %insn_0x00010114_entry
  %xor32 = xor i32 %rs, %lsr32
  %24 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %24, align 4
  %25 = icmp eq i32 %xor32, 0
  %az1 = zext i1 %25 to i32
  %an2 = lshr i32 %xor32, 31
  %26 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %31, align 4
  br label %insn_0x00010116_entry

insn_0x00010116_entry:                            ; preds = %insn_0x00010114
  br label %insn_0x00010116

insn_0x00010116:                                  ; preds = %insn_0x00010116_entry
  %32 = getelementptr i8, ptr %cpu, i32 40
  store i32 %xor32, ptr %32, align 4
  br label %insn_0x00010118_entry

insn_0x00010118_entry:                            ; preds = %insn_0x00010116
  br label %insn_0x00010118

insn_0x00010118:                                  ; preds = %insn_0x00010118_entry
  %33 = getelementptr i8, ptr %cpu, i32 36
  %old = load i32, ptr %33, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, -1640562688
  %34 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_hi, ptr %34, align 4
  br label %insn_0x0001011c_entry

insn_0x0001011c_entry:                            ; preds = %insn_0x00010118
  br label %insn_0x0001011c

insn_0x0001011c:                                  ; preds = %insn_0x0001011c_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 31161
  %35 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %35, align 4
  br label %insn_0x00010120_entry

insn_0x00010120_entry:                            ; preds = %insn_0x0001011c
  br label %insn_0x00010120

insn_0x00010120:                                  ; preds = %insn_0x00010120_entry
  %36 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %38, align 4
  %sp1 = sub i32 %sp, 4
  %39 = and i32 %sp1, 3
  %40 = icmp ne i32 %39, 0
  br i1 %40, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010120
  %41 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %43, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65824, i32 %sp1, i32 65536)
  %44 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i64 188
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %cpu, i64 296
  %48 = load i8, ptr %47, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010120
  %49 = lshr i32 %sp1, 12
  %page_index = zext i32 %49 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %50 = and i32 %sp1, 4095
  %page_offset = zext i32 %50 to i64
  %51 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %51, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %52 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %54, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %55 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %55, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp2 = sub i32 %sp1, 4
  %56 = and i32 %sp2, 3
  %57 = icmp ne i32 %56, 0
  br i1 %57, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %58 = getelementptr i8, ptr %cpu, i64 188
  %next_pc51 = load i32, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 188
  %60 = load i32, ptr %59, align 4
  %61 = getelementptr i8, ptr %cpu, i64 296
  %62 = load i8, ptr %61, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %63 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %65, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65824, i32 %sp2, i32 65536)
  %66 = getelementptr i8, ptr %cpu, i64 188
  %next_pc52 = load i32, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 188
  %68 = load i32, ptr %67, align 4
  %69 = getelementptr i8, ptr %cpu, i64 296
  %70 = load i8, ptr %69, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %71 = lshr i32 %sp2, 12
  %page_index8 = zext i32 %71 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %72 = and i32 %sp2, 4095
  %page_offset12 = zext i32 %72 to i64
  %73 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %fp, ptr %73, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %74 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %76, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %77 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %77, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %78 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %78, align 4
  %sp3 = sub i32 %sp2, 0
  %79 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %79, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %80 = icmp ne i8 %cec_pending, 0
  br i1 %80, label %cec_check, label %cec_checked, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %81 = getelementptr i8, ptr %cpu, i64 188
  %next_pc53 = load i32, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 188
  %83 = load i32, ptr %82, align 4
  %84 = getelementptr i8, ptr %cpu, i64 296
  %85 = load i8, ptr %84, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

cec_check:                                        ; preds = %page_wr_done7
  %86 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %88, align 4
  call void @cec_check_pending(ptr %cpu)
  %89 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %89, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

cec_checked:                                      ; preds = %did_jump_cont18, %page_wr_done7
  br label %insn_0x00010124_entry

did_jump_exit17:                                  ; preds = %cec_check
  %90 = getelementptr i8, ptr %cpu, i64 188
  %next_pc54 = load i32, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 188
  %92 = load i32, ptr %91, align 4
  %93 = getelementptr i8, ptr %cpu, i64 296
  %94 = load i8, ptr %93, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010124_entry:                            ; preds = %cec_checked
  br label %insn_0x00010124

insn_0x00010124:                                  ; preds = %insn_0x00010124_entry
  %95 = and i32 %sp2, 3
  %96 = icmp ne i32 %95, 0
  br i1 %96, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x00010124
  %97 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %99, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65828, i32 %sp2, i32 0)
  %100 = getelementptr i8, ptr %cpu, i64 188
  %next_pc55 = load i32, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 188
  %102 = load i32, ptr %101, align 4
  %103 = getelementptr i8, ptr %cpu, i64 296
  %104 = load i8, ptr %103, align 1
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x00010124
  %105 = lshr i32 %sp2, 12
  %page_index23 = zext i32 %105 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26 = icmp ne ptr %page25, null
  br i1 %page_mapped26, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned22
  %106 = and i32 %sp2, 4095
  %page_offset27 = zext i32 %106 to i64
  %107 = getelementptr i8, ptr %page25, i64 %page_offset27
  %page_val = load i32, ptr %107, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned22
  %108 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %110, align 4
  %111 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %112 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %112, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_done:                                        ; preds = %did_jump_cont29, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %111, %did_jump_cont29 ]
  %sp132 = add i32 %sp2, 4
  %113 = and i32 %sp132, 3
  %114 = icmp ne i32 %113, 0
  br i1 %114, label %data_misaligned33, label %data_aligned34, !prof !1

did_jump_exit28:                                  ; preds = %page_slow
  %115 = getelementptr i8, ptr %cpu, i64 188
  %next_pc56 = load i32, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 188
  %117 = load i32, ptr %116, align 4
  %118 = getelementptr i8, ptr %cpu, i64 296
  %119 = load i8, ptr %118, align 1
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_slow
  br label %page_done

data_misaligned33:                                ; preds = %page_done
  %120 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %122, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65828, i32 %sp132, i32 0)
  %123 = getelementptr i8, ptr %cpu, i64 188
  %next_pc57 = load i32, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i64 188
  %125 = load i32, ptr %124, align 4
  %126 = getelementptr i8, ptr %cpu, i64 296
  %127 = load i8, ptr %126, align 1
  br label %chain_exit

data_aligned34:                                   ; preds = %page_done
  %128 = lshr i32 %sp132, 12
  %page_index38 = zext i32 %128 to i64
  %page_slot39 = getelementptr ptr, ptr %page_table, i64 %page_index38
  %page40 = load ptr, ptr %page_slot39, align 8
  %page_mapped41 = icmp ne ptr %page40, null
  br i1 %page_mapped41, label %page_fast35, label %page_slow36, !prof !0

page_fast35:                                      ; preds = %data_aligned34
  %129 = and i32 %sp132, 4095
  %page_offset42 = zext i32 %129 to i64
  %130 = getelementptr i8, ptr %page40, i64 %page_offset42
  %page_val43 = load i32, ptr %130, align 4
  br label %page_done37

page_slow36:                                      ; preds = %data_aligned34
  %131 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %133, align 4
  %134 = call i32 @mem_read32(ptr %mem, i32 %sp132)
  %135 = getelementptr i8, ptr %cpu, i32 296
  %dj46 = load i8, ptr %135, align 1
  %dj_set47 = icmp ne i8 %dj46, 0
  br i1 %dj_set47, label %did_jump_exit44, label %did_jump_cont45, !prof !1

page_done37:                                      ; preds = %did_jump_cont45, %page_fast35
  %mem_val48 = phi i32 [ %page_val43, %page_fast35 ], [ %134, %did_jump_cont45 ]
  %sp249 = add i32 %sp132, 4
  %136 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val48, ptr %137, align 4
  %138 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp249, ptr %138, align 4
  br label %insn_0x00010128_entry

did_jump_exit44:                                  ; preds = %page_slow36
  %139 = getelementptr i8, ptr %cpu, i64 188
  %next_pc58 = load i32, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i64 188
  %141 = load i32, ptr %140, align 4
  %142 = getelementptr i8, ptr %cpu, i64 296
  %143 = load i8, ptr %142, align 1
  br label %chain_exit

did_jump_cont45:                                  ; preds = %page_slow36
  br label %page_done37

insn_0x00010128_entry:                            ; preds = %page_done37
  br label %insn_0x00010128

insn_0x00010128:                                  ; preds = %insn_0x00010128_entry
  %144 = shl i32 %xor32, 1
  %plshift1 = add i32 %xor32, %144
  %145 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift1, ptr %145, align 4
  br label %insn_0x0001012a_entry

insn_0x0001012a_entry:                            ; preds = %insn_0x00010128
  br label %insn_0x0001012a

insn_0x0001012a:                                  ; preds = %insn_0x0001012a_entry
  %padd = add i32 %plshift1, %with_lo
  %146 = getelementptr i8, ptr %cpu, i32 36
  store i32 %padd, ptr %146, align 4
  br label %insn_0x0001012c_entry

insn_0x0001012c_entry:                            ; preds = %insn_0x0001012a
  br label %insn_0x0001012c

insn_0x0001012c:                                  ; preds = %insn_0x0001012c_entry
  %147 = getelementptr i8, ptr %cpu, i32 0
  store i32 %padd, ptr %147, align 4
  br label %insn_0x0001012e_entry

insn_0x0001012e_entry:                            ; preds = %insn_0x0001012c
  br label %insn_0x0001012e

insn_0x0001012e:                                  ; preds = %insn_0x0001012e_entry
  %lsb = and i32 %mem_val48, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001012e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001012e
  %148 = getelementptr i8, ptr %cpu, i32 188
  store i32 65838, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %150, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %151 = getelementptr i8, ptr %cpu, i64 188
  %next_pc59 = load i32, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i64 188
  %153 = load i32, ptr %152, align 4
  %154 = getelementptr i8, ptr %cpu, i64 296
  %155 = load i8, ptr %154, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %156 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %156, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit44, %data_misaligned33, %did_jump_exit28, %data_misaligned21, %did_jump_exit17, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc60 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc51, %did_jump_exit ], [ %next_pc52, %data_misaligned3 ], [ %next_pc53, %did_jump_exit13 ], [ %next_pc54, %did_jump_exit17 ], [ %next_pc55, %data_misaligned21 ], [ %next_pc56, %did_jump_exit28 ], [ %next_pc57, %data_misaligned33 ], [ %next_pc58, %did_jump_exit44 ], [ %mem_val48, %jump_aligned ], [ %next_pc59, %jump_misalign ]
  %packets = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 6, %data_misaligned3 ], [ 6, %did_jump_exit13 ], [ 6, %did_jump_exit17 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit28 ], [ 7, %data_misaligned33 ], [ 7, %did_jump_exit44 ], [ 11, %jump_aligned ], [ 11, %jump_misalign ]
  %tail = phi i32 [ %46, %data_misaligned ], [ %60, %did_jump_exit ], [ %68, %data_misaligned3 ], [ %83, %did_jump_exit13 ], [ %92, %did_jump_exit17 ], [ %102, %data_misaligned21 ], [ %117, %did_jump_exit28 ], [ %125, %data_misaligned33 ], [ %141, %did_jump_exit44 ], [ %mem_val48, %jump_aligned ], [ %153, %jump_misalign ]
  %tail61 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned3 ], [ 4, %did_jump_exit13 ], [ 4, %did_jump_exit17 ], [ 4, %data_misaligned21 ], [ 4, %did_jump_exit28 ], [ 4, %data_misaligned33 ], [ 4, %did_jump_exit44 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail62 = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 6, %data_misaligned3 ], [ 6, %did_jump_exit13 ], [ 6, %did_jump_exit17 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit28 ], [ 7, %data_misaligned33 ], [ 7, %did_jump_exit44 ], [ 11, %jump_aligned ], [ 11, %jump_misalign ]
  %tail63 = phi i8 [ %48, %data_misaligned ], [ %62, %did_jump_exit ], [ %70, %data_misaligned3 ], [ %85, %did_jump_exit13 ], [ %94, %did_jump_exit17 ], [ %104, %data_misaligned21 ], [ %119, %did_jump_exit28 ], [ %127, %data_misaligned33 ], [ %143, %did_jump_exit44 ], [ 1, %jump_aligned ], [ %155, %jump_misalign ]
  %157 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %157, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %158 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %158 monotonic, align 4, !range !2
  %159 = icmp ult i32 %chain_total, %chain_budget
  br i1 %159, label %chain_lookup, label %chain_leave64, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %160 = lshr i32 %next_pc60, 1
  %161 = and i32 %160, 65535
  %162 = zext i32 %161 to i64
  %163 = mul i64 %162, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %163
  %164 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %164, align 4
  %165 = icmp eq i32 %slot_pc, %next_pc60
  br i1 %165, label %chain_hit, label %chain_leave64, !prof !0

chain_leave64:                                    ; preds = %chain_lookup, %chain_exit
  %166 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail61, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail62, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail63, ptr %169, align 1
  ret void

chain_hit:                                        ; preds = %chain_lookup
  %170 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc60, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %172, align 1
  %173 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %173, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
