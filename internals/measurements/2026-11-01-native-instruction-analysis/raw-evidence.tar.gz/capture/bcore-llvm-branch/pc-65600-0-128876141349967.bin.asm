
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65600-0-128876141349967.bin:     file format binary


Disassembly of section .data:

0000753650a00c4f <.data>:
    753650a00c4f:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a00c56:	01 
    753650a00c57:	48 83 c4 38          	add    rsp,0x38
    753650a00c5b:	c2 08 00             	ret    0x8
    753650a00c5e:	4d 89 d7             	mov    r15,r10
    753650a00c61:	4c 89 c5             	mov    rbp,r8
    753650a00c64:	48 89 fb             	mov    rbx,rdi
    753650a00c67:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00c6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    753650a00c72:	46 00 01 00 
    753650a00c76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00c7d:	02 00 00 00 
    753650a00c81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a00c88:	03 00 00 00 
    753650a00c8c:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00c93:	62 00 00 
    753650a00c96:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00c9b:	4c 89 f7             	mov    rdi,r14
    753650a00c9e:	be 04 f0 00 00       	mov    esi,0xf004
    753650a00ca3:	ff d0                	call   rax
    753650a00ca5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00cac:	00 
    753650a00cad:	0f 85 e5 06 00 00    	jne    0x753650a01398
    753650a00cb3:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00cb8:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00cbc:	48 89 df             	mov    rdi,rbx
    753650a00cbf:	49 89 e8             	mov    r8,rbp
    753650a00cc2:	41 89 c1             	mov    r9d,eax
    753650a00cc5:	4d 89 fa             	mov    r10,r15
    753650a00cc8:	e9 63 fa ff e7       	jmp    0x753638a00730
    753650a00ccd:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00cd2:	45 89 cf             	mov    r15d,r9d
    753650a00cd5:	4c 89 c5             	mov    rbp,r8
    753650a00cd8:	48 89 fb             	mov    rbx,rdi
    753650a00cdb:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00cdf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    753650a00ce6:	4a 00 01 00 
    753650a00cea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00cf1:	02 00 00 00 
    753650a00cf5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a00cfc:	05 00 00 00 
    753650a00d00:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00d07:	62 00 00 
    753650a00d0a:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00d0f:	4c 89 f7             	mov    rdi,r14
    753650a00d12:	be 08 f0 00 00       	mov    esi,0xf008
    753650a00d17:	ff d0                	call   rax
    753650a00d19:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00d20:	00 
    753650a00d21:	0f 85 80 06 00 00    	jne    0x753650a013a7
    753650a00d27:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00d2c:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00d30:	48 89 df             	mov    rdi,rbx
    753650a00d33:	49 89 e8             	mov    r8,rbp
    753650a00d36:	45 89 f9             	mov    r9d,r15d
    753650a00d39:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00d3e:	e9 0a fa ff e7       	jmp    0x753638a0074d
    753650a00d43:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00d47:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    753650a00d4e:	54 00 01 00 
    753650a00d52:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00d59:	02 00 00 00 
    753650a00d5d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    753650a00d64:	09 00 00 00 
    753650a00d68:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a00d6f:	62 00 00 
    753650a00d72:	4c 89 ef             	mov    rdi,r13
    753650a00d75:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00d7a:	4c 89 f6             	mov    rsi,r14
    753650a00d7d:	ba 54 00 01 00       	mov    edx,0x10054
    753650a00d82:	89 d9                	mov    ecx,ebx
    753650a00d84:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a00d8a:	ff d0                	call   rax
    753650a00d8c:	b8 02 00 00 00       	mov    eax,0x2
    753650a00d91:	b9 09 00 00 00       	mov    ecx,0x9
    753650a00d96:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    753650a00d9d:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753650a00da4:	01 ca                	add    edx,ecx
    753650a00da6:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    753650a00dad:	39 fa                	cmp    edx,edi
    753650a00daf:	0f 83 ce 05 00 00    	jae    0x753650a01383
    753650a00db5:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    753650a00dbc:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    753650a00dc2:	48 8b 2c 24          	mov    rbp,QWORD PTR [rsp]
    753650a00dc6:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    753650a00dca:	0f 85 b3 05 00 00    	jne    0x753650a01383
    753650a00dd0:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753650a00dd7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a00dde:	00 
    753650a00ddf:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    753650a00de3:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    753650a00de8:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00ded:	48 83 c4 38          	add    rsp,0x38
    753650a00df1:	ff e0                	jmp    rax
    753650a00df3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    753650a00dfa:	54 00 01 00 
    753650a00dfe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00e05:	02 00 00 00 
    753650a00e09:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    753650a00e10:	09 00 00 00 
    753650a00e14:	48 b9 20 36 9a d4 72 	movabs rcx,0x6272d49a3620
    753650a00e1b:	62 00 00 
    753650a00e1e:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a00e23:	4c 89 f7             	mov    rdi,r14
    753650a00e26:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00e2b:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00e2f:	89 de                	mov    esi,ebx
    753650a00e31:	89 c2                	mov    edx,eax
    753650a00e33:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a00e38:	45 89 cf             	mov    r15d,r9d
    753650a00e3b:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00e40:	4d 89 de             	mov    r14,r11
    753650a00e43:	ff d1                	call   rcx
    753650a00e45:	4d 89 f3             	mov    r11,r14
    753650a00e48:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00e4d:	45 89 f9             	mov    r9d,r15d
    753650a00e50:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a00e55:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a00e5a:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00e5e:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00e63:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00e6a:	00 
    753650a00e6b:	0f 84 20 f9 ff e7    	je     0x753638a00791
    753650a00e71:	e9 16 ff ff ff       	jmp    0x753650a00d8c
    753650a00e76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    753650a00e7d:	56 00 01 00 
    753650a00e81:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00e88:	02 00 00 00 
    753650a00e8c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    753650a00e93:	09 00 00 00 
    753650a00e97:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a00e9e:	62 00 00 
    753650a00ea1:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a00ea6:	4c 89 ef             	mov    rdi,r13
    753650a00ea9:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00eae:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00eb2:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a00eb7:	45 89 cf             	mov    r15d,r9d
    753650a00eba:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00ebf:	4d 89 de             	mov    r14,r11
    753650a00ec2:	ff d0                	call   rax
    753650a00ec4:	4d 89 f3             	mov    r11,r14
    753650a00ec7:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00ecc:	45 89 f9             	mov    r9d,r15d
    753650a00ecf:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a00ed4:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a00ed9:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00edd:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00ee2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00ee9:	00 
    753650a00eea:	0f 84 ab f8 ff e7    	je     0x753638a0079b
    753650a00ef0:	e9 97 fe ff ff       	jmp    0x753650a00d8c
    753650a00ef5:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    753650a00efa:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00eff:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    753650a00f04:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a00f09:	49 89 ff             	mov    r15,rdi
    753650a00f0c:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00f10:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    753650a00f17:	5c 00 01 00 
    753650a00f1b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00f22:	02 00 00 00 
    753650a00f26:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    753650a00f2d:	0c 00 00 00 
    753650a00f31:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a00f38:	62 00 00 
    753650a00f3b:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00f40:	4c 89 f7             	mov    rdi,r14
    753650a00f43:	be 0c f0 00 00       	mov    esi,0xf00c
    753650a00f48:	ff d0                	call   rax
    753650a00f4a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00f51:	00 
    753650a00f52:	0f 85 5e 04 00 00    	jne    0x753650a013b6
    753650a00f58:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00f5d:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00f61:	4c 89 ff             	mov    rdi,r15
    753650a00f64:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a00f69:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    753650a00f6e:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00f73:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    753650a00f78:	e9 37 f8 ff e7       	jmp    0x753638a007b4
    753650a00f7d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    753650a00f84:	6a 00 01 00 
    753650a00f88:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a00f8f:	02 00 00 00 
    753650a00f93:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    753650a00f9a:	10 00 00 00 
    753650a00f9e:	48 b9 20 36 9a d4 72 	movabs rcx,0x6272d49a3620
    753650a00fa5:	62 00 00 
    753650a00fa8:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a00fad:	4c 89 f7             	mov    rdi,r14
    753650a00fb0:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a00fb5:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a00fb9:	89 ee                	mov    esi,ebp
    753650a00fbb:	89 c2                	mov    edx,eax
    753650a00fbd:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a00fc2:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    753650a00fc7:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a00fcc:	4d 89 de             	mov    r14,r11
    753650a00fcf:	ff d1                	call   rcx
    753650a00fd1:	4d 89 f3             	mov    r11,r14
    753650a00fd4:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a00fd9:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    753650a00fde:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a00fe3:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a00fe8:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a00fec:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a00ff1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a00ff8:	00 
    753650a00ff9:	0f 84 ea f7 ff e7    	je     0x753638a007e9
    753650a00fff:	eb 7e                	jmp    0x753650a0107f
    753650a01001:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    753650a01008:	6c 00 01 00 
    753650a0100c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01013:	02 00 00 00 
    753650a01017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    753650a0101e:	10 00 00 00 
    753650a01022:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01029:	62 00 00 
    753650a0102c:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a01031:	4c 89 ef             	mov    rdi,r13
    753650a01034:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a01039:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a0103d:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a01042:	45 89 ce             	mov    r14d,r9d
    753650a01045:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a0104a:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    753650a0104f:	ff d0                	call   rax
    753650a01051:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    753650a01056:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a0105b:	45 89 f1             	mov    r9d,r14d
    753650a0105e:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a01063:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a01068:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a0106c:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a01071:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a01078:	00 
    753650a01079:	0f 84 74 f7 ff e7    	je     0x753638a007f3
    753650a0107f:	b8 02 00 00 00       	mov    eax,0x2
    753650a01084:	b9 10 00 00 00       	mov    ecx,0x10
    753650a01089:	e9 08 fd ff ff       	jmp    0x753650a00d96
    753650a0108e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    753650a01095:	74 00 01 00 
    753650a01099:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a010a0:	02 00 00 00 
    753650a010a4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    753650a010ab:	13 00 00 00 
    753650a010af:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a010b6:	62 00 00 
    753650a010b9:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a010be:	4c 89 f7             	mov    rdi,r14
    753650a010c1:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a010c6:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a010ca:	be 10 f0 00 00       	mov    esi,0xf010
    753650a010cf:	ba 01 00 00 00       	mov    edx,0x1
    753650a010d4:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a010d9:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    753650a010de:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a010e3:	4d 89 de             	mov    r14,r11
    753650a010e6:	ff d0                	call   rax
    753650a010e8:	4d 89 f3             	mov    r11,r14
    753650a010eb:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a010f0:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    753650a010f5:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a010fa:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a010ff:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a01103:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a01108:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a0110f:	00 
    753650a01110:	0f 84 fa f6 ff e7    	je     0x753638a00810
    753650a01116:	eb 7e                	jmp    0x753650a01196
    753650a01118:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    753650a0111f:	76 00 01 00 
    753650a01123:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0112a:	02 00 00 00 
    753650a0112e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    753650a01135:	13 00 00 00 
    753650a01139:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01140:	62 00 00 
    753650a01143:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a01148:	4c 89 ef             	mov    rdi,r13
    753650a0114b:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a01150:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a01154:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a01159:	45 89 ce             	mov    r14d,r9d
    753650a0115c:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a01161:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    753650a01166:	ff d0                	call   rax
    753650a01168:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    753650a0116d:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a01172:	45 89 f1             	mov    r9d,r14d
    753650a01175:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a0117a:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a0117f:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a01183:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a01188:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a0118f:	00 
    753650a01190:	0f 84 84 f6 ff e7    	je     0x753638a0081a
    753650a01196:	b8 02 00 00 00       	mov    eax,0x2
    753650a0119b:	b9 13 00 00 00       	mov    ecx,0x13
    753650a011a0:	e9 f1 fb ff ff       	jmp    0x753650a00d96
    753650a011a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    753650a011ac:	78 00 01 00 
    753650a011b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a011b7:	02 00 00 00 
    753650a011bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    753650a011c2:	15 00 00 00 
    753650a011c6:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a011cd:	62 00 00 
    753650a011d0:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a011d5:	4c 89 f7             	mov    rdi,r14
    753650a011d8:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a011dd:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a011e1:	be 14 f0 00 00       	mov    esi,0xf014
    753650a011e6:	31 d2                	xor    edx,edx
    753650a011e8:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a011ed:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    753650a011f2:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a011f7:	4d 89 de             	mov    r14,r11
    753650a011fa:	ff d0                	call   rax
    753650a011fc:	4d 89 f3             	mov    r11,r14
    753650a011ff:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a01204:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    753650a01209:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a0120e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a01213:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a01217:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a0121c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a01223:	00 
    753650a01224:	0f 84 0d f6 ff e7    	je     0x753638a00837
    753650a0122a:	eb 74                	jmp    0x753650a012a0
    753650a0122c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    753650a01233:	7a 00 01 00 
    753650a01237:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0123e:	02 00 00 00 
    753650a01242:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    753650a01249:	15 00 00 00 
    753650a0124d:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a01254:	62 00 00 
    753650a01257:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a0125c:	4c 89 ef             	mov    rdi,r13
    753650a0125f:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a01264:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a01268:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a0126d:	45 89 ce             	mov    r14d,r9d
    753650a01270:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    753650a01275:	ff d0                	call   rax
    753650a01277:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    753650a0127c:	45 89 f1             	mov    r9d,r14d
    753650a0127f:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a01284:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a01289:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a0128d:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a01292:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a01299:	00 
    753650a0129a:	0f 84 a1 f5 ff e7    	je     0x753638a00841
    753650a012a0:	b8 02 00 00 00       	mov    eax,0x2
    753650a012a5:	b9 15 00 00 00       	mov    ecx,0x15
    753650a012aa:	e9 e7 fa ff ff       	jmp    0x753650a00d96
    753650a012af:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    753650a012b4:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a012b9:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753650a012be:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a012c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    753650a012c9:	84 00 01 00 
    753650a012cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    753650a012d4:	08 00 00 00 
    753650a012d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    753650a012df:	1a 00 00 00 
    753650a012e3:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a012ea:	62 00 00 
    753650a012ed:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a012f2:	4c 89 f7             	mov    rdi,r14
    753650a012f5:	89 de                	mov    esi,ebx
    753650a012f7:	ff d0                	call   rax
    753650a012f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a01300:	00 
    753650a01301:	0f 85 be 00 00 00    	jne    0x753650a013c5
    753650a01307:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a0130c:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a01310:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753650a01315:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a0131a:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    753650a0131f:	e9 4b f5 ff e7       	jmp    0x753638a0086f
    753650a01324:	4d 89 c7             	mov    r15,r8
    753650a01327:	48 89 fb             	mov    rbx,rdi
    753650a0132a:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753650a0132e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    753650a01335:	8c 00 01 00 
    753650a01339:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01340:	02 00 00 00 
    753650a01344:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    753650a0134b:	1b 00 00 00 
    753650a0134f:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a01356:	62 00 00 
    753650a01359:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    753650a0135e:	4c 89 f7             	mov    rdi,r14
    753650a01361:	89 ee                	mov    esi,ebp
    753650a01363:	ff d0                	call   rax
    753650a01365:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a0136c:	00 
    753650a0136d:	75 65                	jne    0x753650a013d4
    753650a0136f:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    753650a01374:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    753650a01378:	48 89 df             	mov    rdi,rbx
    753650a0137b:	4d 89 f8             	mov    r8,r15
    753650a0137e:	e9 0a f5 ff e7       	jmp    0x753638a0088d
    753650a01383:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    753650a0138a:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    753650a01391:	48 83 c4 38          	add    rsp,0x38
    753650a01395:	c2 08 00             	ret    0x8
    753650a01398:	b8 02 00 00 00       	mov    eax,0x2
    753650a0139d:	b9 03 00 00 00       	mov    ecx,0x3
    753650a013a2:	e9 ef f9 ff ff       	jmp    0x753650a00d96
    753650a013a7:	b8 02 00 00 00       	mov    eax,0x2
    753650a013ac:	b9 05 00 00 00       	mov    ecx,0x5
    753650a013b1:	e9 e0 f9 ff ff       	jmp    0x753650a00d96
    753650a013b6:	b8 02 00 00 00       	mov    eax,0x2
    753650a013bb:	b9 0c 00 00 00       	mov    ecx,0xc
    753650a013c0:	e9 d1 f9 ff ff       	jmp    0x753650a00d96
    753650a013c5:	b8 08 00 00 00       	mov    eax,0x8
    753650a013ca:	b9 1a 00 00 00       	mov    ecx,0x1a
    753650a013cf:	e9 c2 f9 ff ff       	jmp    0x753650a00d96
    753650a013d4:	b8 02 00 00 00       	mov    eax,0x2
    753650a013d9:	b9 1b 00 00 00       	mov    ecx,0x1b
    753650a013de:	e9 b3 f9 ff ff       	jmp    0x753650a00d96
