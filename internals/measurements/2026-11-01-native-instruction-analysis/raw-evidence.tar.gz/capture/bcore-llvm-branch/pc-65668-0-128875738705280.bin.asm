
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65668-0-128875738705280.bin:     file format binary


Disassembly of section .data:

0000753638a02d80 <.data>:
    753638a02d80:	48 83 ec 18          	sub    rsp,0x18
    753638a02d84:	b8 71 ff fe ff       	mov    eax,0xfffeff71
    753638a02d89:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    753638a02d90:	01 c1                	add    ecx,eax
    753638a02d92:	83 f9 f4             	cmp    ecx,0xfffffff4
    753638a02d95:	0f 87 bd 12 00 18    	ja     0x753650a04058
    753638a02d9b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    753638a02da2:	83 f8 f4             	cmp    eax,0xfffffff4
    753638a02da5:	0f 87 ad 12 00 18    	ja     0x753650a04058
    753638a02dab:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    753638a02db2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    753638a02db6:	8d 4b fc             	lea    ecx,[rbx-0x4]
    753638a02db9:	f6 c3 03             	test   bl,0x3
    753638a02dbc:	0f 85 a5 12 00 18    	jne    0x753650a04067
    753638a02dc2:	4d 8b bd 38 01 00 00 	mov    r15,QWORD PTR [r13+0x138]
    753638a02dc9:	41 8b 6d 10          	mov    ebp,DWORD PTR [r13+0x10]
    753638a02dcd:	89 c8                	mov    eax,ecx
    753638a02dcf:	c1 e8 0c             	shr    eax,0xc
    753638a02dd2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a02dd6:	48 85 c0             	test   rax,rax
    753638a02dd9:	0f 84 2b 13 00 18    	je     0x753650a0410a
    753638a02ddf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a02de5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753638a02de8:	41 89 6d 00          	mov    DWORD PTR [r13+0x0],ebp
    753638a02dec:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    753638a02df0:	41 8b ad a0 00 00 00 	mov    ebp,DWORD PTR [r13+0xa0]
    753638a02df7:	45 8b a5 a4 00 00 00 	mov    r12d,DWORD PTR [r13+0xa4]
    753638a02dfe:	83 c3 f8             	add    ebx,0xfffffff8
    753638a02e01:	89 d8                	mov    eax,ebx
    753638a02e03:	c1 e8 0c             	shr    eax,0xc
    753638a02e06:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a02e0a:	48 85 c0             	test   rax,rax
    753638a02e0d:	0f 84 45 13 00 18    	je     0x753650a04158
    753638a02e13:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    753638a02e19:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    753638a02e1c:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    753638a02e20:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    753638a02e27:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a02e2e:	02 
    753638a02e2f:	b8 92 00 01 00       	mov    eax,0x10092
    753638a02e34:	ba 92 00 01 00       	mov    edx,0x10092
    753638a02e39:	72 07                	jb     0x753638a02e42
    753638a02e3b:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    753638a02e42:	81 fd 8e 00 01 00    	cmp    ebp,0x1008e
    753638a02e48:	0f 44 c2             	cmove  eax,edx
    753638a02e4b:	89 c2                	mov    edx,eax
    753638a02e4d:	83 f9 02             	cmp    ecx,0x2
    753638a02e50:	72 07                	jb     0x753638a02e59
    753638a02e52:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a02e59:	41 81 fc 8e 00 01 00 	cmp    r12d,0x1008e
    753638a02e60:	0f 44 c2             	cmove  eax,edx
    753638a02e63:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a02e6a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a02e71:	28 03 01 00 
    753638a02e75:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a02e7c:	83 c0 03             	add    eax,0x3
    753638a02e7f:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a02e86:	39 c8                	cmp    eax,ecx
    753638a02e88:	73 2b                	jae    0x753638a02eb5
    753638a02e8a:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    753638a02e91:	03 01 00 
    753638a02e94:	75 1f                	jne    0x753638a02eb5
    753638a02e96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a02e9d:	28 03 01 00 
    753638a02ea1:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a02ea8:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    753638a02eaf:	48 83 c4 18          	add    rsp,0x18
    753638a02eb3:	ff e0                	jmp    rax
    753638a02eb5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753638a02ebc:	28 03 01 00 
    753638a02ec0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753638a02ec7:	04 00 00 00 
    753638a02ecb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753638a02ed2:	03 00 00 00 
    753638a02ed6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a02edd:	01 
    753638a02ede:	48 83 c4 18          	add    rsp,0x18
    753638a02ee2:	c2 08 00             	ret    0x8
