
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65916-0-128875738700592.bin:     file format binary


Disassembly of section .data:

0000753638a01b30 <.data>:
    753638a01b30:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    753638a01b37:	8d 8a 77 fe fe ff    	lea    ecx,[rdx-0x10189]
    753638a01b3d:	b8 65 01 00 00       	mov    eax,0x165
    753638a01b42:	83 f9 f2             	cmp    ecx,0xfffffff2
    753638a01b45:	0f 87 a7 01 00 00    	ja     0x753638a01cf2
    753638a01b4b:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    753638a01b52:	8d b1 77 fe fe ff    	lea    esi,[rcx-0x10189]
    753638a01b58:	83 fe f2             	cmp    esi,0xfffffff2
    753638a01b5b:	0f 87 91 01 00 00    	ja     0x753638a01cf2
    753638a01b61:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753638a01b68:	41 8b 7d 10          	mov    edi,DWORD PTR [r13+0x10]
    753638a01b6c:	41 8b 6d 34          	mov    ebp,DWORD PTR [r13+0x34]
    753638a01b70:	41 0f af 7d 1c       	imul   edi,DWORD PTR [r13+0x1c]
    753638a01b75:	41 89 6d 04          	mov    DWORD PTR [r13+0x4],ebp
    753638a01b79:	8d 34 2f             	lea    esi,[rdi+rbp*1]
    753638a01b7c:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    753638a01b80:	c1 ef 1f             	shr    edi,0x1f
    753638a01b83:	c1 ed 1f             	shr    ebp,0x1f
    753638a01b86:	89 f3                	mov    ebx,esi
    753638a01b88:	c1 eb 1f             	shr    ebx,0x1f
    753638a01b8b:	31 dd                	xor    ebp,ebx
    753638a01b8d:	31 df                	xor    edi,ebx
    753638a01b8f:	21 ef                	and    edi,ebp
    753638a01b91:	41 09 bd 00 01 00 00 	or     DWORD PTR [r13+0x100],edi
    753638a01b98:	31 ed                	xor    ebp,ebp
    753638a01b9a:	85 f6                	test   esi,esi
    753638a01b9c:	40 0f 94 c5          	sete   bpl
    753638a01ba0:	41 89 bd f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edi
    753638a01ba7:	41 89 bd fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edi
    753638a01bae:	41 89 9d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ebx
    753638a01bb5:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    753638a01bbc:	41 89 9d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebx
    753638a01bc3:	48 bf 01 00 00 00 01 	movabs rdi,0x100000001
    753638a01bca:	00 00 00 
    753638a01bcd:	49 89 bd ec 00 00 00 	mov    QWORD PTR [r13+0xec],rdi
    753638a01bd4:	78 4f                	js     0x753638a01c25
    753638a01bd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753638a01bdd:	70 01 01 00 
    753638a01be1:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a01be8:	83 c1 05             	add    ecx,0x5
    753638a01beb:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a01bf2:	39 d1                	cmp    ecx,edx
    753638a01bf4:	0f 83 72 10 00 18    	jae    0x753650a02c6c
    753638a01bfa:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    753638a01c01:	01 01 00 
    753638a01c04:	0f 85 62 10 00 18    	jne    0x753650a02c6c
    753638a01c0a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753638a01c11:	70 01 01 00 
    753638a01c15:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a01c1c:	48 8b 80 88 0b 08 00 	mov    rax,QWORD PTR [rax+0x80b88]
    753638a01c23:	ff e0                	jmp    rax
    753638a01c25:	31 ff                	xor    edi,edi
    753638a01c27:	41 33 75 00          	xor    esi,DWORD PTR [r13+0x0]
    753638a01c2b:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    753638a01c2f:	40 0f 94 c7          	sete   dil
    753638a01c33:	c1 ee 1f             	shr    esi,0x1f
    753638a01c36:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    753638a01c3d:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    753638a01c44:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    753638a01c4b:	00 00 00 00 
    753638a01c4f:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a01c56:	00 00 00 00 
    753638a01c5a:	41 8b bd 9c 00 00 00 	mov    edi,DWORD PTR [r13+0x9c]
    753638a01c61:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a01c68:	02 
    753638a01c69:	be 8c 01 01 00       	mov    esi,0x1018c
    753638a01c6e:	bb 8c 01 01 00       	mov    ebx,0x1018c
    753638a01c73:	72 07                	jb     0x753638a01c7c
    753638a01c75:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    753638a01c7c:	81 fa 88 01 01 00    	cmp    edx,0x10188
    753638a01c82:	0f 44 f3             	cmove  esi,ebx
    753638a01c85:	89 f2                	mov    edx,esi
    753638a01c87:	83 ff 02             	cmp    edi,0x2
    753638a01c8a:	72 07                	jb     0x753638a01c93
    753638a01c8c:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a01c93:	81 f9 88 01 01 00    	cmp    ecx,0x10188
    753638a01c99:	0f 44 f2             	cmove  esi,edx
    753638a01c9c:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    753638a01ca3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753638a01caa:	10 01 01 00 
    753638a01cae:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a01cb5:	83 c1 07             	add    ecx,0x7
    753638a01cb8:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a01cbf:	39 d1                	cmp    ecx,edx
    753638a01cc1:	0f 83 d2 0f 00 18    	jae    0x753650a02c99
    753638a01cc7:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    753638a01cce:	01 01 00 
    753638a01cd1:	0f 85 c2 0f 00 18    	jne    0x753650a02c99
    753638a01cd7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753638a01cde:	10 01 01 00 
    753638a01ce2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a01ce9:	48 8b 80 88 08 08 00 	mov    rax,QWORD PTR [rax+0x80888]
    753638a01cf0:	ff e0                	jmp    rax
    753638a01cf2:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    753638a01cf8:	c2 08 00             	ret    0x8
