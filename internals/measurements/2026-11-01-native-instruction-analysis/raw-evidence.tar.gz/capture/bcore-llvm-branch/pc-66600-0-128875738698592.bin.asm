
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66600-0-128875738698592.bin:     file format binary


Disassembly of section .data:

0000753638a01360 <.data>:
    753638a01360:	48 83 ec 28          	sub    rsp,0x28
    753638a01364:	ba bf fb fe ff       	mov    edx,0xfffefbbf
    753638a01369:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a01370:	01 d6                	add    esi,edx
    753638a01372:	b1 01                	mov    cl,0x1
    753638a01374:	b8 65 01 00 00       	mov    eax,0x165
    753638a01379:	83 fe e6             	cmp    esi,0xffffffe6
    753638a0137c:	0f 87 df 01 00 00    	ja     0x753638a01561
    753638a01382:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a01389:	83 fa e6             	cmp    edx,0xffffffe6
    753638a0138c:	0f 87 cf 01 00 00    	ja     0x753638a01561
    753638a01392:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    753638a01399:	49 8b 9d 38 01 00 00 	mov    rbx,QWORD PTR [r13+0x138]
    753638a013a0:	4d 8b 8d 40 01 00 00 	mov    r9,QWORD PTR [r13+0x140]
    753638a013a7:	66 41 c7 45 2a 01 00 	mov    WORD PTR [r13+0x2a],0x1
    753638a013ae:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    753638a013b2:	44 8d 46 fc          	lea    r8d,[rsi-0x4]
    753638a013b6:	40 f6 c6 03          	test   sil,0x3
    753638a013ba:	0f 85 9e 0d 00 18    	jne    0x753650a0215e
    753638a013c0:	45 8b 55 3c          	mov    r10d,DWORD PTR [r13+0x3c]
    753638a013c4:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a013cb:	45 89 c7             	mov    r15d,r8d
    753638a013ce:	41 c1 ef 0c          	shr    r15d,0xc
    753638a013d2:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    753638a013d6:	48 85 c0             	test   rax,rax
    753638a013d9:	0f 84 e4 0d 00 18    	je     0x753650a021c3
    753638a013df:	44 89 c1             	mov    ecx,r8d
    753638a013e2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a013e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a013eb:	8d 6e f8             	lea    ebp,[rsi-0x8]
    753638a013ee:	41 89 ec             	mov    r12d,ebp
    753638a013f1:	41 c1 ec 0c          	shr    r12d,0xc
    753638a013f5:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    753638a013f9:	48 85 c0             	test   rax,rax
    753638a013fc:	0f 84 33 0e 00 18    	je     0x753650a02235
    753638a01402:	89 e9                	mov    ecx,ebp
    753638a01404:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a0140a:	44 89 14 08          	mov    DWORD PTR [rax+rcx*1],r10d
    753638a0140e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a01412:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    753638a01416:	41 80 39 00          	cmp    BYTE PTR [r9],0x0
    753638a0141a:	0f 85 8a 0e 00 18    	jne    0x753650a022aa
    753638a01420:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    753638a01427:	00 
    753638a01428:	48 8b 83 88 00 00 00 	mov    rax,QWORD PTR [rbx+0x88]
    753638a0142f:	48 85 c0             	test   rax,rax
    753638a01432:	0f 84 e2 0e 00 18    	je     0x753650a0231a
    753638a01438:	8b 80 f0 02 00 00    	mov    eax,DWORD PTR [rax+0x2f0]
    753638a0143e:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    753638a01442:	31 c9                	xor    ecx,ecx
    753638a01444:	83 f8 05             	cmp    eax,0x5
    753638a01447:	0f 92 c1             	setb   cl
    753638a0144a:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    753638a01451:	73 53                	jae    0x753638a014a6
    753638a01453:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    753638a0145a:	42 04 01 00 
    753638a0145e:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a01465:	83 c0 06             	add    eax,0x6
    753638a01468:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a0146f:	39 c8                	cmp    eax,ecx
    753638a01471:	0f 83 15 0f 00 18    	jae    0x753650a0238c
    753638a01477:	81 bf 10 22 08 00 42 	cmp    DWORD PTR [rdi+0x82210],0x10442
    753638a0147e:	04 01 00 
    753638a01481:	0f 85 05 0f 00 18    	jne    0x753650a0238c
    753638a01487:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    753638a0148e:	42 04 01 00 
    753638a01492:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01499:	48 8b 87 18 22 08 00 	mov    rax,QWORD PTR [rdi+0x82218]
    753638a014a0:	48 83 c4 28          	add    rsp,0x28
    753638a014a4:	ff e0                	jmp    rax
    753638a014a6:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    753638a014ad:	00 
    753638a014ae:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    753638a014b2:	48 85 c0             	test   rax,rax
    753638a014b5:	0f 84 ed 0e 00 18    	je     0x753650a023a8
    753638a014bb:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    753638a014c1:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    753638a014c4:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    753638a014c8:	48 85 c0             	test   rax,rax
    753638a014cb:	0f 84 44 0f 00 18    	je     0x753650a02415
    753638a014d1:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
    753638a014d8:	42 8b 04 00          	mov    eax,DWORD PTR [rax+r8*1]
    753638a014dc:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a014e0:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a014e7:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a014eb:	b1 01                	mov    cl,0x1
    753638a014ed:	bb 02 00 00 00       	mov    ebx,0x2
    753638a014f2:	bd 09 00 00 00       	mov    ebp,0x9
    753638a014f7:	a8 01                	test   al,0x1
    753638a014f9:	0f 85 70 0f 00 18    	jne    0x753650a0246f
    753638a014ff:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753638a01506:	01 ea                	add    edx,ebp
    753638a01508:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    753638a0150f:	39 f2                	cmp    edx,esi
    753638a01511:	0f 83 3b 0c 00 18    	jae    0x753650a02152
    753638a01517:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    753638a0151e:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    753638a01524:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    753638a01527:	0f 85 25 0c 00 18    	jne    0x753650a02152
    753638a0152d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a01534:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753638a0153b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a01542:	00 
    753638a01543:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    753638a01548:	48 83 c4 28          	add    rsp,0x28
    753638a0154c:	ff e0                	jmp    rax
    753638a0154e:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a01555:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a0155c:	b8 28 01 00 00       	mov    eax,0x128
    753638a01561:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a01566:	48 83 c4 28          	add    rsp,0x28
    753638a0156a:	c2 08 00             	ret    0x8
