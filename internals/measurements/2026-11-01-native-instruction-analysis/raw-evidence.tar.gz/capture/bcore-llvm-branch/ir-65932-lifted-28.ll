; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001018c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 65932
  %5 = icmp ugt i32 %4, 14
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb106 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb106, 0
  %10 = sub i32 %guard_lb106, 65932
  %11 = icmp ugt i32 %10, 14
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x0001018c_entry, label %lb_guard_miss, !prof !0

insn_0x0001018c_entry:                            ; preds = %lb_guard
  br label %insn_0x0001018c

insn_0x0001018c:                                  ; preds = %insn_0x0001018c_entry
  %14 = getelementptr i8, ptr %cpu, i32 24
  %rd = load i32, ptr %14, align 4
  %rd_add = add i32 %rd, 1
  %15 = getelementptr i8, ptr %cpu, i32 24
  store i32 %rd_add, ptr %15, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %16 = xor i32 0, %flgn
  %17 = xor i32 %flgs, %flgn
  %overflow = and i32 %17, %16
  %18 = xor i32 %rd, -1
  %19 = icmp ult i32 %18, 1
  %ac0 = zext i1 %19 to i32
  %20 = icmp eq i32 %rd_add, 0
  %az = zext i1 %20 to i32
  %an = lshr i32 %rd_add, 31
  %21 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %23, align 4
  %24 = or i32 %vs_cur, %overflow
  %25 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i32 256
  store i32 %24, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %31, align 4
  br label %insn_0x0001018e_entry

insn_0x0001018e_entry:                            ; preds = %insn_0x0001018c
  br label %insn_0x0001018e

insn_0x0001018e:                                  ; preds = %insn_0x0001018e_entry
  %32 = getelementptr i8, ptr %cpu, i32 20
  %rx = load i32, ptr %32, align 4
  %33 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %33 to i32
  %34 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %34, align 4
  %35 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %35 to i32
  %36 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %36 to i32
  %37 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %37 to i32
  %38 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac03, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac03, ptr %41, align 4
  br label %insn_0x00010190_entry

insn_0x00010190_entry:                            ; preds = %insn_0x0001018e
  br label %insn_0x00010190

insn_0x00010190:                                  ; preds = %insn_0x00010190_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010190
  %42 = getelementptr i8, ptr %cpu, i32 188
  store i32 65916, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %43, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %44 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %44 monotonic, align 4, !range !1
  %45 = icmp ult i32 %chain_total, %chain_budget
  br i1 %45, label %chain_go, label %chain_leave107, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010190
  br label %insn_0x00010192_entry

insn_0x00010192_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010192

insn_0x00010192:                                  ; preds = %insn_0x00010192_entry
  %46 = getelementptr i8, ptr %cpu, i32 28
  %rs = load i32, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %47, align 4
  %xor32 = xor i32 %rt, %rs
  %48 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %48, align 4
  %49 = icmp eq i32 %xor32, 0
  %az4 = zext i1 %49 to i32
  %an5 = lshr i32 %xor32, 31
  %50 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az4, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an5, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %55, align 4
  br label %insn_0x00010194_entry

insn_0x00010194_entry:                            ; preds = %insn_0x00010192
  br label %insn_0x00010194

insn_0x00010194:                                  ; preds = %insn_0x00010194_entry
  %56 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %56, align 4
  %57 = and i32 %fp, 3
  %58 = icmp ne i32 %57, 0
  br i1 %58, label %data_misaligned, label %data_aligned, !prof !2

data_misaligned:                                  ; preds = %insn_0x00010194
  %59 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %61, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65940, i32 %fp, i32 0)
  %62 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i64 188
  %64 = load i32, ptr %63, align 4
  %65 = getelementptr i8, ptr %cpu, i64 296
  %66 = load i8, ptr %65, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010194
  %67 = lshr i32 %fp, 12
  %page_index = zext i32 %67 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %68 = and i32 %fp, 4095
  %page_offset = zext i32 %68 to i64
  %69 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %69, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %70 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %72, align 4
  %73 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %74 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %74, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !2

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %73, %did_jump_cont ]
  %sp1 = add i32 %fp, 4
  %75 = and i32 %sp1, 3
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %data_misaligned6, label %data_aligned7, !prof !2

did_jump_exit:                                    ; preds = %page_slow
  %77 = getelementptr i8, ptr %cpu, i64 188
  %next_pc108 = load i32, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 188
  %79 = load i32, ptr %78, align 4
  %80 = getelementptr i8, ptr %cpu, i64 296
  %81 = load i8, ptr %80, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

data_misaligned6:                                 ; preds = %page_done
  %82 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %84, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65940, i32 %sp1, i32 0)
  %85 = getelementptr i8, ptr %cpu, i64 188
  %next_pc109 = load i32, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i64 188
  %87 = load i32, ptr %86, align 4
  %88 = getelementptr i8, ptr %cpu, i64 296
  %89 = load i8, ptr %88, align 1
  br label %chain_exit

data_aligned7:                                    ; preds = %page_done
  %90 = lshr i32 %sp1, 12
  %page_index11 = zext i32 %90 to i64
  %page_slot12 = getelementptr ptr, ptr %page_table, i64 %page_index11
  %page13 = load ptr, ptr %page_slot12, align 8
  %page_mapped14 = icmp ne ptr %page13, null
  br i1 %page_mapped14, label %page_fast8, label %page_slow9, !prof !0

page_fast8:                                       ; preds = %data_aligned7
  %91 = and i32 %sp1, 4095
  %page_offset15 = zext i32 %91 to i64
  %92 = getelementptr i8, ptr %page13, i64 %page_offset15
  %page_val16 = load i32, ptr %92, align 4
  br label %page_done10

page_slow9:                                       ; preds = %data_aligned7
  %93 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %95, align 4
  %96 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %97 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %97, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !2

page_done10:                                      ; preds = %did_jump_cont18, %page_fast8
  %mem_val21 = phi i32 [ %page_val16, %page_fast8 ], [ %96, %did_jump_cont18 ]
  %sp2 = add i32 %sp1, 4
  %98 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val21, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %100, align 4
  br label %insn_0x00010198_entry

did_jump_exit17:                                  ; preds = %page_slow9
  %101 = getelementptr i8, ptr %cpu, i64 188
  %next_pc110 = load i32, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i64 188
  %103 = load i32, ptr %102, align 4
  %104 = getelementptr i8, ptr %cpu, i64 296
  %105 = load i8, ptr %104, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %page_slow9
  br label %page_done10

insn_0x00010198_entry:                            ; preds = %page_done10
  br label %insn_0x00010198

insn_0x00010198:                                  ; preds = %insn_0x00010198_entry
  %106 = and i32 %sp2, 3
  %107 = icmp ne i32 %106, 0
  br i1 %107, label %data_misaligned22, label %data_aligned23, !prof !2

data_misaligned22:                                ; preds = %insn_0x00010198
  %108 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %110, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp2, i32 0)
  %111 = getelementptr i8, ptr %cpu, i64 188
  %next_pc111 = load i32, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i64 188
  %113 = load i32, ptr %112, align 4
  %114 = getelementptr i8, ptr %cpu, i64 296
  %115 = load i8, ptr %114, align 1
  br label %chain_exit

data_aligned23:                                   ; preds = %insn_0x00010198
  %116 = lshr i32 %sp2, 12
  %page_index27 = zext i32 %116 to i64
  %page_slot28 = getelementptr ptr, ptr %page_table, i64 %page_index27
  %page29 = load ptr, ptr %page_slot28, align 8
  %page_mapped30 = icmp ne ptr %page29, null
  br i1 %page_mapped30, label %page_fast24, label %page_slow25, !prof !0

page_fast24:                                      ; preds = %data_aligned23
  %117 = and i32 %sp2, 4095
  %page_offset31 = zext i32 %117 to i64
  %118 = getelementptr i8, ptr %page29, i64 %page_offset31
  %page_val32 = load i32, ptr %118, align 4
  br label %page_done26

page_slow25:                                      ; preds = %data_aligned23
  %119 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %121, align 4
  %122 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %123 = getelementptr i8, ptr %cpu, i32 296
  %dj35 = load i8, ptr %123, align 1
  %dj_set36 = icmp ne i8 %dj35, 0
  br i1 %dj_set36, label %did_jump_exit33, label %did_jump_cont34, !prof !2

page_done26:                                      ; preds = %did_jump_cont34, %page_fast24
  %mem_val37 = phi i32 [ %page_val32, %page_fast24 ], [ %122, %did_jump_cont34 ]
  %124 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val37, ptr %124, align 4
  %sp_inc = add i32 %sp2, 4
  %125 = and i32 %sp_inc, 3
  %126 = icmp ne i32 %125, 0
  br i1 %126, label %data_misaligned38, label %data_aligned39, !prof !2

did_jump_exit33:                                  ; preds = %page_slow25
  %127 = getelementptr i8, ptr %cpu, i64 188
  %next_pc112 = load i32, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 188
  %129 = load i32, ptr %128, align 4
  %130 = getelementptr i8, ptr %cpu, i64 296
  %131 = load i8, ptr %130, align 1
  br label %chain_exit

did_jump_cont34:                                  ; preds = %page_slow25
  br label %page_done26

data_misaligned38:                                ; preds = %page_done26
  %132 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %133, align 4
  %134 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %134, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc, i32 0)
  %135 = getelementptr i8, ptr %cpu, i64 188
  %next_pc113 = load i32, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i64 188
  %137 = load i32, ptr %136, align 4
  %138 = getelementptr i8, ptr %cpu, i64 296
  %139 = load i8, ptr %138, align 1
  br label %chain_exit

data_aligned39:                                   ; preds = %page_done26
  %140 = lshr i32 %sp_inc, 12
  %page_index43 = zext i32 %140 to i64
  %page_slot44 = getelementptr ptr, ptr %page_table, i64 %page_index43
  %page45 = load ptr, ptr %page_slot44, align 8
  %page_mapped46 = icmp ne ptr %page45, null
  br i1 %page_mapped46, label %page_fast40, label %page_slow41, !prof !0

page_fast40:                                      ; preds = %data_aligned39
  %141 = and i32 %sp_inc, 4095
  %page_offset47 = zext i32 %141 to i64
  %142 = getelementptr i8, ptr %page45, i64 %page_offset47
  %page_val48 = load i32, ptr %142, align 4
  br label %page_done42

page_slow41:                                      ; preds = %data_aligned39
  %143 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %144, align 4
  %145 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %145, align 4
  %146 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %147 = getelementptr i8, ptr %cpu, i32 296
  %dj51 = load i8, ptr %147, align 1
  %dj_set52 = icmp ne i8 %dj51, 0
  br i1 %dj_set52, label %did_jump_exit49, label %did_jump_cont50, !prof !2

page_done42:                                      ; preds = %did_jump_cont50, %page_fast40
  %mem_val53 = phi i32 [ %page_val48, %page_fast40 ], [ %146, %did_jump_cont50 ]
  %148 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val53, ptr %148, align 4
  %sp_inc54 = add i32 %sp_inc, 4
  %149 = and i32 %sp_inc54, 3
  %150 = icmp ne i32 %149, 0
  br i1 %150, label %data_misaligned55, label %data_aligned56, !prof !2

did_jump_exit49:                                  ; preds = %page_slow41
  %151 = getelementptr i8, ptr %cpu, i64 188
  %next_pc114 = load i32, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i64 188
  %153 = load i32, ptr %152, align 4
  %154 = getelementptr i8, ptr %cpu, i64 296
  %155 = load i8, ptr %154, align 1
  br label %chain_exit

did_jump_cont50:                                  ; preds = %page_slow41
  br label %page_done42

data_misaligned55:                                ; preds = %page_done42
  %156 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %157, align 4
  %158 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %158, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc54, i32 0)
  %159 = getelementptr i8, ptr %cpu, i64 188
  %next_pc115 = load i32, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i64 188
  %161 = load i32, ptr %160, align 4
  %162 = getelementptr i8, ptr %cpu, i64 296
  %163 = load i8, ptr %162, align 1
  br label %chain_exit

data_aligned56:                                   ; preds = %page_done42
  %164 = lshr i32 %sp_inc54, 12
  %page_index60 = zext i32 %164 to i64
  %page_slot61 = getelementptr ptr, ptr %page_table, i64 %page_index60
  %page62 = load ptr, ptr %page_slot61, align 8
  %page_mapped63 = icmp ne ptr %page62, null
  br i1 %page_mapped63, label %page_fast57, label %page_slow58, !prof !0

page_fast57:                                      ; preds = %data_aligned56
  %165 = and i32 %sp_inc54, 4095
  %page_offset64 = zext i32 %165 to i64
  %166 = getelementptr i8, ptr %page62, i64 %page_offset64
  %page_val65 = load i32, ptr %166, align 4
  br label %page_done59

page_slow58:                                      ; preds = %data_aligned56
  %167 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %169, align 4
  %170 = call i32 @mem_read32(ptr %mem, i32 %sp_inc54)
  %171 = getelementptr i8, ptr %cpu, i32 296
  %dj68 = load i8, ptr %171, align 1
  %dj_set69 = icmp ne i8 %dj68, 0
  br i1 %dj_set69, label %did_jump_exit66, label %did_jump_cont67, !prof !2

page_done59:                                      ; preds = %did_jump_cont67, %page_fast57
  %mem_val70 = phi i32 [ %page_val65, %page_fast57 ], [ %170, %did_jump_cont67 ]
  %172 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val70, ptr %172, align 4
  %sp_inc71 = add i32 %sp_inc54, 4
  %173 = and i32 %sp_inc71, 3
  %174 = icmp ne i32 %173, 0
  br i1 %174, label %data_misaligned72, label %data_aligned73, !prof !2

did_jump_exit66:                                  ; preds = %page_slow58
  %175 = getelementptr i8, ptr %cpu, i64 188
  %next_pc116 = load i32, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i64 188
  %177 = load i32, ptr %176, align 4
  %178 = getelementptr i8, ptr %cpu, i64 296
  %179 = load i8, ptr %178, align 1
  br label %chain_exit

did_jump_cont67:                                  ; preds = %page_slow58
  br label %page_done59

data_misaligned72:                                ; preds = %page_done59
  %180 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %180, align 4
  %181 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %181, align 4
  %182 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %182, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc71, i32 0)
  %183 = getelementptr i8, ptr %cpu, i64 188
  %next_pc117 = load i32, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 188
  %185 = load i32, ptr %184, align 4
  %186 = getelementptr i8, ptr %cpu, i64 296
  %187 = load i8, ptr %186, align 1
  br label %chain_exit

data_aligned73:                                   ; preds = %page_done59
  %188 = lshr i32 %sp_inc71, 12
  %page_index77 = zext i32 %188 to i64
  %page_slot78 = getelementptr ptr, ptr %page_table, i64 %page_index77
  %page79 = load ptr, ptr %page_slot78, align 8
  %page_mapped80 = icmp ne ptr %page79, null
  br i1 %page_mapped80, label %page_fast74, label %page_slow75, !prof !0

page_fast74:                                      ; preds = %data_aligned73
  %189 = and i32 %sp_inc71, 4095
  %page_offset81 = zext i32 %189 to i64
  %190 = getelementptr i8, ptr %page79, i64 %page_offset81
  %page_val82 = load i32, ptr %190, align 4
  br label %page_done76

page_slow75:                                      ; preds = %data_aligned73
  %191 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %191, align 4
  %192 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %193, align 4
  %194 = call i32 @mem_read32(ptr %mem, i32 %sp_inc71)
  %195 = getelementptr i8, ptr %cpu, i32 296
  %dj85 = load i8, ptr %195, align 1
  %dj_set86 = icmp ne i8 %dj85, 0
  br i1 %dj_set86, label %did_jump_exit83, label %did_jump_cont84, !prof !2

page_done76:                                      ; preds = %did_jump_cont84, %page_fast74
  %mem_val87 = phi i32 [ %page_val82, %page_fast74 ], [ %194, %did_jump_cont84 ]
  %196 = getelementptr i8, ptr %cpu, i32 20
  store i32 %mem_val87, ptr %196, align 4
  %sp_inc88 = add i32 %sp_inc71, 4
  %197 = and i32 %sp_inc88, 3
  %198 = icmp ne i32 %197, 0
  br i1 %198, label %data_misaligned89, label %data_aligned90, !prof !2

did_jump_exit83:                                  ; preds = %page_slow75
  %199 = getelementptr i8, ptr %cpu, i64 188
  %next_pc118 = load i32, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i64 188
  %201 = load i32, ptr %200, align 4
  %202 = getelementptr i8, ptr %cpu, i64 296
  %203 = load i8, ptr %202, align 1
  br label %chain_exit

did_jump_cont84:                                  ; preds = %page_slow75
  br label %page_done76

data_misaligned89:                                ; preds = %page_done76
  %204 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %206, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc88, i32 0)
  %207 = getelementptr i8, ptr %cpu, i64 188
  %next_pc119 = load i32, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i64 188
  %209 = load i32, ptr %208, align 4
  %210 = getelementptr i8, ptr %cpu, i64 296
  %211 = load i8, ptr %210, align 1
  br label %chain_exit

data_aligned90:                                   ; preds = %page_done76
  %212 = lshr i32 %sp_inc88, 12
  %page_index94 = zext i32 %212 to i64
  %page_slot95 = getelementptr ptr, ptr %page_table, i64 %page_index94
  %page96 = load ptr, ptr %page_slot95, align 8
  %page_mapped97 = icmp ne ptr %page96, null
  br i1 %page_mapped97, label %page_fast91, label %page_slow92, !prof !0

page_fast91:                                      ; preds = %data_aligned90
  %213 = and i32 %sp_inc88, 4095
  %page_offset98 = zext i32 %213 to i64
  %214 = getelementptr i8, ptr %page96, i64 %page_offset98
  %page_val99 = load i32, ptr %214, align 4
  br label %page_done93

page_slow92:                                      ; preds = %data_aligned90
  %215 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %216, align 4
  %217 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %217, align 4
  %218 = call i32 @mem_read32(ptr %mem, i32 %sp_inc88)
  %219 = getelementptr i8, ptr %cpu, i32 296
  %dj102 = load i8, ptr %219, align 1
  %dj_set103 = icmp ne i8 %dj102, 0
  br i1 %dj_set103, label %did_jump_exit100, label %did_jump_cont101, !prof !2

page_done93:                                      ; preds = %did_jump_cont101, %page_fast91
  %mem_val104 = phi i32 [ %page_val99, %page_fast91 ], [ %218, %did_jump_cont101 ]
  %220 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val104, ptr %220, align 4
  %sp_inc105 = add i32 %sp_inc88, 4
  %221 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc105, ptr %221, align 4
  br label %insn_0x0001019a_entry

did_jump_exit100:                                 ; preds = %page_slow92
  %222 = getelementptr i8, ptr %cpu, i64 188
  %next_pc120 = load i32, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 188
  %224 = load i32, ptr %223, align 4
  %225 = getelementptr i8, ptr %cpu, i64 296
  %226 = load i8, ptr %225, align 1
  br label %chain_exit

did_jump_cont101:                                 ; preds = %page_slow92
  br label %page_done93

insn_0x0001019a_entry:                            ; preds = %page_done93
  br label %insn_0x0001019a

insn_0x0001019a:                                  ; preds = %insn_0x0001019a_entry
  %lsb = and i32 %mem_val21, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !2

jump_aligned:                                     ; preds = %insn_0x0001019a
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001019a
  %227 = getelementptr i8, ptr %cpu, i32 188
  store i32 65946, ptr %227, align 4
  %228 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %228, align 4
  %229 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %229, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %230 = getelementptr i8, ptr %cpu, i64 188
  %next_pc121 = load i32, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i64 188
  %232 = load i32, ptr %231, align 4
  %233 = getelementptr i8, ptr %cpu, i64 296
  %234 = load i8, ptr %233, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %235 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %235, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527328
  %236 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %236, align 4
  %237 = icmp eq i32 %slot_pc, 65916
  br i1 %237, label %chain_hit, label %chain_leave107, !prof !0

chain_leave107:                                   ; preds = %chain_go, %brcc_taken
  %238 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %238, align 4
  %239 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %240, align 4
  %241 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %241, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %242 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %243, align 4
  %244 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %244, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit100, %data_misaligned89, %did_jump_exit83, %data_misaligned72, %did_jump_exit66, %data_misaligned55, %did_jump_exit49, %data_misaligned38, %did_jump_exit33, %data_misaligned22, %did_jump_exit17, %data_misaligned6, %did_jump_exit, %data_misaligned
  %next_pc122 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc108, %did_jump_exit ], [ %next_pc109, %data_misaligned6 ], [ %next_pc110, %did_jump_exit17 ], [ %next_pc111, %data_misaligned22 ], [ %next_pc112, %did_jump_exit33 ], [ %next_pc113, %data_misaligned38 ], [ %next_pc114, %did_jump_exit49 ], [ %next_pc115, %data_misaligned55 ], [ %next_pc116, %did_jump_exit66 ], [ %next_pc117, %data_misaligned72 ], [ %next_pc118, %did_jump_exit83 ], [ %next_pc119, %data_misaligned89 ], [ %next_pc120, %did_jump_exit100 ], [ %mem_val21, %jump_aligned ], [ %next_pc121, %jump_misalign ]
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned6 ], [ 5, %did_jump_exit17 ], [ 6, %data_misaligned22 ], [ 6, %did_jump_exit33 ], [ 6, %data_misaligned38 ], [ 6, %did_jump_exit49 ], [ 6, %data_misaligned55 ], [ 6, %did_jump_exit66 ], [ 6, %data_misaligned72 ], [ 6, %did_jump_exit83 ], [ 6, %data_misaligned89 ], [ 6, %did_jump_exit100 ], [ 7, %jump_aligned ], [ 7, %jump_misalign ]
  %tail = phi i32 [ %64, %data_misaligned ], [ %79, %did_jump_exit ], [ %87, %data_misaligned6 ], [ %103, %did_jump_exit17 ], [ %113, %data_misaligned22 ], [ %129, %did_jump_exit33 ], [ %137, %data_misaligned38 ], [ %153, %did_jump_exit49 ], [ %161, %data_misaligned55 ], [ %177, %did_jump_exit66 ], [ %185, %data_misaligned72 ], [ %201, %did_jump_exit83 ], [ %209, %data_misaligned89 ], [ %224, %did_jump_exit100 ], [ %mem_val21, %jump_aligned ], [ %232, %jump_misalign ]
  %tail123 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned6 ], [ 4, %did_jump_exit17 ], [ 2, %data_misaligned22 ], [ 2, %did_jump_exit33 ], [ 2, %data_misaligned38 ], [ 2, %did_jump_exit49 ], [ 2, %data_misaligned55 ], [ 2, %did_jump_exit66 ], [ 2, %data_misaligned72 ], [ 2, %did_jump_exit83 ], [ 2, %data_misaligned89 ], [ 2, %did_jump_exit100 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail124 = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned6 ], [ 5, %did_jump_exit17 ], [ 6, %data_misaligned22 ], [ 6, %did_jump_exit33 ], [ 6, %data_misaligned38 ], [ 6, %did_jump_exit49 ], [ 6, %data_misaligned55 ], [ 6, %did_jump_exit66 ], [ 6, %data_misaligned72 ], [ 6, %did_jump_exit83 ], [ 6, %data_misaligned89 ], [ 6, %did_jump_exit100 ], [ 7, %jump_aligned ], [ 7, %jump_misalign ]
  %tail125 = phi i8 [ %66, %data_misaligned ], [ %81, %did_jump_exit ], [ %89, %data_misaligned6 ], [ %105, %did_jump_exit17 ], [ %115, %data_misaligned22 ], [ %131, %did_jump_exit33 ], [ %139, %data_misaligned38 ], [ %155, %did_jump_exit49 ], [ %163, %data_misaligned55 ], [ %179, %did_jump_exit66 ], [ %187, %data_misaligned72 ], [ %203, %did_jump_exit83 ], [ %211, %data_misaligned89 ], [ %226, %did_jump_exit100 ], [ 1, %jump_aligned ], [ %234, %jump_misalign ]
  %245 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets127 = load i32, ptr %245, align 4
  %chain_total128 = add nuw i32 %chain_packets127, %packets
  %246 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget129 = load atomic i32, ptr %246 monotonic, align 4, !range !1
  %247 = icmp ult i32 %chain_total128, %chain_budget129
  br i1 %247, label %chain_lookup, label %chain_leave126, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %248 = lshr i32 %next_pc122, 1
  %249 = and i32 %248, 65535
  %250 = zext i32 %249 to i64
  %251 = mul i64 %250, 16
  %chain_slot130 = getelementptr i8, ptr %chain_table, i64 %251
  %252 = getelementptr i8, ptr %chain_slot130, i64 0
  %slot_pc131 = load i32, ptr %252, align 4
  %253 = icmp eq i32 %slot_pc131, %next_pc122
  br i1 %253, label %chain_hit132, label %chain_leave126, !prof !0

chain_leave126:                                   ; preds = %chain_lookup, %chain_exit
  %254 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %254, align 4
  %255 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail123, ptr %255, align 4
  %256 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail124, ptr %256, align 4
  %257 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail125, ptr %257, align 1
  ret void

chain_hit132:                                     ; preds = %chain_lookup
  %258 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc122, ptr %258, align 4
  %259 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total128, ptr %259, align 4
  %260 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %260, align 1
  %261 = getelementptr i8, ptr %chain_slot130, i64 8
  %chain_fn133 = load ptr, ptr %261, align 8
  musttail call swifttailcc void %chain_fn133(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
!2 = !{!"branch_weights", i32 1, i32 1048576}
