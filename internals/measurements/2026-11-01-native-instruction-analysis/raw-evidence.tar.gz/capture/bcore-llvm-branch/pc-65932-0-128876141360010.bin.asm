
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65932-0-128876141360010.bin:     file format binary


Disassembly of section .data:

0000753650a0338a <.data>:
    753650a0338a:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    753650a03391:	e9 db f4 ff e7       	jmp    0x753638a02871
    753650a03396:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753650a0339d:	7c 01 01 00 
    753650a033a1:	b1 01                	mov    cl,0x1
    753650a033a3:	bd 03 00 00 00       	mov    ebp,0x3
    753650a033a8:	bb 02 00 00 00       	mov    ebx,0x2
    753650a033ad:	e9 bf f4 ff e7       	jmp    0x753638a02871
    753650a033b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    753650a033b9:	94 01 01 00 
    753650a033bd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a033c4:	04 00 00 00 
    753650a033c8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a033cf:	05 00 00 00 
    753650a033d3:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a033da:	62 00 00 
    753650a033dd:	4c 89 ef             	mov    rdi,r13
    753650a033e0:	4c 89 f6             	mov    rsi,r14
    753650a033e3:	ba 94 01 01 00       	mov    edx,0x10194
    753650a033e8:	89 e9                	mov    ecx,ebp
    753650a033ea:	4c 89 c3             	mov    rbx,r8
    753650a033ed:	45 31 c0             	xor    r8d,r8d
    753650a033f0:	ff d0                	call   rax
    753650a033f2:	49 89 d8             	mov    r8,rbx
    753650a033f5:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a033fc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03403:	00 
    753650a03404:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03409:	bd 05 00 00 00       	mov    ebp,0x5
    753650a0340e:	e9 b9 f3 ff e7       	jmp    0x753638a027cc
    753650a03413:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a03418:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    753650a0341f:	94 01 01 00 
    753650a03423:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0342a:	04 00 00 00 
    753650a0342e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a03435:	05 00 00 00 
    753650a03439:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03440:	62 00 00 
    753650a03443:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a03448:	4c 89 f7             	mov    rdi,r14
    753650a0344b:	89 ee                	mov    esi,ebp
    753650a0344d:	ff d0                	call   rax
    753650a0344f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03456:	00 
    753650a03457:	84 c9                	test   cl,cl
    753650a03459:	0f 85 98 02 00 00    	jne    0x753650a036f7
    753650a0345f:	89 c3                	mov    ebx,eax
    753650a03461:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03466:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a0346b:	e9 67 f2 ff e7       	jmp    0x753638a026d7
    753650a03470:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a03475:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    753650a0347c:	94 01 01 00 
    753650a03480:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a03487:	04 00 00 00 
    753650a0348b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a03492:	05 00 00 00 
    753650a03496:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0349d:	62 00 00 
    753650a034a0:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a034a5:	4c 89 f7             	mov    rdi,r14
    753650a034a8:	ff d0                	call   rax
    753650a034aa:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a034b1:	00 
    753650a034b2:	84 c9                	test   cl,cl
    753650a034b4:	0f 85 3d 02 00 00    	jne    0x753650a036f7
    753650a034ba:	41 89 c7             	mov    r15d,eax
    753650a034bd:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a034c2:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a034c7:	e9 2a f2 ff e7       	jmp    0x753638a026f6
    753650a034cc:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a034d1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    753650a034d8:	98 01 01 00 
    753650a034dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a034e3:	02 00 00 00 
    753650a034e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a034ee:	06 00 00 00 
    753650a034f2:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a034f9:	62 00 00 
    753650a034fc:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a03501:	4c 89 f7             	mov    rdi,r14
    753650a03504:	ff d0                	call   rax
    753650a03506:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0350d:	00 
    753650a0350e:	84 c9                	test   cl,cl
    753650a03510:	0f 85 c1 01 00 00    	jne    0x753650a036d7
    753650a03516:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a0351b:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a03520:	e9 fe f1 ff e7       	jmp    0x753638a02723
    753650a03525:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a0352a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    753650a03531:	98 01 01 00 
    753650a03535:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0353c:	02 00 00 00 
    753650a03540:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a03547:	06 00 00 00 
    753650a0354b:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03552:	62 00 00 
    753650a03555:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a0355a:	4c 89 f7             	mov    rdi,r14
    753650a0355d:	ff d0                	call   rax
    753650a0355f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03566:	00 
    753650a03567:	84 c9                	test   cl,cl
    753650a03569:	0f 85 68 01 00 00    	jne    0x753650a036d7
    753650a0356f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03574:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a03579:	e9 c7 f1 ff e7       	jmp    0x753638a02745
    753650a0357e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a03583:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    753650a0358a:	98 01 01 00 
    753650a0358e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03595:	02 00 00 00 
    753650a03599:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a035a0:	06 00 00 00 
    753650a035a4:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a035ab:	62 00 00 
    753650a035ae:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a035b3:	4c 89 f7             	mov    rdi,r14
    753650a035b6:	ff d0                	call   rax
    753650a035b8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a035bf:	00 
    753650a035c0:	84 c9                	test   cl,cl
    753650a035c2:	0f 85 0f 01 00 00    	jne    0x753650a036d7
    753650a035c8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a035cd:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a035d2:	e9 90 f1 ff e7       	jmp    0x753638a02767
    753650a035d7:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a035dc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    753650a035e3:	98 01 01 00 
    753650a035e7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a035ee:	02 00 00 00 
    753650a035f2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a035f9:	06 00 00 00 
    753650a035fd:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a03604:	62 00 00 
    753650a03607:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753650a0360c:	4c 89 f7             	mov    rdi,r14
    753650a0360f:	ff d0                	call   rax
    753650a03611:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a03618:	00 
    753650a03619:	84 c9                	test   cl,cl
    753650a0361b:	0f 85 b6 00 00 00    	jne    0x753650a036d7
    753650a03621:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a03626:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a0362b:	e9 59 f1 ff e7       	jmp    0x753638a02789
    753650a03630:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a03635:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    753650a0363c:	98 01 01 00 
    753650a03640:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03647:	02 00 00 00 
    753650a0364b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    753650a03652:	06 00 00 00 
    753650a03656:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a0365d:	62 00 00 
    753650a03660:	4d 89 f4             	mov    r12,r14
    753650a03663:	4c 89 f7             	mov    rdi,r14
    753650a03666:	ff d0                	call   rax
    753650a03668:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0366f:	00 
    753650a03670:	84 c9                	test   cl,cl
    753650a03672:	0f 85 92 00 00 00    	jne    0x753650a0370a
    753650a03678:	4d 89 e6             	mov    r14,r12
    753650a0367b:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a03680:	e9 26 f1 ff e7       	jmp    0x753638a027ab
    753650a03685:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019a
    753650a0368c:	9a 01 01 00 
    753650a03690:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a03697:	02 00 00 00 
    753650a0369b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    753650a036a2:	07 00 00 00 
    753650a036a6:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a036ad:	62 00 00 
    753650a036b0:	4c 89 ef             	mov    rdi,r13
    753650a036b3:	be 2a 00 00 00       	mov    esi,0x2a
    753650a036b8:	4c 89 f2             	mov    rdx,r14
    753650a036bb:	4d 89 c7             	mov    r15,r8
    753650a036be:	ff d0                	call   rax
    753650a036c0:	4d 89 f8             	mov    r8,r15
    753650a036c3:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a036ca:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a036d1:	00 
    753650a036d2:	e9 f5 f0 ff e7       	jmp    0x753638a027cc
    753650a036d7:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a036de:	bb 02 00 00 00       	mov    ebx,0x2
    753650a036e3:	bd 06 00 00 00       	mov    ebp,0x6
    753650a036e8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753650a036ed:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a036f2:	e9 d5 f0 ff e7       	jmp    0x753638a027cc
    753650a036f7:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a036fe:	bb 04 00 00 00       	mov    ebx,0x4
    753650a03703:	bd 05 00 00 00       	mov    ebp,0x5
    753650a03708:	eb de                	jmp    0x753650a036e8
    753650a0370a:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    753650a03711:	bb 02 00 00 00       	mov    ebx,0x2
    753650a03716:	bd 06 00 00 00       	mov    ebp,0x6
    753650a0371b:	4d 89 e6             	mov    r14,r12
    753650a0371e:	eb cd                	jmp    0x753650a036ed
