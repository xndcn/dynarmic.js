; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010092(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65689
  %5 = icmp ult i32 %4, -7
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb11 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb11, -65689
  %8 = icmp ult i32 %7, -7
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010092, label %lb_guard_miss, !prof !0

insn_0x00010092:                                  ; preds = %entry
  %rx = load i32, ptr %cpu, align 4
  %10 = icmp eq i32 %rx, 0
  %az = zext i1 %10 to i32
  %flgn = lshr i32 %rx, 31
  %11 = getelementptr i8, ptr %cpu, i64 276
  store i32 %az, ptr %11, align 4
  %12 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 232
  store i32 %flgn, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 236
  store i32 1, ptr %14, align 4
  %15 = getelementptr i8, ptr %cpu, i64 240
  store i32 1, ptr %15, align 4
  br i1 %10, label %insn_0x00010096, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x00010092
  %16 = getelementptr i8, ptr %cpu, i64 188
  store i32 65728, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %17, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %18 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %18 monotonic, align 4, !range !1
  %19 = icmp ult i32 %chain_total, %chain_budget
  br i1 %19, label %chain_go, label %chain_leave12, !prof !0

insn_0x00010096:                                  ; preds = %insn_0x00010092
  %20 = getelementptr i8, ptr %cpu, i64 48
  %ptr = load i32, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i64 24
  %val = load i32, ptr %21, align 4
  %22 = and i32 %ptr, 3
  %.not = icmp eq i32 %22, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010096
  %23 = getelementptr i8, ptr %cpu, i64 188
  store i32 65686, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %25, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65686, i32 %ptr, i32 65536)
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010096
  %26 = lshr i32 %ptr, 12
  %page_index = zext i32 %26 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !2

page_wr_fast:                                     ; preds = %data_aligned
  %27 = and i32 %ptr, 4095
  %page_offset = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %28, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %29 = getelementptr i8, ptr %cpu, i64 188
  store i32 65686, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %31, align 4
  tail call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %32 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %32, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %chain_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not34 = icmp eq i8 %cec_pending, 0
  br i1 %.not34, label %insn_0x00010098, label %cec_check, !prof !0

cec_check:                                        ; preds = %page_wr_done
  %33 = getelementptr i8, ptr %cpu, i64 188
  store i32 65688, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %35, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %36 = getelementptr i8, ptr %cpu, i64 296
  %dj3 = load i8, ptr %36, align 1
  %dj_set4.not = icmp eq i8 %dj3, 0
  br i1 %dj_set4.not, label %insn_0x00010098, label %chain_exit, !prof !0

insn_0x00010098:                                  ; preds = %page_wr_done, %cec_check
  %37 = getelementptr i8, ptr %cpu, i64 152
  %lc = load i32, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 144
  %lt = load i32, ptr %38, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %guard_lb, 65688
  %hwloop_cond = and i1 %at_lb, %lc_gt1
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65692
  %39 = getelementptr i8, ptr %cpu, i64 156
  %lc5 = load i32, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i64 148
  %lt6 = load i32, ptr %40, align 4
  %lc_gt17 = icmp ugt i32 %lc5, 1
  %at_lb8 = icmp eq i32 %guard_lb11, 65688
  %hwloop_cond9 = and i1 %at_lb8, %lc_gt17
  %hwloop_rets10 = select i1 %hwloop_cond9, i32 %lt6, i32 %hwloop_rets
  %41 = getelementptr i8, ptr %cpu, i64 168
  store i32 %hwloop_rets10, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 188
  store i32 66600, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets17 = load i32, ptr %43, align 4
  %chain_total18 = add nuw i32 %chain_packets17, 4
  %44 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget19 = load atomic i32, ptr %44 monotonic, align 4, !range !1
  %45 = icmp ult i32 %chain_total18, %chain_budget19
  br i1 %45, label %chain_go15, label %chain_leave16, !prof !0

common.ret:                                       ; preds = %chain_leave26, %chain_leave16, %chain_leave12, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %46 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %46, align 1
  br label %common.ret

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525824
  %slot_pc = load i32, ptr %chain_slot, align 4
  %47 = icmp eq i32 %slot_pc, 65728
  br i1 %47, label %chain_hit, label %chain_leave12, !prof !0

chain_leave12:                                    ; preds = %chain_go, %brcc_taken
  store i32 65728, ptr %16, align 4
  %48 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %50, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65728, ptr %16, align 4
  store i32 %chain_total, ptr %17, align 4
  %51 = getelementptr i8, ptr %chain_table, i64 525832
  %chain_fn = load ptr, ptr %51, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go15:                                       ; preds = %insn_0x00010098
  %chain_slot20 = getelementptr i8, ptr %chain_table, i64 532800
  %slot_pc21 = load i32, ptr %chain_slot20, align 4
  %52 = icmp eq i32 %slot_pc21, 66600
  br i1 %52, label %chain_hit22, label %chain_leave16, !prof !0

chain_leave16:                                    ; preds = %chain_go15, %insn_0x00010098
  store i32 66600, ptr %42, align 4
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %55, align 1
  br label %common.ret

chain_hit22:                                      ; preds = %chain_go15
  store i32 66600, ptr %42, align 4
  store i32 %chain_total18, ptr %43, align 4
  %56 = getelementptr i8, ptr %chain_table, i64 532808
  %chain_fn23 = load ptr, ptr %56, align 8
  musttail call swifttailcc void %chain_fn23(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %cec_check, %page_wr_slow, %data_misaligned
  %next_pc24.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc24 = load i32, ptr %next_pc24.in, align 4
  %57 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %57, align 4
  %chain_total28 = add nuw i32 %chain_packets27, 3
  %58 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %58 monotonic, align 4, !range !1
  %59 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %59, label %chain_lookup, label %chain_leave26, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %60 = shl i32 %next_pc24, 3
  %61 = and i32 %60, 1048560
  %62 = zext i32 %61 to i64
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 %62
  %slot_pc31 = load i32, ptr %chain_slot30, align 4
  %63 = icmp eq i32 %slot_pc31, %next_pc24
  br i1 %63, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_lookup, %chain_exit
  %64 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %65, align 4
  br label %common.ret

chain_hit32:                                      ; preds = %chain_lookup
  store i32 %chain_total28, ptr %57, align 4
  %66 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %66, align 1
  %67 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %67, align 8
  musttail call swifttailcc void %chain_fn33(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
!2 = !{!"branch_weights", i32 1, i32 1048576}
