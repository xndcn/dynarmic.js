; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010428(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66600
  %6 = icmp ugt i32 %5, 24
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb64 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb64, 0
  %11 = sub i32 %guard_lb64, 66600
  %12 = icmp ugt i32 %11, 24
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010428_entry, label %lb_guard_miss, !prof !0

insn_0x00010428_entry:                            ; preds = %lb_guard
  br label %insn_0x00010428

insn_0x00010428:                                  ; preds = %insn_0x00010428_entry
  %15 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %15, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %16 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %18, align 4
  br label %insn_0x0001042c_entry

insn_0x0001042c_entry:                            ; preds = %insn_0x00010428
  br label %insn_0x0001042c

insn_0x0001042c:                                  ; preds = %insn_0x0001042c_entry
  %19 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %21, align 4
  %sp1 = sub i32 %sp, 4
  %22 = and i32 %sp1, 3
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001042c
  %24 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %26, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66604, i32 %sp1, i32 65536)
  %27 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 188
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr i8, ptr %cpu, i64 296
  %31 = load i8, ptr %30, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001042c
  %32 = lshr i32 %sp1, 12
  %page_index = zext i32 %32 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %33 = and i32 %sp1, 4095
  %page_offset = zext i32 %33 to i64
  %34 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %34, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %35 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %37, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %38 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %38, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp2 = sub i32 %sp1, 4
  %39 = and i32 %sp2, 3
  %40 = icmp ne i32 %39, 0
  br i1 %40, label %data_misaligned1, label %data_aligned2, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %41 = getelementptr i8, ptr %cpu, i64 188
  %next_pc65 = load i32, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 188
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %cpu, i64 296
  %45 = load i8, ptr %44, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned1:                                 ; preds = %page_wr_done
  %46 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %48, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66604, i32 %sp2, i32 65536)
  %49 = getelementptr i8, ptr %cpu, i64 188
  %next_pc66 = load i32, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 188
  %51 = load i32, ptr %50, align 4
  %52 = getelementptr i8, ptr %cpu, i64 296
  %53 = load i8, ptr %52, align 1
  br label %chain_exit

data_aligned2:                                    ; preds = %page_wr_done
  %54 = lshr i32 %sp2, 12
  %page_index6 = zext i32 %54 to i64
  %page_slot7 = getelementptr ptr, ptr %page_table, i64 %page_index6
  %page8 = load ptr, ptr %page_slot7, align 8
  %page_mapped9 = icmp ne ptr %page8, null
  br i1 %page_mapped9, label %page_wr_fast3, label %page_wr_slow4, !prof !0

page_wr_fast3:                                    ; preds = %data_aligned2
  %55 = and i32 %sp2, 4095
  %page_offset10 = zext i32 %55 to i64
  %56 = getelementptr i8, ptr %page8, i64 %page_offset10
  store i32 %fp, ptr %56, align 4
  br label %page_wr_done5

page_wr_slow4:                                    ; preds = %data_aligned2
  %57 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %59, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %60 = getelementptr i8, ptr %cpu, i32 296
  %dj13 = load i8, ptr %60, align 1
  %dj_set14 = icmp ne i8 %dj13, 0
  br i1 %dj_set14, label %did_jump_exit11, label %did_jump_cont12, !prof !1

page_wr_done5:                                    ; preds = %did_jump_cont12, %page_wr_fast3
  %61 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %61, align 4
  %sp3 = sub i32 %sp2, 0
  %62 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %62, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %63 = icmp ne i8 %cec_pending, 0
  br i1 %63, label %cec_check, label %cec_checked, !prof !1

did_jump_exit11:                                  ; preds = %page_wr_slow4
  %64 = getelementptr i8, ptr %cpu, i64 188
  %next_pc67 = load i32, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 188
  %66 = load i32, ptr %65, align 4
  %67 = getelementptr i8, ptr %cpu, i64 296
  %68 = load i8, ptr %67, align 1
  br label %chain_exit

did_jump_cont12:                                  ; preds = %page_wr_slow4
  br label %page_wr_done5

cec_check:                                        ; preds = %page_wr_done5
  %69 = getelementptr i8, ptr %cpu, i32 188
  store i32 66608, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %71, align 4
  call void @cec_check_pending(ptr %cpu)
  %72 = getelementptr i8, ptr %cpu, i32 296
  %dj17 = load i8, ptr %72, align 1
  %dj_set18 = icmp ne i8 %dj17, 0
  br i1 %dj_set18, label %did_jump_exit15, label %did_jump_cont16, !prof !1

cec_checked:                                      ; preds = %did_jump_cont16, %page_wr_done5
  br label %insn_0x00010430_entry

did_jump_exit15:                                  ; preds = %cec_check
  %73 = getelementptr i8, ptr %cpu, i64 188
  %next_pc68 = load i32, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 188
  %75 = load i32, ptr %74, align 4
  %76 = getelementptr i8, ptr %cpu, i64 296
  %77 = load i8, ptr %76, align 1
  br label %chain_exit

did_jump_cont16:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010430_entry:                            ; preds = %cec_checked
  br label %insn_0x00010430

insn_0x00010430:                                  ; preds = %insn_0x00010430_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4848
  %78 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %78, align 4
  br label %insn_0x00010434_entry

insn_0x00010434_entry:                            ; preds = %insn_0x00010430
  br label %insn_0x00010434

insn_0x00010434:                                  ; preds = %insn_0x00010434_entry
  %79 = and i32 %with_lo, 3
  %80 = icmp ne i32 %79, 0
  br i1 %80, label %data_misaligned19, label %data_aligned20, !prof !1

data_misaligned19:                                ; preds = %insn_0x00010434
  %81 = getelementptr i8, ptr %cpu, i32 188
  store i32 66612, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %83, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66612, i32 %with_lo, i32 0)
  %84 = getelementptr i8, ptr %cpu, i64 188
  %next_pc69 = load i32, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 188
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %cpu, i64 296
  %88 = load i8, ptr %87, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %insn_0x00010434
  %89 = lshr i32 %with_lo, 12
  %page_index21 = zext i32 %89 to i64
  %page_slot22 = getelementptr ptr, ptr %page_table, i64 %page_index21
  %page23 = load ptr, ptr %page_slot22, align 8
  %page_mapped24 = icmp ne ptr %page23, null
  br i1 %page_mapped24, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned20
  %90 = and i32 %with_lo, 4095
  %page_offset25 = zext i32 %90 to i64
  %91 = getelementptr i8, ptr %page23, i64 %page_offset25
  %page_val = load i32, ptr %91, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned20
  %92 = getelementptr i8, ptr %cpu, i32 188
  store i32 66612, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %94, align 4
  %95 = call i32 @mem_read32(ptr %mem, i32 %with_lo)
  %96 = getelementptr i8, ptr %cpu, i32 296
  %dj28 = load i8, ptr %96, align 1
  %dj_set29 = icmp ne i8 %dj28, 0
  br i1 %dj_set29, label %did_jump_exit26, label %did_jump_cont27, !prof !1

page_done:                                        ; preds = %did_jump_cont27, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %95, %did_jump_cont27 ]
  %97 = getelementptr i8, ptr %cpu, i32 40
  store i32 %mem_val, ptr %97, align 4
  br label %insn_0x00010436_entry

did_jump_exit26:                                  ; preds = %page_slow
  %98 = getelementptr i8, ptr %cpu, i64 188
  %next_pc70 = load i32, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 188
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %cpu, i64 296
  %102 = load i8, ptr %101, align 1
  br label %chain_exit

did_jump_cont27:                                  ; preds = %page_slow
  br label %page_done

insn_0x00010436_entry:                            ; preds = %page_done
  br label %insn_0x00010436

insn_0x00010436:                                  ; preds = %insn_0x00010436_entry
  %103 = icmp ule i32 %mem_val, 4
  %cc = zext i1 %103 to i32
  %104 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %104, align 4
  br label %insn_0x00010438_entry

insn_0x00010438_entry:                            ; preds = %insn_0x00010436
  br label %insn_0x00010438

insn_0x00010438:                                  ; preds = %insn_0x00010438_entry
  %cc_true = icmp ne i32 %cc, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x00010438
  %105 = getelementptr i8, ptr %cpu, i32 188
  store i32 66626, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %106, align 4
  %chain_total = add nuw i32 %chain_packets, 6
  %107 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %107 monotonic, align 4, !range !2
  %108 = icmp ult i32 %chain_total, %chain_budget
  br i1 %108, label %chain_go, label %chain_leave71, !prof !0

brt_fallthru:                                     ; preds = %insn_0x00010438
  br label %insn_0x0001043a_entry

insn_0x0001043a_entry:                            ; preds = %brt_fallthru
  br label %insn_0x0001043a

insn_0x0001043a:                                  ; preds = %insn_0x0001043a_entry
  %109 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %109, align 4
  br label %insn_0x0001043c_entry

insn_0x0001043c_entry:                            ; preds = %insn_0x0001043a
  br label %insn_0x0001043c

insn_0x0001043c:                                  ; preds = %insn_0x0001043c_entry
  %110 = and i32 %sp2, 3
  %111 = icmp ne i32 %110, 0
  br i1 %111, label %data_misaligned30, label %data_aligned31, !prof !1

data_misaligned30:                                ; preds = %insn_0x0001043c
  %112 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %114, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66620, i32 %sp2, i32 0)
  %115 = getelementptr i8, ptr %cpu, i64 188
  %next_pc72 = load i32, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 188
  %117 = load i32, ptr %116, align 4
  %118 = getelementptr i8, ptr %cpu, i64 296
  %119 = load i8, ptr %118, align 1
  br label %chain_exit

data_aligned31:                                   ; preds = %insn_0x0001043c
  %120 = lshr i32 %sp2, 12
  %page_index35 = zext i32 %120 to i64
  %page_slot36 = getelementptr ptr, ptr %page_table, i64 %page_index35
  %page37 = load ptr, ptr %page_slot36, align 8
  %page_mapped38 = icmp ne ptr %page37, null
  br i1 %page_mapped38, label %page_fast32, label %page_slow33, !prof !0

page_fast32:                                      ; preds = %data_aligned31
  %121 = and i32 %sp2, 4095
  %page_offset39 = zext i32 %121 to i64
  %122 = getelementptr i8, ptr %page37, i64 %page_offset39
  %page_val40 = load i32, ptr %122, align 4
  br label %page_done34

page_slow33:                                      ; preds = %data_aligned31
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %125, align 4
  %126 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %127 = getelementptr i8, ptr %cpu, i32 296
  %dj43 = load i8, ptr %127, align 1
  %dj_set44 = icmp ne i8 %dj43, 0
  br i1 %dj_set44, label %did_jump_exit41, label %did_jump_cont42, !prof !1

page_done34:                                      ; preds = %did_jump_cont42, %page_fast32
  %mem_val45 = phi i32 [ %page_val40, %page_fast32 ], [ %126, %did_jump_cont42 ]
  %sp146 = add i32 %sp2, 4
  %128 = and i32 %sp146, 3
  %129 = icmp ne i32 %128, 0
  br i1 %129, label %data_misaligned47, label %data_aligned48, !prof !1

did_jump_exit41:                                  ; preds = %page_slow33
  %130 = getelementptr i8, ptr %cpu, i64 188
  %next_pc73 = load i32, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 188
  %132 = load i32, ptr %131, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  %134 = load i8, ptr %133, align 1
  br label %chain_exit

did_jump_cont42:                                  ; preds = %page_slow33
  br label %page_done34

data_misaligned47:                                ; preds = %page_done34
  %135 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %137, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66620, i32 %sp146, i32 0)
  %138 = getelementptr i8, ptr %cpu, i64 188
  %next_pc74 = load i32, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i64 188
  %140 = load i32, ptr %139, align 4
  %141 = getelementptr i8, ptr %cpu, i64 296
  %142 = load i8, ptr %141, align 1
  br label %chain_exit

data_aligned48:                                   ; preds = %page_done34
  %143 = lshr i32 %sp146, 12
  %page_index52 = zext i32 %143 to i64
  %page_slot53 = getelementptr ptr, ptr %page_table, i64 %page_index52
  %page54 = load ptr, ptr %page_slot53, align 8
  %page_mapped55 = icmp ne ptr %page54, null
  br i1 %page_mapped55, label %page_fast49, label %page_slow50, !prof !0

page_fast49:                                      ; preds = %data_aligned48
  %144 = and i32 %sp146, 4095
  %page_offset56 = zext i32 %144 to i64
  %145 = getelementptr i8, ptr %page54, i64 %page_offset56
  %page_val57 = load i32, ptr %145, align 4
  br label %page_done51

page_slow50:                                      ; preds = %data_aligned48
  %146 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %146, align 4
  %147 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %148, align 4
  %149 = call i32 @mem_read32(ptr %mem, i32 %sp146)
  %150 = getelementptr i8, ptr %cpu, i32 296
  %dj60 = load i8, ptr %150, align 1
  %dj_set61 = icmp ne i8 %dj60, 0
  br i1 %dj_set61, label %did_jump_exit58, label %did_jump_cont59, !prof !1

page_done51:                                      ; preds = %did_jump_cont59, %page_fast49
  %mem_val62 = phi i32 [ %page_val57, %page_fast49 ], [ %149, %did_jump_cont59 ]
  %sp263 = add i32 %sp146, 4
  %151 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val45, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val62, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp263, ptr %153, align 4
  br label %insn_0x00010440_entry

did_jump_exit58:                                  ; preds = %page_slow50
  %154 = getelementptr i8, ptr %cpu, i64 188
  %next_pc75 = load i32, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 188
  %156 = load i32, ptr %155, align 4
  %157 = getelementptr i8, ptr %cpu, i64 296
  %158 = load i8, ptr %157, align 1
  br label %chain_exit

did_jump_cont59:                                  ; preds = %page_slow50
  br label %page_done51

insn_0x00010440_entry:                            ; preds = %page_done51
  br label %insn_0x00010440

insn_0x00010440:                                  ; preds = %insn_0x00010440_entry
  %lsb = and i32 %mem_val62, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x00010440
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x00010440
  %159 = getelementptr i8, ptr %cpu, i32 188
  store i32 66624, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %161, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %162 = getelementptr i8, ptr %cpu, i64 188
  %next_pc76 = load i32, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i64 188
  %164 = load i32, ptr %163, align 4
  %165 = getelementptr i8, ptr %cpu, i64 296
  %166 = load i8, ptr %165, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %167 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %167, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 533008
  %168 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %168, align 4
  %169 = icmp eq i32 %slot_pc, 66626
  br i1 %169, label %chain_hit, label %chain_leave71, !prof !0

chain_leave71:                                    ; preds = %chain_go, %brt_taken
  %170 = getelementptr i8, ptr %cpu, i64 188
  store i32 66626, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %173, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %174 = getelementptr i8, ptr %cpu, i64 188
  store i32 66626, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %175, align 4
  %176 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %176, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit58, %data_misaligned47, %did_jump_exit41, %data_misaligned30, %did_jump_exit26, %data_misaligned19, %did_jump_exit15, %did_jump_exit11, %data_misaligned1, %did_jump_exit, %data_misaligned
  %next_pc77 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc65, %did_jump_exit ], [ %next_pc66, %data_misaligned1 ], [ %next_pc67, %did_jump_exit11 ], [ %next_pc68, %did_jump_exit15 ], [ %next_pc69, %data_misaligned19 ], [ %next_pc70, %did_jump_exit26 ], [ %next_pc72, %data_misaligned30 ], [ %next_pc73, %did_jump_exit41 ], [ %next_pc74, %data_misaligned47 ], [ %next_pc75, %did_jump_exit58 ], [ %mem_val62, %jump_aligned ], [ %next_pc76, %jump_misalign ]
  %packets = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned1 ], [ 2, %did_jump_exit11 ], [ 2, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit26 ], [ 8, %data_misaligned30 ], [ 8, %did_jump_exit41 ], [ 8, %data_misaligned47 ], [ 8, %did_jump_exit58 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail = phi i32 [ %29, %data_misaligned ], [ %43, %did_jump_exit ], [ %51, %data_misaligned1 ], [ %66, %did_jump_exit11 ], [ %75, %did_jump_exit15 ], [ %86, %data_misaligned19 ], [ %100, %did_jump_exit26 ], [ %117, %data_misaligned30 ], [ %132, %did_jump_exit41 ], [ %140, %data_misaligned47 ], [ %156, %did_jump_exit58 ], [ %mem_val62, %jump_aligned ], [ %164, %jump_misalign ]
  %tail78 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned1 ], [ 4, %did_jump_exit11 ], [ 4, %did_jump_exit15 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit26 ], [ 4, %data_misaligned30 ], [ 4, %did_jump_exit41 ], [ 4, %data_misaligned47 ], [ 4, %did_jump_exit58 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail79 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned1 ], [ 2, %did_jump_exit11 ], [ 2, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit26 ], [ 8, %data_misaligned30 ], [ 8, %did_jump_exit41 ], [ 8, %data_misaligned47 ], [ 8, %did_jump_exit58 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail80 = phi i8 [ %31, %data_misaligned ], [ %45, %did_jump_exit ], [ %53, %data_misaligned1 ], [ %68, %did_jump_exit11 ], [ %77, %did_jump_exit15 ], [ %88, %data_misaligned19 ], [ %102, %did_jump_exit26 ], [ %119, %data_misaligned30 ], [ %134, %did_jump_exit41 ], [ %142, %data_misaligned47 ], [ %158, %did_jump_exit58 ], [ 1, %jump_aligned ], [ %166, %jump_misalign ]
  %177 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets82 = load i32, ptr %177, align 4
  %chain_total83 = add nuw i32 %chain_packets82, %packets
  %178 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget84 = load atomic i32, ptr %178 monotonic, align 4, !range !2
  %179 = icmp ult i32 %chain_total83, %chain_budget84
  br i1 %179, label %chain_lookup, label %chain_leave81, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %180 = lshr i32 %next_pc77, 1
  %181 = and i32 %180, 65535
  %182 = zext i32 %181 to i64
  %183 = mul i64 %182, 16
  %chain_slot85 = getelementptr i8, ptr %chain_table, i64 %183
  %184 = getelementptr i8, ptr %chain_slot85, i64 0
  %slot_pc86 = load i32, ptr %184, align 4
  %185 = icmp eq i32 %slot_pc86, %next_pc77
  br i1 %185, label %chain_hit87, label %chain_leave81, !prof !0

chain_leave81:                                    ; preds = %chain_lookup, %chain_exit
  %186 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail78, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail79, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail80, ptr %189, align 1
  ret void

chain_hit87:                                      ; preds = %chain_lookup
  %190 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc77, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total83, ptr %191, align 4
  %192 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %192, align 1
  %193 = getelementptr i8, ptr %chain_slot85, i64 8
  %chain_fn88 = load ptr, ptr %193, align 8
  musttail call swifttailcc void %chain_fn88(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
