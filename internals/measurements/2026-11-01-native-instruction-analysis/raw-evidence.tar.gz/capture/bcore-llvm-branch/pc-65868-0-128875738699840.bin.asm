
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65868-0-128875738699840.bin:     file format binary


Disassembly of section .data:

0000753638a01840 <.data>:
    753638a01840:	48 83 ec 18          	sub    rsp,0x18
    753638a01844:	b8 91 fe fe ff       	mov    eax,0xfffefe91
    753638a01849:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    753638a01850:	01 c1                	add    ecx,eax
    753638a01852:	83 f9 dc             	cmp    ecx,0xffffffdc
    753638a01855:	0f 87 c8 0f 00 18    	ja     0x753650a02823
    753638a0185b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    753638a01862:	83 f8 dc             	cmp    eax,0xffffffdc
    753638a01865:	0f 87 b8 0f 00 18    	ja     0x753650a02823
    753638a0186b:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    753638a01872:	45 8b 65 38          	mov    r12d,DWORD PTR [r13+0x38]
    753638a01876:	41 8d 4c 24 fc       	lea    ecx,[r12-0x4]
    753638a0187b:	41 f6 c4 03          	test   r12b,0x3
    753638a0187f:	0f 85 ad 0f 00 18    	jne    0x753650a02832
    753638a01885:	4d 8b bd 38 01 00 00 	mov    r15,QWORD PTR [r13+0x138]
    753638a0188c:	4d 8b 85 40 01 00 00 	mov    r8,QWORD PTR [r13+0x140]
    753638a01893:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    753638a01897:	89 c8                	mov    eax,ecx
    753638a01899:	c1 e8 0c             	shr    eax,0xc
    753638a0189c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a018a0:	48 85 c0             	test   rax,rax
    753638a018a3:	0f 84 2f 10 00 18    	je     0x753650a028d8
    753638a018a9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a018af:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a018b2:	41 8d 74 24 f8       	lea    esi,[r12-0x8]
    753638a018b7:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    753638a018bb:	89 f0                	mov    eax,esi
    753638a018bd:	c1 e8 0c             	shr    eax,0xc
    753638a018c0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a018c4:	48 85 c0             	test   rax,rax
    753638a018c7:	0f 84 5f 10 00 18    	je     0x753650a0292c
    753638a018cd:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a018d3:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    753638a018d6:	41 8d 74 24 f4       	lea    esi,[r12-0xc]
    753638a018db:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    753638a018df:	89 f0                	mov    eax,esi
    753638a018e1:	c1 e8 0c             	shr    eax,0xc
    753638a018e4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a018e8:	48 85 c0             	test   rax,rax
    753638a018eb:	0f 84 8d 10 00 18    	je     0x753650a0297e
    753638a018f1:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a018f7:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    753638a018fa:	41 8d 74 24 f0       	lea    esi,[r12-0x10]
    753638a018ff:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    753638a01903:	89 f0                	mov    eax,esi
    753638a01905:	c1 e8 0c             	shr    eax,0xc
    753638a01908:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a0190c:	48 85 c0             	test   rax,rax
    753638a0190f:	0f 84 bb 10 00 18    	je     0x753650a029d0
    753638a01915:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a0191b:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    753638a0191e:	41 8d 5c 24 ec       	lea    ebx,[r12-0x14]
    753638a01923:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    753638a01927:	89 d8                	mov    eax,ebx
    753638a01929:	c1 e8 0c             	shr    eax,0xc
    753638a0192c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a01930:	48 85 c0             	test   rax,rax
    753638a01933:	0f 84 e9 10 00 18    	je     0x753650a02a22
    753638a01939:	89 d9                	mov    ecx,ebx
    753638a0193b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a01941:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a01944:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    753638a01948:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    753638a0194c:	0f 85 24 11 00 18    	jne    0x753650a02a76
    753638a01952:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    753638a01956:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a0195d:	41 8d 74 24 e8       	lea    esi,[r12-0x18]
    753638a01962:	89 f0                	mov    eax,esi
    753638a01964:	c1 e8 0c             	shr    eax,0xc
    753638a01967:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a0196b:	48 85 c0             	test   rax,rax
    753638a0196e:	0f 84 5f 11 00 18    	je     0x753650a02ad3
    753638a01974:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a0197a:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    753638a0197d:	41 8d 6c 24 e4       	lea    ebp,[r12-0x1c]
    753638a01982:	89 e8                	mov    eax,ebp
    753638a01984:	c1 e8 0c             	shr    eax,0xc
    753638a01987:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    753638a0198b:	48 85 c0             	test   rax,rax
    753638a0198e:	0f 84 9c 11 00 18    	je     0x753650a02b30
    753638a01994:	89 e9                	mov    ecx,ebp
    753638a01996:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a0199c:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    753638a0199f:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a019a3:	41 83 c4 d8          	add    r12d,0xffffffd8
    753638a019a7:	45 89 65 38          	mov    DWORD PTR [r13+0x38],r12d
    753638a019ab:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    753638a019af:	0f 85 d9 11 00 18    	jne    0x753650a02b8e
    753638a019b5:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    753638a019b9:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    753638a019bd:	89 c1                	mov    ecx,eax
    753638a019bf:	c1 e9 1f             	shr    ecx,0x1f
    753638a019c2:	31 d2                	xor    edx,edx
    753638a019c4:	85 c0                	test   eax,eax
    753638a019c6:	0f 94 c2             	sete   dl
    753638a019c9:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    753638a019d0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    753638a019d7:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    753638a019de:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    753638a019e5:	00 00 00 
    753638a019e8:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    753638a019ef:	74 77                	je     0x753638a01a68
    753638a019f1:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    753638a019f5:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a019fc:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    753638a01a00:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    753638a01a04:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    753638a01a0b:	00 
    753638a01a0c:	41 c7 45 10 0d 66 19 	mov    DWORD PTR [r13+0x10],0x19660d
    753638a01a13:	00 
    753638a01a14:	41 c7 45 34 5f f3 6e 	mov    DWORD PTR [r13+0x34],0x3c6ef35f
    753638a01a1b:	3c 
    753638a01a1c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753638a01a23:	7c 01 01 00 
    753638a01a27:	83 c0 0d             	add    eax,0xd
    753638a01a2a:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a01a31:	39 c8                	cmp    eax,ecx
    753638a01a33:	0f 83 c4 0d 00 18    	jae    0x753650a027fd
    753638a01a39:	81 bf e0 0b 08 00 7c 	cmp    DWORD PTR [rdi+0x80be0],0x1017c
    753638a01a40:	01 01 00 
    753638a01a43:	0f 85 b4 0d 00 18    	jne    0x753650a027fd
    753638a01a49:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    753638a01a50:	7c 01 01 00 
    753638a01a54:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01a5b:	48 8b 87 e8 0b 08 00 	mov    rax,QWORD PTR [rdi+0x80be8]
    753638a01a62:	48 83 c4 18          	add    rsp,0x18
    753638a01a66:	ff e0                	jmp    rax
    753638a01a68:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    753638a01a6f:	9c 01 01 00 
    753638a01a73:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a01a7a:	83 c0 05             	add    eax,0x5
    753638a01a7d:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a01a84:	39 c8                	cmp    eax,ecx
    753638a01a86:	0f 83 63 11 00 18    	jae    0x753650a02bef
    753638a01a8c:	81 bf e0 0c 08 00 9c 	cmp    DWORD PTR [rdi+0x80ce0],0x1019c
    753638a01a93:	01 01 00 
    753638a01a96:	0f 85 53 11 00 18    	jne    0x753650a02bef
    753638a01a9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    753638a01aa3:	9c 01 01 00 
    753638a01aa7:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01aae:	48 8b 87 e8 0c 08 00 	mov    rax,QWORD PTR [rdi+0x80ce8]
    753638a01ab5:	48 83 c4 18          	add    rsp,0x18
    753638a01ab9:	ff e0                	jmp    rax
    753638a01abb:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a01ac2:	01 
    753638a01ac3:	48 83 c4 18          	add    rsp,0x18
    753638a01ac7:	c2 08 00             	ret    0x8
