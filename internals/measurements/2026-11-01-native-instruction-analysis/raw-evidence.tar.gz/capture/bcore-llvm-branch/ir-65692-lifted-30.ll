; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001009c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65692
  %6 = icmp ugt i32 %5, 34
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb222 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb222, 0
  %11 = sub i32 %guard_lb222, 65692
  %12 = icmp ugt i32 %11, 34
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x0001009c_entry, label %lb_guard_miss, !prof !0

insn_0x0001009c_entry:                            ; preds = %lb_guard
  br label %insn_0x0001009c

insn_0x0001009c:                                  ; preds = %insn_0x0001009c_entry
  %15 = getelementptr i8, ptr %cpu, i32 48
  %ptr = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i32 20
  %val = load i32, ptr %16, align 4
  %17 = and i32 %ptr, 3
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001009c
  %19 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %20, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65692, i32 %ptr, i32 65536)
  %21 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 188
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr i8, ptr %cpu, i64 296
  %25 = load i8, ptr %24, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001009c
  %26 = lshr i32 %ptr, 12
  %page_index = zext i32 %26 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %27 = and i32 %ptr, 4095
  %page_offset = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %28, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %29 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %30, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %31 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %31, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %32 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %33, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %34 = icmp ne i8 %cec_pending, 0
  br i1 %34, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc223 = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 188
  %37 = load i32, ptr %36, align 4
  %38 = getelementptr i8, ptr %cpu, i64 296
  %39 = load i8, ptr %38, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %40 = getelementptr i8, ptr %cpu, i32 188
  store i32 65694, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %42, align 4
  call void @cec_check_pending(ptr %cpu)
  %43 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %43, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x0001009e_entry

did_jump_exit1:                                   ; preds = %cec_check
  %44 = getelementptr i8, ptr %cpu, i64 188
  %next_pc224 = load i32, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i64 188
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %cpu, i64 296
  %48 = load i8, ptr %47, align 1
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x0001009e_entry:                            ; preds = %cec_checked
  br label %insn_0x0001009e

insn_0x0001009e:                                  ; preds = %insn_0x0001009e_entry
  %49 = getelementptr i8, ptr %cpu, i32 52
  %ptr5 = load i32, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 0
  %val6 = load i32, ptr %50, align 4
  %51 = and i32 %ptr5, 3
  %52 = icmp ne i32 %51, 0
  br i1 %52, label %data_misaligned7, label %data_aligned8, !prof !1

data_misaligned7:                                 ; preds = %insn_0x0001009e
  %53 = getelementptr i8, ptr %cpu, i32 188
  store i32 65694, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %55, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65694, i32 %ptr5, i32 65536)
  %56 = getelementptr i8, ptr %cpu, i64 188
  %next_pc225 = load i32, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 188
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %cpu, i64 296
  %60 = load i8, ptr %59, align 1
  br label %chain_exit

data_aligned8:                                    ; preds = %insn_0x0001009e
  %61 = lshr i32 %ptr5, 12
  %page_index12 = zext i32 %61 to i64
  %page_slot13 = getelementptr ptr, ptr %page_table, i64 %page_index12
  %page14 = load ptr, ptr %page_slot13, align 8
  %page_mapped15 = icmp ne ptr %page14, null
  br i1 %page_mapped15, label %page_wr_fast9, label %page_wr_slow10, !prof !0

page_wr_fast9:                                    ; preds = %data_aligned8
  %62 = and i32 %ptr5, 4095
  %page_offset16 = zext i32 %62 to i64
  %63 = getelementptr i8, ptr %page14, i64 %page_offset16
  store i32 %val6, ptr %63, align 4
  br label %page_wr_done11

page_wr_slow10:                                   ; preds = %data_aligned8
  %64 = getelementptr i8, ptr %cpu, i32 188
  store i32 65694, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %66, align 4
  call void @mem_write32(ptr %mem, i32 %ptr5, i32 %val6)
  %67 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %67, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

page_wr_done11:                                   ; preds = %did_jump_cont18, %page_wr_fast9
  %ptr_inc = add i32 %ptr5, 4
  %68 = getelementptr i8, ptr %cpu, i32 52
  store i32 %ptr_inc, ptr %68, align 4
  %cec_pending21 = load i8, ptr %cec_pending_flag, align 1
  %69 = icmp ne i8 %cec_pending21, 0
  br i1 %69, label %cec_check22, label %cec_checked23, !prof !1

did_jump_exit17:                                  ; preds = %page_wr_slow10
  %70 = getelementptr i8, ptr %cpu, i64 188
  %next_pc226 = load i32, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 188
  %72 = load i32, ptr %71, align 4
  %73 = getelementptr i8, ptr %cpu, i64 296
  %74 = load i8, ptr %73, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %page_wr_slow10
  br label %page_wr_done11

cec_check22:                                      ; preds = %page_wr_done11
  %75 = getelementptr i8, ptr %cpu, i32 188
  store i32 65696, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %77, align 4
  call void @cec_check_pending(ptr %cpu)
  %78 = getelementptr i8, ptr %cpu, i32 296
  %dj26 = load i8, ptr %78, align 1
  %dj_set27 = icmp ne i8 %dj26, 0
  br i1 %dj_set27, label %did_jump_exit24, label %did_jump_cont25, !prof !1

cec_checked23:                                    ; preds = %did_jump_cont25, %page_wr_done11
  br label %insn_0x000100a0_entry

did_jump_exit24:                                  ; preds = %cec_check22
  %79 = getelementptr i8, ptr %cpu, i64 188
  %next_pc227 = load i32, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 188
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr i8, ptr %cpu, i64 296
  %83 = load i8, ptr %82, align 1
  br label %chain_exit

did_jump_cont25:                                  ; preds = %cec_check22
  br label %cec_checked23

insn_0x000100a0_entry:                            ; preds = %cec_checked23
  br label %insn_0x000100a0

insn_0x000100a0:                                  ; preds = %insn_0x000100a0_entry
  %84 = getelementptr i8, ptr %cpu, i32 28
  %rd = load i32, ptr %84, align 4
  %rd_add = add i32 %rd, 1
  %85 = getelementptr i8, ptr %cpu, i32 28
  store i32 %rd_add, ptr %85, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %86 = xor i32 0, %flgn
  %87 = xor i32 %flgs, %flgn
  %overflow = and i32 %87, %86
  %88 = xor i32 %rd, -1
  %89 = icmp ult i32 %88, 1
  %ac0 = zext i1 %89 to i32
  %90 = icmp eq i32 %rd_add, 0
  %az = zext i1 %90 to i32
  %an = lshr i32 %rd_add, 31
  %91 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %93, align 4
  %94 = or i32 %vs_cur, %overflow
  %95 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 256
  store i32 %94, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %99, align 4
  br label %insn_0x000100a2_entry

insn_0x000100a2_entry:                            ; preds = %insn_0x000100a0
  br label %insn_0x000100a2

insn_0x000100a2:                                  ; preds = %insn_0x000100a2_entry
  %100 = getelementptr i8, ptr %cpu, i32 0
  store i32 6, ptr %100, align 4
  br label %insn_0x000100a4_entry

insn_0x000100a4_entry:                            ; preds = %insn_0x000100a2
  br label %insn_0x000100a4

insn_0x000100a4:                                  ; preds = %insn_0x000100a4_entry
  %101 = getelementptr i8, ptr %cpu, i32 44
  %ptr28 = load i32, ptr %101, align 4
  %102 = and i32 %ptr28, 3
  %103 = icmp ne i32 %102, 0
  br i1 %103, label %data_misaligned29, label %data_aligned30, !prof !1

data_misaligned29:                                ; preds = %insn_0x000100a4
  %104 = getelementptr i8, ptr %cpu, i32 188
  store i32 65700, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %106, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65700, i32 %ptr28, i32 65536)
  %107 = getelementptr i8, ptr %cpu, i64 188
  %next_pc228 = load i32, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 188
  %109 = load i32, ptr %108, align 4
  %110 = getelementptr i8, ptr %cpu, i64 296
  %111 = load i8, ptr %110, align 1
  br label %chain_exit

data_aligned30:                                   ; preds = %insn_0x000100a4
  %112 = lshr i32 %ptr28, 12
  %page_index34 = zext i32 %112 to i64
  %page_slot35 = getelementptr ptr, ptr %page_table, i64 %page_index34
  %page36 = load ptr, ptr %page_slot35, align 8
  %page_mapped37 = icmp ne ptr %page36, null
  br i1 %page_mapped37, label %page_wr_fast31, label %page_wr_slow32, !prof !0

page_wr_fast31:                                   ; preds = %data_aligned30
  %113 = and i32 %ptr28, 4095
  %page_offset38 = zext i32 %113 to i64
  %114 = getelementptr i8, ptr %page36, i64 %page_offset38
  store i32 %rd_add, ptr %114, align 4
  br label %page_wr_done33

page_wr_slow32:                                   ; preds = %data_aligned30
  %115 = getelementptr i8, ptr %cpu, i32 188
  store i32 65700, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %117, align 4
  call void @mem_write32(ptr %mem, i32 %ptr28, i32 %rd_add)
  %118 = getelementptr i8, ptr %cpu, i32 296
  %dj41 = load i8, ptr %118, align 1
  %dj_set42 = icmp ne i8 %dj41, 0
  br i1 %dj_set42, label %did_jump_exit39, label %did_jump_cont40, !prof !1

page_wr_done33:                                   ; preds = %did_jump_cont40, %page_wr_fast31
  %cec_pending43 = load i8, ptr %cec_pending_flag, align 1
  %119 = icmp ne i8 %cec_pending43, 0
  br i1 %119, label %cec_check44, label %cec_checked45, !prof !1

did_jump_exit39:                                  ; preds = %page_wr_slow32
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc229 = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

did_jump_cont40:                                  ; preds = %page_wr_slow32
  br label %page_wr_done33

cec_check44:                                      ; preds = %page_wr_done33
  %125 = getelementptr i8, ptr %cpu, i32 188
  store i32 65702, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %127, align 4
  call void @cec_check_pending(ptr %cpu)
  %128 = getelementptr i8, ptr %cpu, i32 296
  %dj48 = load i8, ptr %128, align 1
  %dj_set49 = icmp ne i8 %dj48, 0
  br i1 %dj_set49, label %did_jump_exit46, label %did_jump_cont47, !prof !1

cec_checked45:                                    ; preds = %did_jump_cont47, %page_wr_done33
  br label %insn_0x000100a6_entry

did_jump_exit46:                                  ; preds = %cec_check44
  %129 = getelementptr i8, ptr %cpu, i64 188
  %next_pc230 = load i32, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i64 188
  %131 = load i32, ptr %130, align 4
  %132 = getelementptr i8, ptr %cpu, i64 296
  %133 = load i8, ptr %132, align 1
  br label %chain_exit

did_jump_cont47:                                  ; preds = %cec_check44
  br label %cec_checked45

insn_0x000100a6_entry:                            ; preds = %cec_checked45
  br label %insn_0x000100a6

insn_0x000100a6:                                  ; preds = %insn_0x000100a6_entry
  %diff = sub i32 %rd_add, 6
  %134 = icmp eq i32 %diff, 0
  %az50 = zext i1 %134 to i32
  %flgn51 = lshr i32 %diff, 31
  %flgs52 = lshr i32 %rd_add, 31
  %135 = xor i32 %flgn51, %flgs52
  %136 = xor i32 %flgs52, 0
  %overflow53 = and i32 %136, %135
  %an54 = xor i32 %flgn51, %overflow53
  %137 = icmp ule i32 6, %rd_add
  %ac055 = zext i1 %137 to i32
  %138 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az50, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az50, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an54, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac055, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac055, ptr %142, align 4
  br label %insn_0x000100a8_entry

insn_0x000100a8_entry:                            ; preds = %insn_0x000100a6
  br label %insn_0x000100a8

insn_0x000100a8:                                  ; preds = %insn_0x000100a8_entry
  %cc_false = icmp eq i32 %az50, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x000100a8
  %143 = getelementptr i8, ptr %cpu, i32 188
  store i32 65668, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %144, align 4
  %chain_total = add nuw i32 %chain_packets, 7
  %145 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %145 monotonic, align 4, !range !2
  %146 = icmp ult i32 %chain_total, %chain_budget
  br i1 %146, label %chain_go, label %chain_leave231, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x000100a8
  br label %insn_0x000100aa_entry

insn_0x000100aa_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x000100aa

insn_0x000100aa:                                  ; preds = %insn_0x000100aa_entry
  %147 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %147, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 0
  %148 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %148, align 4
  br label %insn_0x000100ae_entry

insn_0x000100ae_entry:                            ; preds = %insn_0x000100aa
  br label %insn_0x000100ae

insn_0x000100ae:                                  ; preds = %insn_0x000100ae_entry
  %149 = getelementptr i8, ptr %cpu, i32 0
  store i32 2, ptr %149, align 4
  br label %insn_0x000100b0_entry

insn_0x000100b0_entry:                            ; preds = %insn_0x000100ae
  br label %insn_0x000100b0

insn_0x000100b0:                                  ; preds = %insn_0x000100b0_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 61456
  %150 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %150, align 4
  br label %insn_0x000100b4_entry

insn_0x000100b4_entry:                            ; preds = %insn_0x000100b0
  br label %insn_0x000100b4

insn_0x000100b4:                                  ; preds = %insn_0x000100b4_entry
  %151 = and i32 %with_lo, 3
  %152 = icmp ne i32 %151, 0
  br i1 %152, label %data_misaligned56, label %data_aligned57, !prof !1

data_misaligned56:                                ; preds = %insn_0x000100b4
  %153 = getelementptr i8, ptr %cpu, i32 188
  store i32 65716, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %155, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65716, i32 %with_lo, i32 65536)
  %156 = getelementptr i8, ptr %cpu, i64 188
  %next_pc232 = load i32, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i64 188
  %158 = load i32, ptr %157, align 4
  %159 = getelementptr i8, ptr %cpu, i64 296
  %160 = load i8, ptr %159, align 1
  br label %chain_exit

data_aligned57:                                   ; preds = %insn_0x000100b4
  %161 = lshr i32 %with_lo, 12
  %page_index61 = zext i32 %161 to i64
  %page_slot62 = getelementptr ptr, ptr %page_table, i64 %page_index61
  %page63 = load ptr, ptr %page_slot62, align 8
  %page_mapped64 = icmp ne ptr %page63, null
  br i1 %page_mapped64, label %page_wr_fast58, label %page_wr_slow59, !prof !0

page_wr_fast58:                                   ; preds = %data_aligned57
  %162 = and i32 %with_lo, 4095
  %page_offset65 = zext i32 %162 to i64
  %163 = getelementptr i8, ptr %page63, i64 %page_offset65
  store i32 2, ptr %163, align 4
  br label %page_wr_done60

page_wr_slow59:                                   ; preds = %data_aligned57
  %164 = getelementptr i8, ptr %cpu, i32 188
  store i32 65716, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %165, align 4
  %166 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %166, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo, i32 2)
  %167 = getelementptr i8, ptr %cpu, i32 296
  %dj68 = load i8, ptr %167, align 1
  %dj_set69 = icmp ne i8 %dj68, 0
  br i1 %dj_set69, label %did_jump_exit66, label %did_jump_cont67, !prof !1

page_wr_done60:                                   ; preds = %did_jump_cont67, %page_wr_fast58
  %cec_pending70 = load i8, ptr %cec_pending_flag, align 1
  %168 = icmp ne i8 %cec_pending70, 0
  br i1 %168, label %cec_check71, label %cec_checked72, !prof !1

did_jump_exit66:                                  ; preds = %page_wr_slow59
  %169 = getelementptr i8, ptr %cpu, i64 188
  %next_pc233 = load i32, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i64 188
  %171 = load i32, ptr %170, align 4
  %172 = getelementptr i8, ptr %cpu, i64 296
  %173 = load i8, ptr %172, align 1
  br label %chain_exit

did_jump_cont67:                                  ; preds = %page_wr_slow59
  br label %page_wr_done60

cec_check71:                                      ; preds = %page_wr_done60
  %174 = getelementptr i8, ptr %cpu, i32 188
  store i32 65718, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %176, align 4
  call void @cec_check_pending(ptr %cpu)
  %177 = getelementptr i8, ptr %cpu, i32 296
  %dj75 = load i8, ptr %177, align 1
  %dj_set76 = icmp ne i8 %dj75, 0
  br i1 %dj_set76, label %did_jump_exit73, label %did_jump_cont74, !prof !1

cec_checked72:                                    ; preds = %did_jump_cont74, %page_wr_done60
  br label %insn_0x000100b6_entry

did_jump_exit73:                                  ; preds = %cec_check71
  %178 = getelementptr i8, ptr %cpu, i64 188
  %next_pc234 = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 188
  %180 = load i32, ptr %179, align 4
  %181 = getelementptr i8, ptr %cpu, i64 296
  %182 = load i8, ptr %181, align 1
  br label %chain_exit

did_jump_cont74:                                  ; preds = %cec_check71
  br label %cec_checked72

insn_0x000100b6_entry:                            ; preds = %cec_checked72
  br label %insn_0x000100b6

insn_0x000100b6:                                  ; preds = %insn_0x000100b6_entry
  %183 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %183, align 4
  %184 = and i32 %fp, 3
  %185 = icmp ne i32 %184, 0
  br i1 %185, label %data_misaligned77, label %data_aligned78, !prof !1

data_misaligned77:                                ; preds = %insn_0x000100b6
  %186 = getelementptr i8, ptr %cpu, i32 188
  store i32 65718, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %188, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65718, i32 %fp, i32 0)
  %189 = getelementptr i8, ptr %cpu, i64 188
  %next_pc235 = load i32, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i64 188
  %191 = load i32, ptr %190, align 4
  %192 = getelementptr i8, ptr %cpu, i64 296
  %193 = load i8, ptr %192, align 1
  br label %chain_exit

data_aligned78:                                   ; preds = %insn_0x000100b6
  %194 = lshr i32 %fp, 12
  %page_index79 = zext i32 %194 to i64
  %page_slot80 = getelementptr ptr, ptr %page_table, i64 %page_index79
  %page81 = load ptr, ptr %page_slot80, align 8
  %page_mapped82 = icmp ne ptr %page81, null
  br i1 %page_mapped82, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned78
  %195 = and i32 %fp, 4095
  %page_offset83 = zext i32 %195 to i64
  %196 = getelementptr i8, ptr %page81, i64 %page_offset83
  %page_val = load i32, ptr %196, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned78
  %197 = getelementptr i8, ptr %cpu, i32 188
  store i32 65718, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %199, align 4
  %200 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %201 = getelementptr i8, ptr %cpu, i32 296
  %dj86 = load i8, ptr %201, align 1
  %dj_set87 = icmp ne i8 %dj86, 0
  br i1 %dj_set87, label %did_jump_exit84, label %did_jump_cont85, !prof !1

page_done:                                        ; preds = %did_jump_cont85, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %200, %did_jump_cont85 ]
  %sp1 = add i32 %fp, 4
  %202 = and i32 %sp1, 3
  %203 = icmp ne i32 %202, 0
  br i1 %203, label %data_misaligned88, label %data_aligned89, !prof !1

did_jump_exit84:                                  ; preds = %page_slow
  %204 = getelementptr i8, ptr %cpu, i64 188
  %next_pc236 = load i32, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i64 188
  %206 = load i32, ptr %205, align 4
  %207 = getelementptr i8, ptr %cpu, i64 296
  %208 = load i8, ptr %207, align 1
  br label %chain_exit

did_jump_cont85:                                  ; preds = %page_slow
  br label %page_done

data_misaligned88:                                ; preds = %page_done
  %209 = getelementptr i8, ptr %cpu, i32 188
  store i32 65718, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %210, align 4
  %211 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %211, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65718, i32 %sp1, i32 0)
  %212 = getelementptr i8, ptr %cpu, i64 188
  %next_pc237 = load i32, ptr %212, align 4
  %213 = getelementptr i8, ptr %cpu, i64 188
  %214 = load i32, ptr %213, align 4
  %215 = getelementptr i8, ptr %cpu, i64 296
  %216 = load i8, ptr %215, align 1
  br label %chain_exit

data_aligned89:                                   ; preds = %page_done
  %217 = lshr i32 %sp1, 12
  %page_index93 = zext i32 %217 to i64
  %page_slot94 = getelementptr ptr, ptr %page_table, i64 %page_index93
  %page95 = load ptr, ptr %page_slot94, align 8
  %page_mapped96 = icmp ne ptr %page95, null
  br i1 %page_mapped96, label %page_fast90, label %page_slow91, !prof !0

page_fast90:                                      ; preds = %data_aligned89
  %218 = and i32 %sp1, 4095
  %page_offset97 = zext i32 %218 to i64
  %219 = getelementptr i8, ptr %page95, i64 %page_offset97
  %page_val98 = load i32, ptr %219, align 4
  br label %page_done92

page_slow91:                                      ; preds = %data_aligned89
  %220 = getelementptr i8, ptr %cpu, i32 188
  store i32 65718, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %221, align 4
  %222 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %222, align 4
  %223 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %224 = getelementptr i8, ptr %cpu, i32 296
  %dj101 = load i8, ptr %224, align 1
  %dj_set102 = icmp ne i8 %dj101, 0
  br i1 %dj_set102, label %did_jump_exit99, label %did_jump_cont100, !prof !1

page_done92:                                      ; preds = %did_jump_cont100, %page_fast90
  %mem_val103 = phi i32 [ %page_val98, %page_fast90 ], [ %223, %did_jump_cont100 ]
  %sp2 = add i32 %sp1, 4
  %225 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %225, align 4
  %226 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val103, ptr %226, align 4
  %227 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %227, align 4
  br label %insn_0x000100ba_entry

did_jump_exit99:                                  ; preds = %page_slow91
  %228 = getelementptr i8, ptr %cpu, i64 188
  %next_pc238 = load i32, ptr %228, align 4
  %229 = getelementptr i8, ptr %cpu, i64 188
  %230 = load i32, ptr %229, align 4
  %231 = getelementptr i8, ptr %cpu, i64 296
  %232 = load i8, ptr %231, align 1
  br label %chain_exit

did_jump_cont100:                                 ; preds = %page_slow91
  br label %page_done92

insn_0x000100ba_entry:                            ; preds = %page_done92
  br label %insn_0x000100ba

insn_0x000100ba:                                  ; preds = %insn_0x000100ba_entry
  %233 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %233, align 4
  br label %insn_0x000100bc_entry

insn_0x000100bc_entry:                            ; preds = %insn_0x000100ba
  br label %insn_0x000100bc

insn_0x000100bc:                                  ; preds = %insn_0x000100bc_entry
  %234 = and i32 %sp2, 3
  %235 = icmp ne i32 %234, 0
  br i1 %235, label %data_misaligned104, label %data_aligned105, !prof !1

data_misaligned104:                               ; preds = %insn_0x000100bc
  %236 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %236, align 4
  %237 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %237, align 4
  %238 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %238, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp2, i32 0)
  %239 = getelementptr i8, ptr %cpu, i64 188
  %next_pc239 = load i32, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i64 188
  %241 = load i32, ptr %240, align 4
  %242 = getelementptr i8, ptr %cpu, i64 296
  %243 = load i8, ptr %242, align 1
  br label %chain_exit

data_aligned105:                                  ; preds = %insn_0x000100bc
  %244 = lshr i32 %sp2, 12
  %page_index109 = zext i32 %244 to i64
  %page_slot110 = getelementptr ptr, ptr %page_table, i64 %page_index109
  %page111 = load ptr, ptr %page_slot110, align 8
  %page_mapped112 = icmp ne ptr %page111, null
  br i1 %page_mapped112, label %page_fast106, label %page_slow107, !prof !0

page_fast106:                                     ; preds = %data_aligned105
  %245 = and i32 %sp2, 4095
  %page_offset113 = zext i32 %245 to i64
  %246 = getelementptr i8, ptr %page111, i64 %page_offset113
  %page_val114 = load i32, ptr %246, align 4
  br label %page_done108

page_slow107:                                     ; preds = %data_aligned105
  %247 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %247, align 4
  %248 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %248, align 4
  %249 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %249, align 4
  %250 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %251 = getelementptr i8, ptr %cpu, i32 296
  %dj117 = load i8, ptr %251, align 1
  %dj_set118 = icmp ne i8 %dj117, 0
  br i1 %dj_set118, label %did_jump_exit115, label %did_jump_cont116, !prof !1

page_done108:                                     ; preds = %did_jump_cont116, %page_fast106
  %mem_val119 = phi i32 [ %page_val114, %page_fast106 ], [ %250, %did_jump_cont116 ]
  %252 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val119, ptr %252, align 4
  %sp_inc = add i32 %sp2, 4
  %253 = and i32 %sp_inc, 3
  %254 = icmp ne i32 %253, 0
  br i1 %254, label %data_misaligned120, label %data_aligned121, !prof !1

did_jump_exit115:                                 ; preds = %page_slow107
  %255 = getelementptr i8, ptr %cpu, i64 188
  %next_pc240 = load i32, ptr %255, align 4
  %256 = getelementptr i8, ptr %cpu, i64 188
  %257 = load i32, ptr %256, align 4
  %258 = getelementptr i8, ptr %cpu, i64 296
  %259 = load i8, ptr %258, align 1
  br label %chain_exit

did_jump_cont116:                                 ; preds = %page_slow107
  br label %page_done108

data_misaligned120:                               ; preds = %page_done108
  %260 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %260, align 4
  %261 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %261, align 4
  %262 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %262, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc, i32 0)
  %263 = getelementptr i8, ptr %cpu, i64 188
  %next_pc241 = load i32, ptr %263, align 4
  %264 = getelementptr i8, ptr %cpu, i64 188
  %265 = load i32, ptr %264, align 4
  %266 = getelementptr i8, ptr %cpu, i64 296
  %267 = load i8, ptr %266, align 1
  br label %chain_exit

data_aligned121:                                  ; preds = %page_done108
  %268 = lshr i32 %sp_inc, 12
  %page_index125 = zext i32 %268 to i64
  %page_slot126 = getelementptr ptr, ptr %page_table, i64 %page_index125
  %page127 = load ptr, ptr %page_slot126, align 8
  %page_mapped128 = icmp ne ptr %page127, null
  br i1 %page_mapped128, label %page_fast122, label %page_slow123, !prof !0

page_fast122:                                     ; preds = %data_aligned121
  %269 = and i32 %sp_inc, 4095
  %page_offset129 = zext i32 %269 to i64
  %270 = getelementptr i8, ptr %page127, i64 %page_offset129
  %page_val130 = load i32, ptr %270, align 4
  br label %page_done124

page_slow123:                                     ; preds = %data_aligned121
  %271 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %271, align 4
  %272 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %272, align 4
  %273 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %273, align 4
  %274 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %275 = getelementptr i8, ptr %cpu, i32 296
  %dj133 = load i8, ptr %275, align 1
  %dj_set134 = icmp ne i8 %dj133, 0
  br i1 %dj_set134, label %did_jump_exit131, label %did_jump_cont132, !prof !1

page_done124:                                     ; preds = %did_jump_cont132, %page_fast122
  %mem_val135 = phi i32 [ %page_val130, %page_fast122 ], [ %274, %did_jump_cont132 ]
  %276 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val135, ptr %276, align 4
  %sp_inc136 = add i32 %sp_inc, 4
  %277 = and i32 %sp_inc136, 3
  %278 = icmp ne i32 %277, 0
  br i1 %278, label %data_misaligned137, label %data_aligned138, !prof !1

did_jump_exit131:                                 ; preds = %page_slow123
  %279 = getelementptr i8, ptr %cpu, i64 188
  %next_pc242 = load i32, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i64 188
  %281 = load i32, ptr %280, align 4
  %282 = getelementptr i8, ptr %cpu, i64 296
  %283 = load i8, ptr %282, align 1
  br label %chain_exit

did_jump_cont132:                                 ; preds = %page_slow123
  br label %page_done124

data_misaligned137:                               ; preds = %page_done124
  %284 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %284, align 4
  %285 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %285, align 4
  %286 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %286, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc136, i32 0)
  %287 = getelementptr i8, ptr %cpu, i64 188
  %next_pc243 = load i32, ptr %287, align 4
  %288 = getelementptr i8, ptr %cpu, i64 188
  %289 = load i32, ptr %288, align 4
  %290 = getelementptr i8, ptr %cpu, i64 296
  %291 = load i8, ptr %290, align 1
  br label %chain_exit

data_aligned138:                                  ; preds = %page_done124
  %292 = lshr i32 %sp_inc136, 12
  %page_index142 = zext i32 %292 to i64
  %page_slot143 = getelementptr ptr, ptr %page_table, i64 %page_index142
  %page144 = load ptr, ptr %page_slot143, align 8
  %page_mapped145 = icmp ne ptr %page144, null
  br i1 %page_mapped145, label %page_fast139, label %page_slow140, !prof !0

page_fast139:                                     ; preds = %data_aligned138
  %293 = and i32 %sp_inc136, 4095
  %page_offset146 = zext i32 %293 to i64
  %294 = getelementptr i8, ptr %page144, i64 %page_offset146
  %page_val147 = load i32, ptr %294, align 4
  br label %page_done141

page_slow140:                                     ; preds = %data_aligned138
  %295 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %295, align 4
  %296 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %296, align 4
  %297 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %297, align 4
  %298 = call i32 @mem_read32(ptr %mem, i32 %sp_inc136)
  %299 = getelementptr i8, ptr %cpu, i32 296
  %dj150 = load i8, ptr %299, align 1
  %dj_set151 = icmp ne i8 %dj150, 0
  br i1 %dj_set151, label %did_jump_exit148, label %did_jump_cont149, !prof !1

page_done141:                                     ; preds = %did_jump_cont149, %page_fast139
  %mem_val152 = phi i32 [ %page_val147, %page_fast139 ], [ %298, %did_jump_cont149 ]
  %300 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val152, ptr %300, align 4
  %sp_inc153 = add i32 %sp_inc136, 4
  %301 = and i32 %sp_inc153, 3
  %302 = icmp ne i32 %301, 0
  br i1 %302, label %data_misaligned154, label %data_aligned155, !prof !1

did_jump_exit148:                                 ; preds = %page_slow140
  %303 = getelementptr i8, ptr %cpu, i64 188
  %next_pc244 = load i32, ptr %303, align 4
  %304 = getelementptr i8, ptr %cpu, i64 188
  %305 = load i32, ptr %304, align 4
  %306 = getelementptr i8, ptr %cpu, i64 296
  %307 = load i8, ptr %306, align 1
  br label %chain_exit

did_jump_cont149:                                 ; preds = %page_slow140
  br label %page_done141

data_misaligned154:                               ; preds = %page_done141
  %308 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %308, align 4
  %309 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %309, align 4
  %310 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %310, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc153, i32 0)
  %311 = getelementptr i8, ptr %cpu, i64 188
  %next_pc245 = load i32, ptr %311, align 4
  %312 = getelementptr i8, ptr %cpu, i64 188
  %313 = load i32, ptr %312, align 4
  %314 = getelementptr i8, ptr %cpu, i64 296
  %315 = load i8, ptr %314, align 1
  br label %chain_exit

data_aligned155:                                  ; preds = %page_done141
  %316 = lshr i32 %sp_inc153, 12
  %page_index159 = zext i32 %316 to i64
  %page_slot160 = getelementptr ptr, ptr %page_table, i64 %page_index159
  %page161 = load ptr, ptr %page_slot160, align 8
  %page_mapped162 = icmp ne ptr %page161, null
  br i1 %page_mapped162, label %page_fast156, label %page_slow157, !prof !0

page_fast156:                                     ; preds = %data_aligned155
  %317 = and i32 %sp_inc153, 4095
  %page_offset163 = zext i32 %317 to i64
  %318 = getelementptr i8, ptr %page161, i64 %page_offset163
  %page_val164 = load i32, ptr %318, align 4
  br label %page_done158

page_slow157:                                     ; preds = %data_aligned155
  %319 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %319, align 4
  %320 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %320, align 4
  %321 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %321, align 4
  %322 = call i32 @mem_read32(ptr %mem, i32 %sp_inc153)
  %323 = getelementptr i8, ptr %cpu, i32 296
  %dj167 = load i8, ptr %323, align 1
  %dj_set168 = icmp ne i8 %dj167, 0
  br i1 %dj_set168, label %did_jump_exit165, label %did_jump_cont166, !prof !1

page_done158:                                     ; preds = %did_jump_cont166, %page_fast156
  %mem_val169 = phi i32 [ %page_val164, %page_fast156 ], [ %322, %did_jump_cont166 ]
  %324 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val169, ptr %324, align 4
  %sp_inc170 = add i32 %sp_inc153, 4
  %325 = and i32 %sp_inc170, 3
  %326 = icmp ne i32 %325, 0
  br i1 %326, label %data_misaligned171, label %data_aligned172, !prof !1

did_jump_exit165:                                 ; preds = %page_slow157
  %327 = getelementptr i8, ptr %cpu, i64 188
  %next_pc246 = load i32, ptr %327, align 4
  %328 = getelementptr i8, ptr %cpu, i64 188
  %329 = load i32, ptr %328, align 4
  %330 = getelementptr i8, ptr %cpu, i64 296
  %331 = load i8, ptr %330, align 1
  br label %chain_exit

did_jump_cont166:                                 ; preds = %page_slow157
  br label %page_done158

data_misaligned171:                               ; preds = %page_done158
  %332 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %332, align 4
  %333 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %333, align 4
  %334 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %334, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc170, i32 0)
  %335 = getelementptr i8, ptr %cpu, i64 188
  %next_pc247 = load i32, ptr %335, align 4
  %336 = getelementptr i8, ptr %cpu, i64 188
  %337 = load i32, ptr %336, align 4
  %338 = getelementptr i8, ptr %cpu, i64 296
  %339 = load i8, ptr %338, align 1
  br label %chain_exit

data_aligned172:                                  ; preds = %page_done158
  %340 = lshr i32 %sp_inc170, 12
  %page_index176 = zext i32 %340 to i64
  %page_slot177 = getelementptr ptr, ptr %page_table, i64 %page_index176
  %page178 = load ptr, ptr %page_slot177, align 8
  %page_mapped179 = icmp ne ptr %page178, null
  br i1 %page_mapped179, label %page_fast173, label %page_slow174, !prof !0

page_fast173:                                     ; preds = %data_aligned172
  %341 = and i32 %sp_inc170, 4095
  %page_offset180 = zext i32 %341 to i64
  %342 = getelementptr i8, ptr %page178, i64 %page_offset180
  %page_val181 = load i32, ptr %342, align 4
  br label %page_done175

page_slow174:                                     ; preds = %data_aligned172
  %343 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %343, align 4
  %344 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %344, align 4
  %345 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %345, align 4
  %346 = call i32 @mem_read32(ptr %mem, i32 %sp_inc170)
  %347 = getelementptr i8, ptr %cpu, i32 296
  %dj184 = load i8, ptr %347, align 1
  %dj_set185 = icmp ne i8 %dj184, 0
  br i1 %dj_set185, label %did_jump_exit182, label %did_jump_cont183, !prof !1

page_done175:                                     ; preds = %did_jump_cont183, %page_fast173
  %mem_val186 = phi i32 [ %page_val181, %page_fast173 ], [ %346, %did_jump_cont183 ]
  %348 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val186, ptr %348, align 4
  %sp_inc187 = add i32 %sp_inc170, 4
  %349 = and i32 %sp_inc187, 3
  %350 = icmp ne i32 %349, 0
  br i1 %350, label %data_misaligned188, label %data_aligned189, !prof !1

did_jump_exit182:                                 ; preds = %page_slow174
  %351 = getelementptr i8, ptr %cpu, i64 188
  %next_pc248 = load i32, ptr %351, align 4
  %352 = getelementptr i8, ptr %cpu, i64 188
  %353 = load i32, ptr %352, align 4
  %354 = getelementptr i8, ptr %cpu, i64 296
  %355 = load i8, ptr %354, align 1
  br label %chain_exit

did_jump_cont183:                                 ; preds = %page_slow174
  br label %page_done175

data_misaligned188:                               ; preds = %page_done175
  %356 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %356, align 4
  %357 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %357, align 4
  %358 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %358, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc187, i32 0)
  %359 = getelementptr i8, ptr %cpu, i64 188
  %next_pc249 = load i32, ptr %359, align 4
  %360 = getelementptr i8, ptr %cpu, i64 188
  %361 = load i32, ptr %360, align 4
  %362 = getelementptr i8, ptr %cpu, i64 296
  %363 = load i8, ptr %362, align 1
  br label %chain_exit

data_aligned189:                                  ; preds = %page_done175
  %364 = lshr i32 %sp_inc187, 12
  %page_index193 = zext i32 %364 to i64
  %page_slot194 = getelementptr ptr, ptr %page_table, i64 %page_index193
  %page195 = load ptr, ptr %page_slot194, align 8
  %page_mapped196 = icmp ne ptr %page195, null
  br i1 %page_mapped196, label %page_fast190, label %page_slow191, !prof !0

page_fast190:                                     ; preds = %data_aligned189
  %365 = and i32 %sp_inc187, 4095
  %page_offset197 = zext i32 %365 to i64
  %366 = getelementptr i8, ptr %page195, i64 %page_offset197
  %page_val198 = load i32, ptr %366, align 4
  br label %page_done192

page_slow191:                                     ; preds = %data_aligned189
  %367 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %367, align 4
  %368 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %368, align 4
  %369 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %369, align 4
  %370 = call i32 @mem_read32(ptr %mem, i32 %sp_inc187)
  %371 = getelementptr i8, ptr %cpu, i32 296
  %dj201 = load i8, ptr %371, align 1
  %dj_set202 = icmp ne i8 %dj201, 0
  br i1 %dj_set202, label %did_jump_exit199, label %did_jump_cont200, !prof !1

page_done192:                                     ; preds = %did_jump_cont200, %page_fast190
  %mem_val203 = phi i32 [ %page_val198, %page_fast190 ], [ %370, %did_jump_cont200 ]
  %372 = getelementptr i8, ptr %cpu, i32 20
  store i32 %mem_val203, ptr %372, align 4
  %sp_inc204 = add i32 %sp_inc187, 4
  %373 = and i32 %sp_inc204, 3
  %374 = icmp ne i32 %373, 0
  br i1 %374, label %data_misaligned205, label %data_aligned206, !prof !1

did_jump_exit199:                                 ; preds = %page_slow191
  %375 = getelementptr i8, ptr %cpu, i64 188
  %next_pc250 = load i32, ptr %375, align 4
  %376 = getelementptr i8, ptr %cpu, i64 188
  %377 = load i32, ptr %376, align 4
  %378 = getelementptr i8, ptr %cpu, i64 296
  %379 = load i8, ptr %378, align 1
  br label %chain_exit

did_jump_cont200:                                 ; preds = %page_slow191
  br label %page_done192

data_misaligned205:                               ; preds = %page_done192
  %380 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %380, align 4
  %381 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %381, align 4
  %382 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %382, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65724, i32 %sp_inc204, i32 0)
  %383 = getelementptr i8, ptr %cpu, i64 188
  %next_pc251 = load i32, ptr %383, align 4
  %384 = getelementptr i8, ptr %cpu, i64 188
  %385 = load i32, ptr %384, align 4
  %386 = getelementptr i8, ptr %cpu, i64 296
  %387 = load i8, ptr %386, align 1
  br label %chain_exit

data_aligned206:                                  ; preds = %page_done192
  %388 = lshr i32 %sp_inc204, 12
  %page_index210 = zext i32 %388 to i64
  %page_slot211 = getelementptr ptr, ptr %page_table, i64 %page_index210
  %page212 = load ptr, ptr %page_slot211, align 8
  %page_mapped213 = icmp ne ptr %page212, null
  br i1 %page_mapped213, label %page_fast207, label %page_slow208, !prof !0

page_fast207:                                     ; preds = %data_aligned206
  %389 = and i32 %sp_inc204, 4095
  %page_offset214 = zext i32 %389 to i64
  %390 = getelementptr i8, ptr %page212, i64 %page_offset214
  %page_val215 = load i32, ptr %390, align 4
  br label %page_done209

page_slow208:                                     ; preds = %data_aligned206
  %391 = getelementptr i8, ptr %cpu, i32 188
  store i32 65724, ptr %391, align 4
  %392 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %392, align 4
  %393 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %393, align 4
  %394 = call i32 @mem_read32(ptr %mem, i32 %sp_inc204)
  %395 = getelementptr i8, ptr %cpu, i32 296
  %dj218 = load i8, ptr %395, align 1
  %dj_set219 = icmp ne i8 %dj218, 0
  br i1 %dj_set219, label %did_jump_exit216, label %did_jump_cont217, !prof !1

page_done209:                                     ; preds = %did_jump_cont217, %page_fast207
  %mem_val220 = phi i32 [ %page_val215, %page_fast207 ], [ %394, %did_jump_cont217 ]
  %396 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val220, ptr %396, align 4
  %sp_inc221 = add i32 %sp_inc204, 4
  %397 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc221, ptr %397, align 4
  br label %insn_0x000100be_entry

did_jump_exit216:                                 ; preds = %page_slow208
  %398 = getelementptr i8, ptr %cpu, i64 188
  %next_pc252 = load i32, ptr %398, align 4
  %399 = getelementptr i8, ptr %cpu, i64 188
  %400 = load i32, ptr %399, align 4
  %401 = getelementptr i8, ptr %cpu, i64 296
  %402 = load i8, ptr %401, align 1
  br label %chain_exit

did_jump_cont217:                                 ; preds = %page_slow208
  br label %page_done209

insn_0x000100be_entry:                            ; preds = %page_done209
  br label %insn_0x000100be

insn_0x000100be:                                  ; preds = %insn_0x000100be_entry
  %lsb = and i32 %mem_val103, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x000100be
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x000100be
  %403 = getelementptr i8, ptr %cpu, i32 188
  store i32 65726, ptr %403, align 4
  %404 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %404, align 4
  %405 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %405, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %406 = getelementptr i8, ptr %cpu, i64 188
  %next_pc253 = load i32, ptr %406, align 4
  %407 = getelementptr i8, ptr %cpu, i64 188
  %408 = load i32, ptr %407, align 4
  %409 = getelementptr i8, ptr %cpu, i64 296
  %410 = load i8, ptr %409, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %411 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %411, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525344
  %412 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %412, align 4
  %413 = icmp eq i32 %slot_pc, 65668
  br i1 %413, label %chain_hit, label %chain_leave231, !prof !0

chain_leave231:                                   ; preds = %chain_go, %brcc_taken
  %414 = getelementptr i8, ptr %cpu, i64 188
  store i32 65668, ptr %414, align 4
  %415 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %415, align 4
  %416 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %416, align 4
  %417 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %417, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %418 = getelementptr i8, ptr %cpu, i64 188
  store i32 65668, ptr %418, align 4
  %419 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %419, align 4
  %420 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %420, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit216, %data_misaligned205, %did_jump_exit199, %data_misaligned188, %did_jump_exit182, %data_misaligned171, %did_jump_exit165, %data_misaligned154, %did_jump_exit148, %data_misaligned137, %did_jump_exit131, %data_misaligned120, %did_jump_exit115, %data_misaligned104, %did_jump_exit99, %data_misaligned88, %did_jump_exit84, %data_misaligned77, %did_jump_exit73, %did_jump_exit66, %data_misaligned56, %did_jump_exit46, %did_jump_exit39, %data_misaligned29, %did_jump_exit24, %did_jump_exit17, %data_misaligned7, %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc254 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc223, %did_jump_exit ], [ %next_pc224, %did_jump_exit1 ], [ %next_pc225, %data_misaligned7 ], [ %next_pc226, %did_jump_exit17 ], [ %next_pc227, %did_jump_exit24 ], [ %next_pc228, %data_misaligned29 ], [ %next_pc229, %did_jump_exit39 ], [ %next_pc230, %did_jump_exit46 ], [ %next_pc232, %data_misaligned56 ], [ %next_pc233, %did_jump_exit66 ], [ %next_pc234, %did_jump_exit73 ], [ %next_pc235, %data_misaligned77 ], [ %next_pc236, %did_jump_exit84 ], [ %next_pc237, %data_misaligned88 ], [ %next_pc238, %did_jump_exit99 ], [ %next_pc239, %data_misaligned104 ], [ %next_pc240, %did_jump_exit115 ], [ %next_pc241, %data_misaligned120 ], [ %next_pc242, %did_jump_exit131 ], [ %next_pc243, %data_misaligned137 ], [ %next_pc244, %did_jump_exit148 ], [ %next_pc245, %data_misaligned154 ], [ %next_pc246, %did_jump_exit165 ], [ %next_pc247, %data_misaligned171 ], [ %next_pc248, %did_jump_exit182 ], [ %next_pc249, %data_misaligned188 ], [ %next_pc250, %did_jump_exit199 ], [ %next_pc251, %data_misaligned205 ], [ %next_pc252, %did_jump_exit216 ], [ %mem_val103, %jump_aligned ], [ %next_pc253, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit17 ], [ 2, %did_jump_exit24 ], [ 5, %data_misaligned29 ], [ 5, %did_jump_exit39 ], [ 5, %did_jump_exit46 ], [ 11, %data_misaligned56 ], [ 11, %did_jump_exit66 ], [ 11, %did_jump_exit73 ], [ 12, %data_misaligned77 ], [ 12, %did_jump_exit84 ], [ 12, %data_misaligned88 ], [ 12, %did_jump_exit99 ], [ 14, %data_misaligned104 ], [ 14, %did_jump_exit115 ], [ 14, %data_misaligned120 ], [ 14, %did_jump_exit131 ], [ 14, %data_misaligned137 ], [ 14, %did_jump_exit148 ], [ 14, %data_misaligned154 ], [ 14, %did_jump_exit165 ], [ 14, %data_misaligned171 ], [ 14, %did_jump_exit182 ], [ 14, %data_misaligned188 ], [ 14, %did_jump_exit199 ], [ 14, %data_misaligned205 ], [ 14, %did_jump_exit216 ], [ 15, %jump_aligned ], [ 15, %jump_misalign ]
  %tail = phi i32 [ %23, %data_misaligned ], [ %37, %did_jump_exit ], [ %46, %did_jump_exit1 ], [ %58, %data_misaligned7 ], [ %72, %did_jump_exit17 ], [ %81, %did_jump_exit24 ], [ %109, %data_misaligned29 ], [ %122, %did_jump_exit39 ], [ %131, %did_jump_exit46 ], [ %158, %data_misaligned56 ], [ %171, %did_jump_exit66 ], [ %180, %did_jump_exit73 ], [ %191, %data_misaligned77 ], [ %206, %did_jump_exit84 ], [ %214, %data_misaligned88 ], [ %230, %did_jump_exit99 ], [ %241, %data_misaligned104 ], [ %257, %did_jump_exit115 ], [ %265, %data_misaligned120 ], [ %281, %did_jump_exit131 ], [ %289, %data_misaligned137 ], [ %305, %did_jump_exit148 ], [ %313, %data_misaligned154 ], [ %329, %did_jump_exit165 ], [ %337, %data_misaligned171 ], [ %353, %did_jump_exit182 ], [ %361, %data_misaligned188 ], [ %377, %did_jump_exit199 ], [ %385, %data_misaligned205 ], [ %400, %did_jump_exit216 ], [ %mem_val103, %jump_aligned ], [ %408, %jump_misalign ]
  %tail255 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit17 ], [ 2, %did_jump_exit24 ], [ 2, %data_misaligned29 ], [ 2, %did_jump_exit39 ], [ 2, %did_jump_exit46 ], [ 2, %data_misaligned56 ], [ 2, %did_jump_exit66 ], [ 2, %did_jump_exit73 ], [ 4, %data_misaligned77 ], [ 4, %did_jump_exit84 ], [ 4, %data_misaligned88 ], [ 4, %did_jump_exit99 ], [ 2, %data_misaligned104 ], [ 2, %did_jump_exit115 ], [ 2, %data_misaligned120 ], [ 2, %did_jump_exit131 ], [ 2, %data_misaligned137 ], [ 2, %did_jump_exit148 ], [ 2, %data_misaligned154 ], [ 2, %did_jump_exit165 ], [ 2, %data_misaligned171 ], [ 2, %did_jump_exit182 ], [ 2, %data_misaligned188 ], [ 2, %did_jump_exit199 ], [ 2, %data_misaligned205 ], [ 2, %did_jump_exit216 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail256 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit17 ], [ 2, %did_jump_exit24 ], [ 5, %data_misaligned29 ], [ 5, %did_jump_exit39 ], [ 5, %did_jump_exit46 ], [ 11, %data_misaligned56 ], [ 11, %did_jump_exit66 ], [ 11, %did_jump_exit73 ], [ 12, %data_misaligned77 ], [ 12, %did_jump_exit84 ], [ 12, %data_misaligned88 ], [ 12, %did_jump_exit99 ], [ 14, %data_misaligned104 ], [ 14, %did_jump_exit115 ], [ 14, %data_misaligned120 ], [ 14, %did_jump_exit131 ], [ 14, %data_misaligned137 ], [ 14, %did_jump_exit148 ], [ 14, %data_misaligned154 ], [ 14, %did_jump_exit165 ], [ 14, %data_misaligned171 ], [ 14, %did_jump_exit182 ], [ 14, %data_misaligned188 ], [ 14, %did_jump_exit199 ], [ 14, %data_misaligned205 ], [ 14, %did_jump_exit216 ], [ 15, %jump_aligned ], [ 15, %jump_misalign ]
  %tail257 = phi i8 [ %25, %data_misaligned ], [ %39, %did_jump_exit ], [ %48, %did_jump_exit1 ], [ %60, %data_misaligned7 ], [ %74, %did_jump_exit17 ], [ %83, %did_jump_exit24 ], [ %111, %data_misaligned29 ], [ %124, %did_jump_exit39 ], [ %133, %did_jump_exit46 ], [ %160, %data_misaligned56 ], [ %173, %did_jump_exit66 ], [ %182, %did_jump_exit73 ], [ %193, %data_misaligned77 ], [ %208, %did_jump_exit84 ], [ %216, %data_misaligned88 ], [ %232, %did_jump_exit99 ], [ %243, %data_misaligned104 ], [ %259, %did_jump_exit115 ], [ %267, %data_misaligned120 ], [ %283, %did_jump_exit131 ], [ %291, %data_misaligned137 ], [ %307, %did_jump_exit148 ], [ %315, %data_misaligned154 ], [ %331, %did_jump_exit165 ], [ %339, %data_misaligned171 ], [ %355, %did_jump_exit182 ], [ %363, %data_misaligned188 ], [ %379, %did_jump_exit199 ], [ %387, %data_misaligned205 ], [ %402, %did_jump_exit216 ], [ 1, %jump_aligned ], [ %410, %jump_misalign ]
  %421 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets259 = load i32, ptr %421, align 4
  %chain_total260 = add nuw i32 %chain_packets259, %packets
  %422 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget261 = load atomic i32, ptr %422 monotonic, align 4, !range !2
  %423 = icmp ult i32 %chain_total260, %chain_budget261
  br i1 %423, label %chain_lookup, label %chain_leave258, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %424 = lshr i32 %next_pc254, 1
  %425 = and i32 %424, 65535
  %426 = zext i32 %425 to i64
  %427 = mul i64 %426, 16
  %chain_slot262 = getelementptr i8, ptr %chain_table, i64 %427
  %428 = getelementptr i8, ptr %chain_slot262, i64 0
  %slot_pc263 = load i32, ptr %428, align 4
  %429 = icmp eq i32 %slot_pc263, %next_pc254
  br i1 %429, label %chain_hit264, label %chain_leave258, !prof !0

chain_leave258:                                   ; preds = %chain_lookup, %chain_exit
  %430 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %430, align 4
  %431 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail255, ptr %431, align 4
  %432 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail256, ptr %432, align 4
  %433 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail257, ptr %433, align 1
  ret void

chain_hit264:                                     ; preds = %chain_lookup
  %434 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc254, ptr %434, align 4
  %435 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total260, ptr %435, align 4
  %436 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %436, align 1
  %437 = getelementptr i8, ptr %chain_slot262, i64 8
  %chain_fn265 = load ptr, ptr %437, align 8
  musttail call swifttailcc void %chain_fn265(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
