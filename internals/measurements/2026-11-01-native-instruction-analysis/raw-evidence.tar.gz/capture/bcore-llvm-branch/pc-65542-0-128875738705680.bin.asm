
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65542-0-128875738705680.bin:     file format binary


Disassembly of section .data:

0000753638a02f10 <.data>:
    753638a02f10:	50                   	push   rax
    753638a02f11:	b8 ef ff fe ff       	mov    eax,0xfffeffef
    753638a02f16:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    753638a02f1d:	01 c1                	add    ecx,eax
    753638a02f1f:	83 f9 f4             	cmp    ecx,0xfffffff4
    753638a02f22:	0f 87 b5 12 00 18    	ja     0x753650a041dd
    753638a02f28:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    753638a02f2f:	83 f8 f4             	cmp    eax,0xfffffff4
    753638a02f32:	0f 87 a5 12 00 18    	ja     0x753650a041dd
    753638a02f38:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    753638a02f3f:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    753638a02f46:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753638a02f4d:	41 c7 45 20 04 00 00 	mov    DWORD PTR [r13+0x20],0x1000004
    753638a02f54:	01 
    753638a02f55:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    753638a02f59:	48 8b 80 00 80 00 00 	mov    rax,QWORD PTR [rax+0x8000]
    753638a02f60:	48 85 c0             	test   rax,rax
    753638a02f63:	0f 84 80 12 00 18    	je     0x753650a041e9
    753638a02f69:	89 50 04             	mov    DWORD PTR [rax+0x4],edx
    753638a02f6c:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    753638a02f70:	0f 85 b8 12 00 18    	jne    0x753650a0422e
    753638a02f76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    753638a02f7d:	10 00 01 00 
    753638a02f81:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a02f88:	83 c0 04             	add    eax,0x4
    753638a02f8b:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a02f92:	39 c8                	cmp    eax,ecx
    753638a02f94:	73 28                	jae    0x753638a02fbe
    753638a02f96:	81 bb 80 00 08 00 10 	cmp    DWORD PTR [rbx+0x80080],0x10010
    753638a02f9d:	00 01 00 
    753638a02fa0:	75 1c                	jne    0x753638a02fbe
    753638a02fa2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    753638a02fa9:	10 00 01 00 
    753638a02fad:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a02fb4:	48 8b 83 88 00 08 00 	mov    rax,QWORD PTR [rbx+0x80088]
    753638a02fbb:	59                   	pop    rcx
    753638a02fbc:	ff e0                	jmp    rax
    753638a02fbe:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    753638a02fc5:	10 00 01 00 
    753638a02fc9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753638a02fd0:	02 00 00 00 
    753638a02fd4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    753638a02fdb:	04 00 00 00 
    753638a02fdf:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a02fe6:	01 
    753638a02fe7:	58                   	pop    rax
    753638a02fe8:	c2 08 00             	ret    0x8
