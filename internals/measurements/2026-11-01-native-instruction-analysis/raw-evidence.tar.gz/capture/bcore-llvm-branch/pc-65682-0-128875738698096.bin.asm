
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65682-0-128875738698096.bin:     file format binary


Disassembly of section .data:

0000753638a01170 <.data>:
    753638a01170:	50                   	push   rax
    753638a01171:	41 8b 9d a0 00 00 00 	mov    ebx,DWORD PTR [r13+0xa0]
    753638a01178:	8d 83 67 ff fe ff    	lea    eax,[rbx-0x10099]
    753638a0117e:	83 f8 f8             	cmp    eax,0xfffffff8
    753638a01181:	0f 87 53 0e 00 18    	ja     0x753650a01fda
    753638a01187:	41 8b ad a4 00 00 00 	mov    ebp,DWORD PTR [r13+0xa4]
    753638a0118e:	8d 85 67 ff fe ff    	lea    eax,[rbp-0x10099]
    753638a01194:	83 f8 f8             	cmp    eax,0xfffffff8
    753638a01197:	0f 87 3d 0e 00 18    	ja     0x753650a01fda
    753638a0119d:	4d 8b bd 50 01 00 00 	mov    r15,QWORD PTR [r13+0x150]
    753638a011a4:	4d 8b a5 40 01 00 00 	mov    r12,QWORD PTR [r13+0x140]
    753638a011ab:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753638a011b2:	41 8b 4d 00          	mov    ecx,DWORD PTR [r13+0x0]
    753638a011b6:	89 ca                	mov    edx,ecx
    753638a011b8:	c1 ea 1f             	shr    edx,0x1f
    753638a011bb:	31 f6                	xor    esi,esi
    753638a011bd:	85 c9                	test   ecx,ecx
    753638a011bf:	40 0f 94 c6          	sete   sil
    753638a011c3:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    753638a011ca:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    753638a011d1:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    753638a011d8:	48 b9 01 00 00 00 01 	movabs rcx,0x100000001
    753638a011df:	00 00 00 
    753638a011e2:	49 89 8d ec 00 00 00 	mov    QWORD PTR [r13+0xec],rcx
    753638a011e9:	74 51                	je     0x753638a0123c
    753638a011eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    753638a011f2:	c0 00 01 00 
    753638a011f6:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a011fd:	83 c0 02             	add    eax,0x2
    753638a01200:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a01207:	39 c8                	cmp    eax,ecx
    753638a01209:	0f 83 a5 0d 00 18    	jae    0x753650a01fb4
    753638a0120f:	41 81 bf 00 06 08 00 	cmp    DWORD PTR [r15+0x80600],0x100c0
    753638a01216:	c0 00 01 00 
    753638a0121a:	0f 85 94 0d 00 18    	jne    0x753650a01fb4
    753638a01220:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    753638a01227:	c0 00 01 00 
    753638a0122b:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01232:	49 8b 87 08 06 08 00 	mov    rax,QWORD PTR [r15+0x80608]
    753638a01239:	59                   	pop    rcx
    753638a0123a:	ff e0                	jmp    rax
    753638a0123c:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    753638a01240:	f6 c1 03             	test   cl,0x3
    753638a01243:	0f 85 c3 0d 00 18    	jne    0x753650a0200c
    753638a01249:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    753638a0124d:	48 89 ce             	mov    rsi,rcx
    753638a01250:	48 c1 ee 0c          	shr    rsi,0xc
    753638a01254:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    753638a01258:	48 85 c0             	test   rax,rax
    753638a0125b:	0f 84 37 0e 00 18    	je     0x753650a02098
    753638a01261:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a01267:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0126a:	41 80 3c 24 00       	cmp    BYTE PTR [r12],0x0
    753638a0126f:	0f 85 68 0e 00 18    	jne    0x753650a020dd
    753638a01275:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    753638a0127c:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a01283:	02 
    753638a01284:	b8 9c 00 01 00       	mov    eax,0x1009c
    753638a01289:	ba 9c 00 01 00       	mov    edx,0x1009c
    753638a0128e:	72 07                	jb     0x753638a01297
    753638a01290:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    753638a01297:	81 fb 98 00 01 00    	cmp    ebx,0x10098
    753638a0129d:	0f 44 c2             	cmove  eax,edx
    753638a012a0:	89 c2                	mov    edx,eax
    753638a012a2:	83 f9 02             	cmp    ecx,0x2
    753638a012a5:	72 07                	jb     0x753638a012ae
    753638a012a7:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a012ae:	81 fd 98 00 01 00    	cmp    ebp,0x10098
    753638a012b4:	0f 44 c2             	cmove  eax,edx
    753638a012b7:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a012be:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    753638a012c5:	28 04 01 00 
    753638a012c9:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a012d0:	83 c0 04             	add    eax,0x4
    753638a012d3:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a012da:	39 c8                	cmp    eax,ecx
    753638a012dc:	0f 83 04 0d 00 18    	jae    0x753650a01fe6
    753638a012e2:	41 81 bf 40 21 08 00 	cmp    DWORD PTR [r15+0x82140],0x10428
    753638a012e9:	28 04 01 00 
    753638a012ed:	0f 85 f3 0c 00 18    	jne    0x753650a01fe6
    753638a012f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    753638a012fa:	28 04 01 00 
    753638a012fe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01305:	49 8b 87 48 21 08 00 	mov    rax,QWORD PTR [r15+0x82148]
    753638a0130c:	59                   	pop    rcx
    753638a0130d:	ff e0                	jmp    rax
    753638a0130f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a01316:	01 
    753638a01317:	58                   	pop    rax
    753638a01318:	c2 08 00             	ret    0x8
