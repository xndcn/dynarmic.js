; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010170(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65904
  %4 = icmp ugt i32 %3, 2
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb7 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb7, 0
  %9 = sub i32 %guard_lb7, 65904
  %10 = icmp ugt i32 %9, 2
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x00010170_entry, label %lb_guard_miss, !prof !0

insn_0x00010170_entry:                            ; preds = %lb_guard
  br label %insn_0x00010170

insn_0x00010170:                                  ; preds = %insn_0x00010170_entry
  %13 = getelementptr i8, ptr %cpu, i32 28
  %rs = load i32, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %14, align 4
  %add32 = add i32 %rs, %rt
  %15 = getelementptr i8, ptr %cpu, i32 0
  store i32 %add32, ptr %15, align 4
  %flgs = lshr i32 %rs, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %16 = xor i32 %flgo, %flgn
  %17 = xor i32 %flgs, %flgn
  %18 = and i32 %17, %16
  %19 = xor i32 %rs, -1
  %20 = icmp ult i32 %19, %rt
  %ac0 = zext i1 %20 to i32
  %21 = icmp eq i32 %add32, 0
  %az = zext i1 %21 to i32
  %an = lshr i32 %add32, 31
  %22 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %24, align 4
  %25 = or i32 %vs_cur, %18
  %26 = getelementptr i8, ptr %cpu, i32 248
  store i32 %18, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i32 252
  store i32 %18, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 256
  store i32 %25, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %32, align 4
  br label %insn_0x00010172_entry

insn_0x00010172_entry:                            ; preds = %insn_0x00010170
  br label %insn_0x00010172

insn_0x00010172:                                  ; preds = %insn_0x00010172_entry
  %33 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %34, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65906
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65910
  %35 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 148
  %lt2 = load i32, ptr %36, align 4
  %lc_gt13 = icmp ugt i32 %lc1, 1
  %at_lb4 = icmp eq i32 %lb1, 65906
  %hwloop_cond5 = and i1 %lc_gt13, %at_lb4
  %hwloop_rets6 = select i1 %hwloop_cond5, i32 %lt2, i32 %hwloop_rets
  %37 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets6, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 188
  store i32 65840, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %39, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %40 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %40 monotonic, align 4, !range !1
  %41 = icmp ult i32 %chain_total, %chain_budget
  br i1 %41, label %chain_go, label %chain_leave8, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %42 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %42, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %insn_0x00010172
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526720
  %43 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %43, align 4
  %44 = icmp eq i32 %slot_pc, 65840
  br i1 %44, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010172
  %45 = getelementptr i8, ptr %cpu, i64 188
  store i32 65840, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %48, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %49 = getelementptr i8, ptr %cpu, i64 188
  store i32 65840, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %50, align 4
  %51 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %51, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
