
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65682-0-128876141354932.bin:     file format binary


Disassembly of section .data:

0000753650a01fb4 <.data>:
    753650a01fb4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    753650a01fbb:	c0 00 01 00 
    753650a01fbf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a01fc6:	02 00 00 00 
    753650a01fca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a01fd1:	02 00 00 00 
    753650a01fd5:	e9 35 f3 ff e7       	jmp    0x753638a0130f
    753650a01fda:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    753650a01fe1:	01 
    753650a01fe2:	58                   	pop    rax
    753650a01fe3:	c2 08 00             	ret    0x8
    753650a01fe6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    753650a01fed:	28 04 01 00 
    753650a01ff1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a01ff8:	04 00 00 00 
    753650a01ffc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    753650a02003:	04 00 00 00 
    753650a02007:	e9 03 f3 ff e7       	jmp    0x753638a0130f
    753650a0200c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    753650a02013:	96 00 01 00 
    753650a02017:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0201e:	02 00 00 00 
    753650a02022:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a02029:	03 00 00 00 
    753650a0202d:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a02034:	62 00 00 
    753650a02037:	4c 89 ef             	mov    rdi,r13
    753650a0203a:	4c 89 f6             	mov    rsi,r14
    753650a0203d:	ba 96 00 01 00       	mov    edx,0x10096
    753650a02042:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a02048:	ff d0                	call   rax
    753650a0204a:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    753650a02051:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753650a02058:	83 c0 03             	add    eax,0x3
    753650a0205b:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753650a02062:	39 d0                	cmp    eax,edx
    753650a02064:	0f 83 b6 00 00 00    	jae    0x753650a02120
    753650a0206a:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    753650a02071:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753650a02077:	41 39 0c 17          	cmp    DWORD PTR [r15+rdx*1],ecx
    753650a0207b:	0f 85 9f 00 00 00    	jne    0x753650a02120
    753650a02081:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753650a02088:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753650a0208f:	00 
    753650a02090:	49 8b 44 17 08       	mov    rax,QWORD PTR [r15+rdx*1+0x8]
    753650a02095:	59                   	pop    rcx
    753650a02096:	ff e0                	jmp    rax
    753650a02098:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    753650a0209f:	96 00 01 00 
    753650a020a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a020aa:	02 00 00 00 
    753650a020ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a020b5:	03 00 00 00 
    753650a020b9:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a020c0:	62 00 00 
    753650a020c3:	4c 89 f7             	mov    rdi,r14
    753650a020c6:	89 ce                	mov    esi,ecx
    753650a020c8:	ff d0                	call   rax
    753650a020ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a020d1:	00 
    753650a020d2:	0f 84 92 f1 ff e7    	je     0x753638a0126a
    753650a020d8:	e9 6d ff ff ff       	jmp    0x753650a0204a
    753650a020dd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10098
    753650a020e4:	98 00 01 00 
    753650a020e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a020ef:	02 00 00 00 
    753650a020f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a020fa:	03 00 00 00 
    753650a020fe:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a02105:	62 00 00 
    753650a02108:	4c 89 ef             	mov    rdi,r13
    753650a0210b:	ff d0                	call   rax
    753650a0210d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    753650a02114:	00 
    753650a02115:	0f 84 5a f1 ff e7    	je     0x753638a01275
    753650a0211b:	e9 2a ff ff ff       	jmp    0x753650a0204a
    753650a02120:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02127:	02 00 00 00 
    753650a0212b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    753650a02132:	03 00 00 00 
    753650a02136:	58                   	pop    rax
    753650a02137:	c2 08 00             	ret    0x8
