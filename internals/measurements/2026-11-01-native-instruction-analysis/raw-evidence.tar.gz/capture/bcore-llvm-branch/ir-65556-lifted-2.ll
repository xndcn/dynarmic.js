; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010014(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65556
  %6 = icmp ugt i32 %5, 42
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb324 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb324, 0
  %11 = sub i32 %guard_lb324, 65556
  %12 = icmp ugt i32 %11, 42
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010014_entry, label %lb_guard_miss, !prof !0

insn_0x00010014_entry:                            ; preds = %lb_guard
  br label %insn_0x00010014

insn_0x00010014:                                  ; preds = %insn_0x00010014_entry
  %15 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %15, align 4
  %sp_dec = sub i32 %sp, 4
  %16 = getelementptr i8, ptr %cpu, i32 16
  %r = load i32, ptr %16, align 4
  %17 = and i32 %sp_dec, 3
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010014
  %19 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %20, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec, i32 65536)
  %21 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 188
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr i8, ptr %cpu, i64 296
  %25 = load i8, ptr %24, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010014
  %26 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %26 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %27 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %28, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %29 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %30, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %31 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %31, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %32 = getelementptr i8, ptr %cpu, i32 20
  %r2 = load i32, ptr %32, align 4
  %33 = and i32 %sp_dec1, 3
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 188
  %37 = load i32, ptr %36, align 4
  %38 = getelementptr i8, ptr %cpu, i64 296
  %39 = load i8, ptr %38, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec1, i32 65536)
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc326 = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 188
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %cpu, i64 296
  %46 = load i8, ptr %45, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %47 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %47 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %48 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %48 to i64
  %49 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %49, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %50 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %51, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %52 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %52, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %sp_dec17 = sub i32 %sp_dec1, 4
  %53 = getelementptr i8, ptr %cpu, i32 24
  %r18 = load i32, ptr %53, align 4
  %54 = and i32 %sp_dec17, 3
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %56 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 188
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %cpu, i64 296
  %60 = load i8, ptr %59, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

data_misaligned19:                                ; preds = %page_wr_done7
  %61 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %62, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec17, i32 65536)
  %63 = getelementptr i8, ptr %cpu, i64 188
  %next_pc328 = load i32, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 188
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %cpu, i64 296
  %67 = load i8, ptr %66, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_wr_done7
  %68 = lshr i32 %sp_dec17, 12
  %page_index24 = zext i32 %68 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast21, label %page_wr_slow22, !prof !0

page_wr_fast21:                                   ; preds = %data_aligned20
  %69 = and i32 %sp_dec17, 4095
  %page_offset28 = zext i32 %69 to i64
  %70 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %r18, ptr %70, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %data_aligned20
  %71 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %72, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %r18)
  %73 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %73, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done23:                                   ; preds = %did_jump_cont30, %page_wr_fast21
  %sp_dec33 = sub i32 %sp_dec17, 4
  %74 = getelementptr i8, ptr %cpu, i32 28
  %r34 = load i32, ptr %74, align 4
  %75 = and i32 %sp_dec33, 3
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %data_misaligned35, label %data_aligned36, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %77 = getelementptr i8, ptr %cpu, i64 188
  %next_pc329 = load i32, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 188
  %79 = load i32, ptr %78, align 4
  %80 = getelementptr i8, ptr %cpu, i64 296
  %81 = load i8, ptr %80, align 1
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow22
  br label %page_wr_done23

data_misaligned35:                                ; preds = %page_wr_done23
  %82 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %83, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec33, i32 65536)
  %84 = getelementptr i8, ptr %cpu, i64 188
  %next_pc330 = load i32, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 188
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %cpu, i64 296
  %88 = load i8, ptr %87, align 1
  br label %chain_exit

data_aligned36:                                   ; preds = %page_wr_done23
  %89 = lshr i32 %sp_dec33, 12
  %page_index40 = zext i32 %89 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_wr_fast37, label %page_wr_slow38, !prof !0

page_wr_fast37:                                   ; preds = %data_aligned36
  %90 = and i32 %sp_dec33, 4095
  %page_offset44 = zext i32 %90 to i64
  %91 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %r34, ptr %91, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %data_aligned36
  %92 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %93, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec33, i32 %r34)
  %94 = getelementptr i8, ptr %cpu, i32 296
  %dj47 = load i8, ptr %94, align 1
  %dj_set48 = icmp ne i8 %dj47, 0
  br i1 %dj_set48, label %did_jump_exit45, label %did_jump_cont46, !prof !1

page_wr_done39:                                   ; preds = %did_jump_cont46, %page_wr_fast37
  %sp_dec49 = sub i32 %sp_dec33, 4
  %95 = getelementptr i8, ptr %cpu, i32 44
  %p = load i32, ptr %95, align 4
  %96 = and i32 %sp_dec49, 3
  %97 = icmp ne i32 %96, 0
  br i1 %97, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %98 = getelementptr i8, ptr %cpu, i64 188
  %next_pc331 = load i32, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 188
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %cpu, i64 296
  %102 = load i8, ptr %101, align 1
  br label %chain_exit

did_jump_cont46:                                  ; preds = %page_wr_slow38
  br label %page_wr_done39

data_misaligned50:                                ; preds = %page_wr_done39
  %103 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %104, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec49, i32 65536)
  %105 = getelementptr i8, ptr %cpu, i64 188
  %next_pc332 = load i32, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 188
  %107 = load i32, ptr %106, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  %109 = load i8, ptr %108, align 1
  br label %chain_exit

data_aligned51:                                   ; preds = %page_wr_done39
  %110 = lshr i32 %sp_dec49, 12
  %page_index55 = zext i32 %110 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_wr_fast52, label %page_wr_slow53, !prof !0

page_wr_fast52:                                   ; preds = %data_aligned51
  %111 = and i32 %sp_dec49, 4095
  %page_offset59 = zext i32 %111 to i64
  %112 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p, ptr %112, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %data_aligned51
  %113 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %114, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec49, i32 %p)
  %115 = getelementptr i8, ptr %cpu, i32 296
  %dj62 = load i8, ptr %115, align 1
  %dj_set63 = icmp ne i8 %dj62, 0
  br i1 %dj_set63, label %did_jump_exit60, label %did_jump_cont61, !prof !1

page_wr_done54:                                   ; preds = %did_jump_cont61, %page_wr_fast52
  %sp_dec64 = sub i32 %sp_dec49, 4
  %116 = getelementptr i8, ptr %cpu, i32 48
  %p65 = load i32, ptr %116, align 4
  %117 = and i32 %sp_dec64, 3
  %118 = icmp ne i32 %117, 0
  br i1 %118, label %data_misaligned66, label %data_aligned67, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %119 = getelementptr i8, ptr %cpu, i64 188
  %next_pc333 = load i32, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i64 188
  %121 = load i32, ptr %120, align 4
  %122 = getelementptr i8, ptr %cpu, i64 296
  %123 = load i8, ptr %122, align 1
  br label %chain_exit

did_jump_cont61:                                  ; preds = %page_wr_slow53
  br label %page_wr_done54

data_misaligned66:                                ; preds = %page_wr_done54
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %125, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec64, i32 65536)
  %126 = getelementptr i8, ptr %cpu, i64 188
  %next_pc334 = load i32, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i64 188
  %128 = load i32, ptr %127, align 4
  %129 = getelementptr i8, ptr %cpu, i64 296
  %130 = load i8, ptr %129, align 1
  br label %chain_exit

data_aligned67:                                   ; preds = %page_wr_done54
  %131 = lshr i32 %sp_dec64, 12
  %page_index71 = zext i32 %131 to i64
  %page_slot72 = getelementptr ptr, ptr %page_table, i64 %page_index71
  %page73 = load ptr, ptr %page_slot72, align 8
  %page_mapped74 = icmp ne ptr %page73, null
  br i1 %page_mapped74, label %page_wr_fast68, label %page_wr_slow69, !prof !0

page_wr_fast68:                                   ; preds = %data_aligned67
  %132 = and i32 %sp_dec64, 4095
  %page_offset75 = zext i32 %132 to i64
  %133 = getelementptr i8, ptr %page73, i64 %page_offset75
  store i32 %p65, ptr %133, align 4
  br label %page_wr_done70

page_wr_slow69:                                   ; preds = %data_aligned67
  %134 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %135, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec64, i32 %p65)
  %136 = getelementptr i8, ptr %cpu, i32 296
  %dj78 = load i8, ptr %136, align 1
  %dj_set79 = icmp ne i8 %dj78, 0
  br i1 %dj_set79, label %did_jump_exit76, label %did_jump_cont77, !prof !1

page_wr_done70:                                   ; preds = %did_jump_cont77, %page_wr_fast68
  %sp_dec80 = sub i32 %sp_dec64, 4
  %137 = getelementptr i8, ptr %cpu, i32 52
  %p81 = load i32, ptr %137, align 4
  %138 = and i32 %sp_dec80, 3
  %139 = icmp ne i32 %138, 0
  br i1 %139, label %data_misaligned82, label %data_aligned83, !prof !1

did_jump_exit76:                                  ; preds = %page_wr_slow69
  %140 = getelementptr i8, ptr %cpu, i64 188
  %next_pc335 = load i32, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i64 188
  %142 = load i32, ptr %141, align 4
  %143 = getelementptr i8, ptr %cpu, i64 296
  %144 = load i8, ptr %143, align 1
  br label %chain_exit

did_jump_cont77:                                  ; preds = %page_wr_slow69
  br label %page_wr_done70

data_misaligned82:                                ; preds = %page_wr_done70
  %145 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %145, align 4
  %146 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %146, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec80, i32 65536)
  %147 = getelementptr i8, ptr %cpu, i64 188
  %next_pc336 = load i32, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i64 188
  %149 = load i32, ptr %148, align 4
  %150 = getelementptr i8, ptr %cpu, i64 296
  %151 = load i8, ptr %150, align 1
  br label %chain_exit

data_aligned83:                                   ; preds = %page_wr_done70
  %152 = lshr i32 %sp_dec80, 12
  %page_index87 = zext i32 %152 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90 = icmp ne ptr %page89, null
  br i1 %page_mapped90, label %page_wr_fast84, label %page_wr_slow85, !prof !0

page_wr_fast84:                                   ; preds = %data_aligned83
  %153 = and i32 %sp_dec80, 4095
  %page_offset91 = zext i32 %153 to i64
  %154 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %p81, ptr %154, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %data_aligned83
  %155 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %156, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec80, i32 %p81)
  %157 = getelementptr i8, ptr %cpu, i32 296
  %dj94 = load i8, ptr %157, align 1
  %dj_set95 = icmp ne i8 %dj94, 0
  br i1 %dj_set95, label %did_jump_exit92, label %did_jump_cont93, !prof !1

page_wr_done86:                                   ; preds = %did_jump_cont93, %page_wr_fast84
  %158 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec80, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %160, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %161 = icmp ne i8 %cec_pending, 0
  br i1 %161, label %cec_check, label %cec_checked, !prof !1

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %162 = getelementptr i8, ptr %cpu, i64 188
  %next_pc337 = load i32, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i64 188
  %164 = load i32, ptr %163, align 4
  %165 = getelementptr i8, ptr %cpu, i64 296
  %166 = load i8, ptr %165, align 1
  br label %chain_exit

did_jump_cont93:                                  ; preds = %page_wr_slow85
  br label %page_wr_done86

cec_check:                                        ; preds = %page_wr_done86
  %167 = getelementptr i8, ptr %cpu, i32 188
  store i32 65558, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %169, align 4
  call void @cec_check_pending(ptr %cpu)
  %170 = getelementptr i8, ptr %cpu, i32 296
  %dj98 = load i8, ptr %170, align 1
  %dj_set99 = icmp ne i8 %dj98, 0
  br i1 %dj_set99, label %did_jump_exit96, label %did_jump_cont97, !prof !1

cec_checked:                                      ; preds = %did_jump_cont97, %page_wr_done86
  br label %insn_0x00010016_entry

did_jump_exit96:                                  ; preds = %cec_check
  %171 = getelementptr i8, ptr %cpu, i64 188
  %next_pc338 = load i32, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i64 188
  %173 = load i32, ptr %172, align 4
  %174 = getelementptr i8, ptr %cpu, i64 296
  %175 = load i8, ptr %174, align 1
  br label %chain_exit

did_jump_cont97:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010016_entry:                            ; preds = %cec_checked
  br label %insn_0x00010016

insn_0x00010016:                                  ; preds = %insn_0x00010016_entry
  %176 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %176, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 0
  %177 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %177, align 4
  br label %insn_0x0001001a_entry

insn_0x0001001a_entry:                            ; preds = %insn_0x00010016
  br label %insn_0x0001001a

insn_0x0001001a:                                  ; preds = %insn_0x0001001a_entry
  %178 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %179, align 4
  %sp1 = sub i32 %sp_dec80, 4
  %180 = and i32 %sp1, 3
  %181 = icmp ne i32 %180, 0
  br i1 %181, label %data_misaligned100, label %data_aligned101, !prof !1

data_misaligned100:                               ; preds = %insn_0x0001001a
  %182 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %184, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65562, i32 %sp1, i32 65536)
  %185 = getelementptr i8, ptr %cpu, i64 188
  %next_pc339 = load i32, ptr %185, align 4
  %186 = getelementptr i8, ptr %cpu, i64 188
  %187 = load i32, ptr %186, align 4
  %188 = getelementptr i8, ptr %cpu, i64 296
  %189 = load i8, ptr %188, align 1
  br label %chain_exit

data_aligned101:                                  ; preds = %insn_0x0001001a
  %190 = lshr i32 %sp1, 12
  %page_index105 = zext i32 %190 to i64
  %page_slot106 = getelementptr ptr, ptr %page_table, i64 %page_index105
  %page107 = load ptr, ptr %page_slot106, align 8
  %page_mapped108 = icmp ne ptr %page107, null
  br i1 %page_mapped108, label %page_wr_fast102, label %page_wr_slow103, !prof !0

page_wr_fast102:                                  ; preds = %data_aligned101
  %191 = and i32 %sp1, 4095
  %page_offset109 = zext i32 %191 to i64
  %192 = getelementptr i8, ptr %page107, i64 %page_offset109
  store i32 %rets, ptr %192, align 4
  br label %page_wr_done104

page_wr_slow103:                                  ; preds = %data_aligned101
  %193 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %194, align 4
  %195 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %195, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %196 = getelementptr i8, ptr %cpu, i32 296
  %dj112 = load i8, ptr %196, align 1
  %dj_set113 = icmp ne i8 %dj112, 0
  br i1 %dj_set113, label %did_jump_exit110, label %did_jump_cont111, !prof !1

page_wr_done104:                                  ; preds = %did_jump_cont111, %page_wr_fast102
  %sp2 = sub i32 %sp1, 4
  %197 = and i32 %sp2, 3
  %198 = icmp ne i32 %197, 0
  br i1 %198, label %data_misaligned114, label %data_aligned115, !prof !1

did_jump_exit110:                                 ; preds = %page_wr_slow103
  %199 = getelementptr i8, ptr %cpu, i64 188
  %next_pc340 = load i32, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i64 188
  %201 = load i32, ptr %200, align 4
  %202 = getelementptr i8, ptr %cpu, i64 296
  %203 = load i8, ptr %202, align 1
  br label %chain_exit

did_jump_cont111:                                 ; preds = %page_wr_slow103
  br label %page_wr_done104

data_misaligned114:                               ; preds = %page_wr_done104
  %204 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %206, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65562, i32 %sp2, i32 65536)
  %207 = getelementptr i8, ptr %cpu, i64 188
  %next_pc341 = load i32, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i64 188
  %209 = load i32, ptr %208, align 4
  %210 = getelementptr i8, ptr %cpu, i64 296
  %211 = load i8, ptr %210, align 1
  br label %chain_exit

data_aligned115:                                  ; preds = %page_wr_done104
  %212 = lshr i32 %sp2, 12
  %page_index119 = zext i32 %212 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122 = icmp ne ptr %page121, null
  br i1 %page_mapped122, label %page_wr_fast116, label %page_wr_slow117, !prof !0

page_wr_fast116:                                  ; preds = %data_aligned115
  %213 = and i32 %sp2, 4095
  %page_offset123 = zext i32 %213 to i64
  %214 = getelementptr i8, ptr %page121, i64 %page_offset123
  store i32 %fp, ptr %214, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %data_aligned115
  %215 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %216, align 4
  %217 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %217, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %218 = getelementptr i8, ptr %cpu, i32 296
  %dj126 = load i8, ptr %218, align 1
  %dj_set127 = icmp ne i8 %dj126, 0
  br i1 %dj_set127, label %did_jump_exit124, label %did_jump_cont125, !prof !1

page_wr_done118:                                  ; preds = %did_jump_cont125, %page_wr_fast116
  %219 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %219, align 4
  %sp3 = sub i32 %sp2, 20
  %220 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %220, align 4
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %221 = icmp ne i8 %cec_pending128, 0
  br i1 %221, label %cec_check129, label %cec_checked130, !prof !1

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %222 = getelementptr i8, ptr %cpu, i64 188
  %next_pc342 = load i32, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 188
  %224 = load i32, ptr %223, align 4
  %225 = getelementptr i8, ptr %cpu, i64 296
  %226 = load i8, ptr %225, align 1
  br label %chain_exit

did_jump_cont125:                                 ; preds = %page_wr_slow117
  br label %page_wr_done118

cec_check129:                                     ; preds = %page_wr_done118
  %227 = getelementptr i8, ptr %cpu, i32 188
  store i32 65566, ptr %227, align 4
  %228 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %228, align 4
  %229 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %229, align 4
  call void @cec_check_pending(ptr %cpu)
  %230 = getelementptr i8, ptr %cpu, i32 296
  %dj133 = load i8, ptr %230, align 1
  %dj_set134 = icmp ne i8 %dj133, 0
  br i1 %dj_set134, label %did_jump_exit131, label %did_jump_cont132, !prof !1

cec_checked130:                                   ; preds = %did_jump_cont132, %page_wr_done118
  br label %insn_0x0001001e_entry

did_jump_exit131:                                 ; preds = %cec_check129
  %231 = getelementptr i8, ptr %cpu, i64 188
  %next_pc343 = load i32, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i64 188
  %233 = load i32, ptr %232, align 4
  %234 = getelementptr i8, ptr %cpu, i64 296
  %235 = load i8, ptr %234, align 1
  br label %chain_exit

did_jump_cont132:                                 ; preds = %cec_check129
  br label %cec_checked130

insn_0x0001001e_entry:                            ; preds = %cec_checked130
  br label %insn_0x0001001e

insn_0x0001001e:                                  ; preds = %insn_0x0001001e_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 61440
  %236 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %236, align 4
  br label %insn_0x00010022_entry

insn_0x00010022_entry:                            ; preds = %insn_0x0001001e
  br label %insn_0x00010022

insn_0x00010022:                                  ; preds = %insn_0x00010022_entry
  %237 = getelementptr i8, ptr %cpu, i32 4
  %old135 = load i32, ptr %237, align 4
  %lo_kept136 = and i32 %old135, 65535
  %with_hi137 = or i32 %lo_kept136, 1128398848
  %238 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_hi137, ptr %238, align 4
  br label %insn_0x00010026_entry

insn_0x00010026_entry:                            ; preds = %insn_0x00010022
  br label %insn_0x00010026

insn_0x00010026:                                  ; preds = %insn_0x00010026_entry
  %239 = and i32 %with_lo, 3
  %240 = icmp ne i32 %239, 0
  br i1 %240, label %data_misaligned138, label %data_aligned139, !prof !1

data_misaligned138:                               ; preds = %insn_0x00010026
  %241 = getelementptr i8, ptr %cpu, i32 188
  store i32 65574, ptr %241, align 4
  %242 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %243, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65574, i32 %with_lo, i32 0)
  %244 = getelementptr i8, ptr %cpu, i64 188
  %next_pc344 = load i32, ptr %244, align 4
  %245 = getelementptr i8, ptr %cpu, i64 188
  %246 = load i32, ptr %245, align 4
  %247 = getelementptr i8, ptr %cpu, i64 296
  %248 = load i8, ptr %247, align 1
  br label %chain_exit

data_aligned139:                                  ; preds = %insn_0x00010026
  %249 = lshr i32 %with_lo, 12
  %page_index140 = zext i32 %249 to i64
  %page_slot141 = getelementptr ptr, ptr %page_table, i64 %page_index140
  %page142 = load ptr, ptr %page_slot141, align 8
  %page_mapped143 = icmp ne ptr %page142, null
  br i1 %page_mapped143, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned139
  %250 = and i32 %with_lo, 4095
  %page_offset144 = zext i32 %250 to i64
  %251 = getelementptr i8, ptr %page142, i64 %page_offset144
  %page_val = load i32, ptr %251, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned139
  %252 = getelementptr i8, ptr %cpu, i32 188
  store i32 65574, ptr %252, align 4
  %253 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %253, align 4
  %254 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %254, align 4
  %255 = call i32 @mem_read32(ptr %mem, i32 %with_lo)
  %256 = getelementptr i8, ptr %cpu, i32 296
  %dj147 = load i8, ptr %256, align 1
  %dj_set148 = icmp ne i8 %dj147, 0
  br i1 %dj_set148, label %did_jump_exit145, label %did_jump_cont146, !prof !1

page_done:                                        ; preds = %did_jump_cont146, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %255, %did_jump_cont146 ]
  %257 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val, ptr %257, align 4
  br label %insn_0x00010028_entry

did_jump_exit145:                                 ; preds = %page_slow
  %258 = getelementptr i8, ptr %cpu, i64 188
  %next_pc345 = load i32, ptr %258, align 4
  %259 = getelementptr i8, ptr %cpu, i64 188
  %260 = load i32, ptr %259, align 4
  %261 = getelementptr i8, ptr %cpu, i64 296
  %262 = load i8, ptr %261, align 1
  br label %chain_exit

did_jump_cont146:                                 ; preds = %page_slow
  br label %page_done

insn_0x00010028_entry:                            ; preds = %page_done
  br label %insn_0x00010028

insn_0x00010028:                                  ; preds = %insn_0x00010028_entry
  %hi_kept149 = and i32 %with_hi137, -65536
  %with_lo150 = or i32 %hi_kept149, 20017
  %263 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_lo150, ptr %263, align 4
  br label %insn_0x0001002c_entry

insn_0x0001002c_entry:                            ; preds = %insn_0x00010028
  br label %insn_0x0001002c

insn_0x0001002c:                                  ; preds = %insn_0x0001002c_entry
  %diff = sub i32 %mem_val, %with_lo150
  %264 = icmp eq i32 %diff, 0
  %az = zext i1 %264 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %mem_val, 31
  %flgo = lshr i32 %with_lo150, 31
  %265 = xor i32 %flgn, %flgs
  %266 = xor i32 %flgs, %flgo
  %overflow = and i32 %266, %265
  %an = xor i32 %flgn, %overflow
  %267 = icmp ule i32 %with_lo150, %mem_val
  %ac0 = zext i1 %267 to i32
  %268 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %268, align 4
  %269 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %269, align 4
  %270 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %270, align 4
  %271 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %271, align 4
  %272 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %272, align 4
  br label %insn_0x0001002e_entry

insn_0x0001002e_entry:                            ; preds = %insn_0x0001002c
  br label %insn_0x0001002e

insn_0x0001002e:                                  ; preds = %insn_0x0001002e_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x0001002e
  %273 = getelementptr i8, ptr %cpu, i32 188
  store i32 65600, ptr %273, align 4
  %274 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %274, align 4
  %chain_total = add nuw i32 %chain_packets, 9
  %275 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %275 monotonic, align 4, !range !2
  %276 = icmp ult i32 %chain_total, %chain_budget
  br i1 %276, label %chain_go, label %chain_leave346, !prof !0

brt_fallthru:                                     ; preds = %insn_0x0001002e
  br label %insn_0x00010030_entry

insn_0x00010030_entry:                            ; preds = %brt_fallthru
  br label %insn_0x00010030

insn_0x00010030:                                  ; preds = %insn_0x00010030_entry
  %277 = getelementptr i8, ptr %cpu, i32 0
  store i32 3, ptr %277, align 4
  br label %insn_0x00010032_entry

insn_0x00010032_entry:                            ; preds = %insn_0x00010030
  br label %insn_0x00010032

insn_0x00010032:                                  ; preds = %insn_0x00010032_entry
  %pd_add = add i32 %with_lo, 16
  %278 = getelementptr i8, ptr %cpu, i32 40
  store i32 %pd_add, ptr %278, align 4
  br label %insn_0x00010034_entry

insn_0x00010034_entry:                            ; preds = %insn_0x00010032
  br label %insn_0x00010034

insn_0x00010034:                                  ; preds = %insn_0x00010034_entry
  %279 = and i32 %pd_add, 3
  %280 = icmp ne i32 %279, 0
  br i1 %280, label %data_misaligned151, label %data_aligned152, !prof !1

data_misaligned151:                               ; preds = %insn_0x00010034
  %281 = getelementptr i8, ptr %cpu, i32 188
  store i32 65588, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %282, align 4
  %283 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %283, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65588, i32 %pd_add, i32 65536)
  %284 = getelementptr i8, ptr %cpu, i64 188
  %next_pc347 = load i32, ptr %284, align 4
  %285 = getelementptr i8, ptr %cpu, i64 188
  %286 = load i32, ptr %285, align 4
  %287 = getelementptr i8, ptr %cpu, i64 296
  %288 = load i8, ptr %287, align 1
  br label %chain_exit

data_aligned152:                                  ; preds = %insn_0x00010034
  %289 = lshr i32 %pd_add, 12
  %page_index156 = zext i32 %289 to i64
  %page_slot157 = getelementptr ptr, ptr %page_table, i64 %page_index156
  %page158 = load ptr, ptr %page_slot157, align 8
  %page_mapped159 = icmp ne ptr %page158, null
  br i1 %page_mapped159, label %page_wr_fast153, label %page_wr_slow154, !prof !0

page_wr_fast153:                                  ; preds = %data_aligned152
  %290 = and i32 %pd_add, 4095
  %page_offset160 = zext i32 %290 to i64
  %291 = getelementptr i8, ptr %page158, i64 %page_offset160
  store i32 3, ptr %291, align 4
  br label %page_wr_done155

page_wr_slow154:                                  ; preds = %data_aligned152
  %292 = getelementptr i8, ptr %cpu, i32 188
  store i32 65588, ptr %292, align 4
  %293 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %293, align 4
  %294 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %294, align 4
  call void @mem_write32(ptr %mem, i32 %pd_add, i32 3)
  %295 = getelementptr i8, ptr %cpu, i32 296
  %dj163 = load i8, ptr %295, align 1
  %dj_set164 = icmp ne i8 %dj163, 0
  br i1 %dj_set164, label %did_jump_exit161, label %did_jump_cont162, !prof !1

page_wr_done155:                                  ; preds = %did_jump_cont162, %page_wr_fast153
  %cec_pending165 = load i8, ptr %cec_pending_flag, align 1
  %296 = icmp ne i8 %cec_pending165, 0
  br i1 %296, label %cec_check166, label %cec_checked167, !prof !1

did_jump_exit161:                                 ; preds = %page_wr_slow154
  %297 = getelementptr i8, ptr %cpu, i64 188
  %next_pc348 = load i32, ptr %297, align 4
  %298 = getelementptr i8, ptr %cpu, i64 188
  %299 = load i32, ptr %298, align 4
  %300 = getelementptr i8, ptr %cpu, i64 296
  %301 = load i8, ptr %300, align 1
  br label %chain_exit

did_jump_cont162:                                 ; preds = %page_wr_slow154
  br label %page_wr_done155

cec_check166:                                     ; preds = %page_wr_done155
  %302 = getelementptr i8, ptr %cpu, i32 188
  store i32 65590, ptr %302, align 4
  %303 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %303, align 4
  %304 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %304, align 4
  call void @cec_check_pending(ptr %cpu)
  %305 = getelementptr i8, ptr %cpu, i32 296
  %dj170 = load i8, ptr %305, align 1
  %dj_set171 = icmp ne i8 %dj170, 0
  br i1 %dj_set171, label %did_jump_exit168, label %did_jump_cont169, !prof !1

cec_checked167:                                   ; preds = %did_jump_cont169, %page_wr_done155
  br label %insn_0x00010036_entry

did_jump_exit168:                                 ; preds = %cec_check166
  %306 = getelementptr i8, ptr %cpu, i64 188
  %next_pc349 = load i32, ptr %306, align 4
  %307 = getelementptr i8, ptr %cpu, i64 188
  %308 = load i32, ptr %307, align 4
  %309 = getelementptr i8, ptr %cpu, i64 296
  %310 = load i8, ptr %309, align 1
  br label %chain_exit

did_jump_cont169:                                 ; preds = %cec_check166
  br label %cec_checked167

insn_0x00010036_entry:                            ; preds = %cec_checked167
  br label %insn_0x00010036

insn_0x00010036:                                  ; preds = %insn_0x00010036_entry
  %311 = getelementptr i8, ptr %cpu, i32 0
  store i32 1, ptr %311, align 4
  br label %insn_0x00010038_entry

insn_0x00010038_entry:                            ; preds = %insn_0x00010036
  br label %insn_0x00010038

insn_0x00010038:                                  ; preds = %insn_0x00010038_entry
  %312 = and i32 %sp2, 3
  %313 = icmp ne i32 %312, 0
  br i1 %313, label %data_misaligned172, label %data_aligned173, !prof !1

data_misaligned172:                               ; preds = %insn_0x00010038
  %314 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %314, align 4
  %315 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %315, align 4
  %316 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %316, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65592, i32 %sp2, i32 0)
  %317 = getelementptr i8, ptr %cpu, i64 188
  %next_pc350 = load i32, ptr %317, align 4
  %318 = getelementptr i8, ptr %cpu, i64 188
  %319 = load i32, ptr %318, align 4
  %320 = getelementptr i8, ptr %cpu, i64 296
  %321 = load i8, ptr %320, align 1
  br label %chain_exit

data_aligned173:                                  ; preds = %insn_0x00010038
  %322 = lshr i32 %sp2, 12
  %page_index177 = zext i32 %322 to i64
  %page_slot178 = getelementptr ptr, ptr %page_table, i64 %page_index177
  %page179 = load ptr, ptr %page_slot178, align 8
  %page_mapped180 = icmp ne ptr %page179, null
  br i1 %page_mapped180, label %page_fast174, label %page_slow175, !prof !0

page_fast174:                                     ; preds = %data_aligned173
  %323 = and i32 %sp2, 4095
  %page_offset181 = zext i32 %323 to i64
  %324 = getelementptr i8, ptr %page179, i64 %page_offset181
  %page_val182 = load i32, ptr %324, align 4
  br label %page_done176

page_slow175:                                     ; preds = %data_aligned173
  %325 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %325, align 4
  %326 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %326, align 4
  %327 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %327, align 4
  %328 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %329 = getelementptr i8, ptr %cpu, i32 296
  %dj185 = load i8, ptr %329, align 1
  %dj_set186 = icmp ne i8 %dj185, 0
  br i1 %dj_set186, label %did_jump_exit183, label %did_jump_cont184, !prof !1

page_done176:                                     ; preds = %did_jump_cont184, %page_fast174
  %mem_val187 = phi i32 [ %page_val182, %page_fast174 ], [ %328, %did_jump_cont184 ]
  %sp1188 = add i32 %sp2, 4
  %330 = and i32 %sp1188, 3
  %331 = icmp ne i32 %330, 0
  br i1 %331, label %data_misaligned189, label %data_aligned190, !prof !1

did_jump_exit183:                                 ; preds = %page_slow175
  %332 = getelementptr i8, ptr %cpu, i64 188
  %next_pc351 = load i32, ptr %332, align 4
  %333 = getelementptr i8, ptr %cpu, i64 188
  %334 = load i32, ptr %333, align 4
  %335 = getelementptr i8, ptr %cpu, i64 296
  %336 = load i8, ptr %335, align 1
  br label %chain_exit

did_jump_cont184:                                 ; preds = %page_slow175
  br label %page_done176

data_misaligned189:                               ; preds = %page_done176
  %337 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %337, align 4
  %338 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %338, align 4
  %339 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %339, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65592, i32 %sp1188, i32 0)
  %340 = getelementptr i8, ptr %cpu, i64 188
  %next_pc352 = load i32, ptr %340, align 4
  %341 = getelementptr i8, ptr %cpu, i64 188
  %342 = load i32, ptr %341, align 4
  %343 = getelementptr i8, ptr %cpu, i64 296
  %344 = load i8, ptr %343, align 1
  br label %chain_exit

data_aligned190:                                  ; preds = %page_done176
  %345 = lshr i32 %sp1188, 12
  %page_index194 = zext i32 %345 to i64
  %page_slot195 = getelementptr ptr, ptr %page_table, i64 %page_index194
  %page196 = load ptr, ptr %page_slot195, align 8
  %page_mapped197 = icmp ne ptr %page196, null
  br i1 %page_mapped197, label %page_fast191, label %page_slow192, !prof !0

page_fast191:                                     ; preds = %data_aligned190
  %346 = and i32 %sp1188, 4095
  %page_offset198 = zext i32 %346 to i64
  %347 = getelementptr i8, ptr %page196, i64 %page_offset198
  %page_val199 = load i32, ptr %347, align 4
  br label %page_done193

page_slow192:                                     ; preds = %data_aligned190
  %348 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %348, align 4
  %349 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %350, align 4
  %351 = call i32 @mem_read32(ptr %mem, i32 %sp1188)
  %352 = getelementptr i8, ptr %cpu, i32 296
  %dj202 = load i8, ptr %352, align 1
  %dj_set203 = icmp ne i8 %dj202, 0
  br i1 %dj_set203, label %did_jump_exit200, label %did_jump_cont201, !prof !1

page_done193:                                     ; preds = %did_jump_cont201, %page_fast191
  %mem_val204 = phi i32 [ %page_val199, %page_fast191 ], [ %351, %did_jump_cont201 ]
  %sp2205 = add i32 %sp1188, 4
  %353 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val187, ptr %353, align 4
  %354 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val204, ptr %354, align 4
  %355 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2205, ptr %355, align 4
  br label %insn_0x0001003c_entry

did_jump_exit200:                                 ; preds = %page_slow192
  %356 = getelementptr i8, ptr %cpu, i64 188
  %next_pc353 = load i32, ptr %356, align 4
  %357 = getelementptr i8, ptr %cpu, i64 188
  %358 = load i32, ptr %357, align 4
  %359 = getelementptr i8, ptr %cpu, i64 296
  %360 = load i8, ptr %359, align 1
  br label %chain_exit

did_jump_cont201:                                 ; preds = %page_slow192
  br label %page_done193

insn_0x0001003c_entry:                            ; preds = %page_done193
  br label %insn_0x0001003c

insn_0x0001003c:                                  ; preds = %insn_0x0001003c_entry
  %361 = and i32 %sp2205, 3
  %362 = icmp ne i32 %361, 0
  br i1 %362, label %data_misaligned206, label %data_aligned207, !prof !1

data_misaligned206:                               ; preds = %insn_0x0001003c
  %363 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %363, align 4
  %364 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %364, align 4
  %365 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %365, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp2205, i32 0)
  %366 = getelementptr i8, ptr %cpu, i64 188
  %next_pc354 = load i32, ptr %366, align 4
  %367 = getelementptr i8, ptr %cpu, i64 188
  %368 = load i32, ptr %367, align 4
  %369 = getelementptr i8, ptr %cpu, i64 296
  %370 = load i8, ptr %369, align 1
  br label %chain_exit

data_aligned207:                                  ; preds = %insn_0x0001003c
  %371 = lshr i32 %sp2205, 12
  %page_index211 = zext i32 %371 to i64
  %page_slot212 = getelementptr ptr, ptr %page_table, i64 %page_index211
  %page213 = load ptr, ptr %page_slot212, align 8
  %page_mapped214 = icmp ne ptr %page213, null
  br i1 %page_mapped214, label %page_fast208, label %page_slow209, !prof !0

page_fast208:                                     ; preds = %data_aligned207
  %372 = and i32 %sp2205, 4095
  %page_offset215 = zext i32 %372 to i64
  %373 = getelementptr i8, ptr %page213, i64 %page_offset215
  %page_val216 = load i32, ptr %373, align 4
  br label %page_done210

page_slow209:                                     ; preds = %data_aligned207
  %374 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %374, align 4
  %375 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %375, align 4
  %376 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %376, align 4
  %377 = call i32 @mem_read32(ptr %mem, i32 %sp2205)
  %378 = getelementptr i8, ptr %cpu, i32 296
  %dj219 = load i8, ptr %378, align 1
  %dj_set220 = icmp ne i8 %dj219, 0
  br i1 %dj_set220, label %did_jump_exit217, label %did_jump_cont218, !prof !1

page_done210:                                     ; preds = %did_jump_cont218, %page_fast208
  %mem_val221 = phi i32 [ %page_val216, %page_fast208 ], [ %377, %did_jump_cont218 ]
  %379 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val221, ptr %379, align 4
  %sp_inc = add i32 %sp2205, 4
  %380 = and i32 %sp_inc, 3
  %381 = icmp ne i32 %380, 0
  br i1 %381, label %data_misaligned222, label %data_aligned223, !prof !1

did_jump_exit217:                                 ; preds = %page_slow209
  %382 = getelementptr i8, ptr %cpu, i64 188
  %next_pc355 = load i32, ptr %382, align 4
  %383 = getelementptr i8, ptr %cpu, i64 188
  %384 = load i32, ptr %383, align 4
  %385 = getelementptr i8, ptr %cpu, i64 296
  %386 = load i8, ptr %385, align 1
  br label %chain_exit

did_jump_cont218:                                 ; preds = %page_slow209
  br label %page_done210

data_misaligned222:                               ; preds = %page_done210
  %387 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %387, align 4
  %388 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %388, align 4
  %389 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %389, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc, i32 0)
  %390 = getelementptr i8, ptr %cpu, i64 188
  %next_pc356 = load i32, ptr %390, align 4
  %391 = getelementptr i8, ptr %cpu, i64 188
  %392 = load i32, ptr %391, align 4
  %393 = getelementptr i8, ptr %cpu, i64 296
  %394 = load i8, ptr %393, align 1
  br label %chain_exit

data_aligned223:                                  ; preds = %page_done210
  %395 = lshr i32 %sp_inc, 12
  %page_index227 = zext i32 %395 to i64
  %page_slot228 = getelementptr ptr, ptr %page_table, i64 %page_index227
  %page229 = load ptr, ptr %page_slot228, align 8
  %page_mapped230 = icmp ne ptr %page229, null
  br i1 %page_mapped230, label %page_fast224, label %page_slow225, !prof !0

page_fast224:                                     ; preds = %data_aligned223
  %396 = and i32 %sp_inc, 4095
  %page_offset231 = zext i32 %396 to i64
  %397 = getelementptr i8, ptr %page229, i64 %page_offset231
  %page_val232 = load i32, ptr %397, align 4
  br label %page_done226

page_slow225:                                     ; preds = %data_aligned223
  %398 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %398, align 4
  %399 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %399, align 4
  %400 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %400, align 4
  %401 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %402 = getelementptr i8, ptr %cpu, i32 296
  %dj235 = load i8, ptr %402, align 1
  %dj_set236 = icmp ne i8 %dj235, 0
  br i1 %dj_set236, label %did_jump_exit233, label %did_jump_cont234, !prof !1

page_done226:                                     ; preds = %did_jump_cont234, %page_fast224
  %mem_val237 = phi i32 [ %page_val232, %page_fast224 ], [ %401, %did_jump_cont234 ]
  %403 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val237, ptr %403, align 4
  %sp_inc238 = add i32 %sp_inc, 4
  %404 = and i32 %sp_inc238, 3
  %405 = icmp ne i32 %404, 0
  br i1 %405, label %data_misaligned239, label %data_aligned240, !prof !1

did_jump_exit233:                                 ; preds = %page_slow225
  %406 = getelementptr i8, ptr %cpu, i64 188
  %next_pc357 = load i32, ptr %406, align 4
  %407 = getelementptr i8, ptr %cpu, i64 188
  %408 = load i32, ptr %407, align 4
  %409 = getelementptr i8, ptr %cpu, i64 296
  %410 = load i8, ptr %409, align 1
  br label %chain_exit

did_jump_cont234:                                 ; preds = %page_slow225
  br label %page_done226

data_misaligned239:                               ; preds = %page_done226
  %411 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %411, align 4
  %412 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %412, align 4
  %413 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %413, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc238, i32 0)
  %414 = getelementptr i8, ptr %cpu, i64 188
  %next_pc358 = load i32, ptr %414, align 4
  %415 = getelementptr i8, ptr %cpu, i64 188
  %416 = load i32, ptr %415, align 4
  %417 = getelementptr i8, ptr %cpu, i64 296
  %418 = load i8, ptr %417, align 1
  br label %chain_exit

data_aligned240:                                  ; preds = %page_done226
  %419 = lshr i32 %sp_inc238, 12
  %page_index244 = zext i32 %419 to i64
  %page_slot245 = getelementptr ptr, ptr %page_table, i64 %page_index244
  %page246 = load ptr, ptr %page_slot245, align 8
  %page_mapped247 = icmp ne ptr %page246, null
  br i1 %page_mapped247, label %page_fast241, label %page_slow242, !prof !0

page_fast241:                                     ; preds = %data_aligned240
  %420 = and i32 %sp_inc238, 4095
  %page_offset248 = zext i32 %420 to i64
  %421 = getelementptr i8, ptr %page246, i64 %page_offset248
  %page_val249 = load i32, ptr %421, align 4
  br label %page_done243

page_slow242:                                     ; preds = %data_aligned240
  %422 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %422, align 4
  %423 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %423, align 4
  %424 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %424, align 4
  %425 = call i32 @mem_read32(ptr %mem, i32 %sp_inc238)
  %426 = getelementptr i8, ptr %cpu, i32 296
  %dj252 = load i8, ptr %426, align 1
  %dj_set253 = icmp ne i8 %dj252, 0
  br i1 %dj_set253, label %did_jump_exit250, label %did_jump_cont251, !prof !1

page_done243:                                     ; preds = %did_jump_cont251, %page_fast241
  %mem_val254 = phi i32 [ %page_val249, %page_fast241 ], [ %425, %did_jump_cont251 ]
  %427 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val254, ptr %427, align 4
  %sp_inc255 = add i32 %sp_inc238, 4
  %428 = and i32 %sp_inc255, 3
  %429 = icmp ne i32 %428, 0
  br i1 %429, label %data_misaligned256, label %data_aligned257, !prof !1

did_jump_exit250:                                 ; preds = %page_slow242
  %430 = getelementptr i8, ptr %cpu, i64 188
  %next_pc359 = load i32, ptr %430, align 4
  %431 = getelementptr i8, ptr %cpu, i64 188
  %432 = load i32, ptr %431, align 4
  %433 = getelementptr i8, ptr %cpu, i64 296
  %434 = load i8, ptr %433, align 1
  br label %chain_exit

did_jump_cont251:                                 ; preds = %page_slow242
  br label %page_done243

data_misaligned256:                               ; preds = %page_done243
  %435 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %435, align 4
  %436 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %436, align 4
  %437 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %437, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc255, i32 0)
  %438 = getelementptr i8, ptr %cpu, i64 188
  %next_pc360 = load i32, ptr %438, align 4
  %439 = getelementptr i8, ptr %cpu, i64 188
  %440 = load i32, ptr %439, align 4
  %441 = getelementptr i8, ptr %cpu, i64 296
  %442 = load i8, ptr %441, align 1
  br label %chain_exit

data_aligned257:                                  ; preds = %page_done243
  %443 = lshr i32 %sp_inc255, 12
  %page_index261 = zext i32 %443 to i64
  %page_slot262 = getelementptr ptr, ptr %page_table, i64 %page_index261
  %page263 = load ptr, ptr %page_slot262, align 8
  %page_mapped264 = icmp ne ptr %page263, null
  br i1 %page_mapped264, label %page_fast258, label %page_slow259, !prof !0

page_fast258:                                     ; preds = %data_aligned257
  %444 = and i32 %sp_inc255, 4095
  %page_offset265 = zext i32 %444 to i64
  %445 = getelementptr i8, ptr %page263, i64 %page_offset265
  %page_val266 = load i32, ptr %445, align 4
  br label %page_done260

page_slow259:                                     ; preds = %data_aligned257
  %446 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %446, align 4
  %447 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %447, align 4
  %448 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %448, align 4
  %449 = call i32 @mem_read32(ptr %mem, i32 %sp_inc255)
  %450 = getelementptr i8, ptr %cpu, i32 296
  %dj269 = load i8, ptr %450, align 1
  %dj_set270 = icmp ne i8 %dj269, 0
  br i1 %dj_set270, label %did_jump_exit267, label %did_jump_cont268, !prof !1

page_done260:                                     ; preds = %did_jump_cont268, %page_fast258
  %mem_val271 = phi i32 [ %page_val266, %page_fast258 ], [ %449, %did_jump_cont268 ]
  %451 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val271, ptr %451, align 4
  %sp_inc272 = add i32 %sp_inc255, 4
  %452 = and i32 %sp_inc272, 3
  %453 = icmp ne i32 %452, 0
  br i1 %453, label %data_misaligned273, label %data_aligned274, !prof !1

did_jump_exit267:                                 ; preds = %page_slow259
  %454 = getelementptr i8, ptr %cpu, i64 188
  %next_pc361 = load i32, ptr %454, align 4
  %455 = getelementptr i8, ptr %cpu, i64 188
  %456 = load i32, ptr %455, align 4
  %457 = getelementptr i8, ptr %cpu, i64 296
  %458 = load i8, ptr %457, align 1
  br label %chain_exit

did_jump_cont268:                                 ; preds = %page_slow259
  br label %page_done260

data_misaligned273:                               ; preds = %page_done260
  %459 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %459, align 4
  %460 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %460, align 4
  %461 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %461, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc272, i32 0)
  %462 = getelementptr i8, ptr %cpu, i64 188
  %next_pc362 = load i32, ptr %462, align 4
  %463 = getelementptr i8, ptr %cpu, i64 188
  %464 = load i32, ptr %463, align 4
  %465 = getelementptr i8, ptr %cpu, i64 296
  %466 = load i8, ptr %465, align 1
  br label %chain_exit

data_aligned274:                                  ; preds = %page_done260
  %467 = lshr i32 %sp_inc272, 12
  %page_index278 = zext i32 %467 to i64
  %page_slot279 = getelementptr ptr, ptr %page_table, i64 %page_index278
  %page280 = load ptr, ptr %page_slot279, align 8
  %page_mapped281 = icmp ne ptr %page280, null
  br i1 %page_mapped281, label %page_fast275, label %page_slow276, !prof !0

page_fast275:                                     ; preds = %data_aligned274
  %468 = and i32 %sp_inc272, 4095
  %page_offset282 = zext i32 %468 to i64
  %469 = getelementptr i8, ptr %page280, i64 %page_offset282
  %page_val283 = load i32, ptr %469, align 4
  br label %page_done277

page_slow276:                                     ; preds = %data_aligned274
  %470 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %470, align 4
  %471 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %471, align 4
  %472 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %472, align 4
  %473 = call i32 @mem_read32(ptr %mem, i32 %sp_inc272)
  %474 = getelementptr i8, ptr %cpu, i32 296
  %dj286 = load i8, ptr %474, align 1
  %dj_set287 = icmp ne i8 %dj286, 0
  br i1 %dj_set287, label %did_jump_exit284, label %did_jump_cont285, !prof !1

page_done277:                                     ; preds = %did_jump_cont285, %page_fast275
  %mem_val288 = phi i32 [ %page_val283, %page_fast275 ], [ %473, %did_jump_cont285 ]
  %475 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val288, ptr %475, align 4
  %sp_inc289 = add i32 %sp_inc272, 4
  %476 = and i32 %sp_inc289, 3
  %477 = icmp ne i32 %476, 0
  br i1 %477, label %data_misaligned290, label %data_aligned291, !prof !1

did_jump_exit284:                                 ; preds = %page_slow276
  %478 = getelementptr i8, ptr %cpu, i64 188
  %next_pc363 = load i32, ptr %478, align 4
  %479 = getelementptr i8, ptr %cpu, i64 188
  %480 = load i32, ptr %479, align 4
  %481 = getelementptr i8, ptr %cpu, i64 296
  %482 = load i8, ptr %481, align 1
  br label %chain_exit

did_jump_cont285:                                 ; preds = %page_slow276
  br label %page_done277

data_misaligned290:                               ; preds = %page_done277
  %483 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %483, align 4
  %484 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %484, align 4
  %485 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %485, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc289, i32 0)
  %486 = getelementptr i8, ptr %cpu, i64 188
  %next_pc364 = load i32, ptr %486, align 4
  %487 = getelementptr i8, ptr %cpu, i64 188
  %488 = load i32, ptr %487, align 4
  %489 = getelementptr i8, ptr %cpu, i64 296
  %490 = load i8, ptr %489, align 1
  br label %chain_exit

data_aligned291:                                  ; preds = %page_done277
  %491 = lshr i32 %sp_inc289, 12
  %page_index295 = zext i32 %491 to i64
  %page_slot296 = getelementptr ptr, ptr %page_table, i64 %page_index295
  %page297 = load ptr, ptr %page_slot296, align 8
  %page_mapped298 = icmp ne ptr %page297, null
  br i1 %page_mapped298, label %page_fast292, label %page_slow293, !prof !0

page_fast292:                                     ; preds = %data_aligned291
  %492 = and i32 %sp_inc289, 4095
  %page_offset299 = zext i32 %492 to i64
  %493 = getelementptr i8, ptr %page297, i64 %page_offset299
  %page_val300 = load i32, ptr %493, align 4
  br label %page_done294

page_slow293:                                     ; preds = %data_aligned291
  %494 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %494, align 4
  %495 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %495, align 4
  %496 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %496, align 4
  %497 = call i32 @mem_read32(ptr %mem, i32 %sp_inc289)
  %498 = getelementptr i8, ptr %cpu, i32 296
  %dj303 = load i8, ptr %498, align 1
  %dj_set304 = icmp ne i8 %dj303, 0
  br i1 %dj_set304, label %did_jump_exit301, label %did_jump_cont302, !prof !1

page_done294:                                     ; preds = %did_jump_cont302, %page_fast292
  %mem_val305 = phi i32 [ %page_val300, %page_fast292 ], [ %497, %did_jump_cont302 ]
  %499 = getelementptr i8, ptr %cpu, i32 20
  store i32 %mem_val305, ptr %499, align 4
  %sp_inc306 = add i32 %sp_inc289, 4
  %500 = and i32 %sp_inc306, 3
  %501 = icmp ne i32 %500, 0
  br i1 %501, label %data_misaligned307, label %data_aligned308, !prof !1

did_jump_exit301:                                 ; preds = %page_slow293
  %502 = getelementptr i8, ptr %cpu, i64 188
  %next_pc365 = load i32, ptr %502, align 4
  %503 = getelementptr i8, ptr %cpu, i64 188
  %504 = load i32, ptr %503, align 4
  %505 = getelementptr i8, ptr %cpu, i64 296
  %506 = load i8, ptr %505, align 1
  br label %chain_exit

did_jump_cont302:                                 ; preds = %page_slow293
  br label %page_done294

data_misaligned307:                               ; preds = %page_done294
  %507 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %507, align 4
  %508 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %508, align 4
  %509 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %509, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc306, i32 0)
  %510 = getelementptr i8, ptr %cpu, i64 188
  %next_pc366 = load i32, ptr %510, align 4
  %511 = getelementptr i8, ptr %cpu, i64 188
  %512 = load i32, ptr %511, align 4
  %513 = getelementptr i8, ptr %cpu, i64 296
  %514 = load i8, ptr %513, align 1
  br label %chain_exit

data_aligned308:                                  ; preds = %page_done294
  %515 = lshr i32 %sp_inc306, 12
  %page_index312 = zext i32 %515 to i64
  %page_slot313 = getelementptr ptr, ptr %page_table, i64 %page_index312
  %page314 = load ptr, ptr %page_slot313, align 8
  %page_mapped315 = icmp ne ptr %page314, null
  br i1 %page_mapped315, label %page_fast309, label %page_slow310, !prof !0

page_fast309:                                     ; preds = %data_aligned308
  %516 = and i32 %sp_inc306, 4095
  %page_offset316 = zext i32 %516 to i64
  %517 = getelementptr i8, ptr %page314, i64 %page_offset316
  %page_val317 = load i32, ptr %517, align 4
  br label %page_done311

page_slow310:                                     ; preds = %data_aligned308
  %518 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %518, align 4
  %519 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %519, align 4
  %520 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %520, align 4
  %521 = call i32 @mem_read32(ptr %mem, i32 %sp_inc306)
  %522 = getelementptr i8, ptr %cpu, i32 296
  %dj320 = load i8, ptr %522, align 1
  %dj_set321 = icmp ne i8 %dj320, 0
  br i1 %dj_set321, label %did_jump_exit318, label %did_jump_cont319, !prof !1

page_done311:                                     ; preds = %did_jump_cont319, %page_fast309
  %mem_val322 = phi i32 [ %page_val317, %page_fast309 ], [ %521, %did_jump_cont319 ]
  %523 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val322, ptr %523, align 4
  %sp_inc323 = add i32 %sp_inc306, 4
  %524 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc323, ptr %524, align 4
  br label %insn_0x0001003e_entry

did_jump_exit318:                                 ; preds = %page_slow310
  %525 = getelementptr i8, ptr %cpu, i64 188
  %next_pc367 = load i32, ptr %525, align 4
  %526 = getelementptr i8, ptr %cpu, i64 188
  %527 = load i32, ptr %526, align 4
  %528 = getelementptr i8, ptr %cpu, i64 296
  %529 = load i8, ptr %528, align 1
  br label %chain_exit

did_jump_cont319:                                 ; preds = %page_slow310
  br label %page_done311

insn_0x0001003e_entry:                            ; preds = %page_done311
  br label %insn_0x0001003e

insn_0x0001003e:                                  ; preds = %insn_0x0001003e_entry
  %lsb = and i32 %mem_val204, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001003e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001003e
  %530 = getelementptr i8, ptr %cpu, i32 188
  store i32 65598, ptr %530, align 4
  %531 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %531, align 4
  %532 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %532, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %533 = getelementptr i8, ptr %cpu, i64 188
  %next_pc368 = load i32, ptr %533, align 4
  %534 = getelementptr i8, ptr %cpu, i64 188
  %535 = load i32, ptr %534, align 4
  %536 = getelementptr i8, ptr %cpu, i64 296
  %537 = load i8, ptr %536, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %538 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %538, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524800
  %539 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %539, align 4
  %540 = icmp eq i32 %slot_pc, 65600
  br i1 %540, label %chain_hit, label %chain_leave346, !prof !0

chain_leave346:                                   ; preds = %chain_go, %brt_taken
  %541 = getelementptr i8, ptr %cpu, i64 188
  store i32 65600, ptr %541, align 4
  %542 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %542, align 4
  %543 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %543, align 4
  %544 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %544, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %545 = getelementptr i8, ptr %cpu, i64 188
  store i32 65600, ptr %545, align 4
  %546 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %546, align 4
  %547 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %547, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit318, %data_misaligned307, %did_jump_exit301, %data_misaligned290, %did_jump_exit284, %data_misaligned273, %did_jump_exit267, %data_misaligned256, %did_jump_exit250, %data_misaligned239, %did_jump_exit233, %data_misaligned222, %did_jump_exit217, %data_misaligned206, %did_jump_exit200, %data_misaligned189, %did_jump_exit183, %data_misaligned172, %did_jump_exit168, %did_jump_exit161, %data_misaligned151, %did_jump_exit145, %data_misaligned138, %did_jump_exit131, %did_jump_exit124, %data_misaligned114, %did_jump_exit110, %data_misaligned100, %did_jump_exit96, %did_jump_exit92, %data_misaligned82, %did_jump_exit76, %data_misaligned66, %did_jump_exit60, %data_misaligned50, %did_jump_exit45, %data_misaligned35, %did_jump_exit29, %data_misaligned19, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc369 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc325, %did_jump_exit ], [ %next_pc326, %data_misaligned3 ], [ %next_pc327, %did_jump_exit13 ], [ %next_pc328, %data_misaligned19 ], [ %next_pc329, %did_jump_exit29 ], [ %next_pc330, %data_misaligned35 ], [ %next_pc331, %did_jump_exit45 ], [ %next_pc332, %data_misaligned50 ], [ %next_pc333, %did_jump_exit60 ], [ %next_pc334, %data_misaligned66 ], [ %next_pc335, %did_jump_exit76 ], [ %next_pc336, %data_misaligned82 ], [ %next_pc337, %did_jump_exit92 ], [ %next_pc338, %did_jump_exit96 ], [ %next_pc339, %data_misaligned100 ], [ %next_pc340, %did_jump_exit110 ], [ %next_pc341, %data_misaligned114 ], [ %next_pc342, %did_jump_exit124 ], [ %next_pc343, %did_jump_exit131 ], [ %next_pc344, %data_misaligned138 ], [ %next_pc345, %did_jump_exit145 ], [ %next_pc347, %data_misaligned151 ], [ %next_pc348, %did_jump_exit161 ], [ %next_pc349, %did_jump_exit168 ], [ %next_pc350, %data_misaligned172 ], [ %next_pc351, %did_jump_exit183 ], [ %next_pc352, %data_misaligned189 ], [ %next_pc353, %did_jump_exit200 ], [ %next_pc354, %data_misaligned206 ], [ %next_pc355, %did_jump_exit217 ], [ %next_pc356, %data_misaligned222 ], [ %next_pc357, %did_jump_exit233 ], [ %next_pc358, %data_misaligned239 ], [ %next_pc359, %did_jump_exit250 ], [ %next_pc360, %data_misaligned256 ], [ %next_pc361, %did_jump_exit267 ], [ %next_pc362, %data_misaligned273 ], [ %next_pc363, %did_jump_exit284 ], [ %next_pc364, %data_misaligned290 ], [ %next_pc365, %did_jump_exit301 ], [ %next_pc366, %data_misaligned307 ], [ %next_pc367, %did_jump_exit318 ], [ %mem_val204, %jump_aligned ], [ %next_pc368, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %data_misaligned66 ], [ 1, %did_jump_exit76 ], [ 1, %data_misaligned82 ], [ 1, %did_jump_exit92 ], [ 1, %did_jump_exit96 ], [ 3, %data_misaligned100 ], [ 3, %did_jump_exit110 ], [ 3, %data_misaligned114 ], [ 3, %did_jump_exit124 ], [ 3, %did_jump_exit131 ], [ 6, %data_misaligned138 ], [ 6, %did_jump_exit145 ], [ 12, %data_misaligned151 ], [ 12, %did_jump_exit161 ], [ 12, %did_jump_exit168 ], [ 14, %data_misaligned172 ], [ 14, %did_jump_exit183 ], [ 14, %data_misaligned189 ], [ 14, %did_jump_exit200 ], [ 15, %data_misaligned206 ], [ 15, %did_jump_exit217 ], [ 15, %data_misaligned222 ], [ 15, %did_jump_exit233 ], [ 15, %data_misaligned239 ], [ 15, %did_jump_exit250 ], [ 15, %data_misaligned256 ], [ 15, %did_jump_exit267 ], [ 15, %data_misaligned273 ], [ 15, %did_jump_exit284 ], [ 15, %data_misaligned290 ], [ 15, %did_jump_exit301 ], [ 15, %data_misaligned307 ], [ 15, %did_jump_exit318 ], [ 16, %jump_aligned ], [ 16, %jump_misalign ]
  %tail = phi i32 [ %23, %data_misaligned ], [ %37, %did_jump_exit ], [ %44, %data_misaligned3 ], [ %58, %did_jump_exit13 ], [ %65, %data_misaligned19 ], [ %79, %did_jump_exit29 ], [ %86, %data_misaligned35 ], [ %100, %did_jump_exit45 ], [ %107, %data_misaligned50 ], [ %121, %did_jump_exit60 ], [ %128, %data_misaligned66 ], [ %142, %did_jump_exit76 ], [ %149, %data_misaligned82 ], [ %164, %did_jump_exit92 ], [ %173, %did_jump_exit96 ], [ %187, %data_misaligned100 ], [ %201, %did_jump_exit110 ], [ %209, %data_misaligned114 ], [ %224, %did_jump_exit124 ], [ %233, %did_jump_exit131 ], [ %246, %data_misaligned138 ], [ %260, %did_jump_exit145 ], [ %286, %data_misaligned151 ], [ %299, %did_jump_exit161 ], [ %308, %did_jump_exit168 ], [ %319, %data_misaligned172 ], [ %334, %did_jump_exit183 ], [ %342, %data_misaligned189 ], [ %358, %did_jump_exit200 ], [ %368, %data_misaligned206 ], [ %384, %did_jump_exit217 ], [ %392, %data_misaligned222 ], [ %408, %did_jump_exit233 ], [ %416, %data_misaligned239 ], [ %432, %did_jump_exit250 ], [ %440, %data_misaligned256 ], [ %456, %did_jump_exit267 ], [ %464, %data_misaligned273 ], [ %480, %did_jump_exit284 ], [ %488, %data_misaligned290 ], [ %504, %did_jump_exit301 ], [ %512, %data_misaligned307 ], [ %527, %did_jump_exit318 ], [ %mem_val204, %jump_aligned ], [ %535, %jump_misalign ]
  %tail370 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit29 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit60 ], [ 2, %data_misaligned66 ], [ 2, %did_jump_exit76 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit96 ], [ 4, %data_misaligned100 ], [ 4, %did_jump_exit110 ], [ 4, %data_misaligned114 ], [ 4, %did_jump_exit124 ], [ 4, %did_jump_exit131 ], [ 2, %data_misaligned138 ], [ 2, %did_jump_exit145 ], [ 2, %data_misaligned151 ], [ 2, %did_jump_exit161 ], [ 2, %did_jump_exit168 ], [ 4, %data_misaligned172 ], [ 4, %did_jump_exit183 ], [ 4, %data_misaligned189 ], [ 4, %did_jump_exit200 ], [ 2, %data_misaligned206 ], [ 2, %did_jump_exit217 ], [ 2, %data_misaligned222 ], [ 2, %did_jump_exit233 ], [ 2, %data_misaligned239 ], [ 2, %did_jump_exit250 ], [ 2, %data_misaligned256 ], [ 2, %did_jump_exit267 ], [ 2, %data_misaligned273 ], [ 2, %did_jump_exit284 ], [ 2, %data_misaligned290 ], [ 2, %did_jump_exit301 ], [ 2, %data_misaligned307 ], [ 2, %did_jump_exit318 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail371 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %data_misaligned66 ], [ 1, %did_jump_exit76 ], [ 1, %data_misaligned82 ], [ 1, %did_jump_exit92 ], [ 1, %did_jump_exit96 ], [ 3, %data_misaligned100 ], [ 3, %did_jump_exit110 ], [ 3, %data_misaligned114 ], [ 3, %did_jump_exit124 ], [ 3, %did_jump_exit131 ], [ 6, %data_misaligned138 ], [ 6, %did_jump_exit145 ], [ 12, %data_misaligned151 ], [ 12, %did_jump_exit161 ], [ 12, %did_jump_exit168 ], [ 14, %data_misaligned172 ], [ 14, %did_jump_exit183 ], [ 14, %data_misaligned189 ], [ 14, %did_jump_exit200 ], [ 15, %data_misaligned206 ], [ 15, %did_jump_exit217 ], [ 15, %data_misaligned222 ], [ 15, %did_jump_exit233 ], [ 15, %data_misaligned239 ], [ 15, %did_jump_exit250 ], [ 15, %data_misaligned256 ], [ 15, %did_jump_exit267 ], [ 15, %data_misaligned273 ], [ 15, %did_jump_exit284 ], [ 15, %data_misaligned290 ], [ 15, %did_jump_exit301 ], [ 15, %data_misaligned307 ], [ 15, %did_jump_exit318 ], [ 16, %jump_aligned ], [ 16, %jump_misalign ]
  %tail372 = phi i8 [ %25, %data_misaligned ], [ %39, %did_jump_exit ], [ %46, %data_misaligned3 ], [ %60, %did_jump_exit13 ], [ %67, %data_misaligned19 ], [ %81, %did_jump_exit29 ], [ %88, %data_misaligned35 ], [ %102, %did_jump_exit45 ], [ %109, %data_misaligned50 ], [ %123, %did_jump_exit60 ], [ %130, %data_misaligned66 ], [ %144, %did_jump_exit76 ], [ %151, %data_misaligned82 ], [ %166, %did_jump_exit92 ], [ %175, %did_jump_exit96 ], [ %189, %data_misaligned100 ], [ %203, %did_jump_exit110 ], [ %211, %data_misaligned114 ], [ %226, %did_jump_exit124 ], [ %235, %did_jump_exit131 ], [ %248, %data_misaligned138 ], [ %262, %did_jump_exit145 ], [ %288, %data_misaligned151 ], [ %301, %did_jump_exit161 ], [ %310, %did_jump_exit168 ], [ %321, %data_misaligned172 ], [ %336, %did_jump_exit183 ], [ %344, %data_misaligned189 ], [ %360, %did_jump_exit200 ], [ %370, %data_misaligned206 ], [ %386, %did_jump_exit217 ], [ %394, %data_misaligned222 ], [ %410, %did_jump_exit233 ], [ %418, %data_misaligned239 ], [ %434, %did_jump_exit250 ], [ %442, %data_misaligned256 ], [ %458, %did_jump_exit267 ], [ %466, %data_misaligned273 ], [ %482, %did_jump_exit284 ], [ %490, %data_misaligned290 ], [ %506, %did_jump_exit301 ], [ %514, %data_misaligned307 ], [ %529, %did_jump_exit318 ], [ 1, %jump_aligned ], [ %537, %jump_misalign ]
  %548 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets374 = load i32, ptr %548, align 4
  %chain_total375 = add nuw i32 %chain_packets374, %packets
  %549 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget376 = load atomic i32, ptr %549 monotonic, align 4, !range !2
  %550 = icmp ult i32 %chain_total375, %chain_budget376
  br i1 %550, label %chain_lookup, label %chain_leave373, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %551 = lshr i32 %next_pc369, 1
  %552 = and i32 %551, 65535
  %553 = zext i32 %552 to i64
  %554 = mul i64 %553, 16
  %chain_slot377 = getelementptr i8, ptr %chain_table, i64 %554
  %555 = getelementptr i8, ptr %chain_slot377, i64 0
  %slot_pc378 = load i32, ptr %555, align 4
  %556 = icmp eq i32 %slot_pc378, %next_pc369
  br i1 %556, label %chain_hit379, label %chain_leave373, !prof !0

chain_leave373:                                   ; preds = %chain_lookup, %chain_exit
  %557 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %557, align 4
  %558 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail370, ptr %558, align 4
  %559 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail371, ptr %559, align 4
  %560 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail372, ptr %560, align 1
  ret void

chain_hit379:                                     ; preds = %chain_lookup
  %561 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc369, ptr %561, align 4
  %562 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total375, ptr %562, align 4
  %563 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %563, align 1
  %564 = getelementptr i8, ptr %chain_slot377, i64 8
  %chain_fn380 = load ptr, ptr %564, align 8
  musttail call swifttailcc void %chain_fn380(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
