; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010040(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65600
  %6 = icmp ugt i32 %5, 78
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb153 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb153, 0
  %11 = sub i32 %guard_lb153, 65600
  %12 = icmp ugt i32 %11, 78
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010040_entry, label %lb_guard_miss, !prof !0

insn_0x00010040_entry:                            ; preds = %lb_guard
  br label %insn_0x00010040

insn_0x00010040:                                  ; preds = %insn_0x00010040_entry
  %15 = getelementptr i8, ptr %cpu, i32 40
  store i32 15361, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %17, align 4
  br label %insn_0x00010044_entry

insn_0x00010044_entry:                            ; preds = %insn_0x00010040
  br label %insn_0x00010044

insn_0x00010044:                                  ; preds = %insn_0x00010044_entry
  %18 = getelementptr i8, ptr %cpu, i32 40
  store i32 61444, ptr %18, align 4
  br label %insn_0x00010046_entry

insn_0x00010046_entry:                            ; preds = %insn_0x00010044
  br label %insn_0x00010046

insn_0x00010046:                                  ; preds = %insn_0x00010046_entry
  br i1 false, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010046
  %19 = getelementptr i8, ptr %cpu, i32 188
  store i32 65606, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %21, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65606, i32 61444, i32 0)
  %22 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %22, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010046
  %page_slot = getelementptr ptr, ptr %page_table, i64 15
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %23 = getelementptr i8, ptr %page, i64 4
  %page_val = load i32, ptr %23, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %24 = getelementptr i8, ptr %cpu, i32 188
  store i32 65606, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %26, align 4
  %27 = call i32 @mem_read32(ptr %mem, i32 61444)
  %28 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %28, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %27, %did_jump_cont ]
  %29 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val, ptr %29, align 4
  br label %insn_0x00010048_entry

did_jump_exit:                                    ; preds = %page_slow
  %30 = getelementptr i8, ptr %cpu, i64 188
  %next_pc154 = load i32, ptr %30, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x00010048_entry:                            ; preds = %page_done
  br label %insn_0x00010048

insn_0x00010048:                                  ; preds = %insn_0x00010048_entry
  %31 = getelementptr i8, ptr %cpu, i32 40
  store i32 61448, ptr %31, align 4
  br label %insn_0x0001004a_entry

insn_0x0001004a_entry:                            ; preds = %insn_0x00010048
  br label %insn_0x0001004a

insn_0x0001004a:                                  ; preds = %insn_0x0001004a_entry
  br i1 false, label %data_misaligned1, label %data_aligned2, !prof !1

data_misaligned1:                                 ; preds = %insn_0x0001004a
  %32 = getelementptr i8, ptr %cpu, i32 188
  store i32 65610, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %34, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65610, i32 61448, i32 0)
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc155 = load i32, ptr %35, align 4
  br label %chain_exit

data_aligned2:                                    ; preds = %insn_0x0001004a
  %page_slot6 = getelementptr ptr, ptr %page_table, i64 15
  %page7 = load ptr, ptr %page_slot6, align 8
  %page_mapped8 = icmp ne ptr %page7, null
  br i1 %page_mapped8, label %page_fast3, label %page_slow4, !prof !0

page_fast3:                                       ; preds = %data_aligned2
  %36 = getelementptr i8, ptr %page7, i64 8
  %page_val9 = load i32, ptr %36, align 4
  br label %page_done5

page_slow4:                                       ; preds = %data_aligned2
  %37 = getelementptr i8, ptr %cpu, i32 188
  store i32 65610, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %39, align 4
  %40 = call i32 @mem_read32(ptr %mem, i32 61448)
  %41 = getelementptr i8, ptr %cpu, i32 296
  %dj12 = load i8, ptr %41, align 1
  %dj_set13 = icmp ne i8 %dj12, 0
  br i1 %dj_set13, label %did_jump_exit10, label %did_jump_cont11, !prof !1

page_done5:                                       ; preds = %did_jump_cont11, %page_fast3
  %mem_val14 = phi i32 [ %page_val9, %page_fast3 ], [ %40, %did_jump_cont11 ]
  %42 = getelementptr i8, ptr %cpu, i32 40
  store i32 %mem_val14, ptr %42, align 4
  br label %insn_0x0001004c_entry

did_jump_exit10:                                  ; preds = %page_slow4
  %43 = getelementptr i8, ptr %cpu, i64 188
  %next_pc156 = load i32, ptr %43, align 4
  br label %chain_exit

did_jump_cont11:                                  ; preds = %page_slow4
  br label %page_done5

insn_0x0001004c_entry:                            ; preds = %page_done5
  br label %insn_0x0001004c

insn_0x0001004c:                                  ; preds = %insn_0x0001004c_entry
  %44 = getelementptr i8, ptr %cpu, i32 0
  store i32 1, ptr %44, align 4
  br label %insn_0x0001004e_entry

insn_0x0001004e_entry:                            ; preds = %insn_0x0001004c
  br label %insn_0x0001004e

insn_0x0001004e:                                  ; preds = %insn_0x0001004e_entry
  %45 = getelementptr i8, ptr %cpu, i32 44
  store i32 15365, ptr %45, align 4
  br label %insn_0x00010052_entry

insn_0x00010052_entry:                            ; preds = %insn_0x0001004e
  br label %insn_0x00010052

insn_0x00010052:                                  ; preds = %insn_0x00010052_entry
  %46 = getelementptr i8, ptr %cpu, i32 44
  store i32 61460, ptr %46, align 4
  br label %insn_0x00010054_entry

insn_0x00010054_entry:                            ; preds = %insn_0x00010052
  br label %insn_0x00010054

insn_0x00010054:                                  ; preds = %insn_0x00010054_entry
  %47 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %47, align 4
  %addr = add i32 %fp, -4
  %48 = and i32 %addr, 3
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %data_misaligned15, label %data_aligned16, !prof !1

data_misaligned15:                                ; preds = %insn_0x00010054
  %50 = getelementptr i8, ptr %cpu, i32 188
  store i32 65620, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %52, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65620, i32 %addr, i32 65536)
  %53 = getelementptr i8, ptr %cpu, i64 188
  %next_pc157 = load i32, ptr %53, align 4
  br label %chain_exit

data_aligned16:                                   ; preds = %insn_0x00010054
  %54 = lshr i32 %addr, 12
  %page_index = zext i32 %54 to i64
  %page_slot17 = getelementptr ptr, ptr %page_table, i64 %page_index
  %page18 = load ptr, ptr %page_slot17, align 8
  %page_mapped19 = icmp ne ptr %page18, null
  br i1 %page_mapped19, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned16
  %55 = and i32 %addr, 4095
  %page_offset = zext i32 %55 to i64
  %56 = getelementptr i8, ptr %page18, i64 %page_offset
  store i32 %mem_val14, ptr %56, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned16
  %57 = getelementptr i8, ptr %cpu, i32 188
  store i32 65620, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %59, align 4
  call void @mem_write32(ptr %mem, i32 %addr, i32 %mem_val14)
  %60 = getelementptr i8, ptr %cpu, i32 296
  %dj22 = load i8, ptr %60, align 1
  %dj_set23 = icmp ne i8 %dj22, 0
  br i1 %dj_set23, label %did_jump_exit20, label %did_jump_cont21, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont21, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %61 = icmp ne i8 %cec_pending, 0
  br i1 %61, label %cec_check, label %cec_checked, !prof !1

did_jump_exit20:                                  ; preds = %page_wr_slow
  %62 = getelementptr i8, ptr %cpu, i64 188
  %next_pc158 = load i32, ptr %62, align 4
  br label %chain_exit

did_jump_cont21:                                  ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %63 = getelementptr i8, ptr %cpu, i32 188
  store i32 65622, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %65, align 4
  call void @cec_check_pending(ptr %cpu)
  %66 = getelementptr i8, ptr %cpu, i32 296
  %dj26 = load i8, ptr %66, align 1
  %dj_set27 = icmp ne i8 %dj26, 0
  br i1 %dj_set27, label %did_jump_exit24, label %did_jump_cont25, !prof !1

cec_checked:                                      ; preds = %did_jump_cont25, %page_wr_done
  br label %insn_0x00010056_entry

did_jump_exit24:                                  ; preds = %cec_check
  %67 = getelementptr i8, ptr %cpu, i64 188
  %next_pc159 = load i32, ptr %67, align 4
  br label %chain_exit

did_jump_cont25:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010056_entry:                            ; preds = %cec_checked
  br label %insn_0x00010056

insn_0x00010056:                                  ; preds = %insn_0x00010056_entry
  %68 = getelementptr i8, ptr %cpu, i32 40
  store i32 15363, ptr %68, align 4
  br label %insn_0x0001005a_entry

insn_0x0001005a_entry:                            ; preds = %insn_0x00010056
  br label %insn_0x0001005a

insn_0x0001005a:                                  ; preds = %insn_0x0001005a_entry
  %69 = getelementptr i8, ptr %cpu, i32 40
  store i32 61452, ptr %69, align 4
  br label %insn_0x0001005c_entry

insn_0x0001005c_entry:                            ; preds = %insn_0x0001005a
  br label %insn_0x0001005c

insn_0x0001005c:                                  ; preds = %insn_0x0001005c_entry
  br i1 false, label %data_misaligned28, label %data_aligned29, !prof !1

data_misaligned28:                                ; preds = %insn_0x0001005c
  %70 = getelementptr i8, ptr %cpu, i32 188
  store i32 65628, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %72, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65628, i32 61452, i32 0)
  %73 = getelementptr i8, ptr %cpu, i64 188
  %next_pc160 = load i32, ptr %73, align 4
  br label %chain_exit

data_aligned29:                                   ; preds = %insn_0x0001005c
  %page_slot33 = getelementptr ptr, ptr %page_table, i64 15
  %page34 = load ptr, ptr %page_slot33, align 8
  %page_mapped35 = icmp ne ptr %page34, null
  br i1 %page_mapped35, label %page_fast30, label %page_slow31, !prof !0

page_fast30:                                      ; preds = %data_aligned29
  %74 = getelementptr i8, ptr %page34, i64 12
  %page_val36 = load i32, ptr %74, align 4
  br label %page_done32

page_slow31:                                      ; preds = %data_aligned29
  %75 = getelementptr i8, ptr %cpu, i32 188
  store i32 65628, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %77, align 4
  %78 = call i32 @mem_read32(ptr %mem, i32 61452)
  %79 = getelementptr i8, ptr %cpu, i32 296
  %dj39 = load i8, ptr %79, align 1
  %dj_set40 = icmp ne i8 %dj39, 0
  br i1 %dj_set40, label %did_jump_exit37, label %did_jump_cont38, !prof !1

page_done32:                                      ; preds = %did_jump_cont38, %page_fast30
  %mem_val41 = phi i32 [ %page_val36, %page_fast30 ], [ %78, %did_jump_cont38 ]
  %80 = getelementptr i8, ptr %cpu, i32 40
  store i32 %mem_val41, ptr %80, align 4
  br label %insn_0x0001005e_entry

did_jump_exit37:                                  ; preds = %page_slow31
  %81 = getelementptr i8, ptr %cpu, i64 188
  %next_pc161 = load i32, ptr %81, align 4
  br label %chain_exit

did_jump_cont38:                                  ; preds = %page_slow31
  br label %page_done32

insn_0x0001005e_entry:                            ; preds = %page_done32
  br label %insn_0x0001005e

insn_0x0001005e:                                  ; preds = %insn_0x0001005e_entry
  %82 = getelementptr i8, ptr %cpu, i32 52
  %old = load i32, ptr %82, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 0
  %83 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_hi, ptr %83, align 4
  br label %insn_0x00010062_entry

insn_0x00010062_entry:                            ; preds = %insn_0x0001005e
  br label %insn_0x00010062

insn_0x00010062:                                  ; preds = %insn_0x00010062_entry
  %84 = getelementptr i8, ptr %cpu, i32 48
  %old42 = load i32, ptr %84, align 4
  %lo_kept43 = and i32 %old42, 65535
  %with_hi44 = or i32 %lo_kept43, 16777216
  %85 = getelementptr i8, ptr %cpu, i32 48
  store i32 %with_hi44, ptr %85, align 4
  br label %insn_0x00010066_entry

insn_0x00010066_entry:                            ; preds = %insn_0x00010062
  br label %insn_0x00010066

insn_0x00010066:                                  ; preds = %insn_0x00010066_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 61464
  %86 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_lo, ptr %86, align 4
  br label %insn_0x0001006a_entry

insn_0x0001006a_entry:                            ; preds = %insn_0x00010066
  br label %insn_0x0001006a

insn_0x0001006a:                                  ; preds = %insn_0x0001006a_entry
  %addr45 = add i32 %fp, -8
  %87 = and i32 %addr45, 3
  %88 = icmp ne i32 %87, 0
  br i1 %88, label %data_misaligned46, label %data_aligned47, !prof !1

data_misaligned46:                                ; preds = %insn_0x0001006a
  %89 = getelementptr i8, ptr %cpu, i32 188
  store i32 65642, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %91, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65642, i32 %addr45, i32 65536)
  %92 = getelementptr i8, ptr %cpu, i64 188
  %next_pc162 = load i32, ptr %92, align 4
  br label %chain_exit

data_aligned47:                                   ; preds = %insn_0x0001006a
  %93 = lshr i32 %addr45, 12
  %page_index51 = zext i32 %93 to i64
  %page_slot52 = getelementptr ptr, ptr %page_table, i64 %page_index51
  %page53 = load ptr, ptr %page_slot52, align 8
  %page_mapped54 = icmp ne ptr %page53, null
  br i1 %page_mapped54, label %page_wr_fast48, label %page_wr_slow49, !prof !0

page_wr_fast48:                                   ; preds = %data_aligned47
  %94 = and i32 %addr45, 4095
  %page_offset55 = zext i32 %94 to i64
  %95 = getelementptr i8, ptr %page53, i64 %page_offset55
  store i32 %mem_val41, ptr %95, align 4
  br label %page_wr_done50

page_wr_slow49:                                   ; preds = %data_aligned47
  %96 = getelementptr i8, ptr %cpu, i32 188
  store i32 65642, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %98, align 4
  call void @mem_write32(ptr %mem, i32 %addr45, i32 %mem_val41)
  %99 = getelementptr i8, ptr %cpu, i32 296
  %dj58 = load i8, ptr %99, align 1
  %dj_set59 = icmp ne i8 %dj58, 0
  br i1 %dj_set59, label %did_jump_exit56, label %did_jump_cont57, !prof !1

page_wr_done50:                                   ; preds = %did_jump_cont57, %page_wr_fast48
  %cec_pending60 = load i8, ptr %cec_pending_flag, align 1
  %100 = icmp ne i8 %cec_pending60, 0
  br i1 %100, label %cec_check61, label %cec_checked62, !prof !1

did_jump_exit56:                                  ; preds = %page_wr_slow49
  %101 = getelementptr i8, ptr %cpu, i64 188
  %next_pc163 = load i32, ptr %101, align 4
  br label %chain_exit

did_jump_cont57:                                  ; preds = %page_wr_slow49
  br label %page_wr_done50

cec_check61:                                      ; preds = %page_wr_done50
  %102 = getelementptr i8, ptr %cpu, i32 188
  store i32 65644, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %104, align 4
  call void @cec_check_pending(ptr %cpu)
  %105 = getelementptr i8, ptr %cpu, i32 296
  %dj65 = load i8, ptr %105, align 1
  %dj_set66 = icmp ne i8 %dj65, 0
  br i1 %dj_set66, label %did_jump_exit63, label %did_jump_cont64, !prof !1

cec_checked62:                                    ; preds = %did_jump_cont64, %page_wr_done50
  br label %insn_0x0001006c_entry

did_jump_exit63:                                  ; preds = %cec_check61
  %106 = getelementptr i8, ptr %cpu, i64 188
  %next_pc164 = load i32, ptr %106, align 4
  br label %chain_exit

did_jump_cont64:                                  ; preds = %cec_check61
  br label %cec_checked62

insn_0x0001006c_entry:                            ; preds = %cec_checked62
  br label %insn_0x0001006c

insn_0x0001006c:                                  ; preds = %insn_0x0001006c_entry
  %lo_kept67 = and i32 %mem_val41, 65535
  %with_hi68 = or i32 %lo_kept67, 0
  %107 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi68, ptr %107, align 4
  br label %insn_0x00010070_entry

insn_0x00010070_entry:                            ; preds = %insn_0x0001006c
  br label %insn_0x00010070

insn_0x00010070:                                  ; preds = %insn_0x00010070_entry
  %hi_kept69 = and i32 %with_hi68, -65536
  %with_lo70 = or i32 %hi_kept69, 61456
  %108 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo70, ptr %108, align 4
  br label %insn_0x00010074_entry

insn_0x00010074_entry:                            ; preds = %insn_0x00010070
  br label %insn_0x00010074

insn_0x00010074:                                  ; preds = %insn_0x00010074_entry
  %109 = and i32 %with_lo70, 3
  %110 = icmp ne i32 %109, 0
  br i1 %110, label %data_misaligned71, label %data_aligned72, !prof !1

data_misaligned71:                                ; preds = %insn_0x00010074
  %111 = getelementptr i8, ptr %cpu, i32 188
  store i32 65652, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %113, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65652, i32 %with_lo70, i32 65536)
  %114 = getelementptr i8, ptr %cpu, i64 188
  %next_pc165 = load i32, ptr %114, align 4
  br label %chain_exit

data_aligned72:                                   ; preds = %insn_0x00010074
  %115 = lshr i32 %with_lo70, 12
  %page_index76 = zext i32 %115 to i64
  %page_slot77 = getelementptr ptr, ptr %page_table, i64 %page_index76
  %page78 = load ptr, ptr %page_slot77, align 8
  %page_mapped79 = icmp ne ptr %page78, null
  br i1 %page_mapped79, label %page_wr_fast73, label %page_wr_slow74, !prof !0

page_wr_fast73:                                   ; preds = %data_aligned72
  %116 = and i32 %with_lo70, 4095
  %page_offset80 = zext i32 %116 to i64
  %117 = getelementptr i8, ptr %page78, i64 %page_offset80
  store i32 1, ptr %117, align 4
  br label %page_wr_done75

page_wr_slow74:                                   ; preds = %data_aligned72
  %118 = getelementptr i8, ptr %cpu, i32 188
  store i32 65652, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %120, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo70, i32 1)
  %121 = getelementptr i8, ptr %cpu, i32 296
  %dj83 = load i8, ptr %121, align 1
  %dj_set84 = icmp ne i8 %dj83, 0
  br i1 %dj_set84, label %did_jump_exit81, label %did_jump_cont82, !prof !1

page_wr_done75:                                   ; preds = %did_jump_cont82, %page_wr_fast73
  %cec_pending85 = load i8, ptr %cec_pending_flag, align 1
  %122 = icmp ne i8 %cec_pending85, 0
  br i1 %122, label %cec_check86, label %cec_checked87, !prof !1

did_jump_exit81:                                  ; preds = %page_wr_slow74
  %123 = getelementptr i8, ptr %cpu, i64 188
  %next_pc166 = load i32, ptr %123, align 4
  br label %chain_exit

did_jump_cont82:                                  ; preds = %page_wr_slow74
  br label %page_wr_done75

cec_check86:                                      ; preds = %page_wr_done75
  %124 = getelementptr i8, ptr %cpu, i32 188
  store i32 65654, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %126, align 4
  call void @cec_check_pending(ptr %cpu)
  %127 = getelementptr i8, ptr %cpu, i32 296
  %dj90 = load i8, ptr %127, align 1
  %dj_set91 = icmp ne i8 %dj90, 0
  br i1 %dj_set91, label %did_jump_exit88, label %did_jump_cont89, !prof !1

cec_checked87:                                    ; preds = %did_jump_cont89, %page_wr_done75
  br label %insn_0x00010076_entry

did_jump_exit88:                                  ; preds = %cec_check86
  %128 = getelementptr i8, ptr %cpu, i64 188
  %next_pc167 = load i32, ptr %128, align 4
  br label %chain_exit

did_jump_cont89:                                  ; preds = %cec_check86
  br label %cec_checked87

insn_0x00010076_entry:                            ; preds = %cec_checked87
  br label %insn_0x00010076

insn_0x00010076:                                  ; preds = %insn_0x00010076_entry
  %129 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %129, align 4
  br label %insn_0x00010078_entry

insn_0x00010078_entry:                            ; preds = %insn_0x00010076
  br label %insn_0x00010078

insn_0x00010078:                                  ; preds = %insn_0x00010078_entry
  br i1 false, label %data_misaligned92, label %data_aligned93, !prof !1

data_misaligned92:                                ; preds = %insn_0x00010078
  %130 = getelementptr i8, ptr %cpu, i32 188
  store i32 65656, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 308
  store i32 21, ptr %132, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65656, i32 61460, i32 65536)
  %133 = getelementptr i8, ptr %cpu, i64 188
  %next_pc168 = load i32, ptr %133, align 4
  br label %chain_exit

data_aligned93:                                   ; preds = %insn_0x00010078
  %page_slot97 = getelementptr ptr, ptr %page_table, i64 15
  %page98 = load ptr, ptr %page_slot97, align 8
  %page_mapped99 = icmp ne ptr %page98, null
  br i1 %page_mapped99, label %page_wr_fast94, label %page_wr_slow95, !prof !0

page_wr_fast94:                                   ; preds = %data_aligned93
  %134 = getelementptr i8, ptr %page98, i64 20
  store i32 0, ptr %134, align 4
  br label %page_wr_done96

page_wr_slow95:                                   ; preds = %data_aligned93
  %135 = getelementptr i8, ptr %cpu, i32 188
  store i32 65656, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 308
  store i32 21, ptr %137, align 4
  call void @mem_write32(ptr %mem, i32 61460, i32 0)
  %138 = getelementptr i8, ptr %cpu, i32 296
  %dj102 = load i8, ptr %138, align 1
  %dj_set103 = icmp ne i8 %dj102, 0
  br i1 %dj_set103, label %did_jump_exit100, label %did_jump_cont101, !prof !1

page_wr_done96:                                   ; preds = %did_jump_cont101, %page_wr_fast94
  %cec_pending104 = load i8, ptr %cec_pending_flag, align 1
  %139 = icmp ne i8 %cec_pending104, 0
  br i1 %139, label %cec_check105, label %cec_checked106, !prof !1

did_jump_exit100:                                 ; preds = %page_wr_slow95
  %140 = getelementptr i8, ptr %cpu, i64 188
  %next_pc169 = load i32, ptr %140, align 4
  br label %chain_exit

did_jump_cont101:                                 ; preds = %page_wr_slow95
  br label %page_wr_done96

cec_check105:                                     ; preds = %page_wr_done96
  %141 = getelementptr i8, ptr %cpu, i32 188
  store i32 65658, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %142, align 4
  %143 = getelementptr i8, ptr %cpu, i32 308
  store i32 21, ptr %143, align 4
  call void @cec_check_pending(ptr %cpu)
  %144 = getelementptr i8, ptr %cpu, i32 296
  %dj109 = load i8, ptr %144, align 1
  %dj_set110 = icmp ne i8 %dj109, 0
  br i1 %dj_set110, label %did_jump_exit107, label %did_jump_cont108, !prof !1

cec_checked106:                                   ; preds = %did_jump_cont108, %page_wr_done96
  br label %insn_0x0001007a_entry

did_jump_exit107:                                 ; preds = %cec_check105
  %145 = getelementptr i8, ptr %cpu, i64 188
  %next_pc170 = load i32, ptr %145, align 4
  br label %chain_exit

did_jump_cont108:                                 ; preds = %cec_check105
  br label %cec_checked106

insn_0x0001007a_entry:                            ; preds = %cec_checked106
  br label %insn_0x0001007a

insn_0x0001007a:                                  ; preds = %insn_0x0001007a_entry
  %146 = getelementptr i8, ptr %cpu, i32 28
  store i32 0, ptr %146, align 4
  br label %insn_0x0001007c_entry

insn_0x0001007c_entry:                            ; preds = %insn_0x0001007a
  br label %insn_0x0001007c

insn_0x0001007c:                                  ; preds = %insn_0x0001007c_entry
  %hi_kept111 = and i32 %with_hi44, -65536
  %with_lo112 = or i32 %hi_kept111, 0
  %147 = getelementptr i8, ptr %cpu, i32 48
  store i32 %with_lo112, ptr %147, align 4
  br label %insn_0x00010080_entry

insn_0x00010080_entry:                            ; preds = %insn_0x0001007c
  br label %insn_0x00010080

insn_0x00010080:                                  ; preds = %insn_0x00010080_entry
  %148 = getelementptr i8, ptr %cpu, i32 24
  store i32 0, ptr %148, align 4
  br label %insn_0x00010082_entry

insn_0x00010082_entry:                            ; preds = %insn_0x00010080
  br label %insn_0x00010082

insn_0x00010082:                                  ; preds = %insn_0x00010082_entry
  %149 = getelementptr i8, ptr %cpu, i32 20
  store i32 1, ptr %149, align 4
  br label %insn_0x00010084_entry

insn_0x00010084_entry:                            ; preds = %insn_0x00010082
  br label %insn_0x00010084

insn_0x00010084:                                  ; preds = %insn_0x00010084_entry
  %150 = getelementptr i8, ptr %cpu, i32 276
  %cc_old = load i32, ptr %150, align 4
  %addr113 = add i32 %fp, -4
  %151 = and i32 %addr113, 3
  %152 = icmp ne i32 %151, 0
  br i1 %152, label %data_misaligned114, label %data_aligned115, !prof !1

data_misaligned114:                               ; preds = %insn_0x00010084
  %153 = getelementptr i8, ptr %cpu, i32 188
  store i32 65668, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %155, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65668, i32 %addr113, i32 0)
  %156 = getelementptr i8, ptr %cpu, i64 188
  %next_pc171 = load i32, ptr %156, align 4
  br label %chain_exit

data_aligned115:                                  ; preds = %insn_0x00010084
  %157 = lshr i32 %addr113, 12
  %page_index119 = zext i32 %157 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122 = icmp ne ptr %page121, null
  br i1 %page_mapped122, label %page_fast116, label %page_slow117, !prof !0

page_fast116:                                     ; preds = %data_aligned115
  %158 = and i32 %addr113, 4095
  %page_offset123 = zext i32 %158 to i64
  %159 = getelementptr i8, ptr %page121, i64 %page_offset123
  %page_val124 = load i32, ptr %159, align 4
  br label %page_done118

page_slow117:                                     ; preds = %data_aligned115
  %160 = getelementptr i8, ptr %cpu, i32 188
  store i32 65668, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %162, align 4
  %163 = call i32 @mem_read32(ptr %mem, i32 %addr113)
  %164 = getelementptr i8, ptr %cpu, i32 296
  %dj127 = load i8, ptr %164, align 1
  %dj_set128 = icmp ne i8 %dj127, 0
  br i1 %dj_set128, label %did_jump_exit125, label %did_jump_cont126, !prof !1

page_done118:                                     ; preds = %did_jump_cont126, %page_fast116
  %mem_val129 = phi i32 [ %page_val124, %page_fast116 ], [ %163, %did_jump_cont126 ]
  %165 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val, ptr %165, align 4
  %166 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val129, ptr %166, align 4
  br label %insn_0x0001008c_entry

did_jump_exit125:                                 ; preds = %page_slow117
  %167 = getelementptr i8, ptr %cpu, i64 188
  %next_pc172 = load i32, ptr %167, align 4
  br label %chain_exit

did_jump_cont126:                                 ; preds = %page_slow117
  br label %page_done118

insn_0x0001008c_entry:                            ; preds = %page_done118
  br label %insn_0x0001008c

insn_0x0001008c:                                  ; preds = %insn_0x0001008c_entry
  %addr130 = add i32 %fp, -8
  %168 = and i32 %addr130, 3
  %169 = icmp ne i32 %168, 0
  br i1 %169, label %data_misaligned131, label %data_aligned132, !prof !1

data_misaligned131:                               ; preds = %insn_0x0001008c
  %170 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 308
  store i32 27, ptr %172, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65676, i32 %addr130, i32 0)
  %173 = getelementptr i8, ptr %cpu, i64 188
  %next_pc173 = load i32, ptr %173, align 4
  br label %chain_exit

data_aligned132:                                  ; preds = %insn_0x0001008c
  %174 = lshr i32 %addr130, 12
  %page_index136 = zext i32 %174 to i64
  %page_slot137 = getelementptr ptr, ptr %page_table, i64 %page_index136
  %page138 = load ptr, ptr %page_slot137, align 8
  %page_mapped139 = icmp ne ptr %page138, null
  br i1 %page_mapped139, label %page_fast133, label %page_slow134, !prof !0

page_fast133:                                     ; preds = %data_aligned132
  %175 = and i32 %addr130, 4095
  %page_offset140 = zext i32 %175 to i64
  %176 = getelementptr i8, ptr %page138, i64 %page_offset140
  %page_val141 = load i32, ptr %176, align 4
  br label %page_done135

page_slow134:                                     ; preds = %data_aligned132
  %177 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 308
  store i32 27, ptr %179, align 4
  %180 = call i32 @mem_read32(ptr %mem, i32 %addr130)
  %181 = getelementptr i8, ptr %cpu, i32 296
  %dj144 = load i8, ptr %181, align 1
  %dj_set145 = icmp ne i8 %dj144, 0
  br i1 %dj_set145, label %did_jump_exit142, label %did_jump_cont143, !prof !1

page_done135:                                     ; preds = %did_jump_cont143, %page_fast133
  %mem_val146 = phi i32 [ %page_val141, %page_fast133 ], [ %180, %did_jump_cont143 ]
  %182 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mem_val146, ptr %182, align 4
  br label %insn_0x0001008e_entry

did_jump_exit142:                                 ; preds = %page_slow134
  %183 = getelementptr i8, ptr %cpu, i64 188
  %next_pc174 = load i32, ptr %183, align 4
  br label %chain_exit

did_jump_cont143:                                 ; preds = %page_slow134
  br label %page_done135

insn_0x0001008e_entry:                            ; preds = %page_done135
  br label %insn_0x0001008e

insn_0x0001008e:                                  ; preds = %insn_0x0001008e_entry
  %184 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %185, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65678
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65682
  %186 = getelementptr i8, ptr %cpu, i32 156
  %lc147 = load i32, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i32 148
  %lt148 = load i32, ptr %187, align 4
  %lc_gt1149 = icmp ugt i32 %lc147, 1
  %at_lb150 = icmp eq i32 %lb1, 65678
  %hwloop_cond151 = and i1 %lc_gt1149, %at_lb150
  %hwloop_rets152 = select i1 %hwloop_cond151, i32 %lt148, i32 %hwloop_rets
  %188 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets152, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i32 188
  store i32 66344, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %190, align 4
  %chain_total = add nuw i32 %chain_packets, 28
  %191 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %191 monotonic, align 4, !range !2
  %192 = icmp ult i32 %chain_total, %chain_budget
  br i1 %192, label %chain_go, label %chain_leave175, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %193 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %193, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %insn_0x0001008e
  %chain_slot = getelementptr i8, ptr %chain_table, i64 530752
  %194 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %194, align 4
  %195 = icmp eq i32 %slot_pc, 66344
  br i1 %195, label %chain_hit, label %chain_leave175, !prof !0

chain_leave175:                                   ; preds = %chain_go, %insn_0x0001008e
  %196 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %196, align 4
  %197 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i64 308
  store i32 28, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %199, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %200 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %201, align 4
  %202 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %202, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit142, %data_misaligned131, %did_jump_exit125, %data_misaligned114, %did_jump_exit107, %did_jump_exit100, %data_misaligned92, %did_jump_exit88, %did_jump_exit81, %data_misaligned71, %did_jump_exit63, %did_jump_exit56, %data_misaligned46, %did_jump_exit37, %data_misaligned28, %did_jump_exit24, %did_jump_exit20, %data_misaligned15, %did_jump_exit10, %data_misaligned1, %did_jump_exit, %data_misaligned
  %next_pc176 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc154, %did_jump_exit ], [ %next_pc155, %data_misaligned1 ], [ %next_pc156, %did_jump_exit10 ], [ %next_pc157, %data_misaligned15 ], [ %next_pc158, %did_jump_exit20 ], [ %next_pc159, %did_jump_exit24 ], [ %next_pc160, %data_misaligned28 ], [ %next_pc161, %did_jump_exit37 ], [ %next_pc162, %data_misaligned46 ], [ %next_pc163, %did_jump_exit56 ], [ %next_pc164, %did_jump_exit63 ], [ %next_pc165, %data_misaligned71 ], [ %next_pc166, %did_jump_exit81 ], [ %next_pc167, %did_jump_exit88 ], [ %next_pc168, %data_misaligned92 ], [ %next_pc169, %did_jump_exit100 ], [ %next_pc170, %did_jump_exit107 ], [ %next_pc171, %data_misaligned114 ], [ %next_pc172, %did_jump_exit125 ], [ %next_pc173, %data_misaligned131 ], [ %next_pc174, %did_jump_exit142 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 5, %data_misaligned1 ], [ 5, %did_jump_exit10 ], [ 9, %data_misaligned15 ], [ 9, %did_jump_exit20 ], [ 9, %did_jump_exit24 ], [ 12, %data_misaligned28 ], [ 12, %did_jump_exit37 ], [ 16, %data_misaligned46 ], [ 16, %did_jump_exit56 ], [ 16, %did_jump_exit63 ], [ 19, %data_misaligned71 ], [ 19, %did_jump_exit81 ], [ 19, %did_jump_exit88 ], [ 21, %data_misaligned92 ], [ 21, %did_jump_exit100 ], [ 21, %did_jump_exit107 ], [ 26, %data_misaligned114 ], [ 26, %did_jump_exit125 ], [ 27, %data_misaligned131 ], [ 27, %did_jump_exit142 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned1 ], [ 2, %did_jump_exit10 ], [ 2, %data_misaligned15 ], [ 2, %did_jump_exit20 ], [ 2, %did_jump_exit24 ], [ 2, %data_misaligned28 ], [ 2, %did_jump_exit37 ], [ 2, %data_misaligned46 ], [ 2, %did_jump_exit56 ], [ 2, %did_jump_exit63 ], [ 2, %data_misaligned71 ], [ 2, %did_jump_exit81 ], [ 2, %did_jump_exit88 ], [ 2, %data_misaligned92 ], [ 2, %did_jump_exit100 ], [ 2, %did_jump_exit107 ], [ 8, %data_misaligned114 ], [ 8, %did_jump_exit125 ], [ 2, %data_misaligned131 ], [ 2, %did_jump_exit142 ]
  %tail177 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 5, %data_misaligned1 ], [ 5, %did_jump_exit10 ], [ 9, %data_misaligned15 ], [ 9, %did_jump_exit20 ], [ 9, %did_jump_exit24 ], [ 12, %data_misaligned28 ], [ 12, %did_jump_exit37 ], [ 16, %data_misaligned46 ], [ 16, %did_jump_exit56 ], [ 16, %did_jump_exit63 ], [ 19, %data_misaligned71 ], [ 19, %did_jump_exit81 ], [ 19, %did_jump_exit88 ], [ 21, %data_misaligned92 ], [ 21, %did_jump_exit100 ], [ 21, %did_jump_exit107 ], [ 26, %data_misaligned114 ], [ 26, %did_jump_exit125 ], [ 27, %data_misaligned131 ], [ 27, %did_jump_exit142 ]
  %203 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets179 = load i32, ptr %203, align 4
  %chain_total180 = add nuw i32 %chain_packets179, %packets
  %204 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget181 = load atomic i32, ptr %204 monotonic, align 4, !range !2
  %205 = icmp ult i32 %chain_total180, %chain_budget181
  br i1 %205, label %chain_lookup, label %chain_leave178, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %206 = lshr i32 %next_pc176, 1
  %207 = and i32 %206, 65535
  %208 = zext i32 %207 to i64
  %209 = mul i64 %208, 16
  %chain_slot182 = getelementptr i8, ptr %chain_table, i64 %209
  %210 = getelementptr i8, ptr %chain_slot182, i64 0
  %slot_pc183 = load i32, ptr %210, align 4
  %211 = icmp eq i32 %slot_pc183, %next_pc176
  br i1 %211, label %chain_hit184, label %chain_leave178, !prof !0

chain_leave178:                                   ; preds = %chain_lookup, %chain_exit
  %212 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %212, align 4
  %213 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail177, ptr %213, align 4
  ret void

chain_hit184:                                     ; preds = %chain_lookup
  %214 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total180, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %215, align 1
  %216 = getelementptr i8, ptr %chain_slot182, i64 8
  %chain_fn185 = load ptr, ptr %216, align 8
  musttail call swifttailcc void %chain_fn185(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
