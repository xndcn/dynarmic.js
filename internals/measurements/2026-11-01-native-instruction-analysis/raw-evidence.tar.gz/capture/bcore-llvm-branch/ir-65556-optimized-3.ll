; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010014(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65599
  %5 = icmp ult i32 %4, -43
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb324 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb324, -65599
  %8 = icmp ult i32 %7, -43
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010014, label %common.ret, !prof !0

insn_0x00010014:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %10, align 4
  %sp_dec = add i32 %sp, -4
  %11 = getelementptr i8, ptr %cpu, i64 16
  %r = load i32, ptr %11, align 4
  %12 = and i32 %sp, 3
  %.not = icmp eq i32 %12, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010014
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %14, align 4
  tail call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec, i32 65536)
  %15 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 296
  %17 = load i8, ptr %16, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010014
  %18 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %18 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %19 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %19 to i64
  %20 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %20, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %21 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %22, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %23 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %23, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %did_jump_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %sp_dec1 = add i32 %sp, -8
  %24 = getelementptr i8, ptr %cpu, i64 20
  %r2 = load i32, ptr %24, align 4
  %25 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %25 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11.not = icmp eq ptr %page10, null
  br i1 %page_mapped11.not, label %page_wr_slow6, label %page_wr_fast5, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %26 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %26, align 4
  br label %chain_exit

page_wr_fast5:                                    ; preds = %page_wr_done
  %27 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %28, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %page_wr_done
  %29 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %30, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %31 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %31, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_wr_done7, label %did_jump_exit13, !prof !0

page_wr_done7:                                    ; preds = %page_wr_slow6, %page_wr_fast5
  %sp_dec17 = add i32 %sp, -12
  %32 = getelementptr i8, ptr %cpu, i64 24
  %r18 = load i32, ptr %32, align 4
  %33 = lshr i32 %sp_dec17, 12
  %page_index24 = zext i32 %33 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27.not = icmp eq ptr %page26, null
  br i1 %page_mapped27.not, label %page_wr_slow22, label %page_wr_fast21, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %34 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %34, align 4
  br label %chain_exit

page_wr_fast21:                                   ; preds = %page_wr_done7
  %35 = and i32 %sp_dec17, 4095
  %page_offset28 = zext i32 %35 to i64
  %36 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %r18, ptr %36, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %page_wr_done7
  %37 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %38, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %r18)
  %39 = getelementptr i8, ptr %cpu, i64 296
  %dj31 = load i8, ptr %39, align 1
  %dj_set32.not = icmp eq i8 %dj31, 0
  br i1 %dj_set32.not, label %page_wr_done23, label %did_jump_exit29, !prof !0

page_wr_done23:                                   ; preds = %page_wr_slow22, %page_wr_fast21
  %sp_dec33 = add i32 %sp, -16
  %40 = getelementptr i8, ptr %cpu, i64 28
  %r34 = load i32, ptr %40, align 4
  %41 = lshr i32 %sp_dec33, 12
  %page_index40 = zext i32 %41 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43.not = icmp eq ptr %page42, null
  br i1 %page_mapped43.not, label %page_wr_slow38, label %page_wr_fast37, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc329 = load i32, ptr %42, align 4
  br label %chain_exit

page_wr_fast37:                                   ; preds = %page_wr_done23
  %43 = and i32 %sp_dec33, 4095
  %page_offset44 = zext i32 %43 to i64
  %44 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %r34, ptr %44, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %page_wr_done23
  %45 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %46, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec33, i32 %r34)
  %47 = getelementptr i8, ptr %cpu, i64 296
  %dj47 = load i8, ptr %47, align 1
  %dj_set48.not = icmp eq i8 %dj47, 0
  br i1 %dj_set48.not, label %page_wr_done39, label %did_jump_exit45, !prof !0

page_wr_done39:                                   ; preds = %page_wr_slow38, %page_wr_fast37
  %sp_dec49 = add i32 %sp, -20
  %48 = getelementptr i8, ptr %cpu, i64 44
  %p = load i32, ptr %48, align 4
  %49 = lshr i32 %sp_dec49, 12
  %page_index55 = zext i32 %49 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58.not = icmp eq ptr %page57, null
  br i1 %page_mapped58.not, label %page_wr_slow53, label %page_wr_fast52, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %50 = getelementptr i8, ptr %cpu, i64 188
  %next_pc331 = load i32, ptr %50, align 4
  br label %chain_exit

page_wr_fast52:                                   ; preds = %page_wr_done39
  %51 = and i32 %sp_dec49, 4095
  %page_offset59 = zext i32 %51 to i64
  %52 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p, ptr %52, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %page_wr_done39
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %54, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec49, i32 %p)
  %55 = getelementptr i8, ptr %cpu, i64 296
  %dj62 = load i8, ptr %55, align 1
  %dj_set63.not = icmp eq i8 %dj62, 0
  br i1 %dj_set63.not, label %page_wr_done54, label %did_jump_exit60, !prof !0

page_wr_done54:                                   ; preds = %page_wr_slow53, %page_wr_fast52
  %sp_dec64 = add i32 %sp, -24
  %56 = getelementptr i8, ptr %cpu, i64 48
  %p65 = load i32, ptr %56, align 4
  %57 = lshr i32 %sp_dec64, 12
  %page_index71 = zext i32 %57 to i64
  %page_slot72 = getelementptr ptr, ptr %page_table, i64 %page_index71
  %page73 = load ptr, ptr %page_slot72, align 8
  %page_mapped74.not = icmp eq ptr %page73, null
  br i1 %page_mapped74.not, label %page_wr_slow69, label %page_wr_fast68, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %58 = getelementptr i8, ptr %cpu, i64 188
  %next_pc333 = load i32, ptr %58, align 4
  br label %chain_exit

page_wr_fast68:                                   ; preds = %page_wr_done54
  %59 = and i32 %sp_dec64, 4095
  %page_offset75 = zext i32 %59 to i64
  %60 = getelementptr i8, ptr %page73, i64 %page_offset75
  store i32 %p65, ptr %60, align 4
  br label %page_wr_done70

page_wr_slow69:                                   ; preds = %page_wr_done54
  %61 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %62, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec64, i32 %p65)
  %63 = getelementptr i8, ptr %cpu, i64 296
  %dj78 = load i8, ptr %63, align 1
  %dj_set79.not = icmp eq i8 %dj78, 0
  br i1 %dj_set79.not, label %page_wr_done70, label %did_jump_exit76, !prof !0

page_wr_done70:                                   ; preds = %page_wr_slow69, %page_wr_fast68
  %sp_dec80 = add i32 %sp, -28
  %64 = getelementptr i8, ptr %cpu, i64 52
  %p81 = load i32, ptr %64, align 4
  %65 = lshr i32 %sp_dec80, 12
  %page_index87 = zext i32 %65 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90.not = icmp eq ptr %page89, null
  br i1 %page_mapped90.not, label %page_wr_slow85, label %page_wr_fast84, !prof !1

did_jump_exit76:                                  ; preds = %page_wr_slow69
  %66 = getelementptr i8, ptr %cpu, i64 188
  %next_pc335 = load i32, ptr %66, align 4
  br label %chain_exit

page_wr_fast84:                                   ; preds = %page_wr_done70
  %67 = and i32 %sp_dec80, 4095
  %page_offset91 = zext i32 %67 to i64
  %68 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %p81, ptr %68, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %page_wr_done70
  %69 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %70, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec80, i32 %p81)
  %71 = getelementptr i8, ptr %cpu, i64 296
  %dj94 = load i8, ptr %71, align 1
  %dj_set95.not = icmp eq i8 %dj94, 0
  br i1 %dj_set95.not, label %page_wr_done86, label %did_jump_exit92, !prof !0

page_wr_done86:                                   ; preds = %page_wr_slow85, %page_wr_fast84
  store i32 %sp_dec80, ptr %10, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not387 = icmp eq i8 %cec_pending, 0
  br i1 %.not387, label %insn_0x00010016, label %cec_check, !prof !0

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %72 = getelementptr i8, ptr %cpu, i64 188
  %next_pc337 = load i32, ptr %72, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done86
  %73 = getelementptr i8, ptr %cpu, i64 188
  store i32 65558, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %75, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %76 = getelementptr i8, ptr %cpu, i64 296
  %dj98 = load i8, ptr %76, align 1
  %dj_set99.not = icmp eq i8 %dj98, 0
  br i1 %dj_set99.not, label %insn_0x00010016, label %did_jump_exit96, !prof !0

did_jump_exit96:                                  ; preds = %cec_check
  %next_pc338 = load i32, ptr %73, align 4
  br label %chain_exit

insn_0x00010016:                                  ; preds = %page_wr_done86, %cec_check
  %77 = getelementptr i8, ptr %cpu, i64 40
  %old = load i32, ptr %77, align 4
  %lo_kept = and i32 %old, 65535
  store i32 %lo_kept, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %79, align 4
  %sp1 = add i32 %sp, -32
  %80 = lshr i32 %sp1, 12
  %page_index105 = zext i32 %80 to i64
  %page_slot106 = getelementptr ptr, ptr %page_table, i64 %page_index105
  %page107 = load ptr, ptr %page_slot106, align 8
  %page_mapped108.not = icmp eq ptr %page107, null
  br i1 %page_mapped108.not, label %page_wr_slow103, label %page_wr_fast102, !prof !1

page_wr_fast102:                                  ; preds = %insn_0x00010016
  %81 = and i32 %sp1, 4095
  %page_offset109 = zext i32 %81 to i64
  %82 = getelementptr i8, ptr %page107, i64 %page_offset109
  store i32 %rets, ptr %82, align 4
  br label %page_wr_done104

page_wr_slow103:                                  ; preds = %insn_0x00010016
  %83 = getelementptr i8, ptr %cpu, i64 188
  store i32 65562, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %85, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %86 = getelementptr i8, ptr %cpu, i64 296
  %dj112 = load i8, ptr %86, align 1
  %dj_set113.not = icmp eq i8 %dj112, 0
  br i1 %dj_set113.not, label %page_wr_done104, label %did_jump_exit110, !prof !0

page_wr_done104:                                  ; preds = %page_wr_slow103, %page_wr_fast102
  %sp2 = add i32 %sp, -36
  %87 = lshr i32 %sp2, 12
  %page_index119 = zext i32 %87 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122.not = icmp eq ptr %page121, null
  br i1 %page_mapped122.not, label %page_wr_slow117, label %page_wr_fast116, !prof !1

did_jump_exit110:                                 ; preds = %page_wr_slow103
  %next_pc340 = load i32, ptr %83, align 4
  br label %chain_exit

page_wr_fast116:                                  ; preds = %page_wr_done104
  %88 = and i32 %sp2, 4095
  %page_offset123 = zext i32 %88 to i64
  %89 = getelementptr i8, ptr %page121, i64 %page_offset123
  store i32 %fp, ptr %89, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %page_wr_done104
  %90 = getelementptr i8, ptr %cpu, i64 188
  store i32 65562, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %92, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %93 = getelementptr i8, ptr %cpu, i64 296
  %dj126 = load i8, ptr %93, align 1
  %dj_set127.not = icmp eq i8 %dj126, 0
  br i1 %dj_set127.not, label %page_wr_done118, label %did_jump_exit124, !prof !0

page_wr_done118:                                  ; preds = %page_wr_slow117, %page_wr_fast116
  store i32 %sp2, ptr %79, align 4
  %sp3 = add i32 %sp, -56
  store i32 %sp3, ptr %10, align 4
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %.not390 = icmp eq i8 %cec_pending128, 0
  br i1 %.not390, label %insn_0x0001001e, label %cec_check129, !prof !0

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %next_pc342 = load i32, ptr %90, align 4
  br label %chain_exit

cec_check129:                                     ; preds = %page_wr_done118
  %94 = getelementptr i8, ptr %cpu, i64 188
  store i32 65566, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %96, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %97 = getelementptr i8, ptr %cpu, i64 296
  %dj133 = load i8, ptr %97, align 1
  %dj_set134.not = icmp eq i8 %dj133, 0
  br i1 %dj_set134.not, label %insn_0x0001001e, label %did_jump_exit131, !prof !0

did_jump_exit131:                                 ; preds = %cec_check129
  %next_pc343 = load i32, ptr %94, align 4
  br label %chain_exit

insn_0x0001001e:                                  ; preds = %page_wr_done118, %cec_check129
  store i32 61440, ptr %77, align 4
  %98 = getelementptr i8, ptr %cpu, i64 4
  %old135 = load i32, ptr %98, align 4
  %lo_kept136 = and i32 %old135, 65535
  %with_hi137 = or i32 %lo_kept136, 1128398848
  store i32 %with_hi137, ptr %98, align 4
  %page_slot141 = getelementptr ptr, ptr %page_table, i64 15
  %page142 = load ptr, ptr %page_slot141, align 8
  %page_mapped143.not = icmp eq ptr %page142, null
  br i1 %page_mapped143.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x0001001e
  %page_val = load i32, ptr %page142, align 4
  br label %page_done

page_slow:                                        ; preds = %insn_0x0001001e
  %99 = getelementptr i8, ptr %cpu, i64 188
  store i32 65574, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %101, align 4
  %102 = tail call i32 @mem_read32(ptr %mem, i32 61440)
  %103 = getelementptr i8, ptr %cpu, i64 296
  %dj147 = load i8, ptr %103, align 1
  %dj_set148.not = icmp eq i8 %dj147, 0
  br i1 %dj_set148.not, label %page_done, label %did_jump_exit145, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %102, %page_slow ]
  store i32 %mem_val, ptr %cpu, align 4
  store i32 1128418865, ptr %98, align 4
  %diff = add i32 %mem_val, -1128418865
  %104 = icmp eq i32 %diff, 0
  %az = zext i1 %104 to i32
  %flgn391 = or i32 %diff, %mem_val
  %an = lshr i32 %flgn391, 31
  %105 = icmp ugt i32 %mem_val, 1128418864
  %ac0 = zext i1 %105 to i32
  %106 = getelementptr i8, ptr %cpu, i64 276
  store i32 %az, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 232
  store i32 %an, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i64 236
  store i32 %ac0, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 240
  store i32 %ac0, ptr %110, align 4
  br i1 %104, label %brt_taken, label %insn_0x00010030

did_jump_exit145:                                 ; preds = %page_slow
  %next_pc345 = load i32, ptr %99, align 4
  br label %chain_exit

brt_taken:                                        ; preds = %page_done
  %111 = getelementptr i8, ptr %cpu, i64 188
  store i32 65600, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %112, align 4
  %chain_total = add nuw i32 %chain_packets, 9
  %113 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %113 monotonic, align 4, !range !2
  %114 = icmp ult i32 %chain_total, %chain_budget
  br i1 %114, label %chain_go, label %chain_leave346, !prof !0

insn_0x00010030:                                  ; preds = %page_done
  store i32 3, ptr %cpu, align 4
  store i32 61456, ptr %77, align 4
  %page158 = load ptr, ptr %page_slot141, align 8
  %page_mapped159.not = icmp eq ptr %page158, null
  br i1 %page_mapped159.not, label %page_wr_slow154, label %page_wr_fast153, !prof !1

page_wr_fast153:                                  ; preds = %insn_0x00010030
  %115 = getelementptr i8, ptr %page158, i64 16
  store i32 3, ptr %115, align 4
  br label %page_wr_done155

page_wr_slow154:                                  ; preds = %insn_0x00010030
  %116 = getelementptr i8, ptr %cpu, i64 188
  store i32 65588, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %118, align 4
  tail call void @mem_write32(ptr %mem, i32 61456, i32 3)
  %119 = getelementptr i8, ptr %cpu, i64 296
  %dj163 = load i8, ptr %119, align 1
  %dj_set164.not = icmp eq i8 %dj163, 0
  br i1 %dj_set164.not, label %page_wr_done155, label %did_jump_exit161, !prof !0

page_wr_done155:                                  ; preds = %page_wr_slow154, %page_wr_fast153
  %cec_pending165 = load i8, ptr %cec_pending_flag, align 1
  %.not392 = icmp eq i8 %cec_pending165, 0
  br i1 %.not392, label %insn_0x00010036, label %cec_check166, !prof !0

did_jump_exit161:                                 ; preds = %page_wr_slow154
  %next_pc348 = load i32, ptr %116, align 4
  br label %chain_exit

cec_check166:                                     ; preds = %page_wr_done155
  %120 = getelementptr i8, ptr %cpu, i64 188
  store i32 65590, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %122, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %123 = getelementptr i8, ptr %cpu, i64 296
  %dj170 = load i8, ptr %123, align 1
  %dj_set171.not = icmp eq i8 %dj170, 0
  br i1 %dj_set171.not, label %insn_0x00010036, label %did_jump_exit168, !prof !0

did_jump_exit168:                                 ; preds = %cec_check166
  %next_pc349 = load i32, ptr %120, align 4
  br label %chain_exit

insn_0x00010036:                                  ; preds = %page_wr_done155, %cec_check166
  store i32 1, ptr %cpu, align 4
  %page179 = load ptr, ptr %page_slot120, align 8
  %page_mapped180.not = icmp eq ptr %page179, null
  br i1 %page_mapped180.not, label %page_slow175, label %page_fast174, !prof !1

page_fast174:                                     ; preds = %insn_0x00010036
  %124 = and i32 %sp2, 4095
  %page_offset181 = zext i32 %124 to i64
  %125 = getelementptr i8, ptr %page179, i64 %page_offset181
  %page_val182 = load i32, ptr %125, align 4
  br label %data_aligned190

page_slow175:                                     ; preds = %insn_0x00010036
  %126 = getelementptr i8, ptr %cpu, i64 188
  store i32 65592, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %128, align 4
  %129 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %130 = getelementptr i8, ptr %cpu, i64 296
  %dj185 = load i8, ptr %130, align 1
  %dj_set186.not = icmp eq i8 %dj185, 0
  br i1 %dj_set186.not, label %data_aligned190, label %did_jump_exit183, !prof !0

did_jump_exit183:                                 ; preds = %page_slow175
  %next_pc351 = load i32, ptr %126, align 4
  br label %chain_exit

data_aligned190:                                  ; preds = %page_fast174, %page_slow175
  %mem_val187 = phi i32 [ %page_val182, %page_fast174 ], [ %129, %page_slow175 ]
  %page196 = load ptr, ptr %page_slot106, align 8
  %page_mapped197.not = icmp eq ptr %page196, null
  br i1 %page_mapped197.not, label %page_slow192, label %page_fast191, !prof !1

page_fast191:                                     ; preds = %data_aligned190
  %131 = and i32 %sp1, 4095
  %page_offset198 = zext i32 %131 to i64
  %132 = getelementptr i8, ptr %page196, i64 %page_offset198
  %page_val199 = load i32, ptr %132, align 4
  br label %page_done193

page_slow192:                                     ; preds = %data_aligned190
  %133 = getelementptr i8, ptr %cpu, i64 188
  store i32 65592, ptr %133, align 4
  %134 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %135, align 4
  %136 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %137 = getelementptr i8, ptr %cpu, i64 296
  %dj202 = load i8, ptr %137, align 1
  %dj_set203.not = icmp eq i8 %dj202, 0
  br i1 %dj_set203.not, label %page_done193, label %did_jump_exit200, !prof !0

page_done193:                                     ; preds = %page_slow192, %page_fast191
  %mem_val204 = phi i32 [ %page_val199, %page_fast191 ], [ %136, %page_slow192 ]
  store i32 %mem_val187, ptr %79, align 4
  store i32 %mem_val204, ptr %78, align 4
  store i32 %sp_dec80, ptr %10, align 4
  %page213 = load ptr, ptr %page_slot88, align 8
  %page_mapped214.not = icmp eq ptr %page213, null
  br i1 %page_mapped214.not, label %page_slow209, label %page_fast208, !prof !1

did_jump_exit200:                                 ; preds = %page_slow192
  %next_pc353 = load i32, ptr %133, align 4
  br label %chain_exit

page_fast208:                                     ; preds = %page_done193
  %138 = and i32 %sp_dec80, 4095
  %page_offset215 = zext i32 %138 to i64
  %139 = getelementptr i8, ptr %page213, i64 %page_offset215
  %page_val216 = load i32, ptr %139, align 4
  br label %page_done210

page_slow209:                                     ; preds = %page_done193
  %140 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %142, align 4
  %143 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec80)
  %144 = getelementptr i8, ptr %cpu, i64 296
  %dj219 = load i8, ptr %144, align 1
  %dj_set220.not = icmp eq i8 %dj219, 0
  br i1 %dj_set220.not, label %page_done210, label %did_jump_exit217, !prof !0

page_done210:                                     ; preds = %page_slow209, %page_fast208
  %mem_val221 = phi i32 [ %page_val216, %page_fast208 ], [ %143, %page_slow209 ]
  store i32 %mem_val221, ptr %64, align 4
  %page229 = load ptr, ptr %page_slot72, align 8
  %page_mapped230.not = icmp eq ptr %page229, null
  br i1 %page_mapped230.not, label %page_slow225, label %page_fast224, !prof !1

did_jump_exit217:                                 ; preds = %page_slow209
  %next_pc355 = load i32, ptr %140, align 4
  br label %chain_exit

page_fast224:                                     ; preds = %page_done210
  %145 = and i32 %sp_dec64, 4095
  %page_offset231 = zext i32 %145 to i64
  %146 = getelementptr i8, ptr %page229, i64 %page_offset231
  %page_val232 = load i32, ptr %146, align 4
  br label %page_done226

page_slow225:                                     ; preds = %page_done210
  %147 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %149, align 4
  %150 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec64)
  %151 = getelementptr i8, ptr %cpu, i64 296
  %dj235 = load i8, ptr %151, align 1
  %dj_set236.not = icmp eq i8 %dj235, 0
  br i1 %dj_set236.not, label %page_done226, label %did_jump_exit233, !prof !0

page_done226:                                     ; preds = %page_slow225, %page_fast224
  %mem_val237 = phi i32 [ %page_val232, %page_fast224 ], [ %150, %page_slow225 ]
  store i32 %mem_val237, ptr %56, align 4
  %page246 = load ptr, ptr %page_slot56, align 8
  %page_mapped247.not = icmp eq ptr %page246, null
  br i1 %page_mapped247.not, label %page_slow242, label %page_fast241, !prof !1

did_jump_exit233:                                 ; preds = %page_slow225
  %next_pc357 = load i32, ptr %147, align 4
  br label %chain_exit

page_fast241:                                     ; preds = %page_done226
  %152 = and i32 %sp_dec49, 4095
  %page_offset248 = zext i32 %152 to i64
  %153 = getelementptr i8, ptr %page246, i64 %page_offset248
  %page_val249 = load i32, ptr %153, align 4
  br label %page_done243

page_slow242:                                     ; preds = %page_done226
  %154 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %156, align 4
  %157 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec49)
  %158 = getelementptr i8, ptr %cpu, i64 296
  %dj252 = load i8, ptr %158, align 1
  %dj_set253.not = icmp eq i8 %dj252, 0
  br i1 %dj_set253.not, label %page_done243, label %did_jump_exit250, !prof !0

page_done243:                                     ; preds = %page_slow242, %page_fast241
  %mem_val254 = phi i32 [ %page_val249, %page_fast241 ], [ %157, %page_slow242 ]
  store i32 %mem_val254, ptr %48, align 4
  %page263 = load ptr, ptr %page_slot41, align 8
  %page_mapped264.not = icmp eq ptr %page263, null
  br i1 %page_mapped264.not, label %page_slow259, label %page_fast258, !prof !1

did_jump_exit250:                                 ; preds = %page_slow242
  %next_pc359 = load i32, ptr %154, align 4
  br label %chain_exit

page_fast258:                                     ; preds = %page_done243
  %159 = and i32 %sp_dec33, 4095
  %page_offset265 = zext i32 %159 to i64
  %160 = getelementptr i8, ptr %page263, i64 %page_offset265
  %page_val266 = load i32, ptr %160, align 4
  br label %page_done260

page_slow259:                                     ; preds = %page_done243
  %161 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %163, align 4
  %164 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec33)
  %165 = getelementptr i8, ptr %cpu, i64 296
  %dj269 = load i8, ptr %165, align 1
  %dj_set270.not = icmp eq i8 %dj269, 0
  br i1 %dj_set270.not, label %page_done260, label %did_jump_exit267, !prof !0

page_done260:                                     ; preds = %page_slow259, %page_fast258
  %mem_val271 = phi i32 [ %page_val266, %page_fast258 ], [ %164, %page_slow259 ]
  store i32 %mem_val271, ptr %40, align 4
  %page280 = load ptr, ptr %page_slot25, align 8
  %page_mapped281.not = icmp eq ptr %page280, null
  br i1 %page_mapped281.not, label %page_slow276, label %page_fast275, !prof !1

did_jump_exit267:                                 ; preds = %page_slow259
  %next_pc361 = load i32, ptr %161, align 4
  br label %chain_exit

page_fast275:                                     ; preds = %page_done260
  %166 = and i32 %sp_dec17, 4095
  %page_offset282 = zext i32 %166 to i64
  %167 = getelementptr i8, ptr %page280, i64 %page_offset282
  %page_val283 = load i32, ptr %167, align 4
  br label %page_done277

page_slow276:                                     ; preds = %page_done260
  %168 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %170, align 4
  %171 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec17)
  %172 = getelementptr i8, ptr %cpu, i64 296
  %dj286 = load i8, ptr %172, align 1
  %dj_set287.not = icmp eq i8 %dj286, 0
  br i1 %dj_set287.not, label %page_done277, label %did_jump_exit284, !prof !0

page_done277:                                     ; preds = %page_slow276, %page_fast275
  %mem_val288 = phi i32 [ %page_val283, %page_fast275 ], [ %171, %page_slow276 ]
  store i32 %mem_val288, ptr %32, align 4
  %page297 = load ptr, ptr %page_slot9, align 8
  %page_mapped298.not = icmp eq ptr %page297, null
  br i1 %page_mapped298.not, label %page_slow293, label %page_fast292, !prof !1

did_jump_exit284:                                 ; preds = %page_slow276
  %next_pc363 = load i32, ptr %168, align 4
  br label %chain_exit

page_fast292:                                     ; preds = %page_done277
  %173 = and i32 %sp_dec1, 4095
  %page_offset299 = zext i32 %173 to i64
  %174 = getelementptr i8, ptr %page297, i64 %page_offset299
  %page_val300 = load i32, ptr %174, align 4
  br label %page_done294

page_slow293:                                     ; preds = %page_done277
  %175 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %177, align 4
  %178 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec1)
  %179 = getelementptr i8, ptr %cpu, i64 296
  %dj303 = load i8, ptr %179, align 1
  %dj_set304.not = icmp eq i8 %dj303, 0
  br i1 %dj_set304.not, label %page_done294, label %did_jump_exit301, !prof !0

page_done294:                                     ; preds = %page_slow293, %page_fast292
  %mem_val305 = phi i32 [ %page_val300, %page_fast292 ], [ %178, %page_slow293 ]
  store i32 %mem_val305, ptr %24, align 4
  %page314 = load ptr, ptr %page_slot, align 8
  %page_mapped315.not = icmp eq ptr %page314, null
  br i1 %page_mapped315.not, label %page_slow310, label %page_fast309, !prof !1

did_jump_exit301:                                 ; preds = %page_slow293
  %next_pc365 = load i32, ptr %175, align 4
  br label %chain_exit

page_fast309:                                     ; preds = %page_done294
  %180 = and i32 %sp_dec, 4095
  %page_offset316 = zext i32 %180 to i64
  %181 = getelementptr i8, ptr %page314, i64 %page_offset316
  %page_val317 = load i32, ptr %181, align 4
  br label %page_done311

page_slow310:                                     ; preds = %page_done294
  %182 = getelementptr i8, ptr %cpu, i64 188
  store i32 65596, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %184, align 4
  %185 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec)
  %186 = getelementptr i8, ptr %cpu, i64 296
  %dj320 = load i8, ptr %186, align 1
  %dj_set321.not = icmp eq i8 %dj320, 0
  br i1 %dj_set321.not, label %page_done311, label %did_jump_exit318, !prof !0

page_done311:                                     ; preds = %page_slow310, %page_fast309
  %mem_val322 = phi i32 [ %page_val317, %page_fast309 ], [ %185, %page_slow310 ]
  store i32 %mem_val322, ptr %11, align 4
  store i32 %sp, ptr %10, align 4
  %lsb = and i32 %mem_val204, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit318:                                 ; preds = %page_slow310
  %next_pc367 = load i32, ptr %182, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done311
  %187 = getelementptr i8, ptr %cpu, i64 188
  store i32 65598, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %189, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc368 = load i32, ptr %187, align 4
  %190 = getelementptr i8, ptr %cpu, i64 296
  %191 = load i8, ptr %190, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave346, %chain_leave373
  %tail370.sink = phi i32 [ %tail370, %chain_leave373 ], [ 2, %chain_leave346 ]
  %packets.sink = phi i32 [ %packets, %chain_leave373 ], [ 9, %chain_leave346 ]
  %tail372.sink.ph = phi i8 [ %tail372, %chain_leave373 ], [ 1, %chain_leave346 ]
  %192 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail370.sink, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %193, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink393 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail372.sink = phi i8 [ 1, %entry ], [ %tail372.sink.ph, %common.ret.sink.split ]
  %194 = getelementptr i8, ptr %cpu, i64 %.sink393
  store i8 %tail372.sink, ptr %194, align 1
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524800
  %slot_pc = load i32, ptr %chain_slot, align 4
  %195 = icmp eq i32 %slot_pc, 65600
  br i1 %195, label %chain_hit, label %chain_leave346, !prof !0

chain_leave346:                                   ; preds = %chain_go, %brt_taken
  store i32 65600, ptr %111, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65600, ptr %111, align 4
  store i32 %chain_total, ptr %112, align 4
  %196 = getelementptr i8, ptr %chain_table, i64 524808
  %chain_fn = load ptr, ptr %196, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done311, %jump_misalign, %did_jump_exit318, %did_jump_exit301, %did_jump_exit284, %did_jump_exit267, %did_jump_exit250, %did_jump_exit233, %did_jump_exit217, %did_jump_exit200, %did_jump_exit183, %did_jump_exit168, %did_jump_exit161, %did_jump_exit145, %did_jump_exit131, %did_jump_exit124, %did_jump_exit110, %did_jump_exit96, %did_jump_exit92, %did_jump_exit76, %did_jump_exit60, %did_jump_exit45, %did_jump_exit29, %did_jump_exit13, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit29 ], [ 1, %did_jump_exit45 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit76 ], [ 1, %did_jump_exit92 ], [ 1, %did_jump_exit96 ], [ 3, %did_jump_exit110 ], [ 3, %did_jump_exit124 ], [ 3, %did_jump_exit131 ], [ 6, %did_jump_exit145 ], [ 12, %did_jump_exit161 ], [ 12, %did_jump_exit168 ], [ 14, %did_jump_exit183 ], [ 14, %did_jump_exit200 ], [ 15, %did_jump_exit217 ], [ 15, %did_jump_exit233 ], [ 15, %did_jump_exit250 ], [ 15, %did_jump_exit267 ], [ 15, %did_jump_exit284 ], [ 15, %did_jump_exit301 ], [ 15, %did_jump_exit318 ], [ 16, %jump_misalign ], [ 16, %page_done311 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc325, %did_jump_exit ], [ %next_pc327, %did_jump_exit13 ], [ %next_pc329, %did_jump_exit29 ], [ %next_pc331, %did_jump_exit45 ], [ %next_pc333, %did_jump_exit60 ], [ %next_pc335, %did_jump_exit76 ], [ %next_pc337, %did_jump_exit92 ], [ %next_pc338, %did_jump_exit96 ], [ %next_pc340, %did_jump_exit110 ], [ %next_pc342, %did_jump_exit124 ], [ %next_pc343, %did_jump_exit131 ], [ %next_pc345, %did_jump_exit145 ], [ %next_pc348, %did_jump_exit161 ], [ %next_pc349, %did_jump_exit168 ], [ %next_pc351, %did_jump_exit183 ], [ %next_pc353, %did_jump_exit200 ], [ %next_pc355, %did_jump_exit217 ], [ %next_pc357, %did_jump_exit233 ], [ %next_pc359, %did_jump_exit250 ], [ %next_pc361, %did_jump_exit267 ], [ %next_pc363, %did_jump_exit284 ], [ %next_pc365, %did_jump_exit301 ], [ %next_pc367, %did_jump_exit318 ], [ %next_pc368, %jump_misalign ], [ %mem_val204, %page_done311 ]
  %tail370 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit13 ], [ 2, %did_jump_exit29 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit60 ], [ 2, %did_jump_exit76 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit96 ], [ 4, %did_jump_exit110 ], [ 4, %did_jump_exit124 ], [ 4, %did_jump_exit131 ], [ 2, %did_jump_exit145 ], [ 2, %did_jump_exit161 ], [ 2, %did_jump_exit168 ], [ 4, %did_jump_exit183 ], [ 4, %did_jump_exit200 ], [ 2, %did_jump_exit217 ], [ 2, %did_jump_exit233 ], [ 2, %did_jump_exit250 ], [ 2, %did_jump_exit267 ], [ 2, %did_jump_exit284 ], [ 2, %did_jump_exit301 ], [ 2, %did_jump_exit318 ], [ 2, %jump_misalign ], [ 2, %page_done311 ]
  %tail372 = phi i8 [ %17, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj15, %did_jump_exit13 ], [ %dj31, %did_jump_exit29 ], [ %dj47, %did_jump_exit45 ], [ %dj62, %did_jump_exit60 ], [ %dj78, %did_jump_exit76 ], [ %dj94, %did_jump_exit92 ], [ %dj98, %did_jump_exit96 ], [ %dj112, %did_jump_exit110 ], [ %dj126, %did_jump_exit124 ], [ %dj133, %did_jump_exit131 ], [ %dj147, %did_jump_exit145 ], [ %dj163, %did_jump_exit161 ], [ %dj170, %did_jump_exit168 ], [ %dj185, %did_jump_exit183 ], [ %dj202, %did_jump_exit200 ], [ %dj219, %did_jump_exit217 ], [ %dj235, %did_jump_exit233 ], [ %dj252, %did_jump_exit250 ], [ %dj269, %did_jump_exit267 ], [ %dj286, %did_jump_exit284 ], [ %dj303, %did_jump_exit301 ], [ %dj320, %did_jump_exit318 ], [ %191, %jump_misalign ], [ 1, %page_done311 ]
  %197 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets374 = load i32, ptr %197, align 4
  %chain_total375 = add nuw i32 %chain_packets374, %packets
  %198 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget376 = load atomic i32, ptr %198 monotonic, align 4, !range !2
  %199 = icmp ult i32 %chain_total375, %chain_budget376
  br i1 %199, label %chain_lookup, label %chain_leave373, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %200 = shl i32 %tail, 3
  %201 = and i32 %200, 1048560
  %202 = zext i32 %201 to i64
  %chain_slot377 = getelementptr i8, ptr %chain_table, i64 %202
  %slot_pc378 = load i32, ptr %chain_slot377, align 4
  %203 = icmp eq i32 %slot_pc378, %tail
  br i1 %203, label %chain_hit379, label %chain_leave373, !prof !0

chain_leave373:                                   ; preds = %chain_lookup, %chain_exit
  %204 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %204, align 4
  br label %common.ret.sink.split

chain_hit379:                                     ; preds = %chain_lookup
  %205 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %205, align 4
  store i32 %chain_total375, ptr %197, align 4
  %206 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %206, align 1
  %207 = getelementptr i8, ptr %chain_slot377, i64 8
  %chain_fn380 = load ptr, ptr %207, align 8
  musttail call swifttailcc void %chain_fn380(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
