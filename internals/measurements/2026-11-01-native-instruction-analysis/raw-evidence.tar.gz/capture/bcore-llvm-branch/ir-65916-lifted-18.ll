; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001017c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65916
  %4 = icmp ugt i32 %3, 12
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb14 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb14, 0
  %9 = sub i32 %guard_lb14, 65916
  %10 = icmp ugt i32 %9, 12
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x0001017c_entry, label %lb_guard_miss, !prof !0

insn_0x0001017c_entry:                            ; preds = %lb_guard
  br label %insn_0x0001017c

insn_0x0001017c:                                  ; preds = %insn_0x0001017c_entry
  %13 = getelementptr i8, ptr %cpu, i32 28
  %a = load i32, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i32 16
  %b = load i32, ptr %14, align 4
  %mul = mul i32 %a, %b
  %15 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mul, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %17, align 4
  br label %insn_0x0001017e_entry

insn_0x0001017e_entry:                            ; preds = %insn_0x0001017c
  br label %insn_0x0001017e

insn_0x0001017e:                                  ; preds = %insn_0x0001017e_entry
  %18 = getelementptr i8, ptr %cpu, i32 52
  %regmv_src = load i32, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i32 4
  store i32 %regmv_src, ptr %19, align 4
  br label %insn_0x00010180_entry

insn_0x00010180_entry:                            ; preds = %insn_0x0001017e
  br label %insn_0x00010180

insn_0x00010180:                                  ; preds = %insn_0x00010180_entry
  %add32 = add i32 %mul, %regmv_src
  %20 = getelementptr i8, ptr %cpu, i32 28
  store i32 %add32, ptr %20, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn = lshr i32 %add32, 31
  %21 = xor i32 %flgo, %flgn
  %22 = xor i32 %flgs, %flgn
  %23 = and i32 %22, %21
  %24 = xor i32 %mul, -1
  %25 = icmp ult i32 %24, %regmv_src
  %ac0 = zext i1 %25 to i32
  %26 = icmp eq i32 %add32, 0
  %az = zext i1 %26 to i32
  %an = lshr i32 %add32, 31
  %27 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %29, align 4
  %30 = or i32 %vs_cur, %23
  %31 = getelementptr i8, ptr %cpu, i32 248
  store i32 %23, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 252
  store i32 %23, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 256
  store i32 %30, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %35, align 4
  br label %insn_0x00010182_entry

insn_0x00010182_entry:                            ; preds = %insn_0x00010180
  br label %insn_0x00010182

insn_0x00010182:                                  ; preds = %insn_0x00010182_entry
  %diff = sub i32 %add32, 0
  %36 = icmp eq i32 %diff, 0
  %az1 = zext i1 %36 to i32
  %flgn2 = lshr i32 %diff, 31
  %flgs3 = lshr i32 %add32, 31
  %37 = xor i32 %flgn2, %flgs3
  %38 = xor i32 %flgs3, 0
  %overflow = and i32 %38, %37
  %an4 = xor i32 %flgn2, %overflow
  %39 = icmp ule i32 0, %add32
  %ac05 = zext i1 %39 to i32
  %40 = getelementptr i8, ptr %cpu, i32 276
  store i32 %an4, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac05, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac05, ptr %44, align 4
  br label %insn_0x00010184_entry

insn_0x00010184_entry:                            ; preds = %insn_0x00010182
  br label %insn_0x00010184

insn_0x00010184:                                  ; preds = %insn_0x00010184_entry
  %cc_false = icmp eq i32 %an4, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010184
  %45 = getelementptr i8, ptr %cpu, i32 188
  store i32 65904, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %46, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %47 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %47 monotonic, align 4, !range !1
  %48 = icmp ult i32 %chain_total, %chain_budget
  br i1 %48, label %chain_go, label %chain_leave15, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010184
  br label %insn_0x00010186_entry

insn_0x00010186_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010186

insn_0x00010186:                                  ; preds = %insn_0x00010186_entry
  %49 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %49, align 4
  %xor32 = xor i32 %rt, %add32
  %50 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %50, align 4
  %51 = icmp eq i32 %xor32, 0
  %az6 = zext i1 %51 to i32
  %an7 = lshr i32 %xor32, 31
  %52 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az6, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an7, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %57, align 4
  br label %insn_0x00010188_entry

insn_0x00010188_entry:                            ; preds = %insn_0x00010186
  br label %insn_0x00010188

insn_0x00010188:                                  ; preds = %insn_0x00010188_entry
  %58 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %59, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65928
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65932
  %60 = getelementptr i8, ptr %cpu, i32 156
  %lc8 = load i32, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 148
  %lt9 = load i32, ptr %61, align 4
  %lc_gt110 = icmp ugt i32 %lc8, 1
  %at_lb11 = icmp eq i32 %lb1, 65928
  %hwloop_cond12 = and i1 %lc_gt110, %at_lb11
  %hwloop_rets13 = select i1 %hwloop_cond12, i32 %lt9, i32 %hwloop_rets
  %62 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets13, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 188
  store i32 65808, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets18 = load i32, ptr %64, align 4
  %chain_total19 = add nuw i32 %chain_packets18, 7
  %65 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget20 = load atomic i32, ptr %65 monotonic, align 4, !range !1
  %66 = icmp ult i32 %chain_total19, %chain_budget20
  br i1 %66, label %chain_go16, label %chain_leave17, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %67 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %67, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527232
  %68 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %68, align 4
  %69 = icmp eq i32 %slot_pc, 65904
  br i1 %69, label %chain_hit, label %chain_leave15, !prof !0

chain_leave15:                                    ; preds = %chain_go, %brcc_taken
  %70 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %73, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %74 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %75, align 4
  %76 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %76, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go16:                                       ; preds = %insn_0x00010188
  %chain_slot21 = getelementptr i8, ptr %chain_table, i64 526464
  %77 = getelementptr i8, ptr %chain_slot21, i64 0
  %slot_pc22 = load i32, ptr %77, align 4
  %78 = icmp eq i32 %slot_pc22, 65808
  br i1 %78, label %chain_hit23, label %chain_leave17, !prof !0

chain_leave17:                                    ; preds = %chain_go16, %insn_0x00010188
  %79 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %82, align 1
  ret void

chain_hit23:                                      ; preds = %chain_go16
  %83 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total19, ptr %84, align 4
  %85 = getelementptr i8, ptr %chain_slot21, i64 8
  %chain_fn24 = load ptr, ptr %85, align 8
  musttail call swifttailcc void %chain_fn24(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
