; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010442(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 66626
  %5 = icmp ugt i32 %4, 12
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb1 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb1, 0
  %10 = sub i32 %guard_lb1, 66626
  %11 = icmp ugt i32 %10, 12
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x00010442_entry, label %lb_guard_miss, !prof !0

insn_0x00010442_entry:                            ; preds = %lb_guard
  br label %insn_0x00010442

insn_0x00010442:                                  ; preds = %insn_0x00010442_entry
  %14 = getelementptr i8, ptr %cpu, i32 36
  %old = load i32, ptr %14, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %15 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_hi, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %17, align 4
  br label %insn_0x00010446_entry

insn_0x00010446_entry:                            ; preds = %insn_0x00010442
  br label %insn_0x00010446

insn_0x00010446:                                  ; preds = %insn_0x00010446_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4508
  %18 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %18, align 4
  br label %insn_0x0001044a_entry

insn_0x0001044a_entry:                            ; preds = %insn_0x00010446
  br label %insn_0x0001044a

insn_0x0001044a:                                  ; preds = %insn_0x0001044a_entry
  %19 = getelementptr i8, ptr %cpu, i32 40
  %pt = load i32, ptr %19, align 4
  %20 = shl i32 %pt, 2
  %plshift2 = add i32 %with_lo, %20
  %21 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift2, ptr %21, align 4
  br label %insn_0x0001044c_entry

insn_0x0001044c_entry:                            ; preds = %insn_0x0001044a
  br label %insn_0x0001044c

insn_0x0001044c:                                  ; preds = %insn_0x0001044c_entry
  %22 = and i32 %plshift2, 3
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001044c
  %24 = getelementptr i8, ptr %cpu, i32 188
  store i32 66636, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %26, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66636, i32 %plshift2, i32 0)
  %27 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 188
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr i8, ptr %cpu, i64 296
  %31 = load i8, ptr %30, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001044c
  %32 = lshr i32 %plshift2, 12
  %page_index = zext i32 %32 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %33 = and i32 %plshift2, 4095
  %page_offset = zext i32 %33 to i64
  %34 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %34, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %35 = getelementptr i8, ptr %cpu, i32 188
  store i32 66636, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %37, align 4
  %38 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %39 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %39, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %38, %did_jump_cont ]
  %40 = getelementptr i8, ptr %cpu, i32 40
  store i32 %mem_val, ptr %40, align 4
  br label %insn_0x0001044e_entry

did_jump_exit:                                    ; preds = %page_slow
  %41 = getelementptr i8, ptr %cpu, i64 188
  %next_pc2 = load i32, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 188
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %cpu, i64 296
  %45 = load i8, ptr %44, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x0001044e_entry:                            ; preds = %page_done
  br label %insn_0x0001044e

insn_0x0001044e:                                  ; preds = %insn_0x0001044e_entry
  %lsb = and i32 %mem_val, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001044e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001044e
  %46 = getelementptr i8, ptr %cpu, i32 188
  store i32 66638, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %48, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %49 = getelementptr i8, ptr %cpu, i64 188
  %next_pc3 = load i32, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 188
  %51 = load i32, ptr %50, align 4
  %52 = getelementptr i8, ptr %cpu, i64 296
  %53 = load i8, ptr %52, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %54 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %54, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit, %data_misaligned
  %next_pc4 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc2, %did_jump_exit ], [ %mem_val, %jump_aligned ], [ %next_pc3, %jump_misalign ]
  %packets = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 5, %jump_aligned ], [ 5, %jump_misalign ]
  %tail = phi i32 [ %29, %data_misaligned ], [ %43, %did_jump_exit ], [ %mem_val, %jump_aligned ], [ %51, %jump_misalign ]
  %tail5 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail6 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 5, %jump_aligned ], [ 5, %jump_misalign ]
  %tail7 = phi i8 [ %31, %data_misaligned ], [ %45, %did_jump_exit ], [ 1, %jump_aligned ], [ %53, %jump_misalign ]
  %55 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %55, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %56 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %56 monotonic, align 4, !range !2
  %57 = icmp ult i32 %chain_total, %chain_budget
  br i1 %57, label %chain_lookup, label %chain_leave8, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %58 = lshr i32 %next_pc4, 1
  %59 = and i32 %58, 65535
  %60 = zext i32 %59 to i64
  %61 = mul i64 %60, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %61
  %62 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %62, align 4
  %63 = icmp eq i32 %slot_pc, %next_pc4
  br i1 %63, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_lookup, %chain_exit
  %64 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail5, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail6, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail7, ptr %67, align 1
  ret void

chain_hit:                                        ; preds = %chain_lookup
  %68 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc4, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %70, align 1
  %71 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %71, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
