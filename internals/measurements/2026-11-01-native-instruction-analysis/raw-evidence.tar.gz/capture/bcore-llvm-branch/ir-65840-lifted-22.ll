; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010130(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65840
  %6 = icmp ugt i32 %5, 26
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb54 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb54, 0
  %11 = sub i32 %guard_lb54, 65840
  %12 = icmp ugt i32 %11, 26
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010130_entry, label %lb_guard_miss, !prof !0

insn_0x00010130_entry:                            ; preds = %lb_guard
  br label %insn_0x00010130

insn_0x00010130:                                  ; preds = %insn_0x00010130_entry
  %15 = getelementptr i8, ptr %cpu, i32 0
  %rs = load i32, ptr %15, align 4
  %lsl32 = shl i32 %rs, 5
  %16 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsl32, ptr %16, align 4
  %17 = icmp eq i32 %lsl32, 0
  %az = zext i1 %17 to i32
  %an = lshr i32 %lsl32, 31
  %18 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %23, align 4
  br label %insn_0x00010134_entry

insn_0x00010134_entry:                            ; preds = %insn_0x00010130
  br label %insn_0x00010134

insn_0x00010134:                                  ; preds = %insn_0x00010134_entry
  %lsr = lshr i32 %rs, 27
  %24 = getelementptr i8, ptr %cpu, i32 0
  store i32 %lsr, ptr %24, align 4
  %25 = icmp eq i32 %lsr, 0
  %az1 = zext i1 %25 to i32
  %an2 = lshr i32 %lsr, 31
  %26 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %29, align 4
  br label %insn_0x00010136_entry

insn_0x00010136_entry:                            ; preds = %insn_0x00010134
  br label %insn_0x00010136

insn_0x00010136:                                  ; preds = %insn_0x00010136_entry
  %or32 = or i32 %lsr, %lsl32
  %30 = getelementptr i8, ptr %cpu, i32 0
  store i32 %or32, ptr %30, align 4
  %31 = icmp eq i32 %or32, 0
  %az3 = zext i1 %31 to i32
  %an4 = lshr i32 %or32, 31
  %32 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az3, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an4, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %37, align 4
  br label %insn_0x00010138_entry

insn_0x00010138_entry:                            ; preds = %insn_0x00010136
  br label %insn_0x00010138

insn_0x00010138:                                  ; preds = %insn_0x00010138_entry
  %lo_kept = and i32 %lsl32, 65535
  %with_hi = or i32 %lo_kept, 2135556096
  %38 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_hi, ptr %38, align 4
  br label %insn_0x0001013c_entry

insn_0x0001013c_entry:                            ; preds = %insn_0x00010138
  br label %insn_0x0001013c

insn_0x0001013c:                                  ; preds = %insn_0x0001013c_entry
  %39 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %41, align 4
  %sp1 = sub i32 %sp, 4
  %42 = and i32 %sp1, 3
  %43 = icmp ne i32 %42, 0
  br i1 %43, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001013c
  %44 = getelementptr i8, ptr %cpu, i32 188
  store i32 65852, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %46, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65852, i32 %sp1, i32 65536)
  %47 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i64 188
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %cpu, i64 296
  %51 = load i8, ptr %50, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001013c
  %52 = lshr i32 %sp1, 12
  %page_index = zext i32 %52 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %53 = and i32 %sp1, 4095
  %page_offset = zext i32 %53 to i64
  %54 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %54, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %55 = getelementptr i8, ptr %cpu, i32 188
  store i32 65852, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %57, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %58 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %58, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp2 = sub i32 %sp1, 4
  %59 = and i32 %sp2, 3
  %60 = icmp ne i32 %59, 0
  br i1 %60, label %data_misaligned5, label %data_aligned6, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %61 = getelementptr i8, ptr %cpu, i64 188
  %next_pc55 = load i32, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 188
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr i8, ptr %cpu, i64 296
  %65 = load i8, ptr %64, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned5:                                 ; preds = %page_wr_done
  %66 = getelementptr i8, ptr %cpu, i32 188
  store i32 65852, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %68, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65852, i32 %sp2, i32 65536)
  %69 = getelementptr i8, ptr %cpu, i64 188
  %next_pc56 = load i32, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 188
  %71 = load i32, ptr %70, align 4
  %72 = getelementptr i8, ptr %cpu, i64 296
  %73 = load i8, ptr %72, align 1
  br label %chain_exit

data_aligned6:                                    ; preds = %page_wr_done
  %74 = lshr i32 %sp2, 12
  %page_index10 = zext i32 %74 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13 = icmp ne ptr %page12, null
  br i1 %page_mapped13, label %page_wr_fast7, label %page_wr_slow8, !prof !0

page_wr_fast7:                                    ; preds = %data_aligned6
  %75 = and i32 %sp2, 4095
  %page_offset14 = zext i32 %75 to i64
  %76 = getelementptr i8, ptr %page12, i64 %page_offset14
  store i32 %fp, ptr %76, align 4
  br label %page_wr_done9

page_wr_slow8:                                    ; preds = %data_aligned6
  %77 = getelementptr i8, ptr %cpu, i32 188
  store i32 65852, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %79, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %80 = getelementptr i8, ptr %cpu, i32 296
  %dj17 = load i8, ptr %80, align 1
  %dj_set18 = icmp ne i8 %dj17, 0
  br i1 %dj_set18, label %did_jump_exit15, label %did_jump_cont16, !prof !1

page_wr_done9:                                    ; preds = %did_jump_cont16, %page_wr_fast7
  %81 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %81, align 4
  %sp3 = sub i32 %sp2, 0
  %82 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %82, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %83 = icmp ne i8 %cec_pending, 0
  br i1 %83, label %cec_check, label %cec_checked, !prof !1

did_jump_exit15:                                  ; preds = %page_wr_slow8
  %84 = getelementptr i8, ptr %cpu, i64 188
  %next_pc57 = load i32, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 188
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %cpu, i64 296
  %88 = load i8, ptr %87, align 1
  br label %chain_exit

did_jump_cont16:                                  ; preds = %page_wr_slow8
  br label %page_wr_done9

cec_check:                                        ; preds = %page_wr_done9
  %89 = getelementptr i8, ptr %cpu, i32 188
  store i32 65856, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %91, align 4
  call void @cec_check_pending(ptr %cpu)
  %92 = getelementptr i8, ptr %cpu, i32 296
  %dj21 = load i8, ptr %92, align 1
  %dj_set22 = icmp ne i8 %dj21, 0
  br i1 %dj_set22, label %did_jump_exit19, label %did_jump_cont20, !prof !1

cec_checked:                                      ; preds = %did_jump_cont20, %page_wr_done9
  br label %insn_0x00010140_entry

did_jump_exit19:                                  ; preds = %cec_check
  %93 = getelementptr i8, ptr %cpu, i64 188
  %next_pc58 = load i32, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 188
  %95 = load i32, ptr %94, align 4
  %96 = getelementptr i8, ptr %cpu, i64 296
  %97 = load i8, ptr %96, align 1
  br label %chain_exit

did_jump_cont20:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010140_entry:                            ; preds = %cec_checked
  br label %insn_0x00010140

insn_0x00010140:                                  ; preds = %insn_0x00010140_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 31765
  %98 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_lo, ptr %98, align 4
  br label %insn_0x00010144_entry

insn_0x00010144_entry:                            ; preds = %insn_0x00010140
  br label %insn_0x00010144

insn_0x00010144:                                  ; preds = %insn_0x00010144_entry
  %add32 = add i32 %or32, %with_lo
  %99 = getelementptr i8, ptr %cpu, i32 0
  store i32 %add32, ptr %99, align 4
  %flgs = lshr i32 %or32, 31
  %flgo = lshr i32 %with_lo, 31
  %flgn = lshr i32 %add32, 31
  %100 = xor i32 %flgo, %flgn
  %101 = xor i32 %flgs, %flgn
  %102 = and i32 %101, %100
  %103 = xor i32 %or32, -1
  %104 = icmp ult i32 %103, %with_lo
  %ac0 = zext i1 %104 to i32
  %105 = icmp eq i32 %add32, 0
  %az23 = zext i1 %105 to i32
  %an24 = lshr i32 %add32, 31
  %106 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az23, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an24, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %108, align 4
  %109 = or i32 %vs_cur, %102
  %110 = getelementptr i8, ptr %cpu, i32 248
  store i32 %102, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i32 252
  store i32 %102, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i32 256
  store i32 %109, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %114, align 4
  br label %insn_0x00010146_entry

insn_0x00010146_entry:                            ; preds = %insn_0x00010144
  br label %insn_0x00010146

insn_0x00010146:                                  ; preds = %insn_0x00010146_entry
  %115 = and i32 %sp2, 3
  %116 = icmp ne i32 %115, 0
  br i1 %116, label %data_misaligned25, label %data_aligned26, !prof !1

data_misaligned25:                                ; preds = %insn_0x00010146
  %117 = getelementptr i8, ptr %cpu, i32 188
  store i32 65862, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %119, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65862, i32 %sp2, i32 0)
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc59 = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

data_aligned26:                                   ; preds = %insn_0x00010146
  %125 = lshr i32 %sp2, 12
  %page_index27 = zext i32 %125 to i64
  %page_slot28 = getelementptr ptr, ptr %page_table, i64 %page_index27
  %page29 = load ptr, ptr %page_slot28, align 8
  %page_mapped30 = icmp ne ptr %page29, null
  br i1 %page_mapped30, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned26
  %126 = and i32 %sp2, 4095
  %page_offset31 = zext i32 %126 to i64
  %127 = getelementptr i8, ptr %page29, i64 %page_offset31
  %page_val = load i32, ptr %127, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned26
  %128 = getelementptr i8, ptr %cpu, i32 188
  store i32 65862, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %130, align 4
  %131 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %132 = getelementptr i8, ptr %cpu, i32 296
  %dj34 = load i8, ptr %132, align 1
  %dj_set35 = icmp ne i8 %dj34, 0
  br i1 %dj_set35, label %did_jump_exit32, label %did_jump_cont33, !prof !1

page_done:                                        ; preds = %did_jump_cont33, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %131, %did_jump_cont33 ]
  %sp136 = add i32 %sp2, 4
  %133 = and i32 %sp136, 3
  %134 = icmp ne i32 %133, 0
  br i1 %134, label %data_misaligned37, label %data_aligned38, !prof !1

did_jump_exit32:                                  ; preds = %page_slow
  %135 = getelementptr i8, ptr %cpu, i64 188
  %next_pc60 = load i32, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i64 188
  %137 = load i32, ptr %136, align 4
  %138 = getelementptr i8, ptr %cpu, i64 296
  %139 = load i8, ptr %138, align 1
  br label %chain_exit

did_jump_cont33:                                  ; preds = %page_slow
  br label %page_done

data_misaligned37:                                ; preds = %page_done
  %140 = getelementptr i8, ptr %cpu, i32 188
  store i32 65862, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %142, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65862, i32 %sp136, i32 0)
  %143 = getelementptr i8, ptr %cpu, i64 188
  %next_pc61 = load i32, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i64 188
  %145 = load i32, ptr %144, align 4
  %146 = getelementptr i8, ptr %cpu, i64 296
  %147 = load i8, ptr %146, align 1
  br label %chain_exit

data_aligned38:                                   ; preds = %page_done
  %148 = lshr i32 %sp136, 12
  %page_index42 = zext i32 %148 to i64
  %page_slot43 = getelementptr ptr, ptr %page_table, i64 %page_index42
  %page44 = load ptr, ptr %page_slot43, align 8
  %page_mapped45 = icmp ne ptr %page44, null
  br i1 %page_mapped45, label %page_fast39, label %page_slow40, !prof !0

page_fast39:                                      ; preds = %data_aligned38
  %149 = and i32 %sp136, 4095
  %page_offset46 = zext i32 %149 to i64
  %150 = getelementptr i8, ptr %page44, i64 %page_offset46
  %page_val47 = load i32, ptr %150, align 4
  br label %page_done41

page_slow40:                                      ; preds = %data_aligned38
  %151 = getelementptr i8, ptr %cpu, i32 188
  store i32 65862, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %153, align 4
  %154 = call i32 @mem_read32(ptr %mem, i32 %sp136)
  %155 = getelementptr i8, ptr %cpu, i32 296
  %dj50 = load i8, ptr %155, align 1
  %dj_set51 = icmp ne i8 %dj50, 0
  br i1 %dj_set51, label %did_jump_exit48, label %did_jump_cont49, !prof !1

page_done41:                                      ; preds = %did_jump_cont49, %page_fast39
  %mem_val52 = phi i32 [ %page_val47, %page_fast39 ], [ %154, %did_jump_cont49 ]
  %sp253 = add i32 %sp136, 4
  %156 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val52, ptr %157, align 4
  %158 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp253, ptr %158, align 4
  br label %insn_0x0001014a_entry

did_jump_exit48:                                  ; preds = %page_slow40
  %159 = getelementptr i8, ptr %cpu, i64 188
  %next_pc62 = load i32, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i64 188
  %161 = load i32, ptr %160, align 4
  %162 = getelementptr i8, ptr %cpu, i64 296
  %163 = load i8, ptr %162, align 1
  br label %chain_exit

did_jump_cont49:                                  ; preds = %page_slow40
  br label %page_done41

insn_0x0001014a_entry:                            ; preds = %page_done41
  br label %insn_0x0001014a

insn_0x0001014a:                                  ; preds = %insn_0x0001014a_entry
  %lsb = and i32 %mem_val52, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001014a
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001014a
  %164 = getelementptr i8, ptr %cpu, i32 188
  store i32 65866, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %165, align 4
  %166 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %166, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %167 = getelementptr i8, ptr %cpu, i64 188
  %next_pc63 = load i32, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i64 188
  %169 = load i32, ptr %168, align 4
  %170 = getelementptr i8, ptr %cpu, i64 296
  %171 = load i8, ptr %170, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %172 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %172, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit48, %data_misaligned37, %did_jump_exit32, %data_misaligned25, %did_jump_exit19, %did_jump_exit15, %data_misaligned5, %did_jump_exit, %data_misaligned
  %next_pc64 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc55, %did_jump_exit ], [ %next_pc56, %data_misaligned5 ], [ %next_pc57, %did_jump_exit15 ], [ %next_pc58, %did_jump_exit19 ], [ %next_pc59, %data_misaligned25 ], [ %next_pc60, %did_jump_exit32 ], [ %next_pc61, %data_misaligned37 ], [ %next_pc62, %did_jump_exit48 ], [ %mem_val52, %jump_aligned ], [ %next_pc63, %jump_misalign ]
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned5 ], [ 5, %did_jump_exit15 ], [ 5, %did_jump_exit19 ], [ 8, %data_misaligned25 ], [ 8, %did_jump_exit32 ], [ 8, %data_misaligned37 ], [ 8, %did_jump_exit48 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail = phi i32 [ %49, %data_misaligned ], [ %63, %did_jump_exit ], [ %71, %data_misaligned5 ], [ %86, %did_jump_exit15 ], [ %95, %did_jump_exit19 ], [ %122, %data_misaligned25 ], [ %137, %did_jump_exit32 ], [ %145, %data_misaligned37 ], [ %161, %did_jump_exit48 ], [ %mem_val52, %jump_aligned ], [ %169, %jump_misalign ]
  %tail65 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned5 ], [ 4, %did_jump_exit15 ], [ 4, %did_jump_exit19 ], [ 4, %data_misaligned25 ], [ 4, %did_jump_exit32 ], [ 4, %data_misaligned37 ], [ 4, %did_jump_exit48 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail66 = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned5 ], [ 5, %did_jump_exit15 ], [ 5, %did_jump_exit19 ], [ 8, %data_misaligned25 ], [ 8, %did_jump_exit32 ], [ 8, %data_misaligned37 ], [ 8, %did_jump_exit48 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail67 = phi i8 [ %51, %data_misaligned ], [ %65, %did_jump_exit ], [ %73, %data_misaligned5 ], [ %88, %did_jump_exit15 ], [ %97, %did_jump_exit19 ], [ %124, %data_misaligned25 ], [ %139, %did_jump_exit32 ], [ %147, %data_misaligned37 ], [ %163, %did_jump_exit48 ], [ 1, %jump_aligned ], [ %171, %jump_misalign ]
  %173 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %173, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %174 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %174 monotonic, align 4, !range !2
  %175 = icmp ult i32 %chain_total, %chain_budget
  br i1 %175, label %chain_lookup, label %chain_leave68, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %176 = lshr i32 %next_pc64, 1
  %177 = and i32 %176, 65535
  %178 = zext i32 %177 to i64
  %179 = mul i64 %178, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %179
  %180 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %180, align 4
  %181 = icmp eq i32 %slot_pc, %next_pc64
  br i1 %181, label %chain_hit, label %chain_leave68, !prof !0

chain_leave68:                                    ; preds = %chain_lookup, %chain_exit
  %182 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail65, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail66, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail67, ptr %185, align 1
  ret void

chain_hit:                                        ; preds = %chain_lookup
  %186 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc64, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %188, align 1
  %189 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %189, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
