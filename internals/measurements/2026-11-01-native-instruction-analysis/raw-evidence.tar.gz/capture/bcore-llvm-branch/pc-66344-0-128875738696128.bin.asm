
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66344-0-128875738696128.bin:     file format binary


Disassembly of section .data:

0000753638a009c0 <.data>:
    753638a009c0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    753638a009c7:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    753638a009cc:	ba 91 fc fe ff       	mov    edx,0xfffefc91
    753638a009d1:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a009d8:	01 d6                	add    esi,edx
    753638a009da:	b1 01                	mov    cl,0x1
    753638a009dc:	b8 65 01 00 00       	mov    eax,0x165
    753638a009e1:	83 fe b8             	cmp    esi,0xffffffb8
    753638a009e4:	0f 87 9b 06 00 00    	ja     0x753638a01085
    753638a009ea:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a009f1:	83 fa b8             	cmp    edx,0xffffffb8
    753638a009f4:	0f 87 8b 06 00 00    	ja     0x753638a01085
    753638a009fa:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753638a00a01:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753638a00a06:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    753638a00a0a:	45 8d 51 fc          	lea    r10d,[r9-0x4]
    753638a00a0e:	41 f6 c1 03          	test   r9b,0x3
    753638a00a12:	0f 85 47 0a 00 18    	jne    0x753650a0145f
    753638a00a18:	4d 8b 9d 38 01 00 00 	mov    r11,QWORD PTR [r13+0x138]
    753638a00a1f:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753638a00a26:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    753638a00a2b:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    753638a00a2f:	44 89 d7             	mov    edi,r10d
    753638a00a32:	c1 ef 0c             	shr    edi,0xc
    753638a00a35:	49 8b 04 fb          	mov    rax,QWORD PTR [r11+rdi*8]
    753638a00a39:	48 85 c0             	test   rax,rax
    753638a00a3c:	0f 84 73 0a 00 18    	je     0x753650a014b5
    753638a00a42:	44 89 d1             	mov    ecx,r10d
    753638a00a45:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00a4b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00a4e:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    753638a00a52:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    753638a00a56:	89 e8                	mov    eax,ebp
    753638a00a58:	c1 e8 0c             	shr    eax,0xc
    753638a00a5b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753638a00a62:	00 
    753638a00a63:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00a67:	48 85 c0             	test   rax,rax
    753638a00a6a:	0f 84 a0 0a 00 18    	je     0x753650a01510
    753638a00a70:	89 e9                	mov    ecx,ebp
    753638a00a72:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00a78:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00a7b:	41 8d 71 f4          	lea    esi,[r9-0xc]
    753638a00a7f:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    753638a00a83:	89 f0                	mov    eax,esi
    753638a00a85:	c1 e8 0c             	shr    eax,0xc
    753638a00a88:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753638a00a8d:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00a91:	48 85 c0             	test   rax,rax
    753638a00a94:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    753638a00a99:	0f 84 d5 0a 00 18    	je     0x753650a01574
    753638a00a9f:	48 89 f1             	mov    rcx,rsi
    753638a00aa2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00aa8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00aab:	41 8d 71 f0          	lea    esi,[r9-0x10]
    753638a00aaf:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    753638a00ab3:	89 f0                	mov    eax,esi
    753638a00ab5:	c1 e8 0c             	shr    eax,0xc
    753638a00ab8:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753638a00abd:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00ac1:	48 85 c0             	test   rax,rax
    753638a00ac4:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    753638a00ac9:	0f 84 07 0b 00 18    	je     0x753650a015d6
    753638a00acf:	48 89 f1             	mov    rcx,rsi
    753638a00ad2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00ad8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00adb:	41 8d 71 ec          	lea    esi,[r9-0x14]
    753638a00adf:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    753638a00ae3:	89 f0                	mov    eax,esi
    753638a00ae5:	c1 e8 0c             	shr    eax,0xc
    753638a00ae8:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753638a00aed:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00af1:	48 85 c0             	test   rax,rax
    753638a00af4:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    753638a00af9:	0f 84 39 0b 00 18    	je     0x753650a01638
    753638a00aff:	89 f1                	mov    ecx,esi
    753638a00b01:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00b07:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00b0a:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a00b0e:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    753638a00b13:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    753638a00b17:	0f 85 7f 0b 00 18    	jne    0x753650a0169c
    753638a00b1d:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    753638a00b21:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a00b28:	41 8d 71 e8          	lea    esi,[r9-0x18]
    753638a00b2c:	89 f0                	mov    eax,esi
    753638a00b2e:	c1 e8 0c             	shr    eax,0xc
    753638a00b31:	49 89 c6             	mov    r14,rax
    753638a00b34:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00b38:	48 85 c0             	test   rax,rax
    753638a00b3b:	48 89 74 24 48       	mov    QWORD PTR [rsp+0x48],rsi
    753638a00b40:	0f 84 cd 0b 00 18    	je     0x753650a01713
    753638a00b46:	48 89 f1             	mov    rcx,rsi
    753638a00b49:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00b4f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00b52:	45 8d 61 e4          	lea    r12d,[r9-0x1c]
    753638a00b56:	45 89 e7             	mov    r15d,r12d
    753638a00b59:	41 c1 ef 0c          	shr    r15d,0xc
    753638a00b5d:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    753638a00b61:	48 85 c0             	test   rax,rax
    753638a00b64:	0f 84 1f 0c 00 18    	je     0x753650a01789
    753638a00b6a:	44 89 e1             	mov    ecx,r12d
    753638a00b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00b73:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    753638a00b76:	45 89 65 3c          	mov    DWORD PTR [r13+0x3c],r12d
    753638a00b7a:	45 89 65 38          	mov    DWORD PTR [r13+0x38],r12d
    753638a00b7e:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    753638a00b82:	0f 85 7d 0c 00 18    	jne    0x753650a01805
    753638a00b88:	41 8b 5d 00          	mov    ebx,DWORD PTR [r13+0x0]
    753638a00b8c:	31 c0                	xor    eax,eax
    753638a00b8e:	31 c9                	xor    ecx,ecx
    753638a00b90:	31 d2                	xor    edx,edx
    753638a00b92:	31 f6                	xor    esi,esi
    753638a00b94:	83 fb 04             	cmp    ebx,0x4
    753638a00b97:	0f 94 c0             	sete   al
    753638a00b9a:	0f 92 c1             	setb   cl
    753638a00b9d:	40 0f 96 c6          	setbe  sil
    753638a00ba1:	0f 93 c2             	setae  dl
    753638a00ba4:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    753638a00bab:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    753638a00bb2:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    753638a00bb9:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    753638a00bc0:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    753638a00bc7:	0f 87 10 03 00 00    	ja     0x753638a00edd
    753638a00bcd:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    753638a00bd2:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
    753638a00bd6:	89 e8                	mov    eax,ebp
    753638a00bd8:	c1 e8 1f             	shr    eax,0x1f
    753638a00bdb:	31 c9                	xor    ecx,ecx
    753638a00bdd:	85 ed                	test   ebp,ebp
    753638a00bdf:	0f 94 c1             	sete   cl
    753638a00be2:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    753638a00be9:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    753638a00bf0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    753638a00bf7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    753638a00bfe:	00 00 00 
    753638a00c01:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    753638a00c08:	0f 84 34 03 00 00    	je     0x753638a00f42
    753638a00c0e:	41 c7 45 0c 00 48 e8 	mov    DWORD PTR [r13+0xc],0x1e84800
    753638a00c15:	01 
    753638a00c16:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a00c1d:	00 00 00 00 
    753638a00c21:	31 c0                	xor    eax,eax
    753638a00c23:	31 c9                	xor    ecx,ecx
    753638a00c25:	31 d2                	xor    edx,edx
    753638a00c27:	31 f6                	xor    esi,esi
    753638a00c29:	81 fd 00 48 e8 01    	cmp    ebp,0x1e84800
    753638a00c2f:	0f 94 c0             	sete   al
    753638a00c32:	0f 92 c1             	setb   cl
    753638a00c35:	40 0f 96 c6          	setbe  sil
    753638a00c39:	0f 93 c2             	setae  dl
    753638a00c3c:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    753638a00c43:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    753638a00c4a:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    753638a00c51:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    753638a00c58:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    753638a00c5f:	0f 87 17 03 00 00    	ja     0x753638a00f7c
    753638a00c65:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    753638a00c6c:	00 
    753638a00c6d:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    753638a00c74:	48 85 c0             	test   rax,rax
    753638a00c77:	0f 84 28 0c 00 18    	je     0x753650a018a5
    753638a00c7d:	89 98 f0 02 00 00    	mov    DWORD PTR [rax+0x2f0],ebx
    753638a00c83:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    753638a00c88:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    753638a00c8b:	0f 85 8c 0c 00 18    	jne    0x753650a0191d
    753638a00c91:	41 c7 45 28 f4 12 01 	mov    DWORD PTR [r13+0x28],0x112f4
    753638a00c98:	00 
    753638a00c99:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    753638a00ca0:	48 85 c0             	test   rax,rax
    753638a00ca3:	0f 84 f7 0c 00 18    	je     0x753650a019a0
    753638a00ca9:	89 a8 f4 02 00 00    	mov    DWORD PTR [rax+0x2f4],ebp
    753638a00caf:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    753638a00cb2:	0f 85 5c 0d 00 18    	jne    0x753650a01a14
    753638a00cb8:	41 c7 45 28 f8 12 01 	mov    DWORD PTR [r13+0x28],0x112f8
    753638a00cbf:	00 
    753638a00cc0:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    753638a00cc4:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    753638a00ccb:	48 85 c0             	test   rax,rax
    753638a00cce:	0f 84 bf 0d 00 18    	je     0x753650a01a93
    753638a00cd4:	89 90 f8 02 00 00    	mov    DWORD PTR [rax+0x2f8],edx
    753638a00cda:	48 89 fd             	mov    rbp,rdi
    753638a00cdd:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    753638a00ce0:	0f 85 1f 0e 00 18    	jne    0x753650a01b05
    753638a00ce6:	8d 4b fe             	lea    ecx,[rbx-0x2]
    753638a00ce9:	89 ca                	mov    edx,ecx
    753638a00ceb:	c1 ea 1f             	shr    edx,0x1f
    753638a00cee:	89 d8                	mov    eax,ebx
    753638a00cf0:	c1 e8 1f             	shr    eax,0x1f
    753638a00cf3:	09 c2                	or     edx,eax
    753638a00cf5:	31 f6                	xor    esi,esi
    753638a00cf7:	83 fb 02             	cmp    ebx,0x2
    753638a00cfa:	40 0f 93 c6          	setae  sil
    753638a00cfe:	31 ff                	xor    edi,edi
    753638a00d00:	85 c9                	test   ecx,ecx
    753638a00d02:	40 0f 94 c7          	sete   dil
    753638a00d06:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    753638a00d0d:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    753638a00d14:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    753638a00d1b:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    753638a00d22:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    753638a00d29:	0f 84 8b 02 00 00    	je     0x753638a00fba
    753638a00d2f:	8d 4b fd             	lea    ecx,[rbx-0x3]
    753638a00d32:	89 ca                	mov    edx,ecx
    753638a00d34:	c1 ea 1f             	shr    edx,0x1f
    753638a00d37:	09 c2                	or     edx,eax
    753638a00d39:	31 c0                	xor    eax,eax
    753638a00d3b:	83 fb 03             	cmp    ebx,0x3
    753638a00d3e:	0f 93 c0             	setae  al
    753638a00d41:	31 f6                	xor    esi,esi
    753638a00d43:	85 c9                	test   ecx,ecx
    753638a00d45:	40 0f 94 c6          	sete   sil
    753638a00d49:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    753638a00d50:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    753638a00d57:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    753638a00d5e:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    753638a00d65:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    753638a00d6c:	0f 84 a4 02 00 00    	je     0x753638a01016
    753638a00d72:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    753638a00d79:	00 
    753638a00d7a:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    753638a00d7e:	48 85 c0             	test   rax,rax
    753638a00d81:	0f 84 2c 0e 00 18    	je     0x753650a01bb3
    753638a00d87:	41 81 e4 ff 0f 00 00 	and    r12d,0xfff
    753638a00d8e:	42 8b 1c 20          	mov    ebx,DWORD PTR [rax+r12*1]
    753638a00d92:	48 89 e9             	mov    rcx,rbp
    753638a00d95:	4b 8b 04 f3          	mov    rax,QWORD PTR [r11+r14*8]
    753638a00d99:	48 85 c0             	test   rax,rax
    753638a00d9c:	0f 84 77 0e 00 18    	je     0x753650a01c19
    753638a00da2:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    753638a00da7:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a00dad:	8b 3c 10             	mov    edi,DWORD PTR [rax+rdx*1]
    753638a00db0:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    753638a00db4:	41 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],edi
    753638a00dbb:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    753638a00dc0:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a00dc4:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753638a00dc9:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00dcd:	48 85 c0             	test   rax,rax
    753638a00dd0:	0f 84 ab 0e 00 18    	je     0x753650a01c81
    753638a00dd6:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a00ddc:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a00ddf:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    753638a00de3:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753638a00de8:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00dec:	48 85 c0             	test   rax,rax
    753638a00def:	0f 84 f2 0e 00 18    	je     0x753650a01ce7
    753638a00df5:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    753638a00dfa:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a00e00:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a00e03:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    753638a00e07:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753638a00e0c:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00e10:	48 85 c0             	test   rax,rax
    753638a00e13:	0f 84 39 0f 00 18    	je     0x753650a01d52
    753638a00e19:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    753638a00e1e:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a00e24:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a00e27:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    753638a00e2b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753638a00e32:	00 
    753638a00e33:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    753638a00e37:	48 85 c0             	test   rax,rax
    753638a00e3a:	0f 84 7d 0f 00 18    	je     0x753650a01dbd
    753638a00e40:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    753638a00e45:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a00e4b:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a00e4e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    753638a00e52:	49 8b 04 cb          	mov    rax,QWORD PTR [r11+rcx*8]
    753638a00e56:	48 85 c0             	test   rax,rax
    753638a00e59:	0f 84 c9 0f 00 18    	je     0x753650a01e28
    753638a00e5f:	41 81 e2 ff 0f 00 00 	and    r10d,0xfff
    753638a00e66:	42 8b 04 10          	mov    eax,DWORD PTR [rax+r10*1]
    753638a00e6a:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    753638a00e6e:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    753638a00e72:	b1 01                	mov    cl,0x1
    753638a00e74:	bb 02 00 00 00       	mov    ebx,0x2
    753638a00e79:	bd 1b 00 00 00       	mov    ebp,0x1b
    753638a00e7e:	40 f6 c7 01          	test   dil,0x1
    753638a00e82:	0f 85 f2 0f 00 18    	jne    0x753650a01e7a
    753638a00e88:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a00e8f:	01 e8                	add    eax,ebp
    753638a00e91:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a00e98:	39 d0                	cmp    eax,edx
    753638a00e9a:	0f 83 d9 0c 00 18    	jae    0x753650a01b79
    753638a00ea0:	8d 14 fd 00 00 00 00 	lea    edx,[rdi*8+0x0]
    753638a00ea7:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753638a00ead:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753638a00eb2:	39 3c 16             	cmp    DWORD PTR [rsi+rdx*1],edi
    753638a00eb5:	0f 85 be 0c 00 18    	jne    0x753650a01b79
    753638a00ebb:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    753638a00ec2:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a00ec9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a00ed0:	00 
    753638a00ed1:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753638a00ed6:	48 8b 44 10 08       	mov    rax,QWORD PTR [rax+rdx*1+0x8]
    753638a00edb:	eb 57                	jmp    0x753638a00f34
    753638a00edd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753638a00ee4:	70 03 01 00 
    753638a00ee8:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a00eef:	83 c0 04             	add    eax,0x4
    753638a00ef2:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a00ef9:	39 c8                	cmp    eax,ecx
    753638a00efb:	0f 83 88 09 00 18    	jae    0x753650a01889
    753638a00f01:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    753638a00f06:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    753638a00f0d:	03 01 00 
    753638a00f10:	0f 85 73 09 00 18    	jne    0x753650a01889
    753638a00f16:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753638a00f1d:	70 03 01 00 
    753638a00f21:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a00f28:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753638a00f2d:	48 8b 80 88 1b 08 00 	mov    rax,QWORD PTR [rax+0x81b88]
    753638a00f34:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    753638a00f39:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753638a00f40:	ff e0                	jmp    rax
    753638a00f42:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753638a00f49:	70 03 01 00 
    753638a00f4d:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a00f54:	83 c0 06             	add    eax,0x6
    753638a00f57:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a00f5e:	39 c8                	cmp    eax,ecx
    753638a00f60:	0f 83 cb 04 00 18    	jae    0x753650a01431
    753638a00f66:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    753638a00f6b:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    753638a00f72:	03 01 00 
    753638a00f75:	74 9f                	je     0x753638a00f16
    753638a00f77:	e9 b5 04 00 18       	jmp    0x753650a01431
    753638a00f7c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753638a00f83:	70 03 01 00 
    753638a00f87:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a00f8e:	83 c0 0a             	add    eax,0xa
    753638a00f91:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a00f98:	39 c8                	cmp    eax,ecx
    753638a00f9a:	0f 83 a8 04 00 18    	jae    0x753650a01448
    753638a00fa0:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    753638a00fa5:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    753638a00fac:	03 01 00 
    753638a00faf:	0f 84 61 ff ff ff    	je     0x753638a00f16
    753638a00fb5:	e9 8e 04 00 18       	jmp    0x753650a01448
    753638a00fba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    753638a00fc1:	7a 03 01 00 
    753638a00fc5:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a00fcc:	83 c0 15             	add    eax,0x15
    753638a00fcf:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a00fd6:	39 c8                	cmp    eax,ecx
    753638a00fd8:	0f 83 a7 0b 00 18    	jae    0x753650a01b85
    753638a00fde:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    753638a00fe3:	81 b9 d0 1b 08 00 7a 	cmp    DWORD PTR [rcx+0x81bd0],0x1037a
    753638a00fea:	03 01 00 
    753638a00fed:	0f 85 92 0b 00 18    	jne    0x753650a01b85
    753638a00ff3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    753638a00ffa:	7a 03 01 00 
    753638a00ffe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01005:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753638a0100a:	48 8b 80 d8 1b 08 00 	mov    rax,QWORD PTR [rax+0x81bd8]
    753638a01011:	e9 1e ff ff ff       	jmp    0x753638a00f34
    753638a01016:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    753638a0101d:	a4 03 01 00 
    753638a01021:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a01028:	83 c0 17             	add    eax,0x17
    753638a0102b:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a01032:	39 c8                	cmp    eax,ecx
    753638a01034:	0f 83 62 0b 00 18    	jae    0x753650a01b9c
    753638a0103a:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    753638a0103f:	81 b9 20 1d 08 00 a4 	cmp    DWORD PTR [rcx+0x81d20],0x103a4
    753638a01046:	03 01 00 
    753638a01049:	0f 85 4d 0b 00 18    	jne    0x753650a01b9c
    753638a0104f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    753638a01056:	a4 03 01 00 
    753638a0105a:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a01061:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753638a01066:	48 8b 80 28 1d 08 00 	mov    rax,QWORD PTR [rax+0x81d28]
    753638a0106d:	e9 c2 fe ff ff       	jmp    0x753638a00f34
    753638a01072:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a01079:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a01080:	b8 28 01 00 00       	mov    eax,0x128
    753638a01085:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a0108a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753638a01091:	c2 08 00             	ret    0x8
