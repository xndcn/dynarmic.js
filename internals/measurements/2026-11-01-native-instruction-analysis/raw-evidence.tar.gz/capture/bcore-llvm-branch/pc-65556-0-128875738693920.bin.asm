
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65556-0-128875738693920.bin:     file format binary


Disassembly of section .data:

0000753638a00120 <.data>:
    753638a00120:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    753638a00127:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    753638a0012c:	ba c1 ff fe ff       	mov    edx,0xfffeffc1
    753638a00131:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a00138:	01 d6                	add    esi,edx
    753638a0013a:	b1 01                	mov    cl,0x1
    753638a0013c:	b8 65 01 00 00       	mov    eax,0x165
    753638a00141:	83 fe d4             	cmp    esi,0xffffffd4
    753638a00144:	0f 87 c6 04 00 00    	ja     0x753638a00610
    753638a0014a:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a00151:	83 fa d4             	cmp    edx,0xffffffd4
    753638a00154:	0f 87 b6 04 00 00    	ja     0x753638a00610
    753638a0015a:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    753638a00161:	45 8b 45 38          	mov    r8d,DWORD PTR [r13+0x38]
    753638a00165:	45 8d 48 fc          	lea    r9d,[r8-0x4]
    753638a00169:	41 f6 c0 03          	test   r8b,0x3
    753638a0016d:	0f 85 99 fe ff 17    	jne    0x753650a0000c
    753638a00173:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    753638a0017a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    753638a00181:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    753638a00185:	45 89 ca             	mov    r10d,r9d
    753638a00188:	41 c1 ea 0c          	shr    r10d,0xc
    753638a0018c:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    753638a00190:	48 85 c0             	test   rax,rax
    753638a00193:	0f 84 d0 fe ff 17    	je     0x753650a00069
    753638a00199:	44 89 c9             	mov    ecx,r9d
    753638a0019c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a001a2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a001a5:	45 8d 58 f8          	lea    r11d,[r8-0x8]
    753638a001a9:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    753638a001ad:	44 89 d8             	mov    eax,r11d
    753638a001b0:	c1 e8 0c             	shr    eax,0xc
    753638a001b3:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    753638a001ba:	00 
    753638a001bb:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a001bf:	48 85 c0             	test   rax,rax
    753638a001c2:	0f 84 02 ff ff 17    	je     0x753650a000ca
    753638a001c8:	44 89 d9             	mov    ecx,r11d
    753638a001cb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a001d1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a001d4:	41 8d 70 f4          	lea    esi,[r8-0xc]
    753638a001d8:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    753638a001dc:	89 f0                	mov    eax,esi
    753638a001de:	c1 e8 0c             	shr    eax,0xc
    753638a001e1:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    753638a001e8:	00 
    753638a001e9:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a001ed:	48 85 c0             	test   rax,rax
    753638a001f0:	48 89 74 24 38       	mov    QWORD PTR [rsp+0x38],rsi
    753638a001f5:	0f 84 3a ff ff 17    	je     0x753650a00135
    753638a001fb:	48 89 f1             	mov    rcx,rsi
    753638a001fe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00204:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00207:	41 8d 70 f0          	lea    esi,[r8-0x10]
    753638a0020b:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    753638a0020f:	89 f0                	mov    eax,esi
    753638a00211:	c1 e8 0c             	shr    eax,0xc
    753638a00214:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753638a0021b:	00 
    753638a0021c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a00220:	48 85 c0             	test   rax,rax
    753638a00223:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    753638a00228:	0f 84 6f ff ff 17    	je     0x753650a0019d
    753638a0022e:	48 89 f1             	mov    rcx,rsi
    753638a00231:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00237:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0023a:	41 8d 70 ec          	lea    esi,[r8-0x14]
    753638a0023e:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    753638a00242:	89 f0                	mov    eax,esi
    753638a00244:	c1 e8 0c             	shr    eax,0xc
    753638a00247:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753638a0024c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a00250:	48 85 c0             	test   rax,rax
    753638a00253:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    753638a00258:	0f 84 a7 ff ff 17    	je     0x753650a00205
    753638a0025e:	48 89 f1             	mov    rcx,rsi
    753638a00261:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00267:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0026a:	41 8d 70 e8          	lea    esi,[r8-0x18]
    753638a0026e:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    753638a00272:	89 f0                	mov    eax,esi
    753638a00274:	c1 e8 0c             	shr    eax,0xc
    753638a00277:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753638a0027c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a00280:	48 85 c0             	test   rax,rax
    753638a00283:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    753638a00288:	0f 84 df ff ff 17    	je     0x753650a0026d
    753638a0028e:	48 89 f1             	mov    rcx,rsi
    753638a00291:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00297:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a0029a:	41 8d 70 e4          	lea    esi,[r8-0x1c]
    753638a0029e:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    753638a002a2:	89 f0                	mov    eax,esi
    753638a002a4:	c1 e8 0c             	shr    eax,0xc
    753638a002a7:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    753638a002ac:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a002b0:	48 85 c0             	test   rax,rax
    753638a002b3:	48 89 74 24 68       	mov    QWORD PTR [rsp+0x68],rsi
    753638a002b8:	0f 84 17 00 00 18    	je     0x753650a002d5
    753638a002be:	89 f1                	mov    ecx,esi
    753638a002c0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a002c6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a002c9:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    753638a002cd:	49 89 de             	mov    r14,rbx
    753638a002d0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    753638a002d3:	0f 85 66 00 00 18    	jne    0x753650a0033f
    753638a002d9:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    753638a002de:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    753638a002e2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    753638a002e6:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a002ed:	41 8d 70 e0          	lea    esi,[r8-0x20]
    753638a002f1:	89 f1                	mov    ecx,esi
    753638a002f3:	c1 e9 0c             	shr    ecx,0xc
    753638a002f6:	49 8b 04 cc          	mov    rax,QWORD PTR [r12+rcx*8]
    753638a002fa:	48 85 c0             	test   rax,rax
    753638a002fd:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    753638a00302:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    753638a00307:	0f 84 a4 00 00 18    	je     0x753650a003b1
    753638a0030d:	48 89 f1             	mov    rcx,rsi
    753638a00310:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00316:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a00319:	41 8d 68 dc          	lea    ebp,[r8-0x24]
    753638a0031d:	41 89 ef             	mov    r15d,ebp
    753638a00320:	41 c1 ef 0c          	shr    r15d,0xc
    753638a00324:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    753638a00328:	48 85 c0             	test   rax,rax
    753638a0032b:	0f 84 f1 00 00 18    	je     0x753650a00422
    753638a00331:	89 e9                	mov    ecx,ebp
    753638a00333:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a00339:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    753638a0033c:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a00340:	41 8d 40 c8          	lea    eax,[r8-0x38]
    753638a00344:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    753638a00348:	4c 89 f3             	mov    rbx,r14
    753638a0034b:	41 80 3e 00          	cmp    BYTE PTR [r14],0x0
    753638a0034f:	0f 85 43 01 00 18    	jne    0x753650a00498
    753638a00355:	41 c7 45 28 00 f0 00 	mov    DWORD PTR [r13+0x28],0xf000
    753638a0035c:	00 
    753638a0035d:	66 41 c7 45 06 42 43 	mov    WORD PTR [r13+0x6],0x4342
    753638a00364:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a00369:	48 85 c0             	test   rax,rax
    753638a0036c:	0f 84 ae 01 00 18    	je     0x753650a00520
    753638a00372:	8b 00                	mov    eax,DWORD PTR [rax]
    753638a00374:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    753638a00378:	41 c7 45 04 31 4e 42 	mov    DWORD PTR [r13+0x4],0x43424e31
    753638a0037f:	43 
    753638a00380:	8d 88 cf b1 bd bc    	lea    ecx,[rax-0x43424e31]
    753638a00386:	89 ca                	mov    edx,ecx
    753638a00388:	09 c2                	or     edx,eax
    753638a0038a:	c1 ea 1f             	shr    edx,0x1f
    753638a0038d:	31 f6                	xor    esi,esi
    753638a0038f:	3d 31 4e 42 43       	cmp    eax,0x43424e31
    753638a00394:	40 0f 93 c6          	setae  sil
    753638a00398:	31 c0                	xor    eax,eax
    753638a0039a:	85 c9                	test   ecx,ecx
    753638a0039c:	0f 94 c0             	sete   al
    753638a0039f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    753638a003a6:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    753638a003ad:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    753638a003b4:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    753638a003bb:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    753638a003c2:	0f 84 e6 01 00 00    	je     0x753638a005ae
    753638a003c8:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    753638a003cf:	00 
    753638a003d0:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    753638a003d7:	00 
    753638a003d8:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    753638a003dd:	48 85 c0             	test   rax,rax
    753638a003e0:	0f 84 d4 01 00 18    	je     0x753650a005ba
    753638a003e6:	c7 40 10 03 00 00 00 	mov    DWORD PTR [rax+0x10],0x3
    753638a003ed:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    753638a003f0:	0f 85 43 02 00 18    	jne    0x753650a00639
    753638a003f6:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    753638a003fd:	00 
    753638a003fe:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    753638a00402:	48 85 c0             	test   rax,rax
    753638a00405:	0f 84 af 02 00 18    	je     0x753650a006ba
    753638a0040b:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    753638a00411:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    753638a00414:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    753638a00419:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    753638a0041e:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    753638a00423:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a00427:	48 85 c0             	test   rax,rax
    753638a0042a:	0f 84 ff 02 00 18    	je     0x753650a0072f
    753638a00430:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    753638a00435:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a0043b:	8b 1c 10             	mov    ebx,DWORD PTR [rax+rdx*1]
    753638a0043e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a00442:	41 89 9d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ebx
    753638a00449:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    753638a0044e:	41 89 55 38          	mov    DWORD PTR [r13+0x38],edx
    753638a00452:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753638a00457:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a0045b:	48 85 c0             	test   rax,rax
    753638a0045e:	0f 84 4e 03 00 18    	je     0x753650a007b2
    753638a00464:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a0046a:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a0046d:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    753638a00471:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753638a00476:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a0047a:	48 85 c0             	test   rax,rax
    753638a0047d:	0f 84 b3 03 00 18    	je     0x753650a00836
    753638a00483:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    753638a00488:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a0048e:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a00491:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    753638a00495:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753638a0049a:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a0049e:	48 85 c0             	test   rax,rax
    753638a004a1:	0f 84 15 04 00 18    	je     0x753650a008bc
    753638a004a7:	48 8b 54 24 60       	mov    rdx,QWORD PTR [rsp+0x60]
    753638a004ac:	81 e2 ff 0f 00 00    	and    edx,0xfff
    753638a004b2:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    753638a004b5:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    753638a004b9:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753638a004c0:	00 
    753638a004c1:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a004c5:	48 85 c0             	test   rax,rax
    753638a004c8:	0f 84 74 04 00 18    	je     0x753650a00942
    753638a004ce:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a004d4:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753638a004d7:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    753638a004db:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    753638a004e2:	00 
    753638a004e3:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a004e7:	48 85 c0             	test   rax,rax
    753638a004ea:	0f 84 d0 04 00 18    	je     0x753650a009c0
    753638a004f0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a004f6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a004f9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    753638a004fd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753638a00504:	00 
    753638a00505:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    753638a00509:	48 85 c0             	test   rax,rax
    753638a0050c:	0f 84 25 05 00 18    	je     0x753650a00a37
    753638a00512:	41 81 e3 ff 0f 00 00 	and    r11d,0xfff
    753638a00519:	42 8b 04 18          	mov    eax,DWORD PTR [rax+r11*1]
    753638a0051d:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    753638a00521:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    753638a00525:	48 85 c0             	test   rax,rax
    753638a00528:	0f 84 79 05 00 18    	je     0x753650a00aa7
    753638a0052e:	41 81 e1 ff 0f 00 00 	and    r9d,0xfff
    753638a00535:	42 8b 04 08          	mov    eax,DWORD PTR [rax+r9*1]
    753638a00539:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    753638a0053d:	45 89 45 38          	mov    DWORD PTR [r13+0x38],r8d
    753638a00541:	b1 01                	mov    cl,0x1
    753638a00543:	41 bc 02 00 00 00    	mov    r12d,0x2
    753638a00549:	bd 10 00 00 00       	mov    ebp,0x10
    753638a0054e:	f6 c3 01             	test   bl,0x1
    753638a00551:	0f 85 ac 05 00 18    	jne    0x753650a00b03
    753638a00557:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a0055e:	01 e8                	add    eax,ebp
    753638a00560:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a00567:	39 d0                	cmp    eax,edx
    753638a00569:	0f 83 91 fa ff 17    	jae    0x753650a00000
    753638a0056f:	8d 14 dd 00 00 00 00 	lea    edx,[rbx*8+0x0]
    753638a00576:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    753638a0057c:	39 1c 17             	cmp    DWORD PTR [rdi+rdx*1],ebx
    753638a0057f:	0f 85 7b fa ff 17    	jne    0x753650a00000
    753638a00585:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    753638a0058c:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a00593:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a0059a:	00 
    753638a0059b:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    753638a005a0:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753638a005a5:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753638a005ac:	ff e0                	jmp    rax
    753638a005ae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    753638a005b5:	40 00 01 00 
    753638a005b9:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a005c0:	83 c0 09             	add    eax,0x9
    753638a005c3:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a005ca:	39 c8                	cmp    eax,ecx
    753638a005cc:	0f 83 cb ff ff 17    	jae    0x753650a0059d
    753638a005d2:	81 bf 00 02 08 00 40 	cmp    DWORD PTR [rdi+0x80200],0x10040
    753638a005d9:	00 01 00 
    753638a005dc:	0f 85 bb ff ff 17    	jne    0x753650a0059d
    753638a005e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    753638a005e9:	40 00 01 00 
    753638a005ed:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a005f4:	48 8b 87 08 02 08 00 	mov    rax,QWORD PTR [rdi+0x80208]
    753638a005fb:	eb a3                	jmp    0x753638a005a0
    753638a005fd:	45 89 a5 24 01 00 00 	mov    DWORD PTR [r13+0x124],r12d
    753638a00604:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a0060b:	b8 28 01 00 00       	mov    eax,0x128
    753638a00610:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a00615:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753638a0061c:	c2 08 00             	ret    0x8
