
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66600-0-128876141355346.bin:     file format binary


Disassembly of section .data:

0000753650a02152 <.data>:
    753650a02152:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753650a02159:	e9 f0 f3 ff e7       	jmp    0x753638a0154e
    753650a0215e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    753650a02165:	2c 04 01 00 
    753650a02169:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02170:	04 00 00 00 
    753650a02174:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a0217b:	02 00 00 00 
    753650a0217f:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a02186:	62 00 00 
    753650a02189:	48 89 fb             	mov    rbx,rdi
    753650a0218c:	4c 89 ef             	mov    rdi,r13
    753650a0218f:	4c 89 f6             	mov    rsi,r14
    753650a02192:	ba 2c 04 01 00       	mov    edx,0x1042c
    753650a02197:	44 89 c1             	mov    ecx,r8d
    753650a0219a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a021a0:	ff d0                	call   rax
    753650a021a2:	48 89 df             	mov    rdi,rbx
    753650a021a5:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a021ac:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a021b3:	00 
    753650a021b4:	bb 04 00 00 00       	mov    ebx,0x4
    753650a021b9:	bd 02 00 00 00       	mov    ebp,0x2
    753650a021be:	e9 3c f3 ff e7       	jmp    0x753638a014ff
    753650a021c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    753650a021ca:	2c 04 01 00 
    753650a021ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a021d5:	04 00 00 00 
    753650a021d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a021e0:	02 00 00 00 
    753650a021e4:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a021eb:	62 00 00 
    753650a021ee:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a021f3:	4c 89 f7             	mov    rdi,r14
    753650a021f6:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753650a021fb:	44 89 c6             	mov    esi,r8d
    753650a021fe:	4d 89 c4             	mov    r12,r8
    753650a02201:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a02206:	44 89 d5             	mov    ebp,r10d
    753650a02209:	ff d0                	call   rax
    753650a0220b:	41 89 ea             	mov    r10d,ebp
    753650a0220e:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a02213:	4d 89 e0             	mov    r8,r12
    753650a02216:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a0221b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02220:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02227:	00 
    753650a02228:	84 c9                	test   cl,cl
    753650a0222a:	0f 84 bb f1 ff e7    	je     0x753638a013eb
    753650a02230:	e9 d9 00 00 00       	jmp    0x753650a0230e
    753650a02235:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    753650a0223c:	2c 04 01 00 
    753650a02240:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02247:	04 00 00 00 
    753650a0224b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a02252:	02 00 00 00 
    753650a02256:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a0225d:	62 00 00 
    753650a02260:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02265:	4c 89 f7             	mov    rdi,r14
    753650a02268:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753650a0226d:	89 ee                	mov    esi,ebp
    753650a0226f:	44 89 d2             	mov    edx,r10d
    753650a02272:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    753650a02277:	4d 89 c6             	mov    r14,r8
    753650a0227a:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a0227f:	ff d0                	call   rax
    753650a02281:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a02286:	4d 89 f0             	mov    r8,r14
    753650a02289:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a0228e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02293:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753650a02298:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0229f:	00 
    753650a022a0:	84 c9                	test   cl,cl
    753650a022a2:	0f 84 66 f1 ff e7    	je     0x753638a0140e
    753650a022a8:	eb 64                	jmp    0x753650a0230e
    753650a022aa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    753650a022b1:	30 04 01 00 
    753650a022b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a022bc:	04 00 00 00 
    753650a022c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753650a022c7:	02 00 00 00 
    753650a022cb:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a022d2:	62 00 00 
    753650a022d5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a022da:	4c 89 ef             	mov    rdi,r13
    753650a022dd:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    753650a022e2:	49 89 f6             	mov    r14,rsi
    753650a022e5:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a022ea:	ff d0                	call   rax
    753650a022ec:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a022f1:	4c 89 f6             	mov    rsi,r14
    753650a022f4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a022f9:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753650a022fe:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02305:	00 
    753650a02306:	84 c9                	test   cl,cl
    753650a02308:	0f 84 12 f1 ff e7    	je     0x753638a01420
    753650a0230e:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a02315:	e9 9a fe ff ff       	jmp    0x753650a021b4
    753650a0231a:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a0231f:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753650a02324:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a02329:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    753650a02330:	34 04 01 00 
    753650a02334:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a0233b:	02 00 00 00 
    753650a0233f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    753650a02346:	04 00 00 00 
    753650a0234a:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02351:	62 00 00 
    753650a02354:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    753650a02359:	4c 89 f7             	mov    rdi,r14
    753650a0235c:	be f0 12 01 00       	mov    esi,0x112f0
    753650a02361:	ff d0                	call   rax
    753650a02363:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a0236a:	00 
    753650a0236b:	84 c9                	test   cl,cl
    753650a0236d:	0f 85 4e 01 00 00    	jne    0x753650a024c1
    753650a02373:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753650a02378:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a0237d:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a02382:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a02387:	e9 b2 f0 ff e7       	jmp    0x753638a0143e
    753650a0238c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    753650a02393:	42 04 01 00 
    753650a02397:	b1 01                	mov    cl,0x1
    753650a02399:	bd 06 00 00 00       	mov    ebp,0x6
    753650a0239e:	bb 02 00 00 00       	mov    ebx,0x2
    753650a023a3:	e9 a6 f1 ff e7       	jmp    0x753638a0154e
    753650a023a8:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    753650a023ad:	49 89 f4             	mov    r12,rsi
    753650a023b0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    753650a023b5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    753650a023bc:	3c 04 01 00 
    753650a023c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a023c7:	04 00 00 00 
    753650a023cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    753650a023d2:	08 00 00 00 
    753650a023d6:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a023dd:	62 00 00 
    753650a023e0:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    753650a023e5:	4c 89 f7             	mov    rdi,r14
    753650a023e8:	89 ee                	mov    esi,ebp
    753650a023ea:	ff d0                	call   rax
    753650a023ec:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a023f3:	00 
    753650a023f4:	84 c9                	test   cl,cl
    753650a023f6:	0f 85 e5 00 00 00    	jne    0x753650a024e1
    753650a023fc:	89 c5                	mov    ebp,eax
    753650a023fe:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753650a02403:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a02408:	4c 89 e6             	mov    rsi,r12
    753650a0240b:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    753650a02410:	e9 af f0 ff e7       	jmp    0x753638a014c4
    753650a02415:	48 89 f3             	mov    rbx,rsi
    753650a02418:	49 89 fc             	mov    r12,rdi
    753650a0241b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    753650a02422:	3c 04 01 00 
    753650a02426:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a0242d:	04 00 00 00 
    753650a02431:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    753650a02438:	08 00 00 00 
    753650a0243c:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02443:	62 00 00 
    753650a02446:	4d 89 f7             	mov    r15,r14
    753650a02449:	4c 89 f7             	mov    rdi,r14
    753650a0244c:	44 89 c6             	mov    esi,r8d
    753650a0244f:	ff d0                	call   rax
    753650a02451:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02458:	00 
    753650a02459:	84 c9                	test   cl,cl
    753650a0245b:	0f 85 93 00 00 00    	jne    0x753650a024f4
    753650a02461:	4d 89 fe             	mov    r14,r15
    753650a02464:	4c 89 e7             	mov    rdi,r12
    753650a02467:	48 89 de             	mov    rsi,rbx
    753650a0246a:	e9 6d f0 ff e7       	jmp    0x753638a014dc
    753650a0246f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    753650a02476:	40 04 01 00 
    753650a0247a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02481:	02 00 00 00 
    753650a02485:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    753650a0248c:	09 00 00 00 
    753650a02490:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a02497:	62 00 00 
    753650a0249a:	49 89 ff             	mov    r15,rdi
    753650a0249d:	4c 89 ef             	mov    rdi,r13
    753650a024a0:	be 2a 00 00 00       	mov    esi,0x2a
    753650a024a5:	4c 89 f2             	mov    rdx,r14
    753650a024a8:	ff d0                	call   rax
    753650a024aa:	4c 89 ff             	mov    rdi,r15
    753650a024ad:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a024b4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a024bb:	00 
    753650a024bc:	e9 3e f0 ff e7       	jmp    0x753638a014ff
    753650a024c1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a024c8:	bb 02 00 00 00       	mov    ebx,0x2
    753650a024cd:	bd 04 00 00 00       	mov    ebp,0x4
    753650a024d2:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    753650a024d7:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    753650a024dc:	e9 1e f0 ff e7       	jmp    0x753638a014ff
    753650a024e1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a024e8:	bb 04 00 00 00       	mov    ebx,0x4
    753650a024ed:	bd 08 00 00 00       	mov    ebp,0x8
    753650a024f2:	eb de                	jmp    0x753650a024d2
    753650a024f4:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a024fb:	bb 04 00 00 00       	mov    ebx,0x4
    753650a02500:	bd 08 00 00 00       	mov    ebp,0x8
    753650a02505:	4d 89 fe             	mov    r14,r15
    753650a02508:	4c 89 e7             	mov    rdi,r12
    753650a0250b:	e9 ef ef ff e7       	jmp    0x753638a014ff
