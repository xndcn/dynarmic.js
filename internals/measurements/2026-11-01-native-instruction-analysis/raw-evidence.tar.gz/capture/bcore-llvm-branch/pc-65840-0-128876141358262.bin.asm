
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65840-0-128876141358262.bin:     file format binary


Disassembly of section .data:

0000753650a02cb6 <.data>:
    753650a02cb6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    753650a02cbd:	3c 01 01 00 
    753650a02cc1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02cc8:	04 00 00 00 
    753650a02ccc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a02cd3:	05 00 00 00 
    753650a02cd7:	48 b8 d0 98 ab d4 72 	movabs rax,0x6272d4ab98d0
    753650a02cde:	62 00 00 
    753650a02ce1:	4c 89 ef             	mov    rdi,r13
    753650a02ce4:	4c 89 de             	mov    rsi,r11
    753650a02ce7:	ba 3c 01 01 00       	mov    edx,0x1013c
    753650a02cec:	89 d9                	mov    ecx,ebx
    753650a02cee:	4d 89 de             	mov    r14,r11
    753650a02cf1:	4c 89 c3             	mov    rbx,r8
    753650a02cf4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753650a02cfa:	ff d0                	call   rax
    753650a02cfc:	49 89 d8             	mov    r8,rbx
    753650a02cff:	4d 89 f3             	mov    r11,r14
    753650a02d02:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a02d09:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02d10:	00 
    753650a02d11:	bb 04 00 00 00       	mov    ebx,0x4
    753650a02d16:	bd 05 00 00 00       	mov    ebp,0x5
    753650a02d1b:	e9 26 f3 ff e7       	jmp    0x753638a02046
    753650a02d20:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    753650a02d27:	3c 01 01 00 
    753650a02d2b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02d32:	04 00 00 00 
    753650a02d36:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a02d3d:	05 00 00 00 
    753650a02d41:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02d48:	62 00 00 
    753650a02d4b:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    753650a02d4f:	4c 89 df             	mov    rdi,r11
    753650a02d52:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753650a02d57:	89 de                	mov    esi,ebx
    753650a02d59:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a02d5e:	4c 89 c5             	mov    rbp,r8
    753650a02d61:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a02d66:	4d 89 d4             	mov    r12,r10
    753650a02d69:	ff d0                	call   rax
    753650a02d6b:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    753650a02d6f:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a02d74:	4d 89 e2             	mov    r10,r12
    753650a02d77:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a02d7c:	49 89 e8             	mov    r8,rbp
    753650a02d7f:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a02d84:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02d8b:	00 
    753650a02d8c:	84 c9                	test   cl,cl
    753650a02d8e:	0f 84 c7 f1 ff e7    	je     0x753638a01f5b
    753650a02d94:	e9 e0 00 00 00       	jmp    0x753650a02e79
    753650a02d99:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    753650a02da0:	3c 01 01 00 
    753650a02da4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02dab:	04 00 00 00 
    753650a02daf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a02db6:	05 00 00 00 
    753650a02dba:	48 b8 20 36 9a d4 72 	movabs rax,0x6272d49a3620
    753650a02dc1:	62 00 00 
    753650a02dc4:	89 fa                	mov    edx,edi
    753650a02dc6:	4c 89 df             	mov    rdi,r11
    753650a02dc9:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753650a02dce:	89 ee                	mov    esi,ebp
    753650a02dd0:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a02dd5:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a02dda:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a02ddf:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a02de4:	ff d0                	call   rax
    753650a02de6:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    753650a02deb:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a02df0:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a02df5:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a02dfa:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a02dff:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02e06:	00 
    753650a02e07:	84 c9                	test   cl,cl
    753650a02e09:	0f 84 6f f1 ff e7    	je     0x753638a01f7e
    753650a02e0f:	eb 68                	jmp    0x753650a02e79
    753650a02e11:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10140
    753650a02e18:	40 01 01 00 
    753650a02e1c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02e23:	04 00 00 00 
    753650a02e27:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    753650a02e2e:	05 00 00 00 
    753650a02e32:	48 b8 00 96 ab d4 72 	movabs rax,0x6272d4ab9600
    753650a02e39:	62 00 00 
    753650a02e3c:	4c 89 ef             	mov    rdi,r13
    753650a02e3f:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    753650a02e44:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a02e49:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    753650a02e4e:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    753650a02e53:	ff d0                	call   rax
    753650a02e55:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    753650a02e5a:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    753650a02e5f:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a02e64:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    753650a02e69:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02e70:	00 
    753650a02e71:	84 c9                	test   cl,cl
    753650a02e73:	0f 84 16 f1 ff e7    	je     0x753638a01f8f
    753650a02e79:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a02e80:	e9 8c fe ff ff       	jmp    0x753650a02d11
    753650a02e85:	49 89 de             	mov    r14,rbx
    753650a02e88:	4d 89 d4             	mov    r12,r10
    753650a02e8b:	4c 89 cb             	mov    rbx,r9
    753650a02e8e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a02e93:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    753650a02e9a:	46 01 01 00 
    753650a02e9e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02ea5:	04 00 00 00 
    753650a02ea9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    753650a02eb0:	08 00 00 00 
    753650a02eb4:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02ebb:	62 00 00 
    753650a02ebe:	4d 89 df             	mov    r15,r11
    753650a02ec1:	4c 89 df             	mov    rdi,r11
    753650a02ec4:	89 ee                	mov    esi,ebp
    753650a02ec6:	ff d0                	call   rax
    753650a02ec8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02ecf:	00 
    753650a02ed0:	84 c9                	test   cl,cl
    753650a02ed2:	0f 85 c9 00 00 00    	jne    0x753650a02fa1
    753650a02ed8:	89 c5                	mov    ebp,eax
    753650a02eda:	4d 89 fb             	mov    r11,r15
    753650a02edd:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a02ee2:	49 89 d9             	mov    r9,rbx
    753650a02ee5:	4d 89 e2             	mov    r10,r12
    753650a02ee8:	4c 89 f3             	mov    rbx,r14
    753650a02eeb:	e9 18 f1 ff e7       	jmp    0x753638a02008
    753650a02ef0:	4d 89 cc             	mov    r12,r9
    753650a02ef3:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    753650a02ef8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    753650a02eff:	46 01 01 00 
    753650a02f03:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753650a02f0a:	04 00 00 00 
    753650a02f0e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    753650a02f15:	08 00 00 00 
    753650a02f19:	48 b8 f0 35 9a d4 72 	movabs rax,0x6272d49a35f0
    753650a02f20:	62 00 00 
    753650a02f23:	4d 89 df             	mov    r15,r11
    753650a02f26:	4c 89 df             	mov    rdi,r11
    753650a02f29:	89 de                	mov    esi,ebx
    753650a02f2b:	ff d0                	call   rax
    753650a02f2d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02f34:	00 
    753650a02f35:	84 c9                	test   cl,cl
    753650a02f37:	75 68                	jne    0x753650a02fa1
    753650a02f39:	4d 89 fb             	mov    r11,r15
    753650a02f3c:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a02f41:	4d 89 e1             	mov    r9,r12
    753650a02f44:	e9 da f0 ff e7       	jmp    0x753638a02023
    753650a02f49:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014a
    753650a02f50:	4a 01 01 00 
    753650a02f54:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    753650a02f5b:	02 00 00 00 
    753650a02f5f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    753650a02f66:	09 00 00 00 
    753650a02f6a:	48 b8 d0 8a ab d4 72 	movabs rax,0x6272d4ab8ad0
    753650a02f71:	62 00 00 
    753650a02f74:	4c 89 ef             	mov    rdi,r13
    753650a02f77:	be 2a 00 00 00       	mov    esi,0x2a
    753650a02f7c:	4c 89 da             	mov    rdx,r11
    753650a02f7f:	4d 89 de             	mov    r14,r11
    753650a02f82:	4d 89 c7             	mov    r15,r8
    753650a02f85:	ff d0                	call   rax
    753650a02f87:	4d 89 f8             	mov    r8,r15
    753650a02f8a:	4d 89 f3             	mov    r11,r14
    753650a02f8d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a02f94:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    753650a02f9b:	00 
    753650a02f9c:	e9 a5 f0 ff e7       	jmp    0x753638a02046
    753650a02fa1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    753650a02fa8:	bb 04 00 00 00       	mov    ebx,0x4
    753650a02fad:	bd 08 00 00 00       	mov    ebp,0x8
    753650a02fb2:	4d 89 fb             	mov    r11,r15
    753650a02fb5:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    753650a02fba:	e9 87 f0 ff e7       	jmp    0x753638a02046
