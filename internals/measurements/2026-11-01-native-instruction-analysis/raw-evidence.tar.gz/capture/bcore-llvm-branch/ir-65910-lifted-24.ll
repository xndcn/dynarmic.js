; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010176(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65910
  %4 = icmp ugt i32 %3, 18
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb23 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb23, 0
  %9 = sub i32 %guard_lb23, 65910
  %10 = icmp ugt i32 %9, 18
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x00010176_entry, label %lb_guard_miss, !prof !0

insn_0x00010176_entry:                            ; preds = %lb_guard
  br label %insn_0x00010176

insn_0x00010176:                                  ; preds = %insn_0x00010176_entry
  %13 = getelementptr i8, ptr %cpu, i32 24
  %rd = load i32, ptr %13, align 4
  %rd_add = add i32 %rd, 1
  %14 = getelementptr i8, ptr %cpu, i32 24
  store i32 %rd_add, ptr %14, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %15 = xor i32 0, %flgn
  %16 = xor i32 %flgs, %flgn
  %overflow = and i32 %16, %15
  %17 = xor i32 %rd, -1
  %18 = icmp ult i32 %17, 1
  %ac0 = zext i1 %18 to i32
  %19 = icmp eq i32 %rd_add, 0
  %az = zext i1 %19 to i32
  %an = lshr i32 %rd_add, 31
  %20 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %22, align 4
  %23 = or i32 %vs_cur, %overflow
  %24 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i32 256
  store i32 %23, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %30, align 4
  br label %insn_0x00010178_entry

insn_0x00010178_entry:                            ; preds = %insn_0x00010176
  br label %insn_0x00010178

insn_0x00010178:                                  ; preds = %insn_0x00010178_entry
  %31 = getelementptr i8, ptr %cpu, i32 20
  %rx = load i32, ptr %31, align 4
  %32 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %32 to i32
  %33 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %33, align 4
  %34 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %34 to i32
  %35 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %35 to i32
  %36 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %36 to i32
  %37 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac03, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac03, ptr %40, align 4
  br label %insn_0x0001017a_entry

insn_0x0001017a_entry:                            ; preds = %insn_0x00010178
  br label %insn_0x0001017a

insn_0x0001017a:                                  ; preds = %insn_0x0001017a_entry
  %cc_true = icmp ne i32 %cc, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x0001017a
  %41 = getelementptr i8, ptr %cpu, i32 188
  store i32 65938, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %42, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %43 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %43 monotonic, align 4, !range !1
  %44 = icmp ult i32 %chain_total, %chain_budget
  br i1 %44, label %chain_go, label %chain_leave24, !prof !0

brt_fallthru:                                     ; preds = %insn_0x0001017a
  br label %insn_0x0001017c_entry

insn_0x0001017c_entry:                            ; preds = %brt_fallthru
  br label %insn_0x0001017c

insn_0x0001017c:                                  ; preds = %insn_0x0001017c_entry
  %45 = getelementptr i8, ptr %cpu, i32 28
  %a = load i32, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 16
  %b = load i32, ptr %46, align 4
  %mul = mul i32 %a, %b
  %47 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mul, ptr %47, align 4
  br label %insn_0x0001017e_entry

insn_0x0001017e_entry:                            ; preds = %insn_0x0001017c
  br label %insn_0x0001017e

insn_0x0001017e:                                  ; preds = %insn_0x0001017e_entry
  %48 = getelementptr i8, ptr %cpu, i32 52
  %regmv_src = load i32, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 4
  store i32 %regmv_src, ptr %49, align 4
  br label %insn_0x00010180_entry

insn_0x00010180_entry:                            ; preds = %insn_0x0001017e
  br label %insn_0x00010180

insn_0x00010180:                                  ; preds = %insn_0x00010180_entry
  %add32 = add i32 %mul, %regmv_src
  %50 = getelementptr i8, ptr %cpu, i32 28
  store i32 %add32, ptr %50, align 4
  %flgs4 = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn5 = lshr i32 %add32, 31
  %51 = xor i32 %flgo, %flgn5
  %52 = xor i32 %flgs4, %flgn5
  %53 = and i32 %52, %51
  %54 = xor i32 %mul, -1
  %55 = icmp ult i32 %54, %regmv_src
  %ac06 = zext i1 %55 to i32
  %56 = icmp eq i32 %add32, 0
  %az7 = zext i1 %56 to i32
  %an8 = lshr i32 %add32, 31
  %57 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az7, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an8, ptr %58, align 4
  %59 = or i32 %23, %53
  %60 = getelementptr i8, ptr %cpu, i32 248
  store i32 %53, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 252
  store i32 %53, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 256
  store i32 %59, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac06, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac06, ptr %64, align 4
  br label %insn_0x00010182_entry

insn_0x00010182_entry:                            ; preds = %insn_0x00010180
  br label %insn_0x00010182

insn_0x00010182:                                  ; preds = %insn_0x00010182_entry
  %diff = sub i32 %add32, 0
  %65 = icmp eq i32 %diff, 0
  %az9 = zext i1 %65 to i32
  %flgn10 = lshr i32 %diff, 31
  %flgs11 = lshr i32 %add32, 31
  %66 = xor i32 %flgn10, %flgs11
  %67 = xor i32 %flgs11, 0
  %overflow12 = and i32 %67, %66
  %an13 = xor i32 %flgn10, %overflow12
  %68 = icmp ule i32 0, %add32
  %ac014 = zext i1 %68 to i32
  %69 = getelementptr i8, ptr %cpu, i32 276
  store i32 %an13, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az9, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an13, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac014, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac014, ptr %73, align 4
  br label %insn_0x00010184_entry

insn_0x00010184_entry:                            ; preds = %insn_0x00010182
  br label %insn_0x00010184

insn_0x00010184:                                  ; preds = %insn_0x00010184_entry
  %cc_false = icmp eq i32 %an13, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010184
  %74 = getelementptr i8, ptr %cpu, i32 188
  store i32 65904, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %75, align 4
  %chain_total28 = add nuw i32 %chain_packets27, 8
  %76 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %76 monotonic, align 4, !range !1
  %77 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %77, label %chain_go25, label %chain_leave26, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010184
  br label %insn_0x00010186_entry

insn_0x00010186_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010186

insn_0x00010186:                                  ; preds = %insn_0x00010186_entry
  %78 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %78, align 4
  %xor32 = xor i32 %rt, %add32
  %79 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %79, align 4
  %80 = icmp eq i32 %xor32, 0
  %az15 = zext i1 %80 to i32
  %an16 = lshr i32 %xor32, 31
  %81 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az15, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an16, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %86, align 4
  br label %insn_0x00010188_entry

insn_0x00010188_entry:                            ; preds = %insn_0x00010186
  br label %insn_0x00010188

insn_0x00010188:                                  ; preds = %insn_0x00010188_entry
  %87 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %88, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65928
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65932
  %89 = getelementptr i8, ptr %cpu, i32 156
  %lc17 = load i32, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 148
  %lt18 = load i32, ptr %90, align 4
  %lc_gt119 = icmp ugt i32 %lc17, 1
  %at_lb20 = icmp eq i32 %lb1, 65928
  %hwloop_cond21 = and i1 %lc_gt119, %at_lb20
  %hwloop_rets22 = select i1 %hwloop_cond21, i32 %lt18, i32 %hwloop_rets
  %91 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets22, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 188
  store i32 65808, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets36 = load i32, ptr %93, align 4
  %chain_total37 = add nuw i32 %chain_packets36, 10
  %94 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget38 = load atomic i32, ptr %94 monotonic, align 4, !range !1
  %95 = icmp ult i32 %chain_total37, %chain_budget38
  br i1 %95, label %chain_go34, label %chain_leave35, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %96 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %96, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527504
  %97 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %97, align 4
  %98 = icmp eq i32 %slot_pc, 65938
  br i1 %98, label %chain_hit, label %chain_leave24, !prof !0

chain_leave24:                                    ; preds = %chain_go, %brt_taken
  %99 = getelementptr i8, ptr %cpu, i64 188
  store i32 65938, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %102, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %103 = getelementptr i8, ptr %cpu, i64 188
  store i32 65938, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %104, align 4
  %105 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %105, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go25:                                       ; preds = %brcc_taken
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 527232
  %106 = getelementptr i8, ptr %chain_slot30, i64 0
  %slot_pc31 = load i32, ptr %106, align 4
  %107 = icmp eq i32 %slot_pc31, 65904
  br i1 %107, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_go25, %brcc_taken
  %108 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %111, align 1
  ret void

chain_hit32:                                      ; preds = %chain_go25
  %112 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %113, align 4
  %114 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %114, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go34:                                       ; preds = %insn_0x00010188
  %chain_slot39 = getelementptr i8, ptr %chain_table, i64 526464
  %115 = getelementptr i8, ptr %chain_slot39, i64 0
  %slot_pc40 = load i32, ptr %115, align 4
  %116 = icmp eq i32 %slot_pc40, 65808
  br i1 %116, label %chain_hit41, label %chain_leave35, !prof !0

chain_leave35:                                    ; preds = %chain_go34, %insn_0x00010188
  %117 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %120, align 1
  ret void

chain_hit41:                                      ; preds = %chain_go34
  %121 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total37, ptr %122, align 4
  %123 = getelementptr i8, ptr %chain_slot39, i64 8
  %chain_fn42 = load ptr, ptr %123, align 8
  musttail call swifttailcc void %chain_fn42(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
