
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65536-0-128875738693664.bin:     file format binary


Disassembly of section .data:

0000753638a00020 <.data>:
    753638a00020:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    753638a00027:	8d 8a fd ff fe ff    	lea    ecx,[rdx-0x10003]
    753638a0002d:	b8 65 01 00 00       	mov    eax,0x165
    753638a00032:	83 f9 fc             	cmp    ecx,0xfffffffc
    753638a00035:	0f 87 d8 00 00 00    	ja     0x753638a00113
    753638a0003b:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    753638a00042:	8d b1 fd ff fe ff    	lea    esi,[rcx-0x10003]
    753638a00048:	83 fe fc             	cmp    esi,0xfffffffc
    753638a0004b:	0f 87 c2 00 00 00    	ja     0x753638a00113
    753638a00051:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753638a00058:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    753638a0005d:	41 8b bd 9c 00 00 00 	mov    edi,DWORD PTR [r13+0x9c]
    753638a00064:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    753638a0006b:	02 
    753638a0006c:	be 06 00 01 00       	mov    esi,0x10006
    753638a00071:	bb 06 00 01 00       	mov    ebx,0x10006
    753638a00076:	72 07                	jb     0x753638a0007f
    753638a00078:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    753638a0007f:	81 fa 02 00 01 00    	cmp    edx,0x10002
    753638a00085:	0f 44 f3             	cmove  esi,ebx
    753638a00088:	89 f2                	mov    edx,esi
    753638a0008a:	83 ff 02             	cmp    edi,0x2
    753638a0008d:	72 07                	jb     0x753638a00096
    753638a0008f:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    753638a00096:	81 f9 02 00 01 00    	cmp    ecx,0x10002
    753638a0009c:	0f 44 f2             	cmove  esi,edx
    753638a0009f:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    753638a000a6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    753638a000ad:	14 00 01 00 
    753638a000b1:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    753638a000b8:	83 c1 02             	add    ecx,0x2
    753638a000bb:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    753638a000c2:	39 d1                	cmp    ecx,edx
    753638a000c4:	73 27                	jae    0x753638a000ed
    753638a000c6:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    753638a000cd:	00 01 00 
    753638a000d0:	75 1b                	jne    0x753638a000ed
    753638a000d2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    753638a000d9:	14 00 01 00 
    753638a000dd:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753638a000e4:	48 8b 80 a8 00 08 00 	mov    rax,QWORD PTR [rax+0x800a8]
    753638a000eb:	ff e0                	jmp    rax
    753638a000ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    753638a000f4:	14 00 01 00 
    753638a000f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753638a000ff:	04 00 00 00 
    753638a00103:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    753638a0010a:	02 00 00 00 
    753638a0010e:	b8 28 01 00 00       	mov    eax,0x128
    753638a00113:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    753638a00119:	c2 08 00             	ret    0x8
