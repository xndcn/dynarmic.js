
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-66724-0-128875738699456.bin:     file format binary


Disassembly of section .data:

0000753638a016c0 <.data>:
    753638a016c0:	50                   	push   rax
    753638a016c1:	b8 43 fb fe ff       	mov    eax,0xfffefb43
    753638a016c6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    753638a016cd:	01 c1                	add    ecx,eax
    753638a016cf:	83 f9 e6             	cmp    ecx,0xffffffe6
    753638a016d2:	0f 87 2f 0f 00 18    	ja     0x753650a02607
    753638a016d8:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    753638a016df:	83 f8 e6             	cmp    eax,0xffffffe6
    753638a016e2:	0f 87 1f 0f 00 18    	ja     0x753650a02607
    753638a016e8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    753638a016ef:	4d 8b bd 50 01 00 00 	mov    r15,QWORD PTR [r13+0x150]
    753638a016f6:	41 c7 45 28 f4 12 01 	mov    DWORD PTR [r13+0x28],0x112f4
    753638a016fd:	00 
    753638a016fe:	48 8b 85 88 00 00 00 	mov    rax,QWORD PTR [rbp+0x88]
    753638a01705:	48 85 c0             	test   rax,rax
    753638a01708:	0f 84 05 0f 00 18    	je     0x753650a02613
    753638a0170e:	8b 80 f4 02 00 00    	mov    eax,DWORD PTR [rax+0x2f4]
    753638a01714:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    753638a01718:	41 c7 45 28 f8 12 01 	mov    DWORD PTR [r13+0x28],0x112f8
    753638a0171f:	00 
    753638a01720:	48 8b 85 88 00 00 00 	mov    rax,QWORD PTR [rbp+0x88]
    753638a01727:	48 85 c0             	test   rax,rax
    753638a0172a:	0f 84 35 0f 00 18    	je     0x753650a02665
    753638a01730:	8b 80 f8 02 00 00    	mov    eax,DWORD PTR [rax+0x2f8]
    753638a01736:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    753638a0173a:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    753638a0173e:	f6 c3 03             	test   bl,0x3
    753638a01741:	0f 85 6d 0f 00 18    	jne    0x753650a026b4
    753638a01747:	48 89 d8             	mov    rax,rbx
    753638a0174a:	48 c1 e8 0c          	shr    rax,0xc
    753638a0174e:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    753638a01753:	48 85 c0             	test   rax,rax
    753638a01756:	0f 84 ec 0f 00 18    	je     0x753650a02748
    753638a0175c:	89 d9                	mov    ecx,ebx
    753638a0175e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a01764:	44 8b 24 08          	mov    r12d,DWORD PTR [rax+rcx*1]
    753638a01768:	8d 73 04             	lea    esi,[rbx+0x4]
    753638a0176b:	89 f0                	mov    eax,esi
    753638a0176d:	c1 e8 0c             	shr    eax,0xc
    753638a01770:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    753638a01775:	48 85 c0             	test   rax,rax
    753638a01778:	0f 84 12 10 00 18    	je     0x753650a02790
    753638a0177e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753638a01784:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753638a01787:	83 c3 08             	add    ebx,0x8
    753638a0178a:	45 89 65 3c          	mov    DWORD PTR [r13+0x3c],r12d
    753638a0178e:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a01795:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    753638a01799:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    753638a017a0:	4c 01 01 00 
    753638a017a4:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    753638a017ab:	83 c0 08             	add    eax,0x8
    753638a017ae:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    753638a017b5:	39 c8                	cmp    eax,ecx
    753638a017b7:	73 29                	jae    0x753638a017e2
    753638a017b9:	41 81 bf 60 0a 08 00 	cmp    DWORD PTR [r15+0x80a60],0x1014c
    753638a017c0:	4c 01 01 00 
    753638a017c4:	75 1c                	jne    0x753638a017e2
    753638a017c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    753638a017cd:	4c 01 01 00 
    753638a017d1:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    753638a017d8:	49 8b 87 68 0a 08 00 	mov    rax,QWORD PTR [r15+0x80a68]
    753638a017df:	59                   	pop    rcx
    753638a017e0:	ff e0                	jmp    rax
    753638a017e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    753638a017e9:	4c 01 01 00 
    753638a017ed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    753638a017f4:	04 00 00 00 
    753638a017f8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    753638a017ff:	08 00 00 00 
    753638a01803:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    753638a0180a:	01 
    753638a0180b:	58                   	pop    rax
    753638a0180c:	c2 08 00             	ret    0x8
