; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010328(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66344
  %6 = icmp ugt i32 %5, 70
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb318 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb318, 0
  %11 = sub i32 %guard_lb318, 66344
  %12 = icmp ugt i32 %11, 70
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010328_entry, label %lb_guard_miss, !prof !0

insn_0x00010328_entry:                            ; preds = %lb_guard
  br label %insn_0x00010328

insn_0x00010328:                                  ; preds = %insn_0x00010328_entry
  %15 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %15, align 4
  %sp_dec = sub i32 %sp, 4
  %16 = getelementptr i8, ptr %cpu, i32 24
  %r = load i32, ptr %16, align 4
  %17 = and i32 %sp_dec, 3
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010328
  %19 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %20, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec, i32 65536)
  %21 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 188
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr i8, ptr %cpu, i64 296
  %25 = load i8, ptr %24, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010328
  %26 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %26 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %27 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %28, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %29 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %30, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %31 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %31, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %32 = getelementptr i8, ptr %cpu, i32 28
  %r2 = load i32, ptr %32, align 4
  %33 = and i32 %sp_dec1, 3
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc319 = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 188
  %37 = load i32, ptr %36, align 4
  %38 = getelementptr i8, ptr %cpu, i64 296
  %39 = load i8, ptr %38, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec1, i32 65536)
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc320 = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 188
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %cpu, i64 296
  %46 = load i8, ptr %45, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %47 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %47 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %48 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %48 to i64
  %49 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %49, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %50 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %51, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %52 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %52, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %sp_dec17 = sub i32 %sp_dec1, 4
  %53 = getelementptr i8, ptr %cpu, i32 44
  %p = load i32, ptr %53, align 4
  %54 = and i32 %sp_dec17, 3
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %data_misaligned18, label %data_aligned19, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %56 = getelementptr i8, ptr %cpu, i64 188
  %next_pc321 = load i32, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 188
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %cpu, i64 296
  %60 = load i8, ptr %59, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

data_misaligned18:                                ; preds = %page_wr_done7
  %61 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %62, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec17, i32 65536)
  %63 = getelementptr i8, ptr %cpu, i64 188
  %next_pc322 = load i32, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 188
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %cpu, i64 296
  %67 = load i8, ptr %66, align 1
  br label %chain_exit

data_aligned19:                                   ; preds = %page_wr_done7
  %68 = lshr i32 %sp_dec17, 12
  %page_index23 = zext i32 %68 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26 = icmp ne ptr %page25, null
  br i1 %page_mapped26, label %page_wr_fast20, label %page_wr_slow21, !prof !0

page_wr_fast20:                                   ; preds = %data_aligned19
  %69 = and i32 %sp_dec17, 4095
  %page_offset27 = zext i32 %69 to i64
  %70 = getelementptr i8, ptr %page25, i64 %page_offset27
  store i32 %p, ptr %70, align 4
  br label %page_wr_done22

page_wr_slow21:                                   ; preds = %data_aligned19
  %71 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %72, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %p)
  %73 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %73, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_wr_done22:                                   ; preds = %did_jump_cont29, %page_wr_fast20
  %sp_dec32 = sub i32 %sp_dec17, 4
  %74 = getelementptr i8, ptr %cpu, i32 48
  %p33 = load i32, ptr %74, align 4
  %75 = and i32 %sp_dec32, 3
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %data_misaligned34, label %data_aligned35, !prof !1

did_jump_exit28:                                  ; preds = %page_wr_slow21
  %77 = getelementptr i8, ptr %cpu, i64 188
  %next_pc323 = load i32, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 188
  %79 = load i32, ptr %78, align 4
  %80 = getelementptr i8, ptr %cpu, i64 296
  %81 = load i8, ptr %80, align 1
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_wr_slow21
  br label %page_wr_done22

data_misaligned34:                                ; preds = %page_wr_done22
  %82 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %83, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec32, i32 65536)
  %84 = getelementptr i8, ptr %cpu, i64 188
  %next_pc324 = load i32, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 188
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %cpu, i64 296
  %88 = load i8, ptr %87, align 1
  br label %chain_exit

data_aligned35:                                   ; preds = %page_wr_done22
  %89 = lshr i32 %sp_dec32, 12
  %page_index39 = zext i32 %89 to i64
  %page_slot40 = getelementptr ptr, ptr %page_table, i64 %page_index39
  %page41 = load ptr, ptr %page_slot40, align 8
  %page_mapped42 = icmp ne ptr %page41, null
  br i1 %page_mapped42, label %page_wr_fast36, label %page_wr_slow37, !prof !0

page_wr_fast36:                                   ; preds = %data_aligned35
  %90 = and i32 %sp_dec32, 4095
  %page_offset43 = zext i32 %90 to i64
  %91 = getelementptr i8, ptr %page41, i64 %page_offset43
  store i32 %p33, ptr %91, align 4
  br label %page_wr_done38

page_wr_slow37:                                   ; preds = %data_aligned35
  %92 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %93, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec32, i32 %p33)
  %94 = getelementptr i8, ptr %cpu, i32 296
  %dj46 = load i8, ptr %94, align 1
  %dj_set47 = icmp ne i8 %dj46, 0
  br i1 %dj_set47, label %did_jump_exit44, label %did_jump_cont45, !prof !1

page_wr_done38:                                   ; preds = %did_jump_cont45, %page_wr_fast36
  %sp_dec48 = sub i32 %sp_dec32, 4
  %95 = getelementptr i8, ptr %cpu, i32 52
  %p49 = load i32, ptr %95, align 4
  %96 = and i32 %sp_dec48, 3
  %97 = icmp ne i32 %96, 0
  br i1 %97, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit44:                                  ; preds = %page_wr_slow37
  %98 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 188
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %cpu, i64 296
  %102 = load i8, ptr %101, align 1
  br label %chain_exit

did_jump_cont45:                                  ; preds = %page_wr_slow37
  br label %page_wr_done38

data_misaligned50:                                ; preds = %page_wr_done38
  %103 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %104, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec48, i32 65536)
  %105 = getelementptr i8, ptr %cpu, i64 188
  %next_pc326 = load i32, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 188
  %107 = load i32, ptr %106, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  %109 = load i8, ptr %108, align 1
  br label %chain_exit

data_aligned51:                                   ; preds = %page_wr_done38
  %110 = lshr i32 %sp_dec48, 12
  %page_index55 = zext i32 %110 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_wr_fast52, label %page_wr_slow53, !prof !0

page_wr_fast52:                                   ; preds = %data_aligned51
  %111 = and i32 %sp_dec48, 4095
  %page_offset59 = zext i32 %111 to i64
  %112 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p49, ptr %112, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %data_aligned51
  %113 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %114, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec48, i32 %p49)
  %115 = getelementptr i8, ptr %cpu, i32 296
  %dj62 = load i8, ptr %115, align 1
  %dj_set63 = icmp ne i8 %dj62, 0
  br i1 %dj_set63, label %did_jump_exit60, label %did_jump_cont61, !prof !1

page_wr_done54:                                   ; preds = %did_jump_cont61, %page_wr_fast52
  %116 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec48, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %118, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %119 = icmp ne i8 %cec_pending, 0
  br i1 %119, label %cec_check, label %cec_checked, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

did_jump_cont61:                                  ; preds = %page_wr_slow53
  br label %page_wr_done54

cec_check:                                        ; preds = %page_wr_done54
  %125 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %127, align 4
  call void @cec_check_pending(ptr %cpu)
  %128 = getelementptr i8, ptr %cpu, i32 296
  %dj66 = load i8, ptr %128, align 1
  %dj_set67 = icmp ne i8 %dj66, 0
  br i1 %dj_set67, label %did_jump_exit64, label %did_jump_cont65, !prof !1

cec_checked:                                      ; preds = %did_jump_cont65, %page_wr_done54
  br label %insn_0x0001032a_entry

did_jump_exit64:                                  ; preds = %cec_check
  %129 = getelementptr i8, ptr %cpu, i64 188
  %next_pc328 = load i32, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i64 188
  %131 = load i32, ptr %130, align 4
  %132 = getelementptr i8, ptr %cpu, i64 296
  %133 = load i8, ptr %132, align 1
  br label %chain_exit

did_jump_cont65:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x0001032a_entry:                            ; preds = %cec_checked
  br label %insn_0x0001032a

insn_0x0001032a:                                  ; preds = %insn_0x0001032a_entry
  %134 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %135, align 4
  %sp1 = sub i32 %sp_dec48, 4
  %136 = and i32 %sp1, 3
  %137 = icmp ne i32 %136, 0
  br i1 %137, label %data_misaligned68, label %data_aligned69, !prof !1

data_misaligned68:                                ; preds = %insn_0x0001032a
  %138 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %140, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66346, i32 %sp1, i32 65536)
  %141 = getelementptr i8, ptr %cpu, i64 188
  %next_pc329 = load i32, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i64 188
  %143 = load i32, ptr %142, align 4
  %144 = getelementptr i8, ptr %cpu, i64 296
  %145 = load i8, ptr %144, align 1
  br label %chain_exit

data_aligned69:                                   ; preds = %insn_0x0001032a
  %146 = lshr i32 %sp1, 12
  %page_index73 = zext i32 %146 to i64
  %page_slot74 = getelementptr ptr, ptr %page_table, i64 %page_index73
  %page75 = load ptr, ptr %page_slot74, align 8
  %page_mapped76 = icmp ne ptr %page75, null
  br i1 %page_mapped76, label %page_wr_fast70, label %page_wr_slow71, !prof !0

page_wr_fast70:                                   ; preds = %data_aligned69
  %147 = and i32 %sp1, 4095
  %page_offset77 = zext i32 %147 to i64
  %148 = getelementptr i8, ptr %page75, i64 %page_offset77
  store i32 %rets, ptr %148, align 4
  br label %page_wr_done72

page_wr_slow71:                                   ; preds = %data_aligned69
  %149 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %151, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %152 = getelementptr i8, ptr %cpu, i32 296
  %dj80 = load i8, ptr %152, align 1
  %dj_set81 = icmp ne i8 %dj80, 0
  br i1 %dj_set81, label %did_jump_exit78, label %did_jump_cont79, !prof !1

page_wr_done72:                                   ; preds = %did_jump_cont79, %page_wr_fast70
  %sp2 = sub i32 %sp1, 4
  %153 = and i32 %sp2, 3
  %154 = icmp ne i32 %153, 0
  br i1 %154, label %data_misaligned82, label %data_aligned83, !prof !1

did_jump_exit78:                                  ; preds = %page_wr_slow71
  %155 = getelementptr i8, ptr %cpu, i64 188
  %next_pc330 = load i32, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i64 188
  %157 = load i32, ptr %156, align 4
  %158 = getelementptr i8, ptr %cpu, i64 296
  %159 = load i8, ptr %158, align 1
  br label %chain_exit

did_jump_cont79:                                  ; preds = %page_wr_slow71
  br label %page_wr_done72

data_misaligned82:                                ; preds = %page_wr_done72
  %160 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %162, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66346, i32 %sp2, i32 65536)
  %163 = getelementptr i8, ptr %cpu, i64 188
  %next_pc331 = load i32, ptr %163, align 4
  %164 = getelementptr i8, ptr %cpu, i64 188
  %165 = load i32, ptr %164, align 4
  %166 = getelementptr i8, ptr %cpu, i64 296
  %167 = load i8, ptr %166, align 1
  br label %chain_exit

data_aligned83:                                   ; preds = %page_wr_done72
  %168 = lshr i32 %sp2, 12
  %page_index87 = zext i32 %168 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90 = icmp ne ptr %page89, null
  br i1 %page_mapped90, label %page_wr_fast84, label %page_wr_slow85, !prof !0

page_wr_fast84:                                   ; preds = %data_aligned83
  %169 = and i32 %sp2, 4095
  %page_offset91 = zext i32 %169 to i64
  %170 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %fp, ptr %170, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %data_aligned83
  %171 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %173, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %174 = getelementptr i8, ptr %cpu, i32 296
  %dj94 = load i8, ptr %174, align 1
  %dj_set95 = icmp ne i8 %dj94, 0
  br i1 %dj_set95, label %did_jump_exit92, label %did_jump_cont93, !prof !1

page_wr_done86:                                   ; preds = %did_jump_cont93, %page_wr_fast84
  %175 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %175, align 4
  %sp3 = sub i32 %sp2, 0
  %176 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %176, align 4
  %cec_pending96 = load i8, ptr %cec_pending_flag, align 1
  %177 = icmp ne i8 %cec_pending96, 0
  br i1 %177, label %cec_check97, label %cec_checked98, !prof !1

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %178 = getelementptr i8, ptr %cpu, i64 188
  %next_pc332 = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 188
  %180 = load i32, ptr %179, align 4
  %181 = getelementptr i8, ptr %cpu, i64 296
  %182 = load i8, ptr %181, align 1
  br label %chain_exit

did_jump_cont93:                                  ; preds = %page_wr_slow85
  br label %page_wr_done86

cec_check97:                                      ; preds = %page_wr_done86
  %183 = getelementptr i8, ptr %cpu, i32 188
  store i32 66350, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %185, align 4
  call void @cec_check_pending(ptr %cpu)
  %186 = getelementptr i8, ptr %cpu, i32 296
  %dj101 = load i8, ptr %186, align 1
  %dj_set102 = icmp ne i8 %dj101, 0
  br i1 %dj_set102, label %did_jump_exit99, label %did_jump_cont100, !prof !1

cec_checked98:                                    ; preds = %did_jump_cont100, %page_wr_done86
  br label %insn_0x0001032e_entry

did_jump_exit99:                                  ; preds = %cec_check97
  %187 = getelementptr i8, ptr %cpu, i64 188
  %next_pc333 = load i32, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i64 188
  %189 = load i32, ptr %188, align 4
  %190 = getelementptr i8, ptr %cpu, i64 296
  %191 = load i8, ptr %190, align 1
  br label %chain_exit

did_jump_cont100:                                 ; preds = %cec_check97
  br label %cec_checked98

insn_0x0001032e_entry:                            ; preds = %cec_checked98
  br label %insn_0x0001032e

insn_0x0001032e:                                  ; preds = %insn_0x0001032e_entry
  %192 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %192, align 4
  %193 = icmp ule i32 %rx, 4
  %cc = zext i1 %193 to i32
  %194 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %194, align 4
  %195 = icmp eq i32 %rx, 4
  %az = zext i1 %195 to i32
  %196 = icmp ugt i32 4, %rx
  %an = zext i1 %196 to i32
  %197 = icmp ule i32 4, %rx
  %ac0 = zext i1 %197 to i32
  %198 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %201, align 4
  br label %insn_0x00010330_entry

insn_0x00010330_entry:                            ; preds = %insn_0x0001032e
  br label %insn_0x00010330

insn_0x00010330:                                  ; preds = %insn_0x00010330_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010330
  %202 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %203, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %204 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %204 monotonic, align 4, !range !2
  %205 = icmp ult i32 %chain_total, %chain_budget
  br i1 %205, label %chain_go, label %chain_leave334, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010330
  br label %insn_0x00010332_entry

insn_0x00010332_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010332

insn_0x00010332:                                  ; preds = %insn_0x00010332_entry
  %206 = getelementptr i8, ptr %cpu, i32 4
  %rx103 = load i32, ptr %206, align 4
  %diff = sub i32 %rx103, 0
  %207 = icmp eq i32 %diff, 0
  %az104 = zext i1 %207 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx103, 31
  %208 = xor i32 %flgn, %flgs
  %209 = xor i32 %flgs, 0
  %overflow = and i32 %209, %208
  %an105 = xor i32 %flgn, %overflow
  %210 = icmp ule i32 0, %rx103
  %ac0106 = zext i1 %210 to i32
  %211 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az104, ptr %211, align 4
  %212 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az104, ptr %212, align 4
  %213 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an105, ptr %213, align 4
  %214 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0106, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0106, ptr %215, align 4
  br label %insn_0x00010334_entry

insn_0x00010334_entry:                            ; preds = %insn_0x00010332
  br label %insn_0x00010334

insn_0x00010334:                                  ; preds = %insn_0x00010334_entry
  %cc_true = icmp ne i32 %az104, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x00010334
  %216 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %216, align 4
  %217 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets337 = load i32, ptr %217, align 4
  %chain_total338 = add nuw i32 %chain_packets337, 6
  %218 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget339 = load atomic i32, ptr %218 monotonic, align 4, !range !2
  %219 = icmp ult i32 %chain_total338, %chain_budget339
  br i1 %219, label %chain_go335, label %chain_leave336, !prof !0

brt_fallthru:                                     ; preds = %insn_0x00010334
  br label %insn_0x00010336_entry

insn_0x00010336_entry:                            ; preds = %brt_fallthru
  br label %insn_0x00010336

insn_0x00010336:                                  ; preds = %insn_0x00010336_entry
  %220 = getelementptr i8, ptr %cpu, i32 12
  store i32 15625, ptr %220, align 4
  br label %insn_0x0001033a_entry

insn_0x0001033a_entry:                            ; preds = %insn_0x00010336
  br label %insn_0x0001033a

insn_0x0001033a:                                  ; preds = %insn_0x0001033a_entry
  %221 = getelementptr i8, ptr %cpu, i32 12
  store i32 32000000, ptr %221, align 4
  %222 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %223, align 4
  %224 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %224, align 4
  %225 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %225, align 4
  br label %insn_0x0001033c_entry

insn_0x0001033c_entry:                            ; preds = %insn_0x0001033a
  br label %insn_0x0001033c

insn_0x0001033c:                                  ; preds = %insn_0x0001033c_entry
  %226 = icmp ule i32 %rx103, 32000000
  %cc107 = zext i1 %226 to i32
  %227 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc107, ptr %227, align 4
  %228 = icmp eq i32 %rx103, 32000000
  %az108 = zext i1 %228 to i32
  %229 = icmp ugt i32 32000000, %rx103
  %an109 = zext i1 %229 to i32
  %230 = icmp ule i32 32000000, %rx103
  %ac0110 = zext i1 %230 to i32
  %231 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az108, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an109, ptr %232, align 4
  %233 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0110, ptr %233, align 4
  %234 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0110, ptr %234, align 4
  br label %insn_0x0001033e_entry

insn_0x0001033e_entry:                            ; preds = %insn_0x0001033c
  br label %insn_0x0001033e

insn_0x0001033e:                                  ; preds = %insn_0x0001033e_entry
  %cc_false111 = icmp eq i32 %cc107, 0
  br i1 %cc_false111, label %brcc_taken112, label %brcc_fallthru113

brcc_taken112:                                    ; preds = %insn_0x0001033e
  %235 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %235, align 4
  %236 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets346 = load i32, ptr %236, align 4
  %chain_total347 = add nuw i32 %chain_packets346, 10
  %237 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget348 = load atomic i32, ptr %237 monotonic, align 4, !range !2
  %238 = icmp ult i32 %chain_total347, %chain_budget348
  br i1 %238, label %chain_go344, label %chain_leave345, !prof !0

brcc_fallthru113:                                 ; preds = %insn_0x0001033e
  br label %insn_0x00010340_entry

insn_0x00010340_entry:                            ; preds = %brcc_fallthru113
  br label %insn_0x00010340

insn_0x00010340:                                  ; preds = %insn_0x00010340_entry
  %239 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %239, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %240 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %240, align 4
  br label %insn_0x00010344_entry

insn_0x00010344_entry:                            ; preds = %insn_0x00010340
  br label %insn_0x00010344

insn_0x00010344:                                  ; preds = %insn_0x00010344_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4848
  %241 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %241, align 4
  br label %insn_0x00010348_entry

insn_0x00010348_entry:                            ; preds = %insn_0x00010344
  br label %insn_0x00010348

insn_0x00010348:                                  ; preds = %insn_0x00010348_entry
  %242 = and i32 %with_lo, 3
  %243 = icmp ne i32 %242, 0
  br i1 %243, label %data_misaligned114, label %data_aligned115, !prof !1

data_misaligned114:                               ; preds = %insn_0x00010348
  %244 = getelementptr i8, ptr %cpu, i32 188
  store i32 66376, ptr %244, align 4
  %245 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %245, align 4
  %246 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %246, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66376, i32 %with_lo, i32 65536)
  %247 = getelementptr i8, ptr %cpu, i64 188
  %next_pc353 = load i32, ptr %247, align 4
  %248 = getelementptr i8, ptr %cpu, i64 188
  %249 = load i32, ptr %248, align 4
  %250 = getelementptr i8, ptr %cpu, i64 296
  %251 = load i8, ptr %250, align 1
  br label %chain_exit

data_aligned115:                                  ; preds = %insn_0x00010348
  %252 = lshr i32 %with_lo, 12
  %page_index119 = zext i32 %252 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122 = icmp ne ptr %page121, null
  br i1 %page_mapped122, label %page_wr_fast116, label %page_wr_slow117, !prof !0

page_wr_fast116:                                  ; preds = %data_aligned115
  %253 = and i32 %with_lo, 4095
  %page_offset123 = zext i32 %253 to i64
  %254 = getelementptr i8, ptr %page121, i64 %page_offset123
  store i32 %rx, ptr %254, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %data_aligned115
  %255 = getelementptr i8, ptr %cpu, i32 188
  store i32 66376, ptr %255, align 4
  %256 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %256, align 4
  %257 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %257, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo, i32 %rx)
  %258 = getelementptr i8, ptr %cpu, i32 296
  %dj126 = load i8, ptr %258, align 1
  %dj_set127 = icmp ne i8 %dj126, 0
  br i1 %dj_set127, label %did_jump_exit124, label %did_jump_cont125, !prof !1

page_wr_done118:                                  ; preds = %did_jump_cont125, %page_wr_fast116
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %259 = icmp ne i8 %cec_pending128, 0
  br i1 %259, label %cec_check129, label %cec_checked130, !prof !1

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %260 = getelementptr i8, ptr %cpu, i64 188
  %next_pc354 = load i32, ptr %260, align 4
  %261 = getelementptr i8, ptr %cpu, i64 188
  %262 = load i32, ptr %261, align 4
  %263 = getelementptr i8, ptr %cpu, i64 296
  %264 = load i8, ptr %263, align 1
  br label %chain_exit

did_jump_cont125:                                 ; preds = %page_wr_slow117
  br label %page_wr_done118

cec_check129:                                     ; preds = %page_wr_done118
  %265 = getelementptr i8, ptr %cpu, i32 188
  store i32 66378, ptr %265, align 4
  %266 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %266, align 4
  %267 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %267, align 4
  call void @cec_check_pending(ptr %cpu)
  %268 = getelementptr i8, ptr %cpu, i32 296
  %dj133 = load i8, ptr %268, align 1
  %dj_set134 = icmp ne i8 %dj133, 0
  br i1 %dj_set134, label %did_jump_exit131, label %did_jump_cont132, !prof !1

cec_checked130:                                   ; preds = %did_jump_cont132, %page_wr_done118
  br label %insn_0x0001034a_entry

did_jump_exit131:                                 ; preds = %cec_check129
  %269 = getelementptr i8, ptr %cpu, i64 188
  %next_pc355 = load i32, ptr %269, align 4
  %270 = getelementptr i8, ptr %cpu, i64 188
  %271 = load i32, ptr %270, align 4
  %272 = getelementptr i8, ptr %cpu, i64 296
  %273 = load i8, ptr %272, align 1
  br label %chain_exit

did_jump_cont132:                                 ; preds = %cec_check129
  br label %cec_checked130

insn_0x0001034a_entry:                            ; preds = %cec_checked130
  br label %insn_0x0001034a

insn_0x0001034a:                                  ; preds = %insn_0x0001034a_entry
  %lo_kept135 = and i32 %with_lo, 65535
  %with_hi136 = or i32 %lo_kept135, 65536
  %274 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi136, ptr %274, align 4
  br label %insn_0x0001034e_entry

insn_0x0001034e_entry:                            ; preds = %insn_0x0001034a
  br label %insn_0x0001034e

insn_0x0001034e:                                  ; preds = %insn_0x0001034e_entry
  %hi_kept137 = and i32 %with_hi136, -65536
  %with_lo138 = or i32 %hi_kept137, 4852
  %275 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo138, ptr %275, align 4
  br label %insn_0x00010352_entry

insn_0x00010352_entry:                            ; preds = %insn_0x0001034e
  br label %insn_0x00010352

insn_0x00010352:                                  ; preds = %insn_0x00010352_entry
  %276 = and i32 %with_lo138, 3
  %277 = icmp ne i32 %276, 0
  br i1 %277, label %data_misaligned139, label %data_aligned140, !prof !1

data_misaligned139:                               ; preds = %insn_0x00010352
  %278 = getelementptr i8, ptr %cpu, i32 188
  store i32 66386, ptr %278, align 4
  %279 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %280, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66386, i32 %with_lo138, i32 65536)
  %281 = getelementptr i8, ptr %cpu, i64 188
  %next_pc356 = load i32, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i64 188
  %283 = load i32, ptr %282, align 4
  %284 = getelementptr i8, ptr %cpu, i64 296
  %285 = load i8, ptr %284, align 1
  br label %chain_exit

data_aligned140:                                  ; preds = %insn_0x00010352
  %286 = lshr i32 %with_lo138, 12
  %page_index144 = zext i32 %286 to i64
  %page_slot145 = getelementptr ptr, ptr %page_table, i64 %page_index144
  %page146 = load ptr, ptr %page_slot145, align 8
  %page_mapped147 = icmp ne ptr %page146, null
  br i1 %page_mapped147, label %page_wr_fast141, label %page_wr_slow142, !prof !0

page_wr_fast141:                                  ; preds = %data_aligned140
  %287 = and i32 %with_lo138, 4095
  %page_offset148 = zext i32 %287 to i64
  %288 = getelementptr i8, ptr %page146, i64 %page_offset148
  store i32 %rx103, ptr %288, align 4
  br label %page_wr_done143

page_wr_slow142:                                  ; preds = %data_aligned140
  %289 = getelementptr i8, ptr %cpu, i32 188
  store i32 66386, ptr %289, align 4
  %290 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %290, align 4
  %291 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %291, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo138, i32 %rx103)
  %292 = getelementptr i8, ptr %cpu, i32 296
  %dj151 = load i8, ptr %292, align 1
  %dj_set152 = icmp ne i8 %dj151, 0
  br i1 %dj_set152, label %did_jump_exit149, label %did_jump_cont150, !prof !1

page_wr_done143:                                  ; preds = %did_jump_cont150, %page_wr_fast141
  %cec_pending153 = load i8, ptr %cec_pending_flag, align 1
  %293 = icmp ne i8 %cec_pending153, 0
  br i1 %293, label %cec_check154, label %cec_checked155, !prof !1

did_jump_exit149:                                 ; preds = %page_wr_slow142
  %294 = getelementptr i8, ptr %cpu, i64 188
  %next_pc357 = load i32, ptr %294, align 4
  %295 = getelementptr i8, ptr %cpu, i64 188
  %296 = load i32, ptr %295, align 4
  %297 = getelementptr i8, ptr %cpu, i64 296
  %298 = load i8, ptr %297, align 1
  br label %chain_exit

did_jump_cont150:                                 ; preds = %page_wr_slow142
  br label %page_wr_done143

cec_check154:                                     ; preds = %page_wr_done143
  %299 = getelementptr i8, ptr %cpu, i32 188
  store i32 66388, ptr %299, align 4
  %300 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %300, align 4
  %301 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %301, align 4
  call void @cec_check_pending(ptr %cpu)
  %302 = getelementptr i8, ptr %cpu, i32 296
  %dj158 = load i8, ptr %302, align 1
  %dj_set159 = icmp ne i8 %dj158, 0
  br i1 %dj_set159, label %did_jump_exit156, label %did_jump_cont157, !prof !1

cec_checked155:                                   ; preds = %did_jump_cont157, %page_wr_done143
  br label %insn_0x00010354_entry

did_jump_exit156:                                 ; preds = %cec_check154
  %303 = getelementptr i8, ptr %cpu, i64 188
  %next_pc358 = load i32, ptr %303, align 4
  %304 = getelementptr i8, ptr %cpu, i64 188
  %305 = load i32, ptr %304, align 4
  %306 = getelementptr i8, ptr %cpu, i64 296
  %307 = load i8, ptr %306, align 1
  br label %chain_exit

did_jump_cont157:                                 ; preds = %cec_check154
  br label %cec_checked155

insn_0x00010354_entry:                            ; preds = %cec_checked155
  br label %insn_0x00010354

insn_0x00010354:                                  ; preds = %insn_0x00010354_entry
  %lo_kept160 = and i32 %with_lo138, 65535
  %with_hi161 = or i32 %lo_kept160, 65536
  %308 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi161, ptr %308, align 4
  br label %insn_0x00010358_entry

insn_0x00010358_entry:                            ; preds = %insn_0x00010354
  br label %insn_0x00010358

insn_0x00010358:                                  ; preds = %insn_0x00010358_entry
  %hi_kept162 = and i32 %with_hi161, -65536
  %with_lo163 = or i32 %hi_kept162, 4856
  %309 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo163, ptr %309, align 4
  br label %insn_0x0001035c_entry

insn_0x0001035c_entry:                            ; preds = %insn_0x00010358
  br label %insn_0x0001035c

insn_0x0001035c:                                  ; preds = %insn_0x0001035c_entry
  %310 = getelementptr i8, ptr %cpu, i32 8
  %val = load i32, ptr %310, align 4
  %311 = and i32 %with_lo163, 3
  %312 = icmp ne i32 %311, 0
  br i1 %312, label %data_misaligned164, label %data_aligned165, !prof !1

data_misaligned164:                               ; preds = %insn_0x0001035c
  %313 = getelementptr i8, ptr %cpu, i32 188
  store i32 66396, ptr %313, align 4
  %314 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %314, align 4
  %315 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %315, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66396, i32 %with_lo163, i32 65536)
  %316 = getelementptr i8, ptr %cpu, i64 188
  %next_pc359 = load i32, ptr %316, align 4
  %317 = getelementptr i8, ptr %cpu, i64 188
  %318 = load i32, ptr %317, align 4
  %319 = getelementptr i8, ptr %cpu, i64 296
  %320 = load i8, ptr %319, align 1
  br label %chain_exit

data_aligned165:                                  ; preds = %insn_0x0001035c
  %321 = lshr i32 %with_lo163, 12
  %page_index169 = zext i32 %321 to i64
  %page_slot170 = getelementptr ptr, ptr %page_table, i64 %page_index169
  %page171 = load ptr, ptr %page_slot170, align 8
  %page_mapped172 = icmp ne ptr %page171, null
  br i1 %page_mapped172, label %page_wr_fast166, label %page_wr_slow167, !prof !0

page_wr_fast166:                                  ; preds = %data_aligned165
  %322 = and i32 %with_lo163, 4095
  %page_offset173 = zext i32 %322 to i64
  %323 = getelementptr i8, ptr %page171, i64 %page_offset173
  store i32 %val, ptr %323, align 4
  br label %page_wr_done168

page_wr_slow167:                                  ; preds = %data_aligned165
  %324 = getelementptr i8, ptr %cpu, i32 188
  store i32 66396, ptr %324, align 4
  %325 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %325, align 4
  %326 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %326, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo163, i32 %val)
  %327 = getelementptr i8, ptr %cpu, i32 296
  %dj176 = load i8, ptr %327, align 1
  %dj_set177 = icmp ne i8 %dj176, 0
  br i1 %dj_set177, label %did_jump_exit174, label %did_jump_cont175, !prof !1

page_wr_done168:                                  ; preds = %did_jump_cont175, %page_wr_fast166
  %cec_pending178 = load i8, ptr %cec_pending_flag, align 1
  %328 = icmp ne i8 %cec_pending178, 0
  br i1 %328, label %cec_check179, label %cec_checked180, !prof !1

did_jump_exit174:                                 ; preds = %page_wr_slow167
  %329 = getelementptr i8, ptr %cpu, i64 188
  %next_pc360 = load i32, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i64 188
  %331 = load i32, ptr %330, align 4
  %332 = getelementptr i8, ptr %cpu, i64 296
  %333 = load i8, ptr %332, align 1
  br label %chain_exit

did_jump_cont175:                                 ; preds = %page_wr_slow167
  br label %page_wr_done168

cec_check179:                                     ; preds = %page_wr_done168
  %334 = getelementptr i8, ptr %cpu, i32 188
  store i32 66398, ptr %334, align 4
  %335 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %335, align 4
  %336 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %336, align 4
  call void @cec_check_pending(ptr %cpu)
  %337 = getelementptr i8, ptr %cpu, i32 296
  %dj183 = load i8, ptr %337, align 1
  %dj_set184 = icmp ne i8 %dj183, 0
  br i1 %dj_set184, label %did_jump_exit181, label %did_jump_cont182, !prof !1

cec_checked180:                                   ; preds = %did_jump_cont182, %page_wr_done168
  br label %insn_0x0001035e_entry

did_jump_exit181:                                 ; preds = %cec_check179
  %338 = getelementptr i8, ptr %cpu, i64 188
  %next_pc361 = load i32, ptr %338, align 4
  %339 = getelementptr i8, ptr %cpu, i64 188
  %340 = load i32, ptr %339, align 4
  %341 = getelementptr i8, ptr %cpu, i64 296
  %342 = load i8, ptr %341, align 1
  br label %chain_exit

did_jump_cont182:                                 ; preds = %cec_check179
  br label %cec_checked180

insn_0x0001035e_entry:                            ; preds = %cec_checked180
  br label %insn_0x0001035e

insn_0x0001035e:                                  ; preds = %insn_0x0001035e_entry
  %diff185 = sub i32 %rx, 2
  %343 = icmp eq i32 %diff185, 0
  %az186 = zext i1 %343 to i32
  %flgn187 = lshr i32 %diff185, 31
  %flgs188 = lshr i32 %rx, 31
  %344 = xor i32 %flgn187, %flgs188
  %345 = xor i32 %flgs188, 0
  %overflow189 = and i32 %345, %344
  %an190 = xor i32 %flgn187, %overflow189
  %346 = icmp ule i32 2, %rx
  %ac0191 = zext i1 %346 to i32
  %347 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az186, ptr %347, align 4
  %348 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az186, ptr %348, align 4
  %349 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an190, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0191, ptr %350, align 4
  %351 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0191, ptr %351, align 4
  br label %insn_0x00010360_entry

insn_0x00010360_entry:                            ; preds = %insn_0x0001035e
  br label %insn_0x00010360

insn_0x00010360:                                  ; preds = %insn_0x00010360_entry
  %cc_true192 = icmp ne i32 %az186, 0
  br i1 %cc_true192, label %brt_taken193, label %brt_fallthru194

brt_taken193:                                     ; preds = %insn_0x00010360
  %352 = getelementptr i8, ptr %cpu, i32 188
  store i32 66426, ptr %352, align 4
  %353 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets364 = load i32, ptr %353, align 4
  %chain_total365 = add nuw i32 %chain_packets364, 21
  %354 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget366 = load atomic i32, ptr %354 monotonic, align 4, !range !2
  %355 = icmp ult i32 %chain_total365, %chain_budget366
  br i1 %355, label %chain_go362, label %chain_leave363, !prof !0

brt_fallthru194:                                  ; preds = %insn_0x00010360
  br label %insn_0x00010362_entry

insn_0x00010362_entry:                            ; preds = %brt_fallthru194
  br label %insn_0x00010362

insn_0x00010362:                                  ; preds = %insn_0x00010362_entry
  %diff195 = sub i32 %rx, 3
  %356 = icmp eq i32 %diff195, 0
  %az196 = zext i1 %356 to i32
  %flgn197 = lshr i32 %diff195, 31
  %flgs198 = lshr i32 %rx, 31
  %357 = xor i32 %flgn197, %flgs198
  %358 = xor i32 %flgs198, 0
  %overflow199 = and i32 %358, %357
  %an200 = xor i32 %flgn197, %overflow199
  %359 = icmp ule i32 3, %rx
  %ac0201 = zext i1 %359 to i32
  %360 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az196, ptr %360, align 4
  %361 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az196, ptr %361, align 4
  %362 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an200, ptr %362, align 4
  %363 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0201, ptr %363, align 4
  %364 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0201, ptr %364, align 4
  br label %insn_0x00010364_entry

insn_0x00010364_entry:                            ; preds = %insn_0x00010362
  br label %insn_0x00010364

insn_0x00010364:                                  ; preds = %insn_0x00010364_entry
  %cc_true202 = icmp ne i32 %az196, 0
  br i1 %cc_true202, label %brt_taken203, label %brt_fallthru204

brt_taken203:                                     ; preds = %insn_0x00010364
  %365 = getelementptr i8, ptr %cpu, i32 188
  store i32 66468, ptr %365, align 4
  %366 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets373 = load i32, ptr %366, align 4
  %chain_total374 = add nuw i32 %chain_packets373, 23
  %367 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget375 = load atomic i32, ptr %367 monotonic, align 4, !range !2
  %368 = icmp ult i32 %chain_total374, %chain_budget375
  br i1 %368, label %chain_go371, label %chain_leave372, !prof !0

brt_fallthru204:                                  ; preds = %insn_0x00010364
  br label %insn_0x00010366_entry

insn_0x00010366_entry:                            ; preds = %brt_fallthru204
  br label %insn_0x00010366

insn_0x00010366:                                  ; preds = %insn_0x00010366_entry
  %369 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %369, align 4
  br label %insn_0x00010368_entry

insn_0x00010368_entry:                            ; preds = %insn_0x00010366
  br label %insn_0x00010368

insn_0x00010368:                                  ; preds = %insn_0x00010368_entry
  %370 = and i32 %sp2, 3
  %371 = icmp ne i32 %370, 0
  br i1 %371, label %data_misaligned205, label %data_aligned206, !prof !1

data_misaligned205:                               ; preds = %insn_0x00010368
  %372 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %372, align 4
  %373 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %373, align 4
  %374 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %374, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %sp2, i32 0)
  %375 = getelementptr i8, ptr %cpu, i64 188
  %next_pc380 = load i32, ptr %375, align 4
  %376 = getelementptr i8, ptr %cpu, i64 188
  %377 = load i32, ptr %376, align 4
  %378 = getelementptr i8, ptr %cpu, i64 296
  %379 = load i8, ptr %378, align 1
  br label %chain_exit

data_aligned206:                                  ; preds = %insn_0x00010368
  %380 = lshr i32 %sp2, 12
  %page_index207 = zext i32 %380 to i64
  %page_slot208 = getelementptr ptr, ptr %page_table, i64 %page_index207
  %page209 = load ptr, ptr %page_slot208, align 8
  %page_mapped210 = icmp ne ptr %page209, null
  br i1 %page_mapped210, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned206
  %381 = and i32 %sp2, 4095
  %page_offset211 = zext i32 %381 to i64
  %382 = getelementptr i8, ptr %page209, i64 %page_offset211
  %page_val = load i32, ptr %382, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned206
  %383 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %383, align 4
  %384 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %384, align 4
  %385 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %385, align 4
  %386 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %387 = getelementptr i8, ptr %cpu, i32 296
  %dj214 = load i8, ptr %387, align 1
  %dj_set215 = icmp ne i8 %dj214, 0
  br i1 %dj_set215, label %did_jump_exit212, label %did_jump_cont213, !prof !1

page_done:                                        ; preds = %did_jump_cont213, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %386, %did_jump_cont213 ]
  %sp1216 = add i32 %sp2, 4
  %388 = and i32 %sp1216, 3
  %389 = icmp ne i32 %388, 0
  br i1 %389, label %data_misaligned217, label %data_aligned218, !prof !1

did_jump_exit212:                                 ; preds = %page_slow
  %390 = getelementptr i8, ptr %cpu, i64 188
  %next_pc381 = load i32, ptr %390, align 4
  %391 = getelementptr i8, ptr %cpu, i64 188
  %392 = load i32, ptr %391, align 4
  %393 = getelementptr i8, ptr %cpu, i64 296
  %394 = load i8, ptr %393, align 1
  br label %chain_exit

did_jump_cont213:                                 ; preds = %page_slow
  br label %page_done

data_misaligned217:                               ; preds = %page_done
  %395 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %395, align 4
  %396 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %396, align 4
  %397 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %397, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %sp1216, i32 0)
  %398 = getelementptr i8, ptr %cpu, i64 188
  %next_pc382 = load i32, ptr %398, align 4
  %399 = getelementptr i8, ptr %cpu, i64 188
  %400 = load i32, ptr %399, align 4
  %401 = getelementptr i8, ptr %cpu, i64 296
  %402 = load i8, ptr %401, align 1
  br label %chain_exit

data_aligned218:                                  ; preds = %page_done
  %403 = lshr i32 %sp1216, 12
  %page_index222 = zext i32 %403 to i64
  %page_slot223 = getelementptr ptr, ptr %page_table, i64 %page_index222
  %page224 = load ptr, ptr %page_slot223, align 8
  %page_mapped225 = icmp ne ptr %page224, null
  br i1 %page_mapped225, label %page_fast219, label %page_slow220, !prof !0

page_fast219:                                     ; preds = %data_aligned218
  %404 = and i32 %sp1216, 4095
  %page_offset226 = zext i32 %404 to i64
  %405 = getelementptr i8, ptr %page224, i64 %page_offset226
  %page_val227 = load i32, ptr %405, align 4
  br label %page_done221

page_slow220:                                     ; preds = %data_aligned218
  %406 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %406, align 4
  %407 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %407, align 4
  %408 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %408, align 4
  %409 = call i32 @mem_read32(ptr %mem, i32 %sp1216)
  %410 = getelementptr i8, ptr %cpu, i32 296
  %dj230 = load i8, ptr %410, align 1
  %dj_set231 = icmp ne i8 %dj230, 0
  br i1 %dj_set231, label %did_jump_exit228, label %did_jump_cont229, !prof !1

page_done221:                                     ; preds = %did_jump_cont229, %page_fast219
  %mem_val232 = phi i32 [ %page_val227, %page_fast219 ], [ %409, %did_jump_cont229 ]
  %sp2233 = add i32 %sp1216, 4
  %411 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %411, align 4
  %412 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val232, ptr %412, align 4
  %413 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2233, ptr %413, align 4
  br label %insn_0x0001036c_entry

did_jump_exit228:                                 ; preds = %page_slow220
  %414 = getelementptr i8, ptr %cpu, i64 188
  %next_pc383 = load i32, ptr %414, align 4
  %415 = getelementptr i8, ptr %cpu, i64 188
  %416 = load i32, ptr %415, align 4
  %417 = getelementptr i8, ptr %cpu, i64 296
  %418 = load i8, ptr %417, align 1
  br label %chain_exit

did_jump_cont229:                                 ; preds = %page_slow220
  br label %page_done221

insn_0x0001036c_entry:                            ; preds = %page_done221
  br label %insn_0x0001036c

insn_0x0001036c:                                  ; preds = %insn_0x0001036c_entry
  %419 = and i32 %sp2233, 3
  %420 = icmp ne i32 %419, 0
  br i1 %420, label %data_misaligned234, label %data_aligned235, !prof !1

data_misaligned234:                               ; preds = %insn_0x0001036c
  %421 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %421, align 4
  %422 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %422, align 4
  %423 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %423, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp2233, i32 0)
  %424 = getelementptr i8, ptr %cpu, i64 188
  %next_pc384 = load i32, ptr %424, align 4
  %425 = getelementptr i8, ptr %cpu, i64 188
  %426 = load i32, ptr %425, align 4
  %427 = getelementptr i8, ptr %cpu, i64 296
  %428 = load i8, ptr %427, align 1
  br label %chain_exit

data_aligned235:                                  ; preds = %insn_0x0001036c
  %429 = lshr i32 %sp2233, 12
  %page_index239 = zext i32 %429 to i64
  %page_slot240 = getelementptr ptr, ptr %page_table, i64 %page_index239
  %page241 = load ptr, ptr %page_slot240, align 8
  %page_mapped242 = icmp ne ptr %page241, null
  br i1 %page_mapped242, label %page_fast236, label %page_slow237, !prof !0

page_fast236:                                     ; preds = %data_aligned235
  %430 = and i32 %sp2233, 4095
  %page_offset243 = zext i32 %430 to i64
  %431 = getelementptr i8, ptr %page241, i64 %page_offset243
  %page_val244 = load i32, ptr %431, align 4
  br label %page_done238

page_slow237:                                     ; preds = %data_aligned235
  %432 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %432, align 4
  %433 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %433, align 4
  %434 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %434, align 4
  %435 = call i32 @mem_read32(ptr %mem, i32 %sp2233)
  %436 = getelementptr i8, ptr %cpu, i32 296
  %dj247 = load i8, ptr %436, align 1
  %dj_set248 = icmp ne i8 %dj247, 0
  br i1 %dj_set248, label %did_jump_exit245, label %did_jump_cont246, !prof !1

page_done238:                                     ; preds = %did_jump_cont246, %page_fast236
  %mem_val249 = phi i32 [ %page_val244, %page_fast236 ], [ %435, %did_jump_cont246 ]
  %437 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val249, ptr %437, align 4
  %sp_inc = add i32 %sp2233, 4
  %438 = and i32 %sp_inc, 3
  %439 = icmp ne i32 %438, 0
  br i1 %439, label %data_misaligned250, label %data_aligned251, !prof !1

did_jump_exit245:                                 ; preds = %page_slow237
  %440 = getelementptr i8, ptr %cpu, i64 188
  %next_pc385 = load i32, ptr %440, align 4
  %441 = getelementptr i8, ptr %cpu, i64 188
  %442 = load i32, ptr %441, align 4
  %443 = getelementptr i8, ptr %cpu, i64 296
  %444 = load i8, ptr %443, align 1
  br label %chain_exit

did_jump_cont246:                                 ; preds = %page_slow237
  br label %page_done238

data_misaligned250:                               ; preds = %page_done238
  %445 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %445, align 4
  %446 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %446, align 4
  %447 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %447, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc, i32 0)
  %448 = getelementptr i8, ptr %cpu, i64 188
  %next_pc386 = load i32, ptr %448, align 4
  %449 = getelementptr i8, ptr %cpu, i64 188
  %450 = load i32, ptr %449, align 4
  %451 = getelementptr i8, ptr %cpu, i64 296
  %452 = load i8, ptr %451, align 1
  br label %chain_exit

data_aligned251:                                  ; preds = %page_done238
  %453 = lshr i32 %sp_inc, 12
  %page_index255 = zext i32 %453 to i64
  %page_slot256 = getelementptr ptr, ptr %page_table, i64 %page_index255
  %page257 = load ptr, ptr %page_slot256, align 8
  %page_mapped258 = icmp ne ptr %page257, null
  br i1 %page_mapped258, label %page_fast252, label %page_slow253, !prof !0

page_fast252:                                     ; preds = %data_aligned251
  %454 = and i32 %sp_inc, 4095
  %page_offset259 = zext i32 %454 to i64
  %455 = getelementptr i8, ptr %page257, i64 %page_offset259
  %page_val260 = load i32, ptr %455, align 4
  br label %page_done254

page_slow253:                                     ; preds = %data_aligned251
  %456 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %456, align 4
  %457 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %457, align 4
  %458 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %458, align 4
  %459 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %460 = getelementptr i8, ptr %cpu, i32 296
  %dj263 = load i8, ptr %460, align 1
  %dj_set264 = icmp ne i8 %dj263, 0
  br i1 %dj_set264, label %did_jump_exit261, label %did_jump_cont262, !prof !1

page_done254:                                     ; preds = %did_jump_cont262, %page_fast252
  %mem_val265 = phi i32 [ %page_val260, %page_fast252 ], [ %459, %did_jump_cont262 ]
  %461 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val265, ptr %461, align 4
  %sp_inc266 = add i32 %sp_inc, 4
  %462 = and i32 %sp_inc266, 3
  %463 = icmp ne i32 %462, 0
  br i1 %463, label %data_misaligned267, label %data_aligned268, !prof !1

did_jump_exit261:                                 ; preds = %page_slow253
  %464 = getelementptr i8, ptr %cpu, i64 188
  %next_pc387 = load i32, ptr %464, align 4
  %465 = getelementptr i8, ptr %cpu, i64 188
  %466 = load i32, ptr %465, align 4
  %467 = getelementptr i8, ptr %cpu, i64 296
  %468 = load i8, ptr %467, align 1
  br label %chain_exit

did_jump_cont262:                                 ; preds = %page_slow253
  br label %page_done254

data_misaligned267:                               ; preds = %page_done254
  %469 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %469, align 4
  %470 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %470, align 4
  %471 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %471, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc266, i32 0)
  %472 = getelementptr i8, ptr %cpu, i64 188
  %next_pc388 = load i32, ptr %472, align 4
  %473 = getelementptr i8, ptr %cpu, i64 188
  %474 = load i32, ptr %473, align 4
  %475 = getelementptr i8, ptr %cpu, i64 296
  %476 = load i8, ptr %475, align 1
  br label %chain_exit

data_aligned268:                                  ; preds = %page_done254
  %477 = lshr i32 %sp_inc266, 12
  %page_index272 = zext i32 %477 to i64
  %page_slot273 = getelementptr ptr, ptr %page_table, i64 %page_index272
  %page274 = load ptr, ptr %page_slot273, align 8
  %page_mapped275 = icmp ne ptr %page274, null
  br i1 %page_mapped275, label %page_fast269, label %page_slow270, !prof !0

page_fast269:                                     ; preds = %data_aligned268
  %478 = and i32 %sp_inc266, 4095
  %page_offset276 = zext i32 %478 to i64
  %479 = getelementptr i8, ptr %page274, i64 %page_offset276
  %page_val277 = load i32, ptr %479, align 4
  br label %page_done271

page_slow270:                                     ; preds = %data_aligned268
  %480 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %480, align 4
  %481 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %481, align 4
  %482 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %482, align 4
  %483 = call i32 @mem_read32(ptr %mem, i32 %sp_inc266)
  %484 = getelementptr i8, ptr %cpu, i32 296
  %dj280 = load i8, ptr %484, align 1
  %dj_set281 = icmp ne i8 %dj280, 0
  br i1 %dj_set281, label %did_jump_exit278, label %did_jump_cont279, !prof !1

page_done271:                                     ; preds = %did_jump_cont279, %page_fast269
  %mem_val282 = phi i32 [ %page_val277, %page_fast269 ], [ %483, %did_jump_cont279 ]
  %485 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val282, ptr %485, align 4
  %sp_inc283 = add i32 %sp_inc266, 4
  %486 = and i32 %sp_inc283, 3
  %487 = icmp ne i32 %486, 0
  br i1 %487, label %data_misaligned284, label %data_aligned285, !prof !1

did_jump_exit278:                                 ; preds = %page_slow270
  %488 = getelementptr i8, ptr %cpu, i64 188
  %next_pc389 = load i32, ptr %488, align 4
  %489 = getelementptr i8, ptr %cpu, i64 188
  %490 = load i32, ptr %489, align 4
  %491 = getelementptr i8, ptr %cpu, i64 296
  %492 = load i8, ptr %491, align 1
  br label %chain_exit

did_jump_cont279:                                 ; preds = %page_slow270
  br label %page_done271

data_misaligned284:                               ; preds = %page_done271
  %493 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %493, align 4
  %494 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %494, align 4
  %495 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %495, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc283, i32 0)
  %496 = getelementptr i8, ptr %cpu, i64 188
  %next_pc390 = load i32, ptr %496, align 4
  %497 = getelementptr i8, ptr %cpu, i64 188
  %498 = load i32, ptr %497, align 4
  %499 = getelementptr i8, ptr %cpu, i64 296
  %500 = load i8, ptr %499, align 1
  br label %chain_exit

data_aligned285:                                  ; preds = %page_done271
  %501 = lshr i32 %sp_inc283, 12
  %page_index289 = zext i32 %501 to i64
  %page_slot290 = getelementptr ptr, ptr %page_table, i64 %page_index289
  %page291 = load ptr, ptr %page_slot290, align 8
  %page_mapped292 = icmp ne ptr %page291, null
  br i1 %page_mapped292, label %page_fast286, label %page_slow287, !prof !0

page_fast286:                                     ; preds = %data_aligned285
  %502 = and i32 %sp_inc283, 4095
  %page_offset293 = zext i32 %502 to i64
  %503 = getelementptr i8, ptr %page291, i64 %page_offset293
  %page_val294 = load i32, ptr %503, align 4
  br label %page_done288

page_slow287:                                     ; preds = %data_aligned285
  %504 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %504, align 4
  %505 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %505, align 4
  %506 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %506, align 4
  %507 = call i32 @mem_read32(ptr %mem, i32 %sp_inc283)
  %508 = getelementptr i8, ptr %cpu, i32 296
  %dj297 = load i8, ptr %508, align 1
  %dj_set298 = icmp ne i8 %dj297, 0
  br i1 %dj_set298, label %did_jump_exit295, label %did_jump_cont296, !prof !1

page_done288:                                     ; preds = %did_jump_cont296, %page_fast286
  %mem_val299 = phi i32 [ %page_val294, %page_fast286 ], [ %507, %did_jump_cont296 ]
  %509 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val299, ptr %509, align 4
  %sp_inc300 = add i32 %sp_inc283, 4
  %510 = and i32 %sp_inc300, 3
  %511 = icmp ne i32 %510, 0
  br i1 %511, label %data_misaligned301, label %data_aligned302, !prof !1

did_jump_exit295:                                 ; preds = %page_slow287
  %512 = getelementptr i8, ptr %cpu, i64 188
  %next_pc391 = load i32, ptr %512, align 4
  %513 = getelementptr i8, ptr %cpu, i64 188
  %514 = load i32, ptr %513, align 4
  %515 = getelementptr i8, ptr %cpu, i64 296
  %516 = load i8, ptr %515, align 1
  br label %chain_exit

did_jump_cont296:                                 ; preds = %page_slow287
  br label %page_done288

data_misaligned301:                               ; preds = %page_done288
  %517 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %517, align 4
  %518 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %518, align 4
  %519 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %519, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc300, i32 0)
  %520 = getelementptr i8, ptr %cpu, i64 188
  %next_pc392 = load i32, ptr %520, align 4
  %521 = getelementptr i8, ptr %cpu, i64 188
  %522 = load i32, ptr %521, align 4
  %523 = getelementptr i8, ptr %cpu, i64 296
  %524 = load i8, ptr %523, align 1
  br label %chain_exit

data_aligned302:                                  ; preds = %page_done288
  %525 = lshr i32 %sp_inc300, 12
  %page_index306 = zext i32 %525 to i64
  %page_slot307 = getelementptr ptr, ptr %page_table, i64 %page_index306
  %page308 = load ptr, ptr %page_slot307, align 8
  %page_mapped309 = icmp ne ptr %page308, null
  br i1 %page_mapped309, label %page_fast303, label %page_slow304, !prof !0

page_fast303:                                     ; preds = %data_aligned302
  %526 = and i32 %sp_inc300, 4095
  %page_offset310 = zext i32 %526 to i64
  %527 = getelementptr i8, ptr %page308, i64 %page_offset310
  %page_val311 = load i32, ptr %527, align 4
  br label %page_done305

page_slow304:                                     ; preds = %data_aligned302
  %528 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %528, align 4
  %529 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %529, align 4
  %530 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %530, align 4
  %531 = call i32 @mem_read32(ptr %mem, i32 %sp_inc300)
  %532 = getelementptr i8, ptr %cpu, i32 296
  %dj314 = load i8, ptr %532, align 1
  %dj_set315 = icmp ne i8 %dj314, 0
  br i1 %dj_set315, label %did_jump_exit312, label %did_jump_cont313, !prof !1

page_done305:                                     ; preds = %did_jump_cont313, %page_fast303
  %mem_val316 = phi i32 [ %page_val311, %page_fast303 ], [ %531, %did_jump_cont313 ]
  %533 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val316, ptr %533, align 4
  %sp_inc317 = add i32 %sp_inc300, 4
  %534 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc317, ptr %534, align 4
  br label %insn_0x0001036e_entry

did_jump_exit312:                                 ; preds = %page_slow304
  %535 = getelementptr i8, ptr %cpu, i64 188
  %next_pc393 = load i32, ptr %535, align 4
  %536 = getelementptr i8, ptr %cpu, i64 188
  %537 = load i32, ptr %536, align 4
  %538 = getelementptr i8, ptr %cpu, i64 296
  %539 = load i8, ptr %538, align 1
  br label %chain_exit

did_jump_cont313:                                 ; preds = %page_slow304
  br label %page_done305

insn_0x0001036e_entry:                            ; preds = %page_done305
  br label %insn_0x0001036e

insn_0x0001036e:                                  ; preds = %insn_0x0001036e_entry
  %lsb = and i32 %mem_val232, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001036e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001036e
  %540 = getelementptr i8, ptr %cpu, i32 188
  store i32 66414, ptr %540, align 4
  %541 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %541, align 4
  %542 = getelementptr i8, ptr %cpu, i32 308
  store i32 27, ptr %542, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %543 = getelementptr i8, ptr %cpu, i64 188
  %next_pc394 = load i32, ptr %543, align 4
  %544 = getelementptr i8, ptr %cpu, i64 188
  %545 = load i32, ptr %544, align 4
  %546 = getelementptr i8, ptr %cpu, i64 296
  %547 = load i8, ptr %546, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %548 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %548, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531328
  %549 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %549, align 4
  %550 = icmp eq i32 %slot_pc, 66416
  br i1 %550, label %chain_hit, label %chain_leave334, !prof !0

chain_leave334:                                   ; preds = %chain_go, %brcc_taken
  %551 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %551, align 4
  %552 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %552, align 4
  %553 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %553, align 4
  %554 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %554, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %555 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %555, align 4
  %556 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %556, align 4
  %557 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %557, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go335:                                      ; preds = %brt_taken
  %chain_slot340 = getelementptr i8, ptr %chain_table, i64 531328
  %558 = getelementptr i8, ptr %chain_slot340, i64 0
  %slot_pc341 = load i32, ptr %558, align 4
  %559 = icmp eq i32 %slot_pc341, 66416
  br i1 %559, label %chain_hit342, label %chain_leave336, !prof !0

chain_leave336:                                   ; preds = %chain_go335, %brt_taken
  %560 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %560, align 4
  %561 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %561, align 4
  %562 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %562, align 4
  %563 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %563, align 1
  ret void

chain_hit342:                                     ; preds = %chain_go335
  %564 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %564, align 4
  %565 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total338, ptr %565, align 4
  %566 = getelementptr i8, ptr %chain_slot340, i64 8
  %chain_fn343 = load ptr, ptr %566, align 8
  musttail call swifttailcc void %chain_fn343(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go344:                                      ; preds = %brcc_taken112
  %chain_slot349 = getelementptr i8, ptr %chain_table, i64 531328
  %567 = getelementptr i8, ptr %chain_slot349, i64 0
  %slot_pc350 = load i32, ptr %567, align 4
  %568 = icmp eq i32 %slot_pc350, 66416
  br i1 %568, label %chain_hit351, label %chain_leave345, !prof !0

chain_leave345:                                   ; preds = %chain_go344, %brcc_taken112
  %569 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %569, align 4
  %570 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %570, align 4
  %571 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %571, align 4
  %572 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %572, align 1
  ret void

chain_hit351:                                     ; preds = %chain_go344
  %573 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %573, align 4
  %574 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total347, ptr %574, align 4
  %575 = getelementptr i8, ptr %chain_slot349, i64 8
  %chain_fn352 = load ptr, ptr %575, align 8
  musttail call swifttailcc void %chain_fn352(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go362:                                      ; preds = %brt_taken193
  %chain_slot367 = getelementptr i8, ptr %chain_table, i64 531408
  %576 = getelementptr i8, ptr %chain_slot367, i64 0
  %slot_pc368 = load i32, ptr %576, align 4
  %577 = icmp eq i32 %slot_pc368, 66426
  br i1 %577, label %chain_hit369, label %chain_leave363, !prof !0

chain_leave363:                                   ; preds = %chain_go362, %brt_taken193
  %578 = getelementptr i8, ptr %cpu, i64 188
  store i32 66426, ptr %578, align 4
  %579 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %579, align 4
  %580 = getelementptr i8, ptr %cpu, i64 308
  store i32 21, ptr %580, align 4
  %581 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %581, align 1
  ret void

chain_hit369:                                     ; preds = %chain_go362
  %582 = getelementptr i8, ptr %cpu, i64 188
  store i32 66426, ptr %582, align 4
  %583 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total365, ptr %583, align 4
  %584 = getelementptr i8, ptr %chain_slot367, i64 8
  %chain_fn370 = load ptr, ptr %584, align 8
  musttail call swifttailcc void %chain_fn370(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go371:                                      ; preds = %brt_taken203
  %chain_slot376 = getelementptr i8, ptr %chain_table, i64 531744
  %585 = getelementptr i8, ptr %chain_slot376, i64 0
  %slot_pc377 = load i32, ptr %585, align 4
  %586 = icmp eq i32 %slot_pc377, 66468
  br i1 %586, label %chain_hit378, label %chain_leave372, !prof !0

chain_leave372:                                   ; preds = %chain_go371, %brt_taken203
  %587 = getelementptr i8, ptr %cpu, i64 188
  store i32 66468, ptr %587, align 4
  %588 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %588, align 4
  %589 = getelementptr i8, ptr %cpu, i64 308
  store i32 23, ptr %589, align 4
  %590 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %590, align 1
  ret void

chain_hit378:                                     ; preds = %chain_go371
  %591 = getelementptr i8, ptr %cpu, i64 188
  store i32 66468, ptr %591, align 4
  %592 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total374, ptr %592, align 4
  %593 = getelementptr i8, ptr %chain_slot376, i64 8
  %chain_fn379 = load ptr, ptr %593, align 8
  musttail call swifttailcc void %chain_fn379(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit312, %data_misaligned301, %did_jump_exit295, %data_misaligned284, %did_jump_exit278, %data_misaligned267, %did_jump_exit261, %data_misaligned250, %did_jump_exit245, %data_misaligned234, %did_jump_exit228, %data_misaligned217, %did_jump_exit212, %data_misaligned205, %did_jump_exit181, %did_jump_exit174, %data_misaligned164, %did_jump_exit156, %did_jump_exit149, %data_misaligned139, %did_jump_exit131, %did_jump_exit124, %data_misaligned114, %did_jump_exit99, %did_jump_exit92, %data_misaligned82, %did_jump_exit78, %data_misaligned68, %did_jump_exit64, %did_jump_exit60, %data_misaligned50, %did_jump_exit44, %data_misaligned34, %did_jump_exit28, %data_misaligned18, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc395 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc319, %did_jump_exit ], [ %next_pc320, %data_misaligned3 ], [ %next_pc321, %did_jump_exit13 ], [ %next_pc322, %data_misaligned18 ], [ %next_pc323, %did_jump_exit28 ], [ %next_pc324, %data_misaligned34 ], [ %next_pc325, %did_jump_exit44 ], [ %next_pc326, %data_misaligned50 ], [ %next_pc327, %did_jump_exit60 ], [ %next_pc328, %did_jump_exit64 ], [ %next_pc329, %data_misaligned68 ], [ %next_pc330, %did_jump_exit78 ], [ %next_pc331, %data_misaligned82 ], [ %next_pc332, %did_jump_exit92 ], [ %next_pc333, %did_jump_exit99 ], [ %next_pc353, %data_misaligned114 ], [ %next_pc354, %did_jump_exit124 ], [ %next_pc355, %did_jump_exit131 ], [ %next_pc356, %data_misaligned139 ], [ %next_pc357, %did_jump_exit149 ], [ %next_pc358, %did_jump_exit156 ], [ %next_pc359, %data_misaligned164 ], [ %next_pc360, %did_jump_exit174 ], [ %next_pc361, %did_jump_exit181 ], [ %next_pc380, %data_misaligned205 ], [ %next_pc381, %did_jump_exit212 ], [ %next_pc382, %data_misaligned217 ], [ %next_pc383, %did_jump_exit228 ], [ %next_pc384, %data_misaligned234 ], [ %next_pc385, %did_jump_exit245 ], [ %next_pc386, %data_misaligned250 ], [ %next_pc387, %did_jump_exit261 ], [ %next_pc388, %data_misaligned267 ], [ %next_pc389, %did_jump_exit278 ], [ %next_pc390, %data_misaligned284 ], [ %next_pc391, %did_jump_exit295 ], [ %next_pc392, %data_misaligned301 ], [ %next_pc393, %did_jump_exit312 ], [ %mem_val232, %jump_aligned ], [ %next_pc394, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned18 ], [ 1, %did_jump_exit28 ], [ 1, %data_misaligned34 ], [ 1, %did_jump_exit44 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ], [ 13, %data_misaligned114 ], [ 13, %did_jump_exit124 ], [ 13, %did_jump_exit131 ], [ 16, %data_misaligned139 ], [ 16, %did_jump_exit149 ], [ 16, %did_jump_exit156 ], [ 19, %data_misaligned164 ], [ 19, %did_jump_exit174 ], [ 19, %did_jump_exit181 ], [ 25, %data_misaligned205 ], [ 25, %did_jump_exit212 ], [ 25, %data_misaligned217 ], [ 25, %did_jump_exit228 ], [ 26, %data_misaligned234 ], [ 26, %did_jump_exit245 ], [ 26, %data_misaligned250 ], [ 26, %did_jump_exit261 ], [ 26, %data_misaligned267 ], [ 26, %did_jump_exit278 ], [ 26, %data_misaligned284 ], [ 26, %did_jump_exit295 ], [ 26, %data_misaligned301 ], [ 26, %did_jump_exit312 ], [ 27, %jump_aligned ], [ 27, %jump_misalign ]
  %tail = phi i32 [ %23, %data_misaligned ], [ %37, %did_jump_exit ], [ %44, %data_misaligned3 ], [ %58, %did_jump_exit13 ], [ %65, %data_misaligned18 ], [ %79, %did_jump_exit28 ], [ %86, %data_misaligned34 ], [ %100, %did_jump_exit44 ], [ %107, %data_misaligned50 ], [ %122, %did_jump_exit60 ], [ %131, %did_jump_exit64 ], [ %143, %data_misaligned68 ], [ %157, %did_jump_exit78 ], [ %165, %data_misaligned82 ], [ %180, %did_jump_exit92 ], [ %189, %did_jump_exit99 ], [ %249, %data_misaligned114 ], [ %262, %did_jump_exit124 ], [ %271, %did_jump_exit131 ], [ %283, %data_misaligned139 ], [ %296, %did_jump_exit149 ], [ %305, %did_jump_exit156 ], [ %318, %data_misaligned164 ], [ %331, %did_jump_exit174 ], [ %340, %did_jump_exit181 ], [ %377, %data_misaligned205 ], [ %392, %did_jump_exit212 ], [ %400, %data_misaligned217 ], [ %416, %did_jump_exit228 ], [ %426, %data_misaligned234 ], [ %442, %did_jump_exit245 ], [ %450, %data_misaligned250 ], [ %466, %did_jump_exit261 ], [ %474, %data_misaligned267 ], [ %490, %did_jump_exit278 ], [ %498, %data_misaligned284 ], [ %514, %did_jump_exit295 ], [ %522, %data_misaligned301 ], [ %537, %did_jump_exit312 ], [ %mem_val232, %jump_aligned ], [ %545, %jump_misalign ]
  %tail396 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %data_misaligned18 ], [ 2, %did_jump_exit28 ], [ 2, %data_misaligned34 ], [ 2, %did_jump_exit44 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit60 ], [ 2, %did_jump_exit64 ], [ 4, %data_misaligned68 ], [ 4, %did_jump_exit78 ], [ 4, %data_misaligned82 ], [ 4, %did_jump_exit92 ], [ 4, %did_jump_exit99 ], [ 2, %data_misaligned114 ], [ 2, %did_jump_exit124 ], [ 2, %did_jump_exit131 ], [ 2, %data_misaligned139 ], [ 2, %did_jump_exit149 ], [ 2, %did_jump_exit156 ], [ 2, %data_misaligned164 ], [ 2, %did_jump_exit174 ], [ 2, %did_jump_exit181 ], [ 4, %data_misaligned205 ], [ 4, %did_jump_exit212 ], [ 4, %data_misaligned217 ], [ 4, %did_jump_exit228 ], [ 2, %data_misaligned234 ], [ 2, %did_jump_exit245 ], [ 2, %data_misaligned250 ], [ 2, %did_jump_exit261 ], [ 2, %data_misaligned267 ], [ 2, %did_jump_exit278 ], [ 2, %data_misaligned284 ], [ 2, %did_jump_exit295 ], [ 2, %data_misaligned301 ], [ 2, %did_jump_exit312 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail397 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned18 ], [ 1, %did_jump_exit28 ], [ 1, %data_misaligned34 ], [ 1, %did_jump_exit44 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ], [ 13, %data_misaligned114 ], [ 13, %did_jump_exit124 ], [ 13, %did_jump_exit131 ], [ 16, %data_misaligned139 ], [ 16, %did_jump_exit149 ], [ 16, %did_jump_exit156 ], [ 19, %data_misaligned164 ], [ 19, %did_jump_exit174 ], [ 19, %did_jump_exit181 ], [ 25, %data_misaligned205 ], [ 25, %did_jump_exit212 ], [ 25, %data_misaligned217 ], [ 25, %did_jump_exit228 ], [ 26, %data_misaligned234 ], [ 26, %did_jump_exit245 ], [ 26, %data_misaligned250 ], [ 26, %did_jump_exit261 ], [ 26, %data_misaligned267 ], [ 26, %did_jump_exit278 ], [ 26, %data_misaligned284 ], [ 26, %did_jump_exit295 ], [ 26, %data_misaligned301 ], [ 26, %did_jump_exit312 ], [ 27, %jump_aligned ], [ 27, %jump_misalign ]
  %tail398 = phi i8 [ %25, %data_misaligned ], [ %39, %did_jump_exit ], [ %46, %data_misaligned3 ], [ %60, %did_jump_exit13 ], [ %67, %data_misaligned18 ], [ %81, %did_jump_exit28 ], [ %88, %data_misaligned34 ], [ %102, %did_jump_exit44 ], [ %109, %data_misaligned50 ], [ %124, %did_jump_exit60 ], [ %133, %did_jump_exit64 ], [ %145, %data_misaligned68 ], [ %159, %did_jump_exit78 ], [ %167, %data_misaligned82 ], [ %182, %did_jump_exit92 ], [ %191, %did_jump_exit99 ], [ %251, %data_misaligned114 ], [ %264, %did_jump_exit124 ], [ %273, %did_jump_exit131 ], [ %285, %data_misaligned139 ], [ %298, %did_jump_exit149 ], [ %307, %did_jump_exit156 ], [ %320, %data_misaligned164 ], [ %333, %did_jump_exit174 ], [ %342, %did_jump_exit181 ], [ %379, %data_misaligned205 ], [ %394, %did_jump_exit212 ], [ %402, %data_misaligned217 ], [ %418, %did_jump_exit228 ], [ %428, %data_misaligned234 ], [ %444, %did_jump_exit245 ], [ %452, %data_misaligned250 ], [ %468, %did_jump_exit261 ], [ %476, %data_misaligned267 ], [ %492, %did_jump_exit278 ], [ %500, %data_misaligned284 ], [ %516, %did_jump_exit295 ], [ %524, %data_misaligned301 ], [ %539, %did_jump_exit312 ], [ 1, %jump_aligned ], [ %547, %jump_misalign ]
  %594 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets400 = load i32, ptr %594, align 4
  %chain_total401 = add nuw i32 %chain_packets400, %packets
  %595 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget402 = load atomic i32, ptr %595 monotonic, align 4, !range !2
  %596 = icmp ult i32 %chain_total401, %chain_budget402
  br i1 %596, label %chain_lookup, label %chain_leave399, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %597 = lshr i32 %next_pc395, 1
  %598 = and i32 %597, 65535
  %599 = zext i32 %598 to i64
  %600 = mul i64 %599, 16
  %chain_slot403 = getelementptr i8, ptr %chain_table, i64 %600
  %601 = getelementptr i8, ptr %chain_slot403, i64 0
  %slot_pc404 = load i32, ptr %601, align 4
  %602 = icmp eq i32 %slot_pc404, %next_pc395
  br i1 %602, label %chain_hit405, label %chain_leave399, !prof !0

chain_leave399:                                   ; preds = %chain_lookup, %chain_exit
  %603 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %603, align 4
  %604 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail396, ptr %604, align 4
  %605 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail397, ptr %605, align 4
  %606 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail398, ptr %606, align 1
  ret void

chain_hit405:                                     ; preds = %chain_lookup
  %607 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc395, ptr %607, align 4
  %608 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total401, ptr %608, align 4
  %609 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %609, align 1
  %610 = getelementptr i8, ptr %chain_slot403, i64 8
  %chain_fn406 = load ptr, ptr %610, align 8
  musttail call swifttailcc void %chain_fn406(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
