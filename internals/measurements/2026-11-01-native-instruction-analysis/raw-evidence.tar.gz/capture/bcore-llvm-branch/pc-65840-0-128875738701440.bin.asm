
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65840-0-128875738701440.bin:     file format binary


Disassembly of section .data:

0000753638a01e80 <.data>:
    753638a01e80:	48 83 ec 38          	sub    rsp,0x38
    753638a01e84:	ba b5 fe fe ff       	mov    edx,0xfffefeb5
    753638a01e89:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    753638a01e90:	01 d6                	add    esi,edx
    753638a01e92:	b1 01                	mov    cl,0x1
    753638a01e94:	b8 65 01 00 00       	mov    eax,0x165
    753638a01e99:	83 fe e4             	cmp    esi,0xffffffe4
    753638a01e9c:	0f 87 09 02 00 00    	ja     0x753638a020ab
    753638a01ea2:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    753638a01ea9:	83 fa e4             	cmp    edx,0xffffffe4
    753638a01eac:	0f 87 f9 01 00 00    	ja     0x753638a020ab
    753638a01eb2:	4d 89 f3             	mov    r11,r14
    753638a01eb5:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    753638a01ebc:	4d 8b 95 38 01 00 00 	mov    r10,QWORD PTR [r13+0x138]
    753638a01ec3:	49 8b b5 40 01 00 00 	mov    rsi,QWORD PTR [r13+0x140]
    753638a01eca:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    753638a01ece:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    753638a01ed2:	41 89 c7             	mov    r15d,eax
    753638a01ed5:	41 c1 e7 05          	shl    r15d,0x5
    753638a01ed9:	41 0f b7 cf          	movzx  ecx,r15w
    753638a01edd:	41 c1 ef 1f          	shr    r15d,0x1f
    753638a01ee1:	c4 63 7b f0 f0 1b    	rorx   r14d,eax,0x1b
    753638a01ee7:	45 89 75 00          	mov    DWORD PTR [r13+0x0],r14d
    753638a01eeb:	31 d2                	xor    edx,edx
    753638a01eed:	85 c0                	test   eax,eax
    753638a01eef:	0f 94 c2             	sete   dl
    753638a01ef2:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    753638a01ef9:	45 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r15d
    753638a01f00:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    753638a01f07:	00 00 00 00 
    753638a01f0b:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    753638a01f12:	00 00 00 00 
    753638a01f16:	81 c9 00 00 4a 7f    	or     ecx,0x7f4a0000
    753638a01f1c:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    753638a01f20:	41 8d 59 fc          	lea    ebx,[r9-0x4]
    753638a01f24:	41 f6 c1 03          	test   r9b,0x3
    753638a01f28:	0f 85 88 0d 00 18    	jne    0x753650a02cb6
    753638a01f2e:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    753638a01f35:	41 8b 7d 3c          	mov    edi,DWORD PTR [r13+0x3c]
    753638a01f39:	89 d8                	mov    eax,ebx
    753638a01f3b:	c1 e8 0c             	shr    eax,0xc
    753638a01f3e:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    753638a01f43:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    753638a01f47:	48 85 c0             	test   rax,rax
    753638a01f4a:	0f 84 d0 0d 00 18    	je     0x753650a02d20
    753638a01f50:	89 d9                	mov    ecx,ebx
    753638a01f52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a01f58:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753638a01f5b:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    753638a01f5f:	41 89 ec             	mov    r12d,ebp
    753638a01f62:	41 c1 ec 0c          	shr    r12d,0xc
    753638a01f66:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    753638a01f6a:	48 85 c0             	test   rax,rax
    753638a01f6d:	0f 84 26 0e 00 18    	je     0x753650a02d99
    753638a01f73:	89 e9                	mov    ecx,ebp
    753638a01f75:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753638a01f7b:	89 3c 08             	mov    DWORD PTR [rax+rcx*1],edi
    753638a01f7e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a01f82:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    753638a01f86:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    753638a01f89:	0f 85 82 0e 00 18    	jne    0x753650a02e11
    753638a01f8f:	41 c7 45 04 15 7c 4a 	mov    DWORD PTR [r13+0x4],0x7f4a7c15
    753638a01f96:	7f 
    753638a01f97:	41 8d 86 15 7c 4a 7f 	lea    eax,[r14+0x7f4a7c15]
    753638a01f9e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    753638a01fa2:	89 c1                	mov    ecx,eax
    753638a01fa4:	c1 e9 1f             	shr    ecx,0x1f
    753638a01fa7:	c4 e2 00 f2 d1       	andn   edx,r15d,ecx
    753638a01fac:	31 f6                	xor    esi,esi
    753638a01fae:	41 81 fe eb 83 b5 80 	cmp    r14d,0x80b583eb
    753638a01fb5:	40 0f 93 c6          	setae  sil
    753638a01fb9:	31 ff                	xor    edi,edi
    753638a01fbb:	85 c0                	test   eax,eax
    753638a01fbd:	40 0f 94 c7          	sete   dil
    753638a01fc1:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    753638a01fc8:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    753638a01fcf:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    753638a01fd6:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    753638a01fdd:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    753638a01fe4:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    753638a01feb:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    753638a01ff2:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    753638a01ff6:	48 85 c0             	test   rax,rax
    753638a01ff9:	0f 84 86 0e 00 18    	je     0x753650a02e85
    753638a01fff:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    753638a02005:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    753638a02008:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    753638a0200d:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    753638a02011:	48 85 c0             	test   rax,rax
    753638a02014:	0f 84 d6 0e 00 18    	je     0x753650a02ef0
    753638a0201a:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    753638a02020:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    753638a02023:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    753638a02027:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    753638a0202e:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    753638a02032:	b1 01                	mov    cl,0x1
    753638a02034:	bb 02 00 00 00       	mov    ebx,0x2
    753638a02039:	bd 09 00 00 00       	mov    ebp,0x9
    753638a0203e:	a8 01                	test   al,0x1
    753638a02040:	0f 85 03 0f 00 18    	jne    0x753650a02f49
    753638a02046:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    753638a0204d:	01 ea                	add    edx,ebp
    753638a0204f:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    753638a02056:	39 f2                	cmp    edx,esi
    753638a02058:	73 37                	jae    0x753638a02091
    753638a0205a:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    753638a02061:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    753638a02067:	41 39 04 30          	cmp    DWORD PTR [r8+rsi*1],eax
    753638a0206b:	75 24                	jne    0x753638a02091
    753638a0206d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a02074:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    753638a0207b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753638a02082:	00 
    753638a02083:	49 8b 44 30 08       	mov    rax,QWORD PTR [r8+rsi*1+0x8]
    753638a02088:	4d 89 de             	mov    r14,r11
    753638a0208b:	48 83 c4 38          	add    rsp,0x38
    753638a0208f:	ff e0                	jmp    rax
    753638a02091:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    753638a02098:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    753638a0209f:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    753638a020a6:	b8 28 01 00 00       	mov    eax,0x128
    753638a020ab:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    753638a020b0:	48 83 c4 38          	add    rsp,0x38
    753638a020b4:	c2 08 00             	ret    0x8
