; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001018c(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = add i32 %guard_lb, -65947
  %4 = icmp ult i32 %3, -15
  %5 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb106 = load i32, ptr %5, align 4
  %6 = add i32 %guard_lb106, -65947
  %7 = icmp ult i32 %6, -15
  %8 = and i1 %4, %7
  br i1 %8, label %insn_0x0001018c, label %common.ret, !prof !0

insn_0x0001018c:                                  ; preds = %entry
  %9 = getelementptr i8, ptr %cpu, i64 24
  %rd = load i32, ptr %9, align 4
  %rd_add = add i32 %rd, 1
  store i32 %rd_add, ptr %9, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %10 = xor i32 %flgs, -1
  %overflow = and i32 %flgn, %10
  %11 = getelementptr i8, ptr %cpu, i64 228
  %12 = getelementptr i8, ptr %cpu, i64 232
  %13 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %13, align 4
  %14 = or i32 %vs_cur, %overflow
  %15 = getelementptr i8, ptr %cpu, i64 248
  store i32 %overflow, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 252
  store i32 %overflow, ptr %16, align 4
  store i32 %14, ptr %13, align 4
  %17 = getelementptr i8, ptr %cpu, i64 236
  %18 = getelementptr i8, ptr %cpu, i64 240
  %19 = getelementptr i8, ptr %cpu, i64 20
  %rx = load i32, ptr %19, align 4
  %20 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %20 to i32
  %21 = getelementptr i8, ptr %cpu, i64 276
  store i32 %cc, ptr %21, align 4
  %22 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %22 to i32
  %23 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %23 to i32
  %24 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %24 to i32
  store i32 %az1, ptr %11, align 4
  store i32 %an2, ptr %12, align 4
  store i32 %ac03, ptr %17, align 4
  store i32 %ac03, ptr %18, align 4
  br i1 %20, label %insn_0x00010192, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x0001018c
  %25 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %26, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %27 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %27 monotonic, align 4, !range !1
  %28 = icmp ult i32 %chain_total, %chain_budget
  br i1 %28, label %chain_go, label %chain_leave107, !prof !0

insn_0x00010192:                                  ; preds = %insn_0x0001018c
  %29 = getelementptr i8, ptr %cpu, i64 28
  %rs = load i32, ptr %29, align 4
  %rt = load i32, ptr %cpu, align 4
  %xor32 = xor i32 %rt, %rs
  store i32 %xor32, ptr %cpu, align 4
  %30 = icmp eq i32 %xor32, 0
  %az4 = zext i1 %30 to i32
  %an5 = lshr i32 %xor32, 31
  store i32 %az4, ptr %11, align 4
  store i32 %an5, ptr %12, align 4
  store i32 0, ptr %17, align 4
  store i32 0, ptr %18, align 4
  store i32 0, ptr %15, align 4
  store i32 0, ptr %16, align 4
  %31 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %31, align 4
  %32 = and i32 %fp, 3
  %.not = icmp eq i32 %32, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010192
  %33 = getelementptr i8, ptr %cpu, i64 188
  store i32 65940, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %35, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65940, i32 %fp, i32 0)
  %next_pc = load i32, ptr %33, align 4
  %36 = getelementptr i8, ptr %cpu, i64 296
  %37 = load i8, ptr %36, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010192
  %38 = lshr i32 %fp, 12
  %page_index = zext i32 %38 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !2

page_fast:                                        ; preds = %data_aligned
  %39 = and i32 %fp, 4095
  %page_offset = zext i32 %39 to i64
  %40 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %40, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %41 = getelementptr i8, ptr %cpu, i64 188
  store i32 65940, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %43, align 4
  %44 = tail call i32 @mem_read32(ptr %mem, i32 %fp)
  %45 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %45, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_done, label %did_jump_exit, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %44, %page_slow ]
  %sp1 = add i32 %fp, 4
  %46 = lshr i32 %sp1, 12
  %page_index11 = zext i32 %46 to i64
  %page_slot12 = getelementptr ptr, ptr %page_table, i64 %page_index11
  %page13 = load ptr, ptr %page_slot12, align 8
  %page_mapped14.not = icmp eq ptr %page13, null
  br i1 %page_mapped14.not, label %page_slow9, label %page_fast8, !prof !2

did_jump_exit:                                    ; preds = %page_slow
  %next_pc108 = load i32, ptr %41, align 4
  br label %chain_exit

page_fast8:                                       ; preds = %page_done
  %47 = and i32 %sp1, 4095
  %page_offset15 = zext i32 %47 to i64
  %48 = getelementptr i8, ptr %page13, i64 %page_offset15
  %page_val16 = load i32, ptr %48, align 4
  br label %page_done10

page_slow9:                                       ; preds = %page_done
  %49 = getelementptr i8, ptr %cpu, i64 188
  store i32 65940, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %51, align 4
  %52 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %53 = getelementptr i8, ptr %cpu, i64 296
  %dj19 = load i8, ptr %53, align 1
  %dj_set20.not = icmp eq i8 %dj19, 0
  br i1 %dj_set20.not, label %page_done10, label %did_jump_exit17, !prof !0

page_done10:                                      ; preds = %page_slow9, %page_fast8
  %mem_val21 = phi i32 [ %page_val16, %page_fast8 ], [ %52, %page_slow9 ]
  %sp2 = add i32 %fp, 8
  store i32 %mem_val, ptr %31, align 4
  %54 = getelementptr i8, ptr %cpu, i64 168
  store i32 %mem_val21, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 56
  store i32 %sp2, ptr %55, align 4
  %56 = lshr i32 %sp2, 12
  %page_index27 = zext i32 %56 to i64
  %page_slot28 = getelementptr ptr, ptr %page_table, i64 %page_index27
  %page29 = load ptr, ptr %page_slot28, align 8
  %page_mapped30.not = icmp eq ptr %page29, null
  br i1 %page_mapped30.not, label %page_slow25, label %page_fast24, !prof !2

did_jump_exit17:                                  ; preds = %page_slow9
  %next_pc110 = load i32, ptr %49, align 4
  br label %chain_exit

page_fast24:                                      ; preds = %page_done10
  %57 = and i32 %sp2, 4095
  %page_offset31 = zext i32 %57 to i64
  %58 = getelementptr i8, ptr %page29, i64 %page_offset31
  %page_val32 = load i32, ptr %58, align 4
  br label %page_done26

page_slow25:                                      ; preds = %page_done10
  %59 = getelementptr i8, ptr %cpu, i64 188
  store i32 65944, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %61, align 4
  %62 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %63 = getelementptr i8, ptr %cpu, i64 296
  %dj35 = load i8, ptr %63, align 1
  %dj_set36.not = icmp eq i8 %dj35, 0
  br i1 %dj_set36.not, label %page_done26, label %did_jump_exit33, !prof !0

page_done26:                                      ; preds = %page_slow25, %page_fast24
  %mem_val37 = phi i32 [ %page_val32, %page_fast24 ], [ %62, %page_slow25 ]
  %64 = getelementptr i8, ptr %cpu, i64 52
  store i32 %mem_val37, ptr %64, align 4
  %sp_inc = add i32 %fp, 12
  %65 = lshr i32 %sp_inc, 12
  %page_index43 = zext i32 %65 to i64
  %page_slot44 = getelementptr ptr, ptr %page_table, i64 %page_index43
  %page45 = load ptr, ptr %page_slot44, align 8
  %page_mapped46.not = icmp eq ptr %page45, null
  br i1 %page_mapped46.not, label %page_slow41, label %page_fast40, !prof !2

did_jump_exit33:                                  ; preds = %page_slow25
  %next_pc112 = load i32, ptr %59, align 4
  br label %chain_exit

page_fast40:                                      ; preds = %page_done26
  %66 = and i32 %sp_inc, 4095
  %page_offset47 = zext i32 %66 to i64
  %67 = getelementptr i8, ptr %page45, i64 %page_offset47
  %page_val48 = load i32, ptr %67, align 4
  br label %page_done42

page_slow41:                                      ; preds = %page_done26
  %68 = getelementptr i8, ptr %cpu, i64 188
  store i32 65944, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %70, align 4
  %71 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %72 = getelementptr i8, ptr %cpu, i64 296
  %dj51 = load i8, ptr %72, align 1
  %dj_set52.not = icmp eq i8 %dj51, 0
  br i1 %dj_set52.not, label %page_done42, label %did_jump_exit49, !prof !0

page_done42:                                      ; preds = %page_slow41, %page_fast40
  %mem_val53 = phi i32 [ %page_val48, %page_fast40 ], [ %71, %page_slow41 ]
  store i32 %mem_val53, ptr %29, align 4
  %sp_inc54 = add i32 %fp, 16
  %73 = lshr i32 %sp_inc54, 12
  %page_index60 = zext i32 %73 to i64
  %page_slot61 = getelementptr ptr, ptr %page_table, i64 %page_index60
  %page62 = load ptr, ptr %page_slot61, align 8
  %page_mapped63.not = icmp eq ptr %page62, null
  br i1 %page_mapped63.not, label %page_slow58, label %page_fast57, !prof !2

did_jump_exit49:                                  ; preds = %page_slow41
  %next_pc114 = load i32, ptr %68, align 4
  br label %chain_exit

page_fast57:                                      ; preds = %page_done42
  %74 = and i32 %sp_inc54, 4095
  %page_offset64 = zext i32 %74 to i64
  %75 = getelementptr i8, ptr %page62, i64 %page_offset64
  %page_val65 = load i32, ptr %75, align 4
  br label %page_done59

page_slow58:                                      ; preds = %page_done42
  %76 = getelementptr i8, ptr %cpu, i64 188
  store i32 65944, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %78, align 4
  %79 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc54)
  %80 = getelementptr i8, ptr %cpu, i64 296
  %dj68 = load i8, ptr %80, align 1
  %dj_set69.not = icmp eq i8 %dj68, 0
  br i1 %dj_set69.not, label %page_done59, label %did_jump_exit66, !prof !0

page_done59:                                      ; preds = %page_slow58, %page_fast57
  %mem_val70 = phi i32 [ %page_val65, %page_fast57 ], [ %79, %page_slow58 ]
  store i32 %mem_val70, ptr %9, align 4
  %sp_inc71 = add i32 %fp, 20
  %81 = lshr i32 %sp_inc71, 12
  %page_index77 = zext i32 %81 to i64
  %page_slot78 = getelementptr ptr, ptr %page_table, i64 %page_index77
  %page79 = load ptr, ptr %page_slot78, align 8
  %page_mapped80.not = icmp eq ptr %page79, null
  br i1 %page_mapped80.not, label %page_slow75, label %page_fast74, !prof !2

did_jump_exit66:                                  ; preds = %page_slow58
  %next_pc116 = load i32, ptr %76, align 4
  br label %chain_exit

page_fast74:                                      ; preds = %page_done59
  %82 = and i32 %sp_inc71, 4095
  %page_offset81 = zext i32 %82 to i64
  %83 = getelementptr i8, ptr %page79, i64 %page_offset81
  %page_val82 = load i32, ptr %83, align 4
  br label %page_done76

page_slow75:                                      ; preds = %page_done59
  %84 = getelementptr i8, ptr %cpu, i64 188
  store i32 65944, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %86, align 4
  %87 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc71)
  %88 = getelementptr i8, ptr %cpu, i64 296
  %dj85 = load i8, ptr %88, align 1
  %dj_set86.not = icmp eq i8 %dj85, 0
  br i1 %dj_set86.not, label %page_done76, label %did_jump_exit83, !prof !0

page_done76:                                      ; preds = %page_slow75, %page_fast74
  %mem_val87 = phi i32 [ %page_val82, %page_fast74 ], [ %87, %page_slow75 ]
  store i32 %mem_val87, ptr %19, align 4
  %sp_inc88 = add i32 %fp, 24
  %89 = lshr i32 %sp_inc88, 12
  %page_index94 = zext i32 %89 to i64
  %page_slot95 = getelementptr ptr, ptr %page_table, i64 %page_index94
  %page96 = load ptr, ptr %page_slot95, align 8
  %page_mapped97.not = icmp eq ptr %page96, null
  br i1 %page_mapped97.not, label %page_slow92, label %page_fast91, !prof !2

did_jump_exit83:                                  ; preds = %page_slow75
  %next_pc118 = load i32, ptr %84, align 4
  br label %chain_exit

page_fast91:                                      ; preds = %page_done76
  %90 = and i32 %sp_inc88, 4095
  %page_offset98 = zext i32 %90 to i64
  %91 = getelementptr i8, ptr %page96, i64 %page_offset98
  %page_val99 = load i32, ptr %91, align 4
  br label %page_done93

page_slow92:                                      ; preds = %page_done76
  %92 = getelementptr i8, ptr %cpu, i64 188
  store i32 65944, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %94, align 4
  %95 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc88)
  %96 = getelementptr i8, ptr %cpu, i64 296
  %dj102 = load i8, ptr %96, align 1
  %dj_set103.not = icmp eq i8 %dj102, 0
  br i1 %dj_set103.not, label %page_done93, label %did_jump_exit100, !prof !0

page_done93:                                      ; preds = %page_slow92, %page_fast91
  %mem_val104 = phi i32 [ %page_val99, %page_fast91 ], [ %95, %page_slow92 ]
  %97 = getelementptr i8, ptr %cpu, i64 16
  store i32 %mem_val104, ptr %97, align 4
  %sp_inc105 = add i32 %fp, 28
  store i32 %sp_inc105, ptr %55, align 4
  %lsb = and i32 %mem_val21, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit100:                                 ; preds = %page_slow92
  %next_pc120 = load i32, ptr %92, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done93
  %98 = getelementptr i8, ptr %cpu, i64 188
  store i32 65946, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %100, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc121 = load i32, ptr %98, align 4
  %101 = getelementptr i8, ptr %cpu, i64 296
  %102 = load i8, ptr %101, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave107, %chain_leave126
  %tail123.sink = phi i32 [ %tail123, %chain_leave126 ], [ 2, %chain_leave107 ]
  %packets.sink = phi i32 [ %packets, %chain_leave126 ], [ 3, %chain_leave107 ]
  %tail125.sink.ph = phi i8 [ %tail125, %chain_leave126 ], [ 1, %chain_leave107 ]
  %103 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail123.sink, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %104, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink140 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail125.sink = phi i8 [ 1, %entry ], [ %tail125.sink.ph, %common.ret.sink.split ]
  %105 = getelementptr i8, ptr %cpu, i64 %.sink140
  store i8 %tail125.sink, ptr %105, align 1
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527328
  %slot_pc = load i32, ptr %chain_slot, align 4
  %106 = icmp eq i32 %slot_pc, 65916
  br i1 %106, label %chain_hit, label %chain_leave107, !prof !0

chain_leave107:                                   ; preds = %chain_go, %brcc_taken
  store i32 65916, ptr %25, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65916, ptr %25, align 4
  store i32 %chain_total, ptr %26, align 4
  %107 = getelementptr i8, ptr %chain_table, i64 527336
  %chain_fn = load ptr, ptr %107, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done93, %jump_misalign, %did_jump_exit100, %did_jump_exit83, %did_jump_exit66, %did_jump_exit49, %did_jump_exit33, %did_jump_exit17, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %did_jump_exit17 ], [ 6, %did_jump_exit33 ], [ 6, %did_jump_exit49 ], [ 6, %did_jump_exit66 ], [ 6, %did_jump_exit83 ], [ 6, %did_jump_exit100 ], [ 7, %jump_misalign ], [ 7, %page_done93 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc108, %did_jump_exit ], [ %next_pc110, %did_jump_exit17 ], [ %next_pc112, %did_jump_exit33 ], [ %next_pc114, %did_jump_exit49 ], [ %next_pc116, %did_jump_exit66 ], [ %next_pc118, %did_jump_exit83 ], [ %next_pc120, %did_jump_exit100 ], [ %next_pc121, %jump_misalign ], [ %mem_val21, %page_done93 ]
  %tail123 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %did_jump_exit17 ], [ 2, %did_jump_exit33 ], [ 2, %did_jump_exit49 ], [ 2, %did_jump_exit66 ], [ 2, %did_jump_exit83 ], [ 2, %did_jump_exit100 ], [ 2, %jump_misalign ], [ 2, %page_done93 ]
  %tail125 = phi i8 [ %37, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj19, %did_jump_exit17 ], [ %dj35, %did_jump_exit33 ], [ %dj51, %did_jump_exit49 ], [ %dj68, %did_jump_exit66 ], [ %dj85, %did_jump_exit83 ], [ %dj102, %did_jump_exit100 ], [ %102, %jump_misalign ], [ 1, %page_done93 ]
  %108 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets127 = load i32, ptr %108, align 4
  %chain_total128 = add nuw i32 %chain_packets127, %packets
  %109 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget129 = load atomic i32, ptr %109 monotonic, align 4, !range !1
  %110 = icmp ult i32 %chain_total128, %chain_budget129
  br i1 %110, label %chain_lookup, label %chain_leave126, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %111 = shl i32 %tail, 3
  %112 = and i32 %111, 1048560
  %113 = zext i32 %112 to i64
  %chain_slot130 = getelementptr i8, ptr %chain_table, i64 %113
  %slot_pc131 = load i32, ptr %chain_slot130, align 4
  %114 = icmp eq i32 %slot_pc131, %tail
  br i1 %114, label %chain_hit132, label %chain_leave126, !prof !0

chain_leave126:                                   ; preds = %chain_lookup, %chain_exit
  %115 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %115, align 4
  br label %common.ret.sink.split

chain_hit132:                                     ; preds = %chain_lookup
  %116 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %116, align 4
  store i32 %chain_total128, ptr %108, align 4
  %117 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %117, align 1
  %118 = getelementptr i8, ptr %chain_slot130, i64 8
  %chain_fn133 = load ptr, ptr %118, align 8
  musttail call swifttailcc void %chain_fn133(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
!2 = !{!"branch_weights", i32 1, i32 1048576}
