; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010328(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -66415
  %5 = icmp ult i32 %4, -71
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb318 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb318, -66415
  %8 = icmp ult i32 %7, -71
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010328, label %common.ret, !prof !0

insn_0x00010328:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %10, align 4
  %sp_dec = add i32 %sp, -4
  %11 = getelementptr i8, ptr %cpu, i64 24
  %r = load i32, ptr %11, align 4
  %12 = and i32 %sp, 3
  %.not = icmp eq i32 %12, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010328
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %14, align 4
  tail call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec, i32 65536)
  %15 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 296
  %17 = load i8, ptr %16, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010328
  %18 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %18 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %19 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %19 to i64
  %20 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %20, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %21 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %22, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %23 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %23, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %did_jump_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %sp_dec1 = add i32 %sp, -8
  %24 = getelementptr i8, ptr %cpu, i64 28
  %r2 = load i32, ptr %24, align 4
  %25 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %25 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11.not = icmp eq ptr %page10, null
  br i1 %page_mapped11.not, label %page_wr_slow6, label %page_wr_fast5, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %26 = getelementptr i8, ptr %cpu, i64 188
  %next_pc319 = load i32, ptr %26, align 4
  br label %chain_exit

page_wr_fast5:                                    ; preds = %page_wr_done
  %27 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %28, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %page_wr_done
  %29 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %30, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %31 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %31, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_wr_done7, label %did_jump_exit13, !prof !0

page_wr_done7:                                    ; preds = %page_wr_slow6, %page_wr_fast5
  %sp_dec17 = add i32 %sp, -12
  %32 = getelementptr i8, ptr %cpu, i64 44
  %p = load i32, ptr %32, align 4
  %33 = lshr i32 %sp_dec17, 12
  %page_index23 = zext i32 %33 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26.not = icmp eq ptr %page25, null
  br i1 %page_mapped26.not, label %page_wr_slow21, label %page_wr_fast20, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %34 = getelementptr i8, ptr %cpu, i64 188
  %next_pc321 = load i32, ptr %34, align 4
  br label %chain_exit

page_wr_fast20:                                   ; preds = %page_wr_done7
  %35 = and i32 %sp_dec17, 4095
  %page_offset27 = zext i32 %35 to i64
  %36 = getelementptr i8, ptr %page25, i64 %page_offset27
  store i32 %p, ptr %36, align 4
  br label %page_wr_done22

page_wr_slow21:                                   ; preds = %page_wr_done7
  %37 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %38, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %p)
  %39 = getelementptr i8, ptr %cpu, i64 296
  %dj30 = load i8, ptr %39, align 1
  %dj_set31.not = icmp eq i8 %dj30, 0
  br i1 %dj_set31.not, label %page_wr_done22, label %did_jump_exit28, !prof !0

page_wr_done22:                                   ; preds = %page_wr_slow21, %page_wr_fast20
  %sp_dec32 = add i32 %sp, -16
  %40 = getelementptr i8, ptr %cpu, i64 48
  %p33 = load i32, ptr %40, align 4
  %41 = lshr i32 %sp_dec32, 12
  %page_index39 = zext i32 %41 to i64
  %page_slot40 = getelementptr ptr, ptr %page_table, i64 %page_index39
  %page41 = load ptr, ptr %page_slot40, align 8
  %page_mapped42.not = icmp eq ptr %page41, null
  br i1 %page_mapped42.not, label %page_wr_slow37, label %page_wr_fast36, !prof !1

did_jump_exit28:                                  ; preds = %page_wr_slow21
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc323 = load i32, ptr %42, align 4
  br label %chain_exit

page_wr_fast36:                                   ; preds = %page_wr_done22
  %43 = and i32 %sp_dec32, 4095
  %page_offset43 = zext i32 %43 to i64
  %44 = getelementptr i8, ptr %page41, i64 %page_offset43
  store i32 %p33, ptr %44, align 4
  br label %page_wr_done38

page_wr_slow37:                                   ; preds = %page_wr_done22
  %45 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %46, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec32, i32 %p33)
  %47 = getelementptr i8, ptr %cpu, i64 296
  %dj46 = load i8, ptr %47, align 1
  %dj_set47.not = icmp eq i8 %dj46, 0
  br i1 %dj_set47.not, label %page_wr_done38, label %did_jump_exit44, !prof !0

page_wr_done38:                                   ; preds = %page_wr_slow37, %page_wr_fast36
  %sp_dec48 = add i32 %sp, -20
  %48 = getelementptr i8, ptr %cpu, i64 52
  %p49 = load i32, ptr %48, align 4
  %49 = lshr i32 %sp_dec48, 12
  %page_index55 = zext i32 %49 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58.not = icmp eq ptr %page57, null
  br i1 %page_mapped58.not, label %page_wr_slow53, label %page_wr_fast52, !prof !1

did_jump_exit44:                                  ; preds = %page_wr_slow37
  %50 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %50, align 4
  br label %chain_exit

page_wr_fast52:                                   ; preds = %page_wr_done38
  %51 = and i32 %sp_dec48, 4095
  %page_offset59 = zext i32 %51 to i64
  %52 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p49, ptr %52, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %page_wr_done38
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %54, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec48, i32 %p49)
  %55 = getelementptr i8, ptr %cpu, i64 296
  %dj62 = load i8, ptr %55, align 1
  %dj_set63.not = icmp eq i8 %dj62, 0
  br i1 %dj_set63.not, label %page_wr_done54, label %did_jump_exit60, !prof !0

page_wr_done54:                                   ; preds = %page_wr_slow53, %page_wr_fast52
  store i32 %sp_dec48, ptr %10, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not411 = icmp eq i8 %cec_pending, 0
  br i1 %.not411, label %insn_0x0001032a, label %cec_check, !prof !0

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %56 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %56, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done54
  %57 = getelementptr i8, ptr %cpu, i64 188
  store i32 66346, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %59, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %60 = getelementptr i8, ptr %cpu, i64 296
  %dj66 = load i8, ptr %60, align 1
  %dj_set67.not = icmp eq i8 %dj66, 0
  br i1 %dj_set67.not, label %insn_0x0001032a, label %did_jump_exit64, !prof !0

did_jump_exit64:                                  ; preds = %cec_check
  %next_pc328 = load i32, ptr %57, align 4
  br label %chain_exit

insn_0x0001032a:                                  ; preds = %page_wr_done54, %cec_check
  %61 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %62, align 4
  %sp1 = add i32 %sp, -24
  %63 = lshr i32 %sp1, 12
  %page_index73 = zext i32 %63 to i64
  %page_slot74 = getelementptr ptr, ptr %page_table, i64 %page_index73
  %page75 = load ptr, ptr %page_slot74, align 8
  %page_mapped76.not = icmp eq ptr %page75, null
  br i1 %page_mapped76.not, label %page_wr_slow71, label %page_wr_fast70, !prof !1

page_wr_fast70:                                   ; preds = %insn_0x0001032a
  %64 = and i32 %sp1, 4095
  %page_offset77 = zext i32 %64 to i64
  %65 = getelementptr i8, ptr %page75, i64 %page_offset77
  store i32 %rets, ptr %65, align 4
  br label %page_wr_done72

page_wr_slow71:                                   ; preds = %insn_0x0001032a
  %66 = getelementptr i8, ptr %cpu, i64 188
  store i32 66346, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %68, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %69 = getelementptr i8, ptr %cpu, i64 296
  %dj80 = load i8, ptr %69, align 1
  %dj_set81.not = icmp eq i8 %dj80, 0
  br i1 %dj_set81.not, label %page_wr_done72, label %did_jump_exit78, !prof !0

page_wr_done72:                                   ; preds = %page_wr_slow71, %page_wr_fast70
  %sp2 = add i32 %sp, -28
  %70 = lshr i32 %sp2, 12
  %page_index87 = zext i32 %70 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90.not = icmp eq ptr %page89, null
  br i1 %page_mapped90.not, label %page_wr_slow85, label %page_wr_fast84, !prof !1

did_jump_exit78:                                  ; preds = %page_wr_slow71
  %next_pc330 = load i32, ptr %66, align 4
  br label %chain_exit

page_wr_fast84:                                   ; preds = %page_wr_done72
  %71 = and i32 %sp2, 4095
  %page_offset91 = zext i32 %71 to i64
  %72 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %fp, ptr %72, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %page_wr_done72
  %73 = getelementptr i8, ptr %cpu, i64 188
  store i32 66346, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %75, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %76 = getelementptr i8, ptr %cpu, i64 296
  %dj94 = load i8, ptr %76, align 1
  %dj_set95.not = icmp eq i8 %dj94, 0
  br i1 %dj_set95.not, label %page_wr_done86, label %did_jump_exit92, !prof !0

page_wr_done86:                                   ; preds = %page_wr_slow85, %page_wr_fast84
  store i32 %sp2, ptr %62, align 4
  store i32 %sp2, ptr %10, align 4
  %cec_pending96 = load i8, ptr %cec_pending_flag, align 1
  %.not414 = icmp eq i8 %cec_pending96, 0
  br i1 %.not414, label %insn_0x0001032e, label %cec_check97, !prof !0

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %next_pc332 = load i32, ptr %73, align 4
  br label %chain_exit

cec_check97:                                      ; preds = %page_wr_done86
  %77 = getelementptr i8, ptr %cpu, i64 188
  store i32 66350, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %79, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %80 = getelementptr i8, ptr %cpu, i64 296
  %dj101 = load i8, ptr %80, align 1
  %dj_set102.not = icmp eq i8 %dj101, 0
  br i1 %dj_set102.not, label %insn_0x0001032e, label %did_jump_exit99, !prof !0

did_jump_exit99:                                  ; preds = %cec_check97
  %next_pc333 = load i32, ptr %77, align 4
  br label %chain_exit

insn_0x0001032e:                                  ; preds = %page_wr_done86, %cec_check97
  %rx = load i32, ptr %cpu, align 4
  %81 = icmp ult i32 %rx, 5
  %cc = zext i1 %81 to i32
  %82 = getelementptr i8, ptr %cpu, i64 276
  store i32 %cc, ptr %82, align 4
  %83 = icmp eq i32 %rx, 4
  %az = zext i1 %83 to i32
  %84 = icmp ult i32 %rx, 4
  %an = zext i1 %84 to i32
  %85 = icmp ugt i32 %rx, 3
  %ac0 = zext i1 %85 to i32
  %86 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i64 232
  store i32 %an, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i64 236
  store i32 %ac0, ptr %88, align 4
  %89 = getelementptr i8, ptr %cpu, i64 240
  store i32 %ac0, ptr %89, align 4
  br i1 %81, label %insn_0x00010332, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x0001032e
  %90 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %91, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %92 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %92 monotonic, align 4, !range !2
  %93 = icmp ult i32 %chain_total, %chain_budget
  br i1 %93, label %chain_go, label %chain_leave334, !prof !0

insn_0x00010332:                                  ; preds = %insn_0x0001032e
  %94 = getelementptr i8, ptr %cpu, i64 4
  %rx103 = load i32, ptr %94, align 4
  %95 = icmp eq i32 %rx103, 0
  %az104 = zext i1 %95 to i32
  %flgn = lshr i32 %rx103, 31
  store i32 %az104, ptr %82, align 4
  store i32 %az104, ptr %86, align 4
  store i32 %flgn, ptr %87, align 4
  store i32 1, ptr %88, align 4
  store i32 1, ptr %89, align 4
  br i1 %95, label %brt_taken, label %insn_0x00010336

brt_taken:                                        ; preds = %insn_0x00010332
  %96 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets337 = load i32, ptr %97, align 4
  %chain_total338 = add nuw i32 %chain_packets337, 6
  %98 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget339 = load atomic i32, ptr %98 monotonic, align 4, !range !2
  %99 = icmp ult i32 %chain_total338, %chain_budget339
  br i1 %99, label %chain_go335, label %chain_leave336, !prof !0

insn_0x00010336:                                  ; preds = %insn_0x00010332
  %100 = getelementptr i8, ptr %cpu, i64 12
  store i32 32000000, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 248
  store i32 0, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i64 252
  store i32 0, ptr %102, align 4
  %103 = icmp ult i32 %rx103, 32000001
  %cc107 = zext i1 %103 to i32
  store i32 %cc107, ptr %82, align 4
  %104 = icmp eq i32 %rx103, 32000000
  %az108 = zext i1 %104 to i32
  %105 = icmp ult i32 %rx103, 32000000
  %an109 = zext i1 %105 to i32
  %106 = icmp ugt i32 %rx103, 31999999
  %ac0110 = zext i1 %106 to i32
  store i32 %az108, ptr %86, align 4
  store i32 %an109, ptr %87, align 4
  store i32 %ac0110, ptr %88, align 4
  store i32 %ac0110, ptr %89, align 4
  br i1 %103, label %insn_0x00010340, label %brcc_taken112

brcc_taken112:                                    ; preds = %insn_0x00010336
  %107 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets346 = load i32, ptr %108, align 4
  %chain_total347 = add nuw i32 %chain_packets346, 10
  %109 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget348 = load atomic i32, ptr %109 monotonic, align 4, !range !2
  %110 = icmp ult i32 %chain_total347, %chain_budget348
  br i1 %110, label %chain_go344, label %chain_leave345, !prof !0

insn_0x00010340:                                  ; preds = %insn_0x00010336
  %111 = getelementptr i8, ptr %cpu, i64 40
  store i32 70384, ptr %111, align 4
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 17
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122.not = icmp eq ptr %page121, null
  br i1 %page_mapped122.not, label %page_wr_slow117, label %page_wr_fast116, !prof !1

page_wr_fast116:                                  ; preds = %insn_0x00010340
  %112 = getelementptr i8, ptr %page121, i64 752
  store i32 %rx, ptr %112, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %insn_0x00010340
  %113 = getelementptr i8, ptr %cpu, i64 188
  store i32 66376, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i64 308
  store i32 13, ptr %115, align 4
  tail call void @mem_write32(ptr %mem, i32 70384, i32 %rx)
  %116 = getelementptr i8, ptr %cpu, i64 296
  %dj126 = load i8, ptr %116, align 1
  %dj_set127.not = icmp eq i8 %dj126, 0
  br i1 %dj_set127.not, label %page_wr_done118, label %did_jump_exit124, !prof !0

page_wr_done118:                                  ; preds = %page_wr_slow117, %page_wr_fast116
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %.not415 = icmp eq i8 %cec_pending128, 0
  br i1 %.not415, label %insn_0x0001034a, label %cec_check129, !prof !0

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %next_pc354 = load i32, ptr %113, align 4
  br label %chain_exit

cec_check129:                                     ; preds = %page_wr_done118
  %117 = getelementptr i8, ptr %cpu, i64 188
  store i32 66378, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i64 308
  store i32 13, ptr %119, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %120 = getelementptr i8, ptr %cpu, i64 296
  %dj133 = load i8, ptr %120, align 1
  %dj_set134.not = icmp eq i8 %dj133, 0
  br i1 %dj_set134.not, label %insn_0x0001034a, label %did_jump_exit131, !prof !0

did_jump_exit131:                                 ; preds = %cec_check129
  %next_pc355 = load i32, ptr %117, align 4
  br label %chain_exit

insn_0x0001034a:                                  ; preds = %page_wr_done118, %cec_check129
  store i32 70388, ptr %111, align 4
  %page146 = load ptr, ptr %page_slot120, align 8
  %page_mapped147.not = icmp eq ptr %page146, null
  br i1 %page_mapped147.not, label %page_wr_slow142, label %page_wr_fast141, !prof !1

page_wr_fast141:                                  ; preds = %insn_0x0001034a
  %121 = getelementptr i8, ptr %page146, i64 756
  store i32 %rx103, ptr %121, align 4
  br label %page_wr_done143

page_wr_slow142:                                  ; preds = %insn_0x0001034a
  %122 = getelementptr i8, ptr %cpu, i64 188
  store i32 66386, ptr %122, align 4
  %123 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %124, align 4
  tail call void @mem_write32(ptr %mem, i32 70388, i32 %rx103)
  %125 = getelementptr i8, ptr %cpu, i64 296
  %dj151 = load i8, ptr %125, align 1
  %dj_set152.not = icmp eq i8 %dj151, 0
  br i1 %dj_set152.not, label %page_wr_done143, label %did_jump_exit149, !prof !0

page_wr_done143:                                  ; preds = %page_wr_slow142, %page_wr_fast141
  %cec_pending153 = load i8, ptr %cec_pending_flag, align 1
  %.not416 = icmp eq i8 %cec_pending153, 0
  br i1 %.not416, label %insn_0x00010354, label %cec_check154, !prof !0

did_jump_exit149:                                 ; preds = %page_wr_slow142
  %next_pc357 = load i32, ptr %122, align 4
  br label %chain_exit

cec_check154:                                     ; preds = %page_wr_done143
  %126 = getelementptr i8, ptr %cpu, i64 188
  store i32 66388, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %128, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %129 = getelementptr i8, ptr %cpu, i64 296
  %dj158 = load i8, ptr %129, align 1
  %dj_set159.not = icmp eq i8 %dj158, 0
  br i1 %dj_set159.not, label %insn_0x00010354, label %did_jump_exit156, !prof !0

did_jump_exit156:                                 ; preds = %cec_check154
  %next_pc358 = load i32, ptr %126, align 4
  br label %chain_exit

insn_0x00010354:                                  ; preds = %page_wr_done143, %cec_check154
  store i32 70392, ptr %111, align 4
  %130 = getelementptr i8, ptr %cpu, i64 8
  %val = load i32, ptr %130, align 4
  %page171 = load ptr, ptr %page_slot120, align 8
  %page_mapped172.not = icmp eq ptr %page171, null
  br i1 %page_mapped172.not, label %page_wr_slow167, label %page_wr_fast166, !prof !1

page_wr_fast166:                                  ; preds = %insn_0x00010354
  %131 = getelementptr i8, ptr %page171, i64 760
  store i32 %val, ptr %131, align 4
  br label %page_wr_done168

page_wr_slow167:                                  ; preds = %insn_0x00010354
  %132 = getelementptr i8, ptr %cpu, i64 188
  store i32 66396, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %133, align 4
  %134 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %134, align 4
  tail call void @mem_write32(ptr %mem, i32 70392, i32 %val)
  %135 = getelementptr i8, ptr %cpu, i64 296
  %dj176 = load i8, ptr %135, align 1
  %dj_set177.not = icmp eq i8 %dj176, 0
  br i1 %dj_set177.not, label %page_wr_done168, label %did_jump_exit174, !prof !0

page_wr_done168:                                  ; preds = %page_wr_slow167, %page_wr_fast166
  %cec_pending178 = load i8, ptr %cec_pending_flag, align 1
  %.not417 = icmp eq i8 %cec_pending178, 0
  br i1 %.not417, label %insn_0x0001035e, label %cec_check179, !prof !0

did_jump_exit174:                                 ; preds = %page_wr_slow167
  %next_pc360 = load i32, ptr %132, align 4
  br label %chain_exit

cec_check179:                                     ; preds = %page_wr_done168
  %136 = getelementptr i8, ptr %cpu, i64 188
  store i32 66398, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %137, align 4
  %138 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %138, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %139 = getelementptr i8, ptr %cpu, i64 296
  %dj183 = load i8, ptr %139, align 1
  %dj_set184.not = icmp eq i8 %dj183, 0
  br i1 %dj_set184.not, label %insn_0x0001035e, label %did_jump_exit181, !prof !0

did_jump_exit181:                                 ; preds = %cec_check179
  %next_pc361 = load i32, ptr %136, align 4
  br label %chain_exit

insn_0x0001035e:                                  ; preds = %page_wr_done168, %cec_check179
  %diff185 = add i32 %rx, -2
  %140 = icmp eq i32 %diff185, 0
  %az186 = zext i1 %140 to i32
  %flgn187 = lshr i32 %diff185, 31
  %flgs188 = lshr i32 %rx, 31
  %an190 = or i32 %flgn187, %flgs188
  %141 = icmp ugt i32 %rx, 1
  %ac0191 = zext i1 %141 to i32
  store i32 %az186, ptr %82, align 4
  store i32 %az186, ptr %86, align 4
  store i32 %an190, ptr %87, align 4
  store i32 %ac0191, ptr %88, align 4
  store i32 %ac0191, ptr %89, align 4
  br i1 %140, label %brt_taken193, label %insn_0x00010362

brt_taken193:                                     ; preds = %insn_0x0001035e
  %142 = getelementptr i8, ptr %cpu, i64 188
  store i32 66426, ptr %142, align 4
  %143 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets364 = load i32, ptr %143, align 4
  %chain_total365 = add nuw i32 %chain_packets364, 21
  %144 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget366 = load atomic i32, ptr %144 monotonic, align 4, !range !2
  %145 = icmp ult i32 %chain_total365, %chain_budget366
  br i1 %145, label %chain_go362, label %chain_leave363, !prof !0

insn_0x00010362:                                  ; preds = %insn_0x0001035e
  %diff195 = add i32 %rx, -3
  %146 = icmp eq i32 %diff195, 0
  %az196 = zext i1 %146 to i32
  %flgn197 = lshr i32 %diff195, 31
  %an200 = or i32 %flgn197, %flgs188
  %147 = icmp ugt i32 %rx, 2
  %ac0201 = zext i1 %147 to i32
  store i32 %az196, ptr %82, align 4
  store i32 %az196, ptr %86, align 4
  store i32 %an200, ptr %87, align 4
  store i32 %ac0201, ptr %88, align 4
  store i32 %ac0201, ptr %89, align 4
  br i1 %146, label %brt_taken203, label %insn_0x00010366

brt_taken203:                                     ; preds = %insn_0x00010362
  %148 = getelementptr i8, ptr %cpu, i64 188
  store i32 66468, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets373 = load i32, ptr %149, align 4
  %chain_total374 = add nuw i32 %chain_packets373, 23
  %150 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget375 = load atomic i32, ptr %150 monotonic, align 4, !range !2
  %151 = icmp ult i32 %chain_total374, %chain_budget375
  br i1 %151, label %chain_go371, label %chain_leave372, !prof !0

insn_0x00010366:                                  ; preds = %insn_0x00010362
  store i32 0, ptr %cpu, align 4
  %page209 = load ptr, ptr %page_slot88, align 8
  %page_mapped210.not = icmp eq ptr %page209, null
  br i1 %page_mapped210.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x00010366
  %152 = and i32 %sp2, 4095
  %page_offset211 = zext i32 %152 to i64
  %153 = getelementptr i8, ptr %page209, i64 %page_offset211
  %page_val = load i32, ptr %153, align 4
  br label %data_aligned218

page_slow:                                        ; preds = %insn_0x00010366
  %154 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i64 308
  store i32 25, ptr %156, align 4
  %157 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %158 = getelementptr i8, ptr %cpu, i64 296
  %dj214 = load i8, ptr %158, align 1
  %dj_set215.not = icmp eq i8 %dj214, 0
  br i1 %dj_set215.not, label %data_aligned218, label %did_jump_exit212, !prof !0

did_jump_exit212:                                 ; preds = %page_slow
  %next_pc381 = load i32, ptr %154, align 4
  br label %chain_exit

data_aligned218:                                  ; preds = %page_fast, %page_slow
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %157, %page_slow ]
  %page224 = load ptr, ptr %page_slot74, align 8
  %page_mapped225.not = icmp eq ptr %page224, null
  br i1 %page_mapped225.not, label %page_slow220, label %page_fast219, !prof !1

page_fast219:                                     ; preds = %data_aligned218
  %159 = and i32 %sp1, 4095
  %page_offset226 = zext i32 %159 to i64
  %160 = getelementptr i8, ptr %page224, i64 %page_offset226
  %page_val227 = load i32, ptr %160, align 4
  br label %page_done221

page_slow220:                                     ; preds = %data_aligned218
  %161 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i64 308
  store i32 25, ptr %163, align 4
  %164 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %165 = getelementptr i8, ptr %cpu, i64 296
  %dj230 = load i8, ptr %165, align 1
  %dj_set231.not = icmp eq i8 %dj230, 0
  br i1 %dj_set231.not, label %page_done221, label %did_jump_exit228, !prof !0

page_done221:                                     ; preds = %page_slow220, %page_fast219
  %mem_val232 = phi i32 [ %page_val227, %page_fast219 ], [ %164, %page_slow220 ]
  store i32 %mem_val, ptr %62, align 4
  store i32 %mem_val232, ptr %61, align 4
  store i32 %sp_dec48, ptr %10, align 4
  %page241 = load ptr, ptr %page_slot56, align 8
  %page_mapped242.not = icmp eq ptr %page241, null
  br i1 %page_mapped242.not, label %page_slow237, label %page_fast236, !prof !1

did_jump_exit228:                                 ; preds = %page_slow220
  %next_pc383 = load i32, ptr %161, align 4
  br label %chain_exit

page_fast236:                                     ; preds = %page_done221
  %166 = and i32 %sp_dec48, 4095
  %page_offset243 = zext i32 %166 to i64
  %167 = getelementptr i8, ptr %page241, i64 %page_offset243
  %page_val244 = load i32, ptr %167, align 4
  br label %page_done238

page_slow237:                                     ; preds = %page_done221
  %168 = getelementptr i8, ptr %cpu, i64 188
  store i32 66412, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %170, align 4
  %171 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec48)
  %172 = getelementptr i8, ptr %cpu, i64 296
  %dj247 = load i8, ptr %172, align 1
  %dj_set248.not = icmp eq i8 %dj247, 0
  br i1 %dj_set248.not, label %page_done238, label %did_jump_exit245, !prof !0

page_done238:                                     ; preds = %page_slow237, %page_fast236
  %mem_val249 = phi i32 [ %page_val244, %page_fast236 ], [ %171, %page_slow237 ]
  store i32 %mem_val249, ptr %48, align 4
  %page257 = load ptr, ptr %page_slot40, align 8
  %page_mapped258.not = icmp eq ptr %page257, null
  br i1 %page_mapped258.not, label %page_slow253, label %page_fast252, !prof !1

did_jump_exit245:                                 ; preds = %page_slow237
  %next_pc385 = load i32, ptr %168, align 4
  br label %chain_exit

page_fast252:                                     ; preds = %page_done238
  %173 = and i32 %sp_dec32, 4095
  %page_offset259 = zext i32 %173 to i64
  %174 = getelementptr i8, ptr %page257, i64 %page_offset259
  %page_val260 = load i32, ptr %174, align 4
  br label %page_done254

page_slow253:                                     ; preds = %page_done238
  %175 = getelementptr i8, ptr %cpu, i64 188
  store i32 66412, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %177, align 4
  %178 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec32)
  %179 = getelementptr i8, ptr %cpu, i64 296
  %dj263 = load i8, ptr %179, align 1
  %dj_set264.not = icmp eq i8 %dj263, 0
  br i1 %dj_set264.not, label %page_done254, label %did_jump_exit261, !prof !0

page_done254:                                     ; preds = %page_slow253, %page_fast252
  %mem_val265 = phi i32 [ %page_val260, %page_fast252 ], [ %178, %page_slow253 ]
  store i32 %mem_val265, ptr %40, align 4
  %page274 = load ptr, ptr %page_slot24, align 8
  %page_mapped275.not = icmp eq ptr %page274, null
  br i1 %page_mapped275.not, label %page_slow270, label %page_fast269, !prof !1

did_jump_exit261:                                 ; preds = %page_slow253
  %next_pc387 = load i32, ptr %175, align 4
  br label %chain_exit

page_fast269:                                     ; preds = %page_done254
  %180 = and i32 %sp_dec17, 4095
  %page_offset276 = zext i32 %180 to i64
  %181 = getelementptr i8, ptr %page274, i64 %page_offset276
  %page_val277 = load i32, ptr %181, align 4
  br label %page_done271

page_slow270:                                     ; preds = %page_done254
  %182 = getelementptr i8, ptr %cpu, i64 188
  store i32 66412, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %184, align 4
  %185 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec17)
  %186 = getelementptr i8, ptr %cpu, i64 296
  %dj280 = load i8, ptr %186, align 1
  %dj_set281.not = icmp eq i8 %dj280, 0
  br i1 %dj_set281.not, label %page_done271, label %did_jump_exit278, !prof !0

page_done271:                                     ; preds = %page_slow270, %page_fast269
  %mem_val282 = phi i32 [ %page_val277, %page_fast269 ], [ %185, %page_slow270 ]
  store i32 %mem_val282, ptr %32, align 4
  %page291 = load ptr, ptr %page_slot9, align 8
  %page_mapped292.not = icmp eq ptr %page291, null
  br i1 %page_mapped292.not, label %page_slow287, label %page_fast286, !prof !1

did_jump_exit278:                                 ; preds = %page_slow270
  %next_pc389 = load i32, ptr %182, align 4
  br label %chain_exit

page_fast286:                                     ; preds = %page_done271
  %187 = and i32 %sp_dec1, 4095
  %page_offset293 = zext i32 %187 to i64
  %188 = getelementptr i8, ptr %page291, i64 %page_offset293
  %page_val294 = load i32, ptr %188, align 4
  br label %page_done288

page_slow287:                                     ; preds = %page_done271
  %189 = getelementptr i8, ptr %cpu, i64 188
  store i32 66412, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %191, align 4
  %192 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec1)
  %193 = getelementptr i8, ptr %cpu, i64 296
  %dj297 = load i8, ptr %193, align 1
  %dj_set298.not = icmp eq i8 %dj297, 0
  br i1 %dj_set298.not, label %page_done288, label %did_jump_exit295, !prof !0

page_done288:                                     ; preds = %page_slow287, %page_fast286
  %mem_val299 = phi i32 [ %page_val294, %page_fast286 ], [ %192, %page_slow287 ]
  store i32 %mem_val299, ptr %24, align 4
  %page308 = load ptr, ptr %page_slot, align 8
  %page_mapped309.not = icmp eq ptr %page308, null
  br i1 %page_mapped309.not, label %page_slow304, label %page_fast303, !prof !1

did_jump_exit295:                                 ; preds = %page_slow287
  %next_pc391 = load i32, ptr %189, align 4
  br label %chain_exit

page_fast303:                                     ; preds = %page_done288
  %194 = and i32 %sp_dec, 4095
  %page_offset310 = zext i32 %194 to i64
  %195 = getelementptr i8, ptr %page308, i64 %page_offset310
  %page_val311 = load i32, ptr %195, align 4
  br label %page_done305

page_slow304:                                     ; preds = %page_done288
  %196 = getelementptr i8, ptr %cpu, i64 188
  store i32 66412, ptr %196, align 4
  %197 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %198, align 4
  %199 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec)
  %200 = getelementptr i8, ptr %cpu, i64 296
  %dj314 = load i8, ptr %200, align 1
  %dj_set315.not = icmp eq i8 %dj314, 0
  br i1 %dj_set315.not, label %page_done305, label %did_jump_exit312, !prof !0

page_done305:                                     ; preds = %page_slow304, %page_fast303
  %mem_val316 = phi i32 [ %page_val311, %page_fast303 ], [ %199, %page_slow304 ]
  store i32 %mem_val316, ptr %11, align 4
  store i32 %sp, ptr %10, align 4
  %lsb = and i32 %mem_val232, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit312:                                 ; preds = %page_slow304
  %next_pc393 = load i32, ptr %196, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done305
  %201 = getelementptr i8, ptr %cpu, i64 188
  store i32 66414, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i64 308
  store i32 27, ptr %203, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc394 = load i32, ptr %201, align 4
  %204 = getelementptr i8, ptr %cpu, i64 296
  %205 = load i8, ptr %204, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave334, %chain_leave336, %chain_leave345, %chain_leave363, %chain_leave372, %chain_leave399
  %tail396.sink = phi i32 [ %tail396, %chain_leave399 ], [ 2, %chain_leave372 ], [ 2, %chain_leave363 ], [ 2, %chain_leave345 ], [ 2, %chain_leave336 ], [ 2, %chain_leave334 ]
  %packets.sink = phi i32 [ %packets, %chain_leave399 ], [ 23, %chain_leave372 ], [ 21, %chain_leave363 ], [ 10, %chain_leave345 ], [ 6, %chain_leave336 ], [ 4, %chain_leave334 ]
  %tail398.sink.ph = phi i8 [ %tail398, %chain_leave399 ], [ 1, %chain_leave372 ], [ 1, %chain_leave363 ], [ 1, %chain_leave345 ], [ 1, %chain_leave336 ], [ 1, %chain_leave334 ]
  %206 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail396.sink, ptr %206, align 4
  %207 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %207, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink418 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail398.sink = phi i8 [ 1, %entry ], [ %tail398.sink.ph, %common.ret.sink.split ]
  %208 = getelementptr i8, ptr %cpu, i64 %.sink418
  store i8 %tail398.sink, ptr %208, align 1
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531328
  %slot_pc = load i32, ptr %chain_slot, align 4
  %209 = icmp eq i32 %slot_pc, 66416
  br i1 %209, label %chain_hit, label %chain_leave334, !prof !0

chain_leave334:                                   ; preds = %chain_go, %brcc_taken
  store i32 66416, ptr %90, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 66416, ptr %90, align 4
  store i32 %chain_total, ptr %91, align 4
  %210 = getelementptr i8, ptr %chain_table, i64 531336
  %chain_fn = load ptr, ptr %210, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go335:                                      ; preds = %brt_taken
  %chain_slot340 = getelementptr i8, ptr %chain_table, i64 531328
  %slot_pc341 = load i32, ptr %chain_slot340, align 4
  %211 = icmp eq i32 %slot_pc341, 66416
  br i1 %211, label %chain_hit342, label %chain_leave336, !prof !0

chain_leave336:                                   ; preds = %chain_go335, %brt_taken
  store i32 66416, ptr %96, align 4
  br label %common.ret.sink.split

chain_hit342:                                     ; preds = %chain_go335
  store i32 66416, ptr %96, align 4
  store i32 %chain_total338, ptr %97, align 4
  %212 = getelementptr i8, ptr %chain_table, i64 531336
  %chain_fn343 = load ptr, ptr %212, align 8
  musttail call swifttailcc void %chain_fn343(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go344:                                      ; preds = %brcc_taken112
  %chain_slot349 = getelementptr i8, ptr %chain_table, i64 531328
  %slot_pc350 = load i32, ptr %chain_slot349, align 4
  %213 = icmp eq i32 %slot_pc350, 66416
  br i1 %213, label %chain_hit351, label %chain_leave345, !prof !0

chain_leave345:                                   ; preds = %chain_go344, %brcc_taken112
  store i32 66416, ptr %107, align 4
  br label %common.ret.sink.split

chain_hit351:                                     ; preds = %chain_go344
  store i32 66416, ptr %107, align 4
  store i32 %chain_total347, ptr %108, align 4
  %214 = getelementptr i8, ptr %chain_table, i64 531336
  %chain_fn352 = load ptr, ptr %214, align 8
  musttail call swifttailcc void %chain_fn352(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go362:                                      ; preds = %brt_taken193
  %chain_slot367 = getelementptr i8, ptr %chain_table, i64 531408
  %slot_pc368 = load i32, ptr %chain_slot367, align 4
  %215 = icmp eq i32 %slot_pc368, 66426
  br i1 %215, label %chain_hit369, label %chain_leave363, !prof !0

chain_leave363:                                   ; preds = %chain_go362, %brt_taken193
  store i32 66426, ptr %142, align 4
  br label %common.ret.sink.split

chain_hit369:                                     ; preds = %chain_go362
  store i32 66426, ptr %142, align 4
  store i32 %chain_total365, ptr %143, align 4
  %216 = getelementptr i8, ptr %chain_table, i64 531416
  %chain_fn370 = load ptr, ptr %216, align 8
  musttail call swifttailcc void %chain_fn370(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go371:                                      ; preds = %brt_taken203
  %chain_slot376 = getelementptr i8, ptr %chain_table, i64 531744
  %slot_pc377 = load i32, ptr %chain_slot376, align 4
  %217 = icmp eq i32 %slot_pc377, 66468
  br i1 %217, label %chain_hit378, label %chain_leave372, !prof !0

chain_leave372:                                   ; preds = %chain_go371, %brt_taken203
  store i32 66468, ptr %148, align 4
  br label %common.ret.sink.split

chain_hit378:                                     ; preds = %chain_go371
  store i32 66468, ptr %148, align 4
  store i32 %chain_total374, ptr %149, align 4
  %218 = getelementptr i8, ptr %chain_table, i64 531752
  %chain_fn379 = load ptr, ptr %218, align 8
  musttail call swifttailcc void %chain_fn379(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done305, %jump_misalign, %did_jump_exit312, %did_jump_exit295, %did_jump_exit278, %did_jump_exit261, %did_jump_exit245, %did_jump_exit228, %did_jump_exit212, %did_jump_exit181, %did_jump_exit174, %did_jump_exit156, %did_jump_exit149, %did_jump_exit131, %did_jump_exit124, %did_jump_exit99, %did_jump_exit92, %did_jump_exit78, %did_jump_exit64, %did_jump_exit60, %did_jump_exit44, %did_jump_exit28, %did_jump_exit13, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit28 ], [ 1, %did_jump_exit44 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %did_jump_exit78 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ], [ 13, %did_jump_exit124 ], [ 13, %did_jump_exit131 ], [ 16, %did_jump_exit149 ], [ 16, %did_jump_exit156 ], [ 19, %did_jump_exit174 ], [ 19, %did_jump_exit181 ], [ 25, %did_jump_exit212 ], [ 25, %did_jump_exit228 ], [ 26, %did_jump_exit245 ], [ 26, %did_jump_exit261 ], [ 26, %did_jump_exit278 ], [ 26, %did_jump_exit295 ], [ 26, %did_jump_exit312 ], [ 27, %jump_misalign ], [ 27, %page_done305 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc319, %did_jump_exit ], [ %next_pc321, %did_jump_exit13 ], [ %next_pc323, %did_jump_exit28 ], [ %next_pc325, %did_jump_exit44 ], [ %next_pc327, %did_jump_exit60 ], [ %next_pc328, %did_jump_exit64 ], [ %next_pc330, %did_jump_exit78 ], [ %next_pc332, %did_jump_exit92 ], [ %next_pc333, %did_jump_exit99 ], [ %next_pc354, %did_jump_exit124 ], [ %next_pc355, %did_jump_exit131 ], [ %next_pc357, %did_jump_exit149 ], [ %next_pc358, %did_jump_exit156 ], [ %next_pc360, %did_jump_exit174 ], [ %next_pc361, %did_jump_exit181 ], [ %next_pc381, %did_jump_exit212 ], [ %next_pc383, %did_jump_exit228 ], [ %next_pc385, %did_jump_exit245 ], [ %next_pc387, %did_jump_exit261 ], [ %next_pc389, %did_jump_exit278 ], [ %next_pc391, %did_jump_exit295 ], [ %next_pc393, %did_jump_exit312 ], [ %next_pc394, %jump_misalign ], [ %mem_val232, %page_done305 ]
  %tail396 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit13 ], [ 2, %did_jump_exit28 ], [ 2, %did_jump_exit44 ], [ 2, %did_jump_exit60 ], [ 2, %did_jump_exit64 ], [ 4, %did_jump_exit78 ], [ 4, %did_jump_exit92 ], [ 4, %did_jump_exit99 ], [ 2, %did_jump_exit124 ], [ 2, %did_jump_exit131 ], [ 2, %did_jump_exit149 ], [ 2, %did_jump_exit156 ], [ 2, %did_jump_exit174 ], [ 2, %did_jump_exit181 ], [ 4, %did_jump_exit212 ], [ 4, %did_jump_exit228 ], [ 2, %did_jump_exit245 ], [ 2, %did_jump_exit261 ], [ 2, %did_jump_exit278 ], [ 2, %did_jump_exit295 ], [ 2, %did_jump_exit312 ], [ 2, %jump_misalign ], [ 2, %page_done305 ]
  %tail398 = phi i8 [ %17, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj15, %did_jump_exit13 ], [ %dj30, %did_jump_exit28 ], [ %dj46, %did_jump_exit44 ], [ %dj62, %did_jump_exit60 ], [ %dj66, %did_jump_exit64 ], [ %dj80, %did_jump_exit78 ], [ %dj94, %did_jump_exit92 ], [ %dj101, %did_jump_exit99 ], [ %dj126, %did_jump_exit124 ], [ %dj133, %did_jump_exit131 ], [ %dj151, %did_jump_exit149 ], [ %dj158, %did_jump_exit156 ], [ %dj176, %did_jump_exit174 ], [ %dj183, %did_jump_exit181 ], [ %dj214, %did_jump_exit212 ], [ %dj230, %did_jump_exit228 ], [ %dj247, %did_jump_exit245 ], [ %dj263, %did_jump_exit261 ], [ %dj280, %did_jump_exit278 ], [ %dj297, %did_jump_exit295 ], [ %dj314, %did_jump_exit312 ], [ %205, %jump_misalign ], [ 1, %page_done305 ]
  %219 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets400 = load i32, ptr %219, align 4
  %chain_total401 = add nuw i32 %chain_packets400, %packets
  %220 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget402 = load atomic i32, ptr %220 monotonic, align 4, !range !2
  %221 = icmp ult i32 %chain_total401, %chain_budget402
  br i1 %221, label %chain_lookup, label %chain_leave399, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %222 = shl i32 %tail, 3
  %223 = and i32 %222, 1048560
  %224 = zext i32 %223 to i64
  %chain_slot403 = getelementptr i8, ptr %chain_table, i64 %224
  %slot_pc404 = load i32, ptr %chain_slot403, align 4
  %225 = icmp eq i32 %slot_pc404, %tail
  br i1 %225, label %chain_hit405, label %chain_leave399, !prof !0

chain_leave399:                                   ; preds = %chain_lookup, %chain_exit
  %226 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %226, align 4
  br label %common.ret.sink.split

chain_hit405:                                     ; preds = %chain_lookup
  %227 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %227, align 4
  store i32 %chain_total401, ptr %219, align 4
  %228 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %228, align 1
  %229 = getelementptr i8, ptr %chain_slot403, i64 8
  %chain_fn406 = load ptr, ptr %229, align 8
  musttail call swifttailcc void %chain_fn406(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
