
build-native-instruction-analysis/capture/bcore-llvm-branch/pc-65916-0-128876141358188.bin:     file format binary


Disassembly of section .data:

0000753650a02c6c <.data>:
    753650a02c6c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    753650a02c73:	70 01 01 00 
    753650a02c77:	b8 05 00 00 00       	mov    eax,0x5
    753650a02c7c:	b9 02 00 00 00       	mov    ecx,0x2
    753650a02c81:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    753650a02c88:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    753650a02c8f:	b8 28 01 00 00       	mov    eax,0x128
    753650a02c94:	e9 59 f0 ff e7       	jmp    0x753638a01cf2
    753650a02c99:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    753650a02ca0:	10 01 01 00 
    753650a02ca4:	b8 07 00 00 00       	mov    eax,0x7
    753650a02ca9:	b9 04 00 00 00       	mov    ecx,0x4
    753650a02cae:	eb d1                	jmp    0x753650a02c81
