; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010130(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65867
  %5 = icmp ult i32 %4, -27
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb54 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb54, -65867
  %8 = icmp ult i32 %7, -27
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010130, label %common.ret, !prof !0

insn_0x00010130:                                  ; preds = %entry
  %rs = load i32, ptr %cpu, align 4
  %lsl32 = shl i32 %rs, 5
  %10 = getelementptr i8, ptr %cpu, i64 4
  %an = lshr i32 %lsl32, 31
  %11 = getelementptr i8, ptr %cpu, i64 228
  %12 = getelementptr i8, ptr %cpu, i64 232
  %13 = getelementptr i8, ptr %cpu, i64 248
  %14 = getelementptr i8, ptr %cpu, i64 252
  %lsr = lshr i32 %rs, 27
  %or32 = or i32 %lsr, %lsl32
  store i32 %or32, ptr %cpu, align 4
  %15 = icmp eq i32 %or32, 0
  %az3 = zext i1 %15 to i32
  store i32 %az3, ptr %11, align 4
  store i32 %an, ptr %12, align 4
  %16 = getelementptr i8, ptr %cpu, i64 236
  store i32 0, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 240
  store i32 0, ptr %17, align 4
  store i32 0, ptr %13, align 4
  store i32 0, ptr %14, align 4
  %lo_kept = and i32 %lsl32, 65504
  %with_hi = or i32 %lo_kept, 2135556096
  store i32 %with_hi, ptr %10, align 4
  %18 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %20, align 4
  %sp1 = add i32 %sp, -4
  %21 = and i32 %sp, 3
  %.not = icmp eq i32 %21, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010130
  %22 = getelementptr i8, ptr %cpu, i64 188
  store i32 65852, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %24, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65852, i32 %sp1, i32 65536)
  %next_pc = load i32, ptr %22, align 4
  %25 = getelementptr i8, ptr %cpu, i64 296
  %26 = load i8, ptr %25, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010130
  %27 = lshr i32 %sp1, 12
  %page_index = zext i32 %27 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %28 = and i32 %sp1, 4095
  %page_offset = zext i32 %28 to i64
  %29 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %29, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %30 = getelementptr i8, ptr %cpu, i64 188
  store i32 65852, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %32, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %33 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %33, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %did_jump_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %sp2 = add i32 %sp, -8
  %34 = lshr i32 %sp2, 12
  %page_index10 = zext i32 %34 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13.not = icmp eq ptr %page12, null
  br i1 %page_mapped13.not, label %page_wr_slow8, label %page_wr_fast7, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %next_pc55 = load i32, ptr %30, align 4
  br label %chain_exit

page_wr_fast7:                                    ; preds = %page_wr_done
  %35 = and i32 %sp2, 4095
  %page_offset14 = zext i32 %35 to i64
  %36 = getelementptr i8, ptr %page12, i64 %page_offset14
  store i32 %fp, ptr %36, align 4
  br label %page_wr_done9

page_wr_slow8:                                    ; preds = %page_wr_done
  %37 = getelementptr i8, ptr %cpu, i64 188
  store i32 65852, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %39, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %40 = getelementptr i8, ptr %cpu, i64 296
  %dj17 = load i8, ptr %40, align 1
  %dj_set18.not = icmp eq i8 %dj17, 0
  br i1 %dj_set18.not, label %page_wr_done9, label %did_jump_exit15, !prof !0

page_wr_done9:                                    ; preds = %page_wr_slow8, %page_wr_fast7
  store i32 %sp2, ptr %20, align 4
  store i32 %sp2, ptr %18, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not70 = icmp eq i8 %cec_pending, 0
  br i1 %.not70, label %insn_0x00010140, label %cec_check, !prof !0

did_jump_exit15:                                  ; preds = %page_wr_slow8
  %next_pc57 = load i32, ptr %37, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done9
  %41 = getelementptr i8, ptr %cpu, i64 188
  store i32 65856, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %43, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %44 = getelementptr i8, ptr %cpu, i64 296
  %dj21 = load i8, ptr %44, align 1
  %dj_set22.not = icmp eq i8 %dj21, 0
  br i1 %dj_set22.not, label %insn_0x00010140, label %did_jump_exit19, !prof !0

did_jump_exit19:                                  ; preds = %cec_check
  %next_pc58 = load i32, ptr %41, align 4
  br label %chain_exit

insn_0x00010140:                                  ; preds = %page_wr_done9, %cec_check
  store i32 2135587861, ptr %10, align 4
  %add32 = add i32 %or32, 2135587861
  store i32 %add32, ptr %cpu, align 4
  %flgn = lshr i32 %add32, 31
  %45 = xor i32 %an, -1
  %46 = and i32 %flgn, %45
  %47 = icmp ugt i32 %or32, -2135587862
  %ac0 = zext i1 %47 to i32
  %48 = icmp eq i32 %add32, 0
  %az23 = zext i1 %48 to i32
  store i32 %az23, ptr %11, align 4
  store i32 %flgn, ptr %12, align 4
  %49 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %49, align 4
  %50 = or i32 %vs_cur, %46
  store i32 %46, ptr %13, align 4
  store i32 %46, ptr %14, align 4
  store i32 %50, ptr %49, align 4
  store i32 %ac0, ptr %16, align 4
  store i32 %ac0, ptr %17, align 4
  %page29 = load ptr, ptr %page_slot11, align 8
  %page_mapped30.not = icmp eq ptr %page29, null
  br i1 %page_mapped30.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x00010140
  %51 = and i32 %sp2, 4095
  %page_offset31 = zext i32 %51 to i64
  %52 = getelementptr i8, ptr %page29, i64 %page_offset31
  %page_val = load i32, ptr %52, align 4
  br label %data_aligned38

page_slow:                                        ; preds = %insn_0x00010140
  %53 = getelementptr i8, ptr %cpu, i64 188
  store i32 65862, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %55, align 4
  %56 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %57 = getelementptr i8, ptr %cpu, i64 296
  %dj34 = load i8, ptr %57, align 1
  %dj_set35.not = icmp eq i8 %dj34, 0
  br i1 %dj_set35.not, label %data_aligned38, label %did_jump_exit32, !prof !0

did_jump_exit32:                                  ; preds = %page_slow
  %next_pc60 = load i32, ptr %53, align 4
  br label %chain_exit

data_aligned38:                                   ; preds = %page_fast, %page_slow
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %56, %page_slow ]
  %page44 = load ptr, ptr %page_slot, align 8
  %page_mapped45.not = icmp eq ptr %page44, null
  br i1 %page_mapped45.not, label %page_slow40, label %page_fast39, !prof !1

page_fast39:                                      ; preds = %data_aligned38
  %58 = and i32 %sp1, 4095
  %page_offset46 = zext i32 %58 to i64
  %59 = getelementptr i8, ptr %page44, i64 %page_offset46
  %page_val47 = load i32, ptr %59, align 4
  br label %page_done41

page_slow40:                                      ; preds = %data_aligned38
  %60 = getelementptr i8, ptr %cpu, i64 188
  store i32 65862, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %62, align 4
  %63 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %64 = getelementptr i8, ptr %cpu, i64 296
  %dj50 = load i8, ptr %64, align 1
  %dj_set51.not = icmp eq i8 %dj50, 0
  br i1 %dj_set51.not, label %page_done41, label %did_jump_exit48, !prof !0

page_done41:                                      ; preds = %page_slow40, %page_fast39
  %mem_val52 = phi i32 [ %page_val47, %page_fast39 ], [ %63, %page_slow40 ]
  store i32 %mem_val, ptr %20, align 4
  store i32 %mem_val52, ptr %19, align 4
  store i32 %sp, ptr %18, align 4
  %lsb = and i32 %mem_val52, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit48:                                  ; preds = %page_slow40
  %next_pc62 = load i32, ptr %60, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done41
  %65 = getelementptr i8, ptr %cpu, i64 188
  store i32 65866, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %67, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc63 = load i32, ptr %65, align 4
  %68 = getelementptr i8, ptr %cpu, i64 296
  %69 = load i8, ptr %68, align 1
  br label %chain_exit

common.ret:                                       ; preds = %entry, %chain_leave68
  %.sink71 = phi i64 [ 296, %chain_leave68 ], [ 357, %entry ]
  %tail67.sink = phi i8 [ %tail67, %chain_leave68 ], [ 1, %entry ]
  %70 = getelementptr i8, ptr %cpu, i64 %.sink71
  store i8 %tail67.sink, ptr %70, align 1
  ret void

chain_exit:                                       ; preds = %page_done41, %jump_misalign, %did_jump_exit48, %did_jump_exit32, %did_jump_exit19, %did_jump_exit15, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %did_jump_exit15 ], [ 5, %did_jump_exit19 ], [ 8, %did_jump_exit32 ], [ 8, %did_jump_exit48 ], [ 9, %jump_misalign ], [ 9, %page_done41 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc55, %did_jump_exit ], [ %next_pc57, %did_jump_exit15 ], [ %next_pc58, %did_jump_exit19 ], [ %next_pc60, %did_jump_exit32 ], [ %next_pc62, %did_jump_exit48 ], [ %next_pc63, %jump_misalign ], [ %mem_val52, %page_done41 ]
  %tail65 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %did_jump_exit15 ], [ 4, %did_jump_exit19 ], [ 4, %did_jump_exit32 ], [ 4, %did_jump_exit48 ], [ 2, %jump_misalign ], [ 2, %page_done41 ]
  %tail67 = phi i8 [ %26, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj17, %did_jump_exit15 ], [ %dj21, %did_jump_exit19 ], [ %dj34, %did_jump_exit32 ], [ %dj50, %did_jump_exit48 ], [ %69, %jump_misalign ], [ 1, %page_done41 ]
  %71 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %71, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %72 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %72 monotonic, align 4, !range !2
  %73 = icmp ult i32 %chain_total, %chain_budget
  br i1 %73, label %chain_lookup, label %chain_leave68, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %74 = shl i32 %tail, 3
  %75 = and i32 %74, 1048560
  %76 = zext i32 %75 to i64
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %76
  %slot_pc = load i32, ptr %chain_slot, align 4
  %77 = icmp eq i32 %slot_pc, %tail
  br i1 %77, label %chain_hit, label %chain_leave68, !prof !0

chain_leave68:                                    ; preds = %chain_lookup, %chain_exit
  %78 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail65, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %80, align 4
  br label %common.ret

chain_hit:                                        ; preds = %chain_lookup
  %81 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %81, align 4
  store i32 %chain_total, ptr %71, align 4
  %82 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %82, align 1
  %83 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %83, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
