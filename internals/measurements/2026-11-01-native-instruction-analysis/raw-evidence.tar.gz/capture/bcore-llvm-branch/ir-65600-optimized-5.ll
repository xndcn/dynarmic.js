; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010040(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65679
  %5 = icmp ult i32 %4, -79
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb153 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb153, -65679
  %8 = icmp ult i32 %7, -79
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010040, label %lb_guard_miss, !prof !0

insn_0x00010040:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 40
  store i32 61444, ptr %10, align 4
  %page_slot = getelementptr ptr, ptr %page_table, i64 15
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x00010040
  %11 = getelementptr i8, ptr %page, i64 4
  %page_val = load i32, ptr %11, align 4
  br label %page_done

page_slow:                                        ; preds = %insn_0x00010040
  %12 = getelementptr i8, ptr %cpu, i64 188
  store i32 65606, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %14, align 4
  %15 = tail call i32 @mem_read32(ptr %mem, i32 61444)
  %16 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %16, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_done, label %chain_exit, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %15, %page_slow ]
  %17 = getelementptr i8, ptr %cpu, i64 16
  store i32 %mem_val, ptr %17, align 4
  store i32 61448, ptr %10, align 4
  %page7 = load ptr, ptr %page_slot, align 8
  %page_mapped8.not = icmp eq ptr %page7, null
  br i1 %page_mapped8.not, label %page_slow4, label %page_fast3, !prof !1

page_fast3:                                       ; preds = %page_done
  %18 = getelementptr i8, ptr %page7, i64 8
  %page_val9 = load i32, ptr %18, align 4
  br label %page_done5

page_slow4:                                       ; preds = %page_done
  %19 = getelementptr i8, ptr %cpu, i64 188
  store i32 65610, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %21, align 4
  %22 = tail call i32 @mem_read32(ptr %mem, i32 61448)
  %23 = getelementptr i8, ptr %cpu, i64 296
  %dj12 = load i8, ptr %23, align 1
  %dj_set13.not = icmp eq i8 %dj12, 0
  br i1 %dj_set13.not, label %page_done5, label %chain_exit, !prof !0

page_done5:                                       ; preds = %page_slow4, %page_fast3
  %mem_val14 = phi i32 [ %page_val9, %page_fast3 ], [ %22, %page_slow4 ]
  store i32 %mem_val14, ptr %10, align 4
  store i32 1, ptr %cpu, align 4
  %24 = getelementptr i8, ptr %cpu, i64 44
  store i32 61460, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %25, align 4
  %addr = add i32 %fp, -4
  %26 = and i32 %fp, 3
  %.not = icmp eq i32 %26, 0
  br i1 %.not, label %data_aligned16, label %data_misaligned15, !prof !0

data_misaligned15:                                ; preds = %page_done5
  %27 = getelementptr i8, ptr %cpu, i64 188
  store i32 65620, ptr %27, align 4
  %28 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %29, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65620, i32 %addr, i32 65536)
  br label %chain_exit

data_aligned16:                                   ; preds = %page_done5
  %30 = lshr i32 %addr, 12
  %page_index = zext i32 %30 to i64
  %page_slot17 = getelementptr ptr, ptr %page_table, i64 %page_index
  %page18 = load ptr, ptr %page_slot17, align 8
  %page_mapped19.not = icmp eq ptr %page18, null
  br i1 %page_mapped19.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned16
  %31 = and i32 %addr, 4095
  %page_offset = zext i32 %31 to i64
  %32 = getelementptr i8, ptr %page18, i64 %page_offset
  store i32 %mem_val14, ptr %32, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned16
  %33 = getelementptr i8, ptr %cpu, i64 188
  store i32 65620, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %35, align 4
  tail call void @mem_write32(ptr %mem, i32 %addr, i32 %mem_val14)
  %36 = getelementptr i8, ptr %cpu, i64 296
  %dj22 = load i8, ptr %36, align 1
  %dj_set23.not = icmp eq i8 %dj22, 0
  br i1 %dj_set23.not, label %page_wr_done, label %chain_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not186 = icmp eq i8 %cec_pending, 0
  br i1 %.not186, label %insn_0x00010056, label %cec_check, !prof !0

cec_check:                                        ; preds = %page_wr_done
  %37 = getelementptr i8, ptr %cpu, i64 188
  store i32 65622, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %39, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %40 = getelementptr i8, ptr %cpu, i64 296
  %dj26 = load i8, ptr %40, align 1
  %dj_set27.not = icmp eq i8 %dj26, 0
  br i1 %dj_set27.not, label %insn_0x00010056, label %chain_exit, !prof !0

insn_0x00010056:                                  ; preds = %page_wr_done, %cec_check
  store i32 61452, ptr %10, align 4
  %page34 = load ptr, ptr %page_slot, align 8
  %page_mapped35.not = icmp eq ptr %page34, null
  br i1 %page_mapped35.not, label %page_slow31, label %page_fast30, !prof !1

page_fast30:                                      ; preds = %insn_0x00010056
  %41 = getelementptr i8, ptr %page34, i64 12
  %page_val36 = load i32, ptr %41, align 4
  br label %page_done32

page_slow31:                                      ; preds = %insn_0x00010056
  %42 = getelementptr i8, ptr %cpu, i64 188
  store i32 65628, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %44, align 4
  %45 = tail call i32 @mem_read32(ptr %mem, i32 61452)
  %46 = getelementptr i8, ptr %cpu, i64 296
  %dj39 = load i8, ptr %46, align 1
  %dj_set40.not = icmp eq i8 %dj39, 0
  br i1 %dj_set40.not, label %page_done32, label %chain_exit, !prof !0

page_done32:                                      ; preds = %page_slow31, %page_fast30
  %mem_val41 = phi i32 [ %page_val36, %page_fast30 ], [ %45, %page_slow31 ]
  store i32 %mem_val41, ptr %10, align 4
  %47 = getelementptr i8, ptr %cpu, i64 52
  %48 = getelementptr i8, ptr %cpu, i64 48
  %old42 = load i32, ptr %48, align 4
  %lo_kept43 = and i32 %old42, 65535
  %with_hi44 = or i32 %lo_kept43, 16777216
  store i32 %with_hi44, ptr %48, align 4
  store i32 61464, ptr %47, align 4
  %addr45 = add i32 %fp, -8
  %49 = lshr i32 %addr45, 12
  %page_index51 = zext i32 %49 to i64
  %page_slot52 = getelementptr ptr, ptr %page_table, i64 %page_index51
  %page53 = load ptr, ptr %page_slot52, align 8
  %page_mapped54.not = icmp eq ptr %page53, null
  br i1 %page_mapped54.not, label %page_wr_slow49, label %page_wr_fast48, !prof !1

page_wr_fast48:                                   ; preds = %page_done32
  %50 = and i32 %addr45, 4095
  %page_offset55 = zext i32 %50 to i64
  %51 = getelementptr i8, ptr %page53, i64 %page_offset55
  store i32 %mem_val41, ptr %51, align 4
  br label %page_wr_done50

page_wr_slow49:                                   ; preds = %page_done32
  %52 = getelementptr i8, ptr %cpu, i64 188
  store i32 65642, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %54, align 4
  tail call void @mem_write32(ptr %mem, i32 %addr45, i32 %mem_val41)
  %55 = getelementptr i8, ptr %cpu, i64 296
  %dj58 = load i8, ptr %55, align 1
  %dj_set59.not = icmp eq i8 %dj58, 0
  br i1 %dj_set59.not, label %page_wr_done50, label %chain_exit, !prof !0

page_wr_done50:                                   ; preds = %page_wr_slow49, %page_wr_fast48
  %cec_pending60 = load i8, ptr %cec_pending_flag, align 1
  %.not188 = icmp eq i8 %cec_pending60, 0
  br i1 %.not188, label %insn_0x0001006c, label %cec_check61, !prof !0

cec_check61:                                      ; preds = %page_wr_done50
  %56 = getelementptr i8, ptr %cpu, i64 188
  store i32 65644, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %58, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %59 = getelementptr i8, ptr %cpu, i64 296
  %dj65 = load i8, ptr %59, align 1
  %dj_set66.not = icmp eq i8 %dj65, 0
  br i1 %dj_set66.not, label %insn_0x0001006c, label %chain_exit, !prof !0

insn_0x0001006c:                                  ; preds = %page_wr_done50, %cec_check61
  store i32 61456, ptr %10, align 4
  %page78 = load ptr, ptr %page_slot, align 8
  %page_mapped79.not = icmp eq ptr %page78, null
  br i1 %page_mapped79.not, label %page_wr_slow74, label %page_wr_fast73, !prof !1

page_wr_fast73:                                   ; preds = %insn_0x0001006c
  %60 = getelementptr i8, ptr %page78, i64 16
  store i32 1, ptr %60, align 4
  br label %page_wr_done75

page_wr_slow74:                                   ; preds = %insn_0x0001006c
  %61 = getelementptr i8, ptr %cpu, i64 188
  store i32 65652, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %63, align 4
  tail call void @mem_write32(ptr %mem, i32 61456, i32 1)
  %64 = getelementptr i8, ptr %cpu, i64 296
  %dj83 = load i8, ptr %64, align 1
  %dj_set84.not = icmp eq i8 %dj83, 0
  br i1 %dj_set84.not, label %page_wr_done75, label %chain_exit, !prof !0

page_wr_done75:                                   ; preds = %page_wr_slow74, %page_wr_fast73
  %cec_pending85 = load i8, ptr %cec_pending_flag, align 1
  %.not189 = icmp eq i8 %cec_pending85, 0
  br i1 %.not189, label %insn_0x00010076, label %cec_check86, !prof !0

cec_check86:                                      ; preds = %page_wr_done75
  %65 = getelementptr i8, ptr %cpu, i64 188
  store i32 65654, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %67, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %68 = getelementptr i8, ptr %cpu, i64 296
  %dj90 = load i8, ptr %68, align 1
  %dj_set91.not = icmp eq i8 %dj90, 0
  br i1 %dj_set91.not, label %insn_0x00010076, label %chain_exit, !prof !0

insn_0x00010076:                                  ; preds = %page_wr_done75, %cec_check86
  store i32 0, ptr %cpu, align 4
  %page98 = load ptr, ptr %page_slot, align 8
  %page_mapped99.not = icmp eq ptr %page98, null
  br i1 %page_mapped99.not, label %page_wr_slow95, label %page_wr_fast94, !prof !1

page_wr_fast94:                                   ; preds = %insn_0x00010076
  %69 = getelementptr i8, ptr %page98, i64 20
  store i32 0, ptr %69, align 4
  br label %page_wr_done96

page_wr_slow95:                                   ; preds = %insn_0x00010076
  %70 = getelementptr i8, ptr %cpu, i64 188
  store i32 65656, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i64 308
  store i32 21, ptr %72, align 4
  tail call void @mem_write32(ptr %mem, i32 61460, i32 0)
  %73 = getelementptr i8, ptr %cpu, i64 296
  %dj102 = load i8, ptr %73, align 1
  %dj_set103.not = icmp eq i8 %dj102, 0
  br i1 %dj_set103.not, label %page_wr_done96, label %chain_exit, !prof !0

page_wr_done96:                                   ; preds = %page_wr_slow95, %page_wr_fast94
  %cec_pending104 = load i8, ptr %cec_pending_flag, align 1
  %.not190 = icmp eq i8 %cec_pending104, 0
  br i1 %.not190, label %insn_0x0001007a, label %cec_check105, !prof !0

cec_check105:                                     ; preds = %page_wr_done96
  %74 = getelementptr i8, ptr %cpu, i64 188
  store i32 65658, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i64 308
  store i32 21, ptr %76, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %77 = getelementptr i8, ptr %cpu, i64 296
  %dj109 = load i8, ptr %77, align 1
  %dj_set110.not = icmp eq i8 %dj109, 0
  br i1 %dj_set110.not, label %insn_0x0001007a, label %chain_exit, !prof !0

insn_0x0001007a:                                  ; preds = %page_wr_done96, %cec_check105
  %78 = getelementptr i8, ptr %cpu, i64 28
  store i32 0, ptr %78, align 4
  store i32 16777216, ptr %48, align 4
  %79 = getelementptr i8, ptr %cpu, i64 24
  store i32 0, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 20
  store i32 1, ptr %80, align 4
  %page121 = load ptr, ptr %page_slot17, align 8
  %page_mapped122.not = icmp eq ptr %page121, null
  br i1 %page_mapped122.not, label %page_slow117, label %page_fast116, !prof !1

page_fast116:                                     ; preds = %insn_0x0001007a
  %81 = and i32 %addr, 4095
  %page_offset123 = zext i32 %81 to i64
  %82 = getelementptr i8, ptr %page121, i64 %page_offset123
  %page_val124 = load i32, ptr %82, align 4
  br label %page_done118

page_slow117:                                     ; preds = %insn_0x0001007a
  %83 = getelementptr i8, ptr %cpu, i64 188
  store i32 65668, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i64 292
  store i32 8, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 308
  store i32 26, ptr %85, align 4
  %86 = tail call i32 @mem_read32(ptr %mem, i32 %addr)
  %87 = getelementptr i8, ptr %cpu, i64 296
  %dj127 = load i8, ptr %87, align 1
  %dj_set128.not = icmp eq i8 %dj127, 0
  br i1 %dj_set128.not, label %page_done118, label %chain_exit, !prof !0

page_done118:                                     ; preds = %page_slow117, %page_fast116
  %mem_val129 = phi i32 [ %page_val124, %page_fast116 ], [ %86, %page_slow117 ]
  store i32 %mem_val, ptr %cpu, align 4
  %88 = getelementptr i8, ptr %cpu, i64 4
  store i32 %mem_val129, ptr %88, align 4
  %page138 = load ptr, ptr %page_slot52, align 8
  %page_mapped139.not = icmp eq ptr %page138, null
  br i1 %page_mapped139.not, label %page_slow134, label %page_fast133, !prof !1

page_fast133:                                     ; preds = %page_done118
  %89 = and i32 %addr45, 4095
  %page_offset140 = zext i32 %89 to i64
  %90 = getelementptr i8, ptr %page138, i64 %page_offset140
  %page_val141 = load i32, ptr %90, align 4
  br label %page_done135

page_slow134:                                     ; preds = %page_done118
  %91 = getelementptr i8, ptr %cpu, i64 188
  store i32 65676, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 308
  store i32 27, ptr %93, align 4
  %94 = tail call i32 @mem_read32(ptr %mem, i32 %addr45)
  %95 = getelementptr i8, ptr %cpu, i64 296
  %dj144 = load i8, ptr %95, align 1
  %dj_set145.not = icmp eq i8 %dj144, 0
  br i1 %dj_set145.not, label %page_done135, label %chain_exit, !prof !0

page_done135:                                     ; preds = %page_slow134, %page_fast133
  %mem_val146 = phi i32 [ %page_val141, %page_fast133 ], [ %94, %page_slow134 ]
  %96 = getelementptr i8, ptr %cpu, i64 8
  store i32 %mem_val146, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 152
  %lc = load i32, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i64 144
  %lt = load i32, ptr %98, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %guard_lb, 65678
  %hwloop_cond = and i1 %at_lb, %lc_gt1
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65682
  %99 = getelementptr i8, ptr %cpu, i64 156
  %lc147 = load i32, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 148
  %lt148 = load i32, ptr %100, align 4
  %lc_gt1149 = icmp ugt i32 %lc147, 1
  %at_lb150 = icmp eq i32 %guard_lb153, 65678
  %hwloop_cond151 = and i1 %at_lb150, %lc_gt1149
  %hwloop_rets152 = select i1 %hwloop_cond151, i32 %lt148, i32 %hwloop_rets
  %101 = getelementptr i8, ptr %cpu, i64 168
  store i32 %hwloop_rets152, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %103, align 4
  %chain_total = add nuw i32 %chain_packets, 28
  %104 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %104 monotonic, align 4, !range !2
  %105 = icmp ult i32 %chain_total, %chain_budget
  br i1 %105, label %chain_go, label %chain_leave175, !prof !0

common.ret:                                       ; preds = %chain_leave178, %chain_leave175, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %106 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %106, align 1
  br label %common.ret

chain_go:                                         ; preds = %page_done135
  %chain_slot = getelementptr i8, ptr %chain_table, i64 530752
  %slot_pc = load i32, ptr %chain_slot, align 4
  %107 = icmp eq i32 %slot_pc, 66344
  br i1 %107, label %chain_hit, label %chain_leave175, !prof !0

chain_leave175:                                   ; preds = %chain_go, %page_done135
  store i32 66344, ptr %102, align 4
  %108 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i64 308
  store i32 28, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %110, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 66344, ptr %102, align 4
  store i32 %chain_total, ptr %103, align 4
  %111 = getelementptr i8, ptr %chain_table, i64 530760
  %chain_fn = load ptr, ptr %111, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_slow134, %page_slow117, %cec_check105, %page_wr_slow95, %cec_check86, %page_wr_slow74, %cec_check61, %page_wr_slow49, %page_slow31, %cec_check, %page_wr_slow, %page_slow4, %page_slow, %data_misaligned15
  %packets = phi i32 [ 9, %data_misaligned15 ], [ 3, %page_slow ], [ 5, %page_slow4 ], [ 9, %page_wr_slow ], [ 9, %cec_check ], [ 12, %page_slow31 ], [ 16, %page_wr_slow49 ], [ 16, %cec_check61 ], [ 19, %page_wr_slow74 ], [ 19, %cec_check86 ], [ 21, %page_wr_slow95 ], [ 21, %cec_check105 ], [ 26, %page_slow117 ], [ 27, %page_slow134 ]
  %tail = phi i32 [ 2, %data_misaligned15 ], [ 2, %page_slow ], [ 2, %page_slow4 ], [ 2, %page_wr_slow ], [ 2, %cec_check ], [ 2, %page_slow31 ], [ 2, %page_wr_slow49 ], [ 2, %cec_check61 ], [ 2, %page_wr_slow74 ], [ 2, %cec_check86 ], [ 2, %page_wr_slow95 ], [ 2, %cec_check105 ], [ 8, %page_slow117 ], [ 2, %page_slow134 ]
  %next_pc176.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc176 = load i32, ptr %next_pc176.in, align 4
  %112 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets179 = load i32, ptr %112, align 4
  %chain_total180 = add nuw i32 %chain_packets179, %packets
  %113 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget181 = load atomic i32, ptr %113 monotonic, align 4, !range !2
  %114 = icmp ult i32 %chain_total180, %chain_budget181
  br i1 %114, label %chain_lookup, label %chain_leave178, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %115 = shl i32 %next_pc176, 3
  %116 = and i32 %115, 1048560
  %117 = zext i32 %116 to i64
  %chain_slot182 = getelementptr i8, ptr %chain_table, i64 %117
  %slot_pc183 = load i32, ptr %chain_slot182, align 4
  %118 = icmp eq i32 %slot_pc183, %next_pc176
  br i1 %118, label %chain_hit184, label %chain_leave178, !prof !0

chain_leave178:                                   ; preds = %chain_lookup, %chain_exit
  %119 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %120, align 4
  br label %common.ret

chain_hit184:                                     ; preds = %chain_lookup
  store i32 %chain_total180, ptr %112, align 4
  %121 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %121, align 1
  %122 = getelementptr i8, ptr %chain_slot182, i64 8
  %chain_fn185 = load ptr, ptr %122, align 8
  musttail call swifttailcc void %chain_fn185(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
