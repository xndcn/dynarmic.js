
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65682-0-128835395788724.bin:     file format binary


Disassembly of section .data:

0000752cd4001fb4 <.data>:
    752cd4001fb4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    752cd4001fbb:	c0 00 01 00 
    752cd4001fbf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001fc6:	02 00 00 00 
    752cd4001fca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4001fd1:	02 00 00 00 
    752cd4001fd5:	e9 35 f3 ff e7       	jmp    0x752cbc00130f
    752cd4001fda:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    752cd4001fe1:	01 
    752cd4001fe2:	58                   	pop    rax
    752cd4001fe3:	c2 08 00             	ret    0x8
    752cd4001fe6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    752cd4001fed:	28 04 01 00 
    752cd4001ff1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4001ff8:	04 00 00 00 
    752cd4001ffc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    752cd4002003:	04 00 00 00 
    752cd4002007:	e9 03 f3 ff e7       	jmp    0x752cbc00130f
    752cd400200c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    752cd4002013:	96 00 01 00 
    752cd4002017:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400201e:	02 00 00 00 
    752cd4002022:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd4002029:	03 00 00 00 
    752cd400202d:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4002034:	57 00 00 
    752cd4002037:	4c 89 ef             	mov    rdi,r13
    752cd400203a:	4c 89 f6             	mov    rsi,r14
    752cd400203d:	ba 96 00 01 00       	mov    edx,0x10096
    752cd4002042:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4002048:	ff d0                	call   rax
    752cd400204a:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    752cd4002051:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cd4002058:	83 c0 03             	add    eax,0x3
    752cd400205b:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cd4002062:	39 d0                	cmp    eax,edx
    752cd4002064:	0f 83 b6 00 00 00    	jae    0x752cd4002120
    752cd400206a:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    752cd4002071:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cd4002077:	41 39 0c 17          	cmp    DWORD PTR [r15+rdx*1],ecx
    752cd400207b:	0f 85 9f 00 00 00    	jne    0x752cd4002120
    752cd4002081:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cd4002088:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cd400208f:	00 
    752cd4002090:	49 8b 44 17 08       	mov    rax,QWORD PTR [r15+rdx*1+0x8]
    752cd4002095:	59                   	pop    rcx
    752cd4002096:	ff e0                	jmp    rax
    752cd4002098:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    752cd400209f:	96 00 01 00 
    752cd40020a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40020aa:	02 00 00 00 
    752cd40020ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40020b5:	03 00 00 00 
    752cd40020b9:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40020c0:	57 00 00 
    752cd40020c3:	4c 89 f7             	mov    rdi,r14
    752cd40020c6:	89 ce                	mov    esi,ecx
    752cd40020c8:	ff d0                	call   rax
    752cd40020ca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd40020d1:	00 
    752cd40020d2:	0f 84 92 f1 ff e7    	je     0x752cbc00126a
    752cd40020d8:	e9 6d ff ff ff       	jmp    0x752cd400204a
    752cd40020dd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10098
    752cd40020e4:	98 00 01 00 
    752cd40020e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40020ef:	02 00 00 00 
    752cd40020f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40020fa:	03 00 00 00 
    752cd40020fe:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4002105:	57 00 00 
    752cd4002108:	4c 89 ef             	mov    rdi,r13
    752cd400210b:	ff d0                	call   rax
    752cd400210d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4002114:	00 
    752cd4002115:	0f 84 5a f1 ff e7    	je     0x752cbc001275
    752cd400211b:	e9 2a ff ff ff       	jmp    0x752cd400204a
    752cd4002120:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002127:	02 00 00 00 
    752cd400212b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd4002132:	03 00 00 00 
    752cd4002136:	58                   	pop    rax
    752cd4002137:	c2 08 00             	ret    0x8
