
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65668-0-128834993138400.bin:     file format binary


Disassembly of section .data:

0000752cbc002ae0 <.data>:
    752cbc002ae0:	48 83 ec 18          	sub    rsp,0x18
    752cbc002ae4:	b8 71 ff fe ff       	mov    eax,0xfffeff71
    752cbc002ae9:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    752cbc002af0:	01 c1                	add    ecx,eax
    752cbc002af2:	83 f9 f4             	cmp    ecx,0xfffffff4
    752cbc002af5:	0f 87 44 0c 00 18    	ja     0x752cd400373f
    752cbc002afb:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    752cbc002b02:	83 f8 f4             	cmp    eax,0xfffffff4
    752cbc002b05:	0f 87 34 0c 00 18    	ja     0x752cd400373f
    752cbc002b0b:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    752cbc002b12:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    752cbc002b16:	8d 4b fc             	lea    ecx,[rbx-0x4]
    752cbc002b19:	f6 c3 03             	test   bl,0x3
    752cbc002b1c:	0f 85 2c 0c 00 18    	jne    0x752cd400374e
    752cbc002b22:	4d 8b bd 38 01 00 00 	mov    r15,QWORD PTR [r13+0x138]
    752cbc002b29:	41 8b 6d 10          	mov    ebp,DWORD PTR [r13+0x10]
    752cbc002b2d:	89 c8                	mov    eax,ecx
    752cbc002b2f:	c1 e8 0c             	shr    eax,0xc
    752cbc002b32:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    752cbc002b36:	48 85 c0             	test   rax,rax
    752cbc002b39:	0f 84 b2 0c 00 18    	je     0x752cd40037f1
    752cbc002b3f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc002b45:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    752cbc002b48:	41 89 6d 00          	mov    DWORD PTR [r13+0x0],ebp
    752cbc002b4c:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    752cbc002b50:	41 8b ad a0 00 00 00 	mov    ebp,DWORD PTR [r13+0xa0]
    752cbc002b57:	45 8b a5 a4 00 00 00 	mov    r12d,DWORD PTR [r13+0xa4]
    752cbc002b5e:	83 c3 f8             	add    ebx,0xfffffff8
    752cbc002b61:	89 d8                	mov    eax,ebx
    752cbc002b63:	c1 e8 0c             	shr    eax,0xc
    752cbc002b66:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    752cbc002b6a:	48 85 c0             	test   rax,rax
    752cbc002b6d:	0f 84 cc 0c 00 18    	je     0x752cd400383f
    752cbc002b73:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    752cbc002b79:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    752cbc002b7c:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    752cbc002b80:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    752cbc002b87:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    752cbc002b8e:	02 
    752cbc002b8f:	b8 92 00 01 00       	mov    eax,0x10092
    752cbc002b94:	ba 92 00 01 00       	mov    edx,0x10092
    752cbc002b99:	72 07                	jb     0x752cbc002ba2
    752cbc002b9b:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    752cbc002ba2:	81 fd 8e 00 01 00    	cmp    ebp,0x1008e
    752cbc002ba8:	0f 44 c2             	cmove  eax,edx
    752cbc002bab:	89 c2                	mov    edx,eax
    752cbc002bad:	83 f9 02             	cmp    ecx,0x2
    752cbc002bb0:	72 07                	jb     0x752cbc002bb9
    752cbc002bb2:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    752cbc002bb9:	41 81 fc 8e 00 01 00 	cmp    r12d,0x1008e
    752cbc002bc0:	0f 44 c2             	cmove  eax,edx
    752cbc002bc3:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    752cbc002bca:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc002bd1:	28 03 01 00 
    752cbc002bd5:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc002bdc:	83 c0 03             	add    eax,0x3
    752cbc002bdf:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc002be6:	39 c8                	cmp    eax,ecx
    752cbc002be8:	73 2b                	jae    0x752cbc002c15
    752cbc002bea:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    752cbc002bf1:	03 01 00 
    752cbc002bf4:	75 1f                	jne    0x752cbc002c15
    752cbc002bf6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc002bfd:	28 03 01 00 
    752cbc002c01:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc002c08:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    752cbc002c0f:	48 83 c4 18          	add    rsp,0x18
    752cbc002c13:	ff e0                	jmp    rax
    752cbc002c15:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc002c1c:	28 03 01 00 
    752cbc002c20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cbc002c27:	04 00 00 00 
    752cbc002c2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cbc002c32:	03 00 00 00 
    752cbc002c36:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    752cbc002c3d:	01 
    752cbc002c3e:	48 83 c4 18          	add    rsp,0x18
    752cbc002c42:	c2 08 00             	ret    0x8
