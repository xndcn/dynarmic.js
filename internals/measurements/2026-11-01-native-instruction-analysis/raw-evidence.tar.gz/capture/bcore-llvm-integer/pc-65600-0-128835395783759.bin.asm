
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65600-0-128835395783759.bin:     file format binary


Disassembly of section .data:

0000752cd4000c4f <.data>:
    752cd4000c4f:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    752cd4000c56:	01 
    752cd4000c57:	48 83 c4 38          	add    rsp,0x38
    752cd4000c5b:	c2 08 00             	ret    0x8
    752cd4000c5e:	4d 89 d7             	mov    r15,r10
    752cd4000c61:	4c 89 c5             	mov    rbp,r8
    752cd4000c64:	48 89 fb             	mov    rbx,rdi
    752cd4000c67:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000c6b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    752cd4000c72:	46 00 01 00 
    752cd4000c76:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000c7d:	02 00 00 00 
    752cd4000c81:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd4000c88:	03 00 00 00 
    752cd4000c8c:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000c93:	57 00 00 
    752cd4000c96:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000c9b:	4c 89 f7             	mov    rdi,r14
    752cd4000c9e:	be 04 f0 00 00       	mov    esi,0xf004
    752cd4000ca3:	ff d0                	call   rax
    752cd4000ca5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000cac:	00 
    752cd4000cad:	0f 85 e5 06 00 00    	jne    0x752cd4001398
    752cd4000cb3:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000cb8:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000cbc:	48 89 df             	mov    rdi,rbx
    752cd4000cbf:	49 89 e8             	mov    r8,rbp
    752cd4000cc2:	41 89 c1             	mov    r9d,eax
    752cd4000cc5:	4d 89 fa             	mov    r10,r15
    752cd4000cc8:	e9 63 fa ff e7       	jmp    0x752cbc000730
    752cd4000ccd:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000cd2:	45 89 cf             	mov    r15d,r9d
    752cd4000cd5:	4c 89 c5             	mov    rbp,r8
    752cd4000cd8:	48 89 fb             	mov    rbx,rdi
    752cd4000cdb:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000cdf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    752cd4000ce6:	4a 00 01 00 
    752cd4000cea:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000cf1:	02 00 00 00 
    752cd4000cf5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    752cd4000cfc:	05 00 00 00 
    752cd4000d00:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000d07:	57 00 00 
    752cd4000d0a:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000d0f:	4c 89 f7             	mov    rdi,r14
    752cd4000d12:	be 08 f0 00 00       	mov    esi,0xf008
    752cd4000d17:	ff d0                	call   rax
    752cd4000d19:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000d20:	00 
    752cd4000d21:	0f 85 80 06 00 00    	jne    0x752cd40013a7
    752cd4000d27:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000d2c:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000d30:	48 89 df             	mov    rdi,rbx
    752cd4000d33:	49 89 e8             	mov    r8,rbp
    752cd4000d36:	45 89 f9             	mov    r9d,r15d
    752cd4000d39:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000d3e:	e9 0a fa ff e7       	jmp    0x752cbc00074d
    752cd4000d43:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000d47:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    752cd4000d4e:	54 00 01 00 
    752cd4000d52:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000d59:	02 00 00 00 
    752cd4000d5d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    752cd4000d64:	09 00 00 00 
    752cd4000d68:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4000d6f:	57 00 00 
    752cd4000d72:	4c 89 ef             	mov    rdi,r13
    752cd4000d75:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000d7a:	4c 89 f6             	mov    rsi,r14
    752cd4000d7d:	ba 54 00 01 00       	mov    edx,0x10054
    752cd4000d82:	89 d9                	mov    ecx,ebx
    752cd4000d84:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4000d8a:	ff d0                	call   rax
    752cd4000d8c:	b8 02 00 00 00       	mov    eax,0x2
    752cd4000d91:	b9 09 00 00 00       	mov    ecx,0x9
    752cd4000d96:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    752cd4000d9d:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    752cd4000da4:	01 ca                	add    edx,ecx
    752cd4000da6:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    752cd4000dad:	39 fa                	cmp    edx,edi
    752cd4000daf:	0f 83 ce 05 00 00    	jae    0x752cd4001383
    752cd4000db5:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    752cd4000dbc:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    752cd4000dc2:	48 8b 2c 24          	mov    rbp,QWORD PTR [rsp]
    752cd4000dc6:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    752cd4000dca:	0f 85 b3 05 00 00    	jne    0x752cd4001383
    752cd4000dd0:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    752cd4000dd7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cd4000dde:	00 
    752cd4000ddf:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    752cd4000de3:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    752cd4000de8:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000ded:	48 83 c4 38          	add    rsp,0x38
    752cd4000df1:	ff e0                	jmp    rax
    752cd4000df3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    752cd4000dfa:	54 00 01 00 
    752cd4000dfe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000e05:	02 00 00 00 
    752cd4000e09:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    752cd4000e10:	09 00 00 00 
    752cd4000e14:	48 b9 20 66 eb e5 8c 	movabs rcx,0x578ce5eb6620
    752cd4000e1b:	57 00 00 
    752cd4000e1e:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd4000e23:	4c 89 f7             	mov    rdi,r14
    752cd4000e26:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000e2b:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000e2f:	89 de                	mov    esi,ebx
    752cd4000e31:	89 c2                	mov    edx,eax
    752cd4000e33:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4000e38:	45 89 cf             	mov    r15d,r9d
    752cd4000e3b:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000e40:	4d 89 de             	mov    r14,r11
    752cd4000e43:	ff d1                	call   rcx
    752cd4000e45:	4d 89 f3             	mov    r11,r14
    752cd4000e48:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000e4d:	45 89 f9             	mov    r9d,r15d
    752cd4000e50:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4000e55:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4000e5a:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000e5e:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000e63:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000e6a:	00 
    752cd4000e6b:	0f 84 20 f9 ff e7    	je     0x752cbc000791
    752cd4000e71:	e9 16 ff ff ff       	jmp    0x752cd4000d8c
    752cd4000e76:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    752cd4000e7d:	56 00 01 00 
    752cd4000e81:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000e88:	02 00 00 00 
    752cd4000e8c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    752cd4000e93:	09 00 00 00 
    752cd4000e97:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4000e9e:	57 00 00 
    752cd4000ea1:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd4000ea6:	4c 89 ef             	mov    rdi,r13
    752cd4000ea9:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000eae:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000eb2:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4000eb7:	45 89 cf             	mov    r15d,r9d
    752cd4000eba:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000ebf:	4d 89 de             	mov    r14,r11
    752cd4000ec2:	ff d0                	call   rax
    752cd4000ec4:	4d 89 f3             	mov    r11,r14
    752cd4000ec7:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000ecc:	45 89 f9             	mov    r9d,r15d
    752cd4000ecf:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4000ed4:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4000ed9:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000edd:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000ee2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000ee9:	00 
    752cd4000eea:	0f 84 ab f8 ff e7    	je     0x752cbc00079b
    752cd4000ef0:	e9 97 fe ff ff       	jmp    0x752cd4000d8c
    752cd4000ef5:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    752cd4000efa:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000eff:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    752cd4000f04:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4000f09:	49 89 ff             	mov    r15,rdi
    752cd4000f0c:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000f10:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    752cd4000f17:	5c 00 01 00 
    752cd4000f1b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000f22:	02 00 00 00 
    752cd4000f26:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd4000f2d:	0c 00 00 00 
    752cd4000f31:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000f38:	57 00 00 
    752cd4000f3b:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000f40:	4c 89 f7             	mov    rdi,r14
    752cd4000f43:	be 0c f0 00 00       	mov    esi,0xf00c
    752cd4000f48:	ff d0                	call   rax
    752cd4000f4a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000f51:	00 
    752cd4000f52:	0f 85 5e 04 00 00    	jne    0x752cd40013b6
    752cd4000f58:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000f5d:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000f61:	4c 89 ff             	mov    rdi,r15
    752cd4000f64:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4000f69:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    752cd4000f6e:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000f73:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    752cd4000f78:	e9 37 f8 ff e7       	jmp    0x752cbc0007b4
    752cd4000f7d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    752cd4000f84:	6a 00 01 00 
    752cd4000f88:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000f8f:	02 00 00 00 
    752cd4000f93:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    752cd4000f9a:	10 00 00 00 
    752cd4000f9e:	48 b9 20 66 eb e5 8c 	movabs rcx,0x578ce5eb6620
    752cd4000fa5:	57 00 00 
    752cd4000fa8:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd4000fad:	4c 89 f7             	mov    rdi,r14
    752cd4000fb0:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4000fb5:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4000fb9:	89 ee                	mov    esi,ebp
    752cd4000fbb:	89 c2                	mov    edx,eax
    752cd4000fbd:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4000fc2:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    752cd4000fc7:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000fcc:	4d 89 de             	mov    r14,r11
    752cd4000fcf:	ff d1                	call   rcx
    752cd4000fd1:	4d 89 f3             	mov    r11,r14
    752cd4000fd4:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000fd9:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    752cd4000fde:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4000fe3:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4000fe8:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4000fec:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4000ff1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4000ff8:	00 
    752cd4000ff9:	0f 84 ea f7 ff e7    	je     0x752cbc0007e9
    752cd4000fff:	eb 7e                	jmp    0x752cd400107f
    752cd4001001:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    752cd4001008:	6c 00 01 00 
    752cd400100c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001013:	02 00 00 00 
    752cd4001017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    752cd400101e:	10 00 00 00 
    752cd4001022:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001029:	57 00 00 
    752cd400102c:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd4001031:	4c 89 ef             	mov    rdi,r13
    752cd4001034:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4001039:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd400103d:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4001042:	45 89 ce             	mov    r14d,r9d
    752cd4001045:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd400104a:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    752cd400104f:	ff d0                	call   rax
    752cd4001051:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    752cd4001056:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd400105b:	45 89 f1             	mov    r9d,r14d
    752cd400105e:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4001063:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4001068:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd400106c:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4001071:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4001078:	00 
    752cd4001079:	0f 84 74 f7 ff e7    	je     0x752cbc0007f3
    752cd400107f:	b8 02 00 00 00       	mov    eax,0x2
    752cd4001084:	b9 10 00 00 00       	mov    ecx,0x10
    752cd4001089:	e9 08 fd ff ff       	jmp    0x752cd4000d96
    752cd400108e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    752cd4001095:	74 00 01 00 
    752cd4001099:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40010a0:	02 00 00 00 
    752cd40010a4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    752cd40010ab:	13 00 00 00 
    752cd40010af:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40010b6:	57 00 00 
    752cd40010b9:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd40010be:	4c 89 f7             	mov    rdi,r14
    752cd40010c1:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd40010c6:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd40010ca:	be 10 f0 00 00       	mov    esi,0xf010
    752cd40010cf:	ba 01 00 00 00       	mov    edx,0x1
    752cd40010d4:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd40010d9:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    752cd40010de:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd40010e3:	4d 89 de             	mov    r14,r11
    752cd40010e6:	ff d0                	call   rax
    752cd40010e8:	4d 89 f3             	mov    r11,r14
    752cd40010eb:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd40010f0:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    752cd40010f5:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd40010fa:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd40010ff:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4001103:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4001108:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400110f:	00 
    752cd4001110:	0f 84 fa f6 ff e7    	je     0x752cbc000810
    752cd4001116:	eb 7e                	jmp    0x752cd4001196
    752cd4001118:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    752cd400111f:	76 00 01 00 
    752cd4001123:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400112a:	02 00 00 00 
    752cd400112e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    752cd4001135:	13 00 00 00 
    752cd4001139:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001140:	57 00 00 
    752cd4001143:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd4001148:	4c 89 ef             	mov    rdi,r13
    752cd400114b:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4001150:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4001154:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd4001159:	45 89 ce             	mov    r14d,r9d
    752cd400115c:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4001161:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    752cd4001166:	ff d0                	call   rax
    752cd4001168:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    752cd400116d:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4001172:	45 89 f1             	mov    r9d,r14d
    752cd4001175:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd400117a:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd400117f:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4001183:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4001188:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400118f:	00 
    752cd4001190:	0f 84 84 f6 ff e7    	je     0x752cbc00081a
    752cd4001196:	b8 02 00 00 00       	mov    eax,0x2
    752cd400119b:	b9 13 00 00 00       	mov    ecx,0x13
    752cd40011a0:	e9 f1 fb ff ff       	jmp    0x752cd4000d96
    752cd40011a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    752cd40011ac:	78 00 01 00 
    752cd40011b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40011b7:	02 00 00 00 
    752cd40011bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    752cd40011c2:	15 00 00 00 
    752cd40011c6:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40011cd:	57 00 00 
    752cd40011d0:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd40011d5:	4c 89 f7             	mov    rdi,r14
    752cd40011d8:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd40011dd:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd40011e1:	be 14 f0 00 00       	mov    esi,0xf014
    752cd40011e6:	31 d2                	xor    edx,edx
    752cd40011e8:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd40011ed:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    752cd40011f2:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd40011f7:	4d 89 de             	mov    r14,r11
    752cd40011fa:	ff d0                	call   rax
    752cd40011fc:	4d 89 f3             	mov    r11,r14
    752cd40011ff:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4001204:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    752cd4001209:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd400120e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4001213:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4001217:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd400121c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4001223:	00 
    752cd4001224:	0f 84 0d f6 ff e7    	je     0x752cbc000837
    752cd400122a:	eb 74                	jmp    0x752cd40012a0
    752cd400122c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    752cd4001233:	7a 00 01 00 
    752cd4001237:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400123e:	02 00 00 00 
    752cd4001242:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    752cd4001249:	15 00 00 00 
    752cd400124d:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001254:	57 00 00 
    752cd4001257:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd400125c:	4c 89 ef             	mov    rdi,r13
    752cd400125f:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd4001264:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd4001268:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd400126d:	45 89 ce             	mov    r14d,r9d
    752cd4001270:	4c 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],r11
    752cd4001275:	ff d0                	call   rax
    752cd4001277:	4c 8b 5c 24 30       	mov    r11,QWORD PTR [rsp+0x30]
    752cd400127c:	45 89 f1             	mov    r9d,r14d
    752cd400127f:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4001284:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4001289:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd400128d:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4001292:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4001299:	00 
    752cd400129a:	0f 84 a1 f5 ff e7    	je     0x752cbc000841
    752cd40012a0:	b8 02 00 00 00       	mov    eax,0x2
    752cd40012a5:	b9 15 00 00 00       	mov    ecx,0x15
    752cd40012aa:	e9 e7 fa ff ff       	jmp    0x752cd4000d96
    752cd40012af:	44 89 4c 24 1c       	mov    DWORD PTR [rsp+0x1c],r9d
    752cd40012b4:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd40012b9:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cd40012be:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd40012c2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    752cd40012c9:	84 00 01 00 
    752cd40012cd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    752cd40012d4:	08 00 00 00 
    752cd40012d8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd40012df:	1a 00 00 00 
    752cd40012e3:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40012ea:	57 00 00 
    752cd40012ed:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd40012f2:	4c 89 f7             	mov    rdi,r14
    752cd40012f5:	89 de                	mov    esi,ebx
    752cd40012f7:	ff d0                	call   rax
    752cd40012f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4001300:	00 
    752cd4001301:	0f 85 be 00 00 00    	jne    0x752cd40013c5
    752cd4001307:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd400130c:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4001310:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cd4001315:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd400131a:	44 8b 4c 24 1c       	mov    r9d,DWORD PTR [rsp+0x1c]
    752cd400131f:	e9 4b f5 ff e7       	jmp    0x752cbc00086f
    752cd4001324:	4d 89 c7             	mov    r15,r8
    752cd4001327:	48 89 fb             	mov    rbx,rdi
    752cd400132a:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    752cd400132e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    752cd4001335:	8c 00 01 00 
    752cd4001339:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001340:	02 00 00 00 
    752cd4001344:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    752cd400134b:	1b 00 00 00 
    752cd400134f:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001356:	57 00 00 
    752cd4001359:	4c 89 74 24 08       	mov    QWORD PTR [rsp+0x8],r14
    752cd400135e:	4c 89 f7             	mov    rdi,r14
    752cd4001361:	89 ee                	mov    esi,ebp
    752cd4001363:	ff d0                	call   rax
    752cd4001365:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400136c:	00 
    752cd400136d:	75 65                	jne    0x752cd40013d4
    752cd400136f:	4c 8b 74 24 08       	mov    r14,QWORD PTR [rsp+0x8]
    752cd4001374:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
    752cd4001378:	48 89 df             	mov    rdi,rbx
    752cd400137b:	4d 89 f8             	mov    r8,r15
    752cd400137e:	e9 0a f5 ff e7       	jmp    0x752cbc00088d
    752cd4001383:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    752cd400138a:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    752cd4001391:	48 83 c4 38          	add    rsp,0x38
    752cd4001395:	c2 08 00             	ret    0x8
    752cd4001398:	b8 02 00 00 00       	mov    eax,0x2
    752cd400139d:	b9 03 00 00 00       	mov    ecx,0x3
    752cd40013a2:	e9 ef f9 ff ff       	jmp    0x752cd4000d96
    752cd40013a7:	b8 02 00 00 00       	mov    eax,0x2
    752cd40013ac:	b9 05 00 00 00       	mov    ecx,0x5
    752cd40013b1:	e9 e0 f9 ff ff       	jmp    0x752cd4000d96
    752cd40013b6:	b8 02 00 00 00       	mov    eax,0x2
    752cd40013bb:	b9 0c 00 00 00       	mov    ecx,0xc
    752cd40013c0:	e9 d1 f9 ff ff       	jmp    0x752cd4000d96
    752cd40013c5:	b8 08 00 00 00       	mov    eax,0x8
    752cd40013ca:	b9 1a 00 00 00       	mov    ecx,0x1a
    752cd40013cf:	e9 c2 f9 ff ff       	jmp    0x752cd4000d96
    752cd40013d4:	b8 02 00 00 00       	mov    eax,0x2
    752cd40013d9:	b9 1b 00 00 00       	mov    ecx,0x1b
    752cd40013de:	e9 b3 f9 ff ff       	jmp    0x752cd4000d96
