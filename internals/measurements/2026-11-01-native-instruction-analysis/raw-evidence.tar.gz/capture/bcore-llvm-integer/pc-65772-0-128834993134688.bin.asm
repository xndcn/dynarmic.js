
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65772-0-128834993134688.bin:     file format binary


Disassembly of section .data:

0000752cbc001c60 <.data>:
    752cbc001c60:	48 83 ec 58          	sub    rsp,0x58
    752cbc001c64:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    752cbc001c69:	4d 89 e8             	mov    r8,r13
    752cbc001c6c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    752cbc001c73:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    752cbc001c78:	45 8b 9d 58 01 00 00 	mov    r11d,DWORD PTR [r13+0x158]
    752cbc001c7f:	b8 f3 fe fe ff       	mov    eax,0xfffefef3
    752cbc001c84:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    752cbc001c8b:	01 c1                	add    ecx,eax
    752cbc001c8d:	83 f9 de             	cmp    ecx,0xffffffde
    752cbc001c90:	0f 87 a2 11 00 18    	ja     0x752cd4002e38
    752cbc001c96:	41 03 80 a0 00 00 00 	add    eax,DWORD PTR [r8+0xa0]
    752cbc001c9d:	83 f8 de             	cmp    eax,0xffffffde
    752cbc001ca0:	0f 87 92 11 00 18    	ja     0x752cd4002e38
    752cbc001ca6:	49 8b 80 38 01 00 00 	mov    rax,QWORD PTR [r8+0x138]
    752cbc001cad:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    752cbc001cb2:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    752cbc001cb5:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    752cbc001cb9:	41 8b 58 08          	mov    ebx,DWORD PTR [r8+0x8]
    752cbc001cbd:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    752cbc001cc1:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    752cbc001cc5:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    752cbc001cc9:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    752cbc001cce:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    752cbc001cd5:	41 8b b0 5c 01 00 00 	mov    esi,DWORD PTR [r8+0x15c]
    752cbc001cdc:	4c 89 44 24 30       	mov    QWORD PTR [rsp+0x30],r8
    752cbc001ce1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    752cbc001ce8:	0f 1f 84 00 00 00 00 
    752cbc001cef:	00 
    752cbc001cf0:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    752cbc001cf5:	44 89 ca             	mov    edx,r9d
    752cbc001cf8:	c1 ea 1f             	shr    edx,0x1f
    752cbc001cfb:	89 df                	mov    edi,ebx
    752cbc001cfd:	ff c7                	inc    edi
    752cbc001cff:	44 89 e9             	mov    ecx,r13d
    752cbc001d02:	41 39 fd             	cmp    r13d,edi
    752cbc001d05:	89 f8                	mov    eax,edi
    752cbc001d07:	41 0f 47 c5          	cmova  eax,r13d
    752cbc001d0b:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    752cbc001d0f:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    752cbc001d13:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    752cbc001d18:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    752cbc001d1f:	00 
    752cbc001d20:	41 89 f4             	mov    r12d,esi
    752cbc001d23:	89 f8                	mov    eax,edi
    752cbc001d25:	8d 70 ff             	lea    esi,[rax-0x1]
    752cbc001d28:	45 0f af f2          	imul   r14d,r10d
    752cbc001d2c:	43 8d 1c 0e          	lea    ebx,[r14+r9*1]
    752cbc001d30:	41 c1 ee 1f          	shr    r14d,0x1f
    752cbc001d34:	89 df                	mov    edi,ebx
    752cbc001d36:	c1 ef 1f             	shr    edi,0x1f
    752cbc001d39:	89 fd                	mov    ebp,edi
    752cbc001d3b:	31 d5                	xor    ebp,edx
    752cbc001d3d:	44 31 f7             	xor    edi,r14d
    752cbc001d40:	21 ef                	and    edi,ebp
    752cbc001d42:	41 89 de             	mov    r14d,ebx
    752cbc001d45:	41 c1 ee 0d          	shr    r14d,0xd
    752cbc001d49:	41 31 de             	xor    r14d,ebx
    752cbc001d4c:	44 89 f5             	mov    ebp,r14d
    752cbc001d4f:	c1 e5 07             	shl    ebp,0x7
    752cbc001d52:	c1 ee 1f             	shr    esi,0x1f
    752cbc001d55:	89 c1                	mov    ecx,eax
    752cbc001d57:	c1 e9 1f             	shr    ecx,0x1f
    752cbc001d5a:	c4 e2 48 f2 c9       	andn   ecx,esi,ecx
    752cbc001d5f:	41 09 cf             	or     r15d,ecx
    752cbc001d62:	41 09 ff             	or     r15d,edi
    752cbc001d65:	41 0f a4 de 07       	shld   r14d,ebx,0x7
    752cbc001d6a:	41 39 c5             	cmp    r13d,eax
    752cbc001d6d:	76 21                	jbe    0x752cbc001d90
    752cbc001d6f:	41 8d 74 24 0a       	lea    esi,[r12+0xa]
    752cbc001d74:	44 39 de             	cmp    esi,r11d
    752cbc001d77:	0f 83 1c 02 00 00    	jae    0x752cbc001f99
    752cbc001d7d:	41 8b 88 58 01 00 00 	mov    ecx,DWORD PTR [r8+0x158]
    752cbc001d84:	8d 78 01             	lea    edi,[rax+0x1]
    752cbc001d87:	85 c9                	test   ecx,ecx
    752cbc001d89:	75 95                	jne    0x752cbc001d20
    752cbc001d8b:	e9 09 02 00 00       	jmp    0x752cbc001f99
    752cbc001d90:	0f 96 c0             	setbe  al
    752cbc001d93:	0f b6 c0             	movzx  eax,al
    752cbc001d96:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    752cbc001d9a:	31 db                	xor    ebx,ebx
    752cbc001d9c:	31 c0                	xor    eax,eax
    752cbc001d9e:	44 3b 6c 24 08       	cmp    r13d,DWORD PTR [rsp+0x8]
    752cbc001da3:	0f 93 c3             	setae  bl
    752cbc001da6:	0f 92 c0             	setb   al
    752cbc001da9:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    752cbc001dad:	41 8b 78 3c          	mov    edi,DWORD PTR [r8+0x3c]
    752cbc001db1:	40 f6 c7 03          	test   dil,0x3
    752cbc001db5:	0f 85 10 03 00 00    	jne    0x752cbc0020cb
    752cbc001dbb:	48 89 f8             	mov    rax,rdi
    752cbc001dbe:	48 c1 e8 0c          	shr    rax,0xc
    752cbc001dc2:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    752cbc001dc7:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    752cbc001dcb:	48 85 c0             	test   rax,rax
    752cbc001dce:	89 5c 24 1c          	mov    DWORD PTR [rsp+0x1c],ebx
    752cbc001dd2:	0f 84 a4 03 00 00    	je     0x752cbc00217c
    752cbc001dd8:	89 f9                	mov    ecx,edi
    752cbc001dda:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc001de0:	8b 0c 08             	mov    ecx,DWORD PTR [rax+rcx*1]
    752cbc001de3:	8d 77 04             	lea    esi,[rdi+0x4]
    752cbc001de6:	89 f0                	mov    eax,esi
    752cbc001de8:	c1 e8 0c             	shr    eax,0xc
    752cbc001deb:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    752cbc001def:	48 85 c0             	test   rax,rax
    752cbc001df2:	0f 84 61 04 00 00    	je     0x752cbc002259
    752cbc001df8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc001dfe:	44 8b 2c 30          	mov    r13d,DWORD PTR [rax+rsi*1]
    752cbc001e02:	8d 77 08             	lea    esi,[rdi+0x8]
    752cbc001e05:	41 89 48 3c          	mov    DWORD PTR [r8+0x3c],ecx
    752cbc001e09:	45 89 a8 a8 00 00 00 	mov    DWORD PTR [r8+0xa8],r13d
    752cbc001e10:	41 89 70 38          	mov    DWORD PTR [r8+0x38],esi
    752cbc001e14:	89 f0                	mov    eax,esi
    752cbc001e16:	c1 e8 0c             	shr    eax,0xc
    752cbc001e19:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    752cbc001e1d:	48 85 c0             	test   rax,rax
    752cbc001e20:	0f 84 16 05 00 00    	je     0x752cbc00233c
    752cbc001e26:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc001e2c:	8b 0c 30             	mov    ecx,DWORD PTR [rax+rsi*1]
    752cbc001e2f:	8d 77 0c             	lea    esi,[rdi+0xc]
    752cbc001e32:	89 f0                	mov    eax,esi
    752cbc001e34:	c1 e8 0c             	shr    eax,0xc
    752cbc001e37:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    752cbc001e3b:	48 85 c0             	test   rax,rax
    752cbc001e3e:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    752cbc001e43:	0f 84 c9 05 00 00    	je     0x752cbc002412
    752cbc001e49:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc001e4f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc001e52:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    752cbc001e56:	83 c7 10             	add    edi,0x10
    752cbc001e59:	41 89 78 38          	mov    DWORD PTR [r8+0x38],edi
    752cbc001e5d:	41 f6 c5 01          	test   r13b,0x1
    752cbc001e61:	0f 85 74 06 00 00    	jne    0x752cbc0024db
    752cbc001e67:	4d 89 e9             	mov    r9,r13
    752cbc001e6a:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    752cbc001e6f:	c7 44 24 20 00 00 00 	mov    DWORD PTR [rsp+0x20],0x0
    752cbc001e76:	00 
    752cbc001e77:	bf 02 00 00 00       	mov    edi,0x2
    752cbc001e7c:	b9 0e 00 00 00       	mov    ecx,0xe
    752cbc001e81:	c7 44 24 2c 00 00 00 	mov    DWORD PTR [rsp+0x2c],0x0
    752cbc001e88:	00 
    752cbc001e89:	89 d8                	mov    eax,ebx
    752cbc001e8b:	89 da                	mov    edx,ebx
    752cbc001e8d:	45 89 f5             	mov    r13d,r14d
    752cbc001e90:	42 8d 34 21          	lea    esi,[rcx+r12*1]
    752cbc001e94:	44 39 de             	cmp    esi,r11d
    752cbc001e97:	0f 83 98 01 00 00    	jae    0x752cbc002035
    752cbc001e9d:	48 8b 5c 24 30       	mov    rbx,QWORD PTR [rsp+0x30]
    752cbc001ea2:	8b 9b 58 01 00 00    	mov    ebx,DWORD PTR [rbx+0x158]
    752cbc001ea8:	85 db                	test   ebx,ebx
    752cbc001eaa:	0f 84 85 01 00 00    	je     0x752cbc002035
    752cbc001eb0:	4d 89 ca             	mov    r10,r9
    752cbc001eb3:	41 81 fa ec 00 01 00 	cmp    r10d,0x100ec
    752cbc001eba:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc001ebf:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    752cbc001ec3:	0f 84 27 fe ff ff    	je     0x752cbc001cf0
    752cbc001ec9:	46 8d 1c d5 00 00 00 	lea    r11d,[r10*8+0x0]
    752cbc001ed0:	00 
    752cbc001ed1:	41 81 e3 f0 ff 0f 00 	and    r11d,0xffff0
    752cbc001ed8:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    752cbc001edd:	46 39 14 1b          	cmp    DWORD PTR [rbx+r11*1],r10d
    752cbc001ee1:	0f 85 4e 01 00 00    	jne    0x752cbc002035
    752cbc001ee7:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    752cbc001eec:	4e 8b 44 1b 08       	mov    r8,QWORD PTR [rbx+r11*1+0x8]
    752cbc001ef1:	4c 8b 54 24 30       	mov    r10,QWORD PTR [rsp+0x30]
    752cbc001ef6:	45 89 2a             	mov    DWORD PTR [r10],r13d
    752cbc001ef9:	45 89 72 04          	mov    DWORD PTR [r10+0x4],r14d
    752cbc001efd:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    752cbc001f01:	41 89 5a 08          	mov    DWORD PTR [r10+0x8],ebx
    752cbc001f05:	41 89 6a 0c          	mov    DWORD PTR [r10+0xc],ebp
    752cbc001f09:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    752cbc001f0d:	41 89 5a 18          	mov    DWORD PTR [r10+0x18],ebx
    752cbc001f11:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    752cbc001f16:	41 89 6a 1c          	mov    DWORD PTR [r10+0x1c],ebp
    752cbc001f1a:	45 89 8a bc 00 00 00 	mov    DWORD PTR [r10+0xbc],r9d
    752cbc001f21:	41 89 92 e4 00 00 00 	mov    DWORD PTR [r10+0xe4],edx
    752cbc001f28:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    752cbc001f2c:	41 89 92 e8 00 00 00 	mov    DWORD PTR [r10+0xe8],edx
    752cbc001f33:	41 89 82 ec 00 00 00 	mov    DWORD PTR [r10+0xec],eax
    752cbc001f3a:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    752cbc001f3e:	41 89 82 f0 00 00 00 	mov    DWORD PTR [r10+0xf0],eax
    752cbc001f45:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    752cbc001f49:	41 89 82 f8 00 00 00 	mov    DWORD PTR [r10+0xf8],eax
    752cbc001f50:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    752cbc001f54:	41 89 82 fc 00 00 00 	mov    DWORD PTR [r10+0xfc],eax
    752cbc001f5b:	45 89 ba 00 01 00 00 	mov    DWORD PTR [r10+0x100],r15d
    752cbc001f62:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc001f66:	41 89 82 14 01 00 00 	mov    DWORD PTR [r10+0x114],eax
    752cbc001f6d:	41 89 ba 24 01 00 00 	mov    DWORD PTR [r10+0x124],edi
    752cbc001f74:	41 c6 82 28 01 00 00 	mov    BYTE PTR [r10+0x128],0x0
    752cbc001f7b:	00 
    752cbc001f7c:	41 89 8a 34 01 00 00 	mov    DWORD PTR [r10+0x134],ecx
    752cbc001f83:	41 89 b2 5c 01 00 00 	mov    DWORD PTR [r10+0x15c],esi
    752cbc001f8a:	4d 89 d5             	mov    r13,r10
    752cbc001f8d:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    752cbc001f92:	48 83 c4 58          	add    rsp,0x58
    752cbc001f96:	41 ff e0             	jmp    r8
    752cbc001f99:	31 c9                	xor    ecx,ecx
    752cbc001f9b:	31 d2                	xor    edx,edx
    752cbc001f9d:	31 f6                	xor    esi,esi
    752cbc001f9f:	31 ff                	xor    edi,edi
    752cbc001fa1:	41 39 c5             	cmp    r13d,eax
    752cbc001fa4:	0f 96 c1             	setbe  cl
    752cbc001fa7:	0f 94 c2             	sete   dl
    752cbc001faa:	40 0f 92 c6          	setb   sil
    752cbc001fae:	40 0f 93 c7          	setae  dil
    752cbc001fb2:	45 89 28             	mov    DWORD PTR [r8],r13d
    752cbc001fb5:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc001fb9:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc001fbd:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc001fc1:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc001fc5:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    752cbc001fc9:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x100ec
    752cbc001fd0:	ec 00 01 00 
    752cbc001fd4:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    752cbc001fdb:	41 89 b0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],esi
    752cbc001fe2:	41 89 b8 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edi
    752cbc001fe9:	41 89 b8 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edi
    752cbc001ff0:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc001ff7:	00 00 00 00 
    752cbc001ffb:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc002002:	41 89 88 14 01 00 00 	mov    DWORD PTR [r8+0x114],ecx
    752cbc002009:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    752cbc002010:	02 00 00 00 
    752cbc002014:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    752cbc00201b:	01 
    752cbc00201c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xa
    752cbc002023:	0a 00 00 00 
    752cbc002027:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc00202e:	48 83 c4 58          	add    rsp,0x58
    752cbc002032:	c2 08 00             	ret    0x8
    752cbc002035:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    752cbc00203a:	44 89 2e             	mov    DWORD PTR [rsi],r13d
    752cbc00203d:	44 89 76 04          	mov    DWORD PTR [rsi+0x4],r14d
    752cbc002041:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    752cbc002045:	89 5e 08             	mov    DWORD PTR [rsi+0x8],ebx
    752cbc002048:	89 6e 0c             	mov    DWORD PTR [rsi+0xc],ebp
    752cbc00204b:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    752cbc00204f:	89 5e 18             	mov    DWORD PTR [rsi+0x18],ebx
    752cbc002052:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    752cbc002057:	89 6e 1c             	mov    DWORD PTR [rsi+0x1c],ebp
    752cbc00205a:	44 89 8e bc 00 00 00 	mov    DWORD PTR [rsi+0xbc],r9d
    752cbc002061:	89 96 e4 00 00 00    	mov    DWORD PTR [rsi+0xe4],edx
    752cbc002067:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    752cbc00206b:	89 96 e8 00 00 00    	mov    DWORD PTR [rsi+0xe8],edx
    752cbc002071:	89 86 ec 00 00 00    	mov    DWORD PTR [rsi+0xec],eax
    752cbc002077:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    752cbc00207b:	89 86 f0 00 00 00    	mov    DWORD PTR [rsi+0xf0],eax
    752cbc002081:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    752cbc002085:	89 86 f8 00 00 00    	mov    DWORD PTR [rsi+0xf8],eax
    752cbc00208b:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    752cbc00208f:	89 86 fc 00 00 00    	mov    DWORD PTR [rsi+0xfc],eax
    752cbc002095:	44 89 be 00 01 00 00 	mov    DWORD PTR [rsi+0x100],r15d
    752cbc00209c:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc0020a0:	89 86 14 01 00 00    	mov    DWORD PTR [rsi+0x114],eax
    752cbc0020a6:	89 be 24 01 00 00    	mov    DWORD PTR [rsi+0x124],edi
    752cbc0020ac:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    752cbc0020b1:	88 86 28 01 00 00    	mov    BYTE PTR [rsi+0x128],al
    752cbc0020b7:	89 8e 34 01 00 00    	mov    DWORD PTR [rsi+0x134],ecx
    752cbc0020bd:	44 89 a6 5c 01 00 00 	mov    DWORD PTR [rsi+0x15c],r12d
    752cbc0020c4:	48 83 c4 58          	add    rsp,0x58
    752cbc0020c8:	c2 08 00             	ret    0x8
    752cbc0020cb:	89 d9                	mov    ecx,ebx
    752cbc0020cd:	44 89 db             	mov    ebx,r11d
    752cbc0020d0:	45 89 28             	mov    DWORD PTR [r8],r13d
    752cbc0020d3:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc0020d7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc0020db:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc0020df:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc0020e3:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc0020e7:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    752cbc0020eb:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    752cbc0020f2:	04 01 01 00 
    752cbc0020f6:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    752cbc0020fd:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc002101:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc002108:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    752cbc00210f:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    752cbc002116:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc00211d:	00 00 00 00 
    752cbc002121:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc002128:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc00212c:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc002133:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    752cbc00213a:	04 00 00 00 
    752cbc00213e:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc002145:	00 
    752cbc002146:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    752cbc00214d:	0b 00 00 00 
    752cbc002151:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc002158:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cbc00215f:	57 00 00 
    752cbc002162:	48 89 f9             	mov    rcx,rdi
    752cbc002165:	4c 89 c7             	mov    rdi,r8
    752cbc002168:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    752cbc00216d:	ba 04 01 01 00       	mov    edx,0x10104
    752cbc002172:	45 31 c0             	xor    r8d,r8d
    752cbc002175:	ff d0                	call   rax
    752cbc002177:	e9 0e 04 00 00       	jmp    0x752cbc00258a
    752cbc00217c:	89 d9                	mov    ecx,ebx
    752cbc00217e:	44 89 db             	mov    ebx,r11d
    752cbc002181:	45 89 28             	mov    DWORD PTR [r8],r13d
    752cbc002184:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc002188:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc00218c:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc002190:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc002194:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc002198:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    752cbc00219c:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    752cbc0021a3:	04 01 01 00 
    752cbc0021a7:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    752cbc0021ae:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc0021b2:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc0021b9:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    752cbc0021c0:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    752cbc0021c7:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc0021ce:	00 00 00 00 
    752cbc0021d2:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc0021d9:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc0021dd:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc0021e4:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    752cbc0021eb:	04 00 00 00 
    752cbc0021ef:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc0021f6:	00 
    752cbc0021f7:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    752cbc0021fe:	0b 00 00 00 
    752cbc002202:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc002209:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cbc002210:	57 00 00 
    752cbc002213:	48 89 fe             	mov    rsi,rdi
    752cbc002216:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    752cbc00221b:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    752cbc002220:	ff d0                	call   rax
    752cbc002222:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc002227:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    752cbc00222e:	00 
    752cbc00222f:	84 c9                	test   cl,cl
    752cbc002231:	0f 85 60 03 00 00    	jne    0x752cbc002597
    752cbc002237:	41 89 db             	mov    r11d,ebx
    752cbc00223a:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    752cbc00223f:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    752cbc002244:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    752cbc002249:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    752cbc00224d:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cbc002252:	89 c1                	mov    ecx,eax
    752cbc002254:	e9 8a fb ff ff       	jmp    0x752cbc001de3
    752cbc002259:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    752cbc00225d:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cbc002262:	89 d9                	mov    ecx,ebx
    752cbc002264:	44 89 db             	mov    ebx,r11d
    752cbc002267:	45 89 28             	mov    DWORD PTR [r8],r13d
    752cbc00226a:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc00226e:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc002272:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc002276:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc00227a:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc00227e:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    752cbc002282:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    752cbc002289:	04 01 01 00 
    752cbc00228d:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    752cbc002294:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc002298:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc00229f:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    752cbc0022a6:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    752cbc0022ad:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc0022b4:	00 00 00 00 
    752cbc0022b8:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc0022bf:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc0022c3:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc0022ca:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    752cbc0022d1:	04 00 00 00 
    752cbc0022d5:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc0022dc:	00 
    752cbc0022dd:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    752cbc0022e4:	0b 00 00 00 
    752cbc0022e8:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc0022ef:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cbc0022f6:	57 00 00 
    752cbc0022f9:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    752cbc0022fe:	ff d0                	call   rax
    752cbc002300:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc002305:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    752cbc00230c:	00 
    752cbc00230d:	84 c9                	test   cl,cl
    752cbc00230f:	0f 85 82 02 00 00    	jne    0x752cbc002597
    752cbc002315:	41 89 c5             	mov    r13d,eax
    752cbc002318:	41 89 db             	mov    r11d,ebx
    752cbc00231b:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    752cbc002320:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    752cbc002325:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    752cbc00232a:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    752cbc00232e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cbc002333:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    752cbc002337:	e9 c6 fa ff ff       	jmp    0x752cbc001e02
    752cbc00233c:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cbc002341:	89 d9                	mov    ecx,ebx
    752cbc002343:	44 89 db             	mov    ebx,r11d
    752cbc002346:	45 89 30             	mov    DWORD PTR [r8],r14d
    752cbc002349:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc00234d:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc002351:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc002355:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc002359:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc00235d:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    752cbc002361:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    752cbc002368:	0a 01 01 00 
    752cbc00236c:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    752cbc002373:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc002377:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc00237e:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    752cbc002385:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    752cbc00238c:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc002393:	00 00 00 00 
    752cbc002397:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc00239e:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc0023a2:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc0023a9:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    752cbc0023b0:	02 00 00 00 
    752cbc0023b4:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc0023bb:	00 
    752cbc0023bc:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    752cbc0023c3:	0d 00 00 00 
    752cbc0023c7:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc0023ce:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cbc0023d5:	57 00 00 
    752cbc0023d8:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    752cbc0023dd:	ff d0                	call   rax
    752cbc0023df:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc0023e4:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    752cbc0023eb:	00 
    752cbc0023ec:	84 c9                	test   cl,cl
    752cbc0023ee:	0f 85 a3 01 00 00    	jne    0x752cbc002597
    752cbc0023f4:	41 89 db             	mov    r11d,ebx
    752cbc0023f7:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    752cbc0023fc:	48 89 c1             	mov    rcx,rax
    752cbc0023ff:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    752cbc002404:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    752cbc002408:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cbc00240d:	e9 1d fa ff ff       	jmp    0x752cbc001e2f
    752cbc002412:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    752cbc002417:	89 da                	mov    edx,ebx
    752cbc002419:	44 89 db             	mov    ebx,r11d
    752cbc00241c:	45 89 30             	mov    DWORD PTR [r8],r14d
    752cbc00241f:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc002423:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc002427:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc00242b:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc00242f:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    752cbc002433:	41 89 48 1c          	mov    DWORD PTR [r8+0x1c],ecx
    752cbc002437:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    752cbc00243e:	0a 01 01 00 
    752cbc002442:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    752cbc002449:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc00244d:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc002454:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    752cbc00245b:	41 89 90 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edx
    752cbc002462:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc002469:	00 00 00 00 
    752cbc00246d:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc002474:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc002478:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc00247f:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    752cbc002486:	02 00 00 00 
    752cbc00248a:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc002491:	00 
    752cbc002492:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    752cbc002499:	0d 00 00 00 
    752cbc00249d:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc0024a4:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cbc0024ab:	57 00 00 
    752cbc0024ae:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    752cbc0024b3:	ff d0                	call   rax
    752cbc0024b5:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc0024ba:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    752cbc0024c1:	00 
    752cbc0024c2:	84 c9                	test   cl,cl
    752cbc0024c4:	0f 85 cd 00 00 00    	jne    0x752cbc002597
    752cbc0024ca:	41 89 db             	mov    r11d,ebx
    752cbc0024cd:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    752cbc0024d1:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    752cbc0024d6:	e9 77 f9 ff ff       	jmp    0x752cbc001e52
    752cbc0024db:	89 d9                	mov    ecx,ebx
    752cbc0024dd:	44 89 db             	mov    ebx,r11d
    752cbc0024e0:	45 89 30             	mov    DWORD PTR [r8],r14d
    752cbc0024e3:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    752cbc0024e7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    752cbc0024eb:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    752cbc0024ef:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    752cbc0024f3:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    752cbc0024f7:	41 89 40 18          	mov    DWORD PTR [r8+0x18],eax
    752cbc0024fb:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc002500:	41 89 40 1c          	mov    DWORD PTR [r8+0x1c],eax
    752cbc002504:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010c
    752cbc00250b:	0c 01 01 00 
    752cbc00250f:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    752cbc002516:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    752cbc00251a:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    752cbc002521:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    752cbc002528:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    752cbc00252f:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    752cbc002536:	00 00 00 00 
    752cbc00253a:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    752cbc002541:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    752cbc002545:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    752cbc00254c:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    752cbc002553:	02 00 00 00 
    752cbc002557:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cbc00255e:	00 
    752cbc00255f:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xe
    752cbc002566:	0e 00 00 00 
    752cbc00256a:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    752cbc002571:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cbc002578:	57 00 00 
    752cbc00257b:	4c 89 c7             	mov    rdi,r8
    752cbc00257e:	be 2a 00 00 00       	mov    esi,0x2a
    752cbc002583:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    752cbc002588:	ff d0                	call   rax
    752cbc00258a:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    752cbc00258f:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    752cbc002596:	00 
    752cbc002597:	88 4c 24 0f          	mov    BYTE PTR [rsp+0xf],cl
    752cbc00259b:	45 8b 88 bc 00 00 00 	mov    r9d,DWORD PTR [r8+0xbc]
    752cbc0025a2:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    752cbc0025a5:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    752cbc0025a9:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    752cbc0025ad:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    752cbc0025b1:	41 8b 68 0c          	mov    ebp,DWORD PTR [r8+0xc]
    752cbc0025b5:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    752cbc0025b9:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    752cbc0025bd:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    752cbc0025c1:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    752cbc0025c6:	41 8b 90 e4 00 00 00 	mov    edx,DWORD PTR [r8+0xe4]
    752cbc0025cd:	41 8b 80 e8 00 00 00 	mov    eax,DWORD PTR [r8+0xe8]
    752cbc0025d4:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    752cbc0025d8:	41 8b 80 ec 00 00 00 	mov    eax,DWORD PTR [r8+0xec]
    752cbc0025df:	41 8b 88 f0 00 00 00 	mov    ecx,DWORD PTR [r8+0xf0]
    752cbc0025e6:	89 4c 24 1c          	mov    DWORD PTR [rsp+0x1c],ecx
    752cbc0025ea:	41 8b 88 f8 00 00 00 	mov    ecx,DWORD PTR [r8+0xf8]
    752cbc0025f1:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    752cbc0025f5:	41 8b 88 fc 00 00 00 	mov    ecx,DWORD PTR [r8+0xfc]
    752cbc0025fc:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    752cbc002600:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    752cbc002607:	41 8b 88 14 01 00 00 	mov    ecx,DWORD PTR [r8+0x114]
    752cbc00260e:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    752cbc002612:	41 8b b8 24 01 00 00 	mov    edi,DWORD PTR [r8+0x124]
    752cbc002619:	41 8b 88 34 01 00 00 	mov    ecx,DWORD PTR [r8+0x134]
    752cbc002620:	45 8b a0 5c 01 00 00 	mov    r12d,DWORD PTR [r8+0x15c]
    752cbc002627:	41 89 db             	mov    r11d,ebx
    752cbc00262a:	e9 61 f8 ff ff       	jmp    0x752cbc001e90
