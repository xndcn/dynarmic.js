; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100d0(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65744
  %6 = icmp ugt i32 %5, 60
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb140 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb140, 0
  %11 = sub i32 %guard_lb140, 65744
  %12 = icmp ugt i32 %11, 60
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000100d0_entry, label %lb_guard_miss, !prof !0

insn_0x000100d0_entry:                            ; preds = %lb_guard
  br label %insn_0x000100d0

insn_0x000100d0:                                  ; preds = %insn_0x000100d0_entry
  %15 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %15, align 4
  %sp_dec = sub i32 %sp, 4
  %16 = getelementptr i8, ptr %cpu, i32 24
  %r = load i32, ptr %16, align 4
  %17 = and i32 %sp_dec, 3
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000100d0
  %19 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %20, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65744, i32 %sp_dec, i32 65536)
  %21 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 188
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr i8, ptr %cpu, i64 296
  %25 = load i8, ptr %24, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000100d0
  %26 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %26 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %27 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %28, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %29 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %30, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %31 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %31, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %32 = getelementptr i8, ptr %cpu, i32 28
  %r2 = load i32, ptr %32, align 4
  %33 = and i32 %sp_dec1, 3
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %35 = getelementptr i8, ptr %cpu, i64 188
  %next_pc141 = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 188
  %37 = load i32, ptr %36, align 4
  %38 = getelementptr i8, ptr %cpu, i64 296
  %39 = load i8, ptr %38, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65744, i32 %sp_dec1, i32 65536)
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc142 = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 188
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %cpu, i64 296
  %46 = load i8, ptr %45, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %47 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %47 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %48 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %48 to i64
  %49 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %49, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %50 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %51, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %52 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %52, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %53 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec1, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %55, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %56 = icmp ne i8 %cec_pending, 0
  br i1 %56, label %cec_check, label %cec_checked, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %57 = getelementptr i8, ptr %cpu, i64 188
  %next_pc143 = load i32, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 188
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %cpu, i64 296
  %61 = load i8, ptr %60, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

cec_check:                                        ; preds = %page_wr_done7
  %62 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %64, align 4
  call void @cec_check_pending(ptr %cpu)
  %65 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %65, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

cec_checked:                                      ; preds = %did_jump_cont18, %page_wr_done7
  br label %insn_0x000100d2_entry

did_jump_exit17:                                  ; preds = %cec_check
  %66 = getelementptr i8, ptr %cpu, i64 188
  %next_pc144 = load i32, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i64 188
  %68 = load i32, ptr %67, align 4
  %69 = getelementptr i8, ptr %cpu, i64 296
  %70 = load i8, ptr %69, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x000100d2_entry:                            ; preds = %cec_checked
  br label %insn_0x000100d2

insn_0x000100d2:                                  ; preds = %insn_0x000100d2_entry
  %71 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %72, align 4
  %sp1 = sub i32 %sp_dec1, 4
  %73 = and i32 %sp1, 3
  %74 = icmp ne i32 %73, 0
  br i1 %74, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x000100d2
  %75 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %77, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65746, i32 %sp1, i32 65536)
  %78 = getelementptr i8, ptr %cpu, i64 188
  %next_pc145 = load i32, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 188
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %cpu, i64 296
  %82 = load i8, ptr %81, align 1
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x000100d2
  %83 = lshr i32 %sp1, 12
  %page_index26 = zext i32 %83 to i64
  %page_slot27 = getelementptr ptr, ptr %page_table, i64 %page_index26
  %page28 = load ptr, ptr %page_slot27, align 8
  %page_mapped29 = icmp ne ptr %page28, null
  br i1 %page_mapped29, label %page_wr_fast23, label %page_wr_slow24, !prof !0

page_wr_fast23:                                   ; preds = %data_aligned22
  %84 = and i32 %sp1, 4095
  %page_offset30 = zext i32 %84 to i64
  %85 = getelementptr i8, ptr %page28, i64 %page_offset30
  store i32 %rets, ptr %85, align 4
  br label %page_wr_done25

page_wr_slow24:                                   ; preds = %data_aligned22
  %86 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %88, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %89 = getelementptr i8, ptr %cpu, i32 296
  %dj33 = load i8, ptr %89, align 1
  %dj_set34 = icmp ne i8 %dj33, 0
  br i1 %dj_set34, label %did_jump_exit31, label %did_jump_cont32, !prof !1

page_wr_done25:                                   ; preds = %did_jump_cont32, %page_wr_fast23
  %sp2 = sub i32 %sp1, 4
  %90 = and i32 %sp2, 3
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %data_misaligned35, label %data_aligned36, !prof !1

did_jump_exit31:                                  ; preds = %page_wr_slow24
  %92 = getelementptr i8, ptr %cpu, i64 188
  %next_pc146 = load i32, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 188
  %94 = load i32, ptr %93, align 4
  %95 = getelementptr i8, ptr %cpu, i64 296
  %96 = load i8, ptr %95, align 1
  br label %chain_exit

did_jump_cont32:                                  ; preds = %page_wr_slow24
  br label %page_wr_done25

data_misaligned35:                                ; preds = %page_wr_done25
  %97 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %99, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65746, i32 %sp2, i32 65536)
  %100 = getelementptr i8, ptr %cpu, i64 188
  %next_pc147 = load i32, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 188
  %102 = load i32, ptr %101, align 4
  %103 = getelementptr i8, ptr %cpu, i64 296
  %104 = load i8, ptr %103, align 1
  br label %chain_exit

data_aligned36:                                   ; preds = %page_wr_done25
  %105 = lshr i32 %sp2, 12
  %page_index40 = zext i32 %105 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_wr_fast37, label %page_wr_slow38, !prof !0

page_wr_fast37:                                   ; preds = %data_aligned36
  %106 = and i32 %sp2, 4095
  %page_offset44 = zext i32 %106 to i64
  %107 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %fp, ptr %107, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %data_aligned36
  %108 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %110, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %111 = getelementptr i8, ptr %cpu, i32 296
  %dj47 = load i8, ptr %111, align 1
  %dj_set48 = icmp ne i8 %dj47, 0
  br i1 %dj_set48, label %did_jump_exit45, label %did_jump_cont46, !prof !1

page_wr_done39:                                   ; preds = %did_jump_cont46, %page_wr_fast37
  %112 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %112, align 4
  %sp3 = sub i32 %sp2, 0
  %113 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %113, align 4
  %cec_pending49 = load i8, ptr %cec_pending_flag, align 1
  %114 = icmp ne i8 %cec_pending49, 0
  br i1 %114, label %cec_check50, label %cec_checked51, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %115 = getelementptr i8, ptr %cpu, i64 188
  %next_pc148 = load i32, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 188
  %117 = load i32, ptr %116, align 4
  %118 = getelementptr i8, ptr %cpu, i64 296
  %119 = load i8, ptr %118, align 1
  br label %chain_exit

did_jump_cont46:                                  ; preds = %page_wr_slow38
  br label %page_wr_done39

cec_check50:                                      ; preds = %page_wr_done39
  %120 = getelementptr i8, ptr %cpu, i32 188
  store i32 65750, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %122, align 4
  call void @cec_check_pending(ptr %cpu)
  %123 = getelementptr i8, ptr %cpu, i32 296
  %dj54 = load i8, ptr %123, align 1
  %dj_set55 = icmp ne i8 %dj54, 0
  br i1 %dj_set55, label %did_jump_exit52, label %did_jump_cont53, !prof !1

cec_checked51:                                    ; preds = %did_jump_cont53, %page_wr_done39
  br label %insn_0x000100d6_entry

did_jump_exit52:                                  ; preds = %cec_check50
  %124 = getelementptr i8, ptr %cpu, i64 188
  %next_pc149 = load i32, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i64 188
  %126 = load i32, ptr %125, align 4
  %127 = getelementptr i8, ptr %cpu, i64 296
  %128 = load i8, ptr %127, align 1
  br label %chain_exit

did_jump_cont53:                                  ; preds = %cec_check50
  br label %cec_checked51

insn_0x000100d6_entry:                            ; preds = %cec_checked51
  br label %insn_0x000100d6

insn_0x000100d6:                                  ; preds = %insn_0x000100d6_entry
  %129 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %129, align 4
  %diff = sub i32 %rx, 0
  %130 = icmp eq i32 %diff, 0
  %az = zext i1 %130 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %131 = xor i32 %flgn, %flgs
  %132 = xor i32 %flgs, 0
  %overflow = and i32 %132, %131
  %an = xor i32 %flgn, %overflow
  %133 = icmp ule i32 0, %rx
  %ac0 = zext i1 %133 to i32
  %134 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %137, align 4
  %138 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %138, align 4
  br label %insn_0x000100d8_entry

insn_0x000100d8_entry:                            ; preds = %insn_0x000100d6
  br label %insn_0x000100d8

insn_0x000100d8:                                  ; preds = %insn_0x000100d8_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x000100d8
  %139 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %140, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %141 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %141 monotonic, align 4, !range !2
  %142 = icmp ult i32 %chain_total, %chain_budget
  br i1 %142, label %chain_go, label %chain_leave150, !prof !0

brt_fallthru:                                     ; preds = %insn_0x000100d8
  br label %insn_0x000100da_entry

insn_0x000100da_entry:                            ; preds = %brt_fallthru
  br label %insn_0x000100da

insn_0x000100da:                                  ; preds = %insn_0x000100da_entry
  %lo_kept = and i32 %r, 65535
  %with_hi = or i32 %lo_kept, 1638400
  %143 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_hi, ptr %143, align 4
  br label %insn_0x000100de_entry

insn_0x000100de_entry:                            ; preds = %insn_0x000100da
  br label %insn_0x000100de

insn_0x000100de:                                  ; preds = %insn_0x000100de_entry
  %lo_kept56 = and i32 %r2, 65535
  %with_hi57 = or i32 %lo_kept56, 1013841920
  %144 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_hi57, ptr %144, align 4
  br label %insn_0x000100e2_entry

insn_0x000100e2_entry:                            ; preds = %insn_0x000100de
  br label %insn_0x000100e2

insn_0x000100e2:                                  ; preds = %insn_0x000100e2_entry
  %145 = getelementptr i8, ptr %cpu, i32 8
  store i32 0, ptr %145, align 4
  br label %insn_0x000100e4_entry

insn_0x000100e4_entry:                            ; preds = %insn_0x000100e2
  br label %insn_0x000100e4

insn_0x000100e4:                                  ; preds = %insn_0x000100e4_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 26125
  %146 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_lo, ptr %146, align 4
  br label %insn_0x000100e8_entry

insn_0x000100e8_entry:                            ; preds = %insn_0x000100e4
  br label %insn_0x000100e8

insn_0x000100e8:                                  ; preds = %insn_0x000100e8_entry
  %hi_kept58 = and i32 %with_hi57, -65536
  %with_lo59 = or i32 %hi_kept58, 62303
  %147 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_lo59, ptr %147, align 4
  br label %insn_0x000100ec_entry

insn_0x000100ec_entry:                            ; preds = %insn_0x000100e8
  br label %insn_0x000100ec

insn_0x000100ec:                                  ; preds = %insn_0x000100ec_entry
  %148 = getelementptr i8, ptr %cpu, i32 4
  %a = load i32, ptr %148, align 4
  %mul = mul i32 %a, %with_lo
  %149 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mul, ptr %149, align 4
  br label %insn_0x000100ee_entry

insn_0x000100ee_entry:                            ; preds = %insn_0x000100ec
  br label %insn_0x000100ee

insn_0x000100ee:                                  ; preds = %insn_0x000100ee_entry
  %add32 = add i32 %mul, %with_lo59
  %150 = getelementptr i8, ptr %cpu, i32 4
  store i32 %add32, ptr %150, align 4
  %flgs60 = lshr i32 %mul, 31
  %flgo = lshr i32 %with_lo59, 31
  %flgn61 = lshr i32 %add32, 31
  %151 = xor i32 %flgo, %flgn61
  %152 = xor i32 %flgs60, %flgn61
  %153 = and i32 %152, %151
  %154 = xor i32 %mul, -1
  %155 = icmp ult i32 %154, %with_lo59
  %ac062 = zext i1 %155 to i32
  %156 = icmp eq i32 %add32, 0
  %az63 = zext i1 %156 to i32
  %an64 = lshr i32 %add32, 31
  %157 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az63, ptr %157, align 4
  %158 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an64, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %159, align 4
  %160 = or i32 %vs_cur, %153
  %161 = getelementptr i8, ptr %cpu, i32 248
  store i32 %153, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i32 252
  store i32 %153, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i32 256
  store i32 %160, ptr %163, align 4
  %164 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac062, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac062, ptr %165, align 4
  br label %insn_0x000100f0_entry

insn_0x000100f0_entry:                            ; preds = %insn_0x000100ee
  br label %insn_0x000100f0

insn_0x000100f0:                                  ; preds = %insn_0x000100f0_entry
  %lsr32 = lshr i32 %add32, 13
  %166 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsr32, ptr %166, align 4
  %167 = icmp eq i32 %lsr32, 0
  %az65 = zext i1 %167 to i32
  %an66 = lshr i32 %lsr32, 31
  %168 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az65, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an66, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %171, align 4
  br label %insn_0x000100f4_entry

insn_0x000100f4_entry:                            ; preds = %insn_0x000100f0
  br label %insn_0x000100f4

insn_0x000100f4:                                  ; preds = %insn_0x000100f4_entry
  %xor32 = xor i32 %add32, %lsr32
  %172 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %172, align 4
  %173 = icmp eq i32 %xor32, 0
  %az67 = zext i1 %173 to i32
  %an68 = lshr i32 %xor32, 31
  %174 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az67, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an68, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %179, align 4
  br label %insn_0x000100f6_entry

insn_0x000100f6_entry:                            ; preds = %insn_0x000100f4
  br label %insn_0x000100f6

insn_0x000100f6:                                  ; preds = %insn_0x000100f6_entry
  %lsl32 = shl i32 %xor32, 7
  %180 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsl32, ptr %180, align 4
  %181 = icmp eq i32 %lsl32, 0
  %az69 = zext i1 %181 to i32
  %an70 = lshr i32 %lsl32, 31
  %182 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az69, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an70, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %185, align 4
  br label %insn_0x000100fa_entry

insn_0x000100fa_entry:                            ; preds = %insn_0x000100f6
  br label %insn_0x000100fa

insn_0x000100fa:                                  ; preds = %insn_0x000100fa_entry
  %lsr = lshr i32 %xor32, 25
  %186 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr, ptr %186, align 4
  %187 = icmp eq i32 %lsr, 0
  %az71 = zext i1 %187 to i32
  %an72 = lshr i32 %lsr, 31
  %188 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az71, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an72, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %191, align 4
  br label %insn_0x000100fc_entry

insn_0x000100fc_entry:                            ; preds = %insn_0x000100fa
  br label %insn_0x000100fc

insn_0x000100fc:                                  ; preds = %insn_0x000100fc_entry
  %192 = getelementptr i8, ptr %cpu, i32 8
  store i32 1, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %194, align 4
  %195 = or i32 %160, 0
  %196 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %196, align 4
  %197 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i32 256
  store i32 %195, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %200, align 4
  br label %insn_0x000100fe_entry

insn_0x000100fe_entry:                            ; preds = %insn_0x000100fc
  br label %insn_0x000100fe

insn_0x000100fe:                                  ; preds = %insn_0x000100fe_entry
  %or32 = or i32 %lsl32, %lsr
  %201 = getelementptr i8, ptr %cpu, i32 4
  store i32 %or32, ptr %201, align 4
  %202 = icmp eq i32 %or32, 0
  %az73 = zext i1 %202 to i32
  %an74 = lshr i32 %or32, 31
  %203 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az73, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an74, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %206, align 4
  %207 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %208, align 4
  br label %insn_0x00010100_entry

insn_0x00010100_entry:                            ; preds = %insn_0x000100fe
  br label %insn_0x00010100

insn_0x00010100:                                  ; preds = %insn_0x00010100_entry
  %209 = icmp ule i32 %rx, 1
  %cc = zext i1 %209 to i32
  %210 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %210, align 4
  %211 = icmp eq i32 %rx, 1
  %az75 = zext i1 %211 to i32
  %212 = icmp ugt i32 1, %rx
  %an76 = zext i1 %212 to i32
  %213 = icmp ule i32 1, %rx
  %ac077 = zext i1 %213 to i32
  %214 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az75, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an76, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac077, ptr %216, align 4
  %217 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac077, ptr %217, align 4
  br label %insn_0x00010102_entry

insn_0x00010102_entry:                            ; preds = %insn_0x00010100
  br label %insn_0x00010102

insn_0x00010102:                                  ; preds = %insn_0x00010102_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010102
  %218 = getelementptr i8, ptr %cpu, i32 188
  store i32 65772, ptr %218, align 4
  %219 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets153 = load i32, ptr %219, align 4
  %chain_total154 = add nuw i32 %chain_packets153, 19
  %220 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget155 = load atomic i32, ptr %220 monotonic, align 4, !range !2
  %221 = icmp ult i32 %chain_total154, %chain_budget155
  br i1 %221, label %chain_go151, label %chain_leave152, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010102
  br label %insn_0x00010104_entry

insn_0x00010104_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010104

insn_0x00010104:                                  ; preds = %insn_0x00010104_entry
  %222 = and i32 %sp2, 3
  %223 = icmp ne i32 %222, 0
  br i1 %223, label %data_misaligned78, label %data_aligned79, !prof !1

data_misaligned78:                                ; preds = %insn_0x00010104
  %224 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %224, align 4
  %225 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %225, align 4
  %226 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %226, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp2, i32 0)
  %227 = getelementptr i8, ptr %cpu, i64 188
  %next_pc160 = load i32, ptr %227, align 4
  %228 = getelementptr i8, ptr %cpu, i64 188
  %229 = load i32, ptr %228, align 4
  %230 = getelementptr i8, ptr %cpu, i64 296
  %231 = load i8, ptr %230, align 1
  br label %chain_exit

data_aligned79:                                   ; preds = %insn_0x00010104
  %232 = lshr i32 %sp2, 12
  %page_index80 = zext i32 %232 to i64
  %page_slot81 = getelementptr ptr, ptr %page_table, i64 %page_index80
  %page82 = load ptr, ptr %page_slot81, align 8
  %page_mapped83 = icmp ne ptr %page82, null
  br i1 %page_mapped83, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned79
  %233 = and i32 %sp2, 4095
  %page_offset84 = zext i32 %233 to i64
  %234 = getelementptr i8, ptr %page82, i64 %page_offset84
  %page_val = load i32, ptr %234, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned79
  %235 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %235, align 4
  %236 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %236, align 4
  %237 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %237, align 4
  %238 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %239 = getelementptr i8, ptr %cpu, i32 296
  %dj87 = load i8, ptr %239, align 1
  %dj_set88 = icmp ne i8 %dj87, 0
  br i1 %dj_set88, label %did_jump_exit85, label %did_jump_cont86, !prof !1

page_done:                                        ; preds = %did_jump_cont86, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %238, %did_jump_cont86 ]
  %sp189 = add i32 %sp2, 4
  %240 = and i32 %sp189, 3
  %241 = icmp ne i32 %240, 0
  br i1 %241, label %data_misaligned90, label %data_aligned91, !prof !1

did_jump_exit85:                                  ; preds = %page_slow
  %242 = getelementptr i8, ptr %cpu, i64 188
  %next_pc161 = load i32, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i64 188
  %244 = load i32, ptr %243, align 4
  %245 = getelementptr i8, ptr %cpu, i64 296
  %246 = load i8, ptr %245, align 1
  br label %chain_exit

did_jump_cont86:                                  ; preds = %page_slow
  br label %page_done

data_misaligned90:                                ; preds = %page_done
  %247 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %247, align 4
  %248 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %248, align 4
  %249 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %249, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp189, i32 0)
  %250 = getelementptr i8, ptr %cpu, i64 188
  %next_pc162 = load i32, ptr %250, align 4
  %251 = getelementptr i8, ptr %cpu, i64 188
  %252 = load i32, ptr %251, align 4
  %253 = getelementptr i8, ptr %cpu, i64 296
  %254 = load i8, ptr %253, align 1
  br label %chain_exit

data_aligned91:                                   ; preds = %page_done
  %255 = lshr i32 %sp189, 12
  %page_index95 = zext i32 %255 to i64
  %page_slot96 = getelementptr ptr, ptr %page_table, i64 %page_index95
  %page97 = load ptr, ptr %page_slot96, align 8
  %page_mapped98 = icmp ne ptr %page97, null
  br i1 %page_mapped98, label %page_fast92, label %page_slow93, !prof !0

page_fast92:                                      ; preds = %data_aligned91
  %256 = and i32 %sp189, 4095
  %page_offset99 = zext i32 %256 to i64
  %257 = getelementptr i8, ptr %page97, i64 %page_offset99
  %page_val100 = load i32, ptr %257, align 4
  br label %page_done94

page_slow93:                                      ; preds = %data_aligned91
  %258 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %258, align 4
  %259 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %259, align 4
  %260 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %260, align 4
  %261 = call i32 @mem_read32(ptr %mem, i32 %sp189)
  %262 = getelementptr i8, ptr %cpu, i32 296
  %dj103 = load i8, ptr %262, align 1
  %dj_set104 = icmp ne i8 %dj103, 0
  br i1 %dj_set104, label %did_jump_exit101, label %did_jump_cont102, !prof !1

page_done94:                                      ; preds = %did_jump_cont102, %page_fast92
  %mem_val105 = phi i32 [ %page_val100, %page_fast92 ], [ %261, %did_jump_cont102 ]
  %sp2106 = add i32 %sp189, 4
  %263 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %263, align 4
  %264 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val105, ptr %264, align 4
  %265 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2106, ptr %265, align 4
  br label %insn_0x00010108_entry

did_jump_exit101:                                 ; preds = %page_slow93
  %266 = getelementptr i8, ptr %cpu, i64 188
  %next_pc163 = load i32, ptr %266, align 4
  %267 = getelementptr i8, ptr %cpu, i64 188
  %268 = load i32, ptr %267, align 4
  %269 = getelementptr i8, ptr %cpu, i64 296
  %270 = load i8, ptr %269, align 1
  br label %chain_exit

did_jump_cont102:                                 ; preds = %page_slow93
  br label %page_done94

insn_0x00010108_entry:                            ; preds = %page_done94
  br label %insn_0x00010108

insn_0x00010108:                                  ; preds = %insn_0x00010108_entry
  %271 = getelementptr i8, ptr %cpu, i32 0
  store i32 %or32, ptr %271, align 4
  br label %insn_0x0001010a_entry

insn_0x0001010a_entry:                            ; preds = %insn_0x00010108
  br label %insn_0x0001010a

insn_0x0001010a:                                  ; preds = %insn_0x0001010a_entry
  %272 = and i32 %sp2106, 3
  %273 = icmp ne i32 %272, 0
  br i1 %273, label %data_misaligned107, label %data_aligned108, !prof !1

data_misaligned107:                               ; preds = %insn_0x0001010a
  %274 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %274, align 4
  %275 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %275, align 4
  %276 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %276, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp2106, i32 0)
  %277 = getelementptr i8, ptr %cpu, i64 188
  %next_pc164 = load i32, ptr %277, align 4
  %278 = getelementptr i8, ptr %cpu, i64 188
  %279 = load i32, ptr %278, align 4
  %280 = getelementptr i8, ptr %cpu, i64 296
  %281 = load i8, ptr %280, align 1
  br label %chain_exit

data_aligned108:                                  ; preds = %insn_0x0001010a
  %282 = lshr i32 %sp2106, 12
  %page_index112 = zext i32 %282 to i64
  %page_slot113 = getelementptr ptr, ptr %page_table, i64 %page_index112
  %page114 = load ptr, ptr %page_slot113, align 8
  %page_mapped115 = icmp ne ptr %page114, null
  br i1 %page_mapped115, label %page_fast109, label %page_slow110, !prof !0

page_fast109:                                     ; preds = %data_aligned108
  %283 = and i32 %sp2106, 4095
  %page_offset116 = zext i32 %283 to i64
  %284 = getelementptr i8, ptr %page114, i64 %page_offset116
  %page_val117 = load i32, ptr %284, align 4
  br label %page_done111

page_slow110:                                     ; preds = %data_aligned108
  %285 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %285, align 4
  %286 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %286, align 4
  %287 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %287, align 4
  %288 = call i32 @mem_read32(ptr %mem, i32 %sp2106)
  %289 = getelementptr i8, ptr %cpu, i32 296
  %dj120 = load i8, ptr %289, align 1
  %dj_set121 = icmp ne i8 %dj120, 0
  br i1 %dj_set121, label %did_jump_exit118, label %did_jump_cont119, !prof !1

page_done111:                                     ; preds = %did_jump_cont119, %page_fast109
  %mem_val122 = phi i32 [ %page_val117, %page_fast109 ], [ %288, %did_jump_cont119 ]
  %290 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val122, ptr %290, align 4
  %sp_inc = add i32 %sp2106, 4
  %291 = and i32 %sp_inc, 3
  %292 = icmp ne i32 %291, 0
  br i1 %292, label %data_misaligned123, label %data_aligned124, !prof !1

did_jump_exit118:                                 ; preds = %page_slow110
  %293 = getelementptr i8, ptr %cpu, i64 188
  %next_pc165 = load i32, ptr %293, align 4
  %294 = getelementptr i8, ptr %cpu, i64 188
  %295 = load i32, ptr %294, align 4
  %296 = getelementptr i8, ptr %cpu, i64 296
  %297 = load i8, ptr %296, align 1
  br label %chain_exit

did_jump_cont119:                                 ; preds = %page_slow110
  br label %page_done111

data_misaligned123:                               ; preds = %page_done111
  %298 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %298, align 4
  %299 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %299, align 4
  %300 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %300, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp_inc, i32 0)
  %301 = getelementptr i8, ptr %cpu, i64 188
  %next_pc166 = load i32, ptr %301, align 4
  %302 = getelementptr i8, ptr %cpu, i64 188
  %303 = load i32, ptr %302, align 4
  %304 = getelementptr i8, ptr %cpu, i64 296
  %305 = load i8, ptr %304, align 1
  br label %chain_exit

data_aligned124:                                  ; preds = %page_done111
  %306 = lshr i32 %sp_inc, 12
  %page_index128 = zext i32 %306 to i64
  %page_slot129 = getelementptr ptr, ptr %page_table, i64 %page_index128
  %page130 = load ptr, ptr %page_slot129, align 8
  %page_mapped131 = icmp ne ptr %page130, null
  br i1 %page_mapped131, label %page_fast125, label %page_slow126, !prof !0

page_fast125:                                     ; preds = %data_aligned124
  %307 = and i32 %sp_inc, 4095
  %page_offset132 = zext i32 %307 to i64
  %308 = getelementptr i8, ptr %page130, i64 %page_offset132
  %page_val133 = load i32, ptr %308, align 4
  br label %page_done127

page_slow126:                                     ; preds = %data_aligned124
  %309 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %309, align 4
  %310 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %310, align 4
  %311 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %311, align 4
  %312 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %313 = getelementptr i8, ptr %cpu, i32 296
  %dj136 = load i8, ptr %313, align 1
  %dj_set137 = icmp ne i8 %dj136, 0
  br i1 %dj_set137, label %did_jump_exit134, label %did_jump_cont135, !prof !1

page_done127:                                     ; preds = %did_jump_cont135, %page_fast125
  %mem_val138 = phi i32 [ %page_val133, %page_fast125 ], [ %312, %did_jump_cont135 ]
  %314 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val138, ptr %314, align 4
  %sp_inc139 = add i32 %sp_inc, 4
  %315 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc139, ptr %315, align 4
  br label %insn_0x0001010c_entry

did_jump_exit134:                                 ; preds = %page_slow126
  %316 = getelementptr i8, ptr %cpu, i64 188
  %next_pc167 = load i32, ptr %316, align 4
  %317 = getelementptr i8, ptr %cpu, i64 188
  %318 = load i32, ptr %317, align 4
  %319 = getelementptr i8, ptr %cpu, i64 296
  %320 = load i8, ptr %319, align 1
  br label %chain_exit

did_jump_cont135:                                 ; preds = %page_slow126
  br label %page_done127

insn_0x0001010c_entry:                            ; preds = %page_done127
  br label %insn_0x0001010c

insn_0x0001010c:                                  ; preds = %insn_0x0001010c_entry
  %lsb = and i32 %mem_val105, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001010c
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001010c
  %321 = getelementptr i8, ptr %cpu, i32 188
  store i32 65804, ptr %321, align 4
  %322 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %322, align 4
  %323 = getelementptr i8, ptr %cpu, i32 308
  store i32 23, ptr %323, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %324 = getelementptr i8, ptr %cpu, i64 188
  %next_pc168 = load i32, ptr %324, align 4
  %325 = getelementptr i8, ptr %cpu, i64 188
  %326 = load i32, ptr %325, align 4
  %327 = getelementptr i8, ptr %cpu, i64 296
  %328 = load i8, ptr %327, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %329 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %329, align 1
  ret void

chain_leave:                                      ; No predecessors!
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526368
  %330 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %330, align 4
  %331 = icmp eq i32 %slot_pc, 65796
  br i1 %331, label %chain_hit, label %chain_leave150, !prof !0

chain_leave150:                                   ; preds = %chain_go, %brt_taken
  %332 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %332, align 4
  %333 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %333, align 4
  %334 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %334, align 4
  %335 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %335, align 1
  ret void

chain_hit:                                        ; preds = %chain_go
  %336 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %336, align 4
  %337 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %337, align 4
  %338 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %338, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go151:                                      ; preds = %brcc_taken
  %chain_slot156 = getelementptr i8, ptr %chain_table, i64 526176
  %339 = getelementptr i8, ptr %chain_slot156, i64 0
  %slot_pc157 = load i32, ptr %339, align 4
  %340 = icmp eq i32 %slot_pc157, 65772
  br i1 %340, label %chain_hit158, label %chain_leave152, !prof !0

chain_leave152:                                   ; preds = %chain_go151, %brcc_taken
  %341 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %341, align 4
  %342 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %342, align 4
  %343 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %343, align 4
  %344 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %344, align 1
  ret void

chain_hit158:                                     ; preds = %chain_go151
  %345 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %345, align 4
  %346 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total154, ptr %346, align 4
  %347 = getelementptr i8, ptr %chain_slot156, i64 8
  %chain_fn159 = load ptr, ptr %347, align 8
  musttail call swifttailcc void %chain_fn159(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit134, %data_misaligned123, %did_jump_exit118, %data_misaligned107, %did_jump_exit101, %data_misaligned90, %did_jump_exit85, %data_misaligned78, %did_jump_exit52, %did_jump_exit45, %data_misaligned35, %did_jump_exit31, %data_misaligned21, %did_jump_exit17, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc169 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc141, %did_jump_exit ], [ %next_pc142, %data_misaligned3 ], [ %next_pc143, %did_jump_exit13 ], [ %next_pc144, %did_jump_exit17 ], [ %next_pc145, %data_misaligned21 ], [ %next_pc146, %did_jump_exit31 ], [ %next_pc147, %data_misaligned35 ], [ %next_pc148, %did_jump_exit45 ], [ %next_pc149, %did_jump_exit52 ], [ %next_pc160, %data_misaligned78 ], [ %next_pc161, %did_jump_exit85 ], [ %next_pc162, %data_misaligned90 ], [ %next_pc163, %did_jump_exit101 ], [ %next_pc164, %data_misaligned107 ], [ %next_pc165, %did_jump_exit118 ], [ %next_pc166, %data_misaligned123 ], [ %next_pc167, %did_jump_exit134 ], [ %mem_val105, %jump_aligned ], [ %next_pc168, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit17 ], [ 2, %data_misaligned21 ], [ 2, %did_jump_exit31 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit52 ], [ 20, %data_misaligned78 ], [ 20, %did_jump_exit85 ], [ 20, %data_misaligned90 ], [ 20, %did_jump_exit101 ], [ 22, %data_misaligned107 ], [ 22, %did_jump_exit118 ], [ 22, %data_misaligned123 ], [ 22, %did_jump_exit134 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail = phi i32 [ %23, %data_misaligned ], [ %37, %did_jump_exit ], [ %44, %data_misaligned3 ], [ %59, %did_jump_exit13 ], [ %68, %did_jump_exit17 ], [ %80, %data_misaligned21 ], [ %94, %did_jump_exit31 ], [ %102, %data_misaligned35 ], [ %117, %did_jump_exit45 ], [ %126, %did_jump_exit52 ], [ %229, %data_misaligned78 ], [ %244, %did_jump_exit85 ], [ %252, %data_misaligned90 ], [ %268, %did_jump_exit101 ], [ %279, %data_misaligned107 ], [ %295, %did_jump_exit118 ], [ %303, %data_misaligned123 ], [ %318, %did_jump_exit134 ], [ %mem_val105, %jump_aligned ], [ %326, %jump_misalign ]
  %tail170 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %did_jump_exit17 ], [ 4, %data_misaligned21 ], [ 4, %did_jump_exit31 ], [ 4, %data_misaligned35 ], [ 4, %did_jump_exit45 ], [ 4, %did_jump_exit52 ], [ 4, %data_misaligned78 ], [ 4, %did_jump_exit85 ], [ 4, %data_misaligned90 ], [ 4, %did_jump_exit101 ], [ 2, %data_misaligned107 ], [ 2, %did_jump_exit118 ], [ 2, %data_misaligned123 ], [ 2, %did_jump_exit134 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail171 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit17 ], [ 2, %data_misaligned21 ], [ 2, %did_jump_exit31 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit52 ], [ 20, %data_misaligned78 ], [ 20, %did_jump_exit85 ], [ 20, %data_misaligned90 ], [ 20, %did_jump_exit101 ], [ 22, %data_misaligned107 ], [ 22, %did_jump_exit118 ], [ 22, %data_misaligned123 ], [ 22, %did_jump_exit134 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail172 = phi i8 [ %25, %data_misaligned ], [ %39, %did_jump_exit ], [ %46, %data_misaligned3 ], [ %61, %did_jump_exit13 ], [ %70, %did_jump_exit17 ], [ %82, %data_misaligned21 ], [ %96, %did_jump_exit31 ], [ %104, %data_misaligned35 ], [ %119, %did_jump_exit45 ], [ %128, %did_jump_exit52 ], [ %231, %data_misaligned78 ], [ %246, %did_jump_exit85 ], [ %254, %data_misaligned90 ], [ %270, %did_jump_exit101 ], [ %281, %data_misaligned107 ], [ %297, %did_jump_exit118 ], [ %305, %data_misaligned123 ], [ %320, %did_jump_exit134 ], [ 1, %jump_aligned ], [ %328, %jump_misalign ]
  %348 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets174 = load i32, ptr %348, align 4
  %chain_total175 = add nuw i32 %chain_packets174, %packets
  %349 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget176 = load atomic i32, ptr %349 monotonic, align 4, !range !2
  %350 = icmp ult i32 %chain_total175, %chain_budget176
  br i1 %350, label %chain_lookup, label %chain_leave173, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %351 = lshr i32 %next_pc169, 1
  %352 = and i32 %351, 65535
  %353 = zext i32 %352 to i64
  %354 = mul i64 %353, 16
  %chain_slot177 = getelementptr i8, ptr %chain_table, i64 %354
  %355 = getelementptr i8, ptr %chain_slot177, i64 0
  %slot_pc178 = load i32, ptr %355, align 4
  %356 = icmp eq i32 %slot_pc178, %next_pc169
  br i1 %356, label %chain_hit179, label %chain_leave173, !prof !0

chain_leave173:                                   ; preds = %chain_lookup, %chain_exit
  %357 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %357, align 4
  %358 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail170, ptr %358, align 4
  %359 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail171, ptr %359, align 4
  %360 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail172, ptr %360, align 1
  ret void

chain_hit179:                                     ; preds = %chain_lookup
  %361 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc169, ptr %361, align 4
  %362 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total175, ptr %362, align 4
  %363 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %363, align 1
  %364 = getelementptr i8, ptr %chain_slot177, i64 8
  %chain_fn180 = load ptr, ptr %364, align 8
  musttail call swifttailcc void %chain_fn180(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
