
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66696-0-128835395790343.bin:     file format binary


Disassembly of section .data:

0000752cd4002607 <.data>:
    752cd4002607:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    752cd400260e:	01 
    752cd400260f:	58                   	pop    rax
    752cd4002610:	c2 08 00             	ret    0x8
    752cd4002613:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10490
    752cd400261a:	90 04 01 00 
    752cd400261e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002625:	02 00 00 00 
    752cd4002629:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd4002630:	03 00 00 00 
    752cd4002634:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400263b:	57 00 00 
    752cd400263e:	4c 89 f7             	mov    rdi,r14
    752cd4002641:	be f4 12 01 00       	mov    esi,0x112f4
    752cd4002646:	ff d0                	call   rax
    752cd4002648:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400264f:	00 
    752cd4002650:	0f 84 be f0 ff e7    	je     0x752cbc001714
    752cd4002656:	b8 02 00 00 00       	mov    eax,0x2
    752cd400265b:	b9 03 00 00 00       	mov    ecx,0x3
    752cd4002660:	e9 96 00 00 00       	jmp    0x752cd40026fb
    752cd4002665:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049a
    752cd400266c:	9a 04 01 00 
    752cd4002670:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002677:	02 00 00 00 
    752cd400267b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    752cd4002682:	06 00 00 00 
    752cd4002686:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400268d:	57 00 00 
    752cd4002690:	4c 89 f7             	mov    rdi,r14
    752cd4002693:	be f8 12 01 00       	mov    esi,0x112f8
    752cd4002698:	ff d0                	call   rax
    752cd400269a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd40026a1:	00 
    752cd40026a2:	0f 84 8e f0 ff e7    	je     0x752cbc001736
    752cd40026a8:	b8 02 00 00 00       	mov    eax,0x2
    752cd40026ad:	b9 06 00 00 00       	mov    ecx,0x6
    752cd40026b2:	eb 47                	jmp    0x752cd40026fb
    752cd40026b4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    752cd40026bb:	9c 04 01 00 
    752cd40026bf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40026c6:	04 00 00 00 
    752cd40026ca:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    752cd40026d1:	07 00 00 00 
    752cd40026d5:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd40026dc:	57 00 00 
    752cd40026df:	4c 89 ef             	mov    rdi,r13
    752cd40026e2:	4c 89 f6             	mov    rsi,r14
    752cd40026e5:	ba 9c 04 01 00       	mov    edx,0x1049c
    752cd40026ea:	89 d9                	mov    ecx,ebx
    752cd40026ec:	45 31 c0             	xor    r8d,r8d
    752cd40026ef:	ff d0                	call   rax
    752cd40026f1:	b8 04 00 00 00       	mov    eax,0x4
    752cd40026f6:	b9 07 00 00 00       	mov    ecx,0x7
    752cd40026fb:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    752cd4002702:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    752cd4002709:	01 ca                	add    edx,ecx
    752cd400270b:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    752cd4002712:	39 fa                	cmp    edx,edi
    752cd4002714:	0f 83 b9 00 00 00    	jae    0x752cd40027d3
    752cd400271a:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    752cd4002721:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    752cd4002727:	41 39 34 3f          	cmp    DWORD PTR [r15+rdi*1],esi
    752cd400272b:	0f 85 a2 00 00 00    	jne    0x752cd40027d3
    752cd4002731:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    752cd4002738:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cd400273f:	00 
    752cd4002740:	49 8b 44 3f 08       	mov    rax,QWORD PTR [r15+rdi*1+0x8]
    752cd4002745:	59                   	pop    rcx
    752cd4002746:	ff e0                	jmp    rax
    752cd4002748:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    752cd400274f:	9c 04 01 00 
    752cd4002753:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd400275a:	04 00 00 00 
    752cd400275e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    752cd4002765:	07 00 00 00 
    752cd4002769:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002770:	57 00 00 
    752cd4002773:	4c 89 f7             	mov    rdi,r14
    752cd4002776:	89 de                	mov    esi,ebx
    752cd4002778:	ff d0                	call   rax
    752cd400277a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4002781:	00 
    752cd4002782:	0f 85 69 ff ff ff    	jne    0x752cd40026f1
    752cd4002788:	41 89 c4             	mov    r12d,eax
    752cd400278b:	e9 d8 ef ff e7       	jmp    0x752cbc001768
    752cd4002790:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1049c
    752cd4002797:	9c 04 01 00 
    752cd400279b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40027a2:	04 00 00 00 
    752cd40027a6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    752cd40027ad:	07 00 00 00 
    752cd40027b1:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40027b8:	57 00 00 
    752cd40027bb:	4c 89 f7             	mov    rdi,r14
    752cd40027be:	ff d0                	call   rax
    752cd40027c0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd40027c7:	00 
    752cd40027c8:	0f 84 b9 ef ff e7    	je     0x752cbc001787
    752cd40027ce:	e9 1e ff ff ff       	jmp    0x752cd40026f1
    752cd40027d3:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    752cd40027da:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    752cd40027e1:	58                   	pop    rax
    752cd40027e2:	c2 08 00             	ret    0x8
