; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100ec(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %1 monotonic, align 4, !range !0
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %shadow.sroa.26.0..sroa_idx = getelementptr inbounds i8, ptr %cpu, i64 4
  %shadow.sroa.32.0..sroa_idx = getelementptr inbounds i8, ptr %cpu, i64 8
  %shadow.sroa.34.0..sroa_idx = getelementptr inbounds i8, ptr %cpu, i64 12
  %3 = getelementptr i8, ptr %cpu, i64 24
  %shadow.sroa.62.24..sroa_idx = getelementptr i8, ptr %cpu, i64 28
  %4 = getelementptr i8, ptr %cpu, i64 160
  %shadow.sroa.76.160..sroa_idx = getelementptr i8, ptr %cpu, i64 164
  %5 = getelementptr i8, ptr %cpu, i64 188
  %6 = getelementptr i8, ptr %cpu, i64 228
  %shadow.sroa.179.228..sroa_idx = getelementptr i8, ptr %cpu, i64 232
  %shadow.sroa.187.228..sroa_idx = getelementptr i8, ptr %cpu, i64 236
  %shadow.sroa.192.228..sroa_idx = getelementptr i8, ptr %cpu, i64 240
  %7 = getelementptr i8, ptr %cpu, i64 248
  %shadow.sroa.228.248..sroa_idx = getelementptr i8, ptr %cpu, i64 252
  %shadow.sroa.235.248..sroa_idx = getelementptr i8, ptr %cpu, i64 256
  %8 = getelementptr i8, ptr %cpu, i64 276
  %9 = getelementptr i8, ptr %cpu, i64 292
  %10 = getelementptr i8, ptr %cpu, i64 308
  %11 = getelementptr i8, ptr %cpu, i64 348
  %shadow.sroa.76.160.copyload = load i32, ptr %shadow.sroa.76.160..sroa_idx, align 1
  %shadow.sroa.64.160.copyload = load i32, ptr %4, align 1
  %12 = add i32 %shadow.sroa.64.160.copyload, -65805
  %13 = icmp ult i32 %12, -33
  %14 = add i32 %shadow.sroa.76.160.copyload, -65805
  %15 = icmp ult i32 %14, -33
  %16 = and i1 %15, %13
  br i1 %16, label %insn_0x000100ec_entry.preheader, label %lb_guard_miss, !prof !1

insn_0x000100ec_entry.preheader:                  ; preds = %entry
  %shadow.sroa.0.0.copyload = load i32, ptr %cpu, align 1
  %shadow.sroa.26.0.copyload = load i32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  %shadow.sroa.32.0.copyload = load i32, ptr %shadow.sroa.32.0..sroa_idx, align 1
  %shadow.sroa.36.24.copyload = load i32, ptr %3, align 1
  %shadow.sroa.62.24.copyload = load i32, ptr %shadow.sroa.62.24..sroa_idx, align 1
  %shadow.sroa.235.248.copyload = load i32, ptr %shadow.sroa.235.248..sroa_idx, align 1
  %shadow.sroa.374.348.copyload = load i32, ptr %11, align 1
  %17 = getelementptr i8, ptr %cpu, i64 60
  %shadow.sroa.301.292..sroa_idx = getelementptr i8, ptr %cpu, i64 296
  %shadow.sroa.301.292..sroa_idx736 = getelementptr i8, ptr %cpu, i64 296
  %shadow.sroa.301.292..sroa_idx744 = getelementptr i8, ptr %cpu, i64 296
  %18 = getelementptr i8, ptr %cpu, i64 168
  %19 = getelementptr i8, ptr %cpu, i64 56
  %shadow.sroa.301.292..sroa_idx752 = getelementptr i8, ptr %cpu, i64 296
  %shadow.sroa.301.292..sroa_idx760 = getelementptr i8, ptr %cpu, i64 296
  %shadow.sroa.301.292..sroa_idx764 = getelementptr i8, ptr %cpu, i64 296
  br label %insn_0x000100ec_entry.outer

insn_0x000100ec_entry.outer:                      ; preds = %insn_0x000100ec_entry.preheader, %chain_lookup
  %shadow.sroa.374.0.ph = phi i32 [ %shadow.sroa.374.348.copyload, %insn_0x000100ec_entry.preheader ], [ %chain_total103, %chain_lookup ]
  %shadow.sroa.235.0.ph = phi i32 [ %shadow.sroa.235.248.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.235.1, %chain_lookup ]
  %shadow.sroa.62.0.ph = phi i32 [ %shadow.sroa.62.24.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.62.1, %chain_lookup ]
  %shadow.sroa.36.0.ph = phi i32 [ %shadow.sroa.36.24.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.36.1, %chain_lookup ]
  %shadow.sroa.32.0.ph = phi i32 [ %shadow.sroa.32.0.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.32.1, %chain_lookup ]
  %shadow.sroa.26.0.ph = phi i32 [ %shadow.sroa.26.0.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.26.1, %chain_lookup ]
  %shadow.sroa.0.0.ph = phi i32 [ %shadow.sroa.0.0.copyload, %insn_0x000100ec_entry.preheader ], [ %shadow.sroa.0.1, %chain_lookup ]
  %flgo = lshr i32 %shadow.sroa.62.0.ph, 31
  %20 = add i32 %shadow.sroa.32.0.ph, 1
  %umax = tail call i32 @llvm.umax.i32(i32 %shadow.sroa.0.0.ph, i32 %20)
  br label %insn_0x000100ec_entry

insn_0x000100ec_entry:                            ; preds = %insn_0x000100ec_entry.outer, %chain_budget_now
  %shadow.sroa.374.0 = phi i32 [ %chain_total, %chain_budget_now ], [ %shadow.sroa.374.0.ph, %insn_0x000100ec_entry.outer ]
  %shadow.sroa.235.0 = phi i32 [ %26, %chain_budget_now ], [ %shadow.sroa.235.0.ph, %insn_0x000100ec_entry.outer ]
  %shadow.sroa.32.0 = phi i32 [ %rd_add, %chain_budget_now ], [ %shadow.sroa.32.0.ph, %insn_0x000100ec_entry.outer ]
  %shadow.sroa.26.0 = phi i32 [ %or32, %chain_budget_now ], [ %shadow.sroa.26.0.ph, %insn_0x000100ec_entry.outer ]
  %mul = mul i32 %shadow.sroa.26.0, %shadow.sroa.36.0.ph
  %add32 = add i32 %mul, %shadow.sroa.62.0.ph
  %flgs = lshr i32 %mul, 31
  %flgn = lshr i32 %add32, 31
  %21 = xor i32 %flgn, %flgo
  %22 = xor i32 %flgn, %flgs
  %23 = and i32 %22, %21
  %lsr32 = lshr i32 %add32, 13
  %xor32 = xor i32 %lsr32, %add32
  %lsl32 = shl i32 %xor32, 7
  %lsr = lshr i32 %add32, 25
  %rd_add = add i32 %shadow.sroa.32.0, 1
  %flgs9 = lshr i32 %shadow.sroa.32.0, 31
  %flgn10 = lshr i32 %rd_add, 31
  %24 = xor i32 %flgs9, -1
  %overflow = and i32 %flgn10, %24
  %25 = or i32 %overflow, %shadow.sroa.235.0
  %26 = or i32 %25, %23
  %or32 = or i32 %lsl32, %lsr
  %27 = icmp ule i32 %shadow.sroa.0.0.ph, %rd_add
  br i1 %27, label %insn_0x00010104, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x000100ec_entry
  %chain_total = add nuw i32 %shadow.sroa.374.0, 10
  %28 = icmp ult i32 %chain_total, %chain_budget
  br i1 %28, label %chain_budget_now, label %chain_leave72, !prof !1

insn_0x00010104:                                  ; preds = %insn_0x000100ec_entry
  %cc.le1156 = zext i1 %27 to i32
  %29 = icmp uge i32 %shadow.sroa.0.0.ph, %20
  %az16.le1150 = zext i1 %29 to i32
  %30 = icmp ult i32 %shadow.sroa.0.0.ph, %20
  %an17.le1144 = zext i1 %30 to i32
  %31 = icmp uge i32 %shadow.sroa.0.0.ph, %20
  %ac018.le1138 = zext i1 %31 to i32
  %fp = load i32, ptr %17, align 4
  %32 = and i32 %fp, 3
  %33 = icmp eq i32 %32, 0
  br i1 %33, label %data_aligned, label %data_misaligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010104
  store i32 %shadow.sroa.0.0.ph, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %shadow.sroa.62.0.ph, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65796, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 4, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx, align 1
  store i32 11, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  tail call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %fp, i32 0)
  %shadow.sroa.301.292.copyload735 = load i8, ptr %shadow.sroa.301.292..sroa_idx, align 1
  br label %chain_exit.sink.split

data_aligned:                                     ; preds = %insn_0x00010104
  %34 = lshr i32 %fp, 12
  %page_index918 = zext i32 %34 to i64
  %35 = getelementptr ptr, ptr %page_table, i64 %page_index918
  %page919 = load ptr, ptr %35, align 8
  %page_mapped.not = icmp eq ptr %page919, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !2

page_fast:                                        ; preds = %data_aligned
  %36 = and i32 %fp, 4095
  %page_offset920 = zext i32 %36 to i64
  %37 = getelementptr i8, ptr %page919, i64 %page_offset920
  %page_val = load i32, ptr %37, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  store i32 %shadow.sroa.0.0.ph, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %shadow.sroa.62.0.ph, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65796, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 4, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx736, align 1
  store i32 11, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  %38 = tail call i32 @mem_read32(ptr %mem, i32 %fp)
  %real_did_jump = load i8, ptr %shadow.sroa.301.292..sroa_idx736, align 1
  %.not = icmp eq i8 %real_did_jump, 0
  br i1 %.not, label %page_done, label %chain_exit.sink.split, !prof !1

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %38, %page_slow ]
  %sp1 = add i32 %fp, 4
  %39 = lshr i32 %sp1, 12
  %page_index915 = zext i32 %39 to i64
  %40 = getelementptr ptr, ptr %page_table, i64 %page_index915
  %page916 = load ptr, ptr %40, align 8
  %page_mapped26.not = icmp eq ptr %page916, null
  br i1 %page_mapped26.not, label %page_slow23, label %page_fast22, !prof !2

page_fast22:                                      ; preds = %page_done
  %41 = and i32 %sp1, 4095
  %page_offset917 = zext i32 %41 to i64
  %42 = getelementptr i8, ptr %page916, i64 %page_offset917
  %page_val27 = load i32, ptr %42, align 4
  br label %page_done24

page_slow23:                                      ; preds = %page_done
  store i32 %shadow.sroa.0.0.ph, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %shadow.sroa.62.0.ph, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65796, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 4, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx744, align 1
  store i32 11, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  %43 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %real_did_jump28 = load i8, ptr %shadow.sroa.301.292..sroa_idx744, align 1
  %.not853 = icmp eq i8 %real_did_jump28, 0
  br i1 %.not853, label %page_done24, label %chain_exit.sink.split, !prof !1

page_done24:                                      ; preds = %page_slow23, %page_fast22
  %mem_val35 = phi i32 [ %page_val27, %page_fast22 ], [ %43, %page_slow23 ]
  %sp2 = add i32 %fp, 8
  store i32 %mem_val, ptr %17, align 4
  store i32 %mem_val35, ptr %18, align 4
  store i32 %sp2, ptr %19, align 4
  %44 = lshr i32 %sp2, 12
  %page_index912 = zext i32 %44 to i64
  %45 = getelementptr ptr, ptr %page_table, i64 %page_index912
  %page913 = load ptr, ptr %45, align 8
  %page_mapped43.not = icmp eq ptr %page913, null
  br i1 %page_mapped43.not, label %page_slow40, label %page_fast39, !prof !2

page_fast39:                                      ; preds = %page_done24
  %46 = and i32 %sp2, 4095
  %page_offset914 = zext i32 %46 to i64
  %47 = getelementptr i8, ptr %page913, i64 %page_offset914
  %page_val44 = load i32, ptr %47, align 4
  br label %page_done41

page_slow40:                                      ; preds = %page_done24
  store i32 %or32, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %shadow.sroa.62.0.ph, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65802, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 2, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx752, align 1
  store i32 13, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  %48 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %real_did_jump45 = load i8, ptr %shadow.sroa.301.292..sroa_idx752, align 1
  %.not854 = icmp eq i8 %real_did_jump45, 0
  br i1 %.not854, label %page_done41, label %chain_exit.sink.split, !prof !1

page_done41:                                      ; preds = %page_slow40, %page_fast39
  %mem_val52 = phi i32 [ %page_val44, %page_fast39 ], [ %48, %page_slow40 ]
  %sp_inc = add i32 %fp, 12
  %49 = lshr i32 %sp_inc, 12
  %page_index = zext i32 %49 to i64
  %50 = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %50, align 8
  %page_mapped60.not = icmp eq ptr %page, null
  br i1 %page_mapped60.not, label %page_slow57, label %page_fast56, !prof !2

page_fast56:                                      ; preds = %page_done41
  %51 = and i32 %sp_inc, 4095
  %page_offset = zext i32 %51 to i64
  %52 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val61 = load i32, ptr %52, align 4
  br label %page_done58

page_slow57:                                      ; preds = %page_done41
  store i32 %or32, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %mem_val52, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65802, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 2, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx760, align 1
  store i32 13, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  %53 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %real_did_jump62 = load i8, ptr %shadow.sroa.301.292..sroa_idx760, align 1
  %.not855 = icmp eq i8 %real_did_jump62, 0
  br i1 %.not855, label %page_done58, label %chain_exit.sink.split, !prof !1

page_done58:                                      ; preds = %page_slow57, %page_fast56
  %mem_val69 = phi i32 [ %page_val61, %page_fast56 ], [ %53, %page_slow57 ]
  %sp_inc70 = add i32 %fp, 16
  store i32 %sp_inc70, ptr %19, align 4
  %lsb = and i32 %mem_val35, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !1

jump_misalign:                                    ; preds = %page_done58
  store i32 %or32, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %umax, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %mem_val69, ptr %3, align 1
  store i32 %mem_val52, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65804, ptr %5, align 1
  store i32 %az16.le1150, ptr %6, align 1
  store i32 %an17.le1144, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le1138, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le1156, ptr %8, align 1
  store i32 2, ptr %9, align 1
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx764, align 1
  store i32 14, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  tail call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %shadow.sroa.301.292.copyload767 = load i8, ptr %shadow.sroa.301.292..sroa_idx764, align 1
  br label %chain_exit.sink.split

common.ret:                                       ; preds = %chain_leave101, %chain_leave72, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %54 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %54, align 1
  %shadow.sroa.301.292..sroa_idx768 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx768, align 1
  br label %common.ret

chain_leave72:                                    ; preds = %chain_budget_now, %brcc_taken
  %cc.le = zext i1 %27 to i32
  %55 = icmp eq i32 %shadow.sroa.0.0.ph, %rd_add
  %az16.le = zext i1 %55 to i32
  %56 = icmp ugt i32 %rd_add, %shadow.sroa.0.0.ph
  %an17.le = zext i1 %56 to i32
  %57 = icmp ule i32 %rd_add, %shadow.sroa.0.0.ph
  %ac018.le = zext i1 %57 to i32
  store i32 %shadow.sroa.0.0.ph, ptr %cpu, align 1
  store i32 %or32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %rd_add, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %lsl32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.0.ph, ptr %3, align 1
  store i32 %shadow.sroa.62.0.ph, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 65772, ptr %5, align 1
  store i32 %az16.le, ptr %6, align 1
  store i32 %an17.le, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %ac018.le, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %ac018.le, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 0, ptr %7, align 1
  store i32 0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %26, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %cc.le, ptr %8, align 1
  store i32 2, ptr %9, align 1
  %shadow.sroa.301.292..sroa_idx772 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %shadow.sroa.301.292..sroa_idx772, align 1
  store i32 10, ptr %10, align 1
  store i32 %shadow.sroa.374.0, ptr %11, align 1
  br label %common.ret

chain_budget_now:                                 ; preds = %brcc_taken
  %chain_budget73 = load atomic i32, ptr %1 monotonic, align 4, !range !0
  %.not857 = icmp eq i32 %chain_budget73, 0
  br i1 %.not857, label %chain_leave72, label %insn_0x000100ec_entry, !prof !2

chain_exit.sink.split:                            ; preds = %page_slow57, %page_slow40, %page_slow23, %page_slow, %data_misaligned, %jump_misalign
  %tail100.ph = phi i8 [ %shadow.sroa.301.292.copyload767, %jump_misalign ], [ %shadow.sroa.301.292.copyload735, %data_misaligned ], [ %real_did_jump, %page_slow ], [ %real_did_jump28, %page_slow23 ], [ %real_did_jump45, %page_slow40 ], [ %real_did_jump62, %page_slow57 ]
  %next_pc98.ph = load i32, ptr %5, align 1
  %shadow.sroa.0.1.ph = load i32, ptr %cpu, align 1
  %shadow.sroa.26.1.ph = load i32, ptr %shadow.sroa.26.0..sroa_idx, align 1
  %shadow.sroa.32.1.ph = load i32, ptr %shadow.sroa.32.0..sroa_idx, align 1
  %shadow.sroa.34.0.ph = load i32, ptr %shadow.sroa.34.0..sroa_idx, align 1
  %shadow.sroa.36.1.ph = load i32, ptr %3, align 1
  %shadow.sroa.62.1.ph = load i32, ptr %shadow.sroa.62.24..sroa_idx, align 1
  %shadow.sroa.147.0.ph = load i32, ptr %6, align 1
  %shadow.sroa.179.0.ph = load i32, ptr %shadow.sroa.179.228..sroa_idx, align 1
  %shadow.sroa.187.0.ph = load i32, ptr %shadow.sroa.187.228..sroa_idx, align 1
  %shadow.sroa.192.0.ph = load i32, ptr %shadow.sroa.192.228..sroa_idx, align 1
  %shadow.sroa.197.0.ph = load i32, ptr %7, align 1
  %shadow.sroa.228.0.ph = load i32, ptr %shadow.sroa.228.248..sroa_idx, align 1
  %shadow.sroa.235.1.ph = load i32, ptr %shadow.sroa.235.248..sroa_idx, align 1
  %shadow.sroa.238.0.ph = load i32, ptr %8, align 1
  %shadow.sroa.263.0.ph = load i32, ptr %9, align 1
  %shadow.sroa.323.308.copyload823 = load i32, ptr %10, align 1
  %shadow.sroa.374.348.copyload847 = load i32, ptr %11, align 1
  br label %chain_exit

chain_exit:                                       ; preds = %chain_exit.sink.split, %page_done58
  %shadow.sroa.374.1 = phi i32 [ %shadow.sroa.374.0, %page_done58 ], [ %shadow.sroa.374.348.copyload847, %chain_exit.sink.split ]
  %shadow.sroa.323.0 = phi i32 [ 14, %page_done58 ], [ %shadow.sroa.323.308.copyload823, %chain_exit.sink.split ]
  %shadow.sroa.263.0 = phi i32 [ 2, %page_done58 ], [ %shadow.sroa.263.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.238.0 = phi i32 [ %cc.le1156, %page_done58 ], [ %shadow.sroa.238.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.235.1 = phi i32 [ %26, %page_done58 ], [ %shadow.sroa.235.1.ph, %chain_exit.sink.split ]
  %shadow.sroa.228.0 = phi i32 [ 0, %page_done58 ], [ %shadow.sroa.228.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.197.0 = phi i32 [ 0, %page_done58 ], [ %shadow.sroa.197.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.192.0 = phi i32 [ %ac018.le1138, %page_done58 ], [ %shadow.sroa.192.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.187.0 = phi i32 [ %ac018.le1138, %page_done58 ], [ %shadow.sroa.187.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.179.0 = phi i32 [ %an17.le1144, %page_done58 ], [ %shadow.sroa.179.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.147.0 = phi i32 [ %az16.le1150, %page_done58 ], [ %shadow.sroa.147.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.62.1 = phi i32 [ %mem_val52, %page_done58 ], [ %shadow.sroa.62.1.ph, %chain_exit.sink.split ]
  %shadow.sroa.36.1 = phi i32 [ %mem_val69, %page_done58 ], [ %shadow.sroa.36.1.ph, %chain_exit.sink.split ]
  %shadow.sroa.34.0 = phi i32 [ %lsl32, %page_done58 ], [ %shadow.sroa.34.0.ph, %chain_exit.sink.split ]
  %shadow.sroa.32.1 = phi i32 [ %umax, %page_done58 ], [ %shadow.sroa.32.1.ph, %chain_exit.sink.split ]
  %shadow.sroa.26.1 = phi i32 [ %or32, %page_done58 ], [ %shadow.sroa.26.1.ph, %chain_exit.sink.split ]
  %shadow.sroa.0.1 = phi i32 [ %or32, %page_done58 ], [ %shadow.sroa.0.1.ph, %chain_exit.sink.split ]
  %next_pc98 = phi i32 [ %mem_val35, %page_done58 ], [ %next_pc98.ph, %chain_exit.sink.split ]
  %tail100 = phi i8 [ 1, %page_done58 ], [ %tail100.ph, %chain_exit.sink.split ]
  %chain_total103 = add nuw i32 %shadow.sroa.323.0, %shadow.sroa.374.1
  %58 = icmp ult i32 %chain_total103, %chain_budget
  br i1 %58, label %chain_budget_now104, label %chain_leave101, !prof !1

chain_lookup:                                     ; preds = %chain_budget_now104
  %59 = icmp eq i32 %next_pc98, 65772
  br i1 %59, label %insn_0x000100ec_entry.outer, label %chain_other, !prof !3

chain_leave101:                                   ; preds = %chain_budget_now104, %chain_exit, %chain_other
  store i32 %shadow.sroa.0.1, ptr %cpu, align 1
  store i32 %shadow.sroa.26.1, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %shadow.sroa.32.1, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %shadow.sroa.34.0, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.1, ptr %3, align 1
  store i32 %shadow.sroa.62.1, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 %next_pc98, ptr %5, align 1
  store i32 %shadow.sroa.147.0, ptr %6, align 1
  store i32 %shadow.sroa.179.0, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %shadow.sroa.187.0, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %shadow.sroa.192.0, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 %shadow.sroa.197.0, ptr %7, align 1
  store i32 %shadow.sroa.228.0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %shadow.sroa.235.1, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %shadow.sroa.238.0, ptr %8, align 1
  store i32 %shadow.sroa.263.0, ptr %9, align 1
  %shadow.sroa.301.292..sroa_idx774 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail100, ptr %shadow.sroa.301.292..sroa_idx774, align 1
  store i32 %shadow.sroa.323.0, ptr %10, align 1
  store i32 %shadow.sroa.374.1, ptr %11, align 1
  br label %common.ret

chain_budget_now104:                              ; preds = %chain_exit
  %chain_budget105 = load atomic i32, ptr %1 monotonic, align 4, !range !0
  %.not856 = icmp eq i32 %chain_budget105, 0
  br i1 %.not856, label %chain_leave101, label %chain_lookup, !prof !2

chain_other:                                      ; preds = %chain_lookup
  %60 = shl i32 %next_pc98, 3
  %61 = and i32 %60, 1048560
  %62 = zext i32 %61 to i64
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %62
  %slot_pc = load i32, ptr %chain_slot, align 4
  %63 = icmp eq i32 %slot_pc, %next_pc98
  br i1 %63, label %chain_hit, label %chain_leave101, !prof !1

chain_hit:                                        ; preds = %chain_other
  %64 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %64, align 8
  store i32 %shadow.sroa.0.1, ptr %cpu, align 1
  store i32 %shadow.sroa.26.1, ptr %shadow.sroa.26.0..sroa_idx, align 1
  store i32 %shadow.sroa.32.1, ptr %shadow.sroa.32.0..sroa_idx, align 1
  store i32 %shadow.sroa.34.0, ptr %shadow.sroa.34.0..sroa_idx, align 1
  store i32 %shadow.sroa.36.1, ptr %3, align 1
  store i32 %shadow.sroa.62.1, ptr %shadow.sroa.62.24..sroa_idx, align 1
  store i32 %next_pc98, ptr %5, align 1
  store i32 %shadow.sroa.147.0, ptr %6, align 1
  store i32 %shadow.sroa.179.0, ptr %shadow.sroa.179.228..sroa_idx, align 1
  store i32 %shadow.sroa.187.0, ptr %shadow.sroa.187.228..sroa_idx, align 1
  store i32 %shadow.sroa.192.0, ptr %shadow.sroa.192.228..sroa_idx, align 1
  store i32 %shadow.sroa.197.0, ptr %7, align 1
  store i32 %shadow.sroa.228.0, ptr %shadow.sroa.228.248..sroa_idx, align 1
  store i32 %shadow.sroa.235.1, ptr %shadow.sroa.235.248..sroa_idx, align 1
  store i32 %shadow.sroa.238.0, ptr %8, align 1
  store i32 %shadow.sroa.263.0, ptr %9, align 1
  %shadow.sroa.301.292..sroa_idx776 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %shadow.sroa.301.292..sroa_idx776, align 1
  store i32 %shadow.sroa.323.0, ptr %10, align 1
  store i32 %chain_total103, ptr %11, align 1
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #3
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.umax.i32(i32, i32) #2

attributes #0 = { "bcore-loop-block" "no_callee_saved_registers" }
attributes #1 = { cold }
attributes #2 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { "no_callee_saved_registers" }

!0 = !{i32 0, i32 -2147483648}
!1 = !{!"branch_weights", i32 1048576, i32 1}
!2 = !{!"branch_weights", i32 1, i32 1048576}
!3 = !{!"branch_weights", i32 63, i32 1}
