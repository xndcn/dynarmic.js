
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66600-0-128835395789138.bin:     file format binary


Disassembly of section .data:

0000752cd4002152 <.data>:
    752cd4002152:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    752cd4002159:	e9 f0 f3 ff e7       	jmp    0x752cbc00154e
    752cd400215e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    752cd4002165:	2c 04 01 00 
    752cd4002169:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002170:	04 00 00 00 
    752cd4002174:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd400217b:	02 00 00 00 
    752cd400217f:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4002186:	57 00 00 
    752cd4002189:	48 89 fb             	mov    rbx,rdi
    752cd400218c:	4c 89 ef             	mov    rdi,r13
    752cd400218f:	4c 89 f6             	mov    rsi,r14
    752cd4002192:	ba 2c 04 01 00       	mov    edx,0x1042c
    752cd4002197:	44 89 c1             	mov    ecx,r8d
    752cd400219a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd40021a0:	ff d0                	call   rax
    752cd40021a2:	48 89 df             	mov    rdi,rbx
    752cd40021a5:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40021ac:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40021b3:	00 
    752cd40021b4:	bb 04 00 00 00       	mov    ebx,0x4
    752cd40021b9:	bd 02 00 00 00       	mov    ebp,0x2
    752cd40021be:	e9 3c f3 ff e7       	jmp    0x752cbc0014ff
    752cd40021c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    752cd40021ca:	2c 04 01 00 
    752cd40021ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40021d5:	04 00 00 00 
    752cd40021d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd40021e0:	02 00 00 00 
    752cd40021e4:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40021eb:	57 00 00 
    752cd40021ee:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40021f3:	4c 89 f7             	mov    rdi,r14
    752cd40021f6:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    752cd40021fb:	44 89 c6             	mov    esi,r8d
    752cd40021fe:	4d 89 c4             	mov    r12,r8
    752cd4002201:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    752cd4002206:	44 89 d5             	mov    ebp,r10d
    752cd4002209:	ff d0                	call   rax
    752cd400220b:	41 89 ea             	mov    r10d,ebp
    752cd400220e:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    752cd4002213:	4d 89 e0             	mov    r8,r12
    752cd4002216:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    752cd400221b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002220:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002227:	00 
    752cd4002228:	84 c9                	test   cl,cl
    752cd400222a:	0f 84 bb f1 ff e7    	je     0x752cbc0013eb
    752cd4002230:	e9 d9 00 00 00       	jmp    0x752cd400230e
    752cd4002235:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    752cd400223c:	2c 04 01 00 
    752cd4002240:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002247:	04 00 00 00 
    752cd400224b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4002252:	02 00 00 00 
    752cd4002256:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd400225d:	57 00 00 
    752cd4002260:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002265:	4c 89 f7             	mov    rdi,r14
    752cd4002268:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    752cd400226d:	89 ee                	mov    esi,ebp
    752cd400226f:	44 89 d2             	mov    edx,r10d
    752cd4002272:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cd4002277:	4d 89 c6             	mov    r14,r8
    752cd400227a:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    752cd400227f:	ff d0                	call   rax
    752cd4002281:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    752cd4002286:	4d 89 f0             	mov    r8,r14
    752cd4002289:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    752cd400228e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002293:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cd4002298:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400229f:	00 
    752cd40022a0:	84 c9                	test   cl,cl
    752cd40022a2:	0f 84 66 f1 ff e7    	je     0x752cbc00140e
    752cd40022a8:	eb 64                	jmp    0x752cd400230e
    752cd40022aa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    752cd40022b1:	30 04 01 00 
    752cd40022b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40022bc:	04 00 00 00 
    752cd40022c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd40022c7:	02 00 00 00 
    752cd40022cb:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd40022d2:	57 00 00 
    752cd40022d5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40022da:	4c 89 ef             	mov    rdi,r13
    752cd40022dd:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cd40022e2:	49 89 f6             	mov    r14,rsi
    752cd40022e5:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd40022ea:	ff d0                	call   rax
    752cd40022ec:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd40022f1:	4c 89 f6             	mov    rsi,r14
    752cd40022f4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40022f9:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cd40022fe:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002305:	00 
    752cd4002306:	84 c9                	test   cl,cl
    752cd4002308:	0f 84 12 f1 ff e7    	je     0x752cbc001420
    752cd400230e:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd4002315:	e9 9a fe ff ff       	jmp    0x752cd40021b4
    752cd400231a:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd400231f:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    752cd4002324:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002329:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    752cd4002330:	34 04 01 00 
    752cd4002334:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400233b:	02 00 00 00 
    752cd400233f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    752cd4002346:	04 00 00 00 
    752cd400234a:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002351:	57 00 00 
    752cd4002354:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cd4002359:	4c 89 f7             	mov    rdi,r14
    752cd400235c:	be f0 12 01 00       	mov    esi,0x112f0
    752cd4002361:	ff d0                	call   rax
    752cd4002363:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400236a:	00 
    752cd400236b:	84 c9                	test   cl,cl
    752cd400236d:	0f 85 4e 01 00 00    	jne    0x752cd40024c1
    752cd4002373:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cd4002378:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400237d:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    752cd4002382:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4002387:	e9 b2 f0 ff e7       	jmp    0x752cbc00143e
    752cd400238c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    752cd4002393:	42 04 01 00 
    752cd4002397:	b1 01                	mov    cl,0x1
    752cd4002399:	bd 06 00 00 00       	mov    ebp,0x6
    752cd400239e:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40023a3:	e9 a6 f1 ff e7       	jmp    0x752cbc00154e
    752cd40023a8:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    752cd40023ad:	49 89 f4             	mov    r12,rsi
    752cd40023b0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40023b5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    752cd40023bc:	3c 04 01 00 
    752cd40023c0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40023c7:	04 00 00 00 
    752cd40023cb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    752cd40023d2:	08 00 00 00 
    752cd40023d6:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40023dd:	57 00 00 
    752cd40023e0:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cd40023e5:	4c 89 f7             	mov    rdi,r14
    752cd40023e8:	89 ee                	mov    esi,ebp
    752cd40023ea:	ff d0                	call   rax
    752cd40023ec:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40023f3:	00 
    752cd40023f4:	84 c9                	test   cl,cl
    752cd40023f6:	0f 85 e5 00 00 00    	jne    0x752cd40024e1
    752cd40023fc:	89 c5                	mov    ebp,eax
    752cd40023fe:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cd4002403:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002408:	4c 89 e6             	mov    rsi,r12
    752cd400240b:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    752cd4002410:	e9 af f0 ff e7       	jmp    0x752cbc0014c4
    752cd4002415:	48 89 f3             	mov    rbx,rsi
    752cd4002418:	49 89 fc             	mov    r12,rdi
    752cd400241b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    752cd4002422:	3c 04 01 00 
    752cd4002426:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd400242d:	04 00 00 00 
    752cd4002431:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    752cd4002438:	08 00 00 00 
    752cd400243c:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002443:	57 00 00 
    752cd4002446:	4d 89 f7             	mov    r15,r14
    752cd4002449:	4c 89 f7             	mov    rdi,r14
    752cd400244c:	44 89 c6             	mov    esi,r8d
    752cd400244f:	ff d0                	call   rax
    752cd4002451:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002458:	00 
    752cd4002459:	84 c9                	test   cl,cl
    752cd400245b:	0f 85 93 00 00 00    	jne    0x752cd40024f4
    752cd4002461:	4d 89 fe             	mov    r14,r15
    752cd4002464:	4c 89 e7             	mov    rdi,r12
    752cd4002467:	48 89 de             	mov    rsi,rbx
    752cd400246a:	e9 6d f0 ff e7       	jmp    0x752cbc0014dc
    752cd400246f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    752cd4002476:	40 04 01 00 
    752cd400247a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002481:	02 00 00 00 
    752cd4002485:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    752cd400248c:	09 00 00 00 
    752cd4002490:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd4002497:	57 00 00 
    752cd400249a:	49 89 ff             	mov    r15,rdi
    752cd400249d:	4c 89 ef             	mov    rdi,r13
    752cd40024a0:	be 2a 00 00 00       	mov    esi,0x2a
    752cd40024a5:	4c 89 f2             	mov    rdx,r14
    752cd40024a8:	ff d0                	call   rax
    752cd40024aa:	4c 89 ff             	mov    rdi,r15
    752cd40024ad:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40024b4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40024bb:	00 
    752cd40024bc:	e9 3e f0 ff e7       	jmp    0x752cbc0014ff
    752cd40024c1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40024c8:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40024cd:	bd 04 00 00 00       	mov    ebp,0x4
    752cd40024d2:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cd40024d7:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40024dc:	e9 1e f0 ff e7       	jmp    0x752cbc0014ff
    752cd40024e1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40024e8:	bb 04 00 00 00       	mov    ebx,0x4
    752cd40024ed:	bd 08 00 00 00       	mov    ebp,0x8
    752cd40024f2:	eb de                	jmp    0x752cd40024d2
    752cd40024f4:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40024fb:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4002500:	bd 08 00 00 00       	mov    ebp,0x8
    752cd4002505:	4d 89 fe             	mov    r14,r15
    752cd4002508:	4c 89 e7             	mov    rdi,r12
    752cd400250b:	e9 ef ef ff e7       	jmp    0x752cbc0014ff
