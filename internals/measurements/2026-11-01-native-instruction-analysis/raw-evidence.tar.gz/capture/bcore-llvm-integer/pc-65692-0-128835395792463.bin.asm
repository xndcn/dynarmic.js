
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65692-0-128835395792463.bin:     file format binary


Disassembly of section .data:

0000752cd4002e4f <.data>:
    752cd4002e4f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    752cd4002e56:	84 00 01 00 
    752cd4002e5a:	b1 01                	mov    cl,0x1
    752cd4002e5c:	bd 07 00 00 00       	mov    ebp,0x7
    752cd4002e61:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4002e66:	e9 ad fb ff e7       	jmp    0x752cbc002a18
    752cd4002e6b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002e72:	02 00 00 00 
    752cd4002e76:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4002e7d:	01 00 00 00 
    752cd4002e81:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4002e88:	57 00 00 
    752cd4002e8b:	48 89 fb             	mov    rbx,rdi
    752cd4002e8e:	4c 89 ef             	mov    rdi,r13
    752cd4002e91:	4c 89 f6             	mov    rsi,r14
    752cd4002e94:	ba 9c 00 01 00       	mov    edx,0x1009c
    752cd4002e99:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4002e9f:	ff d0                	call   rax
    752cd4002ea1:	48 89 df             	mov    rdi,rbx
    752cd4002ea4:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002eab:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002eb2:	00 
    752cd4002eb3:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4002eb8:	bd 01 00 00 00       	mov    ebp,0x1
    752cd4002ebd:	e9 05 fb ff e7       	jmp    0x752cbc0029c7
    752cd4002ec2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002ec9:	02 00 00 00 
    752cd4002ecd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4002ed4:	01 00 00 00 
    752cd4002ed8:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4002edf:	57 00 00 
    752cd4002ee2:	48 89 fb             	mov    rbx,rdi
    752cd4002ee5:	4c 89 f7             	mov    rdi,r14
    752cd4002ee8:	89 ce                	mov    esi,ecx
    752cd4002eea:	4c 89 c5             	mov    rbp,r8
    752cd4002eed:	ff d0                	call   rax
    752cd4002eef:	49 89 e8             	mov    r8,rbp
    752cd4002ef2:	48 89 df             	mov    rdi,rbx
    752cd4002ef5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002efc:	00 
    752cd4002efd:	84 c9                	test   cl,cl
    752cd4002eff:	0f 84 b0 f7 ff e7    	je     0x752cbc0026b5
    752cd4002f05:	eb 4c                	jmp    0x752cd4002f53
    752cd4002f07:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    752cd4002f0e:	9e 00 01 00 
    752cd4002f12:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002f19:	02 00 00 00 
    752cd4002f1d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4002f24:	01 00 00 00 
    752cd4002f28:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4002f2f:	57 00 00 
    752cd4002f32:	48 89 fb             	mov    rbx,rdi
    752cd4002f35:	4c 89 ef             	mov    rdi,r13
    752cd4002f38:	4c 89 c5             	mov    rbp,r8
    752cd4002f3b:	ff d0                	call   rax
    752cd4002f3d:	49 89 e8             	mov    r8,rbp
    752cd4002f40:	48 89 df             	mov    rdi,rbx
    752cd4002f43:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002f4a:	00 
    752cd4002f4b:	84 c9                	test   cl,cl
    752cd4002f4d:	0f 84 6c f7 ff e7    	je     0x752cbc0026bf
    752cd4002f53:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002f5a:	e9 54 ff ff ff       	jmp    0x752cd4002eb3
    752cd4002f5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    752cd4002f66:	9e 00 01 00 
    752cd4002f6a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002f71:	02 00 00 00 
    752cd4002f75:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4002f7c:	02 00 00 00 
    752cd4002f80:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4002f87:	57 00 00 
    752cd4002f8a:	48 89 fd             	mov    rbp,rdi
    752cd4002f8d:	4c 89 ef             	mov    rdi,r13
    752cd4002f90:	4c 89 f6             	mov    rsi,r14
    752cd4002f93:	ba 9e 00 01 00       	mov    edx,0x1009e
    752cd4002f98:	89 d9                	mov    ecx,ebx
    752cd4002f9a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4002fa0:	ff d0                	call   rax
    752cd4002fa2:	48 89 ef             	mov    rdi,rbp
    752cd4002fa5:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002fac:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002fb3:	00 
    752cd4002fb4:	bd 02 00 00 00       	mov    ebp,0x2
    752cd4002fb9:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4002fbe:	e9 04 fa ff e7       	jmp    0x752cbc0029c7
    752cd4002fc3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    752cd4002fca:	9e 00 01 00 
    752cd4002fce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002fd5:	02 00 00 00 
    752cd4002fd9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4002fe0:	02 00 00 00 
    752cd4002fe4:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4002feb:	57 00 00 
    752cd4002fee:	49 89 fc             	mov    r12,rdi
    752cd4002ff1:	4c 89 f7             	mov    rdi,r14
    752cd4002ff4:	89 de                	mov    esi,ebx
    752cd4002ff6:	4c 89 c5             	mov    rbp,r8
    752cd4002ff9:	ff d0                	call   rax
    752cd4002ffb:	49 89 e8             	mov    r8,rbp
    752cd4002ffe:	4c 89 e7             	mov    rdi,r12
    752cd4003001:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003008:	00 
    752cd4003009:	84 c9                	test   cl,cl
    752cd400300b:	0f 84 de f6 ff e7    	je     0x752cbc0026ef
    752cd4003011:	eb 4c                	jmp    0x752cd400305f
    752cd4003013:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a0
    752cd400301a:	a0 00 01 00 
    752cd400301e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003025:	02 00 00 00 
    752cd4003029:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4003030:	02 00 00 00 
    752cd4003034:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd400303b:	57 00 00 
    752cd400303e:	48 89 fb             	mov    rbx,rdi
    752cd4003041:	4c 89 ef             	mov    rdi,r13
    752cd4003044:	4c 89 c5             	mov    rbp,r8
    752cd4003047:	ff d0                	call   rax
    752cd4003049:	49 89 e8             	mov    r8,rbp
    752cd400304c:	48 89 df             	mov    rdi,rbx
    752cd400304f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003056:	00 
    752cd4003057:	84 c9                	test   cl,cl
    752cd4003059:	0f 84 a1 f6 ff e7    	je     0x752cbc002700
    752cd400305f:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003066:	e9 49 ff ff ff       	jmp    0x752cd4002fb4
    752cd400306b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    752cd4003072:	a4 00 01 00 
    752cd4003076:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400307d:	02 00 00 00 
    752cd4003081:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    752cd4003088:	05 00 00 00 
    752cd400308c:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4003093:	57 00 00 
    752cd4003096:	48 89 fb             	mov    rbx,rdi
    752cd4003099:	4c 89 ef             	mov    rdi,r13
    752cd400309c:	4c 89 f6             	mov    rsi,r14
    752cd400309f:	ba a4 00 01 00       	mov    edx,0x100a4
    752cd40030a4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd40030aa:	ff d0                	call   rax
    752cd40030ac:	48 89 df             	mov    rdi,rbx
    752cd40030af:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd40030b6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40030bd:	00 
    752cd40030be:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40030c3:	bd 05 00 00 00       	mov    ebp,0x5
    752cd40030c8:	e9 fa f8 ff e7       	jmp    0x752cbc0029c7
    752cd40030cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    752cd40030d4:	a4 00 01 00 
    752cd40030d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40030df:	02 00 00 00 
    752cd40030e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    752cd40030ea:	05 00 00 00 
    752cd40030ee:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40030f5:	57 00 00 
    752cd40030f8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40030fd:	4c 89 f7             	mov    rdi,r14
    752cd4003100:	89 ce                	mov    esi,ecx
    752cd4003102:	89 da                	mov    edx,ebx
    752cd4003104:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd4003109:	4d 89 c6             	mov    r14,r8
    752cd400310c:	ff d0                	call   rax
    752cd400310e:	4d 89 f0             	mov    r8,r14
    752cd4003111:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003116:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd400311b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003122:	00 
    752cd4003123:	84 c9                	test   cl,cl
    752cd4003125:	0f 84 62 f6 ff e7    	je     0x752cbc00278d
    752cd400312b:	eb 5a                	jmp    0x752cd4003187
    752cd400312d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a6
    752cd4003134:	a6 00 01 00 
    752cd4003138:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400313f:	02 00 00 00 
    752cd4003143:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    752cd400314a:	05 00 00 00 
    752cd400314e:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4003155:	57 00 00 
    752cd4003158:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400315d:	4c 89 ef             	mov    rdi,r13
    752cd4003160:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd4003165:	4d 89 c6             	mov    r14,r8
    752cd4003168:	ff d0                	call   rax
    752cd400316a:	4d 89 f0             	mov    r8,r14
    752cd400316d:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003172:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd4003177:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400317e:	00 
    752cd400317f:	84 c9                	test   cl,cl
    752cd4003181:	0f 84 10 f6 ff e7    	je     0x752cbc002797
    752cd4003187:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd400318e:	e9 2b ff ff ff       	jmp    0x752cd40030be
    752cd4003193:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    752cd400319a:	e9 79 f8 ff e7       	jmp    0x752cbc002a18
    752cd400319f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    752cd40031a6:	b4 00 01 00 
    752cd40031aa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40031b1:	02 00 00 00 
    752cd40031b5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    752cd40031bc:	0b 00 00 00 
    752cd40031c0:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40031c7:	57 00 00 
    752cd40031ca:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40031cf:	49 89 fc             	mov    r12,rdi
    752cd40031d2:	4c 89 f7             	mov    rdi,r14
    752cd40031d5:	be 10 f0 00 00       	mov    esi,0xf010
    752cd40031da:	ba 02 00 00 00       	mov    edx,0x2
    752cd40031df:	4c 89 c5             	mov    rbp,r8
    752cd40031e2:	ff d0                	call   rax
    752cd40031e4:	49 89 e8             	mov    r8,rbp
    752cd40031e7:	4c 89 e7             	mov    rdi,r12
    752cd40031ea:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40031f1:	00 
    752cd40031f2:	84 c9                	test   cl,cl
    752cd40031f4:	0f 84 53 f6 ff e7    	je     0x752cbc00284d
    752cd40031fa:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003201:	eb 58                	jmp    0x752cd400325b
    752cd4003203:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    752cd400320a:	b6 00 01 00 
    752cd400320e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003215:	02 00 00 00 
    752cd4003219:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    752cd4003220:	0b 00 00 00 
    752cd4003224:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd400322b:	57 00 00 
    752cd400322e:	48 89 fb             	mov    rbx,rdi
    752cd4003231:	4c 89 ef             	mov    rdi,r13
    752cd4003234:	4c 89 c5             	mov    rbp,r8
    752cd4003237:	ff d0                	call   rax
    752cd4003239:	49 89 e8             	mov    r8,rbp
    752cd400323c:	48 89 df             	mov    rdi,rbx
    752cd400323f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003246:	00 
    752cd4003247:	84 c9                	test   cl,cl
    752cd4003249:	0f 84 08 f6 ff e7    	je     0x752cbc002857
    752cd400324f:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003256:	bb 02 00 00 00       	mov    ebx,0x2
    752cd400325b:	bd 0b 00 00 00       	mov    ebp,0xb
    752cd4003260:	e9 62 f7 ff e7       	jmp    0x752cbc0029c7
    752cd4003265:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    752cd400326c:	b6 00 01 00 
    752cd4003270:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4003277:	04 00 00 00 
    752cd400327b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd4003282:	0c 00 00 00 
    752cd4003286:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd400328d:	57 00 00 
    752cd4003290:	48 89 fb             	mov    rbx,rdi
    752cd4003293:	4c 89 ef             	mov    rdi,r13
    752cd4003296:	4c 89 f6             	mov    rsi,r14
    752cd4003299:	ba b6 00 01 00       	mov    edx,0x100b6
    752cd400329e:	89 e9                	mov    ecx,ebp
    752cd40032a0:	45 31 c0             	xor    r8d,r8d
    752cd40032a3:	ff d0                	call   rax
    752cd40032a5:	48 89 df             	mov    rdi,rbx
    752cd40032a8:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd40032af:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40032b6:	00 
    752cd40032b7:	bb 04 00 00 00       	mov    ebx,0x4
    752cd40032bc:	bd 0c 00 00 00       	mov    ebp,0xc
    752cd40032c1:	e9 01 f7 ff e7       	jmp    0x752cbc0029c7
    752cd40032c6:	4d 89 c7             	mov    r15,r8
    752cd40032c9:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40032ce:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    752cd40032d5:	b6 00 01 00 
    752cd40032d9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40032e0:	04 00 00 00 
    752cd40032e4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd40032eb:	0c 00 00 00 
    752cd40032ef:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40032f6:	57 00 00 
    752cd40032f9:	4d 89 f4             	mov    r12,r14
    752cd40032fc:	4c 89 f7             	mov    rdi,r14
    752cd40032ff:	89 ee                	mov    esi,ebp
    752cd4003301:	ff d0                	call   rax
    752cd4003303:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400330a:	00 
    752cd400330b:	84 c9                	test   cl,cl
    752cd400330d:	0f 85 57 03 00 00    	jne    0x752cd400366a
    752cd4003313:	89 c3                	mov    ebx,eax
    752cd4003315:	4d 89 e6             	mov    r14,r12
    752cd4003318:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400331d:	4d 89 f8             	mov    r8,r15
    752cd4003320:	e9 5f f5 ff e7       	jmp    0x752cbc002884
    752cd4003325:	4d 89 c4             	mov    r12,r8
    752cd4003328:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400332d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    752cd4003334:	b6 00 01 00 
    752cd4003338:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd400333f:	04 00 00 00 
    752cd4003343:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd400334a:	0c 00 00 00 
    752cd400334e:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4003355:	57 00 00 
    752cd4003358:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd400335d:	4c 89 f7             	mov    rdi,r14
    752cd4003360:	ff d0                	call   rax
    752cd4003362:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003369:	00 
    752cd400336a:	84 c9                	test   cl,cl
    752cd400336c:	0f 85 0b 03 00 00    	jne    0x752cd400367d
    752cd4003372:	41 89 c7             	mov    r15d,eax
    752cd4003375:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd400337a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400337f:	4d 89 e0             	mov    r8,r12
    752cd4003382:	e9 1c f5 ff e7       	jmp    0x752cbc0028a3
    752cd4003387:	4c 89 c3             	mov    rbx,r8
    752cd400338a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400338f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd4003396:	bc 00 01 00 
    752cd400339a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40033a1:	02 00 00 00 
    752cd40033a5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd40033ac:	0e 00 00 00 
    752cd40033b0:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40033b7:	57 00 00 
    752cd40033ba:	4d 89 f4             	mov    r12,r14
    752cd40033bd:	4c 89 f7             	mov    rdi,r14
    752cd40033c0:	ff d0                	call   rax
    752cd40033c2:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40033c9:	00 
    752cd40033ca:	84 c9                	test   cl,cl
    752cd40033cc:	0f 85 7a 02 00 00    	jne    0x752cd400364c
    752cd40033d2:	4d 89 e6             	mov    r14,r12
    752cd40033d5:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40033da:	49 89 d8             	mov    r8,rbx
    752cd40033dd:	e9 f6 f4 ff e7       	jmp    0x752cbc0028d8
    752cd40033e2:	4c 89 c3             	mov    rbx,r8
    752cd40033e5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40033ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd40033f1:	bc 00 01 00 
    752cd40033f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40033fc:	02 00 00 00 
    752cd4003400:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd4003407:	0e 00 00 00 
    752cd400340b:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4003412:	57 00 00 
    752cd4003415:	4d 89 f4             	mov    r12,r14
    752cd4003418:	4c 89 f7             	mov    rdi,r14
    752cd400341b:	ff d0                	call   rax
    752cd400341d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003424:	00 
    752cd4003425:	84 c9                	test   cl,cl
    752cd4003427:	0f 85 1f 02 00 00    	jne    0x752cd400364c
    752cd400342d:	4d 89 e6             	mov    r14,r12
    752cd4003430:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003435:	49 89 d8             	mov    r8,rbx
    752cd4003438:	e9 bd f4 ff e7       	jmp    0x752cbc0028fa
    752cd400343d:	4c 89 c3             	mov    rbx,r8
    752cd4003440:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4003445:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd400344c:	bc 00 01 00 
    752cd4003450:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003457:	02 00 00 00 
    752cd400345b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd4003462:	0e 00 00 00 
    752cd4003466:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400346d:	57 00 00 
    752cd4003470:	4d 89 f4             	mov    r12,r14
    752cd4003473:	4c 89 f7             	mov    rdi,r14
    752cd4003476:	ff d0                	call   rax
    752cd4003478:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400347f:	00 
    752cd4003480:	84 c9                	test   cl,cl
    752cd4003482:	0f 85 c4 01 00 00    	jne    0x752cd400364c
    752cd4003488:	4d 89 e6             	mov    r14,r12
    752cd400348b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003490:	49 89 d8             	mov    r8,rbx
    752cd4003493:	e9 84 f4 ff e7       	jmp    0x752cbc00291c
    752cd4003498:	4c 89 c3             	mov    rbx,r8
    752cd400349b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40034a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd40034a7:	bc 00 01 00 
    752cd40034ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40034b2:	02 00 00 00 
    752cd40034b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd40034bd:	0e 00 00 00 
    752cd40034c1:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40034c8:	57 00 00 
    752cd40034cb:	4d 89 f4             	mov    r12,r14
    752cd40034ce:	4c 89 f7             	mov    rdi,r14
    752cd40034d1:	ff d0                	call   rax
    752cd40034d3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40034da:	00 
    752cd40034db:	84 c9                	test   cl,cl
    752cd40034dd:	0f 85 69 01 00 00    	jne    0x752cd400364c
    752cd40034e3:	4d 89 e6             	mov    r14,r12
    752cd40034e6:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40034eb:	49 89 d8             	mov    r8,rbx
    752cd40034ee:	e9 4b f4 ff e7       	jmp    0x752cbc00293e
    752cd40034f3:	4c 89 c3             	mov    rbx,r8
    752cd40034f6:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40034fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd4003502:	bc 00 01 00 
    752cd4003506:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400350d:	02 00 00 00 
    752cd4003511:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd4003518:	0e 00 00 00 
    752cd400351c:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4003523:	57 00 00 
    752cd4003526:	4d 89 f4             	mov    r12,r14
    752cd4003529:	4c 89 f7             	mov    rdi,r14
    752cd400352c:	ff d0                	call   rax
    752cd400352e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003535:	00 
    752cd4003536:	84 c9                	test   cl,cl
    752cd4003538:	0f 85 0e 01 00 00    	jne    0x752cd400364c
    752cd400353e:	4d 89 e6             	mov    r14,r12
    752cd4003541:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003546:	49 89 d8             	mov    r8,rbx
    752cd4003549:	e9 12 f4 ff e7       	jmp    0x752cbc002960
    752cd400354e:	4c 89 c3             	mov    rbx,r8
    752cd4003551:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4003556:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd400355d:	bc 00 01 00 
    752cd4003561:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003568:	02 00 00 00 
    752cd400356c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd4003573:	0e 00 00 00 
    752cd4003577:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400357e:	57 00 00 
    752cd4003581:	4d 89 f4             	mov    r12,r14
    752cd4003584:	4c 89 f7             	mov    rdi,r14
    752cd4003587:	ff d0                	call   rax
    752cd4003589:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003590:	00 
    752cd4003591:	84 c9                	test   cl,cl
    752cd4003593:	0f 85 b3 00 00 00    	jne    0x752cd400364c
    752cd4003599:	4d 89 e6             	mov    r14,r12
    752cd400359c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40035a1:	49 89 d8             	mov    r8,rbx
    752cd40035a4:	e9 d9 f3 ff e7       	jmp    0x752cbc002982
    752cd40035a9:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40035ae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    752cd40035b5:	bc 00 01 00 
    752cd40035b9:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40035c0:	02 00 00 00 
    752cd40035c4:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd40035cb:	0e 00 00 00 
    752cd40035cf:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40035d6:	57 00 00 
    752cd40035d9:	4d 89 f4             	mov    r12,r14
    752cd40035dc:	4c 89 f7             	mov    rdi,r14
    752cd40035df:	ff d0                	call   rax
    752cd40035e1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40035e8:	00 
    752cd40035e9:	84 c9                	test   cl,cl
    752cd40035eb:	75 5f                	jne    0x752cd400364c
    752cd40035ed:	4d 89 e6             	mov    r14,r12
    752cd40035f0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40035f5:	e9 ac f3 ff e7       	jmp    0x752cbc0029a6
    752cd40035fa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100be
    752cd4003601:	be 00 01 00 
    752cd4003605:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400360c:	02 00 00 00 
    752cd4003610:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd4003617:	0f 00 00 00 
    752cd400361b:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd4003622:	57 00 00 
    752cd4003625:	49 89 ff             	mov    r15,rdi
    752cd4003628:	4c 89 ef             	mov    rdi,r13
    752cd400362b:	be 2a 00 00 00       	mov    esi,0x2a
    752cd4003630:	4c 89 f2             	mov    rdx,r14
    752cd4003633:	ff d0                	call   rax
    752cd4003635:	4c 89 ff             	mov    rdi,r15
    752cd4003638:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd400363f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4003646:	00 
    752cd4003647:	e9 7b f3 ff e7       	jmp    0x752cbc0029c7
    752cd400364c:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003653:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4003658:	bd 0e 00 00 00       	mov    ebp,0xe
    752cd400365d:	4d 89 e6             	mov    r14,r12
    752cd4003660:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003665:	e9 5d f3 ff e7       	jmp    0x752cbc0029c7
    752cd400366a:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003671:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4003676:	bd 0c 00 00 00       	mov    ebp,0xc
    752cd400367b:	eb e0                	jmp    0x752cd400365d
    752cd400367d:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4003684:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4003689:	bd 0c 00 00 00       	mov    ebp,0xc
    752cd400368e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd4003693:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4003698:	e9 2a f3 ff e7       	jmp    0x752cbc0029c7
