
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65682-0-128834993131888.bin:     file format binary


Disassembly of section .data:

0000752cbc001170 <.data>:
    752cbc001170:	50                   	push   rax
    752cbc001171:	41 8b 9d a0 00 00 00 	mov    ebx,DWORD PTR [r13+0xa0]
    752cbc001178:	8d 83 67 ff fe ff    	lea    eax,[rbx-0x10099]
    752cbc00117e:	83 f8 f8             	cmp    eax,0xfffffff8
    752cbc001181:	0f 87 53 0e 00 18    	ja     0x752cd4001fda
    752cbc001187:	41 8b ad a4 00 00 00 	mov    ebp,DWORD PTR [r13+0xa4]
    752cbc00118e:	8d 85 67 ff fe ff    	lea    eax,[rbp-0x10099]
    752cbc001194:	83 f8 f8             	cmp    eax,0xfffffff8
    752cbc001197:	0f 87 3d 0e 00 18    	ja     0x752cd4001fda
    752cbc00119d:	4d 8b bd 50 01 00 00 	mov    r15,QWORD PTR [r13+0x150]
    752cbc0011a4:	4d 8b a5 40 01 00 00 	mov    r12,QWORD PTR [r13+0x140]
    752cbc0011ab:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    752cbc0011b2:	41 8b 4d 00          	mov    ecx,DWORD PTR [r13+0x0]
    752cbc0011b6:	89 ca                	mov    edx,ecx
    752cbc0011b8:	c1 ea 1f             	shr    edx,0x1f
    752cbc0011bb:	31 f6                	xor    esi,esi
    752cbc0011bd:	85 c9                	test   ecx,ecx
    752cbc0011bf:	40 0f 94 c6          	sete   sil
    752cbc0011c3:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    752cbc0011ca:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    752cbc0011d1:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    752cbc0011d8:	48 b9 01 00 00 00 01 	movabs rcx,0x100000001
    752cbc0011df:	00 00 00 
    752cbc0011e2:	49 89 8d ec 00 00 00 	mov    QWORD PTR [r13+0xec],rcx
    752cbc0011e9:	74 51                	je     0x752cbc00123c
    752cbc0011eb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    752cbc0011f2:	c0 00 01 00 
    752cbc0011f6:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0011fd:	83 c0 02             	add    eax,0x2
    752cbc001200:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc001207:	39 c8                	cmp    eax,ecx
    752cbc001209:	0f 83 a5 0d 00 18    	jae    0x752cd4001fb4
    752cbc00120f:	41 81 bf 00 06 08 00 	cmp    DWORD PTR [r15+0x80600],0x100c0
    752cbc001216:	c0 00 01 00 
    752cbc00121a:	0f 85 94 0d 00 18    	jne    0x752cd4001fb4
    752cbc001220:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    752cbc001227:	c0 00 01 00 
    752cbc00122b:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001232:	49 8b 87 08 06 08 00 	mov    rax,QWORD PTR [r15+0x80608]
    752cbc001239:	59                   	pop    rcx
    752cbc00123a:	ff e0                	jmp    rax
    752cbc00123c:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    752cbc001240:	f6 c1 03             	test   cl,0x3
    752cbc001243:	0f 85 c3 0d 00 18    	jne    0x752cd400200c
    752cbc001249:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    752cbc00124d:	48 89 ce             	mov    rsi,rcx
    752cbc001250:	48 c1 ee 0c          	shr    rsi,0xc
    752cbc001254:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    752cbc001258:	48 85 c0             	test   rax,rax
    752cbc00125b:	0f 84 37 0e 00 18    	je     0x752cd4002098
    752cbc001261:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc001267:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc00126a:	41 80 3c 24 00       	cmp    BYTE PTR [r12],0x0
    752cbc00126f:	0f 85 68 0e 00 18    	jne    0x752cd40020dd
    752cbc001275:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    752cbc00127c:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    752cbc001283:	02 
    752cbc001284:	b8 9c 00 01 00       	mov    eax,0x1009c
    752cbc001289:	ba 9c 00 01 00       	mov    edx,0x1009c
    752cbc00128e:	72 07                	jb     0x752cbc001297
    752cbc001290:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    752cbc001297:	81 fb 98 00 01 00    	cmp    ebx,0x10098
    752cbc00129d:	0f 44 c2             	cmove  eax,edx
    752cbc0012a0:	89 c2                	mov    edx,eax
    752cbc0012a2:	83 f9 02             	cmp    ecx,0x2
    752cbc0012a5:	72 07                	jb     0x752cbc0012ae
    752cbc0012a7:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    752cbc0012ae:	81 fd 98 00 01 00    	cmp    ebp,0x10098
    752cbc0012b4:	0f 44 c2             	cmove  eax,edx
    752cbc0012b7:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    752cbc0012be:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    752cbc0012c5:	28 04 01 00 
    752cbc0012c9:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0012d0:	83 c0 04             	add    eax,0x4
    752cbc0012d3:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc0012da:	39 c8                	cmp    eax,ecx
    752cbc0012dc:	0f 83 04 0d 00 18    	jae    0x752cd4001fe6
    752cbc0012e2:	41 81 bf 40 21 08 00 	cmp    DWORD PTR [r15+0x82140],0x10428
    752cbc0012e9:	28 04 01 00 
    752cbc0012ed:	0f 85 f3 0c 00 18    	jne    0x752cd4001fe6
    752cbc0012f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    752cbc0012fa:	28 04 01 00 
    752cbc0012fe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001305:	49 8b 87 48 21 08 00 	mov    rax,QWORD PTR [r15+0x82148]
    752cbc00130c:	59                   	pop    rcx
    752cbc00130d:	ff e0                	jmp    rax
    752cbc00130f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    752cbc001316:	01 
    752cbc001317:	58                   	pop    rax
    752cbc001318:	c2 08 00             	ret    0x8
