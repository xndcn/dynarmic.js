
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65536-0-128834993127456.bin:     file format binary


Disassembly of section .data:

0000752cbc000020 <.data>:
    752cbc000020:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    752cbc000027:	8d 8a fd ff fe ff    	lea    ecx,[rdx-0x10003]
    752cbc00002d:	b8 65 01 00 00       	mov    eax,0x165
    752cbc000032:	83 f9 fc             	cmp    ecx,0xfffffffc
    752cbc000035:	0f 87 d8 00 00 00    	ja     0x752cbc000113
    752cbc00003b:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    752cbc000042:	8d b1 fd ff fe ff    	lea    esi,[rcx-0x10003]
    752cbc000048:	83 fe fc             	cmp    esi,0xfffffffc
    752cbc00004b:	0f 87 c2 00 00 00    	ja     0x752cbc000113
    752cbc000051:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    752cbc000058:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    752cbc00005d:	41 8b bd 9c 00 00 00 	mov    edi,DWORD PTR [r13+0x9c]
    752cbc000064:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    752cbc00006b:	02 
    752cbc00006c:	be 06 00 01 00       	mov    esi,0x10006
    752cbc000071:	bb 06 00 01 00       	mov    ebx,0x10006
    752cbc000076:	72 07                	jb     0x752cbc00007f
    752cbc000078:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    752cbc00007f:	81 fa 02 00 01 00    	cmp    edx,0x10002
    752cbc000085:	0f 44 f3             	cmove  esi,ebx
    752cbc000088:	89 f2                	mov    edx,esi
    752cbc00008a:	83 ff 02             	cmp    edi,0x2
    752cbc00008d:	72 07                	jb     0x752cbc000096
    752cbc00008f:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    752cbc000096:	81 f9 02 00 01 00    	cmp    ecx,0x10002
    752cbc00009c:	0f 44 f2             	cmove  esi,edx
    752cbc00009f:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    752cbc0000a6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    752cbc0000ad:	14 00 01 00 
    752cbc0000b1:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    752cbc0000b8:	83 c1 02             	add    ecx,0x2
    752cbc0000bb:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cbc0000c2:	39 d1                	cmp    ecx,edx
    752cbc0000c4:	73 27                	jae    0x752cbc0000ed
    752cbc0000c6:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    752cbc0000cd:	00 01 00 
    752cbc0000d0:	75 1b                	jne    0x752cbc0000ed
    752cbc0000d2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    752cbc0000d9:	14 00 01 00 
    752cbc0000dd:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    752cbc0000e4:	48 8b 80 a8 00 08 00 	mov    rax,QWORD PTR [rax+0x800a8]
    752cbc0000eb:	ff e0                	jmp    rax
    752cbc0000ed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    752cbc0000f4:	14 00 01 00 
    752cbc0000f8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cbc0000ff:	04 00 00 00 
    752cbc000103:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cbc00010a:	02 00 00 00 
    752cbc00010e:	b8 28 01 00 00       	mov    eax,0x128
    752cbc000113:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    752cbc000119:	c2 08 00             	ret    0x8
