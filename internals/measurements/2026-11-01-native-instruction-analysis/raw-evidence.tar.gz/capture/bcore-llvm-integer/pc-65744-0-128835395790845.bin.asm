
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65744-0-128835395790845.bin:     file format binary


Disassembly of section .data:

0000752cd40027fd <.data>:
    752cd40027fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002804:	02 00 00 00 
    752cd4002808:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400280f:	01 00 00 00 
    752cd4002813:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd400281a:	57 00 00 
    752cd400281d:	48 89 fb             	mov    rbx,rdi
    752cd4002820:	4c 89 ef             	mov    rdi,r13
    752cd4002823:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    752cd4002828:	ba d0 00 01 00       	mov    edx,0x100d0
    752cd400282d:	44 89 c9             	mov    ecx,r9d
    752cd4002830:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4002836:	ff d0                	call   rax
    752cd4002838:	48 89 df             	mov    rdi,rbx
    752cd400283b:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002842:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002849:	00 
    752cd400284a:	bb 02 00 00 00       	mov    ebx,0x2
    752cd400284f:	bd 01 00 00 00       	mov    ebp,0x1
    752cd4002854:	e9 83 f2 ff e7       	jmp    0x752cbc001adc
    752cd4002859:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002860:	02 00 00 00 
    752cd4002864:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400286b:	01 00 00 00 
    752cd400286f:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4002876:	57 00 00 
    752cd4002879:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400287e:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002883:	44 89 ce             	mov    esi,r9d
    752cd4002886:	4d 89 c6             	mov    r14,r8
    752cd4002889:	4d 89 cc             	mov    r12,r9
    752cd400288c:	4c 89 d3             	mov    rbx,r10
    752cd400288f:	4d 89 df             	mov    r15,r11
    752cd4002892:	ff d0                	call   rax
    752cd4002894:	4d 89 fb             	mov    r11,r15
    752cd4002897:	49 89 da             	mov    r10,rbx
    752cd400289a:	4d 89 e1             	mov    r9,r12
    752cd400289d:	4d 89 f0             	mov    r8,r14
    752cd40028a0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40028a5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40028ac:	00 
    752cd40028ad:	84 c9                	test   cl,cl
    752cd40028af:	0f 84 0d f0 ff e7    	je     0x752cbc0018c2
    752cd40028b5:	e9 e2 00 00 00       	jmp    0x752cd400299c
    752cd40028ba:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40028c1:	02 00 00 00 
    752cd40028c5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40028cc:	01 00 00 00 
    752cd40028d0:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40028d7:	57 00 00 
    752cd40028da:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40028df:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40028e4:	49 89 f7             	mov    r15,rsi
    752cd40028e7:	4d 89 c6             	mov    r14,r8
    752cd40028ea:	4d 89 cc             	mov    r12,r9
    752cd40028ed:	48 89 dd             	mov    rbp,rbx
    752cd40028f0:	4c 89 d3             	mov    rbx,r10
    752cd40028f3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40028f8:	ff d0                	call   rax
    752cd40028fa:	4c 89 fe             	mov    rsi,r15
    752cd40028fd:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002902:	49 89 da             	mov    r10,rbx
    752cd4002905:	48 89 eb             	mov    rbx,rbp
    752cd4002908:	48 8b 6c 24 30       	mov    rbp,QWORD PTR [rsp+0x30]
    752cd400290d:	4d 89 e1             	mov    r9,r12
    752cd4002910:	4d 89 f0             	mov    r8,r14
    752cd4002913:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002918:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400291f:	00 
    752cd4002920:	84 c9                	test   cl,cl
    752cd4002922:	0f 84 c4 ef ff e7    	je     0x752cbc0018ec
    752cd4002928:	eb 72                	jmp    0x752cd400299c
    752cd400292a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    752cd4002931:	d2 00 01 00 
    752cd4002935:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400293c:	02 00 00 00 
    752cd4002940:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4002947:	01 00 00 00 
    752cd400294b:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4002952:	57 00 00 
    752cd4002955:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400295a:	4c 89 ef             	mov    rdi,r13
    752cd400295d:	4c 89 c5             	mov    rbp,r8
    752cd4002960:	4d 89 cc             	mov    r12,r9
    752cd4002963:	49 89 de             	mov    r14,rbx
    752cd4002966:	4c 89 d3             	mov    rbx,r10
    752cd4002969:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd400296e:	49 89 f7             	mov    r15,rsi
    752cd4002971:	ff d0                	call   rax
    752cd4002973:	4c 89 fe             	mov    rsi,r15
    752cd4002976:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd400297b:	49 89 da             	mov    r10,rbx
    752cd400297e:	4c 89 f3             	mov    rbx,r14
    752cd4002981:	4d 89 e1             	mov    r9,r12
    752cd4002984:	49 89 e8             	mov    r8,rbp
    752cd4002987:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400298c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002993:	00 
    752cd4002994:	84 c9                	test   cl,cl
    752cd4002996:	0f 84 5e ef ff e7    	je     0x752cbc0018fa
    752cd400299c:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd40029a3:	e9 a2 fe ff ff       	jmp    0x752cd400284a
    752cd40029a8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    752cd40029af:	d2 00 01 00 
    752cd40029b3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40029ba:	04 00 00 00 
    752cd40029be:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd40029c5:	02 00 00 00 
    752cd40029c9:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40029d0:	57 00 00 
    752cd40029d3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40029d8:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40029dd:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    752cd40029e2:	44 89 f6             	mov    esi,r14d
    752cd40029e5:	4c 89 c5             	mov    rbp,r8
    752cd40029e8:	4c 89 74 24 20       	mov    QWORD PTR [rsp+0x20],r14
    752cd40029ed:	49 89 de             	mov    r14,rbx
    752cd40029f0:	4c 89 cb             	mov    rbx,r9
    752cd40029f3:	4d 89 d7             	mov    r15,r10
    752cd40029f6:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40029fb:	ff d0                	call   rax
    752cd40029fd:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    752cd4002a02:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002a07:	4d 89 fa             	mov    r10,r15
    752cd4002a0a:	49 89 d9             	mov    r9,rbx
    752cd4002a0d:	4c 89 f3             	mov    rbx,r14
    752cd4002a10:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
    752cd4002a15:	49 89 e8             	mov    r8,rbp
    752cd4002a18:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002a1d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002a24:	00 
    752cd4002a25:	84 c9                	test   cl,cl
    752cd4002a27:	0f 84 00 ef ff e7    	je     0x752cbc00192d
    752cd4002a2d:	e9 14 01 00 00       	jmp    0x752cd4002b46
    752cd4002a32:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d2
    752cd4002a39:	d2 00 01 00 
    752cd4002a3d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002a44:	04 00 00 00 
    752cd4002a48:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4002a4f:	02 00 00 00 
    752cd4002a53:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4002a5a:	57 00 00 
    752cd4002a5d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002a62:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002a67:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    752cd4002a6c:	89 ee                	mov    esi,ebp
    752cd4002a6e:	44 89 e2             	mov    edx,r12d
    752cd4002a71:	4c 89 74 24 20       	mov    QWORD PTR [rsp+0x20],r14
    752cd4002a76:	49 89 de             	mov    r14,rbx
    752cd4002a79:	4c 89 c3             	mov    rbx,r8
    752cd4002a7c:	4c 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],r9
    752cd4002a81:	4d 89 d4             	mov    r12,r10
    752cd4002a84:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4002a89:	ff d0                	call   rax
    752cd4002a8b:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    752cd4002a90:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002a95:	4d 89 e2             	mov    r10,r12
    752cd4002a98:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
    752cd4002a9d:	49 89 d8             	mov    r8,rbx
    752cd4002aa0:	4c 89 f3             	mov    rbx,r14
    752cd4002aa3:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
    752cd4002aa8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002aad:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002ab4:	00 
    752cd4002ab5:	84 c9                	test   cl,cl
    752cd4002ab7:	0f 84 94 ee ff e7    	je     0x752cbc001951
    752cd4002abd:	e9 84 00 00 00       	jmp    0x752cd4002b46
    752cd4002ac2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d6
    752cd4002ac9:	d6 00 01 00 
    752cd4002acd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002ad4:	04 00 00 00 
    752cd4002ad8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4002adf:	02 00 00 00 
    752cd4002ae3:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4002aea:	57 00 00 
    752cd4002aed:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002af2:	4c 89 ef             	mov    rdi,r13
    752cd4002af5:	4c 89 74 24 20       	mov    QWORD PTR [rsp+0x20],r14
    752cd4002afa:	4d 89 c6             	mov    r14,r8
    752cd4002afd:	4c 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],r9
    752cd4002b02:	4d 89 d4             	mov    r12,r10
    752cd4002b05:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4002b0a:	48 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],rbx
    752cd4002b0f:	48 89 f3             	mov    rbx,rsi
    752cd4002b12:	ff d0                	call   rax
    752cd4002b14:	48 89 de             	mov    rsi,rbx
    752cd4002b17:	48 8b 5c 24 30       	mov    rbx,QWORD PTR [rsp+0x30]
    752cd4002b1c:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002b21:	4d 89 e2             	mov    r10,r12
    752cd4002b24:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
    752cd4002b29:	4d 89 f0             	mov    r8,r14
    752cd4002b2c:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
    752cd4002b31:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002b36:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002b3d:	00 
    752cd4002b3e:	84 c9                	test   cl,cl
    752cd4002b40:	0f 84 21 ee ff e7    	je     0x752cbc001967
    752cd4002b46:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002b4d:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4002b52:	bd 02 00 00 00       	mov    ebp,0x2
    752cd4002b57:	e9 80 ef ff e7       	jmp    0x752cbc001adc
    752cd4002b5c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    752cd4002b63:	04 01 01 00 
    752cd4002b67:	b1 01                	mov    cl,0x1
    752cd4002b69:	bd 04 00 00 00       	mov    ebp,0x4
    752cd4002b6e:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4002b73:	e9 58 f0 ff e7       	jmp    0x752cbc001bd0
    752cd4002b78:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    752cd4002b7f:	e9 4c f0 ff e7       	jmp    0x752cbc001bd0
    752cd4002b84:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    752cd4002b8b:	ec 00 01 00 
    752cd4002b8f:	b1 01                	mov    cl,0x1
    752cd4002b91:	bd 13 00 00 00       	mov    ebp,0x13
    752cd4002b96:	eb d6                	jmp    0x752cd4002b6e
    752cd4002b98:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4002b9d:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    752cd4002ba2:	4c 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],r9
    752cd4002ba7:	4d 89 c7             	mov    r15,r8
    752cd4002baa:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002baf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    752cd4002bb6:	04 01 01 00 
    752cd4002bba:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002bc1:	04 00 00 00 
    752cd4002bc5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    752cd4002bcc:	14 00 00 00 
    752cd4002bd0:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002bd7:	57 00 00 
    752cd4002bda:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002bdf:	89 ee                	mov    esi,ebp
    752cd4002be1:	ff d0                	call   rax
    752cd4002be3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002bea:	00 
    752cd4002beb:	84 c9                	test   cl,cl
    752cd4002bed:	0f 85 b7 01 00 00    	jne    0x752cd4002daa
    752cd4002bf3:	89 c5                	mov    ebp,eax
    752cd4002bf5:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002bfa:	4d 89 f8             	mov    r8,r15
    752cd4002bfd:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
    752cd4002c02:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    752cd4002c07:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002c0c:	e9 43 ee ff e7       	jmp    0x752cbc001a54
    752cd4002c11:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4002c16:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    752cd4002c1b:	4c 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],r9
    752cd4002c20:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    752cd4002c25:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002c2a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    752cd4002c31:	04 01 01 00 
    752cd4002c35:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4002c3c:	04 00 00 00 
    752cd4002c40:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x14
    752cd4002c47:	14 00 00 00 
    752cd4002c4b:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002c52:	57 00 00 
    752cd4002c55:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002c5a:	44 89 f6             	mov    esi,r14d
    752cd4002c5d:	ff d0                	call   rax
    752cd4002c5f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002c66:	00 
    752cd4002c67:	84 c9                	test   cl,cl
    752cd4002c69:	0f 85 3b 01 00 00    	jne    0x752cd4002daa
    752cd4002c6f:	41 89 c7             	mov    r15d,eax
    752cd4002c72:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002c77:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    752cd4002c7c:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
    752cd4002c81:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    752cd4002c86:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002c8b:	4c 89 e6             	mov    rsi,r12
    752cd4002c8e:	e9 e1 ed ff e7       	jmp    0x752cbc001a74
    752cd4002c93:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4002c98:	4d 89 d4             	mov    r12,r10
    752cd4002c9b:	4c 89 cd             	mov    rbp,r9
    752cd4002c9e:	4c 89 c3             	mov    rbx,r8
    752cd4002ca1:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002ca6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    752cd4002cad:	0a 01 01 00 
    752cd4002cb1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002cb8:	02 00 00 00 
    752cd4002cbc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    752cd4002cc3:	16 00 00 00 
    752cd4002cc7:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002cce:	57 00 00 
    752cd4002cd1:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002cd6:	ff d0                	call   rax
    752cd4002cd8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002cdf:	00 
    752cd4002ce0:	84 c9                	test   cl,cl
    752cd4002ce2:	0f 85 d5 00 00 00    	jne    0x752cd4002dbd
    752cd4002ce8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002ced:	49 89 d8             	mov    r8,rbx
    752cd4002cf0:	49 89 e9             	mov    r9,rbp
    752cd4002cf3:	4d 89 e2             	mov    r10,r12
    752cd4002cf6:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4002cfb:	e9 a2 ed ff e7       	jmp    0x752cbc001aa2
    752cd4002d00:	4c 89 c3             	mov    rbx,r8
    752cd4002d03:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4002d08:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010a
    752cd4002d0f:	0a 01 01 00 
    752cd4002d13:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002d1a:	02 00 00 00 
    752cd4002d1e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    752cd4002d25:	16 00 00 00 
    752cd4002d29:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002d30:	57 00 00 
    752cd4002d33:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4002d38:	44 89 ce             	mov    esi,r9d
    752cd4002d3b:	ff d0                	call   rax
    752cd4002d3d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002d44:	00 
    752cd4002d45:	84 c9                	test   cl,cl
    752cd4002d47:	75 74                	jne    0x752cd4002dbd
    752cd4002d49:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002d4e:	49 89 d8             	mov    r8,rbx
    752cd4002d51:	e9 68 ed ff e7       	jmp    0x752cbc001abe
    752cd4002d56:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1010c
    752cd4002d5d:	0c 01 01 00 
    752cd4002d61:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4002d68:	02 00 00 00 
    752cd4002d6c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    752cd4002d73:	17 00 00 00 
    752cd4002d77:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd4002d7e:	57 00 00 
    752cd4002d81:	49 89 ff             	mov    r15,rdi
    752cd4002d84:	4c 89 ef             	mov    rdi,r13
    752cd4002d87:	be 2a 00 00 00       	mov    esi,0x2a
    752cd4002d8c:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    752cd4002d91:	ff d0                	call   rax
    752cd4002d93:	4c 89 ff             	mov    rdi,r15
    752cd4002d96:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002d9d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4002da4:	00 
    752cd4002da5:	e9 32 ed ff e7       	jmp    0x752cbc001adc
    752cd4002daa:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002db1:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4002db6:	bd 14 00 00 00       	mov    ebp,0x14
    752cd4002dbb:	eb 11                	jmp    0x752cd4002dce
    752cd4002dbd:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    752cd4002dc4:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4002dc9:	bd 16 00 00 00       	mov    ebp,0x16
    752cd4002dce:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4002dd3:	e9 04 ed ff e7       	jmp    0x752cbc001adc
