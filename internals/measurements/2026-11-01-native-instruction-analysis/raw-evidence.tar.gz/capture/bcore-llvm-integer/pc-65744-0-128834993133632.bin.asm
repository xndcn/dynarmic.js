
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65744-0-128834993133632.bin:     file format binary


Disassembly of section .data:

0000752cbc001840 <.data>:
    752cbc001840:	48 83 ec 48          	sub    rsp,0x48
    752cbc001844:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cbc001849:	ba f3 fe fe ff       	mov    edx,0xfffefef3
    752cbc00184e:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc001855:	01 d6                	add    esi,edx
    752cbc001857:	b1 01                	mov    cl,0x1
    752cbc001859:	b8 65 01 00 00       	mov    eax,0x165
    752cbc00185e:	83 fe c2             	cmp    esi,0xffffffc2
    752cbc001861:	0f 87 7c 03 00 00    	ja     0x752cbc001be3
    752cbc001867:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc00186e:	83 fa c2             	cmp    edx,0xffffffc2
    752cbc001871:	0f 87 6c 03 00 00    	ja     0x752cbc001be3
    752cbc001877:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    752cbc00187e:	45 8b 45 38          	mov    r8d,DWORD PTR [r13+0x38]
    752cbc001882:	45 8d 48 fc          	lea    r9d,[r8-0x4]
    752cbc001886:	41 f6 c0 03          	test   r8b,0x3
    752cbc00188a:	0f 85 6d 0f 00 18    	jne    0x752cd40027fd
    752cbc001890:	4d 8b 95 38 01 00 00 	mov    r10,QWORD PTR [r13+0x138]
    752cbc001897:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    752cbc00189e:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    752cbc0018a2:	45 89 cb             	mov    r11d,r9d
    752cbc0018a5:	41 c1 eb 0c          	shr    r11d,0xc
    752cbc0018a9:	4b 8b 04 da          	mov    rax,QWORD PTR [r10+r11*8]
    752cbc0018ad:	48 85 c0             	test   rax,rax
    752cbc0018b0:	0f 84 a3 0f 00 18    	je     0x752cd4002859
    752cbc0018b6:	44 89 c9             	mov    ecx,r9d
    752cbc0018b9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0018bf:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0018c2:	41 8d 70 f8          	lea    esi,[r8-0x8]
    752cbc0018c6:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    752cbc0018ca:	89 f3                	mov    ebx,esi
    752cbc0018cc:	c1 eb 0c             	shr    ebx,0xc
    752cbc0018cf:	49 8b 04 da          	mov    rax,QWORD PTR [r10+rbx*8]
    752cbc0018d3:	48 85 c0             	test   rax,rax
    752cbc0018d6:	48 89 6c 24 30       	mov    QWORD PTR [rsp+0x30],rbp
    752cbc0018db:	0f 84 d9 0f 00 18    	je     0x752cd40028ba
    752cbc0018e1:	89 f1                	mov    ecx,esi
    752cbc0018e3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0018e9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0018ec:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc0018f0:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    752cbc0018f4:	0f 85 30 10 00 18    	jne    0x752cd400292a
    752cbc0018fa:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    752cbc0018fe:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    752cbc001905:	45 8d 70 f4          	lea    r14d,[r8-0xc]
    752cbc001909:	44 89 f0             	mov    eax,r14d
    752cbc00190c:	c1 e8 0c             	shr    eax,0xc
    752cbc00190f:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    752cbc001914:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    752cbc001918:	48 85 c0             	test   rax,rax
    752cbc00191b:	0f 84 87 10 00 18    	je     0x752cd40029a8
    752cbc001921:	44 89 f1             	mov    ecx,r14d
    752cbc001924:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc00192a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc00192d:	41 8d 68 f0          	lea    ebp,[r8-0x10]
    752cbc001931:	41 89 ef             	mov    r15d,ebp
    752cbc001934:	41 c1 ef 0c          	shr    r15d,0xc
    752cbc001938:	4b 8b 04 fa          	mov    rax,QWORD PTR [r10+r15*8]
    752cbc00193c:	48 85 c0             	test   rax,rax
    752cbc00193f:	0f 84 ed 10 00 18    	je     0x752cd4002a32
    752cbc001945:	89 e9                	mov    ecx,ebp
    752cbc001947:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc00194d:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    752cbc001951:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc001955:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    752cbc001959:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    752cbc00195e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    752cbc001961:	0f 85 5b 11 00 18    	jne    0x752cd4002ac2
    752cbc001967:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    752cbc00196b:	89 c1                	mov    ecx,eax
    752cbc00196d:	c1 e9 1f             	shr    ecx,0x1f
    752cbc001970:	31 d2                	xor    edx,edx
    752cbc001972:	85 c0                	test   eax,eax
    752cbc001974:	0f 94 c2             	sete   dl
    752cbc001977:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    752cbc00197e:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    752cbc001985:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    752cbc00198c:	48 b9 01 00 00 00 01 	movabs rcx,0x100000001
    752cbc001993:	00 00 00 
    752cbc001996:	49 89 8d ec 00 00 00 	mov    QWORD PTR [r13+0xec],rcx
    752cbc00199d:	0f 84 86 01 00 00    	je     0x752cbc001b29
    752cbc0019a3:	48 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],rbx
    752cbc0019a8:	49 89 f4             	mov    r12,rsi
    752cbc0019ab:	48 b9 0d 66 19 00 5f 	movabs rcx,0x3c6ef35f0019660d
    752cbc0019b2:	f3 6e 3c 
    752cbc0019b5:	49 89 4d 18          	mov    QWORD PTR [r13+0x18],rcx
    752cbc0019b9:	41 69 4d 04 0d 66 19 	imul   ecx,DWORD PTR [r13+0x4],0x19660d
    752cbc0019c0:	00 
    752cbc0019c1:	8d 91 5f f3 6e 3c    	lea    edx,[rcx+0x3c6ef35f]
    752cbc0019c7:	c1 e9 1f             	shr    ecx,0x1f
    752cbc0019ca:	89 d3                	mov    ebx,edx
    752cbc0019cc:	c1 eb 0d             	shr    ebx,0xd
    752cbc0019cf:	31 d3                	xor    ebx,edx
    752cbc0019d1:	89 d6                	mov    esi,edx
    752cbc0019d3:	c1 ee 1f             	shr    esi,0x1f
    752cbc0019d6:	c4 e2 70 f2 ce       	andn   ecx,ecx,esi
    752cbc0019db:	89 de                	mov    esi,ebx
    752cbc0019dd:	c1 e6 07             	shl    esi,0x7
    752cbc0019e0:	41 89 75 0c          	mov    DWORD PTR [r13+0xc],esi
    752cbc0019e4:	41 c7 45 08 01 00 00 	mov    DWORD PTR [r13+0x8],0x1
    752cbc0019eb:	00 
    752cbc0019ec:	41 09 8d 00 01 00 00 	or     DWORD PTR [r13+0x100],ecx
    752cbc0019f3:	0f a4 d3 07          	shld   ebx,edx,0x7
    752cbc0019f7:	41 89 5d 04          	mov    DWORD PTR [r13+0x4],ebx
    752cbc0019fb:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    752cbc001a02:	00 00 00 00 
    752cbc001a06:	31 c9                	xor    ecx,ecx
    752cbc001a08:	83 f8 01             	cmp    eax,0x1
    752cbc001a0b:	0f 94 c1             	sete   cl
    752cbc001a0e:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    752cbc001a15:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    752cbc001a1c:	48 b8 00 00 00 00 01 	movabs rax,0x100000000
    752cbc001a23:	00 00 00 
    752cbc001a26:	49 89 85 e8 00 00 00 	mov    QWORD PTR [r13+0xe8],rax
    752cbc001a2d:	41 c7 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],0x1
    752cbc001a34:	01 00 00 00 
    752cbc001a38:	0f 85 43 01 00 00    	jne    0x752cbc001b81
    752cbc001a3e:	4b 8b 04 fa          	mov    rax,QWORD PTR [r10+r15*8]
    752cbc001a42:	48 85 c0             	test   rax,rax
    752cbc001a45:	0f 84 4d 11 00 18    	je     0x752cd4002b98
    752cbc001a4b:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    752cbc001a51:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    752cbc001a54:	4c 89 e6             	mov    rsi,r12
    752cbc001a57:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc001a5c:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    752cbc001a60:	48 85 c0             	test   rax,rax
    752cbc001a63:	0f 84 a8 11 00 18    	je     0x752cd4002c11
    752cbc001a69:	41 81 e6 ff 0f 00 00 	and    r14d,0xfff
    752cbc001a70:	46 8b 3c 30          	mov    r15d,DWORD PTR [rax+r14*1]
    752cbc001a74:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc001a78:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    752cbc001a7f:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc001a83:	41 89 5d 00          	mov    DWORD PTR [r13+0x0],ebx
    752cbc001a87:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    752cbc001a8c:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    752cbc001a90:	48 85 c0             	test   rax,rax
    752cbc001a93:	0f 84 fa 11 00 18    	je     0x752cd4002c93
    752cbc001a99:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc001a9f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc001aa2:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    752cbc001aa6:	4b 8b 04 da          	mov    rax,QWORD PTR [r10+r11*8]
    752cbc001aaa:	48 85 c0             	test   rax,rax
    752cbc001aad:	0f 84 4d 12 00 18    	je     0x752cd4002d00
    752cbc001ab3:	41 81 e1 ff 0f 00 00 	and    r9d,0xfff
    752cbc001aba:	42 8b 04 08          	mov    eax,DWORD PTR [rax+r9*1]
    752cbc001abe:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    752cbc001ac2:	45 89 45 38          	mov    DWORD PTR [r13+0x38],r8d
    752cbc001ac6:	b1 01                	mov    cl,0x1
    752cbc001ac8:	bb 02 00 00 00       	mov    ebx,0x2
    752cbc001acd:	bd 17 00 00 00       	mov    ebp,0x17
    752cbc001ad2:	41 f6 c7 01          	test   r15b,0x1
    752cbc001ad6:	0f 85 7a 12 00 18    	jne    0x752cd4002d56
    752cbc001adc:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc001ae3:	01 e8                	add    eax,ebp
    752cbc001ae5:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cbc001aec:	39 d0                	cmp    eax,edx
    752cbc001aee:	0f 83 84 10 00 18    	jae    0x752cd4002b78
    752cbc001af4:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    752cbc001afb:	00 
    752cbc001afc:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cbc001b02:	44 39 3c 17          	cmp    DWORD PTR [rdi+rdx*1],r15d
    752cbc001b06:	0f 85 6c 10 00 18    	jne    0x752cd4002b78
    752cbc001b0c:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    752cbc001b13:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001b1a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc001b21:	00 
    752cbc001b22:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    752cbc001b27:	eb 4d                	jmp    0x752cbc001b76
    752cbc001b29:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    752cbc001b30:	04 01 01 00 
    752cbc001b34:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc001b3b:	83 c0 04             	add    eax,0x4
    752cbc001b3e:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc001b45:	39 c8                	cmp    eax,ecx
    752cbc001b47:	0f 83 0f 10 00 18    	jae    0x752cd4002b5c
    752cbc001b4d:	81 bf 20 08 08 00 04 	cmp    DWORD PTR [rdi+0x80820],0x10104
    752cbc001b54:	01 01 00 
    752cbc001b57:	0f 85 ff 0f 00 18    	jne    0x752cd4002b5c
    752cbc001b5d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    752cbc001b64:	04 01 01 00 
    752cbc001b68:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001b6f:	48 8b 87 28 08 08 00 	mov    rax,QWORD PTR [rdi+0x80828]
    752cbc001b76:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cbc001b7b:	48 83 c4 48          	add    rsp,0x48
    752cbc001b7f:	ff e0                	jmp    rax
    752cbc001b81:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    752cbc001b88:	ec 00 01 00 
    752cbc001b8c:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc001b93:	83 c0 13             	add    eax,0x13
    752cbc001b96:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc001b9d:	39 c8                	cmp    eax,ecx
    752cbc001b9f:	0f 83 df 0f 00 18    	jae    0x752cd4002b84
    752cbc001ba5:	81 bf 60 07 08 00 ec 	cmp    DWORD PTR [rdi+0x80760],0x100ec
    752cbc001bac:	00 01 00 
    752cbc001baf:	0f 85 cf 0f 00 18    	jne    0x752cd4002b84
    752cbc001bb5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    752cbc001bbc:	ec 00 01 00 
    752cbc001bc0:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001bc7:	48 8b 87 68 07 08 00 	mov    rax,QWORD PTR [rdi+0x80768]
    752cbc001bce:	eb a6                	jmp    0x752cbc001b76
    752cbc001bd0:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    752cbc001bd7:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc001bde:	b8 28 01 00 00       	mov    eax,0x128
    752cbc001be3:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc001be8:	48 83 c4 48          	add    rsp,0x48
    752cbc001bec:	c2 08 00             	ret    0x8
