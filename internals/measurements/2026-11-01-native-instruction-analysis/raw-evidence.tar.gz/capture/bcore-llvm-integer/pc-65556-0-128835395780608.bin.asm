
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65556-0-128835395780608.bin:     file format binary


Disassembly of section .data:

0000752cd4000000 <.data>:
    752cd4000000:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    752cd4000007:	e9 f1 05 00 e8       	jmp    0x752cbc0005fd
    752cd400000c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000013:	02 00 00 00 
    752cd4000017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400001e:	01 00 00 00 
    752cd4000022:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4000029:	57 00 00 
    752cd400002c:	48 89 fb             	mov    rbx,rdi
    752cd400002f:	4c 89 ef             	mov    rdi,r13
    752cd4000032:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    752cd4000037:	ba 14 00 01 00       	mov    edx,0x10014
    752cd400003c:	44 89 c9             	mov    ecx,r9d
    752cd400003f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4000045:	ff d0                	call   rax
    752cd4000047:	48 89 df             	mov    rdi,rbx
    752cd400004a:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000051:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000058:	00 
    752cd4000059:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cd400005f:	bd 01 00 00 00       	mov    ebp,0x1
    752cd4000064:	e9 ee 04 00 e8       	jmp    0x752cbc000557
    752cd4000069:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000070:	02 00 00 00 
    752cd4000074:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400007b:	01 00 00 00 
    752cd400007f:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4000086:	57 00 00 
    752cd4000089:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400008e:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000093:	44 89 ce             	mov    esi,r9d
    752cd4000096:	4c 89 c5             	mov    rbp,r8
    752cd4000099:	49 89 de             	mov    r14,rbx
    752cd400009c:	4c 89 cb             	mov    rbx,r9
    752cd400009f:	4d 89 d7             	mov    r15,r10
    752cd40000a2:	ff d0                	call   rax
    752cd40000a4:	4d 89 fa             	mov    r10,r15
    752cd40000a7:	49 89 d9             	mov    r9,rbx
    752cd40000aa:	4c 89 f3             	mov    rbx,r14
    752cd40000ad:	49 89 e8             	mov    r8,rbp
    752cd40000b0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40000b5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40000bc:	00 
    752cd40000bd:	84 c9                	test   cl,cl
    752cd40000bf:	0f 84 e0 00 00 e8    	je     0x752cbc0001a5
    752cd40000c5:	e9 db 02 00 00       	jmp    0x752cd40003a5
    752cd40000ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40000d1:	02 00 00 00 
    752cd40000d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40000dc:	01 00 00 00 
    752cd40000e0:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40000e7:	57 00 00 
    752cd40000ea:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40000ef:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40000f4:	44 89 de             	mov    esi,r11d
    752cd40000f7:	4c 89 c5             	mov    rbp,r8
    752cd40000fa:	49 89 de             	mov    r14,rbx
    752cd40000fd:	4c 89 cb             	mov    rbx,r9
    752cd4000100:	4d 89 d7             	mov    r15,r10
    752cd4000103:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000108:	ff d0                	call   rax
    752cd400010a:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd400010f:	4d 89 fa             	mov    r10,r15
    752cd4000112:	49 89 d9             	mov    r9,rbx
    752cd4000115:	4c 89 f3             	mov    rbx,r14
    752cd4000118:	49 89 e8             	mov    r8,rbp
    752cd400011b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000120:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000127:	00 
    752cd4000128:	84 c9                	test   cl,cl
    752cd400012a:	0f 84 a4 00 00 e8    	je     0x752cbc0001d4
    752cd4000130:	e9 70 02 00 00       	jmp    0x752cd40003a5
    752cd4000135:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400013c:	02 00 00 00 
    752cd4000140:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4000147:	01 00 00 00 
    752cd400014b:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4000152:	57 00 00 
    752cd4000155:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400015a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd400015f:	4c 89 c5             	mov    rbp,r8
    752cd4000162:	49 89 de             	mov    r14,rbx
    752cd4000165:	4c 89 cb             	mov    rbx,r9
    752cd4000168:	4d 89 d7             	mov    r15,r10
    752cd400016b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000170:	ff d0                	call   rax
    752cd4000172:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000177:	4d 89 fa             	mov    r10,r15
    752cd400017a:	49 89 d9             	mov    r9,rbx
    752cd400017d:	4c 89 f3             	mov    rbx,r14
    752cd4000180:	49 89 e8             	mov    r8,rbp
    752cd4000183:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000188:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400018f:	00 
    752cd4000190:	84 c9                	test   cl,cl
    752cd4000192:	0f 84 6f 00 00 e8    	je     0x752cbc000207
    752cd4000198:	e9 08 02 00 00       	jmp    0x752cd40003a5
    752cd400019d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40001a4:	02 00 00 00 
    752cd40001a8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40001af:	01 00 00 00 
    752cd40001b3:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40001ba:	57 00 00 
    752cd40001bd:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40001c2:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40001c7:	4c 89 c5             	mov    rbp,r8
    752cd40001ca:	49 89 de             	mov    r14,rbx
    752cd40001cd:	4c 89 cb             	mov    rbx,r9
    752cd40001d0:	4d 89 d7             	mov    r15,r10
    752cd40001d3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40001d8:	ff d0                	call   rax
    752cd40001da:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40001df:	4d 89 fa             	mov    r10,r15
    752cd40001e2:	49 89 d9             	mov    r9,rbx
    752cd40001e5:	4c 89 f3             	mov    rbx,r14
    752cd40001e8:	49 89 e8             	mov    r8,rbp
    752cd40001eb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40001f0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40001f7:	00 
    752cd40001f8:	84 c9                	test   cl,cl
    752cd40001fa:	0f 84 3a 00 00 e8    	je     0x752cbc00023a
    752cd4000200:	e9 a0 01 00 00       	jmp    0x752cd40003a5
    752cd4000205:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400020c:	02 00 00 00 
    752cd4000210:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4000217:	01 00 00 00 
    752cd400021b:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4000222:	57 00 00 
    752cd4000225:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400022a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd400022f:	4c 89 c5             	mov    rbp,r8
    752cd4000232:	49 89 de             	mov    r14,rbx
    752cd4000235:	4c 89 cb             	mov    rbx,r9
    752cd4000238:	4d 89 d7             	mov    r15,r10
    752cd400023b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000240:	ff d0                	call   rax
    752cd4000242:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000247:	4d 89 fa             	mov    r10,r15
    752cd400024a:	49 89 d9             	mov    r9,rbx
    752cd400024d:	4c 89 f3             	mov    rbx,r14
    752cd4000250:	49 89 e8             	mov    r8,rbp
    752cd4000253:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000258:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400025f:	00 
    752cd4000260:	84 c9                	test   cl,cl
    752cd4000262:	0f 84 02 00 00 e8    	je     0x752cbc00026a
    752cd4000268:	e9 38 01 00 00       	jmp    0x752cd40003a5
    752cd400026d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000274:	02 00 00 00 
    752cd4000278:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400027f:	01 00 00 00 
    752cd4000283:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd400028a:	57 00 00 
    752cd400028d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000292:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000297:	4c 89 c5             	mov    rbp,r8
    752cd400029a:	49 89 de             	mov    r14,rbx
    752cd400029d:	4c 89 cb             	mov    rbx,r9
    752cd40002a0:	4d 89 d7             	mov    r15,r10
    752cd40002a3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40002a8:	ff d0                	call   rax
    752cd40002aa:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40002af:	4d 89 fa             	mov    r10,r15
    752cd40002b2:	49 89 d9             	mov    r9,rbx
    752cd40002b5:	4c 89 f3             	mov    rbx,r14
    752cd40002b8:	49 89 e8             	mov    r8,rbp
    752cd40002bb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40002c0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40002c7:	00 
    752cd40002c8:	84 c9                	test   cl,cl
    752cd40002ca:	0f 84 ca ff ff e7    	je     0x752cbc00029a
    752cd40002d0:	e9 d0 00 00 00       	jmp    0x752cd40003a5
    752cd40002d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40002dc:	02 00 00 00 
    752cd40002e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40002e7:	01 00 00 00 
    752cd40002eb:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40002f2:	57 00 00 
    752cd40002f5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40002fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40002ff:	4c 89 c5             	mov    rbp,r8
    752cd4000302:	49 89 de             	mov    r14,rbx
    752cd4000305:	4c 89 cb             	mov    rbx,r9
    752cd4000308:	4d 89 d7             	mov    r15,r10
    752cd400030b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000310:	ff d0                	call   rax
    752cd4000312:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000317:	4d 89 fa             	mov    r10,r15
    752cd400031a:	49 89 d9             	mov    r9,rbx
    752cd400031d:	4c 89 f3             	mov    rbx,r14
    752cd4000320:	49 89 e8             	mov    r8,rbp
    752cd4000323:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    752cd4000328:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400032d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000334:	00 
    752cd4000335:	84 c9                	test   cl,cl
    752cd4000337:	0f 84 8c ff ff e7    	je     0x752cbc0002c9
    752cd400033d:	eb 66                	jmp    0x752cd40003a5
    752cd400033f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    752cd4000346:	16 00 01 00 
    752cd400034a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000351:	02 00 00 00 
    752cd4000355:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400035c:	01 00 00 00 
    752cd4000360:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4000367:	57 00 00 
    752cd400036a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400036f:	4c 89 ef             	mov    rdi,r13
    752cd4000372:	4c 89 c5             	mov    rbp,r8
    752cd4000375:	4c 89 cb             	mov    rbx,r9
    752cd4000378:	4d 89 d7             	mov    r15,r10
    752cd400037b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000380:	ff d0                	call   rax
    752cd4000382:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000387:	4d 89 fa             	mov    r10,r15
    752cd400038a:	49 89 d9             	mov    r9,rbx
    752cd400038d:	49 89 e8             	mov    r8,rbp
    752cd4000390:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000395:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400039c:	00 
    752cd400039d:	84 c9                	test   cl,cl
    752cd400039f:	0f 84 34 ff ff e7    	je     0x752cbc0002d9
    752cd40003a5:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd40003ac:	e9 a8 fc ff ff       	jmp    0x752cd4000059
    752cd40003b1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    752cd40003b8:	1a 00 01 00 
    752cd40003bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40003c3:	04 00 00 00 
    752cd40003c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40003ce:	03 00 00 00 
    752cd40003d2:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40003d9:	57 00 00 
    752cd40003dc:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40003e1:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40003e6:	4c 89 c5             	mov    rbp,r8
    752cd40003e9:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd40003ee:	4d 89 d7             	mov    r15,r10
    752cd40003f1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40003f6:	ff d0                	call   rax
    752cd40003f8:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40003fd:	4d 89 fa             	mov    r10,r15
    752cd4000400:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4000405:	49 89 e8             	mov    r8,rbp
    752cd4000408:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400040d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000414:	00 
    752cd4000415:	84 c9                	test   cl,cl
    752cd4000417:	0f 84 fc fe ff e7    	je     0x752cbc000319
    752cd400041d:	e9 e7 00 00 00       	jmp    0x752cd4000509
    752cd4000422:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    752cd4000429:	1a 00 01 00 
    752cd400042d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4000434:	04 00 00 00 
    752cd4000438:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd400043f:	03 00 00 00 
    752cd4000443:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd400044a:	57 00 00 
    752cd400044d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000452:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000457:	89 ee                	mov    esi,ebp
    752cd4000459:	89 da                	mov    edx,ebx
    752cd400045b:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    752cd4000460:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4000465:	4c 89 d3             	mov    rbx,r10
    752cd4000468:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd400046d:	ff d0                	call   rax
    752cd400046f:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000474:	49 89 da             	mov    r10,rbx
    752cd4000477:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd400047c:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd4000481:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000486:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400048d:	00 
    752cd400048e:	84 c9                	test   cl,cl
    752cd4000490:	0f 84 a6 fe ff e7    	je     0x752cbc00033c
    752cd4000496:	eb 71                	jmp    0x752cd4000509
    752cd4000498:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    752cd400049f:	1e 00 01 00 
    752cd40004a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40004aa:	04 00 00 00 
    752cd40004ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40004b5:	03 00 00 00 
    752cd40004b9:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd40004c0:	57 00 00 
    752cd40004c3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40004c8:	4c 89 ef             	mov    rdi,r13
    752cd40004cb:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    752cd40004d0:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd40004d5:	4c 89 d3             	mov    rbx,r10
    752cd40004d8:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40004dd:	ff d0                	call   rax
    752cd40004df:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40004e4:	49 89 da             	mov    r10,rbx
    752cd40004e7:	4c 89 f3             	mov    rbx,r14
    752cd40004ea:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd40004ef:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd40004f4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40004f9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000500:	00 
    752cd4000501:	84 c9                	test   cl,cl
    752cd4000503:	0f 84 4c fe ff e7    	je     0x752cbc000355
    752cd4000509:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000510:	41 bc 04 00 00 00    	mov    r12d,0x4
    752cd4000516:	bd 03 00 00 00       	mov    ebp,0x3
    752cd400051b:	e9 37 00 00 e8       	jmp    0x752cbc000557
    752cd4000520:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000525:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd400052a:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd400052f:	4c 89 c3             	mov    rbx,r8
    752cd4000532:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000537:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    752cd400053e:	26 00 01 00 
    752cd4000542:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000549:	02 00 00 00 
    752cd400054d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    752cd4000554:	06 00 00 00 
    752cd4000558:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400055f:	57 00 00 
    752cd4000562:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000567:	be 00 f0 00 00       	mov    esi,0xf000
    752cd400056c:	ff d0                	call   rax
    752cd400056e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000575:	00 
    752cd4000576:	84 c9                	test   cl,cl
    752cd4000578:	0f 85 09 06 00 00    	jne    0x752cd4000b87
    752cd400057e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000583:	49 89 d8             	mov    r8,rbx
    752cd4000586:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd400058b:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000590:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000595:	4c 89 f3             	mov    rbx,r14
    752cd4000598:	e9 d7 fd ff e7       	jmp    0x752cbc000374
    752cd400059d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    752cd40005a4:	40 00 01 00 
    752cd40005a8:	b1 01                	mov    cl,0x1
    752cd40005aa:	bd 09 00 00 00       	mov    ebp,0x9
    752cd40005af:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cd40005b5:	e9 43 00 00 e8       	jmp    0x752cbc0005fd
    752cd40005ba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    752cd40005c1:	34 00 01 00 
    752cd40005c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40005cc:	02 00 00 00 
    752cd40005d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd40005d7:	0c 00 00 00 
    752cd40005db:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40005e2:	57 00 00 
    752cd40005e5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40005ea:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40005ef:	be 10 f0 00 00       	mov    esi,0xf010
    752cd40005f4:	ba 03 00 00 00       	mov    edx,0x3
    752cd40005f9:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    752cd40005fe:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4000603:	4c 89 d3             	mov    rbx,r10
    752cd4000606:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd400060b:	ff d0                	call   rax
    752cd400060d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000612:	49 89 da             	mov    r10,rbx
    752cd4000615:	4c 89 f3             	mov    rbx,r14
    752cd4000618:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd400061d:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd4000622:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000627:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400062e:	00 
    752cd400062f:	84 c9                	test   cl,cl
    752cd4000631:	0f 84 b6 fd ff e7    	je     0x752cbc0003ed
    752cd4000637:	eb 6a                	jmp    0x752cd40006a3
    752cd4000639:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    752cd4000640:	36 00 01 00 
    752cd4000644:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400064b:	02 00 00 00 
    752cd400064f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    752cd4000656:	0c 00 00 00 
    752cd400065a:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4000661:	57 00 00 
    752cd4000664:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000669:	4c 89 ef             	mov    rdi,r13
    752cd400066c:	4d 89 c6             	mov    r14,r8
    752cd400066f:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4000674:	4c 89 d3             	mov    rbx,r10
    752cd4000677:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd400067c:	ff d0                	call   rax
    752cd400067e:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000683:	49 89 da             	mov    r10,rbx
    752cd4000686:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd400068b:	4d 89 f0             	mov    r8,r14
    752cd400068e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000693:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400069a:	00 
    752cd400069b:	84 c9                	test   cl,cl
    752cd400069d:	0f 84 53 fd ff e7    	je     0x752cbc0003f6
    752cd40006a3:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd40006aa:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cd40006b0:	bd 0c 00 00 00       	mov    ebp,0xc
    752cd40006b5:	e9 9d fe ff e7       	jmp    0x752cbc000557
    752cd40006ba:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40006bf:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd40006c4:	4d 89 cf             	mov    r15,r9
    752cd40006c7:	4c 89 c3             	mov    rbx,r8
    752cd40006ca:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40006cf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    752cd40006d6:	38 00 01 00 
    752cd40006da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd40006e1:	04 00 00 00 
    752cd40006e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd40006ec:	0e 00 00 00 
    752cd40006f0:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40006f7:	57 00 00 
    752cd40006fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40006ff:	89 ee                	mov    esi,ebp
    752cd4000701:	ff d0                	call   rax
    752cd4000703:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400070a:	00 
    752cd400070b:	84 c9                	test   cl,cl
    752cd400070d:	0f 85 60 04 00 00    	jne    0x752cd4000b73
    752cd4000713:	89 c5                	mov    ebp,eax
    752cd4000715:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400071a:	49 89 d8             	mov    r8,rbx
    752cd400071d:	4d 89 f9             	mov    r9,r15
    752cd4000720:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd4000725:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd400072a:	e9 e5 fc ff e7       	jmp    0x752cbc000414
    752cd400072f:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000734:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    752cd4000739:	4d 89 cf             	mov    r15,r9
    752cd400073c:	4c 89 c3             	mov    rbx,r8
    752cd400073f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000744:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    752cd400074b:	38 00 01 00 
    752cd400074f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4000756:	04 00 00 00 
    752cd400075a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    752cd4000761:	0e 00 00 00 
    752cd4000765:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400076c:	57 00 00 
    752cd400076f:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000774:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    752cd4000779:	ff d0                	call   rax
    752cd400077b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000782:	00 
    752cd4000783:	84 c9                	test   cl,cl
    752cd4000785:	0f 85 e8 03 00 00    	jne    0x752cd4000b73
    752cd400078b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000790:	49 89 d8             	mov    r8,rbx
    752cd4000793:	4d 89 f9             	mov    r9,r15
    752cd4000796:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    752cd400079b:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40007a0:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cd40007a5:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    752cd40007aa:	48 89 c3             	mov    rbx,rax
    752cd40007ad:	e9 8c fc ff e7       	jmp    0x752cbc00043e
    752cd40007b2:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd40007b7:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40007bc:	4d 89 d7             	mov    r15,r10
    752cd40007bf:	48 89 d6             	mov    rsi,rdx
    752cd40007c2:	4c 89 cd             	mov    rbp,r9
    752cd40007c5:	4c 89 c3             	mov    rbx,r8
    752cd40007c8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40007cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd40007d4:	3c 00 01 00 
    752cd40007d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40007df:	02 00 00 00 
    752cd40007e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd40007ea:	0f 00 00 00 
    752cd40007ee:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40007f5:	57 00 00 
    752cd40007f8:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd40007fd:	ff d0                	call   rax
    752cd40007ff:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000806:	00 
    752cd4000807:	84 c9                	test   cl,cl
    752cd4000809:	0f 85 48 03 00 00    	jne    0x752cd4000b57
    752cd400080f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000814:	49 89 d8             	mov    r8,rbx
    752cd4000817:	49 89 e9             	mov    r9,rbp
    752cd400081a:	4d 89 fa             	mov    r10,r15
    752cd400081d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000822:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cd4000827:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    752cd400082c:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd4000831:	e9 37 fc ff e7       	jmp    0x752cbc00046d
    752cd4000836:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd400083b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd4000840:	4d 89 d7             	mov    r15,r10
    752cd4000843:	4c 89 cd             	mov    rbp,r9
    752cd4000846:	4c 89 c3             	mov    rbx,r8
    752cd4000849:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400084e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd4000855:	3c 00 01 00 
    752cd4000859:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000860:	02 00 00 00 
    752cd4000864:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd400086b:	0f 00 00 00 
    752cd400086f:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000876:	57 00 00 
    752cd4000879:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd400087e:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    752cd4000883:	ff d0                	call   rax
    752cd4000885:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400088c:	00 
    752cd400088d:	84 c9                	test   cl,cl
    752cd400088f:	0f 85 c2 02 00 00    	jne    0x752cd4000b57
    752cd4000895:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400089a:	49 89 d8             	mov    r8,rbx
    752cd400089d:	49 89 e9             	mov    r9,rbp
    752cd40008a0:	4d 89 fa             	mov    r10,r15
    752cd40008a3:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40008a8:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cd40008ad:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    752cd40008b2:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd40008b7:	e9 d5 fb ff e7       	jmp    0x752cbc000491
    752cd40008bc:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd40008c1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40008c6:	4d 89 d7             	mov    r15,r10
    752cd40008c9:	4c 89 cd             	mov    rbp,r9
    752cd40008cc:	4c 89 c3             	mov    rbx,r8
    752cd40008cf:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40008d4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd40008db:	3c 00 01 00 
    752cd40008df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40008e6:	02 00 00 00 
    752cd40008ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd40008f1:	0f 00 00 00 
    752cd40008f5:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd40008fc:	57 00 00 
    752cd40008ff:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000904:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    752cd4000909:	ff d0                	call   rax
    752cd400090b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000912:	00 
    752cd4000913:	84 c9                	test   cl,cl
    752cd4000915:	0f 85 3c 02 00 00    	jne    0x752cd4000b57
    752cd400091b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000920:	49 89 d8             	mov    r8,rbx
    752cd4000923:	49 89 e9             	mov    r9,rbp
    752cd4000926:	4d 89 fa             	mov    r10,r15
    752cd4000929:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd400092e:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cd4000933:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    752cd4000938:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd400093d:	e9 73 fb ff e7       	jmp    0x752cbc0004b5
    752cd4000942:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd4000947:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd400094c:	4d 89 d7             	mov    r15,r10
    752cd400094f:	4c 89 cd             	mov    rbp,r9
    752cd4000952:	4c 89 c3             	mov    rbx,r8
    752cd4000955:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400095a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd4000961:	3c 00 01 00 
    752cd4000965:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400096c:	02 00 00 00 
    752cd4000970:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd4000977:	0f 00 00 00 
    752cd400097b:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000982:	57 00 00 
    752cd4000985:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd400098a:	89 ce                	mov    esi,ecx
    752cd400098c:	ff d0                	call   rax
    752cd400098e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000995:	00 
    752cd4000996:	84 c9                	test   cl,cl
    752cd4000998:	0f 85 b9 01 00 00    	jne    0x752cd4000b57
    752cd400099e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40009a3:	49 89 d8             	mov    r8,rbx
    752cd40009a6:	49 89 e9             	mov    r9,rbp
    752cd40009a9:	4d 89 fa             	mov    r10,r15
    752cd40009ac:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd40009b1:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cd40009b6:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd40009bb:	e9 17 fb ff e7       	jmp    0x752cbc0004d7
    752cd40009c0:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd40009c5:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    752cd40009ca:	4d 89 d7             	mov    r15,r10
    752cd40009cd:	4c 89 cd             	mov    rbp,r9
    752cd40009d0:	4c 89 c3             	mov    rbx,r8
    752cd40009d3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40009d8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd40009df:	3c 00 01 00 
    752cd40009e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40009ea:	02 00 00 00 
    752cd40009ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd40009f5:	0f 00 00 00 
    752cd40009f9:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000a00:	57 00 00 
    752cd4000a03:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000a08:	ff d0                	call   rax
    752cd4000a0a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000a11:	00 
    752cd4000a12:	84 c9                	test   cl,cl
    752cd4000a14:	0f 85 3d 01 00 00    	jne    0x752cd4000b57
    752cd4000a1a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000a1f:	49 89 d8             	mov    r8,rbx
    752cd4000a22:	49 89 e9             	mov    r9,rbp
    752cd4000a25:	4d 89 fa             	mov    r10,r15
    752cd4000a28:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    752cd4000a2d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd4000a32:	e9 c2 fa ff e7       	jmp    0x752cbc0004f9
    752cd4000a37:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    752cd4000a3c:	4d 89 d7             	mov    r15,r10
    752cd4000a3f:	4c 89 cd             	mov    rbp,r9
    752cd4000a42:	4c 89 c3             	mov    rbx,r8
    752cd4000a45:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000a4a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd4000a51:	3c 00 01 00 
    752cd4000a55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000a5c:	02 00 00 00 
    752cd4000a60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd4000a67:	0f 00 00 00 
    752cd4000a6b:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000a72:	57 00 00 
    752cd4000a75:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000a7a:	44 89 de             	mov    esi,r11d
    752cd4000a7d:	ff d0                	call   rax
    752cd4000a7f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000a86:	00 
    752cd4000a87:	84 c9                	test   cl,cl
    752cd4000a89:	0f 85 c8 00 00 00    	jne    0x752cd4000b57
    752cd4000a8f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000a94:	49 89 d8             	mov    r8,rbx
    752cd4000a97:	49 89 e9             	mov    r9,rbp
    752cd4000a9a:	4d 89 fa             	mov    r10,r15
    752cd4000a9d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    752cd4000aa2:	e9 76 fa ff e7       	jmp    0x752cbc00051d
    752cd4000aa7:	48 89 dd             	mov    rbp,rbx
    752cd4000aaa:	4c 89 c3             	mov    rbx,r8
    752cd4000aad:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4000ab2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    752cd4000ab9:	3c 00 01 00 
    752cd4000abd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000ac4:	02 00 00 00 
    752cd4000ac8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    752cd4000acf:	0f 00 00 00 
    752cd4000ad3:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4000ada:	57 00 00 
    752cd4000add:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    752cd4000ae2:	44 89 ce             	mov    esi,r9d
    752cd4000ae5:	ff d0                	call   rax
    752cd4000ae7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000aee:	00 
    752cd4000aef:	84 c9                	test   cl,cl
    752cd4000af1:	75 64                	jne    0x752cd4000b57
    752cd4000af3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000af8:	49 89 d8             	mov    r8,rbx
    752cd4000afb:	48 89 eb             	mov    rbx,rbp
    752cd4000afe:	e9 36 fa ff e7       	jmp    0x752cbc000539
    752cd4000b03:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    752cd4000b0a:	3e 00 01 00 
    752cd4000b0e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4000b15:	02 00 00 00 
    752cd4000b19:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    752cd4000b20:	10 00 00 00 
    752cd4000b24:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd4000b2b:	57 00 00 
    752cd4000b2e:	49 89 ff             	mov    r15,rdi
    752cd4000b31:	4c 89 ef             	mov    rdi,r13
    752cd4000b34:	be 2a 00 00 00       	mov    esi,0x2a
    752cd4000b39:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    752cd4000b3e:	ff d0                	call   rax
    752cd4000b40:	4c 89 ff             	mov    rdi,r15
    752cd4000b43:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000b4a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4000b51:	00 
    752cd4000b52:	e9 00 fa ff e7       	jmp    0x752cbc000557
    752cd4000b57:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000b5e:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cd4000b64:	bd 0f 00 00 00       	mov    ebp,0xf
    752cd4000b69:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4000b6e:	e9 e4 f9 ff e7       	jmp    0x752cbc000557
    752cd4000b73:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000b7a:	41 bc 04 00 00 00    	mov    r12d,0x4
    752cd4000b80:	bd 0e 00 00 00       	mov    ebp,0xe
    752cd4000b85:	eb e2                	jmp    0x752cd4000b69
    752cd4000b87:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    752cd4000b8e:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cd4000b94:	bd 06 00 00 00       	mov    ebp,0x6
    752cd4000b99:	eb ce                	jmp    0x752cd4000b69
