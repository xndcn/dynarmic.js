
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65772-0-128835395792440.bin:     file format binary


Disassembly of section .data:

0000752cd4002e38 <.data>:
    752cd4002e38:	41 c6 80 65 01 00 00 	mov    BYTE PTR [r8+0x165],0x1
    752cd4002e3f:	01 
    752cd4002e40:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    752cd4002e47:	00 
    752cd4002e48:	48 83 c4 58          	add    rsp,0x58
    752cd4002e4c:	c2 08 00             	ret    0x8
