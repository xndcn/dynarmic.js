
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65542-0-128834993138800.bin:     file format binary


Disassembly of section .data:

0000752cbc002c70 <.data>:
    752cbc002c70:	50                   	push   rax
    752cbc002c71:	b8 ef ff fe ff       	mov    eax,0xfffeffef
    752cbc002c76:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    752cbc002c7d:	01 c1                	add    ecx,eax
    752cbc002c7f:	83 f9 f4             	cmp    ecx,0xfffffff4
    752cbc002c82:	0f 87 3c 0c 00 18    	ja     0x752cd40038c4
    752cbc002c88:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    752cbc002c8f:	83 f8 f4             	cmp    eax,0xfffffff4
    752cbc002c92:	0f 87 2c 0c 00 18    	ja     0x752cd40038c4
    752cbc002c98:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    752cbc002c9f:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    752cbc002ca6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    752cbc002cad:	41 c7 45 20 04 00 00 	mov    DWORD PTR [r13+0x20],0x1000004
    752cbc002cb4:	01 
    752cbc002cb5:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    752cbc002cb9:	48 8b 80 00 80 00 00 	mov    rax,QWORD PTR [rax+0x8000]
    752cbc002cc0:	48 85 c0             	test   rax,rax
    752cbc002cc3:	0f 84 07 0c 00 18    	je     0x752cd40038d0
    752cbc002cc9:	89 50 04             	mov    DWORD PTR [rax+0x4],edx
    752cbc002ccc:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    752cbc002cd0:	0f 85 3f 0c 00 18    	jne    0x752cd4003915
    752cbc002cd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    752cbc002cdd:	10 00 01 00 
    752cbc002ce1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc002ce8:	83 c0 04             	add    eax,0x4
    752cbc002ceb:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc002cf2:	39 c8                	cmp    eax,ecx
    752cbc002cf4:	73 28                	jae    0x752cbc002d1e
    752cbc002cf6:	81 bb 80 00 08 00 10 	cmp    DWORD PTR [rbx+0x80080],0x10010
    752cbc002cfd:	00 01 00 
    752cbc002d00:	75 1c                	jne    0x752cbc002d1e
    752cbc002d02:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    752cbc002d09:	10 00 01 00 
    752cbc002d0d:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc002d14:	48 8b 83 88 00 08 00 	mov    rax,QWORD PTR [rbx+0x80088]
    752cbc002d1b:	59                   	pop    rcx
    752cbc002d1c:	ff e0                	jmp    rax
    752cbc002d1e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    752cbc002d25:	10 00 01 00 
    752cbc002d29:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cbc002d30:	02 00 00 00 
    752cbc002d34:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    752cbc002d3b:	04 00 00 00 
    752cbc002d3f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    752cbc002d46:	01 
    752cbc002d47:	58                   	pop    rax
    752cbc002d48:	c2 08 00             	ret    0x8
