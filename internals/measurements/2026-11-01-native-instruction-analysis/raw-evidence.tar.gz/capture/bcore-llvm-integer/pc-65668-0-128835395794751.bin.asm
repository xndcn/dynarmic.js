
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65668-0-128835395794751.bin:     file format binary


Disassembly of section .data:

0000752cd400373f <.data>:
    752cd400373f:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    752cd4003746:	01 
    752cd4003747:	48 83 c4 18          	add    rsp,0x18
    752cd400374b:	c2 08 00             	ret    0x8
    752cd400374e:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    752cd4003753:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    752cd400375a:	08 00 00 00 
    752cd400375e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4003765:	01 00 00 00 
    752cd4003769:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd4003770:	57 00 00 
    752cd4003773:	4c 89 ef             	mov    rdi,r13
    752cd4003776:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd400377b:	4c 89 f6             	mov    rsi,r14
    752cd400377e:	ba 84 00 01 00       	mov    edx,0x10084
    752cd4003783:	45 31 c0             	xor    r8d,r8d
    752cd4003786:	ff d0                	call   rax
    752cd4003788:	b9 08 00 00 00       	mov    ecx,0x8
    752cd400378d:	b8 01 00 00 00       	mov    eax,0x1
    752cd4003792:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    752cd4003799:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    752cd40037a0:	01 c2                	add    edx,eax
    752cd40037a2:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    752cd40037a9:	39 fa                	cmp    edx,edi
    752cd40037ab:	0f 83 e3 00 00 00    	jae    0x752cd4003894
    752cd40037b1:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    752cd40037b8:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    752cd40037be:	48 8b 6c 24 08       	mov    rbp,QWORD PTR [rsp+0x8]
    752cd40037c3:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    752cd40037c7:	0f 85 c7 00 00 00    	jne    0x752cd4003894
    752cd40037cd:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    752cd40037d4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cd40037db:	00 
    752cd40037dc:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    752cd40037e1:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    752cd40037e6:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd40037eb:	48 83 c4 18          	add    rsp,0x18
    752cd40037ef:	ff e0                	jmp    rax
    752cd40037f1:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    752cd40037f6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    752cd40037fd:	08 00 00 00 
    752cd4003801:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4003808:	01 00 00 00 
    752cd400380c:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4003813:	57 00 00 
    752cd4003816:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd400381b:	4c 89 f7             	mov    rdi,r14
    752cd400381e:	89 ce                	mov    esi,ecx
    752cd4003820:	ff d0                	call   rax
    752cd4003822:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4003829:	00 
    752cd400382a:	0f 85 58 ff ff ff    	jne    0x752cd4003788
    752cd4003830:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd4003835:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    752cd400383a:	e9 09 f3 ff e7       	jmp    0x752cbc002b48
    752cd400383f:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    752cd4003844:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    752cd400384b:	8c 00 01 00 
    752cd400384f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003856:	02 00 00 00 
    752cd400385a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4003861:	02 00 00 00 
    752cd4003865:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd400386c:	57 00 00 
    752cd400386f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cd4003874:	4c 89 f7             	mov    rdi,r14
    752cd4003877:	89 de                	mov    esi,ebx
    752cd4003879:	ff d0                	call   rax
    752cd400387b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd4003882:	00 
    752cd4003883:	75 24                	jne    0x752cd40038a9
    752cd4003885:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cd400388a:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    752cd400388f:	e9 e8 f2 ff e7       	jmp    0x752cbc002b7c
    752cd4003894:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    752cd400389b:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    752cd40038a2:	48 83 c4 18          	add    rsp,0x18
    752cd40038a6:	c2 08 00             	ret    0x8
    752cd40038a9:	b8 02 00 00 00       	mov    eax,0x2
    752cd40038ae:	b9 02 00 00 00       	mov    ecx,0x2
    752cd40038b3:	e9 da fe ff ff       	jmp    0x752cd4003792
