
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66626-0-128834993132992.bin:     file format binary


Disassembly of section .data:

0000752cbc0015c0 <.data>:
    752cbc0015c0:	50                   	push   rax
    752cbc0015c1:	ba b1 fb fe ff       	mov    edx,0xfffefbb1
    752cbc0015c6:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc0015cd:	01 d6                	add    esi,edx
    752cbc0015cf:	b1 01                	mov    cl,0x1
    752cbc0015d1:	b8 65 01 00 00       	mov    eax,0x165
    752cbc0015d6:	83 fe f2             	cmp    esi,0xfffffff2
    752cbc0015d9:	0f 87 c5 00 00 00    	ja     0x752cbc0016a4
    752cbc0015df:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc0015e6:	83 fa f2             	cmp    edx,0xfffffff2
    752cbc0015e9:	0f 87 b5 00 00 00    	ja     0x752cbc0016a4
    752cbc0015ef:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    752cbc0015f6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    752cbc0015fd:	41 c7 45 24 9c 11 01 	mov    DWORD PTR [r13+0x24],0x1119c
    752cbc001604:	00 
    752cbc001605:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    752cbc001609:	8d 34 8d 9c 11 01 00 	lea    esi,[rcx*4+0x1119c]
    752cbc001610:	41 89 75 28          	mov    DWORD PTR [r13+0x28],esi
    752cbc001614:	89 f1                	mov    ecx,esi
    752cbc001616:	c1 e9 0c             	shr    ecx,0xc
    752cbc001619:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    752cbc00161d:	48 85 c0             	test   rax,rax
    752cbc001620:	0f 84 32 0f 00 18    	je     0x752cd4002558
    752cbc001626:	81 e6 fc 0f 00 00    	and    esi,0xffc
    752cbc00162c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc00162f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    752cbc001633:	b1 01                	mov    cl,0x1
    752cbc001635:	bd 05 00 00 00       	mov    ebp,0x5
    752cbc00163a:	a8 01                	test   al,0x1
    752cbc00163c:	0f 85 67 0f 00 18    	jne    0x752cd40025a9
    752cbc001642:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    752cbc001649:	01 ea                	add    edx,ebp
    752cbc00164b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    752cbc001652:	39 f2                	cmp    edx,esi
    752cbc001654:	73 30                	jae    0x752cbc001686
    752cbc001656:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    752cbc00165d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    752cbc001663:	39 04 33             	cmp    DWORD PTR [rbx+rsi*1],eax
    752cbc001666:	75 1e                	jne    0x752cbc001686
    752cbc001668:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    752cbc00166f:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    752cbc001676:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc00167d:	00 
    752cbc00167e:	48 8b 44 33 08       	mov    rax,QWORD PTR [rbx+rsi*1+0x8]
    752cbc001683:	59                   	pop    rcx
    752cbc001684:	ff e0                	jmp    rax
    752cbc001686:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    752cbc00168d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cbc001694:	02 00 00 00 
    752cbc001698:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc00169f:	b8 28 01 00 00       	mov    eax,0x128
    752cbc0016a4:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc0016a9:	58                   	pop    rax
    752cbc0016aa:	c2 08 00             	ret    0x8
