; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100ec(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %1 monotonic, align 4, !range !0
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  %shadow = alloca [464 x i8], align 8
  %3 = getelementptr i8, ptr %shadow, i64 0
  %4 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 %4, i64 16, i1 false)
  %5 = getelementptr i8, ptr %shadow, i64 24
  %6 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 1 %6, i64 8, i1 false)
  %7 = getelementptr i8, ptr %shadow, i64 160
  %8 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %7, ptr align 1 %8, i64 8, i1 false)
  %9 = getelementptr i8, ptr %shadow, i64 188
  %10 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %9, ptr align 1 %10, i64 4, i1 false)
  %11 = getelementptr i8, ptr %shadow, i64 228
  %12 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %11, ptr align 1 %12, i64 16, i1 false)
  %13 = getelementptr i8, ptr %shadow, i64 248
  %14 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %13, ptr align 1 %14, i64 12, i1 false)
  %15 = getelementptr i8, ptr %shadow, i64 276
  %16 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %15, ptr align 1 %16, i64 4, i1 false)
  %17 = getelementptr i8, ptr %shadow, i64 292
  %18 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %17, ptr align 1 %18, i64 4, i1 false)
  %19 = getelementptr i8, ptr %shadow, i64 308
  %20 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %19, ptr align 1 %20, i64 4, i1 false)
  %21 = getelementptr i8, ptr %shadow, i64 348
  %22 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %21, ptr align 1 %22, i64 4, i1 false)
  %23 = getelementptr i8, ptr %shadow, i64 296
  store i8 0, ptr %23, align 1
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %24 = getelementptr i8, ptr %shadow, i64 160
  %guard_lb = load i32, ptr %24, align 4
  %25 = icmp eq i32 %guard_lb, 0
  %26 = sub i32 %guard_lb, 65772
  %27 = icmp ugt i32 %26, 32
  %28 = or i1 %25, %27
  %29 = and i1 true, %28
  %30 = getelementptr i8, ptr %shadow, i64 164
  %guard_lb71 = load i32, ptr %30, align 4
  %31 = icmp eq i32 %guard_lb71, 0
  %32 = sub i32 %guard_lb71, 65772
  %33 = icmp ugt i32 %32, 32
  %34 = or i1 %31, %33
  %35 = and i1 %29, %34
  br i1 %35, label %insn_0x000100ec_entry, label %lb_guard_miss, !prof !1

insn_0x000100ec_entry:                            ; preds = %chain_self, %chain_go, %lb_guard
  %36 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %36, align 4
  %37 = getelementptr i8, ptr %shadow, i32 308
  store i32 1, ptr %37, align 4
  br label %insn_0x000100ec

insn_0x000100ec:                                  ; preds = %insn_0x000100ec_entry
  %38 = getelementptr i8, ptr %shadow, i32 4
  %a = load i32, ptr %38, align 4
  %39 = getelementptr i8, ptr %shadow, i32 24
  %b = load i32, ptr %39, align 4
  %mul = mul i32 %a, %b
  %40 = getelementptr i8, ptr %shadow, i32 4
  store i32 %mul, ptr %40, align 4
  %41 = getelementptr i8, ptr %shadow, i32 160
  %lb0 = load i32, ptr %41, align 4
  %42 = getelementptr i8, ptr %shadow, i32 164
  %lb1 = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %shadow, i32 188
  store i32 65774, ptr %43, align 4
  br label %insn_0x000100ee_entry

insn_0x000100ee_entry:                            ; preds = %insn_0x000100ec
  %44 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %shadow, i32 308
  store i32 2, ptr %45, align 4
  br label %insn_0x000100ee

insn_0x000100ee:                                  ; preds = %insn_0x000100ee_entry
  %46 = getelementptr i8, ptr %shadow, i32 28
  %rt = load i32, ptr %46, align 4
  %add32 = add i32 %mul, %rt
  %47 = getelementptr i8, ptr %shadow, i32 4
  store i32 %add32, ptr %47, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %48 = xor i32 %flgo, %flgn
  %49 = xor i32 %flgs, %flgn
  %50 = and i32 %49, %48
  %51 = xor i32 %mul, -1
  %52 = icmp ult i32 %51, %rt
  %ac0 = zext i1 %52 to i32
  %53 = icmp eq i32 %add32, 0
  %az = zext i1 %53 to i32
  %an = lshr i32 %add32, 31
  %54 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az, ptr %54, align 4
  %55 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an, ptr %55, align 4
  %56 = getelementptr i8, ptr %shadow, i32 256
  %vs_cur = load i32, ptr %56, align 4
  %57 = or i32 %vs_cur, %50
  %58 = getelementptr i8, ptr %shadow, i32 248
  store i32 %50, ptr %58, align 4
  %59 = getelementptr i8, ptr %shadow, i32 252
  store i32 %50, ptr %59, align 4
  %60 = getelementptr i8, ptr %shadow, i32 256
  store i32 %57, ptr %60, align 4
  %61 = getelementptr i8, ptr %shadow, i32 236
  store i32 %ac0, ptr %61, align 4
  %62 = getelementptr i8, ptr %shadow, i32 240
  store i32 %ac0, ptr %62, align 4
  %63 = getelementptr i8, ptr %shadow, i32 188
  store i32 65776, ptr %63, align 4
  br label %insn_0x000100f0_entry

insn_0x000100f0_entry:                            ; preds = %insn_0x000100ee
  %64 = getelementptr i8, ptr %shadow, i32 292
  store i32 4, ptr %64, align 4
  %65 = getelementptr i8, ptr %shadow, i32 308
  store i32 3, ptr %65, align 4
  br label %insn_0x000100f0

insn_0x000100f0:                                  ; preds = %insn_0x000100f0_entry
  %lsr32 = lshr i32 %add32, 13
  %66 = getelementptr i8, ptr %shadow, i32 12
  store i32 %lsr32, ptr %66, align 4
  %67 = icmp eq i32 %lsr32, 0
  %az1 = zext i1 %67 to i32
  %an2 = lshr i32 %lsr32, 31
  %68 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az1, ptr %68, align 4
  %69 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an2, ptr %69, align 4
  %70 = getelementptr i8, ptr %shadow, i32 248
  store i32 0, ptr %70, align 4
  %71 = getelementptr i8, ptr %shadow, i32 252
  store i32 0, ptr %71, align 4
  %72 = getelementptr i8, ptr %shadow, i32 188
  store i32 65780, ptr %72, align 4
  br label %insn_0x000100f4_entry

insn_0x000100f4_entry:                            ; preds = %insn_0x000100f0
  %73 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %73, align 4
  %74 = getelementptr i8, ptr %shadow, i32 308
  store i32 4, ptr %74, align 4
  br label %insn_0x000100f4

insn_0x000100f4:                                  ; preds = %insn_0x000100f4_entry
  %xor32 = xor i32 %add32, %lsr32
  %75 = getelementptr i8, ptr %shadow, i32 4
  store i32 %xor32, ptr %75, align 4
  %76 = icmp eq i32 %xor32, 0
  %az3 = zext i1 %76 to i32
  %an4 = lshr i32 %xor32, 31
  %77 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az3, ptr %77, align 4
  %78 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an4, ptr %78, align 4
  %79 = getelementptr i8, ptr %shadow, i32 236
  store i32 0, ptr %79, align 4
  %80 = getelementptr i8, ptr %shadow, i32 240
  store i32 0, ptr %80, align 4
  %81 = getelementptr i8, ptr %shadow, i32 248
  store i32 0, ptr %81, align 4
  %82 = getelementptr i8, ptr %shadow, i32 252
  store i32 0, ptr %82, align 4
  %83 = getelementptr i8, ptr %shadow, i32 188
  store i32 65782, ptr %83, align 4
  br label %insn_0x000100f6_entry

insn_0x000100f6_entry:                            ; preds = %insn_0x000100f4
  %84 = getelementptr i8, ptr %shadow, i32 292
  store i32 4, ptr %84, align 4
  %85 = getelementptr i8, ptr %shadow, i32 308
  store i32 5, ptr %85, align 4
  br label %insn_0x000100f6

insn_0x000100f6:                                  ; preds = %insn_0x000100f6_entry
  %lsl32 = shl i32 %xor32, 7
  %86 = getelementptr i8, ptr %shadow, i32 12
  store i32 %lsl32, ptr %86, align 4
  %87 = icmp eq i32 %lsl32, 0
  %az5 = zext i1 %87 to i32
  %an6 = lshr i32 %lsl32, 31
  %88 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az5, ptr %88, align 4
  %89 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an6, ptr %89, align 4
  %90 = getelementptr i8, ptr %shadow, i32 248
  store i32 0, ptr %90, align 4
  %91 = getelementptr i8, ptr %shadow, i32 252
  store i32 0, ptr %91, align 4
  %92 = getelementptr i8, ptr %shadow, i32 188
  store i32 65786, ptr %92, align 4
  br label %insn_0x000100fa_entry

insn_0x000100fa_entry:                            ; preds = %insn_0x000100f6
  %93 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %93, align 4
  %94 = getelementptr i8, ptr %shadow, i32 308
  store i32 6, ptr %94, align 4
  br label %insn_0x000100fa

insn_0x000100fa:                                  ; preds = %insn_0x000100fa_entry
  %lsr = lshr i32 %xor32, 25
  %95 = getelementptr i8, ptr %shadow, i32 4
  store i32 %lsr, ptr %95, align 4
  %96 = icmp eq i32 %lsr, 0
  %az7 = zext i1 %96 to i32
  %an8 = lshr i32 %lsr, 31
  %97 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az7, ptr %97, align 4
  %98 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an8, ptr %98, align 4
  %99 = getelementptr i8, ptr %shadow, i32 248
  store i32 0, ptr %99, align 4
  %100 = getelementptr i8, ptr %shadow, i32 252
  store i32 0, ptr %100, align 4
  %101 = getelementptr i8, ptr %shadow, i32 188
  store i32 65788, ptr %101, align 4
  br label %insn_0x000100fc_entry

insn_0x000100fc_entry:                            ; preds = %insn_0x000100fa
  %102 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %102, align 4
  %103 = getelementptr i8, ptr %shadow, i32 308
  store i32 7, ptr %103, align 4
  br label %insn_0x000100fc

insn_0x000100fc:                                  ; preds = %insn_0x000100fc_entry
  %104 = getelementptr i8, ptr %shadow, i32 8
  %rd = load i32, ptr %104, align 4
  %rd_add = add i32 %rd, 1
  %105 = getelementptr i8, ptr %shadow, i32 8
  store i32 %rd_add, ptr %105, align 4
  %flgs9 = lshr i32 %rd, 31
  %flgn10 = lshr i32 %rd_add, 31
  %106 = xor i32 0, %flgn10
  %107 = xor i32 %flgs9, %flgn10
  %overflow = and i32 %107, %106
  %108 = xor i32 %rd, -1
  %109 = icmp ult i32 %108, 1
  %ac011 = zext i1 %109 to i32
  %110 = icmp eq i32 %rd_add, 0
  %az12 = zext i1 %110 to i32
  %an13 = lshr i32 %rd_add, 31
  %111 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az12, ptr %111, align 4
  %112 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an13, ptr %112, align 4
  %113 = or i32 %57, %overflow
  %114 = getelementptr i8, ptr %shadow, i32 248
  store i32 %overflow, ptr %114, align 4
  %115 = getelementptr i8, ptr %shadow, i32 252
  store i32 %overflow, ptr %115, align 4
  %116 = getelementptr i8, ptr %shadow, i32 256
  store i32 %113, ptr %116, align 4
  %117 = getelementptr i8, ptr %shadow, i32 236
  store i32 %ac011, ptr %117, align 4
  %118 = getelementptr i8, ptr %shadow, i32 240
  store i32 %ac011, ptr %118, align 4
  %119 = getelementptr i8, ptr %shadow, i32 188
  store i32 65790, ptr %119, align 4
  br label %insn_0x000100fe_entry

insn_0x000100fe_entry:                            ; preds = %insn_0x000100fc
  %120 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %120, align 4
  %121 = getelementptr i8, ptr %shadow, i32 308
  store i32 8, ptr %121, align 4
  br label %insn_0x000100fe

insn_0x000100fe:                                  ; preds = %insn_0x000100fe_entry
  %or32 = or i32 %lsl32, %lsr
  %122 = getelementptr i8, ptr %shadow, i32 4
  store i32 %or32, ptr %122, align 4
  %123 = icmp eq i32 %or32, 0
  %az14 = zext i1 %123 to i32
  %an15 = lshr i32 %or32, 31
  %124 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az14, ptr %124, align 4
  %125 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an15, ptr %125, align 4
  %126 = getelementptr i8, ptr %shadow, i32 236
  store i32 0, ptr %126, align 4
  %127 = getelementptr i8, ptr %shadow, i32 240
  store i32 0, ptr %127, align 4
  %128 = getelementptr i8, ptr %shadow, i32 248
  store i32 0, ptr %128, align 4
  %129 = getelementptr i8, ptr %shadow, i32 252
  store i32 0, ptr %129, align 4
  %130 = getelementptr i8, ptr %shadow, i32 188
  store i32 65792, ptr %130, align 4
  br label %insn_0x00010100_entry

insn_0x00010100_entry:                            ; preds = %insn_0x000100fe
  %131 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %131, align 4
  %132 = getelementptr i8, ptr %shadow, i32 308
  store i32 9, ptr %132, align 4
  br label %insn_0x00010100

insn_0x00010100:                                  ; preds = %insn_0x00010100_entry
  %133 = getelementptr i8, ptr %shadow, i32 0
  %rx = load i32, ptr %133, align 4
  %134 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %134 to i32
  %135 = getelementptr i8, ptr %shadow, i32 276
  store i32 %cc, ptr %135, align 4
  %136 = icmp eq i32 %rx, %rd_add
  %az16 = zext i1 %136 to i32
  %137 = icmp ugt i32 %rd_add, %rx
  %an17 = zext i1 %137 to i32
  %138 = icmp ule i32 %rd_add, %rx
  %ac018 = zext i1 %138 to i32
  %139 = getelementptr i8, ptr %shadow, i32 228
  store i32 %az16, ptr %139, align 4
  %140 = getelementptr i8, ptr %shadow, i32 232
  store i32 %an17, ptr %140, align 4
  %141 = getelementptr i8, ptr %shadow, i32 236
  store i32 %ac018, ptr %141, align 4
  %142 = getelementptr i8, ptr %shadow, i32 240
  store i32 %ac018, ptr %142, align 4
  %143 = getelementptr i8, ptr %shadow, i32 188
  store i32 65794, ptr %143, align 4
  br label %insn_0x00010102_entry

insn_0x00010102_entry:                            ; preds = %insn_0x00010100
  %144 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %144, align 4
  %145 = getelementptr i8, ptr %shadow, i32 308
  store i32 10, ptr %145, align 4
  br label %insn_0x00010102

insn_0x00010102:                                  ; preds = %insn_0x00010102_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010102
  %146 = getelementptr i8, ptr %shadow, i64 348
  %chain_packets = load i32, ptr %146, align 4
  %chain_total = add nuw i32 %chain_packets, 10
  %147 = icmp ult i32 %chain_total, %chain_budget
  br i1 %147, label %chain_budget_now, label %chain_leave72, !prof !1

brcc_fallthru:                                    ; preds = %insn_0x00010102
  %148 = getelementptr i8, ptr %shadow, i32 188
  store i32 65796, ptr %148, align 4
  br label %insn_0x00010104_entry

insn_0x00010104_entry:                            ; preds = %brcc_fallthru
  %149 = getelementptr i8, ptr %shadow, i32 292
  store i32 4, ptr %149, align 4
  %150 = getelementptr i8, ptr %shadow, i32 308
  store i32 11, ptr %150, align 4
  br label %insn_0x00010104

insn_0x00010104:                                  ; preds = %insn_0x00010104_entry
  %151 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %151, align 4
  %guest_aligned = call i1 @bcore.guest.aligned(i32 %fp, i32 4)
  %152 = xor i1 %guest_aligned, true
  br i1 %152, label %data_misaligned, label %data_aligned, !prof !2

data_misaligned:                                  ; preds = %insn_0x00010104
  %153 = getelementptr i8, ptr %shadow, i64 0
  %154 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %154, ptr align 1 %153, i64 16, i1 false)
  %155 = getelementptr i8, ptr %shadow, i64 24
  %156 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %156, ptr align 1 %155, i64 8, i1 false)
  %157 = getelementptr i8, ptr %shadow, i64 188
  %158 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %158, ptr align 1 %157, i64 4, i1 false)
  %159 = getelementptr i8, ptr %shadow, i64 228
  %160 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %160, ptr align 1 %159, i64 16, i1 false)
  %161 = getelementptr i8, ptr %shadow, i64 248
  %162 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %162, ptr align 1 %161, i64 12, i1 false)
  %163 = getelementptr i8, ptr %shadow, i64 276
  %164 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %164, ptr align 1 %163, i64 4, i1 false)
  %165 = getelementptr i8, ptr %shadow, i64 292
  %166 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %166, ptr align 1 %165, i64 5, i1 false)
  %167 = getelementptr i8, ptr %shadow, i64 308
  %168 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %168, ptr align 1 %167, i64 4, i1 false)
  %169 = getelementptr i8, ptr %shadow, i64 348
  %170 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr align 1 %169, i64 4, i1 false)
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %fp, i32 0)
  %171 = getelementptr i8, ptr %shadow, i64 0
  %172 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %171, ptr align 1 %172, i64 16, i1 false)
  %173 = getelementptr i8, ptr %shadow, i64 24
  %174 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %173, ptr align 1 %174, i64 8, i1 false)
  %175 = getelementptr i8, ptr %shadow, i64 160
  %176 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %175, ptr align 1 %176, i64 8, i1 false)
  %177 = getelementptr i8, ptr %shadow, i64 188
  %178 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %177, ptr align 1 %178, i64 4, i1 false)
  %179 = getelementptr i8, ptr %shadow, i64 228
  %180 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %179, ptr align 1 %180, i64 16, i1 false)
  %181 = getelementptr i8, ptr %shadow, i64 248
  %182 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %181, ptr align 1 %182, i64 12, i1 false)
  %183 = getelementptr i8, ptr %shadow, i64 276
  %184 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %183, ptr align 1 %184, i64 4, i1 false)
  %185 = getelementptr i8, ptr %shadow, i64 292
  %186 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %185, ptr align 1 %186, i64 5, i1 false)
  %187 = getelementptr i8, ptr %shadow, i64 308
  %188 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %187, ptr align 1 %188, i64 4, i1 false)
  %189 = getelementptr i8, ptr %shadow, i64 348
  %190 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %189, ptr align 1 %190, i64 4, i1 false)
  %191 = getelementptr i8, ptr %shadow, i64 188
  %next_pc = load i32, ptr %191, align 4
  %192 = getelementptr i8, ptr %shadow, i64 308
  %packets = load i32, ptr %192, align 4
  %193 = getelementptr i8, ptr %shadow, i64 188
  %194 = load i32, ptr %193, align 4
  %195 = getelementptr i8, ptr %shadow, i64 296
  %196 = load i8, ptr %195, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010104
  %guest_ptr = call ptr @bcore.guest.ptr(ptr %page_table, i32 %fp)
  %page_mapped = icmp ne ptr %guest_ptr, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !1

page_fast:                                        ; preds = %data_aligned
  %page_val = load i32, ptr %guest_ptr, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %197 = getelementptr i8, ptr %shadow, i64 0
  %198 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %198, ptr align 1 %197, i64 16, i1 false)
  %199 = getelementptr i8, ptr %shadow, i64 24
  %200 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %200, ptr align 1 %199, i64 8, i1 false)
  %201 = getelementptr i8, ptr %shadow, i64 188
  %202 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %202, ptr align 1 %201, i64 4, i1 false)
  %203 = getelementptr i8, ptr %shadow, i64 228
  %204 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %204, ptr align 1 %203, i64 16, i1 false)
  %205 = getelementptr i8, ptr %shadow, i64 248
  %206 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %206, ptr align 1 %205, i64 12, i1 false)
  %207 = getelementptr i8, ptr %shadow, i64 276
  %208 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %208, ptr align 1 %207, i64 4, i1 false)
  %209 = getelementptr i8, ptr %shadow, i64 292
  %210 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %210, ptr align 1 %209, i64 5, i1 false)
  %211 = getelementptr i8, ptr %shadow, i64 308
  %212 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %212, ptr align 1 %211, i64 4, i1 false)
  %213 = getelementptr i8, ptr %shadow, i64 348
  %214 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %214, ptr align 1 %213, i64 4, i1 false)
  %215 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %216 = getelementptr i8, ptr %cpu, i32 296
  %real_did_jump = load i8, ptr %216, align 1
  %217 = icmp ne i8 %real_did_jump, 0
  br i1 %217, label %loop_sync_raised, label %loop_sync_cont, !prof !2

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %215, %did_jump_cont ]
  %sp1 = add i32 %fp, 4
  %guest_aligned21 = call i1 @bcore.guest.aligned(i32 %sp1, i32 4)
  %218 = xor i1 %guest_aligned21, true
  br i1 %218, label %data_misaligned19, label %data_aligned20, !prof !2

loop_sync_raised:                                 ; preds = %page_slow
  %219 = getelementptr i8, ptr %shadow, i64 0
  %220 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %219, ptr align 1 %220, i64 16, i1 false)
  %221 = getelementptr i8, ptr %shadow, i64 24
  %222 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %221, ptr align 1 %222, i64 8, i1 false)
  %223 = getelementptr i8, ptr %shadow, i64 160
  %224 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %223, ptr align 1 %224, i64 8, i1 false)
  %225 = getelementptr i8, ptr %shadow, i64 188
  %226 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %225, ptr align 1 %226, i64 4, i1 false)
  %227 = getelementptr i8, ptr %shadow, i64 228
  %228 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %227, ptr align 1 %228, i64 16, i1 false)
  %229 = getelementptr i8, ptr %shadow, i64 248
  %230 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %229, ptr align 1 %230, i64 12, i1 false)
  %231 = getelementptr i8, ptr %shadow, i64 276
  %232 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %231, ptr align 1 %232, i64 4, i1 false)
  %233 = getelementptr i8, ptr %shadow, i64 292
  %234 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %233, ptr align 1 %234, i64 5, i1 false)
  %235 = getelementptr i8, ptr %shadow, i64 308
  %236 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %235, ptr align 1 %236, i64 4, i1 false)
  %237 = getelementptr i8, ptr %shadow, i64 348
  %238 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %237, ptr align 1 %238, i64 4, i1 false)
  %239 = getelementptr i8, ptr %shadow, i64 188
  %next_pc74 = load i32, ptr %239, align 4
  %240 = getelementptr i8, ptr %shadow, i64 308
  %packets75 = load i32, ptr %240, align 4
  %241 = getelementptr i8, ptr %shadow, i64 188
  %242 = load i32, ptr %241, align 4
  %243 = getelementptr i8, ptr %shadow, i64 296
  %244 = load i8, ptr %243, align 1
  br label %chain_exit

loop_sync_cont:                                   ; preds = %page_slow
  %245 = getelementptr i8, ptr %shadow, i32 296
  %dj = load i8, ptr %245, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !2

did_jump_exit:                                    ; preds = %loop_sync_cont
  %246 = getelementptr i8, ptr %shadow, i64 188
  %next_pc76 = load i32, ptr %246, align 4
  %247 = getelementptr i8, ptr %shadow, i64 308
  %packets77 = load i32, ptr %247, align 4
  %248 = getelementptr i8, ptr %shadow, i64 188
  %249 = load i32, ptr %248, align 4
  %250 = getelementptr i8, ptr %shadow, i64 296
  %251 = load i8, ptr %250, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %loop_sync_cont
  br label %page_done

data_misaligned19:                                ; preds = %page_done
  %252 = getelementptr i8, ptr %shadow, i64 0
  %253 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %253, ptr align 1 %252, i64 16, i1 false)
  %254 = getelementptr i8, ptr %shadow, i64 24
  %255 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %255, ptr align 1 %254, i64 8, i1 false)
  %256 = getelementptr i8, ptr %shadow, i64 188
  %257 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %257, ptr align 1 %256, i64 4, i1 false)
  %258 = getelementptr i8, ptr %shadow, i64 228
  %259 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %259, ptr align 1 %258, i64 16, i1 false)
  %260 = getelementptr i8, ptr %shadow, i64 248
  %261 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %261, ptr align 1 %260, i64 12, i1 false)
  %262 = getelementptr i8, ptr %shadow, i64 276
  %263 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %263, ptr align 1 %262, i64 4, i1 false)
  %264 = getelementptr i8, ptr %shadow, i64 292
  %265 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %265, ptr align 1 %264, i64 5, i1 false)
  %266 = getelementptr i8, ptr %shadow, i64 308
  %267 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %267, ptr align 1 %266, i64 4, i1 false)
  %268 = getelementptr i8, ptr %shadow, i64 348
  %269 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %269, ptr align 1 %268, i64 4, i1 false)
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp1, i32 0)
  %270 = getelementptr i8, ptr %shadow, i64 0
  %271 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %270, ptr align 1 %271, i64 16, i1 false)
  %272 = getelementptr i8, ptr %shadow, i64 24
  %273 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %272, ptr align 1 %273, i64 8, i1 false)
  %274 = getelementptr i8, ptr %shadow, i64 160
  %275 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %274, ptr align 1 %275, i64 8, i1 false)
  %276 = getelementptr i8, ptr %shadow, i64 188
  %277 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %276, ptr align 1 %277, i64 4, i1 false)
  %278 = getelementptr i8, ptr %shadow, i64 228
  %279 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %278, ptr align 1 %279, i64 16, i1 false)
  %280 = getelementptr i8, ptr %shadow, i64 248
  %281 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %280, ptr align 1 %281, i64 12, i1 false)
  %282 = getelementptr i8, ptr %shadow, i64 276
  %283 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %282, ptr align 1 %283, i64 4, i1 false)
  %284 = getelementptr i8, ptr %shadow, i64 292
  %285 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %284, ptr align 1 %285, i64 5, i1 false)
  %286 = getelementptr i8, ptr %shadow, i64 308
  %287 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %286, ptr align 1 %287, i64 4, i1 false)
  %288 = getelementptr i8, ptr %shadow, i64 348
  %289 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %288, ptr align 1 %289, i64 4, i1 false)
  %290 = getelementptr i8, ptr %shadow, i64 188
  %next_pc78 = load i32, ptr %290, align 4
  %291 = getelementptr i8, ptr %shadow, i64 308
  %packets79 = load i32, ptr %291, align 4
  %292 = getelementptr i8, ptr %shadow, i64 188
  %293 = load i32, ptr %292, align 4
  %294 = getelementptr i8, ptr %shadow, i64 296
  %295 = load i8, ptr %294, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_done
  %guest_ptr25 = call ptr @bcore.guest.ptr(ptr %page_table, i32 %sp1)
  %page_mapped26 = icmp ne ptr %guest_ptr25, null
  br i1 %page_mapped26, label %page_fast22, label %page_slow23, !prof !1

page_fast22:                                      ; preds = %data_aligned20
  %page_val27 = load i32, ptr %guest_ptr25, align 4
  br label %page_done24

page_slow23:                                      ; preds = %data_aligned20
  %296 = getelementptr i8, ptr %shadow, i64 0
  %297 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %297, ptr align 1 %296, i64 16, i1 false)
  %298 = getelementptr i8, ptr %shadow, i64 24
  %299 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %299, ptr align 1 %298, i64 8, i1 false)
  %300 = getelementptr i8, ptr %shadow, i64 188
  %301 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %301, ptr align 1 %300, i64 4, i1 false)
  %302 = getelementptr i8, ptr %shadow, i64 228
  %303 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %303, ptr align 1 %302, i64 16, i1 false)
  %304 = getelementptr i8, ptr %shadow, i64 248
  %305 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %305, ptr align 1 %304, i64 12, i1 false)
  %306 = getelementptr i8, ptr %shadow, i64 276
  %307 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %307, ptr align 1 %306, i64 4, i1 false)
  %308 = getelementptr i8, ptr %shadow, i64 292
  %309 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %309, ptr align 1 %308, i64 5, i1 false)
  %310 = getelementptr i8, ptr %shadow, i64 308
  %311 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %311, ptr align 1 %310, i64 4, i1 false)
  %312 = getelementptr i8, ptr %shadow, i64 348
  %313 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %313, ptr align 1 %312, i64 4, i1 false)
  %314 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %315 = getelementptr i8, ptr %cpu, i32 296
  %real_did_jump28 = load i8, ptr %315, align 1
  %316 = icmp ne i8 %real_did_jump28, 0
  br i1 %316, label %loop_sync_raised29, label %loop_sync_cont30, !prof !2

page_done24:                                      ; preds = %did_jump_cont32, %page_fast22
  %mem_val35 = phi i32 [ %page_val27, %page_fast22 ], [ %314, %did_jump_cont32 ]
  %sp2 = add i32 %sp1, 4
  %317 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %317, align 4
  %318 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val35, ptr %318, align 4
  %319 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %319, align 4
  %320 = getelementptr i8, ptr %shadow, i32 188
  store i32 65800, ptr %320, align 4
  br label %insn_0x00010108_entry

loop_sync_raised29:                               ; preds = %page_slow23
  %321 = getelementptr i8, ptr %shadow, i64 0
  %322 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %321, ptr align 1 %322, i64 16, i1 false)
  %323 = getelementptr i8, ptr %shadow, i64 24
  %324 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %323, ptr align 1 %324, i64 8, i1 false)
  %325 = getelementptr i8, ptr %shadow, i64 160
  %326 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %325, ptr align 1 %326, i64 8, i1 false)
  %327 = getelementptr i8, ptr %shadow, i64 188
  %328 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %327, ptr align 1 %328, i64 4, i1 false)
  %329 = getelementptr i8, ptr %shadow, i64 228
  %330 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %329, ptr align 1 %330, i64 16, i1 false)
  %331 = getelementptr i8, ptr %shadow, i64 248
  %332 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %331, ptr align 1 %332, i64 12, i1 false)
  %333 = getelementptr i8, ptr %shadow, i64 276
  %334 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %333, ptr align 1 %334, i64 4, i1 false)
  %335 = getelementptr i8, ptr %shadow, i64 292
  %336 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %335, ptr align 1 %336, i64 5, i1 false)
  %337 = getelementptr i8, ptr %shadow, i64 308
  %338 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %337, ptr align 1 %338, i64 4, i1 false)
  %339 = getelementptr i8, ptr %shadow, i64 348
  %340 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %339, ptr align 1 %340, i64 4, i1 false)
  %341 = getelementptr i8, ptr %shadow, i64 188
  %next_pc80 = load i32, ptr %341, align 4
  %342 = getelementptr i8, ptr %shadow, i64 308
  %packets81 = load i32, ptr %342, align 4
  %343 = getelementptr i8, ptr %shadow, i64 188
  %344 = load i32, ptr %343, align 4
  %345 = getelementptr i8, ptr %shadow, i64 296
  %346 = load i8, ptr %345, align 1
  br label %chain_exit

loop_sync_cont30:                                 ; preds = %page_slow23
  %347 = getelementptr i8, ptr %shadow, i32 296
  %dj33 = load i8, ptr %347, align 1
  %dj_set34 = icmp ne i8 %dj33, 0
  br i1 %dj_set34, label %did_jump_exit31, label %did_jump_cont32, !prof !2

did_jump_exit31:                                  ; preds = %loop_sync_cont30
  %348 = getelementptr i8, ptr %shadow, i64 188
  %next_pc82 = load i32, ptr %348, align 4
  %349 = getelementptr i8, ptr %shadow, i64 308
  %packets83 = load i32, ptr %349, align 4
  %350 = getelementptr i8, ptr %shadow, i64 188
  %351 = load i32, ptr %350, align 4
  %352 = getelementptr i8, ptr %shadow, i64 296
  %353 = load i8, ptr %352, align 1
  br label %chain_exit

did_jump_cont32:                                  ; preds = %loop_sync_cont30
  br label %page_done24

insn_0x00010108_entry:                            ; preds = %page_done24
  %354 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %354, align 4
  %355 = getelementptr i8, ptr %shadow, i32 308
  store i32 12, ptr %355, align 4
  br label %insn_0x00010108

insn_0x00010108:                                  ; preds = %insn_0x00010108_entry
  %356 = getelementptr i8, ptr %shadow, i32 0
  store i32 %or32, ptr %356, align 4
  %357 = getelementptr i8, ptr %shadow, i32 188
  store i32 65802, ptr %357, align 4
  br label %insn_0x0001010a_entry

insn_0x0001010a_entry:                            ; preds = %insn_0x00010108
  %358 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %358, align 4
  %359 = getelementptr i8, ptr %shadow, i32 308
  store i32 13, ptr %359, align 4
  br label %insn_0x0001010a

insn_0x0001010a:                                  ; preds = %insn_0x0001010a_entry
  %guest_aligned38 = call i1 @bcore.guest.aligned(i32 %sp2, i32 4)
  %360 = xor i1 %guest_aligned38, true
  br i1 %360, label %data_misaligned36, label %data_aligned37, !prof !2

data_misaligned36:                                ; preds = %insn_0x0001010a
  %361 = getelementptr i8, ptr %shadow, i64 0
  %362 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %362, ptr align 1 %361, i64 16, i1 false)
  %363 = getelementptr i8, ptr %shadow, i64 24
  %364 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %364, ptr align 1 %363, i64 8, i1 false)
  %365 = getelementptr i8, ptr %shadow, i64 188
  %366 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %366, ptr align 1 %365, i64 4, i1 false)
  %367 = getelementptr i8, ptr %shadow, i64 228
  %368 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %368, ptr align 1 %367, i64 16, i1 false)
  %369 = getelementptr i8, ptr %shadow, i64 248
  %370 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %370, ptr align 1 %369, i64 12, i1 false)
  %371 = getelementptr i8, ptr %shadow, i64 276
  %372 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %372, ptr align 1 %371, i64 4, i1 false)
  %373 = getelementptr i8, ptr %shadow, i64 292
  %374 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %374, ptr align 1 %373, i64 5, i1 false)
  %375 = getelementptr i8, ptr %shadow, i64 308
  %376 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %376, ptr align 1 %375, i64 4, i1 false)
  %377 = getelementptr i8, ptr %shadow, i64 348
  %378 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %378, ptr align 1 %377, i64 4, i1 false)
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp2, i32 0)
  %379 = getelementptr i8, ptr %shadow, i64 0
  %380 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %379, ptr align 1 %380, i64 16, i1 false)
  %381 = getelementptr i8, ptr %shadow, i64 24
  %382 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %381, ptr align 1 %382, i64 8, i1 false)
  %383 = getelementptr i8, ptr %shadow, i64 160
  %384 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %383, ptr align 1 %384, i64 8, i1 false)
  %385 = getelementptr i8, ptr %shadow, i64 188
  %386 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %385, ptr align 1 %386, i64 4, i1 false)
  %387 = getelementptr i8, ptr %shadow, i64 228
  %388 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %387, ptr align 1 %388, i64 16, i1 false)
  %389 = getelementptr i8, ptr %shadow, i64 248
  %390 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %389, ptr align 1 %390, i64 12, i1 false)
  %391 = getelementptr i8, ptr %shadow, i64 276
  %392 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %391, ptr align 1 %392, i64 4, i1 false)
  %393 = getelementptr i8, ptr %shadow, i64 292
  %394 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %393, ptr align 1 %394, i64 5, i1 false)
  %395 = getelementptr i8, ptr %shadow, i64 308
  %396 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %395, ptr align 1 %396, i64 4, i1 false)
  %397 = getelementptr i8, ptr %shadow, i64 348
  %398 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %397, ptr align 1 %398, i64 4, i1 false)
  %399 = getelementptr i8, ptr %shadow, i64 188
  %next_pc84 = load i32, ptr %399, align 4
  %400 = getelementptr i8, ptr %shadow, i64 308
  %packets85 = load i32, ptr %400, align 4
  %401 = getelementptr i8, ptr %shadow, i64 188
  %402 = load i32, ptr %401, align 4
  %403 = getelementptr i8, ptr %shadow, i64 296
  %404 = load i8, ptr %403, align 1
  br label %chain_exit

data_aligned37:                                   ; preds = %insn_0x0001010a
  %guest_ptr42 = call ptr @bcore.guest.ptr(ptr %page_table, i32 %sp2)
  %page_mapped43 = icmp ne ptr %guest_ptr42, null
  br i1 %page_mapped43, label %page_fast39, label %page_slow40, !prof !1

page_fast39:                                      ; preds = %data_aligned37
  %page_val44 = load i32, ptr %guest_ptr42, align 4
  br label %page_done41

page_slow40:                                      ; preds = %data_aligned37
  %405 = getelementptr i8, ptr %shadow, i64 0
  %406 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %406, ptr align 1 %405, i64 16, i1 false)
  %407 = getelementptr i8, ptr %shadow, i64 24
  %408 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %408, ptr align 1 %407, i64 8, i1 false)
  %409 = getelementptr i8, ptr %shadow, i64 188
  %410 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %410, ptr align 1 %409, i64 4, i1 false)
  %411 = getelementptr i8, ptr %shadow, i64 228
  %412 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %412, ptr align 1 %411, i64 16, i1 false)
  %413 = getelementptr i8, ptr %shadow, i64 248
  %414 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %414, ptr align 1 %413, i64 12, i1 false)
  %415 = getelementptr i8, ptr %shadow, i64 276
  %416 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %416, ptr align 1 %415, i64 4, i1 false)
  %417 = getelementptr i8, ptr %shadow, i64 292
  %418 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %418, ptr align 1 %417, i64 5, i1 false)
  %419 = getelementptr i8, ptr %shadow, i64 308
  %420 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %420, ptr align 1 %419, i64 4, i1 false)
  %421 = getelementptr i8, ptr %shadow, i64 348
  %422 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %422, ptr align 1 %421, i64 4, i1 false)
  %423 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %424 = getelementptr i8, ptr %cpu, i32 296
  %real_did_jump45 = load i8, ptr %424, align 1
  %425 = icmp ne i8 %real_did_jump45, 0
  br i1 %425, label %loop_sync_raised46, label %loop_sync_cont47, !prof !2

page_done41:                                      ; preds = %did_jump_cont49, %page_fast39
  %mem_val52 = phi i32 [ %page_val44, %page_fast39 ], [ %423, %did_jump_cont49 ]
  %426 = getelementptr i8, ptr %shadow, i32 28
  store i32 %mem_val52, ptr %426, align 4
  %sp_inc = add i32 %sp2, 4
  %guest_aligned55 = call i1 @bcore.guest.aligned(i32 %sp_inc, i32 4)
  %427 = xor i1 %guest_aligned55, true
  br i1 %427, label %data_misaligned53, label %data_aligned54, !prof !2

loop_sync_raised46:                               ; preds = %page_slow40
  %428 = getelementptr i8, ptr %shadow, i64 0
  %429 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %428, ptr align 1 %429, i64 16, i1 false)
  %430 = getelementptr i8, ptr %shadow, i64 24
  %431 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %430, ptr align 1 %431, i64 8, i1 false)
  %432 = getelementptr i8, ptr %shadow, i64 160
  %433 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %432, ptr align 1 %433, i64 8, i1 false)
  %434 = getelementptr i8, ptr %shadow, i64 188
  %435 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %434, ptr align 1 %435, i64 4, i1 false)
  %436 = getelementptr i8, ptr %shadow, i64 228
  %437 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %436, ptr align 1 %437, i64 16, i1 false)
  %438 = getelementptr i8, ptr %shadow, i64 248
  %439 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %438, ptr align 1 %439, i64 12, i1 false)
  %440 = getelementptr i8, ptr %shadow, i64 276
  %441 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %440, ptr align 1 %441, i64 4, i1 false)
  %442 = getelementptr i8, ptr %shadow, i64 292
  %443 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %442, ptr align 1 %443, i64 5, i1 false)
  %444 = getelementptr i8, ptr %shadow, i64 308
  %445 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %444, ptr align 1 %445, i64 4, i1 false)
  %446 = getelementptr i8, ptr %shadow, i64 348
  %447 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %446, ptr align 1 %447, i64 4, i1 false)
  %448 = getelementptr i8, ptr %shadow, i64 188
  %next_pc86 = load i32, ptr %448, align 4
  %449 = getelementptr i8, ptr %shadow, i64 308
  %packets87 = load i32, ptr %449, align 4
  %450 = getelementptr i8, ptr %shadow, i64 188
  %451 = load i32, ptr %450, align 4
  %452 = getelementptr i8, ptr %shadow, i64 296
  %453 = load i8, ptr %452, align 1
  br label %chain_exit

loop_sync_cont47:                                 ; preds = %page_slow40
  %454 = getelementptr i8, ptr %shadow, i32 296
  %dj50 = load i8, ptr %454, align 1
  %dj_set51 = icmp ne i8 %dj50, 0
  br i1 %dj_set51, label %did_jump_exit48, label %did_jump_cont49, !prof !2

did_jump_exit48:                                  ; preds = %loop_sync_cont47
  %455 = getelementptr i8, ptr %shadow, i64 188
  %next_pc88 = load i32, ptr %455, align 4
  %456 = getelementptr i8, ptr %shadow, i64 308
  %packets89 = load i32, ptr %456, align 4
  %457 = getelementptr i8, ptr %shadow, i64 188
  %458 = load i32, ptr %457, align 4
  %459 = getelementptr i8, ptr %shadow, i64 296
  %460 = load i8, ptr %459, align 1
  br label %chain_exit

did_jump_cont49:                                  ; preds = %loop_sync_cont47
  br label %page_done41

data_misaligned53:                                ; preds = %page_done41
  %461 = getelementptr i8, ptr %shadow, i64 0
  %462 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %462, ptr align 1 %461, i64 16, i1 false)
  %463 = getelementptr i8, ptr %shadow, i64 24
  %464 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %464, ptr align 1 %463, i64 8, i1 false)
  %465 = getelementptr i8, ptr %shadow, i64 188
  %466 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %466, ptr align 1 %465, i64 4, i1 false)
  %467 = getelementptr i8, ptr %shadow, i64 228
  %468 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %468, ptr align 1 %467, i64 16, i1 false)
  %469 = getelementptr i8, ptr %shadow, i64 248
  %470 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %470, ptr align 1 %469, i64 12, i1 false)
  %471 = getelementptr i8, ptr %shadow, i64 276
  %472 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %472, ptr align 1 %471, i64 4, i1 false)
  %473 = getelementptr i8, ptr %shadow, i64 292
  %474 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %474, ptr align 1 %473, i64 5, i1 false)
  %475 = getelementptr i8, ptr %shadow, i64 308
  %476 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %476, ptr align 1 %475, i64 4, i1 false)
  %477 = getelementptr i8, ptr %shadow, i64 348
  %478 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %478, ptr align 1 %477, i64 4, i1 false)
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp_inc, i32 0)
  %479 = getelementptr i8, ptr %shadow, i64 0
  %480 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %479, ptr align 1 %480, i64 16, i1 false)
  %481 = getelementptr i8, ptr %shadow, i64 24
  %482 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %481, ptr align 1 %482, i64 8, i1 false)
  %483 = getelementptr i8, ptr %shadow, i64 160
  %484 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %483, ptr align 1 %484, i64 8, i1 false)
  %485 = getelementptr i8, ptr %shadow, i64 188
  %486 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %485, ptr align 1 %486, i64 4, i1 false)
  %487 = getelementptr i8, ptr %shadow, i64 228
  %488 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %487, ptr align 1 %488, i64 16, i1 false)
  %489 = getelementptr i8, ptr %shadow, i64 248
  %490 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %489, ptr align 1 %490, i64 12, i1 false)
  %491 = getelementptr i8, ptr %shadow, i64 276
  %492 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %491, ptr align 1 %492, i64 4, i1 false)
  %493 = getelementptr i8, ptr %shadow, i64 292
  %494 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %493, ptr align 1 %494, i64 5, i1 false)
  %495 = getelementptr i8, ptr %shadow, i64 308
  %496 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %495, ptr align 1 %496, i64 4, i1 false)
  %497 = getelementptr i8, ptr %shadow, i64 348
  %498 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %497, ptr align 1 %498, i64 4, i1 false)
  %499 = getelementptr i8, ptr %shadow, i64 188
  %next_pc90 = load i32, ptr %499, align 4
  %500 = getelementptr i8, ptr %shadow, i64 308
  %packets91 = load i32, ptr %500, align 4
  %501 = getelementptr i8, ptr %shadow, i64 188
  %502 = load i32, ptr %501, align 4
  %503 = getelementptr i8, ptr %shadow, i64 296
  %504 = load i8, ptr %503, align 1
  br label %chain_exit

data_aligned54:                                   ; preds = %page_done41
  %guest_ptr59 = call ptr @bcore.guest.ptr(ptr %page_table, i32 %sp_inc)
  %page_mapped60 = icmp ne ptr %guest_ptr59, null
  br i1 %page_mapped60, label %page_fast56, label %page_slow57, !prof !1

page_fast56:                                      ; preds = %data_aligned54
  %page_val61 = load i32, ptr %guest_ptr59, align 4
  br label %page_done58

page_slow57:                                      ; preds = %data_aligned54
  %505 = getelementptr i8, ptr %shadow, i64 0
  %506 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %506, ptr align 1 %505, i64 16, i1 false)
  %507 = getelementptr i8, ptr %shadow, i64 24
  %508 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %508, ptr align 1 %507, i64 8, i1 false)
  %509 = getelementptr i8, ptr %shadow, i64 188
  %510 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %510, ptr align 1 %509, i64 4, i1 false)
  %511 = getelementptr i8, ptr %shadow, i64 228
  %512 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %512, ptr align 1 %511, i64 16, i1 false)
  %513 = getelementptr i8, ptr %shadow, i64 248
  %514 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %514, ptr align 1 %513, i64 12, i1 false)
  %515 = getelementptr i8, ptr %shadow, i64 276
  %516 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %516, ptr align 1 %515, i64 4, i1 false)
  %517 = getelementptr i8, ptr %shadow, i64 292
  %518 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %518, ptr align 1 %517, i64 5, i1 false)
  %519 = getelementptr i8, ptr %shadow, i64 308
  %520 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %520, ptr align 1 %519, i64 4, i1 false)
  %521 = getelementptr i8, ptr %shadow, i64 348
  %522 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %522, ptr align 1 %521, i64 4, i1 false)
  %523 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %524 = getelementptr i8, ptr %cpu, i32 296
  %real_did_jump62 = load i8, ptr %524, align 1
  %525 = icmp ne i8 %real_did_jump62, 0
  br i1 %525, label %loop_sync_raised63, label %loop_sync_cont64, !prof !2

page_done58:                                      ; preds = %did_jump_cont66, %page_fast56
  %mem_val69 = phi i32 [ %page_val61, %page_fast56 ], [ %523, %did_jump_cont66 ]
  %526 = getelementptr i8, ptr %shadow, i32 24
  store i32 %mem_val69, ptr %526, align 4
  %sp_inc70 = add i32 %sp_inc, 4
  %527 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc70, ptr %527, align 4
  %528 = getelementptr i8, ptr %shadow, i32 188
  store i32 65804, ptr %528, align 4
  br label %insn_0x0001010c_entry

loop_sync_raised63:                               ; preds = %page_slow57
  %529 = getelementptr i8, ptr %shadow, i64 0
  %530 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %529, ptr align 1 %530, i64 16, i1 false)
  %531 = getelementptr i8, ptr %shadow, i64 24
  %532 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %531, ptr align 1 %532, i64 8, i1 false)
  %533 = getelementptr i8, ptr %shadow, i64 160
  %534 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %533, ptr align 1 %534, i64 8, i1 false)
  %535 = getelementptr i8, ptr %shadow, i64 188
  %536 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %535, ptr align 1 %536, i64 4, i1 false)
  %537 = getelementptr i8, ptr %shadow, i64 228
  %538 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %537, ptr align 1 %538, i64 16, i1 false)
  %539 = getelementptr i8, ptr %shadow, i64 248
  %540 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %539, ptr align 1 %540, i64 12, i1 false)
  %541 = getelementptr i8, ptr %shadow, i64 276
  %542 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %541, ptr align 1 %542, i64 4, i1 false)
  %543 = getelementptr i8, ptr %shadow, i64 292
  %544 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %543, ptr align 1 %544, i64 5, i1 false)
  %545 = getelementptr i8, ptr %shadow, i64 308
  %546 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %545, ptr align 1 %546, i64 4, i1 false)
  %547 = getelementptr i8, ptr %shadow, i64 348
  %548 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %547, ptr align 1 %548, i64 4, i1 false)
  %549 = getelementptr i8, ptr %shadow, i64 188
  %next_pc92 = load i32, ptr %549, align 4
  %550 = getelementptr i8, ptr %shadow, i64 308
  %packets93 = load i32, ptr %550, align 4
  %551 = getelementptr i8, ptr %shadow, i64 188
  %552 = load i32, ptr %551, align 4
  %553 = getelementptr i8, ptr %shadow, i64 296
  %554 = load i8, ptr %553, align 1
  br label %chain_exit

loop_sync_cont64:                                 ; preds = %page_slow57
  %555 = getelementptr i8, ptr %shadow, i32 296
  %dj67 = load i8, ptr %555, align 1
  %dj_set68 = icmp ne i8 %dj67, 0
  br i1 %dj_set68, label %did_jump_exit65, label %did_jump_cont66, !prof !2

did_jump_exit65:                                  ; preds = %loop_sync_cont64
  %556 = getelementptr i8, ptr %shadow, i64 188
  %next_pc94 = load i32, ptr %556, align 4
  %557 = getelementptr i8, ptr %shadow, i64 308
  %packets95 = load i32, ptr %557, align 4
  %558 = getelementptr i8, ptr %shadow, i64 188
  %559 = load i32, ptr %558, align 4
  %560 = getelementptr i8, ptr %shadow, i64 296
  %561 = load i8, ptr %560, align 1
  br label %chain_exit

did_jump_cont66:                                  ; preds = %loop_sync_cont64
  br label %page_done58

insn_0x0001010c_entry:                            ; preds = %page_done58
  %562 = getelementptr i8, ptr %shadow, i32 292
  store i32 2, ptr %562, align 4
  %563 = getelementptr i8, ptr %shadow, i32 308
  store i32 14, ptr %563, align 4
  br label %insn_0x0001010c

insn_0x0001010c:                                  ; preds = %insn_0x0001010c_entry
  %lsb = and i32 %mem_val35, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !2

jump_aligned:                                     ; preds = %insn_0x0001010c
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001010c
  %564 = getelementptr i8, ptr %shadow, i32 188
  store i32 65804, ptr %564, align 4
  %565 = getelementptr i8, ptr %shadow, i64 0
  %566 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %566, ptr align 1 %565, i64 16, i1 false)
  %567 = getelementptr i8, ptr %shadow, i64 24
  %568 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %568, ptr align 1 %567, i64 8, i1 false)
  %569 = getelementptr i8, ptr %shadow, i64 188
  %570 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %570, ptr align 1 %569, i64 4, i1 false)
  %571 = getelementptr i8, ptr %shadow, i64 228
  %572 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %572, ptr align 1 %571, i64 16, i1 false)
  %573 = getelementptr i8, ptr %shadow, i64 248
  %574 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %574, ptr align 1 %573, i64 12, i1 false)
  %575 = getelementptr i8, ptr %shadow, i64 276
  %576 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %576, ptr align 1 %575, i64 4, i1 false)
  %577 = getelementptr i8, ptr %shadow, i64 292
  %578 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %578, ptr align 1 %577, i64 5, i1 false)
  %579 = getelementptr i8, ptr %shadow, i64 308
  %580 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %580, ptr align 1 %579, i64 4, i1 false)
  %581 = getelementptr i8, ptr %shadow, i64 348
  %582 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %582, ptr align 1 %581, i64 4, i1 false)
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %583 = getelementptr i8, ptr %shadow, i64 0
  %584 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %583, ptr align 1 %584, i64 16, i1 false)
  %585 = getelementptr i8, ptr %shadow, i64 24
  %586 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %585, ptr align 1 %586, i64 8, i1 false)
  %587 = getelementptr i8, ptr %shadow, i64 160
  %588 = getelementptr i8, ptr %cpu, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %587, ptr align 1 %588, i64 8, i1 false)
  %589 = getelementptr i8, ptr %shadow, i64 188
  %590 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %589, ptr align 1 %590, i64 4, i1 false)
  %591 = getelementptr i8, ptr %shadow, i64 228
  %592 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %591, ptr align 1 %592, i64 16, i1 false)
  %593 = getelementptr i8, ptr %shadow, i64 248
  %594 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %593, ptr align 1 %594, i64 12, i1 false)
  %595 = getelementptr i8, ptr %shadow, i64 276
  %596 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %595, ptr align 1 %596, i64 4, i1 false)
  %597 = getelementptr i8, ptr %shadow, i64 292
  %598 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %597, ptr align 1 %598, i64 5, i1 false)
  %599 = getelementptr i8, ptr %shadow, i64 308
  %600 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %599, ptr align 1 %600, i64 4, i1 false)
  %601 = getelementptr i8, ptr %shadow, i64 348
  %602 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %601, ptr align 1 %602, i64 4, i1 false)
  %603 = getelementptr i8, ptr %shadow, i64 188
  %next_pc96 = load i32, ptr %603, align 4
  %604 = getelementptr i8, ptr %shadow, i64 308
  %packets97 = load i32, ptr %604, align 4
  %605 = getelementptr i8, ptr %shadow, i64 188
  %606 = load i32, ptr %605, align 4
  %607 = getelementptr i8, ptr %shadow, i64 296
  %608 = load i8, ptr %607, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %609 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %609, align 1
  %610 = getelementptr i8, ptr %shadow, i64 0
  %611 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %611, ptr align 1 %610, i64 16, i1 false)
  %612 = getelementptr i8, ptr %shadow, i64 24
  %613 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %613, ptr align 1 %612, i64 8, i1 false)
  %614 = getelementptr i8, ptr %shadow, i64 188
  %615 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %615, ptr align 1 %614, i64 4, i1 false)
  %616 = getelementptr i8, ptr %shadow, i64 228
  %617 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %617, ptr align 1 %616, i64 16, i1 false)
  %618 = getelementptr i8, ptr %shadow, i64 248
  %619 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %619, ptr align 1 %618, i64 12, i1 false)
  %620 = getelementptr i8, ptr %shadow, i64 276
  %621 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %621, ptr align 1 %620, i64 4, i1 false)
  %622 = getelementptr i8, ptr %shadow, i64 292
  %623 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %623, ptr align 1 %622, i64 5, i1 false)
  %624 = getelementptr i8, ptr %shadow, i64 308
  %625 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %625, ptr align 1 %624, i64 4, i1 false)
  %626 = getelementptr i8, ptr %shadow, i64 348
  %627 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %627, ptr align 1 %626, i64 4, i1 false)
  ret void

chain_leave:                                      ; No predecessors!
  %628 = getelementptr i8, ptr %shadow, i64 0
  %629 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %629, ptr align 1 %628, i64 16, i1 false)
  %630 = getelementptr i8, ptr %shadow, i64 24
  %631 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %631, ptr align 1 %630, i64 8, i1 false)
  %632 = getelementptr i8, ptr %shadow, i64 188
  %633 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %633, ptr align 1 %632, i64 4, i1 false)
  %634 = getelementptr i8, ptr %shadow, i64 228
  %635 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %635, ptr align 1 %634, i64 16, i1 false)
  %636 = getelementptr i8, ptr %shadow, i64 248
  %637 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %637, ptr align 1 %636, i64 12, i1 false)
  %638 = getelementptr i8, ptr %shadow, i64 276
  %639 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %639, ptr align 1 %638, i64 4, i1 false)
  %640 = getelementptr i8, ptr %shadow, i64 292
  %641 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %641, ptr align 1 %640, i64 5, i1 false)
  %642 = getelementptr i8, ptr %shadow, i64 308
  %643 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %643, ptr align 1 %642, i64 4, i1 false)
  %644 = getelementptr i8, ptr %shadow, i64 348
  %645 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %645, ptr align 1 %644, i64 4, i1 false)
  ret void

chain_go:                                         ; preds = %chain_budget_now
  %646 = getelementptr i8, ptr %shadow, i64 188
  store i32 65772, ptr %646, align 4
  %647 = getelementptr i8, ptr %shadow, i64 348
  store i32 %chain_total, ptr %647, align 4
  br label %insn_0x000100ec_entry

chain_leave72:                                    ; preds = %chain_budget_now, %brcc_taken
  %648 = getelementptr i8, ptr %shadow, i64 188
  store i32 65772, ptr %648, align 4
  %649 = getelementptr i8, ptr %shadow, i64 296
  store i8 1, ptr %649, align 1
  %650 = getelementptr i8, ptr %shadow, i64 0
  %651 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %651, ptr align 1 %650, i64 16, i1 false)
  %652 = getelementptr i8, ptr %shadow, i64 24
  %653 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %653, ptr align 1 %652, i64 8, i1 false)
  %654 = getelementptr i8, ptr %shadow, i64 188
  %655 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %655, ptr align 1 %654, i64 4, i1 false)
  %656 = getelementptr i8, ptr %shadow, i64 228
  %657 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %657, ptr align 1 %656, i64 16, i1 false)
  %658 = getelementptr i8, ptr %shadow, i64 248
  %659 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %659, ptr align 1 %658, i64 12, i1 false)
  %660 = getelementptr i8, ptr %shadow, i64 276
  %661 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %661, ptr align 1 %660, i64 4, i1 false)
  %662 = getelementptr i8, ptr %shadow, i64 292
  %663 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %663, ptr align 1 %662, i64 5, i1 false)
  %664 = getelementptr i8, ptr %shadow, i64 308
  %665 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %665, ptr align 1 %664, i64 4, i1 false)
  %666 = getelementptr i8, ptr %shadow, i64 348
  %667 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %667, ptr align 1 %666, i64 4, i1 false)
  ret void

chain_budget_now:                                 ; preds = %brcc_taken
  %668 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget73 = load atomic i32, ptr %668 monotonic, align 4, !range !0
  %669 = icmp ne i32 %chain_budget73, 0
  br i1 %669, label %chain_go, label %chain_leave72, !prof !1

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit65, %loop_sync_raised63, %data_misaligned53, %did_jump_exit48, %loop_sync_raised46, %data_misaligned36, %did_jump_exit31, %loop_sync_raised29, %data_misaligned19, %did_jump_exit, %loop_sync_raised, %data_misaligned
  %next_pc98 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc74, %loop_sync_raised ], [ %next_pc76, %did_jump_exit ], [ %next_pc78, %data_misaligned19 ], [ %next_pc80, %loop_sync_raised29 ], [ %next_pc82, %did_jump_exit31 ], [ %next_pc84, %data_misaligned36 ], [ %next_pc86, %loop_sync_raised46 ], [ %next_pc88, %did_jump_exit48 ], [ %next_pc90, %data_misaligned53 ], [ %next_pc92, %loop_sync_raised63 ], [ %next_pc94, %did_jump_exit65 ], [ %mem_val35, %jump_aligned ], [ %next_pc96, %jump_misalign ]
  %packets99 = phi i32 [ %packets, %data_misaligned ], [ %packets75, %loop_sync_raised ], [ %packets77, %did_jump_exit ], [ %packets79, %data_misaligned19 ], [ %packets81, %loop_sync_raised29 ], [ %packets83, %did_jump_exit31 ], [ %packets85, %data_misaligned36 ], [ %packets87, %loop_sync_raised46 ], [ %packets89, %did_jump_exit48 ], [ %packets91, %data_misaligned53 ], [ %packets93, %loop_sync_raised63 ], [ %packets95, %did_jump_exit65 ], [ 14, %jump_aligned ], [ %packets97, %jump_misalign ]
  %tail = phi i32 [ %194, %data_misaligned ], [ %242, %loop_sync_raised ], [ %249, %did_jump_exit ], [ %293, %data_misaligned19 ], [ %344, %loop_sync_raised29 ], [ %351, %did_jump_exit31 ], [ %402, %data_misaligned36 ], [ %451, %loop_sync_raised46 ], [ %458, %did_jump_exit48 ], [ %502, %data_misaligned53 ], [ %552, %loop_sync_raised63 ], [ %559, %did_jump_exit65 ], [ %mem_val35, %jump_aligned ], [ %606, %jump_misalign ]
  %tail100 = phi i8 [ %196, %data_misaligned ], [ %244, %loop_sync_raised ], [ %251, %did_jump_exit ], [ %295, %data_misaligned19 ], [ %346, %loop_sync_raised29 ], [ %353, %did_jump_exit31 ], [ %404, %data_misaligned36 ], [ %453, %loop_sync_raised46 ], [ %460, %did_jump_exit48 ], [ %504, %data_misaligned53 ], [ %554, %loop_sync_raised63 ], [ %561, %did_jump_exit65 ], [ 1, %jump_aligned ], [ %608, %jump_misalign ]
  %670 = getelementptr i8, ptr %shadow, i64 348
  %chain_packets102 = load i32, ptr %670, align 4
  %chain_total103 = add nuw i32 %chain_packets102, %packets99
  %671 = icmp ult i32 %chain_total103, %chain_budget
  br i1 %671, label %chain_budget_now104, label %chain_leave101, !prof !1

chain_lookup:                                     ; preds = %chain_budget_now104
  %672 = icmp eq i32 %next_pc98, 65772
  br i1 %672, label %chain_self, label %chain_other, !prof !3

chain_leave101:                                   ; preds = %chain_other, %chain_budget_now104, %chain_exit
  %673 = getelementptr i8, ptr %shadow, i64 188
  store i32 %tail, ptr %673, align 4
  %674 = getelementptr i8, ptr %shadow, i64 296
  store i8 %tail100, ptr %674, align 1
  %675 = getelementptr i8, ptr %shadow, i64 0
  %676 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %676, ptr align 1 %675, i64 16, i1 false)
  %677 = getelementptr i8, ptr %shadow, i64 24
  %678 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %678, ptr align 1 %677, i64 8, i1 false)
  %679 = getelementptr i8, ptr %shadow, i64 188
  %680 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %680, ptr align 1 %679, i64 4, i1 false)
  %681 = getelementptr i8, ptr %shadow, i64 228
  %682 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %682, ptr align 1 %681, i64 16, i1 false)
  %683 = getelementptr i8, ptr %shadow, i64 248
  %684 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %684, ptr align 1 %683, i64 12, i1 false)
  %685 = getelementptr i8, ptr %shadow, i64 276
  %686 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %686, ptr align 1 %685, i64 4, i1 false)
  %687 = getelementptr i8, ptr %shadow, i64 292
  %688 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %688, ptr align 1 %687, i64 5, i1 false)
  %689 = getelementptr i8, ptr %shadow, i64 308
  %690 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %690, ptr align 1 %689, i64 4, i1 false)
  %691 = getelementptr i8, ptr %shadow, i64 348
  %692 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %692, ptr align 1 %691, i64 4, i1 false)
  ret void

chain_budget_now104:                              ; preds = %chain_exit
  %693 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget105 = load atomic i32, ptr %693 monotonic, align 4, !range !0
  %694 = icmp ne i32 %chain_budget105, 0
  br i1 %694, label %chain_lookup, label %chain_leave101, !prof !1

chain_self:                                       ; preds = %chain_lookup
  %695 = getelementptr i8, ptr %shadow, i64 188
  store i32 %next_pc98, ptr %695, align 4
  %696 = getelementptr i8, ptr %shadow, i64 348
  store i32 %chain_total103, ptr %696, align 4
  %697 = getelementptr i8, ptr %shadow, i64 296
  store i8 0, ptr %697, align 1
  br label %insn_0x000100ec_entry

chain_other:                                      ; preds = %chain_lookup
  %698 = lshr i32 %next_pc98, 1
  %699 = and i32 %698, 65535
  %700 = zext i32 %699 to i64
  %701 = mul i64 %700, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %701
  %702 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %702, align 4
  %703 = icmp eq i32 %slot_pc, %next_pc98
  br i1 %703, label %chain_hit, label %chain_leave101, !prof !1

chain_hit:                                        ; preds = %chain_other
  %704 = getelementptr i8, ptr %shadow, i64 188
  store i32 %next_pc98, ptr %704, align 4
  %705 = getelementptr i8, ptr %shadow, i64 348
  store i32 %chain_total103, ptr %705, align 4
  %706 = getelementptr i8, ptr %shadow, i64 296
  store i8 0, ptr %706, align 1
  %707 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %707, align 8
  %708 = getelementptr i8, ptr %shadow, i64 0
  %709 = getelementptr i8, ptr %cpu, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %709, ptr align 1 %708, i64 16, i1 false)
  %710 = getelementptr i8, ptr %shadow, i64 24
  %711 = getelementptr i8, ptr %cpu, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %711, ptr align 1 %710, i64 8, i1 false)
  %712 = getelementptr i8, ptr %shadow, i64 188
  %713 = getelementptr i8, ptr %cpu, i64 188
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %713, ptr align 1 %712, i64 4, i1 false)
  %714 = getelementptr i8, ptr %shadow, i64 228
  %715 = getelementptr i8, ptr %cpu, i64 228
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %715, ptr align 1 %714, i64 16, i1 false)
  %716 = getelementptr i8, ptr %shadow, i64 248
  %717 = getelementptr i8, ptr %cpu, i64 248
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %717, ptr align 1 %716, i64 12, i1 false)
  %718 = getelementptr i8, ptr %shadow, i64 276
  %719 = getelementptr i8, ptr %cpu, i64 276
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %719, ptr align 1 %718, i64 4, i1 false)
  %720 = getelementptr i8, ptr %shadow, i64 292
  %721 = getelementptr i8, ptr %cpu, i64 292
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %721, ptr align 1 %720, i64 5, i1 false)
  %722 = getelementptr i8, ptr %shadow, i64 308
  %723 = getelementptr i8, ptr %cpu, i64 308
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %723, ptr align 1 %722, i64 4, i1 false)
  %724 = getelementptr i8, ptr %shadow, i64 348
  %725 = getelementptr i8, ptr %cpu, i64 348
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %725, ptr align 1 %724, i64 4, i1 false)
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #4
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: nounwind readnone willreturn
declare i1 @bcore.guest.aligned(i32, i32) #1

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #2

; Function Attrs: nounwind readnone willreturn
declare ptr @bcore.guest.ptr(ptr, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #2

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

attributes #0 = { "bcore-loop-block" "no_callee_saved_registers" }
attributes #1 = { nounwind readnone willreturn }
attributes #2 = { cold }
attributes #3 = { argmemonly nocallback nofree nounwind willreturn }
attributes #4 = { "no_callee_saved_registers" }

!0 = !{i32 0, i32 -2147483648}
!1 = !{!"branch_weights", i32 1048576, i32 1}
!2 = !{!"branch_weights", i32 1, i32 1048576}
!3 = !{!"branch_weights", i32 63, i32 1}
