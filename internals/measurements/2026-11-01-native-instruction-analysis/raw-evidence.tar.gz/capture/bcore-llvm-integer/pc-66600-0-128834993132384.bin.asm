
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66600-0-128834993132384.bin:     file format binary


Disassembly of section .data:

0000752cbc001360 <.data>:
    752cbc001360:	48 83 ec 28          	sub    rsp,0x28
    752cbc001364:	ba bf fb fe ff       	mov    edx,0xfffefbbf
    752cbc001369:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc001370:	01 d6                	add    esi,edx
    752cbc001372:	b1 01                	mov    cl,0x1
    752cbc001374:	b8 65 01 00 00       	mov    eax,0x165
    752cbc001379:	83 fe e6             	cmp    esi,0xffffffe6
    752cbc00137c:	0f 87 df 01 00 00    	ja     0x752cbc001561
    752cbc001382:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc001389:	83 fa e6             	cmp    edx,0xffffffe6
    752cbc00138c:	0f 87 cf 01 00 00    	ja     0x752cbc001561
    752cbc001392:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    752cbc001399:	49 8b 9d 38 01 00 00 	mov    rbx,QWORD PTR [r13+0x138]
    752cbc0013a0:	4d 8b 8d 40 01 00 00 	mov    r9,QWORD PTR [r13+0x140]
    752cbc0013a7:	66 41 c7 45 2a 01 00 	mov    WORD PTR [r13+0x2a],0x1
    752cbc0013ae:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    752cbc0013b2:	44 8d 46 fc          	lea    r8d,[rsi-0x4]
    752cbc0013b6:	40 f6 c6 03          	test   sil,0x3
    752cbc0013ba:	0f 85 9e 0d 00 18    	jne    0x752cd400215e
    752cbc0013c0:	45 8b 55 3c          	mov    r10d,DWORD PTR [r13+0x3c]
    752cbc0013c4:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    752cbc0013cb:	45 89 c7             	mov    r15d,r8d
    752cbc0013ce:	41 c1 ef 0c          	shr    r15d,0xc
    752cbc0013d2:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    752cbc0013d6:	48 85 c0             	test   rax,rax
    752cbc0013d9:	0f 84 e4 0d 00 18    	je     0x752cd40021c3
    752cbc0013df:	44 89 c1             	mov    ecx,r8d
    752cbc0013e2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0013e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0013eb:	8d 6e f8             	lea    ebp,[rsi-0x8]
    752cbc0013ee:	41 89 ec             	mov    r12d,ebp
    752cbc0013f1:	41 c1 ec 0c          	shr    r12d,0xc
    752cbc0013f5:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    752cbc0013f9:	48 85 c0             	test   rax,rax
    752cbc0013fc:	0f 84 33 0e 00 18    	je     0x752cd4002235
    752cbc001402:	89 e9                	mov    ecx,ebp
    752cbc001404:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc00140a:	44 89 14 08          	mov    DWORD PTR [rax+rcx*1],r10d
    752cbc00140e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc001412:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    752cbc001416:	41 80 39 00          	cmp    BYTE PTR [r9],0x0
    752cbc00141a:	0f 85 8a 0e 00 18    	jne    0x752cd40022aa
    752cbc001420:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    752cbc001427:	00 
    752cbc001428:	48 8b 83 88 00 00 00 	mov    rax,QWORD PTR [rbx+0x88]
    752cbc00142f:	48 85 c0             	test   rax,rax
    752cbc001432:	0f 84 e2 0e 00 18    	je     0x752cd400231a
    752cbc001438:	8b 80 f0 02 00 00    	mov    eax,DWORD PTR [rax+0x2f0]
    752cbc00143e:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    752cbc001442:	31 c9                	xor    ecx,ecx
    752cbc001444:	83 f8 05             	cmp    eax,0x5
    752cbc001447:	0f 92 c1             	setb   cl
    752cbc00144a:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    752cbc001451:	73 53                	jae    0x752cbc0014a6
    752cbc001453:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    752cbc00145a:	42 04 01 00 
    752cbc00145e:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc001465:	83 c0 06             	add    eax,0x6
    752cbc001468:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc00146f:	39 c8                	cmp    eax,ecx
    752cbc001471:	0f 83 15 0f 00 18    	jae    0x752cd400238c
    752cbc001477:	81 bf 10 22 08 00 42 	cmp    DWORD PTR [rdi+0x82210],0x10442
    752cbc00147e:	04 01 00 
    752cbc001481:	0f 85 05 0f 00 18    	jne    0x752cd400238c
    752cbc001487:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    752cbc00148e:	42 04 01 00 
    752cbc001492:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001499:	48 8b 87 18 22 08 00 	mov    rax,QWORD PTR [rdi+0x82218]
    752cbc0014a0:	48 83 c4 28          	add    rsp,0x28
    752cbc0014a4:	ff e0                	jmp    rax
    752cbc0014a6:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    752cbc0014ad:	00 
    752cbc0014ae:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    752cbc0014b2:	48 85 c0             	test   rax,rax
    752cbc0014b5:	0f 84 ed 0e 00 18    	je     0x752cd40023a8
    752cbc0014bb:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    752cbc0014c1:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    752cbc0014c4:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    752cbc0014c8:	48 85 c0             	test   rax,rax
    752cbc0014cb:	0f 84 44 0f 00 18    	je     0x752cd4002415
    752cbc0014d1:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
    752cbc0014d8:	42 8b 04 00          	mov    eax,DWORD PTR [rax+r8*1]
    752cbc0014dc:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc0014e0:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    752cbc0014e7:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc0014eb:	b1 01                	mov    cl,0x1
    752cbc0014ed:	bb 02 00 00 00       	mov    ebx,0x2
    752cbc0014f2:	bd 09 00 00 00       	mov    ebp,0x9
    752cbc0014f7:	a8 01                	test   al,0x1
    752cbc0014f9:	0f 85 70 0f 00 18    	jne    0x752cd400246f
    752cbc0014ff:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    752cbc001506:	01 ea                	add    edx,ebp
    752cbc001508:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    752cbc00150f:	39 f2                	cmp    edx,esi
    752cbc001511:	0f 83 3b 0c 00 18    	jae    0x752cd4002152
    752cbc001517:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    752cbc00151e:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    752cbc001524:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    752cbc001527:	0f 85 25 0c 00 18    	jne    0x752cd4002152
    752cbc00152d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    752cbc001534:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    752cbc00153b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc001542:	00 
    752cbc001543:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    752cbc001548:	48 83 c4 28          	add    rsp,0x28
    752cbc00154c:	ff e0                	jmp    rax
    752cbc00154e:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    752cbc001555:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc00155c:	b8 28 01 00 00       	mov    eax,0x128
    752cbc001561:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc001566:	48 83 c4 28          	add    rsp,0x28
    752cbc00156a:	c2 08 00             	ret    0x8
