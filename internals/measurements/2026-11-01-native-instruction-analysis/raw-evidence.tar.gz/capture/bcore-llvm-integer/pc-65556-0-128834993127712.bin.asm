
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65556-0-128834993127712.bin:     file format binary


Disassembly of section .data:

0000752cbc000120 <.data>:
    752cbc000120:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    752cbc000127:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    752cbc00012c:	ba c1 ff fe ff       	mov    edx,0xfffeffc1
    752cbc000131:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc000138:	01 d6                	add    esi,edx
    752cbc00013a:	b1 01                	mov    cl,0x1
    752cbc00013c:	b8 65 01 00 00       	mov    eax,0x165
    752cbc000141:	83 fe d4             	cmp    esi,0xffffffd4
    752cbc000144:	0f 87 c6 04 00 00    	ja     0x752cbc000610
    752cbc00014a:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc000151:	83 fa d4             	cmp    edx,0xffffffd4
    752cbc000154:	0f 87 b6 04 00 00    	ja     0x752cbc000610
    752cbc00015a:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    752cbc000161:	45 8b 45 38          	mov    r8d,DWORD PTR [r13+0x38]
    752cbc000165:	45 8d 48 fc          	lea    r9d,[r8-0x4]
    752cbc000169:	41 f6 c0 03          	test   r8b,0x3
    752cbc00016d:	0f 85 99 fe ff 17    	jne    0x752cd400000c
    752cbc000173:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    752cbc00017a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    752cbc000181:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    752cbc000185:	45 89 ca             	mov    r10d,r9d
    752cbc000188:	41 c1 ea 0c          	shr    r10d,0xc
    752cbc00018c:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    752cbc000190:	48 85 c0             	test   rax,rax
    752cbc000193:	0f 84 d0 fe ff 17    	je     0x752cd4000069
    752cbc000199:	44 89 c9             	mov    ecx,r9d
    752cbc00019c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0001a2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0001a5:	45 8d 58 f8          	lea    r11d,[r8-0x8]
    752cbc0001a9:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    752cbc0001ad:	44 89 d8             	mov    eax,r11d
    752cbc0001b0:	c1 e8 0c             	shr    eax,0xc
    752cbc0001b3:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    752cbc0001ba:	00 
    752cbc0001bb:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc0001bf:	48 85 c0             	test   rax,rax
    752cbc0001c2:	0f 84 02 ff ff 17    	je     0x752cd40000ca
    752cbc0001c8:	44 89 d9             	mov    ecx,r11d
    752cbc0001cb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0001d1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0001d4:	41 8d 70 f4          	lea    esi,[r8-0xc]
    752cbc0001d8:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    752cbc0001dc:	89 f0                	mov    eax,esi
    752cbc0001de:	c1 e8 0c             	shr    eax,0xc
    752cbc0001e1:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    752cbc0001e8:	00 
    752cbc0001e9:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc0001ed:	48 85 c0             	test   rax,rax
    752cbc0001f0:	48 89 74 24 38       	mov    QWORD PTR [rsp+0x38],rsi
    752cbc0001f5:	0f 84 3a ff ff 17    	je     0x752cd4000135
    752cbc0001fb:	48 89 f1             	mov    rcx,rsi
    752cbc0001fe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000204:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000207:	41 8d 70 f0          	lea    esi,[r8-0x10]
    752cbc00020b:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    752cbc00020f:	89 f0                	mov    eax,esi
    752cbc000211:	c1 e8 0c             	shr    eax,0xc
    752cbc000214:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    752cbc00021b:	00 
    752cbc00021c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc000220:	48 85 c0             	test   rax,rax
    752cbc000223:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    752cbc000228:	0f 84 6f ff ff 17    	je     0x752cd400019d
    752cbc00022e:	48 89 f1             	mov    rcx,rsi
    752cbc000231:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000237:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc00023a:	41 8d 70 ec          	lea    esi,[r8-0x14]
    752cbc00023e:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    752cbc000242:	89 f0                	mov    eax,esi
    752cbc000244:	c1 e8 0c             	shr    eax,0xc
    752cbc000247:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    752cbc00024c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc000250:	48 85 c0             	test   rax,rax
    752cbc000253:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    752cbc000258:	0f 84 a7 ff ff 17    	je     0x752cd4000205
    752cbc00025e:	48 89 f1             	mov    rcx,rsi
    752cbc000261:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000267:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc00026a:	41 8d 70 e8          	lea    esi,[r8-0x18]
    752cbc00026e:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    752cbc000272:	89 f0                	mov    eax,esi
    752cbc000274:	c1 e8 0c             	shr    eax,0xc
    752cbc000277:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    752cbc00027c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc000280:	48 85 c0             	test   rax,rax
    752cbc000283:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    752cbc000288:	0f 84 df ff ff 17    	je     0x752cd400026d
    752cbc00028e:	48 89 f1             	mov    rcx,rsi
    752cbc000291:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000297:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc00029a:	41 8d 70 e4          	lea    esi,[r8-0x1c]
    752cbc00029e:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    752cbc0002a2:	89 f0                	mov    eax,esi
    752cbc0002a4:	c1 e8 0c             	shr    eax,0xc
    752cbc0002a7:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    752cbc0002ac:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc0002b0:	48 85 c0             	test   rax,rax
    752cbc0002b3:	48 89 74 24 68       	mov    QWORD PTR [rsp+0x68],rsi
    752cbc0002b8:	0f 84 17 00 00 18    	je     0x752cd40002d5
    752cbc0002be:	89 f1                	mov    ecx,esi
    752cbc0002c0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0002c6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0002c9:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc0002cd:	49 89 de             	mov    r14,rbx
    752cbc0002d0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    752cbc0002d3:	0f 85 66 00 00 18    	jne    0x752cd400033f
    752cbc0002d9:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    752cbc0002de:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    752cbc0002e2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    752cbc0002e6:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    752cbc0002ed:	41 8d 70 e0          	lea    esi,[r8-0x20]
    752cbc0002f1:	89 f1                	mov    ecx,esi
    752cbc0002f3:	c1 e9 0c             	shr    ecx,0xc
    752cbc0002f6:	49 8b 04 cc          	mov    rax,QWORD PTR [r12+rcx*8]
    752cbc0002fa:	48 85 c0             	test   rax,rax
    752cbc0002fd:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    752cbc000302:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    752cbc000307:	0f 84 a4 00 00 18    	je     0x752cd40003b1
    752cbc00030d:	48 89 f1             	mov    rcx,rsi
    752cbc000310:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000316:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000319:	41 8d 68 dc          	lea    ebp,[r8-0x24]
    752cbc00031d:	41 89 ef             	mov    r15d,ebp
    752cbc000320:	41 c1 ef 0c          	shr    r15d,0xc
    752cbc000324:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    752cbc000328:	48 85 c0             	test   rax,rax
    752cbc00032b:	0f 84 f1 00 00 18    	je     0x752cd4000422
    752cbc000331:	89 e9                	mov    ecx,ebp
    752cbc000333:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000339:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    752cbc00033c:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc000340:	41 8d 40 c8          	lea    eax,[r8-0x38]
    752cbc000344:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    752cbc000348:	4c 89 f3             	mov    rbx,r14
    752cbc00034b:	41 80 3e 00          	cmp    BYTE PTR [r14],0x0
    752cbc00034f:	0f 85 43 01 00 18    	jne    0x752cd4000498
    752cbc000355:	41 c7 45 28 00 f0 00 	mov    DWORD PTR [r13+0x28],0xf000
    752cbc00035c:	00 
    752cbc00035d:	66 41 c7 45 06 42 43 	mov    WORD PTR [r13+0x6],0x4342
    752cbc000364:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc000369:	48 85 c0             	test   rax,rax
    752cbc00036c:	0f 84 ae 01 00 18    	je     0x752cd4000520
    752cbc000372:	8b 00                	mov    eax,DWORD PTR [rax]
    752cbc000374:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    752cbc000378:	41 c7 45 04 31 4e 42 	mov    DWORD PTR [r13+0x4],0x43424e31
    752cbc00037f:	43 
    752cbc000380:	8d 88 cf b1 bd bc    	lea    ecx,[rax-0x43424e31]
    752cbc000386:	89 ca                	mov    edx,ecx
    752cbc000388:	09 c2                	or     edx,eax
    752cbc00038a:	c1 ea 1f             	shr    edx,0x1f
    752cbc00038d:	31 f6                	xor    esi,esi
    752cbc00038f:	3d 31 4e 42 43       	cmp    eax,0x43424e31
    752cbc000394:	40 0f 93 c6          	setae  sil
    752cbc000398:	31 c0                	xor    eax,eax
    752cbc00039a:	85 c9                	test   ecx,ecx
    752cbc00039c:	0f 94 c0             	sete   al
    752cbc00039f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    752cbc0003a6:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    752cbc0003ad:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    752cbc0003b4:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    752cbc0003bb:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    752cbc0003c2:	0f 84 e6 01 00 00    	je     0x752cbc0005ae
    752cbc0003c8:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    752cbc0003cf:	00 
    752cbc0003d0:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    752cbc0003d7:	00 
    752cbc0003d8:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc0003dd:	48 85 c0             	test   rax,rax
    752cbc0003e0:	0f 84 d4 01 00 18    	je     0x752cd40005ba
    752cbc0003e6:	c7 40 10 03 00 00 00 	mov    DWORD PTR [rax+0x10],0x3
    752cbc0003ed:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    752cbc0003f0:	0f 85 43 02 00 18    	jne    0x752cd4000639
    752cbc0003f6:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    752cbc0003fd:	00 
    752cbc0003fe:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    752cbc000402:	48 85 c0             	test   rax,rax
    752cbc000405:	0f 84 af 02 00 18    	je     0x752cd40006ba
    752cbc00040b:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    752cbc000411:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    752cbc000414:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cbc000419:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    752cbc00041e:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    752cbc000423:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc000427:	48 85 c0             	test   rax,rax
    752cbc00042a:	0f 84 ff 02 00 18    	je     0x752cd400072f
    752cbc000430:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    752cbc000435:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc00043b:	8b 1c 10             	mov    ebx,DWORD PTR [rax+rdx*1]
    752cbc00043e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    752cbc000442:	41 89 9d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ebx
    752cbc000449:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    752cbc00044e:	41 89 55 38          	mov    DWORD PTR [r13+0x38],edx
    752cbc000452:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    752cbc000457:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc00045b:	48 85 c0             	test   rax,rax
    752cbc00045e:	0f 84 4e 03 00 18    	je     0x752cd40007b2
    752cbc000464:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc00046a:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc00046d:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    752cbc000471:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    752cbc000476:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc00047a:	48 85 c0             	test   rax,rax
    752cbc00047d:	0f 84 b3 03 00 18    	je     0x752cd4000836
    752cbc000483:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    752cbc000488:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc00048e:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc000491:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    752cbc000495:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    752cbc00049a:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc00049e:	48 85 c0             	test   rax,rax
    752cbc0004a1:	0f 84 15 04 00 18    	je     0x752cd40008bc
    752cbc0004a7:	48 8b 54 24 60       	mov    rdx,QWORD PTR [rsp+0x60]
    752cbc0004ac:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc0004b2:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc0004b5:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    752cbc0004b9:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    752cbc0004c0:	00 
    752cbc0004c1:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc0004c5:	48 85 c0             	test   rax,rax
    752cbc0004c8:	0f 84 74 04 00 18    	je     0x752cd4000942
    752cbc0004ce:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0004d4:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    752cbc0004d7:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    752cbc0004db:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    752cbc0004e2:	00 
    752cbc0004e3:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc0004e7:	48 85 c0             	test   rax,rax
    752cbc0004ea:	0f 84 d0 04 00 18    	je     0x752cd40009c0
    752cbc0004f0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc0004f6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc0004f9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    752cbc0004fd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    752cbc000504:	00 
    752cbc000505:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    752cbc000509:	48 85 c0             	test   rax,rax
    752cbc00050c:	0f 84 25 05 00 18    	je     0x752cd4000a37
    752cbc000512:	41 81 e3 ff 0f 00 00 	and    r11d,0xfff
    752cbc000519:	42 8b 04 18          	mov    eax,DWORD PTR [rax+r11*1]
    752cbc00051d:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    752cbc000521:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    752cbc000525:	48 85 c0             	test   rax,rax
    752cbc000528:	0f 84 79 05 00 18    	je     0x752cd4000aa7
    752cbc00052e:	41 81 e1 ff 0f 00 00 	and    r9d,0xfff
    752cbc000535:	42 8b 04 08          	mov    eax,DWORD PTR [rax+r9*1]
    752cbc000539:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    752cbc00053d:	45 89 45 38          	mov    DWORD PTR [r13+0x38],r8d
    752cbc000541:	b1 01                	mov    cl,0x1
    752cbc000543:	41 bc 02 00 00 00    	mov    r12d,0x2
    752cbc000549:	bd 10 00 00 00       	mov    ebp,0x10
    752cbc00054e:	f6 c3 01             	test   bl,0x1
    752cbc000551:	0f 85 ac 05 00 18    	jne    0x752cd4000b03
    752cbc000557:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc00055e:	01 e8                	add    eax,ebp
    752cbc000560:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cbc000567:	39 d0                	cmp    eax,edx
    752cbc000569:	0f 83 91 fa ff 17    	jae    0x752cd4000000
    752cbc00056f:	8d 14 dd 00 00 00 00 	lea    edx,[rbx*8+0x0]
    752cbc000576:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cbc00057c:	39 1c 17             	cmp    DWORD PTR [rdi+rdx*1],ebx
    752cbc00057f:	0f 85 7b fa ff 17    	jne    0x752cd4000000
    752cbc000585:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    752cbc00058c:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc000593:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc00059a:	00 
    752cbc00059b:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    752cbc0005a0:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    752cbc0005a5:	48 81 c4 98 00 00 00 	add    rsp,0x98
    752cbc0005ac:	ff e0                	jmp    rax
    752cbc0005ae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    752cbc0005b5:	40 00 01 00 
    752cbc0005b9:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0005c0:	83 c0 09             	add    eax,0x9
    752cbc0005c3:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc0005ca:	39 c8                	cmp    eax,ecx
    752cbc0005cc:	0f 83 cb ff ff 17    	jae    0x752cd400059d
    752cbc0005d2:	81 bf 00 02 08 00 40 	cmp    DWORD PTR [rdi+0x80200],0x10040
    752cbc0005d9:	00 01 00 
    752cbc0005dc:	0f 85 bb ff ff 17    	jne    0x752cd400059d
    752cbc0005e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    752cbc0005e9:	40 00 01 00 
    752cbc0005ed:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc0005f4:	48 8b 87 08 02 08 00 	mov    rax,QWORD PTR [rdi+0x80208]
    752cbc0005fb:	eb a3                	jmp    0x752cbc0005a0
    752cbc0005fd:	45 89 a5 24 01 00 00 	mov    DWORD PTR [r13+0x124],r12d
    752cbc000604:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc00060b:	b8 28 01 00 00       	mov    eax,0x128
    752cbc000610:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc000615:	48 81 c4 98 00 00 00 	add    rsp,0x98
    752cbc00061c:	c2 08 00             	ret    0x8
