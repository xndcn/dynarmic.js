
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65542-0-128835395795140.bin:     file format binary


Disassembly of section .data:

0000752cd40038c4 <.data>:
    752cd40038c4:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    752cd40038cb:	01 
    752cd40038cc:	58                   	pop    rax
    752cd40038cd:	c2 08 00             	ret    0x8
    752cd40038d0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    752cd40038d7:	0e 00 01 00 
    752cd40038db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40038e2:	02 00 00 00 
    752cd40038e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40038ed:	03 00 00 00 
    752cd40038f1:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40038f8:	57 00 00 
    752cd40038fb:	4c 89 f7             	mov    rdi,r14
    752cd40038fe:	be 04 00 00 01       	mov    esi,0x1000004
    752cd4003903:	ff d0                	call   rax
    752cd4003905:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400390c:	00 
    752cd400390d:	0f 84 b9 f3 ff e7    	je     0x752cbc002ccc
    752cd4003913:	eb 3e                	jmp    0x752cd4003953
    752cd4003915:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    752cd400391c:	10 00 01 00 
    752cd4003920:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4003927:	02 00 00 00 
    752cd400392b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd4003932:	03 00 00 00 
    752cd4003936:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd400393d:	57 00 00 
    752cd4003940:	4c 89 ef             	mov    rdi,r13
    752cd4003943:	ff d0                	call   rax
    752cd4003945:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    752cd400394c:	00 
    752cd400394d:	0f 84 83 f3 ff e7    	je     0x752cbc002cd6
    752cd4003953:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    752cd400395a:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cd4003961:	83 c0 03             	add    eax,0x3
    752cd4003964:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cd400396b:	39 d0                	cmp    eax,edx
    752cd400396d:	73 29                	jae    0x752cd4003998
    752cd400396f:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    752cd4003976:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cd400397c:	39 0c 13             	cmp    DWORD PTR [rbx+rdx*1],ecx
    752cd400397f:	75 17                	jne    0x752cd4003998
    752cd4003981:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cd4003988:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cd400398f:	00 
    752cd4003990:	48 8b 44 13 08       	mov    rax,QWORD PTR [rbx+rdx*1+0x8]
    752cd4003995:	59                   	pop    rcx
    752cd4003996:	ff e0                	jmp    rax
    752cd4003998:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400399f:	02 00 00 00 
    752cd40039a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    752cd40039aa:	03 00 00 00 
    752cd40039ae:	58                   	pop    rax
    752cd40039af:	c2 08 00             	ret    0x8
