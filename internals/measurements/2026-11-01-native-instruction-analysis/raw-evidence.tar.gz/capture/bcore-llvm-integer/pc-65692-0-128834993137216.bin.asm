
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65692-0-128834993137216.bin:     file format binary


Disassembly of section .data:

0000752cbc002640 <.data>:
    752cbc002640:	48 83 ec 18          	sub    rsp,0x18
    752cbc002644:	ba 41 ff fe ff       	mov    edx,0xfffeff41
    752cbc002649:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc002650:	01 d6                	add    esi,edx
    752cbc002652:	b1 01                	mov    cl,0x1
    752cbc002654:	b8 65 01 00 00       	mov    eax,0x165
    752cbc002659:	83 fe dc             	cmp    esi,0xffffffdc
    752cbc00265c:	0f 87 c9 03 00 00    	ja     0x752cbc002a2b
    752cbc002662:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc002669:	83 fa dc             	cmp    edx,0xffffffdc
    752cbc00266c:	0f 87 b9 03 00 00    	ja     0x752cbc002a2b
    752cbc002672:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    752cbc002679:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    752cbc00267d:	f6 c1 03             	test   cl,0x3
    752cbc002680:	0f 85 e5 07 00 18    	jne    0x752cd4002e6b
    752cbc002686:	4d 8b 85 38 01 00 00 	mov    r8,QWORD PTR [r13+0x138]
    752cbc00268d:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    752cbc002694:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    752cbc002698:	48 89 c8             	mov    rax,rcx
    752cbc00269b:	48 c1 e8 0c          	shr    rax,0xc
    752cbc00269f:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc0026a3:	48 85 c0             	test   rax,rax
    752cbc0026a6:	0f 84 16 08 00 18    	je     0x752cd4002ec2
    752cbc0026ac:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0026b2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0026b5:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    752cbc0026b9:	0f 85 48 08 00 18    	jne    0x752cd4002f07
    752cbc0026bf:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    752cbc0026c3:	f6 c3 03             	test   bl,0x3
    752cbc0026c6:	0f 85 93 08 00 18    	jne    0x752cd4002f5f
    752cbc0026cc:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    752cbc0026d0:	48 89 d8             	mov    rax,rbx
    752cbc0026d3:	48 c1 e8 0c          	shr    rax,0xc
    752cbc0026d7:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc0026db:	48 85 c0             	test   rax,rax
    752cbc0026de:	0f 84 df 08 00 18    	je     0x752cd4002fc3
    752cbc0026e4:	89 d9                	mov    ecx,ebx
    752cbc0026e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc0026ec:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc0026ef:	83 c3 04             	add    ebx,0x4
    752cbc0026f2:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    752cbc0026f6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    752cbc0026fa:	0f 85 13 09 00 18    	jne    0x752cd4003013
    752cbc002700:	41 8b 6d 1c          	mov    ebp,DWORD PTR [r13+0x1c]
    752cbc002704:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    752cbc002708:	31 c0                	xor    eax,eax
    752cbc00270a:	89 eb                	mov    ebx,ebp
    752cbc00270c:	ff c3                	inc    ebx
    752cbc00270e:	0f 94 c0             	sete   al
    752cbc002711:	41 89 5d 1c          	mov    DWORD PTR [r13+0x1c],ebx
    752cbc002715:	89 ea                	mov    edx,ebp
    752cbc002717:	c1 ea 1f             	shr    edx,0x1f
    752cbc00271a:	41 89 dc             	mov    r12d,ebx
    752cbc00271d:	41 c1 ec 1f          	shr    r12d,0x1f
    752cbc002721:	c4 c2 68 f2 d4       	andn   edx,edx,r12d
    752cbc002726:	31 f6                	xor    esi,esi
    752cbc002728:	85 db                	test   ebx,ebx
    752cbc00272a:	40 0f 94 c6          	sete   sil
    752cbc00272e:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    752cbc002735:	45 89 a5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r12d
    752cbc00273c:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    752cbc002743:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    752cbc00274a:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    752cbc002751:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    752cbc002758:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    752cbc00275f:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    752cbc002766:	00 
    752cbc002767:	f6 c1 03             	test   cl,0x3
    752cbc00276a:	0f 85 fb 08 00 18    	jne    0x752cd400306b
    752cbc002770:	48 89 c8             	mov    rax,rcx
    752cbc002773:	48 c1 e8 0c          	shr    rax,0xc
    752cbc002777:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc00277b:	48 85 c0             	test   rax,rax
    752cbc00277e:	0f 84 49 09 00 18    	je     0x752cd40030cd
    752cbc002784:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc00278a:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    752cbc00278d:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    752cbc002791:	0f 85 96 09 00 18    	jne    0x752cd400312d
    752cbc002797:	83 c5 fb             	add    ebp,0xfffffffb
    752cbc00279a:	89 e8                	mov    eax,ebp
    752cbc00279c:	c1 e8 1f             	shr    eax,0x1f
    752cbc00279f:	44 09 e0             	or     eax,r12d
    752cbc0027a2:	31 c9                	xor    ecx,ecx
    752cbc0027a4:	83 fb 06             	cmp    ebx,0x6
    752cbc0027a7:	0f 93 c1             	setae  cl
    752cbc0027aa:	31 d2                	xor    edx,edx
    752cbc0027ac:	85 ed                	test   ebp,ebp
    752cbc0027ae:	0f 94 c2             	sete   dl
    752cbc0027b1:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    752cbc0027b8:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    752cbc0027bf:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    752cbc0027c6:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    752cbc0027cd:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    752cbc0027d4:	74 53                	je     0x752cbc002829
    752cbc0027d6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    752cbc0027dd:	84 00 01 00 
    752cbc0027e1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0027e8:	83 c0 07             	add    eax,0x7
    752cbc0027eb:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc0027f2:	39 c8                	cmp    eax,ecx
    752cbc0027f4:	0f 83 55 06 00 18    	jae    0x752cd4002e4f
    752cbc0027fa:	81 bf 20 04 08 00 84 	cmp    DWORD PTR [rdi+0x80420],0x10084
    752cbc002801:	00 01 00 
    752cbc002804:	0f 85 45 06 00 18    	jne    0x752cd4002e4f
    752cbc00280a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    752cbc002811:	84 00 01 00 
    752cbc002815:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc00281c:	48 8b 87 28 04 08 00 	mov    rax,QWORD PTR [rdi+0x80428]
    752cbc002823:	48 83 c4 18          	add    rsp,0x18
    752cbc002827:	ff e0                	jmp    rax
    752cbc002829:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    752cbc002830:	00 
    752cbc002831:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    752cbc002838:	00 
    752cbc002839:	49 8b 40 78          	mov    rax,QWORD PTR [r8+0x78]
    752cbc00283d:	48 85 c0             	test   rax,rax
    752cbc002840:	0f 84 59 09 00 18    	je     0x752cd400319f
    752cbc002846:	c7 40 10 02 00 00 00 	mov    DWORD PTR [rax+0x10],0x2
    752cbc00284d:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    752cbc002851:	0f 85 ac 09 00 18    	jne    0x752cd4003203
    752cbc002857:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    752cbc00285b:	40 f6 c5 03          	test   bpl,0x3
    752cbc00285f:	0f 85 00 0a 00 18    	jne    0x752cd4003265
    752cbc002865:	48 89 e8             	mov    rax,rbp
    752cbc002868:	48 c1 e8 0c          	shr    rax,0xc
    752cbc00286c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc002870:	48 85 c0             	test   rax,rax
    752cbc002873:	0f 84 4d 0a 00 18    	je     0x752cd40032c6
    752cbc002879:	89 e9                	mov    ecx,ebp
    752cbc00287b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc002881:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    752cbc002884:	8d 75 04             	lea    esi,[rbp+0x4]
    752cbc002887:	89 f0                	mov    eax,esi
    752cbc002889:	c1 e8 0c             	shr    eax,0xc
    752cbc00288c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc002890:	48 85 c0             	test   rax,rax
    752cbc002893:	0f 84 8c 0a 00 18    	je     0x752cd4003325
    752cbc002899:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc00289f:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    752cbc0028a3:	8d 75 08             	lea    esi,[rbp+0x8]
    752cbc0028a6:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    752cbc0028aa:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    752cbc0028b1:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc0028b5:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    752cbc0028bc:	00 
    752cbc0028bd:	89 f0                	mov    eax,esi
    752cbc0028bf:	c1 e8 0c             	shr    eax,0xc
    752cbc0028c2:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc0028c6:	48 85 c0             	test   rax,rax
    752cbc0028c9:	0f 84 b8 0a 00 18    	je     0x752cd4003387
    752cbc0028cf:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc0028d5:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc0028d8:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    752cbc0028dc:	8d 75 0c             	lea    esi,[rbp+0xc]
    752cbc0028df:	89 f0                	mov    eax,esi
    752cbc0028e1:	c1 e8 0c             	shr    eax,0xc
    752cbc0028e4:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc0028e8:	48 85 c0             	test   rax,rax
    752cbc0028eb:	0f 84 f1 0a 00 18    	je     0x752cd40033e2
    752cbc0028f1:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc0028f7:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc0028fa:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    752cbc0028fe:	8d 75 10             	lea    esi,[rbp+0x10]
    752cbc002901:	89 f0                	mov    eax,esi
    752cbc002903:	c1 e8 0c             	shr    eax,0xc
    752cbc002906:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc00290a:	48 85 c0             	test   rax,rax
    752cbc00290d:	0f 84 2a 0b 00 18    	je     0x752cd400343d
    752cbc002913:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc002919:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc00291c:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    752cbc002920:	8d 75 14             	lea    esi,[rbp+0x14]
    752cbc002923:	89 f0                	mov    eax,esi
    752cbc002925:	c1 e8 0c             	shr    eax,0xc
    752cbc002928:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc00292c:	48 85 c0             	test   rax,rax
    752cbc00292f:	0f 84 63 0b 00 18    	je     0x752cd4003498
    752cbc002935:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc00293b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc00293e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    752cbc002942:	8d 75 18             	lea    esi,[rbp+0x18]
    752cbc002945:	89 f0                	mov    eax,esi
    752cbc002947:	c1 e8 0c             	shr    eax,0xc
    752cbc00294a:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc00294e:	48 85 c0             	test   rax,rax
    752cbc002951:	0f 84 9c 0b 00 18    	je     0x752cd40034f3
    752cbc002957:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc00295d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc002960:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    752cbc002964:	8d 75 1c             	lea    esi,[rbp+0x1c]
    752cbc002967:	89 f0                	mov    eax,esi
    752cbc002969:	c1 e8 0c             	shr    eax,0xc
    752cbc00296c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc002970:	48 85 c0             	test   rax,rax
    752cbc002973:	0f 84 d5 0b 00 18    	je     0x752cd400354e
    752cbc002979:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc00297f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc002982:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    752cbc002986:	89 ee                	mov    esi,ebp
    752cbc002988:	83 c6 20             	add    esi,0x20
    752cbc00298b:	89 f0                	mov    eax,esi
    752cbc00298d:	c1 e8 0c             	shr    eax,0xc
    752cbc002990:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    752cbc002994:	48 85 c0             	test   rax,rax
    752cbc002997:	0f 84 0c 0c 00 18    	je     0x752cd40035a9
    752cbc00299d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc0029a3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc0029a6:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    752cbc0029aa:	8d 45 24             	lea    eax,[rbp+0x24]
    752cbc0029ad:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    752cbc0029b1:	b1 01                	mov    cl,0x1
    752cbc0029b3:	bb 02 00 00 00       	mov    ebx,0x2
    752cbc0029b8:	bd 0f 00 00 00       	mov    ebp,0xf
    752cbc0029bd:	41 f6 c7 01          	test   r15b,0x1
    752cbc0029c1:	0f 85 33 0c 00 18    	jne    0x752cd40035fa
    752cbc0029c7:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0029ce:	01 e8                	add    eax,ebp
    752cbc0029d0:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cbc0029d7:	39 d0                	cmp    eax,edx
    752cbc0029d9:	0f 83 b4 07 00 18    	jae    0x752cd4003193
    752cbc0029df:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    752cbc0029e6:	00 
    752cbc0029e7:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cbc0029ed:	44 39 3c 17          	cmp    DWORD PTR [rdi+rdx*1],r15d
    752cbc0029f1:	0f 85 9c 07 00 18    	jne    0x752cd4003193
    752cbc0029f7:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    752cbc0029fe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc002a05:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc002a0c:	00 
    752cbc002a0d:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    752cbc002a12:	48 83 c4 18          	add    rsp,0x18
    752cbc002a16:	ff e0                	jmp    rax
    752cbc002a18:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    752cbc002a1f:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc002a26:	b8 28 01 00 00       	mov    eax,0x128
    752cbc002a2b:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc002a30:	48 83 c4 18          	add    rsp,0x18
    752cbc002a34:	c2 08 00             	ret    0x8
