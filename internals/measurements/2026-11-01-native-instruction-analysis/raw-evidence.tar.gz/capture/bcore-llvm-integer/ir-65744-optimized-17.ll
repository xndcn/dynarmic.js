; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100d0(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65805
  %5 = icmp ult i32 %4, -61
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb140 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb140, -65805
  %8 = icmp ult i32 %7, -61
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x000100d0, label %common.ret, !prof !0

insn_0x000100d0:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %10, align 4
  %sp_dec = add i32 %sp, -4
  %11 = getelementptr i8, ptr %cpu, i64 24
  %r = load i32, ptr %11, align 4
  %12 = and i32 %sp, 3
  %.not = icmp eq i32 %12, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x000100d0
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %14, align 4
  tail call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65744, i32 %sp_dec, i32 65536)
  %15 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 296
  %17 = load i8, ptr %16, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000100d0
  %18 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %18 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %19 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %19 to i64
  %20 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %20, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %21 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %22, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %23 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %23, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %did_jump_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %sp_dec1 = add i32 %sp, -8
  %24 = getelementptr i8, ptr %cpu, i64 28
  %r2 = load i32, ptr %24, align 4
  %25 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %25 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11.not = icmp eq ptr %page10, null
  br i1 %page_mapped11.not, label %page_wr_slow6, label %page_wr_fast5, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %26 = getelementptr i8, ptr %cpu, i64 188
  %next_pc141 = load i32, ptr %26, align 4
  br label %chain_exit

page_wr_fast5:                                    ; preds = %page_wr_done
  %27 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %27 to i64
  %28 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %28, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %page_wr_done
  %29 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %30, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %31 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %31, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_wr_done7, label %did_jump_exit13, !prof !0

page_wr_done7:                                    ; preds = %page_wr_slow6, %page_wr_fast5
  store i32 %sp_dec1, ptr %10, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not182 = icmp eq i8 %cec_pending, 0
  br i1 %.not182, label %insn_0x000100d2, label %cec_check, !prof !0

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %32 = getelementptr i8, ptr %cpu, i64 188
  %next_pc143 = load i32, ptr %32, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done7
  %33 = getelementptr i8, ptr %cpu, i64 188
  store i32 65746, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %35, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %36 = getelementptr i8, ptr %cpu, i64 296
  %dj19 = load i8, ptr %36, align 1
  %dj_set20.not = icmp eq i8 %dj19, 0
  br i1 %dj_set20.not, label %insn_0x000100d2, label %did_jump_exit17, !prof !0

did_jump_exit17:                                  ; preds = %cec_check
  %next_pc144 = load i32, ptr %33, align 4
  br label %chain_exit

insn_0x000100d2:                                  ; preds = %page_wr_done7, %cec_check
  %37 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %38, align 4
  %sp1 = add i32 %sp, -12
  %39 = lshr i32 %sp1, 12
  %page_index26 = zext i32 %39 to i64
  %page_slot27 = getelementptr ptr, ptr %page_table, i64 %page_index26
  %page28 = load ptr, ptr %page_slot27, align 8
  %page_mapped29.not = icmp eq ptr %page28, null
  br i1 %page_mapped29.not, label %page_wr_slow24, label %page_wr_fast23, !prof !1

page_wr_fast23:                                   ; preds = %insn_0x000100d2
  %40 = and i32 %sp1, 4095
  %page_offset30 = zext i32 %40 to i64
  %41 = getelementptr i8, ptr %page28, i64 %page_offset30
  store i32 %rets, ptr %41, align 4
  br label %page_wr_done25

page_wr_slow24:                                   ; preds = %insn_0x000100d2
  %42 = getelementptr i8, ptr %cpu, i64 188
  store i32 65746, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %44, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %45 = getelementptr i8, ptr %cpu, i64 296
  %dj33 = load i8, ptr %45, align 1
  %dj_set34.not = icmp eq i8 %dj33, 0
  br i1 %dj_set34.not, label %page_wr_done25, label %did_jump_exit31, !prof !0

page_wr_done25:                                   ; preds = %page_wr_slow24, %page_wr_fast23
  %sp2 = add i32 %sp, -16
  %46 = lshr i32 %sp2, 12
  %page_index40 = zext i32 %46 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43.not = icmp eq ptr %page42, null
  br i1 %page_mapped43.not, label %page_wr_slow38, label %page_wr_fast37, !prof !1

did_jump_exit31:                                  ; preds = %page_wr_slow24
  %next_pc146 = load i32, ptr %42, align 4
  br label %chain_exit

page_wr_fast37:                                   ; preds = %page_wr_done25
  %47 = and i32 %sp2, 4095
  %page_offset44 = zext i32 %47 to i64
  %48 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %fp, ptr %48, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %page_wr_done25
  %49 = getelementptr i8, ptr %cpu, i64 188
  store i32 65746, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %51, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %52 = getelementptr i8, ptr %cpu, i64 296
  %dj47 = load i8, ptr %52, align 1
  %dj_set48.not = icmp eq i8 %dj47, 0
  br i1 %dj_set48.not, label %page_wr_done39, label %did_jump_exit45, !prof !0

page_wr_done39:                                   ; preds = %page_wr_slow38, %page_wr_fast37
  store i32 %sp2, ptr %38, align 4
  store i32 %sp2, ptr %10, align 4
  %cec_pending49 = load i8, ptr %cec_pending_flag, align 1
  %.not185 = icmp eq i8 %cec_pending49, 0
  br i1 %.not185, label %insn_0x000100d6, label %cec_check50, !prof !0

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %next_pc148 = load i32, ptr %49, align 4
  br label %chain_exit

cec_check50:                                      ; preds = %page_wr_done39
  %53 = getelementptr i8, ptr %cpu, i64 188
  store i32 65750, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %55, align 4
  tail call void @cec_check_pending(ptr %cpu)
  %56 = getelementptr i8, ptr %cpu, i64 296
  %dj54 = load i8, ptr %56, align 1
  %dj_set55.not = icmp eq i8 %dj54, 0
  br i1 %dj_set55.not, label %insn_0x000100d6, label %did_jump_exit52, !prof !0

did_jump_exit52:                                  ; preds = %cec_check50
  %next_pc149 = load i32, ptr %53, align 4
  br label %chain_exit

insn_0x000100d6:                                  ; preds = %page_wr_done39, %cec_check50
  %rx = load i32, ptr %cpu, align 4
  %57 = icmp eq i32 %rx, 0
  %az = zext i1 %57 to i32
  %flgn = lshr i32 %rx, 31
  %58 = getelementptr i8, ptr %cpu, i64 276
  store i32 %az, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 232
  store i32 %flgn, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 236
  store i32 1, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 240
  store i32 1, ptr %62, align 4
  br i1 %57, label %brt_taken, label %insn_0x000100da

brt_taken:                                        ; preds = %insn_0x000100d6
  %63 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %64, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %65 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %65 monotonic, align 4, !range !2
  %66 = icmp ult i32 %chain_total, %chain_budget
  br i1 %66, label %chain_go, label %chain_leave150, !prof !0

insn_0x000100da:                                  ; preds = %insn_0x000100d6
  %67 = getelementptr i8, ptr %cpu, i64 8
  store i32 1664525, ptr %11, align 4
  store i32 1013904223, ptr %24, align 4
  %68 = getelementptr i8, ptr %cpu, i64 4
  %a = load i32, ptr %68, align 4
  %mul = mul i32 %a, 1664525
  %add32 = add i32 %mul, 1013904223
  %flgs60 = lshr i32 %mul, 31
  %flgn61 = lshr i32 %add32, 31
  %69 = xor i32 %flgs60, -1
  %70 = and i32 %flgn61, %69
  %71 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %71, align 4
  %72 = or i32 %vs_cur, %70
  %73 = getelementptr i8, ptr %cpu, i64 248
  %74 = getelementptr i8, ptr %cpu, i64 252
  %lsr32 = lshr i32 %add32, 13
  %75 = getelementptr i8, ptr %cpu, i64 12
  %xor32 = xor i32 %lsr32, %add32
  %lsl32 = shl i32 %xor32, 7
  store i32 %lsl32, ptr %75, align 4
  %lsr = lshr i32 %add32, 25
  store i32 1, ptr %67, align 4
  store i32 %72, ptr %71, align 4
  %or32 = or i32 %lsl32, %lsr
  store i32 %or32, ptr %68, align 4
  store i32 0, ptr %73, align 4
  store i32 0, ptr %74, align 4
  %76 = icmp eq i32 %rx, 1
  %cc = zext i1 %76 to i32
  store i32 %cc, ptr %58, align 4
  store i32 %cc, ptr %59, align 4
  store i32 0, ptr %60, align 4
  store i32 1, ptr %61, align 4
  store i32 1, ptr %62, align 4
  br i1 %76, label %data_aligned79, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x000100da
  %77 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets153 = load i32, ptr %78, align 4
  %chain_total154 = add nuw i32 %chain_packets153, 19
  %79 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget155 = load atomic i32, ptr %79 monotonic, align 4, !range !2
  %80 = icmp ult i32 %chain_total154, %chain_budget155
  br i1 %80, label %chain_go151, label %chain_leave152, !prof !0

data_aligned79:                                   ; preds = %insn_0x000100da
  %page82 = load ptr, ptr %page_slot41, align 8
  %page_mapped83.not = icmp eq ptr %page82, null
  br i1 %page_mapped83.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %data_aligned79
  %81 = and i32 %sp2, 4095
  %page_offset84 = zext i32 %81 to i64
  %82 = getelementptr i8, ptr %page82, i64 %page_offset84
  %page_val = load i32, ptr %82, align 4
  br label %data_aligned91

page_slow:                                        ; preds = %data_aligned79
  %83 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 308
  store i32 20, ptr %85, align 4
  %86 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %87 = getelementptr i8, ptr %cpu, i64 296
  %dj87 = load i8, ptr %87, align 1
  %dj_set88.not = icmp eq i8 %dj87, 0
  br i1 %dj_set88.not, label %data_aligned91, label %did_jump_exit85, !prof !0

did_jump_exit85:                                  ; preds = %page_slow
  %next_pc161 = load i32, ptr %83, align 4
  br label %chain_exit

data_aligned91:                                   ; preds = %page_fast, %page_slow
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %86, %page_slow ]
  %page97 = load ptr, ptr %page_slot27, align 8
  %page_mapped98.not = icmp eq ptr %page97, null
  br i1 %page_mapped98.not, label %page_slow93, label %page_fast92, !prof !1

page_fast92:                                      ; preds = %data_aligned91
  %88 = and i32 %sp1, 4095
  %page_offset99 = zext i32 %88 to i64
  %89 = getelementptr i8, ptr %page97, i64 %page_offset99
  %page_val100 = load i32, ptr %89, align 4
  br label %page_done94

page_slow93:                                      ; preds = %data_aligned91
  %90 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 308
  store i32 20, ptr %92, align 4
  %93 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %94 = getelementptr i8, ptr %cpu, i64 296
  %dj103 = load i8, ptr %94, align 1
  %dj_set104.not = icmp eq i8 %dj103, 0
  br i1 %dj_set104.not, label %page_done94, label %did_jump_exit101, !prof !0

page_done94:                                      ; preds = %page_slow93, %page_fast92
  %mem_val105 = phi i32 [ %page_val100, %page_fast92 ], [ %93, %page_slow93 ]
  store i32 %mem_val, ptr %38, align 4
  store i32 %mem_val105, ptr %37, align 4
  store i32 %sp_dec1, ptr %10, align 4
  store i32 %or32, ptr %cpu, align 4
  %page114 = load ptr, ptr %page_slot9, align 8
  %page_mapped115.not = icmp eq ptr %page114, null
  br i1 %page_mapped115.not, label %page_slow110, label %page_fast109, !prof !1

did_jump_exit101:                                 ; preds = %page_slow93
  %next_pc163 = load i32, ptr %90, align 4
  br label %chain_exit

page_fast109:                                     ; preds = %page_done94
  %95 = and i32 %sp_dec1, 4095
  %page_offset116 = zext i32 %95 to i64
  %96 = getelementptr i8, ptr %page114, i64 %page_offset116
  %page_val117 = load i32, ptr %96, align 4
  br label %page_done111

page_slow110:                                     ; preds = %page_done94
  %97 = getelementptr i8, ptr %cpu, i64 188
  store i32 65802, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 308
  store i32 22, ptr %99, align 4
  %100 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec1)
  %101 = getelementptr i8, ptr %cpu, i64 296
  %dj120 = load i8, ptr %101, align 1
  %dj_set121.not = icmp eq i8 %dj120, 0
  br i1 %dj_set121.not, label %page_done111, label %did_jump_exit118, !prof !0

page_done111:                                     ; preds = %page_slow110, %page_fast109
  %mem_val122 = phi i32 [ %page_val117, %page_fast109 ], [ %100, %page_slow110 ]
  store i32 %mem_val122, ptr %24, align 4
  %page130 = load ptr, ptr %page_slot, align 8
  %page_mapped131.not = icmp eq ptr %page130, null
  br i1 %page_mapped131.not, label %page_slow126, label %page_fast125, !prof !1

did_jump_exit118:                                 ; preds = %page_slow110
  %next_pc165 = load i32, ptr %97, align 4
  br label %chain_exit

page_fast125:                                     ; preds = %page_done111
  %102 = and i32 %sp_dec, 4095
  %page_offset132 = zext i32 %102 to i64
  %103 = getelementptr i8, ptr %page130, i64 %page_offset132
  %page_val133 = load i32, ptr %103, align 4
  br label %page_done127

page_slow126:                                     ; preds = %page_done111
  %104 = getelementptr i8, ptr %cpu, i64 188
  store i32 65802, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 308
  store i32 22, ptr %106, align 4
  %107 = tail call i32 @mem_read32(ptr %mem, i32 %sp_dec)
  %108 = getelementptr i8, ptr %cpu, i64 296
  %dj136 = load i8, ptr %108, align 1
  %dj_set137.not = icmp eq i8 %dj136, 0
  br i1 %dj_set137.not, label %page_done127, label %did_jump_exit134, !prof !0

page_done127:                                     ; preds = %page_slow126, %page_fast125
  %mem_val138 = phi i32 [ %page_val133, %page_fast125 ], [ %107, %page_slow126 ]
  store i32 %mem_val138, ptr %11, align 4
  store i32 %sp, ptr %10, align 4
  %lsb = and i32 %mem_val105, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit134:                                 ; preds = %page_slow126
  %next_pc167 = load i32, ptr %104, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done127
  %109 = getelementptr i8, ptr %cpu, i64 188
  store i32 65804, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i64 308
  store i32 23, ptr %111, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc168 = load i32, ptr %109, align 4
  %112 = getelementptr i8, ptr %cpu, i64 296
  %113 = load i8, ptr %112, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave150, %chain_leave152, %chain_leave173
  %tail170.sink = phi i32 [ %tail170, %chain_leave173 ], [ 2, %chain_leave152 ], [ 2, %chain_leave150 ]
  %packets.sink = phi i32 [ %packets, %chain_leave173 ], [ 19, %chain_leave152 ], [ 4, %chain_leave150 ]
  %tail172.sink.ph = phi i8 [ %tail172, %chain_leave173 ], [ 1, %chain_leave152 ], [ 1, %chain_leave150 ]
  %114 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail170.sink, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %115, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink186 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail172.sink = phi i8 [ 1, %entry ], [ %tail172.sink.ph, %common.ret.sink.split ]
  %116 = getelementptr i8, ptr %cpu, i64 %.sink186
  store i8 %tail172.sink, ptr %116, align 1
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526368
  %slot_pc = load i32, ptr %chain_slot, align 4
  %117 = icmp eq i32 %slot_pc, 65796
  br i1 %117, label %chain_hit, label %chain_leave150, !prof !0

chain_leave150:                                   ; preds = %chain_go, %brt_taken
  store i32 65796, ptr %63, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65796, ptr %63, align 4
  store i32 %chain_total, ptr %64, align 4
  %118 = getelementptr i8, ptr %chain_table, i64 526376
  %chain_fn = load ptr, ptr %118, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go151:                                      ; preds = %brcc_taken
  %chain_slot156 = getelementptr i8, ptr %chain_table, i64 526176
  %slot_pc157 = load i32, ptr %chain_slot156, align 4
  %119 = icmp eq i32 %slot_pc157, 65772
  br i1 %119, label %chain_hit158, label %chain_leave152, !prof !0

chain_leave152:                                   ; preds = %chain_go151, %brcc_taken
  store i32 65772, ptr %77, align 4
  br label %common.ret.sink.split

chain_hit158:                                     ; preds = %chain_go151
  store i32 65772, ptr %77, align 4
  store i32 %chain_total154, ptr %78, align 4
  %120 = getelementptr i8, ptr %chain_table, i64 526184
  %chain_fn159 = load ptr, ptr %120, align 8
  musttail call swifttailcc void %chain_fn159(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done127, %jump_misalign, %did_jump_exit134, %did_jump_exit118, %did_jump_exit101, %did_jump_exit85, %did_jump_exit52, %did_jump_exit45, %did_jump_exit31, %did_jump_exit17, %did_jump_exit13, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit17 ], [ 2, %did_jump_exit31 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit52 ], [ 20, %did_jump_exit85 ], [ 20, %did_jump_exit101 ], [ 22, %did_jump_exit118 ], [ 22, %did_jump_exit134 ], [ 23, %jump_misalign ], [ 23, %page_done127 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc141, %did_jump_exit ], [ %next_pc143, %did_jump_exit13 ], [ %next_pc144, %did_jump_exit17 ], [ %next_pc146, %did_jump_exit31 ], [ %next_pc148, %did_jump_exit45 ], [ %next_pc149, %did_jump_exit52 ], [ %next_pc161, %did_jump_exit85 ], [ %next_pc163, %did_jump_exit101 ], [ %next_pc165, %did_jump_exit118 ], [ %next_pc167, %did_jump_exit134 ], [ %next_pc168, %jump_misalign ], [ %mem_val105, %page_done127 ]
  %tail170 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit13 ], [ 2, %did_jump_exit17 ], [ 4, %did_jump_exit31 ], [ 4, %did_jump_exit45 ], [ 4, %did_jump_exit52 ], [ 4, %did_jump_exit85 ], [ 4, %did_jump_exit101 ], [ 2, %did_jump_exit118 ], [ 2, %did_jump_exit134 ], [ 2, %jump_misalign ], [ 2, %page_done127 ]
  %tail172 = phi i8 [ %17, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj15, %did_jump_exit13 ], [ %dj19, %did_jump_exit17 ], [ %dj33, %did_jump_exit31 ], [ %dj47, %did_jump_exit45 ], [ %dj54, %did_jump_exit52 ], [ %dj87, %did_jump_exit85 ], [ %dj103, %did_jump_exit101 ], [ %dj120, %did_jump_exit118 ], [ %dj136, %did_jump_exit134 ], [ %113, %jump_misalign ], [ 1, %page_done127 ]
  %121 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets174 = load i32, ptr %121, align 4
  %chain_total175 = add nuw i32 %chain_packets174, %packets
  %122 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget176 = load atomic i32, ptr %122 monotonic, align 4, !range !2
  %123 = icmp ult i32 %chain_total175, %chain_budget176
  br i1 %123, label %chain_lookup, label %chain_leave173, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %124 = shl i32 %tail, 3
  %125 = and i32 %124, 1048560
  %126 = zext i32 %125 to i64
  %chain_slot177 = getelementptr i8, ptr %chain_table, i64 %126
  %slot_pc178 = load i32, ptr %chain_slot177, align 4
  %127 = icmp eq i32 %slot_pc178, %tail
  br i1 %127, label %chain_hit179, label %chain_leave173, !prof !0

chain_leave173:                                   ; preds = %chain_lookup, %chain_exit
  %128 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %128, align 4
  br label %common.ret.sink.split

chain_hit179:                                     ; preds = %chain_lookup
  %129 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %129, align 4
  store i32 %chain_total175, ptr %121, align 4
  %130 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %130, align 1
  %131 = getelementptr i8, ptr %chain_slot177, i64 8
  %chain_fn180 = load ptr, ptr %131, align 8
  musttail call swifttailcc void %chain_fn180(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
