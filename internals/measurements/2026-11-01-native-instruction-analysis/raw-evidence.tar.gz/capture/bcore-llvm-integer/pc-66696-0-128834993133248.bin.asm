
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66696-0-128834993133248.bin:     file format binary


Disassembly of section .data:

0000752cbc0016c0 <.data>:
    752cbc0016c0:	50                   	push   rax
    752cbc0016c1:	b8 5f fb fe ff       	mov    eax,0xfffefb5f
    752cbc0016c6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    752cbc0016cd:	01 c1                	add    ecx,eax
    752cbc0016cf:	83 f9 e6             	cmp    ecx,0xffffffe6
    752cbc0016d2:	0f 87 2f 0f 00 18    	ja     0x752cd4002607
    752cbc0016d8:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    752cbc0016df:	83 f8 e6             	cmp    eax,0xffffffe6
    752cbc0016e2:	0f 87 1f 0f 00 18    	ja     0x752cd4002607
    752cbc0016e8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    752cbc0016ef:	4d 8b bd 50 01 00 00 	mov    r15,QWORD PTR [r13+0x150]
    752cbc0016f6:	41 c7 45 28 f4 12 01 	mov    DWORD PTR [r13+0x28],0x112f4
    752cbc0016fd:	00 
    752cbc0016fe:	48 8b 85 88 00 00 00 	mov    rax,QWORD PTR [rbp+0x88]
    752cbc001705:	48 85 c0             	test   rax,rax
    752cbc001708:	0f 84 05 0f 00 18    	je     0x752cd4002613
    752cbc00170e:	8b 80 f4 02 00 00    	mov    eax,DWORD PTR [rax+0x2f4]
    752cbc001714:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    752cbc001718:	41 c7 45 28 f8 12 01 	mov    DWORD PTR [r13+0x28],0x112f8
    752cbc00171f:	00 
    752cbc001720:	48 8b 85 88 00 00 00 	mov    rax,QWORD PTR [rbp+0x88]
    752cbc001727:	48 85 c0             	test   rax,rax
    752cbc00172a:	0f 84 35 0f 00 18    	je     0x752cd4002665
    752cbc001730:	8b 80 f8 02 00 00    	mov    eax,DWORD PTR [rax+0x2f8]
    752cbc001736:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    752cbc00173a:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    752cbc00173e:	f6 c3 03             	test   bl,0x3
    752cbc001741:	0f 85 6d 0f 00 18    	jne    0x752cd40026b4
    752cbc001747:	48 89 d8             	mov    rax,rbx
    752cbc00174a:	48 c1 e8 0c          	shr    rax,0xc
    752cbc00174e:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    752cbc001753:	48 85 c0             	test   rax,rax
    752cbc001756:	0f 84 ec 0f 00 18    	je     0x752cd4002748
    752cbc00175c:	89 d9                	mov    ecx,ebx
    752cbc00175e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc001764:	44 8b 24 08          	mov    r12d,DWORD PTR [rax+rcx*1]
    752cbc001768:	8d 73 04             	lea    esi,[rbx+0x4]
    752cbc00176b:	89 f0                	mov    eax,esi
    752cbc00176d:	c1 e8 0c             	shr    eax,0xc
    752cbc001770:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    752cbc001775:	48 85 c0             	test   rax,rax
    752cbc001778:	0f 84 12 10 00 18    	je     0x752cd4002790
    752cbc00177e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc001784:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc001787:	83 c3 08             	add    ebx,0x8
    752cbc00178a:	45 89 65 3c          	mov    DWORD PTR [r13+0x3c],r12d
    752cbc00178e:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    752cbc001795:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    752cbc001799:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    752cbc0017a0:	d0 00 01 00 
    752cbc0017a4:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0017ab:	83 c0 08             	add    eax,0x8
    752cbc0017ae:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc0017b5:	39 c8                	cmp    eax,ecx
    752cbc0017b7:	73 29                	jae    0x752cbc0017e2
    752cbc0017b9:	41 81 bf 80 06 08 00 	cmp    DWORD PTR [r15+0x80680],0x100d0
    752cbc0017c0:	d0 00 01 00 
    752cbc0017c4:	75 1c                	jne    0x752cbc0017e2
    752cbc0017c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    752cbc0017cd:	d0 00 01 00 
    752cbc0017d1:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc0017d8:	49 8b 87 88 06 08 00 	mov    rax,QWORD PTR [r15+0x80688]
    752cbc0017df:	59                   	pop    rcx
    752cbc0017e0:	ff e0                	jmp    rax
    752cbc0017e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    752cbc0017e9:	d0 00 01 00 
    752cbc0017ed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cbc0017f4:	04 00 00 00 
    752cbc0017f8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    752cbc0017ff:	08 00 00 00 
    752cbc001803:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    752cbc00180a:	01 
    752cbc00180b:	58                   	pop    rax
    752cbc00180c:	c2 08 00             	ret    0x8
