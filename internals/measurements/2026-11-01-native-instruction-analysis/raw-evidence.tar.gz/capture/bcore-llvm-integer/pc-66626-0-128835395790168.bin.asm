
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66626-0-128835395790168.bin:     file format binary


Disassembly of section .data:

0000752cd4002558 <.data>:
    752cd4002558:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044c
    752cd400255f:	4c 04 01 00 
    752cd4002563:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400256a:	02 00 00 00 
    752cd400256e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    752cd4002575:	04 00 00 00 
    752cd4002579:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4002580:	57 00 00 
    752cd4002583:	4c 89 f7             	mov    rdi,r14
    752cd4002586:	ff d0                	call   rax
    752cd4002588:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400258f:	00 
    752cd4002590:	84 c9                	test   cl,cl
    752cd4002592:	0f 84 97 f0 ff e7    	je     0x752cbc00162f
    752cd4002598:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd400259f:	bd 04 00 00 00       	mov    ebp,0x4
    752cd40025a4:	e9 99 f0 ff e7       	jmp    0x752cbc001642
    752cd40025a9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1044e
    752cd40025b0:	4e 04 01 00 
    752cd40025b4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40025bb:	02 00 00 00 
    752cd40025bf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    752cd40025c6:	05 00 00 00 
    752cd40025ca:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd40025d1:	57 00 00 
    752cd40025d4:	4c 89 ef             	mov    rdi,r13
    752cd40025d7:	be 2a 00 00 00       	mov    esi,0x2a
    752cd40025dc:	4c 89 f2             	mov    rdx,r14
    752cd40025df:	ff d0                	call   rax
    752cd40025e1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    752cd40025e8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40025ef:	00 
    752cd40025f0:	e9 4d f0 ff e7       	jmp    0x752cbc001642
