
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66344-0-128834993129920.bin:     file format binary


Disassembly of section .data:

0000752cbc0009c0 <.data>:
    752cbc0009c0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    752cbc0009c7:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    752cbc0009cc:	ba 91 fc fe ff       	mov    edx,0xfffefc91
    752cbc0009d1:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    752cbc0009d8:	01 d6                	add    esi,edx
    752cbc0009da:	b1 01                	mov    cl,0x1
    752cbc0009dc:	b8 65 01 00 00       	mov    eax,0x165
    752cbc0009e1:	83 fe b8             	cmp    esi,0xffffffb8
    752cbc0009e4:	0f 87 9b 06 00 00    	ja     0x752cbc001085
    752cbc0009ea:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    752cbc0009f1:	83 fa b8             	cmp    edx,0xffffffb8
    752cbc0009f4:	0f 87 8b 06 00 00    	ja     0x752cbc001085
    752cbc0009fa:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    752cbc000a01:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    752cbc000a06:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    752cbc000a0a:	45 8d 51 fc          	lea    r10d,[r9-0x4]
    752cbc000a0e:	41 f6 c1 03          	test   r9b,0x3
    752cbc000a12:	0f 85 47 0a 00 18    	jne    0x752cd400145f
    752cbc000a18:	4d 8b 9d 38 01 00 00 	mov    r11,QWORD PTR [r13+0x138]
    752cbc000a1f:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    752cbc000a26:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    752cbc000a2b:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    752cbc000a2f:	44 89 d7             	mov    edi,r10d
    752cbc000a32:	c1 ef 0c             	shr    edi,0xc
    752cbc000a35:	49 8b 04 fb          	mov    rax,QWORD PTR [r11+rdi*8]
    752cbc000a39:	48 85 c0             	test   rax,rax
    752cbc000a3c:	0f 84 73 0a 00 18    	je     0x752cd40014b5
    752cbc000a42:	44 89 d1             	mov    ecx,r10d
    752cbc000a45:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000a4b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000a4e:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    752cbc000a52:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    752cbc000a56:	89 e8                	mov    eax,ebp
    752cbc000a58:	c1 e8 0c             	shr    eax,0xc
    752cbc000a5b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    752cbc000a62:	00 
    752cbc000a63:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000a67:	48 85 c0             	test   rax,rax
    752cbc000a6a:	0f 84 a0 0a 00 18    	je     0x752cd4001510
    752cbc000a70:	89 e9                	mov    ecx,ebp
    752cbc000a72:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000a78:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000a7b:	41 8d 71 f4          	lea    esi,[r9-0xc]
    752cbc000a7f:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    752cbc000a83:	89 f0                	mov    eax,esi
    752cbc000a85:	c1 e8 0c             	shr    eax,0xc
    752cbc000a88:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    752cbc000a8d:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000a91:	48 85 c0             	test   rax,rax
    752cbc000a94:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    752cbc000a99:	0f 84 d5 0a 00 18    	je     0x752cd4001574
    752cbc000a9f:	48 89 f1             	mov    rcx,rsi
    752cbc000aa2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000aa8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000aab:	41 8d 71 f0          	lea    esi,[r9-0x10]
    752cbc000aaf:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    752cbc000ab3:	89 f0                	mov    eax,esi
    752cbc000ab5:	c1 e8 0c             	shr    eax,0xc
    752cbc000ab8:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    752cbc000abd:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000ac1:	48 85 c0             	test   rax,rax
    752cbc000ac4:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    752cbc000ac9:	0f 84 07 0b 00 18    	je     0x752cd40015d6
    752cbc000acf:	48 89 f1             	mov    rcx,rsi
    752cbc000ad2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000ad8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000adb:	41 8d 71 ec          	lea    esi,[r9-0x14]
    752cbc000adf:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    752cbc000ae3:	89 f0                	mov    eax,esi
    752cbc000ae5:	c1 e8 0c             	shr    eax,0xc
    752cbc000ae8:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    752cbc000aed:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000af1:	48 85 c0             	test   rax,rax
    752cbc000af4:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    752cbc000af9:	0f 84 39 0b 00 18    	je     0x752cd4001638
    752cbc000aff:	89 f1                	mov    ecx,esi
    752cbc000b01:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000b07:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000b0a:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc000b0e:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cbc000b13:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    752cbc000b17:	0f 85 7f 0b 00 18    	jne    0x752cd400169c
    752cbc000b1d:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    752cbc000b21:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    752cbc000b28:	41 8d 71 e8          	lea    esi,[r9-0x18]
    752cbc000b2c:	89 f0                	mov    eax,esi
    752cbc000b2e:	c1 e8 0c             	shr    eax,0xc
    752cbc000b31:	49 89 c6             	mov    r14,rax
    752cbc000b34:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000b38:	48 85 c0             	test   rax,rax
    752cbc000b3b:	48 89 74 24 48       	mov    QWORD PTR [rsp+0x48],rsi
    752cbc000b40:	0f 84 cd 0b 00 18    	je     0x752cd4001713
    752cbc000b46:	48 89 f1             	mov    rcx,rsi
    752cbc000b49:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000b4f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    752cbc000b52:	45 8d 61 e4          	lea    r12d,[r9-0x1c]
    752cbc000b56:	45 89 e7             	mov    r15d,r12d
    752cbc000b59:	41 c1 ef 0c          	shr    r15d,0xc
    752cbc000b5d:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    752cbc000b61:	48 85 c0             	test   rax,rax
    752cbc000b64:	0f 84 1f 0c 00 18    	je     0x752cd4001789
    752cbc000b6a:	44 89 e1             	mov    ecx,r12d
    752cbc000b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    752cbc000b73:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    752cbc000b76:	45 89 65 3c          	mov    DWORD PTR [r13+0x3c],r12d
    752cbc000b7a:	45 89 65 38          	mov    DWORD PTR [r13+0x38],r12d
    752cbc000b7e:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    752cbc000b82:	0f 85 7d 0c 00 18    	jne    0x752cd4001805
    752cbc000b88:	41 8b 5d 00          	mov    ebx,DWORD PTR [r13+0x0]
    752cbc000b8c:	31 c0                	xor    eax,eax
    752cbc000b8e:	31 c9                	xor    ecx,ecx
    752cbc000b90:	31 d2                	xor    edx,edx
    752cbc000b92:	31 f6                	xor    esi,esi
    752cbc000b94:	83 fb 04             	cmp    ebx,0x4
    752cbc000b97:	0f 94 c0             	sete   al
    752cbc000b9a:	0f 92 c1             	setb   cl
    752cbc000b9d:	40 0f 96 c6          	setbe  sil
    752cbc000ba1:	0f 93 c2             	setae  dl
    752cbc000ba4:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    752cbc000bab:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    752cbc000bb2:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    752cbc000bb9:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    752cbc000bc0:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    752cbc000bc7:	0f 87 10 03 00 00    	ja     0x752cbc000edd
    752cbc000bcd:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cbc000bd2:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
    752cbc000bd6:	89 e8                	mov    eax,ebp
    752cbc000bd8:	c1 e8 1f             	shr    eax,0x1f
    752cbc000bdb:	31 c9                	xor    ecx,ecx
    752cbc000bdd:	85 ed                	test   ebp,ebp
    752cbc000bdf:	0f 94 c1             	sete   cl
    752cbc000be2:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    752cbc000be9:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    752cbc000bf0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    752cbc000bf7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    752cbc000bfe:	00 00 00 
    752cbc000c01:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    752cbc000c08:	0f 84 34 03 00 00    	je     0x752cbc000f42
    752cbc000c0e:	41 c7 45 0c 00 48 e8 	mov    DWORD PTR [r13+0xc],0x1e84800
    752cbc000c15:	01 
    752cbc000c16:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    752cbc000c1d:	00 00 00 00 
    752cbc000c21:	31 c0                	xor    eax,eax
    752cbc000c23:	31 c9                	xor    ecx,ecx
    752cbc000c25:	31 d2                	xor    edx,edx
    752cbc000c27:	31 f6                	xor    esi,esi
    752cbc000c29:	81 fd 00 48 e8 01    	cmp    ebp,0x1e84800
    752cbc000c2f:	0f 94 c0             	sete   al
    752cbc000c32:	0f 92 c1             	setb   cl
    752cbc000c35:	40 0f 96 c6          	setbe  sil
    752cbc000c39:	0f 93 c2             	setae  dl
    752cbc000c3c:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    752cbc000c43:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    752cbc000c4a:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    752cbc000c51:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    752cbc000c58:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    752cbc000c5f:	0f 87 17 03 00 00    	ja     0x752cbc000f7c
    752cbc000c65:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    752cbc000c6c:	00 
    752cbc000c6d:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    752cbc000c74:	48 85 c0             	test   rax,rax
    752cbc000c77:	0f 84 28 0c 00 18    	je     0x752cd40018a5
    752cbc000c7d:	89 98 f0 02 00 00    	mov    DWORD PTR [rax+0x2f0],ebx
    752cbc000c83:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cbc000c88:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    752cbc000c8b:	0f 85 8c 0c 00 18    	jne    0x752cd400191d
    752cbc000c91:	41 c7 45 28 f4 12 01 	mov    DWORD PTR [r13+0x28],0x112f4
    752cbc000c98:	00 
    752cbc000c99:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    752cbc000ca0:	48 85 c0             	test   rax,rax
    752cbc000ca3:	0f 84 f7 0c 00 18    	je     0x752cd40019a0
    752cbc000ca9:	89 a8 f4 02 00 00    	mov    DWORD PTR [rax+0x2f4],ebp
    752cbc000caf:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    752cbc000cb2:	0f 85 5c 0d 00 18    	jne    0x752cd4001a14
    752cbc000cb8:	41 c7 45 28 f8 12 01 	mov    DWORD PTR [r13+0x28],0x112f8
    752cbc000cbf:	00 
    752cbc000cc0:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    752cbc000cc4:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    752cbc000ccb:	48 85 c0             	test   rax,rax
    752cbc000cce:	0f 84 bf 0d 00 18    	je     0x752cd4001a93
    752cbc000cd4:	89 90 f8 02 00 00    	mov    DWORD PTR [rax+0x2f8],edx
    752cbc000cda:	48 89 fd             	mov    rbp,rdi
    752cbc000cdd:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    752cbc000ce0:	0f 85 1f 0e 00 18    	jne    0x752cd4001b05
    752cbc000ce6:	8d 4b fe             	lea    ecx,[rbx-0x2]
    752cbc000ce9:	89 ca                	mov    edx,ecx
    752cbc000ceb:	c1 ea 1f             	shr    edx,0x1f
    752cbc000cee:	89 d8                	mov    eax,ebx
    752cbc000cf0:	c1 e8 1f             	shr    eax,0x1f
    752cbc000cf3:	09 c2                	or     edx,eax
    752cbc000cf5:	31 f6                	xor    esi,esi
    752cbc000cf7:	83 fb 02             	cmp    ebx,0x2
    752cbc000cfa:	40 0f 93 c6          	setae  sil
    752cbc000cfe:	31 ff                	xor    edi,edi
    752cbc000d00:	85 c9                	test   ecx,ecx
    752cbc000d02:	40 0f 94 c7          	sete   dil
    752cbc000d06:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    752cbc000d0d:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    752cbc000d14:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    752cbc000d1b:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    752cbc000d22:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    752cbc000d29:	0f 84 8b 02 00 00    	je     0x752cbc000fba
    752cbc000d2f:	8d 4b fd             	lea    ecx,[rbx-0x3]
    752cbc000d32:	89 ca                	mov    edx,ecx
    752cbc000d34:	c1 ea 1f             	shr    edx,0x1f
    752cbc000d37:	09 c2                	or     edx,eax
    752cbc000d39:	31 c0                	xor    eax,eax
    752cbc000d3b:	83 fb 03             	cmp    ebx,0x3
    752cbc000d3e:	0f 93 c0             	setae  al
    752cbc000d41:	31 f6                	xor    esi,esi
    752cbc000d43:	85 c9                	test   ecx,ecx
    752cbc000d45:	40 0f 94 c6          	sete   sil
    752cbc000d49:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    752cbc000d50:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    752cbc000d57:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    752cbc000d5e:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    752cbc000d65:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    752cbc000d6c:	0f 84 a4 02 00 00    	je     0x752cbc001016
    752cbc000d72:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    752cbc000d79:	00 
    752cbc000d7a:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    752cbc000d7e:	48 85 c0             	test   rax,rax
    752cbc000d81:	0f 84 2c 0e 00 18    	je     0x752cd4001bb3
    752cbc000d87:	41 81 e4 ff 0f 00 00 	and    r12d,0xfff
    752cbc000d8e:	42 8b 1c 20          	mov    ebx,DWORD PTR [rax+r12*1]
    752cbc000d92:	48 89 e9             	mov    rcx,rbp
    752cbc000d95:	4b 8b 04 f3          	mov    rax,QWORD PTR [r11+r14*8]
    752cbc000d99:	48 85 c0             	test   rax,rax
    752cbc000d9c:	0f 84 77 0e 00 18    	je     0x752cd4001c19
    752cbc000da2:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    752cbc000da7:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc000dad:	8b 3c 10             	mov    edi,DWORD PTR [rax+rdx*1]
    752cbc000db0:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    752cbc000db4:	41 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],edi
    752cbc000dbb:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    752cbc000dc0:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    752cbc000dc4:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    752cbc000dc9:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000dcd:	48 85 c0             	test   rax,rax
    752cbc000dd0:	0f 84 ab 0e 00 18    	je     0x752cd4001c81
    752cbc000dd6:	81 e6 ff 0f 00 00    	and    esi,0xfff
    752cbc000ddc:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    752cbc000ddf:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    752cbc000de3:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    752cbc000de8:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000dec:	48 85 c0             	test   rax,rax
    752cbc000def:	0f 84 f2 0e 00 18    	je     0x752cd4001ce7
    752cbc000df5:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    752cbc000dfa:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc000e00:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc000e03:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    752cbc000e07:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    752cbc000e0c:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000e10:	48 85 c0             	test   rax,rax
    752cbc000e13:	0f 84 39 0f 00 18    	je     0x752cd4001d52
    752cbc000e19:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    752cbc000e1e:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc000e24:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc000e27:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    752cbc000e2b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    752cbc000e32:	00 
    752cbc000e33:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    752cbc000e37:	48 85 c0             	test   rax,rax
    752cbc000e3a:	0f 84 7d 0f 00 18    	je     0x752cd4001dbd
    752cbc000e40:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    752cbc000e45:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc000e4b:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    752cbc000e4e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    752cbc000e52:	49 8b 04 cb          	mov    rax,QWORD PTR [r11+rcx*8]
    752cbc000e56:	48 85 c0             	test   rax,rax
    752cbc000e59:	0f 84 c9 0f 00 18    	je     0x752cd4001e28
    752cbc000e5f:	41 81 e2 ff 0f 00 00 	and    r10d,0xfff
    752cbc000e66:	42 8b 04 10          	mov    eax,DWORD PTR [rax+r10*1]
    752cbc000e6a:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    752cbc000e6e:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    752cbc000e72:	b1 01                	mov    cl,0x1
    752cbc000e74:	bb 02 00 00 00       	mov    ebx,0x2
    752cbc000e79:	bd 1b 00 00 00       	mov    ebp,0x1b
    752cbc000e7e:	40 f6 c7 01          	test   dil,0x1
    752cbc000e82:	0f 85 f2 0f 00 18    	jne    0x752cd4001e7a
    752cbc000e88:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc000e8f:	01 e8                	add    eax,ebp
    752cbc000e91:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    752cbc000e98:	39 d0                	cmp    eax,edx
    752cbc000e9a:	0f 83 d9 0c 00 18    	jae    0x752cd4001b79
    752cbc000ea0:	8d 14 fd 00 00 00 00 	lea    edx,[rdi*8+0x0]
    752cbc000ea7:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    752cbc000ead:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    752cbc000eb2:	39 3c 16             	cmp    DWORD PTR [rsi+rdx*1],edi
    752cbc000eb5:	0f 85 be 0c 00 18    	jne    0x752cd4001b79
    752cbc000ebb:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    752cbc000ec2:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc000ec9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    752cbc000ed0:	00 
    752cbc000ed1:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc000ed6:	48 8b 44 10 08       	mov    rax,QWORD PTR [rax+rdx*1+0x8]
    752cbc000edb:	eb 57                	jmp    0x752cbc000f34
    752cbc000edd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cbc000ee4:	70 03 01 00 
    752cbc000ee8:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc000eef:	83 c0 04             	add    eax,0x4
    752cbc000ef2:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc000ef9:	39 c8                	cmp    eax,ecx
    752cbc000efb:	0f 83 88 09 00 18    	jae    0x752cd4001889
    752cbc000f01:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    752cbc000f06:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    752cbc000f0d:	03 01 00 
    752cbc000f10:	0f 85 73 09 00 18    	jne    0x752cd4001889
    752cbc000f16:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cbc000f1d:	70 03 01 00 
    752cbc000f21:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc000f28:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc000f2d:	48 8b 80 88 1b 08 00 	mov    rax,QWORD PTR [rax+0x81b88]
    752cbc000f34:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    752cbc000f39:	48 81 c4 88 00 00 00 	add    rsp,0x88
    752cbc000f40:	ff e0                	jmp    rax
    752cbc000f42:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cbc000f49:	70 03 01 00 
    752cbc000f4d:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc000f54:	83 c0 06             	add    eax,0x6
    752cbc000f57:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc000f5e:	39 c8                	cmp    eax,ecx
    752cbc000f60:	0f 83 cb 04 00 18    	jae    0x752cd4001431
    752cbc000f66:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    752cbc000f6b:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    752cbc000f72:	03 01 00 
    752cbc000f75:	74 9f                	je     0x752cbc000f16
    752cbc000f77:	e9 b5 04 00 18       	jmp    0x752cd4001431
    752cbc000f7c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cbc000f83:	70 03 01 00 
    752cbc000f87:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc000f8e:	83 c0 0a             	add    eax,0xa
    752cbc000f91:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc000f98:	39 c8                	cmp    eax,ecx
    752cbc000f9a:	0f 83 a8 04 00 18    	jae    0x752cd4001448
    752cbc000fa0:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    752cbc000fa5:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    752cbc000fac:	03 01 00 
    752cbc000faf:	0f 84 61 ff ff ff    	je     0x752cbc000f16
    752cbc000fb5:	e9 8e 04 00 18       	jmp    0x752cd4001448
    752cbc000fba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    752cbc000fc1:	7a 03 01 00 
    752cbc000fc5:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc000fcc:	83 c0 15             	add    eax,0x15
    752cbc000fcf:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc000fd6:	39 c8                	cmp    eax,ecx
    752cbc000fd8:	0f 83 a7 0b 00 18    	jae    0x752cd4001b85
    752cbc000fde:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    752cbc000fe3:	81 b9 d0 1b 08 00 7a 	cmp    DWORD PTR [rcx+0x81bd0],0x1037a
    752cbc000fea:	03 01 00 
    752cbc000fed:	0f 85 92 0b 00 18    	jne    0x752cd4001b85
    752cbc000ff3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    752cbc000ffa:	7a 03 01 00 
    752cbc000ffe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001005:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc00100a:	48 8b 80 d8 1b 08 00 	mov    rax,QWORD PTR [rax+0x81bd8]
    752cbc001011:	e9 1e ff ff ff       	jmp    0x752cbc000f34
    752cbc001016:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    752cbc00101d:	a4 03 01 00 
    752cbc001021:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc001028:	83 c0 17             	add    eax,0x17
    752cbc00102b:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc001032:	39 c8                	cmp    eax,ecx
    752cbc001034:	0f 83 62 0b 00 18    	jae    0x752cd4001b9c
    752cbc00103a:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    752cbc00103f:	81 b9 20 1d 08 00 a4 	cmp    DWORD PTR [rcx+0x81d20],0x103a4
    752cbc001046:	03 01 00 
    752cbc001049:	0f 85 4d 0b 00 18    	jne    0x752cd4001b9c
    752cbc00104f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    752cbc001056:	a4 03 01 00 
    752cbc00105a:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc001061:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    752cbc001066:	48 8b 80 28 1d 08 00 	mov    rax,QWORD PTR [rax+0x81d28]
    752cbc00106d:	e9 c2 fe ff ff       	jmp    0x752cbc000f34
    752cbc001072:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    752cbc001079:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    752cbc001080:	b8 28 01 00 00       	mov    eax,0x128
    752cbc001085:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    752cbc00108a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    752cbc001091:	c2 08 00             	ret    0x8
