
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-66344-0-128835395785777.bin:     file format binary


Disassembly of section .data:

0000752cd4001431 <.data>:
    752cd4001431:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cd4001438:	70 03 01 00 
    752cd400143c:	b1 01                	mov    cl,0x1
    752cd400143e:	bd 06 00 00 00       	mov    ebp,0x6
    752cd4001443:	e9 53 04 00 00       	jmp    0x752cd400189b
    752cd4001448:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cd400144f:	70 03 01 00 
    752cd4001453:	b1 01                	mov    cl,0x1
    752cd4001455:	bd 0a 00 00 00       	mov    ebp,0xa
    752cd400145a:	e9 3c 04 00 00       	jmp    0x752cd400189b
    752cd400145f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001466:	02 00 00 00 
    752cd400146a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4001471:	01 00 00 00 
    752cd4001475:	48 b8 d0 c8 fc e5 8c 	movabs rax,0x578ce5fcc8d0
    752cd400147c:	57 00 00 
    752cd400147f:	4c 89 ef             	mov    rdi,r13
    752cd4001482:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    752cd4001487:	ba 28 03 01 00       	mov    edx,0x10328
    752cd400148c:	44 89 d1             	mov    ecx,r10d
    752cd400148f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    752cd4001495:	ff d0                	call   rax
    752cd4001497:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd400149e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40014a5:	00 
    752cd40014a6:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40014ab:	bd 01 00 00 00       	mov    ebp,0x1
    752cd40014b0:	e9 d3 f9 ff e7       	jmp    0x752cbc000e88
    752cd40014b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40014bc:	02 00 00 00 
    752cd40014c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40014c7:	01 00 00 00 
    752cd40014cb:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40014d2:	57 00 00 
    752cd40014d5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40014da:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd40014df:	44 89 d6             	mov    esi,r10d
    752cd40014e2:	4d 89 cf             	mov    r15,r9
    752cd40014e5:	4c 89 d5             	mov    rbp,r10
    752cd40014e8:	4d 89 dc             	mov    r12,r11
    752cd40014eb:	ff d0                	call   rax
    752cd40014ed:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40014f2:	4d 89 e3             	mov    r11,r12
    752cd40014f5:	49 89 ea             	mov    r10,rbp
    752cd40014f8:	4d 89 f9             	mov    r9,r15
    752cd40014fb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001502:	00 
    752cd4001503:	84 c9                	test   cl,cl
    752cd4001505:	0f 84 43 f5 ff e7    	je     0x752cbc000a4e
    752cd400150b:	e9 f7 01 00 00       	jmp    0x752cd4001707
    752cd4001510:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001517:	02 00 00 00 
    752cd400151b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4001522:	01 00 00 00 
    752cd4001526:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd400152d:	57 00 00 
    752cd4001530:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001535:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd400153a:	89 ee                	mov    esi,ebp
    752cd400153c:	4d 89 cf             	mov    r15,r9
    752cd400153f:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd4001544:	4c 89 d5             	mov    rbp,r10
    752cd4001547:	4d 89 dc             	mov    r12,r11
    752cd400154a:	ff d0                	call   rax
    752cd400154c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001551:	4d 89 e3             	mov    r11,r12
    752cd4001554:	49 89 ea             	mov    r10,rbp
    752cd4001557:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd400155c:	4d 89 f9             	mov    r9,r15
    752cd400155f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001566:	00 
    752cd4001567:	84 c9                	test   cl,cl
    752cd4001569:	0f 84 0c f5 ff e7    	je     0x752cbc000a7b
    752cd400156f:	e9 93 01 00 00       	jmp    0x752cd4001707
    752cd4001574:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400157b:	02 00 00 00 
    752cd400157f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd4001586:	01 00 00 00 
    752cd400158a:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4001591:	57 00 00 
    752cd4001594:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001599:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd400159e:	4d 89 cf             	mov    r15,r9
    752cd40015a1:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd40015a6:	4c 89 d5             	mov    rbp,r10
    752cd40015a9:	4d 89 dc             	mov    r12,r11
    752cd40015ac:	ff d0                	call   rax
    752cd40015ae:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40015b3:	4d 89 e3             	mov    r11,r12
    752cd40015b6:	49 89 ea             	mov    r10,rbp
    752cd40015b9:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd40015be:	4d 89 f9             	mov    r9,r15
    752cd40015c1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40015c8:	00 
    752cd40015c9:	84 c9                	test   cl,cl
    752cd40015cb:	0f 84 da f4 ff e7    	je     0x752cbc000aab
    752cd40015d1:	e9 31 01 00 00       	jmp    0x752cd4001707
    752cd40015d6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40015dd:	02 00 00 00 
    752cd40015e1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40015e8:	01 00 00 00 
    752cd40015ec:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40015f3:	57 00 00 
    752cd40015f6:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40015fb:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001600:	4d 89 cf             	mov    r15,r9
    752cd4001603:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd4001608:	4c 89 d5             	mov    rbp,r10
    752cd400160b:	4d 89 dc             	mov    r12,r11
    752cd400160e:	ff d0                	call   rax
    752cd4001610:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001615:	4d 89 e3             	mov    r11,r12
    752cd4001618:	49 89 ea             	mov    r10,rbp
    752cd400161b:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd4001620:	4d 89 f9             	mov    r9,r15
    752cd4001623:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400162a:	00 
    752cd400162b:	84 c9                	test   cl,cl
    752cd400162d:	0f 84 a8 f4 ff e7    	je     0x752cbc000adb
    752cd4001633:	e9 cf 00 00 00       	jmp    0x752cd4001707
    752cd4001638:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400163f:	02 00 00 00 
    752cd4001643:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd400164a:	01 00 00 00 
    752cd400164e:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4001655:	57 00 00 
    752cd4001658:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400165d:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001662:	4d 89 cf             	mov    r15,r9
    752cd4001665:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd400166a:	4c 89 d5             	mov    rbp,r10
    752cd400166d:	4d 89 dc             	mov    r12,r11
    752cd4001670:	ff d0                	call   rax
    752cd4001672:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001677:	4d 89 e3             	mov    r11,r12
    752cd400167a:	49 89 ea             	mov    r10,rbp
    752cd400167d:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd4001682:	4d 89 f9             	mov    r9,r15
    752cd4001685:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    752cd400168a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001691:	00 
    752cd4001692:	84 c9                	test   cl,cl
    752cd4001694:	0f 84 70 f4 ff e7    	je     0x752cbc000b0a
    752cd400169a:	eb 6b                	jmp    0x752cd4001707
    752cd400169c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    752cd40016a3:	2a 03 01 00 
    752cd40016a7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40016ae:	02 00 00 00 
    752cd40016b2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    752cd40016b9:	01 00 00 00 
    752cd40016bd:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd40016c4:	57 00 00 
    752cd40016c7:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40016cc:	4c 89 ef             	mov    rdi,r13
    752cd40016cf:	4d 89 cf             	mov    r15,r9
    752cd40016d2:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd40016d7:	4c 89 d5             	mov    rbp,r10
    752cd40016da:	4d 89 dc             	mov    r12,r11
    752cd40016dd:	ff d0                	call   rax
    752cd40016df:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd40016e4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40016e9:	4d 89 e3             	mov    r11,r12
    752cd40016ec:	49 89 ea             	mov    r10,rbp
    752cd40016ef:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd40016f4:	4d 89 f9             	mov    r9,r15
    752cd40016f7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40016fe:	00 
    752cd40016ff:	84 c9                	test   cl,cl
    752cd4001701:	0f 84 16 f4 ff e7    	je     0x752cbc000b1d
    752cd4001707:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd400170e:	e9 93 fd ff ff       	jmp    0x752cd40014a6
    752cd4001713:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    752cd400171a:	2a 03 01 00 
    752cd400171e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4001725:	04 00 00 00 
    752cd4001729:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4001730:	02 00 00 00 
    752cd4001734:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd400173b:	57 00 00 
    752cd400173e:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001743:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001748:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd400174d:	4d 89 cf             	mov    r15,r9
    752cd4001750:	4d 89 d4             	mov    r12,r10
    752cd4001753:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001758:	ff d0                	call   rax
    752cd400175a:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd400175f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001764:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001769:	4d 89 e2             	mov    r10,r12
    752cd400176c:	4d 89 f9             	mov    r9,r15
    752cd400176f:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd4001774:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400177b:	00 
    752cd400177c:	84 c9                	test   cl,cl
    752cd400177e:	0f 84 ce f3 ff e7    	je     0x752cbc000b52
    752cd4001784:	e9 ea 00 00 00       	jmp    0x752cd4001873
    752cd4001789:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    752cd4001790:	2a 03 01 00 
    752cd4001794:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd400179b:	04 00 00 00 
    752cd400179f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd40017a6:	02 00 00 00 
    752cd40017aa:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40017b1:	57 00 00 
    752cd40017b4:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40017b9:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd40017be:	44 89 e6             	mov    esi,r12d
    752cd40017c1:	89 da                	mov    edx,ebx
    752cd40017c3:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd40017c8:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd40017cd:	4c 89 d5             	mov    rbp,r10
    752cd40017d0:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd40017d5:	ff d0                	call   rax
    752cd40017d7:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    752cd40017dc:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40017e1:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd40017e6:	49 89 ea             	mov    r10,rbp
    752cd40017e9:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd40017ee:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd40017f3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd40017fa:	00 
    752cd40017fb:	84 c9                	test   cl,cl
    752cd40017fd:	0f 84 73 f3 ff e7    	je     0x752cbc000b76
    752cd4001803:	eb 6e                	jmp    0x752cd4001873
    752cd4001805:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    752cd400180c:	2e 03 01 00 
    752cd4001810:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4001817:	04 00 00 00 
    752cd400181b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    752cd4001822:	02 00 00 00 
    752cd4001826:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd400182d:	57 00 00 
    752cd4001830:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001835:	4c 89 ef             	mov    rdi,r13
    752cd4001838:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd400183d:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    752cd4001842:	4c 89 d5             	mov    rbp,r10
    752cd4001845:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd400184a:	ff d0                	call   rax
    752cd400184c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001851:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001856:	49 89 ea             	mov    r10,rbp
    752cd4001859:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    752cd400185e:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001863:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400186a:	00 
    752cd400186b:	84 c9                	test   cl,cl
    752cd400186d:	0f 84 15 f3 ff e7    	je     0x752cbc000b88
    752cd4001873:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd400187a:	bb 04 00 00 00       	mov    ebx,0x4
    752cd400187f:	bd 02 00 00 00       	mov    ebp,0x2
    752cd4001884:	e9 ff f5 ff e7       	jmp    0x752cbc000e88
    752cd4001889:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    752cd4001890:	70 03 01 00 
    752cd4001894:	b1 01                	mov    cl,0x1
    752cd4001896:	bd 04 00 00 00       	mov    ebp,0x4
    752cd400189b:	bb 02 00 00 00       	mov    ebx,0x2
    752cd40018a0:	e9 cd f7 ff e7       	jmp    0x752cbc001072
    752cd40018a5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    752cd40018ac:	48 03 01 00 
    752cd40018b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40018b7:	02 00 00 00 
    752cd40018bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    752cd40018c2:	0d 00 00 00 
    752cd40018c6:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40018cd:	57 00 00 
    752cd40018d0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40018d5:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd40018da:	be f0 12 01 00       	mov    esi,0x112f0
    752cd40018df:	89 da                	mov    edx,ebx
    752cd40018e1:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd40018e6:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    752cd40018eb:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd40018f0:	ff d0                	call   rax
    752cd40018f2:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40018f7:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd40018fc:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    752cd4001901:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001906:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd400190d:	00 
    752cd400190e:	84 c9                	test   cl,cl
    752cd4001910:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cd4001915:	0f 84 6d f3 ff e7    	je     0x752cbc000c88
    752cd400191b:	eb 6d                	jmp    0x752cd400198a
    752cd400191d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    752cd4001924:	4a 03 01 00 
    752cd4001928:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd400192f:	02 00 00 00 
    752cd4001933:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    752cd400193a:	0d 00 00 00 
    752cd400193e:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001945:	57 00 00 
    752cd4001948:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd400194d:	4c 89 ef             	mov    rdi,r13
    752cd4001950:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4001955:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    752cd400195a:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd400195f:	ff d0                	call   rax
    752cd4001961:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cd4001966:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd400196b:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001970:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    752cd4001975:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd400197a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001981:	00 
    752cd4001982:	84 c9                	test   cl,cl
    752cd4001984:	0f 84 07 f3 ff e7    	je     0x752cbc000c91
    752cd400198a:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001991:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4001996:	bd 0d 00 00 00       	mov    ebp,0xd
    752cd400199b:	e9 e8 f4 ff e7       	jmp    0x752cbc000e88
    752cd40019a0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    752cd40019a7:	52 03 01 00 
    752cd40019ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd40019b2:	02 00 00 00 
    752cd40019b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    752cd40019bd:	10 00 00 00 
    752cd40019c1:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd40019c8:	57 00 00 
    752cd40019cb:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd40019d0:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd40019d5:	be f4 12 01 00       	mov    esi,0x112f4
    752cd40019da:	89 ea                	mov    edx,ebp
    752cd40019dc:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd40019e1:	4c 89 d5             	mov    rbp,r10
    752cd40019e4:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd40019e9:	ff d0                	call   rax
    752cd40019eb:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cd40019f0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd40019f5:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd40019fa:	49 89 ea             	mov    r10,rbp
    752cd40019fd:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001a02:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001a09:	00 
    752cd4001a0a:	84 c9                	test   cl,cl
    752cd4001a0c:	0f 84 9d f2 ff e7    	je     0x752cbc000caf
    752cd4001a12:	eb 69                	jmp    0x752cd4001a7d
    752cd4001a14:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    752cd4001a1b:	54 03 01 00 
    752cd4001a1f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001a26:	02 00 00 00 
    752cd4001a2a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    752cd4001a31:	10 00 00 00 
    752cd4001a35:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001a3c:	57 00 00 
    752cd4001a3f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001a44:	4c 89 ef             	mov    rdi,r13
    752cd4001a47:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4001a4c:	4c 89 d5             	mov    rbp,r10
    752cd4001a4f:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001a54:	ff d0                	call   rax
    752cd4001a56:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cd4001a5b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001a60:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001a65:	49 89 ea             	mov    r10,rbp
    752cd4001a68:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001a6d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001a74:	00 
    752cd4001a75:	84 c9                	test   cl,cl
    752cd4001a77:	0f 84 3b f2 ff e7    	je     0x752cbc000cb8
    752cd4001a7d:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001a84:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4001a89:	bd 10 00 00 00       	mov    ebp,0x10
    752cd4001a8e:	e9 f5 f3 ff e7       	jmp    0x752cbc000e88
    752cd4001a93:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    752cd4001a9a:	5c 03 01 00 
    752cd4001a9e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001aa5:	02 00 00 00 
    752cd4001aa9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    752cd4001ab0:	13 00 00 00 
    752cd4001ab4:	48 b8 20 66 eb e5 8c 	movabs rax,0x578ce5eb6620
    752cd4001abb:	57 00 00 
    752cd4001abe:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    752cd4001ac3:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001ac8:	be f8 12 01 00       	mov    esi,0x112f8
    752cd4001acd:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4001ad2:	4c 89 d5             	mov    rbp,r10
    752cd4001ad5:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001ada:	ff d0                	call   rax
    752cd4001adc:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    752cd4001ae1:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    752cd4001ae6:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001aeb:	49 89 ea             	mov    r10,rbp
    752cd4001aee:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001af3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001afa:	00 
    752cd4001afb:	84 c9                	test   cl,cl
    752cd4001afd:	0f 84 d7 f1 ff e7    	je     0x752cbc000cda
    752cd4001b03:	eb 5e                	jmp    0x752cd4001b63
    752cd4001b05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    752cd4001b0c:	5e 03 01 00 
    752cd4001b10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001b17:	02 00 00 00 
    752cd4001b1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    752cd4001b22:	13 00 00 00 
    752cd4001b26:	48 b8 00 c6 fc e5 8c 	movabs rax,0x578ce5fcc600
    752cd4001b2d:	57 00 00 
    752cd4001b30:	4c 89 ef             	mov    rdi,r13
    752cd4001b33:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4001b38:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    752cd4001b3d:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001b42:	ff d0                	call   rax
    752cd4001b44:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001b49:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    752cd4001b4e:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001b53:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001b5a:	00 
    752cd4001b5b:	84 c9                	test   cl,cl
    752cd4001b5d:	0f 84 83 f1 ff e7    	je     0x752cbc000ce6
    752cd4001b63:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001b6a:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4001b6f:	bd 13 00 00 00       	mov    ebp,0x13
    752cd4001b74:	e9 0f f3 ff e7       	jmp    0x752cbc000e88
    752cd4001b79:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    752cd4001b80:	e9 ed f4 ff e7       	jmp    0x752cbc001072
    752cd4001b85:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    752cd4001b8c:	7a 03 01 00 
    752cd4001b90:	b1 01                	mov    cl,0x1
    752cd4001b92:	bd 15 00 00 00       	mov    ebp,0x15
    752cd4001b97:	e9 ff fc ff ff       	jmp    0x752cd400189b
    752cd4001b9c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    752cd4001ba3:	a4 03 01 00 
    752cd4001ba7:	b1 01                	mov    cl,0x1
    752cd4001ba9:	bd 17 00 00 00       	mov    ebp,0x17
    752cd4001bae:	e9 e8 fc ff ff       	jmp    0x752cd400189b
    752cd4001bb3:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001bb8:	4d 89 d7             	mov    r15,r10
    752cd4001bbb:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    752cd4001bc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    752cd4001bc7:	68 03 01 00 
    752cd4001bcb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4001bd2:	04 00 00 00 
    752cd4001bd6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    752cd4001bdd:	19 00 00 00 
    752cd4001be1:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001be8:	57 00 00 
    752cd4001beb:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001bf0:	44 89 e6             	mov    esi,r12d
    752cd4001bf3:	ff d0                	call   rax
    752cd4001bf5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001bfc:	00 
    752cd4001bfd:	84 c9                	test   cl,cl
    752cd4001bff:	0f 85 d9 02 00 00    	jne    0x752cd4001ede
    752cd4001c05:	89 c3                	mov    ebx,eax
    752cd4001c07:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    752cd4001c0c:	4d 89 fa             	mov    r10,r15
    752cd4001c0f:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001c14:	e9 79 f1 ff e7       	jmp    0x752cbc000d92
    752cd4001c19:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    752cd4001c1e:	4d 89 d4             	mov    r12,r10
    752cd4001c21:	4d 89 cf             	mov    r15,r9
    752cd4001c24:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    752cd4001c2b:	68 03 01 00 
    752cd4001c2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cd4001c36:	04 00 00 00 
    752cd4001c3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    752cd4001c41:	19 00 00 00 
    752cd4001c45:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001c4c:	57 00 00 
    752cd4001c4f:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001c54:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    752cd4001c59:	ff d0                	call   rax
    752cd4001c5b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001c62:	00 
    752cd4001c63:	84 c9                	test   cl,cl
    752cd4001c65:	0f 85 73 02 00 00    	jne    0x752cd4001ede
    752cd4001c6b:	4d 89 f9             	mov    r9,r15
    752cd4001c6e:	4d 89 e2             	mov    r10,r12
    752cd4001c71:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    752cd4001c76:	48 89 e9             	mov    rcx,rbp
    752cd4001c79:	48 89 c7             	mov    rdi,rax
    752cd4001c7c:	e9 2f f1 ff e7       	jmp    0x752cbc000db0
    752cd4001c81:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    752cd4001c86:	4d 89 dc             	mov    r12,r11
    752cd4001c89:	4d 89 d7             	mov    r15,r10
    752cd4001c8c:	4c 89 cb             	mov    rbx,r9
    752cd4001c8f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    752cd4001c96:	6c 03 01 00 
    752cd4001c9a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001ca1:	02 00 00 00 
    752cd4001ca5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd4001cac:	1a 00 00 00 
    752cd4001cb0:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001cb7:	57 00 00 
    752cd4001cba:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001cbf:	ff d0                	call   rax
    752cd4001cc1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001cc8:	00 
    752cd4001cc9:	84 c9                	test   cl,cl
    752cd4001ccb:	0f 85 f7 01 00 00    	jne    0x752cd4001ec8
    752cd4001cd1:	49 89 d9             	mov    r9,rbx
    752cd4001cd4:	4d 89 fa             	mov    r10,r15
    752cd4001cd7:	4d 89 e3             	mov    r11,r12
    752cd4001cda:	48 89 e9             	mov    rcx,rbp
    752cd4001cdd:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    752cd4001ce2:	e9 f8 f0 ff e7       	jmp    0x752cbc000ddf
    752cd4001ce7:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    752cd4001cec:	4d 89 dc             	mov    r12,r11
    752cd4001cef:	4d 89 d7             	mov    r15,r10
    752cd4001cf2:	4c 89 cb             	mov    rbx,r9
    752cd4001cf5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    752cd4001cfc:	6c 03 01 00 
    752cd4001d00:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001d07:	02 00 00 00 
    752cd4001d0b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd4001d12:	1a 00 00 00 
    752cd4001d16:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001d1d:	57 00 00 
    752cd4001d20:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001d25:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    752cd4001d2a:	ff d0                	call   rax
    752cd4001d2c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001d33:	00 
    752cd4001d34:	84 c9                	test   cl,cl
    752cd4001d36:	0f 85 8c 01 00 00    	jne    0x752cd4001ec8
    752cd4001d3c:	49 89 d9             	mov    r9,rbx
    752cd4001d3f:	4d 89 fa             	mov    r10,r15
    752cd4001d42:	4d 89 e3             	mov    r11,r12
    752cd4001d45:	48 89 e9             	mov    rcx,rbp
    752cd4001d48:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    752cd4001d4d:	e9 b1 f0 ff e7       	jmp    0x752cbc000e03
    752cd4001d52:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    752cd4001d57:	4d 89 dc             	mov    r12,r11
    752cd4001d5a:	4d 89 d7             	mov    r15,r10
    752cd4001d5d:	4c 89 cb             	mov    rbx,r9
    752cd4001d60:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    752cd4001d67:	6c 03 01 00 
    752cd4001d6b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001d72:	02 00 00 00 
    752cd4001d76:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd4001d7d:	1a 00 00 00 
    752cd4001d81:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001d88:	57 00 00 
    752cd4001d8b:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001d90:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    752cd4001d95:	ff d0                	call   rax
    752cd4001d97:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001d9e:	00 
    752cd4001d9f:	84 c9                	test   cl,cl
    752cd4001da1:	0f 85 21 01 00 00    	jne    0x752cd4001ec8
    752cd4001da7:	49 89 d9             	mov    r9,rbx
    752cd4001daa:	4d 89 fa             	mov    r10,r15
    752cd4001dad:	4d 89 e3             	mov    r11,r12
    752cd4001db0:	48 89 e9             	mov    rcx,rbp
    752cd4001db3:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    752cd4001db8:	e9 6a f0 ff e7       	jmp    0x752cbc000e27
    752cd4001dbd:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    752cd4001dc2:	4d 89 dc             	mov    r12,r11
    752cd4001dc5:	4d 89 d7             	mov    r15,r10
    752cd4001dc8:	4c 89 cb             	mov    rbx,r9
    752cd4001dcb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    752cd4001dd2:	6c 03 01 00 
    752cd4001dd6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001ddd:	02 00 00 00 
    752cd4001de1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd4001de8:	1a 00 00 00 
    752cd4001dec:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001df3:	57 00 00 
    752cd4001df6:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001dfb:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    752cd4001e00:	ff d0                	call   rax
    752cd4001e02:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001e09:	00 
    752cd4001e0a:	84 c9                	test   cl,cl
    752cd4001e0c:	0f 85 b6 00 00 00    	jne    0x752cd4001ec8
    752cd4001e12:	49 89 d9             	mov    r9,rbx
    752cd4001e15:	4d 89 fa             	mov    r10,r15
    752cd4001e18:	4d 89 e3             	mov    r11,r12
    752cd4001e1b:	48 89 e9             	mov    rcx,rbp
    752cd4001e1e:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    752cd4001e23:	e9 26 f0 ff e7       	jmp    0x752cbc000e4e
    752cd4001e28:	48 89 fd             	mov    rbp,rdi
    752cd4001e2b:	4c 89 cb             	mov    rbx,r9
    752cd4001e2e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    752cd4001e35:	6c 03 01 00 
    752cd4001e39:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001e40:	02 00 00 00 
    752cd4001e44:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    752cd4001e4b:	1a 00 00 00 
    752cd4001e4f:	48 b8 f0 65 eb e5 8c 	movabs rax,0x578ce5eb65f0
    752cd4001e56:	57 00 00 
    752cd4001e59:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    752cd4001e5e:	44 89 d6             	mov    esi,r10d
    752cd4001e61:	ff d0                	call   rax
    752cd4001e63:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001e6a:	00 
    752cd4001e6b:	84 c9                	test   cl,cl
    752cd4001e6d:	75 59                	jne    0x752cd4001ec8
    752cd4001e6f:	49 89 d9             	mov    r9,rbx
    752cd4001e72:	48 89 ef             	mov    rdi,rbp
    752cd4001e75:	e9 f0 ef ff e7       	jmp    0x752cbc000e6a
    752cd4001e7a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    752cd4001e81:	6e 03 01 00 
    752cd4001e85:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    752cd4001e8c:	02 00 00 00 
    752cd4001e90:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    752cd4001e97:	1b 00 00 00 
    752cd4001e9b:	48 b8 d0 ba fc e5 8c 	movabs rax,0x578ce5fcbad0
    752cd4001ea2:	57 00 00 
    752cd4001ea5:	4c 89 ef             	mov    rdi,r13
    752cd4001ea8:	be 2a 00 00 00       	mov    esi,0x2a
    752cd4001ead:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    752cd4001eb2:	ff d0                	call   rax
    752cd4001eb4:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001ebb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    752cd4001ec2:	00 
    752cd4001ec3:	e9 c0 ef ff e7       	jmp    0x752cbc000e88
    752cd4001ec8:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001ecf:	bb 02 00 00 00       	mov    ebx,0x2
    752cd4001ed4:	bd 1a 00 00 00       	mov    ebp,0x1a
    752cd4001ed9:	e9 aa ef ff e7       	jmp    0x752cbc000e88
    752cd4001ede:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    752cd4001ee5:	bb 04 00 00 00       	mov    ebx,0x4
    752cd4001eea:	bd 19 00 00 00       	mov    ebp,0x19
    752cd4001eef:	e9 94 ef ff e7       	jmp    0x752cbc000e88
