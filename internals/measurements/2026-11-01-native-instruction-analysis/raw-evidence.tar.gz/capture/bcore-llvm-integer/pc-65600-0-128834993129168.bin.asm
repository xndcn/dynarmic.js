
build-native-instruction-analysis/capture/bcore-llvm-integer/pc-65600-0-128834993129168.bin:     file format binary


Disassembly of section .data:

0000752cbc0006d0 <.data>:
    752cbc0006d0:	48 83 ec 38          	sub    rsp,0x38
    752cbc0006d4:	45 8b 85 a0 00 00 00 	mov    r8d,DWORD PTR [r13+0xa0]
    752cbc0006db:	41 8d 80 71 ff fe ff 	lea    eax,[r8-0x1008f]
    752cbc0006e2:	83 f8 b0             	cmp    eax,0xffffffb0
    752cbc0006e5:	0f 87 64 05 00 18    	ja     0x752cd4000c4f
    752cbc0006eb:	41 8b bd a4 00 00 00 	mov    edi,DWORD PTR [r13+0xa4]
    752cbc0006f2:	8d 87 71 ff fe ff    	lea    eax,[rdi-0x1008f]
    752cbc0006f8:	83 f8 b0             	cmp    eax,0xffffffb0
    752cbc0006fb:	0f 87 4e 05 00 18    	ja     0x752cd4000c4f
    752cbc000701:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    752cbc000708:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    752cbc00070f:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    752cbc000716:	41 c7 45 28 04 f0 00 	mov    DWORD PTR [r13+0x28],0xf004
    752cbc00071d:	00 
    752cbc00071e:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc000723:	48 85 c0             	test   rax,rax
    752cbc000726:	0f 84 32 05 00 18    	je     0x752cd4000c5e
    752cbc00072c:	44 8b 48 04          	mov    r9d,DWORD PTR [rax+0x4]
    752cbc000730:	45 89 4d 10          	mov    DWORD PTR [r13+0x10],r9d
    752cbc000734:	41 c7 45 28 08 f0 00 	mov    DWORD PTR [r13+0x28],0xf008
    752cbc00073b:	00 
    752cbc00073c:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc000741:	48 85 c0             	test   rax,rax
    752cbc000744:	0f 84 83 05 00 18    	je     0x752cd4000ccd
    752cbc00074a:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    752cbc00074d:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    752cbc000751:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    752cbc000758:	00 
    752cbc000759:	41 c7 45 2c 14 f0 00 	mov    DWORD PTR [r13+0x2c],0xf014
    752cbc000760:	00 
    752cbc000761:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    752cbc000765:	8d 5d fc             	lea    ebx,[rbp-0x4]
    752cbc000768:	40 f6 c5 03          	test   bpl,0x3
    752cbc00076c:	0f 85 d1 05 00 18    	jne    0x752cd4000d43
    752cbc000772:	41 89 db             	mov    r11d,ebx
    752cbc000775:	41 c1 eb 0c          	shr    r11d,0xc
    752cbc000779:	4b 8b 0c dc          	mov    rcx,QWORD PTR [r12+r11*8]
    752cbc00077d:	48 85 c9             	test   rcx,rcx
    752cbc000780:	0f 84 6d 06 00 18    	je     0x752cd4000df3
    752cbc000786:	89 da                	mov    edx,ebx
    752cbc000788:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc00078e:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    752cbc000791:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    752cbc000795:	0f 85 db 06 00 18    	jne    0x752cd4000e76
    752cbc00079b:	41 c7 45 28 0c f0 00 	mov    DWORD PTR [r13+0x28],0xf00c
    752cbc0007a2:	00 
    752cbc0007a3:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc0007a8:	48 85 c0             	test   rax,rax
    752cbc0007ab:	0f 84 44 07 00 18    	je     0x752cd4000ef5
    752cbc0007b1:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    752cbc0007b4:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    752cbc0007b8:	66 41 c7 45 32 00 01 	mov    WORD PTR [r13+0x32],0x100
    752cbc0007bf:	41 c7 45 34 18 f0 00 	mov    DWORD PTR [r13+0x34],0xf018
    752cbc0007c6:	00 
    752cbc0007c7:	83 c5 f8             	add    ebp,0xfffffff8
    752cbc0007ca:	41 89 ef             	mov    r15d,ebp
    752cbc0007cd:	41 c1 ef 0c          	shr    r15d,0xc
    752cbc0007d1:	4b 8b 0c fc          	mov    rcx,QWORD PTR [r12+r15*8]
    752cbc0007d5:	48 85 c9             	test   rcx,rcx
    752cbc0007d8:	0f 84 9f 07 00 18    	je     0x752cd4000f7d
    752cbc0007de:	89 ea                	mov    edx,ebp
    752cbc0007e0:	81 e2 ff 0f 00 00    	and    edx,0xfff
    752cbc0007e6:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    752cbc0007e9:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    752cbc0007ed:	0f 85 0e 08 00 18    	jne    0x752cd4001001
    752cbc0007f3:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    752cbc0007fa:	00 
    752cbc0007fb:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc000800:	48 85 c0             	test   rax,rax
    752cbc000803:	0f 84 85 08 00 18    	je     0x752cd400108e
    752cbc000809:	c7 40 10 01 00 00 00 	mov    DWORD PTR [rax+0x10],0x1
    752cbc000810:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    752cbc000814:	0f 85 fe 08 00 18    	jne    0x752cd4001118
    752cbc00081a:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    752cbc000821:	00 
    752cbc000822:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    752cbc000827:	48 85 c0             	test   rax,rax
    752cbc00082a:	0f 84 75 09 00 18    	je     0x752cd40011a5
    752cbc000830:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    752cbc000837:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    752cbc00083b:	0f 85 eb 09 00 18    	jne    0x752cd400122c
    752cbc000841:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    752cbc000848:	00 
    752cbc000849:	41 c7 45 30 00 00 00 	mov    DWORD PTR [r13+0x30],0x1000000
    752cbc000850:	01 
    752cbc000851:	49 c7 45 14 01 00 00 	mov    QWORD PTR [r13+0x14],0x1
    752cbc000858:	00 
    752cbc000859:	4b 8b 04 dc          	mov    rax,QWORD PTR [r12+r11*8]
    752cbc00085d:	48 85 c0             	test   rax,rax
    752cbc000860:	0f 84 49 0a 00 18    	je     0x752cd40012af
    752cbc000866:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    752cbc00086c:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    752cbc00086f:	45 89 4d 00          	mov    DWORD PTR [r13+0x0],r9d
    752cbc000873:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    752cbc000877:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    752cbc00087b:	48 85 c0             	test   rax,rax
    752cbc00087e:	0f 84 a0 0a 00 18    	je     0x752cd4001324
    752cbc000884:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    752cbc00088a:	8b 04 28             	mov    eax,DWORD PTR [rax+rbp*1]
    752cbc00088d:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    752cbc000891:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    752cbc000898:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    752cbc00089f:	02 
    752cbc0008a0:	b8 92 00 01 00       	mov    eax,0x10092
    752cbc0008a5:	ba 92 00 01 00       	mov    edx,0x10092
    752cbc0008aa:	72 07                	jb     0x752cbc0008b3
    752cbc0008ac:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    752cbc0008b3:	41 81 f8 8e 00 01 00 	cmp    r8d,0x1008e
    752cbc0008ba:	0f 44 c2             	cmove  eax,edx
    752cbc0008bd:	89 c2                	mov    edx,eax
    752cbc0008bf:	83 f9 02             	cmp    ecx,0x2
    752cbc0008c2:	72 07                	jb     0x752cbc0008cb
    752cbc0008c4:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    752cbc0008cb:	81 ff 8e 00 01 00    	cmp    edi,0x1008e
    752cbc0008d1:	0f 44 c2             	cmove  eax,edx
    752cbc0008d4:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    752cbc0008db:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc0008e2:	28 03 01 00 
    752cbc0008e6:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    752cbc0008ed:	83 c0 1c             	add    eax,0x1c
    752cbc0008f0:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    752cbc0008f7:	39 c8                	cmp    eax,ecx
    752cbc0008f9:	73 2b                	jae    0x752cbc000926
    752cbc0008fb:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    752cbc000902:	03 01 00 
    752cbc000905:	75 1f                	jne    0x752cbc000926
    752cbc000907:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc00090e:	28 03 01 00 
    752cbc000912:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    752cbc000919:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    752cbc000920:	48 83 c4 38          	add    rsp,0x38
    752cbc000924:	ff e0                	jmp    rax
    752cbc000926:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    752cbc00092d:	28 03 01 00 
    752cbc000931:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    752cbc000938:	04 00 00 00 
    752cbc00093c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    752cbc000943:	1c 00 00 00 
    752cbc000947:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    752cbc00094e:	01 
    752cbc00094f:	48 83 c4 38          	add    rsp,0x38
    752cbc000953:	c2 08 00             	ret    0x8
