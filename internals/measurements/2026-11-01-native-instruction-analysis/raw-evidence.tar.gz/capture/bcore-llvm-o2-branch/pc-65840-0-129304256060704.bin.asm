
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65840-0-129304256060704.bin:     file format binary


Disassembly of section .data:

00007599fe401d20 <.data>:
    7599fe401d20:	48 83 ec 38          	sub    rsp,0x38
    7599fe401d24:	ba b5 fe fe ff       	mov    edx,0xfffefeb5
    7599fe401d29:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe401d30:	01 d6                	add    esi,edx
    7599fe401d32:	b1 01                	mov    cl,0x1
    7599fe401d34:	b8 65 01 00 00       	mov    eax,0x165
    7599fe401d39:	83 fe e4             	cmp    esi,0xffffffe4
    7599fe401d3c:	0f 87 09 02 00 00    	ja     0x7599fe401f4b
    7599fe401d42:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe401d49:	83 fa e4             	cmp    edx,0xffffffe4
    7599fe401d4c:	0f 87 f9 01 00 00    	ja     0x7599fe401f4b
    7599fe401d52:	4d 89 f3             	mov    r11,r14
    7599fe401d55:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7599fe401d5c:	4d 8b 95 38 01 00 00 	mov    r10,QWORD PTR [r13+0x138]
    7599fe401d63:	49 8b b5 40 01 00 00 	mov    rsi,QWORD PTR [r13+0x140]
    7599fe401d6a:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7599fe401d6e:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    7599fe401d72:	41 89 c7             	mov    r15d,eax
    7599fe401d75:	41 c1 e7 05          	shl    r15d,0x5
    7599fe401d79:	41 0f b7 cf          	movzx  ecx,r15w
    7599fe401d7d:	41 c1 ef 1f          	shr    r15d,0x1f
    7599fe401d81:	c4 63 7b f0 f0 1b    	rorx   r14d,eax,0x1b
    7599fe401d87:	45 89 75 00          	mov    DWORD PTR [r13+0x0],r14d
    7599fe401d8b:	31 d2                	xor    edx,edx
    7599fe401d8d:	85 c0                	test   eax,eax
    7599fe401d8f:	0f 94 c2             	sete   dl
    7599fe401d92:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7599fe401d99:	45 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r15d
    7599fe401da0:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7599fe401da7:	00 00 00 00 
    7599fe401dab:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe401db2:	00 00 00 00 
    7599fe401db6:	81 c9 00 00 4a 7f    	or     ecx,0x7f4a0000
    7599fe401dbc:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7599fe401dc0:	41 8d 59 fc          	lea    ebx,[r9-0x4]
    7599fe401dc4:	41 f6 c1 03          	test   r9b,0x3
    7599fe401dc8:	0f 85 c8 0d 00 18    	jne    0x759a16402b96
    7599fe401dce:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe401dd5:	41 8b 7d 3c          	mov    edi,DWORD PTR [r13+0x3c]
    7599fe401dd9:	89 d8                	mov    eax,ebx
    7599fe401ddb:	c1 e8 0c             	shr    eax,0xc
    7599fe401dde:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    7599fe401de3:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    7599fe401de7:	48 85 c0             	test   rax,rax
    7599fe401dea:	0f 84 10 0e 00 18    	je     0x759a16402c00
    7599fe401df0:	89 d9                	mov    ecx,ebx
    7599fe401df2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe401df8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe401dfb:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    7599fe401dff:	41 89 ec             	mov    r12d,ebp
    7599fe401e02:	41 c1 ec 0c          	shr    r12d,0xc
    7599fe401e06:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    7599fe401e0a:	48 85 c0             	test   rax,rax
    7599fe401e0d:	0f 84 66 0e 00 18    	je     0x759a16402c79
    7599fe401e13:	89 e9                	mov    ecx,ebp
    7599fe401e15:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe401e1b:	89 3c 08             	mov    DWORD PTR [rax+rcx*1],edi
    7599fe401e1e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe401e22:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7599fe401e26:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    7599fe401e29:	0f 85 c2 0e 00 18    	jne    0x759a16402cf1
    7599fe401e2f:	41 c7 45 04 15 7c 4a 	mov    DWORD PTR [r13+0x4],0x7f4a7c15
    7599fe401e36:	7f 
    7599fe401e37:	41 8d 86 15 7c 4a 7f 	lea    eax,[r14+0x7f4a7c15]
    7599fe401e3e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7599fe401e42:	89 c1                	mov    ecx,eax
    7599fe401e44:	c1 e9 1f             	shr    ecx,0x1f
    7599fe401e47:	c4 e2 00 f2 d1       	andn   edx,r15d,ecx
    7599fe401e4c:	31 f6                	xor    esi,esi
    7599fe401e4e:	41 81 fe eb 83 b5 80 	cmp    r14d,0x80b583eb
    7599fe401e55:	40 0f 93 c6          	setae  sil
    7599fe401e59:	31 ff                	xor    edi,edi
    7599fe401e5b:	85 c0                	test   eax,eax
    7599fe401e5d:	40 0f 94 c7          	sete   dil
    7599fe401e61:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    7599fe401e68:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe401e6f:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7599fe401e76:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7599fe401e7d:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7599fe401e84:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7599fe401e8b:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7599fe401e92:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    7599fe401e96:	48 85 c0             	test   rax,rax
    7599fe401e99:	0f 84 c6 0e 00 18    	je     0x759a16402d65
    7599fe401e9f:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7599fe401ea5:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7599fe401ea8:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    7599fe401ead:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    7599fe401eb1:	48 85 c0             	test   rax,rax
    7599fe401eb4:	0f 84 16 0f 00 18    	je     0x759a16402dd0
    7599fe401eba:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    7599fe401ec0:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    7599fe401ec3:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe401ec7:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7599fe401ece:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    7599fe401ed2:	b1 01                	mov    cl,0x1
    7599fe401ed4:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe401ed9:	bd 09 00 00 00       	mov    ebp,0x9
    7599fe401ede:	a8 01                	test   al,0x1
    7599fe401ee0:	0f 85 43 0f 00 18    	jne    0x759a16402e29
    7599fe401ee6:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7599fe401eed:	01 ea                	add    edx,ebp
    7599fe401eef:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7599fe401ef6:	39 f2                	cmp    edx,esi
    7599fe401ef8:	73 37                	jae    0x7599fe401f31
    7599fe401efa:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7599fe401f01:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7599fe401f07:	41 39 04 30          	cmp    DWORD PTR [r8+rsi*1],eax
    7599fe401f0b:	75 24                	jne    0x7599fe401f31
    7599fe401f0d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe401f14:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7599fe401f1b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe401f22:	00 
    7599fe401f23:	49 8b 44 30 08       	mov    rax,QWORD PTR [r8+rsi*1+0x8]
    7599fe401f28:	4d 89 de             	mov    r14,r11
    7599fe401f2b:	48 83 c4 38          	add    rsp,0x38
    7599fe401f2f:	ff e0                	jmp    rax
    7599fe401f31:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe401f38:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe401f3f:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe401f46:	b8 28 01 00 00       	mov    eax,0x128
    7599fe401f4b:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe401f50:	48 83 c4 38          	add    rsp,0x38
    7599fe401f54:	c2 08 00             	ret    0x8
