
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65910-0-129304256061328.bin:     file format binary


Disassembly of section .data:

00007599fe401f90 <.data>:
    7599fe401f90:	b9 77 fe fe ff       	mov    ecx,0xfffefe77
    7599fe401f95:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7599fe401f9c:	01 ca                	add    edx,ecx
    7599fe401f9e:	b8 65 01 00 00       	mov    eax,0x165
    7599fe401fa3:	83 fa ec             	cmp    edx,0xffffffec
    7599fe401fa6:	0f 87 2d 02 00 00    	ja     0x7599fe4021d9
    7599fe401fac:	41 03 8d a4 00 00 00 	add    ecx,DWORD PTR [r13+0xa4]
    7599fe401fb3:	83 f9 ec             	cmp    ecx,0xffffffec
    7599fe401fb6:	0f 87 1d 02 00 00    	ja     0x7599fe4021d9
    7599fe401fbc:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7599fe401fc3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7599fe401fc7:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    7599fe401fcb:	8d 71 01             	lea    esi,[rcx+0x1]
    7599fe401fce:	41 89 75 18          	mov    DWORD PTR [r13+0x18],esi
    7599fe401fd2:	c1 e9 1f             	shr    ecx,0x1f
    7599fe401fd5:	89 f7                	mov    edi,esi
    7599fe401fd7:	c1 ef 1f             	shr    edi,0x1f
    7599fe401fda:	c4 e2 70 f2 ff       	andn   edi,ecx,edi
    7599fe401fdf:	41 8b 8d 00 01 00 00 	mov    ecx,DWORD PTR [r13+0x100]
    7599fe401fe6:	09 f9                	or     ecx,edi
    7599fe401fe8:	41 89 bd f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edi
    7599fe401fef:	41 89 bd fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edi
    7599fe401ff6:	41 89 8d 00 01 00 00 	mov    DWORD PTR [r13+0x100],ecx
    7599fe401ffd:	31 ff                	xor    edi,edi
    7599fe401fff:	31 db                	xor    ebx,ebx
    7599fe402001:	31 ed                	xor    ebp,ebp
    7599fe402003:	31 c0                	xor    eax,eax
    7599fe402005:	39 d6                	cmp    esi,edx
    7599fe402007:	40 0f 97 c7          	seta   dil
    7599fe40200b:	0f 96 c3             	setbe  bl
    7599fe40200e:	40 0f 93 c5          	setae  bpl
    7599fe402012:	41 89 ad 14 01 00 00 	mov    DWORD PTR [r13+0x114],ebp
    7599fe402019:	0f 94 c0             	sete   al
    7599fe40201c:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7599fe402023:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7599fe40202a:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    7599fe402031:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    7599fe402038:	72 50                	jb     0x7599fe40208a
    7599fe40203a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7599fe402041:	92 01 01 00 
    7599fe402045:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe40204c:	83 c1 03             	add    ecx,0x3
    7599fe40204f:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7599fe402056:	39 c1                	cmp    ecx,eax
    7599fe402058:	0f 83 71 0e 00 18    	jae    0x759a16402ecf
    7599fe40205e:	41 81 b8 90 0c 08 00 	cmp    DWORD PTR [r8+0x80c90],0x10192
    7599fe402065:	92 01 01 00 
    7599fe402069:	0f 85 60 0e 00 18    	jne    0x759a16402ecf
    7599fe40206f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    7599fe402076:	92 01 01 00 
    7599fe40207a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe402081:	49 8b 80 98 0c 08 00 	mov    rax,QWORD PTR [r8+0x80c98]
    7599fe402088:	ff e0                	jmp    rax
    7599fe40208a:	41 8b 45 10          	mov    eax,DWORD PTR [r13+0x10]
    7599fe40208e:	41 8b 75 34          	mov    esi,DWORD PTR [r13+0x34]
    7599fe402092:	41 0f af 45 1c       	imul   eax,DWORD PTR [r13+0x1c]
    7599fe402097:	41 89 75 04          	mov    DWORD PTR [r13+0x4],esi
    7599fe40209b:	8d 14 06             	lea    edx,[rsi+rax*1]
    7599fe40209e:	41 89 55 1c          	mov    DWORD PTR [r13+0x1c],edx
    7599fe4020a2:	c1 e8 1f             	shr    eax,0x1f
    7599fe4020a5:	c1 ee 1f             	shr    esi,0x1f
    7599fe4020a8:	89 d7                	mov    edi,edx
    7599fe4020aa:	c1 ef 1f             	shr    edi,0x1f
    7599fe4020ad:	31 fe                	xor    esi,edi
    7599fe4020af:	31 f8                	xor    eax,edi
    7599fe4020b1:	21 f0                	and    eax,esi
    7599fe4020b3:	09 c1                	or     ecx,eax
    7599fe4020b5:	31 f6                	xor    esi,esi
    7599fe4020b7:	85 d2                	test   edx,edx
    7599fe4020b9:	40 0f 94 c6          	sete   sil
    7599fe4020bd:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7599fe4020c4:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7599fe4020cb:	41 89 8d 00 01 00 00 	mov    DWORD PTR [r13+0x100],ecx
    7599fe4020d2:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    7599fe4020d9:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7599fe4020e0:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7599fe4020e7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7599fe4020ee:	00 00 00 
    7599fe4020f1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7599fe4020f8:	78 50                	js     0x7599fe40214a
    7599fe4020fa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7599fe402101:	70 01 01 00 
    7599fe402105:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe40210c:	83 c1 08             	add    ecx,0x8
    7599fe40210f:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7599fe402116:	39 c1                	cmp    ecx,eax
    7599fe402118:	0f 83 de 0d 00 18    	jae    0x759a16402efc
    7599fe40211e:	41 81 b8 80 0b 08 00 	cmp    DWORD PTR [r8+0x80b80],0x10170
    7599fe402125:	70 01 01 00 
    7599fe402129:	0f 85 cd 0d 00 18    	jne    0x759a16402efc
    7599fe40212f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7599fe402136:	70 01 01 00 
    7599fe40213a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe402141:	49 8b 80 88 0b 08 00 	mov    rax,QWORD PTR [r8+0x80b88]
    7599fe402148:	ff e0                	jmp    rax
    7599fe40214a:	31 c0                	xor    eax,eax
    7599fe40214c:	41 33 55 00          	xor    edx,DWORD PTR [r13+0x0]
    7599fe402150:	41 89 55 00          	mov    DWORD PTR [r13+0x0],edx
    7599fe402154:	0f 94 c0             	sete   al
    7599fe402157:	c1 ea 1f             	shr    edx,0x1f
    7599fe40215a:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7599fe402161:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7599fe402168:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7599fe40216f:	00 00 00 00 
    7599fe402173:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe40217a:	00 00 00 00 
    7599fe40217e:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x1018c
    7599fe402185:	8c 01 01 00 
    7599fe402189:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7599fe402190:	10 01 01 00 
    7599fe402194:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe40219b:	83 c1 0a             	add    ecx,0xa
    7599fe40219e:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    7599fe4021a5:	39 c1                	cmp    ecx,eax
    7599fe4021a7:	0f 83 61 0d 00 18    	jae    0x759a16402f0e
    7599fe4021ad:	41 81 b8 80 08 08 00 	cmp    DWORD PTR [r8+0x80880],0x10110
    7599fe4021b4:	10 01 01 00 
    7599fe4021b8:	0f 85 50 0d 00 18    	jne    0x759a16402f0e
    7599fe4021be:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7599fe4021c5:	10 01 01 00 
    7599fe4021c9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe4021d0:	49 8b 80 88 08 08 00 	mov    rax,QWORD PTR [r8+0x80888]
    7599fe4021d7:	ff e0                	jmp    rax
    7599fe4021d9:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    7599fe4021df:	c2 08 00             	ret    0x8
