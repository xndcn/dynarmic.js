
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65682-0-129304256057584.bin:     file format binary


Disassembly of section .data:

00007599fe4010f0 <.data>:
    7599fe4010f0:	50                   	push   rax
    7599fe4010f1:	b8 67 ff fe ff       	mov    eax,0xfffeff67
    7599fe4010f6:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7599fe4010fd:	01 c1                	add    ecx,eax
    7599fe4010ff:	83 f9 f8             	cmp    ecx,0xfffffff8
    7599fe401102:	0f 87 b3 0d 00 18    	ja     0x759a16401ebb
    7599fe401108:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7599fe40110f:	83 f8 f8             	cmp    eax,0xfffffff8
    7599fe401112:	0f 87 a3 0d 00 18    	ja     0x759a16401ebb
    7599fe401118:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    7599fe40111f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7599fe401126:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    7599fe40112d:	41 8b 4d 00          	mov    ecx,DWORD PTR [r13+0x0]
    7599fe401131:	89 ca                	mov    edx,ecx
    7599fe401133:	c1 ea 1f             	shr    edx,0x1f
    7599fe401136:	31 f6                	xor    esi,esi
    7599fe401138:	85 c9                	test   ecx,ecx
    7599fe40113a:	40 0f 94 c6          	sete   sil
    7599fe40113e:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    7599fe401145:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7599fe40114c:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7599fe401153:	48 b9 01 00 00 00 01 	movabs rcx,0x100000001
    7599fe40115a:	00 00 00 
    7599fe40115d:	49 89 8d ec 00 00 00 	mov    QWORD PTR [r13+0xec],rcx
    7599fe401164:	74 50                	je     0x7599fe4011b6
    7599fe401166:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    7599fe40116d:	c0 00 01 00 
    7599fe401171:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe401178:	83 c0 02             	add    eax,0x2
    7599fe40117b:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe401182:	39 c8                	cmp    eax,ecx
    7599fe401184:	0f 83 0b 0d 00 18    	jae    0x759a16401e95
    7599fe40118a:	81 bb 00 06 08 00 c0 	cmp    DWORD PTR [rbx+0x80600],0x100c0
    7599fe401191:	00 01 00 
    7599fe401194:	0f 85 fb 0c 00 18    	jne    0x759a16401e95
    7599fe40119a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    7599fe4011a1:	c0 00 01 00 
    7599fe4011a5:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe4011ac:	48 8b 83 08 06 08 00 	mov    rax,QWORD PTR [rbx+0x80608]
    7599fe4011b3:	59                   	pop    rcx
    7599fe4011b4:	ff e0                	jmp    rax
    7599fe4011b6:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    7599fe4011ba:	f6 c1 03             	test   cl,0x3
    7599fe4011bd:	0f 85 2a 0d 00 18    	jne    0x759a16401eed
    7599fe4011c3:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7599fe4011c7:	48 89 ce             	mov    rsi,rcx
    7599fe4011ca:	48 c1 ee 0c          	shr    rsi,0xc
    7599fe4011ce:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7599fe4011d2:	48 85 c0             	test   rax,rax
    7599fe4011d5:	0f 84 9d 0d 00 18    	je     0x759a16401f78
    7599fe4011db:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4011e1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4011e4:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    7599fe4011e8:	0f 85 cf 0d 00 18    	jne    0x759a16401fbd
    7599fe4011ee:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x1009c
    7599fe4011f5:	9c 00 01 00 
    7599fe4011f9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7599fe401200:	28 04 01 00 
    7599fe401204:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe40120b:	83 c0 04             	add    eax,0x4
    7599fe40120e:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe401215:	39 c8                	cmp    eax,ecx
    7599fe401217:	0f 83 aa 0c 00 18    	jae    0x759a16401ec7
    7599fe40121d:	81 bb 40 21 08 00 28 	cmp    DWORD PTR [rbx+0x82140],0x10428
    7599fe401224:	04 01 00 
    7599fe401227:	0f 85 9a 0c 00 18    	jne    0x759a16401ec7
    7599fe40122d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7599fe401234:	28 04 01 00 
    7599fe401238:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe40123f:	48 8b 83 48 21 08 00 	mov    rax,QWORD PTR [rbx+0x82148]
    7599fe401246:	59                   	pop    rcx
    7599fe401247:	ff e0                	jmp    rax
    7599fe401249:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7599fe401250:	01 
    7599fe401251:	58                   	pop    rax
    7599fe401252:	c2 08 00             	ret    0x8
