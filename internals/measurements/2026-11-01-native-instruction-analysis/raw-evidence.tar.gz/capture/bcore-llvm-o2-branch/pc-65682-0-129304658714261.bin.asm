
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65682-0-129304658714261.bin:     file format binary


Disassembly of section .data:

0000759a16401e95 <.data>:
    759a16401e95:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    759a16401e9c:	c0 00 01 00 
    759a16401ea0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401ea7:	02 00 00 00 
    759a16401eab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16401eb2:	02 00 00 00 
    759a16401eb6:	e9 8e f3 ff e7       	jmp    0x7599fe401249
    759a16401ebb:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    759a16401ec2:	01 
    759a16401ec3:	58                   	pop    rax
    759a16401ec4:	c2 08 00             	ret    0x8
    759a16401ec7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    759a16401ece:	28 04 01 00 
    759a16401ed2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16401ed9:	04 00 00 00 
    759a16401edd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    759a16401ee4:	04 00 00 00 
    759a16401ee8:	e9 5c f3 ff e7       	jmp    0x7599fe401249
    759a16401eed:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    759a16401ef4:	96 00 01 00 
    759a16401ef8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401eff:	02 00 00 00 
    759a16401f03:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a16401f0a:	03 00 00 00 
    759a16401f0e:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16401f15:	64 00 00 
    759a16401f18:	4c 89 ef             	mov    rdi,r13
    759a16401f1b:	4c 89 f6             	mov    rsi,r14
    759a16401f1e:	ba 96 00 01 00       	mov    edx,0x10096
    759a16401f23:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16401f29:	ff d0                	call   rax
    759a16401f2b:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    759a16401f32:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    759a16401f39:	83 c0 03             	add    eax,0x3
    759a16401f3c:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    759a16401f43:	39 d0                	cmp    eax,edx
    759a16401f45:	0f 83 b5 00 00 00    	jae    0x759a16402000
    759a16401f4b:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    759a16401f52:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    759a16401f58:	39 0c 13             	cmp    DWORD PTR [rbx+rdx*1],ecx
    759a16401f5b:	0f 85 9f 00 00 00    	jne    0x759a16402000
    759a16401f61:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    759a16401f68:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    759a16401f6f:	00 
    759a16401f70:	48 8b 44 13 08       	mov    rax,QWORD PTR [rbx+rdx*1+0x8]
    759a16401f75:	59                   	pop    rcx
    759a16401f76:	ff e0                	jmp    rax
    759a16401f78:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10096
    759a16401f7f:	96 00 01 00 
    759a16401f83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401f8a:	02 00 00 00 
    759a16401f8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a16401f95:	03 00 00 00 
    759a16401f99:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16401fa0:	64 00 00 
    759a16401fa3:	4c 89 f7             	mov    rdi,r14
    759a16401fa6:	89 ce                	mov    esi,ecx
    759a16401fa8:	ff d0                	call   rax
    759a16401faa:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16401fb1:	00 
    759a16401fb2:	0f 84 2c f2 ff e7    	je     0x7599fe4011e4
    759a16401fb8:	e9 6e ff ff ff       	jmp    0x759a16401f2b
    759a16401fbd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10098
    759a16401fc4:	98 00 01 00 
    759a16401fc8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401fcf:	02 00 00 00 
    759a16401fd3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a16401fda:	03 00 00 00 
    759a16401fde:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16401fe5:	64 00 00 
    759a16401fe8:	4c 89 ef             	mov    rdi,r13
    759a16401feb:	ff d0                	call   rax
    759a16401fed:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16401ff4:	00 
    759a16401ff5:	0f 84 f3 f1 ff e7    	je     0x7599fe4011ee
    759a16401ffb:	e9 2b ff ff ff       	jmp    0x759a16401f2b
    759a16402000:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402007:	02 00 00 00 
    759a1640200b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a16402012:	03 00 00 00 
    759a16402016:	58                   	pop    rax
    759a16402017:	c2 08 00             	ret    0x8
