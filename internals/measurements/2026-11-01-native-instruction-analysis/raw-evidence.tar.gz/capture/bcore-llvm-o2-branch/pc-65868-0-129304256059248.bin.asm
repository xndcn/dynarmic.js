
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65868-0-129304256059248.bin:     file format binary


Disassembly of section .data:

00007599fe401770 <.data>:
    7599fe401770:	48 83 ec 18          	sub    rsp,0x18
    7599fe401774:	b8 91 fe fe ff       	mov    eax,0xfffefe91
    7599fe401779:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7599fe401780:	01 c1                	add    ecx,eax
    7599fe401782:	83 f9 dc             	cmp    ecx,0xffffffdc
    7599fe401785:	0f 87 78 0f 00 18    	ja     0x759a16402703
    7599fe40178b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7599fe401792:	83 f8 dc             	cmp    eax,0xffffffdc
    7599fe401795:	0f 87 68 0f 00 18    	ja     0x759a16402703
    7599fe40179b:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7599fe4017a2:	45 8b 65 38          	mov    r12d,DWORD PTR [r13+0x38]
    7599fe4017a6:	41 8d 4c 24 fc       	lea    ecx,[r12-0x4]
    7599fe4017ab:	41 f6 c4 03          	test   r12b,0x3
    7599fe4017af:	0f 85 5d 0f 00 18    	jne    0x759a16402712
    7599fe4017b5:	4d 8b bd 38 01 00 00 	mov    r15,QWORD PTR [r13+0x138]
    7599fe4017bc:	4d 8b 85 40 01 00 00 	mov    r8,QWORD PTR [r13+0x140]
    7599fe4017c3:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7599fe4017c7:	89 c8                	mov    eax,ecx
    7599fe4017c9:	c1 e8 0c             	shr    eax,0xc
    7599fe4017cc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe4017d0:	48 85 c0             	test   rax,rax
    7599fe4017d3:	0f 84 df 0f 00 18    	je     0x759a164027b8
    7599fe4017d9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4017df:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4017e2:	41 8d 74 24 f8       	lea    esi,[r12-0x8]
    7599fe4017e7:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7599fe4017eb:	89 f0                	mov    eax,esi
    7599fe4017ed:	c1 e8 0c             	shr    eax,0xc
    7599fe4017f0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe4017f4:	48 85 c0             	test   rax,rax
    7599fe4017f7:	0f 84 0f 10 00 18    	je     0x759a1640280c
    7599fe4017fd:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe401803:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7599fe401806:	41 8d 74 24 f4       	lea    esi,[r12-0xc]
    7599fe40180b:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7599fe40180f:	89 f0                	mov    eax,esi
    7599fe401811:	c1 e8 0c             	shr    eax,0xc
    7599fe401814:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe401818:	48 85 c0             	test   rax,rax
    7599fe40181b:	0f 84 3d 10 00 18    	je     0x759a1640285e
    7599fe401821:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe401827:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7599fe40182a:	41 8d 74 24 f0       	lea    esi,[r12-0x10]
    7599fe40182f:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7599fe401833:	89 f0                	mov    eax,esi
    7599fe401835:	c1 e8 0c             	shr    eax,0xc
    7599fe401838:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe40183c:	48 85 c0             	test   rax,rax
    7599fe40183f:	0f 84 6b 10 00 18    	je     0x759a164028b0
    7599fe401845:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe40184b:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7599fe40184e:	41 8d 5c 24 ec       	lea    ebx,[r12-0x14]
    7599fe401853:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7599fe401857:	89 d8                	mov    eax,ebx
    7599fe401859:	c1 e8 0c             	shr    eax,0xc
    7599fe40185c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe401860:	48 85 c0             	test   rax,rax
    7599fe401863:	0f 84 99 10 00 18    	je     0x759a16402902
    7599fe401869:	89 d9                	mov    ecx,ebx
    7599fe40186b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe401871:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe401874:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7599fe401878:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe40187c:	0f 85 d4 10 00 18    	jne    0x759a16402956
    7599fe401882:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7599fe401886:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe40188d:	41 8d 74 24 e8       	lea    esi,[r12-0x18]
    7599fe401892:	89 f0                	mov    eax,esi
    7599fe401894:	c1 e8 0c             	shr    eax,0xc
    7599fe401897:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe40189b:	48 85 c0             	test   rax,rax
    7599fe40189e:	0f 84 0f 11 00 18    	je     0x759a164029b3
    7599fe4018a4:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4018aa:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7599fe4018ad:	41 8d 6c 24 e4       	lea    ebp,[r12-0x1c]
    7599fe4018b2:	89 e8                	mov    eax,ebp
    7599fe4018b4:	c1 e8 0c             	shr    eax,0xc
    7599fe4018b7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe4018bb:	48 85 c0             	test   rax,rax
    7599fe4018be:	0f 84 4c 11 00 18    	je     0x759a16402a10
    7599fe4018c4:	89 e9                	mov    ecx,ebp
    7599fe4018c6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4018cc:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    7599fe4018cf:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe4018d3:	41 83 c4 d8          	add    r12d,0xffffffd8
    7599fe4018d7:	45 89 65 38          	mov    DWORD PTR [r13+0x38],r12d
    7599fe4018db:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe4018df:	0f 85 89 11 00 18    	jne    0x759a16402a6e
    7599fe4018e5:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7599fe4018e9:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7599fe4018ed:	89 c1                	mov    ecx,eax
    7599fe4018ef:	c1 e9 1f             	shr    ecx,0x1f
    7599fe4018f2:	31 d2                	xor    edx,edx
    7599fe4018f4:	85 c0                	test   eax,eax
    7599fe4018f6:	0f 94 c2             	sete   dl
    7599fe4018f9:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7599fe401900:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7599fe401907:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe40190e:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7599fe401915:	00 00 00 
    7599fe401918:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7599fe40191f:	74 77                	je     0x7599fe401998
    7599fe401921:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    7599fe401925:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe40192c:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    7599fe401930:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    7599fe401934:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    7599fe40193b:	00 
    7599fe40193c:	41 c7 45 10 0d 66 19 	mov    DWORD PTR [r13+0x10],0x19660d
    7599fe401943:	00 
    7599fe401944:	41 c7 45 34 5f f3 6e 	mov    DWORD PTR [r13+0x34],0x3c6ef35f
    7599fe40194b:	3c 
    7599fe40194c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7599fe401953:	7c 01 01 00 
    7599fe401957:	83 c0 0d             	add    eax,0xd
    7599fe40195a:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe401961:	39 c8                	cmp    eax,ecx
    7599fe401963:	0f 83 74 0d 00 18    	jae    0x759a164026dd
    7599fe401969:	81 bf e0 0b 08 00 7c 	cmp    DWORD PTR [rdi+0x80be0],0x1017c
    7599fe401970:	01 01 00 
    7599fe401973:	0f 85 64 0d 00 18    	jne    0x759a164026dd
    7599fe401979:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7599fe401980:	7c 01 01 00 
    7599fe401984:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe40198b:	48 8b 87 e8 0b 08 00 	mov    rax,QWORD PTR [rdi+0x80be8]
    7599fe401992:	48 83 c4 18          	add    rsp,0x18
    7599fe401996:	ff e0                	jmp    rax
    7599fe401998:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    7599fe40199f:	9c 01 01 00 
    7599fe4019a3:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe4019aa:	83 c0 05             	add    eax,0x5
    7599fe4019ad:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe4019b4:	39 c8                	cmp    eax,ecx
    7599fe4019b6:	0f 83 13 11 00 18    	jae    0x759a16402acf
    7599fe4019bc:	81 bf e0 0c 08 00 9c 	cmp    DWORD PTR [rdi+0x80ce0],0x1019c
    7599fe4019c3:	01 01 00 
    7599fe4019c6:	0f 85 03 11 00 18    	jne    0x759a16402acf
    7599fe4019cc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    7599fe4019d3:	9c 01 01 00 
    7599fe4019d7:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe4019de:	48 8b 87 e8 0c 08 00 	mov    rax,QWORD PTR [rdi+0x80ce8]
    7599fe4019e5:	48 83 c4 18          	add    rsp,0x18
    7599fe4019e9:	ff e0                	jmp    rax
    7599fe4019eb:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7599fe4019f2:	01 
    7599fe4019f3:	48 83 c4 18          	add    rsp,0x18
    7599fe4019f7:	c2 08 00             	ret    0x8
