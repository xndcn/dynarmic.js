; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001009c(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65727
  %5 = icmp ult i32 %4, -35
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb222 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb222, -65727
  %8 = icmp ult i32 %7, -35
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x0001009c, label %common.ret, !prof !0

insn_0x0001009c:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 48
  %ptr = load i32, ptr %10, align 4
  %11 = getelementptr i8, ptr %cpu, i64 20
  %val = load i32, ptr %11, align 4
  %12 = and i32 %ptr, 3
  %.not = icmp eq i32 %12, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x0001009c
  %13 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %13, align 4
  %14 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %14, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65692, i32 %ptr, i32 65536)
  %15 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 296
  %17 = load i8, ptr %16, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001009c
  %18 = lshr i32 %ptr, 12
  %page_index = zext i32 %18 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %19 = and i32 %ptr, 4095
  %page_offset = zext i32 %19 to i64
  %20 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %20, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %21 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %22, align 4
  tail call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %23 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %23, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_wr_done, label %did_jump_exit, !prof !0

page_wr_done:                                     ; preds = %page_wr_slow, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not266 = icmp eq i8 %cec_pending, 0
  br i1 %.not266, label %insn_0x0001009e, label %cec_check, !prof !0

did_jump_exit:                                    ; preds = %page_wr_slow
  %24 = getelementptr i8, ptr %cpu, i64 188
  %next_pc223 = load i32, ptr %24, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done
  %25 = getelementptr i8, ptr %cpu, i64 188
  store i32 65694, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %27, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %28 = getelementptr i8, ptr %cpu, i64 296
  %dj3 = load i8, ptr %28, align 1
  %dj_set4.not = icmp eq i8 %dj3, 0
  br i1 %dj_set4.not, label %insn_0x0001009e, label %did_jump_exit1, !prof !0

did_jump_exit1:                                   ; preds = %cec_check
  %next_pc224 = load i32, ptr %25, align 4
  br label %chain_exit

insn_0x0001009e:                                  ; preds = %page_wr_done, %cec_check
  %29 = getelementptr i8, ptr %cpu, i64 52
  %ptr5 = load i32, ptr %29, align 4
  %val6 = load i32, ptr %cpu, align 4
  %30 = and i32 %ptr5, 3
  %.not267 = icmp eq i32 %30, 0
  br i1 %.not267, label %data_aligned8, label %data_misaligned7, !prof !0

data_misaligned7:                                 ; preds = %insn_0x0001009e
  %31 = getelementptr i8, ptr %cpu, i64 188
  store i32 65694, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %33, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65694, i32 %ptr5, i32 65536)
  %next_pc225 = load i32, ptr %31, align 4
  %34 = getelementptr i8, ptr %cpu, i64 296
  %35 = load i8, ptr %34, align 1
  br label %chain_exit

data_aligned8:                                    ; preds = %insn_0x0001009e
  %36 = lshr i32 %ptr5, 12
  %page_index12 = zext i32 %36 to i64
  %page_slot13 = getelementptr ptr, ptr %page_table, i64 %page_index12
  %page14 = load ptr, ptr %page_slot13, align 8
  %page_mapped15.not = icmp eq ptr %page14, null
  br i1 %page_mapped15.not, label %page_wr_slow10, label %page_wr_fast9, !prof !1

page_wr_fast9:                                    ; preds = %data_aligned8
  %37 = and i32 %ptr5, 4095
  %page_offset16 = zext i32 %37 to i64
  %38 = getelementptr i8, ptr %page14, i64 %page_offset16
  store i32 %val6, ptr %38, align 4
  br label %page_wr_done11

page_wr_slow10:                                   ; preds = %data_aligned8
  %39 = getelementptr i8, ptr %cpu, i64 188
  store i32 65694, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %41, align 4
  tail call void @mem_write32(ptr %mem, i32 %ptr5, i32 %val6)
  %42 = getelementptr i8, ptr %cpu, i64 296
  %dj19 = load i8, ptr %42, align 1
  %dj_set20.not = icmp eq i8 %dj19, 0
  br i1 %dj_set20.not, label %page_wr_done11, label %did_jump_exit17, !prof !0

page_wr_done11:                                   ; preds = %page_wr_slow10, %page_wr_fast9
  %ptr_inc = add i32 %ptr5, 4
  store i32 %ptr_inc, ptr %29, align 4
  %cec_pending21 = load i8, ptr %cec_pending_flag, align 1
  %.not268 = icmp eq i8 %cec_pending21, 0
  br i1 %.not268, label %insn_0x000100a0, label %cec_check22, !prof !0

did_jump_exit17:                                  ; preds = %page_wr_slow10
  %next_pc226 = load i32, ptr %39, align 4
  br label %chain_exit

cec_check22:                                      ; preds = %page_wr_done11
  %43 = getelementptr i8, ptr %cpu, i64 188
  store i32 65696, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %45, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %46 = getelementptr i8, ptr %cpu, i64 296
  %dj26 = load i8, ptr %46, align 1
  %dj_set27.not = icmp eq i8 %dj26, 0
  br i1 %dj_set27.not, label %insn_0x000100a0, label %did_jump_exit24, !prof !0

did_jump_exit24:                                  ; preds = %cec_check22
  %next_pc227 = load i32, ptr %43, align 4
  br label %chain_exit

insn_0x000100a0:                                  ; preds = %page_wr_done11, %cec_check22
  %47 = getelementptr i8, ptr %cpu, i64 28
  %rd = load i32, ptr %47, align 4
  %rd_add = add i32 %rd, 1
  store i32 %rd_add, ptr %47, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %48 = xor i32 %flgs, -1
  %overflow = and i32 %flgn, %48
  %49 = icmp eq i32 %rd, -1
  %ac0 = zext i1 %49 to i32
  %50 = icmp eq i32 %rd_add, 0
  %az = zext i1 %50 to i32
  %51 = getelementptr i8, ptr %cpu, i64 228
  store i32 %az, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 232
  store i32 %flgn, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %53, align 4
  %54 = or i32 %vs_cur, %overflow
  %55 = getelementptr i8, ptr %cpu, i64 248
  store i32 %overflow, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i64 252
  store i32 %overflow, ptr %56, align 4
  store i32 %54, ptr %53, align 4
  %57 = getelementptr i8, ptr %cpu, i64 236
  store i32 %ac0, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 240
  store i32 %ac0, ptr %58, align 4
  store i32 6, ptr %cpu, align 4
  %59 = getelementptr i8, ptr %cpu, i64 44
  %ptr28 = load i32, ptr %59, align 4
  %60 = and i32 %ptr28, 3
  %.not269 = icmp eq i32 %60, 0
  br i1 %.not269, label %data_aligned30, label %data_misaligned29, !prof !0

data_misaligned29:                                ; preds = %insn_0x000100a0
  %61 = getelementptr i8, ptr %cpu, i64 188
  store i32 65700, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %63, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65700, i32 %ptr28, i32 65536)
  %next_pc228 = load i32, ptr %61, align 4
  %64 = getelementptr i8, ptr %cpu, i64 296
  %65 = load i8, ptr %64, align 1
  br label %chain_exit

data_aligned30:                                   ; preds = %insn_0x000100a0
  %66 = lshr i32 %ptr28, 12
  %page_index34 = zext i32 %66 to i64
  %page_slot35 = getelementptr ptr, ptr %page_table, i64 %page_index34
  %page36 = load ptr, ptr %page_slot35, align 8
  %page_mapped37.not = icmp eq ptr %page36, null
  br i1 %page_mapped37.not, label %page_wr_slow32, label %page_wr_fast31, !prof !1

page_wr_fast31:                                   ; preds = %data_aligned30
  %67 = and i32 %ptr28, 4095
  %page_offset38 = zext i32 %67 to i64
  %68 = getelementptr i8, ptr %page36, i64 %page_offset38
  store i32 %rd_add, ptr %68, align 4
  br label %page_wr_done33

page_wr_slow32:                                   ; preds = %data_aligned30
  %69 = getelementptr i8, ptr %cpu, i64 188
  store i32 65700, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %71, align 4
  tail call void @mem_write32(ptr %mem, i32 %ptr28, i32 %rd_add)
  %72 = getelementptr i8, ptr %cpu, i64 296
  %dj41 = load i8, ptr %72, align 1
  %dj_set42.not = icmp eq i8 %dj41, 0
  br i1 %dj_set42.not, label %page_wr_done33, label %did_jump_exit39, !prof !0

page_wr_done33:                                   ; preds = %page_wr_slow32, %page_wr_fast31
  %cec_pending43 = load i8, ptr %cec_pending_flag, align 1
  %.not270 = icmp eq i8 %cec_pending43, 0
  br i1 %.not270, label %insn_0x000100a6, label %cec_check44, !prof !0

did_jump_exit39:                                  ; preds = %page_wr_slow32
  %next_pc229 = load i32, ptr %69, align 4
  br label %chain_exit

cec_check44:                                      ; preds = %page_wr_done33
  %73 = getelementptr i8, ptr %cpu, i64 188
  store i32 65702, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %75, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %76 = getelementptr i8, ptr %cpu, i64 296
  %dj48 = load i8, ptr %76, align 1
  %dj_set49.not = icmp eq i8 %dj48, 0
  br i1 %dj_set49.not, label %insn_0x000100a6, label %did_jump_exit46, !prof !0

did_jump_exit46:                                  ; preds = %cec_check44
  %next_pc230 = load i32, ptr %73, align 4
  br label %chain_exit

insn_0x000100a6:                                  ; preds = %page_wr_done33, %cec_check44
  %diff = add i32 %rd, -5
  %77 = icmp eq i32 %diff, 0
  %az50 = zext i1 %77 to i32
  %flgn51 = lshr i32 %diff, 31
  %an54 = or i32 %flgn51, %flgn
  %78 = icmp ugt i32 %rd_add, 5
  %ac055 = zext i1 %78 to i32
  %79 = getelementptr i8, ptr %cpu, i64 276
  store i32 %az50, ptr %79, align 4
  store i32 %az50, ptr %51, align 4
  store i32 %an54, ptr %52, align 4
  store i32 %ac055, ptr %57, align 4
  store i32 %ac055, ptr %58, align 4
  br i1 %77, label %insn_0x000100aa, label %brcc_taken

brcc_taken:                                       ; preds = %insn_0x000100a6
  %80 = getelementptr i8, ptr %cpu, i64 188
  store i32 65668, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %81, align 4
  %chain_total = add nuw i32 %chain_packets, 7
  %82 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %82 monotonic, align 4, !range !2
  %83 = icmp ult i32 %chain_total, %chain_budget
  br i1 %83, label %chain_go, label %chain_leave231, !prof !0

insn_0x000100aa:                                  ; preds = %insn_0x000100a6
  %84 = getelementptr i8, ptr %cpu, i64 40
  store i32 2, ptr %cpu, align 4
  store i32 61456, ptr %84, align 4
  %page_slot62 = getelementptr ptr, ptr %page_table, i64 15
  %page63 = load ptr, ptr %page_slot62, align 8
  %page_mapped64.not = icmp eq ptr %page63, null
  br i1 %page_mapped64.not, label %page_wr_slow59, label %page_wr_fast58, !prof !1

page_wr_fast58:                                   ; preds = %insn_0x000100aa
  %85 = getelementptr i8, ptr %page63, i64 16
  store i32 2, ptr %85, align 4
  br label %page_wr_done60

page_wr_slow59:                                   ; preds = %insn_0x000100aa
  %86 = getelementptr i8, ptr %cpu, i64 188
  store i32 65716, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i64 308
  store i32 11, ptr %88, align 4
  tail call void @mem_write32(ptr %mem, i32 61456, i32 2)
  %89 = getelementptr i8, ptr %cpu, i64 296
  %dj68 = load i8, ptr %89, align 1
  %dj_set69.not = icmp eq i8 %dj68, 0
  br i1 %dj_set69.not, label %page_wr_done60, label %did_jump_exit66, !prof !0

page_wr_done60:                                   ; preds = %page_wr_slow59, %page_wr_fast58
  %cec_pending70 = load i8, ptr %cec_pending_flag, align 1
  %.not271 = icmp eq i8 %cec_pending70, 0
  br i1 %.not271, label %insn_0x000100b6, label %cec_check71, !prof !0

did_jump_exit66:                                  ; preds = %page_wr_slow59
  %next_pc233 = load i32, ptr %86, align 4
  br label %chain_exit

cec_check71:                                      ; preds = %page_wr_done60
  %90 = getelementptr i8, ptr %cpu, i64 188
  store i32 65718, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 308
  store i32 11, ptr %92, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %93 = getelementptr i8, ptr %cpu, i64 296
  %dj75 = load i8, ptr %93, align 1
  %dj_set76.not = icmp eq i8 %dj75, 0
  br i1 %dj_set76.not, label %insn_0x000100b6, label %did_jump_exit73, !prof !0

did_jump_exit73:                                  ; preds = %cec_check71
  %next_pc234 = load i32, ptr %90, align 4
  br label %chain_exit

insn_0x000100b6:                                  ; preds = %page_wr_done60, %cec_check71
  %94 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %94, align 4
  %95 = and i32 %fp, 3
  %.not272 = icmp eq i32 %95, 0
  br i1 %.not272, label %data_aligned78, label %data_misaligned77, !prof !0

data_misaligned77:                                ; preds = %insn_0x000100b6
  %96 = getelementptr i8, ptr %cpu, i64 188
  store i32 65718, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %98, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65718, i32 %fp, i32 0)
  %next_pc235 = load i32, ptr %96, align 4
  %99 = getelementptr i8, ptr %cpu, i64 296
  %100 = load i8, ptr %99, align 1
  br label %chain_exit

data_aligned78:                                   ; preds = %insn_0x000100b6
  %101 = lshr i32 %fp, 12
  %page_index79 = zext i32 %101 to i64
  %page_slot80 = getelementptr ptr, ptr %page_table, i64 %page_index79
  %page81 = load ptr, ptr %page_slot80, align 8
  %page_mapped82.not = icmp eq ptr %page81, null
  br i1 %page_mapped82.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %data_aligned78
  %102 = and i32 %fp, 4095
  %page_offset83 = zext i32 %102 to i64
  %103 = getelementptr i8, ptr %page81, i64 %page_offset83
  %page_val = load i32, ptr %103, align 4
  br label %data_aligned89

page_slow:                                        ; preds = %data_aligned78
  %104 = getelementptr i8, ptr %cpu, i64 188
  store i32 65718, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %106, align 4
  %107 = tail call i32 @mem_read32(ptr %mem, i32 %fp)
  %108 = getelementptr i8, ptr %cpu, i64 296
  %dj86 = load i8, ptr %108, align 1
  %dj_set87.not = icmp eq i8 %dj86, 0
  br i1 %dj_set87.not, label %data_aligned89, label %did_jump_exit84, !prof !0

did_jump_exit84:                                  ; preds = %page_slow
  %next_pc236 = load i32, ptr %104, align 4
  br label %chain_exit

data_aligned89:                                   ; preds = %page_fast, %page_slow
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %107, %page_slow ]
  %sp1 = add i32 %fp, 4
  %109 = lshr i32 %sp1, 12
  %page_index93 = zext i32 %109 to i64
  %page_slot94 = getelementptr ptr, ptr %page_table, i64 %page_index93
  %page95 = load ptr, ptr %page_slot94, align 8
  %page_mapped96.not = icmp eq ptr %page95, null
  br i1 %page_mapped96.not, label %page_slow91, label %page_fast90, !prof !1

page_fast90:                                      ; preds = %data_aligned89
  %110 = and i32 %sp1, 4095
  %page_offset97 = zext i32 %110 to i64
  %111 = getelementptr i8, ptr %page95, i64 %page_offset97
  %page_val98 = load i32, ptr %111, align 4
  br label %data_aligned105

page_slow91:                                      ; preds = %data_aligned89
  %112 = getelementptr i8, ptr %cpu, i64 188
  store i32 65718, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 308
  store i32 12, ptr %114, align 4
  %115 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %116 = getelementptr i8, ptr %cpu, i64 296
  %dj101 = load i8, ptr %116, align 1
  %dj_set102.not = icmp eq i8 %dj101, 0
  br i1 %dj_set102.not, label %data_aligned105, label %did_jump_exit99, !prof !0

did_jump_exit99:                                  ; preds = %page_slow91
  %next_pc238 = load i32, ptr %112, align 4
  br label %chain_exit

data_aligned105:                                  ; preds = %page_fast90, %page_slow91
  %mem_val103 = phi i32 [ %page_val98, %page_fast90 ], [ %115, %page_slow91 ]
  %sp2 = add i32 %fp, 8
  store i32 %mem_val, ptr %94, align 4
  %117 = getelementptr i8, ptr %cpu, i64 168
  store i32 %mem_val103, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i64 56
  store i32 %sp2, ptr %118, align 4
  store i32 0, ptr %cpu, align 4
  %119 = lshr i32 %sp2, 12
  %page_index109 = zext i32 %119 to i64
  %page_slot110 = getelementptr ptr, ptr %page_table, i64 %page_index109
  %page111 = load ptr, ptr %page_slot110, align 8
  %page_mapped112.not = icmp eq ptr %page111, null
  br i1 %page_mapped112.not, label %page_slow107, label %page_fast106, !prof !1

page_fast106:                                     ; preds = %data_aligned105
  %120 = and i32 %sp2, 4095
  %page_offset113 = zext i32 %120 to i64
  %121 = getelementptr i8, ptr %page111, i64 %page_offset113
  %page_val114 = load i32, ptr %121, align 4
  br label %data_aligned121

page_slow107:                                     ; preds = %data_aligned105
  %122 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %122, align 4
  %123 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %124, align 4
  %125 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %126 = getelementptr i8, ptr %cpu, i64 296
  %dj117 = load i8, ptr %126, align 1
  %dj_set118.not = icmp eq i8 %dj117, 0
  br i1 %dj_set118.not, label %data_aligned121, label %did_jump_exit115, !prof !0

did_jump_exit115:                                 ; preds = %page_slow107
  %next_pc240 = load i32, ptr %122, align 4
  br label %chain_exit

data_aligned121:                                  ; preds = %page_fast106, %page_slow107
  %mem_val119 = phi i32 [ %page_val114, %page_fast106 ], [ %125, %page_slow107 ]
  store i32 %mem_val119, ptr %29, align 4
  %sp_inc = add i32 %fp, 12
  %127 = lshr i32 %sp_inc, 12
  %page_index125 = zext i32 %127 to i64
  %page_slot126 = getelementptr ptr, ptr %page_table, i64 %page_index125
  %page127 = load ptr, ptr %page_slot126, align 8
  %page_mapped128.not = icmp eq ptr %page127, null
  br i1 %page_mapped128.not, label %page_slow123, label %page_fast122, !prof !1

page_fast122:                                     ; preds = %data_aligned121
  %128 = and i32 %sp_inc, 4095
  %page_offset129 = zext i32 %128 to i64
  %129 = getelementptr i8, ptr %page127, i64 %page_offset129
  %page_val130 = load i32, ptr %129, align 4
  br label %data_aligned138

page_slow123:                                     ; preds = %data_aligned121
  %130 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %132, align 4
  %133 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %134 = getelementptr i8, ptr %cpu, i64 296
  %dj133 = load i8, ptr %134, align 1
  %dj_set134.not = icmp eq i8 %dj133, 0
  br i1 %dj_set134.not, label %data_aligned138, label %did_jump_exit131, !prof !0

did_jump_exit131:                                 ; preds = %page_slow123
  %next_pc242 = load i32, ptr %130, align 4
  br label %chain_exit

data_aligned138:                                  ; preds = %page_fast122, %page_slow123
  %mem_val135 = phi i32 [ %page_val130, %page_fast122 ], [ %133, %page_slow123 ]
  store i32 %mem_val135, ptr %10, align 4
  %sp_inc136 = add i32 %fp, 16
  %135 = lshr i32 %sp_inc136, 12
  %page_index142 = zext i32 %135 to i64
  %page_slot143 = getelementptr ptr, ptr %page_table, i64 %page_index142
  %page144 = load ptr, ptr %page_slot143, align 8
  %page_mapped145.not = icmp eq ptr %page144, null
  br i1 %page_mapped145.not, label %page_slow140, label %page_fast139, !prof !1

page_fast139:                                     ; preds = %data_aligned138
  %136 = and i32 %sp_inc136, 4095
  %page_offset146 = zext i32 %136 to i64
  %137 = getelementptr i8, ptr %page144, i64 %page_offset146
  %page_val147 = load i32, ptr %137, align 4
  br label %data_aligned155

page_slow140:                                     ; preds = %data_aligned138
  %138 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %140, align 4
  %141 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc136)
  %142 = getelementptr i8, ptr %cpu, i64 296
  %dj150 = load i8, ptr %142, align 1
  %dj_set151.not = icmp eq i8 %dj150, 0
  br i1 %dj_set151.not, label %data_aligned155, label %did_jump_exit148, !prof !0

did_jump_exit148:                                 ; preds = %page_slow140
  %next_pc244 = load i32, ptr %138, align 4
  br label %chain_exit

data_aligned155:                                  ; preds = %page_fast139, %page_slow140
  %mem_val152 = phi i32 [ %page_val147, %page_fast139 ], [ %141, %page_slow140 ]
  store i32 %mem_val152, ptr %59, align 4
  %sp_inc153 = add i32 %fp, 20
  %143 = lshr i32 %sp_inc153, 12
  %page_index159 = zext i32 %143 to i64
  %page_slot160 = getelementptr ptr, ptr %page_table, i64 %page_index159
  %page161 = load ptr, ptr %page_slot160, align 8
  %page_mapped162.not = icmp eq ptr %page161, null
  br i1 %page_mapped162.not, label %page_slow157, label %page_fast156, !prof !1

page_fast156:                                     ; preds = %data_aligned155
  %144 = and i32 %sp_inc153, 4095
  %page_offset163 = zext i32 %144 to i64
  %145 = getelementptr i8, ptr %page161, i64 %page_offset163
  %page_val164 = load i32, ptr %145, align 4
  br label %data_aligned172

page_slow157:                                     ; preds = %data_aligned155
  %146 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %146, align 4
  %147 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %148, align 4
  %149 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc153)
  %150 = getelementptr i8, ptr %cpu, i64 296
  %dj167 = load i8, ptr %150, align 1
  %dj_set168.not = icmp eq i8 %dj167, 0
  br i1 %dj_set168.not, label %data_aligned172, label %did_jump_exit165, !prof !0

did_jump_exit165:                                 ; preds = %page_slow157
  %next_pc246 = load i32, ptr %146, align 4
  br label %chain_exit

data_aligned172:                                  ; preds = %page_fast156, %page_slow157
  %mem_val169 = phi i32 [ %page_val164, %page_fast156 ], [ %149, %page_slow157 ]
  store i32 %mem_val169, ptr %47, align 4
  %sp_inc170 = add i32 %fp, 24
  %151 = lshr i32 %sp_inc170, 12
  %page_index176 = zext i32 %151 to i64
  %page_slot177 = getelementptr ptr, ptr %page_table, i64 %page_index176
  %page178 = load ptr, ptr %page_slot177, align 8
  %page_mapped179.not = icmp eq ptr %page178, null
  br i1 %page_mapped179.not, label %page_slow174, label %page_fast173, !prof !1

page_fast173:                                     ; preds = %data_aligned172
  %152 = and i32 %sp_inc170, 4095
  %page_offset180 = zext i32 %152 to i64
  %153 = getelementptr i8, ptr %page178, i64 %page_offset180
  %page_val181 = load i32, ptr %153, align 4
  br label %data_aligned189

page_slow174:                                     ; preds = %data_aligned172
  %154 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %156, align 4
  %157 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc170)
  %158 = getelementptr i8, ptr %cpu, i64 296
  %dj184 = load i8, ptr %158, align 1
  %dj_set185.not = icmp eq i8 %dj184, 0
  br i1 %dj_set185.not, label %data_aligned189, label %did_jump_exit182, !prof !0

did_jump_exit182:                                 ; preds = %page_slow174
  %next_pc248 = load i32, ptr %154, align 4
  br label %chain_exit

data_aligned189:                                  ; preds = %page_fast173, %page_slow174
  %mem_val186 = phi i32 [ %page_val181, %page_fast173 ], [ %157, %page_slow174 ]
  %159 = getelementptr i8, ptr %cpu, i64 24
  store i32 %mem_val186, ptr %159, align 4
  %sp_inc187 = add i32 %fp, 28
  %160 = lshr i32 %sp_inc187, 12
  %page_index193 = zext i32 %160 to i64
  %page_slot194 = getelementptr ptr, ptr %page_table, i64 %page_index193
  %page195 = load ptr, ptr %page_slot194, align 8
  %page_mapped196.not = icmp eq ptr %page195, null
  br i1 %page_mapped196.not, label %page_slow191, label %page_fast190, !prof !1

page_fast190:                                     ; preds = %data_aligned189
  %161 = and i32 %sp_inc187, 4095
  %page_offset197 = zext i32 %161 to i64
  %162 = getelementptr i8, ptr %page195, i64 %page_offset197
  %page_val198 = load i32, ptr %162, align 4
  br label %data_aligned206

page_slow191:                                     ; preds = %data_aligned189
  %163 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %163, align 4
  %164 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %165, align 4
  %166 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc187)
  %167 = getelementptr i8, ptr %cpu, i64 296
  %dj201 = load i8, ptr %167, align 1
  %dj_set202.not = icmp eq i8 %dj201, 0
  br i1 %dj_set202.not, label %data_aligned206, label %did_jump_exit199, !prof !0

did_jump_exit199:                                 ; preds = %page_slow191
  %next_pc250 = load i32, ptr %163, align 4
  br label %chain_exit

data_aligned206:                                  ; preds = %page_fast190, %page_slow191
  %mem_val203 = phi i32 [ %page_val198, %page_fast190 ], [ %166, %page_slow191 ]
  store i32 %mem_val203, ptr %11, align 4
  %sp_inc204 = add i32 %fp, 32
  %168 = lshr i32 %sp_inc204, 12
  %page_index210 = zext i32 %168 to i64
  %page_slot211 = getelementptr ptr, ptr %page_table, i64 %page_index210
  %page212 = load ptr, ptr %page_slot211, align 8
  %page_mapped213.not = icmp eq ptr %page212, null
  br i1 %page_mapped213.not, label %page_slow208, label %page_fast207, !prof !1

page_fast207:                                     ; preds = %data_aligned206
  %169 = and i32 %sp_inc204, 4095
  %page_offset214 = zext i32 %169 to i64
  %170 = getelementptr i8, ptr %page212, i64 %page_offset214
  %page_val215 = load i32, ptr %170, align 4
  br label %page_done209

page_slow208:                                     ; preds = %data_aligned206
  %171 = getelementptr i8, ptr %cpu, i64 188
  store i32 65724, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %173, align 4
  %174 = tail call i32 @mem_read32(ptr %mem, i32 %sp_inc204)
  %175 = getelementptr i8, ptr %cpu, i64 296
  %dj218 = load i8, ptr %175, align 1
  %dj_set219.not = icmp eq i8 %dj218, 0
  br i1 %dj_set219.not, label %page_done209, label %did_jump_exit216, !prof !0

page_done209:                                     ; preds = %page_slow208, %page_fast207
  %mem_val220 = phi i32 [ %page_val215, %page_fast207 ], [ %174, %page_slow208 ]
  %176 = getelementptr i8, ptr %cpu, i64 16
  store i32 %mem_val220, ptr %176, align 4
  %sp_inc221 = add i32 %fp, 36
  store i32 %sp_inc221, ptr %118, align 4
  %lsb = and i32 %mem_val103, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit216:                                 ; preds = %page_slow208
  %next_pc252 = load i32, ptr %171, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done209
  %177 = getelementptr i8, ptr %cpu, i64 188
  store i32 65726, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 308
  store i32 15, ptr %179, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc253 = load i32, ptr %177, align 4
  %180 = getelementptr i8, ptr %cpu, i64 296
  %181 = load i8, ptr %180, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave231, %chain_leave258
  %tail255.sink = phi i32 [ %tail255, %chain_leave258 ], [ 2, %chain_leave231 ]
  %packets.sink = phi i32 [ %packets, %chain_leave258 ], [ 7, %chain_leave231 ]
  %tail257.sink.ph = phi i8 [ %tail257, %chain_leave258 ], [ 1, %chain_leave231 ]
  %182 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail255.sink, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %183, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink281 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail257.sink = phi i8 [ 1, %entry ], [ %tail257.sink.ph, %common.ret.sink.split ]
  %184 = getelementptr i8, ptr %cpu, i64 %.sink281
  store i8 %tail257.sink, ptr %184, align 1
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525344
  %slot_pc = load i32, ptr %chain_slot, align 4
  %185 = icmp eq i32 %slot_pc, 65668
  br i1 %185, label %chain_hit, label %chain_leave231, !prof !0

chain_leave231:                                   ; preds = %chain_go, %brcc_taken
  store i32 65668, ptr %80, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65668, ptr %80, align 4
  store i32 %chain_total, ptr %81, align 4
  %186 = getelementptr i8, ptr %chain_table, i64 525352
  %chain_fn = load ptr, ptr %186, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done209, %jump_misalign, %did_jump_exit216, %did_jump_exit199, %did_jump_exit182, %did_jump_exit165, %did_jump_exit148, %did_jump_exit131, %did_jump_exit115, %did_jump_exit99, %did_jump_exit84, %data_misaligned77, %did_jump_exit73, %did_jump_exit66, %did_jump_exit46, %did_jump_exit39, %data_misaligned29, %did_jump_exit24, %did_jump_exit17, %data_misaligned7, %did_jump_exit1, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit17 ], [ 2, %did_jump_exit24 ], [ 5, %data_misaligned29 ], [ 5, %did_jump_exit39 ], [ 5, %did_jump_exit46 ], [ 11, %did_jump_exit66 ], [ 11, %did_jump_exit73 ], [ 12, %data_misaligned77 ], [ 12, %did_jump_exit84 ], [ 12, %did_jump_exit99 ], [ 14, %did_jump_exit115 ], [ 14, %did_jump_exit131 ], [ 14, %did_jump_exit148 ], [ 14, %did_jump_exit165 ], [ 14, %did_jump_exit182 ], [ 14, %did_jump_exit199 ], [ 14, %did_jump_exit216 ], [ 15, %jump_misalign ], [ 15, %page_done209 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc223, %did_jump_exit ], [ %next_pc224, %did_jump_exit1 ], [ %next_pc225, %data_misaligned7 ], [ %next_pc226, %did_jump_exit17 ], [ %next_pc227, %did_jump_exit24 ], [ %next_pc228, %data_misaligned29 ], [ %next_pc229, %did_jump_exit39 ], [ %next_pc230, %did_jump_exit46 ], [ %next_pc233, %did_jump_exit66 ], [ %next_pc234, %did_jump_exit73 ], [ %next_pc235, %data_misaligned77 ], [ %next_pc236, %did_jump_exit84 ], [ %next_pc238, %did_jump_exit99 ], [ %next_pc240, %did_jump_exit115 ], [ %next_pc242, %did_jump_exit131 ], [ %next_pc244, %did_jump_exit148 ], [ %next_pc246, %did_jump_exit165 ], [ %next_pc248, %did_jump_exit182 ], [ %next_pc250, %did_jump_exit199 ], [ %next_pc252, %did_jump_exit216 ], [ %next_pc253, %jump_misalign ], [ %mem_val103, %page_done209 ]
  %tail255 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit17 ], [ 2, %did_jump_exit24 ], [ 2, %data_misaligned29 ], [ 2, %did_jump_exit39 ], [ 2, %did_jump_exit46 ], [ 2, %did_jump_exit66 ], [ 2, %did_jump_exit73 ], [ 4, %data_misaligned77 ], [ 4, %did_jump_exit84 ], [ 4, %did_jump_exit99 ], [ 2, %did_jump_exit115 ], [ 2, %did_jump_exit131 ], [ 2, %did_jump_exit148 ], [ 2, %did_jump_exit165 ], [ 2, %did_jump_exit182 ], [ 2, %did_jump_exit199 ], [ 2, %did_jump_exit216 ], [ 2, %jump_misalign ], [ 2, %page_done209 ]
  %tail257 = phi i8 [ %17, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj3, %did_jump_exit1 ], [ %35, %data_misaligned7 ], [ %dj19, %did_jump_exit17 ], [ %dj26, %did_jump_exit24 ], [ %65, %data_misaligned29 ], [ %dj41, %did_jump_exit39 ], [ %dj48, %did_jump_exit46 ], [ %dj68, %did_jump_exit66 ], [ %dj75, %did_jump_exit73 ], [ %100, %data_misaligned77 ], [ %dj86, %did_jump_exit84 ], [ %dj101, %did_jump_exit99 ], [ %dj117, %did_jump_exit115 ], [ %dj133, %did_jump_exit131 ], [ %dj150, %did_jump_exit148 ], [ %dj167, %did_jump_exit165 ], [ %dj184, %did_jump_exit182 ], [ %dj201, %did_jump_exit199 ], [ %dj218, %did_jump_exit216 ], [ %181, %jump_misalign ], [ 1, %page_done209 ]
  %187 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets259 = load i32, ptr %187, align 4
  %chain_total260 = add nuw i32 %chain_packets259, %packets
  %188 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget261 = load atomic i32, ptr %188 monotonic, align 4, !range !2
  %189 = icmp ult i32 %chain_total260, %chain_budget261
  br i1 %189, label %chain_lookup, label %chain_leave258, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %190 = shl i32 %tail, 3
  %191 = and i32 %190, 1048560
  %192 = zext i32 %191 to i64
  %chain_slot262 = getelementptr i8, ptr %chain_table, i64 %192
  %slot_pc263 = load i32, ptr %chain_slot262, align 4
  %193 = icmp eq i32 %slot_pc263, %tail
  br i1 %193, label %chain_hit264, label %chain_leave258, !prof !0

chain_leave258:                                   ; preds = %chain_lookup, %chain_exit
  %194 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %194, align 4
  br label %common.ret.sink.split

chain_hit264:                                     ; preds = %chain_lookup
  %195 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %195, align 4
  store i32 %chain_total260, ptr %187, align 4
  %196 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %196, align 1
  %197 = getelementptr i8, ptr %chain_slot262, i64 8
  %chain_fn265 = load ptr, ptr %197, align 8
  musttail call swifttailcc void %chain_fn265(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
