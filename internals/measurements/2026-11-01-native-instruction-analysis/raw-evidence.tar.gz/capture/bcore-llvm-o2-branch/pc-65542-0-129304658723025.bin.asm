
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65542-0-129304658723025.bin:     file format binary


Disassembly of section .data:

0000759a164040d1 <.data>:
    759a164040d1:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    759a164040d8:	01 
    759a164040d9:	58                   	pop    rax
    759a164040da:	c2 08 00             	ret    0x8
    759a164040dd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1000e
    759a164040e4:	0e 00 01 00 
    759a164040e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164040ef:	02 00 00 00 
    759a164040f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a164040fa:	03 00 00 00 
    759a164040fe:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16404105:	64 00 00 
    759a16404108:	4c 89 f7             	mov    rdi,r14
    759a1640410b:	be 04 00 00 01       	mov    esi,0x1000004
    759a16404110:	ff d0                	call   rax
    759a16404112:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16404119:	00 
    759a1640411a:	0f 84 9c ec ff e7    	je     0x7599fe402dbc
    759a16404120:	eb 3e                	jmp    0x759a16404160
    759a16404122:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    759a16404129:	10 00 01 00 
    759a1640412d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16404134:	02 00 00 00 
    759a16404138:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a1640413f:	03 00 00 00 
    759a16404143:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640414a:	64 00 00 
    759a1640414d:	4c 89 ef             	mov    rdi,r13
    759a16404150:	ff d0                	call   rax
    759a16404152:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16404159:	00 
    759a1640415a:	0f 84 66 ec ff e7    	je     0x7599fe402dc6
    759a16404160:	41 8b 8d bc 00 00 00 	mov    ecx,DWORD PTR [r13+0xbc]
    759a16404167:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    759a1640416e:	83 c0 03             	add    eax,0x3
    759a16404171:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    759a16404178:	39 d0                	cmp    eax,edx
    759a1640417a:	73 29                	jae    0x759a164041a5
    759a1640417c:	8d 14 cd 00 00 00 00 	lea    edx,[rcx*8+0x0]
    759a16404183:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    759a16404189:	39 0c 13             	cmp    DWORD PTR [rbx+rdx*1],ecx
    759a1640418c:	75 17                	jne    0x759a164041a5
    759a1640418e:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    759a16404195:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    759a1640419c:	00 
    759a1640419d:	48 8b 44 13 08       	mov    rax,QWORD PTR [rbx+rdx*1+0x8]
    759a164041a2:	59                   	pop    rcx
    759a164041a3:	ff e0                	jmp    rax
    759a164041a5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164041ac:	02 00 00 00 
    759a164041b0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a164041b7:	03 00 00 00 
    759a164041bb:	58                   	pop    rax
    759a164041bc:	c2 08 00             	ret    0x8
