; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010084(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = add i32 %guard_lb, -65679
  %4 = icmp ult i32 %3, -11
  %5 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb24 = load i32, ptr %5, align 4
  %6 = add i32 %guard_lb24, -65679
  %7 = icmp ult i32 %6, -11
  %8 = and i1 %4, %7
  br i1 %8, label %insn_0x00010084, label %lb_guard_miss, !prof !0

insn_0x00010084:                                  ; preds = %entry
  %9 = getelementptr i8, ptr %cpu, i64 16
  %rs = load i32, ptr %9, align 4
  %10 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %10, align 4
  %addr = add i32 %fp, -4
  %11 = and i32 %fp, 3
  %.not = icmp eq i32 %11, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010084
  %12 = getelementptr i8, ptr %cpu, i64 292
  store i32 8, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %13, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65668, i32 %addr, i32 0)
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010084
  %14 = lshr i32 %addr, 12
  %page_index = zext i32 %14 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %data_aligned
  %15 = and i32 %addr, 4095
  %page_offset = zext i32 %15 to i64
  %16 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %16, align 4
  br label %data_aligned3

page_slow:                                        ; preds = %data_aligned
  %17 = getelementptr i8, ptr %cpu, i64 292
  store i32 8, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i64 308
  store i32 1, ptr %18, align 4
  %19 = tail call i32 @mem_read32(ptr %mem, i32 %addr)
  %20 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %20, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_slow.data_aligned3_crit_edge, label %chain_exit, !prof !0

page_slow.data_aligned3_crit_edge:                ; preds = %page_slow
  %lb0.pre = load i32, ptr %2, align 4
  %lb1.pre = load i32, ptr %5, align 4
  br label %data_aligned3

data_aligned3:                                    ; preds = %page_slow.data_aligned3_crit_edge, %page_fast
  %lb1 = phi i32 [ %guard_lb24, %page_fast ], [ %lb1.pre, %page_slow.data_aligned3_crit_edge ]
  %lb0 = phi i32 [ %guard_lb, %page_fast ], [ %lb0.pre, %page_slow.data_aligned3_crit_edge ]
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %19, %page_slow.data_aligned3_crit_edge ]
  store i32 %rs, ptr %cpu, align 4
  %21 = getelementptr i8, ptr %cpu, i64 4
  store i32 %mem_val, ptr %21, align 4
  %addr1 = add i32 %fp, -8
  %22 = lshr i32 %addr1, 12
  %page_index7 = zext i32 %22 to i64
  %page_slot8 = getelementptr ptr, ptr %page_table, i64 %page_index7
  %page9 = load ptr, ptr %page_slot8, align 8
  %page_mapped10.not = icmp eq ptr %page9, null
  br i1 %page_mapped10.not, label %page_slow5, label %page_fast4, !prof !1

page_fast4:                                       ; preds = %data_aligned3
  %23 = and i32 %addr1, 4095
  %page_offset11 = zext i32 %23 to i64
  %24 = getelementptr i8, ptr %page9, i64 %page_offset11
  %page_val12 = load i32, ptr %24, align 4
  br label %page_done6

page_slow5:                                       ; preds = %data_aligned3
  %25 = getelementptr i8, ptr %cpu, i64 188
  store i32 65676, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %27, align 4
  %28 = tail call i32 @mem_read32(ptr %mem, i32 %addr1)
  %29 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %29, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_done6, label %chain_exit, !prof !0

page_done6:                                       ; preds = %page_slow5, %page_fast4
  %mem_val17 = phi i32 [ %page_val12, %page_fast4 ], [ %28, %page_slow5 ]
  %30 = getelementptr i8, ptr %cpu, i64 8
  store i32 %mem_val17, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 152
  %lc = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 144
  %lt = load i32, ptr %32, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65678
  %hwloop_cond = and i1 %at_lb, %lc_gt1
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65682
  %33 = getelementptr i8, ptr %cpu, i64 156
  %lc18 = load i32, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 148
  %lt19 = load i32, ptr %34, align 4
  %lc_gt120 = icmp ugt i32 %lc18, 1
  %at_lb21 = icmp eq i32 %lb1, 65678
  %hwloop_cond22 = and i1 %at_lb21, %lc_gt120
  %hwloop_rets23 = select i1 %hwloop_cond22, i32 %lt19, i32 %hwloop_rets
  %35 = getelementptr i8, ptr %cpu, i64 168
  store i32 %hwloop_rets23, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %37, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %38 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %38 monotonic, align 4, !range !2
  %39 = icmp ult i32 %chain_total, %chain_budget
  br i1 %39, label %chain_go, label %chain_leave28, !prof !0

common.ret:                                       ; preds = %chain_leave31, %chain_leave28, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %40 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %40, align 1
  br label %common.ret

chain_go:                                         ; preds = %page_done6
  %chain_slot = getelementptr i8, ptr %chain_table, i64 530752
  %slot_pc = load i32, ptr %chain_slot, align 4
  %41 = icmp eq i32 %slot_pc, 66344
  br i1 %41, label %chain_hit, label %chain_leave28, !prof !0

chain_leave28:                                    ; preds = %chain_go, %page_done6
  store i32 66344, ptr %36, align 4
  %42 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %44, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 66344, ptr %36, align 4
  store i32 %chain_total, ptr %37, align 4
  %45 = getelementptr i8, ptr %chain_table, i64 530760
  %chain_fn = load ptr, ptr %45, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_slow5, %page_slow, %data_misaligned
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %page_slow ], [ 2, %page_slow5 ]
  %tail = phi i32 [ 8, %data_misaligned ], [ 8, %page_slow ], [ 2, %page_slow5 ]
  %next_pc29.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc29 = load i32, ptr %next_pc29.in, align 4
  %46 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets32 = load i32, ptr %46, align 4
  %chain_total33 = add nuw i32 %chain_packets32, %packets
  %47 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget34 = load atomic i32, ptr %47 monotonic, align 4, !range !2
  %48 = icmp ult i32 %chain_total33, %chain_budget34
  br i1 %48, label %chain_lookup, label %chain_leave31, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %49 = shl i32 %next_pc29, 3
  %50 = and i32 %49, 1048560
  %51 = zext i32 %50 to i64
  %chain_slot35 = getelementptr i8, ptr %chain_table, i64 %51
  %slot_pc36 = load i32, ptr %chain_slot35, align 4
  %52 = icmp eq i32 %slot_pc36, %next_pc29
  br i1 %52, label %chain_hit37, label %chain_leave31, !prof !0

chain_leave31:                                    ; preds = %chain_lookup, %chain_exit
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %54, align 4
  br label %common.ret

chain_hit37:                                      ; preds = %chain_lookup
  store i32 %chain_total33, ptr %46, align 4
  %55 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %55, align 1
  %56 = getelementptr i8, ptr %chain_slot35, i64 8
  %chain_fn38 = load ptr, ptr %56, align 8
  musttail call swifttailcc void %chain_fn38(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
