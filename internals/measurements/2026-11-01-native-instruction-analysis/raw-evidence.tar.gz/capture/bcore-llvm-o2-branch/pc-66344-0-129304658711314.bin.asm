
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-66344-0-129304658711314.bin:     file format binary


Disassembly of section .data:

0000759a16401312 <.data>:
    759a16401312:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    759a16401319:	70 03 01 00 
    759a1640131d:	b1 01                	mov    cl,0x1
    759a1640131f:	bd 06 00 00 00       	mov    ebp,0x6
    759a16401324:	e9 53 04 00 00       	jmp    0x759a1640177c
    759a16401329:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    759a16401330:	70 03 01 00 
    759a16401334:	b1 01                	mov    cl,0x1
    759a16401336:	bd 0a 00 00 00       	mov    ebp,0xa
    759a1640133b:	e9 3c 04 00 00       	jmp    0x759a1640177c
    759a16401340:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401347:	02 00 00 00 
    759a1640134b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16401352:	01 00 00 00 
    759a16401356:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a1640135d:	64 00 00 
    759a16401360:	4c 89 ef             	mov    rdi,r13
    759a16401363:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16401368:	ba 28 03 01 00       	mov    edx,0x10328
    759a1640136d:	44 89 d1             	mov    ecx,r10d
    759a16401370:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16401376:	ff d0                	call   rax
    759a16401378:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a1640137f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401386:	00 
    759a16401387:	bb 02 00 00 00       	mov    ebx,0x2
    759a1640138c:	bd 01 00 00 00       	mov    ebp,0x1
    759a16401391:	e9 72 fa ff e7       	jmp    0x7599fe400e08
    759a16401396:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640139d:	02 00 00 00 
    759a164013a1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164013a8:	01 00 00 00 
    759a164013ac:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164013b3:	64 00 00 
    759a164013b6:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164013bb:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a164013c0:	44 89 d6             	mov    esi,r10d
    759a164013c3:	4d 89 cf             	mov    r15,r9
    759a164013c6:	4c 89 d5             	mov    rbp,r10
    759a164013c9:	4d 89 dc             	mov    r12,r11
    759a164013cc:	ff d0                	call   rax
    759a164013ce:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164013d3:	4d 89 e3             	mov    r11,r12
    759a164013d6:	49 89 ea             	mov    r10,rbp
    759a164013d9:	4d 89 f9             	mov    r9,r15
    759a164013dc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164013e3:	00 
    759a164013e4:	84 c9                	test   cl,cl
    759a164013e6:	0f 84 e2 f5 ff e7    	je     0x7599fe4009ce
    759a164013ec:	e9 f7 01 00 00       	jmp    0x759a164015e8
    759a164013f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164013f8:	02 00 00 00 
    759a164013fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16401403:	01 00 00 00 
    759a16401407:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640140e:	64 00 00 
    759a16401411:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16401416:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a1640141b:	89 ee                	mov    esi,ebp
    759a1640141d:	4d 89 cf             	mov    r15,r9
    759a16401420:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a16401425:	4c 89 d5             	mov    rbp,r10
    759a16401428:	4d 89 dc             	mov    r12,r11
    759a1640142b:	ff d0                	call   rax
    759a1640142d:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401432:	4d 89 e3             	mov    r11,r12
    759a16401435:	49 89 ea             	mov    r10,rbp
    759a16401438:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a1640143d:	4d 89 f9             	mov    r9,r15
    759a16401440:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401447:	00 
    759a16401448:	84 c9                	test   cl,cl
    759a1640144a:	0f 84 ab f5 ff e7    	je     0x7599fe4009fb
    759a16401450:	e9 93 01 00 00       	jmp    0x759a164015e8
    759a16401455:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640145c:	02 00 00 00 
    759a16401460:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16401467:	01 00 00 00 
    759a1640146b:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16401472:	64 00 00 
    759a16401475:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640147a:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a1640147f:	4d 89 cf             	mov    r15,r9
    759a16401482:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a16401487:	4c 89 d5             	mov    rbp,r10
    759a1640148a:	4d 89 dc             	mov    r12,r11
    759a1640148d:	ff d0                	call   rax
    759a1640148f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401494:	4d 89 e3             	mov    r11,r12
    759a16401497:	49 89 ea             	mov    r10,rbp
    759a1640149a:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a1640149f:	4d 89 f9             	mov    r9,r15
    759a164014a2:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164014a9:	00 
    759a164014aa:	84 c9                	test   cl,cl
    759a164014ac:	0f 84 79 f5 ff e7    	je     0x7599fe400a2b
    759a164014b2:	e9 31 01 00 00       	jmp    0x759a164015e8
    759a164014b7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164014be:	02 00 00 00 
    759a164014c2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164014c9:	01 00 00 00 
    759a164014cd:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164014d4:	64 00 00 
    759a164014d7:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164014dc:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a164014e1:	4d 89 cf             	mov    r15,r9
    759a164014e4:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a164014e9:	4c 89 d5             	mov    rbp,r10
    759a164014ec:	4d 89 dc             	mov    r12,r11
    759a164014ef:	ff d0                	call   rax
    759a164014f1:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164014f6:	4d 89 e3             	mov    r11,r12
    759a164014f9:	49 89 ea             	mov    r10,rbp
    759a164014fc:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a16401501:	4d 89 f9             	mov    r9,r15
    759a16401504:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640150b:	00 
    759a1640150c:	84 c9                	test   cl,cl
    759a1640150e:	0f 84 47 f5 ff e7    	je     0x7599fe400a5b
    759a16401514:	e9 cf 00 00 00       	jmp    0x759a164015e8
    759a16401519:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401520:	02 00 00 00 
    759a16401524:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640152b:	01 00 00 00 
    759a1640152f:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16401536:	64 00 00 
    759a16401539:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640153e:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401543:	4d 89 cf             	mov    r15,r9
    759a16401546:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a1640154b:	4c 89 d5             	mov    rbp,r10
    759a1640154e:	4d 89 dc             	mov    r12,r11
    759a16401551:	ff d0                	call   rax
    759a16401553:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401558:	4d 89 e3             	mov    r11,r12
    759a1640155b:	49 89 ea             	mov    r10,rbp
    759a1640155e:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a16401563:	4d 89 f9             	mov    r9,r15
    759a16401566:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    759a1640156b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401572:	00 
    759a16401573:	84 c9                	test   cl,cl
    759a16401575:	0f 84 0f f5 ff e7    	je     0x7599fe400a8a
    759a1640157b:	eb 6b                	jmp    0x759a164015e8
    759a1640157d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    759a16401584:	2a 03 01 00 
    759a16401588:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640158f:	02 00 00 00 
    759a16401593:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640159a:	01 00 00 00 
    759a1640159e:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a164015a5:	64 00 00 
    759a164015a8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164015ad:	4c 89 ef             	mov    rdi,r13
    759a164015b0:	4d 89 cf             	mov    r15,r9
    759a164015b3:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a164015b8:	4c 89 d5             	mov    rbp,r10
    759a164015bb:	4d 89 dc             	mov    r12,r11
    759a164015be:	ff d0                	call   rax
    759a164015c0:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a164015c5:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164015ca:	4d 89 e3             	mov    r11,r12
    759a164015cd:	49 89 ea             	mov    r10,rbp
    759a164015d0:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a164015d5:	4d 89 f9             	mov    r9,r15
    759a164015d8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164015df:	00 
    759a164015e0:	84 c9                	test   cl,cl
    759a164015e2:	0f 84 b5 f4 ff e7    	je     0x7599fe400a9d
    759a164015e8:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a164015ef:	e9 93 fd ff ff       	jmp    0x759a16401387
    759a164015f4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    759a164015fb:	2a 03 01 00 
    759a164015ff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16401606:	04 00 00 00 
    759a1640160a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16401611:	02 00 00 00 
    759a16401615:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640161c:	64 00 00 
    759a1640161f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16401624:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401629:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a1640162e:	4d 89 cf             	mov    r15,r9
    759a16401631:	4d 89 d4             	mov    r12,r10
    759a16401634:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401639:	ff d0                	call   rax
    759a1640163b:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a16401640:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401645:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a1640164a:	4d 89 e2             	mov    r10,r12
    759a1640164d:	4d 89 f9             	mov    r9,r15
    759a16401650:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a16401655:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640165c:	00 
    759a1640165d:	84 c9                	test   cl,cl
    759a1640165f:	0f 84 6d f4 ff e7    	je     0x7599fe400ad2
    759a16401665:	e9 ea 00 00 00       	jmp    0x759a16401754
    759a1640166a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032a
    759a16401671:	2a 03 01 00 
    759a16401675:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a1640167c:	04 00 00 00 
    759a16401680:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16401687:	02 00 00 00 
    759a1640168b:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16401692:	64 00 00 
    759a16401695:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640169a:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a1640169f:	44 89 e6             	mov    esi,r12d
    759a164016a2:	89 da                	mov    edx,ebx
    759a164016a4:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164016a9:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a164016ae:	4c 89 d5             	mov    rbp,r10
    759a164016b1:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a164016b6:	ff d0                	call   rax
    759a164016b8:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a164016bd:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164016c2:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a164016c7:	49 89 ea             	mov    r10,rbp
    759a164016ca:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a164016cf:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a164016d4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164016db:	00 
    759a164016dc:	84 c9                	test   cl,cl
    759a164016de:	0f 84 12 f4 ff e7    	je     0x7599fe400af6
    759a164016e4:	eb 6e                	jmp    0x759a16401754
    759a164016e6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1032e
    759a164016ed:	2e 03 01 00 
    759a164016f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164016f8:	04 00 00 00 
    759a164016fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16401703:	02 00 00 00 
    759a16401707:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640170e:	64 00 00 
    759a16401711:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16401716:	4c 89 ef             	mov    rdi,r13
    759a16401719:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a1640171e:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    759a16401723:	4c 89 d5             	mov    rbp,r10
    759a16401726:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a1640172b:	ff d0                	call   rax
    759a1640172d:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401732:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401737:	49 89 ea             	mov    r10,rbp
    759a1640173a:	48 8b 6c 24 20       	mov    rbp,QWORD PTR [rsp+0x20]
    759a1640173f:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a16401744:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640174b:	00 
    759a1640174c:	84 c9                	test   cl,cl
    759a1640174e:	0f 84 b4 f3 ff e7    	je     0x7599fe400b08
    759a16401754:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a1640175b:	bb 04 00 00 00       	mov    ebx,0x4
    759a16401760:	bd 02 00 00 00       	mov    ebp,0x2
    759a16401765:	e9 9e f6 ff e7       	jmp    0x7599fe400e08
    759a1640176a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    759a16401771:	70 03 01 00 
    759a16401775:	b1 01                	mov    cl,0x1
    759a16401777:	bd 04 00 00 00       	mov    ebp,0x4
    759a1640177c:	bb 02 00 00 00       	mov    ebx,0x2
    759a16401781:	e9 6c f8 ff e7       	jmp    0x7599fe400ff2
    759a16401786:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10348
    759a1640178d:	48 03 01 00 
    759a16401791:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401798:	02 00 00 00 
    759a1640179c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    759a164017a3:	0d 00 00 00 
    759a164017a7:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164017ae:	64 00 00 
    759a164017b1:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164017b6:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a164017bb:	be f0 12 01 00       	mov    esi,0x112f0
    759a164017c0:	89 da                	mov    edx,ebx
    759a164017c2:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164017c7:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    759a164017cc:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a164017d1:	ff d0                	call   rax
    759a164017d3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164017d8:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a164017dd:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    759a164017e2:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a164017e7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164017ee:	00 
    759a164017ef:	84 c9                	test   cl,cl
    759a164017f1:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    759a164017f6:	0f 84 0c f4 ff e7    	je     0x7599fe400c08
    759a164017fc:	eb 6d                	jmp    0x759a1640186b
    759a164017fe:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1034a
    759a16401805:	4a 03 01 00 
    759a16401809:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401810:	02 00 00 00 
    759a16401814:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    759a1640181b:	0d 00 00 00 
    759a1640181f:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16401826:	64 00 00 
    759a16401829:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640182e:	4c 89 ef             	mov    rdi,r13
    759a16401831:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16401836:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    759a1640183b:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401840:	ff d0                	call   rax
    759a16401842:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    759a16401847:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640184c:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401851:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    759a16401856:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640185b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401862:	00 
    759a16401863:	84 c9                	test   cl,cl
    759a16401865:	0f 84 a6 f3 ff e7    	je     0x7599fe400c11
    759a1640186b:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401872:	bb 02 00 00 00       	mov    ebx,0x2
    759a16401877:	bd 0d 00 00 00       	mov    ebp,0xd
    759a1640187c:	e9 87 f5 ff e7       	jmp    0x7599fe400e08
    759a16401881:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10352
    759a16401888:	52 03 01 00 
    759a1640188c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401893:	02 00 00 00 
    759a16401897:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    759a1640189e:	10 00 00 00 
    759a164018a2:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164018a9:	64 00 00 
    759a164018ac:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164018b1:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a164018b6:	be f4 12 01 00       	mov    esi,0x112f4
    759a164018bb:	89 ea                	mov    edx,ebp
    759a164018bd:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164018c2:	4c 89 d5             	mov    rbp,r10
    759a164018c5:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a164018ca:	ff d0                	call   rax
    759a164018cc:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    759a164018d1:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164018d6:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a164018db:	49 89 ea             	mov    r10,rbp
    759a164018de:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a164018e3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164018ea:	00 
    759a164018eb:	84 c9                	test   cl,cl
    759a164018ed:	0f 84 3c f3 ff e7    	je     0x7599fe400c2f
    759a164018f3:	eb 69                	jmp    0x759a1640195e
    759a164018f5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10354
    759a164018fc:	54 03 01 00 
    759a16401900:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401907:	02 00 00 00 
    759a1640190b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    759a16401912:	10 00 00 00 
    759a16401916:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640191d:	64 00 00 
    759a16401920:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16401925:	4c 89 ef             	mov    rdi,r13
    759a16401928:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a1640192d:	4c 89 d5             	mov    rbp,r10
    759a16401930:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401935:	ff d0                	call   rax
    759a16401937:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    759a1640193c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16401941:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401946:	49 89 ea             	mov    r10,rbp
    759a16401949:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640194e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401955:	00 
    759a16401956:	84 c9                	test   cl,cl
    759a16401958:	0f 84 da f2 ff e7    	je     0x7599fe400c38
    759a1640195e:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401965:	bb 02 00 00 00       	mov    ebx,0x2
    759a1640196a:	bd 10 00 00 00       	mov    ebp,0x10
    759a1640196f:	e9 94 f4 ff e7       	jmp    0x7599fe400e08
    759a16401974:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035c
    759a1640197b:	5c 03 01 00 
    759a1640197f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401986:	02 00 00 00 
    759a1640198a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    759a16401991:	13 00 00 00 
    759a16401995:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640199c:	64 00 00 
    759a1640199f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164019a4:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a164019a9:	be f8 12 01 00       	mov    esi,0x112f8
    759a164019ae:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164019b3:	4c 89 d5             	mov    rbp,r10
    759a164019b6:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a164019bb:	ff d0                	call   rax
    759a164019bd:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    759a164019c2:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164019c7:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a164019cc:	49 89 ea             	mov    r10,rbp
    759a164019cf:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a164019d4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164019db:	00 
    759a164019dc:	84 c9                	test   cl,cl
    759a164019de:	0f 84 76 f2 ff e7    	je     0x7599fe400c5a
    759a164019e4:	eb 5e                	jmp    0x759a16401a44
    759a164019e6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1035e
    759a164019ed:	5e 03 01 00 
    759a164019f1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164019f8:	02 00 00 00 
    759a164019fc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    759a16401a03:	13 00 00 00 
    759a16401a07:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16401a0e:	64 00 00 
    759a16401a11:	4c 89 ef             	mov    rdi,r13
    759a16401a14:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16401a19:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    759a16401a1e:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401a23:	ff d0                	call   rax
    759a16401a25:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401a2a:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    759a16401a2f:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a16401a34:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401a3b:	00 
    759a16401a3c:	84 c9                	test   cl,cl
    759a16401a3e:	0f 84 22 f2 ff e7    	je     0x7599fe400c66
    759a16401a44:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401a4b:	bb 02 00 00 00       	mov    ebx,0x2
    759a16401a50:	bd 13 00 00 00       	mov    ebp,0x13
    759a16401a55:	e9 ae f3 ff e7       	jmp    0x7599fe400e08
    759a16401a5a:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    759a16401a61:	e9 8c f5 ff e7       	jmp    0x7599fe400ff2
    759a16401a66:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    759a16401a6d:	7a 03 01 00 
    759a16401a71:	b1 01                	mov    cl,0x1
    759a16401a73:	bd 15 00 00 00       	mov    ebp,0x15
    759a16401a78:	e9 ff fc ff ff       	jmp    0x759a1640177c
    759a16401a7d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    759a16401a84:	a4 03 01 00 
    759a16401a88:	b1 01                	mov    cl,0x1
    759a16401a8a:	bd 17 00 00 00       	mov    ebp,0x17
    759a16401a8f:	e9 e8 fc ff ff       	jmp    0x759a1640177c
    759a16401a94:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401a99:	4d 89 d7             	mov    r15,r10
    759a16401a9c:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16401aa1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    759a16401aa8:	68 03 01 00 
    759a16401aac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16401ab3:	04 00 00 00 
    759a16401ab7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    759a16401abe:	19 00 00 00 
    759a16401ac2:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401ac9:	64 00 00 
    759a16401acc:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401ad1:	44 89 e6             	mov    esi,r12d
    759a16401ad4:	ff d0                	call   rax
    759a16401ad6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401add:	00 
    759a16401ade:	84 c9                	test   cl,cl
    759a16401ae0:	0f 85 d9 02 00 00    	jne    0x759a16401dbf
    759a16401ae6:	89 c3                	mov    ebx,eax
    759a16401ae8:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a16401aed:	4d 89 fa             	mov    r10,r15
    759a16401af0:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401af5:	e9 18 f2 ff e7       	jmp    0x7599fe400d12
    759a16401afa:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16401aff:	4d 89 d4             	mov    r12,r10
    759a16401b02:	4d 89 cf             	mov    r15,r9
    759a16401b05:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    759a16401b0c:	68 03 01 00 
    759a16401b10:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16401b17:	04 00 00 00 
    759a16401b1b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x19
    759a16401b22:	19 00 00 00 
    759a16401b26:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401b2d:	64 00 00 
    759a16401b30:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401b35:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    759a16401b3a:	ff d0                	call   rax
    759a16401b3c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401b43:	00 
    759a16401b44:	84 c9                	test   cl,cl
    759a16401b46:	0f 85 73 02 00 00    	jne    0x759a16401dbf
    759a16401b4c:	4d 89 f9             	mov    r9,r15
    759a16401b4f:	4d 89 e2             	mov    r10,r12
    759a16401b52:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16401b57:	48 89 e9             	mov    rcx,rbp
    759a16401b5a:	48 89 c7             	mov    rdi,rax
    759a16401b5d:	e9 ce f1 ff e7       	jmp    0x7599fe400d30
    759a16401b62:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    759a16401b67:	4d 89 dc             	mov    r12,r11
    759a16401b6a:	4d 89 d7             	mov    r15,r10
    759a16401b6d:	4c 89 cb             	mov    rbx,r9
    759a16401b70:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    759a16401b77:	6c 03 01 00 
    759a16401b7b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401b82:	02 00 00 00 
    759a16401b86:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a16401b8d:	1a 00 00 00 
    759a16401b91:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401b98:	64 00 00 
    759a16401b9b:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401ba0:	ff d0                	call   rax
    759a16401ba2:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401ba9:	00 
    759a16401baa:	84 c9                	test   cl,cl
    759a16401bac:	0f 85 f7 01 00 00    	jne    0x759a16401da9
    759a16401bb2:	49 89 d9             	mov    r9,rbx
    759a16401bb5:	4d 89 fa             	mov    r10,r15
    759a16401bb8:	4d 89 e3             	mov    r11,r12
    759a16401bbb:	48 89 e9             	mov    rcx,rbp
    759a16401bbe:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    759a16401bc3:	e9 97 f1 ff e7       	jmp    0x7599fe400d5f
    759a16401bc8:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    759a16401bcd:	4d 89 dc             	mov    r12,r11
    759a16401bd0:	4d 89 d7             	mov    r15,r10
    759a16401bd3:	4c 89 cb             	mov    rbx,r9
    759a16401bd6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    759a16401bdd:	6c 03 01 00 
    759a16401be1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401be8:	02 00 00 00 
    759a16401bec:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a16401bf3:	1a 00 00 00 
    759a16401bf7:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401bfe:	64 00 00 
    759a16401c01:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401c06:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    759a16401c0b:	ff d0                	call   rax
    759a16401c0d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401c14:	00 
    759a16401c15:	84 c9                	test   cl,cl
    759a16401c17:	0f 85 8c 01 00 00    	jne    0x759a16401da9
    759a16401c1d:	49 89 d9             	mov    r9,rbx
    759a16401c20:	4d 89 fa             	mov    r10,r15
    759a16401c23:	4d 89 e3             	mov    r11,r12
    759a16401c26:	48 89 e9             	mov    rcx,rbp
    759a16401c29:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    759a16401c2e:	e9 50 f1 ff e7       	jmp    0x7599fe400d83
    759a16401c33:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    759a16401c38:	4d 89 dc             	mov    r12,r11
    759a16401c3b:	4d 89 d7             	mov    r15,r10
    759a16401c3e:	4c 89 cb             	mov    rbx,r9
    759a16401c41:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    759a16401c48:	6c 03 01 00 
    759a16401c4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401c53:	02 00 00 00 
    759a16401c57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a16401c5e:	1a 00 00 00 
    759a16401c62:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401c69:	64 00 00 
    759a16401c6c:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401c71:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    759a16401c76:	ff d0                	call   rax
    759a16401c78:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401c7f:	00 
    759a16401c80:	84 c9                	test   cl,cl
    759a16401c82:	0f 85 21 01 00 00    	jne    0x759a16401da9
    759a16401c88:	49 89 d9             	mov    r9,rbx
    759a16401c8b:	4d 89 fa             	mov    r10,r15
    759a16401c8e:	4d 89 e3             	mov    r11,r12
    759a16401c91:	48 89 e9             	mov    rcx,rbp
    759a16401c94:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    759a16401c99:	e9 09 f1 ff e7       	jmp    0x7599fe400da7
    759a16401c9e:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    759a16401ca3:	4d 89 dc             	mov    r12,r11
    759a16401ca6:	4d 89 d7             	mov    r15,r10
    759a16401ca9:	4c 89 cb             	mov    rbx,r9
    759a16401cac:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    759a16401cb3:	6c 03 01 00 
    759a16401cb7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401cbe:	02 00 00 00 
    759a16401cc2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a16401cc9:	1a 00 00 00 
    759a16401ccd:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401cd4:	64 00 00 
    759a16401cd7:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401cdc:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a16401ce1:	ff d0                	call   rax
    759a16401ce3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401cea:	00 
    759a16401ceb:	84 c9                	test   cl,cl
    759a16401ced:	0f 85 b6 00 00 00    	jne    0x759a16401da9
    759a16401cf3:	49 89 d9             	mov    r9,rbx
    759a16401cf6:	4d 89 fa             	mov    r10,r15
    759a16401cf9:	4d 89 e3             	mov    r11,r12
    759a16401cfc:	48 89 e9             	mov    rcx,rbp
    759a16401cff:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    759a16401d04:	e9 c5 f0 ff e7       	jmp    0x7599fe400dce
    759a16401d09:	48 89 fd             	mov    rbp,rdi
    759a16401d0c:	4c 89 cb             	mov    rbx,r9
    759a16401d0f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036c
    759a16401d16:	6c 03 01 00 
    759a16401d1a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401d21:	02 00 00 00 
    759a16401d25:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a16401d2c:	1a 00 00 00 
    759a16401d30:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16401d37:	64 00 00 
    759a16401d3a:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    759a16401d3f:	44 89 d6             	mov    esi,r10d
    759a16401d42:	ff d0                	call   rax
    759a16401d44:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401d4b:	00 
    759a16401d4c:	84 c9                	test   cl,cl
    759a16401d4e:	75 59                	jne    0x759a16401da9
    759a16401d50:	49 89 d9             	mov    r9,rbx
    759a16401d53:	48 89 ef             	mov    rdi,rbp
    759a16401d56:	e9 8f f0 ff e7       	jmp    0x7599fe400dea
    759a16401d5b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1036e
    759a16401d62:	6e 03 01 00 
    759a16401d66:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401d6d:	02 00 00 00 
    759a16401d71:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    759a16401d78:	1b 00 00 00 
    759a16401d7c:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a16401d83:	64 00 00 
    759a16401d86:	4c 89 ef             	mov    rdi,r13
    759a16401d89:	be 2a 00 00 00       	mov    esi,0x2a
    759a16401d8e:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    759a16401d93:	ff d0                	call   rax
    759a16401d95:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401d9c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16401da3:	00 
    759a16401da4:	e9 5f f0 ff e7       	jmp    0x7599fe400e08
    759a16401da9:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401db0:	bb 02 00 00 00       	mov    ebx,0x2
    759a16401db5:	bd 1a 00 00 00       	mov    ebp,0x1a
    759a16401dba:	e9 49 f0 ff e7       	jmp    0x7599fe400e08
    759a16401dbf:	41 8b bd bc 00 00 00 	mov    edi,DWORD PTR [r13+0xbc]
    759a16401dc6:	bb 04 00 00 00       	mov    ebx,0x4
    759a16401dcb:	bd 19 00 00 00       	mov    ebp,0x19
    759a16401dd0:	e9 33 f0 ff e7       	jmp    0x7599fe400e08
