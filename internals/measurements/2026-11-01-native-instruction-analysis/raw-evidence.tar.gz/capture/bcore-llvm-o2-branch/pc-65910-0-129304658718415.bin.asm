
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65910-0-129304658718415.bin:     file format binary


Disassembly of section .data:

0000759a16402ecf <.data>:
    759a16402ecf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    759a16402ed6:	92 01 01 00 
    759a16402eda:	b8 03 00 00 00       	mov    eax,0x3
    759a16402edf:	b9 02 00 00 00       	mov    ecx,0x2
    759a16402ee4:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    759a16402eeb:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    759a16402ef2:	b8 28 01 00 00       	mov    eax,0x128
    759a16402ef7:	e9 dd f2 ff e7       	jmp    0x7599fe4021d9
    759a16402efc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    759a16402f03:	70 01 01 00 
    759a16402f07:	b8 08 00 00 00       	mov    eax,0x8
    759a16402f0c:	eb d1                	jmp    0x759a16402edf
    759a16402f0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    759a16402f15:	10 01 01 00 
    759a16402f19:	b8 0a 00 00 00       	mov    eax,0xa
    759a16402f1e:	b9 04 00 00 00       	mov    ecx,0x4
    759a16402f23:	eb bf                	jmp    0x759a16402ee4
