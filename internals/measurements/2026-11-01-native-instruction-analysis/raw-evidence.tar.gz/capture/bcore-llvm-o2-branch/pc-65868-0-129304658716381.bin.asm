
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65868-0-129304658716381.bin:     file format binary


Disassembly of section .data:

0000759a164026dd <.data>:
    759a164026dd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    759a164026e4:	7c 01 01 00 
    759a164026e8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164026ef:	02 00 00 00 
    759a164026f3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    759a164026fa:	0d 00 00 00 
    759a164026fe:	e9 e8 f2 ff e7       	jmp    0x7599fe4019eb
    759a16402703:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    759a1640270a:	01 
    759a1640270b:	48 83 c4 18          	add    rsp,0x18
    759a1640270f:	c2 08 00             	ret    0x8
    759a16402712:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402717:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640271e:	02 00 00 00 
    759a16402722:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16402729:	01 00 00 00 
    759a1640272d:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16402734:	64 00 00 
    759a16402737:	4c 89 ef             	mov    rdi,r13
    759a1640273a:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640273f:	4c 89 f6             	mov    rsi,r14
    759a16402742:	ba 4c 01 01 00       	mov    edx,0x1014c
    759a16402747:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a1640274d:	ff d0                	call   rax
    759a1640274f:	b8 02 00 00 00       	mov    eax,0x2
    759a16402754:	b9 01 00 00 00       	mov    ecx,0x1
    759a16402759:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    759a16402760:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    759a16402767:	01 ca                	add    edx,ecx
    759a16402769:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    759a16402770:	39 fa                	cmp    edx,edi
    759a16402772:	0f 83 7d 03 00 00    	jae    0x759a16402af5
    759a16402778:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    759a1640277f:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    759a16402785:	48 8b 6c 24 08       	mov    rbp,QWORD PTR [rsp+0x8]
    759a1640278a:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    759a1640278e:	0f 85 61 03 00 00    	jne    0x759a16402af5
    759a16402794:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    759a1640279b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    759a164027a2:	00 
    759a164027a3:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    759a164027a8:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    759a164027ad:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164027b2:	48 83 c4 18          	add    rsp,0x18
    759a164027b6:	ff e0                	jmp    rax
    759a164027b8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164027bf:	02 00 00 00 
    759a164027c3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164027ca:	01 00 00 00 
    759a164027ce:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164027d5:	64 00 00 
    759a164027d8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164027dd:	4c 89 f7             	mov    rdi,r14
    759a164027e0:	89 ce                	mov    esi,ecx
    759a164027e2:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a164027e7:	4c 89 c3             	mov    rbx,r8
    759a164027ea:	ff d0                	call   rax
    759a164027ec:	49 89 d8             	mov    r8,rbx
    759a164027ef:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164027f4:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164027f9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16402800:	00 
    759a16402801:	0f 84 db ef ff e7    	je     0x7599fe4017e2
    759a16402807:	e9 43 ff ff ff       	jmp    0x759a1640274f
    759a1640280c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402813:	02 00 00 00 
    759a16402817:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640281e:	01 00 00 00 
    759a16402822:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16402829:	64 00 00 
    759a1640282c:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402831:	4c 89 f7             	mov    rdi,r14
    759a16402834:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16402839:	4c 89 c3             	mov    rbx,r8
    759a1640283c:	ff d0                	call   rax
    759a1640283e:	49 89 d8             	mov    r8,rbx
    759a16402841:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402846:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a1640284b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16402852:	00 
    759a16402853:	0f 84 ad ef ff e7    	je     0x7599fe401806
    759a16402859:	e9 f1 fe ff ff       	jmp    0x759a1640274f
    759a1640285e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402865:	02 00 00 00 
    759a16402869:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16402870:	01 00 00 00 
    759a16402874:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640287b:	64 00 00 
    759a1640287e:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402883:	4c 89 f7             	mov    rdi,r14
    759a16402886:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640288b:	4c 89 c3             	mov    rbx,r8
    759a1640288e:	ff d0                	call   rax
    759a16402890:	49 89 d8             	mov    r8,rbx
    759a16402893:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402898:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a1640289d:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a164028a4:	00 
    759a164028a5:	0f 84 7f ef ff e7    	je     0x7599fe40182a
    759a164028ab:	e9 9f fe ff ff       	jmp    0x759a1640274f
    759a164028b0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164028b7:	02 00 00 00 
    759a164028bb:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164028c2:	01 00 00 00 
    759a164028c6:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164028cd:	64 00 00 
    759a164028d0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164028d5:	4c 89 f7             	mov    rdi,r14
    759a164028d8:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a164028dd:	4c 89 c3             	mov    rbx,r8
    759a164028e0:	ff d0                	call   rax
    759a164028e2:	49 89 d8             	mov    r8,rbx
    759a164028e5:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164028ea:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164028ef:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a164028f6:	00 
    759a164028f7:	0f 84 51 ef ff e7    	je     0x7599fe40184e
    759a164028fd:	e9 4d fe ff ff       	jmp    0x759a1640274f
    759a16402902:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402909:	02 00 00 00 
    759a1640290d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16402914:	01 00 00 00 
    759a16402918:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640291f:	64 00 00 
    759a16402922:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402927:	4c 89 f7             	mov    rdi,r14
    759a1640292a:	89 de                	mov    esi,ebx
    759a1640292c:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16402931:	4c 89 c5             	mov    rbp,r8
    759a16402934:	ff d0                	call   rax
    759a16402936:	49 89 e8             	mov    r8,rbp
    759a16402939:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640293e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16402943:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a1640294a:	00 
    759a1640294b:	0f 84 23 ef ff e7    	je     0x7599fe401874
    759a16402951:	e9 f9 fd ff ff       	jmp    0x759a1640274f
    759a16402956:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    759a1640295d:	4e 01 01 00 
    759a16402961:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402968:	02 00 00 00 
    759a1640296c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16402973:	01 00 00 00 
    759a16402977:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640297e:	64 00 00 
    759a16402981:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402986:	4c 89 ef             	mov    rdi,r13
    759a16402989:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640298e:	4c 89 c3             	mov    rbx,r8
    759a16402991:	ff d0                	call   rax
    759a16402993:	49 89 d8             	mov    r8,rbx
    759a16402996:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640299b:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164029a0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a164029a7:	00 
    759a164029a8:	0f 84 d4 ee ff e7    	je     0x7599fe401882
    759a164029ae:	e9 9c fd ff ff       	jmp    0x759a1640274f
    759a164029b3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    759a164029ba:	4e 01 01 00 
    759a164029be:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164029c5:	04 00 00 00 
    759a164029c9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a164029d0:	02 00 00 00 
    759a164029d4:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164029db:	64 00 00 
    759a164029de:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164029e3:	4c 89 f7             	mov    rdi,r14
    759a164029e6:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a164029eb:	4c 89 c5             	mov    rbp,r8
    759a164029ee:	ff d0                	call   rax
    759a164029f0:	49 89 e8             	mov    r8,rbp
    759a164029f3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164029f8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164029fd:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16402a04:	00 
    759a16402a05:	0f 84 a2 ee ff e7    	je     0x7599fe4018ad
    759a16402a0b:	e9 b0 00 00 00       	jmp    0x759a16402ac0
    759a16402a10:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014e
    759a16402a17:	4e 01 01 00 
    759a16402a1b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402a22:	04 00 00 00 
    759a16402a26:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16402a2d:	02 00 00 00 
    759a16402a31:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16402a38:	64 00 00 
    759a16402a3b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402a40:	4c 89 f7             	mov    rdi,r14
    759a16402a43:	89 ee                	mov    esi,ebp
    759a16402a45:	89 da                	mov    edx,ebx
    759a16402a47:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16402a4c:	4c 89 c3             	mov    rbx,r8
    759a16402a4f:	ff d0                	call   rax
    759a16402a51:	49 89 d8             	mov    r8,rbx
    759a16402a54:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402a59:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16402a5e:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16402a65:	00 
    759a16402a66:	0f 84 63 ee ff e7    	je     0x7599fe4018cf
    759a16402a6c:	eb 52                	jmp    0x759a16402ac0
    759a16402a6e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10152
    759a16402a75:	52 01 01 00 
    759a16402a79:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402a80:	04 00 00 00 
    759a16402a84:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16402a8b:	02 00 00 00 
    759a16402a8f:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16402a96:	64 00 00 
    759a16402a99:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402a9e:	4c 89 ef             	mov    rdi,r13
    759a16402aa1:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16402aa6:	ff d0                	call   rax
    759a16402aa8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402aad:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16402ab2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16402ab9:	00 
    759a16402aba:	0f 84 25 ee ff e7    	je     0x7599fe4018e5
    759a16402ac0:	b8 04 00 00 00       	mov    eax,0x4
    759a16402ac5:	b9 02 00 00 00       	mov    ecx,0x2
    759a16402aca:	e9 8a fc ff ff       	jmp    0x759a16402759
    759a16402acf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    759a16402ad6:	9c 01 01 00 
    759a16402ada:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402ae1:	02 00 00 00 
    759a16402ae5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16402aec:	05 00 00 00 
    759a16402af0:	e9 f6 ee ff e7       	jmp    0x7599fe4019eb
    759a16402af5:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    759a16402afc:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    759a16402b03:	48 83 c4 18          	add    rsp,0x18
    759a16402b07:	c2 08 00             	ret    0x8
