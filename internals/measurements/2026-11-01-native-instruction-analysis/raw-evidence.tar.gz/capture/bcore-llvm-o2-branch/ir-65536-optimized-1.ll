; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010000(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = add i32 %guard_lb, -65539
  %3 = icmp ult i32 %2, -3
  %4 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb7 = load i32, ptr %4, align 4
  %5 = add i32 %guard_lb7, -65539
  %6 = icmp ult i32 %5, -3
  %7 = and i1 %3, %6
  br i1 %7, label %insn_0x00010000, label %common.ret, !prof !0

insn_0x00010000:                                  ; preds = %entry
  %8 = getelementptr i8, ptr %cpu, i64 56
  %pd = load i32, ptr %8, align 4
  %pd_add = add i32 %pd, -12
  store i32 %pd_add, ptr %8, align 4
  %9 = getelementptr i8, ptr %cpu, i64 168
  store i32 65542, ptr %9, align 4
  %10 = getelementptr i8, ptr %cpu, i64 188
  store i32 65556, ptr %10, align 4
  %11 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %11, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %12 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %12 monotonic, align 4, !range !1
  %13 = icmp ult i32 %chain_total, %chain_budget
  br i1 %13, label %chain_go, label %chain_leave8, !prof !0

common.ret:                                       ; preds = %entry, %chain_leave8
  %.sink9 = phi i64 [ 296, %chain_leave8 ], [ 357, %entry ]
  %14 = getelementptr i8, ptr %cpu, i64 %.sink9
  store i8 1, ptr %14, align 1
  ret void

chain_go:                                         ; preds = %insn_0x00010000
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524448
  %slot_pc = load i32, ptr %chain_slot, align 4
  %15 = icmp eq i32 %slot_pc, 65556
  br i1 %15, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010000
  store i32 65556, ptr %10, align 4
  %16 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %17, align 4
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65556, ptr %10, align 4
  store i32 %chain_total, ptr %11, align 4
  %18 = getelementptr i8, ptr %chain_table, i64 524456
  %chain_fn = load ptr, ptr %18, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
