
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65668-0-129304256064480.bin:     file format binary


Disassembly of section .data:

00007599fe402be0 <.data>:
    7599fe402be0:	48 83 ec 18          	sub    rsp,0x18
    7599fe402be4:	41 8b ad a0 00 00 00 	mov    ebp,DWORD PTR [r13+0xa0]
    7599fe402beb:	8d 85 71 ff fe ff    	lea    eax,[rbp-0x1008f]
    7599fe402bf1:	83 f8 f4             	cmp    eax,0xfffffff4
    7599fe402bf4:	0f 87 3e 13 00 18    	ja     0x759a16403f38
    7599fe402bfa:	41 8b bd a4 00 00 00 	mov    edi,DWORD PTR [r13+0xa4]
    7599fe402c01:	8d 87 71 ff fe ff    	lea    eax,[rdi-0x1008f]
    7599fe402c07:	83 f8 f4             	cmp    eax,0xfffffff4
    7599fe402c0a:	0f 87 28 13 00 18    	ja     0x759a16403f38
    7599fe402c10:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    7599fe402c17:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7599fe402c1b:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7599fe402c1e:	f6 c3 03             	test   bl,0x3
    7599fe402c21:	0f 85 20 13 00 18    	jne    0x759a16403f47
    7599fe402c27:	4d 8b bd 38 01 00 00 	mov    r15,QWORD PTR [r13+0x138]
    7599fe402c2e:	45 8b 65 10          	mov    r12d,DWORD PTR [r13+0x10]
    7599fe402c32:	89 c8                	mov    eax,ecx
    7599fe402c34:	c1 e8 0c             	shr    eax,0xc
    7599fe402c37:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe402c3b:	48 85 c0             	test   rax,rax
    7599fe402c3e:	0f 84 a6 13 00 18    	je     0x759a16403fea
    7599fe402c44:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe402c4a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7599fe402c4d:	45 89 65 00          	mov    DWORD PTR [r13+0x0],r12d
    7599fe402c51:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7599fe402c55:	83 c3 f8             	add    ebx,0xfffffff8
    7599fe402c58:	89 d8                	mov    eax,ebx
    7599fe402c5a:	c1 e8 0c             	shr    eax,0xc
    7599fe402c5d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
    7599fe402c61:	48 85 c0             	test   rax,rax
    7599fe402c64:	0f 84 dc 13 00 18    	je     0x759a16404046
    7599fe402c6a:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    7599fe402c70:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    7599fe402c73:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    7599fe402c77:	41 8b 8d 9c 00 00 00 	mov    ecx,DWORD PTR [r13+0x9c]
    7599fe402c7e:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7599fe402c85:	02 
    7599fe402c86:	b8 92 00 01 00       	mov    eax,0x10092
    7599fe402c8b:	ba 92 00 01 00       	mov    edx,0x10092
    7599fe402c90:	72 07                	jb     0x7599fe402c99
    7599fe402c92:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7599fe402c99:	81 fd 8e 00 01 00    	cmp    ebp,0x1008e
    7599fe402c9f:	0f 44 c2             	cmove  eax,edx
    7599fe402ca2:	89 c2                	mov    edx,eax
    7599fe402ca4:	83 f9 02             	cmp    ecx,0x2
    7599fe402ca7:	72 07                	jb     0x7599fe402cb0
    7599fe402ca9:	41 8b 95 94 00 00 00 	mov    edx,DWORD PTR [r13+0x94]
    7599fe402cb0:	81 ff 8e 00 01 00    	cmp    edi,0x1008e
    7599fe402cb6:	0f 44 c2             	cmove  eax,edx
    7599fe402cb9:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7599fe402cc0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe402cc7:	28 03 01 00 
    7599fe402ccb:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe402cd2:	83 c0 03             	add    eax,0x3
    7599fe402cd5:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe402cdc:	39 c8                	cmp    eax,ecx
    7599fe402cde:	73 2b                	jae    0x7599fe402d0b
    7599fe402ce0:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    7599fe402ce7:	03 01 00 
    7599fe402cea:	75 1f                	jne    0x7599fe402d0b
    7599fe402cec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe402cf3:	28 03 01 00 
    7599fe402cf7:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe402cfe:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    7599fe402d05:	48 83 c4 18          	add    rsp,0x18
    7599fe402d09:	ff e0                	jmp    rax
    7599fe402d0b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe402d12:	28 03 01 00 
    7599fe402d16:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7599fe402d1d:	04 00 00 00 
    7599fe402d21:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7599fe402d28:	03 00 00 00 
    7599fe402d2c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7599fe402d33:	01 
    7599fe402d34:	48 83 c4 18          	add    rsp,0x18
    7599fe402d38:	c2 08 00             	ret    0x8
