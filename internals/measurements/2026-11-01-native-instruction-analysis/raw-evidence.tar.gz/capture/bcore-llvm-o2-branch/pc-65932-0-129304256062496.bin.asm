
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65932-0-129304256062496.bin:     file format binary


Disassembly of section .data:

00007599fe402420 <.data>:
    7599fe402420:	48 83 ec 18          	sub    rsp,0x18
    7599fe402424:	ba 65 fe fe ff       	mov    edx,0xfffefe65
    7599fe402429:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe402430:	01 d6                	add    esi,edx
    7599fe402432:	b1 01                	mov    cl,0x1
    7599fe402434:	b8 65 01 00 00       	mov    eax,0x165
    7599fe402439:	83 fe f0             	cmp    esi,0xfffffff0
    7599fe40243c:	0f 87 a2 02 00 00    	ja     0x7599fe4026e4
    7599fe402442:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe402449:	83 fa f0             	cmp    edx,0xfffffff0
    7599fe40244c:	0f 87 92 02 00 00    	ja     0x7599fe4026e4
    7599fe402452:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    7599fe402459:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7599fe402460:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    7599fe402464:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    7599fe402468:	8d 51 01             	lea    edx,[rcx+0x1]
    7599fe40246b:	41 89 55 18          	mov    DWORD PTR [r13+0x18],edx
    7599fe40246f:	c1 e9 1f             	shr    ecx,0x1f
    7599fe402472:	89 d6                	mov    esi,edx
    7599fe402474:	c1 ee 1f             	shr    esi,0x1f
    7599fe402477:	c4 e2 70 f2 ce       	andn   ecx,ecx,esi
    7599fe40247c:	41 89 8d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ecx
    7599fe402483:	41 89 8d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ecx
    7599fe40248a:	41 09 8d 00 01 00 00 	or     DWORD PTR [r13+0x100],ecx
    7599fe402491:	31 c9                	xor    ecx,ecx
    7599fe402493:	31 f6                	xor    esi,esi
    7599fe402495:	31 ff                	xor    edi,edi
    7599fe402497:	31 db                	xor    ebx,ebx
    7599fe402499:	39 c2                	cmp    edx,eax
    7599fe40249b:	0f 97 c1             	seta   cl
    7599fe40249e:	40 0f 96 c6          	setbe  sil
    7599fe4024a2:	40 0f 93 c7          	setae  dil
    7599fe4024a6:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    7599fe4024ad:	0f 94 c3             	sete   bl
    7599fe4024b0:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7599fe4024b7:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe4024be:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7599fe4024c5:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7599fe4024cc:	0f 82 ab 01 00 00    	jb     0x7599fe40267d
    7599fe4024d2:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7599fe4024d6:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    7599fe4024da:	31 c9                	xor    ecx,ecx
    7599fe4024dc:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    7599fe4024e0:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7599fe4024e4:	0f 94 c1             	sete   cl
    7599fe4024e7:	c1 e8 1f             	shr    eax,0x1f
    7599fe4024ea:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7599fe4024f1:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7599fe4024f8:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7599fe4024ff:	00 00 00 00 
    7599fe402503:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe40250a:	00 00 00 00 
    7599fe40250e:	40 f6 c5 03          	test   bpl,0x3
    7599fe402512:	0f 85 7a 0d 00 18    	jne    0x759a16403292
    7599fe402518:	48 89 e8             	mov    rax,rbp
    7599fe40251b:	48 c1 e8 0c          	shr    rax,0xc
    7599fe40251f:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe402523:	48 85 c0             	test   rax,rax
    7599fe402526:	0f 84 c7 0d 00 18    	je     0x759a164032f3
    7599fe40252c:	89 e9                	mov    ecx,ebp
    7599fe40252e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe402534:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    7599fe402537:	8d 75 04             	lea    esi,[rbp+0x4]
    7599fe40253a:	89 f0                	mov    eax,esi
    7599fe40253c:	c1 e8 0c             	shr    eax,0xc
    7599fe40253f:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe402543:	48 85 c0             	test   rax,rax
    7599fe402546:	0f 84 04 0e 00 18    	je     0x759a16403350
    7599fe40254c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402552:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    7599fe402556:	8d 75 08             	lea    esi,[rbp+0x8]
    7599fe402559:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7599fe40255d:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    7599fe402564:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe402568:	89 f0                	mov    eax,esi
    7599fe40256a:	c1 e8 0c             	shr    eax,0xc
    7599fe40256d:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe402571:	48 85 c0             	test   rax,rax
    7599fe402574:	0f 84 32 0e 00 18    	je     0x759a164033ac
    7599fe40257a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402580:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402583:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7599fe402587:	8d 75 0c             	lea    esi,[rbp+0xc]
    7599fe40258a:	89 f0                	mov    eax,esi
    7599fe40258c:	c1 e8 0c             	shr    eax,0xc
    7599fe40258f:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe402593:	48 85 c0             	test   rax,rax
    7599fe402596:	0f 84 69 0e 00 18    	je     0x759a16403405
    7599fe40259c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4025a2:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4025a5:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7599fe4025a9:	8d 75 10             	lea    esi,[rbp+0x10]
    7599fe4025ac:	89 f0                	mov    eax,esi
    7599fe4025ae:	c1 e8 0c             	shr    eax,0xc
    7599fe4025b1:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4025b5:	48 85 c0             	test   rax,rax
    7599fe4025b8:	0f 84 a0 0e 00 18    	je     0x759a1640345e
    7599fe4025be:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4025c4:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4025c7:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7599fe4025cb:	8d 75 14             	lea    esi,[rbp+0x14]
    7599fe4025ce:	89 f0                	mov    eax,esi
    7599fe4025d0:	c1 e8 0c             	shr    eax,0xc
    7599fe4025d3:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4025d7:	48 85 c0             	test   rax,rax
    7599fe4025da:	0f 84 d7 0e 00 18    	je     0x759a164034b7
    7599fe4025e0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4025e6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4025e9:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7599fe4025ed:	8d 75 18             	lea    esi,[rbp+0x18]
    7599fe4025f0:	89 f0                	mov    eax,esi
    7599fe4025f2:	c1 e8 0c             	shr    eax,0xc
    7599fe4025f5:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4025f9:	48 85 c0             	test   rax,rax
    7599fe4025fc:	0f 84 0e 0f 00 18    	je     0x759a16403510
    7599fe402602:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402608:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe40260b:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7599fe40260f:	83 c5 1c             	add    ebp,0x1c
    7599fe402612:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7599fe402616:	b1 01                	mov    cl,0x1
    7599fe402618:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe40261d:	bd 07 00 00 00       	mov    ebp,0x7
    7599fe402622:	41 f6 c7 01          	test   r15b,0x1
    7599fe402626:	0f 85 39 0f 00 18    	jne    0x759a16403565
    7599fe40262c:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe402633:	01 e8                	add    eax,ebp
    7599fe402635:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe40263c:	39 d0                	cmp    eax,edx
    7599fe40263e:	0f 83 26 0c 00 18    	jae    0x759a1640326a
    7599fe402644:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    7599fe40264b:	00 
    7599fe40264c:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    7599fe402652:	45 39 3c 10          	cmp    DWORD PTR [r8+rdx*1],r15d
    7599fe402656:	0f 85 0e 0c 00 18    	jne    0x759a1640326a
    7599fe40265c:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    7599fe402663:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe40266a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe402671:	00 
    7599fe402672:	49 8b 44 10 08       	mov    rax,QWORD PTR [r8+rdx*1+0x8]
    7599fe402677:	48 83 c4 18          	add    rsp,0x18
    7599fe40267b:	ff e0                	jmp    rax
    7599fe40267d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7599fe402684:	7c 01 01 00 
    7599fe402688:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe40268f:	83 c0 03             	add    eax,0x3
    7599fe402692:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe402699:	39 c8                	cmp    eax,ecx
    7599fe40269b:	0f 83 d5 0b 00 18    	jae    0x759a16403276
    7599fe4026a1:	41 81 b8 e0 0b 08 00 	cmp    DWORD PTR [r8+0x80be0],0x1017c
    7599fe4026a8:	7c 01 01 00 
    7599fe4026ac:	0f 85 c4 0b 00 18    	jne    0x759a16403276
    7599fe4026b2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    7599fe4026b9:	7c 01 01 00 
    7599fe4026bd:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe4026c4:	49 8b 80 e8 0b 08 00 	mov    rax,QWORD PTR [r8+0x80be8]
    7599fe4026cb:	48 83 c4 18          	add    rsp,0x18
    7599fe4026cf:	ff e0                	jmp    rax
    7599fe4026d1:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe4026d8:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe4026df:	b8 28 01 00 00       	mov    eax,0x128
    7599fe4026e4:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe4026e9:	48 83 c4 18          	add    rsp,0x18
    7599fe4026ed:	c2 08 00             	ret    0x8
