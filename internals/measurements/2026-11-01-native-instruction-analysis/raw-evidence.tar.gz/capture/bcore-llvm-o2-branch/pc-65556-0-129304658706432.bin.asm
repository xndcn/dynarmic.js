
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65556-0-129304658706432.bin:     file format binary


Disassembly of section .data:

0000759a16400000 <.data>:
    759a16400000:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    759a16400007:	e9 b1 05 00 e8       	jmp    0x7599fe4005bd
    759a1640000c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400013:	02 00 00 00 
    759a16400017:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640001e:	01 00 00 00 
    759a16400022:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16400029:	64 00 00 
    759a1640002c:	48 89 fb             	mov    rbx,rdi
    759a1640002f:	4c 89 ef             	mov    rdi,r13
    759a16400032:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    759a16400037:	ba 14 00 01 00       	mov    edx,0x10014
    759a1640003c:	44 89 c9             	mov    ecx,r9d
    759a1640003f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16400045:	ff d0                	call   rax
    759a16400047:	48 89 df             	mov    rdi,rbx
    759a1640004a:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400051:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400058:	00 
    759a16400059:	41 bc 02 00 00 00    	mov    r12d,0x2
    759a1640005f:	bd 01 00 00 00       	mov    ebp,0x1
    759a16400064:	e9 ae 04 00 e8       	jmp    0x7599fe400517
    759a16400069:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400070:	02 00 00 00 
    759a16400074:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640007b:	01 00 00 00 
    759a1640007f:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16400086:	64 00 00 
    759a16400089:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640008e:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400093:	44 89 ce             	mov    esi,r9d
    759a16400096:	4c 89 c5             	mov    rbp,r8
    759a16400099:	49 89 de             	mov    r14,rbx
    759a1640009c:	4c 89 cb             	mov    rbx,r9
    759a1640009f:	4d 89 d7             	mov    r15,r10
    759a164000a2:	ff d0                	call   rax
    759a164000a4:	4d 89 fa             	mov    r10,r15
    759a164000a7:	49 89 d9             	mov    r9,rbx
    759a164000aa:	4c 89 f3             	mov    rbx,r14
    759a164000ad:	49 89 e8             	mov    r8,rbp
    759a164000b0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164000b5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164000bc:	00 
    759a164000bd:	84 c9                	test   cl,cl
    759a164000bf:	0f 84 a0 00 00 e8    	je     0x7599fe400165
    759a164000c5:	e9 db 02 00 00       	jmp    0x759a164003a5
    759a164000ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164000d1:	02 00 00 00 
    759a164000d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164000dc:	01 00 00 00 
    759a164000e0:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164000e7:	64 00 00 
    759a164000ea:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164000ef:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164000f4:	44 89 de             	mov    esi,r11d
    759a164000f7:	4c 89 c5             	mov    rbp,r8
    759a164000fa:	49 89 de             	mov    r14,rbx
    759a164000fd:	4c 89 cb             	mov    rbx,r9
    759a16400100:	4d 89 d7             	mov    r15,r10
    759a16400103:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400108:	ff d0                	call   rax
    759a1640010a:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a1640010f:	4d 89 fa             	mov    r10,r15
    759a16400112:	49 89 d9             	mov    r9,rbx
    759a16400115:	4c 89 f3             	mov    rbx,r14
    759a16400118:	49 89 e8             	mov    r8,rbp
    759a1640011b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400120:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400127:	00 
    759a16400128:	84 c9                	test   cl,cl
    759a1640012a:	0f 84 64 00 00 e8    	je     0x7599fe400194
    759a16400130:	e9 70 02 00 00       	jmp    0x759a164003a5
    759a16400135:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640013c:	02 00 00 00 
    759a16400140:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16400147:	01 00 00 00 
    759a1640014b:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16400152:	64 00 00 
    759a16400155:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640015a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a1640015f:	4c 89 c5             	mov    rbp,r8
    759a16400162:	49 89 de             	mov    r14,rbx
    759a16400165:	4c 89 cb             	mov    rbx,r9
    759a16400168:	4d 89 d7             	mov    r15,r10
    759a1640016b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400170:	ff d0                	call   rax
    759a16400172:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400177:	4d 89 fa             	mov    r10,r15
    759a1640017a:	49 89 d9             	mov    r9,rbx
    759a1640017d:	4c 89 f3             	mov    rbx,r14
    759a16400180:	49 89 e8             	mov    r8,rbp
    759a16400183:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400188:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640018f:	00 
    759a16400190:	84 c9                	test   cl,cl
    759a16400192:	0f 84 2f 00 00 e8    	je     0x7599fe4001c7
    759a16400198:	e9 08 02 00 00       	jmp    0x759a164003a5
    759a1640019d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164001a4:	02 00 00 00 
    759a164001a8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164001af:	01 00 00 00 
    759a164001b3:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164001ba:	64 00 00 
    759a164001bd:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164001c2:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164001c7:	4c 89 c5             	mov    rbp,r8
    759a164001ca:	49 89 de             	mov    r14,rbx
    759a164001cd:	4c 89 cb             	mov    rbx,r9
    759a164001d0:	4d 89 d7             	mov    r15,r10
    759a164001d3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164001d8:	ff d0                	call   rax
    759a164001da:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164001df:	4d 89 fa             	mov    r10,r15
    759a164001e2:	49 89 d9             	mov    r9,rbx
    759a164001e5:	4c 89 f3             	mov    rbx,r14
    759a164001e8:	49 89 e8             	mov    r8,rbp
    759a164001eb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164001f0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164001f7:	00 
    759a164001f8:	84 c9                	test   cl,cl
    759a164001fa:	0f 84 fa ff ff e7    	je     0x7599fe4001fa
    759a16400200:	e9 a0 01 00 00       	jmp    0x759a164003a5
    759a16400205:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640020c:	02 00 00 00 
    759a16400210:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16400217:	01 00 00 00 
    759a1640021b:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16400222:	64 00 00 
    759a16400225:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640022a:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a1640022f:	4c 89 c5             	mov    rbp,r8
    759a16400232:	49 89 de             	mov    r14,rbx
    759a16400235:	4c 89 cb             	mov    rbx,r9
    759a16400238:	4d 89 d7             	mov    r15,r10
    759a1640023b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400240:	ff d0                	call   rax
    759a16400242:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400247:	4d 89 fa             	mov    r10,r15
    759a1640024a:	49 89 d9             	mov    r9,rbx
    759a1640024d:	4c 89 f3             	mov    rbx,r14
    759a16400250:	49 89 e8             	mov    r8,rbp
    759a16400253:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400258:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640025f:	00 
    759a16400260:	84 c9                	test   cl,cl
    759a16400262:	0f 84 c2 ff ff e7    	je     0x7599fe40022a
    759a16400268:	e9 38 01 00 00       	jmp    0x759a164003a5
    759a1640026d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400274:	02 00 00 00 
    759a16400278:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640027f:	01 00 00 00 
    759a16400283:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640028a:	64 00 00 
    759a1640028d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400292:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400297:	4c 89 c5             	mov    rbp,r8
    759a1640029a:	49 89 de             	mov    r14,rbx
    759a1640029d:	4c 89 cb             	mov    rbx,r9
    759a164002a0:	4d 89 d7             	mov    r15,r10
    759a164002a3:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164002a8:	ff d0                	call   rax
    759a164002aa:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164002af:	4d 89 fa             	mov    r10,r15
    759a164002b2:	49 89 d9             	mov    r9,rbx
    759a164002b5:	4c 89 f3             	mov    rbx,r14
    759a164002b8:	49 89 e8             	mov    r8,rbp
    759a164002bb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164002c0:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164002c7:	00 
    759a164002c8:	84 c9                	test   cl,cl
    759a164002ca:	0f 84 8a ff ff e7    	je     0x7599fe40025a
    759a164002d0:	e9 d0 00 00 00       	jmp    0x759a164003a5
    759a164002d5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164002dc:	02 00 00 00 
    759a164002e0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164002e7:	01 00 00 00 
    759a164002eb:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164002f2:	64 00 00 
    759a164002f5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164002fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164002ff:	4c 89 c5             	mov    rbp,r8
    759a16400302:	49 89 de             	mov    r14,rbx
    759a16400305:	4c 89 cb             	mov    rbx,r9
    759a16400308:	4d 89 d7             	mov    r15,r10
    759a1640030b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400310:	ff d0                	call   rax
    759a16400312:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400317:	4d 89 fa             	mov    r10,r15
    759a1640031a:	49 89 d9             	mov    r9,rbx
    759a1640031d:	4c 89 f3             	mov    rbx,r14
    759a16400320:	49 89 e8             	mov    r8,rbp
    759a16400323:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    759a16400328:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640032d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400334:	00 
    759a16400335:	84 c9                	test   cl,cl
    759a16400337:	0f 84 4c ff ff e7    	je     0x7599fe400289
    759a1640033d:	eb 66                	jmp    0x759a164003a5
    759a1640033f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10016
    759a16400346:	16 00 01 00 
    759a1640034a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400351:	02 00 00 00 
    759a16400355:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640035c:	01 00 00 00 
    759a16400360:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16400367:	64 00 00 
    759a1640036a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640036f:	4c 89 ef             	mov    rdi,r13
    759a16400372:	4c 89 c5             	mov    rbp,r8
    759a16400375:	4c 89 cb             	mov    rbx,r9
    759a16400378:	4d 89 d7             	mov    r15,r10
    759a1640037b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400380:	ff d0                	call   rax
    759a16400382:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400387:	4d 89 fa             	mov    r10,r15
    759a1640038a:	49 89 d9             	mov    r9,rbx
    759a1640038d:	49 89 e8             	mov    r8,rbp
    759a16400390:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400395:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640039c:	00 
    759a1640039d:	84 c9                	test   cl,cl
    759a1640039f:	0f 84 f4 fe ff e7    	je     0x7599fe400299
    759a164003a5:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a164003ac:	e9 a8 fc ff ff       	jmp    0x759a16400059
    759a164003b1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    759a164003b8:	1a 00 01 00 
    759a164003bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164003c3:	04 00 00 00 
    759a164003c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a164003ce:	03 00 00 00 
    759a164003d2:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164003d9:	64 00 00 
    759a164003dc:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164003e1:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164003e6:	4c 89 c5             	mov    rbp,r8
    759a164003e9:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164003ee:	4d 89 d7             	mov    r15,r10
    759a164003f1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164003f6:	ff d0                	call   rax
    759a164003f8:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164003fd:	4d 89 fa             	mov    r10,r15
    759a16400400:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a16400405:	49 89 e8             	mov    r8,rbp
    759a16400408:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640040d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400414:	00 
    759a16400415:	84 c9                	test   cl,cl
    759a16400417:	0f 84 bc fe ff e7    	je     0x7599fe4002d9
    759a1640041d:	e9 e7 00 00 00       	jmp    0x759a16400509
    759a16400422:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001a
    759a16400429:	1a 00 01 00 
    759a1640042d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16400434:	04 00 00 00 
    759a16400438:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a1640043f:	03 00 00 00 
    759a16400443:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640044a:	64 00 00 
    759a1640044d:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400452:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400457:	89 ee                	mov    esi,ebp
    759a16400459:	89 da                	mov    edx,ebx
    759a1640045b:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    759a16400460:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16400465:	4c 89 d3             	mov    rbx,r10
    759a16400468:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a1640046d:	ff d0                	call   rax
    759a1640046f:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400474:	49 89 da             	mov    r10,rbx
    759a16400477:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640047c:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a16400481:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400486:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640048d:	00 
    759a1640048e:	84 c9                	test   cl,cl
    759a16400490:	0f 84 66 fe ff e7    	je     0x7599fe4002fc
    759a16400496:	eb 71                	jmp    0x759a16400509
    759a16400498:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1001e
    759a1640049f:	1e 00 01 00 
    759a164004a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164004aa:	04 00 00 00 
    759a164004ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a164004b5:	03 00 00 00 
    759a164004b9:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a164004c0:	64 00 00 
    759a164004c3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164004c8:	4c 89 ef             	mov    rdi,r13
    759a164004cb:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    759a164004d0:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a164004d5:	4c 89 d3             	mov    rbx,r10
    759a164004d8:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164004dd:	ff d0                	call   rax
    759a164004df:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164004e4:	49 89 da             	mov    r10,rbx
    759a164004e7:	4c 89 f3             	mov    rbx,r14
    759a164004ea:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a164004ef:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a164004f4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164004f9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400500:	00 
    759a16400501:	84 c9                	test   cl,cl
    759a16400503:	0f 84 0c fe ff e7    	je     0x7599fe400315
    759a16400509:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400510:	41 bc 04 00 00 00    	mov    r12d,0x4
    759a16400516:	bd 03 00 00 00       	mov    ebp,0x3
    759a1640051b:	e9 f7 ff ff e7       	jmp    0x7599fe400517
    759a16400520:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400525:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    759a1640052a:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a1640052f:	4c 89 c3             	mov    rbx,r8
    759a16400532:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400537:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10026
    759a1640053e:	26 00 01 00 
    759a16400542:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400549:	02 00 00 00 
    759a1640054d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16400554:	06 00 00 00 
    759a16400558:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640055f:	64 00 00 
    759a16400562:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400567:	be 00 f0 00 00       	mov    esi,0xf000
    759a1640056c:	ff d0                	call   rax
    759a1640056e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400575:	00 
    759a16400576:	84 c9                	test   cl,cl
    759a16400578:	0f 85 09 06 00 00    	jne    0x759a16400b87
    759a1640057e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400583:	49 89 d8             	mov    r8,rbx
    759a16400586:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640058b:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    759a16400590:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400595:	4c 89 f3             	mov    rbx,r14
    759a16400598:	e9 97 fd ff e7       	jmp    0x7599fe400334
    759a1640059d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    759a164005a4:	40 00 01 00 
    759a164005a8:	b1 01                	mov    cl,0x1
    759a164005aa:	bd 09 00 00 00       	mov    ebp,0x9
    759a164005af:	41 bc 02 00 00 00    	mov    r12d,0x2
    759a164005b5:	e9 03 00 00 e8       	jmp    0x7599fe4005bd
    759a164005ba:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10034
    759a164005c1:	34 00 01 00 
    759a164005c5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164005cc:	02 00 00 00 
    759a164005d0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a164005d7:	0c 00 00 00 
    759a164005db:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164005e2:	64 00 00 
    759a164005e5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164005ea:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164005ef:	be 10 f0 00 00       	mov    esi,0xf010
    759a164005f4:	ba 03 00 00 00       	mov    edx,0x3
    759a164005f9:	4c 89 44 24 28       	mov    QWORD PTR [rsp+0x28],r8
    759a164005fe:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16400603:	4c 89 d3             	mov    rbx,r10
    759a16400606:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a1640060b:	ff d0                	call   rax
    759a1640060d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400612:	49 89 da             	mov    r10,rbx
    759a16400615:	4c 89 f3             	mov    rbx,r14
    759a16400618:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640061d:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    759a16400622:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400627:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640062e:	00 
    759a1640062f:	84 c9                	test   cl,cl
    759a16400631:	0f 84 76 fd ff e7    	je     0x7599fe4003ad
    759a16400637:	eb 6a                	jmp    0x759a164006a3
    759a16400639:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10036
    759a16400640:	36 00 01 00 
    759a16400644:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640064b:	02 00 00 00 
    759a1640064f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a16400656:	0c 00 00 00 
    759a1640065a:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16400661:	64 00 00 
    759a16400664:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400669:	4c 89 ef             	mov    rdi,r13
    759a1640066c:	4d 89 c6             	mov    r14,r8
    759a1640066f:	4c 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],r9
    759a16400674:	4c 89 d3             	mov    rbx,r10
    759a16400677:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a1640067c:	ff d0                	call   rax
    759a1640067e:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400683:	49 89 da             	mov    r10,rbx
    759a16400686:	4c 8b 4c 24 30       	mov    r9,QWORD PTR [rsp+0x30]
    759a1640068b:	4d 89 f0             	mov    r8,r14
    759a1640068e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400693:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640069a:	00 
    759a1640069b:	84 c9                	test   cl,cl
    759a1640069d:	0f 84 13 fd ff e7    	je     0x7599fe4003b6
    759a164006a3:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a164006aa:	41 bc 02 00 00 00    	mov    r12d,0x2
    759a164006b0:	bd 0c 00 00 00       	mov    ebp,0xc
    759a164006b5:	e9 5d fe ff e7       	jmp    0x7599fe400517
    759a164006ba:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164006bf:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    759a164006c4:	4d 89 cf             	mov    r15,r9
    759a164006c7:	4c 89 c3             	mov    rbx,r8
    759a164006ca:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164006cf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    759a164006d6:	38 00 01 00 
    759a164006da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164006e1:	04 00 00 00 
    759a164006e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a164006ec:	0e 00 00 00 
    759a164006f0:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164006f7:	64 00 00 
    759a164006fa:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164006ff:	89 ee                	mov    esi,ebp
    759a16400701:	ff d0                	call   rax
    759a16400703:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640070a:	00 
    759a1640070b:	84 c9                	test   cl,cl
    759a1640070d:	0f 85 60 04 00 00    	jne    0x759a16400b73
    759a16400713:	89 c5                	mov    ebp,eax
    759a16400715:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640071a:	49 89 d8             	mov    r8,rbx
    759a1640071d:	4d 89 f9             	mov    r9,r15
    759a16400720:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    759a16400725:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a1640072a:	e9 a5 fc ff e7       	jmp    0x7599fe4003d4
    759a1640072f:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400734:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    759a16400739:	4d 89 cf             	mov    r15,r9
    759a1640073c:	4c 89 c3             	mov    rbx,r8
    759a1640073f:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400744:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10038
    759a1640074b:	38 00 01 00 
    759a1640074f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16400756:	04 00 00 00 
    759a1640075a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16400761:	0e 00 00 00 
    759a16400765:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640076c:	64 00 00 
    759a1640076f:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400774:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    759a16400779:	ff d0                	call   rax
    759a1640077b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400782:	00 
    759a16400783:	84 c9                	test   cl,cl
    759a16400785:	0f 85 e8 03 00 00    	jne    0x759a16400b73
    759a1640078b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400790:	49 89 d8             	mov    r8,rbx
    759a16400793:	4d 89 f9             	mov    r9,r15
    759a16400796:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    759a1640079b:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164007a0:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    759a164007a5:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    759a164007aa:	48 89 c3             	mov    rbx,rax
    759a164007ad:	e9 4c fc ff e7       	jmp    0x7599fe4003fe
    759a164007b2:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a164007b7:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164007bc:	4d 89 d7             	mov    r15,r10
    759a164007bf:	48 89 d6             	mov    rsi,rdx
    759a164007c2:	4c 89 cd             	mov    rbp,r9
    759a164007c5:	4c 89 c3             	mov    rbx,r8
    759a164007c8:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164007cd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a164007d4:	3c 00 01 00 
    759a164007d8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164007df:	02 00 00 00 
    759a164007e3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a164007ea:	0f 00 00 00 
    759a164007ee:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164007f5:	64 00 00 
    759a164007f8:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a164007fd:	ff d0                	call   rax
    759a164007ff:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400806:	00 
    759a16400807:	84 c9                	test   cl,cl
    759a16400809:	0f 85 48 03 00 00    	jne    0x759a16400b57
    759a1640080f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400814:	49 89 d8             	mov    r8,rbx
    759a16400817:	49 89 e9             	mov    r9,rbp
    759a1640081a:	4d 89 fa             	mov    r10,r15
    759a1640081d:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400822:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    759a16400827:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    759a1640082c:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a16400831:	e9 f7 fb ff e7       	jmp    0x7599fe40042d
    759a16400836:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a1640083b:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a16400840:	4d 89 d7             	mov    r15,r10
    759a16400843:	4c 89 cd             	mov    rbp,r9
    759a16400846:	4c 89 c3             	mov    rbx,r8
    759a16400849:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640084e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a16400855:	3c 00 01 00 
    759a16400859:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400860:	02 00 00 00 
    759a16400864:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a1640086b:	0f 00 00 00 
    759a1640086f:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400876:	64 00 00 
    759a16400879:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a1640087e:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    759a16400883:	ff d0                	call   rax
    759a16400885:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640088c:	00 
    759a1640088d:	84 c9                	test   cl,cl
    759a1640088f:	0f 85 c2 02 00 00    	jne    0x759a16400b57
    759a16400895:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640089a:	49 89 d8             	mov    r8,rbx
    759a1640089d:	49 89 e9             	mov    r9,rbp
    759a164008a0:	4d 89 fa             	mov    r10,r15
    759a164008a3:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164008a8:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    759a164008ad:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    759a164008b2:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a164008b7:	e9 95 fb ff e7       	jmp    0x7599fe400451
    759a164008bc:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a164008c1:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164008c6:	4d 89 d7             	mov    r15,r10
    759a164008c9:	4c 89 cd             	mov    rbp,r9
    759a164008cc:	4c 89 c3             	mov    rbx,r8
    759a164008cf:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164008d4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a164008db:	3c 00 01 00 
    759a164008df:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164008e6:	02 00 00 00 
    759a164008ea:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a164008f1:	0f 00 00 00 
    759a164008f5:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164008fc:	64 00 00 
    759a164008ff:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400904:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    759a16400909:	ff d0                	call   rax
    759a1640090b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400912:	00 
    759a16400913:	84 c9                	test   cl,cl
    759a16400915:	0f 85 3c 02 00 00    	jne    0x759a16400b57
    759a1640091b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400920:	49 89 d8             	mov    r8,rbx
    759a16400923:	49 89 e9             	mov    r9,rbp
    759a16400926:	4d 89 fa             	mov    r10,r15
    759a16400929:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a1640092e:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    759a16400933:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    759a16400938:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a1640093d:	e9 33 fb ff e7       	jmp    0x7599fe400475
    759a16400942:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a16400947:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a1640094c:	4d 89 d7             	mov    r15,r10
    759a1640094f:	4c 89 cd             	mov    rbp,r9
    759a16400952:	4c 89 c3             	mov    rbx,r8
    759a16400955:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640095a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a16400961:	3c 00 01 00 
    759a16400965:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640096c:	02 00 00 00 
    759a16400970:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a16400977:	0f 00 00 00 
    759a1640097b:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400982:	64 00 00 
    759a16400985:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a1640098a:	89 ce                	mov    esi,ecx
    759a1640098c:	ff d0                	call   rax
    759a1640098e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400995:	00 
    759a16400996:	84 c9                	test   cl,cl
    759a16400998:	0f 85 b9 01 00 00    	jne    0x759a16400b57
    759a1640099e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164009a3:	49 89 d8             	mov    r8,rbx
    759a164009a6:	49 89 e9             	mov    r9,rbp
    759a164009a9:	4d 89 fa             	mov    r10,r15
    759a164009ac:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a164009b1:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    759a164009b6:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a164009bb:	e9 d7 fa ff e7       	jmp    0x7599fe400497
    759a164009c0:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a164009c5:	4c 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],r11
    759a164009ca:	4d 89 d7             	mov    r15,r10
    759a164009cd:	4c 89 cd             	mov    rbp,r9
    759a164009d0:	4c 89 c3             	mov    rbx,r8
    759a164009d3:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164009d8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a164009df:	3c 00 01 00 
    759a164009e3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164009ea:	02 00 00 00 
    759a164009ee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a164009f5:	0f 00 00 00 
    759a164009f9:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400a00:	64 00 00 
    759a16400a03:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400a08:	ff d0                	call   rax
    759a16400a0a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400a11:	00 
    759a16400a12:	84 c9                	test   cl,cl
    759a16400a14:	0f 85 3d 01 00 00    	jne    0x759a16400b57
    759a16400a1a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400a1f:	49 89 d8             	mov    r8,rbx
    759a16400a22:	49 89 e9             	mov    r9,rbp
    759a16400a25:	4d 89 fa             	mov    r10,r15
    759a16400a28:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
    759a16400a2d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a16400a32:	e9 82 fa ff e7       	jmp    0x7599fe4004b9
    759a16400a37:	48 89 5c 24 20       	mov    QWORD PTR [rsp+0x20],rbx
    759a16400a3c:	4d 89 d7             	mov    r15,r10
    759a16400a3f:	4c 89 cd             	mov    rbp,r9
    759a16400a42:	4c 89 c3             	mov    rbx,r8
    759a16400a45:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400a4a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a16400a51:	3c 00 01 00 
    759a16400a55:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400a5c:	02 00 00 00 
    759a16400a60:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a16400a67:	0f 00 00 00 
    759a16400a6b:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400a72:	64 00 00 
    759a16400a75:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400a7a:	44 89 de             	mov    esi,r11d
    759a16400a7d:	ff d0                	call   rax
    759a16400a7f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400a86:	00 
    759a16400a87:	84 c9                	test   cl,cl
    759a16400a89:	0f 85 c8 00 00 00    	jne    0x759a16400b57
    759a16400a8f:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400a94:	49 89 d8             	mov    r8,rbx
    759a16400a97:	49 89 e9             	mov    r9,rbp
    759a16400a9a:	4d 89 fa             	mov    r10,r15
    759a16400a9d:	48 8b 5c 24 20       	mov    rbx,QWORD PTR [rsp+0x20]
    759a16400aa2:	e9 36 fa ff e7       	jmp    0x7599fe4004dd
    759a16400aa7:	48 89 dd             	mov    rbp,rbx
    759a16400aaa:	4c 89 c3             	mov    rbx,r8
    759a16400aad:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16400ab2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003c
    759a16400ab9:	3c 00 01 00 
    759a16400abd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400ac4:	02 00 00 00 
    759a16400ac8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a16400acf:	0f 00 00 00 
    759a16400ad3:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400ada:	64 00 00 
    759a16400add:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    759a16400ae2:	44 89 ce             	mov    esi,r9d
    759a16400ae5:	ff d0                	call   rax
    759a16400ae7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400aee:	00 
    759a16400aef:	84 c9                	test   cl,cl
    759a16400af1:	75 64                	jne    0x759a16400b57
    759a16400af3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400af8:	49 89 d8             	mov    r8,rbx
    759a16400afb:	48 89 eb             	mov    rbx,rbp
    759a16400afe:	e9 f6 f9 ff e7       	jmp    0x7599fe4004f9
    759a16400b03:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1003e
    759a16400b0a:	3e 00 01 00 
    759a16400b0e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400b15:	02 00 00 00 
    759a16400b19:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    759a16400b20:	10 00 00 00 
    759a16400b24:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a16400b2b:	64 00 00 
    759a16400b2e:	49 89 ff             	mov    r15,rdi
    759a16400b31:	4c 89 ef             	mov    rdi,r13
    759a16400b34:	be 2a 00 00 00       	mov    esi,0x2a
    759a16400b39:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    759a16400b3e:	ff d0                	call   rax
    759a16400b40:	4c 89 ff             	mov    rdi,r15
    759a16400b43:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400b4a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16400b51:	00 
    759a16400b52:	e9 c0 f9 ff e7       	jmp    0x7599fe400517
    759a16400b57:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400b5e:	41 bc 02 00 00 00    	mov    r12d,0x2
    759a16400b64:	bd 0f 00 00 00       	mov    ebp,0xf
    759a16400b69:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16400b6e:	e9 a4 f9 ff e7       	jmp    0x7599fe400517
    759a16400b73:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400b7a:	41 bc 04 00 00 00    	mov    r12d,0x4
    759a16400b80:	bd 0e 00 00 00       	mov    ebp,0xe
    759a16400b85:	eb e2                	jmp    0x759a16400b69
    759a16400b87:	41 8b 9d bc 00 00 00 	mov    ebx,DWORD PTR [r13+0xbc]
    759a16400b8e:	41 bc 02 00 00 00    	mov    r12d,0x2
    759a16400b94:	bd 06 00 00 00       	mov    ebp,0x6
    759a16400b99:	eb ce                	jmp    0x759a16400b69
