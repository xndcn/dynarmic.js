; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010110(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -65839
  %5 = icmp ult i32 %4, -31
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb50 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb50, -65839
  %8 = icmp ult i32 %7, -31
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010110, label %common.ret, !prof !0

insn_0x00010110:                                  ; preds = %entry
  %rs = load i32, ptr %cpu, align 4
  %lsr32 = lshr i32 %rs, 7
  %10 = getelementptr i8, ptr %cpu, i64 4
  %11 = getelementptr i8, ptr %cpu, i64 228
  %12 = getelementptr i8, ptr %cpu, i64 232
  %13 = getelementptr i8, ptr %cpu, i64 248
  %xor32 = xor i32 %lsr32, %rs
  store i32 %xor32, ptr %10, align 4
  %14 = icmp eq i32 %xor32, 0
  %az1 = zext i1 %14 to i32
  %an2 = lshr i32 %rs, 31
  store i32 %az1, ptr %11, align 4
  store i32 %an2, ptr %12, align 4
  %15 = getelementptr i8, ptr %cpu, i64 236
  store <2 x i32> zeroinitializer, ptr %15, align 4
  store <2 x i32> zeroinitializer, ptr %13, align 4
  %16 = getelementptr i8, ptr %cpu, i64 40
  store i32 %xor32, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 36
  store i32 -1640531527, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %19, align 4
  %20 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %20, align 4
  %sp1 = add i32 %sp, -4
  %21 = and i32 %sp, 3
  %.not = icmp eq i32 %21, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010110
  %22 = getelementptr i8, ptr %cpu, i64 188
  store i32 65824, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %24, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 65824, i32 %sp1, i32 65536)
  %next_pc = load i32, ptr %22, align 4
  %25 = getelementptr i8, ptr %cpu, i64 296
  %26 = load i8, ptr %25, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010110
  %27 = lshr i32 %sp1, 12
  %page_index = zext i32 %27 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %28 = and i32 %sp1, 4095
  %page_offset = zext i32 %28 to i64
  %29 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %29, align 4
  br label %data_aligned4

page_wr_slow:                                     ; preds = %data_aligned
  %30 = getelementptr i8, ptr %cpu, i64 188
  store i32 65824, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %32, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %33 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %33, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %data_aligned4, label %did_jump_exit, !prof !0

did_jump_exit:                                    ; preds = %page_wr_slow
  %next_pc51 = load i32, ptr %30, align 4
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_fast, %page_wr_slow
  %sp2 = add i32 %sp, -8
  %34 = lshr i32 %sp2, 12
  %page_index8 = zext i32 %34 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11.not = icmp eq ptr %page10, null
  br i1 %page_mapped11.not, label %page_wr_slow6, label %page_wr_fast5, !prof !1

page_wr_fast5:                                    ; preds = %data_aligned4
  %35 = and i32 %sp2, 4095
  %page_offset12 = zext i32 %35 to i64
  %36 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %fp, ptr %36, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %37 = getelementptr i8, ptr %cpu, i64 188
  store i32 65824, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %39, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %40 = getelementptr i8, ptr %cpu, i64 296
  %dj15 = load i8, ptr %40, align 1
  %dj_set16.not = icmp eq i8 %dj15, 0
  br i1 %dj_set16.not, label %page_wr_done7, label %did_jump_exit13, !prof !0

page_wr_done7:                                    ; preds = %page_wr_slow6, %page_wr_fast5
  store i32 %sp2, ptr %20, align 4
  store i32 %sp2, ptr %18, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not66 = icmp eq i8 %cec_pending, 0
  br i1 %.not66, label %data_aligned22, label %cec_check, !prof !0

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %next_pc53 = load i32, ptr %37, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done7
  %41 = getelementptr i8, ptr %cpu, i64 188
  store i32 65828, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %43, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %44 = getelementptr i8, ptr %cpu, i64 296
  %dj19 = load i8, ptr %44, align 1
  %dj_set20.not = icmp eq i8 %dj19, 0
  br i1 %dj_set20.not, label %data_aligned22, label %did_jump_exit17, !prof !0

did_jump_exit17:                                  ; preds = %cec_check
  %next_pc54 = load i32, ptr %41, align 4
  br label %chain_exit

data_aligned22:                                   ; preds = %cec_check, %page_wr_done7
  %page25 = load ptr, ptr %page_slot9, align 8
  %page_mapped26.not = icmp eq ptr %page25, null
  br i1 %page_mapped26.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %data_aligned22
  %45 = and i32 %sp2, 4095
  %page_offset27 = zext i32 %45 to i64
  %46 = getelementptr i8, ptr %page25, i64 %page_offset27
  %page_val = load i32, ptr %46, align 4
  br label %data_aligned34

page_slow:                                        ; preds = %data_aligned22
  %47 = getelementptr i8, ptr %cpu, i64 188
  store i32 65828, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %49, align 4
  %50 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %51 = getelementptr i8, ptr %cpu, i64 296
  %dj30 = load i8, ptr %51, align 1
  %dj_set31.not = icmp eq i8 %dj30, 0
  br i1 %dj_set31.not, label %data_aligned34, label %did_jump_exit28, !prof !0

did_jump_exit28:                                  ; preds = %page_slow
  %next_pc56 = load i32, ptr %47, align 4
  br label %chain_exit

data_aligned34:                                   ; preds = %page_fast, %page_slow
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %50, %page_slow ]
  %page40 = load ptr, ptr %page_slot, align 8
  %page_mapped41.not = icmp eq ptr %page40, null
  br i1 %page_mapped41.not, label %page_slow36, label %page_fast35, !prof !1

page_fast35:                                      ; preds = %data_aligned34
  %52 = and i32 %sp1, 4095
  %page_offset42 = zext i32 %52 to i64
  %53 = getelementptr i8, ptr %page40, i64 %page_offset42
  %page_val43 = load i32, ptr %53, align 4
  br label %page_done37

page_slow36:                                      ; preds = %data_aligned34
  %54 = getelementptr i8, ptr %cpu, i64 188
  store i32 65828, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %56, align 4
  %57 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %58 = getelementptr i8, ptr %cpu, i64 296
  %dj46 = load i8, ptr %58, align 1
  %dj_set47.not = icmp eq i8 %dj46, 0
  br i1 %dj_set47.not, label %page_done37, label %did_jump_exit44, !prof !0

page_done37:                                      ; preds = %page_slow36, %page_fast35
  %mem_val48 = phi i32 [ %page_val43, %page_fast35 ], [ %57, %page_slow36 ]
  store i32 %mem_val, ptr %20, align 4
  store i32 %mem_val48, ptr %19, align 4
  store i32 %sp, ptr %18, align 4
  %plshift1 = mul i32 %xor32, 3
  store i32 %plshift1, ptr %16, align 4
  %padd = add i32 %plshift1, -1640531527
  store i32 %padd, ptr %17, align 4
  store i32 %padd, ptr %cpu, align 4
  %lsb = and i32 %mem_val48, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit44:                                  ; preds = %page_slow36
  %next_pc58 = load i32, ptr %54, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done37
  %59 = getelementptr i8, ptr %cpu, i64 188
  store i32 65838, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 308
  store i32 11, ptr %61, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc59 = load i32, ptr %59, align 4
  %62 = getelementptr i8, ptr %cpu, i64 296
  %63 = load i8, ptr %62, align 1
  br label %chain_exit

common.ret:                                       ; preds = %entry, %chain_leave64
  %.sink67 = phi i64 [ 296, %chain_leave64 ], [ 357, %entry ]
  %tail63.sink = phi i8 [ %tail63, %chain_leave64 ], [ 1, %entry ]
  %64 = getelementptr i8, ptr %cpu, i64 %.sink67
  store i8 %tail63.sink, ptr %64, align 1
  ret void

chain_exit:                                       ; preds = %page_done37, %jump_misalign, %did_jump_exit44, %did_jump_exit28, %did_jump_exit17, %did_jump_exit13, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 6, %did_jump_exit13 ], [ 6, %did_jump_exit17 ], [ 7, %did_jump_exit28 ], [ 7, %did_jump_exit44 ], [ 11, %jump_misalign ], [ 11, %page_done37 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc51, %did_jump_exit ], [ %next_pc53, %did_jump_exit13 ], [ %next_pc54, %did_jump_exit17 ], [ %next_pc56, %did_jump_exit28 ], [ %next_pc58, %did_jump_exit44 ], [ %next_pc59, %jump_misalign ], [ %mem_val48, %page_done37 ]
  %tail61 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %did_jump_exit13 ], [ 4, %did_jump_exit17 ], [ 4, %did_jump_exit28 ], [ 4, %did_jump_exit44 ], [ 2, %jump_misalign ], [ 2, %page_done37 ]
  %tail63 = phi i8 [ %26, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj15, %did_jump_exit13 ], [ %dj19, %did_jump_exit17 ], [ %dj30, %did_jump_exit28 ], [ %dj46, %did_jump_exit44 ], [ %63, %jump_misalign ], [ 1, %page_done37 ]
  %65 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %65, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %66 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %66 monotonic, align 4, !range !2
  %67 = icmp ult i32 %chain_total, %chain_budget
  br i1 %67, label %chain_lookup, label %chain_leave64, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %68 = shl i32 %tail, 3
  %69 = and i32 %68, 1048560
  %70 = zext i32 %69 to i64
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %70
  %slot_pc = load i32, ptr %chain_slot, align 4
  %71 = icmp eq i32 %slot_pc, %tail
  br i1 %71, label %chain_hit, label %chain_leave64, !prof !0

chain_leave64:                                    ; preds = %chain_lookup, %chain_exit
  %72 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail61, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %74, align 4
  br label %common.ret

chain_hit:                                        ; preds = %chain_lookup
  %75 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %75, align 4
  store i32 %chain_total, ptr %65, align 4
  %76 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %76, align 1
  %77 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %77, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
