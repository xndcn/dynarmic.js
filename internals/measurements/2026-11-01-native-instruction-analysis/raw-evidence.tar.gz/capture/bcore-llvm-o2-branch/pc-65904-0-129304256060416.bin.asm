
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65904-0-129304256060416.bin:     file format binary


Disassembly of section .data:

00007599fe401c00 <.data>:
    7599fe401c00:	b9 8d fe fe ff       	mov    ecx,0xfffefe8d
    7599fe401c05:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7599fe401c0c:	01 ca                	add    edx,ecx
    7599fe401c0e:	b8 65 01 00 00       	mov    eax,0x165
    7599fe401c13:	83 fa fc             	cmp    edx,0xfffffffc
    7599fe401c16:	0f 87 f0 00 00 00    	ja     0x7599fe401d0c
    7599fe401c1c:	41 03 8d a4 00 00 00 	add    ecx,DWORD PTR [r13+0xa4]
    7599fe401c23:	83 f9 fc             	cmp    ecx,0xfffffffc
    7599fe401c26:	0f 87 e0 00 00 00    	ja     0x7599fe401d0c
    7599fe401c2c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7599fe401c33:	41 8b 4d 00          	mov    ecx,DWORD PTR [r13+0x0]
    7599fe401c37:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7599fe401c3b:	89 d6                	mov    esi,edx
    7599fe401c3d:	c1 ee 1f             	shr    esi,0x1f
    7599fe401c40:	89 cf                	mov    edi,ecx
    7599fe401c42:	c1 ef 1f             	shr    edi,0x1f
    7599fe401c45:	31 db                	xor    ebx,ebx
    7599fe401c47:	01 ca                	add    edx,ecx
    7599fe401c49:	41 89 55 00          	mov    DWORD PTR [r13+0x0],edx
    7599fe401c4d:	0f 92 c3             	setb   bl
    7599fe401c50:	89 d1                	mov    ecx,edx
    7599fe401c52:	c1 e9 1f             	shr    ecx,0x1f
    7599fe401c55:	31 cf                	xor    edi,ecx
    7599fe401c57:	31 ce                	xor    esi,ecx
    7599fe401c59:	21 fe                	and    esi,edi
    7599fe401c5b:	31 ff                	xor    edi,edi
    7599fe401c5d:	85 d2                	test   edx,edx
    7599fe401c5f:	40 0f 94 c7          	sete   dil
    7599fe401c63:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    7599fe401c6a:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe401c71:	41 89 b5 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],esi
    7599fe401c78:	41 89 b5 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],esi
    7599fe401c7f:	41 09 b5 00 01 00 00 	or     DWORD PTR [r13+0x100],esi
    7599fe401c86:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    7599fe401c8d:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    7599fe401c94:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x10176
    7599fe401c9b:	76 01 01 00 
    7599fe401c9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7599fe401ca6:	30 01 01 00 
    7599fe401caa:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe401cb1:	83 c1 02             	add    ecx,0x2
    7599fe401cb4:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe401cbb:	39 d1                	cmp    ecx,edx
    7599fe401cbd:	73 27                	jae    0x7599fe401ce6
    7599fe401cbf:	81 b8 80 09 08 00 30 	cmp    DWORD PTR [rax+0x80980],0x10130
    7599fe401cc6:	01 01 00 
    7599fe401cc9:	75 1b                	jne    0x7599fe401ce6
    7599fe401ccb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7599fe401cd2:	30 01 01 00 
    7599fe401cd6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe401cdd:	48 8b 80 88 09 08 00 	mov    rax,QWORD PTR [rax+0x80988]
    7599fe401ce4:	ff e0                	jmp    rax
    7599fe401ce6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    7599fe401ced:	30 01 01 00 
    7599fe401cf1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7599fe401cf8:	04 00 00 00 
    7599fe401cfc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7599fe401d03:	02 00 00 00 
    7599fe401d07:	b8 28 01 00 00       	mov    eax,0x128
    7599fe401d0c:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    7599fe401d12:	c2 08 00             	ret    0x8
