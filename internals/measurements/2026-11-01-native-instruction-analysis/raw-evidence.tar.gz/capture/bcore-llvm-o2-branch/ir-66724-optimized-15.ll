; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000104a4(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = add i32 %guard_lb, -66749
  %4 = icmp ult i32 %3, -25
  %5 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb53 = load i32, ptr %5, align 4
  %6 = add i32 %guard_lb53, -66749
  %7 = icmp ult i32 %6, -25
  %8 = and i1 %4, %7
  br i1 %8, label %insn_0x000104a4, label %lb_guard_miss, !prof !0

insn_0x000104a4:                                  ; preds = %entry
  %9 = getelementptr i8, ptr %cpu, i64 40
  store i32 70388, ptr %9, align 4
  %page_slot = getelementptr ptr, ptr %page_table, i64 17
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x000104a4
  %10 = getelementptr i8, ptr %page, i64 756
  %page_val = load i32, ptr %10, align 4
  br label %page_done

page_slow:                                        ; preds = %insn_0x000104a4
  %11 = getelementptr i8, ptr %cpu, i64 188
  store i32 66732, ptr %11, align 4
  %12 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %13, align 4
  %14 = tail call i32 @mem_read32(ptr %mem, i32 70388)
  %15 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %15, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_done, label %chain_exit, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %14, %page_slow ]
  store i32 %mem_val, ptr %cpu, align 4
  store i32 70392, ptr %9, align 4
  %page12 = load ptr, ptr %page_slot, align 8
  %page_mapped13.not = icmp eq ptr %page12, null
  br i1 %page_mapped13.not, label %page_slow8, label %page_fast7, !prof !1

page_fast7:                                       ; preds = %page_done
  %16 = getelementptr i8, ptr %page12, i64 760
  %page_val15 = load i32, ptr %16, align 4
  br label %page_done9

page_slow8:                                       ; preds = %page_done
  %17 = getelementptr i8, ptr %cpu, i64 188
  store i32 66742, ptr %17, align 4
  %18 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %18, align 4
  %19 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %19, align 4
  %20 = tail call i32 @mem_read32(ptr %mem, i32 70392)
  %21 = getelementptr i8, ptr %cpu, i64 296
  %dj18 = load i8, ptr %21, align 1
  %dj_set19.not = icmp eq i8 %dj18, 0
  br i1 %dj_set19.not, label %page_done9, label %chain_exit, !prof !0

page_done9:                                       ; preds = %page_slow8, %page_fast7
  %mem_val20 = phi i32 [ %page_val15, %page_fast7 ], [ %20, %page_slow8 ]
  %22 = getelementptr i8, ptr %cpu, i64 4
  store i32 %mem_val20, ptr %22, align 4
  %23 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %23, align 4
  %24 = and i32 %fp, 3
  %.not = icmp eq i32 %24, 0
  br i1 %.not, label %data_aligned22, label %data_misaligned21, !prof !0

data_misaligned21:                                ; preds = %page_done9
  %25 = getelementptr i8, ptr %cpu, i64 188
  store i32 66744, ptr %25, align 4
  %26 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %26, align 4
  %27 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %27, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 66744, i32 %fp, i32 0)
  br label %chain_exit

data_aligned22:                                   ; preds = %page_done9
  %28 = lshr i32 %fp, 12
  %page_index26 = zext i32 %28 to i64
  %page_slot27 = getelementptr ptr, ptr %page_table, i64 %page_index26
  %page28 = load ptr, ptr %page_slot27, align 8
  %page_mapped29.not = icmp eq ptr %page28, null
  br i1 %page_mapped29.not, label %page_slow24, label %page_fast23, !prof !1

page_fast23:                                      ; preds = %data_aligned22
  %29 = and i32 %fp, 4095
  %page_offset30 = zext i32 %29 to i64
  %30 = getelementptr i8, ptr %page28, i64 %page_offset30
  %page_val31 = load i32, ptr %30, align 4
  br label %data_aligned38

page_slow24:                                      ; preds = %data_aligned22
  %31 = getelementptr i8, ptr %cpu, i64 188
  store i32 66744, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %33, align 4
  %34 = tail call i32 @mem_read32(ptr %mem, i32 %fp)
  %35 = getelementptr i8, ptr %cpu, i64 296
  %dj34 = load i8, ptr %35, align 1
  %dj_set35.not = icmp eq i8 %dj34, 0
  br i1 %dj_set35.not, label %data_aligned38, label %chain_exit, !prof !0

data_aligned38:                                   ; preds = %page_fast23, %page_slow24
  %mem_val36 = phi i32 [ %page_val31, %page_fast23 ], [ %34, %page_slow24 ]
  %sp1 = add i32 %fp, 4
  %36 = lshr i32 %sp1, 12
  %page_index42 = zext i32 %36 to i64
  %page_slot43 = getelementptr ptr, ptr %page_table, i64 %page_index42
  %page44 = load ptr, ptr %page_slot43, align 8
  %page_mapped45.not = icmp eq ptr %page44, null
  br i1 %page_mapped45.not, label %page_slow40, label %page_fast39, !prof !1

page_fast39:                                      ; preds = %data_aligned38
  %37 = and i32 %sp1, 4095
  %page_offset46 = zext i32 %37 to i64
  %38 = getelementptr i8, ptr %page44, i64 %page_offset46
  %page_val47 = load i32, ptr %38, align 4
  br label %page_done41

page_slow40:                                      ; preds = %data_aligned38
  %39 = getelementptr i8, ptr %cpu, i64 188
  store i32 66744, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %41, align 4
  %42 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %43 = getelementptr i8, ptr %cpu, i64 296
  %dj50 = load i8, ptr %43, align 1
  %dj_set51.not = icmp eq i8 %dj50, 0
  br i1 %dj_set51.not, label %page_done41, label %chain_exit, !prof !0

page_done41:                                      ; preds = %page_slow40, %page_fast39
  %mem_val52 = phi i32 [ %page_val47, %page_fast39 ], [ %42, %page_slow40 ]
  %sp2 = add i32 %fp, 8
  store i32 %mem_val36, ptr %23, align 4
  %44 = getelementptr i8, ptr %cpu, i64 168
  store i32 %mem_val52, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i64 56
  store i32 %sp2, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i64 188
  store i32 65868, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %47, align 4
  %chain_total = add nuw i32 %chain_packets, 8
  %48 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %48 monotonic, align 4, !range !2
  %49 = icmp ult i32 %chain_total, %chain_budget
  br i1 %49, label %chain_go, label %chain_leave61, !prof !0

common.ret:                                       ; preds = %chain_leave64, %chain_leave61, %lb_guard_miss
  ret void

lb_guard_miss:                                    ; preds = %entry
  %50 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %50, align 1
  br label %common.ret

chain_go:                                         ; preds = %page_done41
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526944
  %slot_pc = load i32, ptr %chain_slot, align 4
  %51 = icmp eq i32 %slot_pc, 65868
  br i1 %51, label %chain_hit, label %chain_leave61, !prof !0

chain_leave61:                                    ; preds = %chain_go, %page_done41
  store i32 65868, ptr %46, align 4
  %52 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %54, align 1
  br label %common.ret

chain_hit:                                        ; preds = %chain_go
  store i32 65868, ptr %46, align 4
  store i32 %chain_total, ptr %47, align 4
  %55 = getelementptr i8, ptr %chain_table, i64 526952
  %chain_fn = load ptr, ptr %55, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_slow40, %page_slow24, %page_slow8, %page_slow, %data_misaligned21
  %packets = phi i32 [ 7, %data_misaligned21 ], [ 3, %page_slow ], [ 6, %page_slow8 ], [ 7, %page_slow24 ], [ 7, %page_slow40 ]
  %tail = phi i32 [ 4, %data_misaligned21 ], [ 2, %page_slow ], [ 2, %page_slow8 ], [ 4, %page_slow24 ], [ 4, %page_slow40 ]
  %next_pc62.in = getelementptr i8, ptr %cpu, i64 188
  %next_pc62 = load i32, ptr %next_pc62.in, align 4
  %56 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets65 = load i32, ptr %56, align 4
  %chain_total66 = add nuw i32 %chain_packets65, %packets
  %57 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget67 = load atomic i32, ptr %57 monotonic, align 4, !range !2
  %58 = icmp ult i32 %chain_total66, %chain_budget67
  br i1 %58, label %chain_lookup, label %chain_leave64, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %59 = shl i32 %next_pc62, 3
  %60 = and i32 %59, 1048560
  %61 = zext i32 %60 to i64
  %chain_slot68 = getelementptr i8, ptr %chain_table, i64 %61
  %slot_pc69 = load i32, ptr %chain_slot68, align 4
  %62 = icmp eq i32 %slot_pc69, %next_pc62
  br i1 %62, label %chain_hit70, label %chain_leave64, !prof !0

chain_leave64:                                    ; preds = %chain_lookup, %chain_exit
  %63 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %64, align 4
  br label %common.ret

chain_hit70:                                      ; preds = %chain_lookup
  store i32 %chain_total66, ptr %56, align 4
  %65 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %65, align 1
  %66 = getelementptr i8, ptr %chain_slot68, i64 8
  %chain_fn71 = load ptr, ptr %66, align 8
  musttail call swifttailcc void %chain_fn71(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
