
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65808-0-129304256061968.bin:     file format binary


Disassembly of section .data:

00007599fe402210 <.data>:
    7599fe402210:	48 83 ec 28          	sub    rsp,0x28
    7599fe402214:	ba d1 fe fe ff       	mov    edx,0xfffefed1
    7599fe402219:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe402220:	01 d6                	add    esi,edx
    7599fe402222:	b1 01                	mov    cl,0x1
    7599fe402224:	b8 65 01 00 00       	mov    eax,0x165
    7599fe402229:	83 fe e0             	cmp    esi,0xffffffe0
    7599fe40222c:	0f 87 ad 01 00 00    	ja     0x7599fe4023df
    7599fe402232:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe402239:	83 fa e0             	cmp    edx,0xffffffe0
    7599fe40223c:	0f 87 9d 01 00 00    	ja     0x7599fe4023df
    7599fe402242:	4d 89 f0             	mov    r8,r14
    7599fe402245:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7599fe40224c:	4d 8b 8d 38 01 00 00 	mov    r9,QWORD PTR [r13+0x138]
    7599fe402253:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    7599fe40225a:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7599fe40225e:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    7599fe402262:	41 89 c4             	mov    r12d,eax
    7599fe402265:	41 c1 ec 07          	shr    r12d,0x7
    7599fe402269:	31 c9                	xor    ecx,ecx
    7599fe40226b:	41 31 c4             	xor    r12d,eax
    7599fe40226e:	45 89 65 04          	mov    DWORD PTR [r13+0x4],r12d
    7599fe402272:	0f 94 c1             	sete   cl
    7599fe402275:	c1 e8 1f             	shr    eax,0x1f
    7599fe402278:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7599fe40227f:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7599fe402286:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7599fe40228d:	00 00 00 00 
    7599fe402291:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe402298:	00 00 00 00 
    7599fe40229c:	45 89 65 28          	mov    DWORD PTR [r13+0x28],r12d
    7599fe4022a0:	41 c7 45 24 b9 79 37 	mov    DWORD PTR [r13+0x24],0x9e3779b9
    7599fe4022a7:	9e 
    7599fe4022a8:	8d 5e fc             	lea    ebx,[rsi-0x4]
    7599fe4022ab:	40 f6 c6 03          	test   sil,0x3
    7599fe4022af:	0f 85 76 0c 00 18    	jne    0x759a16402f2b
    7599fe4022b5:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe4022bc:	45 8b 5d 3c          	mov    r11d,DWORD PTR [r13+0x3c]
    7599fe4022c0:	41 89 de             	mov    r14d,ebx
    7599fe4022c3:	41 c1 ee 0c          	shr    r14d,0xc
    7599fe4022c7:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    7599fe4022cb:	48 85 c0             	test   rax,rax
    7599fe4022ce:	0f 84 c1 0c 00 18    	je     0x759a16402f95
    7599fe4022d4:	89 d9                	mov    ecx,ebx
    7599fe4022d6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4022dc:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4022df:	8d 6e f8             	lea    ebp,[rsi-0x8]
    7599fe4022e2:	41 89 ef             	mov    r15d,ebp
    7599fe4022e5:	41 c1 ef 0c          	shr    r15d,0xc
    7599fe4022e9:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    7599fe4022ed:	48 85 c0             	test   rax,rax
    7599fe4022f0:	0f 84 18 0d 00 18    	je     0x759a1640300e
    7599fe4022f6:	89 e9                	mov    ecx,ebp
    7599fe4022f8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4022fe:	44 89 1c 08          	mov    DWORD PTR [rax+rcx*1],r11d
    7599fe402302:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe402306:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7599fe40230a:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    7599fe40230e:	0f 85 71 0d 00 18    	jne    0x759a16403085
    7599fe402314:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    7599fe402318:	48 85 c0             	test   rax,rax
    7599fe40231b:	0f 84 dc 0d 00 18    	je     0x759a164030fd
    7599fe402321:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7599fe402327:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7599fe40232a:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    7599fe40232e:	48 85 c0             	test   rax,rax
    7599fe402331:	0f 84 31 0e 00 18    	je     0x759a16403168
    7599fe402337:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    7599fe40233d:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    7599fe402340:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe402344:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7599fe40234b:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe40234f:	43 8d 0c 64          	lea    ecx,[r12+r12*2]
    7599fe402353:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7599fe402357:	43 8d 8c 64 b9 79 37 	lea    ecx,[r12+r12*2-0x61c88647]
    7599fe40235e:	9e 
    7599fe40235f:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7599fe402363:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    7599fe402367:	b1 01                	mov    cl,0x1
    7599fe402369:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe40236e:	bd 0b 00 00 00       	mov    ebp,0xb
    7599fe402373:	a8 01                	test   al,0x1
    7599fe402375:	0f 85 48 0e 00 18    	jne    0x759a164031c3
    7599fe40237b:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7599fe402382:	01 ea                	add    edx,ebp
    7599fe402384:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7599fe40238b:	39 f2                	cmp    edx,esi
    7599fe40238d:	73 36                	jae    0x7599fe4023c5
    7599fe40238f:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7599fe402396:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7599fe40239c:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    7599fe40239f:	75 24                	jne    0x7599fe4023c5
    7599fe4023a1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe4023a8:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7599fe4023af:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe4023b6:	00 
    7599fe4023b7:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    7599fe4023bc:	4d 89 c6             	mov    r14,r8
    7599fe4023bf:	48 83 c4 28          	add    rsp,0x28
    7599fe4023c3:	ff e0                	jmp    rax
    7599fe4023c5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe4023cc:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe4023d3:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe4023da:	b8 28 01 00 00       	mov    eax,0x128
    7599fe4023df:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe4023e4:	48 83 c4 28          	add    rsp,0x28
    7599fe4023e8:	c2 08 00             	ret    0x8
