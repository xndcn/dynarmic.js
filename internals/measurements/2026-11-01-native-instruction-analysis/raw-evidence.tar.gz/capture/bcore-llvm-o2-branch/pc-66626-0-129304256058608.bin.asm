
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-66626-0-129304256058608.bin:     file format binary


Disassembly of section .data:

00007599fe4014f0 <.data>:
    7599fe4014f0:	50                   	push   rax
    7599fe4014f1:	ba b1 fb fe ff       	mov    edx,0xfffefbb1
    7599fe4014f6:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe4014fd:	01 d6                	add    esi,edx
    7599fe4014ff:	b1 01                	mov    cl,0x1
    7599fe401501:	b8 65 01 00 00       	mov    eax,0x165
    7599fe401506:	83 fe f2             	cmp    esi,0xfffffff2
    7599fe401509:	0f 87 c5 00 00 00    	ja     0x7599fe4015d4
    7599fe40150f:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe401516:	83 fa f2             	cmp    edx,0xfffffff2
    7599fe401519:	0f 87 b5 00 00 00    	ja     0x7599fe4015d4
    7599fe40151f:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    7599fe401526:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7599fe40152d:	41 c7 45 24 9c 11 01 	mov    DWORD PTR [r13+0x24],0x1119c
    7599fe401534:	00 
    7599fe401535:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7599fe401539:	8d 34 8d 9c 11 01 00 	lea    esi,[rcx*4+0x1119c]
    7599fe401540:	41 89 75 28          	mov    DWORD PTR [r13+0x28],esi
    7599fe401544:	89 f1                	mov    ecx,esi
    7599fe401546:	c1 e9 0c             	shr    ecx,0xc
    7599fe401549:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7599fe40154d:	48 85 c0             	test   rax,rax
    7599fe401550:	0f 84 e2 0e 00 18    	je     0x759a16402438
    7599fe401556:	81 e6 fc 0f 00 00    	and    esi,0xffc
    7599fe40155c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe40155f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7599fe401563:	b1 01                	mov    cl,0x1
    7599fe401565:	bd 05 00 00 00       	mov    ebp,0x5
    7599fe40156a:	a8 01                	test   al,0x1
    7599fe40156c:	0f 85 17 0f 00 18    	jne    0x759a16402489
    7599fe401572:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7599fe401579:	01 ea                	add    edx,ebp
    7599fe40157b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7599fe401582:	39 f2                	cmp    edx,esi
    7599fe401584:	73 30                	jae    0x7599fe4015b6
    7599fe401586:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7599fe40158d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7599fe401593:	39 04 33             	cmp    DWORD PTR [rbx+rsi*1],eax
    7599fe401596:	75 1e                	jne    0x7599fe4015b6
    7599fe401598:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe40159f:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7599fe4015a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe4015ad:	00 
    7599fe4015ae:	48 8b 44 33 08       	mov    rax,QWORD PTR [rbx+rsi*1+0x8]
    7599fe4015b3:	59                   	pop    rcx
    7599fe4015b4:	ff e0                	jmp    rax
    7599fe4015b6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe4015bd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7599fe4015c4:	02 00 00 00 
    7599fe4015c8:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe4015cf:	b8 28 01 00 00       	mov    eax,0x128
    7599fe4015d4:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe4015d9:	58                   	pop    rax
    7599fe4015da:	c2 08 00             	ret    0x8
