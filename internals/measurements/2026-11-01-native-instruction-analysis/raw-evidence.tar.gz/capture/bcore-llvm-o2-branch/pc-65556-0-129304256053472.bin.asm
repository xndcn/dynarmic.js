
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65556-0-129304256053472.bin:     file format binary


Disassembly of section .data:

00007599fe4000e0 <.data>:
    7599fe4000e0:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    7599fe4000e7:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    7599fe4000ec:	ba c1 ff fe ff       	mov    edx,0xfffeffc1
    7599fe4000f1:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe4000f8:	01 d6                	add    esi,edx
    7599fe4000fa:	b1 01                	mov    cl,0x1
    7599fe4000fc:	b8 65 01 00 00       	mov    eax,0x165
    7599fe400101:	83 fe d4             	cmp    esi,0xffffffd4
    7599fe400104:	0f 87 c6 04 00 00    	ja     0x7599fe4005d0
    7599fe40010a:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe400111:	83 fa d4             	cmp    edx,0xffffffd4
    7599fe400114:	0f 87 b6 04 00 00    	ja     0x7599fe4005d0
    7599fe40011a:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7599fe400121:	45 8b 45 38          	mov    r8d,DWORD PTR [r13+0x38]
    7599fe400125:	45 8d 48 fc          	lea    r9d,[r8-0x4]
    7599fe400129:	41 f6 c0 03          	test   r8b,0x3
    7599fe40012d:	0f 85 d9 fe ff 17    	jne    0x759a1640000c
    7599fe400133:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    7599fe40013a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7599fe400141:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7599fe400145:	45 89 ca             	mov    r10d,r9d
    7599fe400148:	41 c1 ea 0c          	shr    r10d,0xc
    7599fe40014c:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    7599fe400150:	48 85 c0             	test   rax,rax
    7599fe400153:	0f 84 10 ff ff 17    	je     0x759a16400069
    7599fe400159:	44 89 c9             	mov    ecx,r9d
    7599fe40015c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400162:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400165:	45 8d 58 f8          	lea    r11d,[r8-0x8]
    7599fe400169:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7599fe40016d:	44 89 d8             	mov    eax,r11d
    7599fe400170:	c1 e8 0c             	shr    eax,0xc
    7599fe400173:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    7599fe40017a:	00 
    7599fe40017b:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe40017f:	48 85 c0             	test   rax,rax
    7599fe400182:	0f 84 42 ff ff 17    	je     0x759a164000ca
    7599fe400188:	44 89 d9             	mov    ecx,r11d
    7599fe40018b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400191:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400194:	41 8d 70 f4          	lea    esi,[r8-0xc]
    7599fe400198:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7599fe40019c:	89 f0                	mov    eax,esi
    7599fe40019e:	c1 e8 0c             	shr    eax,0xc
    7599fe4001a1:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    7599fe4001a8:	00 
    7599fe4001a9:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4001ad:	48 85 c0             	test   rax,rax
    7599fe4001b0:	48 89 74 24 38       	mov    QWORD PTR [rsp+0x38],rsi
    7599fe4001b5:	0f 84 7a ff ff 17    	je     0x759a16400135
    7599fe4001bb:	48 89 f1             	mov    rcx,rsi
    7599fe4001be:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4001c4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4001c7:	41 8d 70 f0          	lea    esi,[r8-0x10]
    7599fe4001cb:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7599fe4001cf:	89 f0                	mov    eax,esi
    7599fe4001d1:	c1 e8 0c             	shr    eax,0xc
    7599fe4001d4:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    7599fe4001db:	00 
    7599fe4001dc:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4001e0:	48 85 c0             	test   rax,rax
    7599fe4001e3:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
    7599fe4001e8:	0f 84 af ff ff 17    	je     0x759a1640019d
    7599fe4001ee:	48 89 f1             	mov    rcx,rsi
    7599fe4001f1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4001f7:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4001fa:	41 8d 70 ec          	lea    esi,[r8-0x14]
    7599fe4001fe:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    7599fe400202:	89 f0                	mov    eax,esi
    7599fe400204:	c1 e8 0c             	shr    eax,0xc
    7599fe400207:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    7599fe40020c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe400210:	48 85 c0             	test   rax,rax
    7599fe400213:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    7599fe400218:	0f 84 e7 ff ff 17    	je     0x759a16400205
    7599fe40021e:	48 89 f1             	mov    rcx,rsi
    7599fe400221:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400227:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe40022a:	41 8d 70 e8          	lea    esi,[r8-0x18]
    7599fe40022e:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    7599fe400232:	89 f0                	mov    eax,esi
    7599fe400234:	c1 e8 0c             	shr    eax,0xc
    7599fe400237:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    7599fe40023c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe400240:	48 85 c0             	test   rax,rax
    7599fe400243:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    7599fe400248:	0f 84 1f 00 00 18    	je     0x759a1640026d
    7599fe40024e:	48 89 f1             	mov    rcx,rsi
    7599fe400251:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400257:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe40025a:	41 8d 70 e4          	lea    esi,[r8-0x1c]
    7599fe40025e:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7599fe400262:	89 f0                	mov    eax,esi
    7599fe400264:	c1 e8 0c             	shr    eax,0xc
    7599fe400267:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    7599fe40026c:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe400270:	48 85 c0             	test   rax,rax
    7599fe400273:	48 89 74 24 68       	mov    QWORD PTR [rsp+0x68],rsi
    7599fe400278:	0f 84 57 00 00 18    	je     0x759a164002d5
    7599fe40027e:	89 f1                	mov    ecx,esi
    7599fe400280:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400286:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400289:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe40028d:	49 89 de             	mov    r14,rbx
    7599fe400290:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7599fe400293:	0f 85 a6 00 00 18    	jne    0x759a1640033f
    7599fe400299:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7599fe40029e:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7599fe4002a2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7599fe4002a6:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe4002ad:	41 8d 70 e0          	lea    esi,[r8-0x20]
    7599fe4002b1:	89 f1                	mov    ecx,esi
    7599fe4002b3:	c1 e9 0c             	shr    ecx,0xc
    7599fe4002b6:	49 8b 04 cc          	mov    rax,QWORD PTR [r12+rcx*8]
    7599fe4002ba:	48 85 c0             	test   rax,rax
    7599fe4002bd:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    7599fe4002c2:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    7599fe4002c7:	0f 84 e4 00 00 18    	je     0x759a164003b1
    7599fe4002cd:	48 89 f1             	mov    rcx,rsi
    7599fe4002d0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4002d6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4002d9:	41 8d 68 dc          	lea    ebp,[r8-0x24]
    7599fe4002dd:	41 89 ef             	mov    r15d,ebp
    7599fe4002e0:	41 c1 ef 0c          	shr    r15d,0xc
    7599fe4002e4:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    7599fe4002e8:	48 85 c0             	test   rax,rax
    7599fe4002eb:	0f 84 31 01 00 18    	je     0x759a16400422
    7599fe4002f1:	89 e9                	mov    ecx,ebp
    7599fe4002f3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4002f9:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    7599fe4002fc:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe400300:	41 8d 40 c8          	lea    eax,[r8-0x38]
    7599fe400304:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7599fe400308:	4c 89 f3             	mov    rbx,r14
    7599fe40030b:	41 80 3e 00          	cmp    BYTE PTR [r14],0x0
    7599fe40030f:	0f 85 83 01 00 18    	jne    0x759a16400498
    7599fe400315:	41 c7 45 28 00 f0 00 	mov    DWORD PTR [r13+0x28],0xf000
    7599fe40031c:	00 
    7599fe40031d:	66 41 c7 45 06 42 43 	mov    WORD PTR [r13+0x6],0x4342
    7599fe400324:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe400329:	48 85 c0             	test   rax,rax
    7599fe40032c:	0f 84 ee 01 00 18    	je     0x759a16400520
    7599fe400332:	8b 00                	mov    eax,DWORD PTR [rax]
    7599fe400334:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7599fe400338:	41 c7 45 04 31 4e 42 	mov    DWORD PTR [r13+0x4],0x43424e31
    7599fe40033f:	43 
    7599fe400340:	8d 88 cf b1 bd bc    	lea    ecx,[rax-0x43424e31]
    7599fe400346:	89 ca                	mov    edx,ecx
    7599fe400348:	09 c2                	or     edx,eax
    7599fe40034a:	c1 ea 1f             	shr    edx,0x1f
    7599fe40034d:	31 f6                	xor    esi,esi
    7599fe40034f:	3d 31 4e 42 43       	cmp    eax,0x43424e31
    7599fe400354:	40 0f 93 c6          	setae  sil
    7599fe400358:	31 c0                	xor    eax,eax
    7599fe40035a:	85 c9                	test   ecx,ecx
    7599fe40035c:	0f 94 c0             	sete   al
    7599fe40035f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    7599fe400366:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7599fe40036d:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7599fe400374:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7599fe40037b:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7599fe400382:	0f 84 e6 01 00 00    	je     0x7599fe40056e
    7599fe400388:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    7599fe40038f:	00 
    7599fe400390:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    7599fe400397:	00 
    7599fe400398:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe40039d:	48 85 c0             	test   rax,rax
    7599fe4003a0:	0f 84 14 02 00 18    	je     0x759a164005ba
    7599fe4003a6:	c7 40 10 03 00 00 00 	mov    DWORD PTR [rax+0x10],0x3
    7599fe4003ad:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7599fe4003b0:	0f 85 83 02 00 18    	jne    0x759a16400639
    7599fe4003b6:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    7599fe4003bd:	00 
    7599fe4003be:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    7599fe4003c2:	48 85 c0             	test   rax,rax
    7599fe4003c5:	0f 84 ef 02 00 18    	je     0x759a164006ba
    7599fe4003cb:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7599fe4003d1:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7599fe4003d4:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    7599fe4003d9:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
    7599fe4003de:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    7599fe4003e3:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4003e7:	48 85 c0             	test   rax,rax
    7599fe4003ea:	0f 84 3f 03 00 18    	je     0x759a1640072f
    7599fe4003f0:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    7599fe4003f5:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe4003fb:	8b 1c 10             	mov    ebx,DWORD PTR [rax+rdx*1]
    7599fe4003fe:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe400402:	41 89 9d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ebx
    7599fe400409:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    7599fe40040e:	41 89 55 38          	mov    DWORD PTR [r13+0x38],edx
    7599fe400412:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    7599fe400417:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe40041b:	48 85 c0             	test   rax,rax
    7599fe40041e:	0f 84 8e 03 00 18    	je     0x759a164007b2
    7599fe400424:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe40042a:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe40042d:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7599fe400431:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    7599fe400436:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe40043a:	48 85 c0             	test   rax,rax
    7599fe40043d:	0f 84 f3 03 00 18    	je     0x759a16400836
    7599fe400443:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    7599fe400448:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe40044e:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe400451:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7599fe400455:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    7599fe40045a:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe40045e:	48 85 c0             	test   rax,rax
    7599fe400461:	0f 84 55 04 00 18    	je     0x759a164008bc
    7599fe400467:	48 8b 54 24 60       	mov    rdx,QWORD PTR [rsp+0x60]
    7599fe40046c:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe400472:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe400475:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7599fe400479:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    7599fe400480:	00 
    7599fe400481:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe400485:	48 85 c0             	test   rax,rax
    7599fe400488:	0f 84 b4 04 00 18    	je     0x759a16400942
    7599fe40048e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400494:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7599fe400497:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7599fe40049b:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    7599fe4004a2:	00 
    7599fe4004a3:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4004a7:	48 85 c0             	test   rax,rax
    7599fe4004aa:	0f 84 10 05 00 18    	je     0x759a164009c0
    7599fe4004b0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4004b6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4004b9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7599fe4004bd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7599fe4004c4:	00 
    7599fe4004c5:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    7599fe4004c9:	48 85 c0             	test   rax,rax
    7599fe4004cc:	0f 84 65 05 00 18    	je     0x759a16400a37
    7599fe4004d2:	41 81 e3 ff 0f 00 00 	and    r11d,0xfff
    7599fe4004d9:	42 8b 04 18          	mov    eax,DWORD PTR [rax+r11*1]
    7599fe4004dd:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7599fe4004e1:	4b 8b 04 d4          	mov    rax,QWORD PTR [r12+r10*8]
    7599fe4004e5:	48 85 c0             	test   rax,rax
    7599fe4004e8:	0f 84 b9 05 00 18    	je     0x759a16400aa7
    7599fe4004ee:	41 81 e1 ff 0f 00 00 	and    r9d,0xfff
    7599fe4004f5:	42 8b 04 08          	mov    eax,DWORD PTR [rax+r9*1]
    7599fe4004f9:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7599fe4004fd:	45 89 45 38          	mov    DWORD PTR [r13+0x38],r8d
    7599fe400501:	b1 01                	mov    cl,0x1
    7599fe400503:	41 bc 02 00 00 00    	mov    r12d,0x2
    7599fe400509:	bd 10 00 00 00       	mov    ebp,0x10
    7599fe40050e:	f6 c3 01             	test   bl,0x1
    7599fe400511:	0f 85 ec 05 00 18    	jne    0x759a16400b03
    7599fe400517:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe40051e:	01 e8                	add    eax,ebp
    7599fe400520:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe400527:	39 d0                	cmp    eax,edx
    7599fe400529:	0f 83 d1 fa ff 17    	jae    0x759a16400000
    7599fe40052f:	8d 14 dd 00 00 00 00 	lea    edx,[rbx*8+0x0]
    7599fe400536:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    7599fe40053c:	39 1c 17             	cmp    DWORD PTR [rdi+rdx*1],ebx
    7599fe40053f:	0f 85 bb fa ff 17    	jne    0x759a16400000
    7599fe400545:	41 89 9d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],ebx
    7599fe40054c:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400553:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe40055a:	00 
    7599fe40055b:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    7599fe400560:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    7599fe400565:	48 81 c4 98 00 00 00 	add    rsp,0x98
    7599fe40056c:	ff e0                	jmp    rax
    7599fe40056e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    7599fe400575:	40 00 01 00 
    7599fe400579:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400580:	83 c0 09             	add    eax,0x9
    7599fe400583:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe40058a:	39 c8                	cmp    eax,ecx
    7599fe40058c:	0f 83 0b 00 00 18    	jae    0x759a1640059d
    7599fe400592:	81 bf 00 02 08 00 40 	cmp    DWORD PTR [rdi+0x80200],0x10040
    7599fe400599:	00 01 00 
    7599fe40059c:	0f 85 fb ff ff 17    	jne    0x759a1640059d
    7599fe4005a2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    7599fe4005a9:	40 00 01 00 
    7599fe4005ad:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe4005b4:	48 8b 87 08 02 08 00 	mov    rax,QWORD PTR [rdi+0x80208]
    7599fe4005bb:	eb a3                	jmp    0x7599fe400560
    7599fe4005bd:	45 89 a5 24 01 00 00 	mov    DWORD PTR [r13+0x124],r12d
    7599fe4005c4:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe4005cb:	b8 28 01 00 00       	mov    eax,0x128
    7599fe4005d0:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe4005d5:	48 81 c4 98 00 00 00 	add    rsp,0x98
    7599fe4005dc:	c2 08 00             	ret    0x8
