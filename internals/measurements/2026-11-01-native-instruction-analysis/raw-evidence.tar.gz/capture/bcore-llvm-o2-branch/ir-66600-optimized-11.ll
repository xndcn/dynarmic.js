; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010428(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %2, align 8
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = add i32 %guard_lb, -66625
  %5 = icmp ult i32 %4, -25
  %6 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb64 = load i32, ptr %6, align 4
  %7 = add i32 %guard_lb64, -66625
  %8 = icmp ult i32 %7, -25
  %9 = and i1 %5, %8
  br i1 %9, label %insn_0x00010428, label %common.ret, !prof !0

insn_0x00010428:                                  ; preds = %entry
  %10 = getelementptr i8, ptr %cpu, i64 40
  %old = load i32, ptr %10, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  store i32 %with_hi, ptr %10, align 4
  %11 = getelementptr i8, ptr %cpu, i64 56
  %sp = load i32, ptr %11, align 4
  %12 = getelementptr i8, ptr %cpu, i64 168
  %rets = load i32, ptr %12, align 4
  %13 = getelementptr i8, ptr %cpu, i64 60
  %fp = load i32, ptr %13, align 4
  %sp1 = add i32 %sp, -4
  %14 = and i32 %sp, 3
  %.not = icmp eq i32 %14, 0
  br i1 %.not, label %data_aligned, label %data_misaligned, !prof !0

data_misaligned:                                  ; preds = %insn_0x00010428
  %15 = getelementptr i8, ptr %cpu, i64 188
  store i32 66604, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %17, align 4
  tail call void @cec_data_alignment(ptr nonnull %cpu, ptr %mem, i32 66604, i32 %sp1, i32 65536)
  %next_pc = load i32, ptr %15, align 4
  %18 = getelementptr i8, ptr %cpu, i64 296
  %19 = load i8, ptr %18, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010428
  %20 = lshr i32 %sp1, 12
  %page_index = zext i32 %20 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_wr_slow, label %page_wr_fast, !prof !1

page_wr_fast:                                     ; preds = %data_aligned
  %21 = and i32 %sp1, 4095
  %page_offset = zext i32 %21 to i64
  %22 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %22, align 4
  br label %data_aligned2

page_wr_slow:                                     ; preds = %data_aligned
  %23 = getelementptr i8, ptr %cpu, i64 188
  store i32 66604, ptr %23, align 4
  %24 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %25, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %26 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %26, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %data_aligned2, label %did_jump_exit, !prof !0

did_jump_exit:                                    ; preds = %page_wr_slow
  %next_pc65 = load i32, ptr %23, align 4
  br label %chain_exit

data_aligned2:                                    ; preds = %page_wr_fast, %page_wr_slow
  %sp2 = add i32 %sp, -8
  %27 = lshr i32 %sp2, 12
  %page_index6 = zext i32 %27 to i64
  %page_slot7 = getelementptr ptr, ptr %page_table, i64 %page_index6
  %page8 = load ptr, ptr %page_slot7, align 8
  %page_mapped9.not = icmp eq ptr %page8, null
  br i1 %page_mapped9.not, label %page_wr_slow4, label %page_wr_fast3, !prof !1

page_wr_fast3:                                    ; preds = %data_aligned2
  %28 = and i32 %sp2, 4095
  %page_offset10 = zext i32 %28 to i64
  %29 = getelementptr i8, ptr %page8, i64 %page_offset10
  store i32 %fp, ptr %29, align 4
  br label %page_wr_done5

page_wr_slow4:                                    ; preds = %data_aligned2
  %30 = getelementptr i8, ptr %cpu, i64 188
  store i32 66604, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %32, align 4
  tail call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %33 = getelementptr i8, ptr %cpu, i64 296
  %dj13 = load i8, ptr %33, align 1
  %dj_set14.not = icmp eq i8 %dj13, 0
  br i1 %dj_set14.not, label %page_wr_done5, label %did_jump_exit11, !prof !0

page_wr_done5:                                    ; preds = %page_wr_slow4, %page_wr_fast3
  store i32 %sp2, ptr %13, align 4
  store i32 %sp2, ptr %11, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %.not90 = icmp eq i8 %cec_pending, 0
  br i1 %.not90, label %insn_0x00010430, label %cec_check, !prof !0

did_jump_exit11:                                  ; preds = %page_wr_slow4
  %next_pc67 = load i32, ptr %30, align 4
  br label %chain_exit

cec_check:                                        ; preds = %page_wr_done5
  %34 = getelementptr i8, ptr %cpu, i64 188
  store i32 66608, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %36, align 4
  tail call void @cec_check_pending(ptr nonnull %cpu)
  %37 = getelementptr i8, ptr %cpu, i64 296
  %dj17 = load i8, ptr %37, align 1
  %dj_set18.not = icmp eq i8 %dj17, 0
  br i1 %dj_set18.not, label %insn_0x00010430, label %did_jump_exit15, !prof !0

did_jump_exit15:                                  ; preds = %cec_check
  %next_pc68 = load i32, ptr %34, align 4
  br label %chain_exit

insn_0x00010430:                                  ; preds = %page_wr_done5, %cec_check
  store i32 70384, ptr %10, align 4
  %page_slot22 = getelementptr ptr, ptr %page_table, i64 17
  %page23 = load ptr, ptr %page_slot22, align 8
  %page_mapped24.not = icmp eq ptr %page23, null
  br i1 %page_mapped24.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x00010430
  %38 = getelementptr i8, ptr %page23, i64 752
  %page_val = load i32, ptr %38, align 4
  br label %page_done

page_slow:                                        ; preds = %insn_0x00010430
  %39 = getelementptr i8, ptr %cpu, i64 188
  store i32 66612, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %41, align 4
  %42 = tail call i32 @mem_read32(ptr %mem, i32 70384)
  %43 = getelementptr i8, ptr %cpu, i64 296
  %dj28 = load i8, ptr %43, align 1
  %dj_set29.not = icmp eq i8 %dj28, 0
  br i1 %dj_set29.not, label %page_done, label %did_jump_exit26, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %42, %page_slow ]
  store i32 %mem_val, ptr %10, align 4
  %44 = icmp ult i32 %mem_val, 5
  %cc = zext i1 %44 to i32
  %45 = getelementptr i8, ptr %cpu, i64 276
  store i32 %cc, ptr %45, align 4
  br i1 %44, label %brt_taken, label %insn_0x0001043a

did_jump_exit26:                                  ; preds = %page_slow
  %next_pc70 = load i32, ptr %39, align 4
  br label %chain_exit

brt_taken:                                        ; preds = %page_done
  %46 = getelementptr i8, ptr %cpu, i64 188
  store i32 66626, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %47, align 4
  %chain_total = add nuw i32 %chain_packets, 6
  %48 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %48 monotonic, align 4, !range !2
  %49 = icmp ult i32 %chain_total, %chain_budget
  br i1 %49, label %chain_go, label %chain_leave71, !prof !0

insn_0x0001043a:                                  ; preds = %page_done
  store i32 0, ptr %cpu, align 4
  %page37 = load ptr, ptr %page_slot7, align 8
  %page_mapped38.not = icmp eq ptr %page37, null
  br i1 %page_mapped38.not, label %page_slow33, label %page_fast32, !prof !1

page_fast32:                                      ; preds = %insn_0x0001043a
  %50 = and i32 %sp2, 4095
  %page_offset39 = zext i32 %50 to i64
  %51 = getelementptr i8, ptr %page37, i64 %page_offset39
  %page_val40 = load i32, ptr %51, align 4
  br label %data_aligned48

page_slow33:                                      ; preds = %insn_0x0001043a
  %52 = getelementptr i8, ptr %cpu, i64 188
  store i32 66620, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %54, align 4
  %55 = tail call i32 @mem_read32(ptr %mem, i32 %sp2)
  %56 = getelementptr i8, ptr %cpu, i64 296
  %dj43 = load i8, ptr %56, align 1
  %dj_set44.not = icmp eq i8 %dj43, 0
  br i1 %dj_set44.not, label %data_aligned48, label %did_jump_exit41, !prof !0

did_jump_exit41:                                  ; preds = %page_slow33
  %next_pc73 = load i32, ptr %52, align 4
  br label %chain_exit

data_aligned48:                                   ; preds = %page_fast32, %page_slow33
  %mem_val45 = phi i32 [ %page_val40, %page_fast32 ], [ %55, %page_slow33 ]
  %page54 = load ptr, ptr %page_slot, align 8
  %page_mapped55.not = icmp eq ptr %page54, null
  br i1 %page_mapped55.not, label %page_slow50, label %page_fast49, !prof !1

page_fast49:                                      ; preds = %data_aligned48
  %57 = and i32 %sp1, 4095
  %page_offset56 = zext i32 %57 to i64
  %58 = getelementptr i8, ptr %page54, i64 %page_offset56
  %page_val57 = load i32, ptr %58, align 4
  br label %page_done51

page_slow50:                                      ; preds = %data_aligned48
  %59 = getelementptr i8, ptr %cpu, i64 188
  store i32 66620, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %61, align 4
  %62 = tail call i32 @mem_read32(ptr %mem, i32 %sp1)
  %63 = getelementptr i8, ptr %cpu, i64 296
  %dj60 = load i8, ptr %63, align 1
  %dj_set61.not = icmp eq i8 %dj60, 0
  br i1 %dj_set61.not, label %page_done51, label %did_jump_exit58, !prof !0

page_done51:                                      ; preds = %page_slow50, %page_fast49
  %mem_val62 = phi i32 [ %page_val57, %page_fast49 ], [ %62, %page_slow50 ]
  store i32 %mem_val45, ptr %13, align 4
  store i32 %mem_val62, ptr %12, align 4
  store i32 %sp, ptr %11, align 4
  %lsb = and i32 %mem_val62, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit58:                                  ; preds = %page_slow50
  %next_pc75 = load i32, ptr %59, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done51
  %64 = getelementptr i8, ptr %cpu, i64 188
  store i32 66624, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %66, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc76 = load i32, ptr %64, align 4
  %67 = getelementptr i8, ptr %cpu, i64 296
  %68 = load i8, ptr %67, align 1
  br label %chain_exit

common.ret.sink.split:                            ; preds = %chain_leave71, %chain_leave81
  %tail78.sink = phi i32 [ %tail78, %chain_leave81 ], [ 2, %chain_leave71 ]
  %packets.sink = phi i32 [ %packets, %chain_leave81 ], [ 6, %chain_leave71 ]
  %tail80.sink.ph = phi i8 [ %tail80, %chain_leave81 ], [ 1, %chain_leave71 ]
  %69 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail78.sink, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets.sink, ptr %70, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink91 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %tail80.sink = phi i8 [ 1, %entry ], [ %tail80.sink.ph, %common.ret.sink.split ]
  %71 = getelementptr i8, ptr %cpu, i64 %.sink91
  store i8 %tail80.sink, ptr %71, align 1
  ret void

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 533008
  %slot_pc = load i32, ptr %chain_slot, align 4
  %72 = icmp eq i32 %slot_pc, 66626
  br i1 %72, label %chain_hit, label %chain_leave71, !prof !0

chain_leave71:                                    ; preds = %chain_go, %brt_taken
  store i32 66626, ptr %46, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 66626, ptr %46, align 4
  store i32 %chain_total, ptr %47, align 4
  %73 = getelementptr i8, ptr %chain_table, i64 533016
  %chain_fn = load ptr, ptr %73, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %page_done51, %jump_misalign, %did_jump_exit58, %did_jump_exit41, %did_jump_exit26, %did_jump_exit15, %did_jump_exit11, %did_jump_exit, %data_misaligned
  %packets = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit11 ], [ 2, %did_jump_exit15 ], [ 4, %did_jump_exit26 ], [ 8, %did_jump_exit41 ], [ 8, %did_jump_exit58 ], [ 9, %jump_misalign ], [ 9, %page_done51 ]
  %tail = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc65, %did_jump_exit ], [ %next_pc67, %did_jump_exit11 ], [ %next_pc68, %did_jump_exit15 ], [ %next_pc70, %did_jump_exit26 ], [ %next_pc73, %did_jump_exit41 ], [ %next_pc75, %did_jump_exit58 ], [ %next_pc76, %jump_misalign ], [ %mem_val62, %page_done51 ]
  %tail78 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %did_jump_exit11 ], [ 4, %did_jump_exit15 ], [ 2, %did_jump_exit26 ], [ 4, %did_jump_exit41 ], [ 4, %did_jump_exit58 ], [ 2, %jump_misalign ], [ 2, %page_done51 ]
  %tail80 = phi i8 [ %19, %data_misaligned ], [ %dj, %did_jump_exit ], [ %dj13, %did_jump_exit11 ], [ %dj17, %did_jump_exit15 ], [ %dj28, %did_jump_exit26 ], [ %dj43, %did_jump_exit41 ], [ %dj60, %did_jump_exit58 ], [ %68, %jump_misalign ], [ 1, %page_done51 ]
  %74 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets82 = load i32, ptr %74, align 4
  %chain_total83 = add nuw i32 %chain_packets82, %packets
  %75 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget84 = load atomic i32, ptr %75 monotonic, align 4, !range !2
  %76 = icmp ult i32 %chain_total83, %chain_budget84
  br i1 %76, label %chain_lookup, label %chain_leave81, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %77 = shl i32 %tail, 3
  %78 = and i32 %77, 1048560
  %79 = zext i32 %78 to i64
  %chain_slot85 = getelementptr i8, ptr %chain_table, i64 %79
  %slot_pc86 = load i32, ptr %chain_slot85, align 4
  %80 = icmp eq i32 %slot_pc86, %tail
  br i1 %80, label %chain_hit87, label %chain_leave81, !prof !0

chain_leave81:                                    ; preds = %chain_lookup, %chain_exit
  %81 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %81, align 4
  br label %common.ret.sink.split

chain_hit87:                                      ; preds = %chain_lookup
  %82 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %82, align 4
  store i32 %chain_total83, ptr %74, align 4
  %83 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %83, align 1
  %84 = getelementptr i8, ptr %chain_slot85, i64 8
  %chain_fn88 = load ptr, ptr %84, align 8
  musttail call swifttailcc void %chain_fn88(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

declare void @mem_write32(ptr, i32, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) local_unnamed_addr #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
