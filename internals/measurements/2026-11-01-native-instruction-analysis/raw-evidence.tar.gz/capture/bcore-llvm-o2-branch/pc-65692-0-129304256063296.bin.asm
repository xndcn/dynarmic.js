
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65692-0-129304256063296.bin:     file format binary


Disassembly of section .data:

00007599fe402740 <.data>:
    7599fe402740:	48 83 ec 18          	sub    rsp,0x18
    7599fe402744:	ba 41 ff fe ff       	mov    edx,0xfffeff41
    7599fe402749:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe402750:	01 d6                	add    esi,edx
    7599fe402752:	b1 01                	mov    cl,0x1
    7599fe402754:	b8 65 01 00 00       	mov    eax,0x165
    7599fe402759:	83 fe dc             	cmp    esi,0xffffffdc
    7599fe40275c:	0f 87 c9 03 00 00    	ja     0x7599fe402b2b
    7599fe402762:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe402769:	83 fa dc             	cmp    edx,0xffffffdc
    7599fe40276c:	0f 87 b9 03 00 00    	ja     0x7599fe402b2b
    7599fe402772:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7599fe402779:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    7599fe40277d:	f6 c1 03             	test   cl,0x3
    7599fe402780:	0f 85 de 0e 00 18    	jne    0x759a16403664
    7599fe402786:	4d 8b 85 38 01 00 00 	mov    r8,QWORD PTR [r13+0x138]
    7599fe40278d:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7599fe402794:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7599fe402798:	48 89 c8             	mov    rax,rcx
    7599fe40279b:	48 c1 e8 0c          	shr    rax,0xc
    7599fe40279f:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe4027a3:	48 85 c0             	test   rax,rax
    7599fe4027a6:	0f 84 0f 0f 00 18    	je     0x759a164036bb
    7599fe4027ac:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4027b2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4027b5:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7599fe4027b9:	0f 85 41 0f 00 18    	jne    0x759a16403700
    7599fe4027bf:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    7599fe4027c3:	f6 c3 03             	test   bl,0x3
    7599fe4027c6:	0f 85 8c 0f 00 18    	jne    0x759a16403758
    7599fe4027cc:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7599fe4027d0:	48 89 d8             	mov    rax,rbx
    7599fe4027d3:	48 c1 e8 0c          	shr    rax,0xc
    7599fe4027d7:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe4027db:	48 85 c0             	test   rax,rax
    7599fe4027de:	0f 84 d8 0f 00 18    	je     0x759a164037bc
    7599fe4027e4:	89 d9                	mov    ecx,ebx
    7599fe4027e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4027ec:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4027ef:	83 c3 04             	add    ebx,0x4
    7599fe4027f2:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    7599fe4027f6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7599fe4027fa:	0f 85 0c 10 00 18    	jne    0x759a1640380c
    7599fe402800:	41 8b 6d 1c          	mov    ebp,DWORD PTR [r13+0x1c]
    7599fe402804:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    7599fe402808:	31 c0                	xor    eax,eax
    7599fe40280a:	89 eb                	mov    ebx,ebp
    7599fe40280c:	ff c3                	inc    ebx
    7599fe40280e:	0f 94 c0             	sete   al
    7599fe402811:	41 89 5d 1c          	mov    DWORD PTR [r13+0x1c],ebx
    7599fe402815:	89 ea                	mov    edx,ebp
    7599fe402817:	c1 ea 1f             	shr    edx,0x1f
    7599fe40281a:	41 89 dc             	mov    r12d,ebx
    7599fe40281d:	41 c1 ec 1f          	shr    r12d,0x1f
    7599fe402821:	c4 c2 68 f2 d4       	andn   edx,edx,r12d
    7599fe402826:	31 f6                	xor    esi,esi
    7599fe402828:	85 db                	test   ebx,ebx
    7599fe40282a:	40 0f 94 c6          	sete   sil
    7599fe40282e:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7599fe402835:	45 89 a5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r12d
    7599fe40283c:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7599fe402843:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7599fe40284a:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7599fe402851:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    7599fe402858:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    7599fe40285f:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    7599fe402866:	00 
    7599fe402867:	f6 c1 03             	test   cl,0x3
    7599fe40286a:	0f 85 f4 0f 00 18    	jne    0x759a16403864
    7599fe402870:	48 89 c8             	mov    rax,rcx
    7599fe402873:	48 c1 e8 0c          	shr    rax,0xc
    7599fe402877:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe40287b:	48 85 c0             	test   rax,rax
    7599fe40287e:	0f 84 42 10 00 18    	je     0x759a164038c6
    7599fe402884:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe40288a:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    7599fe40288d:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7599fe402891:	0f 85 8f 10 00 18    	jne    0x759a16403926
    7599fe402897:	83 c5 fb             	add    ebp,0xfffffffb
    7599fe40289a:	89 e8                	mov    eax,ebp
    7599fe40289c:	c1 e8 1f             	shr    eax,0x1f
    7599fe40289f:	44 09 e0             	or     eax,r12d
    7599fe4028a2:	31 c9                	xor    ecx,ecx
    7599fe4028a4:	83 fb 06             	cmp    ebx,0x6
    7599fe4028a7:	0f 93 c1             	setae  cl
    7599fe4028aa:	31 d2                	xor    edx,edx
    7599fe4028ac:	85 ed                	test   ebp,ebp
    7599fe4028ae:	0f 94 c2             	sete   dl
    7599fe4028b1:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7599fe4028b8:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7599fe4028bf:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7599fe4028c6:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    7599fe4028cd:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    7599fe4028d4:	74 53                	je     0x7599fe402929
    7599fe4028d6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7599fe4028dd:	84 00 01 00 
    7599fe4028e1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe4028e8:	83 c0 07             	add    eax,0x7
    7599fe4028eb:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe4028f2:	39 c8                	cmp    eax,ecx
    7599fe4028f4:	0f 83 4e 0d 00 18    	jae    0x759a16403648
    7599fe4028fa:	81 bf 20 04 08 00 84 	cmp    DWORD PTR [rdi+0x80420],0x10084
    7599fe402901:	00 01 00 
    7599fe402904:	0f 85 3e 0d 00 18    	jne    0x759a16403648
    7599fe40290a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    7599fe402911:	84 00 01 00 
    7599fe402915:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe40291c:	48 8b 87 28 04 08 00 	mov    rax,QWORD PTR [rdi+0x80428]
    7599fe402923:	48 83 c4 18          	add    rsp,0x18
    7599fe402927:	ff e0                	jmp    rax
    7599fe402929:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    7599fe402930:	00 
    7599fe402931:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    7599fe402938:	00 
    7599fe402939:	49 8b 40 78          	mov    rax,QWORD PTR [r8+0x78]
    7599fe40293d:	48 85 c0             	test   rax,rax
    7599fe402940:	0f 84 52 10 00 18    	je     0x759a16403998
    7599fe402946:	c7 40 10 02 00 00 00 	mov    DWORD PTR [rax+0x10],0x2
    7599fe40294d:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7599fe402951:	0f 85 a5 10 00 18    	jne    0x759a164039fc
    7599fe402957:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    7599fe40295b:	40 f6 c5 03          	test   bpl,0x3
    7599fe40295f:	0f 85 f9 10 00 18    	jne    0x759a16403a5e
    7599fe402965:	48 89 e8             	mov    rax,rbp
    7599fe402968:	48 c1 e8 0c          	shr    rax,0xc
    7599fe40296c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402970:	48 85 c0             	test   rax,rax
    7599fe402973:	0f 84 46 11 00 18    	je     0x759a16403abf
    7599fe402979:	89 e9                	mov    ecx,ebp
    7599fe40297b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe402981:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    7599fe402984:	8d 75 04             	lea    esi,[rbp+0x4]
    7599fe402987:	89 f0                	mov    eax,esi
    7599fe402989:	c1 e8 0c             	shr    eax,0xc
    7599fe40298c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402990:	48 85 c0             	test   rax,rax
    7599fe402993:	0f 84 85 11 00 18    	je     0x759a16403b1e
    7599fe402999:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe40299f:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    7599fe4029a3:	8d 75 08             	lea    esi,[rbp+0x8]
    7599fe4029a6:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7599fe4029aa:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    7599fe4029b1:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe4029b5:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7599fe4029bc:	00 
    7599fe4029bd:	89 f0                	mov    eax,esi
    7599fe4029bf:	c1 e8 0c             	shr    eax,0xc
    7599fe4029c2:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe4029c6:	48 85 c0             	test   rax,rax
    7599fe4029c9:	0f 84 b1 11 00 18    	je     0x759a16403b80
    7599fe4029cf:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4029d5:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4029d8:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7599fe4029dc:	8d 75 0c             	lea    esi,[rbp+0xc]
    7599fe4029df:	89 f0                	mov    eax,esi
    7599fe4029e1:	c1 e8 0c             	shr    eax,0xc
    7599fe4029e4:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe4029e8:	48 85 c0             	test   rax,rax
    7599fe4029eb:	0f 84 ea 11 00 18    	je     0x759a16403bdb
    7599fe4029f1:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe4029f7:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe4029fa:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7599fe4029fe:	8d 75 10             	lea    esi,[rbp+0x10]
    7599fe402a01:	89 f0                	mov    eax,esi
    7599fe402a03:	c1 e8 0c             	shr    eax,0xc
    7599fe402a06:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402a0a:	48 85 c0             	test   rax,rax
    7599fe402a0d:	0f 84 23 12 00 18    	je     0x759a16403c36
    7599fe402a13:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402a19:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402a1c:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7599fe402a20:	8d 75 14             	lea    esi,[rbp+0x14]
    7599fe402a23:	89 f0                	mov    eax,esi
    7599fe402a25:	c1 e8 0c             	shr    eax,0xc
    7599fe402a28:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402a2c:	48 85 c0             	test   rax,rax
    7599fe402a2f:	0f 84 5c 12 00 18    	je     0x759a16403c91
    7599fe402a35:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402a3b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402a3e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7599fe402a42:	8d 75 18             	lea    esi,[rbp+0x18]
    7599fe402a45:	89 f0                	mov    eax,esi
    7599fe402a47:	c1 e8 0c             	shr    eax,0xc
    7599fe402a4a:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402a4e:	48 85 c0             	test   rax,rax
    7599fe402a51:	0f 84 95 12 00 18    	je     0x759a16403cec
    7599fe402a57:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402a5d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402a60:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7599fe402a64:	8d 75 1c             	lea    esi,[rbp+0x1c]
    7599fe402a67:	89 f0                	mov    eax,esi
    7599fe402a69:	c1 e8 0c             	shr    eax,0xc
    7599fe402a6c:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402a70:	48 85 c0             	test   rax,rax
    7599fe402a73:	0f 84 ce 12 00 18    	je     0x759a16403d47
    7599fe402a79:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402a7f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402a82:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    7599fe402a86:	89 ee                	mov    esi,ebp
    7599fe402a88:	83 c6 20             	add    esi,0x20
    7599fe402a8b:	89 f0                	mov    eax,esi
    7599fe402a8d:	c1 e8 0c             	shr    eax,0xc
    7599fe402a90:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    7599fe402a94:	48 85 c0             	test   rax,rax
    7599fe402a97:	0f 84 05 13 00 18    	je     0x759a16403da2
    7599fe402a9d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe402aa3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe402aa6:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    7599fe402aaa:	8d 45 24             	lea    eax,[rbp+0x24]
    7599fe402aad:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    7599fe402ab1:	b1 01                	mov    cl,0x1
    7599fe402ab3:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe402ab8:	bd 0f 00 00 00       	mov    ebp,0xf
    7599fe402abd:	41 f6 c7 01          	test   r15b,0x1
    7599fe402ac1:	0f 85 2c 13 00 18    	jne    0x759a16403df3
    7599fe402ac7:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe402ace:	01 e8                	add    eax,ebp
    7599fe402ad0:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe402ad7:	39 d0                	cmp    eax,edx
    7599fe402ad9:	0f 83 ad 0e 00 18    	jae    0x759a1640398c
    7599fe402adf:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    7599fe402ae6:	00 
    7599fe402ae7:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    7599fe402aed:	44 39 3c 17          	cmp    DWORD PTR [rdi+rdx*1],r15d
    7599fe402af1:	0f 85 95 0e 00 18    	jne    0x759a1640398c
    7599fe402af7:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    7599fe402afe:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe402b05:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe402b0c:	00 
    7599fe402b0d:	48 8b 44 17 08       	mov    rax,QWORD PTR [rdi+rdx*1+0x8]
    7599fe402b12:	48 83 c4 18          	add    rsp,0x18
    7599fe402b16:	ff e0                	jmp    rax
    7599fe402b18:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe402b1f:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe402b26:	b8 28 01 00 00       	mov    eax,0x128
    7599fe402b2b:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe402b30:	48 83 c4 18          	add    rsp,0x18
    7599fe402b34:	c2 08 00             	ret    0x8
