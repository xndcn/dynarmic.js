
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65808-0-129304658718507.bin:     file format binary


Disassembly of section .data:

0000759a16402f2b <.data>:
    759a16402f2b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    759a16402f32:	20 01 01 00 
    759a16402f36:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402f3d:	04 00 00 00 
    759a16402f41:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16402f48:	06 00 00 00 
    759a16402f4c:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16402f53:	64 00 00 
    759a16402f56:	48 89 fd             	mov    rbp,rdi
    759a16402f59:	4c 89 ef             	mov    rdi,r13
    759a16402f5c:	4c 89 c6             	mov    rsi,r8
    759a16402f5f:	ba 20 01 01 00       	mov    edx,0x10120
    759a16402f64:	89 d9                	mov    ecx,ebx
    759a16402f66:	4d 89 c6             	mov    r14,r8
    759a16402f69:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16402f6f:	ff d0                	call   rax
    759a16402f71:	48 89 ef             	mov    rdi,rbp
    759a16402f74:	4d 89 f0             	mov    r8,r14
    759a16402f77:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402f7e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402f85:	00 
    759a16402f86:	bb 04 00 00 00       	mov    ebx,0x4
    759a16402f8b:	bd 06 00 00 00       	mov    ebp,0x6
    759a16402f90:	e9 e6 f3 ff e7       	jmp    0x7599fe40237b
    759a16402f95:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    759a16402f9c:	20 01 01 00 
    759a16402fa0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402fa7:	04 00 00 00 
    759a16402fab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16402fb2:	06 00 00 00 
    759a16402fb6:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16402fbd:	64 00 00 
    759a16402fc0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402fc5:	4c 89 c7             	mov    rdi,r8
    759a16402fc8:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    759a16402fcd:	89 de                	mov    esi,ebx
    759a16402fcf:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    759a16402fd3:	4c 89 cd             	mov    rbp,r9
    759a16402fd6:	4d 89 d7             	mov    r15,r10
    759a16402fd9:	44 89 5c 24 10       	mov    DWORD PTR [rsp+0x10],r11d
    759a16402fde:	ff d0                	call   rax
    759a16402fe0:	44 8b 5c 24 10       	mov    r11d,DWORD PTR [rsp+0x10]
    759a16402fe5:	4d 89 fa             	mov    r10,r15
    759a16402fe8:	49 89 e9             	mov    r9,rbp
    759a16402feb:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    759a16402ff0:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402ff5:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a16402ff9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403000:	00 
    759a16403001:	84 c9                	test   cl,cl
    759a16403003:	0f 84 d6 f2 ff e7    	je     0x7599fe4022df
    759a16403009:	e9 e3 00 00 00       	jmp    0x759a164030f1
    759a1640300e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    759a16403015:	20 01 01 00 
    759a16403019:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403020:	04 00 00 00 
    759a16403024:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a1640302b:	06 00 00 00 
    759a1640302f:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16403036:	64 00 00 
    759a16403039:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640303e:	4c 89 c7             	mov    rdi,r8
    759a16403041:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    759a16403046:	89 ee                	mov    esi,ebp
    759a16403048:	44 89 da             	mov    edx,r11d
    759a1640304b:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    759a1640304f:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a16403054:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    759a16403059:	ff d0                	call   rax
    759a1640305b:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    759a16403060:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16403065:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    759a1640306a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640306f:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a16403073:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640307a:	00 
    759a1640307b:	84 c9                	test   cl,cl
    759a1640307d:	0f 84 7f f2 ff e7    	je     0x7599fe402302
    759a16403083:	eb 6c                	jmp    0x759a164030f1
    759a16403085:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    759a1640308c:	24 01 01 00 
    759a16403090:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403097:	04 00 00 00 
    759a1640309b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a164030a2:	06 00 00 00 
    759a164030a6:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a164030ad:	64 00 00 
    759a164030b0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164030b5:	4c 89 ef             	mov    rdi,r13
    759a164030b8:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    759a164030bc:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    759a164030c1:	48 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],rbx
    759a164030c6:	4c 89 cb             	mov    rbx,r9
    759a164030c9:	ff d0                	call   rax
    759a164030cb:	49 89 d9             	mov    r9,rbx
    759a164030ce:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    759a164030d3:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    759a164030d8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164030dd:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a164030e1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164030e8:	00 
    759a164030e9:	84 c9                	test   cl,cl
    759a164030eb:	0f 84 23 f2 ff e7    	je     0x7599fe402314
    759a164030f1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a164030f8:	e9 89 fe ff ff       	jmp    0x759a16402f86
    759a164030fd:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a16403102:	49 89 f7             	mov    r15,rsi
    759a16403105:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a1640310a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    759a16403111:	24 01 01 00 
    759a16403115:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a1640311c:	04 00 00 00 
    759a16403120:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    759a16403127:	07 00 00 00 
    759a1640312b:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403132:	64 00 00 
    759a16403135:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    759a16403139:	4c 89 c7             	mov    rdi,r8
    759a1640313c:	89 ee                	mov    esi,ebp
    759a1640313e:	ff d0                	call   rax
    759a16403140:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403147:	00 
    759a16403148:	84 c9                	test   cl,cl
    759a1640314a:	0f 85 cb 00 00 00    	jne    0x759a1640321b
    759a16403150:	89 c5                	mov    ebp,eax
    759a16403152:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a16403156:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640315b:	4c 89 fe             	mov    rsi,r15
    759a1640315e:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16403163:	e9 c2 f1 ff e7       	jmp    0x7599fe40232a
    759a16403168:	49 89 f7             	mov    r15,rsi
    759a1640316b:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403170:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    759a16403177:	24 01 01 00 
    759a1640317b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403182:	04 00 00 00 
    759a16403186:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    759a1640318d:	07 00 00 00 
    759a16403191:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403198:	64 00 00 
    759a1640319b:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    759a1640319f:	4c 89 c7             	mov    rdi,r8
    759a164031a2:	89 de                	mov    esi,ebx
    759a164031a4:	ff d0                	call   rax
    759a164031a6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164031ad:	00 
    759a164031ae:	84 c9                	test   cl,cl
    759a164031b0:	75 69                	jne    0x759a1640321b
    759a164031b2:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a164031b6:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164031bb:	4c 89 fe             	mov    rsi,r15
    759a164031be:	e9 7d f1 ff e7       	jmp    0x7599fe402340
    759a164031c3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012e
    759a164031ca:	2e 01 01 00 
    759a164031ce:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164031d5:	02 00 00 00 
    759a164031d9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    759a164031e0:	0b 00 00 00 
    759a164031e4:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a164031eb:	64 00 00 
    759a164031ee:	49 89 ff             	mov    r15,rdi
    759a164031f1:	4c 89 ef             	mov    rdi,r13
    759a164031f4:	be 2a 00 00 00       	mov    esi,0x2a
    759a164031f9:	4c 89 c2             	mov    rdx,r8
    759a164031fc:	4d 89 c6             	mov    r14,r8
    759a164031ff:	ff d0                	call   rax
    759a16403201:	4c 89 ff             	mov    rdi,r15
    759a16403204:	4d 89 f0             	mov    r8,r14
    759a16403207:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a1640320e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403215:	00 
    759a16403216:	e9 60 f1 ff e7       	jmp    0x7599fe40237b
    759a1640321b:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16403222:	bb 04 00 00 00       	mov    ebx,0x4
    759a16403227:	bd 07 00 00 00       	mov    ebp,0x7
    759a1640322c:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    759a16403230:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403235:	e9 41 f1 ff e7       	jmp    0x7599fe40237b
