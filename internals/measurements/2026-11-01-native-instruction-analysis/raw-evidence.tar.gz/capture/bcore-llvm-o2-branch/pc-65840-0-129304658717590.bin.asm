
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65840-0-129304658717590.bin:     file format binary


Disassembly of section .data:

0000759a16402b96 <.data>:
    759a16402b96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    759a16402b9d:	3c 01 01 00 
    759a16402ba1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402ba8:	04 00 00 00 
    759a16402bac:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16402bb3:	05 00 00 00 
    759a16402bb7:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16402bbe:	64 00 00 
    759a16402bc1:	4c 89 ef             	mov    rdi,r13
    759a16402bc4:	4c 89 de             	mov    rsi,r11
    759a16402bc7:	ba 3c 01 01 00       	mov    edx,0x1013c
    759a16402bcc:	89 d9                	mov    ecx,ebx
    759a16402bce:	4d 89 de             	mov    r14,r11
    759a16402bd1:	4c 89 c3             	mov    rbx,r8
    759a16402bd4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16402bda:	ff d0                	call   rax
    759a16402bdc:	49 89 d8             	mov    r8,rbx
    759a16402bdf:	4d 89 f3             	mov    r11,r14
    759a16402be2:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402be9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402bf0:	00 
    759a16402bf1:	bb 04 00 00 00       	mov    ebx,0x4
    759a16402bf6:	bd 05 00 00 00       	mov    ebp,0x5
    759a16402bfb:	e9 e6 f2 ff e7       	jmp    0x7599fe401ee6
    759a16402c00:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    759a16402c07:	3c 01 01 00 
    759a16402c0b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402c12:	04 00 00 00 
    759a16402c16:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16402c1d:	05 00 00 00 
    759a16402c21:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16402c28:	64 00 00 
    759a16402c2b:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    759a16402c2f:	4c 89 df             	mov    rdi,r11
    759a16402c32:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    759a16402c37:	89 de                	mov    esi,ebx
    759a16402c39:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16402c3e:	4c 89 c5             	mov    rbp,r8
    759a16402c41:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a16402c46:	4d 89 d4             	mov    r12,r10
    759a16402c49:	ff d0                	call   rax
    759a16402c4b:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    759a16402c4f:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a16402c54:	4d 89 e2             	mov    r10,r12
    759a16402c57:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16402c5c:	49 89 e8             	mov    r8,rbp
    759a16402c5f:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16402c64:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402c6b:	00 
    759a16402c6c:	84 c9                	test   cl,cl
    759a16402c6e:	0f 84 87 f1 ff e7    	je     0x7599fe401dfb
    759a16402c74:	e9 e0 00 00 00       	jmp    0x759a16402d59
    759a16402c79:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    759a16402c80:	3c 01 01 00 
    759a16402c84:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402c8b:	04 00 00 00 
    759a16402c8f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16402c96:	05 00 00 00 
    759a16402c9a:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a16402ca1:	64 00 00 
    759a16402ca4:	89 fa                	mov    edx,edi
    759a16402ca6:	4c 89 df             	mov    rdi,r11
    759a16402ca9:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    759a16402cae:	89 ee                	mov    esi,ebp
    759a16402cb0:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16402cb5:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16402cba:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a16402cbf:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    759a16402cc4:	ff d0                	call   rax
    759a16402cc6:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a16402ccb:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    759a16402cd0:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16402cd5:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16402cda:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16402cdf:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402ce6:	00 
    759a16402ce7:	84 c9                	test   cl,cl
    759a16402ce9:	0f 84 2f f1 ff e7    	je     0x7599fe401e1e
    759a16402cef:	eb 68                	jmp    0x759a16402d59
    759a16402cf1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10140
    759a16402cf8:	40 01 01 00 
    759a16402cfc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402d03:	04 00 00 00 
    759a16402d07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16402d0e:	05 00 00 00 
    759a16402d12:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16402d19:	64 00 00 
    759a16402d1c:	4c 89 ef             	mov    rdi,r13
    759a16402d1f:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    759a16402d24:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16402d29:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a16402d2e:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    759a16402d33:	ff d0                	call   rax
    759a16402d35:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    759a16402d3a:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16402d3f:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16402d44:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    759a16402d49:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402d50:	00 
    759a16402d51:	84 c9                	test   cl,cl
    759a16402d53:	0f 84 d6 f0 ff e7    	je     0x7599fe401e2f
    759a16402d59:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402d60:	e9 8c fe ff ff       	jmp    0x759a16402bf1
    759a16402d65:	49 89 de             	mov    r14,rbx
    759a16402d68:	4d 89 d4             	mov    r12,r10
    759a16402d6b:	4c 89 cb             	mov    rbx,r9
    759a16402d6e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16402d73:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    759a16402d7a:	46 01 01 00 
    759a16402d7e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402d85:	04 00 00 00 
    759a16402d89:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    759a16402d90:	08 00 00 00 
    759a16402d94:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16402d9b:	64 00 00 
    759a16402d9e:	4d 89 df             	mov    r15,r11
    759a16402da1:	4c 89 df             	mov    rdi,r11
    759a16402da4:	89 ee                	mov    esi,ebp
    759a16402da6:	ff d0                	call   rax
    759a16402da8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402daf:	00 
    759a16402db0:	84 c9                	test   cl,cl
    759a16402db2:	0f 85 c9 00 00 00    	jne    0x759a16402e81
    759a16402db8:	89 c5                	mov    ebp,eax
    759a16402dba:	4d 89 fb             	mov    r11,r15
    759a16402dbd:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16402dc2:	49 89 d9             	mov    r9,rbx
    759a16402dc5:	4d 89 e2             	mov    r10,r12
    759a16402dc8:	4c 89 f3             	mov    rbx,r14
    759a16402dcb:	e9 d8 f0 ff e7       	jmp    0x7599fe401ea8
    759a16402dd0:	4d 89 cc             	mov    r12,r9
    759a16402dd3:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16402dd8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    759a16402ddf:	46 01 01 00 
    759a16402de3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402dea:	04 00 00 00 
    759a16402dee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    759a16402df5:	08 00 00 00 
    759a16402df9:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16402e00:	64 00 00 
    759a16402e03:	4d 89 df             	mov    r15,r11
    759a16402e06:	4c 89 df             	mov    rdi,r11
    759a16402e09:	89 de                	mov    esi,ebx
    759a16402e0b:	ff d0                	call   rax
    759a16402e0d:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402e14:	00 
    759a16402e15:	84 c9                	test   cl,cl
    759a16402e17:	75 68                	jne    0x759a16402e81
    759a16402e19:	4d 89 fb             	mov    r11,r15
    759a16402e1c:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16402e21:	4d 89 e1             	mov    r9,r12
    759a16402e24:	e9 9a f0 ff e7       	jmp    0x7599fe401ec3
    759a16402e29:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014a
    759a16402e30:	4a 01 01 00 
    759a16402e34:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402e3b:	02 00 00 00 
    759a16402e3f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    759a16402e46:	09 00 00 00 
    759a16402e4a:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a16402e51:	64 00 00 
    759a16402e54:	4c 89 ef             	mov    rdi,r13
    759a16402e57:	be 2a 00 00 00       	mov    esi,0x2a
    759a16402e5c:	4c 89 da             	mov    rdx,r11
    759a16402e5f:	4d 89 de             	mov    r14,r11
    759a16402e62:	4d 89 c7             	mov    r15,r8
    759a16402e65:	ff d0                	call   rax
    759a16402e67:	4d 89 f8             	mov    r8,r15
    759a16402e6a:	4d 89 f3             	mov    r11,r14
    759a16402e6d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402e74:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402e7b:	00 
    759a16402e7c:	e9 65 f0 ff e7       	jmp    0x7599fe401ee6
    759a16402e81:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402e88:	bb 04 00 00 00       	mov    ebx,0x4
    759a16402e8d:	bd 08 00 00 00       	mov    ebp,0x8
    759a16402e92:	4d 89 fb             	mov    r11,r15
    759a16402e95:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16402e9a:	e9 47 f0 ff e7       	jmp    0x7599fe401ee6
