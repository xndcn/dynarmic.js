
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65536-0-129304256053280.bin:     file format binary


Disassembly of section .data:

00007599fe400020 <.data>:
    7599fe400020:	b9 fd ff fe ff       	mov    ecx,0xfffefffd
    7599fe400025:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7599fe40002c:	01 ca                	add    edx,ecx
    7599fe40002e:	b8 65 01 00 00       	mov    eax,0x165
    7599fe400033:	83 fa fc             	cmp    edx,0xfffffffc
    7599fe400036:	0f 87 94 00 00 00    	ja     0x7599fe4000d0
    7599fe40003c:	41 03 8d a4 00 00 00 	add    ecx,DWORD PTR [r13+0xa4]
    7599fe400043:	83 f9 fc             	cmp    ecx,0xfffffffc
    7599fe400046:	0f 87 84 00 00 00    	ja     0x7599fe4000d0
    7599fe40004c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7599fe400053:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    7599fe400058:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x10006
    7599fe40005f:	06 00 01 00 
    7599fe400063:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7599fe40006a:	14 00 01 00 
    7599fe40006e:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe400075:	83 c1 02             	add    ecx,0x2
    7599fe400078:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe40007f:	39 d1                	cmp    ecx,edx
    7599fe400081:	73 27                	jae    0x7599fe4000aa
    7599fe400083:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    7599fe40008a:	00 01 00 
    7599fe40008d:	75 1b                	jne    0x7599fe4000aa
    7599fe40008f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7599fe400096:	14 00 01 00 
    7599fe40009a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe4000a1:	48 8b 80 a8 00 08 00 	mov    rax,QWORD PTR [rax+0x800a8]
    7599fe4000a8:	ff e0                	jmp    rax
    7599fe4000aa:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7599fe4000b1:	14 00 01 00 
    7599fe4000b5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7599fe4000bc:	04 00 00 00 
    7599fe4000c0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7599fe4000c7:	02 00 00 00 
    7599fe4000cb:	b8 28 01 00 00       	mov    eax,0x128
    7599fe4000d0:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    7599fe4000d6:	c2 08 00             	ret    0x8
