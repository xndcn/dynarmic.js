
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65600-0-129304256054928.bin:     file format binary


Disassembly of section .data:

00007599fe400690 <.data>:
    7599fe400690:	48 83 ec 28          	sub    rsp,0x28
    7599fe400694:	b8 71 ff fe ff       	mov    eax,0xfffeff71
    7599fe400699:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7599fe4006a0:	01 c1                	add    ecx,eax
    7599fe4006a2:	83 f9 b0             	cmp    ecx,0xffffffb0
    7599fe4006a5:	0f 87 a4 05 00 18    	ja     0x759a16400c4f
    7599fe4006ab:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7599fe4006b2:	83 f8 b0             	cmp    eax,0xffffffb0
    7599fe4006b5:	0f 87 94 05 00 18    	ja     0x759a16400c4f
    7599fe4006bb:	4d 89 f1             	mov    r9,r14
    7599fe4006be:	49 8b b5 50 01 00 00 	mov    rsi,QWORD PTR [r13+0x150]
    7599fe4006c5:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    7599fe4006cc:	4d 8b 85 40 01 00 00 	mov    r8,QWORD PTR [r13+0x140]
    7599fe4006d3:	41 c7 45 28 04 f0 00 	mov    DWORD PTR [r13+0x28],0xf004
    7599fe4006da:	00 
    7599fe4006db:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe4006e0:	48 85 c0             	test   rax,rax
    7599fe4006e3:	0f 84 75 05 00 18    	je     0x759a16400c5e
    7599fe4006e9:	8b 78 04             	mov    edi,DWORD PTR [rax+0x4]
    7599fe4006ec:	41 89 7d 10          	mov    DWORD PTR [r13+0x10],edi
    7599fe4006f0:	41 c7 45 28 08 f0 00 	mov    DWORD PTR [r13+0x28],0xf008
    7599fe4006f7:	00 
    7599fe4006f8:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe4006fd:	48 85 c0             	test   rax,rax
    7599fe400700:	0f 84 bc 05 00 18    	je     0x759a16400cc2
    7599fe400706:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    7599fe400709:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7599fe40070d:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    7599fe400714:	00 
    7599fe400715:	41 c7 45 2c 14 f0 00 	mov    DWORD PTR [r13+0x2c],0xf014
    7599fe40071c:	00 
    7599fe40071d:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    7599fe400721:	44 8d 75 fc          	lea    r14d,[rbp-0x4]
    7599fe400725:	40 f6 c5 03          	test   bpl,0x3
    7599fe400729:	0f 85 f9 05 00 18    	jne    0x759a16400d28
    7599fe40072f:	44 89 f3             	mov    ebx,r14d
    7599fe400732:	c1 eb 0c             	shr    ebx,0xc
    7599fe400735:	49 8b 0c dc          	mov    rcx,QWORD PTR [r12+rbx*8]
    7599fe400739:	48 85 c9             	test   rcx,rcx
    7599fe40073c:	0f 84 9a 06 00 18    	je     0x759a16400ddc
    7599fe400742:	44 89 f2             	mov    edx,r14d
    7599fe400745:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe40074b:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    7599fe40074e:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe400752:	0f 85 ee 06 00 18    	jne    0x759a16400e46
    7599fe400758:	41 c7 45 28 0c f0 00 	mov    DWORD PTR [r13+0x28],0xf00c
    7599fe40075f:	00 
    7599fe400760:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe400765:	48 85 c0             	test   rax,rax
    7599fe400768:	0f 84 3d 07 00 18    	je     0x759a16400eab
    7599fe40076e:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    7599fe400771:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7599fe400775:	66 41 c7 45 32 00 01 	mov    WORD PTR [r13+0x32],0x100
    7599fe40077c:	41 c7 45 34 18 f0 00 	mov    DWORD PTR [r13+0x34],0xf018
    7599fe400783:	00 
    7599fe400784:	83 c5 f8             	add    ebp,0xfffffff8
    7599fe400787:	41 89 ef             	mov    r15d,ebp
    7599fe40078a:	41 c1 ef 0c          	shr    r15d,0xc
    7599fe40078e:	4b 8b 0c fc          	mov    rcx,QWORD PTR [r12+r15*8]
    7599fe400792:	48 85 c9             	test   rcx,rcx
    7599fe400795:	0f 84 7c 07 00 18    	je     0x759a16400f17
    7599fe40079b:	89 ea                	mov    edx,ebp
    7599fe40079d:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe4007a3:	89 04 11             	mov    DWORD PTR [rcx+rdx*1],eax
    7599fe4007a6:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe4007aa:	0f 85 d1 07 00 18    	jne    0x759a16400f81
    7599fe4007b0:	41 c7 45 28 10 f0 00 	mov    DWORD PTR [r13+0x28],0xf010
    7599fe4007b7:	00 
    7599fe4007b8:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe4007bd:	48 85 c0             	test   rax,rax
    7599fe4007c0:	0f 84 2e 08 00 18    	je     0x759a16400ff4
    7599fe4007c6:	c7 40 10 01 00 00 00 	mov    DWORD PTR [rax+0x10],0x1
    7599fe4007cd:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe4007d1:	0f 85 8d 08 00 18    	jne    0x759a16401064
    7599fe4007d7:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7599fe4007de:	00 
    7599fe4007df:	49 8b 44 24 78       	mov    rax,QWORD PTR [r12+0x78]
    7599fe4007e4:	48 85 c0             	test   rax,rax
    7599fe4007e7:	0f 84 ea 08 00 18    	je     0x759a164010d7
    7599fe4007ed:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    7599fe4007f4:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe4007f8:	0f 85 46 09 00 18    	jne    0x759a16401144
    7599fe4007fe:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    7599fe400805:	00 
    7599fe400806:	41 c7 45 30 00 00 00 	mov    DWORD PTR [r13+0x30],0x1000000
    7599fe40080d:	01 
    7599fe40080e:	49 c7 45 14 01 00 00 	mov    QWORD PTR [r13+0x14],0x1
    7599fe400815:	00 
    7599fe400816:	49 8b 04 dc          	mov    rax,QWORD PTR [r12+rbx*8]
    7599fe40081a:	48 85 c0             	test   rax,rax
    7599fe40081d:	0f 84 8a 09 00 18    	je     0x759a164011ad
    7599fe400823:	41 81 e6 ff 0f 00 00 	and    r14d,0xfff
    7599fe40082a:	42 8b 04 30          	mov    eax,DWORD PTR [rax+r14*1]
    7599fe40082e:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    7599fe400832:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7599fe400836:	4b 8b 04 fc          	mov    rax,QWORD PTR [r12+r15*8]
    7599fe40083a:	48 85 c0             	test   rax,rax
    7599fe40083d:	0f 84 cc 09 00 18    	je     0x759a1640120f
    7599fe400843:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7599fe400849:	8b 04 28             	mov    eax,DWORD PTR [rax+rbp*1]
    7599fe40084c:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    7599fe400850:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x10092
    7599fe400857:	92 00 01 00 
    7599fe40085b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe400862:	28 03 01 00 
    7599fe400866:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe40086d:	83 c0 1c             	add    eax,0x1c
    7599fe400870:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400877:	39 c8                	cmp    eax,ecx
    7599fe400879:	73 2e                	jae    0x7599fe4008a9
    7599fe40087b:	81 be 40 19 08 00 28 	cmp    DWORD PTR [rsi+0x81940],0x10328
    7599fe400882:	03 01 00 
    7599fe400885:	75 22                	jne    0x7599fe4008a9
    7599fe400887:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe40088e:	28 03 01 00 
    7599fe400892:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400899:	48 8b 86 48 19 08 00 	mov    rax,QWORD PTR [rsi+0x81948]
    7599fe4008a0:	4d 89 ce             	mov    r14,r9
    7599fe4008a3:	48 83 c4 28          	add    rsp,0x28
    7599fe4008a7:	ff e0                	jmp    rax
    7599fe4008a9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7599fe4008b0:	28 03 01 00 
    7599fe4008b4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7599fe4008bb:	04 00 00 00 
    7599fe4008bf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    7599fe4008c6:	1c 00 00 00 
    7599fe4008ca:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7599fe4008d1:	01 
    7599fe4008d2:	48 83 c4 28          	add    rsp,0x28
    7599fe4008d6:	c2 08 00             	ret    0x8
