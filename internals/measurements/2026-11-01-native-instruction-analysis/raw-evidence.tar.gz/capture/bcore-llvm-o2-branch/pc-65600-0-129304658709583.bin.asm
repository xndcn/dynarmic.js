
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65600-0-129304658709583.bin:     file format binary


Disassembly of section .data:

0000759a16400c4f <.data>:
    759a16400c4f:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    759a16400c56:	01 
    759a16400c57:	48 83 c4 28          	add    rsp,0x28
    759a16400c5b:	c2 08 00             	ret    0x8
    759a16400c5e:	4c 89 c3             	mov    rbx,r8
    759a16400c61:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400c66:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10046
    759a16400c6d:	46 00 01 00 
    759a16400c71:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400c78:	02 00 00 00 
    759a16400c7c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    759a16400c83:	03 00 00 00 
    759a16400c87:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400c8e:	64 00 00 
    759a16400c91:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400c96:	4c 89 cf             	mov    rdi,r9
    759a16400c99:	be 04 f0 00 00       	mov    esi,0xf004
    759a16400c9e:	ff d0                	call   rax
    759a16400ca0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400ca7:	00 
    759a16400ca8:	0f 85 cb 05 00 00    	jne    0x759a16401279
    759a16400cae:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400cb3:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400cb8:	89 c7                	mov    edi,eax
    759a16400cba:	49 89 d8             	mov    r8,rbx
    759a16400cbd:	e9 2a fa ff e7       	jmp    0x7599fe4006ec
    759a16400cc2:	4c 89 c5             	mov    rbp,r8
    759a16400cc5:	89 fb                	mov    ebx,edi
    759a16400cc7:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400ccc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1004a
    759a16400cd3:	4a 00 01 00 
    759a16400cd7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400cde:	02 00 00 00 
    759a16400ce2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16400ce9:	05 00 00 00 
    759a16400ced:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400cf4:	64 00 00 
    759a16400cf7:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400cfc:	4c 89 cf             	mov    rdi,r9
    759a16400cff:	be 08 f0 00 00       	mov    esi,0xf008
    759a16400d04:	ff d0                	call   rax
    759a16400d06:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400d0d:	00 
    759a16400d0e:	0f 85 74 05 00 00    	jne    0x759a16401288
    759a16400d14:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400d19:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400d1e:	89 df                	mov    edi,ebx
    759a16400d20:	49 89 e8             	mov    r8,rbp
    759a16400d23:	e9 e1 f9 ff e7       	jmp    0x7599fe400709
    759a16400d28:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400d2d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    759a16400d34:	54 00 01 00 
    759a16400d38:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400d3f:	02 00 00 00 
    759a16400d43:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    759a16400d4a:	09 00 00 00 
    759a16400d4e:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16400d55:	64 00 00 
    759a16400d58:	4c 89 ef             	mov    rdi,r13
    759a16400d5b:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400d60:	4c 89 ce             	mov    rsi,r9
    759a16400d63:	ba 54 00 01 00       	mov    edx,0x10054
    759a16400d68:	44 89 f1             	mov    ecx,r14d
    759a16400d6b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16400d71:	ff d0                	call   rax
    759a16400d73:	b8 02 00 00 00       	mov    eax,0x2
    759a16400d78:	b9 09 00 00 00       	mov    ecx,0x9
    759a16400d7d:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    759a16400d84:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    759a16400d8b:	01 ca                	add    edx,ecx
    759a16400d8d:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    759a16400d94:	39 fa                	cmp    edx,edi
    759a16400d96:	0f 83 c8 04 00 00    	jae    0x759a16401264
    759a16400d9c:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    759a16400da3:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    759a16400da9:	48 8b 6c 24 10       	mov    rbp,QWORD PTR [rsp+0x10]
    759a16400dae:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    759a16400db2:	0f 85 ac 04 00 00    	jne    0x759a16401264
    759a16400db8:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    759a16400dbf:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    759a16400dc6:	00 
    759a16400dc7:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    759a16400dcc:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    759a16400dd1:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a16400dd6:	48 83 c4 28          	add    rsp,0x28
    759a16400dda:	ff e0                	jmp    rax
    759a16400ddc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10054
    759a16400de3:	54 00 01 00 
    759a16400de7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400dee:	02 00 00 00 
    759a16400df2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    759a16400df9:	09 00 00 00 
    759a16400dfd:	48 b9 20 56 c0 d7 e7 	movabs rcx,0x64e7d7c05620
    759a16400e04:	64 00 00 
    759a16400e07:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16400e0b:	4c 89 cf             	mov    rdi,r9
    759a16400e0e:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400e13:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400e18:	44 89 f6             	mov    esi,r14d
    759a16400e1b:	89 c2                	mov    edx,eax
    759a16400e1d:	4d 89 c7             	mov    r15,r8
    759a16400e20:	ff d1                	call   rcx
    759a16400e22:	4d 89 f8             	mov    r8,r15
    759a16400e25:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a16400e29:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400e2e:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400e33:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400e3a:	00 
    759a16400e3b:	0f 84 0d f9 ff e7    	je     0x7599fe40074e
    759a16400e41:	e9 2d ff ff ff       	jmp    0x759a16400d73
    759a16400e46:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10056
    759a16400e4d:	56 00 01 00 
    759a16400e51:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400e58:	02 00 00 00 
    759a16400e5c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    759a16400e63:	09 00 00 00 
    759a16400e67:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16400e6e:	64 00 00 
    759a16400e71:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16400e75:	4c 89 ef             	mov    rdi,r13
    759a16400e78:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400e7d:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400e82:	4d 89 c7             	mov    r15,r8
    759a16400e85:	ff d0                	call   rax
    759a16400e87:	4d 89 f8             	mov    r8,r15
    759a16400e8a:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a16400e8e:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400e93:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400e98:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400e9f:	00 
    759a16400ea0:	0f 84 b2 f8 ff e7    	je     0x7599fe400758
    759a16400ea6:	e9 c8 fe ff ff       	jmp    0x759a16400d73
    759a16400eab:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a16400eb0:	41 89 ff             	mov    r15d,edi
    759a16400eb3:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400eb8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1005c
    759a16400ebf:	5c 00 01 00 
    759a16400ec3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400eca:	02 00 00 00 
    759a16400ece:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a16400ed5:	0c 00 00 00 
    759a16400ed9:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16400ee0:	64 00 00 
    759a16400ee3:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400ee8:	4c 89 cf             	mov    rdi,r9
    759a16400eeb:	be 0c f0 00 00       	mov    esi,0xf00c
    759a16400ef0:	ff d0                	call   rax
    759a16400ef2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400ef9:	00 
    759a16400efa:	0f 85 97 03 00 00    	jne    0x759a16401297
    759a16400f00:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400f05:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400f0a:	44 89 ff             	mov    edi,r15d
    759a16400f0d:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a16400f12:	e9 5a f8 ff e7       	jmp    0x7599fe400771
    759a16400f17:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006a
    759a16400f1e:	6a 00 01 00 
    759a16400f22:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400f29:	02 00 00 00 
    759a16400f2d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    759a16400f34:	10 00 00 00 
    759a16400f38:	48 b9 20 56 c0 d7 e7 	movabs rcx,0x64e7d7c05620
    759a16400f3f:	64 00 00 
    759a16400f42:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16400f46:	4c 89 cf             	mov    rdi,r9
    759a16400f49:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400f4e:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400f53:	89 ee                	mov    esi,ebp
    759a16400f55:	89 c2                	mov    edx,eax
    759a16400f57:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a16400f5c:	ff d1                	call   rcx
    759a16400f5e:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a16400f63:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a16400f67:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400f6c:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400f71:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400f78:	00 
    759a16400f79:	0f 84 27 f8 ff e7    	je     0x7599fe4007a6
    759a16400f7f:	eb 64                	jmp    0x759a16400fe5
    759a16400f81:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1006c
    759a16400f88:	6c 00 01 00 
    759a16400f8c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16400f93:	02 00 00 00 
    759a16400f97:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    759a16400f9e:	10 00 00 00 
    759a16400fa2:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16400fa9:	64 00 00 
    759a16400fac:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16400fb0:	4c 89 ef             	mov    rdi,r13
    759a16400fb3:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16400fb8:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16400fbd:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a16400fc2:	ff d0                	call   rax
    759a16400fc4:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a16400fc9:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a16400fcd:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16400fd2:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16400fd7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16400fde:	00 
    759a16400fdf:	0f 84 cb f7 ff e7    	je     0x7599fe4007b0
    759a16400fe5:	b8 02 00 00 00       	mov    eax,0x2
    759a16400fea:	b9 10 00 00 00       	mov    ecx,0x10
    759a16400fef:	e9 89 fd ff ff       	jmp    0x759a16400d7d
    759a16400ff4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10074
    759a16400ffb:	74 00 01 00 
    759a16400fff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401006:	02 00 00 00 
    759a1640100a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    759a16401011:	13 00 00 00 
    759a16401015:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640101c:	64 00 00 
    759a1640101f:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16401023:	4c 89 cf             	mov    rdi,r9
    759a16401026:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a1640102b:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16401030:	be 10 f0 00 00       	mov    esi,0xf010
    759a16401035:	ba 01 00 00 00       	mov    edx,0x1
    759a1640103a:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a1640103f:	ff d0                	call   rax
    759a16401041:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a16401046:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a1640104a:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a1640104f:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16401054:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a1640105b:	00 
    759a1640105c:	0f 84 6b f7 ff e7    	je     0x7599fe4007cd
    759a16401062:	eb 64                	jmp    0x759a164010c8
    759a16401064:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10076
    759a1640106b:	76 00 01 00 
    759a1640106f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401076:	02 00 00 00 
    759a1640107a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x13
    759a16401081:	13 00 00 00 
    759a16401085:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640108c:	64 00 00 
    759a1640108f:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16401093:	4c 89 ef             	mov    rdi,r13
    759a16401096:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a1640109b:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a164010a0:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a164010a5:	ff d0                	call   rax
    759a164010a7:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a164010ac:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a164010b0:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a164010b5:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a164010ba:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a164010c1:	00 
    759a164010c2:	0f 84 0f f7 ff e7    	je     0x7599fe4007d7
    759a164010c8:	b8 02 00 00 00       	mov    eax,0x2
    759a164010cd:	b9 13 00 00 00       	mov    ecx,0x13
    759a164010d2:	e9 a6 fc ff ff       	jmp    0x759a16400d7d
    759a164010d7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10078
    759a164010de:	78 00 01 00 
    759a164010e2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164010e9:	02 00 00 00 
    759a164010ed:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    759a164010f4:	15 00 00 00 
    759a164010f8:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164010ff:	64 00 00 
    759a16401102:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16401106:	4c 89 cf             	mov    rdi,r9
    759a16401109:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a1640110e:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16401113:	be 14 f0 00 00       	mov    esi,0xf014
    759a16401118:	31 d2                	xor    edx,edx
    759a1640111a:	4c 89 44 24 20       	mov    QWORD PTR [rsp+0x20],r8
    759a1640111f:	ff d0                	call   rax
    759a16401121:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
    759a16401126:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a1640112a:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a1640112f:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16401134:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a1640113b:	00 
    759a1640113c:	0f 84 b2 f6 ff e7    	je     0x7599fe4007f4
    759a16401142:	eb 5a                	jmp    0x759a1640119e
    759a16401144:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1007a
    759a1640114b:	7a 00 01 00 
    759a1640114f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401156:	02 00 00 00 
    759a1640115a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    759a16401161:	15 00 00 00 
    759a16401165:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640116c:	64 00 00 
    759a1640116f:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a16401173:	4c 89 ef             	mov    rdi,r13
    759a16401176:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a1640117b:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16401180:	ff d0                	call   rax
    759a16401182:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a16401186:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a1640118b:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16401190:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16401197:	00 
    759a16401198:	0f 84 60 f6 ff e7    	je     0x7599fe4007fe
    759a1640119e:	b8 02 00 00 00       	mov    eax,0x2
    759a164011a3:	b9 15 00 00 00       	mov    ecx,0x15
    759a164011a8:	e9 d0 fb ff ff       	jmp    0x759a16400d7d
    759a164011ad:	89 7c 24 0c          	mov    DWORD PTR [rsp+0xc],edi
    759a164011b1:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a164011b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    759a164011bd:	84 00 01 00 
    759a164011c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    759a164011c8:	08 00 00 00 
    759a164011cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1a
    759a164011d3:	1a 00 00 00 
    759a164011d7:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164011de:	64 00 00 
    759a164011e1:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a164011e6:	4c 89 cf             	mov    rdi,r9
    759a164011e9:	44 89 f6             	mov    esi,r14d
    759a164011ec:	ff d0                	call   rax
    759a164011ee:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a164011f5:	00 
    759a164011f6:	0f 85 aa 00 00 00    	jne    0x759a164012a6
    759a164011fc:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a16401201:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a16401206:	8b 7c 24 0c          	mov    edi,DWORD PTR [rsp+0xc]
    759a1640120a:	e9 1f f6 ff e7       	jmp    0x7599fe40082e
    759a1640120f:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
    759a16401214:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    759a1640121b:	8c 00 01 00 
    759a1640121f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16401226:	02 00 00 00 
    759a1640122a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    759a16401231:	1b 00 00 00 
    759a16401235:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640123c:	64 00 00 
    759a1640123f:	4c 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],r9
    759a16401244:	4c 89 cf             	mov    rdi,r9
    759a16401247:	89 ee                	mov    esi,ebp
    759a16401249:	ff d0                	call   rax
    759a1640124b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16401252:	00 
    759a16401253:	75 60                	jne    0x759a164012b5
    759a16401255:	4c 8b 4c 24 18       	mov    r9,QWORD PTR [rsp+0x18]
    759a1640125a:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    759a1640125f:	e9 e8 f5 ff e7       	jmp    0x7599fe40084c
    759a16401264:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    759a1640126b:	41 89 8d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ecx
    759a16401272:	48 83 c4 28          	add    rsp,0x28
    759a16401276:	c2 08 00             	ret    0x8
    759a16401279:	b8 02 00 00 00       	mov    eax,0x2
    759a1640127e:	b9 03 00 00 00       	mov    ecx,0x3
    759a16401283:	e9 f5 fa ff ff       	jmp    0x759a16400d7d
    759a16401288:	b8 02 00 00 00       	mov    eax,0x2
    759a1640128d:	b9 05 00 00 00       	mov    ecx,0x5
    759a16401292:	e9 e6 fa ff ff       	jmp    0x759a16400d7d
    759a16401297:	b8 02 00 00 00       	mov    eax,0x2
    759a1640129c:	b9 0c 00 00 00       	mov    ecx,0xc
    759a164012a1:	e9 d7 fa ff ff       	jmp    0x759a16400d7d
    759a164012a6:	b8 08 00 00 00       	mov    eax,0x8
    759a164012ab:	b9 1a 00 00 00       	mov    ecx,0x1a
    759a164012b0:	e9 c8 fa ff ff       	jmp    0x759a16400d7d
    759a164012b5:	b8 02 00 00 00       	mov    eax,0x2
    759a164012ba:	b9 1b 00 00 00       	mov    ecx,0x1b
    759a164012bf:	e9 b9 fa ff ff       	jmp    0x759a16400d7d
