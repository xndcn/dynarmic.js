
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-66600-0-129304256058000.bin:     file format binary


Disassembly of section .data:

00007599fe401290 <.data>:
    7599fe401290:	48 83 ec 28          	sub    rsp,0x28
    7599fe401294:	ba bf fb fe ff       	mov    edx,0xfffefbbf
    7599fe401299:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe4012a0:	01 d6                	add    esi,edx
    7599fe4012a2:	b1 01                	mov    cl,0x1
    7599fe4012a4:	b8 65 01 00 00       	mov    eax,0x165
    7599fe4012a9:	83 fe e6             	cmp    esi,0xffffffe6
    7599fe4012ac:	0f 87 df 01 00 00    	ja     0x7599fe401491
    7599fe4012b2:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe4012b9:	83 fa e6             	cmp    edx,0xffffffe6
    7599fe4012bc:	0f 87 cf 01 00 00    	ja     0x7599fe401491
    7599fe4012c2:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    7599fe4012c9:	49 8b 9d 38 01 00 00 	mov    rbx,QWORD PTR [r13+0x138]
    7599fe4012d0:	4d 8b 8d 40 01 00 00 	mov    r9,QWORD PTR [r13+0x140]
    7599fe4012d7:	66 41 c7 45 2a 01 00 	mov    WORD PTR [r13+0x2a],0x1
    7599fe4012de:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    7599fe4012e2:	44 8d 46 fc          	lea    r8d,[rsi-0x4]
    7599fe4012e6:	40 f6 c6 03          	test   sil,0x3
    7599fe4012ea:	0f 85 4e 0d 00 18    	jne    0x759a1640203e
    7599fe4012f0:	45 8b 55 3c          	mov    r10d,DWORD PTR [r13+0x3c]
    7599fe4012f4:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe4012fb:	45 89 c7             	mov    r15d,r8d
    7599fe4012fe:	41 c1 ef 0c          	shr    r15d,0xc
    7599fe401302:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    7599fe401306:	48 85 c0             	test   rax,rax
    7599fe401309:	0f 84 94 0d 00 18    	je     0x759a164020a3
    7599fe40130f:	44 89 c1             	mov    ecx,r8d
    7599fe401312:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe401318:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe40131b:	8d 6e f8             	lea    ebp,[rsi-0x8]
    7599fe40131e:	41 89 ec             	mov    r12d,ebp
    7599fe401321:	41 c1 ec 0c          	shr    r12d,0xc
    7599fe401325:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    7599fe401329:	48 85 c0             	test   rax,rax
    7599fe40132c:	0f 84 e3 0d 00 18    	je     0x759a16402115
    7599fe401332:	89 e9                	mov    ecx,ebp
    7599fe401334:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe40133a:	44 89 14 08          	mov    DWORD PTR [rax+rcx*1],r10d
    7599fe40133e:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe401342:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    7599fe401346:	41 80 39 00          	cmp    BYTE PTR [r9],0x0
    7599fe40134a:	0f 85 3a 0e 00 18    	jne    0x759a1640218a
    7599fe401350:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    7599fe401357:	00 
    7599fe401358:	48 8b 83 88 00 00 00 	mov    rax,QWORD PTR [rbx+0x88]
    7599fe40135f:	48 85 c0             	test   rax,rax
    7599fe401362:	0f 84 92 0e 00 18    	je     0x759a164021fa
    7599fe401368:	8b 80 f0 02 00 00    	mov    eax,DWORD PTR [rax+0x2f0]
    7599fe40136e:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7599fe401372:	31 c9                	xor    ecx,ecx
    7599fe401374:	83 f8 05             	cmp    eax,0x5
    7599fe401377:	0f 92 c1             	setb   cl
    7599fe40137a:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    7599fe401381:	73 53                	jae    0x7599fe4013d6
    7599fe401383:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    7599fe40138a:	42 04 01 00 
    7599fe40138e:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe401395:	83 c0 06             	add    eax,0x6
    7599fe401398:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe40139f:	39 c8                	cmp    eax,ecx
    7599fe4013a1:	0f 83 c5 0e 00 18    	jae    0x759a1640226c
    7599fe4013a7:	81 bf 10 22 08 00 42 	cmp    DWORD PTR [rdi+0x82210],0x10442
    7599fe4013ae:	04 01 00 
    7599fe4013b1:	0f 85 b5 0e 00 18    	jne    0x759a1640226c
    7599fe4013b7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    7599fe4013be:	42 04 01 00 
    7599fe4013c2:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe4013c9:	48 8b 87 18 22 08 00 	mov    rax,QWORD PTR [rdi+0x82218]
    7599fe4013d0:	48 83 c4 28          	add    rsp,0x28
    7599fe4013d4:	ff e0                	jmp    rax
    7599fe4013d6:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7599fe4013dd:	00 
    7599fe4013de:	4a 8b 04 e3          	mov    rax,QWORD PTR [rbx+r12*8]
    7599fe4013e2:	48 85 c0             	test   rax,rax
    7599fe4013e5:	0f 84 9d 0e 00 18    	je     0x759a16402288
    7599fe4013eb:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    7599fe4013f1:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    7599fe4013f4:	4a 8b 04 fb          	mov    rax,QWORD PTR [rbx+r15*8]
    7599fe4013f8:	48 85 c0             	test   rax,rax
    7599fe4013fb:	0f 84 f4 0e 00 18    	je     0x759a164022f5
    7599fe401401:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
    7599fe401408:	42 8b 04 00          	mov    eax,DWORD PTR [rax+r8*1]
    7599fe40140c:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    7599fe401410:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7599fe401417:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe40141b:	b1 01                	mov    cl,0x1
    7599fe40141d:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe401422:	bd 09 00 00 00       	mov    ebp,0x9
    7599fe401427:	a8 01                	test   al,0x1
    7599fe401429:	0f 85 20 0f 00 18    	jne    0x759a1640234f
    7599fe40142f:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    7599fe401436:	01 ea                	add    edx,ebp
    7599fe401438:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7599fe40143f:	39 f2                	cmp    edx,esi
    7599fe401441:	0f 83 eb 0b 00 18    	jae    0x759a16402032
    7599fe401447:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    7599fe40144e:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7599fe401454:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    7599fe401457:	0f 85 d5 0b 00 18    	jne    0x759a16402032
    7599fe40145d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7599fe401464:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    7599fe40146b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe401472:	00 
    7599fe401473:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    7599fe401478:	48 83 c4 28          	add    rsp,0x28
    7599fe40147c:	ff e0                	jmp    rax
    7599fe40147e:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe401485:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe40148c:	b8 28 01 00 00       	mov    eax,0x128
    7599fe401491:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe401496:	48 83 c4 28          	add    rsp,0x28
    7599fe40149a:	c2 08 00             	ret    0x8
