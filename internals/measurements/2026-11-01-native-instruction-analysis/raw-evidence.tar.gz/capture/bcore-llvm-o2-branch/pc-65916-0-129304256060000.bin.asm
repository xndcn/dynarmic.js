
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65916-0-129304256060000.bin:     file format binary


Disassembly of section .data:

00007599fe401a60 <.data>:
    7599fe401a60:	b9 77 fe fe ff       	mov    ecx,0xfffefe77
    7599fe401a65:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    7599fe401a6c:	01 ca                	add    edx,ecx
    7599fe401a6e:	b8 65 01 00 00       	mov    eax,0x165
    7599fe401a73:	83 fa f2             	cmp    edx,0xfffffff2
    7599fe401a76:	0f 87 62 01 00 00    	ja     0x7599fe401bde
    7599fe401a7c:	41 03 8d a4 00 00 00 	add    ecx,DWORD PTR [r13+0xa4]
    7599fe401a83:	83 f9 f2             	cmp    ecx,0xfffffff2
    7599fe401a86:	0f 87 52 01 00 00    	ja     0x7599fe401bde
    7599fe401a8c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7599fe401a93:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7599fe401a97:	41 8b 75 34          	mov    esi,DWORD PTR [r13+0x34]
    7599fe401a9b:	41 0f af 55 1c       	imul   edx,DWORD PTR [r13+0x1c]
    7599fe401aa0:	41 89 75 04          	mov    DWORD PTR [r13+0x4],esi
    7599fe401aa4:	8d 0c 16             	lea    ecx,[rsi+rdx*1]
    7599fe401aa7:	41 89 4d 1c          	mov    DWORD PTR [r13+0x1c],ecx
    7599fe401aab:	c1 ea 1f             	shr    edx,0x1f
    7599fe401aae:	c1 ee 1f             	shr    esi,0x1f
    7599fe401ab1:	89 cf                	mov    edi,ecx
    7599fe401ab3:	c1 ef 1f             	shr    edi,0x1f
    7599fe401ab6:	31 fe                	xor    esi,edi
    7599fe401ab8:	31 fa                	xor    edx,edi
    7599fe401aba:	21 f2                	and    edx,esi
    7599fe401abc:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    7599fe401ac3:	31 f6                	xor    esi,esi
    7599fe401ac5:	85 c9                	test   ecx,ecx
    7599fe401ac7:	40 0f 94 c6          	sete   sil
    7599fe401acb:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7599fe401ad2:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7599fe401ad9:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    7599fe401ae0:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7599fe401ae7:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7599fe401aee:	48 ba 01 00 00 00 01 	movabs rdx,0x100000001
    7599fe401af5:	00 00 00 
    7599fe401af8:	49 89 95 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rdx
    7599fe401aff:	78 4f                	js     0x7599fe401b50
    7599fe401b01:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7599fe401b08:	70 01 01 00 
    7599fe401b0c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe401b13:	83 c1 05             	add    ecx,0x5
    7599fe401b16:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe401b1d:	39 d1                	cmp    ecx,edx
    7599fe401b1f:	0f 83 27 10 00 18    	jae    0x759a16402b4c
    7599fe401b25:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    7599fe401b2c:	01 01 00 
    7599fe401b2f:	0f 85 17 10 00 18    	jne    0x759a16402b4c
    7599fe401b35:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    7599fe401b3c:	70 01 01 00 
    7599fe401b40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe401b47:	48 8b 80 88 0b 08 00 	mov    rax,QWORD PTR [rax+0x80b88]
    7599fe401b4e:	ff e0                	jmp    rax
    7599fe401b50:	31 d2                	xor    edx,edx
    7599fe401b52:	41 33 4d 00          	xor    ecx,DWORD PTR [r13+0x0]
    7599fe401b56:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    7599fe401b5a:	0f 94 c2             	sete   dl
    7599fe401b5d:	c1 e9 1f             	shr    ecx,0x1f
    7599fe401b60:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7599fe401b67:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe401b6e:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7599fe401b75:	00 00 00 00 
    7599fe401b79:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe401b80:	00 00 00 00 
    7599fe401b84:	41 c7 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],0x1018c
    7599fe401b8b:	8c 01 01 00 
    7599fe401b8f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7599fe401b96:	10 01 01 00 
    7599fe401b9a:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7599fe401ba1:	83 c1 07             	add    ecx,0x7
    7599fe401ba4:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe401bab:	39 d1                	cmp    ecx,edx
    7599fe401bad:	0f 83 c6 0f 00 18    	jae    0x759a16402b79
    7599fe401bb3:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    7599fe401bba:	01 01 00 
    7599fe401bbd:	0f 85 b6 0f 00 18    	jne    0x759a16402b79
    7599fe401bc3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    7599fe401bca:	10 01 01 00 
    7599fe401bce:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7599fe401bd5:	48 8b 80 88 08 08 00 	mov    rax,QWORD PTR [rax+0x80888]
    7599fe401bdc:	ff e0                	jmp    rax
    7599fe401bde:	41 c6 44 05 00 01    	mov    BYTE PTR [r13+rax*1+0x0],0x1
    7599fe401be4:	c2 08 00             	ret    0x8
