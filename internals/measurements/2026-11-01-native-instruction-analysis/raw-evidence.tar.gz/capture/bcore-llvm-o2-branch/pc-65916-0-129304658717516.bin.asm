
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65916-0-129304658717516.bin:     file format binary


Disassembly of section .data:

0000759a16402b4c <.data>:
    759a16402b4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    759a16402b53:	70 01 01 00 
    759a16402b57:	b8 05 00 00 00       	mov    eax,0x5
    759a16402b5c:	b9 02 00 00 00       	mov    ecx,0x2
    759a16402b61:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    759a16402b68:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    759a16402b6f:	b8 28 01 00 00       	mov    eax,0x128
    759a16402b74:	e9 65 f0 ff e7       	jmp    0x7599fe401bde
    759a16402b79:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    759a16402b80:	10 01 01 00 
    759a16402b84:	b8 07 00 00 00       	mov    eax,0x7
    759a16402b89:	b9 04 00 00 00       	mov    ecx,0x4
    759a16402b8e:	eb d1                	jmp    0x759a16402b61
