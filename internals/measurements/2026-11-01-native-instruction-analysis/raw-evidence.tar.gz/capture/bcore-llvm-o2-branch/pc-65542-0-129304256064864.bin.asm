
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65542-0-129304256064864.bin:     file format binary


Disassembly of section .data:

00007599fe402d60 <.data>:
    7599fe402d60:	50                   	push   rax
    7599fe402d61:	b8 ef ff fe ff       	mov    eax,0xfffeffef
    7599fe402d66:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7599fe402d6d:	01 c1                	add    ecx,eax
    7599fe402d6f:	83 f9 f4             	cmp    ecx,0xfffffff4
    7599fe402d72:	0f 87 59 13 00 18    	ja     0x759a164040d1
    7599fe402d78:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    7599fe402d7f:	83 f8 f4             	cmp    eax,0xfffffff4
    7599fe402d82:	0f 87 49 13 00 18    	ja     0x759a164040d1
    7599fe402d88:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    7599fe402d8f:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    7599fe402d96:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7599fe402d9d:	41 c7 45 20 04 00 00 	mov    DWORD PTR [r13+0x20],0x1000004
    7599fe402da4:	01 
    7599fe402da5:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7599fe402da9:	48 8b 80 00 80 00 00 	mov    rax,QWORD PTR [rax+0x8000]
    7599fe402db0:	48 85 c0             	test   rax,rax
    7599fe402db3:	0f 84 24 13 00 18    	je     0x759a164040dd
    7599fe402db9:	89 50 04             	mov    DWORD PTR [rax+0x4],edx
    7599fe402dbc:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    7599fe402dc0:	0f 85 5c 13 00 18    	jne    0x759a16404122
    7599fe402dc6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    7599fe402dcd:	10 00 01 00 
    7599fe402dd1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe402dd8:	83 c0 04             	add    eax,0x4
    7599fe402ddb:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe402de2:	39 c8                	cmp    eax,ecx
    7599fe402de4:	73 28                	jae    0x7599fe402e0e
    7599fe402de6:	81 bb 80 00 08 00 10 	cmp    DWORD PTR [rbx+0x80080],0x10010
    7599fe402ded:	00 01 00 
    7599fe402df0:	75 1c                	jne    0x7599fe402e0e
    7599fe402df2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    7599fe402df9:	10 00 01 00 
    7599fe402dfd:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe402e04:	48 8b 83 88 00 08 00 	mov    rax,QWORD PTR [rbx+0x80088]
    7599fe402e0b:	59                   	pop    rcx
    7599fe402e0c:	ff e0                	jmp    rax
    7599fe402e0e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    7599fe402e15:	10 00 01 00 
    7599fe402e19:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7599fe402e20:	02 00 00 00 
    7599fe402e24:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7599fe402e2b:	04 00 00 00 
    7599fe402e2f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7599fe402e36:	01 
    7599fe402e37:	58                   	pop    rax
    7599fe402e38:	c2 08 00             	ret    0x8
