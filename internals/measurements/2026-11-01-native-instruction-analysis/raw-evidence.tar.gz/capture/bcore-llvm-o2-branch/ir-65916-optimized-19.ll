; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001017c(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = add i32 %guard_lb, -65929
  %3 = icmp ult i32 %2, -13
  %4 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb14 = load i32, ptr %4, align 4
  %5 = add i32 %guard_lb14, -65929
  %6 = icmp ult i32 %5, -13
  %7 = and i1 %3, %6
  br i1 %7, label %insn_0x0001017c, label %common.ret, !prof !0

insn_0x0001017c:                                  ; preds = %entry
  %8 = getelementptr i8, ptr %cpu, i64 28
  %a = load i32, ptr %8, align 4
  %9 = getelementptr i8, ptr %cpu, i64 16
  %b = load i32, ptr %9, align 4
  %mul = mul i32 %b, %a
  %10 = getelementptr i8, ptr %cpu, i64 52
  %regmv_src = load i32, ptr %10, align 4
  %11 = getelementptr i8, ptr %cpu, i64 4
  store i32 %regmv_src, ptr %11, align 4
  %add32 = add i32 %regmv_src, %mul
  store i32 %add32, ptr %8, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn = lshr i32 %add32, 31
  %12 = xor i32 %flgn, %flgo
  %13 = xor i32 %flgn, %flgs
  %14 = and i32 %13, %12
  %15 = icmp eq i32 %add32, 0
  %az = zext i1 %15 to i32
  %16 = getelementptr i8, ptr %cpu, i64 228
  %17 = getelementptr i8, ptr %cpu, i64 232
  %18 = getelementptr i8, ptr %cpu, i64 256
  %vs_cur = load i32, ptr %18, align 4
  %19 = or i32 %vs_cur, %14
  %20 = getelementptr i8, ptr %cpu, i64 248
  store i32 %14, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i64 252
  store i32 %14, ptr %21, align 4
  store i32 %19, ptr %18, align 4
  %22 = getelementptr i8, ptr %cpu, i64 236
  %23 = getelementptr i8, ptr %cpu, i64 276
  store i32 %flgn, ptr %23, align 4
  store i32 %az, ptr %16, align 4
  store i32 %flgn, ptr %17, align 4
  store <2 x i32> <i32 1, i32 1>, ptr %22, align 4
  %cc_false = icmp sgt i32 %add32, -1
  br i1 %cc_false, label %brcc_taken, label %insn_0x00010186

brcc_taken:                                       ; preds = %insn_0x0001017c
  %24 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %24, align 4
  %25 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %25, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %26 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %26 monotonic, align 4, !range !1
  %27 = icmp ult i32 %chain_total, %chain_budget
  br i1 %27, label %chain_go, label %chain_leave15, !prof !0

insn_0x00010186:                                  ; preds = %insn_0x0001017c
  %rt = load i32, ptr %cpu, align 4
  %xor32 = xor i32 %rt, %add32
  store i32 %xor32, ptr %cpu, align 4
  %28 = icmp eq i32 %xor32, 0
  %az6 = zext i1 %28 to i32
  %an7 = lshr i32 %xor32, 31
  store i32 %az6, ptr %16, align 4
  store i32 %an7, ptr %17, align 4
  store <2 x i32> zeroinitializer, ptr %22, align 4
  store <2 x i32> zeroinitializer, ptr %20, align 4
  %29 = getelementptr i8, ptr %cpu, i64 168
  store i32 65932, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets18 = load i32, ptr %31, align 4
  %chain_total19 = add nuw i32 %chain_packets18, 7
  %32 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget20 = load atomic i32, ptr %32 monotonic, align 4, !range !1
  %33 = icmp ult i32 %chain_total19, %chain_budget20
  br i1 %33, label %chain_go16, label %chain_leave17, !prof !0

common.ret.sink.split:                            ; preds = %chain_leave15, %chain_leave17
  %.sink27 = phi i32 [ 4, %chain_leave17 ], [ 2, %chain_leave15 ]
  %.sink = phi i32 [ 7, %chain_leave17 ], [ 5, %chain_leave15 ]
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 %.sink27, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 %.sink, ptr %35, align 4
  br label %common.ret

common.ret:                                       ; preds = %common.ret.sink.split, %entry
  %.sink25 = phi i64 [ 357, %entry ], [ 296, %common.ret.sink.split ]
  %36 = getelementptr i8, ptr %cpu, i64 %.sink25
  store i8 1, ptr %36, align 1
  ret void

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527232
  %slot_pc = load i32, ptr %chain_slot, align 4
  %37 = icmp eq i32 %slot_pc, 65904
  br i1 %37, label %chain_hit, label %chain_leave15, !prof !0

chain_leave15:                                    ; preds = %chain_go, %brcc_taken
  store i32 65904, ptr %24, align 4
  br label %common.ret.sink.split

chain_hit:                                        ; preds = %chain_go
  store i32 65904, ptr %24, align 4
  store i32 %chain_total, ptr %25, align 4
  %38 = getelementptr i8, ptr %chain_table, i64 527240
  %chain_fn = load ptr, ptr %38, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go16:                                       ; preds = %insn_0x00010186
  %chain_slot21 = getelementptr i8, ptr %chain_table, i64 526464
  %slot_pc22 = load i32, ptr %chain_slot21, align 4
  %39 = icmp eq i32 %slot_pc22, 65808
  br i1 %39, label %chain_hit23, label %chain_leave17, !prof !0

chain_leave17:                                    ; preds = %chain_go16, %insn_0x00010186
  store i32 65808, ptr %30, align 4
  br label %common.ret.sink.split

chain_hit23:                                      ; preds = %chain_go16
  store i32 65808, ptr %30, align 4
  store i32 %chain_total19, ptr %31, align 4
  %40 = getelementptr i8, ptr %chain_table, i64 526472
  %chain_fn24 = load ptr, ptr %40, align 8
  musttail call swifttailcc void %chain_fn24(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{i32 0, i32 -2147483648}
