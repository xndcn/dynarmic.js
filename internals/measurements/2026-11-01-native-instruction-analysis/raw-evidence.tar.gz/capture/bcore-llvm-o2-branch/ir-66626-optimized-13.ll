; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010442(ptr swiftself %cpu, ptr swiftasync %mem) local_unnamed_addr #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = add i32 %guard_lb, -66639
  %3 = icmp ult i32 %2, -13
  %4 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb1 = load i32, ptr %4, align 4
  %5 = add i32 %guard_lb1, -66639
  %6 = icmp ult i32 %5, -13
  %7 = and i1 %3, %6
  br i1 %7, label %insn_0x00010442, label %common.ret, !prof !0

insn_0x00010442:                                  ; preds = %entry
  %8 = getelementptr i8, ptr %cpu, i64 312
  %page_table = load ptr, ptr %8, align 8
  %9 = getelementptr i8, ptr %cpu, i64 36
  store i32 70044, ptr %9, align 4
  %10 = getelementptr i8, ptr %cpu, i64 40
  %pt = load i32, ptr %10, align 4
  %11 = shl i32 %pt, 2
  %plshift2 = add i32 %11, 70044
  store i32 %plshift2, ptr %10, align 4
  %12 = lshr i32 %plshift2, 12
  %page_index = zext i32 %12 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped.not = icmp eq ptr %page, null
  br i1 %page_mapped.not, label %page_slow, label %page_fast, !prof !1

page_fast:                                        ; preds = %insn_0x00010442
  %13 = and i32 %plshift2, 4092
  %page_offset = zext i32 %13 to i64
  %14 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %14, align 4
  br label %page_done

page_slow:                                        ; preds = %insn_0x00010442
  %15 = getelementptr i8, ptr %cpu, i64 188
  store i32 66636, ptr %15, align 4
  %16 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %16, align 4
  %17 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %17, align 4
  %18 = tail call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %19 = getelementptr i8, ptr %cpu, i64 296
  %dj = load i8, ptr %19, align 1
  %dj_set.not = icmp eq i8 %dj, 0
  br i1 %dj_set.not, label %page_done, label %did_jump_exit, !prof !0

page_done:                                        ; preds = %page_slow, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %18, %page_slow ]
  store i32 %mem_val, ptr %10, align 4
  %lsb = and i32 %mem_val, 1
  %is_odd.not = icmp eq i32 %lsb, 0
  br i1 %is_odd.not, label %chain_exit, label %jump_misalign, !prof !0

did_jump_exit:                                    ; preds = %page_slow
  %next_pc2 = load i32, ptr %15, align 4
  br label %chain_exit

jump_misalign:                                    ; preds = %page_done
  %20 = getelementptr i8, ptr %cpu, i64 188
  store i32 66638, ptr %20, align 4
  %21 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %21, align 4
  %22 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %22, align 4
  tail call void @cec_exception(ptr nonnull %cpu, i32 42, ptr %mem)
  %next_pc3 = load i32, ptr %20, align 4
  %23 = getelementptr i8, ptr %cpu, i64 296
  %24 = load i8, ptr %23, align 1
  br label %chain_exit

common.ret:                                       ; preds = %entry, %chain_leave8
  %.sink9 = phi i64 [ 296, %chain_leave8 ], [ 357, %entry ]
  %tail7.sink = phi i8 [ %tail7, %chain_leave8 ], [ 1, %entry ]
  %25 = getelementptr i8, ptr %cpu, i64 %.sink9
  store i8 %tail7.sink, ptr %25, align 1
  ret void

chain_exit:                                       ; preds = %page_done, %jump_misalign, %did_jump_exit
  %packets = phi i32 [ 4, %did_jump_exit ], [ 5, %jump_misalign ], [ 5, %page_done ]
  %tail = phi i32 [ %next_pc2, %did_jump_exit ], [ %next_pc3, %jump_misalign ], [ %mem_val, %page_done ]
  %tail7 = phi i8 [ %dj, %did_jump_exit ], [ %24, %jump_misalign ], [ 1, %page_done ]
  %26 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %26, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %27 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %27 monotonic, align 4, !range !2
  %28 = icmp ult i32 %chain_total, %chain_budget
  br i1 %28, label %chain_lookup, label %chain_leave8, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %29 = shl i32 %tail, 3
  %30 = and i32 %29, 1048560
  %31 = zext i32 %30 to i64
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %31
  %slot_pc = load i32, ptr %chain_slot, align 4
  %32 = icmp eq i32 %slot_pc, %tail
  br i1 %32, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_lookup, %chain_exit
  %33 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 308
  store i32 %packets, ptr %35, align 4
  br label %common.ret

chain_hit:                                        ; preds = %chain_lookup
  %36 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %36, align 4
  store i32 %chain_total, ptr %26, align 4
  %37 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %37, align 1
  %38 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %38, align 8
  musttail call swifttailcc void %chain_fn(ptr nonnull swiftself %cpu, ptr swiftasync %mem) #0
  ret void
}

declare i32 @mem_read32(ptr, i32) local_unnamed_addr

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) local_unnamed_addr #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
