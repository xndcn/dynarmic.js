
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65668-0-129304658722616.bin:     file format binary


Disassembly of section .data:

0000759a16403f38 <.data>:
    759a16403f38:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    759a16403f3f:	01 
    759a16403f40:	48 83 c4 18          	add    rsp,0x18
    759a16403f44:	c2 08 00             	ret    0x8
    759a16403f47:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    759a16403f4c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    759a16403f53:	08 00 00 00 
    759a16403f57:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16403f5e:	01 00 00 00 
    759a16403f62:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16403f69:	64 00 00 
    759a16403f6c:	4c 89 ef             	mov    rdi,r13
    759a16403f6f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403f74:	4c 89 f6             	mov    rsi,r14
    759a16403f77:	ba 84 00 01 00       	mov    edx,0x10084
    759a16403f7c:	45 31 c0             	xor    r8d,r8d
    759a16403f7f:	ff d0                	call   rax
    759a16403f81:	b9 08 00 00 00       	mov    ecx,0x8
    759a16403f86:	b8 01 00 00 00       	mov    eax,0x1
    759a16403f8b:	41 8b b5 bc 00 00 00 	mov    esi,DWORD PTR [r13+0xbc]
    759a16403f92:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    759a16403f99:	01 c2                	add    edx,eax
    759a16403f9b:	41 8b bd 58 01 00 00 	mov    edi,DWORD PTR [r13+0x158]
    759a16403fa2:	39 fa                	cmp    edx,edi
    759a16403fa4:	0f 83 f7 00 00 00    	jae    0x759a164040a1
    759a16403faa:	8d 3c f5 00 00 00 00 	lea    edi,[rsi*8+0x0]
    759a16403fb1:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    759a16403fb7:	48 8b 6c 24 08       	mov    rbp,QWORD PTR [rsp+0x8]
    759a16403fbc:	39 74 3d 00          	cmp    DWORD PTR [rbp+rdi*1+0x0],esi
    759a16403fc0:	0f 85 db 00 00 00    	jne    0x759a164040a1
    759a16403fc6:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    759a16403fcd:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    759a16403fd4:	00 
    759a16403fd5:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    759a16403fda:	48 8b 44 38 08       	mov    rax,QWORD PTR [rax+rdi*1+0x8]
    759a16403fdf:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403fe4:	48 83 c4 18          	add    rsp,0x18
    759a16403fe8:	ff e0                	jmp    rax
    759a16403fea:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    759a16403fef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    759a16403ff6:	08 00 00 00 
    759a16403ffa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16404001:	01 00 00 00 
    759a16404005:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640400c:	64 00 00 
    759a1640400f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16404014:	4c 89 f7             	mov    rdi,r14
    759a16404017:	89 ce                	mov    esi,ecx
    759a16404019:	ff d0                	call   rax
    759a1640401b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a16404022:	00 
    759a16404023:	0f 85 58 ff ff ff    	jne    0x759a16403f81
    759a16404029:	41 8b ad a0 00 00 00 	mov    ebp,DWORD PTR [r13+0xa0]
    759a16404030:	41 8b bd a4 00 00 00 	mov    edi,DWORD PTR [r13+0xa4]
    759a16404037:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a1640403c:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    759a16404041:	e9 07 ec ff e7       	jmp    0x7599fe402c4d
    759a16404046:	49 89 ff             	mov    r15,rdi
    759a16404049:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    759a1640404e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    759a16404055:	8c 00 01 00 
    759a16404059:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16404060:	02 00 00 00 
    759a16404064:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a1640406b:	02 00 00 00 
    759a1640406f:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16404076:	64 00 00 
    759a16404079:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640407e:	4c 89 f7             	mov    rdi,r14
    759a16404081:	89 de                	mov    esi,ebx
    759a16404083:	ff d0                	call   rax
    759a16404085:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    759a1640408c:	00 
    759a1640408d:	75 27                	jne    0x759a164040b6
    759a1640408f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16404094:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
    759a16404099:	4c 89 ff             	mov    rdi,r15
    759a1640409c:	e9 d2 eb ff e7       	jmp    0x7599fe402c73
    759a164040a1:	41 89 8d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ecx
    759a164040a8:	41 89 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],eax
    759a164040af:	48 83 c4 18          	add    rsp,0x18
    759a164040b3:	c2 08 00             	ret    0x8
    759a164040b6:	b8 02 00 00 00       	mov    eax,0x2
    759a164040bb:	b9 02 00 00 00       	mov    ecx,0x2
    759a164040c0:	e9 c6 fe ff ff       	jmp    0x759a16403f8b
