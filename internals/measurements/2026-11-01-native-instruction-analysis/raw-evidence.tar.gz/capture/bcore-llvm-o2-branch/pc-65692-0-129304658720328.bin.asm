
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65692-0-129304658720328.bin:     file format binary


Disassembly of section .data:

0000759a16403648 <.data>:
    759a16403648:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    759a1640364f:	84 00 01 00 
    759a16403653:	b1 01                	mov    cl,0x1
    759a16403655:	bd 07 00 00 00       	mov    ebp,0x7
    759a1640365a:	bb 02 00 00 00       	mov    ebx,0x2
    759a1640365f:	e9 b4 f4 ff e7       	jmp    0x7599fe402b18
    759a16403664:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640366b:	02 00 00 00 
    759a1640366f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a16403676:	01 00 00 00 
    759a1640367a:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16403681:	64 00 00 
    759a16403684:	48 89 fb             	mov    rbx,rdi
    759a16403687:	4c 89 ef             	mov    rdi,r13
    759a1640368a:	4c 89 f6             	mov    rsi,r14
    759a1640368d:	ba 9c 00 01 00       	mov    edx,0x1009c
    759a16403692:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16403698:	ff d0                	call   rax
    759a1640369a:	48 89 df             	mov    rdi,rbx
    759a1640369d:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164036a4:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164036ab:	00 
    759a164036ac:	bb 02 00 00 00       	mov    ebx,0x2
    759a164036b1:	bd 01 00 00 00       	mov    ebp,0x1
    759a164036b6:	e9 0c f4 ff e7       	jmp    0x7599fe402ac7
    759a164036bb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164036c2:	02 00 00 00 
    759a164036c6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a164036cd:	01 00 00 00 
    759a164036d1:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164036d8:	64 00 00 
    759a164036db:	48 89 fb             	mov    rbx,rdi
    759a164036de:	4c 89 f7             	mov    rdi,r14
    759a164036e1:	89 ce                	mov    esi,ecx
    759a164036e3:	4c 89 c5             	mov    rbp,r8
    759a164036e6:	ff d0                	call   rax
    759a164036e8:	49 89 e8             	mov    r8,rbp
    759a164036eb:	48 89 df             	mov    rdi,rbx
    759a164036ee:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164036f5:	00 
    759a164036f6:	84 c9                	test   cl,cl
    759a164036f8:	0f 84 b7 f0 ff e7    	je     0x7599fe4027b5
    759a164036fe:	eb 4c                	jmp    0x759a1640374c
    759a16403700:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    759a16403707:	9e 00 01 00 
    759a1640370b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403712:	02 00 00 00 
    759a16403716:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    759a1640371d:	01 00 00 00 
    759a16403721:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16403728:	64 00 00 
    759a1640372b:	48 89 fb             	mov    rbx,rdi
    759a1640372e:	4c 89 ef             	mov    rdi,r13
    759a16403731:	4c 89 c5             	mov    rbp,r8
    759a16403734:	ff d0                	call   rax
    759a16403736:	49 89 e8             	mov    r8,rbp
    759a16403739:	48 89 df             	mov    rdi,rbx
    759a1640373c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403743:	00 
    759a16403744:	84 c9                	test   cl,cl
    759a16403746:	0f 84 73 f0 ff e7    	je     0x7599fe4027bf
    759a1640374c:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403753:	e9 54 ff ff ff       	jmp    0x759a164036ac
    759a16403758:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    759a1640375f:	9e 00 01 00 
    759a16403763:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640376a:	02 00 00 00 
    759a1640376e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16403775:	02 00 00 00 
    759a16403779:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16403780:	64 00 00 
    759a16403783:	48 89 fd             	mov    rbp,rdi
    759a16403786:	4c 89 ef             	mov    rdi,r13
    759a16403789:	4c 89 f6             	mov    rsi,r14
    759a1640378c:	ba 9e 00 01 00       	mov    edx,0x1009e
    759a16403791:	89 d9                	mov    ecx,ebx
    759a16403793:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16403799:	ff d0                	call   rax
    759a1640379b:	48 89 ef             	mov    rdi,rbp
    759a1640379e:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164037a5:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164037ac:	00 
    759a164037ad:	bd 02 00 00 00       	mov    ebp,0x2
    759a164037b2:	bb 02 00 00 00       	mov    ebx,0x2
    759a164037b7:	e9 0b f3 ff e7       	jmp    0x7599fe402ac7
    759a164037bc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1009e
    759a164037c3:	9e 00 01 00 
    759a164037c7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164037ce:	02 00 00 00 
    759a164037d2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a164037d9:	02 00 00 00 
    759a164037dd:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164037e4:	64 00 00 
    759a164037e7:	49 89 fc             	mov    r12,rdi
    759a164037ea:	4c 89 f7             	mov    rdi,r14
    759a164037ed:	89 de                	mov    esi,ebx
    759a164037ef:	4c 89 c5             	mov    rbp,r8
    759a164037f2:	ff d0                	call   rax
    759a164037f4:	49 89 e8             	mov    r8,rbp
    759a164037f7:	4c 89 e7             	mov    rdi,r12
    759a164037fa:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403801:	00 
    759a16403802:	84 c9                	test   cl,cl
    759a16403804:	0f 84 e5 ef ff e7    	je     0x7599fe4027ef
    759a1640380a:	eb 4c                	jmp    0x759a16403858
    759a1640380c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a0
    759a16403813:	a0 00 01 00 
    759a16403817:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640381e:	02 00 00 00 
    759a16403822:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16403829:	02 00 00 00 
    759a1640382d:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16403834:	64 00 00 
    759a16403837:	48 89 fb             	mov    rbx,rdi
    759a1640383a:	4c 89 ef             	mov    rdi,r13
    759a1640383d:	4c 89 c5             	mov    rbp,r8
    759a16403840:	ff d0                	call   rax
    759a16403842:	49 89 e8             	mov    r8,rbp
    759a16403845:	48 89 df             	mov    rdi,rbx
    759a16403848:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640384f:	00 
    759a16403850:	84 c9                	test   cl,cl
    759a16403852:	0f 84 a8 ef ff e7    	je     0x7599fe402800
    759a16403858:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a1640385f:	e9 49 ff ff ff       	jmp    0x759a164037ad
    759a16403864:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    759a1640386b:	a4 00 01 00 
    759a1640386f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403876:	02 00 00 00 
    759a1640387a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16403881:	05 00 00 00 
    759a16403885:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a1640388c:	64 00 00 
    759a1640388f:	48 89 fb             	mov    rbx,rdi
    759a16403892:	4c 89 ef             	mov    rdi,r13
    759a16403895:	4c 89 f6             	mov    rsi,r14
    759a16403898:	ba a4 00 01 00       	mov    edx,0x100a4
    759a1640389d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a164038a3:	ff d0                	call   rax
    759a164038a5:	48 89 df             	mov    rdi,rbx
    759a164038a8:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164038af:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164038b6:	00 
    759a164038b7:	bb 02 00 00 00       	mov    ebx,0x2
    759a164038bc:	bd 05 00 00 00       	mov    ebp,0x5
    759a164038c1:	e9 01 f2 ff e7       	jmp    0x7599fe402ac7
    759a164038c6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a4
    759a164038cd:	a4 00 01 00 
    759a164038d1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164038d8:	02 00 00 00 
    759a164038dc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a164038e3:	05 00 00 00 
    759a164038e7:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164038ee:	64 00 00 
    759a164038f1:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164038f6:	4c 89 f7             	mov    rdi,r14
    759a164038f9:	89 ce                	mov    esi,ecx
    759a164038fb:	89 da                	mov    edx,ebx
    759a164038fd:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403902:	4d 89 c6             	mov    r14,r8
    759a16403905:	ff d0                	call   rax
    759a16403907:	4d 89 f0             	mov    r8,r14
    759a1640390a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640390f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403914:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640391b:	00 
    759a1640391c:	84 c9                	test   cl,cl
    759a1640391e:	0f 84 69 ef ff e7    	je     0x7599fe40288d
    759a16403924:	eb 5a                	jmp    0x759a16403980
    759a16403926:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100a6
    759a1640392d:	a6 00 01 00 
    759a16403931:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403938:	02 00 00 00 
    759a1640393c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16403943:	05 00 00 00 
    759a16403947:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a1640394e:	64 00 00 
    759a16403951:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403956:	4c 89 ef             	mov    rdi,r13
    759a16403959:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640395e:	4d 89 c6             	mov    r14,r8
    759a16403961:	ff d0                	call   rax
    759a16403963:	4d 89 f0             	mov    r8,r14
    759a16403966:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640396b:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403970:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403977:	00 
    759a16403978:	84 c9                	test   cl,cl
    759a1640397a:	0f 84 17 ef ff e7    	je     0x7599fe402897
    759a16403980:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403987:	e9 2b ff ff ff       	jmp    0x759a164038b7
    759a1640398c:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    759a16403993:	e9 80 f1 ff e7       	jmp    0x7599fe402b18
    759a16403998:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b4
    759a1640399f:	b4 00 01 00 
    759a164039a3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164039aa:	02 00 00 00 
    759a164039ae:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    759a164039b5:	0b 00 00 00 
    759a164039b9:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164039c0:	64 00 00 
    759a164039c3:	bb 02 00 00 00       	mov    ebx,0x2
    759a164039c8:	49 89 fc             	mov    r12,rdi
    759a164039cb:	4c 89 f7             	mov    rdi,r14
    759a164039ce:	be 10 f0 00 00       	mov    esi,0xf010
    759a164039d3:	ba 02 00 00 00       	mov    edx,0x2
    759a164039d8:	4c 89 c5             	mov    rbp,r8
    759a164039db:	ff d0                	call   rax
    759a164039dd:	49 89 e8             	mov    r8,rbp
    759a164039e0:	4c 89 e7             	mov    rdi,r12
    759a164039e3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164039ea:	00 
    759a164039eb:	84 c9                	test   cl,cl
    759a164039ed:	0f 84 5a ef ff e7    	je     0x7599fe40294d
    759a164039f3:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164039fa:	eb 58                	jmp    0x759a16403a54
    759a164039fc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    759a16403a03:	b6 00 01 00 
    759a16403a07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403a0e:	02 00 00 00 
    759a16403a12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    759a16403a19:	0b 00 00 00 
    759a16403a1d:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a16403a24:	64 00 00 
    759a16403a27:	48 89 fb             	mov    rbx,rdi
    759a16403a2a:	4c 89 ef             	mov    rdi,r13
    759a16403a2d:	4c 89 c5             	mov    rbp,r8
    759a16403a30:	ff d0                	call   rax
    759a16403a32:	49 89 e8             	mov    r8,rbp
    759a16403a35:	48 89 df             	mov    rdi,rbx
    759a16403a38:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403a3f:	00 
    759a16403a40:	84 c9                	test   cl,cl
    759a16403a42:	0f 84 0f ef ff e7    	je     0x7599fe402957
    759a16403a48:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403a4f:	bb 02 00 00 00       	mov    ebx,0x2
    759a16403a54:	bd 0b 00 00 00       	mov    ebp,0xb
    759a16403a59:	e9 69 f0 ff e7       	jmp    0x7599fe402ac7
    759a16403a5e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    759a16403a65:	b6 00 01 00 
    759a16403a69:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403a70:	04 00 00 00 
    759a16403a74:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a16403a7b:	0c 00 00 00 
    759a16403a7f:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16403a86:	64 00 00 
    759a16403a89:	48 89 fb             	mov    rbx,rdi
    759a16403a8c:	4c 89 ef             	mov    rdi,r13
    759a16403a8f:	4c 89 f6             	mov    rsi,r14
    759a16403a92:	ba b6 00 01 00       	mov    edx,0x100b6
    759a16403a97:	89 e9                	mov    ecx,ebp
    759a16403a99:	45 31 c0             	xor    r8d,r8d
    759a16403a9c:	ff d0                	call   rax
    759a16403a9e:	48 89 df             	mov    rdi,rbx
    759a16403aa1:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403aa8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403aaf:	00 
    759a16403ab0:	bb 04 00 00 00       	mov    ebx,0x4
    759a16403ab5:	bd 0c 00 00 00       	mov    ebp,0xc
    759a16403aba:	e9 08 f0 ff e7       	jmp    0x7599fe402ac7
    759a16403abf:	4d 89 c7             	mov    r15,r8
    759a16403ac2:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403ac7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    759a16403ace:	b6 00 01 00 
    759a16403ad2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403ad9:	04 00 00 00 
    759a16403add:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a16403ae4:	0c 00 00 00 
    759a16403ae8:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403aef:	64 00 00 
    759a16403af2:	4d 89 f4             	mov    r12,r14
    759a16403af5:	4c 89 f7             	mov    rdi,r14
    759a16403af8:	89 ee                	mov    esi,ebp
    759a16403afa:	ff d0                	call   rax
    759a16403afc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403b03:	00 
    759a16403b04:	84 c9                	test   cl,cl
    759a16403b06:	0f 85 57 03 00 00    	jne    0x759a16403e63
    759a16403b0c:	89 c3                	mov    ebx,eax
    759a16403b0e:	4d 89 e6             	mov    r14,r12
    759a16403b11:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403b16:	4d 89 f8             	mov    r8,r15
    759a16403b19:	e9 66 ee ff e7       	jmp    0x7599fe402984
    759a16403b1e:	4d 89 c4             	mov    r12,r8
    759a16403b21:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403b26:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100b6
    759a16403b2d:	b6 00 01 00 
    759a16403b31:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403b38:	04 00 00 00 
    759a16403b3c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xc
    759a16403b43:	0c 00 00 00 
    759a16403b47:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403b4e:	64 00 00 
    759a16403b51:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403b56:	4c 89 f7             	mov    rdi,r14
    759a16403b59:	ff d0                	call   rax
    759a16403b5b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403b62:	00 
    759a16403b63:	84 c9                	test   cl,cl
    759a16403b65:	0f 85 0b 03 00 00    	jne    0x759a16403e76
    759a16403b6b:	41 89 c7             	mov    r15d,eax
    759a16403b6e:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403b73:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403b78:	4d 89 e0             	mov    r8,r12
    759a16403b7b:	e9 23 ee ff e7       	jmp    0x7599fe4029a3
    759a16403b80:	4c 89 c3             	mov    rbx,r8
    759a16403b83:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403b88:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403b8f:	bc 00 01 00 
    759a16403b93:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403b9a:	02 00 00 00 
    759a16403b9e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403ba5:	0e 00 00 00 
    759a16403ba9:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403bb0:	64 00 00 
    759a16403bb3:	4d 89 f4             	mov    r12,r14
    759a16403bb6:	4c 89 f7             	mov    rdi,r14
    759a16403bb9:	ff d0                	call   rax
    759a16403bbb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403bc2:	00 
    759a16403bc3:	84 c9                	test   cl,cl
    759a16403bc5:	0f 85 7a 02 00 00    	jne    0x759a16403e45
    759a16403bcb:	4d 89 e6             	mov    r14,r12
    759a16403bce:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403bd3:	49 89 d8             	mov    r8,rbx
    759a16403bd6:	e9 fd ed ff e7       	jmp    0x7599fe4029d8
    759a16403bdb:	4c 89 c3             	mov    rbx,r8
    759a16403bde:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403be3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403bea:	bc 00 01 00 
    759a16403bee:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403bf5:	02 00 00 00 
    759a16403bf9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403c00:	0e 00 00 00 
    759a16403c04:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403c0b:	64 00 00 
    759a16403c0e:	4d 89 f4             	mov    r12,r14
    759a16403c11:	4c 89 f7             	mov    rdi,r14
    759a16403c14:	ff d0                	call   rax
    759a16403c16:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403c1d:	00 
    759a16403c1e:	84 c9                	test   cl,cl
    759a16403c20:	0f 85 1f 02 00 00    	jne    0x759a16403e45
    759a16403c26:	4d 89 e6             	mov    r14,r12
    759a16403c29:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403c2e:	49 89 d8             	mov    r8,rbx
    759a16403c31:	e9 c4 ed ff e7       	jmp    0x7599fe4029fa
    759a16403c36:	4c 89 c3             	mov    rbx,r8
    759a16403c39:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403c3e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403c45:	bc 00 01 00 
    759a16403c49:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403c50:	02 00 00 00 
    759a16403c54:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403c5b:	0e 00 00 00 
    759a16403c5f:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403c66:	64 00 00 
    759a16403c69:	4d 89 f4             	mov    r12,r14
    759a16403c6c:	4c 89 f7             	mov    rdi,r14
    759a16403c6f:	ff d0                	call   rax
    759a16403c71:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403c78:	00 
    759a16403c79:	84 c9                	test   cl,cl
    759a16403c7b:	0f 85 c4 01 00 00    	jne    0x759a16403e45
    759a16403c81:	4d 89 e6             	mov    r14,r12
    759a16403c84:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403c89:	49 89 d8             	mov    r8,rbx
    759a16403c8c:	e9 8b ed ff e7       	jmp    0x7599fe402a1c
    759a16403c91:	4c 89 c3             	mov    rbx,r8
    759a16403c94:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403c99:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403ca0:	bc 00 01 00 
    759a16403ca4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403cab:	02 00 00 00 
    759a16403caf:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403cb6:	0e 00 00 00 
    759a16403cba:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403cc1:	64 00 00 
    759a16403cc4:	4d 89 f4             	mov    r12,r14
    759a16403cc7:	4c 89 f7             	mov    rdi,r14
    759a16403cca:	ff d0                	call   rax
    759a16403ccc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403cd3:	00 
    759a16403cd4:	84 c9                	test   cl,cl
    759a16403cd6:	0f 85 69 01 00 00    	jne    0x759a16403e45
    759a16403cdc:	4d 89 e6             	mov    r14,r12
    759a16403cdf:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403ce4:	49 89 d8             	mov    r8,rbx
    759a16403ce7:	e9 52 ed ff e7       	jmp    0x7599fe402a3e
    759a16403cec:	4c 89 c3             	mov    rbx,r8
    759a16403cef:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403cf4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403cfb:	bc 00 01 00 
    759a16403cff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403d06:	02 00 00 00 
    759a16403d0a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403d11:	0e 00 00 00 
    759a16403d15:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403d1c:	64 00 00 
    759a16403d1f:	4d 89 f4             	mov    r12,r14
    759a16403d22:	4c 89 f7             	mov    rdi,r14
    759a16403d25:	ff d0                	call   rax
    759a16403d27:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403d2e:	00 
    759a16403d2f:	84 c9                	test   cl,cl
    759a16403d31:	0f 85 0e 01 00 00    	jne    0x759a16403e45
    759a16403d37:	4d 89 e6             	mov    r14,r12
    759a16403d3a:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403d3f:	49 89 d8             	mov    r8,rbx
    759a16403d42:	e9 19 ed ff e7       	jmp    0x7599fe402a60
    759a16403d47:	4c 89 c3             	mov    rbx,r8
    759a16403d4a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403d4f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403d56:	bc 00 01 00 
    759a16403d5a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403d61:	02 00 00 00 
    759a16403d65:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403d6c:	0e 00 00 00 
    759a16403d70:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403d77:	64 00 00 
    759a16403d7a:	4d 89 f4             	mov    r12,r14
    759a16403d7d:	4c 89 f7             	mov    rdi,r14
    759a16403d80:	ff d0                	call   rax
    759a16403d82:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403d89:	00 
    759a16403d8a:	84 c9                	test   cl,cl
    759a16403d8c:	0f 85 b3 00 00 00    	jne    0x759a16403e45
    759a16403d92:	4d 89 e6             	mov    r14,r12
    759a16403d95:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403d9a:	49 89 d8             	mov    r8,rbx
    759a16403d9d:	e9 e0 ec ff e7       	jmp    0x7599fe402a82
    759a16403da2:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16403da7:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100bc
    759a16403dae:	bc 00 01 00 
    759a16403db2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403db9:	02 00 00 00 
    759a16403dbd:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xe
    759a16403dc4:	0e 00 00 00 
    759a16403dc8:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403dcf:	64 00 00 
    759a16403dd2:	4d 89 f4             	mov    r12,r14
    759a16403dd5:	4c 89 f7             	mov    rdi,r14
    759a16403dd8:	ff d0                	call   rax
    759a16403dda:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403de1:	00 
    759a16403de2:	84 c9                	test   cl,cl
    759a16403de4:	75 5f                	jne    0x759a16403e45
    759a16403de6:	4d 89 e6             	mov    r14,r12
    759a16403de9:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403dee:	e9 b3 ec ff e7       	jmp    0x7599fe402aa6
    759a16403df3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100be
    759a16403dfa:	be 00 01 00 
    759a16403dfe:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403e05:	02 00 00 00 
    759a16403e09:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    759a16403e10:	0f 00 00 00 
    759a16403e14:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a16403e1b:	64 00 00 
    759a16403e1e:	49 89 ff             	mov    r15,rdi
    759a16403e21:	4c 89 ef             	mov    rdi,r13
    759a16403e24:	be 2a 00 00 00       	mov    esi,0x2a
    759a16403e29:	4c 89 f2             	mov    rdx,r14
    759a16403e2c:	ff d0                	call   rax
    759a16403e2e:	4c 89 ff             	mov    rdi,r15
    759a16403e31:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403e38:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403e3f:	00 
    759a16403e40:	e9 82 ec ff e7       	jmp    0x7599fe402ac7
    759a16403e45:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403e4c:	bb 02 00 00 00       	mov    ebx,0x2
    759a16403e51:	bd 0e 00 00 00       	mov    ebp,0xe
    759a16403e56:	4d 89 e6             	mov    r14,r12
    759a16403e59:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403e5e:	e9 64 ec ff e7       	jmp    0x7599fe402ac7
    759a16403e63:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403e6a:	bb 04 00 00 00       	mov    ebx,0x4
    759a16403e6f:	bd 0c 00 00 00       	mov    ebp,0xc
    759a16403e74:	eb e0                	jmp    0x759a16403e56
    759a16403e76:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a16403e7d:	bb 04 00 00 00       	mov    ebx,0x4
    759a16403e82:	bd 0c 00 00 00       	mov    ebp,0xc
    759a16403e87:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403e8c:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16403e91:	e9 31 ec ff e7       	jmp    0x7599fe402ac7
