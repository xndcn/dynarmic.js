
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-66600-0-129304658714674.bin:     file format binary


Disassembly of section .data:

0000759a16402032 <.data>:
    759a16402032:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    759a16402039:	e9 40 f4 ff e7       	jmp    0x7599fe40147e
    759a1640203e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    759a16402045:	2c 04 01 00 
    759a16402049:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402050:	04 00 00 00 
    759a16402054:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a1640205b:	02 00 00 00 
    759a1640205f:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a16402066:	64 00 00 
    759a16402069:	48 89 fb             	mov    rbx,rdi
    759a1640206c:	4c 89 ef             	mov    rdi,r13
    759a1640206f:	4c 89 f6             	mov    rsi,r14
    759a16402072:	ba 2c 04 01 00       	mov    edx,0x1042c
    759a16402077:	44 89 c1             	mov    ecx,r8d
    759a1640207a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    759a16402080:	ff d0                	call   rax
    759a16402082:	48 89 df             	mov    rdi,rbx
    759a16402085:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a1640208c:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402093:	00 
    759a16402094:	bb 04 00 00 00       	mov    ebx,0x4
    759a16402099:	bd 02 00 00 00       	mov    ebp,0x2
    759a1640209e:	e9 8c f3 ff e7       	jmp    0x7599fe40142f
    759a164020a3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    759a164020aa:	2c 04 01 00 
    759a164020ae:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164020b5:	04 00 00 00 
    759a164020b9:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a164020c0:	02 00 00 00 
    759a164020c4:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a164020cb:	64 00 00 
    759a164020ce:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164020d3:	4c 89 f7             	mov    rdi,r14
    759a164020d6:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    759a164020db:	44 89 c6             	mov    esi,r8d
    759a164020de:	4d 89 c4             	mov    r12,r8
    759a164020e1:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a164020e6:	44 89 d5             	mov    ebp,r10d
    759a164020e9:	ff d0                	call   rax
    759a164020eb:	41 89 ea             	mov    r10d,ebp
    759a164020ee:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a164020f3:	4d 89 e0             	mov    r8,r12
    759a164020f6:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a164020fb:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402100:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402107:	00 
    759a16402108:	84 c9                	test   cl,cl
    759a1640210a:	0f 84 0b f2 ff e7    	je     0x7599fe40131b
    759a16402110:	e9 d9 00 00 00       	jmp    0x759a164021ee
    759a16402115:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    759a1640211c:	2c 04 01 00 
    759a16402120:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16402127:	04 00 00 00 
    759a1640212b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a16402132:	02 00 00 00 
    759a16402136:	48 b8 20 56 c0 d7 e7 	movabs rax,0x64e7d7c05620
    759a1640213d:	64 00 00 
    759a16402140:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402145:	4c 89 f7             	mov    rdi,r14
    759a16402148:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    759a1640214d:	89 ee                	mov    esi,ebp
    759a1640214f:	44 89 d2             	mov    edx,r10d
    759a16402152:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    759a16402157:	4d 89 c6             	mov    r14,r8
    759a1640215a:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    759a1640215f:	ff d0                	call   rax
    759a16402161:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    759a16402166:	4d 89 f0             	mov    r8,r14
    759a16402169:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a1640216e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a16402173:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a16402178:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640217f:	00 
    759a16402180:	84 c9                	test   cl,cl
    759a16402182:	0f 84 b6 f1 ff e7    	je     0x7599fe40133e
    759a16402188:	eb 64                	jmp    0x759a164021ee
    759a1640218a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    759a16402191:	30 04 01 00 
    759a16402195:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a1640219c:	04 00 00 00 
    759a164021a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    759a164021a7:	02 00 00 00 
    759a164021ab:	48 b8 00 b6 d1 d7 e7 	movabs rax,0x64e7d7d1b600
    759a164021b2:	64 00 00 
    759a164021b5:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a164021ba:	4c 89 ef             	mov    rdi,r13
    759a164021bd:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    759a164021c2:	49 89 f6             	mov    r14,rsi
    759a164021c5:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    759a164021ca:	ff d0                	call   rax
    759a164021cc:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    759a164021d1:	4c 89 f6             	mov    rsi,r14
    759a164021d4:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164021d9:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a164021de:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164021e5:	00 
    759a164021e6:	84 c9                	test   cl,cl
    759a164021e8:	0f 84 62 f1 ff e7    	je     0x7599fe401350
    759a164021ee:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a164021f5:	e9 9a fe ff ff       	jmp    0x759a16402094
    759a164021fa:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    759a164021ff:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    759a16402204:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402209:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    759a16402210:	34 04 01 00 
    759a16402214:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640221b:	02 00 00 00 
    759a1640221f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    759a16402226:	04 00 00 00 
    759a1640222a:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16402231:	64 00 00 
    759a16402234:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    759a16402239:	4c 89 f7             	mov    rdi,r14
    759a1640223c:	be f0 12 01 00       	mov    esi,0x112f0
    759a16402241:	ff d0                	call   rax
    759a16402243:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640224a:	00 
    759a1640224b:	84 c9                	test   cl,cl
    759a1640224d:	0f 85 4e 01 00 00    	jne    0x759a164023a1
    759a16402253:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a16402258:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a1640225d:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    759a16402262:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    759a16402267:	e9 02 f1 ff e7       	jmp    0x7599fe40136e
    759a1640226c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    759a16402273:	42 04 01 00 
    759a16402277:	b1 01                	mov    cl,0x1
    759a16402279:	bd 06 00 00 00       	mov    ebp,0x6
    759a1640227e:	bb 02 00 00 00       	mov    ebx,0x2
    759a16402283:	e9 f6 f1 ff e7       	jmp    0x7599fe40147e
    759a16402288:	4c 89 44 24 10       	mov    QWORD PTR [rsp+0x10],r8
    759a1640228d:	49 89 f4             	mov    r12,rsi
    759a16402290:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    759a16402295:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    759a1640229c:	3c 04 01 00 
    759a164022a0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164022a7:	04 00 00 00 
    759a164022ab:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    759a164022b2:	08 00 00 00 
    759a164022b6:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164022bd:	64 00 00 
    759a164022c0:	4c 89 74 24 18       	mov    QWORD PTR [rsp+0x18],r14
    759a164022c5:	4c 89 f7             	mov    rdi,r14
    759a164022c8:	89 ee                	mov    esi,ebp
    759a164022ca:	ff d0                	call   rax
    759a164022cc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164022d3:	00 
    759a164022d4:	84 c9                	test   cl,cl
    759a164022d6:	0f 85 e5 00 00 00    	jne    0x759a164023c1
    759a164022dc:	89 c5                	mov    ebp,eax
    759a164022de:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a164022e3:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164022e8:	4c 89 e6             	mov    rsi,r12
    759a164022eb:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
    759a164022f0:	e9 ff f0 ff e7       	jmp    0x7599fe4013f4
    759a164022f5:	48 89 f3             	mov    rbx,rsi
    759a164022f8:	49 89 fc             	mov    r12,rdi
    759a164022fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    759a16402302:	3c 04 01 00 
    759a16402306:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a1640230d:	04 00 00 00 
    759a16402311:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    759a16402318:	08 00 00 00 
    759a1640231c:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16402323:	64 00 00 
    759a16402326:	4d 89 f7             	mov    r15,r14
    759a16402329:	4c 89 f7             	mov    rdi,r14
    759a1640232c:	44 89 c6             	mov    esi,r8d
    759a1640232f:	ff d0                	call   rax
    759a16402331:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16402338:	00 
    759a16402339:	84 c9                	test   cl,cl
    759a1640233b:	0f 85 93 00 00 00    	jne    0x759a164023d4
    759a16402341:	4d 89 fe             	mov    r14,r15
    759a16402344:	4c 89 e7             	mov    rdi,r12
    759a16402347:	48 89 de             	mov    rsi,rbx
    759a1640234a:	e9 bd f0 ff e7       	jmp    0x7599fe40140c
    759a1640234f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    759a16402356:	40 04 01 00 
    759a1640235a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16402361:	02 00 00 00 
    759a16402365:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    759a1640236c:	09 00 00 00 
    759a16402370:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a16402377:	64 00 00 
    759a1640237a:	49 89 ff             	mov    r15,rdi
    759a1640237d:	4c 89 ef             	mov    rdi,r13
    759a16402380:	be 2a 00 00 00       	mov    esi,0x2a
    759a16402385:	4c 89 f2             	mov    rdx,r14
    759a16402388:	ff d0                	call   rax
    759a1640238a:	4c 89 ff             	mov    rdi,r15
    759a1640238d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a16402394:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640239b:	00 
    759a1640239c:	e9 8e f0 ff e7       	jmp    0x7599fe40142f
    759a164023a1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a164023a8:	bb 02 00 00 00       	mov    ebx,0x2
    759a164023ad:	bd 04 00 00 00       	mov    ebp,0x4
    759a164023b2:	4c 8b 74 24 18       	mov    r14,QWORD PTR [rsp+0x18]
    759a164023b7:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    759a164023bc:	e9 6e f0 ff e7       	jmp    0x7599fe40142f
    759a164023c1:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a164023c8:	bb 04 00 00 00       	mov    ebx,0x4
    759a164023cd:	bd 08 00 00 00       	mov    ebp,0x8
    759a164023d2:	eb de                	jmp    0x759a164023b2
    759a164023d4:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    759a164023db:	bb 04 00 00 00       	mov    ebx,0x4
    759a164023e0:	bd 08 00 00 00       	mov    ebp,0x8
    759a164023e5:	4d 89 fe             	mov    r14,r15
    759a164023e8:	4c 89 e7             	mov    rdi,r12
    759a164023eb:	e9 3f f0 ff e7       	jmp    0x7599fe40142f
