
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-65932-0-129304658719338.bin:     file format binary


Disassembly of section .data:

0000759a1640326a <.data>:
    759a1640326a:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    759a16403271:	e9 5b f4 ff e7       	jmp    0x7599fe4026d1
    759a16403276:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    759a1640327d:	7c 01 01 00 
    759a16403281:	b1 01                	mov    cl,0x1
    759a16403283:	bd 03 00 00 00       	mov    ebp,0x3
    759a16403288:	bb 02 00 00 00       	mov    ebx,0x2
    759a1640328d:	e9 3f f4 ff e7       	jmp    0x7599fe4026d1
    759a16403292:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    759a16403299:	94 01 01 00 
    759a1640329d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a164032a4:	04 00 00 00 
    759a164032a8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a164032af:	05 00 00 00 
    759a164032b3:	48 b8 d0 b8 d1 d7 e7 	movabs rax,0x64e7d7d1b8d0
    759a164032ba:	64 00 00 
    759a164032bd:	4c 89 ef             	mov    rdi,r13
    759a164032c0:	4c 89 f6             	mov    rsi,r14
    759a164032c3:	ba 94 01 01 00       	mov    edx,0x10194
    759a164032c8:	89 e9                	mov    ecx,ebp
    759a164032ca:	4c 89 c3             	mov    rbx,r8
    759a164032cd:	45 31 c0             	xor    r8d,r8d
    759a164032d0:	ff d0                	call   rax
    759a164032d2:	49 89 d8             	mov    r8,rbx
    759a164032d5:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164032dc:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164032e3:	00 
    759a164032e4:	bb 04 00 00 00       	mov    ebx,0x4
    759a164032e9:	bd 05 00 00 00       	mov    ebp,0x5
    759a164032ee:	e9 39 f3 ff e7       	jmp    0x7599fe40262c
    759a164032f3:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a164032f8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    759a164032ff:	94 01 01 00 
    759a16403303:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a1640330a:	04 00 00 00 
    759a1640330e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16403315:	05 00 00 00 
    759a16403319:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403320:	64 00 00 
    759a16403323:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403328:	4c 89 f7             	mov    rdi,r14
    759a1640332b:	89 ee                	mov    esi,ebp
    759a1640332d:	ff d0                	call   rax
    759a1640332f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403336:	00 
    759a16403337:	84 c9                	test   cl,cl
    759a16403339:	0f 85 98 02 00 00    	jne    0x759a164035d7
    759a1640333f:	89 c3                	mov    ebx,eax
    759a16403341:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403346:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a1640334b:	e9 e7 f1 ff e7       	jmp    0x7599fe402537
    759a16403350:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16403355:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    759a1640335c:	94 01 01 00 
    759a16403360:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    759a16403367:	04 00 00 00 
    759a1640336b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    759a16403372:	05 00 00 00 
    759a16403376:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640337d:	64 00 00 
    759a16403380:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403385:	4c 89 f7             	mov    rdi,r14
    759a16403388:	ff d0                	call   rax
    759a1640338a:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403391:	00 
    759a16403392:	84 c9                	test   cl,cl
    759a16403394:	0f 85 3d 02 00 00    	jne    0x759a164035d7
    759a1640339a:	41 89 c7             	mov    r15d,eax
    759a1640339d:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164033a2:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a164033a7:	e9 aa f1 ff e7       	jmp    0x7599fe402556
    759a164033ac:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a164033b1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    759a164033b8:	98 01 01 00 
    759a164033bc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164033c3:	02 00 00 00 
    759a164033c7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a164033ce:	06 00 00 00 
    759a164033d2:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164033d9:	64 00 00 
    759a164033dc:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a164033e1:	4c 89 f7             	mov    rdi,r14
    759a164033e4:	ff d0                	call   rax
    759a164033e6:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164033ed:	00 
    759a164033ee:	84 c9                	test   cl,cl
    759a164033f0:	0f 85 c1 01 00 00    	jne    0x759a164035b7
    759a164033f6:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164033fb:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16403400:	e9 7e f1 ff e7       	jmp    0x7599fe402583
    759a16403405:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a1640340a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    759a16403411:	98 01 01 00 
    759a16403415:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a1640341c:	02 00 00 00 
    759a16403420:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16403427:	06 00 00 00 
    759a1640342b:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a16403432:	64 00 00 
    759a16403435:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a1640343a:	4c 89 f7             	mov    rdi,r14
    759a1640343d:	ff d0                	call   rax
    759a1640343f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a16403446:	00 
    759a16403447:	84 c9                	test   cl,cl
    759a16403449:	0f 85 68 01 00 00    	jne    0x759a164035b7
    759a1640344f:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403454:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16403459:	e9 47 f1 ff e7       	jmp    0x7599fe4025a5
    759a1640345e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16403463:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    759a1640346a:	98 01 01 00 
    759a1640346e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403475:	02 00 00 00 
    759a16403479:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16403480:	06 00 00 00 
    759a16403484:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640348b:	64 00 00 
    759a1640348e:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a16403493:	4c 89 f7             	mov    rdi,r14
    759a16403496:	ff d0                	call   rax
    759a16403498:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640349f:	00 
    759a164034a0:	84 c9                	test   cl,cl
    759a164034a2:	0f 85 0f 01 00 00    	jne    0x759a164035b7
    759a164034a8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164034ad:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a164034b2:	e9 10 f1 ff e7       	jmp    0x7599fe4025c7
    759a164034b7:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a164034bc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    759a164034c3:	98 01 01 00 
    759a164034c7:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a164034ce:	02 00 00 00 
    759a164034d2:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a164034d9:	06 00 00 00 
    759a164034dd:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a164034e4:	64 00 00 
    759a164034e7:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    759a164034ec:	4c 89 f7             	mov    rdi,r14
    759a164034ef:	ff d0                	call   rax
    759a164034f1:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164034f8:	00 
    759a164034f9:	84 c9                	test   cl,cl
    759a164034fb:	0f 85 b6 00 00 00    	jne    0x759a164035b7
    759a16403501:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a16403506:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a1640350b:	e9 d9 f0 ff e7       	jmp    0x7599fe4025e9
    759a16403510:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    759a16403515:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    759a1640351c:	98 01 01 00 
    759a16403520:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403527:	02 00 00 00 
    759a1640352b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    759a16403532:	06 00 00 00 
    759a16403536:	48 b8 f0 55 c0 d7 e7 	movabs rax,0x64e7d7c055f0
    759a1640353d:	64 00 00 
    759a16403540:	4d 89 f4             	mov    r12,r14
    759a16403543:	4c 89 f7             	mov    rdi,r14
    759a16403546:	ff d0                	call   rax
    759a16403548:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a1640354f:	00 
    759a16403550:	84 c9                	test   cl,cl
    759a16403552:	0f 85 92 00 00 00    	jne    0x759a164035ea
    759a16403558:	4d 89 e6             	mov    r14,r12
    759a1640355b:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a16403560:	e9 a6 f0 ff e7       	jmp    0x7599fe40260b
    759a16403565:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019a
    759a1640356c:	9a 01 01 00 
    759a16403570:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    759a16403577:	02 00 00 00 
    759a1640357b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    759a16403582:	07 00 00 00 
    759a16403586:	48 b8 d0 aa d1 d7 e7 	movabs rax,0x64e7d7d1aad0
    759a1640358d:	64 00 00 
    759a16403590:	4c 89 ef             	mov    rdi,r13
    759a16403593:	be 2a 00 00 00       	mov    esi,0x2a
    759a16403598:	4c 89 f2             	mov    rdx,r14
    759a1640359b:	4d 89 c7             	mov    r15,r8
    759a1640359e:	ff d0                	call   rax
    759a164035a0:	4d 89 f8             	mov    r8,r15
    759a164035a3:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164035aa:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    759a164035b1:	00 
    759a164035b2:	e9 75 f0 ff e7       	jmp    0x7599fe40262c
    759a164035b7:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164035be:	bb 02 00 00 00       	mov    ebx,0x2
    759a164035c3:	bd 06 00 00 00       	mov    ebp,0x6
    759a164035c8:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    759a164035cd:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    759a164035d2:	e9 55 f0 ff e7       	jmp    0x7599fe40262c
    759a164035d7:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164035de:	bb 04 00 00 00       	mov    ebx,0x4
    759a164035e3:	bd 05 00 00 00       	mov    ebp,0x5
    759a164035e8:	eb de                	jmp    0x759a164035c8
    759a164035ea:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    759a164035f1:	bb 02 00 00 00       	mov    ebx,0x2
    759a164035f6:	bd 06 00 00 00       	mov    ebp,0x6
    759a164035fb:	4d 89 e6             	mov    r14,r12
    759a164035fe:	eb cd                	jmp    0x759a164035cd
