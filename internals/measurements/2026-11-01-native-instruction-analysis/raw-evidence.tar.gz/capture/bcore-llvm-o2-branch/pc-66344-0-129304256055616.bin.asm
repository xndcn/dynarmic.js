
build-native-instruction-analysis/capture/bcore-llvm-o2-branch/pc-66344-0-129304256055616.bin:     file format binary


Disassembly of section .data:

00007599fe400940 <.data>:
    7599fe400940:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    7599fe400947:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    7599fe40094c:	ba 91 fc fe ff       	mov    edx,0xfffefc91
    7599fe400951:	41 8b b5 a0 00 00 00 	mov    esi,DWORD PTR [r13+0xa0]
    7599fe400958:	01 d6                	add    esi,edx
    7599fe40095a:	b1 01                	mov    cl,0x1
    7599fe40095c:	b8 65 01 00 00       	mov    eax,0x165
    7599fe400961:	83 fe b8             	cmp    esi,0xffffffb8
    7599fe400964:	0f 87 9b 06 00 00    	ja     0x7599fe401005
    7599fe40096a:	41 03 95 a4 00 00 00 	add    edx,DWORD PTR [r13+0xa4]
    7599fe400971:	83 fa b8             	cmp    edx,0xffffffb8
    7599fe400974:	0f 87 8b 06 00 00    	ja     0x7599fe401005
    7599fe40097a:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7599fe400981:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    7599fe400986:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    7599fe40098a:	45 8d 51 fc          	lea    r10d,[r9-0x4]
    7599fe40098e:	41 f6 c1 03          	test   r9b,0x3
    7599fe400992:	0f 85 a8 09 00 18    	jne    0x759a16401340
    7599fe400998:	4d 8b 9d 38 01 00 00 	mov    r11,QWORD PTR [r13+0x138]
    7599fe40099f:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    7599fe4009a6:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    7599fe4009ab:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7599fe4009af:	44 89 d7             	mov    edi,r10d
    7599fe4009b2:	c1 ef 0c             	shr    edi,0xc
    7599fe4009b5:	49 8b 04 fb          	mov    rax,QWORD PTR [r11+rdi*8]
    7599fe4009b9:	48 85 c0             	test   rax,rax
    7599fe4009bc:	0f 84 d4 09 00 18    	je     0x759a16401396
    7599fe4009c2:	44 89 d1             	mov    ecx,r10d
    7599fe4009c5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4009cb:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4009ce:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    7599fe4009d2:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7599fe4009d6:	89 e8                	mov    eax,ebp
    7599fe4009d8:	c1 e8 0c             	shr    eax,0xc
    7599fe4009db:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    7599fe4009e2:	00 
    7599fe4009e3:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe4009e7:	48 85 c0             	test   rax,rax
    7599fe4009ea:	0f 84 01 0a 00 18    	je     0x759a164013f1
    7599fe4009f0:	89 e9                	mov    ecx,ebp
    7599fe4009f2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe4009f8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe4009fb:	41 8d 71 f4          	lea    esi,[r9-0xc]
    7599fe4009ff:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    7599fe400a03:	89 f0                	mov    eax,esi
    7599fe400a05:	c1 e8 0c             	shr    eax,0xc
    7599fe400a08:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    7599fe400a0d:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400a11:	48 85 c0             	test   rax,rax
    7599fe400a14:	48 89 74 24 58       	mov    QWORD PTR [rsp+0x58],rsi
    7599fe400a19:	0f 84 36 0a 00 18    	je     0x759a16401455
    7599fe400a1f:	48 89 f1             	mov    rcx,rsi
    7599fe400a22:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400a28:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400a2b:	41 8d 71 f0          	lea    esi,[r9-0x10]
    7599fe400a2f:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    7599fe400a33:	89 f0                	mov    eax,esi
    7599fe400a35:	c1 e8 0c             	shr    eax,0xc
    7599fe400a38:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    7599fe400a3d:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400a41:	48 85 c0             	test   rax,rax
    7599fe400a44:	48 89 74 24 50       	mov    QWORD PTR [rsp+0x50],rsi
    7599fe400a49:	0f 84 68 0a 00 18    	je     0x759a164014b7
    7599fe400a4f:	48 89 f1             	mov    rcx,rsi
    7599fe400a52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400a58:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400a5b:	41 8d 71 ec          	lea    esi,[r9-0x14]
    7599fe400a5f:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    7599fe400a63:	89 f0                	mov    eax,esi
    7599fe400a65:	c1 e8 0c             	shr    eax,0xc
    7599fe400a68:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    7599fe400a6d:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400a71:	48 85 c0             	test   rax,rax
    7599fe400a74:	48 89 74 24 60       	mov    QWORD PTR [rsp+0x60],rsi
    7599fe400a79:	0f 84 9a 0a 00 18    	je     0x759a16401519
    7599fe400a7f:	89 f1                	mov    ecx,esi
    7599fe400a81:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400a87:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400a8a:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe400a8e:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
    7599fe400a93:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe400a97:	0f 85 e0 0a 00 18    	jne    0x759a1640157d
    7599fe400a9d:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7599fe400aa1:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    7599fe400aa8:	41 8d 71 e8          	lea    esi,[r9-0x18]
    7599fe400aac:	89 f0                	mov    eax,esi
    7599fe400aae:	c1 e8 0c             	shr    eax,0xc
    7599fe400ab1:	49 89 c6             	mov    r14,rax
    7599fe400ab4:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400ab8:	48 85 c0             	test   rax,rax
    7599fe400abb:	48 89 74 24 48       	mov    QWORD PTR [rsp+0x48],rsi
    7599fe400ac0:	0f 84 2e 0b 00 18    	je     0x759a164015f4
    7599fe400ac6:	48 89 f1             	mov    rcx,rsi
    7599fe400ac9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400acf:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7599fe400ad2:	45 8d 61 e4          	lea    r12d,[r9-0x1c]
    7599fe400ad6:	45 89 e7             	mov    r15d,r12d
    7599fe400ad9:	41 c1 ef 0c          	shr    r15d,0xc
    7599fe400add:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    7599fe400ae1:	48 85 c0             	test   rax,rax
    7599fe400ae4:	0f 84 80 0b 00 18    	je     0x759a1640166a
    7599fe400aea:	44 89 e1             	mov    ecx,r12d
    7599fe400aed:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7599fe400af3:	89 1c 08             	mov    DWORD PTR [rax+rcx*1],ebx
    7599fe400af6:	45 89 65 3c          	mov    DWORD PTR [r13+0x3c],r12d
    7599fe400afa:	45 89 65 38          	mov    DWORD PTR [r13+0x38],r12d
    7599fe400afe:	41 80 38 00          	cmp    BYTE PTR [r8],0x0
    7599fe400b02:	0f 85 de 0b 00 18    	jne    0x759a164016e6
    7599fe400b08:	41 8b 5d 00          	mov    ebx,DWORD PTR [r13+0x0]
    7599fe400b0c:	31 c0                	xor    eax,eax
    7599fe400b0e:	31 c9                	xor    ecx,ecx
    7599fe400b10:	31 d2                	xor    edx,edx
    7599fe400b12:	31 f6                	xor    esi,esi
    7599fe400b14:	83 fb 04             	cmp    ebx,0x4
    7599fe400b17:	0f 94 c0             	sete   al
    7599fe400b1a:	0f 92 c1             	setb   cl
    7599fe400b1d:	40 0f 96 c6          	setbe  sil
    7599fe400b21:	0f 93 c2             	setae  dl
    7599fe400b24:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    7599fe400b2b:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7599fe400b32:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe400b39:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7599fe400b40:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7599fe400b47:	0f 87 10 03 00 00    	ja     0x7599fe400e5d
    7599fe400b4d:	48 89 6c 24 20       	mov    QWORD PTR [rsp+0x20],rbp
    7599fe400b52:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
    7599fe400b56:	89 e8                	mov    eax,ebp
    7599fe400b58:	c1 e8 1f             	shr    eax,0x1f
    7599fe400b5b:	31 c9                	xor    ecx,ecx
    7599fe400b5d:	85 ed                	test   ebp,ebp
    7599fe400b5f:	0f 94 c1             	sete   cl
    7599fe400b62:	41 89 8d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ecx
    7599fe400b69:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    7599fe400b70:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7599fe400b77:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7599fe400b7e:	00 00 00 
    7599fe400b81:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7599fe400b88:	0f 84 34 03 00 00    	je     0x7599fe400ec2
    7599fe400b8e:	41 c7 45 0c 00 48 e8 	mov    DWORD PTR [r13+0xc],0x1e84800
    7599fe400b95:	01 
    7599fe400b96:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7599fe400b9d:	00 00 00 00 
    7599fe400ba1:	31 c0                	xor    eax,eax
    7599fe400ba3:	31 c9                	xor    ecx,ecx
    7599fe400ba5:	31 d2                	xor    edx,edx
    7599fe400ba7:	31 f6                	xor    esi,esi
    7599fe400ba9:	81 fd 00 48 e8 01    	cmp    ebp,0x1e84800
    7599fe400baf:	0f 94 c0             	sete   al
    7599fe400bb2:	0f 92 c1             	setb   cl
    7599fe400bb5:	40 0f 96 c6          	setbe  sil
    7599fe400bb9:	0f 93 c2             	setae  dl
    7599fe400bbc:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    7599fe400bc3:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    7599fe400bca:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7599fe400bd1:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7599fe400bd8:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7599fe400bdf:	0f 87 17 03 00 00    	ja     0x7599fe400efc
    7599fe400be5:	41 c7 45 28 f0 12 01 	mov    DWORD PTR [r13+0x28],0x112f0
    7599fe400bec:	00 
    7599fe400bed:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    7599fe400bf4:	48 85 c0             	test   rax,rax
    7599fe400bf7:	0f 84 89 0b 00 18    	je     0x759a16401786
    7599fe400bfd:	89 98 f0 02 00 00    	mov    DWORD PTR [rax+0x2f0],ebx
    7599fe400c03:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    7599fe400c08:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    7599fe400c0b:	0f 85 ed 0b 00 18    	jne    0x759a164017fe
    7599fe400c11:	41 c7 45 28 f4 12 01 	mov    DWORD PTR [r13+0x28],0x112f4
    7599fe400c18:	00 
    7599fe400c19:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    7599fe400c20:	48 85 c0             	test   rax,rax
    7599fe400c23:	0f 84 58 0c 00 18    	je     0x759a16401881
    7599fe400c29:	89 a8 f4 02 00 00    	mov    DWORD PTR [rax+0x2f4],ebp
    7599fe400c2f:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    7599fe400c32:	0f 85 bd 0c 00 18    	jne    0x759a164018f5
    7599fe400c38:	41 c7 45 28 f8 12 01 	mov    DWORD PTR [r13+0x28],0x112f8
    7599fe400c3f:	00 
    7599fe400c40:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    7599fe400c44:	49 8b 83 88 00 00 00 	mov    rax,QWORD PTR [r11+0x88]
    7599fe400c4b:	48 85 c0             	test   rax,rax
    7599fe400c4e:	0f 84 20 0d 00 18    	je     0x759a16401974
    7599fe400c54:	89 90 f8 02 00 00    	mov    DWORD PTR [rax+0x2f8],edx
    7599fe400c5a:	48 89 fd             	mov    rbp,rdi
    7599fe400c5d:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    7599fe400c60:	0f 85 80 0d 00 18    	jne    0x759a164019e6
    7599fe400c66:	8d 4b fe             	lea    ecx,[rbx-0x2]
    7599fe400c69:	89 ca                	mov    edx,ecx
    7599fe400c6b:	c1 ea 1f             	shr    edx,0x1f
    7599fe400c6e:	89 d8                	mov    eax,ebx
    7599fe400c70:	c1 e8 1f             	shr    eax,0x1f
    7599fe400c73:	09 c2                	or     edx,eax
    7599fe400c75:	31 f6                	xor    esi,esi
    7599fe400c77:	83 fb 02             	cmp    ebx,0x2
    7599fe400c7a:	40 0f 93 c6          	setae  sil
    7599fe400c7e:	31 ff                	xor    edi,edi
    7599fe400c80:	85 c9                	test   ecx,ecx
    7599fe400c82:	40 0f 94 c7          	sete   dil
    7599fe400c86:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    7599fe400c8d:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    7599fe400c94:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7599fe400c9b:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    7599fe400ca2:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    7599fe400ca9:	0f 84 8b 02 00 00    	je     0x7599fe400f3a
    7599fe400caf:	8d 4b fd             	lea    ecx,[rbx-0x3]
    7599fe400cb2:	89 ca                	mov    edx,ecx
    7599fe400cb4:	c1 ea 1f             	shr    edx,0x1f
    7599fe400cb7:	09 c2                	or     edx,eax
    7599fe400cb9:	31 c0                	xor    eax,eax
    7599fe400cbb:	83 fb 03             	cmp    ebx,0x3
    7599fe400cbe:	0f 93 c0             	setae  al
    7599fe400cc1:	31 f6                	xor    esi,esi
    7599fe400cc3:	85 c9                	test   ecx,ecx
    7599fe400cc5:	40 0f 94 c6          	sete   sil
    7599fe400cc9:	41 89 b5 14 01 00 00 	mov    DWORD PTR [r13+0x114],esi
    7599fe400cd0:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7599fe400cd7:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    7599fe400cde:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    7599fe400ce5:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    7599fe400cec:	0f 84 a4 02 00 00    	je     0x7599fe400f96
    7599fe400cf2:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7599fe400cf9:	00 
    7599fe400cfa:	4b 8b 04 fb          	mov    rax,QWORD PTR [r11+r15*8]
    7599fe400cfe:	48 85 c0             	test   rax,rax
    7599fe400d01:	0f 84 8d 0d 00 18    	je     0x759a16401a94
    7599fe400d07:	41 81 e4 ff 0f 00 00 	and    r12d,0xfff
    7599fe400d0e:	42 8b 1c 20          	mov    ebx,DWORD PTR [rax+r12*1]
    7599fe400d12:	48 89 e9             	mov    rcx,rbp
    7599fe400d15:	4b 8b 04 f3          	mov    rax,QWORD PTR [r11+r14*8]
    7599fe400d19:	48 85 c0             	test   rax,rax
    7599fe400d1c:	0f 84 d8 0d 00 18    	je     0x759a16401afa
    7599fe400d22:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    7599fe400d27:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe400d2d:	8b 3c 10             	mov    edi,DWORD PTR [rax+rdx*1]
    7599fe400d30:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7599fe400d34:	41 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],edi
    7599fe400d3b:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    7599fe400d40:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    7599fe400d44:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    7599fe400d49:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400d4d:	48 85 c0             	test   rax,rax
    7599fe400d50:	0f 84 0c 0e 00 18    	je     0x759a16401b62
    7599fe400d56:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7599fe400d5c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7599fe400d5f:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7599fe400d63:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    7599fe400d68:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400d6c:	48 85 c0             	test   rax,rax
    7599fe400d6f:	0f 84 53 0e 00 18    	je     0x759a16401bc8
    7599fe400d75:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
    7599fe400d7a:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe400d80:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe400d83:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7599fe400d87:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    7599fe400d8c:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400d90:	48 85 c0             	test   rax,rax
    7599fe400d93:	0f 84 9a 0e 00 18    	je     0x759a16401c33
    7599fe400d99:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
    7599fe400d9e:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe400da4:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe400da7:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7599fe400dab:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    7599fe400db2:	00 
    7599fe400db3:	49 8b 04 c3          	mov    rax,QWORD PTR [r11+rax*8]
    7599fe400db7:	48 85 c0             	test   rax,rax
    7599fe400dba:	0f 84 de 0e 00 18    	je     0x759a16401c9e
    7599fe400dc0:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    7599fe400dc5:	81 e2 ff 0f 00 00    	and    edx,0xfff
    7599fe400dcb:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    7599fe400dce:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    7599fe400dd2:	49 8b 04 cb          	mov    rax,QWORD PTR [r11+rcx*8]
    7599fe400dd6:	48 85 c0             	test   rax,rax
    7599fe400dd9:	0f 84 2a 0f 00 18    	je     0x759a16401d09
    7599fe400ddf:	41 81 e2 ff 0f 00 00 	and    r10d,0xfff
    7599fe400de6:	42 8b 04 10          	mov    eax,DWORD PTR [rax+r10*1]
    7599fe400dea:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    7599fe400dee:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    7599fe400df2:	b1 01                	mov    cl,0x1
    7599fe400df4:	bb 02 00 00 00       	mov    ebx,0x2
    7599fe400df9:	bd 1b 00 00 00       	mov    ebp,0x1b
    7599fe400dfe:	40 f6 c7 01          	test   dil,0x1
    7599fe400e02:	0f 85 53 0f 00 18    	jne    0x759a16401d5b
    7599fe400e08:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400e0f:	01 e8                	add    eax,ebp
    7599fe400e11:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    7599fe400e18:	39 d0                	cmp    eax,edx
    7599fe400e1a:	0f 83 3a 0c 00 18    	jae    0x759a16401a5a
    7599fe400e20:	8d 14 fd 00 00 00 00 	lea    edx,[rdi*8+0x0]
    7599fe400e27:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    7599fe400e2d:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    7599fe400e32:	39 3c 16             	cmp    DWORD PTR [rsi+rdx*1],edi
    7599fe400e35:	0f 85 1f 0c 00 18    	jne    0x759a16401a5a
    7599fe400e3b:	41 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edi
    7599fe400e42:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400e49:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7599fe400e50:	00 
    7599fe400e51:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7599fe400e56:	48 8b 44 10 08       	mov    rax,QWORD PTR [rax+rdx*1+0x8]
    7599fe400e5b:	eb 57                	jmp    0x7599fe400eb4
    7599fe400e5d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    7599fe400e64:	70 03 01 00 
    7599fe400e68:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400e6f:	83 c0 04             	add    eax,0x4
    7599fe400e72:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400e79:	39 c8                	cmp    eax,ecx
    7599fe400e7b:	0f 83 e9 08 00 18    	jae    0x759a1640176a
    7599fe400e81:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7599fe400e86:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    7599fe400e8d:	03 01 00 
    7599fe400e90:	0f 85 d4 08 00 18    	jne    0x759a1640176a
    7599fe400e96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    7599fe400e9d:	70 03 01 00 
    7599fe400ea1:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400ea8:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7599fe400ead:	48 8b 80 88 1b 08 00 	mov    rax,QWORD PTR [rax+0x81b88]
    7599fe400eb4:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    7599fe400eb9:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7599fe400ec0:	ff e0                	jmp    rax
    7599fe400ec2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    7599fe400ec9:	70 03 01 00 
    7599fe400ecd:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400ed4:	83 c0 06             	add    eax,0x6
    7599fe400ed7:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400ede:	39 c8                	cmp    eax,ecx
    7599fe400ee0:	0f 83 2c 04 00 18    	jae    0x759a16401312
    7599fe400ee6:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7599fe400eeb:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    7599fe400ef2:	03 01 00 
    7599fe400ef5:	74 9f                	je     0x7599fe400e96
    7599fe400ef7:	e9 16 04 00 18       	jmp    0x759a16401312
    7599fe400efc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    7599fe400f03:	70 03 01 00 
    7599fe400f07:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400f0e:	83 c0 0a             	add    eax,0xa
    7599fe400f11:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400f18:	39 c8                	cmp    eax,ecx
    7599fe400f1a:	0f 83 09 04 00 18    	jae    0x759a16401329
    7599fe400f20:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7599fe400f25:	81 b9 80 1b 08 00 70 	cmp    DWORD PTR [rcx+0x81b80],0x10370
    7599fe400f2c:	03 01 00 
    7599fe400f2f:	0f 84 61 ff ff ff    	je     0x7599fe400e96
    7599fe400f35:	e9 ef 03 00 18       	jmp    0x759a16401329
    7599fe400f3a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    7599fe400f41:	7a 03 01 00 
    7599fe400f45:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400f4c:	83 c0 15             	add    eax,0x15
    7599fe400f4f:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400f56:	39 c8                	cmp    eax,ecx
    7599fe400f58:	0f 83 08 0b 00 18    	jae    0x759a16401a66
    7599fe400f5e:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7599fe400f63:	81 b9 d0 1b 08 00 7a 	cmp    DWORD PTR [rcx+0x81bd0],0x1037a
    7599fe400f6a:	03 01 00 
    7599fe400f6d:	0f 85 f3 0a 00 18    	jne    0x759a16401a66
    7599fe400f73:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    7599fe400f7a:	7a 03 01 00 
    7599fe400f7e:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400f85:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7599fe400f8a:	48 8b 80 d8 1b 08 00 	mov    rax,QWORD PTR [rax+0x81bd8]
    7599fe400f91:	e9 1e ff ff ff       	jmp    0x7599fe400eb4
    7599fe400f96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    7599fe400f9d:	a4 03 01 00 
    7599fe400fa1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    7599fe400fa8:	83 c0 17             	add    eax,0x17
    7599fe400fab:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    7599fe400fb2:	39 c8                	cmp    eax,ecx
    7599fe400fb4:	0f 83 c3 0a 00 18    	jae    0x759a16401a7d
    7599fe400fba:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7599fe400fbf:	81 b9 20 1d 08 00 a4 	cmp    DWORD PTR [rcx+0x81d20],0x103a4
    7599fe400fc6:	03 01 00 
    7599fe400fc9:	0f 85 ae 0a 00 18    	jne    0x759a16401a7d
    7599fe400fcf:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    7599fe400fd6:	a4 03 01 00 
    7599fe400fda:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    7599fe400fe1:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7599fe400fe6:	48 8b 80 28 1d 08 00 	mov    rax,QWORD PTR [rax+0x81d28]
    7599fe400fed:	e9 c2 fe ff ff       	jmp    0x7599fe400eb4
    7599fe400ff2:	41 89 9d 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebx
    7599fe400ff9:	41 89 ad 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebp
    7599fe401000:	b8 28 01 00 00       	mov    eax,0x128
    7599fe401005:	41 88 4c 05 00       	mov    BYTE PTR [r13+rax*1+0x0],cl
    7599fe40100a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7599fe401011:	c2 08 00             	ret    0x8
