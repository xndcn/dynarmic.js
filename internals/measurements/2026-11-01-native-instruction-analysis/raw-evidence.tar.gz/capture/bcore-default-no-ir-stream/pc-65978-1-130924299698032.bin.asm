
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65978-1-130924299698032.bin:     file format binary


Disassembly of section .data:

0000771330603f70 <.data>:
    771330603f70:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330603f77:	8b 88 30 00 10 00    	mov    ecx,DWORD PTR [rax+0x100030]
    771330603f7d:	ff c1                	inc    ecx
    771330603f7f:	89 88 30 00 10 00    	mov    DWORD PTR [rax+0x100030],ecx
    771330603f85:	81 f9 c8 af 00 00    	cmp    ecx,0xafc8
    771330603f8b:	0f 84 5f 18 00 18    	je     0x7713486057f0
    771330603f91:	50                   	push   rax
    771330603f92:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    771330603f96:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603f9d:	31 d2                	xor    edx,edx
    771330603f9f:	41 23 45 08          	and    eax,DWORD PTR [r13+0x8]
    771330603fa3:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330603fa7:	0f 94 c2             	sete   dl
    771330603faa:	c1 e8 1f             	shr    eax,0x1f
    771330603fad:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330603fb4:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330603fbb:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    771330603fc2:	00 00 00 00 
    771330603fc6:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330603fcd:	00 00 00 00 
    771330603fd1:	81 f9 ba 01 01 00    	cmp    ecx,0x101ba
    771330603fd7:	0f 84 3f 18 00 18    	je     0x77134860581c
    771330603fdd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ba
    771330603fe4:	ba 01 01 00 
    771330603fe8:	0f 84 2e 18 00 18    	je     0x77134860581c
    771330603fee:	58                   	pop    rax
    771330603fef:	50                   	push   rax
    771330603ff0:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    771330603ff4:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603ffb:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330603fff:	81 f9 bc 01 01 00    	cmp    ecx,0x101bc
    771330604005:	0f 84 71 18 00 18    	je     0x77134860587c
    77133060400b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101bc
    771330604012:	bc 01 01 00 
    771330604016:	0f 84 60 18 00 18    	je     0x77134860587c
    77133060401c:	58                   	pop    rax
    77133060401d:	50                   	push   rax
    77133060401e:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330604022:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604029:	c1 e0 02             	shl    eax,0x2
    77133060402c:	41 03 45 20          	add    eax,DWORD PTR [r13+0x20]
    771330604030:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330604034:	81 f9 be 01 01 00    	cmp    ecx,0x101be
    77133060403a:	0f 84 9c 18 00 18    	je     0x7713486058dc
    771330604040:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101be
    771330604047:	be 01 01 00 
    77133060404b:	0f 84 8b 18 00 18    	je     0x7713486058dc
    771330604051:	58                   	pop    rax
    771330604052:	50                   	push   rax
    771330604053:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330604057:	f6 c1 03             	test   cl,0x3
    77133060405a:	0f 85 dc 18 00 18    	jne    0x77134860593c
    771330604060:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330604067:	48 89 ca             	mov    rdx,rcx
    77133060406a:	48 c1 ea 0c          	shr    rdx,0xc
    77133060406e:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330604072:	48 85 c0             	test   rax,rax
    771330604075:	0f 84 11 19 00 18    	je     0x77134860598c
    77133060407b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330604081:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330604084:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    771330604088:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c0
    77133060408f:	c0 01 01 00 
    771330604093:	0f 84 2e 19 00 18    	je     0x7713486059c7
    771330604099:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c0
    7713306040a0:	c0 01 01 00 
    7713306040a4:	0f 84 1d 19 00 18    	je     0x7713486059c7
    7713306040aa:	58                   	pop    rax
    7713306040ab:	50                   	push   rax
    7713306040ac:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    7713306040b0:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    7713306040b4:	89 c2                	mov    edx,eax
    7713306040b6:	c1 ea 1f             	shr    edx,0x1f
    7713306040b9:	89 ce                	mov    esi,ecx
    7713306040bb:	c1 ee 1f             	shr    esi,0x1f
    7713306040be:	31 ff                	xor    edi,edi
    7713306040c0:	01 c8                	add    eax,ecx
    7713306040c2:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    7713306040c6:	40 0f 92 c7          	setb   dil
    7713306040ca:	89 c1                	mov    ecx,eax
    7713306040cc:	c1 e9 1f             	shr    ecx,0x1f
    7713306040cf:	31 ce                	xor    esi,ecx
    7713306040d1:	31 ca                	xor    edx,ecx
    7713306040d3:	21 f2                	and    edx,esi
    7713306040d5:	31 f6                	xor    esi,esi
    7713306040d7:	85 c0                	test   eax,eax
    7713306040d9:	40 0f 94 c6          	sete   sil
    7713306040dd:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7713306040e4:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    7713306040eb:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    7713306040f2:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    7713306040f9:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    771330604100:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    771330604107:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    77133060410e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c2
    771330604115:	c2 01 01 00 
    771330604119:	0f 84 f1 18 00 18    	je     0x771348605a10
    77133060411f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c2
    771330604126:	c2 01 01 00 
    77133060412a:	0f 84 e0 18 00 18    	je     0x771348605a10
    771330604130:	58                   	pop    rax
    771330604131:	50                   	push   rax
    771330604132:	41 8b 85 0c 00 00 00 	mov    eax,DWORD PTR [r13+0xc]
    771330604139:	89 c1                	mov    ecx,eax
    77133060413b:	c1 e9 0b             	shr    ecx,0xb
    77133060413e:	41 89 8d 04 00 00 00 	mov    DWORD PTR [r13+0x4],ecx
    771330604145:	31 c9                	xor    ecx,ecx
    771330604147:	3d 00 08 00 00       	cmp    eax,0x800
    77133060414c:	0f 92 c1             	setb   cl
    77133060414f:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    771330604156:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    77133060415d:	00 00 00 00 
    771330604161:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330604168:	00 00 00 00 
    77133060416c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c4
    771330604173:	c4 01 01 00 
    771330604177:	0f 84 f3 18 00 18    	je     0x771348605a70
    77133060417d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c4
    771330604184:	c4 01 01 00 
    771330604188:	0f 84 e2 18 00 18    	je     0x771348605a70
    77133060418e:	58                   	pop    rax
    77133060418f:	50                   	push   rax
    771330604190:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    771330604194:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    77133060419b:	31 d2                	xor    edx,edx
    77133060419d:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    7713306041a1:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7713306041a5:	0f 94 c2             	sete   dl
    7713306041a8:	c1 e8 1f             	shr    eax,0x1f
    7713306041ab:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306041b2:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7713306041b9:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7713306041c0:	00 00 00 00 
    7713306041c4:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7713306041cb:	00 00 00 00 
    7713306041cf:	81 f9 c8 01 01 00    	cmp    ecx,0x101c8
    7713306041d5:	0f 84 f5 18 00 18    	je     0x771348605ad0
    7713306041db:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c8
    7713306041e2:	c8 01 01 00 
    7713306041e6:	0f 84 e4 18 00 18    	je     0x771348605ad0
    7713306041ec:	58                   	pop    rax
    7713306041ed:	50                   	push   rax
    7713306041ee:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7713306041f2:	f6 c1 03             	test   cl,0x3
    7713306041f5:	0f 85 35 19 00 18    	jne    0x771348605b30
    7713306041fb:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330604202:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    771330604206:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    77133060420d:	48 89 ce             	mov    rsi,rcx
    771330604210:	48 c1 ee 0c          	shr    rsi,0xc
    771330604214:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330604218:	48 85 c0             	test   rax,rax
    77133060421b:	0f 84 62 19 00 18    	je     0x771348605b83
    771330604221:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330604227:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    77133060422a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ca
    771330604231:	ca 01 01 00 
    771330604235:	0f 84 83 19 00 18    	je     0x771348605bbe
    77133060423b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ca
    771330604242:	ca 01 01 00 
    771330604246:	0f 84 72 19 00 18    	je     0x771348605bbe
    77133060424c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    77133060424f:	0f 85 aa 19 00 18    	jne    0x771348605bff
    771330604255:	58                   	pop    rax
    771330604256:	e9 0f 00 00 00       	jmp    0x77133060426a
    77133060425b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330604262:	00 
    771330604263:	74 f0                	je     0x771330604255
    771330604265:	e9 fd 18 00 18       	jmp    0x771348605b67
    77133060426a:	50                   	push   rax
    77133060426b:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    77133060426f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604276:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    77133060427a:	81 f9 cc 01 01 00    	cmp    ecx,0x101cc
    771330604280:	0f 84 ab 19 00 18    	je     0x771348605c31
    771330604286:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101cc
    77133060428d:	cc 01 01 00 
    771330604291:	0f 84 9a 19 00 18    	je     0x771348605c31
    771330604297:	58                   	pop    rax
    771330604298:	50                   	push   rax
    771330604299:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    77133060429d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306042a4:	31 d2                	xor    edx,edx
    7713306042a6:	89 c6                	mov    esi,eax
    7713306042a8:	ff c6                	inc    esi
    7713306042aa:	0f 94 c2             	sete   dl
    7713306042ad:	41 89 75 08          	mov    DWORD PTR [r13+0x8],esi
    7713306042b1:	c1 e8 1f             	shr    eax,0x1f
    7713306042b4:	89 f7                	mov    edi,esi
    7713306042b6:	c1 ef 1f             	shr    edi,0x1f
    7713306042b9:	f7 d0                	not    eax
    7713306042bb:	21 f8                	and    eax,edi
    7713306042bd:	31 db                	xor    ebx,ebx
    7713306042bf:	85 f6                	test   esi,esi
    7713306042c1:	0f 94 c3             	sete   bl
    7713306042c4:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7713306042cb:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7713306042d2:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7713306042d9:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7713306042e0:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    7713306042e7:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7713306042ee:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7713306042f5:	81 f9 ce 01 01 00    	cmp    ecx,0x101ce
    7713306042fb:	0f 84 90 19 00 18    	je     0x771348605c91
    771330604301:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ce
    771330604308:	ce 01 01 00 
    77133060430c:	0f 84 7f 19 00 18    	je     0x771348605c91
    771330604312:	58                   	pop    rax
    771330604313:	50                   	push   rax
    771330604314:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330604318:	41 8b 4d 08          	mov    ecx,DWORD PTR [r13+0x8]
    77133060431c:	31 d2                	xor    edx,edx
    77133060431e:	31 f6                	xor    esi,esi
    771330604320:	31 ff                	xor    edi,edi
    771330604322:	31 db                	xor    ebx,ebx
    771330604324:	39 c8                	cmp    eax,ecx
    771330604326:	0f 96 c2             	setbe  dl
    771330604329:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330604330:	40 0f 94 c6          	sete   sil
    771330604334:	40 0f 92 c7          	setb   dil
    771330604338:	0f 93 c3             	setae  bl
    77133060433b:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    771330604342:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    771330604349:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    771330604350:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    771330604357:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d0
    77133060435e:	d0 01 01 00 
    771330604362:	0f 84 89 19 00 18    	je     0x771348605cf1
    771330604368:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d0
    77133060436f:	d0 01 01 00 
    771330604373:	0f 84 78 19 00 18    	je     0x771348605cf1
    771330604379:	58                   	pop    rax
    77133060437a:	50                   	push   rax
    77133060437b:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    77133060437f:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604386:	41 01 45 24          	add    DWORD PTR [r13+0x24],eax
    77133060438a:	81 f9 d2 01 01 00    	cmp    ecx,0x101d2
    771330604390:	0f 84 bb 19 00 18    	je     0x771348605d51
    771330604396:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d2
    77133060439d:	d2 01 01 00 
    7713306043a1:	0f 84 aa 19 00 18    	je     0x771348605d51
    7713306043a7:	58                   	pop    rax
    7713306043a8:	50                   	push   rax
    7713306043a9:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7713306043b0:	00 
    7713306043b1:	74 28                	je     0x7713306043db
    7713306043b3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d4
    7713306043ba:	d4 01 01 00 
    7713306043be:	0f 84 ed 19 00 18    	je     0x771348605db1
    7713306043c4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d4
    7713306043cb:	d4 01 01 00 
    7713306043cf:	0f 84 dc 19 00 18    	je     0x771348605db1
    7713306043d5:	58                   	pop    rax
    7713306043d6:	e9 55 00 00 00       	jmp    0x771330604430
    7713306043db:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7713306043e2:	01 
    7713306043e3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d4
    7713306043ea:	d4 01 01 00 
    7713306043ee:	0f 84 06 1a 00 18    	je     0x771348605dfa
    7713306043f4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d4
    7713306043fb:	d4 01 01 00 
    7713306043ff:	0f 84 f5 19 00 18    	je     0x771348605dfa
    771330604405:	b8 d4 01 01 00       	mov    eax,0x101d4
    77133060440a:	83 c0 e6             	add    eax,0xffffffe6
    77133060440d:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330604414:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060441b:	02 00 00 00 
    77133060441f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xd
    771330604426:	0d 00 00 00 
    77133060442a:	58                   	pop    rax
    77133060442b:	e9 92 03 00 00       	jmp    0x7713306047c2
    771330604430:	50                   	push   rax
    771330604431:	41 c7 45 04 ff 1f 00 	mov    DWORD PTR [r13+0x4],0x1fff
    771330604438:	00 
    771330604439:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d6
    771330604440:	d6 01 01 00 
    771330604444:	0f 84 ec 19 00 18    	je     0x771348605e36
    77133060444a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d6
    771330604451:	d6 01 01 00 
    771330604455:	0f 84 db 19 00 18    	je     0x771348605e36
    77133060445b:	58                   	pop    rax
    77133060445c:	50                   	push   rax
    77133060445d:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330604461:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604468:	31 d2                	xor    edx,edx
    77133060446a:	89 c6                	mov    esi,eax
    77133060446c:	83 c6 ff             	add    esi,0xffffffff
    77133060446f:	0f 92 c2             	setb   dl
    771330604472:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    771330604476:	c1 e8 1f             	shr    eax,0x1f
    771330604479:	89 f7                	mov    edi,esi
    77133060447b:	c1 ef 1f             	shr    edi,0x1f
    77133060447e:	89 fb                	mov    ebx,edi
    771330604480:	f7 d3                	not    ebx
    771330604482:	21 c3                	and    ebx,eax
    771330604484:	31 c0                	xor    eax,eax
    771330604486:	85 f6                	test   esi,esi
    771330604488:	0f 94 c0             	sete   al
    77133060448b:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    771330604492:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    771330604499:	41 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebx
    7713306044a0:	41 89 9d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebx
    7713306044a7:	41 09 9d 00 01 00 00 	or     DWORD PTR [r13+0x100],ebx
    7713306044ae:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7713306044b5:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    7713306044bc:	81 f9 da 01 01 00    	cmp    ecx,0x101da
    7713306044c2:	0f 84 ce 19 00 18    	je     0x771348605e96
    7713306044c8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101da
    7713306044cf:	da 01 01 00 
    7713306044d3:	0f 84 bd 19 00 18    	je     0x771348605e96
    7713306044d9:	58                   	pop    rax
    7713306044da:	50                   	push   rax
    7713306044db:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7713306044df:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306044e6:	31 d2                	xor    edx,edx
    7713306044e8:	41 23 45 00          	and    eax,DWORD PTR [r13+0x0]
    7713306044ec:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7713306044f0:	0f 94 c2             	sete   dl
    7713306044f3:	c1 e8 1f             	shr    eax,0x1f
    7713306044f6:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306044fd:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330604504:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    77133060450b:	00 00 00 00 
    77133060450f:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330604516:	00 00 00 00 
    77133060451a:	81 f9 dc 01 01 00    	cmp    ecx,0x101dc
    771330604520:	0f 84 d0 19 00 18    	je     0x771348605ef6
    771330604526:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101dc
    77133060452d:	dc 01 01 00 
    771330604531:	0f 84 bf 19 00 18    	je     0x771348605ef6
    771330604537:	58                   	pop    rax
    771330604538:	50                   	push   rax
    771330604539:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    77133060453d:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604544:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330604548:	81 f9 de 01 01 00    	cmp    ecx,0x101de
    77133060454e:	0f 84 02 1a 00 18    	je     0x771348605f56
    771330604554:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101de
    77133060455b:	de 01 01 00 
    77133060455f:	0f 84 f1 19 00 18    	je     0x771348605f56
    771330604565:	58                   	pop    rax
    771330604566:	50                   	push   rax
    771330604567:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    77133060456b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604572:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330604576:	81 f9 e0 01 01 00    	cmp    ecx,0x101e0
    77133060457c:	0f 84 34 1a 00 18    	je     0x771348605fb6
    771330604582:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e0
    771330604589:	e0 01 01 00 
    77133060458d:	0f 84 23 1a 00 18    	je     0x771348605fb6
    771330604593:	58                   	pop    rax
    771330604594:	50                   	push   rax
    771330604595:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    771330604599:	f6 c3 03             	test   bl,0x3
    77133060459c:	0f 85 74 1a 00 18    	jne    0x771348606016
    7713306045a2:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7713306045a9:	48 89 d8             	mov    rax,rbx
    7713306045ac:	48 c1 e8 0c          	shr    rax,0xc
    7713306045b0:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306045b5:	48 85 c0             	test   rax,rax
    7713306045b8:	0f 84 aa 1a 00 18    	je     0x771348606068
    7713306045be:	89 d9                	mov    ecx,ebx
    7713306045c0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306045c6:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7713306045ca:	89 de                	mov    esi,ebx
    7713306045cc:	83 c6 04             	add    esi,0x4
    7713306045cf:	89 f0                	mov    eax,esi
    7713306045d1:	c1 e8 0c             	shr    eax,0xc
    7713306045d4:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306045d9:	48 85 c0             	test   rax,rax
    7713306045dc:	0f 84 c3 1a 00 18    	je     0x7713486060a5
    7713306045e2:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7713306045e8:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7713306045eb:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7713306045ee:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7713306045f2:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7713306045f9:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7713306045fd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101e2
    771330604604:	e2 01 01 00 
    771330604608:	0f 84 d3 1a 00 18    	je     0x7713486060e1
    77133060460e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e2
    771330604615:	e2 01 01 00 
    771330604619:	0f 84 c2 1a 00 18    	je     0x7713486060e1
    77133060461f:	58                   	pop    rax
    771330604620:	50                   	push   rax
    771330604621:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330604625:	f6 c3 03             	test   bl,0x3
    771330604628:	0f 85 fc 1a 00 18    	jne    0x77134860612a
    77133060462e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330604635:	48 89 d9             	mov    rcx,rbx
    771330604638:	48 c1 e9 0c          	shr    rcx,0xc
    77133060463c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    771330604640:	48 85 c0             	test   rax,rax
    771330604643:	0f 84 33 1b 00 18    	je     0x77134860617c
    771330604649:	89 d9                	mov    ecx,ebx
    77133060464b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330604651:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330604654:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330604658:	83 c3 04             	add    ebx,0x4
    77133060465b:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    77133060465f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101e6
    771330604666:	e6 01 01 00 
    77133060466a:	0f 84 47 1b 00 18    	je     0x7713486061b7
    771330604670:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e6
    771330604677:	e6 01 01 00 
    77133060467b:	0f 84 36 1b 00 18    	je     0x7713486061b7
    771330604681:	58                   	pop    rax
    771330604682:	50                   	push   rax
    771330604683:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330604687:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    77133060468e:	c1 e0 02             	shl    eax,0x2
    771330604691:	41 01 45 20          	add    DWORD PTR [r13+0x20],eax
    771330604695:	81 f9 e8 01 01 00    	cmp    ecx,0x101e8
    77133060469b:	0f 84 5f 1b 00 18    	je     0x771348606200
    7713306046a1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e8
    7713306046a8:	e8 01 01 00 
    7713306046ac:	0f 84 4e 1b 00 18    	je     0x771348606200
    7713306046b2:	58                   	pop    rax
    7713306046b3:	50                   	push   rax
    7713306046b4:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    7713306046b8:	f6 c1 03             	test   cl,0x3
    7713306046bb:	0f 85 9f 1b 00 18    	jne    0x771348606260
    7713306046c1:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306046c8:	48 89 ca             	mov    rdx,rcx
    7713306046cb:	48 c1 ea 0c          	shr    rdx,0xc
    7713306046cf:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7713306046d3:	48 85 c0             	test   rax,rax
    7713306046d6:	0f 84 d4 1b 00 18    	je     0x7713486062b0
    7713306046dc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306046e2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7713306046e5:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    7713306046e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ea
    7713306046f0:	ea 01 01 00 
    7713306046f4:	0f 84 f1 1b 00 18    	je     0x7713486062eb
    7713306046fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ea
    771330604701:	ea 01 01 00 
    771330604705:	0f 84 e0 1b 00 18    	je     0x7713486062eb
    77133060470b:	58                   	pop    rax
    77133060470c:	50                   	push   rax
    77133060470d:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330604711:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330604718:	31 d2                	xor    edx,edx
    77133060471a:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    77133060471e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330604722:	0f 94 c2             	sete   dl
    771330604725:	c1 e8 1f             	shr    eax,0x1f
    771330604728:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    77133060472f:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330604736:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    77133060473d:	00 00 00 00 
    771330604741:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330604748:	00 00 00 00 
    77133060474c:	81 f9 ec 01 01 00    	cmp    ecx,0x101ec
    771330604752:	0f 84 dc 1b 00 18    	je     0x771348606334
    771330604758:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ec
    77133060475f:	ec 01 01 00 
    771330604763:	0f 84 cb 1b 00 18    	je     0x771348606334
    771330604769:	58                   	pop    rax
    77133060476a:	50                   	push   rax
    77133060476b:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330604772:	a8 01                	test   al,0x1
    771330604774:	0f 85 1a 1c 00 18    	jne    0x771348606394
    77133060477a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330604781:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330604788:	01 
    771330604789:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ee
    771330604790:	ee 01 01 00 
    771330604794:	0f 84 30 1c 00 18    	je     0x7713486063ca
    77133060479a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ee
    7713306047a1:	ee 01 01 00 
    7713306047a5:	0f 84 1f 1c 00 18    	je     0x7713486063ca
    7713306047ab:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7713306047b2:	02 00 00 00 
    7713306047b6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x18
    7713306047bd:	18 00 00 00 
    7713306047c1:	58                   	pop    rax
    7713306047c2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306047c9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7713306047d0:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7713306047d7:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7713306047de:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7713306047e5:	39 f1                	cmp    ecx,esi
    7713306047e7:	0f 83 0a 1c 00 18    	jae    0x7713486063f7
    7713306047ed:	81 fa ba 01 01 00    	cmp    edx,0x101ba
    7713306047f3:	75 14                	jne    0x771330604809
    7713306047f5:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306047fc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330604803:	00 
    771330604804:	e9 67 f7 ff ff       	jmp    0x771330603f70
    771330604809:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330604810:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330604816:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330604819:	0f 85 d8 1b 00 18    	jne    0x7713486063f7
    77133060481f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330604826:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060482d:	00 
    77133060482e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330604833:	ff e0                	jmp    rax
