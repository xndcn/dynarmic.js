
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65536-1-130924299682576.bin:     file format binary


Disassembly of section .data:

0000771330600310 <.data>:
    771330600310:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330600317:	8b 88 00 00 10 00    	mov    ecx,DWORD PTR [rax+0x100000]
    77133060031d:	ff c1                	inc    ecx
    77133060031f:	89 88 00 00 10 00    	mov    DWORD PTR [rax+0x100000],ecx
    771330600325:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060032b:	0f 84 cf fc ff 17    	je     0x771348600000
    771330600331:	50                   	push   rax
    771330600332:	41 83 45 38 f4       	add    DWORD PTR [r13+0x38],0xfffffff4
    771330600337:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10000
    77133060033e:	00 00 01 00 
    771330600342:	0f 84 e4 fc ff 17    	je     0x77134860002c
    771330600348:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10000
    77133060034f:	00 00 01 00 
    771330600353:	0f 84 d3 fc ff 17    	je     0x77134860002c
    771330600359:	58                   	pop    rax
    77133060035a:	50                   	push   rax
    77133060035b:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    771330600362:	b9 02 00 01 00       	mov    ecx,0x10002
    771330600367:	83 c1 04             	add    ecx,0x4
    77133060036a:	89 ca                	mov    edx,ecx
    77133060036c:	3d 02 00 01 00       	cmp    eax,0x10002
    771330600371:	75 07                	jne    0x77133060037a
    771330600373:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    77133060037a:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    771330600381:	02 
    771330600382:	0f 43 ca             	cmovae ecx,edx
    771330600385:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    77133060038c:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    771330600393:	89 cf                	mov    edi,ecx
    771330600395:	81 fa 02 00 01 00    	cmp    edx,0x10002
    77133060039b:	75 07                	jne    0x7713306003a4
    77133060039d:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7713306003a4:	83 fe 02             	cmp    esi,0x2
    7713306003a7:	0f 43 cf             	cmovae ecx,edi
    7713306003aa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    7713306003b1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7713306003b8:	01 
    7713306003b9:	3d 02 00 01 00       	cmp    eax,0x10002
    7713306003be:	0f 84 c8 fc ff 17    	je     0x77134860008c
    7713306003c4:	81 fa 02 00 01 00    	cmp    edx,0x10002
    7713306003ca:	0f 84 bc fc ff 17    	je     0x77134860008c
    7713306003d0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    7713306003d7:	14 00 01 00 
    7713306003db:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7713306003e2:	04 00 00 00 
    7713306003e6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7713306003ed:	02 00 00 00 
    7713306003f1:	58                   	pop    rax
    7713306003f2:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306003f9:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330600400:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330600407:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060040e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330600415:	39 f1                	cmp    ecx,esi
    771330600417:	0f 83 a7 fc ff 17    	jae    0x7713486000c4
    77133060041d:	81 fa 00 00 01 00    	cmp    edx,0x10000
    771330600423:	75 14                	jne    0x771330600439
    771330600425:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    77133060042c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330600433:	00 
    771330600434:	e9 d7 fe ff ff       	jmp    0x771330600310
    771330600439:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330600440:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330600446:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330600449:	0f 85 75 fc ff 17    	jne    0x7713486000c4
    77133060044f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330600456:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060045d:	00 
    77133060045e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330600463:	ff e0                	jmp    rax
