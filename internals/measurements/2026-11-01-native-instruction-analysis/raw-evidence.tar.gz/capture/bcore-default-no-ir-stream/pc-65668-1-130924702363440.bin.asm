
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65668-1-130924702363440.bin:     file format binary


Disassembly of section .data:

0000771348606f30 <.data>:
    771348606f30:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    771348606f37:	84 00 01 00 
    771348606f3b:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    771348606f42:	01 
    771348606f43:	c2 08 00             	ret    0x8
    771348606f46:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    771348606f4c:	8d 51 01             	lea    edx,[rcx+0x1]
    771348606f4f:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    771348606f55:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    771348606f5c:	0f 87 98 ef ff e7    	ja     0x771330605efa
    771348606f62:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0xe
    771348606f69:	0e 00 00 00 
    771348606f6d:	e9 88 ef ff e7       	jmp    0x771330605efa
    771348606f72:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    771348606f79:	84 00 01 00 
    771348606f7d:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    771348606f84:	08 00 00 00 
    771348606f88:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    771348606f8f:	01 00 00 00 
    771348606f93:	ba 84 00 01 00       	mov    edx,0x10084
    771348606f98:	4c 89 ef             	mov    rdi,r13
    771348606f9b:	4c 89 f6             	mov    rsi,r14
    771348606f9e:	45 31 c0             	xor    r8d,r8d
    771348606fa1:	e8 da 90 ff e7       	call   0x771330600080
    771348606fa6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    771348606fad:	08 00 00 00 
    771348606fb1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    771348606fb8:	01 00 00 00 
    771348606fbc:	58                   	pop    rax
    771348606fbd:	e9 7c f0 ff e7       	jmp    0x77133060603e
    771348606fc2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    771348606fc9:	84 00 01 00 
    771348606fcd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x8
    771348606fd4:	08 00 00 00 
    771348606fd8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    771348606fdf:	01 00 00 00 
    771348606fe3:	4c 89 f7             	mov    rdi,r14
    771348606fe6:	89 ce                	mov    esi,ecx
    771348606fe8:	e8 53 90 ff e7       	call   0x771330600040
    771348606fed:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348606ff4:	00 
    771348606ff5:	0f 84 31 ef ff e7    	je     0x771330605f2c
    771348606ffb:	eb a9                	jmp    0x771348606fa6
    771348606ffd:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    771348607004:	8c 00 01 00 
    771348607008:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77134860700f:	02 00 00 00 
    771348607013:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    77134860701a:	02 00 00 00 
    77134860701e:	ba 8c 00 01 00       	mov    edx,0x1008c
    771348607023:	4c 89 ef             	mov    rdi,r13
    771348607026:	4c 89 f6             	mov    rsi,r14
    771348607029:	45 31 c0             	xor    r8d,r8d
    77134860702c:	e8 4f 90 ff e7       	call   0x771330600080
    771348607031:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348607038:	02 00 00 00 
    77134860703c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348607043:	02 00 00 00 
    771348607047:	58                   	pop    rax
    771348607048:	e9 f1 ef ff e7       	jmp    0x77133060603e
    77134860704d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    771348607054:	8c 00 01 00 
    771348607058:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77134860705f:	02 00 00 00 
    771348607063:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    77134860706a:	02 00 00 00 
    77134860706e:	4c 89 f7             	mov    rdi,r14
    771348607071:	89 ce                	mov    esi,ecx
    771348607073:	e8 c8 8f ff e7       	call   0x771330600040
    771348607078:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77134860707f:	00 
    771348607080:	0f 84 f9 ee ff e7    	je     0x771330605f7f
    771348607086:	eb a9                	jmp    0x771348607031
    771348607088:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1008c
    77134860708f:	8c 00 01 00 
    771348607093:	b8 8c 00 01 00       	mov    eax,0x1008c
    771348607098:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77134860709f:	02 00 00 00 
    7713486070a3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    7713486070aa:	02 00 00 00 
    7713486070ae:	8d 50 02             	lea    edx,[rax+0x2]
    7713486070b1:	be 8c 00 01 00       	mov    esi,0x1008c
    7713486070b6:	4c 89 ef             	mov    rdi,r13
    7713486070b9:	e8 a2 90 ff e7       	call   0x771330600160
    7713486070be:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713486070c5:	00 
    7713486070c6:	0f 84 d9 ee ff e7    	je     0x771330605fa5
    7713486070cc:	e9 60 ff ff ff       	jmp    0x771348607031
    7713486070d1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    7713486070d8:	28 03 01 00 
    7713486070dc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7713486070e3:	04 00 00 00 
    7713486070e7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7713486070ee:	03 00 00 00 
    7713486070f2:	be 8e 00 01 00       	mov    esi,0x1008e
    7713486070f7:	ba 8e 00 01 00       	mov    edx,0x1008e
    7713486070fc:	4c 89 ef             	mov    rdi,r13
    7713486070ff:	e8 5c 90 ff e7       	call   0x771330600160
    771348607104:	e9 13 ef ff e7       	jmp    0x77133060601c
    771348607109:	c2 08 00             	ret    0x8
