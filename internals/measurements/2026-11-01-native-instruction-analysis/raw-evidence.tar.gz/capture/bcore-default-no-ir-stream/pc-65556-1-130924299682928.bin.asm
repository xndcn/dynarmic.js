
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65556-1-130924299682928.bin:     file format binary


Disassembly of section .data:

0000771330600470 <.data>:
    771330600470:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330600477:	8b 88 04 00 10 00    	mov    ecx,DWORD PTR [rax+0x100004]
    77133060047d:	ff c1                	inc    ecx
    77133060047f:	89 88 04 00 10 00    	mov    DWORD PTR [rax+0x100004],ecx
    771330600485:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060048b:	0f 84 3f fc ff 17    	je     0x7713486000d0
    771330600491:	50                   	push   rax
    771330600492:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330600496:	8d 4b fc             	lea    ecx,[rbx-0x4]
    771330600499:	f6 c3 03             	test   bl,0x3
    77133060049c:	0f 85 5a fc ff 17    	jne    0x7713486000fc
    7713306004a2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7713306004a9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7713306004b0:	41 8b 55 10          	mov    edx,DWORD PTR [r13+0x10]
    7713306004b4:	89 c8                	mov    eax,ecx
    7713306004b6:	c1 e8 0c             	shr    eax,0xc
    7713306004b9:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306004be:	48 85 c0             	test   rax,rax
    7713306004c1:	0f 84 88 fc ff 17    	je     0x77134860014f
    7713306004c7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306004cd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7713306004d0:	8d 73 f8             	lea    esi,[rbx-0x8]
    7713306004d3:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7713306004d7:	89 f0                	mov    eax,esi
    7713306004d9:	c1 e8 0c             	shr    eax,0xc
    7713306004dc:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306004e1:	48 85 c0             	test   rax,rax
    7713306004e4:	0f 84 a0 fc ff 17    	je     0x77134860018a
    7713306004ea:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7713306004f0:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    7713306004f3:	8d 73 f4             	lea    esi,[rbx-0xc]
    7713306004f6:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    7713306004fa:	89 f0                	mov    eax,esi
    7713306004fc:	c1 e8 0c             	shr    eax,0xc
    7713306004ff:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600504:	48 85 c0             	test   rax,rax
    771330600507:	0f 84 b9 fc ff 17    	je     0x7713486001c6
    77133060050d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600513:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    771330600516:	8d 73 f0             	lea    esi,[rbx-0x10]
    771330600519:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    77133060051d:	89 f0                	mov    eax,esi
    77133060051f:	c1 e8 0c             	shr    eax,0xc
    771330600522:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600527:	48 85 c0             	test   rax,rax
    77133060052a:	0f 84 d2 fc ff 17    	je     0x771348600202
    771330600530:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600536:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    771330600539:	8d 73 ec             	lea    esi,[rbx-0x14]
    77133060053c:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    771330600540:	89 f0                	mov    eax,esi
    771330600542:	c1 e8 0c             	shr    eax,0xc
    771330600545:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060054a:	48 85 c0             	test   rax,rax
    77133060054d:	0f 84 eb fc ff 17    	je     0x77134860023e
    771330600553:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600559:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    77133060055c:	8d 73 e8             	lea    esi,[rbx-0x18]
    77133060055f:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    771330600563:	89 f0                	mov    eax,esi
    771330600565:	c1 e8 0c             	shr    eax,0xc
    771330600568:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060056d:	48 85 c0             	test   rax,rax
    771330600570:	0f 84 04 fd ff 17    	je     0x77134860027a
    771330600576:	81 e6 ff 0f 00 00    	and    esi,0xfff
    77133060057c:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    77133060057f:	83 c3 e4             	add    ebx,0xffffffe4
    771330600582:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    771330600586:	89 d8                	mov    eax,ebx
    771330600588:	c1 e8 0c             	shr    eax,0xc
    77133060058b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600590:	48 85 c0             	test   rax,rax
    771330600593:	0f 84 1d fd ff 17    	je     0x7713486002b6
    771330600599:	89 d9                	mov    ecx,ebx
    77133060059b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306005a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7713306005a4:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7713306005a8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10014
    7713306005af:	14 00 01 00 
    7713306005b3:	0f 84 3b fd ff 17    	je     0x7713486002f4
    7713306005b9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10014
    7713306005c0:	14 00 01 00 
    7713306005c4:	0f 84 2a fd ff 17    	je     0x7713486002f4
    7713306005ca:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7713306005ce:	0f 85 62 fd ff 17    	jne    0x771348600336
    7713306005d4:	58                   	pop    rax
    7713306005d5:	e9 0f 00 00 00       	jmp    0x7713306005e9
    7713306005da:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306005e1:	00 
    7713306005e2:	74 f0                	je     0x7713306005d4
    7713306005e4:	e9 4a fb ff 17       	jmp    0x771348600133
    7713306005e9:	50                   	push   rax
    7713306005ea:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7713306005ef:	b9 00 00 00 00       	mov    ecx,0x0
    7713306005f4:	09 c1                	or     ecx,eax
    7713306005f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306005fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10016
    771330600601:	16 00 01 00 
    771330600605:	0f 84 5d fd ff 17    	je     0x771348600368
    77133060060b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10016
    771330600612:	16 00 01 00 
    771330600616:	0f 84 4c fd ff 17    	je     0x771348600368
    77133060061c:	58                   	pop    rax
    77133060061d:	50                   	push   rax
    77133060061e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330600622:	8d 4b fc             	lea    ecx,[rbx-0x4]
    771330600625:	f6 c3 03             	test   bl,0x3
    771330600628:	0f 85 9a fd ff 17    	jne    0x7713486003c8
    77133060062e:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    771330600635:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    77133060063c:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    771330600640:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    771330600647:	89 c8                	mov    eax,ecx
    771330600649:	c1 e8 0c             	shr    eax,0xc
    77133060064c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600651:	48 85 c0             	test   rax,rax
    771330600654:	0f 84 c1 fd ff 17    	je     0x77134860041b
    77133060065a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600660:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330600663:	83 c3 f8             	add    ebx,0xfffffff8
    771330600666:	89 d8                	mov    eax,ebx
    771330600668:	c1 e8 0c             	shr    eax,0xc
    77133060066b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600670:	48 85 c0             	test   rax,rax
    771330600673:	0f 84 dd fd ff 17    	je     0x771348600456
    771330600679:	89 d9                	mov    ecx,ebx
    77133060067b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600681:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    771330600685:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    771330600689:	b8 14 00 00 00       	mov    eax,0x14
    77133060068e:	29 c3                	sub    ebx,eax
    771330600690:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    771330600694:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001a
    77133060069b:	1a 00 01 00 
    77133060069f:	0f 84 f2 fd ff 17    	je     0x771348600497
    7713306006a5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001a
    7713306006ac:	1a 00 01 00 
    7713306006b0:	0f 84 e1 fd ff 17    	je     0x771348600497
    7713306006b6:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7713306006ba:	0f 85 19 fe ff 17    	jne    0x7713486004d9
    7713306006c0:	58                   	pop    rax
    7713306006c1:	e9 0f 00 00 00       	jmp    0x7713306006d5
    7713306006c6:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306006cd:	00 
    7713306006ce:	74 f0                	je     0x7713306006c0
    7713306006d0:	e9 2a fd ff 17       	jmp    0x7713486003ff
    7713306006d5:	50                   	push   rax
    7713306006d6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7713306006db:	c1 e0 10             	shl    eax,0x10
    7713306006de:	b9 00 f0 00 00       	mov    ecx,0xf000
    7713306006e3:	09 c1                	or     ecx,eax
    7713306006e5:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306006e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1001e
    7713306006f0:	1e 00 01 00 
    7713306006f4:	0f 84 11 fe ff 17    	je     0x77134860050b
    7713306006fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1001e
    771330600701:	1e 00 01 00 
    771330600705:	0f 84 00 fe ff 17    	je     0x77134860050b
    77133060070b:	58                   	pop    rax
    77133060070c:	50                   	push   rax
    77133060070d:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    771330600712:	b9 00 00 42 43       	mov    ecx,0x43420000
    771330600717:	09 c1                	or     ecx,eax
    771330600719:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    77133060071d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10022
    771330600724:	22 00 01 00 
    771330600728:	0f 84 3d fe ff 17    	je     0x77134860056b
    77133060072e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10022
    771330600735:	22 00 01 00 
    771330600739:	0f 84 2c fe ff 17    	je     0x77134860056b
    77133060073f:	58                   	pop    rax
    771330600740:	50                   	push   rax
    771330600741:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330600745:	f6 c1 03             	test   cl,0x3
    771330600748:	0f 85 7d fe ff 17    	jne    0x7713486005cb
    77133060074e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600755:	48 89 ca             	mov    rdx,rcx
    771330600758:	48 c1 ea 0c          	shr    rdx,0xc
    77133060075c:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330600760:	48 85 c0             	test   rax,rax
    771330600763:	0f 84 b2 fe ff 17    	je     0x77134860061b
    771330600769:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060076f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330600772:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330600776:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10026
    77133060077d:	26 00 01 00 
    771330600781:	0f 84 cf fe ff 17    	je     0x771348600656
    771330600787:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10026
    77133060078e:	26 00 01 00 
    771330600792:	0f 84 be fe ff 17    	je     0x771348600656
    771330600798:	58                   	pop    rax
    771330600799:	50                   	push   rax
    77133060079a:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    77133060079f:	c1 e0 10             	shl    eax,0x10
    7713306007a2:	b9 31 4e 00 00       	mov    ecx,0x4e31
    7713306007a7:	09 c1                	or     ecx,eax
    7713306007a9:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7713306007ad:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10028
    7713306007b4:	28 00 01 00 
    7713306007b8:	0f 84 e1 fe ff 17    	je     0x77134860069f
    7713306007be:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10028
    7713306007c5:	28 00 01 00 
    7713306007c9:	0f 84 d0 fe ff 17    	je     0x77134860069f
    7713306007cf:	58                   	pop    rax
    7713306007d0:	50                   	push   rax
    7713306007d1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7713306007d5:	41 8b 4d 04          	mov    ecx,DWORD PTR [r13+0x4]
    7713306007d9:	31 d2                	xor    edx,edx
    7713306007db:	31 f6                	xor    esi,esi
    7713306007dd:	89 c7                	mov    edi,eax
    7713306007df:	29 cf                	sub    edi,ecx
    7713306007e1:	0f 94 c2             	sete   dl
    7713306007e4:	40 0f 93 c6          	setae  sil
    7713306007e8:	c1 ef 1f             	shr    edi,0x1f
    7713306007eb:	c1 e8 1f             	shr    eax,0x1f
    7713306007ee:	c1 e9 1f             	shr    ecx,0x1f
    7713306007f1:	89 fb                	mov    ebx,edi
    7713306007f3:	31 c3                	xor    ebx,eax
    7713306007f5:	31 c1                	xor    ecx,eax
    7713306007f7:	21 d9                	and    ecx,ebx
    7713306007f9:	31 f9                	xor    ecx,edi
    7713306007fb:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330600802:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330600809:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    771330600810:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    771330600817:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    77133060081e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002c
    771330600825:	2c 00 01 00 
    771330600829:	0f 84 d0 fe ff 17    	je     0x7713486006ff
    77133060082f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002c
    771330600836:	2c 00 01 00 
    77133060083a:	0f 84 bf fe ff 17    	je     0x7713486006ff
    771330600840:	58                   	pop    rax
    771330600841:	50                   	push   rax
    771330600842:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330600849:	00 
    77133060084a:	74 55                	je     0x7713306008a1
    77133060084c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330600853:	01 
    771330600854:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    77133060085b:	2e 00 01 00 
    77133060085f:	0f 84 fa fe ff 17    	je     0x77134860075f
    771330600865:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    77133060086c:	2e 00 01 00 
    771330600870:	0f 84 e9 fe ff 17    	je     0x77134860075f
    771330600876:	b8 2e 00 01 00       	mov    eax,0x1002e
    77133060087b:	83 c0 12             	add    eax,0x12
    77133060087e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330600885:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060088c:	02 00 00 00 
    771330600890:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    771330600897:	09 00 00 00 
    77133060089b:	58                   	pop    rax
    77133060089c:	e9 3c 03 00 00       	jmp    0x771330600bdd
    7713306008a1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1002e
    7713306008a8:	2e 00 01 00 
    7713306008ac:	0f 84 e9 fe ff 17    	je     0x77134860079b
    7713306008b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1002e
    7713306008b9:	2e 00 01 00 
    7713306008bd:	0f 84 d8 fe ff 17    	je     0x77134860079b
    7713306008c3:	58                   	pop    rax
    7713306008c4:	50                   	push   rax
    7713306008c5:	41 c7 45 00 03 00 00 	mov    DWORD PTR [r13+0x0],0x3
    7713306008cc:	00 
    7713306008cd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10030
    7713306008d4:	30 00 01 00 
    7713306008d8:	0f 84 06 ff ff 17    	je     0x7713486007e4
    7713306008de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10030
    7713306008e5:	30 00 01 00 
    7713306008e9:	0f 84 f5 fe ff 17    	je     0x7713486007e4
    7713306008ef:	58                   	pop    rax
    7713306008f0:	50                   	push   rax
    7713306008f1:	41 83 45 28 10       	add    DWORD PTR [r13+0x28],0x10
    7713306008f6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10032
    7713306008fd:	32 00 01 00 
    771330600901:	0f 84 3d ff ff 17    	je     0x771348600844
    771330600907:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10032
    77133060090e:	32 00 01 00 
    771330600912:	0f 84 2c ff ff 17    	je     0x771348600844
    771330600918:	58                   	pop    rax
    771330600919:	50                   	push   rax
    77133060091a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    77133060091e:	f6 c1 03             	test   cl,0x3
    771330600921:	0f 85 7d ff ff 17    	jne    0x7713486008a4
    771330600927:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    77133060092e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    771330600932:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600939:	48 89 ce             	mov    rsi,rcx
    77133060093c:	48 c1 ee 0c          	shr    rsi,0xc
    771330600940:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330600944:	48 85 c0             	test   rax,rax
    771330600947:	0f 84 aa ff ff 17    	je     0x7713486008f7
    77133060094d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600953:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330600956:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10034
    77133060095d:	34 00 01 00 
    771330600961:	0f 84 cb ff ff 17    	je     0x771348600932
    771330600967:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10034
    77133060096e:	34 00 01 00 
    771330600972:	0f 84 ba ff ff 17    	je     0x771348600932
    771330600978:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    77133060097b:	0f 85 f2 ff ff 17    	jne    0x771348600973
    771330600981:	58                   	pop    rax
    771330600982:	e9 0f 00 00 00       	jmp    0x771330600996
    771330600987:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77133060098e:	00 
    77133060098f:	74 f0                	je     0x771330600981
    771330600991:	e9 45 ff ff 17       	jmp    0x7713486008db
    771330600996:	50                   	push   rax
    771330600997:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    77133060099e:	00 
    77133060099f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10036
    7713306009a6:	36 00 01 00 
    7713306009aa:	0f 84 f5 ff ff 17    	je     0x7713486009a5
    7713306009b0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10036
    7713306009b7:	36 00 01 00 
    7713306009bb:	0f 84 e4 ff ff 17    	je     0x7713486009a5
    7713306009c1:	58                   	pop    rax
    7713306009c2:	50                   	push   rax
    7713306009c3:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7713306009c7:	f6 c3 03             	test   bl,0x3
    7713306009ca:	0f 85 35 00 00 18    	jne    0x771348600a05
    7713306009d0:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    7713306009d7:	48 89 d8             	mov    rax,rbx
    7713306009da:	48 c1 e8 0c          	shr    rax,0xc
    7713306009de:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306009e3:	48 85 c0             	test   rax,rax
    7713306009e6:	0f 84 6b 00 00 18    	je     0x771348600a57
    7713306009ec:	89 d9                	mov    ecx,ebx
    7713306009ee:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306009f4:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    7713306009f8:	89 de                	mov    esi,ebx
    7713306009fa:	83 c6 04             	add    esi,0x4
    7713306009fd:	89 f0                	mov    eax,esi
    7713306009ff:	c1 e8 0c             	shr    eax,0xc
    771330600a02:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600a07:	48 85 c0             	test   rax,rax
    771330600a0a:	0f 84 84 00 00 18    	je     0x771348600a94
    771330600a10:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600a16:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600a19:	8d 4b 08             	lea    ecx,[rbx+0x8]
    771330600a1c:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    771330600a20:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330600a27:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    771330600a2b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10038
    771330600a32:	38 00 01 00 
    771330600a36:	0f 84 94 00 00 18    	je     0x771348600ad0
    771330600a3c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10038
    771330600a43:	38 00 01 00 
    771330600a47:	0f 84 83 00 00 18    	je     0x771348600ad0
    771330600a4d:	58                   	pop    rax
    771330600a4e:	50                   	push   rax
    771330600a4f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330600a53:	f6 c3 03             	test   bl,0x3
    771330600a56:	0f 85 bd 00 00 18    	jne    0x771348600b19
    771330600a5c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330600a63:	48 89 d8             	mov    rax,rbx
    771330600a66:	48 c1 e8 0c          	shr    rax,0xc
    771330600a6a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600a6f:	48 85 c0             	test   rax,rax
    771330600a72:	0f 84 f3 00 00 18    	je     0x771348600b6b
    771330600a78:	89 d9                	mov    ecx,ebx
    771330600a7a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600a80:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330600a83:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    771330600a87:	8d 73 04             	lea    esi,[rbx+0x4]
    771330600a8a:	89 f0                	mov    eax,esi
    771330600a8c:	c1 e8 0c             	shr    eax,0xc
    771330600a8f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600a94:	48 85 c0             	test   rax,rax
    771330600a97:	0f 84 09 01 00 18    	je     0x771348600ba6
    771330600a9d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600aa3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600aa6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    771330600aaa:	8d 73 08             	lea    esi,[rbx+0x8]
    771330600aad:	89 f0                	mov    eax,esi
    771330600aaf:	c1 e8 0c             	shr    eax,0xc
    771330600ab2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600ab7:	48 85 c0             	test   rax,rax
    771330600aba:	0f 84 22 01 00 18    	je     0x771348600be2
    771330600ac0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600ac6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600ac9:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    771330600acd:	8d 73 0c             	lea    esi,[rbx+0xc]
    771330600ad0:	89 f0                	mov    eax,esi
    771330600ad2:	c1 e8 0c             	shr    eax,0xc
    771330600ad5:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600ada:	48 85 c0             	test   rax,rax
    771330600add:	0f 84 3b 01 00 18    	je     0x771348600c1e
    771330600ae3:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600ae9:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600aec:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330600af0:	8d 73 10             	lea    esi,[rbx+0x10]
    771330600af3:	89 f0                	mov    eax,esi
    771330600af5:	c1 e8 0c             	shr    eax,0xc
    771330600af8:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600afd:	48 85 c0             	test   rax,rax
    771330600b00:	0f 84 54 01 00 18    	je     0x771348600c5a
    771330600b06:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600b0c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600b0f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    771330600b13:	8d 73 14             	lea    esi,[rbx+0x14]
    771330600b16:	89 f0                	mov    eax,esi
    771330600b18:	c1 e8 0c             	shr    eax,0xc
    771330600b1b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600b20:	48 85 c0             	test   rax,rax
    771330600b23:	0f 84 6d 01 00 18    	je     0x771348600c96
    771330600b29:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600b2f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600b32:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    771330600b36:	89 de                	mov    esi,ebx
    771330600b38:	83 c6 18             	add    esi,0x18
    771330600b3b:	89 f0                	mov    eax,esi
    771330600b3d:	c1 e8 0c             	shr    eax,0xc
    771330600b40:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330600b45:	48 85 c0             	test   rax,rax
    771330600b48:	0f 84 84 01 00 18    	je     0x771348600cd2
    771330600b4e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330600b54:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330600b57:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    771330600b5b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    771330600b5e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    771330600b62:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003c
    771330600b69:	3c 00 01 00 
    771330600b6d:	0f 84 9b 01 00 18    	je     0x771348600d0e
    771330600b73:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003c
    771330600b7a:	3c 00 01 00 
    771330600b7e:	0f 84 8a 01 00 18    	je     0x771348600d0e
    771330600b84:	58                   	pop    rax
    771330600b85:	50                   	push   rax
    771330600b86:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330600b8d:	a8 01                	test   al,0x1
    771330600b8f:	0f 85 c2 01 00 18    	jne    0x771348600d57
    771330600b95:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330600b9c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330600ba3:	01 
    771330600ba4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1003e
    771330600bab:	3e 00 01 00 
    771330600baf:	0f 84 d8 01 00 18    	je     0x771348600d8d
    771330600bb5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1003e
    771330600bbc:	3e 00 01 00 
    771330600bc0:	0f 84 c7 01 00 18    	je     0x771348600d8d
    771330600bc6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330600bcd:	02 00 00 00 
    771330600bd1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x10
    771330600bd8:	10 00 00 00 
    771330600bdc:	58                   	pop    rax
    771330600bdd:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330600be4:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330600beb:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330600bf2:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330600bf9:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330600c00:	39 f1                	cmp    ecx,esi
    771330600c02:	0f 83 b2 01 00 18    	jae    0x771348600dba
    771330600c08:	81 fa 14 00 01 00    	cmp    edx,0x10014
    771330600c0e:	75 14                	jne    0x771330600c24
    771330600c10:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330600c17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330600c1e:	00 
    771330600c1f:	e9 4c f8 ff ff       	jmp    0x771330600470
    771330600c24:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330600c2b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330600c31:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330600c34:	0f 85 80 01 00 18    	jne    0x771348600dba
    771330600c3a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330600c41:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330600c48:	00 
    771330600c49:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330600c4e:	ff e0                	jmp    rax
