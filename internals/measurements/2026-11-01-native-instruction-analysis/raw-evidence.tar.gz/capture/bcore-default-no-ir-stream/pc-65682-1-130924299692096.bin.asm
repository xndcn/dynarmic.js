
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65682-1-130924299692096.bin:     file format binary


Disassembly of section .data:

0000771330602840 <.data>:
    771330602840:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602847:	8b 88 1c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10001c]
    77133060284d:	ff c1                	inc    ecx
    77133060284f:	89 88 1c 00 10 00    	mov    DWORD PTR [rax+0x10001c],ecx
    771330602855:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060285b:	0f 84 0f 0f 00 18    	je     0x771348603770
    771330602861:	50                   	push   rax
    771330602862:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330602866:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    77133060286d:	31 d2                	xor    edx,edx
    77133060286f:	85 c0                	test   eax,eax
    771330602871:	0f 94 c2             	sete   dl
    771330602874:	c1 e8 1f             	shr    eax,0x1f
    771330602877:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    77133060287e:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330602885:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    77133060288c:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    771330602893:	00 00 00 
    771330602896:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    77133060289d:	81 f9 92 00 01 00    	cmp    ecx,0x10092
    7713306028a3:	0f 84 f3 0e 00 18    	je     0x77134860379c
    7713306028a9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10092
    7713306028b0:	92 00 01 00 
    7713306028b4:	0f 84 e2 0e 00 18    	je     0x77134860379c
    7713306028ba:	58                   	pop    rax
    7713306028bb:	50                   	push   rax
    7713306028bc:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7713306028c3:	00 
    7713306028c4:	74 28                	je     0x7713306028ee
    7713306028c6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    7713306028cd:	94 00 01 00 
    7713306028d1:	0f 84 25 0f 00 18    	je     0x7713486037fc
    7713306028d7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    7713306028de:	94 00 01 00 
    7713306028e2:	0f 84 14 0f 00 18    	je     0x7713486037fc
    7713306028e8:	58                   	pop    rax
    7713306028e9:	e9 55 00 00 00       	jmp    0x771330602943
    7713306028ee:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7713306028f5:	01 
    7713306028f6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10094
    7713306028fd:	94 00 01 00 
    771330602901:	0f 84 3e 0f 00 18    	je     0x771348603845
    771330602907:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10094
    77133060290e:	94 00 01 00 
    771330602912:	0f 84 2d 0f 00 18    	je     0x771348603845
    771330602918:	b8 94 00 01 00       	mov    eax,0x10094
    77133060291d:	83 c0 2c             	add    eax,0x2c
    771330602920:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602927:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060292e:	02 00 00 00 
    771330602932:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771330602939:	02 00 00 00 
    77133060293d:	58                   	pop    rax
    77133060293e:	e9 15 01 00 00       	jmp    0x771330602a58
    771330602943:	50                   	push   rax
    771330602944:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    771330602948:	f6 c1 03             	test   cl,0x3
    77133060294b:	0f 85 30 0f 00 18    	jne    0x771348603881
    771330602951:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330602958:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    77133060295c:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330602963:	48 89 ce             	mov    rsi,rcx
    771330602966:	48 c1 ee 0c          	shr    rsi,0xc
    77133060296a:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    77133060296e:	48 85 c0             	test   rax,rax
    771330602971:	0f 84 5d 0f 00 18    	je     0x7713486038d4
    771330602977:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060297d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330602980:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10096
    771330602987:	96 00 01 00 
    77133060298b:	0f 84 7e 0f 00 18    	je     0x77134860390f
    771330602991:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10096
    771330602998:	96 00 01 00 
    77133060299c:	0f 84 6d 0f 00 18    	je     0x77134860390f
    7713306029a2:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7713306029a5:	0f 85 a5 0f 00 18    	jne    0x771348603950
    7713306029ab:	58                   	pop    rax
    7713306029ac:	e9 0f 00 00 00       	jmp    0x7713306029c0
    7713306029b1:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306029b8:	00 
    7713306029b9:	74 f0                	je     0x7713306029ab
    7713306029bb:	e9 f8 0e 00 18       	jmp    0x7713486038b8
    7713306029c0:	50                   	push   rax
    7713306029c1:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7713306029c8:	b9 98 00 01 00       	mov    ecx,0x10098
    7713306029cd:	83 c1 04             	add    ecx,0x4
    7713306029d0:	89 ca                	mov    edx,ecx
    7713306029d2:	3d 98 00 01 00       	cmp    eax,0x10098
    7713306029d7:	75 07                	jne    0x7713306029e0
    7713306029d9:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7713306029e0:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7713306029e7:	02 
    7713306029e8:	0f 43 ca             	cmovae ecx,edx
    7713306029eb:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7713306029f2:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7713306029f9:	89 cf                	mov    edi,ecx
    7713306029fb:	81 fa 98 00 01 00    	cmp    edx,0x10098
    771330602a01:	75 07                	jne    0x771330602a0a
    771330602a03:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    771330602a0a:	83 fe 02             	cmp    esi,0x2
    771330602a0d:	0f 43 cf             	cmovae ecx,edi
    771330602a10:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    771330602a17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602a1e:	01 
    771330602a1f:	3d 98 00 01 00       	cmp    eax,0x10098
    771330602a24:	0f 84 58 0f 00 18    	je     0x771348603982
    771330602a2a:	81 fa 98 00 01 00    	cmp    edx,0x10098
    771330602a30:	0f 84 4c 0f 00 18    	je     0x771348603982
    771330602a36:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    771330602a3d:	28 04 01 00 
    771330602a41:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771330602a48:	04 00 00 00 
    771330602a4c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771330602a53:	04 00 00 00 
    771330602a57:	58                   	pop    rax
    771330602a58:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602a5f:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330602a66:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330602a6d:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330602a74:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330602a7b:	39 f1                	cmp    ecx,esi
    771330602a7d:	0f 83 37 0f 00 18    	jae    0x7713486039ba
    771330602a83:	81 fa 92 00 01 00    	cmp    edx,0x10092
    771330602a89:	75 14                	jne    0x771330602a9f
    771330602a8b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602a92:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602a99:	00 
    771330602a9a:	e9 a1 fd ff ff       	jmp    0x771330602840
    771330602a9f:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330602aa6:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330602aac:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330602aaf:	0f 85 05 0f 00 18    	jne    0x7713486039ba
    771330602ab5:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602abc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602ac3:	00 
    771330602ac4:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330602ac9:	ff e0                	jmp    rax
