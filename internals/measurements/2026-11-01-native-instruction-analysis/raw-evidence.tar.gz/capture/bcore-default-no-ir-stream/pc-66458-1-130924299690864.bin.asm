
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66458-1-130924299690864.bin:     file format binary


Disassembly of section .data:

0000771330602370 <.data>:
    771330602370:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602377:	8b 88 14 00 10 00    	mov    ecx,DWORD PTR [rax+0x100014]
    77133060237d:	ff c1                	inc    ecx
    77133060237f:	89 88 14 00 10 00    	mov    DWORD PTR [rax+0x100014],ecx
    771330602385:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060238b:	0f 84 df 0d 00 18    	je     0x771348603170
    771330602391:	50                   	push   rax
    771330602392:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    771330602396:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    77133060239d:	41 0f af 45 08       	imul   eax,DWORD PTR [r13+0x8]
    7713306023a2:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    7713306023a6:	81 f9 9a 03 01 00    	cmp    ecx,0x1039a
    7713306023ac:	0f 84 ea 0d 00 18    	je     0x77134860319c
    7713306023b2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1039a
    7713306023b9:	9a 03 01 00 
    7713306023bd:	0f 84 d9 0d 00 18    	je     0x77134860319c
    7713306023c3:	58                   	pop    rax
    7713306023c4:	50                   	push   rax
    7713306023c5:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7713306023c9:	41 8b 4d 08          	mov    ecx,DWORD PTR [r13+0x8]
    7713306023cd:	89 ca                	mov    edx,ecx
    7713306023cf:	c1 ea 1f             	shr    edx,0x1f
    7713306023d2:	89 c6                	mov    esi,eax
    7713306023d4:	c1 ee 1f             	shr    esi,0x1f
    7713306023d7:	31 ff                	xor    edi,edi
    7713306023d9:	01 c1                	add    ecx,eax
    7713306023db:	41 89 4d 08          	mov    DWORD PTR [r13+0x8],ecx
    7713306023df:	40 0f 92 c7          	setb   dil
    7713306023e3:	89 c8                	mov    eax,ecx
    7713306023e5:	c1 e8 1f             	shr    eax,0x1f
    7713306023e8:	31 c6                	xor    esi,eax
    7713306023ea:	31 c2                	xor    edx,eax
    7713306023ec:	21 f2                	and    edx,esi
    7713306023ee:	31 f6                	xor    esi,esi
    7713306023f0:	85 c9                	test   ecx,ecx
    7713306023f2:	40 0f 94 c6          	sete   sil
    7713306023f6:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    7713306023fd:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330602404:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    77133060240b:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    771330602412:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    771330602419:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    771330602420:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    771330602427:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1039c
    77133060242e:	9c 03 01 00 
    771330602432:	0f 84 c4 0d 00 18    	je     0x7713486031fc
    771330602438:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1039c
    77133060243f:	9c 03 01 00 
    771330602443:	0f 84 b3 0d 00 18    	je     0x7713486031fc
    771330602449:	58                   	pop    rax
    77133060244a:	50                   	push   rax
    77133060244b:	41 8b 5d 24          	mov    ebx,DWORD PTR [r13+0x24]
    77133060244f:	f6 c3 03             	test   bl,0x3
    771330602452:	0f 85 04 0e 00 18    	jne    0x77134860325c
    771330602458:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    77133060245f:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    771330602463:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    77133060246a:	48 89 d9             	mov    rcx,rbx
    77133060246d:	48 c1 e9 0c          	shr    rcx,0xc
    771330602471:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    771330602475:	48 85 c0             	test   rax,rax
    771330602478:	0f 84 33 0e 00 18    	je     0x7713486032b1
    77133060247e:	89 d9                	mov    ecx,ebx
    771330602480:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602486:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330602489:	83 c3 04             	add    ebx,0x4
    77133060248c:	41 89 5d 24          	mov    DWORD PTR [r13+0x24],ebx
    771330602490:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1039e
    771330602497:	9e 03 01 00 
    77133060249b:	0f 84 4b 0e 00 18    	je     0x7713486032ec
    7713306024a1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1039e
    7713306024a8:	9e 03 01 00 
    7713306024ac:	0f 84 3a 0e 00 18    	je     0x7713486032ec
    7713306024b2:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    7713306024b6:	0f 85 72 0e 00 18    	jne    0x77134860332e
    7713306024bc:	58                   	pop    rax
    7713306024bd:	e9 0f 00 00 00       	jmp    0x7713306024d1
    7713306024c2:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306024c9:	00 
    7713306024ca:	74 f0                	je     0x7713306024bc
    7713306024cc:	e9 c4 0d 00 18       	jmp    0x771348603295
    7713306024d1:	50                   	push   rax
    7713306024d2:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7713306024d9:	00 
    7713306024da:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103a0
    7713306024e1:	a0 03 01 00 
    7713306024e5:	0f 84 75 0e 00 18    	je     0x771348603360
    7713306024eb:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103a0
    7713306024f2:	a0 03 01 00 
    7713306024f6:	0f 84 64 0e 00 18    	je     0x771348603360
    7713306024fc:	58                   	pop    rax
    7713306024fd:	50                   	push   rax
    7713306024fe:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602505:	01 
    771330602506:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x103a2
    77133060250d:	a2 03 01 00 
    771330602511:	0f 84 a9 0e 00 18    	je     0x7713486033c0
    771330602517:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x103a2
    77133060251e:	a2 03 01 00 
    771330602522:	0f 84 98 0e 00 18    	je     0x7713486033c0
    771330602528:	b8 a2 03 01 00       	mov    eax,0x103a2
    77133060252d:	83 c0 c6             	add    eax,0xffffffc6
    771330602530:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602537:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060253e:	02 00 00 00 
    771330602542:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    771330602549:	05 00 00 00 
    77133060254d:	58                   	pop    rax
    77133060254e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602555:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    77133060255c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330602563:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060256a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330602571:	39 f1                	cmp    ecx,esi
    771330602573:	0f 83 83 0e 00 18    	jae    0x7713486033fc
    771330602579:	81 fa 9a 03 01 00    	cmp    edx,0x1039a
    77133060257f:	75 14                	jne    0x771330602595
    771330602581:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602588:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060258f:	00 
    771330602590:	e9 db fd ff ff       	jmp    0x771330602370
    771330602595:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    77133060259c:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7713306025a2:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7713306025a5:	0f 85 51 0e 00 18    	jne    0x7713486033fc
    7713306025ab:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306025b2:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306025b9:	00 
    7713306025ba:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7713306025bf:	ff e0                	jmp    rax
