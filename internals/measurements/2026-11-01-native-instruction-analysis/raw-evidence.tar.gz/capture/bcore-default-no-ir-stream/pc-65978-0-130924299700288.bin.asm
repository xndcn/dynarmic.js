
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65978-0-130924299700288.bin:     file format binary


Disassembly of section .data:

0000771330604840 <.data>:
    771330604840:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    771330604847:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    77133060484c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330604853:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    771330604858:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    77133060485f:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    771330604863:	b8 11 fe fe ff       	mov    eax,0xfffefe11
    771330604868:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    77133060486f:	01 c1                	add    ecx,eax
    771330604871:	83 f9 ca             	cmp    ecx,0xffffffca
    771330604874:	0f 87 80 1b 00 18    	ja     0x7713486063fa
    77133060487a:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    771330604881:	83 f8 ca             	cmp    eax,0xffffffca
    771330604884:	0f 87 70 1b 00 18    	ja     0x7713486063fa
    77133060488a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330604891:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    771330604896:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    77133060489d:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    7713306048a2:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7713306048a6:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7713306048aa:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    7713306048ae:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    7713306048b3:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    7713306048b7:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    7713306048bc:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7713306048c0:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    7713306048c4:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    7713306048c8:	41 8b 55 24          	mov    edx,DWORD PTR [r13+0x24]
    7713306048cc:	41 8b 85 00 01 00 00 	mov    eax,DWORD PTR [r13+0x100]
    7713306048d3:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    7713306048d7:	41 8b 85 14 01 00 00 	mov    eax,DWORD PTR [r13+0x114]
    7713306048de:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    7713306048e2:	4c 89 6c 24 10       	mov    QWORD PTR [rsp+0x10],r13
    7713306048e7:	45 8b 85 5c 01 00 00 	mov    r8d,DWORD PTR [r13+0x15c]
    7713306048ee:	49 89 d5             	mov    r13,rdx
    7713306048f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    7713306048f8:	0f 1f 84 00 00 00 00 
    7713306048ff:	00 
    771330604900:	44 8b 54 24 20       	mov    r10d,DWORD PTR [rsp+0x20]
    771330604905:	44 89 ea             	mov    edx,r13d
    771330604908:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    77133060490d:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    771330604912:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    771330604917:	89 c3                	mov    ebx,eax
    771330604919:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    77133060491e:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330604923:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    771330604928:	48 89 4c 24 50       	mov    QWORD PTR [rsp+0x50],rcx
    77133060492d:	0f 1f 00             	nop    DWORD PTR [rax]
    771330604930:	41 89 d4             	mov    r12d,edx
    771330604933:	31 c0                	xor    eax,eax
    771330604935:	89 da                	mov    edx,ebx
    771330604937:	23 54 24 0c          	and    edx,DWORD PTR [rsp+0xc]
    77133060493b:	0f 94 c0             	sete   al
    77133060493e:	89 d5                	mov    ebp,edx
    771330604940:	c1 ed 1f             	shr    ebp,0x1f
    771330604943:	44 8d 2c 91          	lea    r13d,[rcx+rdx*4]
    771330604947:	41 f6 c5 03          	test   r13b,0x3
    77133060494b:	0f 85 23 04 00 00    	jne    0x771330604d74
    771330604951:	44 89 ee             	mov    esi,r13d
    771330604954:	c1 ee 0c             	shr    esi,0xc
    771330604957:	4c 8b 34 f7          	mov    r14,QWORD PTR [rdi+rsi*8]
    77133060495b:	45 89 ef             	mov    r15d,r13d
    77133060495e:	41 81 e7 ff 0f 00 00 	and    r15d,0xfff
    771330604965:	4d 85 f6             	test   r14,r14
    771330604968:	48 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],rbx
    77133060496d:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    771330604972:	4c 89 64 24 30       	mov    QWORD PTR [rsp+0x30],r12
    771330604977:	0f 84 3e 05 00 00    	je     0x771330604ebb
    77133060497d:	44 89 d5             	mov    ebp,r10d
    771330604980:	47 8b 14 3e          	mov    r10d,DWORD PTR [r14+r15*1]
    771330604984:	41 8d 34 1a          	lea    esi,[r10+rbx*1]
    771330604988:	41 89 dd             	mov    r13d,ebx
    77133060498b:	41 c1 ed 1f          	shr    r13d,0x1f
    77133060498f:	44 89 d0             	mov    eax,r10d
    771330604992:	c1 e8 1f             	shr    eax,0x1f
    771330604995:	41 89 f4             	mov    r12d,esi
    771330604998:	41 c1 ec 1f          	shr    r12d,0x1f
    77133060499c:	44 31 e0             	xor    eax,r12d
    77133060499f:	44 89 e1             	mov    ecx,r12d
    7713306049a2:	44 31 e9             	xor    ecx,r13d
    7713306049a5:	21 c1                	and    ecx,eax
    7713306049a7:	09 e9                	or     ecx,ebp
    7713306049a9:	89 cd                	mov    ebp,ecx
    7713306049ab:	89 f2                	mov    edx,esi
    7713306049ad:	c1 ea 0b             	shr    edx,0xb
    7713306049b0:	31 db                	xor    ebx,ebx
    7713306049b2:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    7713306049b7:	31 f2                	xor    edx,esi
    7713306049b9:	0f 94 c3             	sete   bl
    7713306049bc:	4d 85 f6             	test   r14,r14
    7713306049bf:	89 54 24 58          	mov    DWORD PTR [rsp+0x58],edx
    7713306049c3:	0f 84 c7 05 00 00    	je     0x771330604f90
    7713306049c9:	43 89 14 3e          	mov    DWORD PTR [r14+r15*1],edx
    7713306049cd:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    7713306049d2:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7713306049d5:	0f 85 98 06 00 00    	jne    0x771330605073
    7713306049db:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    7713306049e0:	41 8d 5c 24 01       	lea    ebx,[r12+0x1]
    7713306049e5:	89 d8                	mov    eax,ebx
    7713306049e7:	c1 e8 1f             	shr    eax,0x1f
    7713306049ea:	c4 62 10 f2 f8       	andn   r15d,r13d,eax
    7713306049ef:	44 09 fd             	or     ebp,r15d
    7713306049f2:	45 31 db             	xor    r11d,r11d
    7713306049f5:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    7713306049f9:	39 d9                	cmp    ecx,ebx
    7713306049fb:	41 0f 96 c3          	setbe  r11b
    7713306049ff:	76 3f                	jbe    0x771330604a40
    771330604a01:	4d 89 d5             	mov    r13,r10
    771330604a04:	4d 89 c6             	mov    r14,r8
    771330604a07:	41 83 c0 0d          	add    r8d,0xd
    771330604a0b:	45 39 c8             	cmp    r8d,r9d
    771330604a0e:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    771330604a13:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    771330604a18:	0f 83 9b 02 00 00    	jae    0x771330604cb9
    771330604a1e:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    771330604a23:	01 c2                	add    edx,eax
    771330604a25:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    771330604a2a:	8b b6 58 01 00 00    	mov    esi,DWORD PTR [rsi+0x158]
    771330604a30:	41 89 ea             	mov    r10d,ebp
    771330604a33:	85 f6                	test   esi,esi
    771330604a35:	0f 85 f5 fe ff ff    	jne    0x771330604930
    771330604a3b:	e9 79 02 00 00       	jmp    0x771330604cb9
    771330604a40:	c4 e2 78 f3 d9       	blsi   eax,ecx
    771330604a45:	ff c9                	dec    ecx
    771330604a47:	c1 e8 1f             	shr    eax,0x1f
    771330604a4a:	09 c5                	or     ebp,eax
    771330604a4c:	45 31 f6             	xor    r14d,r14d
    771330604a4f:	41 89 c9             	mov    r9d,ecx
    771330604a52:	41 81 e1 ff 1f 00 00 	and    r9d,0x1fff
    771330604a59:	41 0f 94 c6          	sete   r14b
    771330604a5d:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330604a62:	8b 58 3c             	mov    ebx,DWORD PTR [rax+0x3c]
    771330604a65:	45 01 e2             	add    r10d,r12d
    771330604a68:	41 ff c4             	inc    r12d
    771330604a6b:	4c 8b 6c 24 30       	mov    r13,QWORD PTR [rsp+0x30]
    771330604a70:	45 01 d5             	add    r13d,r10d
    771330604a73:	f6 c3 03             	test   bl,0x3
    771330604a76:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    771330604a7b:	0f 85 6d 07 00 00    	jne    0x7713306051ee
    771330604a81:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    771330604a86:	89 6c 24 20          	mov    DWORD PTR [rsp+0x20],ebp
    771330604a8a:	48 89 d8             	mov    rax,rbx
    771330604a8d:	48 c1 e8 0c          	shr    rax,0xc
    771330604a91:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    771330604a95:	48 85 c0             	test   rax,rax
    771330604a98:	44 89 5c 24 30       	mov    DWORD PTR [rsp+0x30],r11d
    771330604a9d:	4c 89 64 24 38       	mov    QWORD PTR [rsp+0x38],r12
    771330604aa2:	4c 89 4c 24 58       	mov    QWORD PTR [rsp+0x58],r9
    771330604aa7:	0f 84 e2 07 00 00    	je     0x77133060528f
    771330604aad:	89 da                	mov    edx,ebx
    771330604aaf:	81 e2 ff 0f 00 00    	and    edx,0xfff
    771330604ab5:	44 8b 3c 10          	mov    r15d,DWORD PTR [rax+rdx*1]
    771330604ab9:	8d 73 04             	lea    esi,[rbx+0x4]
    771330604abc:	89 f0                	mov    eax,esi
    771330604abe:	c1 e8 0c             	shr    eax,0xc
    771330604ac1:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    771330604ac5:	48 85 c0             	test   rax,rax
    771330604ac8:	0f 84 a3 08 00 00    	je     0x771330605371
    771330604ace:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330604ad4:	8b 2c 30             	mov    ebp,DWORD PTR [rax+rsi*1]
    771330604ad7:	8d 73 08             	lea    esi,[rbx+0x8]
    771330604ada:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330604adf:	44 89 78 3c          	mov    DWORD PTR [rax+0x3c],r15d
    771330604ae3:	89 a8 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],ebp
    771330604ae9:	89 70 38             	mov    DWORD PTR [rax+0x38],esi
    771330604aec:	89 f0                	mov    eax,esi
    771330604aee:	c1 e8 0c             	shr    eax,0xc
    771330604af1:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    771330604af5:	48 85 c0             	test   rax,rax
    771330604af8:	0f 84 53 09 00 00    	je     0x771330605451
    771330604afe:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330604b04:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330604b07:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    771330604b0b:	83 c3 0c             	add    ebx,0xc
    771330604b0e:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330604b13:	89 58 38             	mov    DWORD PTR [rax+0x38],ebx
    771330604b16:	42 8d 0c 89          	lea    ecx,[rcx+r9*4]
    771330604b1a:	f6 c1 03             	test   cl,0x3
    771330604b1d:	0f 85 15 0a 00 00    	jne    0x771330605538
    771330604b23:	89 c8                	mov    eax,ecx
    771330604b25:	c1 e8 0c             	shr    eax,0xc
    771330604b28:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    771330604b2c:	48 85 c0             	test   rax,rax
    771330604b2f:	0f 84 aa 0a 00 00    	je     0x7713306055df
    771330604b35:	89 ca                	mov    edx,ecx
    771330604b37:	81 e2 ff 0f 00 00    	and    edx,0xfff
    771330604b3d:	8b 14 10             	mov    edx,DWORD PTR [rax+rdx*1]
    771330604b40:	45 31 e4             	xor    r12d,r12d
    771330604b43:	44 31 ea             	xor    edx,r13d
    771330604b46:	41 0f 94 c4          	sete   r12b
    771330604b4a:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    771330604b4e:	c1 ea 1f             	shr    edx,0x1f
    771330604b51:	40 f6 c5 01          	test   bpl,0x1
    771330604b55:	0f 85 5a 0b 00 00    	jne    0x7713306056b5
    771330604b5b:	49 89 e9             	mov    r9,rbp
    771330604b5e:	c6 44 24 68 01       	mov    BYTE PTR [rsp+0x68],0x1
    771330604b63:	45 31 d2             	xor    r10d,r10d
    771330604b66:	c7 44 24 50 02 00 00 	mov    DWORD PTR [rsp+0x50],0x2
    771330604b6d:	00 
    771330604b6e:	be 18 00 00 00       	mov    esi,0x18
    771330604b73:	45 31 db             	xor    r11d,r11d
    771330604b76:	45 31 f6             	xor    r14d,r14d
    771330604b79:	45 31 ff             	xor    r15d,r15d
    771330604b7c:	44 89 e8             	mov    eax,r13d
    771330604b7f:	4c 89 c3             	mov    rbx,r8
    771330604b82:	41 01 f0             	add    r8d,esi
    771330604b85:	44 3b 44 24 2c       	cmp    r8d,DWORD PTR [rsp+0x2c]
    771330604b8a:	0f 83 bb 05 00 00    	jae    0x77133060514b
    771330604b90:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330604b95:	8b af 58 01 00 00    	mov    ebp,DWORD PTR [rdi+0x158]
    771330604b9b:	85 ed                	test   ebp,ebp
    771330604b9d:	0f 84 a8 05 00 00    	je     0x77133060514b
    771330604ba3:	4c 89 cf             	mov    rdi,r9
    771330604ba6:	81 ff ba 01 01 00    	cmp    edi,0x101ba
    771330604bac:	0f 84 4e fd ff ff    	je     0x771330604900
    771330604bb2:	48 89 bc 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rdi
    771330604bb9:	00 
    771330604bba:	8d 3c fd 00 00 00 00 	lea    edi,[rdi*8+0x0]
    771330604bc1:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    771330604bc7:	48 89 7c 24 70       	mov    QWORD PTR [rsp+0x70],rdi
    771330604bcc:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    771330604bd1:	48 8b ac 24 80 00 00 	mov    rbp,QWORD PTR [rsp+0x80]
    771330604bd8:	00 
    771330604bd9:	44 89 54 24 2c       	mov    DWORD PTR [rsp+0x2c],r10d
    771330604bde:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
    771330604be3:	42 39 2c 17          	cmp    DWORD PTR [rdi+r10*1],ebp
    771330604be7:	44 8b 54 24 2c       	mov    r10d,DWORD PTR [rsp+0x2c]
    771330604bec:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
    771330604bf1:	0f 85 54 05 00 00    	jne    0x77133060514b
    771330604bf7:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    771330604bfc:	48 8b 6c 2f 08       	mov    rbp,QWORD PTR [rdi+rbp*1+0x8]
    771330604c01:	4c 89 ef             	mov    rdi,r13
    771330604c04:	4c 8b 6c 24 10       	mov    r13,QWORD PTR [rsp+0x10]
    771330604c09:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    771330604c0d:	41 89 5d 00          	mov    DWORD PTR [r13+0x0],ebx
    771330604c11:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330604c15:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    771330604c1a:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    771330604c1e:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    771330604c23:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    771330604c27:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330604c2b:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330604c2f:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    771330604c33:	41 89 7d 24          	mov    DWORD PTR [r13+0x24],edi
    771330604c37:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    771330604c3c:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330604c40:	45 89 8d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r9d
    771330604c47:	45 89 a5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],r12d
    771330604c4e:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    771330604c55:	45 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],r15d
    771330604c5c:	45 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],r14d
    771330604c63:	45 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],r11d
    771330604c6a:	45 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],r10d
    771330604c71:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    771330604c75:	41 89 85 00 01 00 00 	mov    DWORD PTR [r13+0x100],eax
    771330604c7c:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    771330604c80:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    771330604c87:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    771330604c8b:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    771330604c92:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330604c99:	00 
    771330604c9a:	41 89 b5 34 01 00 00 	mov    DWORD PTR [r13+0x134],esi
    771330604ca1:	45 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],r8d
    771330604ca8:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    771330604cad:	48 89 e8             	mov    rax,rbp
    771330604cb0:	48 81 c4 88 00 00 00 	add    rsp,0x88
    771330604cb7:	ff e0                	jmp    rax
    771330604cb9:	45 8d 44 24 01       	lea    r8d,[r12+0x1]
    771330604cbe:	31 d2                	xor    edx,edx
    771330604cc0:	45 31 c9             	xor    r9d,r9d
    771330604cc3:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    771330604cc7:	41 39 f0             	cmp    r8d,esi
    771330604cca:	0f 96 c2             	setbe  dl
    771330604ccd:	41 0f 97 c1          	seta   r9b
    771330604cd1:	45 01 e5             	add    r13d,r12d
    771330604cd4:	41 29 f4             	sub    r12d,esi
    771330604cd7:	31 db                	xor    ebx,ebx
    771330604cd9:	41 83 fc ff          	cmp    r12d,0xffffffff
    771330604cdd:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330604ce2:	89 37                	mov    DWORD PTR [rdi],esi
    771330604ce4:	8b 74 24 58          	mov    esi,DWORD PTR [rsp+0x58]
    771330604ce8:	89 77 04             	mov    DWORD PTR [rdi+0x4],esi
    771330604ceb:	44 89 47 08          	mov    DWORD PTR [rdi+0x8],r8d
    771330604cef:	44 89 6f 0c          	mov    DWORD PTR [rdi+0xc],r13d
    771330604cf3:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    771330604cf7:	89 77 1c             	mov    DWORD PTR [rdi+0x1c],esi
    771330604cfa:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    771330604cfd:	0f 94 c3             	sete   bl
    771330604d00:	44 01 e8             	add    eax,r13d
    771330604d03:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    771330604d06:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    771330604d0a:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x101ba
    771330604d11:	01 01 00 
    771330604d14:	89 9f e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],ebx
    771330604d1a:	44 89 8f e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r9d
    771330604d21:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    771330604d27:	89 97 f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],edx
    771330604d2d:	44 89 bf f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r15d
    771330604d34:	44 89 bf fc 00 00 00 	mov    DWORD PTR [rdi+0xfc],r15d
    771330604d3b:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    771330604d41:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    771330604d48:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    771330604d4f:	00 00 00 
    771330604d52:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    771330604d59:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    771330604d60:	00 00 00 
    771330604d63:	44 89 b7 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r14d
    771330604d6a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    771330604d71:	c2 08 00             	ret    0x8
    771330604d74:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    771330604d78:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330604d7d:	89 37                	mov    DWORD PTR [rdi],esi
    771330604d7f:	89 57 04             	mov    DWORD PTR [rdi+0x4],edx
    771330604d82:	89 5f 08             	mov    DWORD PTR [rdi+0x8],ebx
    771330604d85:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    771330604d8a:	89 57 0c             	mov    DWORD PTR [rdi+0xc],edx
    771330604d8d:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    771330604d91:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    771330604d94:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    771330604d97:	44 89 67 24          	mov    DWORD PTR [rdi+0x24],r12d
    771330604d9b:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    771330604d9f:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    771330604da6:	01 01 00 
    771330604da9:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    771330604daf:	89 af e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebp
    771330604db5:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    771330604dbc:	00 00 00 00 
    771330604dc0:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    771330604dc7:	00 00 00 00 
    771330604dcb:	44 89 97 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r10d
    771330604dd2:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    771330604dd9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    771330604de0:	00 00 00 
    771330604de3:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    771330604dea:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    771330604df1:	00 00 00 
    771330604df4:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    771330604dfb:	48 b8 e0 e8 8f a8 39 	movabs rax,0x6039a88fe8e0
    771330604e02:	60 00 00 
    771330604e05:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    771330604e0a:	ba c0 01 01 00       	mov    edx,0x101c0
    771330604e0f:	44 89 e9             	mov    ecx,r13d
    771330604e12:	45 31 c0             	xor    r8d,r8d
    771330604e15:	ff d0                	call   rax
    771330604e17:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330604e1c:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    771330604e23:	88 4c 24 68          	mov    BYTE PTR [rsp+0x68],cl
    771330604e27:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330604e2c:	44 8b 8f bc 00 00 00 	mov    r9d,DWORD PTR [rdi+0xbc]
    771330604e33:	8b 07                	mov    eax,DWORD PTR [rdi]
    771330604e35:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    771330604e39:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    771330604e3c:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
    771330604e3f:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    771330604e44:	8b 4f 0c             	mov    ecx,DWORD PTR [rdi+0xc]
    771330604e47:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    771330604e4c:	8b 4f 1c             	mov    ecx,DWORD PTR [rdi+0x1c]
    771330604e4f:	89 4c 24 0c          	mov    DWORD PTR [rsp+0xc],ecx
    771330604e53:	8b 4f 20             	mov    ecx,DWORD PTR [rdi+0x20]
    771330604e56:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    771330604e5a:	8b 57 28             	mov    edx,DWORD PTR [rdi+0x28]
    771330604e5d:	48 89 54 24 58       	mov    QWORD PTR [rsp+0x58],rdx
    771330604e62:	44 8b a7 e4 00 00 00 	mov    r12d,DWORD PTR [rdi+0xe4]
    771330604e69:	8b 97 e8 00 00 00    	mov    edx,DWORD PTR [rdi+0xe8]
    771330604e6f:	44 8b bf ec 00 00 00 	mov    r15d,DWORD PTR [rdi+0xec]
    771330604e76:	44 8b b7 f0 00 00 00 	mov    r14d,DWORD PTR [rdi+0xf0]
    771330604e7d:	44 8b 9f f8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xf8]
    771330604e84:	44 8b 97 fc 00 00 00 	mov    r10d,DWORD PTR [rdi+0xfc]
    771330604e8b:	8b b7 00 01 00 00    	mov    esi,DWORD PTR [rdi+0x100]
    771330604e91:	89 74 24 20          	mov    DWORD PTR [rsp+0x20],esi
    771330604e95:	8b b7 14 01 00 00    	mov    esi,DWORD PTR [rdi+0x114]
    771330604e9b:	89 74 24 30          	mov    DWORD PTR [rsp+0x30],esi
    771330604e9f:	8b b7 24 01 00 00    	mov    esi,DWORD PTR [rdi+0x124]
    771330604ea5:	89 74 24 50          	mov    DWORD PTR [rsp+0x50],esi
    771330604ea9:	8b b7 34 01 00 00    	mov    esi,DWORD PTR [rdi+0x134]
    771330604eaf:	44 8b 87 5c 01 00 00 	mov    r8d,DWORD PTR [rdi+0x15c]
    771330604eb6:	e9 c4 fc ff ff       	jmp    0x771330604b7f
    771330604ebb:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    771330604ebf:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330604ec4:	89 37                	mov    DWORD PTR [rdi],esi
    771330604ec6:	89 57 04             	mov    DWORD PTR [rdi+0x4],edx
    771330604ec9:	89 5f 08             	mov    DWORD PTR [rdi+0x8],ebx
    771330604ecc:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    771330604ed1:	89 57 0c             	mov    DWORD PTR [rdi+0xc],edx
    771330604ed4:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    771330604ed8:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    771330604edb:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    771330604ede:	44 89 67 24          	mov    DWORD PTR [rdi+0x24],r12d
    771330604ee2:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    771330604ee6:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    771330604eed:	01 01 00 
    771330604ef0:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    771330604ef6:	89 af e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebp
    771330604efc:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    771330604f03:	00 00 00 00 
    771330604f07:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    771330604f0e:	00 00 00 00 
    771330604f12:	44 89 d5             	mov    ebp,r10d
    771330604f15:	44 89 97 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r10d
    771330604f1c:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    771330604f23:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    771330604f2a:	00 00 00 
    771330604f2d:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    771330604f34:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    771330604f3b:	00 00 00 
    771330604f3e:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    771330604f45:	48 b8 f0 85 7e a8 39 	movabs rax,0x6039a87e85f0
    771330604f4c:	60 00 00 
    771330604f4f:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    771330604f54:	44 89 ee             	mov    esi,r13d
    771330604f57:	44 89 db             	mov    ebx,r11d
    771330604f5a:	4d 89 c4             	mov    r12,r8
    771330604f5d:	ff d0                	call   rax
    771330604f5f:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330604f64:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    771330604f69:	41 89 c2             	mov    r10d,eax
    771330604f6c:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330604f71:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    771330604f78:	84 c9                	test   cl,cl
    771330604f7a:	0f 85 a3 fe ff ff    	jne    0x771330604e23
    771330604f80:	4d 89 e0             	mov    r8,r12
    771330604f83:	41 89 db             	mov    r11d,ebx
    771330604f86:	48 8b 5c 24 38       	mov    rbx,QWORD PTR [rsp+0x38]
    771330604f8b:	e9 f4 f9 ff ff       	jmp    0x771330604984
    771330604f90:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    771330604f94:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    771330604f99:	89 01                	mov    DWORD PTR [rcx],eax
    771330604f9b:	89 51 04             	mov    DWORD PTR [rcx+0x4],edx
    771330604f9e:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    771330604fa3:	89 41 08             	mov    DWORD PTR [rcx+0x8],eax
    771330604fa6:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    771330604fab:	89 41 0c             	mov    DWORD PTR [rcx+0xc],eax
    771330604fae:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330604fb2:	89 41 1c             	mov    DWORD PTR [rcx+0x1c],eax
    771330604fb5:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    771330604fba:	89 41 20             	mov    DWORD PTR [rcx+0x20],eax
    771330604fbd:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    771330604fc2:	89 41 24             	mov    DWORD PTR [rcx+0x24],eax
    771330604fc5:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    771330604fca:	89 71 28             	mov    DWORD PTR [rcx+0x28],esi
    771330604fcd:	c7 81 bc 00 00 00 ca 	mov    DWORD PTR [rcx+0xbc],0x101ca
    771330604fd4:	01 01 00 
    771330604fd7:	89 99 e4 00 00 00    	mov    DWORD PTR [rcx+0xe4],ebx
    771330604fdd:	44 89 a1 e8 00 00 00 	mov    DWORD PTR [rcx+0xe8],r12d
    771330604fe4:	48 c7 81 ec 00 00 00 	mov    QWORD PTR [rcx+0xec],0x0
    771330604feb:	00 00 00 00 
    771330604fef:	48 c7 81 f8 00 00 00 	mov    QWORD PTR [rcx+0xf8],0x0
    771330604ff6:	00 00 00 00 
    771330604ffa:	89 a9 00 01 00 00    	mov    DWORD PTR [rcx+0x100],ebp
    771330605000:	44 89 99 14 01 00 00 	mov    DWORD PTR [rcx+0x114],r11d
    771330605007:	c7 81 24 01 00 00 02 	mov    DWORD PTR [rcx+0x124],0x2
    77133060500e:	00 00 00 
    771330605011:	c6 81 28 01 00 00 00 	mov    BYTE PTR [rcx+0x128],0x0
    771330605018:	c7 81 34 01 00 00 08 	mov    DWORD PTR [rcx+0x134],0x8
    77133060501f:	00 00 00 
    771330605022:	44 89 81 5c 01 00 00 	mov    DWORD PTR [rcx+0x15c],r8d
    771330605029:	48 b8 20 86 7e a8 39 	movabs rax,0x6039a87e8620
    771330605030:	60 00 00 
    771330605033:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    771330605038:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    77133060503d:	45 89 df             	mov    r15d,r11d
    771330605040:	4d 89 c6             	mov    r14,r8
    771330605043:	ff d0                	call   rax
    771330605045:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    77133060504a:	4d 89 f0             	mov    r8,r14
    77133060504d:	45 89 fb             	mov    r11d,r15d
    771330605050:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330605055:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    77133060505a:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    77133060505f:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    771330605066:	84 c9                	test   cl,cl
    771330605068:	0f 84 5f f9 ff ff    	je     0x7713306049cd
    77133060506e:	e9 b0 fd ff ff       	jmp    0x771330604e23
    771330605073:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    771330605077:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    77133060507c:	89 07                	mov    DWORD PTR [rdi],eax
    77133060507e:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    771330605082:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    771330605085:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    77133060508a:	89 47 08             	mov    DWORD PTR [rdi+0x8],eax
    77133060508d:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    771330605092:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    771330605095:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330605099:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    77133060509c:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    7713306050a1:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    7713306050a4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    7713306050a9:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    7713306050ac:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    7713306050b1:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    7713306050b4:	c7 87 bc 00 00 00 cc 	mov    DWORD PTR [rdi+0xbc],0x101cc
    7713306050bb:	01 01 00 
    7713306050be:	89 9f e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],ebx
    7713306050c4:	44 89 a7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r12d
    7713306050cb:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    7713306050d2:	00 00 00 00 
    7713306050d6:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    7713306050dd:	00 00 00 00 
    7713306050e1:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    7713306050e7:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    7713306050ee:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7713306050f5:	00 00 00 
    7713306050f8:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    7713306050ff:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    771330605106:	00 00 00 
    771330605109:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    771330605110:	48 b8 10 e6 8f a8 39 	movabs rax,0x6039a88fe610
    771330605117:	60 00 00 
    77133060511a:	4c 89 c3             	mov    rbx,r8
    77133060511d:	4d 89 d6             	mov    r14,r10
    771330605120:	ff d0                	call   rax
    771330605122:	4d 89 f2             	mov    r10,r14
    771330605125:	49 89 d8             	mov    r8,rbx
    771330605128:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    77133060512d:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    771330605132:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330605137:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    77133060513e:	84 c9                	test   cl,cl
    771330605140:	0f 84 95 f8 ff ff    	je     0x7713306049db
    771330605146:	e9 d8 fc ff ff       	jmp    0x771330604e23
    77133060514b:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    771330605150:	8b 6c 24 1c          	mov    ebp,DWORD PTR [rsp+0x1c]
    771330605154:	89 2f                	mov    DWORD PTR [rdi],ebp
    771330605156:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    771330605159:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    77133060515e:	89 47 08             	mov    DWORD PTR [rdi+0x8],eax
    771330605161:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    771330605166:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    771330605169:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    77133060516d:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    771330605170:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    771330605173:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    771330605177:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    77133060517c:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    77133060517f:	44 89 8f bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r9d
    771330605186:	44 89 a7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r12d
    77133060518d:	89 97 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],edx
    771330605193:	44 89 bf ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r15d
    77133060519a:	44 89 b7 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r14d
    7713306051a1:	44 89 9f f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r11d
    7713306051a8:	44 89 97 fc 00 00 00 	mov    DWORD PTR [rdi+0xfc],r10d
    7713306051af:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7713306051b3:	89 87 00 01 00 00    	mov    DWORD PTR [rdi+0x100],eax
    7713306051b9:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    7713306051bd:	89 87 14 01 00 00    	mov    DWORD PTR [rdi+0x114],eax
    7713306051c3:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    7713306051c7:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    7713306051cd:	0f b6 44 24 68       	movzx  eax,BYTE PTR [rsp+0x68]
    7713306051d2:	88 87 28 01 00 00    	mov    BYTE PTR [rdi+0x128],al
    7713306051d8:	89 b7 34 01 00 00    	mov    DWORD PTR [rdi+0x134],esi
    7713306051de:	89 9f 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ebx
    7713306051e4:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7713306051eb:	c2 08 00             	ret    0x8
    7713306051ee:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    7713306051f3:	44 89 0f             	mov    DWORD PTR [rdi],r9d
    7713306051f6:	44 89 6f 04          	mov    DWORD PTR [rdi+0x4],r13d
    7713306051fa:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    7713306051fe:	44 89 57 0c          	mov    DWORD PTR [rdi+0xc],r10d
    771330605202:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330605206:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    771330605209:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    77133060520c:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    771330605210:	44 89 4f 28          	mov    DWORD PTR [rdi+0x28],r9d
    771330605214:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    77133060521b:	01 01 00 
    77133060521e:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    771330605225:	48 c7 87 e8 00 00 00 	mov    QWORD PTR [rdi+0xe8],0x0
    77133060522c:	00 00 00 00 
    771330605230:	c7 87 f0 00 00 00 00 	mov    DWORD PTR [rdi+0xf0],0x0
    771330605237:	00 00 00 
    77133060523a:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    771330605241:	00 00 00 00 
    771330605245:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    77133060524b:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    771330605252:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    771330605259:	00 00 00 
    77133060525c:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    771330605263:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    77133060526a:	00 00 00 
    77133060526d:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    771330605274:	48 b8 e0 e8 8f a8 39 	movabs rax,0x6039a88fe8e0
    77133060527b:	60 00 00 
    77133060527e:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    771330605283:	ba e2 01 01 00       	mov    edx,0x101e2
    771330605288:	89 d9                	mov    ecx,ebx
    77133060528a:	e9 83 fb ff ff       	jmp    0x771330604e12
    77133060528f:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    771330605294:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    771330605297:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    77133060529b:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    77133060529f:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    7713306052a4:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    7713306052a7:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    7713306052ab:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    7713306052ae:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    7713306052b1:	4d 89 ec             	mov    r12,r13
    7713306052b4:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    7713306052b8:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    7713306052bc:	c7 82 bc 00 00 00 e2 	mov    DWORD PTR [rdx+0xbc],0x101e2
    7713306052c3:	01 01 00 
    7713306052c6:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    7713306052cd:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    7713306052d4:	00 00 00 00 
    7713306052d8:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    7713306052df:	00 00 00 
    7713306052e2:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    7713306052e9:	00 00 00 00 
    7713306052ed:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7713306052f1:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    7713306052f7:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    7713306052fe:	c7 82 24 01 00 00 04 	mov    DWORD PTR [rdx+0x124],0x4
    771330605305:	00 00 00 
    771330605308:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    77133060530f:	c7 82 34 01 00 00 13 	mov    DWORD PTR [rdx+0x134],0x13
    771330605316:	00 00 00 
    771330605319:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    771330605320:	48 b8 f0 85 7e a8 39 	movabs rax,0x6039a87e85f0
    771330605327:	60 00 00 
    77133060532a:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    77133060532f:	89 de                	mov    esi,ebx
    771330605331:	4c 89 c5             	mov    rbp,r8
    771330605334:	ff d0                	call   rax
    771330605336:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    77133060533b:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330605340:	41 89 c7             	mov    r15d,eax
    771330605343:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    771330605348:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    77133060534f:	84 c9                	test   cl,cl
    771330605351:	0f 85 cc fa ff ff    	jne    0x771330604e23
    771330605357:	49 89 e8             	mov    r8,rbp
    77133060535a:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    77133060535f:	4d 89 e5             	mov    r13,r12
    771330605362:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    771330605367:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    77133060536c:	e9 48 f7 ff ff       	jmp    0x771330604ab9
    771330605371:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    771330605376:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    771330605379:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    77133060537d:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    771330605381:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    771330605386:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    771330605389:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    77133060538d:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    771330605390:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    771330605393:	4d 89 ec             	mov    r12,r13
    771330605396:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    77133060539a:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    77133060539e:	c7 82 bc 00 00 00 e2 	mov    DWORD PTR [rdx+0xbc],0x101e2
    7713306053a5:	01 01 00 
    7713306053a8:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    7713306053af:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    7713306053b6:	00 00 00 00 
    7713306053ba:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    7713306053c1:	00 00 00 
    7713306053c4:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    7713306053cb:	00 00 00 00 
    7713306053cf:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7713306053d3:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    7713306053d9:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    7713306053e0:	c7 82 24 01 00 00 04 	mov    DWORD PTR [rdx+0x124],0x4
    7713306053e7:	00 00 00 
    7713306053ea:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    7713306053f1:	c7 82 34 01 00 00 13 	mov    DWORD PTR [rdx+0x134],0x13
    7713306053f8:	00 00 00 
    7713306053fb:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    771330605402:	48 b8 f0 85 7e a8 39 	movabs rax,0x6039a87e85f0
    771330605409:	60 00 00 
    77133060540c:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    771330605411:	4c 89 c5             	mov    rbp,r8
    771330605414:	ff d0                	call   rax
    771330605416:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    77133060541b:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330605420:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    771330605425:	0f b6 89 28 01 00 00 	movzx  ecx,BYTE PTR [rcx+0x128]
    77133060542c:	84 c9                	test   cl,cl
    77133060542e:	0f 85 ef f9 ff ff    	jne    0x771330604e23
    771330605434:	49 89 e8             	mov    r8,rbp
    771330605437:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    77133060543c:	4d 89 e5             	mov    r13,r12
    77133060543f:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    771330605444:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    771330605449:	48 89 c5             	mov    rbp,rax
    77133060544c:	e9 86 f6 ff ff       	jmp    0x771330604ad7
    771330605451:	49 89 ef             	mov    r15,rbp
    771330605454:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    771330605459:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    77133060545c:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    771330605460:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    771330605464:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    771330605469:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    77133060546c:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330605470:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    771330605473:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    771330605476:	4d 89 ec             	mov    r12,r13
    771330605479:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    77133060547d:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    771330605481:	c7 82 bc 00 00 00 e6 	mov    DWORD PTR [rdx+0xbc],0x101e6
    771330605488:	01 01 00 
    77133060548b:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    771330605492:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    771330605499:	00 00 00 00 
    77133060549d:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    7713306054a4:	00 00 00 
    7713306054a7:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    7713306054ae:	00 00 00 00 
    7713306054b2:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7713306054b6:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    7713306054bc:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    7713306054c3:	c7 82 24 01 00 00 02 	mov    DWORD PTR [rdx+0x124],0x2
    7713306054ca:	00 00 00 
    7713306054cd:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    7713306054d4:	c7 82 34 01 00 00 14 	mov    DWORD PTR [rdx+0x134],0x14
    7713306054db:	00 00 00 
    7713306054de:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    7713306054e5:	48 b8 f0 85 7e a8 39 	movabs rax,0x6039a87e85f0
    7713306054ec:	60 00 00 
    7713306054ef:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    7713306054f4:	4c 89 c5             	mov    rbp,r8
    7713306054f7:	ff d0                	call   rax
    7713306054f9:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    7713306054fe:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    771330605503:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    771330605507:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    77133060550c:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    771330605513:	84 c9                	test   cl,cl
    771330605515:	0f 85 08 f9 ff ff    	jne    0x771330604e23
    77133060551b:	49 89 e8             	mov    r8,rbp
    77133060551e:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    771330605523:	4d 89 e5             	mov    r13,r12
    771330605526:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    77133060552b:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    771330605530:	4c 89 fd             	mov    rbp,r15
    771330605533:	e9 d3 f5 ff ff       	jmp    0x771330604b0b
    771330605538:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    77133060553d:	44 89 0f             	mov    DWORD PTR [rdi],r9d
    771330605540:	44 89 6f 04          	mov    DWORD PTR [rdi+0x4],r13d
    771330605544:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    771330605548:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    77133060554d:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    771330605550:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    771330605554:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    771330605557:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    77133060555a:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    77133060555e:	44 89 4f 28          	mov    DWORD PTR [rdi+0x28],r9d
    771330605562:	c7 87 bc 00 00 00 ea 	mov    DWORD PTR [rdi+0xbc],0x101ea
    771330605569:	01 01 00 
    77133060556c:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    771330605573:	48 c7 87 e8 00 00 00 	mov    QWORD PTR [rdi+0xe8],0x0
    77133060557a:	00 00 00 00 
    77133060557e:	c7 87 f0 00 00 00 00 	mov    DWORD PTR [rdi+0xf0],0x0
    771330605585:	00 00 00 
    771330605588:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    77133060558f:	00 00 00 00 
    771330605593:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    771330605597:	89 87 00 01 00 00    	mov    DWORD PTR [rdi+0x100],eax
    77133060559d:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    7713306055a4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7713306055ab:	00 00 00 
    7713306055ae:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    7713306055b5:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    7713306055bc:	00 00 00 
    7713306055bf:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    7713306055c6:	48 b8 e0 e8 8f a8 39 	movabs rax,0x6039a88fe8e0
    7713306055cd:	60 00 00 
    7713306055d0:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    7713306055d5:	ba ea 01 01 00       	mov    edx,0x101ea
    7713306055da:	e9 33 f8 ff ff       	jmp    0x771330604e12
    7713306055df:	49 89 ef             	mov    r15,rbp
    7713306055e2:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    7713306055e7:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    7713306055ea:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    7713306055ee:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    7713306055f2:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    7713306055f7:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    7713306055fa:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    7713306055fe:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    771330605601:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    771330605604:	44 89 f0             	mov    eax,r14d
    771330605607:	4d 89 ee             	mov    r14,r13
    77133060560a:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    77133060560e:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    771330605612:	c7 82 bc 00 00 00 ea 	mov    DWORD PTR [rdx+0xbc],0x101ea
    771330605619:	01 01 00 
    77133060561c:	89 82 e4 00 00 00    	mov    DWORD PTR [rdx+0xe4],eax
    771330605622:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    771330605629:	00 00 00 00 
    77133060562d:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    771330605634:	00 00 00 
    771330605637:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    77133060563e:	00 00 00 00 
    771330605642:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    771330605646:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    77133060564c:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    771330605653:	c7 82 24 01 00 00 02 	mov    DWORD PTR [rdx+0x124],0x2
    77133060565a:	00 00 00 
    77133060565d:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    771330605664:	c7 82 34 01 00 00 16 	mov    DWORD PTR [rdx+0x134],0x16
    77133060566b:	00 00 00 
    77133060566e:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    771330605675:	48 b8 f0 85 7e a8 39 	movabs rax,0x6039a87e85f0
    77133060567c:	60 00 00 
    77133060567f:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    771330605684:	48 89 cd             	mov    rbp,rcx
    771330605687:	89 ce                	mov    esi,ecx
    771330605689:	4c 89 c3             	mov    rbx,r8
    77133060568c:	ff d0                	call   rax
    77133060568e:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    771330605693:	0f b6 89 28 01 00 00 	movzx  ecx,BYTE PTR [rcx+0x128]
    77133060569a:	84 c9                	test   cl,cl
    77133060569c:	0f 85 81 f7 ff ff    	jne    0x771330604e23
    7713306056a2:	49 89 d8             	mov    r8,rbx
    7713306056a5:	48 89 e9             	mov    rcx,rbp
    7713306056a8:	4d 89 f5             	mov    r13,r14
    7713306056ab:	89 c2                	mov    edx,eax
    7713306056ad:	4c 89 fd             	mov    rbp,r15
    7713306056b0:	e9 8b f4 ff ff       	jmp    0x771330604b40
    7713306056b5:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    7713306056ba:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    7713306056be:	89 03                	mov    DWORD PTR [rbx],eax
    7713306056c0:	44 89 6b 04          	mov    DWORD PTR [rbx+0x4],r13d
    7713306056c4:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7713306056c9:	89 43 08             	mov    DWORD PTR [rbx+0x8],eax
    7713306056cc:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    7713306056d1:	89 43 0c             	mov    DWORD PTR [rbx+0xc],eax
    7713306056d4:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    7713306056d8:	89 43 1c             	mov    DWORD PTR [rbx+0x1c],eax
    7713306056db:	89 4b 20             	mov    DWORD PTR [rbx+0x20],ecx
    7713306056de:	44 89 6b 24          	mov    DWORD PTR [rbx+0x24],r13d
    7713306056e2:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    7713306056e7:	89 43 28             	mov    DWORD PTR [rbx+0x28],eax
    7713306056ea:	c7 83 bc 00 00 00 ee 	mov    DWORD PTR [rbx+0xbc],0x101ee
    7713306056f1:	01 01 00 
    7713306056f4:	44 89 a3 e4 00 00 00 	mov    DWORD PTR [rbx+0xe4],r12d
    7713306056fb:	89 93 e8 00 00 00    	mov    DWORD PTR [rbx+0xe8],edx
    771330605701:	48 c7 83 ec 00 00 00 	mov    QWORD PTR [rbx+0xec],0x0
    771330605708:	00 00 00 00 
    77133060570c:	48 c7 83 f8 00 00 00 	mov    QWORD PTR [rbx+0xf8],0x0
    771330605713:	00 00 00 00 
    771330605717:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    77133060571b:	89 83 00 01 00 00    	mov    DWORD PTR [rbx+0x100],eax
    771330605721:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    771330605725:	89 83 14 01 00 00    	mov    DWORD PTR [rbx+0x114],eax
    77133060572b:	c7 83 24 01 00 00 02 	mov    DWORD PTR [rbx+0x124],0x2
    771330605732:	00 00 00 
    771330605735:	c6 83 28 01 00 00 00 	mov    BYTE PTR [rbx+0x128],0x0
    77133060573c:	c7 83 34 01 00 00 18 	mov    DWORD PTR [rbx+0x134],0x18
    771330605743:	00 00 00 
    771330605746:	44 89 83 5c 01 00 00 	mov    DWORD PTR [rbx+0x15c],r8d
    77133060574d:	48 b8 e0 da 8f a8 39 	movabs rax,0x6039a88fdae0
    771330605754:	60 00 00 
    771330605757:	48 89 df             	mov    rdi,rbx
    77133060575a:	be 2a 00 00 00       	mov    esi,0x2a
    77133060575f:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    771330605764:	ff d0                	call   rax
    771330605766:	0f b6 8b 28 01 00 00 	movzx  ecx,BYTE PTR [rbx+0x128]
    77133060576d:	e9 b1 f6 ff ff       	jmp    0x771330604e23
