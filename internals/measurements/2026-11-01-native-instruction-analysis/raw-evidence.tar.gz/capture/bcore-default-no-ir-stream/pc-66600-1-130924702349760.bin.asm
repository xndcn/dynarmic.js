
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66600-1-130924702349760.bin:     file format binary


Disassembly of section .data:

00007713486039c0 <.data>:
    7713486039c0:	8b 88 00 00 14 00    	mov    ecx,DWORD PTR [rax+0x140000]
    7713486039c6:	8d 51 01             	lea    edx,[rcx+0x1]
    7713486039c9:	89 90 00 00 14 00    	mov    DWORD PTR [rax+0x140000],edx
    7713486039cf:	48 81 f9 ff 00 00 00 	cmp    rcx,0xff
    7713486039d6:	0f 87 15 f1 ff e7    	ja     0x771330602af1
    7713486039dc:	c7 84 88 04 00 14 00 	mov    DWORD PTR [rax+rcx*4+0x140004],0x8
    7713486039e3:	08 00 00 00 
    7713486039e7:	e9 05 f1 ff e7       	jmp    0x771330602af1
    7713486039ec:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    7713486039f3:	28 04 01 00 
    7713486039f7:	b8 28 04 01 00       	mov    eax,0x10428
    7713486039fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603a03:	04 00 00 00 
    771348603a07:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    771348603a0e:	01 00 00 00 
    771348603a12:	8d 50 04             	lea    edx,[rax+0x4]
    771348603a15:	be 28 04 01 00       	mov    esi,0x10428
    771348603a1a:	4c 89 ef             	mov    rdi,r13
    771348603a1d:	e8 3e c7 ff e7       	call   0x771330600160
    771348603a22:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603a29:	00 
    771348603a2a:	0f 84 f4 f0 ff e7    	je     0x771330602b24
    771348603a30:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603a37:	04 00 00 00 
    771348603a3b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1
    771348603a42:	01 00 00 00 
    771348603a46:	58                   	pop    rax
    771348603a47:	e9 eb f3 ff e7       	jmp    0x771330602e37
    771348603a4c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    771348603a53:	2c 04 01 00 
    771348603a57:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603a5e:	04 00 00 00 
    771348603a62:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603a69:	02 00 00 00 
    771348603a6d:	ba 2c 04 01 00       	mov    edx,0x1042c
    771348603a72:	4c 89 ef             	mov    rdi,r13
    771348603a75:	4c 89 f6             	mov    rsi,r14
    771348603a78:	41 b8 00 00 01 00    	mov    r8d,0x10000
    771348603a7e:	e8 fd c5 ff e7       	call   0x771330600080
    771348603a83:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603a8a:	04 00 00 00 
    771348603a8e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603a95:	02 00 00 00 
    771348603a99:	58                   	pop    rax
    771348603a9a:	e9 98 f3 ff e7       	jmp    0x771330602e37
    771348603a9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    771348603aa6:	2c 04 01 00 
    771348603aaa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603ab1:	04 00 00 00 
    771348603ab5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603abc:	02 00 00 00 
    771348603ac0:	4c 89 f7             	mov    rdi,r14
    771348603ac3:	89 ce                	mov    esi,ecx
    771348603ac5:	e8 a6 c5 ff e7       	call   0x771330600070
    771348603aca:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603ad1:	00 
    771348603ad2:	0f 84 93 f0 ff e7    	je     0x771330602b6b
    771348603ad8:	eb a9                	jmp    0x771348603a83
    771348603ada:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    771348603ae1:	2c 04 01 00 
    771348603ae5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603aec:	04 00 00 00 
    771348603af0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603af7:	02 00 00 00 
    771348603afb:	4c 89 f7             	mov    rdi,r14
    771348603afe:	89 de                	mov    esi,ebx
    771348603b00:	44 89 e2             	mov    edx,r12d
    771348603b03:	e8 68 c5 ff e7       	call   0x771330600070
    771348603b08:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603b0f:	00 
    771348603b10:	0f 84 77 f0 ff e7    	je     0x771330602b8d
    771348603b16:	e9 68 ff ff ff       	jmp    0x771348603a83
    771348603b1b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1042c
    771348603b22:	2c 04 01 00 
    771348603b26:	b8 2c 04 01 00       	mov    eax,0x1042c
    771348603b2b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603b32:	04 00 00 00 
    771348603b36:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603b3d:	02 00 00 00 
    771348603b41:	8d 50 04             	lea    edx,[rax+0x4]
    771348603b44:	be 2c 04 01 00       	mov    esi,0x1042c
    771348603b49:	4c 89 ef             	mov    rdi,r13
    771348603b4c:	e8 0f c6 ff e7       	call   0x771330600160
    771348603b51:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    771348603b55:	0f 84 73 f0 ff e7    	je     0x771330602bce
    771348603b5b:	eb 0f                	jmp    0x771348603b6c
    771348603b5d:	b8 2c 04 01 00       	mov    eax,0x1042c
    771348603b62:	83 c0 04             	add    eax,0x4
    771348603b65:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771348603b6c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603b73:	04 00 00 00 
    771348603b77:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    771348603b7e:	02 00 00 00 
    771348603b82:	4c 89 ef             	mov    rdi,r13
    771348603b85:	e8 c6 c5 ff e7       	call   0x771330600150
    771348603b8a:	e9 3f f0 ff e7       	jmp    0x771330602bce
    771348603b8f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10430
    771348603b96:	30 04 01 00 
    771348603b9a:	b8 30 04 01 00       	mov    eax,0x10430
    771348603b9f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603ba6:	04 00 00 00 
    771348603baa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    771348603bb1:	03 00 00 00 
    771348603bb5:	8d 50 04             	lea    edx,[rax+0x4]
    771348603bb8:	be 30 04 01 00       	mov    esi,0x10430
    771348603bbd:	4c 89 ef             	mov    rdi,r13
    771348603bc0:	e8 9b c5 ff e7       	call   0x771330600160
    771348603bc5:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603bcc:	00 
    771348603bcd:	0f 84 40 f0 ff e7    	je     0x771330602c13
    771348603bd3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603bda:	04 00 00 00 
    771348603bde:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    771348603be5:	03 00 00 00 
    771348603be9:	58                   	pop    rax
    771348603bea:	e9 48 f2 ff e7       	jmp    0x771330602e37
    771348603bef:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    771348603bf6:	34 04 01 00 
    771348603bfa:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603c01:	02 00 00 00 
    771348603c05:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771348603c0c:	04 00 00 00 
    771348603c10:	ba 34 04 01 00       	mov    edx,0x10434
    771348603c15:	4c 89 ef             	mov    rdi,r13
    771348603c18:	4c 89 f6             	mov    rsi,r14
    771348603c1b:	45 31 c0             	xor    r8d,r8d
    771348603c1e:	e8 5d c4 ff e7       	call   0x771330600080
    771348603c23:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603c2a:	02 00 00 00 
    771348603c2e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771348603c35:	04 00 00 00 
    771348603c39:	58                   	pop    rax
    771348603c3a:	e9 f8 f1 ff e7       	jmp    0x771330602e37
    771348603c3f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    771348603c46:	34 04 01 00 
    771348603c4a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603c51:	02 00 00 00 
    771348603c55:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771348603c5c:	04 00 00 00 
    771348603c60:	4c 89 f7             	mov    rdi,r14
    771348603c63:	89 ce                	mov    esi,ecx
    771348603c65:	e8 d6 c3 ff e7       	call   0x771330600040
    771348603c6a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603c71:	00 
    771348603c72:	0f 84 ce ef ff e7    	je     0x771330602c46
    771348603c78:	eb a9                	jmp    0x771348603c23
    771348603c7a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10434
    771348603c81:	34 04 01 00 
    771348603c85:	b8 34 04 01 00       	mov    eax,0x10434
    771348603c8a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603c91:	02 00 00 00 
    771348603c95:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771348603c9c:	04 00 00 00 
    771348603ca0:	8d 50 02             	lea    edx,[rax+0x2]
    771348603ca3:	be 34 04 01 00       	mov    esi,0x10434
    771348603ca8:	4c 89 ef             	mov    rdi,r13
    771348603cab:	e8 b0 c4 ff e7       	call   0x771330600160
    771348603cb0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603cb7:	00 
    771348603cb8:	0f 84 ae ef ff e7    	je     0x771330602c6c
    771348603cbe:	e9 60 ff ff ff       	jmp    0x771348603c23
    771348603cc3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10436
    771348603cca:	36 04 01 00 
    771348603cce:	b8 36 04 01 00       	mov    eax,0x10436
    771348603cd3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603cda:	02 00 00 00 
    771348603cde:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    771348603ce5:	05 00 00 00 
    771348603ce9:	8d 50 02             	lea    edx,[rax+0x2]
    771348603cec:	be 36 04 01 00       	mov    esi,0x10436
    771348603cf1:	4c 89 ef             	mov    rdi,r13
    771348603cf4:	e8 67 c4 ff e7       	call   0x771330600160
    771348603cf9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603d00:	00 
    771348603d01:	0f 84 9c ef ff e7    	je     0x771330602ca3
    771348603d07:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603d0e:	02 00 00 00 
    771348603d12:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    771348603d19:	05 00 00 00 
    771348603d1d:	58                   	pop    rax
    771348603d1e:	e9 14 f1 ff e7       	jmp    0x771330602e37
    771348603d23:	b8 38 04 01 00       	mov    eax,0x10438
    771348603d28:	83 c0 0a             	add    eax,0xa
    771348603d2b:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771348603d32:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603d39:	02 00 00 00 
    771348603d3d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    771348603d44:	06 00 00 00 
    771348603d48:	be 38 04 01 00       	mov    esi,0x10438
    771348603d4d:	ba 38 04 01 00       	mov    edx,0x10438
    771348603d52:	4c 89 ef             	mov    rdi,r13
    771348603d55:	e8 06 c4 ff e7       	call   0x771330600160
    771348603d5a:	e9 7a ef ff e7       	jmp    0x771330602cd9
    771348603d5f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10438
    771348603d66:	38 04 01 00 
    771348603d6a:	b8 38 04 01 00       	mov    eax,0x10438
    771348603d6f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603d76:	02 00 00 00 
    771348603d7a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    771348603d81:	06 00 00 00 
    771348603d85:	8d 50 02             	lea    edx,[rax+0x2]
    771348603d88:	be 38 04 01 00       	mov    esi,0x10438
    771348603d8d:	4c 89 ef             	mov    rdi,r13
    771348603d90:	e8 cb c3 ff e7       	call   0x771330600160
    771348603d95:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603d9c:	00 
    771348603d9d:	0f 84 83 ef ff e7    	je     0x771330602d26
    771348603da3:	e9 40 ef ff e7       	jmp    0x771330602ce8
    771348603da8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043a
    771348603daf:	3a 04 01 00 
    771348603db3:	b8 3a 04 01 00       	mov    eax,0x1043a
    771348603db8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603dbf:	02 00 00 00 
    771348603dc3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    771348603dca:	07 00 00 00 
    771348603dce:	8d 50 02             	lea    edx,[rax+0x2]
    771348603dd1:	be 3a 04 01 00       	mov    esi,0x1043a
    771348603dd6:	4c 89 ef             	mov    rdi,r13
    771348603dd9:	e8 82 c3 ff e7       	call   0x771330600160
    771348603dde:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603de5:	00 
    771348603de6:	0f 84 66 ef ff e7    	je     0x771330602d52
    771348603dec:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603df3:	02 00 00 00 
    771348603df7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    771348603dfe:	07 00 00 00 
    771348603e02:	58                   	pop    rax
    771348603e03:	e9 2f f0 ff e7       	jmp    0x771330602e37
    771348603e08:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    771348603e0f:	3c 04 01 00 
    771348603e13:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603e1a:	04 00 00 00 
    771348603e1e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    771348603e25:	08 00 00 00 
    771348603e29:	ba 3c 04 01 00       	mov    edx,0x1043c
    771348603e2e:	4c 89 ef             	mov    rdi,r13
    771348603e31:	4c 89 f6             	mov    rsi,r14
    771348603e34:	89 d9                	mov    ecx,ebx
    771348603e36:	45 31 c0             	xor    r8d,r8d
    771348603e39:	e8 42 c2 ff e7       	call   0x771330600080
    771348603e3e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603e45:	04 00 00 00 
    771348603e49:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    771348603e50:	08 00 00 00 
    771348603e54:	58                   	pop    rax
    771348603e55:	e9 dd ef ff e7       	jmp    0x771330602e37
    771348603e5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    771348603e61:	3c 04 01 00 
    771348603e65:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603e6c:	04 00 00 00 
    771348603e70:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    771348603e77:	08 00 00 00 
    771348603e7b:	4c 89 f7             	mov    rdi,r14
    771348603e7e:	89 de                	mov    esi,ebx
    771348603e80:	e8 bb c1 ff e7       	call   0x771330600040
    771348603e85:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603e8c:	00 
    771348603e8d:	75 af                	jne    0x771348603e3e
    771348603e8f:	41 89 c7             	mov    r15d,eax
    771348603e92:	e9 f2 ee ff e7       	jmp    0x771330602d89
    771348603e97:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    771348603e9e:	3c 04 01 00 
    771348603ea2:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603ea9:	04 00 00 00 
    771348603ead:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    771348603eb4:	08 00 00 00 
    771348603eb8:	4c 89 f7             	mov    rdi,r14
    771348603ebb:	e8 80 c1 ff e7       	call   0x771330600040
    771348603ec0:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603ec7:	00 
    771348603ec8:	0f 84 dc ee ff e7    	je     0x771330602daa
    771348603ece:	e9 6b ff ff ff       	jmp    0x771348603e3e
    771348603ed3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1043c
    771348603eda:	3c 04 01 00 
    771348603ede:	b8 3c 04 01 00       	mov    eax,0x1043c
    771348603ee3:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771348603eea:	04 00 00 00 
    771348603eee:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    771348603ef5:	08 00 00 00 
    771348603ef9:	8d 50 04             	lea    edx,[rax+0x4]
    771348603efc:	be 3c 04 01 00       	mov    esi,0x1043c
    771348603f01:	4c 89 ef             	mov    rdi,r13
    771348603f04:	e8 57 c2 ff e7       	call   0x771330600160
    771348603f09:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771348603f10:	00 
    771348603f11:	0f 84 c7 ee ff e7    	je     0x771330602dde
    771348603f17:	e9 22 ff ff ff       	jmp    0x771348603e3e
    771348603f1c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10440
    771348603f23:	40 04 01 00 
    771348603f27:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603f2e:	02 00 00 00 
    771348603f32:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    771348603f39:	09 00 00 00 
    771348603f3d:	4c 89 ef             	mov    rdi,r13
    771348603f40:	be 2a 00 00 00       	mov    esi,0x2a
    771348603f45:	4c 89 f2             	mov    rdx,r14
    771348603f48:	e8 43 c1 ff e7       	call   0x771330600090
    771348603f4d:	e9 ce ee ff e7       	jmp    0x771330602e20
    771348603f52:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771348603f59:	02 00 00 00 
    771348603f5d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    771348603f64:	09 00 00 00 
    771348603f68:	be 40 04 01 00       	mov    esi,0x10440
    771348603f6d:	ba 40 04 01 00       	mov    edx,0x10440
    771348603f72:	4c 89 ef             	mov    rdi,r13
    771348603f75:	e8 e6 c1 ff e7       	call   0x771330600160
    771348603f7a:	e9 a1 ee ff e7       	jmp    0x771330602e20
    771348603f7f:	c2 08 00             	ret    0x8
