
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65978-0-130924702360570.bin:     file format binary


Disassembly of section .data:

00007713486063fa <.data>:
    7713486063fa:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    771348606401:	01 
    771348606402:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771348606409:	00 
    77134860640a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    771348606411:	c2 08 00             	ret    0x8
