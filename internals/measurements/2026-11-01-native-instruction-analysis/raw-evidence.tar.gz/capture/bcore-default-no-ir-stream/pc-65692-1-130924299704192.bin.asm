
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65692-1-130924299704192.bin:     file format binary


Disassembly of section .data:

0000771330605780 <.data>:
    771330605780:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330605787:	8b 88 34 00 10 00    	mov    ecx,DWORD PTR [rax+0x100034]
    77133060578d:	ff c1                	inc    ecx
    77133060578f:	89 88 34 00 10 00    	mov    DWORD PTR [rax+0x100034],ecx
    771330605795:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060579b:	0f 84 7f 0c 00 18    	je     0x771348606420
    7713306057a1:	50                   	push   rax
    7713306057a2:	41 8b 4d 30          	mov    ecx,DWORD PTR [r13+0x30]
    7713306057a6:	f6 c1 03             	test   cl,0x3
    7713306057a9:	0f 85 9d 0c 00 18    	jne    0x77134860644c
    7713306057af:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7713306057b6:	41 8b 55 14          	mov    edx,DWORD PTR [r13+0x14]
    7713306057ba:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306057c1:	48 89 ce             	mov    rsi,rcx
    7713306057c4:	48 c1 ee 0c          	shr    rsi,0xc
    7713306057c8:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7713306057cc:	48 85 c0             	test   rax,rax
    7713306057cf:	0f 84 ca 0c 00 18    	je     0x77134860649f
    7713306057d5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306057db:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7713306057de:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009c
    7713306057e5:	9c 00 01 00 
    7713306057e9:	0f 84 eb 0c 00 18    	je     0x7713486064da
    7713306057ef:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009c
    7713306057f6:	9c 00 01 00 
    7713306057fa:	0f 84 da 0c 00 18    	je     0x7713486064da
    771330605800:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330605803:	0f 85 12 0d 00 18    	jne    0x77134860651b
    771330605809:	58                   	pop    rax
    77133060580a:	e9 0f 00 00 00       	jmp    0x77133060581e
    77133060580f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330605816:	00 
    771330605817:	74 f0                	je     0x771330605809
    771330605819:	e9 65 0c 00 18       	jmp    0x771348606483
    77133060581e:	50                   	push   rax
    77133060581f:	41 8b 5d 34          	mov    ebx,DWORD PTR [r13+0x34]
    771330605823:	f6 c3 03             	test   bl,0x3
    771330605826:	0f 85 21 0d 00 18    	jne    0x77134860654d
    77133060582c:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    771330605833:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    771330605837:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    77133060583e:	48 89 d9             	mov    rcx,rbx
    771330605841:	48 c1 e9 0c          	shr    rcx,0xc
    771330605845:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    771330605849:	48 85 c0             	test   rax,rax
    77133060584c:	0f 84 50 0d 00 18    	je     0x7713486065a2
    771330605852:	89 d9                	mov    ecx,ebx
    771330605854:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060585a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    77133060585d:	83 c3 04             	add    ebx,0x4
    771330605860:	41 89 5d 34          	mov    DWORD PTR [r13+0x34],ebx
    771330605864:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1009e
    77133060586b:	9e 00 01 00 
    77133060586f:	0f 84 68 0d 00 18    	je     0x7713486065dd
    771330605875:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1009e
    77133060587c:	9e 00 01 00 
    771330605880:	0f 84 57 0d 00 18    	je     0x7713486065dd
    771330605886:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    77133060588a:	0f 85 8f 0d 00 18    	jne    0x77134860661f
    771330605890:	58                   	pop    rax
    771330605891:	e9 0f 00 00 00       	jmp    0x7713306058a5
    771330605896:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77133060589d:	00 
    77133060589e:	74 f0                	je     0x771330605890
    7713306058a0:	e9 e1 0c 00 18       	jmp    0x771348606586
    7713306058a5:	50                   	push   rax
    7713306058a6:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7713306058aa:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306058b1:	31 d2                	xor    edx,edx
    7713306058b3:	89 c6                	mov    esi,eax
    7713306058b5:	ff c6                	inc    esi
    7713306058b7:	0f 94 c2             	sete   dl
    7713306058ba:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    7713306058be:	c1 e8 1f             	shr    eax,0x1f
    7713306058c1:	89 f7                	mov    edi,esi
    7713306058c3:	c1 ef 1f             	shr    edi,0x1f
    7713306058c6:	f7 d0                	not    eax
    7713306058c8:	21 f8                	and    eax,edi
    7713306058ca:	31 db                	xor    ebx,ebx
    7713306058cc:	85 f6                	test   esi,esi
    7713306058ce:	0f 94 c3             	sete   bl
    7713306058d1:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    7713306058d8:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    7713306058df:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    7713306058e6:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    7713306058ed:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    7713306058f4:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    7713306058fb:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    771330605902:	81 f9 a0 00 01 00    	cmp    ecx,0x100a0
    771330605908:	0f 84 43 0d 00 18    	je     0x771348606651
    77133060590e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a0
    771330605915:	a0 00 01 00 
    771330605919:	0f 84 32 0d 00 18    	je     0x771348606651
    77133060591f:	58                   	pop    rax
    771330605920:	50                   	push   rax
    771330605921:	41 c7 45 00 06 00 00 	mov    DWORD PTR [r13+0x0],0x6
    771330605928:	00 
    771330605929:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a2
    771330605930:	a2 00 01 00 
    771330605934:	0f 84 77 0d 00 18    	je     0x7713486066b1
    77133060593a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a2
    771330605941:	a2 00 01 00 
    771330605945:	0f 84 66 0d 00 18    	je     0x7713486066b1
    77133060594b:	58                   	pop    rax
    77133060594c:	50                   	push   rax
    77133060594d:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    771330605951:	f6 c1 03             	test   cl,0x3
    771330605954:	0f 85 b7 0d 00 18    	jne    0x771348606711
    77133060595a:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330605961:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    771330605965:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    77133060596c:	48 89 ce             	mov    rsi,rcx
    77133060596f:	48 c1 ee 0c          	shr    rsi,0xc
    771330605973:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330605977:	48 85 c0             	test   rax,rax
    77133060597a:	0f 84 e4 0d 00 18    	je     0x771348606764
    771330605980:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605986:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330605989:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a4
    771330605990:	a4 00 01 00 
    771330605994:	0f 84 05 0e 00 18    	je     0x77134860679f
    77133060599a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a4
    7713306059a1:	a4 00 01 00 
    7713306059a5:	0f 84 f4 0d 00 18    	je     0x77134860679f
    7713306059ab:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    7713306059ae:	0f 85 2c 0e 00 18    	jne    0x7713486067e0
    7713306059b4:	58                   	pop    rax
    7713306059b5:	e9 0f 00 00 00       	jmp    0x7713306059c9
    7713306059ba:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306059c1:	00 
    7713306059c2:	74 f0                	je     0x7713306059b4
    7713306059c4:	e9 7f 0d 00 18       	jmp    0x771348606748
    7713306059c9:	50                   	push   rax
    7713306059ca:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7713306059ce:	41 8b 4d 1c          	mov    ecx,DWORD PTR [r13+0x1c]
    7713306059d2:	31 d2                	xor    edx,edx
    7713306059d4:	31 f6                	xor    esi,esi
    7713306059d6:	89 cf                	mov    edi,ecx
    7713306059d8:	29 c7                	sub    edi,eax
    7713306059da:	0f 94 c2             	sete   dl
    7713306059dd:	40 0f 93 c6          	setae  sil
    7713306059e1:	c1 ef 1f             	shr    edi,0x1f
    7713306059e4:	c1 e9 1f             	shr    ecx,0x1f
    7713306059e7:	c1 e8 1f             	shr    eax,0x1f
    7713306059ea:	89 fb                	mov    ebx,edi
    7713306059ec:	31 cb                	xor    ebx,ecx
    7713306059ee:	31 c8                	xor    eax,ecx
    7713306059f0:	21 d8                	and    eax,ebx
    7713306059f2:	31 f8                	xor    eax,edi
    7713306059f4:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7713306059fb:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330605a02:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330605a09:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    771330605a10:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    771330605a17:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a6
    771330605a1e:	a6 00 01 00 
    771330605a22:	0f 84 ea 0d 00 18    	je     0x771348606812
    771330605a28:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a6
    771330605a2f:	a6 00 01 00 
    771330605a33:	0f 84 d9 0d 00 18    	je     0x771348606812
    771330605a39:	58                   	pop    rax
    771330605a3a:	50                   	push   rax
    771330605a3b:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330605a42:	00 
    771330605a43:	74 28                	je     0x771330605a6d
    771330605a45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    771330605a4c:	a8 00 01 00 
    771330605a50:	0f 84 1c 0e 00 18    	je     0x771348606872
    771330605a56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    771330605a5d:	a8 00 01 00 
    771330605a61:	0f 84 0b 0e 00 18    	je     0x771348606872
    771330605a67:	58                   	pop    rax
    771330605a68:	e9 55 00 00 00       	jmp    0x771330605ac2
    771330605a6d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330605a74:	01 
    771330605a75:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100a8
    771330605a7c:	a8 00 01 00 
    771330605a80:	0f 84 35 0e 00 18    	je     0x7713486068bb
    771330605a86:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100a8
    771330605a8d:	a8 00 01 00 
    771330605a91:	0f 84 24 0e 00 18    	je     0x7713486068bb
    771330605a97:	b8 a8 00 01 00       	mov    eax,0x100a8
    771330605a9c:	83 c0 dc             	add    eax,0xffffffdc
    771330605a9f:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330605aa6:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330605aad:	02 00 00 00 
    771330605ab1:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    771330605ab8:	07 00 00 00 
    771330605abc:	58                   	pop    rax
    771330605abd:	e9 5b 03 00 00       	jmp    0x771330605e1d
    771330605ac2:	50                   	push   rax
    771330605ac3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    771330605ac8:	b9 00 00 00 00       	mov    ecx,0x0
    771330605acd:	09 c1                	or     ecx,eax
    771330605acf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330605ad3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100aa
    771330605ada:	aa 00 01 00 
    771330605ade:	0f 84 13 0e 00 18    	je     0x7713486068f7
    771330605ae4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100aa
    771330605aeb:	aa 00 01 00 
    771330605aef:	0f 84 02 0e 00 18    	je     0x7713486068f7
    771330605af5:	58                   	pop    rax
    771330605af6:	50                   	push   rax
    771330605af7:	41 c7 45 00 02 00 00 	mov    DWORD PTR [r13+0x0],0x2
    771330605afe:	00 
    771330605aff:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ae
    771330605b06:	ae 00 01 00 
    771330605b0a:	0f 84 47 0e 00 18    	je     0x771348606957
    771330605b10:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ae
    771330605b17:	ae 00 01 00 
    771330605b1b:	0f 84 36 0e 00 18    	je     0x771348606957
    771330605b21:	58                   	pop    rax
    771330605b22:	50                   	push   rax
    771330605b23:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    771330605b28:	c1 e0 10             	shl    eax,0x10
    771330605b2b:	b9 10 f0 00 00       	mov    ecx,0xf010
    771330605b30:	09 c1                	or     ecx,eax
    771330605b32:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330605b36:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b0
    771330605b3d:	b0 00 01 00 
    771330605b41:	0f 84 70 0e 00 18    	je     0x7713486069b7
    771330605b47:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b0
    771330605b4e:	b0 00 01 00 
    771330605b52:	0f 84 5f 0e 00 18    	je     0x7713486069b7
    771330605b58:	58                   	pop    rax
    771330605b59:	50                   	push   rax
    771330605b5a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330605b5e:	f6 c1 03             	test   cl,0x3
    771330605b61:	0f 85 b0 0e 00 18    	jne    0x771348606a17
    771330605b67:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330605b6e:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    771330605b72:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330605b79:	48 89 ce             	mov    rsi,rcx
    771330605b7c:	48 c1 ee 0c          	shr    rsi,0xc
    771330605b80:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330605b84:	48 85 c0             	test   rax,rax
    771330605b87:	0f 84 dd 0e 00 18    	je     0x771348606a6a
    771330605b8d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605b93:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330605b96:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b4
    771330605b9d:	b4 00 01 00 
    771330605ba1:	0f 84 fe 0e 00 18    	je     0x771348606aa5
    771330605ba7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b4
    771330605bae:	b4 00 01 00 
    771330605bb2:	0f 84 ed 0e 00 18    	je     0x771348606aa5
    771330605bb8:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330605bbb:	0f 85 25 0f 00 18    	jne    0x771348606ae6
    771330605bc1:	58                   	pop    rax
    771330605bc2:	e9 0f 00 00 00       	jmp    0x771330605bd6
    771330605bc7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330605bce:	00 
    771330605bcf:	74 f0                	je     0x771330605bc1
    771330605bd1:	e9 78 0e 00 18       	jmp    0x771348606a4e
    771330605bd6:	50                   	push   rax
    771330605bd7:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    771330605bdb:	f6 c3 03             	test   bl,0x3
    771330605bde:	0f 85 34 0f 00 18    	jne    0x771348606b18
    771330605be4:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330605beb:	48 89 d8             	mov    rax,rbx
    771330605bee:	48 c1 e8 0c          	shr    rax,0xc
    771330605bf2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605bf7:	48 85 c0             	test   rax,rax
    771330605bfa:	0f 84 6a 0f 00 18    	je     0x771348606b6a
    771330605c00:	89 d9                	mov    ecx,ebx
    771330605c02:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605c08:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    771330605c0c:	89 de                	mov    esi,ebx
    771330605c0e:	83 c6 04             	add    esi,0x4
    771330605c11:	89 f0                	mov    eax,esi
    771330605c13:	c1 e8 0c             	shr    eax,0xc
    771330605c16:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605c1b:	48 85 c0             	test   rax,rax
    771330605c1e:	0f 84 83 0f 00 18    	je     0x771348606ba7
    771330605c24:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605c2a:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605c2d:	8d 4b 08             	lea    ecx,[rbx+0x8]
    771330605c30:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    771330605c34:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330605c3b:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    771330605c3f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100b6
    771330605c46:	b6 00 01 00 
    771330605c4a:	0f 84 93 0f 00 18    	je     0x771348606be3
    771330605c50:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100b6
    771330605c57:	b6 00 01 00 
    771330605c5b:	0f 84 82 0f 00 18    	je     0x771348606be3
    771330605c61:	58                   	pop    rax
    771330605c62:	50                   	push   rax
    771330605c63:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    771330605c6a:	00 
    771330605c6b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100ba
    771330605c72:	ba 00 01 00 
    771330605c76:	0f 84 b0 0f 00 18    	je     0x771348606c2c
    771330605c7c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100ba
    771330605c83:	ba 00 01 00 
    771330605c87:	0f 84 9f 0f 00 18    	je     0x771348606c2c
    771330605c8d:	58                   	pop    rax
    771330605c8e:	50                   	push   rax
    771330605c8f:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330605c93:	f6 c3 03             	test   bl,0x3
    771330605c96:	0f 85 f0 0f 00 18    	jne    0x771348606c8c
    771330605c9c:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330605ca3:	48 89 d8             	mov    rax,rbx
    771330605ca6:	48 c1 e8 0c          	shr    rax,0xc
    771330605caa:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605caf:	48 85 c0             	test   rax,rax
    771330605cb2:	0f 84 26 10 00 18    	je     0x771348606cde
    771330605cb8:	89 d9                	mov    ecx,ebx
    771330605cba:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605cc0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330605cc3:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    771330605cc7:	8d 73 04             	lea    esi,[rbx+0x4]
    771330605cca:	89 f0                	mov    eax,esi
    771330605ccc:	c1 e8 0c             	shr    eax,0xc
    771330605ccf:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605cd4:	48 85 c0             	test   rax,rax
    771330605cd7:	0f 84 3c 10 00 18    	je     0x771348606d19
    771330605cdd:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605ce3:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605ce6:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    771330605cea:	8d 73 08             	lea    esi,[rbx+0x8]
    771330605ced:	89 f0                	mov    eax,esi
    771330605cef:	c1 e8 0c             	shr    eax,0xc
    771330605cf2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605cf7:	48 85 c0             	test   rax,rax
    771330605cfa:	0f 84 55 10 00 18    	je     0x771348606d55
    771330605d00:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605d06:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605d09:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    771330605d0d:	8d 73 0c             	lea    esi,[rbx+0xc]
    771330605d10:	89 f0                	mov    eax,esi
    771330605d12:	c1 e8 0c             	shr    eax,0xc
    771330605d15:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605d1a:	48 85 c0             	test   rax,rax
    771330605d1d:	0f 84 6e 10 00 18    	je     0x771348606d91
    771330605d23:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605d29:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605d2c:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330605d30:	8d 73 10             	lea    esi,[rbx+0x10]
    771330605d33:	89 f0                	mov    eax,esi
    771330605d35:	c1 e8 0c             	shr    eax,0xc
    771330605d38:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605d3d:	48 85 c0             	test   rax,rax
    771330605d40:	0f 84 87 10 00 18    	je     0x771348606dcd
    771330605d46:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605d4c:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605d4f:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    771330605d53:	8d 73 14             	lea    esi,[rbx+0x14]
    771330605d56:	89 f0                	mov    eax,esi
    771330605d58:	c1 e8 0c             	shr    eax,0xc
    771330605d5b:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605d60:	48 85 c0             	test   rax,rax
    771330605d63:	0f 84 a0 10 00 18    	je     0x771348606e09
    771330605d69:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605d6f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605d72:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    771330605d76:	89 de                	mov    esi,ebx
    771330605d78:	83 c6 18             	add    esi,0x18
    771330605d7b:	89 f0                	mov    eax,esi
    771330605d7d:	c1 e8 0c             	shr    eax,0xc
    771330605d80:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330605d85:	48 85 c0             	test   rax,rax
    771330605d88:	0f 84 b7 10 00 18    	je     0x771348606e45
    771330605d8e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330605d94:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330605d97:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    771330605d9b:	8d 43 1c             	lea    eax,[rbx+0x1c]
    771330605d9e:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    771330605da2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100bc
    771330605da9:	bc 00 01 00 
    771330605dad:	0f 84 ce 10 00 18    	je     0x771348606e81
    771330605db3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100bc
    771330605dba:	bc 00 01 00 
    771330605dbe:	0f 84 bd 10 00 18    	je     0x771348606e81
    771330605dc4:	58                   	pop    rax
    771330605dc5:	50                   	push   rax
    771330605dc6:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330605dcd:	a8 01                	test   al,0x1
    771330605dcf:	0f 85 f5 10 00 18    	jne    0x771348606eca
    771330605dd5:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330605ddc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330605de3:	01 
    771330605de4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x100be
    771330605deb:	be 00 01 00 
    771330605def:	0f 84 0b 11 00 18    	je     0x771348606f00
    771330605df5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x100be
    771330605dfc:	be 00 01 00 
    771330605e00:	0f 84 fa 10 00 18    	je     0x771348606f00
    771330605e06:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330605e0d:	02 00 00 00 
    771330605e11:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xf
    771330605e18:	0f 00 00 00 
    771330605e1c:	58                   	pop    rax
    771330605e1d:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330605e24:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330605e2b:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330605e32:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330605e39:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330605e40:	39 f1                	cmp    ecx,esi
    771330605e42:	0f 83 e5 10 00 18    	jae    0x771348606f2d
    771330605e48:	81 fa 9c 00 01 00    	cmp    edx,0x1009c
    771330605e4e:	75 14                	jne    0x771330605e64
    771330605e50:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330605e57:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330605e5e:	00 
    771330605e5f:	e9 1c f9 ff ff       	jmp    0x771330605780
    771330605e64:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330605e6b:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330605e71:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330605e74:	0f 85 b3 10 00 18    	jne    0x771348606f2d
    771330605e7a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330605e81:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330605e88:	00 
    771330605e89:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330605e8e:	ff e0                	jmp    rax
