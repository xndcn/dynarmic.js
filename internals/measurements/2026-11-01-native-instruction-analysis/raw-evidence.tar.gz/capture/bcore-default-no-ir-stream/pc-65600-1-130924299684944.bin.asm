
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65600-1-130924299684944.bin:     file format binary


Disassembly of section .data:

0000771330600c50 <.data>:
    771330600c50:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    771330600c57:	3d 00 00 00 00       	cmp    eax,0x0
    771330600c5c:	0f 95 c2             	setne  dl
    771330600c5f:	b9 40 00 01 00       	mov    ecx,0x10040
    771330600c64:	29 c8                	sub    eax,ecx
    771330600c66:	3d 4e 00 00 00       	cmp    eax,0x4e
    771330600c6b:	0f 96 c3             	setbe  bl
    771330600c6e:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    771330600c75:	81 fe 00 00 00 00    	cmp    esi,0x0
    771330600c7b:	0f 94 c0             	sete   al
    771330600c7e:	29 ce                	sub    esi,ecx
    771330600c80:	81 fe 4e 00 00 00    	cmp    esi,0x4e
    771330600c86:	0f 97 c1             	seta   cl
    771330600c89:	84 da                	test   dl,bl
    771330600c8b:	0f 85 2f 01 00 18    	jne    0x771348600dc0
    771330600c91:	08 c8                	or     al,cl
    771330600c93:	0f 84 27 01 00 18    	je     0x771348600dc0
    771330600c99:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330600ca0:	8b 88 08 00 10 00    	mov    ecx,DWORD PTR [rax+0x100008]
    771330600ca6:	ff c1                	inc    ecx
    771330600ca8:	89 88 08 00 10 00    	mov    DWORD PTR [rax+0x100008],ecx
    771330600cae:	81 f9 14 cd 00 00    	cmp    ecx,0xcd14
    771330600cb4:	0f 84 1c 01 00 18    	je     0x771348600dd6
    771330600cba:	50                   	push   rax
    771330600cbb:	41 c7 45 28 01 3c 00 	mov    DWORD PTR [r13+0x28],0x3c01
    771330600cc2:	00 
    771330600cc3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10040
    771330600cca:	40 00 01 00 
    771330600cce:	0f 84 2e 01 00 18    	je     0x771348600e02
    771330600cd4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10040
    771330600cdb:	40 00 01 00 
    771330600cdf:	0f 84 1d 01 00 18    	je     0x771348600e02
    771330600ce5:	58                   	pop    rax
    771330600ce6:	50                   	push   rax
    771330600ce7:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    771330600cec:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10044
    771330600cf3:	44 00 01 00 
    771330600cf7:	0f 84 65 01 00 18    	je     0x771348600e62
    771330600cfd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10044
    771330600d04:	44 00 01 00 
    771330600d08:	0f 84 54 01 00 18    	je     0x771348600e62
    771330600d0e:	58                   	pop    rax
    771330600d0f:	50                   	push   rax
    771330600d10:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330600d14:	f6 c1 03             	test   cl,0x3
    771330600d17:	0f 85 a5 01 00 18    	jne    0x771348600ec2
    771330600d1d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600d24:	48 89 ca             	mov    rdx,rcx
    771330600d27:	48 c1 ea 0c          	shr    rdx,0xc
    771330600d2b:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330600d2f:	48 85 c0             	test   rax,rax
    771330600d32:	0f 84 da 01 00 18    	je     0x771348600f12
    771330600d38:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600d3e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330600d41:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    771330600d45:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10046
    771330600d4c:	46 00 01 00 
    771330600d50:	0f 84 f7 01 00 18    	je     0x771348600f4d
    771330600d56:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10046
    771330600d5d:	46 00 01 00 
    771330600d61:	0f 84 e6 01 00 18    	je     0x771348600f4d
    771330600d67:	58                   	pop    rax
    771330600d68:	50                   	push   rax
    771330600d69:	41 83 45 28 04       	add    DWORD PTR [r13+0x28],0x4
    771330600d6e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10048
    771330600d75:	48 00 01 00 
    771330600d79:	0f 84 17 02 00 18    	je     0x771348600f96
    771330600d7f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10048
    771330600d86:	48 00 01 00 
    771330600d8a:	0f 84 06 02 00 18    	je     0x771348600f96
    771330600d90:	58                   	pop    rax
    771330600d91:	50                   	push   rax
    771330600d92:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330600d96:	f6 c1 03             	test   cl,0x3
    771330600d99:	0f 85 57 02 00 18    	jne    0x771348600ff6
    771330600d9f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600da6:	48 89 ca             	mov    rdx,rcx
    771330600da9:	48 c1 ea 0c          	shr    rdx,0xc
    771330600dad:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330600db1:	48 85 c0             	test   rax,rax
    771330600db4:	0f 84 8c 02 00 18    	je     0x771348601046
    771330600dba:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600dc0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330600dc3:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330600dc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004a
    771330600dce:	4a 00 01 00 
    771330600dd2:	0f 84 a9 02 00 18    	je     0x771348601081
    771330600dd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004a
    771330600ddf:	4a 00 01 00 
    771330600de3:	0f 84 98 02 00 18    	je     0x771348601081
    771330600de9:	58                   	pop    rax
    771330600dea:	50                   	push   rax
    771330600deb:	41 c7 45 00 01 00 00 	mov    DWORD PTR [r13+0x0],0x1
    771330600df2:	00 
    771330600df3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004c
    771330600dfa:	4c 00 01 00 
    771330600dfe:	0f 84 c6 02 00 18    	je     0x7713486010ca
    771330600e04:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004c
    771330600e0b:	4c 00 01 00 
    771330600e0f:	0f 84 b5 02 00 18    	je     0x7713486010ca
    771330600e15:	58                   	pop    rax
    771330600e16:	50                   	push   rax
    771330600e17:	41 c7 45 2c 05 3c 00 	mov    DWORD PTR [r13+0x2c],0x3c05
    771330600e1e:	00 
    771330600e1f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1004e
    771330600e26:	4e 00 01 00 
    771330600e2a:	0f 84 fa 02 00 18    	je     0x77134860112a
    771330600e30:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1004e
    771330600e37:	4e 00 01 00 
    771330600e3b:	0f 84 e9 02 00 18    	je     0x77134860112a
    771330600e41:	58                   	pop    rax
    771330600e42:	50                   	push   rax
    771330600e43:	41 c1 65 2c 02       	shl    DWORD PTR [r13+0x2c],0x2
    771330600e48:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10052
    771330600e4f:	52 00 01 00 
    771330600e53:	0f 84 31 03 00 18    	je     0x77134860118a
    771330600e59:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10052
    771330600e60:	52 00 01 00 
    771330600e64:	0f 84 20 03 00 18    	je     0x77134860118a
    771330600e6a:	58                   	pop    rax
    771330600e6b:	50                   	push   rax
    771330600e6c:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    771330600e70:	8d 48 fc             	lea    ecx,[rax-0x4]
    771330600e73:	a8 03                	test   al,0x3
    771330600e75:	0f 85 6f 03 00 18    	jne    0x7713486011ea
    771330600e7b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330600e82:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    771330600e86:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600e8d:	89 ce                	mov    esi,ecx
    771330600e8f:	c1 ee 0c             	shr    esi,0xc
    771330600e92:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330600e96:	48 85 c0             	test   rax,rax
    771330600e99:	0f 84 9e 03 00 18    	je     0x77134860123d
    771330600e9f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600ea5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330600ea8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10054
    771330600eaf:	54 00 01 00 
    771330600eb3:	0f 84 bf 03 00 18    	je     0x771348601278
    771330600eb9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10054
    771330600ec0:	54 00 01 00 
    771330600ec4:	0f 84 ae 03 00 18    	je     0x771348601278
    771330600eca:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330600ecd:	0f 85 e6 03 00 18    	jne    0x7713486012b9
    771330600ed3:	58                   	pop    rax
    771330600ed4:	e9 0f 00 00 00       	jmp    0x771330600ee8
    771330600ed9:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330600ee0:	00 
    771330600ee1:	74 f0                	je     0x771330600ed3
    771330600ee3:	e9 39 03 00 18       	jmp    0x771348601221
    771330600ee8:	50                   	push   rax
    771330600ee9:	41 c7 45 28 03 3c 00 	mov    DWORD PTR [r13+0x28],0x3c03
    771330600ef0:	00 
    771330600ef1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10056
    771330600ef8:	56 00 01 00 
    771330600efc:	0f 84 e9 03 00 18    	je     0x7713486012eb
    771330600f02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10056
    771330600f09:	56 00 01 00 
    771330600f0d:	0f 84 d8 03 00 18    	je     0x7713486012eb
    771330600f13:	58                   	pop    rax
    771330600f14:	50                   	push   rax
    771330600f15:	41 c1 65 28 02       	shl    DWORD PTR [r13+0x28],0x2
    771330600f1a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005a
    771330600f21:	5a 00 01 00 
    771330600f25:	0f 84 20 04 00 18    	je     0x77134860134b
    771330600f2b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005a
    771330600f32:	5a 00 01 00 
    771330600f36:	0f 84 0f 04 00 18    	je     0x77134860134b
    771330600f3c:	58                   	pop    rax
    771330600f3d:	50                   	push   rax
    771330600f3e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330600f42:	f6 c1 03             	test   cl,0x3
    771330600f45:	0f 85 60 04 00 18    	jne    0x7713486013ab
    771330600f4b:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330600f52:	48 89 ca             	mov    rdx,rcx
    771330600f55:	48 c1 ea 0c          	shr    rdx,0xc
    771330600f59:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330600f5d:	48 85 c0             	test   rax,rax
    771330600f60:	0f 84 95 04 00 18    	je     0x7713486013fb
    771330600f66:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330600f6c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330600f6f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330600f73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005c
    771330600f7a:	5c 00 01 00 
    771330600f7e:	0f 84 b2 04 00 18    	je     0x771348601436
    771330600f84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005c
    771330600f8b:	5c 00 01 00 
    771330600f8f:	0f 84 a1 04 00 18    	je     0x771348601436
    771330600f95:	58                   	pop    rax
    771330600f96:	50                   	push   rax
    771330600f97:	41 0f b7 45 34       	movzx  eax,WORD PTR [r13+0x34]
    771330600f9c:	b9 00 00 00 00       	mov    ecx,0x0
    771330600fa1:	09 c1                	or     ecx,eax
    771330600fa3:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    771330600fa7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1005e
    771330600fae:	5e 00 01 00 
    771330600fb2:	0f 84 c7 04 00 18    	je     0x77134860147f
    771330600fb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1005e
    771330600fbf:	5e 00 01 00 
    771330600fc3:	0f 84 b6 04 00 18    	je     0x77134860147f
    771330600fc9:	58                   	pop    rax
    771330600fca:	50                   	push   rax
    771330600fcb:	41 0f b7 45 30       	movzx  eax,WORD PTR [r13+0x30]
    771330600fd0:	b9 00 00 00 01       	mov    ecx,0x1000000
    771330600fd5:	09 c1                	or     ecx,eax
    771330600fd7:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    771330600fdb:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10062
    771330600fe2:	62 00 01 00 
    771330600fe6:	0f 84 f3 04 00 18    	je     0x7713486014df
    771330600fec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10062
    771330600ff3:	62 00 01 00 
    771330600ff7:	0f 84 e2 04 00 18    	je     0x7713486014df
    771330600ffd:	58                   	pop    rax
    771330600ffe:	50                   	push   rax
    771330600fff:	41 0f b7 45 36       	movzx  eax,WORD PTR [r13+0x36]
    771330601004:	c1 e0 10             	shl    eax,0x10
    771330601007:	b9 18 f0 00 00       	mov    ecx,0xf018
    77133060100c:	09 c1                	or     ecx,eax
    77133060100e:	41 89 4d 34          	mov    DWORD PTR [r13+0x34],ecx
    771330601012:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10066
    771330601019:	66 00 01 00 
    77133060101d:	0f 84 1c 05 00 18    	je     0x77134860153f
    771330601023:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10066
    77133060102a:	66 00 01 00 
    77133060102e:	0f 84 0b 05 00 18    	je     0x77134860153f
    771330601034:	58                   	pop    rax
    771330601035:	50                   	push   rax
    771330601036:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    77133060103a:	8d 48 f8             	lea    ecx,[rax-0x8]
    77133060103d:	a8 03                	test   al,0x3
    77133060103f:	0f 85 5a 05 00 18    	jne    0x77134860159f
    771330601045:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    77133060104c:	41 8b 55 28          	mov    edx,DWORD PTR [r13+0x28]
    771330601050:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601057:	89 ce                	mov    esi,ecx
    771330601059:	c1 ee 0c             	shr    esi,0xc
    77133060105c:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330601060:	48 85 c0             	test   rax,rax
    771330601063:	0f 84 89 05 00 18    	je     0x7713486015f2
    771330601069:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060106f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601072:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006a
    771330601079:	6a 00 01 00 
    77133060107d:	0f 84 aa 05 00 18    	je     0x77134860162d
    771330601083:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006a
    77133060108a:	6a 00 01 00 
    77133060108e:	0f 84 99 05 00 18    	je     0x77134860162d
    771330601094:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330601097:	0f 85 d1 05 00 18    	jne    0x77134860166e
    77133060109d:	58                   	pop    rax
    77133060109e:	e9 0f 00 00 00       	jmp    0x7713306010b2
    7713306010a3:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306010aa:	00 
    7713306010ab:	74 f0                	je     0x77133060109d
    7713306010ad:	e9 24 05 00 18       	jmp    0x7713486015d6
    7713306010b2:	50                   	push   rax
    7713306010b3:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7713306010b8:	b9 00 00 00 00       	mov    ecx,0x0
    7713306010bd:	09 c1                	or     ecx,eax
    7713306010bf:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306010c3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1006c
    7713306010ca:	6c 00 01 00 
    7713306010ce:	0f 84 cc 05 00 18    	je     0x7713486016a0
    7713306010d4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1006c
    7713306010db:	6c 00 01 00 
    7713306010df:	0f 84 bb 05 00 18    	je     0x7713486016a0
    7713306010e5:	58                   	pop    rax
    7713306010e6:	50                   	push   rax
    7713306010e7:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7713306010ec:	c1 e0 10             	shl    eax,0x10
    7713306010ef:	b9 10 f0 00 00       	mov    ecx,0xf010
    7713306010f4:	09 c1                	or     ecx,eax
    7713306010f6:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306010fa:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10070
    771330601101:	70 00 01 00 
    771330601105:	0f 84 f5 05 00 18    	je     0x771348601700
    77133060110b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10070
    771330601112:	70 00 01 00 
    771330601116:	0f 84 e4 05 00 18    	je     0x771348601700
    77133060111c:	58                   	pop    rax
    77133060111d:	50                   	push   rax
    77133060111e:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330601122:	f6 c1 03             	test   cl,0x3
    771330601125:	0f 85 35 06 00 18    	jne    0x771348601760
    77133060112b:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330601132:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    771330601136:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    77133060113d:	48 89 ce             	mov    rsi,rcx
    771330601140:	48 c1 ee 0c          	shr    rsi,0xc
    771330601144:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330601148:	48 85 c0             	test   rax,rax
    77133060114b:	0f 84 62 06 00 18    	je     0x7713486017b3
    771330601151:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601157:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    77133060115a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10074
    771330601161:	74 00 01 00 
    771330601165:	0f 84 83 06 00 18    	je     0x7713486017ee
    77133060116b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10074
    771330601172:	74 00 01 00 
    771330601176:	0f 84 72 06 00 18    	je     0x7713486017ee
    77133060117c:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    77133060117f:	0f 85 aa 06 00 18    	jne    0x77134860182f
    771330601185:	58                   	pop    rax
    771330601186:	e9 0f 00 00 00       	jmp    0x77133060119a
    77133060118b:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330601192:	00 
    771330601193:	74 f0                	je     0x771330601185
    771330601195:	e9 fd 05 00 18       	jmp    0x771348601797
    77133060119a:	50                   	push   rax
    77133060119b:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    7713306011a2:	00 
    7713306011a3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10076
    7713306011aa:	76 00 01 00 
    7713306011ae:	0f 84 ad 06 00 18    	je     0x771348601861
    7713306011b4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10076
    7713306011bb:	76 00 01 00 
    7713306011bf:	0f 84 9c 06 00 18    	je     0x771348601861
    7713306011c5:	58                   	pop    rax
    7713306011c6:	50                   	push   rax
    7713306011c7:	41 8b 4d 2c          	mov    ecx,DWORD PTR [r13+0x2c]
    7713306011cb:	f6 c1 03             	test   cl,0x3
    7713306011ce:	0f 85 ed 06 00 18    	jne    0x7713486018c1
    7713306011d4:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7713306011db:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7713306011df:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306011e6:	48 89 ce             	mov    rsi,rcx
    7713306011e9:	48 c1 ee 0c          	shr    rsi,0xc
    7713306011ed:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7713306011f1:	48 85 c0             	test   rax,rax
    7713306011f4:	0f 84 1a 07 00 18    	je     0x771348601914
    7713306011fa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601200:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601203:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10078
    77133060120a:	78 00 01 00 
    77133060120e:	0f 84 3b 07 00 18    	je     0x77134860194f
    771330601214:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10078
    77133060121b:	78 00 01 00 
    77133060121f:	0f 84 2a 07 00 18    	je     0x77134860194f
    771330601225:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330601228:	0f 85 62 07 00 18    	jne    0x771348601990
    77133060122e:	58                   	pop    rax
    77133060122f:	e9 0f 00 00 00       	jmp    0x771330601243
    771330601234:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77133060123b:	00 
    77133060123c:	74 f0                	je     0x77133060122e
    77133060123e:	e9 b5 06 00 18       	jmp    0x7713486018f8
    771330601243:	50                   	push   rax
    771330601244:	41 c7 45 1c 00 00 00 	mov    DWORD PTR [r13+0x1c],0x0
    77133060124b:	00 
    77133060124c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007a
    771330601253:	7a 00 01 00 
    771330601257:	0f 84 65 07 00 18    	je     0x7713486019c2
    77133060125d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007a
    771330601264:	7a 00 01 00 
    771330601268:	0f 84 54 07 00 18    	je     0x7713486019c2
    77133060126e:	58                   	pop    rax
    77133060126f:	50                   	push   rax
    771330601270:	41 0f b7 45 32       	movzx  eax,WORD PTR [r13+0x32]
    771330601275:	c1 e0 10             	shl    eax,0x10
    771330601278:	b9 00 00 00 00       	mov    ecx,0x0
    77133060127d:	09 c1                	or     ecx,eax
    77133060127f:	41 89 4d 30          	mov    DWORD PTR [r13+0x30],ecx
    771330601283:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1007c
    77133060128a:	7c 00 01 00 
    77133060128e:	0f 84 8e 07 00 18    	je     0x771348601a22
    771330601294:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1007c
    77133060129b:	7c 00 01 00 
    77133060129f:	0f 84 7d 07 00 18    	je     0x771348601a22
    7713306012a5:	58                   	pop    rax
    7713306012a6:	50                   	push   rax
    7713306012a7:	41 c7 45 18 00 00 00 	mov    DWORD PTR [r13+0x18],0x0
    7713306012ae:	00 
    7713306012af:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10080
    7713306012b6:	80 00 01 00 
    7713306012ba:	0f 84 c2 07 00 18    	je     0x771348601a82
    7713306012c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10080
    7713306012c7:	80 00 01 00 
    7713306012cb:	0f 84 b1 07 00 18    	je     0x771348601a82
    7713306012d1:	58                   	pop    rax
    7713306012d2:	50                   	push   rax
    7713306012d3:	41 c7 45 14 01 00 00 	mov    DWORD PTR [r13+0x14],0x1
    7713306012da:	00 
    7713306012db:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10082
    7713306012e2:	82 00 01 00 
    7713306012e6:	0f 84 f6 07 00 18    	je     0x771348601ae2
    7713306012ec:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10082
    7713306012f3:	82 00 01 00 
    7713306012f7:	0f 84 e5 07 00 18    	je     0x771348601ae2
    7713306012fd:	58                   	pop    rax
    7713306012fe:	50                   	push   rax
    7713306012ff:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    771330601303:	8d 48 fc             	lea    ecx,[rax-0x4]
    771330601306:	a8 03                	test   al,0x3
    771330601308:	0f 85 34 08 00 18    	jne    0x771348601b42
    77133060130e:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601315:	89 ca                	mov    edx,ecx
    771330601317:	c1 ea 0c             	shr    edx,0xc
    77133060131a:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    77133060131e:	48 85 c0             	test   rax,rax
    771330601321:	0f 84 6b 08 00 18    	je     0x771348601b92
    771330601327:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060132d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330601330:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    771330601337:	58                   	pop    rax
    771330601338:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    77133060133f:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    771330601346:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    77133060134d:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330601351:	50                   	push   rax
    771330601352:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    771330601356:	8d 48 f8             	lea    ecx,[rax-0x8]
    771330601359:	a8 03                	test   al,0x3
    77133060135b:	0f 85 6c 08 00 18    	jne    0x771348601bcd
    771330601361:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601368:	89 ca                	mov    edx,ecx
    77133060136a:	c1 ea 0c             	shr    edx,0xc
    77133060136d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330601371:	48 85 c0             	test   rax,rax
    771330601374:	0f 84 a3 08 00 18    	je     0x771348601c1d
    77133060137a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601380:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330601383:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    771330601387:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    77133060138e:	8c 00 01 00 
    771330601392:	0f 84 c0 08 00 18    	je     0x771348601c58
    771330601398:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    77133060139f:	8c 00 01 00 
    7713306013a3:	0f 84 af 08 00 18    	je     0x771348601c58
    7713306013a9:	58                   	pop    rax
    7713306013aa:	50                   	push   rax
    7713306013ab:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    7713306013b2:	b9 8e 00 01 00       	mov    ecx,0x1008e
    7713306013b7:	83 c1 04             	add    ecx,0x4
    7713306013ba:	89 ca                	mov    edx,ecx
    7713306013bc:	3d 8e 00 01 00       	cmp    eax,0x1008e
    7713306013c1:	75 07                	jne    0x7713306013ca
    7713306013c3:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    7713306013ca:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    7713306013d1:	02 
    7713306013d2:	0f 43 ca             	cmovae ecx,edx
    7713306013d5:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    7713306013dc:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    7713306013e3:	89 cf                	mov    edi,ecx
    7713306013e5:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    7713306013eb:	75 07                	jne    0x7713306013f4
    7713306013ed:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    7713306013f4:	83 fe 02             	cmp    esi,0x2
    7713306013f7:	0f 43 cf             	cmovae ecx,edi
    7713306013fa:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    771330601401:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330601408:	01 
    771330601409:	3d 8e 00 01 00       	cmp    eax,0x1008e
    77133060140e:	0f 84 8d 08 00 18    	je     0x771348601ca1
    771330601414:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    77133060141a:	0f 84 81 08 00 18    	je     0x771348601ca1
    771330601420:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    771330601427:	28 03 01 00 
    77133060142b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771330601432:	04 00 00 00 
    771330601436:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1c
    77133060143d:	1c 00 00 00 
    771330601441:	58                   	pop    rax
    771330601442:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330601449:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330601450:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330601457:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060145e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330601465:	39 f1                	cmp    ecx,esi
    771330601467:	0f 83 6c 08 00 18    	jae    0x771348601cd9
    77133060146d:	81 fa 40 00 01 00    	cmp    edx,0x10040
    771330601473:	75 14                	jne    0x771330601489
    771330601475:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    77133060147c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330601483:	00 
    771330601484:	e9 10 f8 ff ff       	jmp    0x771330600c99
    771330601489:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330601490:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330601496:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330601499:	0f 85 3a 08 00 18    	jne    0x771348601cd9
    77133060149f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306014a6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306014ad:	00 
    7713306014ae:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7713306014b3:	ff e0                	jmp    rax
