
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66408-1-130924299691472.bin:     file format binary


Disassembly of section .data:

00007713306025d0 <.data>:
    7713306025d0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306025d7:	8b 88 18 00 10 00    	mov    ecx,DWORD PTR [rax+0x100018]
    7713306025dd:	ff c1                	inc    ecx
    7713306025df:	89 88 18 00 10 00    	mov    DWORD PTR [rax+0x100018],ecx
    7713306025e5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7713306025eb:	0f 84 0f 0e 00 18    	je     0x771348603400
    7713306025f1:	50                   	push   rax
    7713306025f2:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    7713306025f6:	f6 c3 03             	test   bl,0x3
    7713306025f9:	0f 85 2d 0e 00 18    	jne    0x77134860342c
    7713306025ff:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330602606:	48 89 d8             	mov    rax,rbx
    771330602609:	48 c1 e8 0c          	shr    rax,0xc
    77133060260d:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602612:	48 85 c0             	test   rax,rax
    771330602615:	0f 84 63 0e 00 18    	je     0x77134860347e
    77133060261b:	89 d9                	mov    ecx,ebx
    77133060261d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602623:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    771330602627:	89 de                	mov    esi,ebx
    771330602629:	83 c6 04             	add    esi,0x4
    77133060262c:	89 f0                	mov    eax,esi
    77133060262e:	c1 e8 0c             	shr    eax,0xc
    771330602631:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602636:	48 85 c0             	test   rax,rax
    771330602639:	0f 84 7c 0e 00 18    	je     0x7713486034bb
    77133060263f:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330602645:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330602648:	8d 4b 08             	lea    ecx,[rbx+0x8]
    77133060264b:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    77133060264f:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330602656:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    77133060265a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    771330602661:	68 03 01 00 
    771330602665:	0f 84 8c 0e 00 18    	je     0x7713486034f7
    77133060266b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    771330602672:	68 03 01 00 
    771330602676:	0f 84 7b 0e 00 18    	je     0x7713486034f7
    77133060267c:	58                   	pop    rax
    77133060267d:	50                   	push   rax
    77133060267e:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330602682:	f6 c3 03             	test   bl,0x3
    771330602685:	0f 85 b5 0e 00 18    	jne    0x771348603540
    77133060268b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330602692:	48 89 d8             	mov    rax,rbx
    771330602695:	48 c1 e8 0c          	shr    rax,0xc
    771330602699:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060269e:	48 85 c0             	test   rax,rax
    7713306026a1:	0f 84 eb 0e 00 18    	je     0x771348603592
    7713306026a7:	89 d9                	mov    ecx,ebx
    7713306026a9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306026af:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7713306026b2:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    7713306026b6:	8d 73 04             	lea    esi,[rbx+0x4]
    7713306026b9:	89 f0                	mov    eax,esi
    7713306026bb:	c1 e8 0c             	shr    eax,0xc
    7713306026be:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306026c3:	48 85 c0             	test   rax,rax
    7713306026c6:	0f 84 01 0f 00 18    	je     0x7713486035cd
    7713306026cc:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7713306026d2:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7713306026d5:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    7713306026d9:	8d 73 08             	lea    esi,[rbx+0x8]
    7713306026dc:	89 f0                	mov    eax,esi
    7713306026de:	c1 e8 0c             	shr    eax,0xc
    7713306026e1:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    7713306026e6:	48 85 c0             	test   rax,rax
    7713306026e9:	0f 84 1a 0f 00 18    	je     0x771348603609
    7713306026ef:	81 e6 ff 0f 00 00    	and    esi,0xfff
    7713306026f5:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7713306026f8:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    7713306026fc:	8d 73 0c             	lea    esi,[rbx+0xc]
    7713306026ff:	89 f0                	mov    eax,esi
    771330602701:	c1 e8 0c             	shr    eax,0xc
    771330602704:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602709:	48 85 c0             	test   rax,rax
    77133060270c:	0f 84 33 0f 00 18    	je     0x771348603645
    771330602712:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330602718:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    77133060271b:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    77133060271f:	89 de                	mov    esi,ebx
    771330602721:	83 c6 10             	add    esi,0x10
    771330602724:	89 f0                	mov    eax,esi
    771330602726:	c1 e8 0c             	shr    eax,0xc
    771330602729:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060272e:	48 85 c0             	test   rax,rax
    771330602731:	0f 84 4a 0f 00 18    	je     0x771348603681
    771330602737:	81 e6 ff 0f 00 00    	and    esi,0xfff
    77133060273d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330602740:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    771330602744:	8d 43 14             	lea    eax,[rbx+0x14]
    771330602747:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    77133060274b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    771330602752:	6c 03 01 00 
    771330602756:	0f 84 61 0f 00 18    	je     0x7713486036bd
    77133060275c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    771330602763:	6c 03 01 00 
    771330602767:	0f 84 50 0f 00 18    	je     0x7713486036bd
    77133060276d:	58                   	pop    rax
    77133060276e:	50                   	push   rax
    77133060276f:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330602776:	a8 01                	test   al,0x1
    771330602778:	0f 85 88 0f 00 18    	jne    0x771348603706
    77133060277e:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602785:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    77133060278c:	01 
    77133060278d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    771330602794:	6e 03 01 00 
    771330602798:	0f 84 9e 0f 00 18    	je     0x77134860373c
    77133060279e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    7713306027a5:	6e 03 01 00 
    7713306027a9:	0f 84 8d 0f 00 18    	je     0x77134860373c
    7713306027af:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7713306027b6:	02 00 00 00 
    7713306027ba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    7713306027c1:	03 00 00 00 
    7713306027c5:	58                   	pop    rax
    7713306027c6:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306027cd:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7713306027d4:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    7713306027db:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    7713306027e2:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    7713306027e9:	39 f1                	cmp    ecx,esi
    7713306027eb:	0f 83 78 0f 00 18    	jae    0x771348603769
    7713306027f1:	81 fa 68 03 01 00    	cmp    edx,0x10368
    7713306027f7:	75 14                	jne    0x77133060280d
    7713306027f9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602800:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602807:	00 
    771330602808:	e9 c3 fd ff ff       	jmp    0x7713306025d0
    77133060280d:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330602814:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    77133060281a:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    77133060281d:	0f 85 46 0f 00 18    	jne    0x771348603769
    771330602823:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    77133060282a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602831:	00 
    771330602832:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330602837:	ff e0                	jmp    rax
