
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66458-0-130924299706560.bin:     file format binary


Disassembly of section .data:

00007713306060c0 <.data>:
    7713306060c0:	48 83 ec 68          	sub    rsp,0x68
    7713306060c4:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    7713306060c9:	4c 89 ef             	mov    rdi,r13
    7713306060cc:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    7713306060d3:	45 8b 95 58 01 00 00 	mov    r10d,DWORD PTR [r13+0x158]
    7713306060da:	b8 5d fc fe ff       	mov    eax,0xfffefc5d
    7713306060df:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    7713306060e6:	83 f8 f6             	cmp    eax,0xfffffff6
    7713306060e9:	0f 87 99 10 00 18    	ja     0x771348607188
    7713306060ef:	81 bf a4 00 00 00 9e 	cmp    DWORD PTR [rdi+0xa4],0x1039e
    7713306060f6:	03 01 00 
    7713306060f9:	0f 85 89 10 00 18    	jne    0x771348607188
    7713306060ff:	81 bf 94 00 00 00 9a 	cmp    DWORD PTR [rdi+0x94],0x1039a
    771330606106:	03 01 00 
    771330606109:	0f 85 79 10 00 18    	jne    0x771348607188
    77133060610f:	48 8b 87 40 01 00 00 	mov    rax,QWORD PTR [rdi+0x140]
    771330606116:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    77133060611b:	48 8b 87 38 01 00 00 	mov    rax,QWORD PTR [rdi+0x138]
    771330606122:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    771330606127:	8b 07                	mov    eax,DWORD PTR [rdi]
    771330606129:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    77133060612d:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    771330606130:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    771330606134:	44 8b 67 08          	mov    r12d,DWORD PTR [rdi+0x8]
    771330606138:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    77133060613c:	8b 87 9c 00 00 00    	mov    eax,DWORD PTR [rdi+0x9c]
    771330606142:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    771330606146:	44 8b 8f 00 01 00 00 	mov    r9d,DWORD PTR [rdi+0x100]
    77133060614d:	44 8b bf 5c 01 00 00 	mov    r15d,DWORD PTR [rdi+0x15c]
    771330606154:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    77133060615b:	00 00 00 00 00 
    771330606160:	44 0f af 64 24 44    	imul   r12d,DWORD PTR [rsp+0x44]
    771330606166:	44 89 e5             	mov    ebp,r12d
    771330606169:	c1 ed 1f             	shr    ebp,0x1f
    77133060616c:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    771330606170:	89 c8                	mov    eax,ecx
    771330606172:	c1 e8 1f             	shr    eax,0x1f
    771330606175:	45 31 db             	xor    r11d,r11d
    771330606178:	41 01 cc             	add    r12d,ecx
    77133060617b:	41 0f 92 c3          	setb   r11b
    77133060617f:	44 89 e3             	mov    ebx,r12d
    771330606182:	c1 eb 1f             	shr    ebx,0x1f
    771330606185:	31 d8                	xor    eax,ebx
    771330606187:	31 dd                	xor    ebp,ebx
    771330606189:	21 c5                	and    ebp,eax
    77133060618b:	45 31 f6             	xor    r14d,r14d
    77133060618e:	45 85 e4             	test   r12d,r12d
    771330606191:	41 0f 94 c6          	sete   r14b
    771330606195:	41 09 e9             	or     r9d,ebp
    771330606198:	41 f6 c5 03          	test   r13b,0x3
    77133060619c:	0f 85 79 02 00 00    	jne    0x77133060641b
    7713306061a2:	44 89 74 24 10       	mov    DWORD PTR [rsp+0x10],r14d
    7713306061a7:	44 89 e8             	mov    eax,r13d
    7713306061aa:	c1 e8 0c             	shr    eax,0xc
    7713306061ad:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    7713306061b2:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
    7713306061b6:	48 85 c0             	test   rax,rax
    7713306061b9:	0f 84 81 03 00 00    	je     0x771330606540
    7713306061bf:	44 89 e9             	mov    ecx,r13d
    7713306061c2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306061c8:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7713306061cc:	41 83 c5 04          	add    r13d,0x4
    7713306061d0:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    7713306061d4:	83 f8 02             	cmp    eax,0x2
    7713306061d7:	72 6d                	jb     0x771330606246
    7713306061d9:	ff c8                	dec    eax
    7713306061db:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    7713306061df:	41 be 9a 03 01 00    	mov    r14d,0x1039a
    7713306061e5:	c7 44 24 34 02 00 00 	mov    DWORD PTR [rsp+0x34],0x2
    7713306061ec:	00 
    7713306061ed:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    7713306061f2:	b8 03 00 00 00       	mov    eax,0x3
    7713306061f7:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    7713306061fc:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    771330606201:	80 38 00             	cmp    BYTE PTR [rax],0x0
    771330606204:	0f 85 09 04 00 00    	jne    0x771330606613
    77133060620a:	44 89 f9             	mov    ecx,r15d
    77133060620d:	89 e8                	mov    eax,ebp
    77133060620f:	44 89 da             	mov    edx,r11d
    771330606212:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    771330606217:	44 8d 3c 0e          	lea    r15d,[rsi+rcx*1]
    77133060621b:	45 39 d7             	cmp    r15d,r10d
    77133060621e:	0f 83 7b 01 00 00    	jae    0x77133060639f
    771330606224:	8b b7 58 01 00 00    	mov    esi,DWORD PTR [rdi+0x158]
    77133060622a:	85 f6                	test   esi,esi
    77133060622c:	0f 84 6d 01 00 00    	je     0x77133060639f
    771330606232:	4c 89 f6             	mov    rsi,r14
    771330606235:	81 fe 9a 03 01 00    	cmp    esi,0x1039a
    77133060623b:	0f 84 1f ff ff ff    	je     0x771330606160
    771330606241:	e9 ba 00 00 00       	jmp    0x771330606300
    771330606246:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    77133060624b:	80 38 00             	cmp    BYTE PTR [rax],0x0
    77133060624e:	0f 85 49 0f 00 18    	jne    0x77134860719d
    771330606254:	41 8d 47 05          	lea    eax,[r15+0x5]
    771330606258:	44 39 d0             	cmp    eax,r10d
    77133060625b:	0f 83 ab 0e 00 18    	jae    0x77134860710c
    771330606261:	8b 8f 58 01 00 00    	mov    ecx,DWORD PTR [rdi+0x158]
    771330606267:	85 c9                	test   ecx,ecx
    771330606269:	0f 84 9d 0e 00 18    	je     0x77134860710c
    77133060626f:	41 81 b8 40 1b 08 00 	cmp    DWORD PTR [r8+0x81b40],0x10368
    771330606276:	68 03 01 00 
    77133060627a:	0f 85 8c 0e 00 18    	jne    0x77134860710c
    771330606280:	49 8b 88 48 1b 08 00 	mov    rcx,QWORD PTR [r8+0x81b48]
    771330606287:	c7 07 00 00 00 00    	mov    DWORD PTR [rdi],0x0
    77133060628d:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    771330606291:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    771330606295:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    77133060629c:	00 00 00 
    77133060629f:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    7713306062a6:	03 01 00 
    7713306062a9:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    7713306062ad:	89 97 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],edx
    7713306062b3:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    7713306062b9:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    7713306062c0:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    7713306062c7:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    7713306062cd:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    7713306062d3:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    7713306062da:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7713306062e1:	00 00 00 
    7713306062e4:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    7713306062eb:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    7713306062f2:	00 00 00 
    7713306062f5:	89 87 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],eax
    7713306062fb:	e9 91 00 00 00       	jmp    0x771330606391
    771330606300:	49 89 f2             	mov    r10,rsi
    771330606303:	8d 34 f5 00 00 00 00 	lea    esi,[rsi*8+0x0]
    77133060630a:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330606310:	45 39 14 30          	cmp    DWORD PTR [r8+rsi*1],r10d
    771330606314:	0f 85 85 00 00 00    	jne    0x77133060639f
    77133060631a:	49 8b 4c 30 08       	mov    rcx,QWORD PTR [r8+rsi*1+0x8]
    77133060631f:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    771330606323:	89 37                	mov    DWORD PTR [rdi],esi
    771330606325:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    771330606329:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    77133060632d:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    771330606331:	89 b7 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],esi
    771330606337:	44 89 b7 bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r14d
    77133060633e:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    771330606342:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    771330606348:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    77133060634e:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    771330606354:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    77133060635b:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    771330606361:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    771330606367:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    77133060636e:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    771330606372:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    771330606378:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    77133060637f:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    771330606384:	89 87 34 01 00 00    	mov    DWORD PTR [rdi+0x134],eax
    77133060638a:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    771330606391:	49 89 fd             	mov    r13,rdi
    771330606394:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    771330606399:	48 83 c4 68          	add    rsp,0x68
    77133060639d:	ff e1                	jmp    rcx
    77133060639f:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    7713306063a3:	89 37                	mov    DWORD PTR [rdi],esi
    7713306063a5:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    7713306063a9:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    7713306063ad:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    7713306063b1:	89 b7 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],esi
    7713306063b7:	44 89 b7 bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r14d
    7713306063be:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    7713306063c2:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    7713306063c8:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    7713306063ce:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    7713306063d4:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    7713306063db:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    7713306063e1:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    7713306063e7:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    7713306063ee:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    7713306063f2:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    7713306063f8:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    7713306063fd:	88 87 28 01 00 00    	mov    BYTE PTR [rdi+0x128],al
    771330606403:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    771330606408:	89 87 34 01 00 00    	mov    DWORD PTR [rdi+0x134],eax
    77133060640e:	89 8f 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ecx
    771330606414:	48 83 c4 68          	add    rsp,0x68
    771330606418:	c2 08 00             	ret    0x8
    77133060641b:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    77133060641f:	89 07                	mov    DWORD PTR [rdi],eax
    771330606421:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    771330606425:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    771330606429:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    77133060642d:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    771330606433:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1039e
    77133060643a:	03 01 00 
    77133060643d:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    771330606444:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    77133060644a:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    771330606451:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    771330606458:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    77133060645e:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    771330606464:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    77133060646b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    771330606472:	00 00 00 
    771330606475:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    77133060647c:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    771330606483:	00 00 00 
    771330606486:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    77133060648d:	48 b8 e0 e8 8f a8 39 	movabs rax,0x6039a88fe8e0
    771330606494:	60 00 00 
    771330606497:	48 89 fb             	mov    rbx,rdi
    77133060649a:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    77133060649f:	ba 9e 03 01 00       	mov    edx,0x1039e
    7713306064a4:	44 89 e9             	mov    ecx,r13d
    7713306064a7:	4d 89 c7             	mov    r15,r8
    7713306064aa:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7713306064b0:	44 89 d5             	mov    ebp,r10d
    7713306064b3:	ff d0                	call   rax
    7713306064b5:	41 89 ea             	mov    r10d,ebp
    7713306064b8:	4d 89 f8             	mov    r8,r15
    7713306064bb:	48 89 df             	mov    rdi,rbx
    7713306064be:	0f b6 b3 28 01 00 00 	movzx  esi,BYTE PTR [rbx+0x128]
    7713306064c5:	8b 07                	mov    eax,DWORD PTR [rdi]
    7713306064c7:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    7713306064cb:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    7713306064ce:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    7713306064d2:	44 8b 67 08          	mov    r12d,DWORD PTR [rdi+0x8]
    7713306064d6:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    7713306064da:	8b 87 9c 00 00 00    	mov    eax,DWORD PTR [rdi+0x9c]
    7713306064e0:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    7713306064e4:	44 8b b7 bc 00 00 00 	mov    r14d,DWORD PTR [rdi+0xbc]
    7713306064eb:	8b 87 e4 00 00 00    	mov    eax,DWORD PTR [rdi+0xe4]
    7713306064f1:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    7713306064f5:	8b 9f e8 00 00 00    	mov    ebx,DWORD PTR [rdi+0xe8]
    7713306064fb:	8b 97 ec 00 00 00    	mov    edx,DWORD PTR [rdi+0xec]
    771330606501:	44 8b 9f f0 00 00 00 	mov    r11d,DWORD PTR [rdi+0xf0]
    771330606508:	8b 87 f8 00 00 00    	mov    eax,DWORD PTR [rdi+0xf8]
    77133060650e:	8b af fc 00 00 00    	mov    ebp,DWORD PTR [rdi+0xfc]
    771330606514:	44 8b 8f 00 01 00 00 	mov    r9d,DWORD PTR [rdi+0x100]
    77133060651b:	8b 8f 24 01 00 00    	mov    ecx,DWORD PTR [rdi+0x124]
    771330606521:	89 4c 24 34          	mov    DWORD PTR [rsp+0x34],ecx
    771330606525:	40 88 74 24 0f       	mov    BYTE PTR [rsp+0xf],sil
    77133060652a:	8b 8f 34 01 00 00    	mov    ecx,DWORD PTR [rdi+0x134]
    771330606530:	48 89 4c 24 50       	mov    QWORD PTR [rsp+0x50],rcx
    771330606535:	8b 8f 5c 01 00 00    	mov    ecx,DWORD PTR [rdi+0x15c]
    77133060653b:	e9 d2 fc ff ff       	jmp    0x771330606212
    771330606540:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    771330606544:	89 07                	mov    DWORD PTR [rdi],eax
    771330606546:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    77133060654a:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    77133060654e:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    771330606552:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    771330606558:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1039e
    77133060655f:	03 01 00 
    771330606562:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    771330606566:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    77133060656c:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    771330606572:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    771330606579:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    771330606580:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    771330606586:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    77133060658c:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    771330606593:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    77133060659a:	00 00 00 
    77133060659d:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    7713306065a4:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    7713306065ab:	00 00 00 
    7713306065ae:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    7713306065b5:	48 b8 20 86 7e a8 39 	movabs rax,0x6039a87e8620
    7713306065bc:	60 00 00 
    7713306065bf:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    7713306065c4:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    7713306065c9:	44 89 ee             	mov    esi,r13d
    7713306065cc:	44 89 e2             	mov    edx,r12d
    7713306065cf:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    7713306065d4:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    7713306065d9:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    7713306065de:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    7713306065e3:	ff d0                	call   rax
    7713306065e5:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    7713306065ea:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    7713306065ef:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    7713306065f4:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    7713306065f9:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    7713306065fe:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    771330606605:	40 84 f6             	test   sil,sil
    771330606608:	0f 84 be fb ff ff    	je     0x7713306061cc
    77133060660e:	e9 b2 fe ff ff       	jmp    0x7713306064c5
    771330606613:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    771330606617:	89 07                	mov    DWORD PTR [rdi],eax
    771330606619:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    77133060661d:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    771330606621:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    771330606625:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    77133060662b:	c7 87 bc 00 00 00 9a 	mov    DWORD PTR [rdi+0xbc],0x1039a
    771330606632:	03 01 00 
    771330606635:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    771330606639:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    77133060663f:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    771330606645:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    77133060664c:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    771330606653:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    771330606659:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    77133060665f:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    771330606666:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    77133060666d:	00 00 00 
    771330606670:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    771330606677:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    77133060667e:	00 00 00 
    771330606681:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    771330606688:	48 b8 10 e6 8f a8 39 	movabs rax,0x6039a88fe610
    77133060668f:	60 00 00 
    771330606692:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    771330606697:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    77133060669c:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    7713306066a1:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    7713306066a6:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    7713306066ab:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    7713306066b0:	ff d0                	call   rax
    7713306066b2:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    7713306066b7:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    7713306066bc:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    7713306066c1:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    7713306066c6:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    7713306066cb:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    7713306066d2:	44 89 f9             	mov    ecx,r15d
    7713306066d5:	89 e8                	mov    eax,ebp
    7713306066d7:	44 89 da             	mov    edx,r11d
    7713306066da:	40 84 f6             	test   sil,sil
    7713306066dd:	0f 84 2f fb ff ff    	je     0x771330606212
    7713306066e3:	e9 dd fd ff ff       	jmp    0x7713306064c5
