
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65668-1-130924299706000.bin:     file format binary


Disassembly of section .data:

0000771330605e90 <.data>:
    771330605e90:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    771330605e97:	3d 00 00 00 00       	cmp    eax,0x0
    771330605e9c:	0f 95 c2             	setne  dl
    771330605e9f:	b9 84 00 01 00       	mov    ecx,0x10084
    771330605ea4:	29 c8                	sub    eax,ecx
    771330605ea6:	3d 0a 00 00 00       	cmp    eax,0xa
    771330605eab:	0f 96 c3             	setbe  bl
    771330605eae:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    771330605eb5:	81 fe 9e 03 01 00    	cmp    esi,0x1039e
    771330605ebb:	0f 94 c0             	sete   al
    771330605ebe:	29 ce                	sub    esi,ecx
    771330605ec0:	81 fe 0a 00 00 00    	cmp    esi,0xa
    771330605ec6:	0f 97 c1             	seta   cl
    771330605ec9:	84 da                	test   dl,bl
    771330605ecb:	0f 85 5f 10 00 18    	jne    0x771348606f30
    771330605ed1:	08 c8                	or     al,cl
    771330605ed3:	0f 84 57 10 00 18    	je     0x771348606f30
    771330605ed9:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330605ee0:	8b 88 38 00 10 00    	mov    ecx,DWORD PTR [rax+0x100038]
    771330605ee6:	ff c1                	inc    ecx
    771330605ee8:	89 88 38 00 10 00    	mov    DWORD PTR [rax+0x100038],ecx
    771330605eee:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    771330605ef4:	0f 84 4c 10 00 18    	je     0x771348606f46
    771330605efa:	50                   	push   rax
    771330605efb:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    771330605eff:	8d 48 fc             	lea    ecx,[rax-0x4]
    771330605f02:	a8 03                	test   al,0x3
    771330605f04:	0f 85 68 10 00 18    	jne    0x771348606f72
    771330605f0a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330605f11:	89 ca                	mov    edx,ecx
    771330605f13:	c1 ea 0c             	shr    edx,0xc
    771330605f16:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330605f1a:	48 85 c0             	test   rax,rax
    771330605f1d:	0f 84 9f 10 00 18    	je     0x771348606fc2
    771330605f23:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605f29:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330605f2c:	41 89 85 80 01 00 00 	mov    DWORD PTR [r13+0x180],eax
    771330605f33:	58                   	pop    rax
    771330605f34:	41 8b 85 10 00 00 00 	mov    eax,DWORD PTR [r13+0x10]
    771330605f3b:	41 89 85 00 00 00 00 	mov    DWORD PTR [r13+0x0],eax
    771330605f42:	41 8b 85 80 01 00 00 	mov    eax,DWORD PTR [r13+0x180]
    771330605f49:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330605f4d:	50                   	push   rax
    771330605f4e:	41 8b 45 3c          	mov    eax,DWORD PTR [r13+0x3c]
    771330605f52:	8d 48 f8             	lea    ecx,[rax-0x8]
    771330605f55:	a8 03                	test   al,0x3
    771330605f57:	0f 85 a0 10 00 18    	jne    0x771348606ffd
    771330605f5d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330605f64:	89 ca                	mov    edx,ecx
    771330605f66:	c1 ea 0c             	shr    edx,0xc
    771330605f69:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330605f6d:	48 85 c0             	test   rax,rax
    771330605f70:	0f 84 d7 10 00 18    	je     0x77134860704d
    771330605f76:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330605f7c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330605f7f:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    771330605f83:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1008c
    771330605f8a:	8c 00 01 00 
    771330605f8e:	0f 84 f4 10 00 18    	je     0x771348607088
    771330605f94:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1008c
    771330605f9b:	8c 00 01 00 
    771330605f9f:	0f 84 e3 10 00 18    	je     0x771348607088
    771330605fa5:	58                   	pop    rax
    771330605fa6:	50                   	push   rax
    771330605fa7:	41 8b 85 a0 00 00 00 	mov    eax,DWORD PTR [r13+0xa0]
    771330605fae:	b9 8e 00 01 00       	mov    ecx,0x1008e
    771330605fb3:	83 c1 04             	add    ecx,0x4
    771330605fb6:	89 ca                	mov    edx,ecx
    771330605fb8:	3d 8e 00 01 00       	cmp    eax,0x1008e
    771330605fbd:	75 07                	jne    0x771330605fc6
    771330605fbf:	41 8b 95 90 00 00 00 	mov    edx,DWORD PTR [r13+0x90]
    771330605fc6:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    771330605fcd:	02 
    771330605fce:	0f 43 ca             	cmovae ecx,edx
    771330605fd1:	41 8b b5 9c 00 00 00 	mov    esi,DWORD PTR [r13+0x9c]
    771330605fd8:	41 8b 95 a4 00 00 00 	mov    edx,DWORD PTR [r13+0xa4]
    771330605fdf:	89 cf                	mov    edi,ecx
    771330605fe1:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    771330605fe7:	75 07                	jne    0x771330605ff0
    771330605fe9:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    771330605ff0:	83 fe 02             	cmp    esi,0x2
    771330605ff3:	0f 43 cf             	cmovae ecx,edi
    771330605ff6:	41 89 8d a8 00 00 00 	mov    DWORD PTR [r13+0xa8],ecx
    771330605ffd:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330606004:	01 
    771330606005:	3d 8e 00 01 00       	cmp    eax,0x1008e
    77133060600a:	0f 84 c1 10 00 18    	je     0x7713486070d1
    771330606010:	81 fa 8e 00 01 00    	cmp    edx,0x1008e
    771330606016:	0f 84 b5 10 00 18    	je     0x7713486070d1
    77133060601c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    771330606023:	28 03 01 00 
    771330606027:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    77133060602e:	04 00 00 00 
    771330606032:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    771330606039:	03 00 00 00 
    77133060603d:	58                   	pop    rax
    77133060603e:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330606045:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    77133060604c:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330606053:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060605a:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330606061:	39 f1                	cmp    ecx,esi
    771330606063:	0f 83 a0 10 00 18    	jae    0x771348607109
    771330606069:	81 fa 84 00 01 00    	cmp    edx,0x10084
    77133060606f:	75 14                	jne    0x771330606085
    771330606071:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330606078:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060607f:	00 
    771330606080:	e9 54 fe ff ff       	jmp    0x771330605ed9
    771330606085:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    77133060608c:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330606092:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330606095:	0f 85 6e 10 00 18    	jne    0x771348607109
    77133060609b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306060a2:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306060a9:	00 
    7713306060aa:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7713306060af:	ff e0                	jmp    rax
