
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65542-1-130924299708192.bin:     file format binary


Disassembly of section .data:

0000771330606720 <.data>:
    771330606720:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330606727:	8b 88 3c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10003c]
    77133060672d:	ff c1                	inc    ecx
    77133060672f:	89 88 3c 00 10 00    	mov    DWORD PTR [rax+0x10003c],ecx
    771330606735:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060673b:	0f 84 3f 0b 00 18    	je     0x771348607280
    771330606741:	50                   	push   rax
    771330606742:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    771330606747:	b9 00 00 00 01       	mov    ecx,0x1000000
    77133060674c:	09 c1                	or     ecx,eax
    77133060674e:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    771330606752:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10006
    771330606759:	06 00 01 00 
    77133060675d:	0f 84 49 0b 00 18    	je     0x7713486072ac
    771330606763:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10006
    77133060676a:	06 00 01 00 
    77133060676e:	0f 84 38 0b 00 18    	je     0x7713486072ac
    771330606774:	58                   	pop    rax
    771330606775:	50                   	push   rax
    771330606776:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    77133060677b:	c1 e0 10             	shl    eax,0x10
    77133060677e:	b9 04 00 00 00       	mov    ecx,0x4
    771330606783:	09 c1                	or     ecx,eax
    771330606785:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    771330606789:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000a
    771330606790:	0a 00 01 00 
    771330606794:	0f 84 72 0b 00 18    	je     0x77134860730c
    77133060679a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000a
    7713306067a1:	0a 00 01 00 
    7713306067a5:	0f 84 61 0b 00 18    	je     0x77134860730c
    7713306067ab:	58                   	pop    rax
    7713306067ac:	50                   	push   rax
    7713306067ad:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    7713306067b1:	f6 c1 03             	test   cl,0x3
    7713306067b4:	0f 85 b2 0b 00 18    	jne    0x77134860736c
    7713306067ba:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    7713306067c1:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    7713306067c5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306067cc:	48 89 ce             	mov    rsi,rcx
    7713306067cf:	48 c1 ee 0c          	shr    rsi,0xc
    7713306067d3:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    7713306067d7:	48 85 c0             	test   rax,rax
    7713306067da:	0f 84 df 0b 00 18    	je     0x7713486073bf
    7713306067e0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306067e6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7713306067e9:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1000e
    7713306067f0:	0e 00 01 00 
    7713306067f4:	0f 84 00 0c 00 18    	je     0x7713486073fa
    7713306067fa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1000e
    771330606801:	0e 00 01 00 
    771330606805:	0f 84 ef 0b 00 18    	je     0x7713486073fa
    77133060680b:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    77133060680e:	0f 85 27 0c 00 18    	jne    0x77134860743b
    771330606814:	58                   	pop    rax
    771330606815:	e9 0f 00 00 00       	jmp    0x771330606829
    77133060681a:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330606821:	00 
    771330606822:	74 f0                	je     0x771330606814
    771330606824:	e9 7a 0b 00 18       	jmp    0x7713486073a3
    771330606829:	50                   	push   rax
    77133060682a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330606831:	01 
    771330606832:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10010
    771330606839:	10 00 01 00 
    77133060683d:	0f 84 2a 0c 00 18    	je     0x77134860746d
    771330606843:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10010
    77133060684a:	10 00 01 00 
    77133060684e:	0f 84 19 0c 00 18    	je     0x77134860746d
    771330606854:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    77133060685b:	10 00 01 00 
    77133060685f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330606866:	02 00 00 00 
    77133060686a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771330606871:	04 00 00 00 
    771330606875:	58                   	pop    rax
    771330606876:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    77133060687d:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330606884:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    77133060688b:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330606892:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330606899:	39 f1                	cmp    ecx,esi
    77133060689b:	0f 83 04 0c 00 18    	jae    0x7713486074a5
    7713306068a1:	81 fa 06 00 01 00    	cmp    edx,0x10006
    7713306068a7:	75 14                	jne    0x7713306068bd
    7713306068a9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306068b0:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306068b7:	00 
    7713306068b8:	e9 63 fe ff ff       	jmp    0x771330606720
    7713306068bd:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7713306068c4:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7713306068ca:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7713306068cd:	0f 85 d2 0b 00 18    	jne    0x7713486074a5
    7713306068d3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306068da:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306068e1:	00 
    7713306068e2:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7713306068e7:	ff e0                	jmp    rax
