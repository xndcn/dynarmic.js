
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66344-1-130924299687104.bin:     file format binary


Disassembly of section .data:

00007713306014c0 <.data>:
    7713306014c0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306014c7:	8b 88 0c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10000c]
    7713306014cd:	ff c1                	inc    ecx
    7713306014cf:	89 88 0c 00 10 00    	mov    DWORD PTR [rax+0x10000c],ecx
    7713306014d5:	81 f9 c1 c5 00 00    	cmp    ecx,0xc5c1
    7713306014db:	0f 84 ff 07 00 18    	je     0x771348601ce0
    7713306014e1:	50                   	push   rax
    7713306014e2:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7713306014e6:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7713306014e9:	f6 c3 03             	test   bl,0x3
    7713306014ec:	0f 85 1a 08 00 18    	jne    0x771348601d0c
    7713306014f2:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    7713306014f9:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330601500:	41 8b 55 18          	mov    edx,DWORD PTR [r13+0x18]
    771330601504:	89 c8                	mov    eax,ecx
    771330601506:	c1 e8 0c             	shr    eax,0xc
    771330601509:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060150e:	48 85 c0             	test   rax,rax
    771330601511:	0f 84 48 08 00 18    	je     0x771348601d5f
    771330601517:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060151d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601520:	8d 73 f8             	lea    esi,[rbx-0x8]
    771330601523:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    771330601527:	89 f0                	mov    eax,esi
    771330601529:	c1 e8 0c             	shr    eax,0xc
    77133060152c:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601531:	48 85 c0             	test   rax,rax
    771330601534:	0f 84 60 08 00 18    	je     0x771348601d9a
    77133060153a:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601540:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    771330601543:	8d 73 f4             	lea    esi,[rbx-0xc]
    771330601546:	41 8b 55 2c          	mov    edx,DWORD PTR [r13+0x2c]
    77133060154a:	89 f0                	mov    eax,esi
    77133060154c:	c1 e8 0c             	shr    eax,0xc
    77133060154f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601554:	48 85 c0             	test   rax,rax
    771330601557:	0f 84 79 08 00 18    	je     0x771348601dd6
    77133060155d:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601563:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    771330601566:	8d 73 f0             	lea    esi,[rbx-0x10]
    771330601569:	41 8b 55 30          	mov    edx,DWORD PTR [r13+0x30]
    77133060156d:	89 f0                	mov    eax,esi
    77133060156f:	c1 e8 0c             	shr    eax,0xc
    771330601572:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601577:	48 85 c0             	test   rax,rax
    77133060157a:	0f 84 92 08 00 18    	je     0x771348601e12
    771330601580:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601586:	89 14 30             	mov    DWORD PTR [rax+rsi*1],edx
    771330601589:	83 c3 ec             	add    ebx,0xffffffec
    77133060158c:	41 8b 55 34          	mov    edx,DWORD PTR [r13+0x34]
    771330601590:	89 d8                	mov    eax,ebx
    771330601592:	c1 e8 0c             	shr    eax,0xc
    771330601595:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060159a:	48 85 c0             	test   rax,rax
    77133060159d:	0f 84 ab 08 00 18    	je     0x771348601e4e
    7713306015a3:	89 d9                	mov    ecx,ebx
    7713306015a5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306015ab:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7713306015ae:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7713306015b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10328
    7713306015b9:	28 03 01 00 
    7713306015bd:	0f 84 c9 08 00 18    	je     0x771348601e8c
    7713306015c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10328
    7713306015ca:	28 03 01 00 
    7713306015ce:	0f 84 b8 08 00 18    	je     0x771348601e8c
    7713306015d4:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7713306015d8:	0f 85 f0 08 00 18    	jne    0x771348601ece
    7713306015de:	58                   	pop    rax
    7713306015df:	e9 0f 00 00 00       	jmp    0x7713306015f3
    7713306015e4:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306015eb:	00 
    7713306015ec:	74 f0                	je     0x7713306015de
    7713306015ee:	e9 50 07 00 18       	jmp    0x771348601d43
    7713306015f3:	50                   	push   rax
    7713306015f4:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    7713306015f8:	8d 4b fc             	lea    ecx,[rbx-0x4]
    7713306015fb:	f6 c3 03             	test   bl,0x3
    7713306015fe:	0f 85 fc 08 00 18    	jne    0x771348601f00
    771330601604:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    77133060160b:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330601612:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    771330601616:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    77133060161d:	89 c8                	mov    eax,ecx
    77133060161f:	c1 e8 0c             	shr    eax,0xc
    771330601622:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601627:	48 85 c0             	test   rax,rax
    77133060162a:	0f 84 23 09 00 18    	je     0x771348601f53
    771330601630:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601636:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601639:	83 c3 f8             	add    ebx,0xfffffff8
    77133060163c:	89 d8                	mov    eax,ebx
    77133060163e:	c1 e8 0c             	shr    eax,0xc
    771330601641:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601646:	48 85 c0             	test   rax,rax
    771330601649:	0f 84 3f 09 00 18    	je     0x771348601f8e
    77133060164f:	89 d9                	mov    ecx,ebx
    771330601651:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601657:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    77133060165b:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    77133060165f:	b8 00 00 00 00       	mov    eax,0x0
    771330601664:	29 c3                	sub    ebx,eax
    771330601666:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    77133060166a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1032a
    771330601671:	2a 03 01 00 
    771330601675:	0f 84 54 09 00 18    	je     0x771348601fcf
    77133060167b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032a
    771330601682:	2a 03 01 00 
    771330601686:	0f 84 43 09 00 18    	je     0x771348601fcf
    77133060168c:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    771330601690:	0f 85 7b 09 00 18    	jne    0x771348602011
    771330601696:	58                   	pop    rax
    771330601697:	e9 0f 00 00 00       	jmp    0x7713306016ab
    77133060169c:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306016a3:	00 
    7713306016a4:	74 f0                	je     0x771330601696
    7713306016a6:	e9 8c 08 00 18       	jmp    0x771348601f37
    7713306016ab:	50                   	push   rax
    7713306016ac:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7713306016b0:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306016b7:	31 d2                	xor    edx,edx
    7713306016b9:	83 f8 05             	cmp    eax,0x5
    7713306016bc:	0f 92 c2             	setb   dl
    7713306016bf:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7713306016c6:	31 d2                	xor    edx,edx
    7713306016c8:	31 f6                	xor    esi,esi
    7713306016ca:	31 ff                	xor    edi,edi
    7713306016cc:	83 f8 04             	cmp    eax,0x4
    7713306016cf:	0f 94 c2             	sete   dl
    7713306016d2:	40 0f 92 c6          	setb   sil
    7713306016d6:	40 0f 93 c7          	setae  dil
    7713306016da:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306016e1:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    7713306016e8:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    7713306016ef:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    7713306016f6:	81 f9 2e 03 01 00    	cmp    ecx,0x1032e
    7713306016fc:	0f 84 41 09 00 18    	je     0x771348602043
    771330601702:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1032e
    771330601709:	2e 03 01 00 
    77133060170d:	0f 84 30 09 00 18    	je     0x771348602043
    771330601713:	58                   	pop    rax
    771330601714:	50                   	push   rax
    771330601715:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    77133060171c:	00 
    77133060171d:	74 28                	je     0x771330601747
    77133060171f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    771330601726:	30 03 01 00 
    77133060172a:	0f 84 73 09 00 18    	je     0x7713486020a3
    771330601730:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    771330601737:	30 03 01 00 
    77133060173b:	0f 84 62 09 00 18    	je     0x7713486020a3
    771330601741:	58                   	pop    rax
    771330601742:	e9 55 00 00 00       	jmp    0x77133060179c
    771330601747:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    77133060174e:	01 
    77133060174f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10330
    771330601756:	30 03 01 00 
    77133060175a:	0f 84 8c 09 00 18    	je     0x7713486020ec
    771330601760:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10330
    771330601767:	30 03 01 00 
    77133060176b:	0f 84 7b 09 00 18    	je     0x7713486020ec
    771330601771:	b8 30 03 01 00       	mov    eax,0x10330
    771330601776:	83 c0 40             	add    eax,0x40
    771330601779:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330601780:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330601787:	02 00 00 00 
    77133060178b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    771330601792:	04 00 00 00 
    771330601796:	58                   	pop    rax
    771330601797:	e9 d3 08 00 00       	jmp    0x77133060206f
    77133060179c:	50                   	push   rax
    77133060179d:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7713306017a1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306017a8:	31 d2                	xor    edx,edx
    7713306017aa:	85 c0                	test   eax,eax
    7713306017ac:	0f 94 c2             	sete   dl
    7713306017af:	c1 e8 1f             	shr    eax,0x1f
    7713306017b2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    7713306017b9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306017c0:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7713306017c7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    7713306017ce:	00 00 00 
    7713306017d1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    7713306017d8:	81 f9 32 03 01 00    	cmp    ecx,0x10332
    7713306017de:	0f 84 44 09 00 18    	je     0x771348602128
    7713306017e4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10332
    7713306017eb:	32 03 01 00 
    7713306017ef:	0f 84 33 09 00 18    	je     0x771348602128
    7713306017f5:	58                   	pop    rax
    7713306017f6:	50                   	push   rax
    7713306017f7:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    7713306017fe:	00 
    7713306017ff:	74 55                	je     0x771330601856
    771330601801:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330601808:	01 
    771330601809:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    771330601810:	34 03 01 00 
    771330601814:	0f 84 6e 09 00 18    	je     0x771348602188
    77133060181a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    771330601821:	34 03 01 00 
    771330601825:	0f 84 5d 09 00 18    	je     0x771348602188
    77133060182b:	b8 34 03 01 00       	mov    eax,0x10334
    771330601830:	83 c0 3c             	add    eax,0x3c
    771330601833:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    77133060183a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330601841:	02 00 00 00 
    771330601845:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    77133060184c:	06 00 00 00 
    771330601850:	58                   	pop    rax
    771330601851:	e9 19 08 00 00       	jmp    0x77133060206f
    771330601856:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10334
    77133060185d:	34 03 01 00 
    771330601861:	0f 84 5d 09 00 18    	je     0x7713486021c4
    771330601867:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10334
    77133060186e:	34 03 01 00 
    771330601872:	0f 84 4c 09 00 18    	je     0x7713486021c4
    771330601878:	58                   	pop    rax
    771330601879:	50                   	push   rax
    77133060187a:	41 c7 45 0c 09 3d 00 	mov    DWORD PTR [r13+0xc],0x3d09
    771330601881:	00 
    771330601882:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10336
    771330601889:	36 03 01 00 
    77133060188d:	0f 84 7a 09 00 18    	je     0x77134860220d
    771330601893:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10336
    77133060189a:	36 03 01 00 
    77133060189e:	0f 84 69 09 00 18    	je     0x77134860220d
    7713306018a4:	58                   	pop    rax
    7713306018a5:	50                   	push   rax
    7713306018a6:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    7713306018aa:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306018b1:	31 d2                	xor    edx,edx
    7713306018b3:	c1 e0 0b             	shl    eax,0xb
    7713306018b6:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    7713306018ba:	0f 94 c2             	sete   dl
    7713306018bd:	c1 e8 1f             	shr    eax,0x1f
    7713306018c0:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306018c7:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7713306018ce:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7713306018d5:	00 00 00 00 
    7713306018d9:	81 f9 3a 03 01 00    	cmp    ecx,0x1033a
    7713306018df:	0f 84 88 09 00 18    	je     0x77134860226d
    7713306018e5:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033a
    7713306018ec:	3a 03 01 00 
    7713306018f0:	0f 84 77 09 00 18    	je     0x77134860226d
    7713306018f6:	58                   	pop    rax
    7713306018f7:	50                   	push   rax
    7713306018f8:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    7713306018fc:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    771330601900:	31 d2                	xor    edx,edx
    771330601902:	31 f6                	xor    esi,esi
    771330601904:	31 ff                	xor    edi,edi
    771330601906:	31 db                	xor    ebx,ebx
    771330601908:	39 c8                	cmp    eax,ecx
    77133060190a:	0f 96 c2             	setbe  dl
    77133060190d:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330601914:	40 0f 94 c6          	sete   sil
    771330601918:	40 0f 92 c7          	setb   dil
    77133060191c:	0f 93 c3             	setae  bl
    77133060191f:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    771330601926:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    77133060192d:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    771330601934:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    77133060193b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033c
    771330601942:	3c 03 01 00 
    771330601946:	0f 84 81 09 00 18    	je     0x7713486022cd
    77133060194c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033c
    771330601953:	3c 03 01 00 
    771330601957:	0f 84 70 09 00 18    	je     0x7713486022cd
    77133060195d:	58                   	pop    rax
    77133060195e:	50                   	push   rax
    77133060195f:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330601966:	00 
    771330601967:	74 28                	je     0x771330601991
    771330601969:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    771330601970:	3e 03 01 00 
    771330601974:	0f 84 b3 09 00 18    	je     0x77134860232d
    77133060197a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    771330601981:	3e 03 01 00 
    771330601985:	0f 84 a2 09 00 18    	je     0x77134860232d
    77133060198b:	58                   	pop    rax
    77133060198c:	e9 55 00 00 00       	jmp    0x7713306019e6
    771330601991:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330601998:	01 
    771330601999:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1033e
    7713306019a0:	3e 03 01 00 
    7713306019a4:	0f 84 cc 09 00 18    	je     0x771348602376
    7713306019aa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1033e
    7713306019b1:	3e 03 01 00 
    7713306019b5:	0f 84 bb 09 00 18    	je     0x771348602376
    7713306019bb:	b8 3e 03 01 00       	mov    eax,0x1033e
    7713306019c0:	83 c0 32             	add    eax,0x32
    7713306019c3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7713306019ca:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7713306019d1:	02 00 00 00 
    7713306019d5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    7713306019dc:	0a 00 00 00 
    7713306019e0:	58                   	pop    rax
    7713306019e1:	e9 89 06 00 00       	jmp    0x77133060206f
    7713306019e6:	50                   	push   rax
    7713306019e7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7713306019ec:	b9 00 00 01 00       	mov    ecx,0x10000
    7713306019f1:	09 c1                	or     ecx,eax
    7713306019f3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306019f7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10340
    7713306019fe:	40 03 01 00 
    771330601a02:	0f 84 aa 09 00 18    	je     0x7713486023b2
    771330601a08:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10340
    771330601a0f:	40 03 01 00 
    771330601a13:	0f 84 99 09 00 18    	je     0x7713486023b2
    771330601a19:	58                   	pop    rax
    771330601a1a:	50                   	push   rax
    771330601a1b:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    771330601a20:	c1 e0 10             	shl    eax,0x10
    771330601a23:	b9 f0 12 00 00       	mov    ecx,0x12f0
    771330601a28:	09 c1                	or     ecx,eax
    771330601a2a:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330601a2e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10344
    771330601a35:	44 03 01 00 
    771330601a39:	0f 84 d3 09 00 18    	je     0x771348602412
    771330601a3f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10344
    771330601a46:	44 03 01 00 
    771330601a4a:	0f 84 c2 09 00 18    	je     0x771348602412
    771330601a50:	58                   	pop    rax
    771330601a51:	50                   	push   rax
    771330601a52:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330601a56:	f6 c1 03             	test   cl,0x3
    771330601a59:	0f 85 13 0a 00 18    	jne    0x771348602472
    771330601a5f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330601a66:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
    771330601a6a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601a71:	48 89 ce             	mov    rsi,rcx
    771330601a74:	48 c1 ee 0c          	shr    rsi,0xc
    771330601a78:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330601a7c:	48 85 c0             	test   rax,rax
    771330601a7f:	0f 84 40 0a 00 18    	je     0x7713486024c5
    771330601a85:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601a8b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601a8e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10348
    771330601a95:	48 03 01 00 
    771330601a99:	0f 84 61 0a 00 18    	je     0x771348602500
    771330601a9f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10348
    771330601aa6:	48 03 01 00 
    771330601aaa:	0f 84 50 0a 00 18    	je     0x771348602500
    771330601ab0:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330601ab3:	0f 85 88 0a 00 18    	jne    0x771348602541
    771330601ab9:	58                   	pop    rax
    771330601aba:	e9 0f 00 00 00       	jmp    0x771330601ace
    771330601abf:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330601ac6:	00 
    771330601ac7:	74 f0                	je     0x771330601ab9
    771330601ac9:	e9 db 09 00 18       	jmp    0x7713486024a9
    771330601ace:	50                   	push   rax
    771330601acf:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    771330601ad4:	b9 00 00 01 00       	mov    ecx,0x10000
    771330601ad9:	09 c1                	or     ecx,eax
    771330601adb:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330601adf:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034a
    771330601ae6:	4a 03 01 00 
    771330601aea:	0f 84 83 0a 00 18    	je     0x771348602573
    771330601af0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034a
    771330601af7:	4a 03 01 00 
    771330601afb:	0f 84 72 0a 00 18    	je     0x771348602573
    771330601b01:	58                   	pop    rax
    771330601b02:	50                   	push   rax
    771330601b03:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    771330601b08:	c1 e0 10             	shl    eax,0x10
    771330601b0b:	b9 f4 12 00 00       	mov    ecx,0x12f4
    771330601b10:	09 c1                	or     ecx,eax
    771330601b12:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330601b16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1034e
    771330601b1d:	4e 03 01 00 
    771330601b21:	0f 84 ac 0a 00 18    	je     0x7713486025d3
    771330601b27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1034e
    771330601b2e:	4e 03 01 00 
    771330601b32:	0f 84 9b 0a 00 18    	je     0x7713486025d3
    771330601b38:	58                   	pop    rax
    771330601b39:	50                   	push   rax
    771330601b3a:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330601b3e:	f6 c1 03             	test   cl,0x3
    771330601b41:	0f 85 ec 0a 00 18    	jne    0x771348602633
    771330601b47:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330601b4e:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    771330601b52:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601b59:	48 89 ce             	mov    rsi,rcx
    771330601b5c:	48 c1 ee 0c          	shr    rsi,0xc
    771330601b60:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330601b64:	48 85 c0             	test   rax,rax
    771330601b67:	0f 84 19 0b 00 18    	je     0x771348602686
    771330601b6d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601b73:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601b76:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10352
    771330601b7d:	52 03 01 00 
    771330601b81:	0f 84 3a 0b 00 18    	je     0x7713486026c1
    771330601b87:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10352
    771330601b8e:	52 03 01 00 
    771330601b92:	0f 84 29 0b 00 18    	je     0x7713486026c1
    771330601b98:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330601b9b:	0f 85 61 0b 00 18    	jne    0x771348602702
    771330601ba1:	58                   	pop    rax
    771330601ba2:	e9 0f 00 00 00       	jmp    0x771330601bb6
    771330601ba7:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330601bae:	00 
    771330601baf:	74 f0                	je     0x771330601ba1
    771330601bb1:	e9 b4 0a 00 18       	jmp    0x77134860266a
    771330601bb6:	50                   	push   rax
    771330601bb7:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    771330601bbc:	b9 00 00 01 00       	mov    ecx,0x10000
    771330601bc1:	09 c1                	or     ecx,eax
    771330601bc3:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330601bc7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10354
    771330601bce:	54 03 01 00 
    771330601bd2:	0f 84 5c 0b 00 18    	je     0x771348602734
    771330601bd8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10354
    771330601bdf:	54 03 01 00 
    771330601be3:	0f 84 4b 0b 00 18    	je     0x771348602734
    771330601be9:	58                   	pop    rax
    771330601bea:	50                   	push   rax
    771330601beb:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    771330601bf0:	c1 e0 10             	shl    eax,0x10
    771330601bf3:	b9 f8 12 00 00       	mov    ecx,0x12f8
    771330601bf8:	09 c1                	or     ecx,eax
    771330601bfa:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330601bfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10358
    771330601c05:	58 03 01 00 
    771330601c09:	0f 84 85 0b 00 18    	je     0x771348602794
    771330601c0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10358
    771330601c16:	58 03 01 00 
    771330601c1a:	0f 84 74 0b 00 18    	je     0x771348602794
    771330601c20:	58                   	pop    rax
    771330601c21:	50                   	push   rax
    771330601c22:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330601c26:	f6 c1 03             	test   cl,0x3
    771330601c29:	0f 85 c5 0b 00 18    	jne    0x7713486027f4
    771330601c2f:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    771330601c36:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    771330601c3a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330601c41:	48 89 ce             	mov    rsi,rcx
    771330601c44:	48 c1 ee 0c          	shr    rsi,0xc
    771330601c48:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330601c4c:	48 85 c0             	test   rax,rax
    771330601c4f:	0f 84 f2 0b 00 18    	je     0x771348602847
    771330601c55:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601c5b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330601c5e:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1035c
    771330601c65:	5c 03 01 00 
    771330601c69:	0f 84 13 0c 00 18    	je     0x771348602882
    771330601c6f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035c
    771330601c76:	5c 03 01 00 
    771330601c7a:	0f 84 02 0c 00 18    	je     0x771348602882
    771330601c80:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330601c83:	0f 85 3a 0c 00 18    	jne    0x7713486028c3
    771330601c89:	58                   	pop    rax
    771330601c8a:	e9 0f 00 00 00       	jmp    0x771330601c9e
    771330601c8f:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330601c96:	00 
    771330601c97:	74 f0                	je     0x771330601c89
    771330601c99:	e9 8d 0b 00 18       	jmp    0x77134860282b
    771330601c9e:	50                   	push   rax
    771330601c9f:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330601ca3:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330601caa:	31 d2                	xor    edx,edx
    771330601cac:	89 c6                	mov    esi,eax
    771330601cae:	83 c6 fe             	add    esi,0xfffffffe
    771330601cb1:	0f 94 c2             	sete   dl
    771330601cb4:	09 c6                	or     esi,eax
    771330601cb6:	c1 ee 1f             	shr    esi,0x1f
    771330601cb9:	31 ff                	xor    edi,edi
    771330601cbb:	83 f8 02             	cmp    eax,0x2
    771330601cbe:	40 0f 93 c7          	setae  dil
    771330601cc2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330601cc9:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330601cd0:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    771330601cd7:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    771330601cde:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    771330601ce5:	81 f9 5e 03 01 00    	cmp    ecx,0x1035e
    771330601ceb:	0f 84 04 0c 00 18    	je     0x7713486028f5
    771330601cf1:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1035e
    771330601cf8:	5e 03 01 00 
    771330601cfc:	0f 84 f3 0b 00 18    	je     0x7713486028f5
    771330601d02:	58                   	pop    rax
    771330601d03:	50                   	push   rax
    771330601d04:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330601d0b:	00 
    771330601d0c:	74 55                	je     0x771330601d63
    771330601d0e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330601d15:	01 
    771330601d16:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    771330601d1d:	60 03 01 00 
    771330601d21:	0f 84 2e 0c 00 18    	je     0x771348602955
    771330601d27:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    771330601d2e:	60 03 01 00 
    771330601d32:	0f 84 1d 0c 00 18    	je     0x771348602955
    771330601d38:	b8 60 03 01 00       	mov    eax,0x10360
    771330601d3d:	83 c0 1a             	add    eax,0x1a
    771330601d40:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330601d47:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330601d4e:	02 00 00 00 
    771330601d52:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x15
    771330601d59:	15 00 00 00 
    771330601d5d:	58                   	pop    rax
    771330601d5e:	e9 0c 03 00 00       	jmp    0x77133060206f
    771330601d63:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10360
    771330601d6a:	60 03 01 00 
    771330601d6e:	0f 84 1d 0c 00 18    	je     0x771348602991
    771330601d74:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10360
    771330601d7b:	60 03 01 00 
    771330601d7f:	0f 84 0c 0c 00 18    	je     0x771348602991
    771330601d85:	58                   	pop    rax
    771330601d86:	50                   	push   rax
    771330601d87:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330601d8b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330601d92:	31 d2                	xor    edx,edx
    771330601d94:	89 c6                	mov    esi,eax
    771330601d96:	83 c6 fd             	add    esi,0xfffffffd
    771330601d99:	0f 94 c2             	sete   dl
    771330601d9c:	09 c6                	or     esi,eax
    771330601d9e:	c1 ee 1f             	shr    esi,0x1f
    771330601da1:	31 ff                	xor    edi,edi
    771330601da3:	83 f8 03             	cmp    eax,0x3
    771330601da6:	40 0f 93 c7          	setae  dil
    771330601daa:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330601db1:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330601db8:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    771330601dbf:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    771330601dc6:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    771330601dcd:	81 f9 62 03 01 00    	cmp    ecx,0x10362
    771330601dd3:	0f 84 01 0c 00 18    	je     0x7713486029da
    771330601dd9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10362
    771330601de0:	62 03 01 00 
    771330601de4:	0f 84 f0 0b 00 18    	je     0x7713486029da
    771330601dea:	58                   	pop    rax
    771330601deb:	50                   	push   rax
    771330601dec:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330601df3:	00 
    771330601df4:	74 55                	je     0x771330601e4b
    771330601df6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330601dfd:	01 
    771330601dfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    771330601e05:	64 03 01 00 
    771330601e09:	0f 84 2b 0c 00 18    	je     0x771348602a3a
    771330601e0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    771330601e16:	64 03 01 00 
    771330601e1a:	0f 84 1a 0c 00 18    	je     0x771348602a3a
    771330601e20:	b8 64 03 01 00       	mov    eax,0x10364
    771330601e25:	83 c0 40             	add    eax,0x40
    771330601e28:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330601e2f:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330601e36:	02 00 00 00 
    771330601e3a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x17
    771330601e41:	17 00 00 00 
    771330601e45:	58                   	pop    rax
    771330601e46:	e9 24 02 00 00       	jmp    0x77133060206f
    771330601e4b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10364
    771330601e52:	64 03 01 00 
    771330601e56:	0f 84 1a 0c 00 18    	je     0x771348602a76
    771330601e5c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10364
    771330601e63:	64 03 01 00 
    771330601e67:	0f 84 09 0c 00 18    	je     0x771348602a76
    771330601e6d:	58                   	pop    rax
    771330601e6e:	50                   	push   rax
    771330601e6f:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    771330601e76:	00 
    771330601e77:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10366
    771330601e7e:	66 03 01 00 
    771330601e82:	0f 84 37 0c 00 18    	je     0x771348602abf
    771330601e88:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10366
    771330601e8f:	66 03 01 00 
    771330601e93:	0f 84 26 0c 00 18    	je     0x771348602abf
    771330601e99:	58                   	pop    rax
    771330601e9a:	50                   	push   rax
    771330601e9b:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    771330601e9f:	f6 c3 03             	test   bl,0x3
    771330601ea2:	0f 85 77 0c 00 18    	jne    0x771348602b1f
    771330601ea8:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330601eaf:	48 89 d8             	mov    rax,rbx
    771330601eb2:	48 c1 e8 0c          	shr    rax,0xc
    771330601eb6:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601ebb:	48 85 c0             	test   rax,rax
    771330601ebe:	0f 84 ad 0c 00 18    	je     0x771348602b71
    771330601ec4:	89 d9                	mov    ecx,ebx
    771330601ec6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601ecc:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    771330601ed0:	89 de                	mov    esi,ebx
    771330601ed2:	83 c6 04             	add    esi,0x4
    771330601ed5:	89 f0                	mov    eax,esi
    771330601ed7:	c1 e8 0c             	shr    eax,0xc
    771330601eda:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601edf:	48 85 c0             	test   rax,rax
    771330601ee2:	0f 84 c6 0c 00 18    	je     0x771348602bae
    771330601ee8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601eee:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330601ef1:	8d 4b 08             	lea    ecx,[rbx+0x8]
    771330601ef4:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    771330601ef8:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330601eff:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    771330601f03:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10368
    771330601f0a:	68 03 01 00 
    771330601f0e:	0f 84 d6 0c 00 18    	je     0x771348602bea
    771330601f14:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10368
    771330601f1b:	68 03 01 00 
    771330601f1f:	0f 84 c5 0c 00 18    	je     0x771348602bea
    771330601f25:	58                   	pop    rax
    771330601f26:	50                   	push   rax
    771330601f27:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330601f2b:	f6 c3 03             	test   bl,0x3
    771330601f2e:	0f 85 ff 0c 00 18    	jne    0x771348602c33
    771330601f34:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330601f3b:	48 89 d8             	mov    rax,rbx
    771330601f3e:	48 c1 e8 0c          	shr    rax,0xc
    771330601f42:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601f47:	48 85 c0             	test   rax,rax
    771330601f4a:	0f 84 35 0d 00 18    	je     0x771348602c85
    771330601f50:	89 d9                	mov    ecx,ebx
    771330601f52:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330601f58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330601f5b:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    771330601f5f:	8d 73 04             	lea    esi,[rbx+0x4]
    771330601f62:	89 f0                	mov    eax,esi
    771330601f64:	c1 e8 0c             	shr    eax,0xc
    771330601f67:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601f6c:	48 85 c0             	test   rax,rax
    771330601f6f:	0f 84 4b 0d 00 18    	je     0x771348602cc0
    771330601f75:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601f7b:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330601f7e:	41 89 45 30          	mov    DWORD PTR [r13+0x30],eax
    771330601f82:	8d 73 08             	lea    esi,[rbx+0x8]
    771330601f85:	89 f0                	mov    eax,esi
    771330601f87:	c1 e8 0c             	shr    eax,0xc
    771330601f8a:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601f8f:	48 85 c0             	test   rax,rax
    771330601f92:	0f 84 64 0d 00 18    	je     0x771348602cfc
    771330601f98:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601f9e:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330601fa1:	41 89 45 2c          	mov    DWORD PTR [r13+0x2c],eax
    771330601fa5:	8d 73 0c             	lea    esi,[rbx+0xc]
    771330601fa8:	89 f0                	mov    eax,esi
    771330601faa:	c1 e8 0c             	shr    eax,0xc
    771330601fad:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601fb2:	48 85 c0             	test   rax,rax
    771330601fb5:	0f 84 7d 0d 00 18    	je     0x771348602d38
    771330601fbb:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601fc1:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330601fc4:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330601fc8:	89 de                	mov    esi,ebx
    771330601fca:	83 c6 10             	add    esi,0x10
    771330601fcd:	89 f0                	mov    eax,esi
    771330601fcf:	c1 e8 0c             	shr    eax,0xc
    771330601fd2:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330601fd7:	48 85 c0             	test   rax,rax
    771330601fda:	0f 84 94 0d 00 18    	je     0x771348602d74
    771330601fe0:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330601fe6:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330601fe9:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    771330601fed:	8d 43 14             	lea    eax,[rbx+0x14]
    771330601ff0:	41 89 45 38          	mov    DWORD PTR [r13+0x38],eax
    771330601ff4:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036c
    771330601ffb:	6c 03 01 00 
    771330601fff:	0f 84 ab 0d 00 18    	je     0x771348602db0
    771330602005:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036c
    77133060200c:	6c 03 01 00 
    771330602010:	0f 84 9a 0d 00 18    	je     0x771348602db0
    771330602016:	58                   	pop    rax
    771330602017:	50                   	push   rax
    771330602018:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    77133060201f:	a8 01                	test   al,0x1
    771330602021:	0f 85 d2 0d 00 18    	jne    0x771348602df9
    771330602027:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    77133060202e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602035:	01 
    771330602036:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1036e
    77133060203d:	6e 03 01 00 
    771330602041:	0f 84 e8 0d 00 18    	je     0x771348602e2f
    771330602047:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1036e
    77133060204e:	6e 03 01 00 
    771330602052:	0f 84 d7 0d 00 18    	je     0x771348602e2f
    771330602058:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060205f:	02 00 00 00 
    771330602063:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x1b
    77133060206a:	1b 00 00 00 
    77133060206e:	58                   	pop    rax
    77133060206f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602076:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    77133060207d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330602084:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060208b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330602092:	39 f1                	cmp    ecx,esi
    771330602094:	0f 83 c2 0d 00 18    	jae    0x771348602e5c
    77133060209a:	81 fa 28 03 01 00    	cmp    edx,0x10328
    7713306020a0:	75 14                	jne    0x7713306020b6
    7713306020a2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306020a9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306020b0:	00 
    7713306020b1:	e9 0a f4 ff ff       	jmp    0x7713306014c0
    7713306020b6:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    7713306020bd:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    7713306020c3:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    7713306020c6:	0f 85 90 0d 00 18    	jne    0x771348602e5c
    7713306020cc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7713306020d3:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7713306020da:	00 
    7713306020db:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    7713306020e0:	ff e0                	jmp    rax
