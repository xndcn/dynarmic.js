
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66752-1-130924299694240.bin:     file format binary


Disassembly of section .data:

00007713306030a0 <.data>:
    7713306030a0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306030a7:	8b 88 28 00 10 00    	mov    ecx,DWORD PTR [rax+0x100028]
    7713306030ad:	ff c1                	inc    ecx
    7713306030af:	89 88 28 00 10 00    	mov    DWORD PTR [rax+0x100028],ecx
    7713306030b5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    7713306030bb:	0f 84 5f 11 00 18    	je     0x771348604220
    7713306030c1:	50                   	push   rax
    7713306030c2:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    7713306030c7:	b9 00 00 01 00       	mov    ecx,0x10000
    7713306030cc:	09 c1                	or     ecx,eax
    7713306030ce:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306030d2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104c0
    7713306030d9:	c0 04 01 00 
    7713306030dd:	0f 84 69 11 00 18    	je     0x77134860424c
    7713306030e3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104c0
    7713306030ea:	c0 04 01 00 
    7713306030ee:	0f 84 58 11 00 18    	je     0x77134860424c
    7713306030f4:	58                   	pop    rax
    7713306030f5:	50                   	push   rax
    7713306030f6:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7713306030fb:	c1 e0 10             	shl    eax,0x10
    7713306030fe:	b9 f4 12 00 00       	mov    ecx,0x12f4
    771330603103:	09 c1                	or     ecx,eax
    771330603105:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330603109:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104c4
    771330603110:	c4 04 01 00 
    771330603114:	0f 84 92 11 00 18    	je     0x7713486042ac
    77133060311a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104c4
    771330603121:	c4 04 01 00 
    771330603125:	0f 84 81 11 00 18    	je     0x7713486042ac
    77133060312b:	58                   	pop    rax
    77133060312c:	50                   	push   rax
    77133060312d:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330603131:	f6 c1 03             	test   cl,0x3
    771330603134:	0f 85 d2 11 00 18    	jne    0x77134860430c
    77133060313a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330603141:	48 89 ca             	mov    rdx,rcx
    771330603144:	48 c1 ea 0c          	shr    rdx,0xc
    771330603148:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    77133060314c:	48 85 c0             	test   rax,rax
    77133060314f:	0f 84 07 12 00 18    	je     0x77134860435c
    771330603155:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060315b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    77133060315e:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330603162:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104c8
    771330603169:	c8 04 01 00 
    77133060316d:	0f 84 24 12 00 18    	je     0x771348604397
    771330603173:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104c8
    77133060317a:	c8 04 01 00 
    77133060317e:	0f 84 13 12 00 18    	je     0x771348604397
    771330603184:	58                   	pop    rax
    771330603185:	50                   	push   rax
    771330603186:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    77133060318b:	b9 00 00 01 00       	mov    ecx,0x10000
    771330603190:	09 c1                	or     ecx,eax
    771330603192:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330603196:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104ca
    77133060319d:	ca 04 01 00 
    7713306031a1:	0f 84 39 12 00 18    	je     0x7713486043e0
    7713306031a7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104ca
    7713306031ae:	ca 04 01 00 
    7713306031b2:	0f 84 28 12 00 18    	je     0x7713486043e0
    7713306031b8:	58                   	pop    rax
    7713306031b9:	50                   	push   rax
    7713306031ba:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    7713306031bf:	c1 e0 10             	shl    eax,0x10
    7713306031c2:	b9 f8 12 00 00       	mov    ecx,0x12f8
    7713306031c7:	09 c1                	or     ecx,eax
    7713306031c9:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    7713306031cd:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104ce
    7713306031d4:	ce 04 01 00 
    7713306031d8:	0f 84 62 12 00 18    	je     0x771348604440
    7713306031de:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104ce
    7713306031e5:	ce 04 01 00 
    7713306031e9:	0f 84 51 12 00 18    	je     0x771348604440
    7713306031ef:	58                   	pop    rax
    7713306031f0:	50                   	push   rax
    7713306031f1:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    7713306031f5:	f6 c1 03             	test   cl,0x3
    7713306031f8:	0f 85 a2 12 00 18    	jne    0x7713486044a0
    7713306031fe:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330603205:	48 89 ca             	mov    rdx,rcx
    771330603208:	48 c1 ea 0c          	shr    rdx,0xc
    77133060320c:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330603210:	48 85 c0             	test   rax,rax
    771330603213:	0f 84 d7 12 00 18    	je     0x7713486044f0
    771330603219:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060321f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330603222:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330603226:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104d2
    77133060322d:	d2 04 01 00 
    771330603231:	0f 84 f4 12 00 18    	je     0x77134860452b
    771330603237:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104d2
    77133060323e:	d2 04 01 00 
    771330603242:	0f 84 e3 12 00 18    	je     0x77134860452b
    771330603248:	58                   	pop    rax
    771330603249:	50                   	push   rax
    77133060324a:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    77133060324e:	f6 c3 03             	test   bl,0x3
    771330603251:	0f 85 1d 13 00 18    	jne    0x771348604574
    771330603257:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    77133060325e:	48 89 d8             	mov    rax,rbx
    771330603261:	48 c1 e8 0c          	shr    rax,0xc
    771330603265:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060326a:	48 85 c0             	test   rax,rax
    77133060326d:	0f 84 53 13 00 18    	je     0x7713486045c6
    771330603273:	89 d9                	mov    ecx,ebx
    771330603275:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    77133060327b:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    77133060327f:	89 de                	mov    esi,ebx
    771330603281:	83 c6 04             	add    esi,0x4
    771330603284:	89 f0                	mov    eax,esi
    771330603286:	c1 e8 0c             	shr    eax,0xc
    771330603289:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    77133060328e:	48 85 c0             	test   rax,rax
    771330603291:	0f 84 6c 13 00 18    	je     0x771348604603
    771330603297:	81 e6 ff 0f 00 00    	and    esi,0xfff
    77133060329d:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    7713306032a0:	8d 4b 08             	lea    ecx,[rbx+0x8]
    7713306032a3:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    7713306032a7:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    7713306032ae:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    7713306032b2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104d4
    7713306032b9:	d4 04 01 00 
    7713306032bd:	0f 84 7c 13 00 18    	je     0x77134860463f
    7713306032c3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104d4
    7713306032ca:	d4 04 01 00 
    7713306032ce:	0f 84 6b 13 00 18    	je     0x77134860463f
    7713306032d4:	58                   	pop    rax
    7713306032d5:	50                   	push   rax
    7713306032d6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7713306032dd:	01 
    7713306032de:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x104d8
    7713306032e5:	d8 04 01 00 
    7713306032e9:	0f 84 99 13 00 18    	je     0x771348604688
    7713306032ef:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x104d8
    7713306032f6:	d8 04 01 00 
    7713306032fa:	0f 84 88 13 00 18    	je     0x771348604688
    771330603300:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101a0
    771330603307:	a0 01 01 00 
    77133060330b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    771330603312:	04 00 00 00 
    771330603316:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    77133060331d:	08 00 00 00 
    771330603321:	58                   	pop    rax
    771330603322:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330603329:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330603330:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330603337:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060333e:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330603345:	39 f1                	cmp    ecx,esi
    771330603347:	0f 83 73 13 00 18    	jae    0x7713486046c0
    77133060334d:	81 fa c0 04 01 00    	cmp    edx,0x104c0
    771330603353:	75 14                	jne    0x771330603369
    771330603355:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    77133060335c:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330603363:	00 
    771330603364:	e9 37 fd ff ff       	jmp    0x7713306030a0
    771330603369:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330603370:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330603376:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330603379:	0f 85 41 13 00 18    	jne    0x7713486046c0
    77133060337f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330603386:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060338d:	00 
    77133060338e:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330603393:	ff e0                	jmp    rax
