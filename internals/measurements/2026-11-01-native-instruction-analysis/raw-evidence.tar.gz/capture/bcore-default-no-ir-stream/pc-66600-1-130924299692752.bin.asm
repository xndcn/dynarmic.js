
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66600-1-130924299692752.bin:     file format binary


Disassembly of section .data:

0000771330602ad0 <.data>:
    771330602ad0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602ad7:	8b 88 20 00 10 00    	mov    ecx,DWORD PTR [rax+0x100020]
    771330602add:	ff c1                	inc    ecx
    771330602adf:	89 88 20 00 10 00    	mov    DWORD PTR [rax+0x100020],ecx
    771330602ae5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    771330602aeb:	0f 84 cf 0e 00 18    	je     0x7713486039c0
    771330602af1:	50                   	push   rax
    771330602af2:	41 0f b7 45 28       	movzx  eax,WORD PTR [r13+0x28]
    771330602af7:	b9 00 00 01 00       	mov    ecx,0x10000
    771330602afc:	09 c1                	or     ecx,eax
    771330602afe:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330602b02:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10428
    771330602b09:	28 04 01 00 
    771330602b0d:	0f 84 d9 0e 00 18    	je     0x7713486039ec
    771330602b13:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10428
    771330602b1a:	28 04 01 00 
    771330602b1e:	0f 84 c8 0e 00 18    	je     0x7713486039ec
    771330602b24:	58                   	pop    rax
    771330602b25:	50                   	push   rax
    771330602b26:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330602b2a:	8d 4b fc             	lea    ecx,[rbx-0x4]
    771330602b2d:	f6 c3 03             	test   bl,0x3
    771330602b30:	0f 85 16 0f 00 18    	jne    0x771348603a4c
    771330602b36:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    771330602b3d:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330602b44:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    771330602b48:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    771330602b4f:	89 c8                	mov    eax,ecx
    771330602b51:	c1 e8 0c             	shr    eax,0xc
    771330602b54:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602b59:	48 85 c0             	test   rax,rax
    771330602b5c:	0f 84 3d 0f 00 18    	je     0x771348603a9f
    771330602b62:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602b68:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330602b6b:	83 c3 f8             	add    ebx,0xfffffff8
    771330602b6e:	89 d8                	mov    eax,ebx
    771330602b70:	c1 e8 0c             	shr    eax,0xc
    771330602b73:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602b78:	48 85 c0             	test   rax,rax
    771330602b7b:	0f 84 59 0f 00 18    	je     0x771348603ada
    771330602b81:	89 d9                	mov    ecx,ebx
    771330602b83:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602b89:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    771330602b8d:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    771330602b91:	b8 00 00 00 00       	mov    eax,0x0
    771330602b96:	29 c3                	sub    ebx,eax
    771330602b98:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    771330602b9c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1042c
    771330602ba3:	2c 04 01 00 
    771330602ba7:	0f 84 6e 0f 00 18    	je     0x771348603b1b
    771330602bad:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1042c
    771330602bb4:	2c 04 01 00 
    771330602bb8:	0f 84 5d 0f 00 18    	je     0x771348603b1b
    771330602bbe:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    771330602bc2:	0f 85 95 0f 00 18    	jne    0x771348603b5d
    771330602bc8:	58                   	pop    rax
    771330602bc9:	e9 0f 00 00 00       	jmp    0x771330602bdd
    771330602bce:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    771330602bd5:	00 
    771330602bd6:	74 f0                	je     0x771330602bc8
    771330602bd8:	e9 a6 0e 00 18       	jmp    0x771348603a83
    771330602bdd:	50                   	push   rax
    771330602bde:	41 0f b7 45 2a       	movzx  eax,WORD PTR [r13+0x2a]
    771330602be3:	c1 e0 10             	shl    eax,0x10
    771330602be6:	b9 f0 12 00 00       	mov    ecx,0x12f0
    771330602beb:	09 c1                	or     ecx,eax
    771330602bed:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    771330602bf1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10430
    771330602bf8:	30 04 01 00 
    771330602bfc:	0f 84 8d 0f 00 18    	je     0x771348603b8f
    771330602c02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10430
    771330602c09:	30 04 01 00 
    771330602c0d:	0f 84 7c 0f 00 18    	je     0x771348603b8f
    771330602c13:	58                   	pop    rax
    771330602c14:	50                   	push   rax
    771330602c15:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330602c19:	f6 c1 03             	test   cl,0x3
    771330602c1c:	0f 85 cd 0f 00 18    	jne    0x771348603bef
    771330602c22:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330602c29:	48 89 ca             	mov    rdx,rcx
    771330602c2c:	48 c1 ea 0c          	shr    rdx,0xc
    771330602c30:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330602c34:	48 85 c0             	test   rax,rax
    771330602c37:	0f 84 02 10 00 18    	je     0x771348603c3f
    771330602c3d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602c43:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330602c46:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330602c4a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10434
    771330602c51:	34 04 01 00 
    771330602c55:	0f 84 1f 10 00 18    	je     0x771348603c7a
    771330602c5b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10434
    771330602c62:	34 04 01 00 
    771330602c66:	0f 84 0e 10 00 18    	je     0x771348603c7a
    771330602c6c:	58                   	pop    rax
    771330602c6d:	50                   	push   rax
    771330602c6e:	31 c0                	xor    eax,eax
    771330602c70:	41 83 7d 28 05       	cmp    DWORD PTR [r13+0x28],0x5
    771330602c75:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330602c7c:	0f 92 c0             	setb   al
    771330602c7f:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    771330602c86:	81 f9 36 04 01 00    	cmp    ecx,0x10436
    771330602c8c:	0f 84 31 10 00 18    	je     0x771348603cc3
    771330602c92:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10436
    771330602c99:	36 04 01 00 
    771330602c9d:	0f 84 20 10 00 18    	je     0x771348603cc3
    771330602ca3:	58                   	pop    rax
    771330602ca4:	50                   	push   rax
    771330602ca5:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330602cac:	00 
    771330602cad:	74 55                	je     0x771330602d04
    771330602caf:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602cb6:	01 
    771330602cb7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    771330602cbe:	38 04 01 00 
    771330602cc2:	0f 84 5b 10 00 18    	je     0x771348603d23
    771330602cc8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    771330602ccf:	38 04 01 00 
    771330602cd3:	0f 84 4a 10 00 18    	je     0x771348603d23
    771330602cd9:	b8 38 04 01 00       	mov    eax,0x10438
    771330602cde:	83 c0 0a             	add    eax,0xa
    771330602ce1:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602ce8:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330602cef:	02 00 00 00 
    771330602cf3:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    771330602cfa:	06 00 00 00 
    771330602cfe:	58                   	pop    rax
    771330602cff:	e9 33 01 00 00       	jmp    0x771330602e37
    771330602d04:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10438
    771330602d0b:	38 04 01 00 
    771330602d0f:	0f 84 4a 10 00 18    	je     0x771348603d5f
    771330602d15:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10438
    771330602d1c:	38 04 01 00 
    771330602d20:	0f 84 39 10 00 18    	je     0x771348603d5f
    771330602d26:	58                   	pop    rax
    771330602d27:	50                   	push   rax
    771330602d28:	41 c7 45 00 00 00 00 	mov    DWORD PTR [r13+0x0],0x0
    771330602d2f:	00 
    771330602d30:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043a
    771330602d37:	3a 04 01 00 
    771330602d3b:	0f 84 67 10 00 18    	je     0x771348603da8
    771330602d41:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043a
    771330602d48:	3a 04 01 00 
    771330602d4c:	0f 84 56 10 00 18    	je     0x771348603da8
    771330602d52:	58                   	pop    rax
    771330602d53:	50                   	push   rax
    771330602d54:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    771330602d58:	f6 c3 03             	test   bl,0x3
    771330602d5b:	0f 85 a7 10 00 18    	jne    0x771348603e08
    771330602d61:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330602d68:	48 89 d8             	mov    rax,rbx
    771330602d6b:	48 c1 e8 0c          	shr    rax,0xc
    771330602d6f:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602d74:	48 85 c0             	test   rax,rax
    771330602d77:	0f 84 dd 10 00 18    	je     0x771348603e5a
    771330602d7d:	89 d9                	mov    ecx,ebx
    771330602d7f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602d85:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    771330602d89:	89 de                	mov    esi,ebx
    771330602d8b:	83 c6 04             	add    esi,0x4
    771330602d8e:	89 f0                	mov    eax,esi
    771330602d90:	c1 e8 0c             	shr    eax,0xc
    771330602d93:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330602d98:	48 85 c0             	test   rax,rax
    771330602d9b:	0f 84 f6 10 00 18    	je     0x771348603e97
    771330602da1:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330602da7:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330602daa:	8d 4b 08             	lea    ecx,[rbx+0x8]
    771330602dad:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    771330602db1:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330602db8:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    771330602dbc:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1043c
    771330602dc3:	3c 04 01 00 
    771330602dc7:	0f 84 06 11 00 18    	je     0x771348603ed3
    771330602dcd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1043c
    771330602dd4:	3c 04 01 00 
    771330602dd8:	0f 84 f5 10 00 18    	je     0x771348603ed3
    771330602dde:	58                   	pop    rax
    771330602ddf:	50                   	push   rax
    771330602de0:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330602de7:	a8 01                	test   al,0x1
    771330602de9:	0f 85 2d 11 00 18    	jne    0x771348603f1c
    771330602def:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602df6:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602dfd:	01 
    771330602dfe:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10440
    771330602e05:	40 04 01 00 
    771330602e09:	0f 84 43 11 00 18    	je     0x771348603f52
    771330602e0f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10440
    771330602e16:	40 04 01 00 
    771330602e1a:	0f 84 32 11 00 18    	je     0x771348603f52
    771330602e20:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330602e27:	02 00 00 00 
    771330602e2b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    771330602e32:	09 00 00 00 
    771330602e36:	58                   	pop    rax
    771330602e37:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602e3e:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330602e45:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330602e4c:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330602e53:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330602e5a:	39 f1                	cmp    ecx,esi
    771330602e5c:	0f 83 1d 11 00 18    	jae    0x771348603f7f
    771330602e62:	81 fa 28 04 01 00    	cmp    edx,0x10428
    771330602e68:	75 14                	jne    0x771330602e7e
    771330602e6a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602e71:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602e78:	00 
    771330602e79:	e9 52 fc ff ff       	jmp    0x771330602ad0
    771330602e7e:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330602e85:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330602e8b:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330602e8e:	0f 85 eb 10 00 18    	jne    0x771348603f7f
    771330602e94:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602e9b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602ea2:	00 
    771330602ea3:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330602ea8:	ff e0                	jmp    rax
