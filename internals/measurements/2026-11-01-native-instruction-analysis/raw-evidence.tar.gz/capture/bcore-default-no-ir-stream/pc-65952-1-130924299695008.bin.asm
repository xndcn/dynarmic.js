
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-65952-1-130924299695008.bin:     file format binary


Disassembly of section .data:

00007713306033a0 <.data>:
    7713306033a0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306033a7:	8b 88 2c 00 10 00    	mov    ecx,DWORD PTR [rax+0x10002c]
    7713306033ad:	ff c1                	inc    ecx
    7713306033af:	89 88 2c 00 10 00    	mov    DWORD PTR [rax+0x10002c],ecx
    7713306033b5:	81 f9 b3 f1 00 00    	cmp    ecx,0xf1b3
    7713306033bb:	0f 84 0f 13 00 18    	je     0x7713486046d0
    7713306033c1:	50                   	push   rax
    7713306033c2:	41 8b 45 38          	mov    eax,DWORD PTR [r13+0x38]
    7713306033c6:	8d 58 fc             	lea    ebx,[rax-0x4]
    7713306033c9:	a8 03                	test   al,0x3
    7713306033cb:	0f 85 2b 13 00 18    	jne    0x7713486046fc
    7713306033d1:	49 8b ad 40 01 00 00 	mov    rbp,QWORD PTR [r13+0x140]
    7713306033d8:	41 8b 55 1c          	mov    edx,DWORD PTR [r13+0x1c]
    7713306033dc:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306033e3:	89 d9                	mov    ecx,ebx
    7713306033e5:	c1 e9 0c             	shr    ecx,0xc
    7713306033e8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7713306033ec:	48 85 c0             	test   rax,rax
    7713306033ef:	0f 84 5c 13 00 18    	je     0x771348604751
    7713306033f5:	89 d9                	mov    ecx,ebx
    7713306033f7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306033fd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330603400:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    771330603404:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101a0
    77133060340b:	a0 01 01 00 
    77133060340f:	0f 84 77 13 00 18    	je     0x77134860478c
    771330603415:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101a0
    77133060341c:	a0 01 01 00 
    771330603420:	0f 84 66 13 00 18    	je     0x77134860478c
    771330603426:	80 7d 00 00          	cmp    BYTE PTR [rbp+0x0],0x0
    77133060342a:	0f 85 9e 13 00 18    	jne    0x7713486047ce
    771330603430:	58                   	pop    rax
    771330603431:	e9 0f 00 00 00       	jmp    0x771330603445
    771330603436:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77133060343d:	00 
    77133060343e:	74 f0                	je     0x771330603430
    771330603440:	e9 f0 12 00 18       	jmp    0x771348604735
    771330603445:	50                   	push   rax
    771330603446:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    77133060344a:	8d 4b fc             	lea    ecx,[rbx-0x4]
    77133060344d:	f6 c3 03             	test   bl,0x3
    771330603450:	0f 85 aa 13 00 18    	jne    0x771348604800
    771330603456:	4d 8b bd 40 01 00 00 	mov    r15,QWORD PTR [r13+0x140]
    77133060345d:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330603464:	45 8b 65 3c          	mov    r12d,DWORD PTR [r13+0x3c]
    771330603468:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    77133060346f:	89 c8                	mov    eax,ecx
    771330603471:	c1 e8 0c             	shr    eax,0xc
    771330603474:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330603479:	48 85 c0             	test   rax,rax
    77133060347c:	0f 84 d1 13 00 18    	je     0x771348604853
    771330603482:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330603488:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    77133060348b:	83 c3 f8             	add    ebx,0xfffffff8
    77133060348e:	89 d8                	mov    eax,ebx
    771330603490:	c1 e8 0c             	shr    eax,0xc
    771330603493:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330603498:	48 85 c0             	test   rax,rax
    77133060349b:	0f 84 ed 13 00 18    	je     0x77134860488e
    7713306034a1:	89 d9                	mov    ecx,ebx
    7713306034a3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306034a9:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    7713306034ad:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    7713306034b1:	b8 00 00 00 00       	mov    eax,0x0
    7713306034b6:	29 c3                	sub    ebx,eax
    7713306034b8:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    7713306034bc:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101a2
    7713306034c3:	a2 01 01 00 
    7713306034c7:	0f 84 02 14 00 18    	je     0x7713486048cf
    7713306034cd:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101a2
    7713306034d4:	a2 01 01 00 
    7713306034d8:	0f 84 f1 13 00 18    	je     0x7713486048cf
    7713306034de:	41 80 3f 00          	cmp    BYTE PTR [r15],0x0
    7713306034e2:	0f 85 29 14 00 18    	jne    0x771348604911
    7713306034e8:	58                   	pop    rax
    7713306034e9:	e9 0f 00 00 00       	jmp    0x7713306034fd
    7713306034ee:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    7713306034f5:	00 
    7713306034f6:	74 f0                	je     0x7713306034e8
    7713306034f8:	e9 3a 13 00 18       	jmp    0x771348604837
    7713306034fd:	50                   	push   rax
    7713306034fe:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330603502:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603509:	31 d2                	xor    edx,edx
    77133060350b:	85 c0                	test   eax,eax
    77133060350d:	0f 94 c2             	sete   dl
    771330603510:	c1 e8 1f             	shr    eax,0x1f
    771330603513:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    77133060351a:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330603521:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330603528:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    77133060352f:	00 00 00 
    771330603532:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    771330603539:	81 f9 a6 01 01 00    	cmp    ecx,0x101a6
    77133060353f:	0f 84 fe 13 00 18    	je     0x771348604943
    771330603545:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101a6
    77133060354c:	a6 01 01 00 
    771330603550:	0f 84 ed 13 00 18    	je     0x771348604943
    771330603556:	58                   	pop    rax
    771330603557:	50                   	push   rax
    771330603558:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    77133060355f:	00 
    771330603560:	74 55                	je     0x7713306035b7
    771330603562:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330603569:	01 
    77133060356a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101a8
    771330603571:	a8 01 01 00 
    771330603575:	0f 84 28 14 00 18    	je     0x7713486049a3
    77133060357b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101a8
    771330603582:	a8 01 01 00 
    771330603586:	0f 84 17 14 00 18    	je     0x7713486049a3
    77133060358c:	b8 a8 01 01 00       	mov    eax,0x101a8
    771330603591:	83 c0 48             	add    eax,0x48
    771330603594:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    77133060359b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    7713306035a2:	02 00 00 00 
    7713306035a6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x4
    7713306035ad:	04 00 00 00 
    7713306035b1:	58                   	pop    rax
    7713306035b2:	e9 45 09 00 00       	jmp    0x771330603efc
    7713306035b7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101a8
    7713306035be:	a8 01 01 00 
    7713306035c2:	0f 84 17 14 00 18    	je     0x7713486049df
    7713306035c8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101a8
    7713306035cf:	a8 01 01 00 
    7713306035d3:	0f 84 06 14 00 18    	je     0x7713486049df
    7713306035d9:	58                   	pop    rax
    7713306035da:	50                   	push   rax
    7713306035db:	41 0f b7 45 20       	movzx  eax,WORD PTR [r13+0x20]
    7713306035e0:	b9 00 00 01 00       	mov    ecx,0x10000
    7713306035e5:	09 c1                	or     ecx,eax
    7713306035e7:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    7713306035eb:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101aa
    7713306035f2:	aa 01 01 00 
    7713306035f6:	0f 84 2c 14 00 18    	je     0x771348604a28
    7713306035fc:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101aa
    771330603603:	aa 01 01 00 
    771330603607:	0f 84 1b 14 00 18    	je     0x771348604a28
    77133060360d:	58                   	pop    rax
    77133060360e:	50                   	push   rax
    77133060360f:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    771330603613:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    77133060361a:	41 89 45 24          	mov    DWORD PTR [r13+0x24],eax
    77133060361e:	81 f9 ae 01 01 00    	cmp    ecx,0x101ae
    771330603624:	0f 84 5e 14 00 18    	je     0x771348604a88
    77133060362a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ae
    771330603631:	ae 01 01 00 
    771330603635:	0f 84 4d 14 00 18    	je     0x771348604a88
    77133060363b:	58                   	pop    rax
    77133060363c:	50                   	push   rax
    77133060363d:	41 c7 45 08 00 00 00 	mov    DWORD PTR [r13+0x8],0x0
    771330603644:	00 
    771330603645:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101b0
    77133060364c:	b0 01 01 00 
    771330603650:	0f 84 92 14 00 18    	je     0x771348604ae8
    771330603656:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101b0
    77133060365d:	b0 01 01 00 
    771330603661:	0f 84 81 14 00 18    	je     0x771348604ae8
    771330603667:	58                   	pop    rax
    771330603668:	50                   	push   rax
    771330603669:	41 0f b7 45 22       	movzx  eax,WORD PTR [r13+0x22]
    77133060366e:	c1 e0 10             	shl    eax,0x10
    771330603671:	b9 fc 12 00 00       	mov    ecx,0x12fc
    771330603676:	09 c1                	or     ecx,eax
    771330603678:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    77133060367c:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101b2
    771330603683:	b2 01 01 00 
    771330603687:	0f 84 bb 14 00 18    	je     0x771348604b48
    77133060368d:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101b2
    771330603694:	b2 01 01 00 
    771330603698:	0f 84 aa 14 00 18    	je     0x771348604b48
    77133060369e:	58                   	pop    rax
    77133060369f:	50                   	push   rax
    7713306036a0:	41 c7 45 1c ff 1f 00 	mov    DWORD PTR [r13+0x1c],0x1fff
    7713306036a7:	00 
    7713306036a8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101b6
    7713306036af:	b6 01 01 00 
    7713306036b3:	0f 84 ef 14 00 18    	je     0x771348604ba8
    7713306036b9:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101b6
    7713306036c0:	b6 01 01 00 
    7713306036c4:	0f 84 de 14 00 18    	je     0x771348604ba8
    7713306036ca:	58                   	pop    rax
    7713306036cb:	50                   	push   rax
    7713306036cc:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    7713306036d0:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306036d7:	31 d2                	xor    edx,edx
    7713306036d9:	41 23 45 08          	and    eax,DWORD PTR [r13+0x8]
    7713306036dd:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7713306036e1:	0f 94 c2             	sete   dl
    7713306036e4:	c1 e8 1f             	shr    eax,0x1f
    7713306036e7:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306036ee:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7713306036f5:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7713306036fc:	00 00 00 00 
    771330603700:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330603707:	00 00 00 00 
    77133060370b:	81 f9 ba 01 01 00    	cmp    ecx,0x101ba
    771330603711:	0f 84 f1 14 00 18    	je     0x771348604c08
    771330603717:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ba
    77133060371e:	ba 01 01 00 
    771330603722:	0f 84 e0 14 00 18    	je     0x771348604c08
    771330603728:	58                   	pop    rax
    771330603729:	50                   	push   rax
    77133060372a:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    77133060372e:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603735:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330603739:	81 f9 bc 01 01 00    	cmp    ecx,0x101bc
    77133060373f:	0f 84 23 15 00 18    	je     0x771348604c68
    771330603745:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101bc
    77133060374c:	bc 01 01 00 
    771330603750:	0f 84 12 15 00 18    	je     0x771348604c68
    771330603756:	58                   	pop    rax
    771330603757:	50                   	push   rax
    771330603758:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    77133060375c:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603763:	c1 e0 02             	shl    eax,0x2
    771330603766:	41 03 45 20          	add    eax,DWORD PTR [r13+0x20]
    77133060376a:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    77133060376e:	81 f9 be 01 01 00    	cmp    ecx,0x101be
    771330603774:	0f 84 4e 15 00 18    	je     0x771348604cc8
    77133060377a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101be
    771330603781:	be 01 01 00 
    771330603785:	0f 84 3d 15 00 18    	je     0x771348604cc8
    77133060378b:	58                   	pop    rax
    77133060378c:	50                   	push   rax
    77133060378d:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330603791:	f6 c1 03             	test   cl,0x3
    771330603794:	0f 85 8e 15 00 18    	jne    0x771348604d28
    77133060379a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7713306037a1:	48 89 ca             	mov    rdx,rcx
    7713306037a4:	48 c1 ea 0c          	shr    rdx,0xc
    7713306037a8:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    7713306037ac:	48 85 c0             	test   rax,rax
    7713306037af:	0f 84 c3 15 00 18    	je     0x771348604d78
    7713306037b5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7713306037bb:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7713306037be:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    7713306037c2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c0
    7713306037c9:	c0 01 01 00 
    7713306037cd:	0f 84 e0 15 00 18    	je     0x771348604db3
    7713306037d3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c0
    7713306037da:	c0 01 01 00 
    7713306037de:	0f 84 cf 15 00 18    	je     0x771348604db3
    7713306037e4:	58                   	pop    rax
    7713306037e5:	50                   	push   rax
    7713306037e6:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    7713306037ea:	41 8b 4d 0c          	mov    ecx,DWORD PTR [r13+0xc]
    7713306037ee:	89 c2                	mov    edx,eax
    7713306037f0:	c1 ea 1f             	shr    edx,0x1f
    7713306037f3:	89 ce                	mov    esi,ecx
    7713306037f5:	c1 ee 1f             	shr    esi,0x1f
    7713306037f8:	31 ff                	xor    edi,edi
    7713306037fa:	01 c8                	add    eax,ecx
    7713306037fc:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    771330603800:	40 0f 92 c7          	setb   dil
    771330603804:	89 c1                	mov    ecx,eax
    771330603806:	c1 e9 1f             	shr    ecx,0x1f
    771330603809:	31 ce                	xor    esi,ecx
    77133060380b:	31 ca                	xor    edx,ecx
    77133060380d:	21 f2                	and    edx,esi
    77133060380f:	31 f6                	xor    esi,esi
    771330603811:	85 c0                	test   eax,eax
    771330603813:	40 0f 94 c6          	sete   sil
    771330603817:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    77133060381e:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    771330603825:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    77133060382c:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    771330603833:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    77133060383a:	41 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],edi
    771330603841:	41 89 bd f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edi
    771330603848:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c2
    77133060384f:	c2 01 01 00 
    771330603853:	0f 84 a3 15 00 18    	je     0x771348604dfc
    771330603859:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c2
    771330603860:	c2 01 01 00 
    771330603864:	0f 84 92 15 00 18    	je     0x771348604dfc
    77133060386a:	58                   	pop    rax
    77133060386b:	50                   	push   rax
    77133060386c:	41 8b 85 0c 00 00 00 	mov    eax,DWORD PTR [r13+0xc]
    771330603873:	89 c1                	mov    ecx,eax
    771330603875:	c1 e9 0b             	shr    ecx,0xb
    771330603878:	41 89 8d 04 00 00 00 	mov    DWORD PTR [r13+0x4],ecx
    77133060387f:	31 c9                	xor    ecx,ecx
    771330603881:	3d 00 08 00 00       	cmp    eax,0x800
    771330603886:	0f 92 c1             	setb   cl
    771330603889:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    771330603890:	41 c7 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],0x0
    771330603897:	00 00 00 00 
    77133060389b:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    7713306038a2:	00 00 00 00 
    7713306038a6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101c4
    7713306038ad:	c4 01 01 00 
    7713306038b1:	0f 84 a5 15 00 18    	je     0x771348604e5c
    7713306038b7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c4
    7713306038be:	c4 01 01 00 
    7713306038c2:	0f 84 94 15 00 18    	je     0x771348604e5c
    7713306038c8:	58                   	pop    rax
    7713306038c9:	50                   	push   rax
    7713306038ca:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    7713306038ce:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306038d5:	31 d2                	xor    edx,edx
    7713306038d7:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    7713306038db:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    7713306038df:	0f 94 c2             	sete   dl
    7713306038e2:	c1 e8 1f             	shr    eax,0x1f
    7713306038e5:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    7713306038ec:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    7713306038f3:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    7713306038fa:	00 00 00 00 
    7713306038fe:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330603905:	00 00 00 00 
    771330603909:	81 f9 c8 01 01 00    	cmp    ecx,0x101c8
    77133060390f:	0f 84 a7 15 00 18    	je     0x771348604ebc
    771330603915:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101c8
    77133060391c:	c8 01 01 00 
    771330603920:	0f 84 96 15 00 18    	je     0x771348604ebc
    771330603926:	58                   	pop    rax
    771330603927:	50                   	push   rax
    771330603928:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    77133060392c:	f6 c1 03             	test   cl,0x3
    77133060392f:	0f 85 e7 15 00 18    	jne    0x771348604f1c
    771330603935:	49 8b 9d 40 01 00 00 	mov    rbx,QWORD PTR [r13+0x140]
    77133060393c:	41 8b 55 04          	mov    edx,DWORD PTR [r13+0x4]
    771330603940:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330603947:	48 89 ce             	mov    rsi,rcx
    77133060394a:	48 c1 ee 0c          	shr    rsi,0xc
    77133060394e:	48 8b 04 f0          	mov    rax,QWORD PTR [rax+rsi*8]
    771330603952:	48 85 c0             	test   rax,rax
    771330603955:	0f 84 14 16 00 18    	je     0x771348604f6f
    77133060395b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330603961:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    771330603964:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ca
    77133060396b:	ca 01 01 00 
    77133060396f:	0f 84 35 16 00 18    	je     0x771348604faa
    771330603975:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ca
    77133060397c:	ca 01 01 00 
    771330603980:	0f 84 24 16 00 18    	je     0x771348604faa
    771330603986:	80 3b 00             	cmp    BYTE PTR [rbx],0x0
    771330603989:	0f 85 5c 16 00 18    	jne    0x771348604feb
    77133060398f:	58                   	pop    rax
    771330603990:	e9 0f 00 00 00       	jmp    0x7713306039a4
    771330603995:	41 80 bd 28 01 00 00 	cmp    BYTE PTR [r13+0x128],0x0
    77133060399c:	00 
    77133060399d:	74 f0                	je     0x77133060398f
    77133060399f:	e9 af 15 00 18       	jmp    0x771348604f53
    7713306039a4:	50                   	push   rax
    7713306039a5:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    7713306039a9:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306039b0:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    7713306039b4:	81 f9 cc 01 01 00    	cmp    ecx,0x101cc
    7713306039ba:	0f 84 5d 16 00 18    	je     0x77134860501d
    7713306039c0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101cc
    7713306039c7:	cc 01 01 00 
    7713306039cb:	0f 84 4c 16 00 18    	je     0x77134860501d
    7713306039d1:	58                   	pop    rax
    7713306039d2:	50                   	push   rax
    7713306039d3:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    7713306039d7:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306039de:	31 d2                	xor    edx,edx
    7713306039e0:	89 c6                	mov    esi,eax
    7713306039e2:	ff c6                	inc    esi
    7713306039e4:	0f 94 c2             	sete   dl
    7713306039e7:	41 89 75 08          	mov    DWORD PTR [r13+0x8],esi
    7713306039eb:	c1 e8 1f             	shr    eax,0x1f
    7713306039ee:	89 f7                	mov    edi,esi
    7713306039f0:	c1 ef 1f             	shr    edi,0x1f
    7713306039f3:	f7 d0                	not    eax
    7713306039f5:	21 f8                	and    eax,edi
    7713306039f7:	31 db                	xor    ebx,ebx
    7713306039f9:	85 f6                	test   esi,esi
    7713306039fb:	0f 94 c3             	sete   bl
    7713306039fe:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    771330603a05:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    771330603a0c:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    771330603a13:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    771330603a1a:	41 09 85 00 01 00 00 	or     DWORD PTR [r13+0x100],eax
    771330603a21:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    771330603a28:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    771330603a2f:	81 f9 ce 01 01 00    	cmp    ecx,0x101ce
    771330603a35:	0f 84 42 16 00 18    	je     0x77134860507d
    771330603a3b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ce
    771330603a42:	ce 01 01 00 
    771330603a46:	0f 84 31 16 00 18    	je     0x77134860507d
    771330603a4c:	58                   	pop    rax
    771330603a4d:	50                   	push   rax
    771330603a4e:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330603a52:	41 8b 4d 08          	mov    ecx,DWORD PTR [r13+0x8]
    771330603a56:	31 d2                	xor    edx,edx
    771330603a58:	31 f6                	xor    esi,esi
    771330603a5a:	31 ff                	xor    edi,edi
    771330603a5c:	31 db                	xor    ebx,ebx
    771330603a5e:	39 c8                	cmp    eax,ecx
    771330603a60:	0f 96 c2             	setbe  dl
    771330603a63:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    771330603a6a:	40 0f 94 c6          	sete   sil
    771330603a6e:	40 0f 92 c7          	setb   dil
    771330603a72:	0f 93 c3             	setae  bl
    771330603a75:	41 89 b5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],esi
    771330603a7c:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    771330603a83:	41 89 9d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ebx
    771330603a8a:	41 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ebx
    771330603a91:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d0
    771330603a98:	d0 01 01 00 
    771330603a9c:	0f 84 3b 16 00 18    	je     0x7713486050dd
    771330603aa2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d0
    771330603aa9:	d0 01 01 00 
    771330603aad:	0f 84 2a 16 00 18    	je     0x7713486050dd
    771330603ab3:	58                   	pop    rax
    771330603ab4:	50                   	push   rax
    771330603ab5:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330603ab9:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603ac0:	41 01 45 24          	add    DWORD PTR [r13+0x24],eax
    771330603ac4:	81 f9 d2 01 01 00    	cmp    ecx,0x101d2
    771330603aca:	0f 84 6d 16 00 18    	je     0x77134860513d
    771330603ad0:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d2
    771330603ad7:	d2 01 01 00 
    771330603adb:	0f 84 5c 16 00 18    	je     0x77134860513d
    771330603ae1:	58                   	pop    rax
    771330603ae2:	50                   	push   rax
    771330603ae3:	41 83 bd 14 01 00 00 	cmp    DWORD PTR [r13+0x114],0x0
    771330603aea:	00 
    771330603aeb:	74 28                	je     0x771330603b15
    771330603aed:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d4
    771330603af4:	d4 01 01 00 
    771330603af8:	0f 84 9f 16 00 18    	je     0x77134860519d
    771330603afe:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d4
    771330603b05:	d4 01 01 00 
    771330603b09:	0f 84 8e 16 00 18    	je     0x77134860519d
    771330603b0f:	58                   	pop    rax
    771330603b10:	e9 55 00 00 00       	jmp    0x771330603b6a
    771330603b15:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330603b1c:	01 
    771330603b1d:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d4
    771330603b24:	d4 01 01 00 
    771330603b28:	0f 84 b8 16 00 18    	je     0x7713486051e6
    771330603b2e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d4
    771330603b35:	d4 01 01 00 
    771330603b39:	0f 84 a7 16 00 18    	je     0x7713486051e6
    771330603b3f:	b8 d4 01 01 00       	mov    eax,0x101d4
    771330603b44:	83 c0 e6             	add    eax,0xffffffe6
    771330603b47:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330603b4e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330603b55:	02 00 00 00 
    771330603b59:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x16
    771330603b60:	16 00 00 00 
    771330603b64:	58                   	pop    rax
    771330603b65:	e9 92 03 00 00       	jmp    0x771330603efc
    771330603b6a:	50                   	push   rax
    771330603b6b:	41 c7 45 04 ff 1f 00 	mov    DWORD PTR [r13+0x4],0x1fff
    771330603b72:	00 
    771330603b73:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101d6
    771330603b7a:	d6 01 01 00 
    771330603b7e:	0f 84 9e 16 00 18    	je     0x771348605222
    771330603b84:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101d6
    771330603b8b:	d6 01 01 00 
    771330603b8f:	0f 84 8d 16 00 18    	je     0x771348605222
    771330603b95:	58                   	pop    rax
    771330603b96:	50                   	push   rax
    771330603b97:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330603b9b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603ba2:	31 d2                	xor    edx,edx
    771330603ba4:	89 c6                	mov    esi,eax
    771330603ba6:	83 c6 ff             	add    esi,0xffffffff
    771330603ba9:	0f 92 c2             	setb   dl
    771330603bac:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    771330603bb0:	c1 e8 1f             	shr    eax,0x1f
    771330603bb3:	89 f7                	mov    edi,esi
    771330603bb5:	c1 ef 1f             	shr    edi,0x1f
    771330603bb8:	89 fb                	mov    ebx,edi
    771330603bba:	f7 d3                	not    ebx
    771330603bbc:	21 c3                	and    ebx,eax
    771330603bbe:	31 c0                	xor    eax,eax
    771330603bc0:	85 f6                	test   esi,esi
    771330603bc2:	0f 94 c0             	sete   al
    771330603bc5:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    771330603bcc:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    771330603bd3:	41 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebx
    771330603bda:	41 89 9d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebx
    771330603be1:	41 09 9d 00 01 00 00 	or     DWORD PTR [r13+0x100],ebx
    771330603be8:	41 89 95 ec 00 00 00 	mov    DWORD PTR [r13+0xec],edx
    771330603bef:	41 89 95 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],edx
    771330603bf6:	81 f9 da 01 01 00    	cmp    ecx,0x101da
    771330603bfc:	0f 84 80 16 00 18    	je     0x771348605282
    771330603c02:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101da
    771330603c09:	da 01 01 00 
    771330603c0d:	0f 84 6f 16 00 18    	je     0x771348605282
    771330603c13:	58                   	pop    rax
    771330603c14:	50                   	push   rax
    771330603c15:	41 8b 45 04          	mov    eax,DWORD PTR [r13+0x4]
    771330603c19:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603c20:	31 d2                	xor    edx,edx
    771330603c22:	41 23 45 00          	and    eax,DWORD PTR [r13+0x0]
    771330603c26:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330603c2a:	0f 94 c2             	sete   dl
    771330603c2d:	c1 e8 1f             	shr    eax,0x1f
    771330603c30:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330603c37:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330603c3e:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    771330603c45:	00 00 00 00 
    771330603c49:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330603c50:	00 00 00 00 
    771330603c54:	81 f9 dc 01 01 00    	cmp    ecx,0x101dc
    771330603c5a:	0f 84 82 16 00 18    	je     0x7713486052e2
    771330603c60:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101dc
    771330603c67:	dc 01 01 00 
    771330603c6b:	0f 84 71 16 00 18    	je     0x7713486052e2
    771330603c71:	58                   	pop    rax
    771330603c72:	50                   	push   rax
    771330603c73:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330603c77:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603c7e:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330603c82:	81 f9 de 01 01 00    	cmp    ecx,0x101de
    771330603c88:	0f 84 b4 16 00 18    	je     0x771348605342
    771330603c8e:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101de
    771330603c95:	de 01 01 00 
    771330603c99:	0f 84 a3 16 00 18    	je     0x771348605342
    771330603c9f:	58                   	pop    rax
    771330603ca0:	50                   	push   rax
    771330603ca1:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    771330603ca5:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603cac:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    771330603cb0:	81 f9 e0 01 01 00    	cmp    ecx,0x101e0
    771330603cb6:	0f 84 e6 16 00 18    	je     0x7713486053a2
    771330603cbc:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e0
    771330603cc3:	e0 01 01 00 
    771330603cc7:	0f 84 d5 16 00 18    	je     0x7713486053a2
    771330603ccd:	58                   	pop    rax
    771330603cce:	50                   	push   rax
    771330603ccf:	41 8b 5d 3c          	mov    ebx,DWORD PTR [r13+0x3c]
    771330603cd3:	f6 c3 03             	test   bl,0x3
    771330603cd6:	0f 85 26 17 00 18    	jne    0x771348605402
    771330603cdc:	49 8b ad 38 01 00 00 	mov    rbp,QWORD PTR [r13+0x138]
    771330603ce3:	48 89 d8             	mov    rax,rbx
    771330603ce6:	48 c1 e8 0c          	shr    rax,0xc
    771330603cea:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330603cef:	48 85 c0             	test   rax,rax
    771330603cf2:	0f 84 5c 17 00 18    	je     0x771348605454
    771330603cf8:	89 d9                	mov    ecx,ebx
    771330603cfa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330603d00:	44 8b 3c 08          	mov    r15d,DWORD PTR [rax+rcx*1]
    771330603d04:	89 de                	mov    esi,ebx
    771330603d06:	83 c6 04             	add    esi,0x4
    771330603d09:	89 f0                	mov    eax,esi
    771330603d0b:	c1 e8 0c             	shr    eax,0xc
    771330603d0e:	48 8b 44 c5 00       	mov    rax,QWORD PTR [rbp+rax*8+0x0]
    771330603d13:	48 85 c0             	test   rax,rax
    771330603d16:	0f 84 75 17 00 18    	je     0x771348605491
    771330603d1c:	81 e6 ff 0f 00 00    	and    esi,0xfff
    771330603d22:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    771330603d25:	8d 4b 08             	lea    ecx,[rbx+0x8]
    771330603d28:	45 89 7d 3c          	mov    DWORD PTR [r13+0x3c],r15d
    771330603d2c:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    771330603d33:	41 89 4d 38          	mov    DWORD PTR [r13+0x38],ecx
    771330603d37:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101e2
    771330603d3e:	e2 01 01 00 
    771330603d42:	0f 84 85 17 00 18    	je     0x7713486054cd
    771330603d48:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e2
    771330603d4f:	e2 01 01 00 
    771330603d53:	0f 84 74 17 00 18    	je     0x7713486054cd
    771330603d59:	58                   	pop    rax
    771330603d5a:	50                   	push   rax
    771330603d5b:	41 8b 5d 38          	mov    ebx,DWORD PTR [r13+0x38]
    771330603d5f:	f6 c3 03             	test   bl,0x3
    771330603d62:	0f 85 ae 17 00 18    	jne    0x771348605516
    771330603d68:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330603d6f:	48 89 d9             	mov    rcx,rbx
    771330603d72:	48 c1 e9 0c          	shr    rcx,0xc
    771330603d76:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    771330603d7a:	48 85 c0             	test   rax,rax
    771330603d7d:	0f 84 e5 17 00 18    	je     0x771348605568
    771330603d83:	89 d9                	mov    ecx,ebx
    771330603d85:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330603d8b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330603d8e:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    771330603d92:	83 c3 04             	add    ebx,0x4
    771330603d95:	41 89 5d 38          	mov    DWORD PTR [r13+0x38],ebx
    771330603d99:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101e6
    771330603da0:	e6 01 01 00 
    771330603da4:	0f 84 f9 17 00 18    	je     0x7713486055a3
    771330603daa:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e6
    771330603db1:	e6 01 01 00 
    771330603db5:	0f 84 e8 17 00 18    	je     0x7713486055a3
    771330603dbb:	58                   	pop    rax
    771330603dbc:	50                   	push   rax
    771330603dbd:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330603dc1:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603dc8:	c1 e0 02             	shl    eax,0x2
    771330603dcb:	41 01 45 20          	add    DWORD PTR [r13+0x20],eax
    771330603dcf:	81 f9 e8 01 01 00    	cmp    ecx,0x101e8
    771330603dd5:	0f 84 11 18 00 18    	je     0x7713486055ec
    771330603ddb:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101e8
    771330603de2:	e8 01 01 00 
    771330603de6:	0f 84 00 18 00 18    	je     0x7713486055ec
    771330603dec:	58                   	pop    rax
    771330603ded:	50                   	push   rax
    771330603dee:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    771330603df2:	f6 c1 03             	test   cl,0x3
    771330603df5:	0f 85 51 18 00 18    	jne    0x77134860564c
    771330603dfb:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330603e02:	48 89 ca             	mov    rdx,rcx
    771330603e05:	48 c1 ea 0c          	shr    rdx,0xc
    771330603e09:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330603e0d:	48 85 c0             	test   rax,rax
    771330603e10:	0f 84 86 18 00 18    	je     0x77134860569c
    771330603e16:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330603e1c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330603e1f:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330603e23:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ea
    771330603e2a:	ea 01 01 00 
    771330603e2e:	0f 84 a3 18 00 18    	je     0x7713486056d7
    771330603e34:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ea
    771330603e3b:	ea 01 01 00 
    771330603e3f:	0f 84 92 18 00 18    	je     0x7713486056d7
    771330603e45:	58                   	pop    rax
    771330603e46:	50                   	push   rax
    771330603e47:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    771330603e4b:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330603e52:	31 d2                	xor    edx,edx
    771330603e54:	41 33 45 04          	xor    eax,DWORD PTR [r13+0x4]
    771330603e58:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    771330603e5c:	0f 94 c2             	sete   dl
    771330603e5f:	c1 e8 1f             	shr    eax,0x1f
    771330603e62:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    771330603e69:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    771330603e70:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    771330603e77:	00 00 00 00 
    771330603e7b:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    771330603e82:	00 00 00 00 
    771330603e86:	81 f9 ec 01 01 00    	cmp    ecx,0x101ec
    771330603e8c:	0f 84 8e 18 00 18    	je     0x771348605720
    771330603e92:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ec
    771330603e99:	ec 01 01 00 
    771330603e9d:	0f 84 7d 18 00 18    	je     0x771348605720
    771330603ea3:	58                   	pop    rax
    771330603ea4:	50                   	push   rax
    771330603ea5:	41 8b 85 a8 00 00 00 	mov    eax,DWORD PTR [r13+0xa8]
    771330603eac:	a8 01                	test   al,0x1
    771330603eae:	0f 85 cc 18 00 18    	jne    0x771348605780
    771330603eb4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330603ebb:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330603ec2:	01 
    771330603ec3:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x101ee
    771330603eca:	ee 01 01 00 
    771330603ece:	0f 84 e2 18 00 18    	je     0x7713486057b6
    771330603ed4:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x101ee
    771330603edb:	ee 01 01 00 
    771330603edf:	0f 84 d1 18 00 18    	je     0x7713486057b6
    771330603ee5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    771330603eec:	02 00 00 00 
    771330603ef0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x21
    771330603ef7:	21 00 00 00 
    771330603efb:	58                   	pop    rax
    771330603efc:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330603f03:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    771330603f0a:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330603f11:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    771330603f18:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330603f1f:	39 f1                	cmp    ecx,esi
    771330603f21:	0f 83 bc 18 00 18    	jae    0x7713486057e3
    771330603f27:	81 fa a0 01 01 00    	cmp    edx,0x101a0
    771330603f2d:	75 14                	jne    0x771330603f43
    771330603f2f:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330603f36:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330603f3d:	00 
    771330603f3e:	e9 5d f4 ff ff       	jmp    0x7713306033a0
    771330603f43:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    771330603f4a:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330603f50:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330603f53:	0f 85 8a 18 00 18    	jne    0x7713486057e3
    771330603f59:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330603f60:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330603f67:	00 
    771330603f68:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330603f6d:	ff e0                	jmp    rax
