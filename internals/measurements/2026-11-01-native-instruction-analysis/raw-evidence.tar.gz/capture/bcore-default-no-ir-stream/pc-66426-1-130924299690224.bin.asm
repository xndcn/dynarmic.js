
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66426-1-130924299690224.bin:     file format binary


Disassembly of section .data:

00007713306020f0 <.data>:
    7713306020f0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306020f7:	8b 88 10 00 10 00    	mov    ecx,DWORD PTR [rax+0x100010]
    7713306020fd:	ff c1                	inc    ecx
    7713306020ff:	89 88 10 00 10 00    	mov    DWORD PTR [rax+0x100010],ecx
    771330602105:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    77133060210b:	0f 84 4f 0d 00 18    	je     0x771348602e60
    771330602111:	50                   	push   rax
    771330602112:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    771330602117:	b9 00 00 01 00       	mov    ecx,0x10000
    77133060211c:	09 c1                	or     ecx,eax
    77133060211e:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    771330602122:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1037a
    771330602129:	7a 03 01 00 
    77133060212d:	0f 84 59 0d 00 18    	je     0x771348602e8c
    771330602133:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1037a
    77133060213a:	7a 03 01 00 
    77133060213e:	0f 84 48 0d 00 18    	je     0x771348602e8c
    771330602144:	58                   	pop    rax
    771330602145:	50                   	push   rax
    771330602146:	41 0f b7 45 04       	movzx  eax,WORD PTR [r13+0x4]
    77133060214b:	b9 00 00 19 00       	mov    ecx,0x190000
    771330602150:	09 c1                	or     ecx,eax
    771330602152:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    771330602156:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1037e
    77133060215d:	7e 03 01 00 
    771330602161:	0f 84 85 0d 00 18    	je     0x771348602eec
    771330602167:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1037e
    77133060216e:	7e 03 01 00 
    771330602172:	0f 84 74 0d 00 18    	je     0x771348602eec
    771330602178:	58                   	pop    rax
    771330602179:	50                   	push   rax
    77133060217a:	41 0f b7 45 00       	movzx  eax,WORD PTR [r13+0x0]
    77133060217f:	b9 00 00 6e 3c       	mov    ecx,0x3c6e0000
    771330602184:	09 c1                	or     ecx,eax
    771330602186:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    77133060218a:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10382
    771330602191:	82 03 01 00 
    771330602195:	0f 84 b1 0d 00 18    	je     0x771348602f4c
    77133060219b:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10382
    7713306021a2:	82 03 01 00 
    7713306021a6:	0f 84 a0 0d 00 18    	je     0x771348602f4c
    7713306021ac:	58                   	pop    rax
    7713306021ad:	50                   	push   rax
    7713306021ae:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    7713306021b3:	c1 e0 10             	shl    eax,0x10
    7713306021b6:	b9 fc 12 00 00       	mov    ecx,0x12fc
    7713306021bb:	09 c1                	or     ecx,eax
    7713306021bd:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    7713306021c1:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10386
    7713306021c8:	86 03 01 00 
    7713306021cc:	0f 84 da 0d 00 18    	je     0x771348602fac
    7713306021d2:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10386
    7713306021d9:	86 03 01 00 
    7713306021dd:	0f 84 c9 0d 00 18    	je     0x771348602fac
    7713306021e3:	58                   	pop    rax
    7713306021e4:	50                   	push   rax
    7713306021e5:	41 0f b7 45 06       	movzx  eax,WORD PTR [r13+0x6]
    7713306021ea:	c1 e0 10             	shl    eax,0x10
    7713306021ed:	b9 0d 66 00 00       	mov    ecx,0x660d
    7713306021f2:	09 c1                	or     ecx,eax
    7713306021f4:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    7713306021f8:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1038a
    7713306021ff:	8a 03 01 00 
    771330602203:	0f 84 03 0e 00 18    	je     0x77134860300c
    771330602209:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1038a
    771330602210:	8a 03 01 00 
    771330602214:	0f 84 f2 0d 00 18    	je     0x77134860300c
    77133060221a:	58                   	pop    rax
    77133060221b:	50                   	push   rax
    77133060221c:	41 0f b7 45 02       	movzx  eax,WORD PTR [r13+0x2]
    771330602221:	c1 e0 10             	shl    eax,0x10
    771330602224:	b9 5f f3 00 00       	mov    ecx,0xf35f
    771330602229:	09 c1                	or     ecx,eax
    77133060222b:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    77133060222f:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1038e
    771330602236:	8e 03 01 00 
    77133060223a:	0f 84 2c 0e 00 18    	je     0x77134860306c
    771330602240:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1038e
    771330602247:	8e 03 01 00 
    77133060224b:	0f 84 1b 0e 00 18    	je     0x77134860306c
    771330602251:	58                   	pop    rax
    771330602252:	50                   	push   rax
    771330602253:	41 c7 45 28 00 20 00 	mov    DWORD PTR [r13+0x28],0x2000
    77133060225a:	00 
    77133060225b:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10392
    771330602262:	92 03 01 00 
    771330602266:	0f 84 60 0e 00 18    	je     0x7713486030cc
    77133060226c:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10392
    771330602273:	92 03 01 00 
    771330602277:	0f 84 4f 0e 00 18    	je     0x7713486030cc
    77133060227d:	58                   	pop    rax
    77133060227e:	50                   	push   rax
    77133060227f:	41 c7 85 94 00 00 00 	mov    DWORD PTR [r13+0x94],0x1039a
    771330602286:	9a 03 01 00 
    77133060228a:	41 c7 85 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],0x1039e
    771330602291:	9e 03 01 00 
    771330602295:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330602299:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    7713306022a0:	41 89 85 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],eax
    7713306022a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    7713306022ae:	01 
    7713306022af:	81 f9 96 03 01 00    	cmp    ecx,0x10396
    7713306022b5:	0f 84 71 0e 00 18    	je     0x77134860312c
    7713306022bb:	b8 9e 03 01 00       	mov    eax,0x1039e
    7713306022c0:	3d 96 03 01 00       	cmp    eax,0x10396
    7713306022c5:	0f 84 61 0e 00 18    	je     0x77134860312c
    7713306022cb:	b8 96 03 01 00       	mov    eax,0x10396
    7713306022d0:	83 c0 04             	add    eax,0x4
    7713306022d3:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    7713306022da:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    7713306022e1:	04 00 00 00 
    7713306022e5:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    7713306022ec:	08 00 00 00 
    7713306022f0:	58                   	pop    rax
    7713306022f1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7713306022f8:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    7713306022ff:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330602306:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060230d:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330602314:	39 f1                	cmp    ecx,esi
    771330602316:	0f 83 4c 0e 00 18    	jae    0x771348603168
    77133060231c:	81 fa 7a 03 01 00    	cmp    edx,0x1037a
    771330602322:	75 14                	jne    0x771330602338
    771330602324:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    77133060232b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330602332:	00 
    771330602333:	e9 b8 fd ff ff       	jmp    0x7713306020f0
    771330602338:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    77133060233f:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330602345:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330602348:	0f 85 1a 0e 00 18    	jne    0x771348603168
    77133060234e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330602355:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060235c:	00 
    77133060235d:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330602362:	ff e0                	jmp    rax
