
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66626-1-130924299693744.bin:     file format binary


Disassembly of section .data:

0000771330602eb0 <.data>:
    771330602eb0:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330602eb7:	8b 88 24 00 10 00    	mov    ecx,DWORD PTR [rax+0x100024]
    771330602ebd:	ff c1                	inc    ecx
    771330602ebf:	89 88 24 00 10 00    	mov    DWORD PTR [rax+0x100024],ecx
    771330602ec5:	81 f9 30 75 00 00    	cmp    ecx,0x7530
    771330602ecb:	0f 84 bf 10 00 18    	je     0x771348603f90
    771330602ed1:	50                   	push   rax
    771330602ed2:	41 0f b7 45 24       	movzx  eax,WORD PTR [r13+0x24]
    771330602ed7:	b9 00 00 01 00       	mov    ecx,0x10000
    771330602edc:	09 c1                	or     ecx,eax
    771330602ede:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    771330602ee2:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10442
    771330602ee9:	42 04 01 00 
    771330602eed:	0f 84 c9 10 00 18    	je     0x771348603fbc
    771330602ef3:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10442
    771330602efa:	42 04 01 00 
    771330602efe:	0f 84 b8 10 00 18    	je     0x771348603fbc
    771330602f04:	58                   	pop    rax
    771330602f05:	50                   	push   rax
    771330602f06:	41 0f b7 45 26       	movzx  eax,WORD PTR [r13+0x26]
    771330602f0b:	c1 e0 10             	shl    eax,0x10
    771330602f0e:	b9 9c 11 00 00       	mov    ecx,0x119c
    771330602f13:	09 c1                	or     ecx,eax
    771330602f15:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    771330602f19:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x10446
    771330602f20:	46 04 01 00 
    771330602f24:	0f 84 f2 10 00 18    	je     0x77134860401c
    771330602f2a:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x10446
    771330602f31:	46 04 01 00 
    771330602f35:	0f 84 e1 10 00 18    	je     0x77134860401c
    771330602f3b:	58                   	pop    rax
    771330602f3c:	50                   	push   rax
    771330602f3d:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330602f41:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    771330602f48:	c1 e0 02             	shl    eax,0x2
    771330602f4b:	41 03 45 24          	add    eax,DWORD PTR [r13+0x24]
    771330602f4f:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330602f53:	81 f9 4a 04 01 00    	cmp    ecx,0x1044a
    771330602f59:	0f 84 1d 11 00 18    	je     0x77134860407c
    771330602f5f:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044a
    771330602f66:	4a 04 01 00 
    771330602f6a:	0f 84 0c 11 00 18    	je     0x77134860407c
    771330602f70:	58                   	pop    rax
    771330602f71:	50                   	push   rax
    771330602f72:	41 8b 4d 28          	mov    ecx,DWORD PTR [r13+0x28]
    771330602f76:	f6 c1 03             	test   cl,0x3
    771330602f79:	0f 85 5d 11 00 18    	jne    0x7713486040dc
    771330602f7f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    771330602f86:	48 89 ca             	mov    rdx,rcx
    771330602f89:	48 c1 ea 0c          	shr    rdx,0xc
    771330602f8d:	48 8b 04 d0          	mov    rax,QWORD PTR [rax+rdx*8]
    771330602f91:	48 85 c0             	test   rax,rax
    771330602f94:	0f 84 92 11 00 18    	je     0x77134860412c
    771330602f9a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    771330602fa0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    771330602fa3:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    771330602fa7:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044c
    771330602fae:	4c 04 01 00 
    771330602fb2:	0f 84 af 11 00 18    	je     0x771348604167
    771330602fb8:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044c
    771330602fbf:	4c 04 01 00 
    771330602fc3:	0f 84 9e 11 00 18    	je     0x771348604167
    771330602fc9:	58                   	pop    rax
    771330602fca:	50                   	push   rax
    771330602fcb:	41 8b 45 28          	mov    eax,DWORD PTR [r13+0x28]
    771330602fcf:	a8 01                	test   al,0x1
    771330602fd1:	0f 85 d9 11 00 18    	jne    0x7713486041b0
    771330602fd7:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    771330602fde:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    771330602fe5:	01 
    771330602fe6:	41 81 bd a0 00 00 00 	cmp    DWORD PTR [r13+0xa0],0x1044e
    771330602fed:	4e 04 01 00 
    771330602ff1:	0f 84 ef 11 00 18    	je     0x7713486041e6
    771330602ff7:	41 81 bd a4 00 00 00 	cmp    DWORD PTR [r13+0xa4],0x1044e
    771330602ffe:	4e 04 01 00 
    771330603002:	0f 84 de 11 00 18    	je     0x7713486041e6
    771330603008:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    77133060300f:	02 00 00 00 
    771330603013:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    77133060301a:	05 00 00 00 
    77133060301e:	58                   	pop    rax
    77133060301f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    771330603026:	41 8b 95 bc 00 00 00 	mov    edx,DWORD PTR [r13+0xbc]
    77133060302d:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    771330603034:	41 03 8d 34 01 00 00 	add    ecx,DWORD PTR [r13+0x134]
    77133060303b:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    771330603042:	39 f1                	cmp    ecx,esi
    771330603044:	0f 83 c9 11 00 18    	jae    0x771348604213
    77133060304a:	81 fa 42 04 01 00    	cmp    edx,0x10442
    771330603050:	75 14                	jne    0x771330603066
    771330603052:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330603059:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    771330603060:	00 
    771330603061:	e9 4a fe ff ff       	jmp    0x771330602eb0
    771330603066:	8d 34 d5 00 00 00 00 	lea    esi,[rdx*8+0x0]
    77133060306d:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    771330603073:	39 14 30             	cmp    DWORD PTR [rax+rsi*1],edx
    771330603076:	0f 85 97 11 00 18    	jne    0x771348604213
    77133060307c:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    771330603083:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    77133060308a:	00 
    77133060308b:	48 8b 44 30 08       	mov    rax,QWORD PTR [rax+rsi*1+0x8]
    771330603090:	ff e0                	jmp    rax
