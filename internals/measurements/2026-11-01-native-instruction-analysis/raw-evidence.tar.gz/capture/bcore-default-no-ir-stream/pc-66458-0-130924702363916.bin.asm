
build-native-instruction-analysis/capture/bcore-default-no-ir-stream/pc-66458-0-130924702363916.bin:     file format binary


Disassembly of section .data:

000077134860710c <.data>:
    77134860710c:	c7 07 00 00 00 00    	mov    DWORD PTR [rdi],0x0
    771348607112:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    771348607116:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    77134860711a:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    771348607121:	00 00 00 
    771348607124:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    77134860712b:	03 01 00 
    77134860712e:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    771348607132:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    771348607138:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    77134860713e:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    771348607145:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    77134860714c:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    771348607152:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    771348607158:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    77134860715f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    771348607166:	00 00 00 
    771348607169:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    771348607170:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    771348607177:	00 00 00 
    77134860717a:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    771348607181:	48 83 c4 68          	add    rsp,0x68
    771348607185:	c2 08 00             	ret    0x8
    771348607188:	c6 87 65 01 00 00 01 	mov    BYTE PTR [rdi+0x165],0x1
    77134860718f:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    771348607196:	48 83 c4 68          	add    rsp,0x68
    77134860719a:	c2 08 00             	ret    0x8
    77134860719d:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    7713486071a1:	89 07                	mov    DWORD PTR [rdi],eax
    7713486071a3:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    7713486071a7:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    7713486071ab:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    7713486071b2:	00 00 00 
    7713486071b5:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x103a0
    7713486071bc:	03 01 00 
    7713486071bf:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    7713486071c3:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    7713486071c9:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    7713486071cf:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    7713486071d6:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    7713486071dd:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    7713486071e3:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    7713486071e9:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    7713486071f0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7713486071f7:	00 00 00 
    7713486071fa:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    771348607201:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    771348607208:	00 00 00 
    77134860720b:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    771348607212:	48 b8 10 e6 8f a8 39 	movabs rax,0x6039a88fe610
    771348607219:	60 00 00 
    77134860721c:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    771348607221:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    771348607226:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    77134860722b:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    771348607230:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    771348607235:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    77134860723a:	ff d0                	call   rax
    77134860723c:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    771348607241:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    771348607246:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    77134860724b:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    771348607250:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    771348607255:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    77134860725c:	40 84 f6             	test   sil,sil
    77134860725f:	0f 84 ef ef ff e7    	je     0x771330606254
    771348607265:	e9 5b f2 ff e7       	jmp    0x7713306064c5
