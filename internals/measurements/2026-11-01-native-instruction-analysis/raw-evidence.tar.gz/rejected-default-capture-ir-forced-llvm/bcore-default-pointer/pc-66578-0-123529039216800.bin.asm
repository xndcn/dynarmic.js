
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66578-0-123529039216800.bin:     file format binary


Disassembly of section .data:

00007059588080a0 <.data>:
    7059588080a0:	48 81 ec b8 00 00 00 	sub    rsp,0xb8
    7059588080a7:	4c 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r14
    7059588080ae:	00 
    7059588080af:	4c 89 ac 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r13
    7059588080b6:	00 
    7059588080b7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7059588080be:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    7059588080c5:	00 
    7059588080c6:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    7059588080cd:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    7059588080d4:	00 
    7059588080d5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7059588080dc:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    7059588080e3:	00 
    7059588080e4:	48 8b 94 24 98 00 00 	mov    rdx,QWORD PTR [rsp+0x98]
    7059588080eb:	00 
    7059588080ec:	8b 8a a0 00 00 00    	mov    ecx,DWORD PTR [rdx+0xa0]
    7059588080f2:	83 f9 00             	cmp    ecx,0x0
    7059588080f5:	0f 94 c0             	sete   al
    7059588080f8:	81 e9 12 04 01 00    	sub    ecx,0x10412
    7059588080fe:	83 f9 12             	cmp    ecx,0x12
    705958808101:	0f 97 c1             	seta   cl
    705958808104:	08 c8                	or     al,cl
    705958808106:	24 01                	and    al,0x1
    705958808108:	81 ba a4 00 00 00 20 	cmp    DWORD PTR [rdx+0xa4],0x10420
    70595880810f:	04 01 00 
    705958808112:	0f 94 c1             	sete   cl
    705958808115:	81 ba 94 00 00 00 12 	cmp    DWORD PTR [rdx+0x94],0x10412
    70595880811c:	04 01 00 
    70595880811f:	0f 94 c2             	sete   dl
    705958808122:	20 d1                	and    cl,dl
    705958808124:	20 c8                	and    al,cl
    705958808126:	a8 01                	test   al,0x1
    705958808128:	75 05                	jne    0x70595880812f
    70595880812a:	e9 17 07 00 00       	jmp    0x705958808846
    70595880812f:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808136:	00 
    705958808137:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880813e:	48 89 c8             	mov    rax,rcx
    705958808141:	48 05 00 00 10 00    	add    rax,0x100000
    705958808147:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    70595880814e:	00 
    70595880814f:	8b 81 1c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10001c]
    705958808155:	83 c0 01             	add    eax,0x1
    705958808158:	89 81 1c 00 10 00    	mov    DWORD PTR [rcx+0x10001c],eax
    70595880815e:	3d 30 75 00 00       	cmp    eax,0x7530
    705958808163:	75 4c                	jne    0x7059588081b1
    705958808165:	48 8b 8c 24 88 00 00 	mov    rcx,QWORD PTR [rsp+0x88]
    70595880816c:	00 
    70595880816d:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958808173:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    70595880817a:	89 c2                	mov    edx,eax
    70595880817c:	83 c2 01             	add    edx,0x1
    70595880817f:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958808185:	3d 00 01 00 00       	cmp    eax,0x100
    70595880818a:	73 23                	jae    0x7059588081af
    70595880818c:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    705958808193:	00 
    705958808194:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880819b:	89 c9                	mov    ecx,ecx
    70595880819d:	48 c1 e1 02          	shl    rcx,0x2
    7059588081a1:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    7059588081a8:	c7 04 08 07 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x7
    7059588081af:	eb 00                	jmp    0x7059588081b1
    7059588081b1:	eb 00                	jmp    0x7059588081b3
    7059588081b3:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588081ba:	00 
    7059588081bb:	8b 08                	mov    ecx,DWORD PTR [rax]
    7059588081bd:	89 ca                	mov    edx,ecx
    7059588081bf:	83 c2 01             	add    edx,0x1
    7059588081c2:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    7059588081c9:	89 10                	mov    DWORD PTR [rax],edx
    7059588081cb:	89 ce                	mov    esi,ecx
    7059588081cd:	c1 ee 1f             	shr    esi,0x1f
    7059588081d0:	89 d3                	mov    ebx,edx
    7059588081d2:	c1 eb 1f             	shr    ebx,0x1f
    7059588081d5:	89 df                	mov    edi,ebx
    7059588081d7:	83 f7 00             	xor    edi,0x0
    7059588081da:	31 de                	xor    esi,ebx
    7059588081dc:	21 fe                	and    esi,edi
    7059588081de:	83 f1 ff             	xor    ecx,0xffffffff
    7059588081e1:	83 f9 01             	cmp    ecx,0x1
    7059588081e4:	0f 92 c1             	setb   cl
    7059588081e7:	80 e1 01             	and    cl,0x1
    7059588081ea:	0f b6 c9             	movzx  ecx,cl
    7059588081ed:	83 fa 00             	cmp    edx,0x0
    7059588081f0:	0f 94 c3             	sete   bl
    7059588081f3:	80 e3 01             	and    bl,0x1
    7059588081f6:	0f b6 fb             	movzx  edi,bl
    7059588081f9:	c1 ea 1f             	shr    edx,0x1f
    7059588081fc:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    705958808202:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958808208:	89 f2                	mov    edx,esi
    70595880820a:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    705958808210:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    705958808216:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    70595880821c:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    705958808222:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958808228:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880822e:	eb 00                	jmp    0x705958808230
    705958808230:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808237:	00 
    705958808238:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    70595880823f:	23 48 08             	and    ecx,DWORD PTR [rax+0x8]
    705958808242:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    705958808246:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    705958808249:	83 f9 00             	cmp    ecx,0x0
    70595880824c:	0f 94 c2             	sete   dl
    70595880824f:	80 e2 01             	and    dl,0x1
    705958808252:	0f b6 d2             	movzx  edx,dl
    705958808255:	c1 e9 1f             	shr    ecx,0x1f
    705958808258:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880825e:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    705958808264:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880826b:	00 00 00 
    70595880826e:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    705958808275:	00 00 00 
    705958808278:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880827f:	00 00 00 
    705958808282:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    705958808289:	00 00 00 
    70595880828c:	eb 00                	jmp    0x70595880828e
    70595880828e:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808295:	00 
    705958808296:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    70595880829a:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    70595880829d:	eb 00                	jmp    0x70595880829f
    70595880829f:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588082a6:	00 
    7059588082a7:	8b 40 34             	mov    eax,DWORD PTR [rax+0x34]
    7059588082aa:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    7059588082ae:	83 e0 03             	and    eax,0x3
    7059588082b1:	83 f8 00             	cmp    eax,0x0
    7059588082b4:	74 71                	je     0x705958808327
    7059588082b6:	48 8b bc 24 98 00 00 	mov    rdi,QWORD PTR [rsp+0x98]
    7059588082bd:	00 
    7059588082be:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    7059588082c2:	48 8b b4 24 90 00 00 	mov    rsi,QWORD PTR [rsp+0x90]
    7059588082c9:	00 
    7059588082ca:	c7 87 bc 00 00 00 18 	mov    DWORD PTR [rdi+0xbc],0x10418
    7059588082d1:	04 01 00 
    7059588082d4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588082db:	00 00 00 
    7059588082de:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    7059588082e5:	00 00 00 
    7059588082e8:	31 c0                	xor    eax,eax
    7059588082ea:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588082f1:	63 00 00 
    7059588082f4:	ba 18 04 01 00       	mov    edx,0x10418
    7059588082f9:	45 31 c0             	xor    r8d,r8d
    7059588082fc:	ff d0                	call   rax
    7059588082fe:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808305:	00 
    705958808306:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880830c:	b9 04 00 00 00       	mov    ecx,0x4
    705958808311:	b8 02 00 00 00       	mov    eax,0x2
    705958808316:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    70595880831a:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    70595880831e:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958808322:	e9 c0 05 00 00       	jmp    0x7059588088e7
    705958808327:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880832e:	00 
    70595880832f:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    705958808333:	c1 e9 0c             	shr    ecx,0xc
    705958808336:	89 c9                	mov    ecx,ecx
    705958808338:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880833c:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    705958808341:	48 83 f8 00          	cmp    rax,0x0
    705958808345:	74 1a                	je     0x705958808361
    705958808347:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595880834c:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    705958808350:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958808356:	89 c9                	mov    ecx,ecx
    705958808358:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880835b:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880835f:	eb 57                	jmp    0x7059588083b8
    705958808361:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808368:	00 
    705958808369:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    70595880836d:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    705958808374:	00 
    705958808375:	c7 80 bc 00 00 00 18 	mov    DWORD PTR [rax+0xbc],0x10418
    70595880837c:	04 01 00 
    70595880837f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958808386:	00 00 00 
    705958808389:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    705958808390:	00 00 00 
    705958808393:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880839a:	63 00 00 
    70595880839d:	ff d0                	call   rax
    70595880839f:	89 c1                	mov    ecx,eax
    7059588083a1:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588083a8:	00 
    7059588083a9:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    7059588083ad:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588083b4:	75 21                	jne    0x7059588083d7
    7059588083b6:	eb 48                	jmp    0x705958808400
    7059588083b8:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588083bf:	00 
    7059588083c0:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    7059588083c4:	8b 54 24 5c          	mov    edx,DWORD PTR [rsp+0x5c]
    7059588083c8:	89 54 24 54          	mov    DWORD PTR [rsp+0x54],edx
    7059588083cc:	89 50 24             	mov    DWORD PTR [rax+0x24],edx
    7059588083cf:	83 c1 04             	add    ecx,0x4
    7059588083d2:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    7059588083d5:	eb 33                	jmp    0x70595880840a
    7059588083d7:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588083de:	00 
    7059588083df:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588083e5:	b9 04 00 00 00       	mov    ecx,0x4
    7059588083ea:	b8 02 00 00 00       	mov    eax,0x2
    7059588083ef:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    7059588083f3:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588083f7:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588083fb:	e9 e7 04 00 00       	jmp    0x7059588088e7
    705958808400:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    705958808404:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    705958808408:	eb ae                	jmp    0x7059588083b8
    70595880840a:	eb 00                	jmp    0x70595880840c
    70595880840c:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808413:	00 
    705958808414:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958808418:	c1 e1 02             	shl    ecx,0x2
    70595880841b:	03 48 20             	add    ecx,DWORD PTR [rax+0x20]
    70595880841e:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    705958808422:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    705958808425:	eb 00                	jmp    0x705958808427
    705958808427:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880842e:	00 
    70595880842f:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    705958808433:	c1 e1 02             	shl    ecx,0x2
    705958808436:	03 48 2c             	add    ecx,DWORD PTR [rax+0x2c]
    705958808439:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    70595880843d:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    705958808440:	eb 00                	jmp    0x705958808442
    705958808442:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    705958808446:	83 e0 03             	and    eax,0x3
    705958808449:	83 f8 00             	cmp    eax,0x0
    70595880844c:	74 71                	je     0x7059588084bf
    70595880844e:	48 8b bc 24 98 00 00 	mov    rdi,QWORD PTR [rsp+0x98]
    705958808455:	00 
    705958808456:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    70595880845a:	48 8b b4 24 90 00 00 	mov    rsi,QWORD PTR [rsp+0x90]
    705958808461:	00 
    705958808462:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1041e
    705958808469:	04 01 00 
    70595880846c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958808473:	00 00 00 
    705958808476:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    70595880847d:	00 00 00 
    705958808480:	31 c0                	xor    eax,eax
    705958808482:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958808489:	63 00 00 
    70595880848c:	ba 1e 04 01 00       	mov    edx,0x1041e
    705958808491:	45 31 c0             	xor    r8d,r8d
    705958808494:	ff d0                	call   rax
    705958808496:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880849d:	00 
    70595880849e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588084a4:	b9 07 00 00 00       	mov    ecx,0x7
    7059588084a9:	b8 02 00 00 00       	mov    eax,0x2
    7059588084ae:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    7059588084b2:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588084b6:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588084ba:	e9 28 04 00 00       	jmp    0x7059588088e7
    7059588084bf:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    7059588084c6:	00 
    7059588084c7:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    7059588084cb:	c1 e9 0c             	shr    ecx,0xc
    7059588084ce:	89 c9                	mov    ecx,ecx
    7059588084d0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588084d4:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    7059588084d9:	48 83 f8 00          	cmp    rax,0x0
    7059588084dd:	74 1a                	je     0x7059588084f9
    7059588084df:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    7059588084e4:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    7059588084e8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588084ee:	89 c9                	mov    ecx,ecx
    7059588084f0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588084f3:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    7059588084f7:	eb 57                	jmp    0x705958808550
    7059588084f9:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808500:	00 
    705958808501:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    705958808505:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    70595880850c:	00 
    70595880850d:	c7 80 bc 00 00 00 1e 	mov    DWORD PTR [rax+0xbc],0x1041e
    705958808514:	04 01 00 
    705958808517:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880851e:	00 00 00 
    705958808521:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    705958808528:	00 00 00 
    70595880852b:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958808532:	63 00 00 
    705958808535:	ff d0                	call   rax
    705958808537:	89 c1                	mov    ecx,eax
    705958808539:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808540:	00 
    705958808541:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    705958808545:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880854c:	75 17                	jne    0x705958808565
    70595880854e:	eb 3e                	jmp    0x70595880858e
    705958808550:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808557:	00 
    705958808558:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    70595880855c:	89 4c 24 34          	mov    DWORD PTR [rsp+0x34],ecx
    705958808560:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    705958808563:	eb 33                	jmp    0x705958808598
    705958808565:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880856c:	00 
    70595880856d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808573:	b9 07 00 00 00       	mov    ecx,0x7
    705958808578:	b8 02 00 00 00       	mov    eax,0x2
    70595880857d:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    705958808581:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    705958808585:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958808589:	e9 59 03 00 00       	jmp    0x7059588088e7
    70595880858e:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    705958808592:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    705958808596:	eb b8                	jmp    0x705958808550
    705958808598:	eb 00                	jmp    0x70595880859a
    70595880859a:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    70595880859e:	83 e0 03             	and    eax,0x3
    7059588085a1:	83 f8 00             	cmp    eax,0x0
    7059588085a4:	74 72                	je     0x705958808618
    7059588085a6:	48 8b bc 24 98 00 00 	mov    rdi,QWORD PTR [rsp+0x98]
    7059588085ad:	00 
    7059588085ae:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    7059588085b2:	48 8b b4 24 90 00 00 	mov    rsi,QWORD PTR [rsp+0x90]
    7059588085b9:	00 
    7059588085ba:	c7 87 bc 00 00 00 20 	mov    DWORD PTR [rdi+0xbc],0x10420
    7059588085c1:	04 01 00 
    7059588085c4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588085cb:	00 00 00 
    7059588085ce:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    7059588085d5:	00 00 00 
    7059588085d8:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588085df:	63 00 00 
    7059588085e2:	ba 20 04 01 00       	mov    edx,0x10420
    7059588085e7:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588085ed:	ff d0                	call   rax
    7059588085ef:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588085f6:	00 
    7059588085f7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588085fd:	b9 08 00 00 00       	mov    ecx,0x8
    705958808602:	b8 02 00 00 00       	mov    eax,0x2
    705958808607:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    70595880860b:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    70595880860f:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958808613:	e9 cf 02 00 00       	jmp    0x7059588088e7
    705958808618:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880861f:	00 
    705958808620:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958808624:	c1 e9 0c             	shr    ecx,0xc
    705958808627:	89 c9                	mov    ecx,ecx
    705958808629:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880862d:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    705958808632:	48 83 f8 00          	cmp    rax,0x0
    705958808636:	74 1a                	je     0x705958808652
    705958808638:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880863d:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    705958808641:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958808645:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880864b:	89 c9                	mov    ecx,ecx
    70595880864d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958808650:	eb 55                	jmp    0x7059588086a7
    705958808652:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808659:	00 
    70595880865a:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    70595880865e:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    705958808662:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    705958808669:	00 
    70595880866a:	c7 80 bc 00 00 00 20 	mov    DWORD PTR [rax+0xbc],0x10420
    705958808671:	04 01 00 
    705958808674:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880867b:	00 00 00 
    70595880867e:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    705958808685:	00 00 00 
    705958808688:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880868f:	63 00 00 
    705958808692:	ff d0                	call   rax
    705958808694:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880869b:	00 
    70595880869c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588086a3:	75 1b                	jne    0x7059588086c0
    7059588086a5:	eb 42                	jmp    0x7059588086e9
    7059588086a7:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588086ae:	00 
    7059588086af:	8b 80 9c 00 00 00    	mov    eax,DWORD PTR [rax+0x9c]
    7059588086b5:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    7059588086b9:	83 f8 01             	cmp    eax,0x1
    7059588086bc:	77 32                	ja     0x7059588086f0
    7059588086be:	eb 65                	jmp    0x705958808725
    7059588086c0:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588086c7:	00 
    7059588086c8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588086ce:	b9 08 00 00 00       	mov    ecx,0x8
    7059588086d3:	b8 02 00 00 00       	mov    eax,0x2
    7059588086d8:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    7059588086dc:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588086e0:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588086e4:	e9 fe 01 00 00       	jmp    0x7059588088e7
    7059588086e9:	eb bc                	jmp    0x7059588086a7
    7059588086eb:	e9 1b 01 00 00       	jmp    0x70595880880b
    7059588086f0:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    7059588086f7:	00 
    7059588086f8:	48 8b 8c 24 98 00 00 	mov    rcx,QWORD PTR [rsp+0x98]
    7059588086ff:	00 
    705958808700:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    705958808704:	83 ea 01             	sub    edx,0x1
    705958808707:	89 91 9c 00 00 00    	mov    DWORD PTR [rcx+0x9c],edx
    70595880870d:	c7 81 bc 00 00 00 12 	mov    DWORD PTR [rcx+0xbc],0x10412
    705958808714:	04 01 00 
    705958808717:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    70595880871e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958808721:	75 26                	jne    0x705958808749
    705958808723:	eb 4c                	jmp    0x705958808771
    705958808725:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    70595880872c:	00 
    70595880872d:	48 8b 8c 24 98 00 00 	mov    rcx,QWORD PTR [rsp+0x98]
    705958808734:	00 
    705958808735:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x0
    70595880873c:	00 00 00 
    70595880873f:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958808742:	75 56                	jne    0x70595880879a
    705958808744:	e9 83 00 00 00       	jmp    0x7059588087cc
    705958808749:	48 8b bc 24 98 00 00 	mov    rdi,QWORD PTR [rsp+0x98]
    705958808750:	00 
    705958808751:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958808758:	00 00 00 
    70595880875b:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    705958808762:	00 00 00 
    705958808765:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880876c:	63 00 00 
    70595880876f:	ff d0                	call   rax
    705958808771:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808778:	00 
    705958808779:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880877f:	b9 08 00 00 00       	mov    ecx,0x8
    705958808784:	b8 02 00 00 00       	mov    eax,0x2
    705958808789:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    70595880878d:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    705958808791:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958808795:	e9 4d 01 00 00       	jmp    0x7059588088e7
    70595880879a:	48 8b bc 24 98 00 00 	mov    rdi,QWORD PTR [rsp+0x98]
    7059588087a1:	00 
    7059588087a2:	c7 87 bc 00 00 00 22 	mov    DWORD PTR [rdi+0xbc],0x10422
    7059588087a9:	04 01 00 
    7059588087ac:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588087b3:	00 00 00 
    7059588087b6:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    7059588087bd:	00 00 00 
    7059588087c0:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059588087c7:	63 00 00 
    7059588087ca:	ff d0                	call   rax
    7059588087cc:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588087d3:	00 
    7059588087d4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588087db:	74 29                	je     0x705958808806
    7059588087dd:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588087e4:	00 
    7059588087e5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588087eb:	b9 08 00 00 00       	mov    ecx,0x8
    7059588087f0:	b8 02 00 00 00       	mov    eax,0x2
    7059588087f5:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    7059588087f9:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588087fd:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958808801:	e9 e1 00 00 00       	jmp    0x7059588088e7
    705958808806:	e9 e0 fe ff ff       	jmp    0x7059588086eb
    70595880880b:	eb 00                	jmp    0x70595880880d
    70595880880d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808814:	00 
    705958808815:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    70595880881b:	eb 00                	jmp    0x70595880881d
    70595880881d:	48 8b 8c 24 98 00 00 	mov    rcx,QWORD PTR [rsp+0x98]
    705958808824:	00 
    705958808825:	c7 81 bc 00 00 00 68 	mov    DWORD PTR [rcx+0xbc],0x10368
    70595880882c:	03 01 00 
    70595880882f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958808835:	83 c0 0a             	add    eax,0xa
    705958808838:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    70595880883c:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958808842:	72 16                	jb     0x70595880885a
    705958808844:	eb 37                	jmp    0x70595880887d
    705958808846:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880884d:	00 
    70595880884e:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958808855:	e9 6a 01 00 00       	jmp    0x7059588089c4
    70595880885a:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    705958808861:	00 
    705958808862:	48 89 c1             	mov    rcx,rax
    705958808865:	48 81 c1 40 1b 08 00 	add    rcx,0x81b40
    70595880886c:	48 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],rcx
    705958808871:	81 b8 40 1b 08 00 68 	cmp    DWORD PTR [rax+0x81b40],0x10368
    705958808878:	03 01 00 
    70595880887b:	74 32                	je     0x7059588088af
    70595880887d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958808884:	00 
    705958808885:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    70595880888c:	03 01 00 
    70595880888f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958808896:	00 00 00 
    705958808899:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    7059588088a0:	00 00 00 
    7059588088a3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    7059588088aa:	e9 15 01 00 00       	jmp    0x7059588089c4
    7059588088af:	4c 8b b4 24 90 00 00 	mov    r14,QWORD PTR [rsp+0x90]
    7059588088b6:	00 
    7059588088b7:	4c 8b ac 24 98 00 00 	mov    r13,QWORD PTR [rsp+0x98]
    7059588088be:	00 
    7059588088bf:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    7059588088c4:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    7059588088c8:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    7059588088cf:	68 03 01 00 
    7059588088d3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7059588088da:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588088de:	48 81 c4 b8 00 00 00 	add    rsp,0xb8
    7059588088e5:	ff e0                	jmp    rax
    7059588088e7:	48 8b 8c 24 98 00 00 	mov    rcx,QWORD PTR [rsp+0x98]
    7059588088ee:	00 
    7059588088ef:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    7059588088f3:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    7059588088f7:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    7059588088fb:	89 c7                	mov    edi,eax
    7059588088fd:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    705958808901:	89 74 24 0c          	mov    DWORD PTR [rsp+0xc],esi
    705958808905:	89 54 24 10          	mov    DWORD PTR [rsp+0x10],edx
    705958808909:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880890f:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    705958808913:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958808919:	73 0d                	jae    0x705958808928
    70595880891b:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595880891f:	3d 12 04 01 00       	cmp    eax,0x10412
    705958808924:	74 20                	je     0x705958808946
    705958808926:	eb 3c                	jmp    0x705958808964
    705958808928:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880892f:	00 
    705958808930:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    705958808934:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    705958808938:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    70595880893e:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    705958808944:	eb 7e                	jmp    0x7059588089c4
    705958808946:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880894d:	00 
    70595880894e:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    705958808952:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    705958808958:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    70595880895f:	e9 cb f7 ff ff       	jmp    0x70595880812f
    705958808964:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    70595880896b:	00 
    70595880896c:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    705958808970:	89 d1                	mov    ecx,edx
    705958808972:	c1 e9 01             	shr    ecx,0x1
    705958808975:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880897b:	89 c9                	mov    ecx,ecx
    70595880897d:	48 c1 e1 04          	shl    rcx,0x4
    705958808981:	48 89 c6             	mov    rsi,rax
    705958808984:	48 01 ce             	add    rsi,rcx
    705958808987:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    70595880898b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880898e:	75 98                	jne    0x705958808928
    705958808990:	4c 8b b4 24 90 00 00 	mov    r14,QWORD PTR [rsp+0x90]
    705958808997:	00 
    705958808998:	4c 8b ac 24 98 00 00 	mov    r13,QWORD PTR [rsp+0x98]
    70595880899f:	00 
    7059588089a0:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    7059588089a4:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    7059588089a8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7059588089af:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7059588089b6:	00 
    7059588089b7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588089bb:	48 81 c4 b8 00 00 00 	add    rsp,0xb8
    7059588089c2:	ff e0                	jmp    rax
    7059588089c4:	48 81 c4 b8 00 00 00 	add    rsp,0xb8
    7059588089cb:	c2 08 00             	ret    0x8
