; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000103a4(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 66468
  %4 = icmp ugt i32 %3, 16
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb1 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb1, 0
  %9 = sub i32 %guard_lb1, 66468
  %10 = icmp ugt i32 %9, 16
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x000103a4_entry, label %lb_guard_miss, !prof !0

insn_0x000103a4_entry:                            ; preds = %lb_guard
  %13 = getelementptr i8, ptr %cpu, i64 336
  %chain_table3 = load ptr, ptr %13, align 8
  %tier_table = getelementptr i8, ptr %chain_table3, i64 1048576
  %14 = getelementptr i8, ptr %tier_table, i64 16
  %15 = load i32, ptr %14, align 4
  %tier_count = add i32 %15, 1
  store i32 %tier_count, ptr %14, align 4
  %16 = icmp eq i32 %tier_count, 30000
  br i1 %16, label %17, label %27, !prof !1

17:                                               ; preds = %insn_0x000103a4_entry
  %18 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %18, align 4
  %19 = add i32 %tier_requests, 1
  store i32 %19, ptr %18, align 4
  %20 = icmp ult i32 %tier_requests, 256
  br i1 %20, label %21, label %26

21:                                               ; preds = %17
  %22 = zext i32 %tier_requests to i64
  %23 = mul i64 %22, 4
  %24 = add i64 262148, %23
  %25 = getelementptr i8, ptr %tier_table, i64 %24
  store i32 4, ptr %25, align 4
  br label %26

26:                                               ; preds = %17, %21
  br label %27

27:                                               ; preds = %insn_0x000103a4_entry, %26
  br label %insn_0x000103a4

insn_0x000103a4:                                  ; preds = %27
  %28 = getelementptr i8, ptr %cpu, i32 52
  %old = load i32, ptr %28, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %29 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_hi, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %31, align 4
  br label %insn_0x000103a8_entry

insn_0x000103a8_entry:                            ; preds = %insn_0x000103a4
  br label %insn_0x000103a8

insn_0x000103a8:                                  ; preds = %insn_0x000103a8_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 37628
  %32 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_lo, ptr %32, align 4
  br label %insn_0x000103ac_entry

insn_0x000103ac_entry:                            ; preds = %insn_0x000103a8
  br label %insn_0x000103ac

insn_0x000103ac:                                  ; preds = %insn_0x000103ac_entry
  %33 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %33, align 4
  br label %insn_0x000103ae_entry

insn_0x000103ae_entry:                            ; preds = %insn_0x000103ac
  br label %insn_0x000103ae

insn_0x000103ae:                                  ; preds = %insn_0x000103ae_entry
  %34 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %34, align 4
  br label %insn_0x000103b0_entry

insn_0x000103b0_entry:                            ; preds = %insn_0x000103ae
  br label %insn_0x000103b0

insn_0x000103b0:                                  ; preds = %insn_0x000103b0_entry
  %35 = getelementptr i8, ptr %cpu, i32 40
  store i32 8192, ptr %35, align 4
  br label %insn_0x000103b4_entry

insn_0x000103b4_entry:                            ; preds = %insn_0x000103b0
  br label %insn_0x000103b4

insn_0x000103b4:                                  ; preds = %insn_0x000103b4_entry
  %36 = getelementptr i8, ptr %cpu, i32 148
  store i32 66488, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 164
  store i32 66490, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 156
  store i32 8192, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 296
  %40 = getelementptr i8, ptr %cpu, i32 188
  store i32 66488, ptr %40, align 4
  store i8 1, ptr %39, align 1
  %at_lb0 = icmp eq i32 %lb0, 66484
  %at_lb = or i1 %at_lb0, false
  br i1 %at_lb, label %hwloop_count, label %hwloop_counted, !prof !1

hwloop_count:                                     ; preds = %insn_0x000103b4
  %41 = getelementptr i8, ptr %cpu, i32 188
  store i32 66488, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %43, align 4
  call void @bfin_hwloop_step(ptr %cpu, i32 66484, i32 66484)
  br label %hwloop_counted

hwloop_counted:                                   ; preds = %hwloop_count, %insn_0x000103b4
  %44 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %44, align 4
  %chain_total = add nuw i32 %chain_packets, 6
  %45 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %45 monotonic, align 4, !range !2
  %46 = icmp ult i32 %chain_total, %chain_budget
  br i1 %46, label %chain_go, label %chain_leave2, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %47 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %47, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %hwloop_counted
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531904
  %48 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %48, align 4
  %49 = icmp eq i32 %slot_pc, 66488
  br i1 %49, label %chain_hit, label %chain_leave2, !prof !0

chain_leave2:                                     ; preds = %chain_go, %hwloop_counted
  %50 = getelementptr i8, ptr %cpu, i64 188
  store i32 66488, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %52, align 4
  br label %return

chain_hit:                                        ; preds = %chain_go
  %53 = getelementptr i8, ptr %cpu, i64 188
  store i32 66488, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %55, align 1
  %56 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %56, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave2, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @bfin_hwloop_step(ptr, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
