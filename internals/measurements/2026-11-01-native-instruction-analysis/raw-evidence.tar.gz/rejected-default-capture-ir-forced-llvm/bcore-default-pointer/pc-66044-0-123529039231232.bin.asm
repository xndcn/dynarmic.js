
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66044-0-123529039231232.bin:     file format binary


Disassembly of section .data:

000070595880b900 <.data>:
    70595880b900:	48 81 ec 48 01 00 00 	sub    rsp,0x148
    70595880b907:	4c 89 b4 24 20 01 00 	mov    QWORD PTR [rsp+0x120],r14
    70595880b90e:	00 
    70595880b90f:	4c 89 ac 24 28 01 00 	mov    QWORD PTR [rsp+0x128],r13
    70595880b916:	00 
    70595880b917:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880b91e:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    70595880b925:	00 
    70595880b926:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    70595880b92d:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    70595880b934:	00 
    70595880b935:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880b93c:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
    70595880b943:	00 
    70595880b944:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880b94b:	00 
    70595880b94c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    70595880b952:	83 fa 00             	cmp    edx,0x0
    70595880b955:	0f 94 c0             	sete   al
    70595880b958:	81 ea fc 01 01 00    	sub    edx,0x101fc
    70595880b95e:	83 fa 3a             	cmp    edx,0x3a
    70595880b961:	0f 97 c2             	seta   dl
    70595880b964:	08 d0                	or     al,dl
    70595880b966:	24 01                	and    al,0x1
    70595880b968:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880b96e:	81 fa 20 04 01 00    	cmp    edx,0x10420
    70595880b974:	0f 94 c1             	sete   cl
    70595880b977:	81 ea fc 01 01 00    	sub    edx,0x101fc
    70595880b97d:	83 fa 3a             	cmp    edx,0x3a
    70595880b980:	0f 97 c2             	seta   dl
    70595880b983:	08 d1                	or     cl,dl
    70595880b985:	20 c8                	and    al,cl
    70595880b987:	a8 01                	test   al,0x1
    70595880b989:	75 05                	jne    0x70595880b990
    70595880b98b:	e9 23 13 00 00       	jmp    0x70595880ccb3
    70595880b990:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880b997:	00 
    70595880b998:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880b99f:	48 89 c8             	mov    rax,rcx
    70595880b9a2:	48 05 00 00 10 00    	add    rax,0x100000
    70595880b9a8:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    70595880b9af:	00 
    70595880b9b0:	8b 81 34 00 10 00    	mov    eax,DWORD PTR [rcx+0x100034]
    70595880b9b6:	83 c0 01             	add    eax,0x1
    70595880b9b9:	89 81 34 00 10 00    	mov    DWORD PTR [rcx+0x100034],eax
    70595880b9bf:	3d 75 a8 00 00       	cmp    eax,0xa875
    70595880b9c4:	75 4c                	jne    0x70595880ba12
    70595880b9c6:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
    70595880b9cd:	00 
    70595880b9ce:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    70595880b9d4:	89 84 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],eax
    70595880b9db:	89 c2                	mov    edx,eax
    70595880b9dd:	83 c2 01             	add    edx,0x1
    70595880b9e0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    70595880b9e6:	3d 00 01 00 00       	cmp    eax,0x100
    70595880b9eb:	73 23                	jae    0x70595880ba10
    70595880b9ed:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    70595880b9f4:	00 
    70595880b9f5:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    70595880b9fc:	89 c9                	mov    ecx,ecx
    70595880b9fe:	48 c1 e1 02          	shl    rcx,0x2
    70595880ba02:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880ba09:	c7 04 08 0d 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xd
    70595880ba10:	eb 00                	jmp    0x70595880ba12
    70595880ba12:	eb 00                	jmp    0x70595880ba14
    70595880ba14:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880ba1b:	00 
    70595880ba1c:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    70595880ba1f:	83 e8 04             	sub    eax,0x4
    70595880ba22:	89 84 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],eax
    70595880ba29:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    70595880ba2c:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    70595880ba33:	83 e0 03             	and    eax,0x3
    70595880ba36:	83 f8 00             	cmp    eax,0x0
    70595880ba39:	0f 84 8e 00 00 00    	je     0x70595880bacd
    70595880ba3f:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880ba46:	00 
    70595880ba47:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    70595880ba4e:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880ba55:	00 
    70595880ba56:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ba5d:	00 00 00 
    70595880ba60:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595880ba67:	00 00 00 
    70595880ba6a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ba71:	63 00 00 
    70595880ba74:	ba fc 01 01 00       	mov    edx,0x101fc
    70595880ba79:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880ba7f:	ff d0                	call   rax
    70595880ba81:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880ba88:	00 
    70595880ba89:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ba8f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ba95:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ba9b:	be 01 00 00 00       	mov    esi,0x1
    70595880baa0:	b9 02 00 00 00       	mov    ecx,0x2
    70595880baa5:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880baac:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bab3:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880baba:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880bac1:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880bac8:	e9 17 13 00 00       	jmp    0x70595880cde4
    70595880bacd:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880bad4:	00 
    70595880bad5:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    70595880badc:	c1 e9 0c             	shr    ecx,0xc
    70595880badf:	89 c9                	mov    ecx,ecx
    70595880bae1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880bae5:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    70595880baec:	00 
    70595880baed:	48 83 f8 00          	cmp    rax,0x0
    70595880baf1:	74 23                	je     0x70595880bb16
    70595880baf3:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880bafa:	00 
    70595880bafb:	8b 94 24 10 01 00 00 	mov    edx,DWORD PTR [rsp+0x110]
    70595880bb02:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    70595880bb09:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880bb0f:	89 c9                	mov    ecx,ecx
    70595880bb11:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880bb14:	eb 51                	jmp    0x70595880bb67
    70595880bb16:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bb1d:	00 
    70595880bb1e:	8b 94 24 10 01 00 00 	mov    edx,DWORD PTR [rsp+0x110]
    70595880bb25:	8b b4 24 0c 01 00 00 	mov    esi,DWORD PTR [rsp+0x10c]
    70595880bb2c:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880bb33:	00 
    70595880bb34:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880bb3b:	00 00 00 
    70595880bb3e:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    70595880bb45:	00 00 00 
    70595880bb48:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880bb4f:	63 00 00 
    70595880bb52:	ff d0                	call   rax
    70595880bb54:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bb5b:	00 
    70595880bb5c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880bb63:	75 26                	jne    0x70595880bb8b
    70595880bb65:	eb 70                	jmp    0x70595880bbd7
    70595880bb67:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    70595880bb6e:	00 
    70595880bb6f:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880bb76:	00 
    70595880bb77:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    70595880bb7e:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    70595880bb81:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880bb84:	75 53                	jne    0x70595880bbd9
    70595880bb86:	e9 93 00 00 00       	jmp    0x70595880bc1e
    70595880bb8b:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bb92:	00 
    70595880bb93:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880bb99:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880bb9f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880bba5:	be 01 00 00 00       	mov    esi,0x1
    70595880bbaa:	b9 02 00 00 00       	mov    ecx,0x2
    70595880bbaf:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880bbb6:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bbbd:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880bbc4:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880bbcb:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880bbd2:	e9 0d 12 00 00       	jmp    0x70595880cde4
    70595880bbd7:	eb 8e                	jmp    0x70595880bb67
    70595880bbd9:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880bbe0:	00 
    70595880bbe1:	c7 87 bc 00 00 00 fe 	mov    DWORD PTR [rdi+0xbc],0x101fe
    70595880bbe8:	01 01 00 
    70595880bbeb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880bbf2:	00 00 00 
    70595880bbf5:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595880bbfc:	00 00 00 
    70595880bbff:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880bc06:	63 00 00 
    70595880bc09:	ff d0                	call   rax
    70595880bc0b:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bc12:	00 
    70595880bc13:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880bc1a:	75 04                	jne    0x70595880bc20
    70595880bc1c:	eb 4e                	jmp    0x70595880bc6c
    70595880bc1e:	eb 4e                	jmp    0x70595880bc6e
    70595880bc20:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bc27:	00 
    70595880bc28:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880bc2e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880bc34:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880bc3a:	be 01 00 00 00       	mov    esi,0x1
    70595880bc3f:	b9 02 00 00 00       	mov    ecx,0x2
    70595880bc44:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880bc4b:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bc52:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880bc59:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880bc60:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880bc67:	e9 78 11 00 00       	jmp    0x70595880cde4
    70595880bc6c:	eb b0                	jmp    0x70595880bc1e
    70595880bc6e:	eb 00                	jmp    0x70595880bc70
    70595880bc70:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bc77:	00 
    70595880bc78:	c7 40 08 ff 1f 00 00 	mov    DWORD PTR [rax+0x8],0x1fff
    70595880bc7f:	eb 00                	jmp    0x70595880bc81
    70595880bc81:	8b 84 24 0c 01 00 00 	mov    eax,DWORD PTR [rsp+0x10c]
    70595880bc88:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880bc8f:	00 
    70595880bc90:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    70595880bc96:	89 94 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],edx
    70595880bc9d:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    70595880bca0:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    70595880bca7:	83 e8 04             	sub    eax,0x4
    70595880bcaa:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    70595880bcb1:	83 e0 03             	and    eax,0x3
    70595880bcb4:	83 f8 00             	cmp    eax,0x0
    70595880bcb7:	0f 84 98 00 00 00    	je     0x70595880bd55
    70595880bcbd:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880bcc4:	00 
    70595880bcc5:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880bccc:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880bcd3:	00 
    70595880bcd4:	c7 87 bc 00 00 00 02 	mov    DWORD PTR [rdi+0xbc],0x10202
    70595880bcdb:	02 01 00 
    70595880bcde:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880bce5:	00 00 00 
    70595880bce8:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    70595880bcef:	00 00 00 
    70595880bcf2:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880bcf9:	63 00 00 
    70595880bcfc:	ba 02 02 01 00       	mov    edx,0x10202
    70595880bd01:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880bd07:	ff d0                	call   rax
    70595880bd09:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bd10:	00 
    70595880bd11:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880bd17:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880bd1d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880bd23:	be 03 00 00 00       	mov    esi,0x3
    70595880bd28:	b9 04 00 00 00       	mov    ecx,0x4
    70595880bd2d:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880bd34:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bd3b:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880bd42:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880bd49:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880bd50:	e9 8f 10 00 00       	jmp    0x70595880cde4
    70595880bd55:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880bd5c:	00 
    70595880bd5d:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880bd64:	c1 e9 0c             	shr    ecx,0xc
    70595880bd67:	89 c9                	mov    ecx,ecx
    70595880bd69:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880bd6d:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    70595880bd74:	00 
    70595880bd75:	48 83 f8 00          	cmp    rax,0x0
    70595880bd79:	74 23                	je     0x70595880bd9e
    70595880bd7b:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880bd82:	00 
    70595880bd83:	8b 94 24 e4 00 00 00 	mov    edx,DWORD PTR [rsp+0xe4]
    70595880bd8a:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880bd91:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880bd97:	89 c9                	mov    ecx,ecx
    70595880bd99:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880bd9c:	eb 5b                	jmp    0x70595880bdf9
    70595880bd9e:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bda5:	00 
    70595880bda6:	8b 94 24 e4 00 00 00 	mov    edx,DWORD PTR [rsp+0xe4]
    70595880bdad:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    70595880bdb4:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880bdbb:	00 
    70595880bdbc:	c7 80 bc 00 00 00 02 	mov    DWORD PTR [rax+0xbc],0x10202
    70595880bdc3:	02 01 00 
    70595880bdc6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880bdcd:	00 00 00 
    70595880bdd0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    70595880bdd7:	00 00 00 
    70595880bdda:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880bde1:	63 00 00 
    70595880bde4:	ff d0                	call   rax
    70595880bde6:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bded:	00 
    70595880bdee:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880bdf5:	75 20                	jne    0x70595880be17
    70595880bdf7:	eb 6a                	jmp    0x70595880be63
    70595880bdf9:	8b 84 24 ec 00 00 00 	mov    eax,DWORD PTR [rsp+0xec]
    70595880be00:	83 e8 04             	sub    eax,0x4
    70595880be03:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    70595880be0a:	83 e0 03             	and    eax,0x3
    70595880be0d:	83 f8 00             	cmp    eax,0x0
    70595880be10:	75 53                	jne    0x70595880be65
    70595880be12:	e9 e6 00 00 00       	jmp    0x70595880befd
    70595880be17:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880be1e:	00 
    70595880be1f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880be25:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880be2b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880be31:	be 03 00 00 00       	mov    esi,0x3
    70595880be36:	b9 04 00 00 00       	mov    ecx,0x4
    70595880be3b:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880be42:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880be49:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880be50:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880be57:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880be5e:	e9 81 0f 00 00       	jmp    0x70595880cde4
    70595880be63:	eb 94                	jmp    0x70595880bdf9
    70595880be65:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880be6c:	00 
    70595880be6d:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880be74:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880be7b:	00 
    70595880be7c:	c7 87 bc 00 00 00 02 	mov    DWORD PTR [rdi+0xbc],0x10202
    70595880be83:	02 01 00 
    70595880be86:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880be8d:	00 00 00 
    70595880be90:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    70595880be97:	00 00 00 
    70595880be9a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880bea1:	63 00 00 
    70595880bea4:	ba 02 02 01 00       	mov    edx,0x10202
    70595880bea9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880beaf:	ff d0                	call   rax
    70595880beb1:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880beb8:	00 
    70595880beb9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880bebf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880bec5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880becb:	be 03 00 00 00       	mov    esi,0x3
    70595880bed0:	b9 04 00 00 00       	mov    ecx,0x4
    70595880bed5:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880bedc:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bee3:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880beea:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880bef1:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880bef8:	e9 e7 0e 00 00       	jmp    0x70595880cde4
    70595880befd:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880bf04:	00 
    70595880bf05:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880bf0c:	c1 e9 0c             	shr    ecx,0xc
    70595880bf0f:	89 c9                	mov    ecx,ecx
    70595880bf11:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880bf15:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    70595880bf1c:	00 
    70595880bf1d:	48 83 f8 00          	cmp    rax,0x0
    70595880bf21:	74 23                	je     0x70595880bf46
    70595880bf23:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    70595880bf2a:	00 
    70595880bf2b:	8b 94 24 e8 00 00 00 	mov    edx,DWORD PTR [rsp+0xe8]
    70595880bf32:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880bf39:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880bf3f:	89 c9                	mov    ecx,ecx
    70595880bf41:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880bf44:	eb 5b                	jmp    0x70595880bfa1
    70595880bf46:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bf4d:	00 
    70595880bf4e:	8b 94 24 e8 00 00 00 	mov    edx,DWORD PTR [rsp+0xe8]
    70595880bf55:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    70595880bf5c:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880bf63:	00 
    70595880bf64:	c7 80 bc 00 00 00 02 	mov    DWORD PTR [rax+0xbc],0x10202
    70595880bf6b:	02 01 00 
    70595880bf6e:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880bf75:	00 00 00 
    70595880bf78:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    70595880bf7f:	00 00 00 
    70595880bf82:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880bf89:	63 00 00 
    70595880bf8c:	ff d0                	call   rax
    70595880bf8e:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bf95:	00 
    70595880bf96:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880bf9d:	75 2c                	jne    0x70595880bfcb
    70595880bf9f:	eb 76                	jmp    0x70595880c017
    70595880bfa1:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    70595880bfa8:	00 
    70595880bfa9:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880bfb0:	00 
    70595880bfb1:	8b 94 24 d4 00 00 00 	mov    edx,DWORD PTR [rsp+0xd4]
    70595880bfb8:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    70595880bfbb:	83 ea 00             	sub    edx,0x0
    70595880bfbe:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    70595880bfc1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880bfc4:	75 53                	jne    0x70595880c019
    70595880bfc6:	e9 93 00 00 00       	jmp    0x70595880c05e
    70595880bfcb:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880bfd2:	00 
    70595880bfd3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880bfd9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880bfdf:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880bfe5:	be 03 00 00 00       	mov    esi,0x3
    70595880bfea:	b9 04 00 00 00       	mov    ecx,0x4
    70595880bfef:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880bff6:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880bffd:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c004:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c00b:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c012:	e9 cd 0d 00 00       	jmp    0x70595880cde4
    70595880c017:	eb 88                	jmp    0x70595880bfa1
    70595880c019:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880c020:	00 
    70595880c021:	c7 87 bc 00 00 00 06 	mov    DWORD PTR [rdi+0xbc],0x10206
    70595880c028:	02 01 00 
    70595880c02b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880c032:	00 00 00 
    70595880c035:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    70595880c03c:	00 00 00 
    70595880c03f:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880c046:	63 00 00 
    70595880c049:	ff d0                	call   rax
    70595880c04b:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c052:	00 
    70595880c053:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880c05a:	75 04                	jne    0x70595880c060
    70595880c05c:	eb 4e                	jmp    0x70595880c0ac
    70595880c05e:	eb 4e                	jmp    0x70595880c0ae
    70595880c060:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c067:	00 
    70595880c068:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c06e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c074:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c07a:	be 03 00 00 00       	mov    esi,0x3
    70595880c07f:	b9 04 00 00 00       	mov    ecx,0x4
    70595880c084:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c08b:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c092:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c099:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c0a0:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c0a7:	e9 38 0d 00 00       	jmp    0x70595880cde4
    70595880c0ac:	eb b0                	jmp    0x70595880c05e
    70595880c0ae:	eb 00                	jmp    0x70595880c0b0
    70595880c0b0:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c0b7:	00 
    70595880c0b8:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    70595880c0bb:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    70595880c0c2:	81 e1 ff 1f 00 00    	and    ecx,0x1fff
    70595880c0c8:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    70595880c0cf:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    70595880c0d2:	83 f9 00             	cmp    ecx,0x0
    70595880c0d5:	0f 94 c2             	sete   dl
    70595880c0d8:	80 e2 01             	and    dl,0x1
    70595880c0db:	0f b6 d2             	movzx  edx,dl
    70595880c0de:	c1 e9 1f             	shr    ecx,0x1f
    70595880c0e1:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880c0e7:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    70595880c0ed:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880c0f4:	00 00 00 
    70595880c0f7:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880c0fe:	00 00 00 
    70595880c101:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880c108:	00 00 00 
    70595880c10b:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880c112:	00 00 00 
    70595880c115:	eb 00                	jmp    0x70595880c117
    70595880c117:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c11e:	00 
    70595880c11f:	8b 38                	mov    edi,DWORD PTR [rax]
    70595880c121:	89 bc 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],edi
    70595880c128:	89 fa                	mov    edx,edi
    70595880c12a:	83 ea 00             	sub    edx,0x0
    70595880c12d:	83 fa 00             	cmp    edx,0x0
    70595880c130:	0f 94 c1             	sete   cl
    70595880c133:	80 e1 01             	and    cl,0x1
    70595880c136:	0f b6 f1             	movzx  esi,cl
    70595880c139:	89 b4 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],esi
    70595880c140:	c1 ea 1f             	shr    edx,0x1f
    70595880c143:	89 f9                	mov    ecx,edi
    70595880c145:	c1 e9 1f             	shr    ecx,0x1f
    70595880c148:	89 d3                	mov    ebx,edx
    70595880c14a:	31 cb                	xor    ebx,ecx
    70595880c14c:	83 f1 00             	xor    ecx,0x0
    70595880c14f:	21 d9                	and    ecx,ebx
    70595880c151:	31 ca                	xor    edx,ecx
    70595880c153:	31 c9                	xor    ecx,ecx
    70595880c155:	39 f9                	cmp    ecx,edi
    70595880c157:	0f 96 c1             	setbe  cl
    70595880c15a:	80 e1 01             	and    cl,0x1
    70595880c15d:	0f b6 c9             	movzx  ecx,cl
    70595880c160:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    70595880c166:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    70595880c16c:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880c172:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880c178:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880c17e:	eb 00                	jmp    0x70595880c180
    70595880c180:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    70595880c187:	83 f8 00             	cmp    eax,0x0
    70595880c18a:	74 33                	je     0x70595880c1bf
    70595880c18c:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880c193:	00 
    70595880c194:	c7 81 bc 00 00 00 2e 	mov    DWORD PTR [rcx+0xbc],0x1022e
    70595880c19b:	02 01 00 
    70595880c19e:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880c1a4:	83 c0 06             	add    eax,0x6
    70595880c1a7:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    70595880c1ae:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880c1b4:	0f 82 0d 0b 00 00    	jb     0x70595880ccc7
    70595880c1ba:	e9 2b 0b 00 00       	jmp    0x70595880ccea
    70595880c1bf:	eb 00                	jmp    0x70595880c1c1
    70595880c1c1:	eb 00                	jmp    0x70595880c1c3
    70595880c1c3:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c1ca:	00 
    70595880c1cb:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    70595880c1ce:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880c1d4:	81 c9 00 00 01 00    	or     ecx,0x10000
    70595880c1da:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    70595880c1e1:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    70595880c1e4:	eb 00                	jmp    0x70595880c1e6
    70595880c1e6:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c1ed:	00 
    70595880c1ee:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    70595880c1f5:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880c1fb:	81 c9 00 00 37 9e    	or     ecx,0x9e370000
    70595880c201:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880c208:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    70595880c20b:	eb 00                	jmp    0x70595880c20d
    70595880c20d:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c214:	00 
    70595880c215:	c7 40 0c 00 00 00 00 	mov    DWORD PTR [rax+0xc],0x0
    70595880c21c:	eb 00                	jmp    0x70595880c21e
    70595880c21e:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c225:	00 
    70595880c226:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    70595880c22d:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880c233:	81 c9 fc 12 00 00    	or     ecx,0x12fc
    70595880c239:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    70595880c240:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    70595880c243:	eb 00                	jmp    0x70595880c245
    70595880c245:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c24c:	00 
    70595880c24d:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    70595880c254:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880c25a:	81 c9 b9 79 00 00    	or     ecx,0x79b9
    70595880c260:	89 8c 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],ecx
    70595880c267:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    70595880c26a:	eb 00                	jmp    0x70595880c26c
    70595880c26c:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c273:	00 
    70595880c274:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    70595880c27b:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    70595880c27e:	eb 00                	jmp    0x70595880c280
    70595880c280:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c287:	00 
    70595880c288:	c7 40 0c 01 00 00 00 	mov    DWORD PTR [rax+0xc],0x1
    70595880c28f:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    70595880c296:	00 00 00 
    70595880c299:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    70595880c2a0:	00 00 00 
    70595880c2a3:	8b 88 00 01 00 00    	mov    ecx,DWORD PTR [rax+0x100]
    70595880c2a9:	83 c9 00             	or     ecx,0x0
    70595880c2ac:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880c2b3:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880c2ba:	00 00 00 
    70595880c2bd:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880c2c4:	00 00 00 
    70595880c2c7:	89 88 00 01 00 00    	mov    DWORD PTR [rax+0x100],ecx
    70595880c2cd:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880c2d4:	00 00 00 
    70595880c2d7:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880c2de:	00 00 00 
    70595880c2e1:	eb 00                	jmp    0x70595880c2e3
    70595880c2e3:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c2ea:	00 
    70595880c2eb:	8b bc 24 b8 00 00 00 	mov    edi,DWORD PTR [rsp+0xb8]
    70595880c2f2:	83 ff 01             	cmp    edi,0x1
    70595880c2f5:	0f 96 c1             	setbe  cl
    70595880c2f8:	80 e1 01             	and    cl,0x1
    70595880c2fb:	0f b6 c9             	movzx  ecx,cl
    70595880c2fe:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    70595880c305:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    70595880c30b:	83 ff 01             	cmp    edi,0x1
    70595880c30e:	0f 94 c1             	sete   cl
    70595880c311:	80 e1 01             	and    cl,0x1
    70595880c314:	0f b6 f1             	movzx  esi,cl
    70595880c317:	b9 01 00 00 00       	mov    ecx,0x1
    70595880c31c:	39 f9                	cmp    ecx,edi
    70595880c31e:	0f 97 c1             	seta   cl
    70595880c321:	80 e1 01             	and    cl,0x1
    70595880c324:	0f b6 d1             	movzx  edx,cl
    70595880c327:	b9 01 00 00 00       	mov    ecx,0x1
    70595880c32c:	39 f9                	cmp    ecx,edi
    70595880c32e:	0f 96 c1             	setbe  cl
    70595880c331:	80 e1 01             	and    cl,0x1
    70595880c334:	0f b6 c9             	movzx  ecx,cl
    70595880c337:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    70595880c33d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880c343:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880c349:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880c34f:	eb 00                	jmp    0x70595880c351
    70595880c351:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c358:	00 
    70595880c359:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    70595880c360:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    70595880c367:	c1 e2 02             	shl    edx,0x2
    70595880c36a:	01 d1                	add    ecx,edx
    70595880c36c:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    70595880c373:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880c376:	eb 00                	jmp    0x70595880c378
    70595880c378:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    70595880c37f:	83 e0 03             	and    eax,0x3
    70595880c382:	83 f8 00             	cmp    eax,0x0
    70595880c385:	0f 84 97 00 00 00    	je     0x70595880c422
    70595880c38b:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880c392:	00 
    70595880c393:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    70595880c39a:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880c3a1:	00 
    70595880c3a2:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    70595880c3a9:	02 01 00 
    70595880c3ac:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880c3b3:	00 00 00 
    70595880c3b6:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    70595880c3bd:	00 00 00 
    70595880c3c0:	31 c0                	xor    eax,eax
    70595880c3c2:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880c3c9:	63 00 00 
    70595880c3cc:	ba 26 02 01 00       	mov    edx,0x10226
    70595880c3d1:	45 31 c0             	xor    r8d,r8d
    70595880c3d4:	ff d0                	call   rax
    70595880c3d6:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c3dd:	00 
    70595880c3de:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c3e4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c3ea:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c3f0:	be 10 00 00 00       	mov    esi,0x10
    70595880c3f5:	b9 02 00 00 00       	mov    ecx,0x2
    70595880c3fa:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c401:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c408:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c40f:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c416:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c41d:	e9 c2 09 00 00       	jmp    0x70595880cde4
    70595880c422:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880c429:	00 
    70595880c42a:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    70595880c431:	c1 e9 0c             	shr    ecx,0xc
    70595880c434:	89 c9                	mov    ecx,ecx
    70595880c436:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880c43a:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    70595880c441:	00 
    70595880c442:	48 83 f8 00          	cmp    rax,0x0
    70595880c446:	74 23                	je     0x70595880c46b
    70595880c448:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    70595880c44f:	00 
    70595880c450:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    70595880c457:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880c45d:	89 c9                	mov    ecx,ecx
    70595880c45f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880c462:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    70595880c469:	eb 5d                	jmp    0x70595880c4c8
    70595880c46b:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c472:	00 
    70595880c473:	8b b4 24 98 00 00 00 	mov    esi,DWORD PTR [rsp+0x98]
    70595880c47a:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880c481:	00 
    70595880c482:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10226
    70595880c489:	02 01 00 
    70595880c48c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880c493:	00 00 00 
    70595880c496:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    70595880c49d:	00 00 00 
    70595880c4a0:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880c4a7:	63 00 00 
    70595880c4aa:	ff d0                	call   rax
    70595880c4ac:	89 c1                	mov    ecx,eax
    70595880c4ae:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c4b5:	00 
    70595880c4b6:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    70595880c4bd:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880c4c4:	75 1d                	jne    0x70595880c4e3
    70595880c4c6:	eb 67                	jmp    0x70595880c52f
    70595880c4c8:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c4cf:	00 
    70595880c4d0:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    70595880c4d7:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    70595880c4de:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    70595880c4e1:	eb 5c                	jmp    0x70595880c53f
    70595880c4e3:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c4ea:	00 
    70595880c4eb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c4f1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c4f7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c4fd:	be 10 00 00 00       	mov    esi,0x10
    70595880c502:	b9 02 00 00 00       	mov    ecx,0x2
    70595880c507:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c50e:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c515:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c51c:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c523:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c52a:	e9 b5 08 00 00       	jmp    0x70595880cde4
    70595880c52f:	8b 84 24 88 00 00 00 	mov    eax,DWORD PTR [rsp+0x88]
    70595880c536:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    70595880c53d:	eb 89                	jmp    0x70595880c4c8
    70595880c53f:	eb 00                	jmp    0x70595880c541
    70595880c541:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c548:	00 
    70595880c549:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    70595880c550:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    70595880c557:	31 d1                	xor    ecx,edx
    70595880c559:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    70595880c560:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    70595880c563:	83 f9 00             	cmp    ecx,0x0
    70595880c566:	0f 94 c2             	sete   dl
    70595880c569:	80 e2 01             	and    dl,0x1
    70595880c56c:	0f b6 d2             	movzx  edx,dl
    70595880c56f:	c1 e9 1f             	shr    ecx,0x1f
    70595880c572:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880c578:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    70595880c57e:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880c585:	00 00 00 
    70595880c588:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880c58f:	00 00 00 
    70595880c592:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880c599:	00 00 00 
    70595880c59c:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880c5a3:	00 00 00 
    70595880c5a6:	eb 00                	jmp    0x70595880c5a8
    70595880c5a8:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c5af:	00 
    70595880c5b0:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    70595880c5b7:	8b 9c 24 a4 00 00 00 	mov    ebx,DWORD PTR [rsp+0xa4]
    70595880c5be:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    70595880c5c5:	89 cf                	mov    edi,ecx
    70595880c5c7:	01 df                	add    edi,ebx
    70595880c5c9:	89 7c 24 7c          	mov    DWORD PTR [rsp+0x7c],edi
    70595880c5cd:	89 78 04             	mov    DWORD PTR [rax+0x4],edi
    70595880c5d0:	89 ce                	mov    esi,ecx
    70595880c5d2:	c1 ee 1f             	shr    esi,0x1f
    70595880c5d5:	89 dd                	mov    ebp,ebx
    70595880c5d7:	c1 ed 1f             	shr    ebp,0x1f
    70595880c5da:	41 89 f8             	mov    r8d,edi
    70595880c5dd:	41 c1 e8 1f          	shr    r8d,0x1f
    70595880c5e1:	44 31 c5             	xor    ebp,r8d
    70595880c5e4:	44 31 c6             	xor    esi,r8d
    70595880c5e7:	21 ee                	and    esi,ebp
    70595880c5e9:	83 f1 ff             	xor    ecx,0xffffffff
    70595880c5ec:	39 d9                	cmp    ecx,ebx
    70595880c5ee:	0f 92 c1             	setb   cl
    70595880c5f1:	80 e1 01             	and    cl,0x1
    70595880c5f4:	0f b6 c9             	movzx  ecx,cl
    70595880c5f7:	83 ff 00             	cmp    edi,0x0
    70595880c5fa:	0f 94 c3             	sete   bl
    70595880c5fd:	80 e3 01             	and    bl,0x1
    70595880c600:	0f b6 db             	movzx  ebx,bl
    70595880c603:	c1 ef 1f             	shr    edi,0x1f
    70595880c606:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    70595880c60c:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    70595880c612:	09 f2                	or     edx,esi
    70595880c614:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    70595880c61a:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    70595880c620:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    70595880c626:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880c62c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880c632:	eb 00                	jmp    0x70595880c634
    70595880c634:	8b 84 24 9c 00 00 00 	mov    eax,DWORD PTR [rsp+0x9c]
    70595880c63b:	83 f8 00             	cmp    eax,0x0
    70595880c63e:	75 30                	jne    0x70595880c670
    70595880c640:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880c647:	00 
    70595880c648:	c7 81 bc 00 00 00 1e 	mov    DWORD PTR [rcx+0xbc],0x1021e
    70595880c64f:	02 01 00 
    70595880c652:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880c658:	83 c0 13             	add    eax,0x13
    70595880c65b:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    70595880c65f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880c665:	0f 82 ec 06 00 00    	jb     0x70595880cd57
    70595880c66b:	e9 0a 07 00 00       	jmp    0x70595880cd7a
    70595880c670:	eb 00                	jmp    0x70595880c672
    70595880c672:	eb 00                	jmp    0x70595880c674
    70595880c674:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    70595880c67b:	83 e0 03             	and    eax,0x3
    70595880c67e:	83 f8 00             	cmp    eax,0x0
    70595880c681:	0f 84 97 00 00 00    	je     0x70595880c71e
    70595880c687:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880c68e:	00 
    70595880c68f:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880c696:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880c69d:	00 
    70595880c69e:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880c6a5:	02 01 00 
    70595880c6a8:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880c6af:	00 00 00 
    70595880c6b2:	c7 87 34 01 00 00 14 	mov    DWORD PTR [rdi+0x134],0x14
    70595880c6b9:	00 00 00 
    70595880c6bc:	31 c0                	xor    eax,eax
    70595880c6be:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880c6c5:	63 00 00 
    70595880c6c8:	ba 2e 02 01 00       	mov    edx,0x1022e
    70595880c6cd:	45 31 c0             	xor    r8d,r8d
    70595880c6d0:	ff d0                	call   rax
    70595880c6d2:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c6d9:	00 
    70595880c6da:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c6e0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c6e6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c6ec:	be 14 00 00 00       	mov    esi,0x14
    70595880c6f1:	b9 04 00 00 00       	mov    ecx,0x4
    70595880c6f6:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c6fd:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c704:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c70b:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c712:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c719:	e9 c6 06 00 00       	jmp    0x70595880cde4
    70595880c71e:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880c725:	00 
    70595880c726:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880c72d:	c1 e9 0c             	shr    ecx,0xc
    70595880c730:	89 c9                	mov    ecx,ecx
    70595880c732:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880c736:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    70595880c73b:	48 83 f8 00          	cmp    rax,0x0
    70595880c73f:	74 1d                	je     0x70595880c75e
    70595880c741:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880c746:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880c74d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880c753:	89 c9                	mov    ecx,ecx
    70595880c755:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880c758:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    70595880c75c:	eb 5a                	jmp    0x70595880c7b8
    70595880c75e:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c765:	00 
    70595880c766:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    70595880c76d:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880c774:	00 
    70595880c775:	c7 80 bc 00 00 00 2e 	mov    DWORD PTR [rax+0xbc],0x1022e
    70595880c77c:	02 01 00 
    70595880c77f:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880c786:	00 00 00 
    70595880c789:	c7 80 34 01 00 00 14 	mov    DWORD PTR [rax+0x134],0x14
    70595880c790:	00 00 00 
    70595880c793:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880c79a:	63 00 00 
    70595880c79d:	ff d0                	call   rax
    70595880c79f:	89 c1                	mov    ecx,eax
    70595880c7a1:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c7a8:	00 
    70595880c7a9:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    70595880c7ad:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880c7b4:	75 25                	jne    0x70595880c7db
    70595880c7b6:	eb 6f                	jmp    0x70595880c827
    70595880c7b8:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    70595880c7bf:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    70595880c7c3:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    70595880c7c7:	83 c0 04             	add    eax,0x4
    70595880c7ca:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880c7ce:	83 e0 03             	and    eax,0x3
    70595880c7d1:	83 f8 00             	cmp    eax,0x0
    70595880c7d4:	75 5b                	jne    0x70595880c831
    70595880c7d6:	e9 ea 00 00 00       	jmp    0x70595880c8c5
    70595880c7db:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c7e2:	00 
    70595880c7e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c7e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c7ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c7f5:	be 14 00 00 00       	mov    esi,0x14
    70595880c7fa:	b9 04 00 00 00       	mov    ecx,0x4
    70595880c7ff:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c806:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c80d:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c814:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c81b:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c822:	e9 bd 05 00 00       	jmp    0x70595880cde4
    70595880c827:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    70595880c82b:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    70595880c82f:	eb 87                	jmp    0x70595880c7b8
    70595880c831:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880c838:	00 
    70595880c839:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880c83d:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880c844:	00 
    70595880c845:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880c84c:	02 01 00 
    70595880c84f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880c856:	00 00 00 
    70595880c859:	c7 87 34 01 00 00 14 	mov    DWORD PTR [rdi+0x134],0x14
    70595880c860:	00 00 00 
    70595880c863:	31 c0                	xor    eax,eax
    70595880c865:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880c86c:	63 00 00 
    70595880c86f:	ba 2e 02 01 00       	mov    edx,0x1022e
    70595880c874:	45 31 c0             	xor    r8d,r8d
    70595880c877:	ff d0                	call   rax
    70595880c879:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c880:	00 
    70595880c881:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c887:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c88d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c893:	be 14 00 00 00       	mov    esi,0x14
    70595880c898:	b9 04 00 00 00       	mov    ecx,0x4
    70595880c89d:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c8a4:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c8ab:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c8b2:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c8b9:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c8c0:	e9 1f 05 00 00       	jmp    0x70595880cde4
    70595880c8c5:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880c8cc:	00 
    70595880c8cd:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880c8d1:	c1 e9 0c             	shr    ecx,0xc
    70595880c8d4:	89 c9                	mov    ecx,ecx
    70595880c8d6:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880c8da:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    70595880c8df:	48 83 f8 00          	cmp    rax,0x0
    70595880c8e3:	74 1a                	je     0x70595880c8ff
    70595880c8e5:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    70595880c8ea:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880c8ee:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880c8f4:	89 c9                	mov    ecx,ecx
    70595880c8f6:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880c8f9:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880c8fd:	eb 57                	jmp    0x70595880c956
    70595880c8ff:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c906:	00 
    70595880c907:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    70595880c90b:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880c912:	00 
    70595880c913:	c7 80 bc 00 00 00 2e 	mov    DWORD PTR [rax+0xbc],0x1022e
    70595880c91a:	02 01 00 
    70595880c91d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880c924:	00 00 00 
    70595880c927:	c7 80 34 01 00 00 14 	mov    DWORD PTR [rax+0x134],0x14
    70595880c92e:	00 00 00 
    70595880c931:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880c938:	63 00 00 
    70595880c93b:	ff d0                	call   rax
    70595880c93d:	89 c1                	mov    ecx,eax
    70595880c93f:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c946:	00 
    70595880c947:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    70595880c94b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880c952:	75 2f                	jne    0x70595880c983
    70595880c954:	eb 79                	jmp    0x70595880c9cf
    70595880c956:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c95d:	00 
    70595880c95e:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    70595880c962:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880c966:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    70595880c96a:	89 54 24 48          	mov    DWORD PTR [rsp+0x48],edx
    70595880c96e:	83 c1 04             	add    ecx,0x4
    70595880c971:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    70595880c975:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    70595880c978:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    70595880c97e:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880c981:	eb 59                	jmp    0x70595880c9dc
    70595880c983:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c98a:	00 
    70595880c98b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880c991:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880c997:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880c99d:	be 14 00 00 00       	mov    esi,0x14
    70595880c9a2:	b9 04 00 00 00       	mov    ecx,0x4
    70595880c9a7:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880c9ae:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880c9b5:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880c9bc:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880c9c3:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880c9ca:	e9 15 04 00 00       	jmp    0x70595880cde4
    70595880c9cf:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    70595880c9d3:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880c9d7:	e9 7a ff ff ff       	jmp    0x70595880c956
    70595880c9dc:	eb 00                	jmp    0x70595880c9de
    70595880c9de:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880c9e5:	00 
    70595880c9e6:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    70595880c9ea:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880c9f1:	31 d1                	xor    ecx,edx
    70595880c9f3:	89 08                	mov    DWORD PTR [rax],ecx
    70595880c9f5:	83 f9 00             	cmp    ecx,0x0
    70595880c9f8:	0f 94 c2             	sete   dl
    70595880c9fb:	80 e2 01             	and    dl,0x1
    70595880c9fe:	0f b6 d2             	movzx  edx,dl
    70595880ca01:	c1 e9 1f             	shr    ecx,0x1f
    70595880ca04:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880ca0a:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    70595880ca10:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880ca17:	00 00 00 
    70595880ca1a:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880ca21:	00 00 00 
    70595880ca24:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880ca2b:	00 00 00 
    70595880ca2e:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880ca35:	00 00 00 
    70595880ca38:	eb 00                	jmp    0x70595880ca3a
    70595880ca3a:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    70595880ca3e:	83 e0 03             	and    eax,0x3
    70595880ca41:	83 f8 00             	cmp    eax,0x0
    70595880ca44:	0f 84 94 00 00 00    	je     0x70595880cade
    70595880ca4a:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880ca51:	00 
    70595880ca52:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880ca56:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
    70595880ca5d:	00 
    70595880ca5e:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10234
    70595880ca65:	02 01 00 
    70595880ca68:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ca6f:	00 00 00 
    70595880ca72:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    70595880ca79:	00 00 00 
    70595880ca7c:	31 c0                	xor    eax,eax
    70595880ca7e:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ca85:	63 00 00 
    70595880ca88:	ba 34 02 01 00       	mov    edx,0x10234
    70595880ca8d:	45 31 c0             	xor    r8d,r8d
    70595880ca90:	ff d0                	call   rax
    70595880ca92:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880ca99:	00 
    70595880ca9a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880caa0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880caa6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880caac:	be 16 00 00 00       	mov    esi,0x16
    70595880cab1:	b9 02 00 00 00       	mov    ecx,0x2
    70595880cab6:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880cabd:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880cac4:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880cacb:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880cad2:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880cad9:	e9 06 03 00 00       	jmp    0x70595880cde4
    70595880cade:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880cae5:	00 
    70595880cae6:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880caea:	c1 e9 0c             	shr    ecx,0xc
    70595880caed:	89 c9                	mov    ecx,ecx
    70595880caef:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880caf3:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    70595880caf8:	48 83 f8 00          	cmp    rax,0x0
    70595880cafc:	74 1a                	je     0x70595880cb18
    70595880cafe:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    70595880cb03:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880cb07:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880cb0d:	89 c9                	mov    ecx,ecx
    70595880cb0f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880cb12:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    70595880cb16:	eb 57                	jmp    0x70595880cb6f
    70595880cb18:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cb1f:	00 
    70595880cb20:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    70595880cb24:	48 8b bc 24 20 01 00 	mov    rdi,QWORD PTR [rsp+0x120]
    70595880cb2b:	00 
    70595880cb2c:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10234
    70595880cb33:	02 01 00 
    70595880cb36:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880cb3d:	00 00 00 
    70595880cb40:	c7 80 34 01 00 00 16 	mov    DWORD PTR [rax+0x134],0x16
    70595880cb47:	00 00 00 
    70595880cb4a:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880cb51:	63 00 00 
    70595880cb54:	ff d0                	call   rax
    70595880cb56:	89 c1                	mov    ecx,eax
    70595880cb58:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cb5f:	00 
    70595880cb60:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    70595880cb64:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880cb6b:	75 1d                	jne    0x70595880cb8a
    70595880cb6d:	eb 67                	jmp    0x70595880cbd6
    70595880cb6f:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cb76:	00 
    70595880cb77:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880cb7b:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    70595880cb7f:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    70595880cb82:	83 c1 04             	add    ecx,0x4
    70595880cb85:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880cb88:	eb 56                	jmp    0x70595880cbe0
    70595880cb8a:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cb91:	00 
    70595880cb92:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880cb98:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880cb9e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880cba4:	be 16 00 00 00       	mov    esi,0x16
    70595880cba9:	b9 02 00 00 00       	mov    ecx,0x2
    70595880cbae:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880cbb5:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880cbbc:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880cbc3:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880cbca:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880cbd1:	e9 0e 02 00 00       	jmp    0x70595880cde4
    70595880cbd6:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    70595880cbda:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    70595880cbde:	eb 8f                	jmp    0x70595880cb6f
    70595880cbe0:	eb 00                	jmp    0x70595880cbe2
    70595880cbe2:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    70595880cbe6:	83 e0 01             	and    eax,0x1
    70595880cbe9:	83 f8 00             	cmp    eax,0x0
    70595880cbec:	75 3a                	jne    0x70595880cc28
    70595880cbee:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    70595880cbf2:	be 17 00 00 00       	mov    esi,0x17
    70595880cbf7:	b9 02 00 00 00       	mov    ecx,0x2
    70595880cbfc:	b0 01                	mov    al,0x1
    70595880cbfe:	89 d7                	mov    edi,edx
    70595880cc00:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880cc07:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880cc0e:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880cc15:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880cc1c:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880cc23:	e9 bc 01 00 00       	jmp    0x70595880cde4
    70595880cc28:	48 8b bc 24 28 01 00 	mov    rdi,QWORD PTR [rsp+0x128]
    70595880cc2f:	00 
    70595880cc30:	48 8b 94 24 20 01 00 	mov    rdx,QWORD PTR [rsp+0x120]
    70595880cc37:	00 
    70595880cc38:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10236
    70595880cc3f:	02 01 00 
    70595880cc42:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880cc49:	00 00 00 
    70595880cc4c:	c7 87 34 01 00 00 17 	mov    DWORD PTR [rdi+0x134],0x17
    70595880cc53:	00 00 00 
    70595880cc56:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880cc5d:	63 00 00 
    70595880cc60:	be 2a 00 00 00       	mov    esi,0x2a
    70595880cc65:	ff d0                	call   rax
    70595880cc67:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cc6e:	00 
    70595880cc6f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880cc75:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880cc7b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880cc81:	be 17 00 00 00       	mov    esi,0x17
    70595880cc86:	b9 02 00 00 00       	mov    ecx,0x2
    70595880cc8b:	89 bc 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],edi
    70595880cc92:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    70595880cc99:	89 94 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],edx
    70595880cca0:	89 8c 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],ecx
    70595880cca7:	88 84 24 0b 01 00 00 	mov    BYTE PTR [rsp+0x10b],al
    70595880ccae:	e9 31 01 00 00       	jmp    0x70595880cde4
    70595880ccb3:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880ccba:	00 
    70595880ccbb:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880ccc2:	e9 0f 02 00 00       	jmp    0x70595880ced6
    70595880ccc7:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    70595880ccce:	00 
    70595880cccf:	48 89 c1             	mov    rcx,rax
    70595880ccd2:	48 81 c1 70 11 08 00 	add    rcx,0x81170
    70595880ccd9:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    70595880ccde:	81 b8 70 11 08 00 2e 	cmp    DWORD PTR [rax+0x81170],0x1022e
    70595880cce5:	02 01 00 
    70595880cce8:	74 32                	je     0x70595880cd1c
    70595880ccea:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880ccf1:	00 
    70595880ccf2:	c7 80 bc 00 00 00 2e 	mov    DWORD PTR [rax+0xbc],0x1022e
    70595880ccf9:	02 01 00 
    70595880ccfc:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880cd03:	00 00 00 
    70595880cd06:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    70595880cd0d:	00 00 00 
    70595880cd10:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880cd17:	e9 ba 01 00 00       	jmp    0x70595880ced6
    70595880cd1c:	4c 8b b4 24 20 01 00 	mov    r14,QWORD PTR [rsp+0x120]
    70595880cd23:	00 
    70595880cd24:	4c 8b ac 24 28 01 00 	mov    r13,QWORD PTR [rsp+0x128]
    70595880cd2b:	00 
    70595880cd2c:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    70595880cd31:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    70595880cd38:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1022e
    70595880cd3f:	2e 02 01 00 
    70595880cd43:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880cd4a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880cd4e:	48 81 c4 48 01 00 00 	add    rsp,0x148
    70595880cd55:	ff e0                	jmp    rax
    70595880cd57:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    70595880cd5e:	00 
    70595880cd5f:	48 89 c1             	mov    rcx,rax
    70595880cd62:	48 81 c1 f0 10 08 00 	add    rcx,0x810f0
    70595880cd69:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    70595880cd6e:	81 b8 f0 10 08 00 1e 	cmp    DWORD PTR [rax+0x810f0],0x1021e
    70595880cd75:	02 01 00 
    70595880cd78:	74 32                	je     0x70595880cdac
    70595880cd7a:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880cd81:	00 
    70595880cd82:	c7 80 bc 00 00 00 1e 	mov    DWORD PTR [rax+0xbc],0x1021e
    70595880cd89:	02 01 00 
    70595880cd8c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880cd93:	00 00 00 
    70595880cd96:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    70595880cd9d:	00 00 00 
    70595880cda0:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880cda7:	e9 2a 01 00 00       	jmp    0x70595880ced6
    70595880cdac:	4c 8b b4 24 20 01 00 	mov    r14,QWORD PTR [rsp+0x120]
    70595880cdb3:	00 
    70595880cdb4:	4c 8b ac 24 28 01 00 	mov    r13,QWORD PTR [rsp+0x128]
    70595880cdbb:	00 
    70595880cdbc:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880cdc1:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    70595880cdc5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1021e
    70595880cdcc:	1e 02 01 00 
    70595880cdd0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880cdd7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880cddb:	48 81 c4 48 01 00 00 	add    rsp,0x148
    70595880cde2:	ff e0                	jmp    rax
    70595880cde4:	48 8b 8c 24 28 01 00 	mov    rcx,QWORD PTR [rsp+0x128]
    70595880cdeb:	00 
    70595880cdec:	8b 94 24 f8 00 00 00 	mov    edx,DWORD PTR [rsp+0xf8]
    70595880cdf3:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    70595880cdfa:	8b b4 24 00 01 00 00 	mov    esi,DWORD PTR [rsp+0x100]
    70595880ce01:	8b bc 24 04 01 00 00 	mov    edi,DWORD PTR [rsp+0x104]
    70595880ce08:	8a 9c 24 0b 01 00 00 	mov    bl,BYTE PTR [rsp+0x10b]
    70595880ce0f:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    70595880ce13:	89 c3                	mov    ebx,eax
    70595880ce15:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    70595880ce19:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    70595880ce1d:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    70595880ce21:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    70595880ce25:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880ce2b:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    70595880ce2f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880ce35:	73 2d                	jae    0x70595880ce64
    70595880ce37:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    70595880ce3e:	00 
    70595880ce3f:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880ce43:	89 d1                	mov    ecx,edx
    70595880ce45:	c1 e9 01             	shr    ecx,0x1
    70595880ce48:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880ce4e:	89 c9                	mov    ecx,ecx
    70595880ce50:	48 c1 e1 04          	shl    rcx,0x4
    70595880ce54:	48 89 c6             	mov    rsi,rax
    70595880ce57:	48 01 ce             	add    rsi,rcx
    70595880ce5a:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    70595880ce5f:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880ce62:	74 32                	je     0x70595880ce96
    70595880ce64:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    70595880ce6b:	00 
    70595880ce6c:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    70595880ce70:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595880ce74:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    70595880ce78:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    70595880ce7c:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    70595880ce82:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    70595880ce88:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    70595880ce8e:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595880ce94:	eb 40                	jmp    0x70595880ced6
    70595880ce96:	4c 8b b4 24 20 01 00 	mov    r14,QWORD PTR [rsp+0x120]
    70595880ce9d:	00 
    70595880ce9e:	4c 8b ac 24 28 01 00 	mov    r13,QWORD PTR [rsp+0x128]
    70595880cea5:	00 
    70595880cea6:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    70595880ceab:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    70595880ceaf:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880ceb3:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    70595880ceba:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880cec1:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880cec8:	00 
    70595880cec9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880cecd:	48 81 c4 48 01 00 00 	add    rsp,0x148
    70595880ced4:	ff e0                	jmp    rax
    70595880ced6:	48 81 c4 48 01 00 00 	add    rsp,0x148
    70595880cedd:	c2 08 00             	ret    0x8
