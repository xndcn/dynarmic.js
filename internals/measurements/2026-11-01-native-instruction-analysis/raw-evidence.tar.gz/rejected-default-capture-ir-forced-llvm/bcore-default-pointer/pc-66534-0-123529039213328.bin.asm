
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66534-0-123529039213328.bin:     file format binary


Disassembly of section .data:

0000705958807310 <.data>:
    705958807310:	48 81 ec d8 00 00 00 	sub    rsp,0xd8
    705958807317:	4c 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r14
    70595880731e:	00 
    70595880731f:	4c 89 ac 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r13
    705958807326:	00 
    705958807327:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880732e:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    705958807335:	00 
    705958807336:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    70595880733d:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    705958807344:	00 
    705958807345:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880734c:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    705958807353:	00 
    705958807354:	48 8b 94 24 b8 00 00 	mov    rdx,QWORD PTR [rsp+0xb8]
    70595880735b:	00 
    70595880735c:	8b 8a a0 00 00 00    	mov    ecx,DWORD PTR [rdx+0xa0]
    705958807362:	83 f9 00             	cmp    ecx,0x0
    705958807365:	0f 94 c0             	sete   al
    705958807368:	81 e9 e6 03 01 00    	sub    ecx,0x103e6
    70595880736e:	83 f9 28             	cmp    ecx,0x28
    705958807371:	0f 97 c1             	seta   cl
    705958807374:	08 c8                	or     al,cl
    705958807376:	24 01                	and    al,0x1
    705958807378:	81 ba a4 00 00 00 fa 	cmp    DWORD PTR [rdx+0xa4],0x103fa
    70595880737f:	03 01 00 
    705958807382:	0f 94 c1             	sete   cl
    705958807385:	81 ba 94 00 00 00 e6 	cmp    DWORD PTR [rdx+0x94],0x103e6
    70595880738c:	03 01 00 
    70595880738f:	0f 94 c2             	sete   dl
    705958807392:	20 d1                	and    cl,dl
    705958807394:	20 c8                	and    al,cl
    705958807396:	a8 01                	test   al,0x1
    705958807398:	75 05                	jne    0x70595880739f
    70595880739a:	e9 68 0b 00 00       	jmp    0x705958807f07
    70595880739f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588073a6:	00 
    7059588073a7:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    7059588073ae:	48 89 c8             	mov    rax,rcx
    7059588073b1:	48 05 00 00 10 00    	add    rax,0x100000
    7059588073b7:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    7059588073be:	00 
    7059588073bf:	8b 81 18 00 10 00    	mov    eax,DWORD PTR [rcx+0x100018]
    7059588073c5:	83 c0 01             	add    eax,0x1
    7059588073c8:	89 81 18 00 10 00    	mov    DWORD PTR [rcx+0x100018],eax
    7059588073ce:	3d 30 75 00 00       	cmp    eax,0x7530
    7059588073d3:	75 4c                	jne    0x705958807421
    7059588073d5:	48 8b 8c 24 a8 00 00 	mov    rcx,QWORD PTR [rsp+0xa8]
    7059588073dc:	00 
    7059588073dd:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    7059588073e3:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    7059588073ea:	89 c2                	mov    edx,eax
    7059588073ec:	83 c2 01             	add    edx,0x1
    7059588073ef:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    7059588073f5:	3d 00 01 00 00       	cmp    eax,0x100
    7059588073fa:	73 23                	jae    0x70595880741f
    7059588073fc:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    705958807403:	00 
    705958807404:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880740b:	89 c9                	mov    ecx,ecx
    70595880740d:	48 c1 e1 02          	shl    rcx,0x2
    705958807411:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958807418:	c7 04 08 06 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x6
    70595880741f:	eb 00                	jmp    0x705958807421
    705958807421:	eb 00                	jmp    0x705958807423
    705958807423:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880742a:	00 
    70595880742b:	8b 48 08             	mov    ecx,DWORD PTR [rax+0x8]
    70595880742e:	0f af 48 18          	imul   ecx,DWORD PTR [rax+0x18]
    705958807432:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    705958807439:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    70595880743c:	8b 80 a0 00 00 00    	mov    eax,DWORD PTR [rax+0xa0]
    705958807442:	89 84 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],eax
    705958807449:	eb 00                	jmp    0x70595880744b
    70595880744b:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807452:	00 
    705958807453:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    70595880745a:	8b 78 1c             	mov    edi,DWORD PTR [rax+0x1c]
    70595880745d:	89 ca                	mov    edx,ecx
    70595880745f:	01 fa                	add    edx,edi
    705958807461:	89 94 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],edx
    705958807468:	89 50 08             	mov    DWORD PTR [rax+0x8],edx
    70595880746b:	89 ce                	mov    esi,ecx
    70595880746d:	c1 ee 1f             	shr    esi,0x1f
    705958807470:	89 fb                	mov    ebx,edi
    705958807472:	c1 eb 1f             	shr    ebx,0x1f
    705958807475:	89 d5                	mov    ebp,edx
    705958807477:	c1 ed 1f             	shr    ebp,0x1f
    70595880747a:	31 eb                	xor    ebx,ebp
    70595880747c:	31 ee                	xor    esi,ebp
    70595880747e:	21 de                	and    esi,ebx
    705958807480:	83 f1 ff             	xor    ecx,0xffffffff
    705958807483:	39 f9                	cmp    ecx,edi
    705958807485:	0f 92 c1             	setb   cl
    705958807488:	80 e1 01             	and    cl,0x1
    70595880748b:	0f b6 c9             	movzx  ecx,cl
    70595880748e:	83 fa 00             	cmp    edx,0x0
    705958807491:	0f 94 c3             	sete   bl
    705958807494:	80 e3 01             	and    bl,0x1
    705958807497:	0f b6 fb             	movzx  edi,bl
    70595880749a:	c1 ea 1f             	shr    edx,0x1f
    70595880749d:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    7059588074a3:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    7059588074a9:	89 f2                	mov    edx,esi
    7059588074ab:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    7059588074b1:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    7059588074b7:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    7059588074bd:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    7059588074c3:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    7059588074c9:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    7059588074cf:	eb 00                	jmp    0x7059588074d1
    7059588074d1:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588074d8:	00 
    7059588074d9:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    7059588074e0:	c1 e9 08             	shr    ecx,0x8
    7059588074e3:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    7059588074ea:	89 08                	mov    DWORD PTR [rax],ecx
    7059588074ec:	83 f9 00             	cmp    ecx,0x0
    7059588074ef:	0f 94 c2             	sete   dl
    7059588074f2:	80 e2 01             	and    dl,0x1
    7059588074f5:	0f b6 d2             	movzx  edx,dl
    7059588074f8:	c1 e9 1f             	shr    ecx,0x1f
    7059588074fb:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    705958807501:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    705958807507:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880750e:	00 00 00 
    705958807511:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    705958807518:	00 00 00 
    70595880751b:	eb 00                	jmp    0x70595880751d
    70595880751d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807524:	00 
    705958807525:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880752c:	23 48 0c             	and    ecx,DWORD PTR [rax+0xc]
    70595880752f:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    705958807536:	89 08                	mov    DWORD PTR [rax],ecx
    705958807538:	83 f9 00             	cmp    ecx,0x0
    70595880753b:	0f 94 c2             	sete   dl
    70595880753e:	80 e2 01             	and    dl,0x1
    705958807541:	0f b6 d2             	movzx  edx,dl
    705958807544:	c1 e9 1f             	shr    ecx,0x1f
    705958807547:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880754d:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    705958807553:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880755a:	00 00 00 
    70595880755d:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    705958807564:	00 00 00 
    705958807567:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880756e:	00 00 00 
    705958807571:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    705958807578:	00 00 00 
    70595880757b:	eb 00                	jmp    0x70595880757d
    70595880757d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807584:	00 
    705958807585:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    70595880758c:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    70595880758f:	eb 00                	jmp    0x705958807591
    705958807591:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807598:	00 
    705958807599:	8b 40 50             	mov    eax,DWORD PTR [rax+0x50]
    70595880759c:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    7059588075a3:	83 e0 03             	and    eax,0x3
    7059588075a6:	83 f8 00             	cmp    eax,0x0
    7059588075a9:	74 7d                	je     0x705958807628
    7059588075ab:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    7059588075b2:	00 
    7059588075b3:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    7059588075ba:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    7059588075c1:	00 
    7059588075c2:	c7 87 bc 00 00 00 f2 	mov    DWORD PTR [rdi+0xbc],0x103f2
    7059588075c9:	03 01 00 
    7059588075cc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588075d3:	00 00 00 
    7059588075d6:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    7059588075dd:	00 00 00 
    7059588075e0:	31 c0                	xor    eax,eax
    7059588075e2:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588075e9:	63 00 00 
    7059588075ec:	ba f2 03 01 00       	mov    edx,0x103f2
    7059588075f1:	45 31 c0             	xor    r8d,r8d
    7059588075f4:	ff d0                	call   rax
    7059588075f6:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588075fd:	00 
    7059588075fe:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807604:	b9 06 00 00 00       	mov    ecx,0x6
    705958807609:	b8 02 00 00 00       	mov    eax,0x2
    70595880760e:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807615:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    70595880761c:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807623:	e9 81 09 00 00       	jmp    0x705958807fa9
    705958807628:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880762f:	00 
    705958807630:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    705958807637:	c1 e9 0c             	shr    ecx,0xc
    70595880763a:	89 c9                	mov    ecx,ecx
    70595880763c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958807640:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    705958807645:	48 83 f8 00          	cmp    rax,0x0
    705958807649:	74 1d                	je     0x705958807668
    70595880764b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807650:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    705958807657:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880765d:	89 c9                	mov    ecx,ecx
    70595880765f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958807662:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    705958807666:	eb 61                	jmp    0x7059588076c9
    705958807668:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880766f:	00 
    705958807670:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    705958807677:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    70595880767e:	00 
    70595880767f:	c7 80 bc 00 00 00 f2 	mov    DWORD PTR [rax+0xbc],0x103f2
    705958807686:	03 01 00 
    705958807689:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958807690:	00 00 00 
    705958807693:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    70595880769a:	00 00 00 
    70595880769d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588076a4:	63 00 00 
    7059588076a7:	ff d0                	call   rax
    7059588076a9:	89 c1                	mov    ecx,eax
    7059588076ab:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588076b2:	00 
    7059588076b3:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588076b7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588076be:	0f 85 d6 00 00 00    	jne    0x70595880779a
    7059588076c4:	e9 03 01 00 00       	jmp    0x7059588077cc
    7059588076c9:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588076d0:	00 
    7059588076d1:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    7059588076d8:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    7059588076dc:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    7059588076e0:	89 08                	mov    DWORD PTR [rax],ecx
    7059588076e2:	8b 88 80 00 00 00    	mov    ecx,DWORD PTR [rax+0x80]
    7059588076e8:	8b 68 70             	mov    ebp,DWORD PTR [rax+0x70]
    7059588076eb:	89 d2                	mov    edx,edx
    7059588076ed:	41 89 d0             	mov    r8d,edx
    7059588076f0:	89 c9                	mov    ecx,ecx
    7059588076f2:	41 89 c9             	mov    r9d,ecx
    7059588076f5:	89 e9                	mov    ecx,ebp
    7059588076f7:	4c 89 c6             	mov    rsi,r8
    7059588076fa:	48 83 c6 04          	add    rsi,0x4
    7059588076fe:	89 f7                	mov    edi,esi
    705958807700:	89 7c 24 6c          	mov    DWORD PTR [rsp+0x6c],edi
    705958807704:	4d 89 cb             	mov    r11,r9
    705958807707:	49 01 cb             	add    r11,rcx
    70595880770a:	44 89 d9             	mov    ecx,r11d
    70595880770d:	48 89 f2             	mov    rdx,rsi
    705958807710:	4c 29 ca             	sub    rdx,r9
    705958807713:	89 d3                	mov    ebx,edx
    705958807715:	48 ba 00 00 00 00 01 	movabs rdx,0x100000000
    70595880771c:	00 00 00 
    70595880771f:	49 89 f2             	mov    r10,rsi
    705958807722:	49 21 d2             	and    r10,rdx
    705958807725:	48 ba 00 00 00 00 01 	movabs rdx,0x100000000
    70595880772c:	00 00 00 
    70595880772f:	49 21 d3             	and    r11,rdx
    705958807732:	39 cf                	cmp    edi,ecx
    705958807734:	89 da                	mov    edx,ebx
    705958807736:	0f 42 d7             	cmovb  edx,edi
    705958807739:	39 cf                	cmp    edi,ecx
    70595880773b:	89 f9                	mov    ecx,edi
    70595880773d:	0f 42 cb             	cmovb  ecx,ebx
    705958807740:	4d 39 da             	cmp    r10,r11
    705958807743:	0f 44 ca             	cmove  ecx,edx
    705958807746:	48 89 f2             	mov    rdx,rsi
    705958807749:	4c 01 ca             	add    rdx,r9
    70595880774c:	49 b9 00 00 00 80 00 	movabs r9,0x80000000
    705958807753:	00 00 00 
    705958807756:	4d 21 c8             	and    r8,r9
    705958807759:	49 83 f8 00          	cmp    r8,0x0
    70595880775d:	0f 95 c3             	setne  bl
    705958807760:	49 b8 00 00 00 00 01 	movabs r8,0x100000000
    705958807767:	00 00 00 
    70595880776a:	4c 21 c6             	and    rsi,r8
    70595880776d:	48 83 fe 00          	cmp    rsi,0x0
    705958807771:	40 0f 95 c6          	setne  sil
    705958807775:	40 08 f3             	or     bl,sil
    705958807778:	39 ef                	cmp    edi,ebp
    70595880777a:	89 fe                	mov    esi,edi
    70595880777c:	0f 42 f2             	cmovb  esi,edx
    70595880777f:	39 ef                	cmp    edi,ebp
    705958807781:	0f 42 d7             	cmovb  edx,edi
    705958807784:	f6 c3 01             	test   bl,0x1
    705958807787:	0f 45 d6             	cmovne edx,esi
    70595880778a:	31 f6                	xor    esi,esi
    70595880778c:	40 88 f3             	mov    bl,sil
    70595880778f:	f6 c3 01             	test   bl,0x1
    705958807792:	0f 45 ca             	cmovne ecx,edx
    705958807795:	89 48 50             	mov    DWORD PTR [rax+0x50],ecx
    705958807798:	eb 3f                	jmp    0x7059588077d9
    70595880779a:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588077a1:	00 
    7059588077a2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588077a8:	b9 06 00 00 00       	mov    ecx,0x6
    7059588077ad:	b8 02 00 00 00       	mov    eax,0x2
    7059588077b2:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    7059588077b9:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    7059588077c0:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    7059588077c7:	e9 dd 07 00 00       	jmp    0x705958807fa9
    7059588077cc:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    7059588077d0:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588077d4:	e9 f0 fe ff ff       	jmp    0x7059588076c9
    7059588077d9:	eb 00                	jmp    0x7059588077db
    7059588077db:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588077e2:	00 
    7059588077e3:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    7059588077ea:	c1 e1 02             	shl    ecx,0x2
    7059588077ed:	03 48 20             	add    ecx,DWORD PTR [rax+0x20]
    7059588077f0:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    7059588077f4:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    7059588077f7:	eb 00                	jmp    0x7059588077f9
    7059588077f9:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    7059588077fd:	83 e0 03             	and    eax,0x3
    705958807800:	83 f8 00             	cmp    eax,0x0
    705958807803:	74 7a                	je     0x70595880787f
    705958807805:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    70595880780c:	00 
    70595880780d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958807811:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    705958807818:	00 
    705958807819:	c7 87 bc 00 00 00 f6 	mov    DWORD PTR [rdi+0xbc],0x103f6
    705958807820:	03 01 00 
    705958807823:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880782a:	00 00 00 
    70595880782d:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    705958807834:	00 00 00 
    705958807837:	31 c0                	xor    eax,eax
    705958807839:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958807840:	63 00 00 
    705958807843:	ba f6 03 01 00       	mov    edx,0x103f6
    705958807848:	45 31 c0             	xor    r8d,r8d
    70595880784b:	ff d0                	call   rax
    70595880784d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807854:	00 
    705958807855:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880785b:	b9 08 00 00 00       	mov    ecx,0x8
    705958807860:	b8 02 00 00 00       	mov    eax,0x2
    705958807865:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    70595880786c:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807873:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    70595880787a:	e9 2a 07 00 00       	jmp    0x705958807fa9
    70595880787f:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    705958807886:	00 
    705958807887:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880788b:	c1 e9 0c             	shr    ecx,0xc
    70595880788e:	89 c9                	mov    ecx,ecx
    705958807890:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958807894:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958807899:	48 83 f8 00          	cmp    rax,0x0
    70595880789d:	74 1a                	je     0x7059588078b9
    70595880789f:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    7059588078a4:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    7059588078a8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588078ae:	89 c9                	mov    ecx,ecx
    7059588078b0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588078b3:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    7059588078b7:	eb 57                	jmp    0x705958807910
    7059588078b9:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588078c0:	00 
    7059588078c1:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    7059588078c5:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    7059588078cc:	00 
    7059588078cd:	c7 80 bc 00 00 00 f6 	mov    DWORD PTR [rax+0xbc],0x103f6
    7059588078d4:	03 01 00 
    7059588078d7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588078de:	00 00 00 
    7059588078e1:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    7059588078e8:	00 00 00 
    7059588078eb:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588078f2:	63 00 00 
    7059588078f5:	ff d0                	call   rax
    7059588078f7:	89 c1                	mov    ecx,eax
    7059588078f9:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807900:	00 
    705958807901:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    705958807905:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880790c:	75 17                	jne    0x705958807925
    70595880790e:	eb 47                	jmp    0x705958807957
    705958807910:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807917:	00 
    705958807918:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880791c:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    705958807920:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    705958807923:	eb 3c                	jmp    0x705958807961
    705958807925:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880792c:	00 
    70595880792d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807933:	b9 08 00 00 00       	mov    ecx,0x8
    705958807938:	b8 02 00 00 00       	mov    eax,0x2
    70595880793d:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807944:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    70595880794b:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807952:	e9 52 06 00 00       	jmp    0x705958807fa9
    705958807957:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    70595880795b:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880795f:	eb af                	jmp    0x705958807910
    705958807961:	eb 00                	jmp    0x705958807963
    705958807963:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880796a:	00 
    70595880796b:	8b 40 2c             	mov    eax,DWORD PTR [rax+0x2c]
    70595880796e:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    705958807972:	83 e0 03             	and    eax,0x3
    705958807975:	83 f8 00             	cmp    eax,0x0
    705958807978:	74 7b                	je     0x7059588079f5
    70595880797a:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807981:	00 
    705958807982:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    705958807986:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    70595880798d:	00 
    70595880798e:	c7 87 bc 00 00 00 f8 	mov    DWORD PTR [rdi+0xbc],0x103f8
    705958807995:	03 01 00 
    705958807998:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880799f:	00 00 00 
    7059588079a2:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    7059588079a9:	00 00 00 
    7059588079ac:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588079b3:	63 00 00 
    7059588079b6:	ba f8 03 01 00       	mov    edx,0x103f8
    7059588079bb:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588079c1:	ff d0                	call   rax
    7059588079c3:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    7059588079ca:	00 
    7059588079cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588079d1:	b9 09 00 00 00       	mov    ecx,0x9
    7059588079d6:	b8 02 00 00 00       	mov    eax,0x2
    7059588079db:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    7059588079e2:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    7059588079e9:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    7059588079f0:	e9 b4 05 00 00       	jmp    0x705958807fa9
    7059588079f5:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    7059588079fc:	00 
    7059588079fd:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    705958807a01:	c1 e9 0c             	shr    ecx,0xc
    705958807a04:	89 c9                	mov    ecx,ecx
    705958807a06:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958807a0a:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    705958807a0f:	48 83 f8 00          	cmp    rax,0x0
    705958807a13:	74 1a                	je     0x705958807a2f
    705958807a15:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    705958807a1a:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    705958807a1e:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    705958807a22:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958807a28:	89 c9                	mov    ecx,ecx
    705958807a2a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958807a2d:	eb 55                	jmp    0x705958807a84
    705958807a2f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807a36:	00 
    705958807a37:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    705958807a3b:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    705958807a3f:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    705958807a46:	00 
    705958807a47:	c7 80 bc 00 00 00 f8 	mov    DWORD PTR [rax+0xbc],0x103f8
    705958807a4e:	03 01 00 
    705958807a51:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958807a58:	00 00 00 
    705958807a5b:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    705958807a62:	00 00 00 
    705958807a65:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958807a6c:	63 00 00 
    705958807a6f:	ff d0                	call   rax
    705958807a71:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807a78:	00 
    705958807a79:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958807a80:	75 27                	jne    0x705958807aa9
    705958807a82:	eb 57                	jmp    0x705958807adb
    705958807a84:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    705958807a8b:	00 
    705958807a8c:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807a93:	00 
    705958807a94:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    705958807a98:	83 c2 04             	add    edx,0x4
    705958807a9b:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    705958807a9f:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    705958807aa2:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958807aa5:	75 36                	jne    0x705958807add
    705958807aa7:	eb 79                	jmp    0x705958807b22
    705958807aa9:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807ab0:	00 
    705958807ab1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807ab7:	b9 09 00 00 00       	mov    ecx,0x9
    705958807abc:	b8 02 00 00 00       	mov    eax,0x2
    705958807ac1:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807ac8:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807acf:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807ad6:	e9 ce 04 00 00       	jmp    0x705958807fa9
    705958807adb:	eb a7                	jmp    0x705958807a84
    705958807add:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807ae4:	00 
    705958807ae5:	c7 87 bc 00 00 00 fa 	mov    DWORD PTR [rdi+0xbc],0x103fa
    705958807aec:	03 01 00 
    705958807aef:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958807af6:	00 00 00 
    705958807af9:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    705958807b00:	00 00 00 
    705958807b03:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958807b0a:	63 00 00 
    705958807b0d:	ff d0                	call   rax
    705958807b0f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807b16:	00 
    705958807b17:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958807b1e:	75 04                	jne    0x705958807b24
    705958807b20:	eb 34                	jmp    0x705958807b56
    705958807b22:	eb 34                	jmp    0x705958807b58
    705958807b24:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807b2b:	00 
    705958807b2c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807b32:	b9 09 00 00 00       	mov    ecx,0x9
    705958807b37:	b8 02 00 00 00       	mov    eax,0x2
    705958807b3c:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807b43:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807b4a:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807b51:	e9 53 04 00 00       	jmp    0x705958807fa9
    705958807b56:	eb ca                	jmp    0x705958807b22
    705958807b58:	eb 00                	jmp    0x705958807b5a
    705958807b5a:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    705958807b5e:	83 e0 03             	and    eax,0x3
    705958807b61:	83 f8 00             	cmp    eax,0x0
    705958807b64:	74 7b                	je     0x705958807be1
    705958807b66:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807b6d:	00 
    705958807b6e:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958807b72:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    705958807b79:	00 
    705958807b7a:	c7 87 bc 00 00 00 fa 	mov    DWORD PTR [rdi+0xbc],0x103fa
    705958807b81:	03 01 00 
    705958807b84:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958807b8b:	00 00 00 
    705958807b8e:	c7 87 34 01 00 00 0a 	mov    DWORD PTR [rdi+0x134],0xa
    705958807b95:	00 00 00 
    705958807b98:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958807b9f:	63 00 00 
    705958807ba2:	ba fa 03 01 00       	mov    edx,0x103fa
    705958807ba7:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958807bad:	ff d0                	call   rax
    705958807baf:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807bb6:	00 
    705958807bb7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807bbd:	b9 0a 00 00 00       	mov    ecx,0xa
    705958807bc2:	b8 02 00 00 00       	mov    eax,0x2
    705958807bc7:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807bce:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807bd5:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807bdc:	e9 c8 03 00 00       	jmp    0x705958807fa9
    705958807be1:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    705958807be8:	00 
    705958807be9:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958807bed:	c1 e9 0c             	shr    ecx,0xc
    705958807bf0:	89 c9                	mov    ecx,ecx
    705958807bf2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958807bf6:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    705958807bfb:	48 83 f8 00          	cmp    rax,0x0
    705958807bff:	74 1a                	je     0x705958807c1b
    705958807c01:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958807c06:	8b 54 24 68          	mov    edx,DWORD PTR [rsp+0x68]
    705958807c0a:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958807c0e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958807c14:	89 c9                	mov    ecx,ecx
    705958807c16:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958807c19:	eb 55                	jmp    0x705958807c70
    705958807c1b:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807c22:	00 
    705958807c23:	8b 54 24 68          	mov    edx,DWORD PTR [rsp+0x68]
    705958807c27:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    705958807c2b:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    705958807c32:	00 
    705958807c33:	c7 80 bc 00 00 00 fa 	mov    DWORD PTR [rax+0xbc],0x103fa
    705958807c3a:	03 01 00 
    705958807c3d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958807c44:	00 00 00 
    705958807c47:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    705958807c4e:	00 00 00 
    705958807c51:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958807c58:	63 00 00 
    705958807c5b:	ff d0                	call   rax
    705958807c5d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807c64:	00 
    705958807c65:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958807c6c:	75 1b                	jne    0x705958807c89
    705958807c6e:	eb 4b                	jmp    0x705958807cbb
    705958807c70:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807c77:	00 
    705958807c78:	8b 80 9c 00 00 00    	mov    eax,DWORD PTR [rax+0x9c]
    705958807c7e:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    705958807c82:	83 f8 01             	cmp    eax,0x1
    705958807c85:	77 3b                	ja     0x705958807cc2
    705958807c87:	eb 6e                	jmp    0x705958807cf7
    705958807c89:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807c90:	00 
    705958807c91:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807c97:	b9 0a 00 00 00       	mov    ecx,0xa
    705958807c9c:	b8 02 00 00 00       	mov    eax,0x2
    705958807ca1:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807ca8:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807caf:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807cb6:	e9 ee 02 00 00       	jmp    0x705958807fa9
    705958807cbb:	eb b3                	jmp    0x705958807c70
    705958807cbd:	e9 2d 01 00 00       	jmp    0x705958807def
    705958807cc2:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    705958807cc9:	00 
    705958807cca:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807cd1:	00 
    705958807cd2:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    705958807cd6:	83 ea 01             	sub    edx,0x1
    705958807cd9:	89 91 9c 00 00 00    	mov    DWORD PTR [rcx+0x9c],edx
    705958807cdf:	c7 81 bc 00 00 00 e6 	mov    DWORD PTR [rcx+0xbc],0x103e6
    705958807ce6:	03 01 00 
    705958807ce9:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    705958807cf0:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958807cf3:	75 26                	jne    0x705958807d1b
    705958807cf5:	eb 4c                	jmp    0x705958807d43
    705958807cf7:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    705958807cfe:	00 
    705958807cff:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807d06:	00 
    705958807d07:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x0
    705958807d0e:	00 00 00 
    705958807d11:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958807d14:	75 5f                	jne    0x705958807d75
    705958807d16:	e9 8c 00 00 00       	jmp    0x705958807da7
    705958807d1b:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807d22:	00 
    705958807d23:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958807d2a:	00 00 00 
    705958807d2d:	c7 87 34 01 00 00 0a 	mov    DWORD PTR [rdi+0x134],0xa
    705958807d34:	00 00 00 
    705958807d37:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958807d3e:	63 00 00 
    705958807d41:	ff d0                	call   rax
    705958807d43:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807d4a:	00 
    705958807d4b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807d51:	b9 0a 00 00 00       	mov    ecx,0xa
    705958807d56:	b8 02 00 00 00       	mov    eax,0x2
    705958807d5b:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807d62:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807d69:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807d70:	e9 34 02 00 00       	jmp    0x705958807fa9
    705958807d75:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807d7c:	00 
    705958807d7d:	c7 87 bc 00 00 00 fc 	mov    DWORD PTR [rdi+0xbc],0x103fc
    705958807d84:	03 01 00 
    705958807d87:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958807d8e:	00 00 00 
    705958807d91:	c7 87 34 01 00 00 0a 	mov    DWORD PTR [rdi+0x134],0xa
    705958807d98:	00 00 00 
    705958807d9b:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958807da2:	63 00 00 
    705958807da5:	ff d0                	call   rax
    705958807da7:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807dae:	00 
    705958807daf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958807db6:	74 32                	je     0x705958807dea
    705958807db8:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807dbf:	00 
    705958807dc0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958807dc6:	b9 0a 00 00 00       	mov    ecx,0xa
    705958807dcb:	b8 02 00 00 00       	mov    eax,0x2
    705958807dd0:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    705958807dd7:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    705958807dde:	89 84 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],eax
    705958807de5:	e9 bf 01 00 00       	jmp    0x705958807fa9
    705958807dea:	e9 ce fe ff ff       	jmp    0x705958807cbd
    705958807def:	eb 00                	jmp    0x705958807df1
    705958807df1:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807df8:	00 
    705958807df9:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    705958807dfd:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958807e03:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958807e09:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    705958807e0d:	89 48 2c             	mov    DWORD PTR [rax+0x2c],ecx
    705958807e10:	eb 00                	jmp    0x705958807e12
    705958807e12:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807e19:	00 
    705958807e1a:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    705958807e20:	eb 00                	jmp    0x705958807e22
    705958807e22:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807e29:	00 
    705958807e2a:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    705958807e2e:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958807e34:	81 c9 fc 12 00 00    	or     ecx,0x12fc
    705958807e3a:	89 48 2c             	mov    DWORD PTR [rax+0x2c],ecx
    705958807e3d:	eb 00                	jmp    0x705958807e3f
    705958807e3f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807e46:	00 
    705958807e47:	c7 40 08 ff 1f 00 00 	mov    DWORD PTR [rax+0x8],0x1fff
    705958807e4e:	eb 00                	jmp    0x705958807e50
    705958807e50:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807e57:	00 
    705958807e58:	c7 40 28 00 20 00 00 	mov    DWORD PTR [rax+0x28],0x2000
    705958807e5f:	eb 00                	jmp    0x705958807e61
    705958807e61:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [rsp+0xa0]
    705958807e68:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807e6f:	00 
    705958807e70:	c7 81 94 00 00 00 12 	mov    DWORD PTR [rcx+0x94],0x10412
    705958807e77:	04 01 00 
    705958807e7a:	c7 81 a4 00 00 00 20 	mov    DWORD PTR [rcx+0xa4],0x10420
    705958807e81:	04 01 00 
    705958807e84:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x2000
    705958807e8b:	20 00 00 
    705958807e8e:	c7 81 bc 00 00 00 12 	mov    DWORD PTR [rcx+0xbc],0x10412
    705958807e95:	04 01 00 
    705958807e98:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    705958807e9f:	3d 0e 04 01 00       	cmp    eax,0x1040e
    705958807ea4:	0f 94 c0             	sete   al
    705958807ea7:	0c 00                	or     al,0x0
    705958807ea9:	a8 01                	test   al,0x1
    705958807eab:	75 02                	jne    0x705958807eaf
    705958807ead:	eb 39                	jmp    0x705958807ee8
    705958807eaf:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    705958807eb6:	00 
    705958807eb7:	c7 87 bc 00 00 00 12 	mov    DWORD PTR [rdi+0xbc],0x10412
    705958807ebe:	04 01 00 
    705958807ec1:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958807ec8:	00 00 00 
    705958807ecb:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958807ed2:	00 00 00 
    705958807ed5:	48 b8 20 6d 8c 23 5a 	movabs rax,0x635a238c6d20
    705958807edc:	63 00 00 
    705958807edf:	ba 0e 04 01 00       	mov    edx,0x1040e
    705958807ee4:	89 d6                	mov    esi,edx
    705958807ee6:	ff d0                	call   rax
    705958807ee8:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807eef:	00 
    705958807ef0:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958807ef6:	83 c0 10             	add    eax,0x10
    705958807ef9:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    705958807efd:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958807f03:	72 16                	jb     0x705958807f1b
    705958807f05:	eb 37                	jmp    0x705958807f3e
    705958807f07:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807f0e:	00 
    705958807f0f:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958807f16:	e9 74 01 00 00       	jmp    0x70595880808f
    705958807f1b:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    705958807f22:	00 
    705958807f23:	48 89 c1             	mov    rcx,rax
    705958807f26:	48 81 c1 90 20 08 00 	add    rcx,0x82090
    705958807f2d:	48 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],rcx
    705958807f32:	81 b8 90 20 08 00 12 	cmp    DWORD PTR [rax+0x82090],0x10412
    705958807f39:	04 01 00 
    705958807f3c:	74 2b                	je     0x705958807f69
    705958807f3e:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807f45:	00 
    705958807f46:	c7 80 bc 00 00 00 12 	mov    DWORD PTR [rax+0xbc],0x10412
    705958807f4d:	04 01 00 
    705958807f50:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958807f57:	00 00 00 
    705958807f5a:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    705958807f61:	00 00 00 
    705958807f64:	e9 26 01 00 00       	jmp    0x70595880808f
    705958807f69:	4c 8b b4 24 b0 00 00 	mov    r14,QWORD PTR [rsp+0xb0]
    705958807f70:	00 
    705958807f71:	4c 8b ac 24 b8 00 00 	mov    r13,QWORD PTR [rsp+0xb8]
    705958807f78:	00 
    705958807f79:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    705958807f7e:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    705958807f82:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10412
    705958807f89:	12 04 01 00 
    705958807f8d:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958807f94:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958807f9b:	00 
    705958807f9c:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958807fa0:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    705958807fa7:	ff e0                	jmp    rax
    705958807fa9:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    705958807fb0:	00 
    705958807fb1:	8b 94 24 80 00 00 00 	mov    edx,DWORD PTR [rsp+0x80]
    705958807fb8:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    705958807fbf:	8b b4 24 88 00 00 00 	mov    esi,DWORD PTR [rsp+0x88]
    705958807fc6:	89 c7                	mov    edi,eax
    705958807fc8:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    705958807fcc:	89 74 24 0c          	mov    DWORD PTR [rsp+0xc],esi
    705958807fd0:	89 54 24 10          	mov    DWORD PTR [rsp+0x10],edx
    705958807fd4:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    705958807fda:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    705958807fde:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958807fe4:	73 0d                	jae    0x705958807ff3
    705958807fe6:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    705958807fea:	3d e6 03 01 00       	cmp    eax,0x103e6
    705958807fef:	74 20                	je     0x705958808011
    705958807ff1:	eb 3c                	jmp    0x70595880802f
    705958807ff3:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958807ffa:	00 
    705958807ffb:	8b 4c 24 08          	mov    ecx,DWORD PTR [rsp+0x8]
    705958807fff:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    705958808003:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    705958808009:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    70595880800f:	eb 7e                	jmp    0x70595880808f
    705958808011:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958808018:	00 
    705958808019:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    70595880801d:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    705958808023:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    70595880802a:	e9 25 f3 ff ff       	jmp    0x705958807354
    70595880802f:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    705958808036:	00 
    705958808037:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    70595880803b:	89 d1                	mov    ecx,edx
    70595880803d:	c1 e9 01             	shr    ecx,0x1
    705958808040:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958808046:	89 c9                	mov    ecx,ecx
    705958808048:	48 c1 e1 04          	shl    rcx,0x4
    70595880804c:	48 89 c6             	mov    rsi,rax
    70595880804f:	48 01 ce             	add    rsi,rcx
    705958808052:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    705958808056:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958808059:	75 98                	jne    0x705958807ff3
    70595880805b:	4c 8b b4 24 b0 00 00 	mov    r14,QWORD PTR [rsp+0xb0]
    705958808062:	00 
    705958808063:	4c 8b ac 24 b8 00 00 	mov    r13,QWORD PTR [rsp+0xb8]
    70595880806a:	00 
    70595880806b:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    70595880806f:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    705958808073:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880807a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958808081:	00 
    705958808082:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958808086:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    70595880808d:	ff e0                	jmp    rax
    70595880808f:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    705958808096:	c2 08 00             	ret    0x8
