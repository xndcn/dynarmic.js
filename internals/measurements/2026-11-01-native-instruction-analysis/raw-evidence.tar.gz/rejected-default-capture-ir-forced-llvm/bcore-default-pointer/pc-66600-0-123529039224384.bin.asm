
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66600-0-123529039224384.bin:     file format binary


Disassembly of section .data:

0000705958809e40 <.data>:
    705958809e40:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    705958809e47:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
    705958809e4e:	00 
    705958809e4f:	4c 89 ac 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r13
    705958809e56:	00 
    705958809e57:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958809e5e:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    705958809e65:	00 
    705958809e66:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    705958809e6d:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    705958809e74:	00 
    705958809e75:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    705958809e7c:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    705958809e83:	00 
    705958809e84:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    705958809e8b:	00 
    705958809e8c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958809e92:	83 fa 00             	cmp    edx,0x0
    705958809e95:	0f 94 c0             	sete   al
    705958809e98:	81 ea 28 04 01 00    	sub    edx,0x10428
    705958809e9e:	83 fa 18             	cmp    edx,0x18
    705958809ea1:	0f 97 c2             	seta   dl
    705958809ea4:	08 d0                	or     al,dl
    705958809ea6:	24 01                	and    al,0x1
    705958809ea8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958809eae:	81 fa 20 04 01 00    	cmp    edx,0x10420
    705958809eb4:	0f 94 c1             	sete   cl
    705958809eb7:	81 ea 28 04 01 00    	sub    edx,0x10428
    705958809ebd:	83 fa 18             	cmp    edx,0x18
    705958809ec0:	0f 97 c2             	seta   dl
    705958809ec3:	08 d1                	or     cl,dl
    705958809ec5:	20 c8                	and    al,cl
    705958809ec7:	a8 01                	test   al,0x1
    705958809ec9:	75 05                	jne    0x705958809ed0
    705958809ecb:	e9 4f 0b 00 00       	jmp    0x70595880aa1f
    705958809ed0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    705958809ed7:	00 
    705958809ed8:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958809edf:	48 89 c8             	mov    rax,rcx
    705958809ee2:	48 05 00 00 10 00    	add    rax,0x100000
    705958809ee8:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    705958809eef:	00 
    705958809ef0:	8b 81 28 00 10 00    	mov    eax,DWORD PTR [rcx+0x100028]
    705958809ef6:	83 c0 01             	add    eax,0x1
    705958809ef9:	89 81 28 00 10 00    	mov    DWORD PTR [rcx+0x100028],eax
    705958809eff:	3d 30 75 00 00       	cmp    eax,0x7530
    705958809f04:	75 4c                	jne    0x705958809f52
    705958809f06:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    705958809f0d:	00 
    705958809f0e:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958809f14:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    705958809f1b:	89 c2                	mov    edx,eax
    705958809f1d:	83 c2 01             	add    edx,0x1
    705958809f20:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958809f26:	3d 00 01 00 00       	cmp    eax,0x100
    705958809f2b:	73 23                	jae    0x705958809f50
    705958809f2d:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    705958809f34:	00 
    705958809f35:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    705958809f3c:	89 c9                	mov    ecx,ecx
    705958809f3e:	48 c1 e1 02          	shl    rcx,0x2
    705958809f42:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958809f49:	c7 04 08 0a 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xa
    705958809f50:	eb 00                	jmp    0x705958809f52
    705958809f52:	eb 00                	jmp    0x705958809f54
    705958809f54:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    705958809f5b:	00 
    705958809f5c:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    705958809f5f:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958809f65:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958809f6b:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    705958809f72:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958809f75:	eb 00                	jmp    0x705958809f77
    705958809f77:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    705958809f7e:	00 
    705958809f7f:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    705958809f82:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    705958809f88:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    705958809f8f:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    705958809f92:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    705958809f99:	83 e8 04             	sub    eax,0x4
    705958809f9c:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    705958809fa3:	83 e0 03             	and    eax,0x3
    705958809fa6:	83 f8 00             	cmp    eax,0x0
    705958809fa9:	0f 84 98 00 00 00    	je     0x70595880a047
    705958809faf:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    705958809fb6:	00 
    705958809fb7:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    705958809fbe:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    705958809fc5:	00 
    705958809fc6:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    705958809fcd:	04 01 00 
    705958809fd0:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958809fd7:	00 00 00 
    705958809fda:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958809fe1:	00 00 00 
    705958809fe4:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958809feb:	63 00 00 
    705958809fee:	ba 2c 04 01 00       	mov    edx,0x1042c
    705958809ff3:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958809ff9:	ff d0                	call   rax
    705958809ffb:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a002:	00 
    70595880a003:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a009:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a00f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a015:	be 02 00 00 00       	mov    esi,0x2
    70595880a01a:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a01f:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a026:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a02d:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a034:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a03b:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a042:	e9 79 0a 00 00       	jmp    0x70595880aac0
    70595880a047:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880a04e:	00 
    70595880a04f:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880a056:	c1 e9 0c             	shr    ecx,0xc
    70595880a059:	89 c9                	mov    ecx,ecx
    70595880a05b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880a05f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    70595880a066:	00 
    70595880a067:	48 83 f8 00          	cmp    rax,0x0
    70595880a06b:	74 23                	je     0x70595880a090
    70595880a06d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880a074:	00 
    70595880a075:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    70595880a07c:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880a083:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880a089:	89 c9                	mov    ecx,ecx
    70595880a08b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880a08e:	eb 5b                	jmp    0x70595880a0eb
    70595880a090:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a097:	00 
    70595880a098:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    70595880a09f:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    70595880a0a6:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880a0ad:	00 
    70595880a0ae:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    70595880a0b5:	04 01 00 
    70595880a0b8:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880a0bf:	00 00 00 
    70595880a0c2:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    70595880a0c9:	00 00 00 
    70595880a0cc:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880a0d3:	63 00 00 
    70595880a0d6:	ff d0                	call   rax
    70595880a0d8:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a0df:	00 
    70595880a0e0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a0e7:	75 20                	jne    0x70595880a109
    70595880a0e9:	eb 6a                	jmp    0x70595880a155
    70595880a0eb:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    70595880a0f2:	83 e8 04             	sub    eax,0x4
    70595880a0f5:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    70595880a0fc:	83 e0 03             	and    eax,0x3
    70595880a0ff:	83 f8 00             	cmp    eax,0x0
    70595880a102:	75 53                	jne    0x70595880a157
    70595880a104:	e9 e6 00 00 00       	jmp    0x70595880a1ef
    70595880a109:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a110:	00 
    70595880a111:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a117:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a11d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a123:	be 02 00 00 00       	mov    esi,0x2
    70595880a128:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a12d:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a134:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a13b:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a142:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a149:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a150:	e9 6b 09 00 00       	jmp    0x70595880aac0
    70595880a155:	eb 94                	jmp    0x70595880a0eb
    70595880a157:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a15e:	00 
    70595880a15f:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a166:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    70595880a16d:	00 
    70595880a16e:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    70595880a175:	04 01 00 
    70595880a178:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880a17f:	00 00 00 
    70595880a182:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    70595880a189:	00 00 00 
    70595880a18c:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880a193:	63 00 00 
    70595880a196:	ba 2c 04 01 00       	mov    edx,0x1042c
    70595880a19b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880a1a1:	ff d0                	call   rax
    70595880a1a3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a1aa:	00 
    70595880a1ab:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a1b1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a1b7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a1bd:	be 02 00 00 00       	mov    esi,0x2
    70595880a1c2:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a1c7:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a1ce:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a1d5:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a1dc:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a1e3:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a1ea:	e9 d1 08 00 00       	jmp    0x70595880aac0
    70595880a1ef:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880a1f6:	00 
    70595880a1f7:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a1fe:	c1 e9 0c             	shr    ecx,0xc
    70595880a201:	89 c9                	mov    ecx,ecx
    70595880a203:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880a207:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    70595880a20e:	00 
    70595880a20f:	48 83 f8 00          	cmp    rax,0x0
    70595880a213:	74 23                	je     0x70595880a238
    70595880a215:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    70595880a21c:	00 
    70595880a21d:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    70595880a224:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a22b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880a231:	89 c9                	mov    ecx,ecx
    70595880a233:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880a236:	eb 5b                	jmp    0x70595880a293
    70595880a238:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a23f:	00 
    70595880a240:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    70595880a247:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    70595880a24e:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880a255:	00 
    70595880a256:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    70595880a25d:	04 01 00 
    70595880a260:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880a267:	00 00 00 
    70595880a26a:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    70595880a271:	00 00 00 
    70595880a274:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880a27b:	63 00 00 
    70595880a27e:	ff d0                	call   rax
    70595880a280:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a287:	00 
    70595880a288:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a28f:	75 2c                	jne    0x70595880a2bd
    70595880a291:	eb 76                	jmp    0x70595880a309
    70595880a293:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    70595880a29a:	00 
    70595880a29b:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    70595880a2a2:	00 
    70595880a2a3:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    70595880a2aa:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    70595880a2ad:	83 ea 00             	sub    edx,0x0
    70595880a2b0:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    70595880a2b3:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880a2b6:	75 53                	jne    0x70595880a30b
    70595880a2b8:	e9 93 00 00 00       	jmp    0x70595880a350
    70595880a2bd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a2c4:	00 
    70595880a2c5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a2cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a2d1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a2d7:	be 02 00 00 00       	mov    esi,0x2
    70595880a2dc:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a2e1:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a2e8:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a2ef:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a2f6:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a2fd:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a304:	e9 b7 07 00 00       	jmp    0x70595880aac0
    70595880a309:	eb 88                	jmp    0x70595880a293
    70595880a30b:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a312:	00 
    70595880a313:	c7 87 bc 00 00 00 30 	mov    DWORD PTR [rdi+0xbc],0x10430
    70595880a31a:	04 01 00 
    70595880a31d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880a324:	00 00 00 
    70595880a327:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    70595880a32e:	00 00 00 
    70595880a331:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880a338:	63 00 00 
    70595880a33b:	ff d0                	call   rax
    70595880a33d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a344:	00 
    70595880a345:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a34c:	75 04                	jne    0x70595880a352
    70595880a34e:	eb 4e                	jmp    0x70595880a39e
    70595880a350:	eb 4e                	jmp    0x70595880a3a0
    70595880a352:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a359:	00 
    70595880a35a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a360:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a366:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a36c:	be 02 00 00 00       	mov    esi,0x2
    70595880a371:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a376:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a37d:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a384:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a38b:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a392:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a399:	e9 22 07 00 00       	jmp    0x70595880aac0
    70595880a39e:	eb b0                	jmp    0x70595880a350
    70595880a3a0:	eb 00                	jmp    0x70595880a3a2
    70595880a3a2:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a3a9:	00 
    70595880a3aa:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    70595880a3b1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880a3b7:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    70595880a3bd:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    70595880a3c4:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880a3c7:	eb 00                	jmp    0x70595880a3c9
    70595880a3c9:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    70595880a3d0:	83 e0 03             	and    eax,0x3
    70595880a3d3:	83 f8 00             	cmp    eax,0x0
    70595880a3d6:	0f 84 97 00 00 00    	je     0x70595880a473
    70595880a3dc:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a3e3:	00 
    70595880a3e4:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880a3eb:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    70595880a3f2:	00 
    70595880a3f3:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10434
    70595880a3fa:	04 01 00 
    70595880a3fd:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880a404:	00 00 00 
    70595880a407:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    70595880a40e:	00 00 00 
    70595880a411:	31 c0                	xor    eax,eax
    70595880a413:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880a41a:	63 00 00 
    70595880a41d:	ba 34 04 01 00       	mov    edx,0x10434
    70595880a422:	45 31 c0             	xor    r8d,r8d
    70595880a425:	ff d0                	call   rax
    70595880a427:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a42e:	00 
    70595880a42f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a435:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a43b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a441:	be 04 00 00 00       	mov    esi,0x4
    70595880a446:	b9 02 00 00 00       	mov    ecx,0x2
    70595880a44b:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a452:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a459:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a460:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a467:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a46e:	e9 4d 06 00 00       	jmp    0x70595880aac0
    70595880a473:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880a47a:	00 
    70595880a47b:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880a482:	c1 e9 0c             	shr    ecx,0xc
    70595880a485:	89 c9                	mov    ecx,ecx
    70595880a487:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880a48b:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    70595880a490:	48 83 f8 00          	cmp    rax,0x0
    70595880a494:	74 1d                	je     0x70595880a4b3
    70595880a496:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880a49b:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880a4a2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880a4a8:	89 c9                	mov    ecx,ecx
    70595880a4aa:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880a4ad:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    70595880a4b1:	eb 5a                	jmp    0x70595880a50d
    70595880a4b3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a4ba:	00 
    70595880a4bb:	8b b4 24 84 00 00 00 	mov    esi,DWORD PTR [rsp+0x84]
    70595880a4c2:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880a4c9:	00 
    70595880a4ca:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10434
    70595880a4d1:	04 01 00 
    70595880a4d4:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880a4db:	00 00 00 
    70595880a4de:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    70595880a4e5:	00 00 00 
    70595880a4e8:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880a4ef:	63 00 00 
    70595880a4f2:	ff d0                	call   rax
    70595880a4f4:	89 c1                	mov    ecx,eax
    70595880a4f6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a4fd:	00 
    70595880a4fe:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    70595880a502:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a509:	75 17                	jne    0x70595880a522
    70595880a50b:	eb 61                	jmp    0x70595880a56e
    70595880a50d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a514:	00 
    70595880a515:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880a519:	89 4c 24 6c          	mov    DWORD PTR [rsp+0x6c],ecx
    70595880a51d:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880a520:	eb 56                	jmp    0x70595880a578
    70595880a522:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a529:	00 
    70595880a52a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a530:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a536:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a53c:	be 04 00 00 00       	mov    esi,0x4
    70595880a541:	b9 02 00 00 00       	mov    ecx,0x2
    70595880a546:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a54d:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a554:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a55b:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a562:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a569:	e9 52 05 00 00       	jmp    0x70595880aac0
    70595880a56e:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    70595880a572:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    70595880a576:	eb 95                	jmp    0x70595880a50d
    70595880a578:	eb 00                	jmp    0x70595880a57a
    70595880a57a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a581:	00 
    70595880a582:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    70595880a586:	83 f9 04             	cmp    ecx,0x4
    70595880a589:	0f 96 c1             	setbe  cl
    70595880a58c:	80 e1 01             	and    cl,0x1
    70595880a58f:	0f b6 c9             	movzx  ecx,cl
    70595880a592:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    70595880a596:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    70595880a59c:	eb 00                	jmp    0x70595880a59e
    70595880a59e:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    70595880a5a2:	83 f8 00             	cmp    eax,0x0
    70595880a5a5:	74 30                	je     0x70595880a5d7
    70595880a5a7:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    70595880a5ae:	00 
    70595880a5af:	c7 81 bc 00 00 00 42 	mov    DWORD PTR [rcx+0xbc],0x10442
    70595880a5b6:	04 01 00 
    70595880a5b9:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880a5bf:	83 c0 06             	add    eax,0x6
    70595880a5c2:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880a5c6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880a5cc:	0f 82 61 04 00 00    	jb     0x70595880aa33
    70595880a5d2:	e9 7f 04 00 00       	jmp    0x70595880aa56
    70595880a5d7:	eb 00                	jmp    0x70595880a5d9
    70595880a5d9:	eb 00                	jmp    0x70595880a5db
    70595880a5db:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a5e2:	00 
    70595880a5e3:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    70595880a5e9:	eb 00                	jmp    0x70595880a5eb
    70595880a5eb:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    70595880a5f2:	83 e0 03             	and    eax,0x3
    70595880a5f5:	83 f8 00             	cmp    eax,0x0
    70595880a5f8:	0f 84 97 00 00 00    	je     0x70595880a695
    70595880a5fe:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a605:	00 
    70595880a606:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a60d:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    70595880a614:	00 
    70595880a615:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    70595880a61c:	04 01 00 
    70595880a61f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880a626:	00 00 00 
    70595880a629:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    70595880a630:	00 00 00 
    70595880a633:	31 c0                	xor    eax,eax
    70595880a635:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880a63c:	63 00 00 
    70595880a63f:	ba 3c 04 01 00       	mov    edx,0x1043c
    70595880a644:	45 31 c0             	xor    r8d,r8d
    70595880a647:	ff d0                	call   rax
    70595880a649:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a650:	00 
    70595880a651:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a657:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a65d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a663:	be 08 00 00 00       	mov    esi,0x8
    70595880a668:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a66d:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a674:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a67b:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a682:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a689:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a690:	e9 2b 04 00 00       	jmp    0x70595880aac0
    70595880a695:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880a69c:	00 
    70595880a69d:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a6a4:	c1 e9 0c             	shr    ecx,0xc
    70595880a6a7:	89 c9                	mov    ecx,ecx
    70595880a6a9:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880a6ad:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    70595880a6b2:	48 83 f8 00          	cmp    rax,0x0
    70595880a6b6:	74 1d                	je     0x70595880a6d5
    70595880a6b8:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    70595880a6bd:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880a6c4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880a6ca:	89 c9                	mov    ecx,ecx
    70595880a6cc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880a6cf:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880a6d3:	eb 5a                	jmp    0x70595880a72f
    70595880a6d5:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a6dc:	00 
    70595880a6dd:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    70595880a6e4:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880a6eb:	00 
    70595880a6ec:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    70595880a6f3:	04 01 00 
    70595880a6f6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880a6fd:	00 00 00 
    70595880a700:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    70595880a707:	00 00 00 
    70595880a70a:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880a711:	63 00 00 
    70595880a714:	ff d0                	call   rax
    70595880a716:	89 c1                	mov    ecx,eax
    70595880a718:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a71f:	00 
    70595880a720:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    70595880a724:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a72b:	75 25                	jne    0x70595880a752
    70595880a72d:	eb 6f                	jmp    0x70595880a79e
    70595880a72f:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    70595880a736:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880a73a:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880a73e:	83 c0 04             	add    eax,0x4
    70595880a741:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    70595880a745:	83 e0 03             	and    eax,0x3
    70595880a748:	83 f8 00             	cmp    eax,0x0
    70595880a74b:	75 5b                	jne    0x70595880a7a8
    70595880a74d:	e9 ea 00 00 00       	jmp    0x70595880a83c
    70595880a752:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a759:	00 
    70595880a75a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a760:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a766:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a76c:	be 08 00 00 00       	mov    esi,0x8
    70595880a771:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a776:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a77d:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a784:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a78b:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a792:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a799:	e9 22 03 00 00       	jmp    0x70595880aac0
    70595880a79e:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    70595880a7a2:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880a7a6:	eb 87                	jmp    0x70595880a72f
    70595880a7a8:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a7af:	00 
    70595880a7b0:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880a7b4:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    70595880a7bb:	00 
    70595880a7bc:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    70595880a7c3:	04 01 00 
    70595880a7c6:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880a7cd:	00 00 00 
    70595880a7d0:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    70595880a7d7:	00 00 00 
    70595880a7da:	31 c0                	xor    eax,eax
    70595880a7dc:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880a7e3:	63 00 00 
    70595880a7e6:	ba 3c 04 01 00       	mov    edx,0x1043c
    70595880a7eb:	45 31 c0             	xor    r8d,r8d
    70595880a7ee:	ff d0                	call   rax
    70595880a7f0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a7f7:	00 
    70595880a7f8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a7fe:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a804:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a80a:	be 08 00 00 00       	mov    esi,0x8
    70595880a80f:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a814:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a81b:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a822:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a829:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a830:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a837:	e9 84 02 00 00       	jmp    0x70595880aac0
    70595880a83c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880a843:	00 
    70595880a844:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880a848:	c1 e9 0c             	shr    ecx,0xc
    70595880a84b:	89 c9                	mov    ecx,ecx
    70595880a84d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880a851:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    70595880a856:	48 83 f8 00          	cmp    rax,0x0
    70595880a85a:	74 1a                	je     0x70595880a876
    70595880a85c:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    70595880a861:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880a865:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880a86b:	89 c9                	mov    ecx,ecx
    70595880a86d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880a870:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    70595880a874:	eb 57                	jmp    0x70595880a8cd
    70595880a876:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a87d:	00 
    70595880a87e:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    70595880a882:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880a889:	00 
    70595880a88a:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    70595880a891:	04 01 00 
    70595880a894:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880a89b:	00 00 00 
    70595880a89e:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    70595880a8a5:	00 00 00 
    70595880a8a8:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880a8af:	63 00 00 
    70595880a8b2:	ff d0                	call   rax
    70595880a8b4:	89 c1                	mov    ecx,eax
    70595880a8b6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a8bd:	00 
    70595880a8be:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    70595880a8c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880a8c9:	75 2b                	jne    0x70595880a8f6
    70595880a8cb:	eb 75                	jmp    0x70595880a942
    70595880a8cd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a8d4:	00 
    70595880a8d5:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    70595880a8d9:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880a8dd:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    70595880a8e1:	89 54 24 34          	mov    DWORD PTR [rsp+0x34],edx
    70595880a8e5:	83 c1 04             	add    ecx,0x4
    70595880a8e8:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    70595880a8eb:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    70595880a8f1:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880a8f4:	eb 56                	jmp    0x70595880a94c
    70595880a8f6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a8fd:	00 
    70595880a8fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a904:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a90a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a910:	be 08 00 00 00       	mov    esi,0x8
    70595880a915:	b9 04 00 00 00       	mov    ecx,0x4
    70595880a91a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a921:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a928:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a92f:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a936:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a93d:	e9 7e 01 00 00       	jmp    0x70595880aac0
    70595880a942:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    70595880a946:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    70595880a94a:	eb 81                	jmp    0x70595880a8cd
    70595880a94c:	eb 00                	jmp    0x70595880a94e
    70595880a94e:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    70595880a952:	83 e0 01             	and    eax,0x1
    70595880a955:	83 f8 00             	cmp    eax,0x0
    70595880a958:	75 3a                	jne    0x70595880a994
    70595880a95a:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    70595880a95e:	be 09 00 00 00       	mov    esi,0x9
    70595880a963:	b9 02 00 00 00       	mov    ecx,0x2
    70595880a968:	b0 01                	mov    al,0x1
    70595880a96a:	89 d7                	mov    edi,edx
    70595880a96c:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a973:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880a97a:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880a981:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880a988:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880a98f:	e9 2c 01 00 00       	jmp    0x70595880aac0
    70595880a994:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    70595880a99b:	00 
    70595880a99c:	48 8b 94 24 d0 00 00 	mov    rdx,QWORD PTR [rsp+0xd0]
    70595880a9a3:	00 
    70595880a9a4:	c7 87 bc 00 00 00 40 	mov    DWORD PTR [rdi+0xbc],0x10440
    70595880a9ab:	04 01 00 
    70595880a9ae:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880a9b5:	00 00 00 
    70595880a9b8:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880a9bf:	00 00 00 
    70595880a9c2:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880a9c9:	63 00 00 
    70595880a9cc:	be 2a 00 00 00       	mov    esi,0x2a
    70595880a9d1:	ff d0                	call   rax
    70595880a9d3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880a9da:	00 
    70595880a9db:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880a9e1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880a9e7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880a9ed:	be 09 00 00 00       	mov    esi,0x9
    70595880a9f2:	b9 02 00 00 00       	mov    ecx,0x2
    70595880a9f7:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    70595880a9fe:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    70595880aa05:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    70595880aa0c:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    70595880aa13:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    70595880aa1a:	e9 a1 00 00 00       	jmp    0x70595880aac0
    70595880aa1f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880aa26:	00 
    70595880aa27:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880aa2e:	e9 7f 01 00 00       	jmp    0x70595880abb2
    70595880aa33:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880aa3a:	00 
    70595880aa3b:	48 89 c1             	mov    rcx,rax
    70595880aa3e:	48 81 c1 10 22 08 00 	add    rcx,0x82210
    70595880aa45:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    70595880aa4a:	81 b8 10 22 08 00 42 	cmp    DWORD PTR [rax+0x82210],0x10442
    70595880aa51:	04 01 00 
    70595880aa54:	74 32                	je     0x70595880aa88
    70595880aa56:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880aa5d:	00 
    70595880aa5e:	c7 80 bc 00 00 00 42 	mov    DWORD PTR [rax+0xbc],0x10442
    70595880aa65:	04 01 00 
    70595880aa68:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880aa6f:	00 00 00 
    70595880aa72:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    70595880aa79:	00 00 00 
    70595880aa7c:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880aa83:	e9 2a 01 00 00       	jmp    0x70595880abb2
    70595880aa88:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    70595880aa8f:	00 
    70595880aa90:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    70595880aa97:	00 
    70595880aa98:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880aa9d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880aaa1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    70595880aaa8:	42 04 01 00 
    70595880aaac:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880aab3:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880aab7:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    70595880aabe:	ff e0                	jmp    rax
    70595880aac0:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    70595880aac7:	00 
    70595880aac8:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    70595880aacf:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    70595880aad6:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    70595880aadd:	8b bc 24 ac 00 00 00 	mov    edi,DWORD PTR [rsp+0xac]
    70595880aae4:	8a 9c 24 b3 00 00 00 	mov    bl,BYTE PTR [rsp+0xb3]
    70595880aaeb:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    70595880aaef:	89 c3                	mov    ebx,eax
    70595880aaf1:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    70595880aaf5:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    70595880aaf9:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    70595880aafd:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    70595880ab01:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880ab07:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    70595880ab0b:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880ab11:	73 2d                	jae    0x70595880ab40
    70595880ab13:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880ab1a:	00 
    70595880ab1b:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880ab1f:	89 d1                	mov    ecx,edx
    70595880ab21:	c1 e9 01             	shr    ecx,0x1
    70595880ab24:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880ab2a:	89 c9                	mov    ecx,ecx
    70595880ab2c:	48 c1 e1 04          	shl    rcx,0x4
    70595880ab30:	48 89 c6             	mov    rsi,rax
    70595880ab33:	48 01 ce             	add    rsi,rcx
    70595880ab36:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    70595880ab3b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880ab3e:	74 32                	je     0x70595880ab72
    70595880ab40:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880ab47:	00 
    70595880ab48:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    70595880ab4c:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595880ab50:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    70595880ab54:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    70595880ab58:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    70595880ab5e:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    70595880ab64:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    70595880ab6a:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595880ab70:	eb 40                	jmp    0x70595880abb2
    70595880ab72:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    70595880ab79:	00 
    70595880ab7a:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    70595880ab81:	00 
    70595880ab82:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    70595880ab87:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    70595880ab8b:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880ab8f:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    70595880ab96:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880ab9d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880aba4:	00 
    70595880aba5:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880aba9:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    70595880abb0:	ff e0                	jmp    rax
    70595880abb2:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    70595880abb9:	c2 08 00             	ret    0x8
