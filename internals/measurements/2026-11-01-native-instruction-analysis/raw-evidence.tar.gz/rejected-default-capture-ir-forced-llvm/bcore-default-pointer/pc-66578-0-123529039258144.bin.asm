
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66578-0-123529039258144.bin:     file format binary


Disassembly of section .data:

0000705958812220 <.data>:
    705958812220:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    705958812227:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    70595881222c:	4d 89 e8             	mov    r8,r13
    70595881222f:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958812236:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    70595881223b:	45 8b 95 58 01 00 00 	mov    r10d,DWORD PTR [r13+0x158]
    705958812242:	b8 db fb fe ff       	mov    eax,0xfffefbdb
    705958812247:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    70595881224e:	83 f8 ec             	cmp    eax,0xffffffec
    705958812251:	0f 87 3e e0 fe 17    	ja     0x705970800295
    705958812257:	41 81 b8 a4 00 00 00 	cmp    DWORD PTR [r8+0xa4],0x10420
    70595881225e:	20 04 01 00 
    705958812262:	0f 85 2d e0 fe 17    	jne    0x705970800295
    705958812268:	41 81 b8 94 00 00 00 	cmp    DWORD PTR [r8+0x94],0x10412
    70595881226f:	12 04 01 00 
    705958812273:	0f 85 1c e0 fe 17    	jne    0x705970800295
    705958812279:	4d 8b 98 40 01 00 00 	mov    r11,QWORD PTR [r8+0x140]
    705958812280:	49 8b b8 38 01 00 00 	mov    rdi,QWORD PTR [r8+0x138]
    705958812287:	41 8b 40 34          	mov    eax,DWORD PTR [r8+0x34]
    70595881228b:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    705958812290:	41 8b 40 24          	mov    eax,DWORD PTR [r8+0x24]
    705958812294:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    705958812299:	41 8b 00             	mov    eax,DWORD PTR [r8]
    70595881229c:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7059588122a0:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    7059588122a4:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    7059588122a8:	41 8b 40 20          	mov    eax,DWORD PTR [r8+0x20]
    7059588122ac:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    7059588122b3:	00 
    7059588122b4:	41 8b 40 2c          	mov    eax,DWORD PTR [r8+0x2c]
    7059588122b8:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    7059588122bd:	45 8b a0 9c 00 00 00 	mov    r12d,DWORD PTR [r8+0x9c]
    7059588122c4:	45 8b b0 00 01 00 00 	mov    r14d,DWORD PTR [r8+0x100]
    7059588122cb:	45 8b b8 5c 01 00 00 	mov    r15d,DWORD PTR [r8+0x15c]
    7059588122d2:	48 89 7c 24 68       	mov    QWORD PTR [rsp+0x68],rdi
    7059588122d7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
    7059588122de:	00 00 
    7059588122e0:	44 89 64 24 10       	mov    DWORD PTR [rsp+0x10],r12d
    7059588122e5:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    7059588122e9:	44 89 f1             	mov    ecx,r14d
    7059588122ec:	8d 70 01             	lea    esi,[rax+0x1]
    7059588122ef:	c1 e8 1f             	shr    eax,0x1f
    7059588122f2:	89 f2                	mov    edx,esi
    7059588122f4:	c1 ea 1f             	shr    edx,0x1f
    7059588122f7:	c4 62 78 f2 f2       	andn   r14d,eax,edx
    7059588122fc:	41 09 ce             	or     r14d,ecx
    7059588122ff:	45 31 c9             	xor    r9d,r9d
    705958812302:	89 f3                	mov    ebx,esi
    705958812304:	23 5c 24 5c          	and    ebx,DWORD PTR [rsp+0x5c]
    705958812308:	41 0f 94 c1          	sete   r9b
    70595881230c:	41 89 dc             	mov    r12d,ebx
    70595881230f:	41 c1 ec 1f          	shr    r12d,0x1f
    705958812313:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    705958812318:	40 f6 c5 03          	test   bpl,0x3
    70595881231c:	0f 85 78 03 00 00    	jne    0x70595881269a
    705958812322:	89 e8                	mov    eax,ebp
    705958812324:	c1 e8 0c             	shr    eax,0xc
    705958812327:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    70595881232b:	48 85 c0             	test   rax,rax
    70595881232e:	44 89 4c 24 14       	mov    DWORD PTR [rsp+0x14],r9d
    705958812333:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    705958812337:	0f 84 f9 03 00 00    	je     0x705958812736
    70595881233d:	89 e9                	mov    ecx,ebp
    70595881233f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958812345:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958812348:	83 c5 04             	add    ebp,0x4
    70595881234b:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    705958812352:	00 
    705958812353:	44 8d 2c 99          	lea    r13d,[rcx+rbx*4]
    705958812357:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    70595881235c:	8d 0c 81             	lea    ecx,[rcx+rax*4]
    70595881235f:	41 f6 c5 03          	test   r13b,0x3
    705958812363:	0f 85 a7 04 00 00    	jne    0x705958812810
    705958812369:	44 89 e8             	mov    eax,r13d
    70595881236c:	c1 e8 0c             	shr    eax,0xc
    70595881236f:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    705958812373:	48 85 c0             	test   rax,rax
    705958812376:	44 89 64 24 20       	mov    DWORD PTR [rsp+0x20],r12d
    70595881237b:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    705958812380:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    705958812385:	0f 84 eb 05 00 00    	je     0x705958812976
    70595881238b:	44 89 eb             	mov    ebx,r13d
    70595881238e:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    705958812394:	8b 14 18             	mov    edx,DWORD PTR [rax+rbx*1]
    705958812397:	44 89 74 24 18       	mov    DWORD PTR [rsp+0x18],r14d
    70595881239c:	f6 c1 03             	test   cl,0x3
    70595881239f:	0f 85 ad 06 00 00    	jne    0x705958812a52
    7059588123a5:	89 c8                	mov    eax,ecx
    7059588123a7:	c1 e8 0c             	shr    eax,0xc
    7059588123aa:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    7059588123ae:	48 85 c0             	test   rax,rax
    7059588123b1:	89 54 24 24          	mov    DWORD PTR [rsp+0x24],edx
    7059588123b5:	0f 84 39 07 00 00    	je     0x705958812af4
    7059588123bb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588123c1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588123c4:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    7059588123c9:	41 83 fc 02          	cmp    r12d,0x2
    7059588123cd:	72 74                	jb     0x705958812443
    7059588123cf:	41 ff cc             	dec    r12d
    7059588123d2:	41 be 12 04 01 00    	mov    r14d,0x10412
    7059588123d8:	bd 08 00 00 00       	mov    ebp,0x8
    7059588123dd:	41 80 3b 00          	cmp    BYTE PTR [r11],0x0
    7059588123e1:	0f 85 df 07 00 00    	jne    0x705958812bc6
    7059588123e7:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    7059588123ec:	c7 44 24 44 00 00 00 	mov    DWORD PTR [rsp+0x44],0x0
    7059588123f3:	00 
    7059588123f4:	c7 44 24 10 02 00 00 	mov    DWORD PTR [rsp+0x10],0x2
    7059588123fb:	00 
    7059588123fc:	44 89 f9             	mov    ecx,r15d
    7059588123ff:	31 f6                	xor    esi,esi
    705958812401:	31 c0                	xor    eax,eax
    705958812403:	31 d2                	xor    edx,edx
    705958812405:	48 89 eb             	mov    rbx,rbp
    705958812408:	44 8d 3c 29          	lea    r15d,[rcx+rbp*1]
    70595881240c:	45 39 d7             	cmp    r15d,r10d
    70595881240f:	0f 83 e2 01 00 00    	jae    0x7059588125f7
    705958812415:	41 8b b8 58 01 00 00 	mov    edi,DWORD PTR [r8+0x158]
    70595881241c:	85 ff                	test   edi,edi
    70595881241e:	0f 84 d3 01 00 00    	je     0x7059588125f7
    705958812424:	41 81 fe 12 04 01 00 	cmp    r14d,0x10412
    70595881242b:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    705958812430:	4c 89 f5             	mov    rbp,r14
    705958812433:	44 8b 74 24 18       	mov    r14d,DWORD PTR [rsp+0x18]
    705958812438:	0f 84 a2 fe ff ff    	je     0x7059588122e0
    70595881243e:	e9 e3 00 00 00       	jmp    0x705958812526
    705958812443:	41 80 3b 00          	cmp    BYTE PTR [r11],0x0
    705958812447:	0f 85 62 de fe 17    	jne    0x7059708002af
    70595881244d:	41 8d 47 0a          	lea    eax,[r15+0xa]
    705958812451:	44 39 d0             	cmp    eax,r10d
    705958812454:	0f 83 9a dd fe 17    	jae    0x7059708001f4
    70595881245a:	41 8b 88 58 01 00 00 	mov    ecx,DWORD PTR [r8+0x158]
    705958812461:	85 c9                	test   ecx,ecx
    705958812463:	0f 84 8b dd fe 17    	je     0x7059708001f4
    705958812469:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    70595881246e:	81 b9 40 1b 08 00 68 	cmp    DWORD PTR [rcx+0x81b40],0x10368
    705958812475:	03 01 00 
    705958812478:	0f 85 76 dd fe 17    	jne    0x7059708001f4
    70595881247e:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    705958812483:	48 8b 89 48 1b 08 00 	mov    rcx,QWORD PTR [rcx+0x81b48]
    70595881248a:	41 c7 00 00 00 00 00 	mov    DWORD PTR [r8],0x0
    705958812491:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    705958812495:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    705958812499:	48 8b 54 24 30       	mov    rdx,QWORD PTR [rsp+0x30]
    70595881249e:	41 89 50 24          	mov    DWORD PTR [r8+0x24],edx
    7059588124a2:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    7059588124a6:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    7059588124ab:	41 89 50 34          	mov    DWORD PTR [r8+0x34],edx
    7059588124af:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    7059588124b6:	00 00 00 00 
    7059588124ba:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10368
    7059588124c1:	68 03 01 00 
    7059588124c5:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    7059588124c9:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    7059588124d0:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    7059588124d4:	41 89 90 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edx
    7059588124db:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    7059588124e2:	00 00 00 00 
    7059588124e6:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    7059588124ed:	00 00 00 00 
    7059588124f1:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    7059588124f5:	41 89 90 00 01 00 00 	mov    DWORD PTR [r8+0x100],edx
    7059588124fc:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705958812503:	02 00 00 00 
    705958812507:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    70595881250e:	00 
    70595881250f:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x9
    705958812516:	09 00 00 00 
    70595881251a:	41 89 80 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],eax
    705958812521:	e9 c0 00 00 00       	jmp    0x7059588125e6
    705958812526:	44 8d 0c ed 00 00 00 	lea    r9d,[rbp*8+0x0]
    70595881252d:	00 
    70595881252e:	41 81 e1 f0 ff 0f 00 	and    r9d,0xffff0
    705958812535:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    70595881253a:	42 39 2c 0f          	cmp    DWORD PTR [rdi+r9*1],ebp
    70595881253e:	49 89 ee             	mov    r14,rbp
    705958812541:	0f 85 b0 00 00 00    	jne    0x7059588125f7
    705958812547:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    70595881254c:	4a 8b 4c 09 08       	mov    rcx,QWORD PTR [rcx+r9*1+0x8]
    705958812551:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    705958812555:	41 89 38             	mov    DWORD PTR [r8],edi
    705958812558:	8b 7c 24 24          	mov    edi,DWORD PTR [rsp+0x24]
    70595881255c:	41 89 78 04          	mov    DWORD PTR [r8+0x4],edi
    705958812560:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
    705958812565:	41 89 78 24          	mov    DWORD PTR [r8+0x24],edi
    705958812569:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    70595881256d:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    705958812572:	41 89 78 34          	mov    DWORD PTR [r8+0x34],edi
    705958812576:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    70595881257d:	45 89 b0 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],r14d
    705958812584:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    705958812588:	41 89 b8 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edi
    70595881258f:	8b 7c 24 20          	mov    edi,DWORD PTR [rsp+0x20]
    705958812593:	41 89 b8 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edi
    70595881259a:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    7059588125a1:	41 89 80 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],eax
    7059588125a8:	41 89 b0 f8 00 00 00 	mov    DWORD PTR [r8+0xf8],esi
    7059588125af:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    7059588125b3:	41 89 80 fc 00 00 00 	mov    DWORD PTR [r8+0xfc],eax
    7059588125ba:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    7059588125be:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    7059588125c5:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    7059588125c9:	41 89 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],eax
    7059588125d0:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    7059588125d7:	00 
    7059588125d8:	41 89 98 34 01 00 00 	mov    DWORD PTR [r8+0x134],ebx
    7059588125df:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    7059588125e6:	4d 89 c5             	mov    r13,r8
    7059588125e9:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    7059588125ee:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7059588125f5:	ff e1                	jmp    rcx
    7059588125f7:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    7059588125fb:	41 89 38             	mov    DWORD PTR [r8],edi
    7059588125fe:	8b 7c 24 24          	mov    edi,DWORD PTR [rsp+0x24]
    705958812602:	41 89 78 04          	mov    DWORD PTR [r8+0x4],edi
    705958812606:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
    70595881260b:	41 89 78 24          	mov    DWORD PTR [r8+0x24],edi
    70595881260f:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705958812613:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    705958812618:	41 89 78 34          	mov    DWORD PTR [r8+0x34],edi
    70595881261c:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    705958812623:	45 89 b0 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],r14d
    70595881262a:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    70595881262e:	41 89 b8 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edi
    705958812635:	8b 7c 24 20          	mov    edi,DWORD PTR [rsp+0x20]
    705958812639:	41 89 b8 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],edi
    705958812640:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    705958812647:	41 89 80 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],eax
    70595881264e:	41 89 b0 f8 00 00 00 	mov    DWORD PTR [r8+0xf8],esi
    705958812655:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    705958812659:	41 89 80 fc 00 00 00 	mov    DWORD PTR [r8+0xfc],eax
    705958812660:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    705958812664:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    70595881266b:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595881266f:	41 89 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],eax
    705958812676:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    70595881267b:	41 88 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],al
    705958812682:	41 89 98 34 01 00 00 	mov    DWORD PTR [r8+0x134],ebx
    705958812689:	41 89 88 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],ecx
    705958812690:	48 81 c4 88 00 00 00 	add    rsp,0x88
    705958812697:	c2 08 00             	ret    0x8
    70595881269a:	41 89 30             	mov    DWORD PTR [r8],esi
    70595881269d:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    7059588126a1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    7059588126a6:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    7059588126aa:	41 89 58 30          	mov    DWORD PTR [r8+0x30],ebx
    7059588126ae:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    7059588126b2:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    7059588126b6:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    7059588126bd:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10418
    7059588126c4:	18 04 01 00 
    7059588126c8:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    7059588126cf:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    7059588126d6:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    7059588126dd:	00 00 00 00 
    7059588126e1:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    7059588126e8:	00 00 00 00 
    7059588126ec:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    7059588126f3:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    7059588126fa:	02 00 00 00 
    7059588126fe:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    705958812705:	00 
    705958812706:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x4
    70595881270d:	04 00 00 00 
    705958812711:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705958812718:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595881271f:	63 00 00 
    705958812722:	4c 89 c7             	mov    rdi,r8
    705958812725:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    70595881272a:	ba 18 04 01 00       	mov    edx,0x10418
    70595881272f:	89 e9                	mov    ecx,ebp
    705958812731:	e9 6d 01 00 00       	jmp    0x7059588128a3
    705958812736:	41 89 30             	mov    DWORD PTR [r8],esi
    705958812739:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    70595881273d:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958812742:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    705958812746:	41 89 58 30          	mov    DWORD PTR [r8+0x30],ebx
    70595881274a:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    70595881274e:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    705958812752:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    705958812759:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10418
    705958812760:	18 04 01 00 
    705958812764:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    70595881276b:	45 89 e5             	mov    r13d,r12d
    70595881276e:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    705958812775:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    70595881277c:	00 00 00 00 
    705958812780:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705958812787:	00 00 00 00 
    70595881278b:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    705958812792:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705958812799:	02 00 00 00 
    70595881279d:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    7059588127a4:	00 
    7059588127a5:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x4
    7059588127ac:	04 00 00 00 
    7059588127b0:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    7059588127b7:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588127be:	63 00 00 
    7059588127c1:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    7059588127c6:	89 ee                	mov    esi,ebp
    7059588127c8:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    7059588127cd:	44 89 d5             	mov    ebp,r10d
    7059588127d0:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    7059588127d5:	ff d0                	call   rax
    7059588127d7:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    7059588127dc:	41 89 ea             	mov    r10d,ebp
    7059588127df:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    7059588127e4:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    7059588127eb:	00 
    7059588127ec:	40 84 ff             	test   dil,dil
    7059588127ef:	0f 85 cd 00 00 00    	jne    0x7059588128c2
    7059588127f5:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    7059588127fa:	44 8b 4c 24 14       	mov    r9d,DWORD PTR [rsp+0x14]
    7059588127ff:	45 89 ec             	mov    r12d,r13d
    705958812802:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    705958812806:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    70595881280b:	e9 38 fb ff ff       	jmp    0x705958812348
    705958812810:	41 89 30             	mov    DWORD PTR [r8],esi
    705958812813:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    705958812817:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    70595881281b:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    70595881281f:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    705958812823:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    705958812827:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    70595881282e:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1041e
    705958812835:	1e 04 01 00 
    705958812839:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    705958812840:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    705958812847:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    70595881284e:	00 00 00 00 
    705958812852:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705958812859:	00 00 00 00 
    70595881285d:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    705958812864:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    70595881286b:	02 00 00 00 
    70595881286f:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    705958812876:	00 
    705958812877:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x7
    70595881287e:	07 00 00 00 
    705958812882:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705958812889:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958812890:	63 00 00 
    705958812893:	4c 89 c7             	mov    rdi,r8
    705958812896:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    70595881289b:	ba 1e 04 01 00       	mov    edx,0x1041e
    7059588128a0:	44 89 e9             	mov    ecx,r13d
    7059588128a3:	4d 89 c5             	mov    r13,r8
    7059588128a6:	45 31 c0             	xor    r8d,r8d
    7059588128a9:	44 89 d5             	mov    ebp,r10d
    7059588128ac:	4d 89 df             	mov    r15,r11
    7059588128af:	ff d0                	call   rax
    7059588128b1:	4d 89 fb             	mov    r11,r15
    7059588128b4:	41 89 ea             	mov    r10d,ebp
    7059588128b7:	4d 89 e8             	mov    r8,r13
    7059588128ba:	41 0f b6 bd 28 01 00 	movzx  edi,BYTE PTR [r13+0x128]
    7059588128c1:	00 
    7059588128c2:	41 8b 00             	mov    eax,DWORD PTR [r8]
    7059588128c5:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7059588128c9:	41 8b 40 04          	mov    eax,DWORD PTR [r8+0x4]
    7059588128cd:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    7059588128d1:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    7059588128d5:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    7059588128d9:	41 8b 40 20          	mov    eax,DWORD PTR [r8+0x20]
    7059588128dd:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    7059588128e4:	00 
    7059588128e5:	41 8b 40 24          	mov    eax,DWORD PTR [r8+0x24]
    7059588128e9:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    7059588128ee:	41 8b 40 2c          	mov    eax,DWORD PTR [r8+0x2c]
    7059588128f2:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    7059588128f7:	45 8b 68 30          	mov    r13d,DWORD PTR [r8+0x30]
    7059588128fb:	41 8b 40 34          	mov    eax,DWORD PTR [r8+0x34]
    7059588128ff:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    705958812904:	45 8b a0 9c 00 00 00 	mov    r12d,DWORD PTR [r8+0x9c]
    70595881290b:	45 8b b0 bc 00 00 00 	mov    r14d,DWORD PTR [r8+0xbc]
    705958812912:	41 8b 80 e4 00 00 00 	mov    eax,DWORD PTR [r8+0xe4]
    705958812919:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    70595881291d:	41 8b 80 e8 00 00 00 	mov    eax,DWORD PTR [r8+0xe8]
    705958812924:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    705958812928:	41 8b 90 ec 00 00 00 	mov    edx,DWORD PTR [r8+0xec]
    70595881292f:	41 8b 80 f0 00 00 00 	mov    eax,DWORD PTR [r8+0xf0]
    705958812936:	40 88 7c 24 0f       	mov    BYTE PTR [rsp+0xf],dil
    70595881293b:	41 8b b0 f8 00 00 00 	mov    esi,DWORD PTR [r8+0xf8]
    705958812942:	41 8b 88 fc 00 00 00 	mov    ecx,DWORD PTR [r8+0xfc]
    705958812949:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    70595881294d:	41 8b 88 00 01 00 00 	mov    ecx,DWORD PTR [r8+0x100]
    705958812954:	89 4c 24 18          	mov    DWORD PTR [rsp+0x18],ecx
    705958812958:	41 8b 88 24 01 00 00 	mov    ecx,DWORD PTR [r8+0x124]
    70595881295f:	89 4c 24 10          	mov    DWORD PTR [rsp+0x10],ecx
    705958812963:	41 8b a8 34 01 00 00 	mov    ebp,DWORD PTR [r8+0x134]
    70595881296a:	41 8b 88 5c 01 00 00 	mov    ecx,DWORD PTR [r8+0x15c]
    705958812971:	e9 8f fa ff ff       	jmp    0x705958812405
    705958812976:	41 89 30             	mov    DWORD PTR [r8],esi
    705958812979:	41 89 58 04          	mov    DWORD PTR [r8+0x4],ebx
    70595881297d:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    705958812981:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705958812985:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    705958812989:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595881298d:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    705958812994:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1041e
    70595881299b:	1e 04 01 00 
    70595881299f:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    7059588129a6:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    7059588129ad:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    7059588129b4:	00 00 00 00 
    7059588129b8:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    7059588129bf:	00 00 00 00 
    7059588129c3:	45 89 b0 00 01 00 00 	mov    DWORD PTR [r8+0x100],r14d
    7059588129ca:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    7059588129d1:	02 00 00 00 
    7059588129d5:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    7059588129dc:	00 
    7059588129dd:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x7
    7059588129e4:	07 00 00 00 
    7059588129e8:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    7059588129ef:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588129f6:	63 00 00 
    7059588129f9:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    7059588129fe:	44 89 ee             	mov    esi,r13d
    705958812a01:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    705958812a06:	44 89 d3             	mov    ebx,r10d
    705958812a09:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    705958812a0e:	ff d0                	call   rax
    705958812a10:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    705958812a15:	41 89 da             	mov    r10d,ebx
    705958812a18:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    705958812a1d:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    705958812a24:	00 
    705958812a25:	40 84 ff             	test   dil,dil
    705958812a28:	0f 85 94 fe ff ff    	jne    0x7059588128c2
    705958812a2e:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    705958812a33:	44 8b 4c 24 14       	mov    r9d,DWORD PTR [rsp+0x14]
    705958812a38:	44 8b 64 24 20       	mov    r12d,DWORD PTR [rsp+0x20]
    705958812a3d:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    705958812a42:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    705958812a46:	89 c2                	mov    edx,eax
    705958812a48:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    705958812a4d:	e9 45 f9 ff ff       	jmp    0x705958812397
    705958812a52:	41 89 30             	mov    DWORD PTR [r8],esi
    705958812a55:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    705958812a59:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    705958812a5d:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705958812a61:	41 89 68 34          	mov    DWORD PTR [r8+0x34],ebp
    705958812a65:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    705958812a69:	41 89 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],eax
    705958812a70:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10420
    705958812a77:	20 04 01 00 
    705958812a7b:	45 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],r9d
    705958812a82:	45 89 a0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],r12d
    705958812a89:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    705958812a90:	00 00 00 00 
    705958812a94:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705958812a9b:	00 00 00 00 
    705958812a9f:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    705958812aa3:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    705958812aaa:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705958812ab1:	02 00 00 00 
    705958812ab5:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    705958812abc:	00 
    705958812abd:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    705958812ac4:	08 00 00 00 
    705958812ac8:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705958812acf:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958812ad6:	63 00 00 
    705958812ad9:	4c 89 c7             	mov    rdi,r8
    705958812adc:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    705958812ae1:	ba 20 04 01 00       	mov    edx,0x10420
    705958812ae6:	4d 89 c5             	mov    r13,r8
    705958812ae9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958812aef:	e9 b5 fd ff ff       	jmp    0x7059588128a9
    705958812af4:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    705958812af8:	41 89 00             	mov    DWORD PTR [r8],eax
    705958812afb:	41 89 50 04          	mov    DWORD PTR [r8+0x4],edx
    705958812aff:	41 89 48 24          	mov    DWORD PTR [r8+0x24],ecx
    705958812b03:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705958812b07:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958812b0c:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    705958812b10:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    705958812b15:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    705958812b1c:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10420
    705958812b23:	20 04 01 00 
    705958812b27:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    705958812b2b:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    705958812b32:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958812b36:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    705958812b3d:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    705958812b44:	00 00 00 00 
    705958812b48:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705958812b4f:	00 00 00 00 
    705958812b53:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    705958812b57:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    705958812b5e:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705958812b65:	02 00 00 00 
    705958812b69:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    705958812b70:	00 
    705958812b71:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    705958812b78:	08 00 00 00 
    705958812b7c:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705958812b83:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958812b8a:	63 00 00 
    705958812b8d:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    705958812b92:	89 ce                	mov    esi,ecx
    705958812b94:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    705958812b99:	44 89 d3             	mov    ebx,r10d
    705958812b9c:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    705958812ba1:	ff d0                	call   rax
    705958812ba3:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    705958812ba8:	41 89 da             	mov    r10d,ebx
    705958812bab:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    705958812bb0:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    705958812bb7:	00 
    705958812bb8:	40 84 ff             	test   dil,dil
    705958812bbb:	0f 84 08 f8 ff ff    	je     0x7059588123c9
    705958812bc1:	e9 fc fc ff ff       	jmp    0x7059588128c2
    705958812bc6:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    705958812bcb:	c7 44 24 44 00 00 00 	mov    DWORD PTR [rsp+0x44],0x0
    705958812bd2:	00 
    705958812bd3:	c7 44 24 10 02 00 00 	mov    DWORD PTR [rsp+0x10],0x2
    705958812bda:	00 
    705958812bdb:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    705958812bdf:	41 89 00             	mov    DWORD PTR [r8],eax
    705958812be2:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    705958812be6:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    705958812bea:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958812bef:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    705958812bf3:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705958812bf7:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958812bfc:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    705958812c00:	45 89 a0 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],r12d
    705958812c07:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10412
    705958812c0e:	12 04 01 00 
    705958812c12:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    705958812c16:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    705958812c1d:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958812c21:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    705958812c28:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    705958812c2f:	00 00 00 00 
    705958812c33:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705958812c3a:	00 00 00 00 
    705958812c3e:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    705958812c42:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    705958812c49:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705958812c50:	02 00 00 00 
    705958812c54:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    705958812c5b:	01 
    705958812c5c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    705958812c63:	08 00 00 00 
    705958812c67:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705958812c6e:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958812c75:	63 00 00 
    705958812c78:	4c 89 c7             	mov    rdi,r8
    705958812c7b:	4c 89 44 24 50       	mov    QWORD PTR [rsp+0x50],r8
    705958812c80:	44 89 54 24 74       	mov    DWORD PTR [rsp+0x74],r10d
    705958812c85:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    705958812c8a:	ff d0                	call   rax
    705958812c8c:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    705958812c91:	44 8b 54 24 74       	mov    r10d,DWORD PTR [rsp+0x74]
    705958812c96:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
    705958812c9b:	41 0f b6 b8 28 01 00 	movzx  edi,BYTE PTR [r8+0x128]
    705958812ca2:	00 
    705958812ca3:	44 89 f9             	mov    ecx,r15d
    705958812ca6:	be 00 00 00 00       	mov    esi,0x0
    705958812cab:	b8 00 00 00 00       	mov    eax,0x0
    705958812cb0:	ba 00 00 00 00       	mov    edx,0x0
    705958812cb5:	40 84 ff             	test   dil,dil
    705958812cb8:	0f 84 47 f7 ff ff    	je     0x705958812405
    705958812cbe:	e9 ff fb ff ff       	jmp    0x7059588128c2
