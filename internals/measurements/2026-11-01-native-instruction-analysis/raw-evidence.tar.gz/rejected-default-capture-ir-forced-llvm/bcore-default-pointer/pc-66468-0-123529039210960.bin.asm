
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66468-0-123529039210960.bin:     file format binary


Disassembly of section .data:

00007059588069d0 <.data>:
    7059588069d0:	48 83 ec 48          	sub    rsp,0x48
    7059588069d4:	4c 89 74 24 30       	mov    QWORD PTR [rsp+0x30],r14
    7059588069d9:	4c 89 6c 24 38       	mov    QWORD PTR [rsp+0x38],r13
    7059588069de:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7059588069e5:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    7059588069ea:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    7059588069ef:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    7059588069f5:	83 fa 00             	cmp    edx,0x0
    7059588069f8:	0f 94 c0             	sete   al
    7059588069fb:	81 ea a4 03 01 00    	sub    edx,0x103a4
    705958806a01:	83 fa 10             	cmp    edx,0x10
    705958806a04:	0f 97 c2             	seta   dl
    705958806a07:	08 d0                	or     al,dl
    705958806a09:	24 01                	and    al,0x1
    705958806a0b:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958806a11:	83 fa 00             	cmp    edx,0x0
    705958806a14:	0f 94 c1             	sete   cl
    705958806a17:	81 ea a4 03 01 00    	sub    edx,0x103a4
    705958806a1d:	83 fa 10             	cmp    edx,0x10
    705958806a20:	0f 97 c2             	seta   dl
    705958806a23:	08 d1                	or     cl,dl
    705958806a25:	20 c8                	and    al,cl
    705958806a27:	a8 01                	test   al,0x1
    705958806a29:	75 05                	jne    0x705958806a30
    705958806a2b:	e9 7a 01 00 00       	jmp    0x705958806baa
    705958806a30:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806a35:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958806a3c:	48 89 c8             	mov    rax,rcx
    705958806a3f:	48 05 00 00 10 00    	add    rax,0x100000
    705958806a45:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    705958806a4a:	8b 81 10 00 10 00    	mov    eax,DWORD PTR [rcx+0x100010]
    705958806a50:	83 c0 01             	add    eax,0x1
    705958806a53:	89 81 10 00 10 00    	mov    DWORD PTR [rcx+0x100010],eax
    705958806a59:	3d 30 75 00 00       	cmp    eax,0x7530
    705958806a5e:	75 40                	jne    0x705958806aa0
    705958806a60:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
    705958806a65:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958806a6b:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    705958806a6f:	89 c2                	mov    edx,eax
    705958806a71:	83 c2 01             	add    edx,0x1
    705958806a74:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958806a7a:	3d 00 01 00 00       	cmp    eax,0x100
    705958806a7f:	73 1d                	jae    0x705958806a9e
    705958806a81:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958806a86:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    705958806a8a:	89 c9                	mov    ecx,ecx
    705958806a8c:	48 c1 e1 02          	shl    rcx,0x2
    705958806a90:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958806a97:	c7 04 08 04 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x4
    705958806a9e:	eb 00                	jmp    0x705958806aa0
    705958806aa0:	eb 00                	jmp    0x705958806aa2
    705958806aa2:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806aa7:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    705958806aaa:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958806ab0:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958806ab6:	89 4c 24 1c          	mov    DWORD PTR [rsp+0x1c],ecx
    705958806aba:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    705958806abd:	8b 80 a0 00 00 00    	mov    eax,DWORD PTR [rax+0xa0]
    705958806ac3:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    705958806ac7:	eb 00                	jmp    0x705958806ac9
    705958806ac9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806ace:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    705958806ad2:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958806ad8:	81 c9 fc 92 00 00    	or     ecx,0x92fc
    705958806ade:	89 4c 24 18          	mov    DWORD PTR [rsp+0x18],ecx
    705958806ae2:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    705958806ae5:	eb 00                	jmp    0x705958806ae7
    705958806ae7:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806aec:	8b 4c 24 18          	mov    ecx,DWORD PTR [rsp+0x18]
    705958806af0:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    705958806af3:	eb 00                	jmp    0x705958806af5
    705958806af5:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806afa:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    705958806b00:	eb 00                	jmp    0x705958806b02
    705958806b02:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806b07:	c7 40 28 00 20 00 00 	mov    DWORD PTR [rax+0x28],0x2000
    705958806b0e:	eb 00                	jmp    0x705958806b10
    705958806b10:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958806b14:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    705958806b19:	c7 81 94 00 00 00 b8 	mov    DWORD PTR [rcx+0x94],0x103b8
    705958806b20:	03 01 00 
    705958806b23:	c7 81 a4 00 00 00 ba 	mov    DWORD PTR [rcx+0xa4],0x103ba
    705958806b2a:	03 01 00 
    705958806b2d:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x2000
    705958806b34:	20 00 00 
    705958806b37:	c7 81 bc 00 00 00 b8 	mov    DWORD PTR [rcx+0xbc],0x103b8
    705958806b3e:	03 01 00 
    705958806b41:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    705958806b48:	3d b4 03 01 00       	cmp    eax,0x103b4
    705958806b4d:	0f 94 c0             	sete   al
    705958806b50:	0c 00                	or     al,0x0
    705958806b52:	a8 01                	test   al,0x1
    705958806b54:	75 02                	jne    0x705958806b58
    705958806b56:	eb 36                	jmp    0x705958806b8e
    705958806b58:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
    705958806b5d:	c7 87 bc 00 00 00 b8 	mov    DWORD PTR [rdi+0xbc],0x103b8
    705958806b64:	03 01 00 
    705958806b67:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958806b6e:	00 00 00 
    705958806b71:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    705958806b78:	00 00 00 
    705958806b7b:	48 b8 20 6d 8c 23 5a 	movabs rax,0x635a238c6d20
    705958806b82:	63 00 00 
    705958806b85:	ba b4 03 01 00       	mov    edx,0x103b4
    705958806b8a:	89 d6                	mov    esi,edx
    705958806b8c:	ff d0                	call   rax
    705958806b8e:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    705958806b93:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958806b99:	83 c0 06             	add    eax,0x6
    705958806b9c:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    705958806ba0:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958806ba6:	72 10                	jb     0x705958806bb8
    705958806ba8:	eb 2e                	jmp    0x705958806bd8
    705958806baa:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806baf:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958806bb6:	eb 7c                	jmp    0x705958806c34
    705958806bb8:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    705958806bbd:	48 89 c1             	mov    rcx,rax
    705958806bc0:	48 81 c1 c0 1d 08 00 	add    rcx,0x81dc0
    705958806bc7:	48 89 4c 24 08       	mov    QWORD PTR [rsp+0x8],rcx
    705958806bcc:	81 b8 c0 1d 08 00 b8 	cmp    DWORD PTR [rax+0x81dc0],0x103b8
    705958806bd3:	03 01 00 
    705958806bd6:	74 25                	je     0x705958806bfd
    705958806bd8:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806bdd:	c7 80 bc 00 00 00 b8 	mov    DWORD PTR [rax+0xbc],0x103b8
    705958806be4:	03 01 00 
    705958806be7:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958806bee:	00 00 00 
    705958806bf1:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    705958806bf8:	00 00 00 
    705958806bfb:	eb 37                	jmp    0x705958806c34
    705958806bfd:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
    705958806c02:	4c 8b 6c 24 38       	mov    r13,QWORD PTR [rsp+0x38]
    705958806c07:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958806c0c:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    705958806c10:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103b8
    705958806c17:	b8 03 01 00 
    705958806c1b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958806c22:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958806c29:	00 
    705958806c2a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958806c2e:	48 83 c4 48          	add    rsp,0x48
    705958806c32:	ff e0                	jmp    rax
    705958806c34:	48 83 c4 48          	add    rsp,0x48
    705958806c38:	c2 08 00             	ret    0x8
