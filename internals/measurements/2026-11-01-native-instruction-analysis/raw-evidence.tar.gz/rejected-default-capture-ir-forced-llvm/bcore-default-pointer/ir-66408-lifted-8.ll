; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010368(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 66408
  %5 = icmp ugt i32 %4, 6
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb101 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb101, 66592
  %10 = sub i32 %guard_lb101, 66408
  %11 = icmp ugt i32 %10, 6
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x00010368_entry, label %lb_guard_miss, !prof !0

insn_0x00010368_entry:                            ; preds = %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table121 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table121, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 32
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x00010368_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 8, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x00010368_entry, %27
  br label %insn_0x00010368

insn_0x00010368:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %29, align 4
  %30 = and i32 %fp, 3
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010368
  %32 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %33, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %fp, i32 0)
  %34 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i64 188
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %cpu, i64 296
  %38 = load i8, ptr %37, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010368
  %39 = lshr i32 %fp, 12
  %page_index = zext i32 %39 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %40 = and i32 %fp, 4095
  %page_offset = zext i32 %40 to i64
  %41 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %41, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %42 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %43, align 4
  %44 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %45 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %45, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %44, %did_jump_cont ]
  %sp1 = add i32 %fp, 4
  %46 = and i32 %sp1, 3
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %data_misaligned1, label %data_aligned2, !prof !1

did_jump_exit:                                    ; preds = %page_slow
  %48 = getelementptr i8, ptr %cpu, i64 188
  %next_pc102 = load i32, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i64 188
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %cpu, i64 296
  %52 = load i8, ptr %51, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

data_misaligned1:                                 ; preds = %page_done
  %53 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %54, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %sp1, i32 0)
  %55 = getelementptr i8, ptr %cpu, i64 188
  %next_pc103 = load i32, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i64 188
  %57 = load i32, ptr %56, align 4
  %58 = getelementptr i8, ptr %cpu, i64 296
  %59 = load i8, ptr %58, align 1
  br label %chain_exit

data_aligned2:                                    ; preds = %page_done
  %60 = lshr i32 %sp1, 12
  %page_index6 = zext i32 %60 to i64
  %page_slot7 = getelementptr ptr, ptr %page_table, i64 %page_index6
  %page8 = load ptr, ptr %page_slot7, align 8
  %page_mapped9 = icmp ne ptr %page8, null
  br i1 %page_mapped9, label %page_fast3, label %page_slow4, !prof !0

page_fast3:                                       ; preds = %data_aligned2
  %61 = and i32 %sp1, 4095
  %page_offset10 = zext i32 %61 to i64
  %62 = getelementptr i8, ptr %page8, i64 %page_offset10
  %page_val11 = load i32, ptr %62, align 4
  br label %page_done5

page_slow4:                                       ; preds = %data_aligned2
  %63 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %64, align 4
  %65 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %66 = getelementptr i8, ptr %cpu, i32 296
  %dj14 = load i8, ptr %66, align 1
  %dj_set15 = icmp ne i8 %dj14, 0
  br i1 %dj_set15, label %did_jump_exit12, label %did_jump_cont13, !prof !1

page_done5:                                       ; preds = %did_jump_cont13, %page_fast3
  %mem_val16 = phi i32 [ %page_val11, %page_fast3 ], [ %65, %did_jump_cont13 ]
  %sp2 = add i32 %sp1, 4
  %67 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val16, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %71, align 4
  br label %insn_0x0001036c_entry

did_jump_exit12:                                  ; preds = %page_slow4
  %72 = getelementptr i8, ptr %cpu, i64 188
  %next_pc104 = load i32, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 188
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %cpu, i64 296
  %76 = load i8, ptr %75, align 1
  br label %chain_exit

did_jump_cont13:                                  ; preds = %page_slow4
  br label %page_done5

insn_0x0001036c_entry:                            ; preds = %page_done5
  br label %insn_0x0001036c

insn_0x0001036c:                                  ; preds = %insn_0x0001036c_entry
  %77 = and i32 %sp2, 3
  %78 = icmp ne i32 %77, 0
  br i1 %78, label %data_misaligned17, label %data_aligned18, !prof !1

data_misaligned17:                                ; preds = %insn_0x0001036c
  %79 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %81, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp2, i32 0)
  %82 = getelementptr i8, ptr %cpu, i64 188
  %next_pc105 = load i32, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i64 188
  %84 = load i32, ptr %83, align 4
  %85 = getelementptr i8, ptr %cpu, i64 296
  %86 = load i8, ptr %85, align 1
  br label %chain_exit

data_aligned18:                                   ; preds = %insn_0x0001036c
  %87 = lshr i32 %sp2, 12
  %page_index22 = zext i32 %87 to i64
  %page_slot23 = getelementptr ptr, ptr %page_table, i64 %page_index22
  %page24 = load ptr, ptr %page_slot23, align 8
  %page_mapped25 = icmp ne ptr %page24, null
  br i1 %page_mapped25, label %page_fast19, label %page_slow20, !prof !0

page_fast19:                                      ; preds = %data_aligned18
  %88 = and i32 %sp2, 4095
  %page_offset26 = zext i32 %88 to i64
  %89 = getelementptr i8, ptr %page24, i64 %page_offset26
  %page_val27 = load i32, ptr %89, align 4
  br label %page_done21

page_slow20:                                      ; preds = %data_aligned18
  %90 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %92, align 4
  %93 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %94 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %94, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_done21:                                      ; preds = %did_jump_cont29, %page_fast19
  %mem_val32 = phi i32 [ %page_val27, %page_fast19 ], [ %93, %did_jump_cont29 ]
  %95 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val32, ptr %95, align 4
  %sp_inc = add i32 %sp2, 4
  %96 = and i32 %sp_inc, 3
  %97 = icmp ne i32 %96, 0
  br i1 %97, label %data_misaligned33, label %data_aligned34, !prof !1

did_jump_exit28:                                  ; preds = %page_slow20
  %98 = getelementptr i8, ptr %cpu, i64 188
  %next_pc106 = load i32, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 188
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %cpu, i64 296
  %102 = load i8, ptr %101, align 1
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_slow20
  br label %page_done21

data_misaligned33:                                ; preds = %page_done21
  %103 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %105, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc, i32 0)
  %106 = getelementptr i8, ptr %cpu, i64 188
  %next_pc107 = load i32, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i64 188
  %108 = load i32, ptr %107, align 4
  %109 = getelementptr i8, ptr %cpu, i64 296
  %110 = load i8, ptr %109, align 1
  br label %chain_exit

data_aligned34:                                   ; preds = %page_done21
  %111 = lshr i32 %sp_inc, 12
  %page_index38 = zext i32 %111 to i64
  %page_slot39 = getelementptr ptr, ptr %page_table, i64 %page_index38
  %page40 = load ptr, ptr %page_slot39, align 8
  %page_mapped41 = icmp ne ptr %page40, null
  br i1 %page_mapped41, label %page_fast35, label %page_slow36, !prof !0

page_fast35:                                      ; preds = %data_aligned34
  %112 = and i32 %sp_inc, 4095
  %page_offset42 = zext i32 %112 to i64
  %113 = getelementptr i8, ptr %page40, i64 %page_offset42
  %page_val43 = load i32, ptr %113, align 4
  br label %page_done37

page_slow36:                                      ; preds = %data_aligned34
  %114 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %116, align 4
  %117 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %118 = getelementptr i8, ptr %cpu, i32 296
  %dj46 = load i8, ptr %118, align 1
  %dj_set47 = icmp ne i8 %dj46, 0
  br i1 %dj_set47, label %did_jump_exit44, label %did_jump_cont45, !prof !1

page_done37:                                      ; preds = %did_jump_cont45, %page_fast35
  %mem_val48 = phi i32 [ %page_val43, %page_fast35 ], [ %117, %did_jump_cont45 ]
  %119 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val48, ptr %119, align 4
  %sp_inc49 = add i32 %sp_inc, 4
  %120 = and i32 %sp_inc49, 3
  %121 = icmp ne i32 %120, 0
  br i1 %121, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit44:                                  ; preds = %page_slow36
  %122 = getelementptr i8, ptr %cpu, i64 188
  %next_pc108 = load i32, ptr %122, align 4
  %123 = getelementptr i8, ptr %cpu, i64 188
  %124 = load i32, ptr %123, align 4
  %125 = getelementptr i8, ptr %cpu, i64 296
  %126 = load i8, ptr %125, align 1
  br label %chain_exit

did_jump_cont45:                                  ; preds = %page_slow36
  br label %page_done37

data_misaligned50:                                ; preds = %page_done37
  %127 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %129, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc49, i32 0)
  %130 = getelementptr i8, ptr %cpu, i64 188
  %next_pc109 = load i32, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 188
  %132 = load i32, ptr %131, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  %134 = load i8, ptr %133, align 1
  br label %chain_exit

data_aligned51:                                   ; preds = %page_done37
  %135 = lshr i32 %sp_inc49, 12
  %page_index55 = zext i32 %135 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_fast52, label %page_slow53, !prof !0

page_fast52:                                      ; preds = %data_aligned51
  %136 = and i32 %sp_inc49, 4095
  %page_offset59 = zext i32 %136 to i64
  %137 = getelementptr i8, ptr %page57, i64 %page_offset59
  %page_val60 = load i32, ptr %137, align 4
  br label %page_done54

page_slow53:                                      ; preds = %data_aligned51
  %138 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %140, align 4
  %141 = call i32 @mem_read32(ptr %mem, i32 %sp_inc49)
  %142 = getelementptr i8, ptr %cpu, i32 296
  %dj63 = load i8, ptr %142, align 1
  %dj_set64 = icmp ne i8 %dj63, 0
  br i1 %dj_set64, label %did_jump_exit61, label %did_jump_cont62, !prof !1

page_done54:                                      ; preds = %did_jump_cont62, %page_fast52
  %mem_val65 = phi i32 [ %page_val60, %page_fast52 ], [ %141, %did_jump_cont62 ]
  %143 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val65, ptr %143, align 4
  %sp_inc66 = add i32 %sp_inc49, 4
  %144 = and i32 %sp_inc66, 3
  %145 = icmp ne i32 %144, 0
  br i1 %145, label %data_misaligned67, label %data_aligned68, !prof !1

did_jump_exit61:                                  ; preds = %page_slow53
  %146 = getelementptr i8, ptr %cpu, i64 188
  %next_pc110 = load i32, ptr %146, align 4
  %147 = getelementptr i8, ptr %cpu, i64 188
  %148 = load i32, ptr %147, align 4
  %149 = getelementptr i8, ptr %cpu, i64 296
  %150 = load i8, ptr %149, align 1
  br label %chain_exit

did_jump_cont62:                                  ; preds = %page_slow53
  br label %page_done54

data_misaligned67:                                ; preds = %page_done54
  %151 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %153, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc66, i32 0)
  %154 = getelementptr i8, ptr %cpu, i64 188
  %next_pc111 = load i32, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 188
  %156 = load i32, ptr %155, align 4
  %157 = getelementptr i8, ptr %cpu, i64 296
  %158 = load i8, ptr %157, align 1
  br label %chain_exit

data_aligned68:                                   ; preds = %page_done54
  %159 = lshr i32 %sp_inc66, 12
  %page_index72 = zext i32 %159 to i64
  %page_slot73 = getelementptr ptr, ptr %page_table, i64 %page_index72
  %page74 = load ptr, ptr %page_slot73, align 8
  %page_mapped75 = icmp ne ptr %page74, null
  br i1 %page_mapped75, label %page_fast69, label %page_slow70, !prof !0

page_fast69:                                      ; preds = %data_aligned68
  %160 = and i32 %sp_inc66, 4095
  %page_offset76 = zext i32 %160 to i64
  %161 = getelementptr i8, ptr %page74, i64 %page_offset76
  %page_val77 = load i32, ptr %161, align 4
  br label %page_done71

page_slow70:                                      ; preds = %data_aligned68
  %162 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %163, align 4
  %164 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %164, align 4
  %165 = call i32 @mem_read32(ptr %mem, i32 %sp_inc66)
  %166 = getelementptr i8, ptr %cpu, i32 296
  %dj80 = load i8, ptr %166, align 1
  %dj_set81 = icmp ne i8 %dj80, 0
  br i1 %dj_set81, label %did_jump_exit78, label %did_jump_cont79, !prof !1

page_done71:                                      ; preds = %did_jump_cont79, %page_fast69
  %mem_val82 = phi i32 [ %page_val77, %page_fast69 ], [ %165, %did_jump_cont79 ]
  %167 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val82, ptr %167, align 4
  %sp_inc83 = add i32 %sp_inc66, 4
  %168 = and i32 %sp_inc83, 3
  %169 = icmp ne i32 %168, 0
  br i1 %169, label %data_misaligned84, label %data_aligned85, !prof !1

did_jump_exit78:                                  ; preds = %page_slow70
  %170 = getelementptr i8, ptr %cpu, i64 188
  %next_pc112 = load i32, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i64 188
  %172 = load i32, ptr %171, align 4
  %173 = getelementptr i8, ptr %cpu, i64 296
  %174 = load i8, ptr %173, align 1
  br label %chain_exit

did_jump_cont79:                                  ; preds = %page_slow70
  br label %page_done71

data_misaligned84:                                ; preds = %page_done71
  %175 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %177, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc83, i32 0)
  %178 = getelementptr i8, ptr %cpu, i64 188
  %next_pc113 = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 188
  %180 = load i32, ptr %179, align 4
  %181 = getelementptr i8, ptr %cpu, i64 296
  %182 = load i8, ptr %181, align 1
  br label %chain_exit

data_aligned85:                                   ; preds = %page_done71
  %183 = lshr i32 %sp_inc83, 12
  %page_index89 = zext i32 %183 to i64
  %page_slot90 = getelementptr ptr, ptr %page_table, i64 %page_index89
  %page91 = load ptr, ptr %page_slot90, align 8
  %page_mapped92 = icmp ne ptr %page91, null
  br i1 %page_mapped92, label %page_fast86, label %page_slow87, !prof !0

page_fast86:                                      ; preds = %data_aligned85
  %184 = and i32 %sp_inc83, 4095
  %page_offset93 = zext i32 %184 to i64
  %185 = getelementptr i8, ptr %page91, i64 %page_offset93
  %page_val94 = load i32, ptr %185, align 4
  br label %page_done88

page_slow87:                                      ; preds = %data_aligned85
  %186 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %188, align 4
  %189 = call i32 @mem_read32(ptr %mem, i32 %sp_inc83)
  %190 = getelementptr i8, ptr %cpu, i32 296
  %dj97 = load i8, ptr %190, align 1
  %dj_set98 = icmp ne i8 %dj97, 0
  br i1 %dj_set98, label %did_jump_exit95, label %did_jump_cont96, !prof !1

page_done88:                                      ; preds = %did_jump_cont96, %page_fast86
  %mem_val99 = phi i32 [ %page_val94, %page_fast86 ], [ %189, %did_jump_cont96 ]
  %191 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val99, ptr %191, align 4
  %sp_inc100 = add i32 %sp_inc83, 4
  %192 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc100, ptr %192, align 4
  br label %insn_0x0001036e_entry

did_jump_exit95:                                  ; preds = %page_slow87
  %193 = getelementptr i8, ptr %cpu, i64 188
  %next_pc114 = load i32, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i64 188
  %195 = load i32, ptr %194, align 4
  %196 = getelementptr i8, ptr %cpu, i64 296
  %197 = load i8, ptr %196, align 1
  br label %chain_exit

did_jump_cont96:                                  ; preds = %page_slow87
  br label %page_done88

insn_0x0001036e_entry:                            ; preds = %page_done88
  br label %insn_0x0001036e

insn_0x0001036e:                                  ; preds = %insn_0x0001036e_entry
  %lsb = and i32 %mem_val16, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001036e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001036e
  %198 = getelementptr i8, ptr %cpu, i32 188
  store i32 66414, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %200, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %201 = getelementptr i8, ptr %cpu, i64 188
  %next_pc115 = load i32, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i64 188
  %203 = load i32, ptr %202, align 4
  %204 = getelementptr i8, ptr %cpu, i64 296
  %205 = load i8, ptr %204, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %206 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %206, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit95, %data_misaligned84, %did_jump_exit78, %data_misaligned67, %did_jump_exit61, %data_misaligned50, %did_jump_exit44, %data_misaligned33, %did_jump_exit28, %data_misaligned17, %did_jump_exit12, %data_misaligned1, %did_jump_exit, %data_misaligned
  %next_pc116 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc102, %did_jump_exit ], [ %next_pc103, %data_misaligned1 ], [ %next_pc104, %did_jump_exit12 ], [ %next_pc105, %data_misaligned17 ], [ %next_pc106, %did_jump_exit28 ], [ %next_pc107, %data_misaligned33 ], [ %next_pc108, %did_jump_exit44 ], [ %next_pc109, %data_misaligned50 ], [ %next_pc110, %did_jump_exit61 ], [ %next_pc111, %data_misaligned67 ], [ %next_pc112, %did_jump_exit78 ], [ %next_pc113, %data_misaligned84 ], [ %next_pc114, %did_jump_exit95 ], [ %mem_val16, %jump_aligned ], [ %next_pc115, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned1 ], [ 1, %did_jump_exit12 ], [ 2, %data_misaligned17 ], [ 2, %did_jump_exit28 ], [ 2, %data_misaligned33 ], [ 2, %did_jump_exit44 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit61 ], [ 2, %data_misaligned67 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned84 ], [ 2, %did_jump_exit95 ], [ 3, %jump_aligned ], [ 3, %jump_misalign ]
  %tail = phi i32 [ %36, %data_misaligned ], [ %50, %did_jump_exit ], [ %57, %data_misaligned1 ], [ %74, %did_jump_exit12 ], [ %84, %data_misaligned17 ], [ %100, %did_jump_exit28 ], [ %108, %data_misaligned33 ], [ %124, %did_jump_exit44 ], [ %132, %data_misaligned50 ], [ %148, %did_jump_exit61 ], [ %156, %data_misaligned67 ], [ %172, %did_jump_exit78 ], [ %180, %data_misaligned84 ], [ %195, %did_jump_exit95 ], [ %mem_val16, %jump_aligned ], [ %203, %jump_misalign ]
  %tail117 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned1 ], [ 4, %did_jump_exit12 ], [ 2, %data_misaligned17 ], [ 2, %did_jump_exit28 ], [ 2, %data_misaligned33 ], [ 2, %did_jump_exit44 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit61 ], [ 2, %data_misaligned67 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned84 ], [ 2, %did_jump_exit95 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail118 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned1 ], [ 1, %did_jump_exit12 ], [ 2, %data_misaligned17 ], [ 2, %did_jump_exit28 ], [ 2, %data_misaligned33 ], [ 2, %did_jump_exit44 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit61 ], [ 2, %data_misaligned67 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned84 ], [ 2, %did_jump_exit95 ], [ 3, %jump_aligned ], [ 3, %jump_misalign ]
  %tail119 = phi i8 [ %38, %data_misaligned ], [ %52, %did_jump_exit ], [ %59, %data_misaligned1 ], [ %76, %did_jump_exit12 ], [ %86, %data_misaligned17 ], [ %102, %did_jump_exit28 ], [ %110, %data_misaligned33 ], [ %126, %did_jump_exit44 ], [ %134, %data_misaligned50 ], [ %150, %did_jump_exit61 ], [ %158, %data_misaligned67 ], [ %174, %did_jump_exit78 ], [ %182, %data_misaligned84 ], [ %197, %did_jump_exit95 ], [ 1, %jump_aligned ], [ %205, %jump_misalign ]
  %207 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %207, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %208 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %208 monotonic, align 4, !range !2
  %209 = icmp ult i32 %chain_total, %chain_budget
  br i1 %209, label %chain_lookup, label %chain_leave120, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %210 = lshr i32 %next_pc116, 1
  %211 = and i32 %210, 65535
  %212 = zext i32 %211 to i64
  %213 = mul i64 %212, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %213
  %214 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %214, align 4
  %215 = icmp eq i32 %slot_pc, %next_pc116
  br i1 %215, label %chain_hit, label %chain_leave120, !prof !0

chain_leave120:                                   ; preds = %chain_lookup, %chain_exit
  %216 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %216, align 4
  %217 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail117, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail118, ptr %218, align 4
  %219 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail119, ptr %219, align 1
  br label %return

chain_hit:                                        ; preds = %chain_lookup
  %220 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc116, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %221, align 4
  %222 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %222, align 1
  %223 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %223, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave120, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
