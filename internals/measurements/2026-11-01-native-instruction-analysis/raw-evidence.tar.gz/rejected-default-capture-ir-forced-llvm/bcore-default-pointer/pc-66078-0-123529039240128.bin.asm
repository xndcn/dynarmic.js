
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66078-0-123529039240128.bin:     file format binary


Disassembly of section .data:

000070595880dbc0 <.data>:
    70595880dbc0:	48 83 ec 78          	sub    rsp,0x78
    70595880dbc4:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    70595880dbc9:	4c 89 ee             	mov    rsi,r13
    70595880dbcc:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880dbd3:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    70595880dbd8:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    70595880dbdf:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880dbe3:	b8 c9 fd fe ff       	mov    eax,0xfffefdc9
    70595880dbe8:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    70595880dbef:	01 c1                	add    ecx,eax
    70595880dbf1:	83 f9 e6             	cmp    ecx,0xffffffe6
    70595880dbf4:	0f 87 06 24 ff 17    	ja     0x705970800000
    70595880dbfa:	03 86 a0 00 00 00    	add    eax,DWORD PTR [rsi+0xa0]
    70595880dc00:	83 f8 e6             	cmp    eax,0xffffffe6
    70595880dc03:	0f 87 f7 23 ff 17    	ja     0x705970800000
    70595880dc09:	48 8b 86 38 01 00 00 	mov    rax,QWORD PTR [rsi+0x138]
    70595880dc10:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    70595880dc15:	8b 06                	mov    eax,DWORD PTR [rsi]
    70595880dc17:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    70595880dc1b:	8b 46 04             	mov    eax,DWORD PTR [rsi+0x4]
    70595880dc1e:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    70595880dc22:	44 8b 6e 08          	mov    r13d,DWORD PTR [rsi+0x8]
    70595880dc26:	44 8b 7e 0c          	mov    r15d,DWORD PTR [rsi+0xc]
    70595880dc2a:	8b 46 1c             	mov    eax,DWORD PTR [rsi+0x1c]
    70595880dc2d:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    70595880dc32:	8b 46 24             	mov    eax,DWORD PTR [rsi+0x24]
    70595880dc35:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    70595880dc3a:	44 8b b6 00 01 00 00 	mov    r14d,DWORD PTR [rsi+0x100]
    70595880dc41:	8b 96 5c 01 00 00    	mov    edx,DWORD PTR [rsi+0x15c]
    70595880dc47:	48 89 f7             	mov    rdi,rsi
    70595880dc4a:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    70595880dc4f:	90                   	nop
    70595880dc50:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880dc55:	c1 e8 1f             	shr    eax,0x1f
    70595880dc58:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    70595880dc5c:	41 ff c7             	inc    r15d
    70595880dc5f:	44 89 f9             	mov    ecx,r15d
    70595880dc62:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    70595880dc67:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    70595880dc6c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
    70595880dc70:	41 89 cf             	mov    r15d,ecx
    70595880dc73:	41 8d 47 ff          	lea    eax,[r15-0x1]
    70595880dc77:	c1 e8 1f             	shr    eax,0x1f
    70595880dc7a:	c1 e9 1f             	shr    ecx,0x1f
    70595880dc7d:	c4 e2 78 f2 c1       	andn   eax,eax,ecx
    70595880dc82:	41 09 c6             	or     r14d,eax
    70595880dc85:	45 31 e4             	xor    r12d,r12d
    70595880dc88:	45 31 d2             	xor    r10d,r10d
    70595880dc8b:	31 f6                	xor    esi,esi
    70595880dc8d:	31 db                	xor    ebx,ebx
    70595880dc8f:	44 39 7c 24 08       	cmp    DWORD PTR [rsp+0x8],r15d
    70595880dc94:	41 0f 96 c4          	setbe  r12b
    70595880dc98:	44 89 ed             	mov    ebp,r13d
    70595880dc9b:	41 89 d1             	mov    r9d,edx
    70595880dc9e:	41 0f 94 c2          	sete   r10b
    70595880dca2:	40 0f 92 c6          	setb   sil
    70595880dca6:	0f 93 c3             	setae  bl
    70595880dca9:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    70595880dcae:	8d 0c a9             	lea    ecx,[rcx+rbp*4]
    70595880dcb1:	f6 c1 03             	test   cl,0x3
    70595880dcb4:	0f 85 12 03 00 00    	jne    0x70595880dfcc
    70595880dcba:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    70595880dcbf:	89 ca                	mov    edx,ecx
    70595880dcc1:	c1 ea 0c             	shr    edx,0xc
    70595880dcc4:	49 8b 14 d0          	mov    rdx,QWORD PTR [r8+rdx*8]
    70595880dcc8:	48 85 d2             	test   rdx,rdx
    70595880dccb:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    70595880dcd0:	0f 84 32 04 00 00    	je     0x70595880e108
    70595880dcd6:	89 c8                	mov    eax,ecx
    70595880dcd8:	25 ff 0f 00 00       	and    eax,0xfff
    70595880dcdd:	8b 14 02             	mov    edx,DWORD PTR [rdx+rax*1]
    70595880dce0:	44 89 d8             	mov    eax,r11d
    70595880dce3:	31 d0                	xor    eax,edx
    70595880dce5:	48 8b 4c 24 18       	mov    rcx,QWORD PTR [rsp+0x18]
    70595880dcea:	44 8d 1c 08          	lea    r11d,[rax+rcx*1]
    70595880dcee:	89 c5                	mov    ebp,eax
    70595880dcf0:	c1 ed 1f             	shr    ebp,0x1f
    70595880dcf3:	44 89 db             	mov    ebx,r11d
    70595880dcf6:	c1 eb 1f             	shr    ebx,0x1f
    70595880dcf9:	89 d9                	mov    ecx,ebx
    70595880dcfb:	33 4c 24 10          	xor    ecx,DWORD PTR [rsp+0x10]
    70595880dcff:	31 dd                	xor    ebp,ebx
    70595880dd01:	21 cd                	and    ebp,ecx
    70595880dd03:	41 09 ee             	or     r14d,ebp
    70595880dd06:	44 39 7c 24 08       	cmp    DWORD PTR [rsp+0x8],r15d
    70595880dd0b:	41 89 d5             	mov    r13d,edx
    70595880dd0e:	76 30                	jbe    0x70595880dd40
    70595880dd10:	41 8d 51 08          	lea    edx,[r9+0x8]
    70595880dd14:	3b 54 24 54          	cmp    edx,DWORD PTR [rsp+0x54]
    70595880dd18:	0f 83 10 02 00 00    	jae    0x70595880df2e
    70595880dd1e:	8b b7 58 01 00 00    	mov    esi,DWORD PTR [rdi+0x158]
    70595880dd24:	41 8d 4f 01          	lea    ecx,[r15+0x1]
    70595880dd28:	85 f6                	test   esi,esi
    70595880dd2a:	0f 85 40 ff ff ff    	jne    0x70595880dc70
    70595880dd30:	e9 f9 01 00 00       	jmp    0x70595880df2e
    70595880dd35:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
    70595880dd3c:	00 00 00 00 
    70595880dd40:	45 31 d2             	xor    r10d,r10d
    70595880dd43:	03 44 24 18          	add    eax,DWORD PTR [rsp+0x18]
    70595880dd47:	41 0f 92 c2          	setb   r10b
    70595880dd4b:	31 f6                	xor    esi,esi
    70595880dd4d:	45 85 db             	test   r11d,r11d
    70595880dd50:	40 0f 94 c6          	sete   sil
    70595880dd54:	8b 4f 3c             	mov    ecx,DWORD PTR [rdi+0x3c]
    70595880dd57:	f6 c1 03             	test   cl,0x3
    70595880dd5a:	0f 85 0d 05 00 00    	jne    0x70595880e26d
    70595880dd60:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    70595880dd64:	48 89 c8             	mov    rax,rcx
    70595880dd67:	48 c1 e8 0c          	shr    rax,0xc
    70595880dd6b:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    70595880dd6f:	48 85 c0             	test   rax,rax
    70595880dd72:	44 89 5c 24 0c       	mov    DWORD PTR [rsp+0xc],r11d
    70595880dd77:	0f 84 92 05 00 00    	je     0x70595880e30f
    70595880dd7d:	89 ce                	mov    esi,ecx
    70595880dd7f:	81 e6 ff 0f 00 00    	and    esi,0xfff
    70595880dd85:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    70595880dd88:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    70595880dd8c:	8d 71 04             	lea    esi,[rcx+0x4]
    70595880dd8f:	89 f0                	mov    eax,esi
    70595880dd91:	c1 e8 0c             	shr    eax,0xc
    70595880dd94:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    70595880dd98:	48 85 c0             	test   rax,rax
    70595880dd9b:	0f 84 58 06 00 00    	je     0x70595880e3f9
    70595880dda1:	81 e6 ff 0f 00 00    	and    esi,0xfff
    70595880dda7:	8b 2c 30             	mov    ebp,DWORD PTR [rax+rsi*1]
    70595880ddaa:	8d 71 08             	lea    esi,[rcx+0x8]
    70595880ddad:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595880ddb1:	89 47 3c             	mov    DWORD PTR [rdi+0x3c],eax
    70595880ddb4:	89 af a8 00 00 00    	mov    DWORD PTR [rdi+0xa8],ebp
    70595880ddba:	89 77 38             	mov    DWORD PTR [rdi+0x38],esi
    70595880ddbd:	31 db                	xor    ebx,ebx
    70595880ddbf:	44 89 d8             	mov    eax,r11d
    70595880ddc2:	31 d0                	xor    eax,edx
    70595880ddc4:	0f 94 c3             	sete   bl
    70595880ddc7:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    70595880ddcb:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    70595880ddcf:	c1 e8 1f             	shr    eax,0x1f
    70595880ddd2:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    70595880ddd6:	89 f0                	mov    eax,esi
    70595880ddd8:	c1 e8 0c             	shr    eax,0xc
    70595880dddb:	49 8b 04 c0          	mov    rax,QWORD PTR [r8+rax*8]
    70595880dddf:	48 85 c0             	test   rax,rax
    70595880dde2:	0f 84 ea 06 00 00    	je     0x70595880e4d2
    70595880dde8:	81 e6 ff 0f 00 00    	and    esi,0xfff
    70595880ddee:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    70595880ddf1:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    70595880ddf6:	4d 89 cb             	mov    r11,r9
    70595880ddf9:	83 c1 0c             	add    ecx,0xc
    70595880ddfc:	89 4f 38             	mov    DWORD PTR [rdi+0x38],ecx
    70595880ddff:	40 f6 c5 01          	test   bpl,0x1
    70595880de03:	0f 85 97 07 00 00    	jne    0x70595880e5a0
    70595880de09:	49 89 e9             	mov    r9,rbp
    70595880de0c:	b3 01                	mov    bl,0x1
    70595880de0e:	31 c0                	xor    eax,eax
    70595880de10:	41 ba 02 00 00 00    	mov    r10d,0x2
    70595880de16:	b9 0c 00 00 00       	mov    ecx,0xc
    70595880de1b:	31 ed                	xor    ebp,ebp
    70595880de1d:	c7 44 24 30 00 00 00 	mov    DWORD PTR [rsp+0x30],0x0
    70595880de24:	00 
    70595880de25:	c7 44 24 48 00 00 00 	mov    DWORD PTR [rsp+0x48],0x0
    70595880de2c:	00 
    70595880de2d:	42 8d 14 19          	lea    edx,[rcx+r11*1]
    70595880de31:	3b 54 24 54          	cmp    edx,DWORD PTR [rsp+0x54]
    70595880de35:	0f 83 96 03 00 00    	jae    0x70595880e1d1
    70595880de3b:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    70595880de40:	8b b6 58 01 00 00    	mov    esi,DWORD PTR [rsi+0x158]
    70595880de46:	85 f6                	test   esi,esi
    70595880de48:	0f 84 83 03 00 00    	je     0x70595880e1d1
    70595880de4e:	4d 89 c8             	mov    r8,r9
    70595880de51:	41 81 f8 1e 02 01 00 	cmp    r8d,0x1021e
    70595880de58:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880de5d:	0f 84 ed fd ff ff    	je     0x70595880dc50
    70595880de63:	42 8d 3c c5 00 00 00 	lea    edi,[r8*8+0x0]
    70595880de6a:	00 
    70595880de6b:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    70595880de71:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    70595880de76:	44 39 04 3e          	cmp    DWORD PTR [rsi+rdi*1],r8d
    70595880de7a:	0f 85 51 03 00 00    	jne    0x70595880e1d1
    70595880de80:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    70595880de85:	4c 8b 44 3e 08       	mov    r8,QWORD PTR [rsi+rdi*1+0x8]
    70595880de8a:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880de8f:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    70595880de93:	89 37                	mov    DWORD PTR [rdi],esi
    70595880de95:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    70595880de99:	89 77 04             	mov    DWORD PTR [rdi+0x4],esi
    70595880de9c:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    70595880dea0:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880dea4:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    70595880dea9:	89 77 1c             	mov    DWORD PTR [rdi+0x1c],esi
    70595880deac:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    70595880deb1:	89 77 20             	mov    DWORD PTR [rdi+0x20],esi
    70595880deb4:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    70595880deb9:	89 77 28             	mov    DWORD PTR [rdi+0x28],esi
    70595880debc:	44 89 8f bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r9d
    70595880dec3:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    70595880dec7:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    70595880decd:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    70595880ded1:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    70595880ded7:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    70595880dedb:	89 b7 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],esi
    70595880dee1:	8b 74 24 30          	mov    esi,DWORD PTR [rsp+0x30]
    70595880dee5:	89 b7 f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],esi
    70595880deeb:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    70595880def1:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    70595880def7:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880defe:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880df05:	44 89 97 24 01 00 00 	mov    DWORD PTR [rdi+0x124],r10d
    70595880df0c:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880df13:	89 8f 34 01 00 00    	mov    DWORD PTR [rdi+0x134],ecx
    70595880df19:	89 97 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],edx
    70595880df1f:	49 89 fd             	mov    r13,rdi
    70595880df22:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    70595880df27:	48 83 c4 78          	add    rsp,0x78
    70595880df2b:	41 ff e0             	jmp    r8
    70595880df2e:	31 c9                	xor    ecx,ecx
    70595880df30:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    70595880df35:	01 d0                	add    eax,edx
    70595880df37:	0f 92 c1             	setb   cl
    70595880df3a:	31 c0                	xor    eax,eax
    70595880df3c:	45 85 db             	test   r11d,r11d
    70595880df3f:	0f 94 c0             	sete   al
    70595880df42:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    70595880df46:	89 37                	mov    DWORD PTR [rdi],esi
    70595880df48:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880df4c:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    70595880df50:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880df54:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    70595880df57:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    70595880df5c:	89 57 20             	mov    DWORD PTR [rdi+0x20],edx
    70595880df5f:	48 8b 54 24 38       	mov    rdx,QWORD PTR [rsp+0x38]
    70595880df64:	89 57 28             	mov    DWORD PTR [rdi+0x28],edx
    70595880df67:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1021e
    70595880df6e:	02 01 00 
    70595880df71:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    70595880df77:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    70595880df7d:	89 8f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ecx
    70595880df83:	89 8f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ecx
    70595880df89:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    70595880df8f:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    70595880df95:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880df9c:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880dfa3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880dfaa:	00 00 00 
    70595880dfad:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    70595880dfb4:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    70595880dfbb:	00 00 00 
    70595880dfbe:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880dfc5:	48 83 c4 78          	add    rsp,0x78
    70595880dfc9:	c2 08 00             	ret    0x8
    70595880dfcc:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    70595880dfd0:	89 17                	mov    DWORD PTR [rdi],edx
    70595880dfd2:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880dfd6:	89 6f 08             	mov    DWORD PTR [rdi+0x8],ebp
    70595880dfd9:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880dfdd:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    70595880dfe2:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    70595880dfe5:	89 6f 20             	mov    DWORD PTR [rdi+0x20],ebp
    70595880dfe8:	89 4f 28             	mov    DWORD PTR [rdi+0x28],ecx
    70595880dfeb:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    70595880dff2:	02 01 00 
    70595880dff5:	44 89 97 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r10d
    70595880dffc:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    70595880e002:	89 9f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ebx
    70595880e008:	89 9f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ebx
    70595880e00e:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    70595880e014:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    70595880e01a:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e021:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e028:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e02f:	00 00 00 
    70595880e032:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e039:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880e040:	00 00 00 
    70595880e043:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e04a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880e051:	63 00 00 
    70595880e054:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    70595880e059:	ba 26 02 01 00       	mov    edx,0x10226
    70595880e05e:	45 31 c0             	xor    r8d,r8d
    70595880e061:	ff d0                	call   rax
    70595880e063:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880e068:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    70595880e06f:	44 8b 8f bc 00 00 00 	mov    r9d,DWORD PTR [rdi+0xbc]
    70595880e076:	8b 07                	mov    eax,DWORD PTR [rdi]
    70595880e078:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    70595880e07c:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    70595880e07f:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    70595880e083:	44 8b 6f 08          	mov    r13d,DWORD PTR [rdi+0x8]
    70595880e087:	44 8b 7f 0c          	mov    r15d,DWORD PTR [rdi+0xc]
    70595880e08b:	8b 47 1c             	mov    eax,DWORD PTR [rdi+0x1c]
    70595880e08e:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    70595880e093:	8b 47 20             	mov    eax,DWORD PTR [rdi+0x20]
    70595880e096:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    70595880e09b:	8b 47 24             	mov    eax,DWORD PTR [rdi+0x24]
    70595880e09e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    70595880e0a3:	8b 47 28             	mov    eax,DWORD PTR [rdi+0x28]
    70595880e0a6:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    70595880e0ab:	8b 87 e4 00 00 00    	mov    eax,DWORD PTR [rdi+0xe4]
    70595880e0b1:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    70595880e0b5:	8b 87 e8 00 00 00    	mov    eax,DWORD PTR [rdi+0xe8]
    70595880e0bb:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    70595880e0bf:	8b 87 ec 00 00 00    	mov    eax,DWORD PTR [rdi+0xec]
    70595880e0c5:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    70595880e0c9:	8b 87 f0 00 00 00    	mov    eax,DWORD PTR [rdi+0xf0]
    70595880e0cf:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    70595880e0d3:	8b af f8 00 00 00    	mov    ebp,DWORD PTR [rdi+0xf8]
    70595880e0d9:	8b 87 fc 00 00 00    	mov    eax,DWORD PTR [rdi+0xfc]
    70595880e0df:	44 8b b7 00 01 00 00 	mov    r14d,DWORD PTR [rdi+0x100]
    70595880e0e6:	44 8b a7 14 01 00 00 	mov    r12d,DWORD PTR [rdi+0x114]
    70595880e0ed:	44 8b 97 24 01 00 00 	mov    r10d,DWORD PTR [rdi+0x124]
    70595880e0f4:	8b 8f 34 01 00 00    	mov    ecx,DWORD PTR [rdi+0x134]
    70595880e0fa:	44 8b 9f 5c 01 00 00 	mov    r11d,DWORD PTR [rdi+0x15c]
    70595880e101:	89 f3                	mov    ebx,esi
    70595880e103:	e9 25 fd ff ff       	jmp    0x70595880de2d
    70595880e108:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    70595880e10c:	89 17                	mov    DWORD PTR [rdi],edx
    70595880e10e:	44 89 5c 24 0c       	mov    DWORD PTR [rsp+0xc],r11d
    70595880e113:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880e117:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    70595880e11c:	89 6f 08             	mov    DWORD PTR [rdi+0x8],ebp
    70595880e11f:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e123:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
    70595880e128:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    70595880e12b:	89 6f 20             	mov    DWORD PTR [rdi+0x20],ebp
    70595880e12e:	89 4f 28             	mov    DWORD PTR [rdi+0x28],ecx
    70595880e131:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    70595880e138:	02 01 00 
    70595880e13b:	44 89 97 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r10d
    70595880e142:	89 b7 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],esi
    70595880e148:	89 9f ec 00 00 00    	mov    DWORD PTR [rdi+0xec],ebx
    70595880e14e:	89 9f f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],ebx
    70595880e154:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    70595880e15a:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    70595880e160:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e167:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e16e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e175:	00 00 00 
    70595880e178:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e17f:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880e186:	00 00 00 
    70595880e189:	48 89 ce             	mov    rsi,rcx
    70595880e18c:	4c 89 cb             	mov    rbx,r9
    70595880e18f:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e196:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880e19d:	63 00 00 
    70595880e1a0:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    70595880e1a5:	ff d0                	call   rax
    70595880e1a7:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880e1ac:	89 c2                	mov    edx,eax
    70595880e1ae:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    70595880e1b5:	89 c6                	mov    esi,eax
    70595880e1b7:	84 c0                	test   al,al
    70595880e1b9:	0f 85 b0 fe ff ff    	jne    0x70595880e06f
    70595880e1bf:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    70595880e1c4:	49 89 d9             	mov    r9,rbx
    70595880e1c7:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    70595880e1cc:	e9 0f fb ff ff       	jmp    0x70595880dce0
    70595880e1d1:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    70595880e1d6:	8b 74 24 08          	mov    esi,DWORD PTR [rsp+0x8]
    70595880e1da:	89 32                	mov    DWORD PTR [rdx],esi
    70595880e1dc:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    70595880e1e0:	89 72 04             	mov    DWORD PTR [rdx+0x4],esi
    70595880e1e3:	44 89 6a 08          	mov    DWORD PTR [rdx+0x8],r13d
    70595880e1e7:	44 89 7a 0c          	mov    DWORD PTR [rdx+0xc],r15d
    70595880e1eb:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    70595880e1f0:	89 72 1c             	mov    DWORD PTR [rdx+0x1c],esi
    70595880e1f3:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    70595880e1f8:	89 72 20             	mov    DWORD PTR [rdx+0x20],esi
    70595880e1fb:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
    70595880e200:	89 72 28             	mov    DWORD PTR [rdx+0x28],esi
    70595880e203:	44 89 8a bc 00 00 00 	mov    DWORD PTR [rdx+0xbc],r9d
    70595880e20a:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    70595880e20e:	89 b2 e4 00 00 00    	mov    DWORD PTR [rdx+0xe4],esi
    70595880e214:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    70595880e218:	89 b2 e8 00 00 00    	mov    DWORD PTR [rdx+0xe8],esi
    70595880e21e:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    70595880e222:	89 b2 ec 00 00 00    	mov    DWORD PTR [rdx+0xec],esi
    70595880e228:	8b 74 24 30          	mov    esi,DWORD PTR [rsp+0x30]
    70595880e22c:	89 b2 f0 00 00 00    	mov    DWORD PTR [rdx+0xf0],esi
    70595880e232:	89 aa f8 00 00 00    	mov    DWORD PTR [rdx+0xf8],ebp
    70595880e238:	89 82 fc 00 00 00    	mov    DWORD PTR [rdx+0xfc],eax
    70595880e23e:	44 89 b2 00 01 00 00 	mov    DWORD PTR [rdx+0x100],r14d
    70595880e245:	44 89 a2 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r12d
    70595880e24c:	44 89 92 24 01 00 00 	mov    DWORD PTR [rdx+0x124],r10d
    70595880e253:	88 9a 28 01 00 00    	mov    BYTE PTR [rdx+0x128],bl
    70595880e259:	89 8a 34 01 00 00    	mov    DWORD PTR [rdx+0x134],ecx
    70595880e25f:	44 89 9a 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r11d
    70595880e266:	48 83 c4 78          	add    rsp,0x78
    70595880e26a:	c2 08 00             	ret    0x8
    70595880e26d:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70595880e271:	89 07                	mov    DWORD PTR [rdi],eax
    70595880e273:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880e277:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    70595880e27a:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e27e:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880e283:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    70595880e286:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880e28b:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    70595880e28e:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880e293:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    70595880e296:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880e29d:	02 01 00 
    70595880e2a0:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    70595880e2a6:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    70595880e2ac:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    70595880e2b3:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    70595880e2ba:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    70595880e2c0:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    70595880e2c6:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e2cd:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e2d4:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880e2db:	00 00 00 
    70595880e2de:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e2e5:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880e2ec:	00 00 00 
    70595880e2ef:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e2f6:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880e2fd:	63 00 00 
    70595880e300:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    70595880e305:	ba 2e 02 01 00       	mov    edx,0x1022e
    70595880e30a:	e9 4f fd ff ff       	jmp    0x70595880e05e
    70595880e30f:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70595880e313:	89 07                	mov    DWORD PTR [rdi],eax
    70595880e315:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880e319:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    70595880e31c:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e320:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880e325:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    70595880e328:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880e32d:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    70595880e330:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880e335:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    70595880e338:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880e33f:	02 01 00 
    70595880e342:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    70595880e346:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    70595880e34c:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    70595880e352:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    70595880e359:	44 89 54 24 64       	mov    DWORD PTR [rsp+0x64],r10d
    70595880e35e:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    70595880e365:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    70595880e36b:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    70595880e371:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e378:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e37f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880e386:	00 00 00 
    70595880e389:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e390:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880e397:	00 00 00 
    70595880e39a:	4c 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],r9
    70595880e39f:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e3a6:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880e3ad:	63 00 00 
    70595880e3b0:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    70595880e3b5:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    70595880e3ba:	89 ce                	mov    esi,ecx
    70595880e3bc:	ff d0                	call   rax
    70595880e3be:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880e3c3:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    70595880e3c7:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    70595880e3ce:	89 c6                	mov    esi,eax
    70595880e3d0:	84 c0                	test   al,al
    70595880e3d2:	0f 85 97 fc ff ff    	jne    0x70595880e06f
    70595880e3d8:	44 89 ea             	mov    edx,r13d
    70595880e3db:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    70595880e3e0:	4c 8b 4c 24 48       	mov    r9,QWORD PTR [rsp+0x48]
    70595880e3e5:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    70595880e3ea:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    70595880e3ef:	44 8b 54 24 64       	mov    r10d,DWORD PTR [rsp+0x64]
    70595880e3f4:	e9 93 f9 ff ff       	jmp    0x70595880dd8c
    70595880e3f9:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    70595880e3fe:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70595880e402:	89 07                	mov    DWORD PTR [rdi],eax
    70595880e404:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880e408:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    70595880e40b:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e40f:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880e414:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    70595880e417:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880e41c:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    70595880e41f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880e424:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    70595880e427:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880e42e:	02 01 00 
    70595880e431:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    70595880e435:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    70595880e43b:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    70595880e441:	44 89 97 ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r10d
    70595880e448:	44 89 97 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r10d
    70595880e44f:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    70595880e455:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    70595880e45b:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e462:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e469:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880e470:	00 00 00 
    70595880e473:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e47a:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880e481:	00 00 00 
    70595880e484:	4c 89 cb             	mov    rbx,r9
    70595880e487:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e48e:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880e495:	63 00 00 
    70595880e498:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    70595880e49d:	ff d0                	call   rax
    70595880e49f:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880e4a4:	0f b6 8f 28 01 00 00 	movzx  ecx,BYTE PTR [rdi+0x128]
    70595880e4ab:	89 ce                	mov    esi,ecx
    70595880e4ad:	84 c9                	test   cl,cl
    70595880e4af:	0f 85 ba fb ff ff    	jne    0x70595880e06f
    70595880e4b5:	44 89 ea             	mov    edx,r13d
    70595880e4b8:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
    70595880e4bd:	49 89 d9             	mov    r9,rbx
    70595880e4c0:	44 8b 5c 24 0c       	mov    r11d,DWORD PTR [rsp+0xc]
    70595880e4c5:	48 89 c5             	mov    rbp,rax
    70595880e4c8:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    70595880e4cd:	e9 d8 f8 ff ff       	jmp    0x70595880ddaa
    70595880e4d2:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    70595880e4d7:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70595880e4db:	89 07                	mov    DWORD PTR [rdi],eax
    70595880e4dd:	44 89 5f 04          	mov    DWORD PTR [rdi+0x4],r11d
    70595880e4e1:	89 57 08             	mov    DWORD PTR [rdi+0x8],edx
    70595880e4e4:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e4e8:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880e4ed:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    70595880e4f0:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880e4f5:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    70595880e4f8:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880e4fd:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    70595880e500:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10234
    70595880e507:	02 01 00 
    70595880e50a:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595880e50e:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    70595880e514:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    70595880e518:	89 87 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],eax
    70595880e51e:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    70595880e525:	00 00 00 00 
    70595880e529:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    70595880e530:	00 00 00 00 
    70595880e534:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e53b:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e542:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e549:	00 00 00 
    70595880e54c:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e553:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    70595880e55a:	00 00 00 
    70595880e55d:	4c 89 cb             	mov    rbx,r9
    70595880e560:	44 89 8f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r9d
    70595880e567:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880e56e:	63 00 00 
    70595880e571:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    70595880e576:	ff d0                	call   rax
    70595880e578:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    70595880e57d:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    70595880e582:	0f b6 87 28 01 00 00 	movzx  eax,BYTE PTR [rdi+0x128]
    70595880e589:	89 c6                	mov    esi,eax
    70595880e58b:	84 c0                	test   al,al
    70595880e58d:	0f 85 dc fa ff ff    	jne    0x70595880e06f
    70595880e593:	49 89 d9             	mov    r9,rbx
    70595880e596:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    70595880e59b:	e9 56 f8 ff ff       	jmp    0x70595880ddf6
    70595880e5a0:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70595880e5a4:	89 07                	mov    DWORD PTR [rdi],eax
    70595880e5a6:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    70595880e5aa:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    70595880e5ad:	44 89 6f 08          	mov    DWORD PTR [rdi+0x8],r13d
    70595880e5b1:	44 89 7f 0c          	mov    DWORD PTR [rdi+0xc],r15d
    70595880e5b5:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    70595880e5ba:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    70595880e5bd:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    70595880e5c2:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    70595880e5c5:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880e5ca:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    70595880e5cd:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10236
    70595880e5d4:	02 01 00 
    70595880e5d7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    70595880e5db:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    70595880e5e1:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    70595880e5e5:	89 87 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],eax
    70595880e5eb:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    70595880e5f2:	00 00 00 00 
    70595880e5f6:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    70595880e5fd:	00 00 00 00 
    70595880e601:	44 89 b7 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r14d
    70595880e608:	44 89 a7 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r12d
    70595880e60f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e616:	00 00 00 
    70595880e619:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595880e620:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    70595880e627:	00 00 00 
    70595880e62a:	44 89 9f 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r11d
    70595880e631:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880e638:	63 00 00 
    70595880e63b:	be 2a 00 00 00       	mov    esi,0x2a
    70595880e640:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    70595880e645:	ff d0                	call   rax
    70595880e647:	e9 17 fa ff ff       	jmp    0x70595880e063
