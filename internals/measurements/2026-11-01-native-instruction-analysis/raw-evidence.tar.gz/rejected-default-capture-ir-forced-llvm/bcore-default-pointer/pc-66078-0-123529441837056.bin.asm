
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66078-0-123529441837056.bin:     file format binary


Disassembly of section .data:

0000705970800000 <.data>:
    705970800000:	c6 86 65 01 00 00 01 	mov    BYTE PTR [rsi+0x165],0x1
    705970800007:	c6 86 28 01 00 00 00 	mov    BYTE PTR [rsi+0x128],0x0
    70597080000e:	48 83 c4 78          	add    rsp,0x78
    705970800012:	c2 08 00             	ret    0x8
