
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66578-0-123529441837556.bin:     file format binary


Disassembly of section .data:

00007059708001f4 <.data>:
    7059708001f4:	41 c7 00 00 00 00 00 	mov    DWORD PTR [r8],0x0
    7059708001fb:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    7059708001ff:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    705970800203:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705970800208:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    70597080020c:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    705970800210:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705970800215:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    705970800219:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    705970800220:	00 00 00 00 
    705970800224:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10368
    70597080022b:	68 03 01 00 
    70597080022f:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    705970800233:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    70597080023a:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    70597080023e:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    705970800245:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    70597080024c:	00 00 00 00 
    705970800250:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705970800257:	00 00 00 00 
    70597080025b:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    70597080025f:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    705970800266:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    70597080026d:	02 00 00 00 
    705970800271:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    705970800278:	01 
    705970800279:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xa
    705970800280:	0a 00 00 00 
    705970800284:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    70597080028b:	48 81 c4 88 00 00 00 	add    rsp,0x88
    705970800292:	c2 08 00             	ret    0x8
    705970800295:	41 c6 80 65 01 00 00 	mov    BYTE PTR [r8+0x165],0x1
    70597080029c:	01 
    70597080029d:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    7059708002a4:	00 
    7059708002a5:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7059708002ac:	c2 08 00             	ret    0x8
    7059708002af:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    7059708002b3:	41 89 00             	mov    DWORD PTR [r8],eax
    7059708002b6:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    7059708002ba:	41 89 40 04          	mov    DWORD PTR [r8+0x4],eax
    7059708002be:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    7059708002c3:	41 89 40 24          	mov    DWORD PTR [r8+0x24],eax
    7059708002c7:	45 89 68 30          	mov    DWORD PTR [r8+0x30],r13d
    7059708002cb:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    7059708002d0:	41 89 40 34          	mov    DWORD PTR [r8+0x34],eax
    7059708002d4:	41 c7 80 9c 00 00 00 	mov    DWORD PTR [r8+0x9c],0x0
    7059708002db:	00 00 00 00 
    7059708002df:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10422
    7059708002e6:	22 04 01 00 
    7059708002ea:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    7059708002ee:	41 89 80 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],eax
    7059708002f5:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7059708002f9:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    705970800300:	49 c7 80 ec 00 00 00 	mov    QWORD PTR [r8+0xec],0x0
    705970800307:	00 00 00 00 
    70597080030b:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    705970800312:	00 00 00 00 
    705970800316:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    70597080031a:	41 89 80 00 01 00 00 	mov    DWORD PTR [r8+0x100],eax
    705970800321:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    705970800328:	02 00 00 00 
    70597080032c:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    705970800333:	00 
    705970800334:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0x8
    70597080033b:	08 00 00 00 
    70597080033f:	45 89 b8 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r15d
    705970800346:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70597080034d:	63 00 00 
    705970800350:	4c 89 c7             	mov    rdi,r8
    705970800353:	4c 89 c5             	mov    rbp,r8
    705970800356:	44 89 d3             	mov    ebx,r10d
    705970800359:	4c 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],r11
    70597080035e:	ff d0                	call   rax
    705970800360:	4c 8b 5c 24 38       	mov    r11,QWORD PTR [rsp+0x38]
    705970800365:	41 89 da             	mov    r10d,ebx
    705970800368:	49 89 e8             	mov    r8,rbp
    70597080036b:	0f b6 bd 28 01 00 00 	movzx  edi,BYTE PTR [rbp+0x128]
    705970800372:	40 84 ff             	test   dil,dil
    705970800375:	0f 84 d2 20 01 e8    	je     0x70595881244d
    70597080037b:	e9 42 25 01 e8       	jmp    0x7059588128c2
