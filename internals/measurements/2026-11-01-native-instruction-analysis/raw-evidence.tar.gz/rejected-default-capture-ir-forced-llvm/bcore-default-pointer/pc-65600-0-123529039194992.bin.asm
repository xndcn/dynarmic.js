
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65600-0-123529039194992.bin:     file format binary


Disassembly of section .data:

0000705958802b70 <.data>:
    705958802b70:	48 81 ec 28 01 00 00 	sub    rsp,0x128
    705958802b77:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
    705958802b7e:	00 
    705958802b7f:	4c 89 ac 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r13
    705958802b86:	00 
    705958802b87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958802b8e:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    705958802b95:	00 
    705958802b96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    705958802b9d:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    705958802ba4:	00 
    705958802ba5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    705958802bac:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    705958802bb3:	00 
    705958802bb4:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    705958802bbb:	00 
    705958802bbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958802bc2:	83 fa 00             	cmp    edx,0x0
    705958802bc5:	0f 94 c0             	sete   al
    705958802bc8:	81 ea 40 00 01 00    	sub    edx,0x10040
    705958802bce:	83 fa 4e             	cmp    edx,0x4e
    705958802bd1:	0f 97 c2             	seta   dl
    705958802bd4:	08 d0                	or     al,dl
    705958802bd6:	24 01                	and    al,0x1
    705958802bd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958802bde:	83 fa 00             	cmp    edx,0x0
    705958802be1:	0f 94 c1             	sete   cl
    705958802be4:	81 ea 40 00 01 00    	sub    edx,0x10040
    705958802bea:	83 fa 4e             	cmp    edx,0x4e
    705958802bed:	0f 97 c2             	seta   dl
    705958802bf0:	08 d1                	or     cl,dl
    705958802bf2:	20 c8                	and    al,cl
    705958802bf4:	a8 01                	test   al,0x1
    705958802bf6:	75 05                	jne    0x705958802bfd
    705958802bf8:	e9 6e 11 00 00       	jmp    0x705958803d6b
    705958802bfd:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802c04:	00 
    705958802c05:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958802c0c:	48 89 c8             	mov    rax,rcx
    705958802c0f:	48 05 00 00 10 00    	add    rax,0x100000
    705958802c15:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    705958802c1c:	00 
    705958802c1d:	8b 81 08 00 10 00    	mov    eax,DWORD PTR [rcx+0x100008]
    705958802c23:	83 c0 01             	add    eax,0x1
    705958802c26:	89 81 08 00 10 00    	mov    DWORD PTR [rcx+0x100008],eax
    705958802c2c:	3d 14 cd 00 00       	cmp    eax,0xcd14
    705958802c31:	75 4c                	jne    0x705958802c7f
    705958802c33:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    705958802c3a:	00 
    705958802c3b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958802c41:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    705958802c48:	89 c2                	mov    edx,eax
    705958802c4a:	83 c2 01             	add    edx,0x1
    705958802c4d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958802c53:	3d 00 01 00 00       	cmp    eax,0x100
    705958802c58:	73 23                	jae    0x705958802c7d
    705958802c5a:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    705958802c61:	00 
    705958802c62:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    705958802c69:	89 c9                	mov    ecx,ecx
    705958802c6b:	48 c1 e1 02          	shl    rcx,0x2
    705958802c6f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958802c76:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    705958802c7d:	eb 00                	jmp    0x705958802c7f
    705958802c7f:	eb 00                	jmp    0x705958802c81
    705958802c81:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802c88:	00 
    705958802c89:	c7 40 28 01 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c01
    705958802c90:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    705958802c96:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    705958802c9d:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    705958802ca3:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    705958802caa:	eb 00                	jmp    0x705958802cac
    705958802cac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802cb3:	00 
    705958802cb4:	c7 40 28 04 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf004
    705958802cbb:	eb 00                	jmp    0x705958802cbd
    705958802cbd:	31 c0                	xor    eax,eax
    705958802cbf:	a8 01                	test   al,0x1
    705958802cc1:	75 02                	jne    0x705958802cc5
    705958802cc3:	eb 7b                	jmp    0x705958802d40
    705958802cc5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958802ccc:	00 
    705958802ccd:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958802cd4:	00 
    705958802cd5:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10046
    705958802cdc:	00 01 00 
    705958802cdf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958802ce6:	00 00 00 
    705958802ce9:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958802cf0:	00 00 00 
    705958802cf3:	31 c0                	xor    eax,eax
    705958802cf5:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958802cfc:	63 00 00 
    705958802cff:	ba 46 00 01 00       	mov    edx,0x10046
    705958802d04:	b9 04 f0 00 00       	mov    ecx,0xf004
    705958802d09:	45 31 c0             	xor    r8d,r8d
    705958802d0c:	ff d0                	call   rax
    705958802d0e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802d15:	00 
    705958802d16:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802d1c:	b9 03 00 00 00       	mov    ecx,0x3
    705958802d21:	b8 02 00 00 00       	mov    eax,0x2
    705958802d26:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958802d2d:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958802d34:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958802d3b:	e9 cc 10 00 00       	jmp    0x705958803e0c
    705958802d40:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958802d47:	00 
    705958802d48:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    705958802d4c:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    705958802d53:	00 
    705958802d54:	48 83 f8 00          	cmp    rax,0x0
    705958802d58:	74 14                	je     0x705958802d6e
    705958802d5a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    705958802d61:	00 
    705958802d62:	8b 40 04             	mov    eax,DWORD PTR [rax+0x4]
    705958802d65:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    705958802d6c:	eb 5b                	jmp    0x705958802dc9
    705958802d6e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802d75:	00 
    705958802d76:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    705958802d7d:	00 
    705958802d7e:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10046
    705958802d85:	00 01 00 
    705958802d88:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802d8f:	00 00 00 
    705958802d92:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    705958802d99:	00 00 00 
    705958802d9c:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958802da3:	63 00 00 
    705958802da6:	be 04 f0 00 00       	mov    esi,0xf004
    705958802dab:	ff d0                	call   rax
    705958802dad:	89 c1                	mov    ecx,eax
    705958802daf:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802db6:	00 
    705958802db7:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958802dbe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958802dc5:	75 1d                	jne    0x705958802de4
    705958802dc7:	eb 4d                	jmp    0x705958802e16
    705958802dc9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802dd0:	00 
    705958802dd1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    705958802dd8:	89 8c 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],ecx
    705958802ddf:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    705958802de2:	eb 42                	jmp    0x705958802e26
    705958802de4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802deb:	00 
    705958802dec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802df2:	b9 03 00 00 00       	mov    ecx,0x3
    705958802df7:	b8 02 00 00 00       	mov    eax,0x2
    705958802dfc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958802e03:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958802e0a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958802e11:	e9 f6 0f 00 00       	jmp    0x705958803e0c
    705958802e16:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    705958802e1d:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    705958802e24:	eb a3                	jmp    0x705958802dc9
    705958802e26:	eb 00                	jmp    0x705958802e28
    705958802e28:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802e2f:	00 
    705958802e30:	c7 40 28 08 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf008
    705958802e37:	eb 00                	jmp    0x705958802e39
    705958802e39:	31 c0                	xor    eax,eax
    705958802e3b:	a8 01                	test   al,0x1
    705958802e3d:	75 02                	jne    0x705958802e41
    705958802e3f:	eb 7b                	jmp    0x705958802ebc
    705958802e41:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958802e48:	00 
    705958802e49:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958802e50:	00 
    705958802e51:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1004a
    705958802e58:	00 01 00 
    705958802e5b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958802e62:	00 00 00 
    705958802e65:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    705958802e6c:	00 00 00 
    705958802e6f:	31 c0                	xor    eax,eax
    705958802e71:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958802e78:	63 00 00 
    705958802e7b:	ba 4a 00 01 00       	mov    edx,0x1004a
    705958802e80:	b9 08 f0 00 00       	mov    ecx,0xf008
    705958802e85:	45 31 c0             	xor    r8d,r8d
    705958802e88:	ff d0                	call   rax
    705958802e8a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802e91:	00 
    705958802e92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802e98:	b9 05 00 00 00       	mov    ecx,0x5
    705958802e9d:	b8 02 00 00 00       	mov    eax,0x2
    705958802ea2:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958802ea9:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958802eb0:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958802eb7:	e9 50 0f 00 00       	jmp    0x705958803e0c
    705958802ebc:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958802ec3:	00 
    705958802ec4:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    705958802ec8:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    705958802ecf:	00 
    705958802ed0:	48 83 f8 00          	cmp    rax,0x0
    705958802ed4:	74 14                	je     0x705958802eea
    705958802ed6:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    705958802edd:	00 
    705958802ede:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    705958802ee1:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    705958802ee8:	eb 5b                	jmp    0x705958802f45
    705958802eea:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802ef1:	00 
    705958802ef2:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    705958802ef9:	00 
    705958802efa:	c7 80 bc 00 00 00 4a 	mov    DWORD PTR [rax+0xbc],0x1004a
    705958802f01:	00 01 00 
    705958802f04:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802f0b:	00 00 00 
    705958802f0e:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    705958802f15:	00 00 00 
    705958802f18:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958802f1f:	63 00 00 
    705958802f22:	be 08 f0 00 00       	mov    esi,0xf008
    705958802f27:	ff d0                	call   rax
    705958802f29:	89 c1                	mov    ecx,eax
    705958802f2b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802f32:	00 
    705958802f33:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    705958802f3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958802f41:	75 1d                	jne    0x705958802f60
    705958802f43:	eb 4d                	jmp    0x705958802f92
    705958802f45:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802f4c:	00 
    705958802f4d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    705958802f54:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    705958802f5b:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958802f5e:	eb 42                	jmp    0x705958802fa2
    705958802f60:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802f67:	00 
    705958802f68:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802f6e:	b9 05 00 00 00       	mov    ecx,0x5
    705958802f73:	b8 02 00 00 00       	mov    eax,0x2
    705958802f78:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958802f7f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958802f86:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958802f8d:	e9 7a 0e 00 00       	jmp    0x705958803e0c
    705958802f92:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [rsp+0xb8]
    705958802f99:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    705958802fa0:	eb a3                	jmp    0x705958802f45
    705958802fa2:	eb 00                	jmp    0x705958802fa4
    705958802fa4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802fab:	00 
    705958802fac:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    705958802fb2:	eb 00                	jmp    0x705958802fb4
    705958802fb4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802fbb:	00 
    705958802fbc:	c7 40 2c 05 3c 00 00 	mov    DWORD PTR [rax+0x2c],0x3c05
    705958802fc3:	eb 00                	jmp    0x705958802fc5
    705958802fc5:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802fcc:	00 
    705958802fcd:	c7 40 2c 14 f0 00 00 	mov    DWORD PTR [rax+0x2c],0xf014
    705958802fd4:	eb 00                	jmp    0x705958802fd6
    705958802fd6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958802fdd:	00 
    705958802fde:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    705958802fe1:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    705958802fe8:	83 c0 fc             	add    eax,0xfffffffc
    705958802feb:	89 84 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],eax
    705958802ff2:	83 e0 03             	and    eax,0x3
    705958802ff5:	83 f8 00             	cmp    eax,0x0
    705958802ff8:	74 7e                	je     0x705958803078
    705958802ffa:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803001:	00 
    705958803002:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    705958803009:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803010:	00 
    705958803011:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10054
    705958803018:	00 01 00 
    70595880301b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803022:	00 00 00 
    705958803025:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880302c:	00 00 00 
    70595880302f:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803036:	63 00 00 
    705958803039:	ba 54 00 01 00       	mov    edx,0x10054
    70595880303e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958803044:	ff d0                	call   rax
    705958803046:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880304d:	00 
    70595880304e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803054:	b9 09 00 00 00       	mov    ecx,0x9
    705958803059:	b8 02 00 00 00       	mov    eax,0x2
    70595880305e:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803065:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    70595880306c:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803073:	e9 94 0d 00 00       	jmp    0x705958803e0c
    705958803078:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    70595880307f:	00 
    705958803080:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    705958803087:	c1 e9 0c             	shr    ecx,0xc
    70595880308a:	89 c9                	mov    ecx,ecx
    70595880308c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958803090:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    705958803097:	00 
    705958803098:	48 83 f8 00          	cmp    rax,0x0
    70595880309c:	74 23                	je     0x7059588030c1
    70595880309e:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    7059588030a5:	00 
    7059588030a6:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    7059588030ad:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    7059588030b4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588030ba:	89 c9                	mov    ecx,ecx
    7059588030bc:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588030bf:	eb 5b                	jmp    0x70595880311c
    7059588030c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588030c8:	00 
    7059588030c9:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    7059588030d0:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    7059588030d7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    7059588030de:	00 
    7059588030df:	c7 80 bc 00 00 00 54 	mov    DWORD PTR [rax+0xbc],0x10054
    7059588030e6:	00 01 00 
    7059588030e9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588030f0:	00 00 00 
    7059588030f3:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    7059588030fa:	00 00 00 
    7059588030fd:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958803104:	63 00 00 
    705958803107:	ff d0                	call   rax
    705958803109:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803110:	00 
    705958803111:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803118:	75 11                	jne    0x70595880312b
    70595880311a:	eb 41                	jmp    0x70595880315d
    70595880311c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    705958803123:	00 
    705958803124:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958803127:	75 36                	jne    0x70595880315f
    705958803129:	eb 79                	jmp    0x7059588031a4
    70595880312b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803132:	00 
    705958803133:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803139:	b9 09 00 00 00       	mov    ecx,0x9
    70595880313e:	b8 02 00 00 00       	mov    eax,0x2
    705958803143:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    70595880314a:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803151:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803158:	e9 af 0c 00 00       	jmp    0x705958803e0c
    70595880315d:	eb bd                	jmp    0x70595880311c
    70595880315f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803166:	00 
    705958803167:	c7 87 bc 00 00 00 56 	mov    DWORD PTR [rdi+0xbc],0x10056
    70595880316e:	00 01 00 
    705958803171:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803178:	00 00 00 
    70595880317b:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    705958803182:	00 00 00 
    705958803185:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880318c:	63 00 00 
    70595880318f:	ff d0                	call   rax
    705958803191:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803198:	00 
    705958803199:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588031a0:	75 04                	jne    0x7059588031a6
    7059588031a2:	eb 34                	jmp    0x7059588031d8
    7059588031a4:	eb 34                	jmp    0x7059588031da
    7059588031a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588031ad:	00 
    7059588031ae:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588031b4:	b9 09 00 00 00       	mov    ecx,0x9
    7059588031b9:	b8 02 00 00 00       	mov    eax,0x2
    7059588031be:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    7059588031c5:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    7059588031cc:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    7059588031d3:	e9 34 0c 00 00       	jmp    0x705958803e0c
    7059588031d8:	eb ca                	jmp    0x7059588031a4
    7059588031da:	eb 00                	jmp    0x7059588031dc
    7059588031dc:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588031e3:	00 
    7059588031e4:	c7 40 28 03 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c03
    7059588031eb:	eb 00                	jmp    0x7059588031ed
    7059588031ed:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588031f4:	00 
    7059588031f5:	c7 40 28 0c f0 00 00 	mov    DWORD PTR [rax+0x28],0xf00c
    7059588031fc:	eb 00                	jmp    0x7059588031fe
    7059588031fe:	31 c0                	xor    eax,eax
    705958803200:	a8 01                	test   al,0x1
    705958803202:	75 02                	jne    0x705958803206
    705958803204:	eb 7b                	jmp    0x705958803281
    705958803206:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    70595880320d:	00 
    70595880320e:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803215:	00 
    705958803216:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1005c
    70595880321d:	00 01 00 
    705958803220:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803227:	00 00 00 
    70595880322a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    705958803231:	00 00 00 
    705958803234:	31 c0                	xor    eax,eax
    705958803236:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880323d:	63 00 00 
    705958803240:	ba 5c 00 01 00       	mov    edx,0x1005c
    705958803245:	b9 0c f0 00 00       	mov    ecx,0xf00c
    70595880324a:	45 31 c0             	xor    r8d,r8d
    70595880324d:	ff d0                	call   rax
    70595880324f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803256:	00 
    705958803257:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880325d:	b9 0c 00 00 00       	mov    ecx,0xc
    705958803262:	b8 02 00 00 00       	mov    eax,0x2
    705958803267:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    70595880326e:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803275:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    70595880327c:	e9 8b 0b 00 00       	jmp    0x705958803e0c
    705958803281:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958803288:	00 
    705958803289:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    70595880328d:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    705958803294:	00 
    705958803295:	48 83 f8 00          	cmp    rax,0x0
    705958803299:	74 14                	je     0x7059588032af
    70595880329b:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588032a2:	00 
    7059588032a3:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    7059588032a6:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    7059588032ad:	eb 5b                	jmp    0x70595880330a
    7059588032af:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588032b6:	00 
    7059588032b7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    7059588032be:	00 
    7059588032bf:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1005c
    7059588032c6:	00 01 00 
    7059588032c9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588032d0:	00 00 00 
    7059588032d3:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    7059588032da:	00 00 00 
    7059588032dd:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588032e4:	63 00 00 
    7059588032e7:	be 0c f0 00 00       	mov    esi,0xf00c
    7059588032ec:	ff d0                	call   rax
    7059588032ee:	89 c1                	mov    ecx,eax
    7059588032f0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588032f7:	00 
    7059588032f8:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    7059588032ff:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803306:	75 1d                	jne    0x705958803325
    705958803308:	eb 4d                	jmp    0x705958803357
    70595880330a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803311:	00 
    705958803312:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    705958803319:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    705958803320:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958803323:	eb 42                	jmp    0x705958803367
    705958803325:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880332c:	00 
    70595880332d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803333:	b9 0c 00 00 00       	mov    ecx,0xc
    705958803338:	b8 02 00 00 00       	mov    eax,0x2
    70595880333d:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803344:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    70595880334b:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803352:	e9 b5 0a 00 00       	jmp    0x705958803e0c
    705958803357:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    70595880335e:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    705958803365:	eb a3                	jmp    0x70595880330a
    705958803367:	eb 00                	jmp    0x705958803369
    705958803369:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803370:	00 
    705958803371:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    705958803374:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880337a:	83 c9 00             	or     ecx,0x0
    70595880337d:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    705958803384:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    705958803387:	eb 00                	jmp    0x705958803389
    705958803389:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803390:	00 
    705958803391:	8b 48 30             	mov    ecx,DWORD PTR [rax+0x30]
    705958803394:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880339a:	81 c9 00 00 00 01    	or     ecx,0x1000000
    7059588033a0:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    7059588033a7:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    7059588033aa:	eb 00                	jmp    0x7059588033ac
    7059588033ac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588033b3:	00 
    7059588033b4:	8b 8c 24 88 00 00 00 	mov    ecx,DWORD PTR [rsp+0x88]
    7059588033bb:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588033c1:	81 c9 18 f0 00 00    	or     ecx,0xf018
    7059588033c7:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    7059588033ca:	eb 00                	jmp    0x7059588033cc
    7059588033cc:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    7059588033d3:	83 c0 f8             	add    eax,0xfffffff8
    7059588033d6:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    7059588033dd:	83 e0 03             	and    eax,0x3
    7059588033e0:	83 f8 00             	cmp    eax,0x0
    7059588033e3:	74 7e                	je     0x705958803463
    7059588033e5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    7059588033ec:	00 
    7059588033ed:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    7059588033f4:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    7059588033fb:	00 
    7059588033fc:	c7 87 bc 00 00 00 6a 	mov    DWORD PTR [rdi+0xbc],0x1006a
    705958803403:	00 01 00 
    705958803406:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880340d:	00 00 00 
    705958803410:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958803417:	00 00 00 
    70595880341a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803421:	63 00 00 
    705958803424:	ba 6a 00 01 00       	mov    edx,0x1006a
    705958803429:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880342f:	ff d0                	call   rax
    705958803431:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803438:	00 
    705958803439:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880343f:	b9 10 00 00 00       	mov    ecx,0x10
    705958803444:	b8 02 00 00 00       	mov    eax,0x2
    705958803449:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803450:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803457:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    70595880345e:	e9 a9 09 00 00       	jmp    0x705958803e0c
    705958803463:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    70595880346a:	00 
    70595880346b:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    705958803472:	c1 e9 0c             	shr    ecx,0xc
    705958803475:	89 c9                	mov    ecx,ecx
    705958803477:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880347b:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    705958803480:	48 83 f8 00          	cmp    rax,0x0
    705958803484:	74 20                	je     0x7059588034a6
    705958803486:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880348b:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    705958803492:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    705958803499:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880349f:	89 c9                	mov    ecx,ecx
    7059588034a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588034a4:	eb 5b                	jmp    0x705958803501
    7059588034a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588034ad:	00 
    7059588034ae:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    7059588034b5:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    7059588034bc:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    7059588034c3:	00 
    7059588034c4:	c7 80 bc 00 00 00 6a 	mov    DWORD PTR [rax+0xbc],0x1006a
    7059588034cb:	00 01 00 
    7059588034ce:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588034d5:	00 00 00 
    7059588034d8:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    7059588034df:	00 00 00 
    7059588034e2:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588034e9:	63 00 00 
    7059588034ec:	ff d0                	call   rax
    7059588034ee:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588034f5:	00 
    7059588034f6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588034fd:	75 11                	jne    0x705958803510
    7059588034ff:	eb 41                	jmp    0x705958803542
    705958803501:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    705958803508:	00 
    705958803509:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880350c:	75 36                	jne    0x705958803544
    70595880350e:	eb 79                	jmp    0x705958803589
    705958803510:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803517:	00 
    705958803518:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880351e:	b9 10 00 00 00       	mov    ecx,0x10
    705958803523:	b8 02 00 00 00       	mov    eax,0x2
    705958803528:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    70595880352f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803536:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    70595880353d:	e9 ca 08 00 00       	jmp    0x705958803e0c
    705958803542:	eb bd                	jmp    0x705958803501
    705958803544:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    70595880354b:	00 
    70595880354c:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1006c
    705958803553:	00 01 00 
    705958803556:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880355d:	00 00 00 
    705958803560:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958803567:	00 00 00 
    70595880356a:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958803571:	63 00 00 
    705958803574:	ff d0                	call   rax
    705958803576:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880357d:	00 
    70595880357e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803585:	75 04                	jne    0x70595880358b
    705958803587:	eb 34                	jmp    0x7059588035bd
    705958803589:	eb 34                	jmp    0x7059588035bf
    70595880358b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803592:	00 
    705958803593:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803599:	b9 10 00 00 00       	mov    ecx,0x10
    70595880359e:	b8 02 00 00 00       	mov    eax,0x2
    7059588035a3:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    7059588035aa:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    7059588035b1:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    7059588035b8:	e9 4f 08 00 00       	jmp    0x705958803e0c
    7059588035bd:	eb ca                	jmp    0x705958803589
    7059588035bf:	eb 00                	jmp    0x7059588035c1
    7059588035c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588035c8:	00 
    7059588035c9:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    7059588035d0:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588035d6:	83 c9 00             	or     ecx,0x0
    7059588035d9:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    7059588035dd:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    7059588035e0:	eb 00                	jmp    0x7059588035e2
    7059588035e2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588035e9:	00 
    7059588035ea:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    7059588035ee:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588035f4:	81 c9 10 f0 00 00    	or     ecx,0xf010
    7059588035fa:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588035fe:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958803601:	eb 00                	jmp    0x705958803603
    705958803603:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    705958803607:	83 e0 03             	and    eax,0x3
    70595880360a:	83 f8 00             	cmp    eax,0x0
    70595880360d:	74 7b                	je     0x70595880368a
    70595880360f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803616:	00 
    705958803617:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    70595880361b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803622:	00 
    705958803623:	c7 87 bc 00 00 00 74 	mov    DWORD PTR [rdi+0xbc],0x10074
    70595880362a:	00 01 00 
    70595880362d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803634:	00 00 00 
    705958803637:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    70595880363e:	00 00 00 
    705958803641:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803648:	63 00 00 
    70595880364b:	ba 74 00 01 00       	mov    edx,0x10074
    705958803650:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958803656:	ff d0                	call   rax
    705958803658:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880365f:	00 
    705958803660:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803666:	b9 13 00 00 00       	mov    ecx,0x13
    70595880366b:	b8 02 00 00 00       	mov    eax,0x2
    705958803670:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803677:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    70595880367e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803685:	e9 82 07 00 00       	jmp    0x705958803e0c
    70595880368a:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958803691:	00 
    705958803692:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    705958803696:	c1 e9 0c             	shr    ecx,0xc
    705958803699:	89 c9                	mov    ecx,ecx
    70595880369b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880369f:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    7059588036a4:	48 83 f8 00          	cmp    rax,0x0
    7059588036a8:	74 1a                	je     0x7059588036c4
    7059588036aa:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    7059588036af:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    7059588036b3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588036b9:	89 c9                	mov    ecx,ecx
    7059588036bb:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    7059588036c2:	eb 56                	jmp    0x70595880371a
    7059588036c4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588036cb:	00 
    7059588036cc:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    7059588036d0:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    7059588036d7:	00 
    7059588036d8:	c7 80 bc 00 00 00 74 	mov    DWORD PTR [rax+0xbc],0x10074
    7059588036df:	00 01 00 
    7059588036e2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588036e9:	00 00 00 
    7059588036ec:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    7059588036f3:	00 00 00 
    7059588036f6:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588036fd:	63 00 00 
    705958803700:	ba 01 00 00 00       	mov    edx,0x1
    705958803705:	ff d0                	call   rax
    705958803707:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880370e:	00 
    70595880370f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803716:	75 11                	jne    0x705958803729
    705958803718:	eb 41                	jmp    0x70595880375b
    70595880371a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    705958803721:	00 
    705958803722:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958803725:	75 36                	jne    0x70595880375d
    705958803727:	eb 79                	jmp    0x7059588037a2
    705958803729:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803730:	00 
    705958803731:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803737:	b9 13 00 00 00       	mov    ecx,0x13
    70595880373c:	b8 02 00 00 00       	mov    eax,0x2
    705958803741:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803748:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    70595880374f:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803756:	e9 b1 06 00 00       	jmp    0x705958803e0c
    70595880375b:	eb bd                	jmp    0x70595880371a
    70595880375d:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803764:	00 
    705958803765:	c7 87 bc 00 00 00 76 	mov    DWORD PTR [rdi+0xbc],0x10076
    70595880376c:	00 01 00 
    70595880376f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803776:	00 00 00 
    705958803779:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    705958803780:	00 00 00 
    705958803783:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880378a:	63 00 00 
    70595880378d:	ff d0                	call   rax
    70595880378f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803796:	00 
    705958803797:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880379e:	75 04                	jne    0x7059588037a4
    7059588037a0:	eb 34                	jmp    0x7059588037d6
    7059588037a2:	eb 34                	jmp    0x7059588037d8
    7059588037a4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588037ab:	00 
    7059588037ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588037b2:	b9 13 00 00 00       	mov    ecx,0x13
    7059588037b7:	b8 02 00 00 00       	mov    eax,0x2
    7059588037bc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    7059588037c3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    7059588037ca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    7059588037d1:	e9 36 06 00 00       	jmp    0x705958803e0c
    7059588037d6:	eb ca                	jmp    0x7059588037a2
    7059588037d8:	eb 00                	jmp    0x7059588037da
    7059588037da:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588037e1:	00 
    7059588037e2:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    7059588037e8:	eb 00                	jmp    0x7059588037ea
    7059588037ea:	31 c0                	xor    eax,eax
    7059588037ec:	a8 01                	test   al,0x1
    7059588037ee:	75 02                	jne    0x7059588037f2
    7059588037f0:	eb 7c                	jmp    0x70595880386e
    7059588037f2:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    7059588037f9:	00 
    7059588037fa:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803801:	00 
    705958803802:	c7 87 bc 00 00 00 78 	mov    DWORD PTR [rdi+0xbc],0x10078
    705958803809:	00 01 00 
    70595880380c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803813:	00 00 00 
    705958803816:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    70595880381d:	00 00 00 
    705958803820:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803827:	63 00 00 
    70595880382a:	ba 78 00 01 00       	mov    edx,0x10078
    70595880382f:	b9 14 f0 00 00       	mov    ecx,0xf014
    705958803834:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880383a:	ff d0                	call   rax
    70595880383c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803843:	00 
    705958803844:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880384a:	b9 15 00 00 00       	mov    ecx,0x15
    70595880384f:	b8 02 00 00 00       	mov    eax,0x2
    705958803854:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    70595880385b:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803862:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803869:	e9 9e 05 00 00       	jmp    0x705958803e0c
    70595880386e:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958803875:	00 
    705958803876:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    70595880387a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    70595880387f:	48 83 f8 00          	cmp    rax,0x0
    705958803883:	74 0e                	je     0x705958803893
    705958803885:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595880388a:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    705958803891:	eb 56                	jmp    0x7059588038e9
    705958803893:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880389a:	00 
    70595880389b:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    7059588038a2:	00 
    7059588038a3:	c7 80 bc 00 00 00 78 	mov    DWORD PTR [rax+0xbc],0x10078
    7059588038aa:	00 01 00 
    7059588038ad:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588038b4:	00 00 00 
    7059588038b7:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    7059588038be:	00 00 00 
    7059588038c1:	31 c0                	xor    eax,eax
    7059588038c3:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588038ca:	63 00 00 
    7059588038cd:	be 14 f0 00 00       	mov    esi,0xf014
    7059588038d2:	31 d2                	xor    edx,edx
    7059588038d4:	ff d0                	call   rax
    7059588038d6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588038dd:	00 
    7059588038de:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588038e5:	75 11                	jne    0x7059588038f8
    7059588038e7:	eb 41                	jmp    0x70595880392a
    7059588038e9:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    7059588038f0:	00 
    7059588038f1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7059588038f4:	75 36                	jne    0x70595880392c
    7059588038f6:	eb 79                	jmp    0x705958803971
    7059588038f8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588038ff:	00 
    705958803900:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803906:	b9 15 00 00 00       	mov    ecx,0x15
    70595880390b:	b8 02 00 00 00       	mov    eax,0x2
    705958803910:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803917:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    70595880391e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803925:	e9 e2 04 00 00       	jmp    0x705958803e0c
    70595880392a:	eb bd                	jmp    0x7059588038e9
    70595880392c:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803933:	00 
    705958803934:	c7 87 bc 00 00 00 7a 	mov    DWORD PTR [rdi+0xbc],0x1007a
    70595880393b:	00 01 00 
    70595880393e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803945:	00 00 00 
    705958803948:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    70595880394f:	00 00 00 
    705958803952:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958803959:	63 00 00 
    70595880395c:	ff d0                	call   rax
    70595880395e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803965:	00 
    705958803966:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880396d:	75 04                	jne    0x705958803973
    70595880396f:	eb 34                	jmp    0x7059588039a5
    705958803971:	eb 34                	jmp    0x7059588039a7
    705958803973:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880397a:	00 
    70595880397b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803981:	b9 15 00 00 00       	mov    ecx,0x15
    705958803986:	b8 02 00 00 00       	mov    eax,0x2
    70595880398b:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803992:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803999:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    7059588039a0:	e9 67 04 00 00       	jmp    0x705958803e0c
    7059588039a5:	eb ca                	jmp    0x705958803971
    7059588039a7:	eb 00                	jmp    0x7059588039a9
    7059588039a9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588039b0:	00 
    7059588039b1:	c7 40 1c 00 00 00 00 	mov    DWORD PTR [rax+0x1c],0x0
    7059588039b8:	eb 00                	jmp    0x7059588039ba
    7059588039ba:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588039c1:	00 
    7059588039c2:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    7059588039c9:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588039cf:	83 c9 00             	or     ecx,0x0
    7059588039d2:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    7059588039d5:	eb 00                	jmp    0x7059588039d7
    7059588039d7:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588039de:	00 
    7059588039df:	c7 40 18 00 00 00 00 	mov    DWORD PTR [rax+0x18],0x0
    7059588039e6:	eb 00                	jmp    0x7059588039e8
    7059588039e8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    7059588039ef:	00 
    7059588039f0:	c7 40 14 01 00 00 00 	mov    DWORD PTR [rax+0x14],0x1
    7059588039f7:	eb 00                	jmp    0x7059588039f9
    7059588039f9:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    705958803a00:	83 c0 fc             	add    eax,0xfffffffc
    705958803a03:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    705958803a07:	83 e0 03             	and    eax,0x3
    705958803a0a:	83 f8 00             	cmp    eax,0x0
    705958803a0d:	74 7a                	je     0x705958803a89
    705958803a0f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803a16:	00 
    705958803a17:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958803a1b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803a22:	00 
    705958803a23:	c7 87 bc 00 00 00 84 	mov    DWORD PTR [rdi+0xbc],0x10084
    705958803a2a:	00 01 00 
    705958803a2d:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    705958803a34:	00 00 00 
    705958803a37:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    705958803a3e:	00 00 00 
    705958803a41:	31 c0                	xor    eax,eax
    705958803a43:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803a4a:	63 00 00 
    705958803a4d:	ba 84 00 01 00       	mov    edx,0x10084
    705958803a52:	45 31 c0             	xor    r8d,r8d
    705958803a55:	ff d0                	call   rax
    705958803a57:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803a5e:	00 
    705958803a5f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803a65:	b9 1a 00 00 00       	mov    ecx,0x1a
    705958803a6a:	b8 08 00 00 00       	mov    eax,0x8
    705958803a6f:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803a76:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803a7d:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803a84:	e9 83 03 00 00       	jmp    0x705958803e0c
    705958803a89:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958803a90:	00 
    705958803a91:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958803a95:	c1 e9 0c             	shr    ecx,0xc
    705958803a98:	89 c9                	mov    ecx,ecx
    705958803a9a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958803a9e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    705958803aa3:	48 83 f8 00          	cmp    rax,0x0
    705958803aa7:	74 1a                	je     0x705958803ac3
    705958803aa9:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    705958803aae:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958803ab2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958803ab8:	89 c9                	mov    ecx,ecx
    705958803aba:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958803abd:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958803ac1:	eb 57                	jmp    0x705958803b1a
    705958803ac3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803aca:	00 
    705958803acb:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    705958803acf:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    705958803ad6:	00 
    705958803ad7:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    705958803ade:	00 01 00 
    705958803ae1:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    705958803ae8:	00 00 00 
    705958803aeb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    705958803af2:	00 00 00 
    705958803af5:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958803afc:	63 00 00 
    705958803aff:	ff d0                	call   rax
    705958803b01:	89 c1                	mov    ecx,eax
    705958803b03:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803b0a:	00 
    705958803b0b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    705958803b0f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803b16:	75 1c                	jne    0x705958803b34
    705958803b18:	eb 4c                	jmp    0x705958803b66
    705958803b1a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803b21:	00 
    705958803b22:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    705958803b29:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958803b2d:	89 10                	mov    DWORD PTR [rax],edx
    705958803b2f:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    705958803b32:	eb 3c                	jmp    0x705958803b70
    705958803b34:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803b3b:	00 
    705958803b3c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803b42:	b9 1a 00 00 00       	mov    ecx,0x1a
    705958803b47:	b8 08 00 00 00       	mov    eax,0x8
    705958803b4c:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803b53:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803b5a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803b61:	e9 a6 02 00 00       	jmp    0x705958803e0c
    705958803b66:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    705958803b6a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958803b6e:	eb aa                	jmp    0x705958803b1a
    705958803b70:	eb 00                	jmp    0x705958803b72
    705958803b72:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    705958803b79:	83 c0 f8             	add    eax,0xfffffff8
    705958803b7c:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    705958803b80:	83 e0 03             	and    eax,0x3
    705958803b83:	83 f8 00             	cmp    eax,0x0
    705958803b86:	74 7a                	je     0x705958803c02
    705958803b88:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    705958803b8f:	00 
    705958803b90:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958803b94:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    705958803b9b:	00 
    705958803b9c:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    705958803ba3:	00 01 00 
    705958803ba6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958803bad:	00 00 00 
    705958803bb0:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    705958803bb7:	00 00 00 
    705958803bba:	31 c0                	xor    eax,eax
    705958803bbc:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958803bc3:	63 00 00 
    705958803bc6:	ba 8c 00 01 00       	mov    edx,0x1008c
    705958803bcb:	45 31 c0             	xor    r8d,r8d
    705958803bce:	ff d0                	call   rax
    705958803bd0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803bd7:	00 
    705958803bd8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803bde:	b9 1b 00 00 00       	mov    ecx,0x1b
    705958803be3:	b8 02 00 00 00       	mov    eax,0x2
    705958803be8:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803bef:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803bf6:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803bfd:	e9 0a 02 00 00       	jmp    0x705958803e0c
    705958803c02:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    705958803c09:	00 
    705958803c0a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958803c0e:	c1 e9 0c             	shr    ecx,0xc
    705958803c11:	89 c9                	mov    ecx,ecx
    705958803c13:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958803c17:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    705958803c1c:	48 83 f8 00          	cmp    rax,0x0
    705958803c20:	74 1a                	je     0x705958803c3c
    705958803c22:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958803c27:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958803c2b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958803c31:	89 c9                	mov    ecx,ecx
    705958803c33:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958803c36:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958803c3a:	eb 57                	jmp    0x705958803c93
    705958803c3c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803c43:	00 
    705958803c44:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    705958803c48:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    705958803c4f:	00 
    705958803c50:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    705958803c57:	00 01 00 
    705958803c5a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958803c61:	00 00 00 
    705958803c64:	c7 80 34 01 00 00 1b 	mov    DWORD PTR [rax+0x134],0x1b
    705958803c6b:	00 00 00 
    705958803c6e:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958803c75:	63 00 00 
    705958803c78:	ff d0                	call   rax
    705958803c7a:	89 c1                	mov    ecx,eax
    705958803c7c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803c83:	00 
    705958803c84:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    705958803c88:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958803c8f:	75 13                	jne    0x705958803ca4
    705958803c91:	eb 43                	jmp    0x705958803cd6
    705958803c93:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803c9a:	00 
    705958803c9b:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958803c9f:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    705958803ca2:	eb 3c                	jmp    0x705958803ce0
    705958803ca4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803cab:	00 
    705958803cac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958803cb2:	b9 1b 00 00 00       	mov    ecx,0x1b
    705958803cb7:	b8 02 00 00 00       	mov    eax,0x2
    705958803cbc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    705958803cc3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    705958803cca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    705958803cd1:	e9 36 01 00 00       	jmp    0x705958803e0c
    705958803cd6:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    705958803cda:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958803cde:	eb b3                	jmp    0x705958803c93
    705958803ce0:	eb 00                	jmp    0x705958803ce2
    705958803ce2:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    705958803ce9:	00 
    705958803cea:	8b b4 24 f0 00 00 00 	mov    esi,DWORD PTR [rsp+0xf0]
    705958803cf1:	8b 84 24 ec 00 00 00 	mov    eax,DWORD PTR [rsp+0xec]
    705958803cf8:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    705958803cfe:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    705958803d04:	83 ff 01             	cmp    edi,0x1
    705958803d07:	0f 97 c3             	seta   bl
    705958803d0a:	3d 8e 00 01 00       	cmp    eax,0x1008e
    705958803d0f:	0f 94 c0             	sete   al
    705958803d12:	20 c3                	and    bl,al
    705958803d14:	b8 92 00 01 00       	mov    eax,0x10092
    705958803d19:	f6 c3 01             	test   bl,0x1
    705958803d1c:	0f 45 c2             	cmovne eax,edx
    705958803d1f:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    705958803d25:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    705958803d2b:	83 ff 01             	cmp    edi,0x1
    705958803d2e:	0f 97 c3             	seta   bl
    705958803d31:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    705958803d37:	40 0f 94 c6          	sete   sil
    705958803d3b:	40 20 f3             	and    bl,sil
    705958803d3e:	f6 c3 01             	test   bl,0x1
    705958803d41:	0f 45 c2             	cmovne eax,edx
    705958803d44:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    705958803d4a:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    705958803d51:	03 01 00 
    705958803d54:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958803d5a:	83 c0 1c             	add    eax,0x1c
    705958803d5d:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    705958803d61:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958803d67:	72 16                	jb     0x705958803d7f
    705958803d69:	eb 37                	jmp    0x705958803da2
    705958803d6b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803d72:	00 
    705958803d73:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958803d7a:	e9 4a 01 00 00       	jmp    0x705958803ec9
    705958803d7f:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    705958803d86:	00 
    705958803d87:	48 89 c1             	mov    rcx,rax
    705958803d8a:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    705958803d91:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    705958803d96:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    705958803d9d:	03 01 00 
    705958803da0:	74 32                	je     0x705958803dd4
    705958803da2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803da9:	00 
    705958803daa:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    705958803db1:	03 01 00 
    705958803db4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958803dbb:	00 00 00 
    705958803dbe:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    705958803dc5:	00 00 00 
    705958803dc8:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    705958803dcf:	e9 f5 00 00 00       	jmp    0x705958803ec9
    705958803dd4:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    705958803ddb:	00 
    705958803ddc:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    705958803de3:	00 
    705958803de4:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    705958803de9:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    705958803ded:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    705958803df4:	28 03 01 00 
    705958803df8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958803dff:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958803e03:	48 81 c4 28 01 00 00 	add    rsp,0x128
    705958803e0a:	ff e0                	jmp    rax
    705958803e0c:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    705958803e13:	00 
    705958803e14:	8b 94 24 e0 00 00 00 	mov    edx,DWORD PTR [rsp+0xe0]
    705958803e1b:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    705958803e22:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    705958803e29:	89 c7                	mov    edi,eax
    705958803e2b:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    705958803e2f:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    705958803e33:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    705958803e37:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    705958803e3d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    705958803e41:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958803e47:	73 2d                	jae    0x705958803e76
    705958803e49:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    705958803e50:	00 
    705958803e51:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    705958803e55:	89 d1                	mov    ecx,edx
    705958803e57:	c1 e9 01             	shr    ecx,0x1
    705958803e5a:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958803e60:	89 c9                	mov    ecx,ecx
    705958803e62:	48 c1 e1 04          	shl    rcx,0x4
    705958803e66:	48 89 c6             	mov    rsi,rax
    705958803e69:	48 01 ce             	add    rsi,rcx
    705958803e6c:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    705958803e71:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958803e74:	74 1e                	je     0x705958803e94
    705958803e76:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    705958803e7d:	00 
    705958803e7e:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    705958803e82:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    705958803e86:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    705958803e8c:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    705958803e92:	eb 35                	jmp    0x705958803ec9
    705958803e94:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    705958803e9b:	00 
    705958803e9c:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    705958803ea3:	00 
    705958803ea4:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958803ea9:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    705958803ead:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958803eb4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958803ebb:	00 
    705958803ebc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958803ec0:	48 81 c4 28 01 00 00 	add    rsp,0x128
    705958803ec7:	ff e0                	jmp    rax
    705958803ec9:	48 81 c4 28 01 00 00 	add    rsp,0x128
    705958803ed0:	c2 08 00             	ret    0x8
