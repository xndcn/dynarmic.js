
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65536-0-123529039183904.bin:     file format binary


Disassembly of section .data:

0000705958800020 <.data>:
    705958800020:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    705958800025:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    70595880002a:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958800031:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    705958800036:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    70595880003b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958800041:	83 fa 00             	cmp    edx,0x0
    705958800044:	0f 94 c0             	sete   al
    705958800047:	81 ea 00 00 01 00    	sub    edx,0x10000
    70595880004d:	83 fa 02             	cmp    edx,0x2
    705958800050:	0f 97 c2             	seta   dl
    705958800053:	08 d0                	or     al,dl
    705958800055:	24 01                	and    al,0x1
    705958800057:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880005d:	83 fa 00             	cmp    edx,0x0
    705958800060:	0f 94 c1             	sete   cl
    705958800063:	81 ea 00 00 01 00    	sub    edx,0x10000
    705958800069:	83 fa 02             	cmp    edx,0x2
    70595880006c:	0f 97 c2             	seta   dl
    70595880006f:	08 d1                	or     cl,dl
    705958800071:	20 c8                	and    al,cl
    705958800073:	a8 01                	test   al,0x1
    705958800075:	75 05                	jne    0x70595880007c
    705958800077:	e9 16 01 00 00       	jmp    0x705958800192
    70595880007c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    705958800081:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958800088:	48 89 c8             	mov    rax,rcx
    70595880008b:	48 05 00 00 10 00    	add    rax,0x100000
    705958800091:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    705958800096:	8b 81 00 00 10 00    	mov    eax,DWORD PTR [rcx+0x100000]
    70595880009c:	83 c0 01             	add    eax,0x1
    70595880009f:	89 81 00 00 10 00    	mov    DWORD PTR [rcx+0x100000],eax
    7059588000a5:	3d 30 75 00 00       	cmp    eax,0x7530
    7059588000aa:	75 40                	jne    0x7059588000ec
    7059588000ac:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    7059588000b1:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    7059588000b7:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    7059588000bb:	89 c2                	mov    edx,eax
    7059588000bd:	83 c2 01             	add    edx,0x1
    7059588000c0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    7059588000c6:	3d 00 01 00 00       	cmp    eax,0x100
    7059588000cb:	73 1d                	jae    0x7059588000ea
    7059588000cd:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    7059588000d2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    7059588000d6:	89 c9                	mov    ecx,ecx
    7059588000d8:	48 c1 e1 02          	shl    rcx,0x2
    7059588000dc:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    7059588000e3:	c7 04 08 00 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x0
    7059588000ea:	eb 00                	jmp    0x7059588000ec
    7059588000ec:	eb 00                	jmp    0x7059588000ee
    7059588000ee:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    7059588000f3:	8b 48 38             	mov    ecx,DWORD PTR [rax+0x38]
    7059588000f6:	83 c1 f4             	add    ecx,0xfffffff4
    7059588000f9:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    7059588000fc:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    705958800102:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    705958800106:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    70595880010c:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    705958800110:	eb 00                	jmp    0x705958800112
    705958800112:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    705958800117:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    70595880011b:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    70595880011f:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    705958800125:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    70595880012b:	83 ff 01             	cmp    edi,0x1
    70595880012e:	0f 97 c3             	seta   bl
    705958800131:	3d 02 00 01 00       	cmp    eax,0x10002
    705958800136:	0f 94 c0             	sete   al
    705958800139:	20 c3                	and    bl,al
    70595880013b:	b8 06 00 01 00       	mov    eax,0x10006
    705958800140:	f6 c3 01             	test   bl,0x1
    705958800143:	0f 45 c2             	cmovne eax,edx
    705958800146:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    70595880014c:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    705958800152:	83 ff 01             	cmp    edi,0x1
    705958800155:	0f 97 c3             	seta   bl
    705958800158:	81 fe 02 00 01 00    	cmp    esi,0x10002
    70595880015e:	40 0f 94 c6          	sete   sil
    705958800162:	40 20 f3             	and    bl,sil
    705958800165:	f6 c3 01             	test   bl,0x1
    705958800168:	0f 45 c2             	cmovne eax,edx
    70595880016b:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    705958800171:	c7 81 bc 00 00 00 14 	mov    DWORD PTR [rcx+0xbc],0x10014
    705958800178:	00 01 00 
    70595880017b:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958800181:	83 c0 02             	add    eax,0x2
    705958800184:	89 44 24 d0          	mov    DWORD PTR [rsp-0x30],eax
    705958800188:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880018e:	72 10                	jb     0x7059588001a0
    705958800190:	eb 2e                	jmp    0x7059588001c0
    705958800192:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    705958800197:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880019e:	eb 77                	jmp    0x705958800217
    7059588001a0:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    7059588001a5:	48 89 c1             	mov    rcx,rax
    7059588001a8:	48 81 c1 a0 00 08 00 	add    rcx,0x800a0
    7059588001af:	48 89 4c 24 c8       	mov    QWORD PTR [rsp-0x38],rcx
    7059588001b4:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    7059588001bb:	00 01 00 
    7059588001be:	74 2c                	je     0x7059588001ec
    7059588001c0:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    7059588001c5:	c7 80 bc 00 00 00 14 	mov    DWORD PTR [rax+0xbc],0x10014
    7059588001cc:	00 01 00 
    7059588001cf:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    7059588001d6:	00 00 00 
    7059588001d9:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    7059588001e0:	00 00 00 
    7059588001e3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    7059588001ea:	eb 2b                	jmp    0x705958800217
    7059588001ec:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    7059588001f1:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    7059588001f6:	48 8b 44 24 c8       	mov    rax,QWORD PTR [rsp-0x38]
    7059588001fb:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    7059588001ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    705958800206:	14 00 01 00 
    70595880020a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958800211:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958800215:	ff e0                	jmp    rax
    705958800217:	c2 08 00             	ret    0x8
