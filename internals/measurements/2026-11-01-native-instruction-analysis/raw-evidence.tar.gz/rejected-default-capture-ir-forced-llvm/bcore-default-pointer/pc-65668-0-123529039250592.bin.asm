
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65668-0-123529039250592.bin:     file format binary


Disassembly of section .data:

00007059588104a0 <.data>:
    7059588104a0:	48 81 ec a8 00 00 00 	sub    rsp,0xa8
    7059588104a7:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
    7059588104ae:	00 
    7059588104af:	4c 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r13
    7059588104b6:	00 
    7059588104b7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7059588104be:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    7059588104c5:	00 
    7059588104c6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7059588104cd:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    7059588104d4:	00 
    7059588104d5:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    7059588104dc:	00 
    7059588104dd:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    7059588104e3:	83 fa 00             	cmp    edx,0x0
    7059588104e6:	0f 94 c0             	sete   al
    7059588104e9:	81 ea 84 00 01 00    	sub    edx,0x10084
    7059588104ef:	83 fa 0a             	cmp    edx,0xa
    7059588104f2:	0f 97 c2             	seta   dl
    7059588104f5:	08 d0                	or     al,dl
    7059588104f7:	24 01                	and    al,0x1
    7059588104f9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    7059588104ff:	81 fa 20 04 01 00    	cmp    edx,0x10420
    705958810505:	0f 94 c1             	sete   cl
    705958810508:	81 ea 84 00 01 00    	sub    edx,0x10084
    70595881050e:	83 fa 0a             	cmp    edx,0xa
    705958810511:	0f 97 c2             	seta   dl
    705958810514:	08 d1                	or     cl,dl
    705958810516:	20 c8                	and    al,cl
    705958810518:	a8 01                	test   al,0x1
    70595881051a:	75 05                	jne    0x705958810521
    70595881051c:	e9 c9 03 00 00       	jmp    0x7059588108ea
    705958810521:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958810528:	00 
    705958810529:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958810530:	48 89 c8             	mov    rax,rcx
    705958810533:	48 05 00 00 10 00    	add    rax,0x100000
    705958810539:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    705958810540:	00 
    705958810541:	8b 81 40 00 10 00    	mov    eax,DWORD PTR [rcx+0x100040]
    705958810547:	83 c0 01             	add    eax,0x1
    70595881054a:	89 81 40 00 10 00    	mov    DWORD PTR [rcx+0x100040],eax
    705958810550:	3d 30 75 00 00       	cmp    eax,0x7530
    705958810555:	75 46                	jne    0x70595881059d
    705958810557:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    70595881055e:	00 
    70595881055f:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958810565:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    705958810569:	89 c2                	mov    edx,eax
    70595881056b:	83 c2 01             	add    edx,0x1
    70595881056e:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958810574:	3d 00 01 00 00       	cmp    eax,0x100
    705958810579:	73 20                	jae    0x70595881059b
    70595881057b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958810582:	00 
    705958810583:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958810587:	89 c9                	mov    ecx,ecx
    705958810589:	48 c1 e1 02          	shl    rcx,0x2
    70595881058d:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958810594:	c7 04 08 10 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x10
    70595881059b:	eb 00                	jmp    0x70595881059d
    70595881059d:	eb 00                	jmp    0x70595881059f
    70595881059f:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588105a6:	00 
    7059588105a7:	8b 48 10             	mov    ecx,DWORD PTR [rax+0x10]
    7059588105aa:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    7059588105ae:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    7059588105b1:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588105b5:	83 c0 fc             	add    eax,0xfffffffc
    7059588105b8:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    7059588105bc:	83 e0 03             	and    eax,0x3
    7059588105bf:	83 f8 00             	cmp    eax,0x0
    7059588105c2:	74 67                	je     0x70595881062b
    7059588105c4:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    7059588105cb:	00 
    7059588105cc:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    7059588105d0:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    7059588105d7:	00 
    7059588105d8:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    7059588105df:	00 00 00 
    7059588105e2:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    7059588105e9:	00 00 00 
    7059588105ec:	31 c0                	xor    eax,eax
    7059588105ee:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588105f5:	63 00 00 
    7059588105f8:	ba 84 00 01 00       	mov    edx,0x10084
    7059588105fd:	45 31 c0             	xor    r8d,r8d
    705958810600:	ff d0                	call   rax
    705958810602:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958810609:	00 
    70595881060a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958810610:	b9 01 00 00 00       	mov    ecx,0x1
    705958810615:	b8 08 00 00 00       	mov    eax,0x8
    70595881061a:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    70595881061e:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    705958810622:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    705958810626:	e9 60 03 00 00       	jmp    0x70595881098b
    70595881062b:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    705958810632:	00 
    705958810633:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    705958810637:	c1 e9 0c             	shr    ecx,0xc
    70595881063a:	89 c9                	mov    ecx,ecx
    70595881063c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958810640:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958810645:	48 83 f8 00          	cmp    rax,0x0
    705958810649:	74 1a                	je     0x705958810665
    70595881064b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    705958810650:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    705958810654:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595881065a:	89 c9                	mov    ecx,ecx
    70595881065c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595881065f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    705958810663:	eb 4d                	jmp    0x7059588106b2
    705958810665:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    70595881066c:	00 
    70595881066d:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    705958810671:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    705958810678:	00 
    705958810679:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    705958810680:	00 00 00 
    705958810683:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    70595881068a:	00 00 00 
    70595881068d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958810694:	63 00 00 
    705958810697:	ff d0                	call   rax
    705958810699:	89 c1                	mov    ecx,eax
    70595881069b:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588106a2:	00 
    7059588106a3:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    7059588106a7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588106ae:	75 2d                	jne    0x7059588106dd
    7059588106b0:	eb 54                	jmp    0x705958810706
    7059588106b2:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588106b9:	00 
    7059588106ba:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    7059588106be:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    7059588106c2:	89 10                	mov    DWORD PTR [rax],edx
    7059588106c4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    7059588106c7:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    7059588106cd:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    7059588106d1:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    7059588106d7:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    7059588106db:	eb 33                	jmp    0x705958810710
    7059588106dd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588106e4:	00 
    7059588106e5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588106eb:	b9 01 00 00 00       	mov    ecx,0x1
    7059588106f0:	b8 08 00 00 00       	mov    eax,0x8
    7059588106f5:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    7059588106f9:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    7059588106fd:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    705958810701:	e9 85 02 00 00       	jmp    0x70595881098b
    705958810706:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    70595881070a:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595881070e:	eb a2                	jmp    0x7059588106b2
    705958810710:	eb 00                	jmp    0x705958810712
    705958810712:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    705958810716:	83 c0 f8             	add    eax,0xfffffff8
    705958810719:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    70595881071d:	83 e0 03             	and    eax,0x3
    705958810720:	83 f8 00             	cmp    eax,0x0
    705958810723:	74 6e                	je     0x705958810793
    705958810725:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    70595881072c:	00 
    70595881072d:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958810731:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    705958810738:	00 
    705958810739:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    705958810740:	00 01 00 
    705958810743:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595881074a:	00 00 00 
    70595881074d:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958810754:	00 00 00 
    705958810757:	31 c0                	xor    eax,eax
    705958810759:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958810760:	63 00 00 
    705958810763:	ba 8c 00 01 00       	mov    edx,0x1008c
    705958810768:	45 31 c0             	xor    r8d,r8d
    70595881076b:	ff d0                	call   rax
    70595881076d:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958810774:	00 
    705958810775:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    70595881077b:	b8 02 00 00 00       	mov    eax,0x2
    705958810780:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    705958810784:	89 c1                	mov    ecx,eax
    705958810786:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    70595881078a:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    70595881078e:	e9 f8 01 00 00       	jmp    0x70595881098b
    705958810793:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    70595881079a:	00 
    70595881079b:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595881079f:	c1 e9 0c             	shr    ecx,0xc
    7059588107a2:	89 c9                	mov    ecx,ecx
    7059588107a4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588107a8:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    7059588107ad:	48 83 f8 00          	cmp    rax,0x0
    7059588107b1:	74 1a                	je     0x7059588107cd
    7059588107b3:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    7059588107b8:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    7059588107bc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588107c2:	89 c9                	mov    ecx,ecx
    7059588107c4:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588107c7:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    7059588107cb:	eb 57                	jmp    0x705958810824
    7059588107cd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588107d4:	00 
    7059588107d5:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    7059588107d9:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    7059588107e0:	00 
    7059588107e1:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    7059588107e8:	00 01 00 
    7059588107eb:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588107f2:	00 00 00 
    7059588107f5:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    7059588107fc:	00 00 00 
    7059588107ff:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958810806:	63 00 00 
    705958810809:	ff d0                	call   rax
    70595881080b:	89 c1                	mov    ecx,eax
    70595881080d:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958810814:	00 
    705958810815:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    705958810819:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958810820:	75 13                	jne    0x705958810835
    705958810822:	eb 37                	jmp    0x70595881085b
    705958810824:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    70595881082b:	00 
    70595881082c:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958810830:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    705958810833:	eb 30                	jmp    0x705958810865
    705958810835:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    70595881083c:	00 
    70595881083d:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    705958810843:	b8 02 00 00 00       	mov    eax,0x2
    705958810848:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    70595881084c:	89 c1                	mov    ecx,eax
    70595881084e:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    705958810852:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    705958810856:	e9 30 01 00 00       	jmp    0x70595881098b
    70595881085b:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    70595881085f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958810863:	eb bf                	jmp    0x705958810824
    705958810865:	eb 00                	jmp    0x705958810867
    705958810867:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    70595881086e:	00 
    70595881086f:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    705958810873:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    705958810877:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    70595881087d:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    705958810883:	83 ff 01             	cmp    edi,0x1
    705958810886:	0f 97 c3             	seta   bl
    705958810889:	3d 8e 00 01 00       	cmp    eax,0x1008e
    70595881088e:	0f 94 c0             	sete   al
    705958810891:	20 c3                	and    bl,al
    705958810893:	b8 92 00 01 00       	mov    eax,0x10092
    705958810898:	f6 c3 01             	test   bl,0x1
    70595881089b:	0f 45 c2             	cmovne eax,edx
    70595881089e:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    7059588108a4:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    7059588108aa:	83 ff 01             	cmp    edi,0x1
    7059588108ad:	0f 97 c3             	seta   bl
    7059588108b0:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    7059588108b6:	40 0f 94 c6          	sete   sil
    7059588108ba:	40 20 f3             	and    bl,sil
    7059588108bd:	f6 c3 01             	test   bl,0x1
    7059588108c0:	0f 45 c2             	cmovne eax,edx
    7059588108c3:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    7059588108c9:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    7059588108d0:	03 01 00 
    7059588108d3:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    7059588108d9:	83 c0 03             	add    eax,0x3
    7059588108dc:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    7059588108e0:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588108e6:	72 16                	jb     0x7059588108fe
    7059588108e8:	eb 37                	jmp    0x705958810921
    7059588108ea:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588108f1:	00 
    7059588108f2:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    7059588108f9:	e9 41 01 00 00       	jmp    0x705958810a3f
    7059588108fe:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958810905:	00 
    705958810906:	48 89 c1             	mov    rcx,rax
    705958810909:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    705958810910:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    705958810915:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    70595881091c:	03 01 00 
    70595881091f:	74 32                	je     0x705958810953
    705958810921:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958810928:	00 
    705958810929:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    705958810930:	03 01 00 
    705958810933:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595881093a:	00 00 00 
    70595881093d:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    705958810944:	00 00 00 
    705958810947:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595881094e:	e9 ec 00 00 00       	jmp    0x705958810a3f
    705958810953:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    70595881095a:	00 
    70595881095b:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    705958810962:	00 
    705958810963:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    705958810968:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    70595881096c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    705958810973:	28 03 01 00 
    705958810977:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595881097e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958810982:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    705958810989:	ff e0                	jmp    rax
    70595881098b:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    705958810992:	00 
    705958810993:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    705958810997:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    70595881099b:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    70595881099f:	89 c7                	mov    edi,eax
    7059588109a1:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    7059588109a5:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    7059588109a9:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    7059588109ad:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    7059588109b3:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7059588109b7:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588109bd:	73 2d                	jae    0x7059588109ec
    7059588109bf:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    7059588109c6:	00 
    7059588109c7:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    7059588109cb:	89 d1                	mov    ecx,edx
    7059588109cd:	c1 e9 01             	shr    ecx,0x1
    7059588109d0:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588109d6:	89 c9                	mov    ecx,ecx
    7059588109d8:	48 c1 e1 04          	shl    rcx,0x4
    7059588109dc:	48 89 c6             	mov    rsi,rax
    7059588109df:	48 01 ce             	add    rsi,rcx
    7059588109e2:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    7059588109e7:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    7059588109ea:	74 1e                	je     0x705958810a0a
    7059588109ec:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    7059588109f3:	00 
    7059588109f4:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    7059588109f8:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    7059588109fc:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    705958810a02:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    705958810a08:	eb 35                	jmp    0x705958810a3f
    705958810a0a:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    705958810a11:	00 
    705958810a12:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    705958810a19:	00 
    705958810a1a:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958810a1f:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    705958810a23:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958810a2a:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958810a31:	00 
    705958810a32:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958810a36:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    705958810a3d:	ff e0                	jmp    rax
    705958810a3f:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    705958810a46:	c2 08 00             	ret    0x8
