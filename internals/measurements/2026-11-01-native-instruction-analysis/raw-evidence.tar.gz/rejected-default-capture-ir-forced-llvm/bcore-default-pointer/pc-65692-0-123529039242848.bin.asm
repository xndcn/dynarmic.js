
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65692-0-123529039242848.bin:     file format binary


Disassembly of section .data:

000070595880e660 <.data>:
    70595880e660:	48 81 ec 98 01 00 00 	sub    rsp,0x198
    70595880e667:	4c 89 b4 24 70 01 00 	mov    QWORD PTR [rsp+0x170],r14
    70595880e66e:	00 
    70595880e66f:	4c 89 ac 24 78 01 00 	mov    QWORD PTR [rsp+0x178],r13
    70595880e676:	00 
    70595880e677:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880e67e:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    70595880e685:	00 
    70595880e686:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    70595880e68d:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    70595880e694:	00 
    70595880e695:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880e69c:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    70595880e6a3:	00 
    70595880e6a4:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880e6ab:	00 
    70595880e6ac:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    70595880e6b2:	83 fa 00             	cmp    edx,0x0
    70595880e6b5:	0f 94 c0             	sete   al
    70595880e6b8:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    70595880e6be:	83 fa 22             	cmp    edx,0x22
    70595880e6c1:	0f 97 c2             	seta   dl
    70595880e6c4:	08 d0                	or     al,dl
    70595880e6c6:	24 01                	and    al,0x1
    70595880e6c8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880e6ce:	81 fa 20 04 01 00    	cmp    edx,0x10420
    70595880e6d4:	0f 94 c1             	sete   cl
    70595880e6d7:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    70595880e6dd:	83 fa 22             	cmp    edx,0x22
    70595880e6e0:	0f 97 c2             	seta   dl
    70595880e6e3:	08 d1                	or     cl,dl
    70595880e6e5:	20 c8                	and    al,cl
    70595880e6e7:	a8 01                	test   al,0x1
    70595880e6e9:	75 05                	jne    0x70595880e6f0
    70595880e6eb:	e9 0a 1c 00 00       	jmp    0x7059588102fa
    70595880e6f0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e6f7:	00 
    70595880e6f8:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880e6ff:	48 89 c8             	mov    rax,rcx
    70595880e702:	48 05 00 00 10 00    	add    rax,0x100000
    70595880e708:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    70595880e70f:	00 
    70595880e710:	8b 81 3c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10003c]
    70595880e716:	83 c0 01             	add    eax,0x1
    70595880e719:	89 81 3c 00 10 00    	mov    DWORD PTR [rcx+0x10003c],eax
    70595880e71f:	3d 30 75 00 00       	cmp    eax,0x7530
    70595880e724:	75 4c                	jne    0x70595880e772
    70595880e726:	48 8b 8c 24 68 01 00 	mov    rcx,QWORD PTR [rsp+0x168]
    70595880e72d:	00 
    70595880e72e:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    70595880e734:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    70595880e73b:	89 c2                	mov    edx,eax
    70595880e73d:	83 c2 01             	add    edx,0x1
    70595880e740:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    70595880e746:	3d 00 01 00 00       	cmp    eax,0x100
    70595880e74b:	73 23                	jae    0x70595880e770
    70595880e74d:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    70595880e754:	00 
    70595880e755:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    70595880e75c:	89 c9                	mov    ecx,ecx
    70595880e75e:	48 c1 e1 02          	shl    rcx,0x2
    70595880e762:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880e769:	c7 04 08 0f 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xf
    70595880e770:	eb 00                	jmp    0x70595880e772
    70595880e772:	eb 00                	jmp    0x70595880e774
    70595880e774:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880e77b:	00 
    70595880e77c:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    70595880e77f:	89 84 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],eax
    70595880e786:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    70595880e789:	89 8c 24 60 01 00 00 	mov    DWORD PTR [rsp+0x160],ecx
    70595880e790:	83 e0 03             	and    eax,0x3
    70595880e793:	83 f8 00             	cmp    eax,0x0
    70595880e796:	0f 84 8e 00 00 00    	je     0x70595880e82a
    70595880e79c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880e7a3:	00 
    70595880e7a4:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    70595880e7ab:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880e7b2:	00 
    70595880e7b3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e7ba:	00 00 00 
    70595880e7bd:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595880e7c4:	00 00 00 
    70595880e7c7:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880e7ce:	63 00 00 
    70595880e7d1:	ba 9c 00 01 00       	mov    edx,0x1009c
    70595880e7d6:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880e7dc:	ff d0                	call   rax
    70595880e7de:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e7e5:	00 
    70595880e7e6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880e7ec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880e7f2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880e7f8:	be 01 00 00 00       	mov    esi,0x1
    70595880e7fd:	b9 02 00 00 00       	mov    ecx,0x2
    70595880e802:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880e809:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880e810:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880e817:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880e81e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880e825:	e9 74 1b 00 00       	jmp    0x70595881039e
    70595880e82a:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880e831:	00 
    70595880e832:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    70595880e839:	c1 e9 0c             	shr    ecx,0xc
    70595880e83c:	89 c9                	mov    ecx,ecx
    70595880e83e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880e842:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
    70595880e849:	00 
    70595880e84a:	48 83 f8 00          	cmp    rax,0x0
    70595880e84e:	74 23                	je     0x70595880e873
    70595880e850:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    70595880e857:	00 
    70595880e858:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    70595880e85f:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    70595880e866:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880e86c:	89 c9                	mov    ecx,ecx
    70595880e86e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880e871:	eb 51                	jmp    0x70595880e8c4
    70595880e873:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e87a:	00 
    70595880e87b:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    70595880e882:	8b b4 24 5c 01 00 00 	mov    esi,DWORD PTR [rsp+0x15c]
    70595880e889:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880e890:	00 
    70595880e891:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880e898:	00 00 00 
    70595880e89b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    70595880e8a2:	00 00 00 
    70595880e8a5:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880e8ac:	63 00 00 
    70595880e8af:	ff d0                	call   rax
    70595880e8b1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e8b8:	00 
    70595880e8b9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880e8c0:	75 14                	jne    0x70595880e8d6
    70595880e8c2:	eb 5e                	jmp    0x70595880e922
    70595880e8c4:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    70595880e8cb:	00 
    70595880e8cc:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880e8cf:	75 53                	jne    0x70595880e924
    70595880e8d1:	e9 93 00 00 00       	jmp    0x70595880e969
    70595880e8d6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e8dd:	00 
    70595880e8de:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880e8e4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880e8ea:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880e8f0:	be 01 00 00 00       	mov    esi,0x1
    70595880e8f5:	b9 02 00 00 00       	mov    ecx,0x2
    70595880e8fa:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880e901:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880e908:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880e90f:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880e916:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880e91d:	e9 7c 1a 00 00       	jmp    0x70595881039e
    70595880e922:	eb a0                	jmp    0x70595880e8c4
    70595880e924:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880e92b:	00 
    70595880e92c:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    70595880e933:	00 01 00 
    70595880e936:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880e93d:	00 00 00 
    70595880e940:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595880e947:	00 00 00 
    70595880e94a:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880e951:	63 00 00 
    70595880e954:	ff d0                	call   rax
    70595880e956:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e95d:	00 
    70595880e95e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880e965:	75 04                	jne    0x70595880e96b
    70595880e967:	eb 4e                	jmp    0x70595880e9b7
    70595880e969:	eb 4e                	jmp    0x70595880e9b9
    70595880e96b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880e972:	00 
    70595880e973:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880e979:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880e97f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880e985:	be 01 00 00 00       	mov    esi,0x1
    70595880e98a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880e98f:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880e996:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880e99d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880e9a4:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880e9ab:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880e9b2:	e9 e7 19 00 00       	jmp    0x70595881039e
    70595880e9b7:	eb b0                	jmp    0x70595880e969
    70595880e9b9:	eb 00                	jmp    0x70595880e9bb
    70595880e9bb:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880e9c2:	00 
    70595880e9c3:	8b 41 34             	mov    eax,DWORD PTR [rcx+0x34]
    70595880e9c6:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    70595880e9cd:	8b 09                	mov    ecx,DWORD PTR [rcx]
    70595880e9cf:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    70595880e9d6:	83 e0 03             	and    eax,0x3
    70595880e9d9:	83 f8 00             	cmp    eax,0x0
    70595880e9dc:	0f 84 95 00 00 00    	je     0x70595880ea77
    70595880e9e2:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880e9e9:	00 
    70595880e9ea:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    70595880e9f1:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880e9f8:	00 
    70595880e9f9:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    70595880ea00:	00 01 00 
    70595880ea03:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ea0a:	00 00 00 
    70595880ea0d:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    70595880ea14:	00 00 00 
    70595880ea17:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ea1e:	63 00 00 
    70595880ea21:	ba 9e 00 01 00       	mov    edx,0x1009e
    70595880ea26:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880ea2c:	ff d0                	call   rax
    70595880ea2e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ea35:	00 
    70595880ea36:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    70595880ea3c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ea42:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ea48:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ea4d:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    70595880ea54:	89 ce                	mov    esi,ecx
    70595880ea56:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880ea5d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880ea64:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880ea6b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880ea72:	e9 27 19 00 00       	jmp    0x70595881039e
    70595880ea77:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880ea7e:	00 
    70595880ea7f:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    70595880ea86:	c1 e9 0c             	shr    ecx,0xc
    70595880ea89:	89 c9                	mov    ecx,ecx
    70595880ea8b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880ea8f:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    70595880ea96:	00 
    70595880ea97:	48 83 f8 00          	cmp    rax,0x0
    70595880ea9b:	74 23                	je     0x70595880eac0
    70595880ea9d:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    70595880eaa4:	00 
    70595880eaa5:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    70595880eaac:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    70595880eab3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880eab9:	89 c9                	mov    ecx,ecx
    70595880eabb:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880eabe:	eb 5b                	jmp    0x70595880eb1b
    70595880eac0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eac7:	00 
    70595880eac8:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    70595880eacf:	8b b4 24 38 01 00 00 	mov    esi,DWORD PTR [rsp+0x138]
    70595880ead6:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880eadd:	00 
    70595880eade:	c7 80 bc 00 00 00 9e 	mov    DWORD PTR [rax+0xbc],0x1009e
    70595880eae5:	00 01 00 
    70595880eae8:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880eaef:	00 00 00 
    70595880eaf2:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    70595880eaf9:	00 00 00 
    70595880eafc:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880eb03:	63 00 00 
    70595880eb06:	ff d0                	call   rax
    70595880eb08:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eb0f:	00 
    70595880eb10:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880eb17:	75 29                	jne    0x70595880eb42
    70595880eb19:	eb 70                	jmp    0x70595880eb8b
    70595880eb1b:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    70595880eb22:	00 
    70595880eb23:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880eb2a:	00 
    70595880eb2b:	8b 94 24 38 01 00 00 	mov    edx,DWORD PTR [rsp+0x138]
    70595880eb32:	83 c2 04             	add    edx,0x4
    70595880eb35:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    70595880eb38:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880eb3b:	75 50                	jne    0x70595880eb8d
    70595880eb3d:	e9 90 00 00 00       	jmp    0x70595880ebd2
    70595880eb42:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eb49:	00 
    70595880eb4a:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    70595880eb50:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880eb56:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880eb5c:	b9 02 00 00 00       	mov    ecx,0x2
    70595880eb61:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    70595880eb68:	89 ce                	mov    esi,ecx
    70595880eb6a:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880eb71:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880eb78:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880eb7f:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880eb86:	e9 13 18 00 00       	jmp    0x70595881039e
    70595880eb8b:	eb 8e                	jmp    0x70595880eb1b
    70595880eb8d:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880eb94:	00 
    70595880eb95:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x100a0
    70595880eb9c:	00 01 00 
    70595880eb9f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880eba6:	00 00 00 
    70595880eba9:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    70595880ebb0:	00 00 00 
    70595880ebb3:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880ebba:	63 00 00 
    70595880ebbd:	ff d0                	call   rax
    70595880ebbf:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ebc6:	00 
    70595880ebc7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880ebce:	75 04                	jne    0x70595880ebd4
    70595880ebd0:	eb 4b                	jmp    0x70595880ec1d
    70595880ebd2:	eb 4b                	jmp    0x70595880ec1f
    70595880ebd4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ebdb:	00 
    70595880ebdc:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    70595880ebe2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ebe8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ebee:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ebf3:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    70595880ebfa:	89 ce                	mov    esi,ecx
    70595880ebfc:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880ec03:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880ec0a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880ec11:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880ec18:	e9 81 17 00 00       	jmp    0x70595881039e
    70595880ec1d:	eb b3                	jmp    0x70595880ebd2
    70595880ec1f:	eb 00                	jmp    0x70595880ec21
    70595880ec21:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ec28:	00 
    70595880ec29:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    70595880ec2c:	89 ca                	mov    edx,ecx
    70595880ec2e:	83 c2 01             	add    edx,0x1
    70595880ec31:	89 94 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],edx
    70595880ec38:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    70595880ec3b:	89 ce                	mov    esi,ecx
    70595880ec3d:	c1 ee 1f             	shr    esi,0x1f
    70595880ec40:	89 d3                	mov    ebx,edx
    70595880ec42:	c1 eb 1f             	shr    ebx,0x1f
    70595880ec45:	89 df                	mov    edi,ebx
    70595880ec47:	83 f7 00             	xor    edi,0x0
    70595880ec4a:	31 de                	xor    esi,ebx
    70595880ec4c:	21 fe                	and    esi,edi
    70595880ec4e:	83 f1 ff             	xor    ecx,0xffffffff
    70595880ec51:	83 f9 01             	cmp    ecx,0x1
    70595880ec54:	0f 92 c1             	setb   cl
    70595880ec57:	80 e1 01             	and    cl,0x1
    70595880ec5a:	0f b6 c9             	movzx  ecx,cl
    70595880ec5d:	83 fa 00             	cmp    edx,0x0
    70595880ec60:	0f 94 c3             	sete   bl
    70595880ec63:	80 e3 01             	and    bl,0x1
    70595880ec66:	0f b6 fb             	movzx  edi,bl
    70595880ec69:	c1 ea 1f             	shr    edx,0x1f
    70595880ec6c:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    70595880ec72:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880ec78:	89 f2                	mov    edx,esi
    70595880ec7a:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    70595880ec80:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    70595880ec86:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    70595880ec8c:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    70595880ec92:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880ec98:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880ec9e:	eb 00                	jmp    0x70595880eca0
    70595880eca0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eca7:	00 
    70595880eca8:	c7 00 06 00 00 00    	mov    DWORD PTR [rax],0x6
    70595880ecae:	eb 00                	jmp    0x70595880ecb0
    70595880ecb0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ecb7:	00 
    70595880ecb8:	8b 40 2c             	mov    eax,DWORD PTR [rax+0x2c]
    70595880ecbb:	89 84 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],eax
    70595880ecc2:	83 e0 03             	and    eax,0x3
    70595880ecc5:	83 f8 00             	cmp    eax,0x0
    70595880ecc8:	0f 84 98 00 00 00    	je     0x70595880ed66
    70595880ecce:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880ecd5:	00 
    70595880ecd6:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    70595880ecdd:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880ece4:	00 
    70595880ece5:	c7 87 bc 00 00 00 a4 	mov    DWORD PTR [rdi+0xbc],0x100a4
    70595880ecec:	00 01 00 
    70595880ecef:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ecf6:	00 00 00 
    70595880ecf9:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880ed00:	00 00 00 
    70595880ed03:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ed0a:	63 00 00 
    70595880ed0d:	ba a4 00 01 00       	mov    edx,0x100a4
    70595880ed12:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880ed18:	ff d0                	call   rax
    70595880ed1a:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ed21:	00 
    70595880ed22:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ed28:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ed2e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ed34:	be 05 00 00 00       	mov    esi,0x5
    70595880ed39:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ed3e:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880ed45:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880ed4c:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880ed53:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880ed5a:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880ed61:	e9 38 16 00 00       	jmp    0x70595881039e
    70595880ed66:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880ed6d:	00 
    70595880ed6e:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    70595880ed75:	c1 e9 0c             	shr    ecx,0xc
    70595880ed78:	89 c9                	mov    ecx,ecx
    70595880ed7a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880ed7e:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    70595880ed85:	00 
    70595880ed86:	48 83 f8 00          	cmp    rax,0x0
    70595880ed8a:	74 23                	je     0x70595880edaf
    70595880ed8c:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    70595880ed93:	00 
    70595880ed94:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    70595880ed9b:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    70595880eda2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880eda8:	89 c9                	mov    ecx,ecx
    70595880edaa:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880edad:	eb 5b                	jmp    0x70595880ee0a
    70595880edaf:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880edb6:	00 
    70595880edb7:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    70595880edbe:	8b b4 24 28 01 00 00 	mov    esi,DWORD PTR [rsp+0x128]
    70595880edc5:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880edcc:	00 
    70595880edcd:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x100a4
    70595880edd4:	00 01 00 
    70595880edd7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880edde:	00 00 00 
    70595880ede1:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    70595880ede8:	00 00 00 
    70595880edeb:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880edf2:	63 00 00 
    70595880edf5:	ff d0                	call   rax
    70595880edf7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880edfe:	00 
    70595880edff:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880ee06:	75 14                	jne    0x70595880ee1c
    70595880ee08:	eb 5e                	jmp    0x70595880ee68
    70595880ee0a:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    70595880ee11:	00 
    70595880ee12:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880ee15:	75 53                	jne    0x70595880ee6a
    70595880ee17:	e9 93 00 00 00       	jmp    0x70595880eeaf
    70595880ee1c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ee23:	00 
    70595880ee24:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ee2a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ee30:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ee36:	be 05 00 00 00       	mov    esi,0x5
    70595880ee3b:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ee40:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880ee47:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880ee4e:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880ee55:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880ee5c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880ee63:	e9 36 15 00 00       	jmp    0x70595881039e
    70595880ee68:	eb a0                	jmp    0x70595880ee0a
    70595880ee6a:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880ee71:	00 
    70595880ee72:	c7 87 bc 00 00 00 a6 	mov    DWORD PTR [rdi+0xbc],0x100a6
    70595880ee79:	00 01 00 
    70595880ee7c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ee83:	00 00 00 
    70595880ee86:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880ee8d:	00 00 00 
    70595880ee90:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880ee97:	63 00 00 
    70595880ee9a:	ff d0                	call   rax
    70595880ee9c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eea3:	00 
    70595880eea4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880eeab:	75 04                	jne    0x70595880eeb1
    70595880eead:	eb 4e                	jmp    0x70595880eefd
    70595880eeaf:	eb 4e                	jmp    0x70595880eeff
    70595880eeb1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880eeb8:	00 
    70595880eeb9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880eebf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880eec5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880eecb:	be 05 00 00 00       	mov    esi,0x5
    70595880eed0:	b9 02 00 00 00       	mov    ecx,0x2
    70595880eed5:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880eedc:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880eee3:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880eeea:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880eef1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880eef8:	e9 a1 14 00 00       	jmp    0x70595881039e
    70595880eefd:	eb b0                	jmp    0x70595880eeaf
    70595880eeff:	eb 00                	jmp    0x70595880ef01
    70595880ef01:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ef08:	00 
    70595880ef09:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    70595880ef10:	89 fa                	mov    edx,edi
    70595880ef12:	83 ea 06             	sub    edx,0x6
    70595880ef15:	83 fa 00             	cmp    edx,0x0
    70595880ef18:	0f 94 c1             	sete   cl
    70595880ef1b:	80 e1 01             	and    cl,0x1
    70595880ef1e:	0f b6 f1             	movzx  esi,cl
    70595880ef21:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    70595880ef28:	c1 ea 1f             	shr    edx,0x1f
    70595880ef2b:	89 f9                	mov    ecx,edi
    70595880ef2d:	c1 e9 1f             	shr    ecx,0x1f
    70595880ef30:	89 d3                	mov    ebx,edx
    70595880ef32:	31 cb                	xor    ebx,ecx
    70595880ef34:	83 f1 00             	xor    ecx,0x0
    70595880ef37:	21 d9                	and    ecx,ebx
    70595880ef39:	31 ca                	xor    edx,ecx
    70595880ef3b:	b9 06 00 00 00       	mov    ecx,0x6
    70595880ef40:	39 f9                	cmp    ecx,edi
    70595880ef42:	0f 96 c1             	setbe  cl
    70595880ef45:	80 e1 01             	and    cl,0x1
    70595880ef48:	0f b6 c9             	movzx  ecx,cl
    70595880ef4b:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    70595880ef51:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    70595880ef57:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880ef5d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880ef63:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880ef69:	eb 00                	jmp    0x70595880ef6b
    70595880ef6b:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    70595880ef72:	83 f8 00             	cmp    eax,0x0
    70595880ef75:	75 33                	jne    0x70595880efaa
    70595880ef77:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880ef7e:	00 
    70595880ef7f:	c7 81 bc 00 00 00 84 	mov    DWORD PTR [rcx+0xbc],0x10084
    70595880ef86:	00 01 00 
    70595880ef89:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880ef8f:	83 c0 07             	add    eax,0x7
    70595880ef92:	89 84 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],eax
    70595880ef99:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880ef9f:	0f 82 69 13 00 00    	jb     0x70595881030e
    70595880efa5:	e9 87 13 00 00       	jmp    0x705958810331
    70595880efaa:	eb 00                	jmp    0x70595880efac
    70595880efac:	eb 00                	jmp    0x70595880efae
    70595880efae:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880efb5:	00 
    70595880efb6:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    70595880efb9:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880efbf:	83 c9 00             	or     ecx,0x0
    70595880efc2:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    70595880efc9:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880efcc:	eb 00                	jmp    0x70595880efce
    70595880efce:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880efd5:	00 
    70595880efd6:	c7 00 02 00 00 00    	mov    DWORD PTR [rax],0x2
    70595880efdc:	eb 00                	jmp    0x70595880efde
    70595880efde:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880efe5:	00 
    70595880efe6:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    70595880efed:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880eff3:	81 c9 10 f0 00 00    	or     ecx,0xf010
    70595880eff9:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    70595880f000:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880f003:	eb 00                	jmp    0x70595880f005
    70595880f005:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    70595880f00c:	83 e0 03             	and    eax,0x3
    70595880f00f:	83 f8 00             	cmp    eax,0x0
    70595880f012:	0f 84 98 00 00 00    	je     0x70595880f0b0
    70595880f018:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f01f:	00 
    70595880f020:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    70595880f027:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f02e:	00 
    70595880f02f:	c7 87 bc 00 00 00 b4 	mov    DWORD PTR [rdi+0xbc],0x100b4
    70595880f036:	00 01 00 
    70595880f039:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880f040:	00 00 00 
    70595880f043:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    70595880f04a:	00 00 00 
    70595880f04d:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880f054:	63 00 00 
    70595880f057:	ba b4 00 01 00       	mov    edx,0x100b4
    70595880f05c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880f062:	ff d0                	call   rax
    70595880f064:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f06b:	00 
    70595880f06c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f072:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f078:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f07e:	be 0b 00 00 00       	mov    esi,0xb
    70595880f083:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f088:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f08f:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f096:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f09d:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f0a4:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f0ab:	e9 ee 12 00 00       	jmp    0x70595881039e
    70595880f0b0:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880f0b7:	00 
    70595880f0b8:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    70595880f0bf:	c1 e9 0c             	shr    ecx,0xc
    70595880f0c2:	89 c9                	mov    ecx,ecx
    70595880f0c4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880f0c8:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    70595880f0cf:	00 
    70595880f0d0:	48 83 f8 00          	cmp    rax,0x0
    70595880f0d4:	74 20                	je     0x70595880f0f6
    70595880f0d6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    70595880f0dd:	00 
    70595880f0de:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    70595880f0e5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880f0eb:	89 c9                	mov    ecx,ecx
    70595880f0ed:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    70595880f0f4:	eb 59                	jmp    0x70595880f14f
    70595880f0f6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f0fd:	00 
    70595880f0fe:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    70595880f105:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880f10c:	00 
    70595880f10d:	c7 80 bc 00 00 00 b4 	mov    DWORD PTR [rax+0xbc],0x100b4
    70595880f114:	00 01 00 
    70595880f117:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880f11e:	00 00 00 
    70595880f121:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    70595880f128:	00 00 00 
    70595880f12b:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880f132:	63 00 00 
    70595880f135:	ba 02 00 00 00       	mov    edx,0x2
    70595880f13a:	ff d0                	call   rax
    70595880f13c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f143:	00 
    70595880f144:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f14b:	75 14                	jne    0x70595880f161
    70595880f14d:	eb 5e                	jmp    0x70595880f1ad
    70595880f14f:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    70595880f156:	00 
    70595880f157:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595880f15a:	75 53                	jne    0x70595880f1af
    70595880f15c:	e9 93 00 00 00       	jmp    0x70595880f1f4
    70595880f161:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f168:	00 
    70595880f169:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f16f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f175:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f17b:	be 0b 00 00 00       	mov    esi,0xb
    70595880f180:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f185:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f18c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f193:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f19a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f1a1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f1a8:	e9 f1 11 00 00       	jmp    0x70595881039e
    70595880f1ad:	eb a0                	jmp    0x70595880f14f
    70595880f1af:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f1b6:	00 
    70595880f1b7:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    70595880f1be:	00 01 00 
    70595880f1c1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880f1c8:	00 00 00 
    70595880f1cb:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    70595880f1d2:	00 00 00 
    70595880f1d5:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880f1dc:	63 00 00 
    70595880f1df:	ff d0                	call   rax
    70595880f1e1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f1e8:	00 
    70595880f1e9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f1f0:	75 04                	jne    0x70595880f1f6
    70595880f1f2:	eb 4e                	jmp    0x70595880f242
    70595880f1f4:	eb 4e                	jmp    0x70595880f244
    70595880f1f6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f1fd:	00 
    70595880f1fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f204:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f20a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f210:	be 0b 00 00 00       	mov    esi,0xb
    70595880f215:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f21a:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f221:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f228:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f22f:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f236:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f23d:	e9 5c 11 00 00       	jmp    0x70595881039e
    70595880f242:	eb b0                	jmp    0x70595880f1f4
    70595880f244:	eb 00                	jmp    0x70595880f246
    70595880f246:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f24d:	00 
    70595880f24e:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    70595880f251:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    70595880f258:	83 e0 03             	and    eax,0x3
    70595880f25b:	83 f8 00             	cmp    eax,0x0
    70595880f25e:	0f 84 97 00 00 00    	je     0x70595880f2fb
    70595880f264:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f26b:	00 
    70595880f26c:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    70595880f273:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f27a:	00 
    70595880f27b:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    70595880f282:	00 01 00 
    70595880f285:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880f28c:	00 00 00 
    70595880f28f:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    70595880f296:	00 00 00 
    70595880f299:	31 c0                	xor    eax,eax
    70595880f29b:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880f2a2:	63 00 00 
    70595880f2a5:	ba b6 00 01 00       	mov    edx,0x100b6
    70595880f2aa:	45 31 c0             	xor    r8d,r8d
    70595880f2ad:	ff d0                	call   rax
    70595880f2af:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f2b6:	00 
    70595880f2b7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f2bd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f2c3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f2c9:	be 0c 00 00 00       	mov    esi,0xc
    70595880f2ce:	b9 04 00 00 00       	mov    ecx,0x4
    70595880f2d3:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f2da:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f2e1:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f2e8:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f2ef:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f2f6:	e9 a3 10 00 00       	jmp    0x70595881039e
    70595880f2fb:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880f302:	00 
    70595880f303:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    70595880f30a:	c1 e9 0c             	shr    ecx,0xc
    70595880f30d:	89 c9                	mov    ecx,ecx
    70595880f30f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880f313:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    70595880f31a:	00 
    70595880f31b:	48 83 f8 00          	cmp    rax,0x0
    70595880f31f:	74 23                	je     0x70595880f344
    70595880f321:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    70595880f328:	00 
    70595880f329:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    70595880f330:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880f336:	89 c9                	mov    ecx,ecx
    70595880f338:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880f33b:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    70595880f342:	eb 5d                	jmp    0x70595880f3a1
    70595880f344:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f34b:	00 
    70595880f34c:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    70595880f353:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880f35a:	00 
    70595880f35b:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    70595880f362:	00 01 00 
    70595880f365:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880f36c:	00 00 00 
    70595880f36f:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    70595880f376:	00 00 00 
    70595880f379:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880f380:	63 00 00 
    70595880f383:	ff d0                	call   rax
    70595880f385:	89 c1                	mov    ecx,eax
    70595880f387:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f38e:	00 
    70595880f38f:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    70595880f396:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f39d:	75 2e                	jne    0x70595880f3cd
    70595880f39f:	eb 78                	jmp    0x70595880f419
    70595880f3a1:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    70595880f3a8:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    70595880f3af:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    70595880f3b6:	83 c0 04             	add    eax,0x4
    70595880f3b9:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    70595880f3c0:	83 e0 03             	and    eax,0x3
    70595880f3c3:	83 f8 00             	cmp    eax,0x0
    70595880f3c6:	75 64                	jne    0x70595880f42c
    70595880f3c8:	e9 f6 00 00 00       	jmp    0x70595880f4c3
    70595880f3cd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f3d4:	00 
    70595880f3d5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f3db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f3e1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f3e7:	be 0c 00 00 00       	mov    esi,0xc
    70595880f3ec:	b9 04 00 00 00       	mov    ecx,0x4
    70595880f3f1:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f3f8:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f3ff:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f406:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f40d:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f414:	e9 85 0f 00 00       	jmp    0x70595881039e
    70595880f419:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    70595880f420:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    70595880f427:	e9 75 ff ff ff       	jmp    0x70595880f3a1
    70595880f42c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f433:	00 
    70595880f434:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880f43b:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f442:	00 
    70595880f443:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    70595880f44a:	00 01 00 
    70595880f44d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880f454:	00 00 00 
    70595880f457:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    70595880f45e:	00 00 00 
    70595880f461:	31 c0                	xor    eax,eax
    70595880f463:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880f46a:	63 00 00 
    70595880f46d:	ba b6 00 01 00       	mov    edx,0x100b6
    70595880f472:	45 31 c0             	xor    r8d,r8d
    70595880f475:	ff d0                	call   rax
    70595880f477:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f47e:	00 
    70595880f47f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f485:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f48b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f491:	be 0c 00 00 00       	mov    esi,0xc
    70595880f496:	b9 04 00 00 00       	mov    ecx,0x4
    70595880f49b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f4a2:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f4a9:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f4b0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f4b7:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f4be:	e9 db 0e 00 00       	jmp    0x70595881039e
    70595880f4c3:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880f4ca:	00 
    70595880f4cb:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880f4d2:	c1 e9 0c             	shr    ecx,0xc
    70595880f4d5:	89 c9                	mov    ecx,ecx
    70595880f4d7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880f4db:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    70595880f4e2:	00 
    70595880f4e3:	48 83 f8 00          	cmp    rax,0x0
    70595880f4e7:	74 23                	je     0x70595880f50c
    70595880f4e9:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880f4f0:	00 
    70595880f4f1:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880f4f8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880f4fe:	89 c9                	mov    ecx,ecx
    70595880f500:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880f503:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    70595880f50a:	eb 60                	jmp    0x70595880f56c
    70595880f50c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f513:	00 
    70595880f514:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    70595880f51b:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880f522:	00 
    70595880f523:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    70595880f52a:	00 01 00 
    70595880f52d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880f534:	00 00 00 
    70595880f537:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    70595880f53e:	00 00 00 
    70595880f541:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880f548:	63 00 00 
    70595880f54b:	ff d0                	call   rax
    70595880f54d:	89 c1                	mov    ecx,eax
    70595880f54f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f556:	00 
    70595880f557:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    70595880f55e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f565:	75 41                	jne    0x70595880f5a8
    70595880f567:	e9 88 00 00 00       	jmp    0x70595880f5f4
    70595880f56c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f573:	00 
    70595880f574:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    70595880f57b:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    70595880f582:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    70595880f589:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    70595880f590:	83 c1 04             	add    ecx,0x4
    70595880f593:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    70595880f59a:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    70595880f59d:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    70595880f5a3:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880f5a6:	eb 5f                	jmp    0x70595880f607
    70595880f5a8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f5af:	00 
    70595880f5b0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f5b6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f5bc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f5c2:	be 0c 00 00 00       	mov    esi,0xc
    70595880f5c7:	b9 04 00 00 00       	mov    ecx,0x4
    70595880f5cc:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f5d3:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f5da:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f5e1:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f5e8:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f5ef:	e9 aa 0d 00 00       	jmp    0x70595881039e
    70595880f5f4:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    70595880f5fb:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    70595880f602:	e9 65 ff ff ff       	jmp    0x70595880f56c
    70595880f607:	eb 00                	jmp    0x70595880f609
    70595880f609:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f610:	00 
    70595880f611:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    70595880f617:	eb 00                	jmp    0x70595880f619
    70595880f619:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    70595880f620:	83 e0 03             	and    eax,0x3
    70595880f623:	83 f8 00             	cmp    eax,0x0
    70595880f626:	0f 84 97 00 00 00    	je     0x70595880f6c3
    70595880f62c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f633:	00 
    70595880f634:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880f63b:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f642:	00 
    70595880f643:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880f64a:	00 01 00 
    70595880f64d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880f654:	00 00 00 
    70595880f657:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880f65e:	00 00 00 
    70595880f661:	31 c0                	xor    eax,eax
    70595880f663:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880f66a:	63 00 00 
    70595880f66d:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880f672:	45 31 c0             	xor    r8d,r8d
    70595880f675:	ff d0                	call   rax
    70595880f677:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f67e:	00 
    70595880f67f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f685:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f68b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f691:	be 0e 00 00 00       	mov    esi,0xe
    70595880f696:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f69b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f6a2:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f6a9:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f6b0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f6b7:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f6be:	e9 db 0c 00 00       	jmp    0x70595881039e
    70595880f6c3:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880f6ca:	00 
    70595880f6cb:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880f6d2:	c1 e9 0c             	shr    ecx,0xc
    70595880f6d5:	89 c9                	mov    ecx,ecx
    70595880f6d7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880f6db:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    70595880f6e2:	00 
    70595880f6e3:	48 83 f8 00          	cmp    rax,0x0
    70595880f6e7:	74 23                	je     0x70595880f70c
    70595880f6e9:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    70595880f6f0:	00 
    70595880f6f1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    70595880f6f8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880f6fe:	89 c9                	mov    ecx,ecx
    70595880f700:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880f703:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    70595880f70a:	eb 5d                	jmp    0x70595880f769
    70595880f70c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f713:	00 
    70595880f714:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    70595880f71b:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880f722:	00 
    70595880f723:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880f72a:	00 01 00 
    70595880f72d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880f734:	00 00 00 
    70595880f737:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880f73e:	00 00 00 
    70595880f741:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880f748:	63 00 00 
    70595880f74b:	ff d0                	call   rax
    70595880f74d:	89 c1                	mov    ecx,eax
    70595880f74f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f756:	00 
    70595880f757:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    70595880f75e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f765:	75 32                	jne    0x70595880f799
    70595880f767:	eb 7c                	jmp    0x70595880f7e5
    70595880f769:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    70595880f770:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880f777:	00 
    70595880f778:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    70595880f77f:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    70595880f782:	83 c0 04             	add    eax,0x4
    70595880f785:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    70595880f78c:	83 e0 03             	and    eax,0x3
    70595880f78f:	83 f8 00             	cmp    eax,0x0
    70595880f792:	75 64                	jne    0x70595880f7f8
    70595880f794:	e9 f6 00 00 00       	jmp    0x70595880f88f
    70595880f799:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f7a0:	00 
    70595880f7a1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f7a7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f7ad:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f7b3:	be 0e 00 00 00       	mov    esi,0xe
    70595880f7b8:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f7bd:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f7c4:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f7cb:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f7d2:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f7d9:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f7e0:	e9 b9 0b 00 00       	jmp    0x70595881039e
    70595880f7e5:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    70595880f7ec:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    70595880f7f3:	e9 71 ff ff ff       	jmp    0x70595880f769
    70595880f7f8:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f7ff:	00 
    70595880f800:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880f807:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f80e:	00 
    70595880f80f:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880f816:	00 01 00 
    70595880f819:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880f820:	00 00 00 
    70595880f823:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880f82a:	00 00 00 
    70595880f82d:	31 c0                	xor    eax,eax
    70595880f82f:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880f836:	63 00 00 
    70595880f839:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880f83e:	45 31 c0             	xor    r8d,r8d
    70595880f841:	ff d0                	call   rax
    70595880f843:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f84a:	00 
    70595880f84b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f851:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f857:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f85d:	be 0e 00 00 00       	mov    esi,0xe
    70595880f862:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f867:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f86e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f875:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f87c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f883:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f88a:	e9 0f 0b 00 00       	jmp    0x70595881039e
    70595880f88f:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880f896:	00 
    70595880f897:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880f89e:	c1 e9 0c             	shr    ecx,0xc
    70595880f8a1:	89 c9                	mov    ecx,ecx
    70595880f8a3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880f8a7:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    70595880f8ae:	00 
    70595880f8af:	48 83 f8 00          	cmp    rax,0x0
    70595880f8b3:	74 23                	je     0x70595880f8d8
    70595880f8b5:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880f8bc:	00 
    70595880f8bd:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880f8c4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880f8ca:	89 c9                	mov    ecx,ecx
    70595880f8cc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880f8cf:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    70595880f8d6:	eb 5d                	jmp    0x70595880f935
    70595880f8d8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f8df:	00 
    70595880f8e0:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    70595880f8e7:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880f8ee:	00 
    70595880f8ef:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880f8f6:	00 01 00 
    70595880f8f9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880f900:	00 00 00 
    70595880f903:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880f90a:	00 00 00 
    70595880f90d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880f914:	63 00 00 
    70595880f917:	ff d0                	call   rax
    70595880f919:	89 c1                	mov    ecx,eax
    70595880f91b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f922:	00 
    70595880f923:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    70595880f92a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880f931:	75 32                	jne    0x70595880f965
    70595880f933:	eb 7c                	jmp    0x70595880f9b1
    70595880f935:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    70595880f93c:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880f943:	00 
    70595880f944:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    70595880f94b:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    70595880f94e:	83 c0 04             	add    eax,0x4
    70595880f951:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    70595880f958:	83 e0 03             	and    eax,0x3
    70595880f95b:	83 f8 00             	cmp    eax,0x0
    70595880f95e:	75 64                	jne    0x70595880f9c4
    70595880f960:	e9 f6 00 00 00       	jmp    0x70595880fa5b
    70595880f965:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880f96c:	00 
    70595880f96d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880f973:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880f979:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880f97f:	be 0e 00 00 00       	mov    esi,0xe
    70595880f984:	b9 02 00 00 00       	mov    ecx,0x2
    70595880f989:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880f990:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880f997:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880f99e:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880f9a5:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880f9ac:	e9 ed 09 00 00       	jmp    0x70595881039e
    70595880f9b1:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    70595880f9b8:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    70595880f9bf:	e9 71 ff ff ff       	jmp    0x70595880f935
    70595880f9c4:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880f9cb:	00 
    70595880f9cc:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880f9d3:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880f9da:	00 
    70595880f9db:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880f9e2:	00 01 00 
    70595880f9e5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880f9ec:	00 00 00 
    70595880f9ef:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880f9f6:	00 00 00 
    70595880f9f9:	31 c0                	xor    eax,eax
    70595880f9fb:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880fa02:	63 00 00 
    70595880fa05:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880fa0a:	45 31 c0             	xor    r8d,r8d
    70595880fa0d:	ff d0                	call   rax
    70595880fa0f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fa16:	00 
    70595880fa17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fa1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fa23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fa29:	be 0e 00 00 00       	mov    esi,0xe
    70595880fa2e:	b9 02 00 00 00       	mov    ecx,0x2
    70595880fa33:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880fa3a:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fa41:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fa48:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fa4f:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880fa56:	e9 43 09 00 00       	jmp    0x70595881039e
    70595880fa5b:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880fa62:	00 
    70595880fa63:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880fa6a:	c1 e9 0c             	shr    ecx,0xc
    70595880fa6d:	89 c9                	mov    ecx,ecx
    70595880fa6f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880fa73:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    70595880fa7a:	00 
    70595880fa7b:	48 83 f8 00          	cmp    rax,0x0
    70595880fa7f:	74 23                	je     0x70595880faa4
    70595880fa81:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    70595880fa88:	00 
    70595880fa89:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880fa90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880fa96:	89 c9                	mov    ecx,ecx
    70595880fa98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880fa9b:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    70595880faa2:	eb 5d                	jmp    0x70595880fb01
    70595880faa4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880faab:	00 
    70595880faac:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    70595880fab3:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880faba:	00 
    70595880fabb:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880fac2:	00 01 00 
    70595880fac5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880facc:	00 00 00 
    70595880facf:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880fad6:	00 00 00 
    70595880fad9:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880fae0:	63 00 00 
    70595880fae3:	ff d0                	call   rax
    70595880fae5:	89 c1                	mov    ecx,eax
    70595880fae7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880faee:	00 
    70595880faef:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    70595880faf6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880fafd:	75 32                	jne    0x70595880fb31
    70595880faff:	eb 7c                	jmp    0x70595880fb7d
    70595880fb01:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    70595880fb08:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880fb0f:	00 
    70595880fb10:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    70595880fb17:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    70595880fb1a:	83 c0 04             	add    eax,0x4
    70595880fb1d:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    70595880fb24:	83 e0 03             	and    eax,0x3
    70595880fb27:	83 f8 00             	cmp    eax,0x0
    70595880fb2a:	75 64                	jne    0x70595880fb90
    70595880fb2c:	e9 f6 00 00 00       	jmp    0x70595880fc27
    70595880fb31:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fb38:	00 
    70595880fb39:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fb3f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fb45:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fb4b:	be 0e 00 00 00       	mov    esi,0xe
    70595880fb50:	b9 02 00 00 00       	mov    ecx,0x2
    70595880fb55:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880fb5c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fb63:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fb6a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fb71:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880fb78:	e9 21 08 00 00       	jmp    0x70595881039e
    70595880fb7d:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    70595880fb84:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    70595880fb8b:	e9 71 ff ff ff       	jmp    0x70595880fb01
    70595880fb90:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880fb97:	00 
    70595880fb98:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    70595880fb9f:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880fba6:	00 
    70595880fba7:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880fbae:	00 01 00 
    70595880fbb1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880fbb8:	00 00 00 
    70595880fbbb:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880fbc2:	00 00 00 
    70595880fbc5:	31 c0                	xor    eax,eax
    70595880fbc7:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880fbce:	63 00 00 
    70595880fbd1:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880fbd6:	45 31 c0             	xor    r8d,r8d
    70595880fbd9:	ff d0                	call   rax
    70595880fbdb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fbe2:	00 
    70595880fbe3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fbe9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fbef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fbf5:	be 0e 00 00 00       	mov    esi,0xe
    70595880fbfa:	b9 02 00 00 00       	mov    ecx,0x2
    70595880fbff:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880fc06:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fc0d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fc14:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fc1b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880fc22:	e9 77 07 00 00       	jmp    0x70595881039e
    70595880fc27:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880fc2e:	00 
    70595880fc2f:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    70595880fc36:	c1 e9 0c             	shr    ecx,0xc
    70595880fc39:	89 c9                	mov    ecx,ecx
    70595880fc3b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880fc3f:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    70595880fc46:	00 
    70595880fc47:	48 83 f8 00          	cmp    rax,0x0
    70595880fc4b:	74 20                	je     0x70595880fc6d
    70595880fc4d:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    70595880fc54:	00 
    70595880fc55:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    70595880fc5c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880fc62:	89 c9                	mov    ecx,ecx
    70595880fc64:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880fc67:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    70595880fc6b:	eb 5a                	jmp    0x70595880fcc7
    70595880fc6d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fc74:	00 
    70595880fc75:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    70595880fc7c:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880fc83:	00 
    70595880fc84:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880fc8b:	00 01 00 
    70595880fc8e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880fc95:	00 00 00 
    70595880fc98:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880fc9f:	00 00 00 
    70595880fca2:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880fca9:	63 00 00 
    70595880fcac:	ff d0                	call   rax
    70595880fcae:	89 c1                	mov    ecx,eax
    70595880fcb0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fcb7:	00 
    70595880fcb8:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    70595880fcbc:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880fcc3:	75 2c                	jne    0x70595880fcf1
    70595880fcc5:	eb 76                	jmp    0x70595880fd3d
    70595880fcc7:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    70595880fcce:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880fcd5:	00 
    70595880fcd6:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    70595880fcda:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    70595880fcdd:	83 c0 04             	add    eax,0x4
    70595880fce0:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    70595880fce4:	83 e0 03             	and    eax,0x3
    70595880fce7:	83 f8 00             	cmp    eax,0x0
    70595880fcea:	75 5b                	jne    0x70595880fd47
    70595880fcec:	e9 ea 00 00 00       	jmp    0x70595880fddb
    70595880fcf1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fcf8:	00 
    70595880fcf9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fcff:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fd05:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fd0b:	be 0e 00 00 00       	mov    esi,0xe
    70595880fd10:	b9 02 00 00 00       	mov    ecx,0x2
    70595880fd15:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880fd1c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fd23:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fd2a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fd31:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880fd38:	e9 61 06 00 00       	jmp    0x70595881039e
    70595880fd3d:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    70595880fd41:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    70595880fd45:	eb 80                	jmp    0x70595880fcc7
    70595880fd47:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880fd4e:	00 
    70595880fd4f:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880fd53:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880fd5a:	00 
    70595880fd5b:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880fd62:	00 01 00 
    70595880fd65:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880fd6c:	00 00 00 
    70595880fd6f:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880fd76:	00 00 00 
    70595880fd79:	31 c0                	xor    eax,eax
    70595880fd7b:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880fd82:	63 00 00 
    70595880fd85:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880fd8a:	45 31 c0             	xor    r8d,r8d
    70595880fd8d:	ff d0                	call   rax
    70595880fd8f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fd96:	00 
    70595880fd97:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fd9d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fda3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fda9:	be 0e 00 00 00       	mov    esi,0xe
    70595880fdae:	b9 02 00 00 00       	mov    ecx,0x2
    70595880fdb3:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880fdba:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fdc1:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fdc8:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fdcf:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880fdd6:	e9 c3 05 00 00       	jmp    0x70595881039e
    70595880fddb:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880fde2:	00 
    70595880fde3:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880fde7:	c1 e9 0c             	shr    ecx,0xc
    70595880fdea:	89 c9                	mov    ecx,ecx
    70595880fdec:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880fdf0:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    70595880fdf5:	48 83 f8 00          	cmp    rax,0x0
    70595880fdf9:	74 1a                	je     0x70595880fe15
    70595880fdfb:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    70595880fe00:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880fe04:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880fe0a:	89 c9                	mov    ecx,ecx
    70595880fe0c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880fe0f:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880fe13:	eb 57                	jmp    0x70595880fe6c
    70595880fe15:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fe1c:	00 
    70595880fe1d:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    70595880fe21:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880fe28:	00 
    70595880fe29:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880fe30:	00 01 00 
    70595880fe33:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880fe3a:	00 00 00 
    70595880fe3d:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880fe44:	00 00 00 
    70595880fe47:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880fe4e:	63 00 00 
    70595880fe51:	ff d0                	call   rax
    70595880fe53:	89 c1                	mov    ecx,eax
    70595880fe55:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fe5c:	00 
    70595880fe5d:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    70595880fe61:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880fe68:	75 29                	jne    0x70595880fe93
    70595880fe6a:	eb 73                	jmp    0x70595880fedf
    70595880fe6c:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    70595880fe70:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    70595880fe77:	00 
    70595880fe78:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    70595880fe7c:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    70595880fe7f:	83 c0 04             	add    eax,0x4
    70595880fe82:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880fe86:	83 e0 03             	and    eax,0x3
    70595880fe89:	83 f8 00             	cmp    eax,0x0
    70595880fe8c:	75 5b                	jne    0x70595880fee9
    70595880fe8e:	e9 ea 00 00 00       	jmp    0x70595880ff7d
    70595880fe93:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fe9a:	00 
    70595880fe9b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880fea1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880fea7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880fead:	be 0e 00 00 00       	mov    esi,0xe
    70595880feb2:	b9 02 00 00 00       	mov    ecx,0x2
    70595880feb7:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880febe:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880fec5:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880fecc:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880fed3:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880feda:	e9 bf 04 00 00       	jmp    0x70595881039e
    70595880fedf:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    70595880fee3:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880fee7:	eb 83                	jmp    0x70595880fe6c
    70595880fee9:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    70595880fef0:	00 
    70595880fef1:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880fef5:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595880fefc:	00 
    70595880fefd:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    70595880ff04:	00 01 00 
    70595880ff07:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ff0e:	00 00 00 
    70595880ff11:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    70595880ff18:	00 00 00 
    70595880ff1b:	31 c0                	xor    eax,eax
    70595880ff1d:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ff24:	63 00 00 
    70595880ff27:	ba bc 00 01 00       	mov    edx,0x100bc
    70595880ff2c:	45 31 c0             	xor    r8d,r8d
    70595880ff2f:	ff d0                	call   rax
    70595880ff31:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ff38:	00 
    70595880ff39:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ff3f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ff45:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ff4b:	be 0e 00 00 00       	mov    esi,0xe
    70595880ff50:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ff55:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595880ff5c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    70595880ff63:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595880ff6a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595880ff71:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595880ff78:	e9 21 04 00 00       	jmp    0x70595881039e
    70595880ff7d:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    70595880ff84:	00 
    70595880ff85:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880ff89:	c1 e9 0c             	shr    ecx,0xc
    70595880ff8c:	89 c9                	mov    ecx,ecx
    70595880ff8e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880ff92:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    70595880ff97:	48 83 f8 00          	cmp    rax,0x0
    70595880ff9b:	74 1a                	je     0x70595880ffb7
    70595880ff9d:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    70595880ffa2:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880ffa6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880ffac:	89 c9                	mov    ecx,ecx
    70595880ffae:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880ffb1:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    70595880ffb5:	eb 57                	jmp    0x70595881000e
    70595880ffb7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880ffbe:	00 
    70595880ffbf:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    70595880ffc3:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595880ffca:	00 
    70595880ffcb:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    70595880ffd2:	00 01 00 
    70595880ffd5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880ffdc:	00 00 00 
    70595880ffdf:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    70595880ffe6:	00 00 00 
    70595880ffe9:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880fff0:	63 00 00 
    70595880fff3:	ff d0                	call   rax
    70595880fff5:	89 c1                	mov    ecx,eax
    70595880fff7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595880fffe:	00 
    70595880ffff:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    705958810003:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595881000a:	75 29                	jne    0x705958810035
    70595881000c:	eb 73                	jmp    0x705958810081
    70595881000e:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    705958810012:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    705958810019:	00 
    70595881001a:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    70595881001e:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    705958810021:	83 c0 04             	add    eax,0x4
    705958810024:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    705958810028:	83 e0 03             	and    eax,0x3
    70595881002b:	83 f8 00             	cmp    eax,0x0
    70595881002e:	75 5b                	jne    0x70595881008b
    705958810030:	e9 ea 00 00 00       	jmp    0x70595881011f
    705958810035:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    70595881003c:	00 
    70595881003d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958810043:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958810049:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595881004f:	be 0e 00 00 00       	mov    esi,0xe
    705958810054:	b9 02 00 00 00       	mov    ecx,0x2
    705958810059:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    705958810060:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    705958810067:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595881006e:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    705958810075:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595881007c:	e9 1d 03 00 00       	jmp    0x70595881039e
    705958810081:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    705958810085:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958810089:	eb 83                	jmp    0x70595881000e
    70595881008b:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    705958810092:	00 
    705958810093:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958810097:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    70595881009e:	00 
    70595881009f:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    7059588100a6:	00 01 00 
    7059588100a9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588100b0:	00 00 00 
    7059588100b3:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    7059588100ba:	00 00 00 
    7059588100bd:	31 c0                	xor    eax,eax
    7059588100bf:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588100c6:	63 00 00 
    7059588100c9:	ba bc 00 01 00       	mov    edx,0x100bc
    7059588100ce:	45 31 c0             	xor    r8d,r8d
    7059588100d1:	ff d0                	call   rax
    7059588100d3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    7059588100da:	00 
    7059588100db:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588100e1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588100e7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588100ed:	be 0e 00 00 00       	mov    esi,0xe
    7059588100f2:	b9 02 00 00 00       	mov    ecx,0x2
    7059588100f7:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    7059588100fe:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    705958810105:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595881010c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    705958810113:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595881011a:	e9 7f 02 00 00       	jmp    0x70595881039e
    70595881011f:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    705958810126:	00 
    705958810127:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595881012b:	c1 e9 0c             	shr    ecx,0xc
    70595881012e:	89 c9                	mov    ecx,ecx
    705958810130:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958810134:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    705958810139:	48 83 f8 00          	cmp    rax,0x0
    70595881013d:	74 1a                	je     0x705958810159
    70595881013f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958810144:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958810148:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595881014e:	89 c9                	mov    ecx,ecx
    705958810150:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958810153:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958810157:	eb 57                	jmp    0x7059588101b0
    705958810159:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    705958810160:	00 
    705958810161:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    705958810165:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    70595881016c:	00 
    70595881016d:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    705958810174:	00 01 00 
    705958810177:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595881017e:	00 00 00 
    705958810181:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    705958810188:	00 00 00 
    70595881018b:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958810192:	63 00 00 
    705958810195:	ff d0                	call   rax
    705958810197:	89 c1                	mov    ecx,eax
    705958810199:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    7059588101a0:	00 
    7059588101a1:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    7059588101a5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588101ac:	75 1d                	jne    0x7059588101cb
    7059588101ae:	eb 67                	jmp    0x705958810217
    7059588101b0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    7059588101b7:	00 
    7059588101b8:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    7059588101bc:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    7059588101c0:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    7059588101c3:	83 c1 04             	add    ecx,0x4
    7059588101c6:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    7059588101c9:	eb 56                	jmp    0x705958810221
    7059588101cb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    7059588101d2:	00 
    7059588101d3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588101d9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588101df:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588101e5:	be 0e 00 00 00       	mov    esi,0xe
    7059588101ea:	b9 02 00 00 00       	mov    ecx,0x2
    7059588101ef:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    7059588101f6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    7059588101fd:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    705958810204:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    70595881020b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    705958810212:	e9 87 01 00 00       	jmp    0x70595881039e
    705958810217:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    70595881021b:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    70595881021f:	eb 8f                	jmp    0x7059588101b0
    705958810221:	eb 00                	jmp    0x705958810223
    705958810223:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    70595881022a:	83 e0 01             	and    eax,0x1
    70595881022d:	83 f8 00             	cmp    eax,0x0
    705958810230:	75 3d                	jne    0x70595881026f
    705958810232:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    705958810239:	be 0f 00 00 00       	mov    esi,0xf
    70595881023e:	b9 02 00 00 00       	mov    ecx,0x2
    705958810243:	b0 01                	mov    al,0x1
    705958810245:	89 d7                	mov    edi,edx
    705958810247:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    70595881024e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    705958810255:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    70595881025c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    705958810263:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    70595881026a:	e9 2f 01 00 00       	jmp    0x70595881039e
    70595881026f:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    705958810276:	00 
    705958810277:	48 8b 94 24 70 01 00 	mov    rdx,QWORD PTR [rsp+0x170]
    70595881027e:	00 
    70595881027f:	c7 87 bc 00 00 00 be 	mov    DWORD PTR [rdi+0xbc],0x100be
    705958810286:	00 01 00 
    705958810289:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958810290:	00 00 00 
    705958810293:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    70595881029a:	00 00 00 
    70595881029d:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    7059588102a4:	63 00 00 
    7059588102a7:	be 2a 00 00 00       	mov    esi,0x2a
    7059588102ac:	ff d0                	call   rax
    7059588102ae:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    7059588102b5:	00 
    7059588102b6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588102bc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588102c2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588102c8:	be 0f 00 00 00       	mov    esi,0xf
    7059588102cd:	b9 02 00 00 00       	mov    ecx,0x2
    7059588102d2:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    7059588102d9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    7059588102e0:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    7059588102e7:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    7059588102ee:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    7059588102f5:	e9 a4 00 00 00       	jmp    0x70595881039e
    7059588102fa:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    705958810301:	00 
    705958810302:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958810309:	e9 82 01 00 00       	jmp    0x705958810490
    70595881030e:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    705958810315:	00 
    705958810316:	48 89 c1             	mov    rcx,rax
    705958810319:	48 81 c1 20 04 08 00 	add    rcx,0x80420
    705958810320:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    705958810325:	81 b8 20 04 08 00 84 	cmp    DWORD PTR [rax+0x80420],0x10084
    70595881032c:	00 01 00 
    70595881032f:	74 32                	je     0x705958810363
    705958810331:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    705958810338:	00 
    705958810339:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    705958810340:	00 01 00 
    705958810343:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595881034a:	00 00 00 
    70595881034d:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    705958810354:	00 00 00 
    705958810357:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595881035e:	e9 2d 01 00 00       	jmp    0x705958810490
    705958810363:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    70595881036a:	00 
    70595881036b:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    705958810372:	00 
    705958810373:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958810378:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    70595881037f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    705958810386:	84 00 01 00 
    70595881038a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958810391:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958810395:	48 81 c4 98 01 00 00 	add    rsp,0x198
    70595881039c:	ff e0                	jmp    rax
    70595881039e:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    7059588103a5:	00 
    7059588103a6:	8b 94 24 48 01 00 00 	mov    edx,DWORD PTR [rsp+0x148]
    7059588103ad:	8b 84 24 4c 01 00 00 	mov    eax,DWORD PTR [rsp+0x14c]
    7059588103b4:	8b b4 24 50 01 00 00 	mov    esi,DWORD PTR [rsp+0x150]
    7059588103bb:	8b bc 24 54 01 00 00 	mov    edi,DWORD PTR [rsp+0x154]
    7059588103c2:	8a 9c 24 5b 01 00 00 	mov    bl,BYTE PTR [rsp+0x15b]
    7059588103c9:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    7059588103cd:	89 c3                	mov    ebx,eax
    7059588103cf:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    7059588103d3:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    7059588103d7:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    7059588103db:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    7059588103df:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    7059588103e5:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    7059588103e9:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588103ef:	73 2d                	jae    0x70595881041e
    7059588103f1:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    7059588103f8:	00 
    7059588103f9:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    7059588103fd:	89 d1                	mov    ecx,edx
    7059588103ff:	c1 e9 01             	shr    ecx,0x1
    705958810402:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958810408:	89 c9                	mov    ecx,ecx
    70595881040a:	48 c1 e1 04          	shl    rcx,0x4
    70595881040e:	48 89 c6             	mov    rsi,rax
    705958810411:	48 01 ce             	add    rsi,rcx
    705958810414:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    705958810419:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595881041c:	74 32                	je     0x705958810450
    70595881041e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    705958810425:	00 
    705958810426:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    70595881042a:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595881042e:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    705958810432:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    705958810436:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    70595881043c:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    705958810442:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    705958810448:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595881044e:	eb 40                	jmp    0x705958810490
    705958810450:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    705958810457:	00 
    705958810458:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    70595881045f:	00 
    705958810460:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958810465:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    705958810469:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595881046d:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    705958810474:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595881047b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958810482:	00 
    705958810483:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958810487:	48 81 c4 98 01 00 00 	add    rsp,0x198
    70595881048e:	ff e0                	jmp    rax
    705958810490:	48 81 c4 98 01 00 00 	add    rsp,0x198
    705958810497:	c2 08 00             	ret    0x8
