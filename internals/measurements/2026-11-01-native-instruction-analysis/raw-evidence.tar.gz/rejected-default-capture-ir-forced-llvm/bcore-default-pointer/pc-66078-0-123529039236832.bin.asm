
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66078-0-123529039236832.bin:     file format binary


Disassembly of section .data:

000070595880cee0 <.data>:
    70595880cee0:	48 81 ec e8 00 00 00 	sub    rsp,0xe8
    70595880cee7:	4c 89 b4 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r14
    70595880ceee:	00 
    70595880ceef:	4c 89 ac 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r13
    70595880cef6:	00 
    70595880cef7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880cefe:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    70595880cf05:	00 
    70595880cf06:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880cf0d:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    70595880cf14:	00 
    70595880cf15:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    70595880cf1c:	00 
    70595880cf1d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    70595880cf23:	83 fa 00             	cmp    edx,0x0
    70595880cf26:	0f 94 c0             	sete   al
    70595880cf29:	81 ea 1e 02 01 00    	sub    edx,0x1021e
    70595880cf2f:	83 fa 18             	cmp    edx,0x18
    70595880cf32:	0f 97 c2             	seta   dl
    70595880cf35:	08 d0                	or     al,dl
    70595880cf37:	24 01                	and    al,0x1
    70595880cf39:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880cf3f:	81 fa 20 04 01 00    	cmp    edx,0x10420
    70595880cf45:	0f 94 c1             	sete   cl
    70595880cf48:	81 ea 1e 02 01 00    	sub    edx,0x1021e
    70595880cf4e:	83 fa 18             	cmp    edx,0x18
    70595880cf51:	0f 97 c2             	seta   dl
    70595880cf54:	08 d1                	or     cl,dl
    70595880cf56:	20 c8                	and    al,cl
    70595880cf58:	a8 01                	test   al,0x1
    70595880cf5a:	75 05                	jne    0x70595880cf61
    70595880cf5c:	e9 be 0a 00 00       	jmp    0x70595880da1f
    70595880cf61:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880cf68:	00 
    70595880cf69:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880cf70:	48 89 c8             	mov    rax,rcx
    70595880cf73:	48 05 00 00 10 00    	add    rax,0x100000
    70595880cf79:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    70595880cf80:	00 
    70595880cf81:	8b 81 38 00 10 00    	mov    eax,DWORD PTR [rcx+0x100038]
    70595880cf87:	83 c0 01             	add    eax,0x1
    70595880cf8a:	89 81 38 00 10 00    	mov    DWORD PTR [rcx+0x100038],eax
    70595880cf90:	3d 30 75 00 00       	cmp    eax,0x7530
    70595880cf95:	75 4c                	jne    0x70595880cfe3
    70595880cf97:	48 8b 8c 24 c0 00 00 	mov    rcx,QWORD PTR [rsp+0xc0]
    70595880cf9e:	00 
    70595880cf9f:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    70595880cfa5:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    70595880cfac:	89 c2                	mov    edx,eax
    70595880cfae:	83 c2 01             	add    edx,0x1
    70595880cfb1:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    70595880cfb7:	3d 00 01 00 00       	cmp    eax,0x100
    70595880cfbc:	73 23                	jae    0x70595880cfe1
    70595880cfbe:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    70595880cfc5:	00 
    70595880cfc6:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    70595880cfcd:	89 c9                	mov    ecx,ecx
    70595880cfcf:	48 c1 e1 02          	shl    rcx,0x2
    70595880cfd3:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880cfda:	c7 04 08 0e 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xe
    70595880cfe1:	eb 00                	jmp    0x70595880cfe3
    70595880cfe3:	eb 00                	jmp    0x70595880cfe5
    70595880cfe5:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880cfec:	00 
    70595880cfed:	8b 48 08             	mov    ecx,DWORD PTR [rax+0x8]
    70595880cff0:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    70595880cff7:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    70595880cffa:	eb 00                	jmp    0x70595880cffc
    70595880cffc:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d003:	00 
    70595880d004:	8b 48 0c             	mov    ecx,DWORD PTR [rax+0xc]
    70595880d007:	89 ca                	mov    edx,ecx
    70595880d009:	83 c2 01             	add    edx,0x1
    70595880d00c:	89 94 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],edx
    70595880d013:	89 50 0c             	mov    DWORD PTR [rax+0xc],edx
    70595880d016:	89 ce                	mov    esi,ecx
    70595880d018:	c1 ee 1f             	shr    esi,0x1f
    70595880d01b:	89 d3                	mov    ebx,edx
    70595880d01d:	c1 eb 1f             	shr    ebx,0x1f
    70595880d020:	89 df                	mov    edi,ebx
    70595880d022:	83 f7 00             	xor    edi,0x0
    70595880d025:	31 de                	xor    esi,ebx
    70595880d027:	21 fe                	and    esi,edi
    70595880d029:	83 f1 ff             	xor    ecx,0xffffffff
    70595880d02c:	83 f9 01             	cmp    ecx,0x1
    70595880d02f:	0f 92 c1             	setb   cl
    70595880d032:	80 e1 01             	and    cl,0x1
    70595880d035:	0f b6 c9             	movzx  ecx,cl
    70595880d038:	83 fa 00             	cmp    edx,0x0
    70595880d03b:	0f 94 c3             	sete   bl
    70595880d03e:	80 e3 01             	and    bl,0x1
    70595880d041:	0f b6 fb             	movzx  edi,bl
    70595880d044:	c1 ea 1f             	shr    edx,0x1f
    70595880d047:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    70595880d04d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880d053:	89 f2                	mov    edx,esi
    70595880d055:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    70595880d05b:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    70595880d062:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    70595880d068:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    70595880d06e:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    70595880d074:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880d07a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880d080:	eb 00                	jmp    0x70595880d082
    70595880d082:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d089:	00 
    70595880d08a:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    70595880d091:	8b 38                	mov    edi,DWORD PTR [rax]
    70595880d093:	39 cf                	cmp    edi,ecx
    70595880d095:	0f 96 c2             	setbe  dl
    70595880d098:	80 e2 01             	and    dl,0x1
    70595880d09b:	0f b6 d2             	movzx  edx,dl
    70595880d09e:	89 94 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],edx
    70595880d0a5:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    70595880d0ab:	39 cf                	cmp    edi,ecx
    70595880d0ad:	0f 94 c2             	sete   dl
    70595880d0b0:	80 e2 01             	and    dl,0x1
    70595880d0b3:	0f b6 f2             	movzx  esi,dl
    70595880d0b6:	39 f9                	cmp    ecx,edi
    70595880d0b8:	0f 97 c2             	seta   dl
    70595880d0bb:	80 e2 01             	and    dl,0x1
    70595880d0be:	0f b6 d2             	movzx  edx,dl
    70595880d0c1:	39 f9                	cmp    ecx,edi
    70595880d0c3:	0f 96 c1             	setbe  cl
    70595880d0c6:	80 e1 01             	and    cl,0x1
    70595880d0c9:	0f b6 c9             	movzx  ecx,cl
    70595880d0cc:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    70595880d0d2:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880d0d8:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880d0de:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880d0e4:	eb 00                	jmp    0x70595880d0e6
    70595880d0e6:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d0ed:	00 
    70595880d0ee:	8b 8c 24 b8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb8]
    70595880d0f5:	c1 e1 02             	shl    ecx,0x2
    70595880d0f8:	03 48 24             	add    ecx,DWORD PTR [rax+0x24]
    70595880d0fb:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    70595880d102:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880d105:	eb 00                	jmp    0x70595880d107
    70595880d107:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    70595880d10e:	83 e0 03             	and    eax,0x3
    70595880d111:	83 f8 00             	cmp    eax,0x0
    70595880d114:	0f 84 97 00 00 00    	je     0x70595880d1b1
    70595880d11a:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880d121:	00 
    70595880d122:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    70595880d129:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    70595880d130:	00 
    70595880d131:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10226
    70595880d138:	02 01 00 
    70595880d13b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880d142:	00 00 00 
    70595880d145:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880d14c:	00 00 00 
    70595880d14f:	31 c0                	xor    eax,eax
    70595880d151:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880d158:	63 00 00 
    70595880d15b:	ba 26 02 01 00       	mov    edx,0x10226
    70595880d160:	45 31 c0             	xor    r8d,r8d
    70595880d163:	ff d0                	call   rax
    70595880d165:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d16c:	00 
    70595880d16d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d173:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d179:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d17f:	be 05 00 00 00       	mov    esi,0x5
    70595880d184:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d189:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d190:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d197:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d19e:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d1a5:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d1ac:	e9 d5 08 00 00       	jmp    0x70595880da86
    70595880d1b1:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880d1b8:	00 
    70595880d1b9:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    70595880d1c0:	c1 e9 0c             	shr    ecx,0xc
    70595880d1c3:	89 c9                	mov    ecx,ecx
    70595880d1c5:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880d1c9:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    70595880d1d0:	00 
    70595880d1d1:	48 83 f8 00          	cmp    rax,0x0
    70595880d1d5:	74 23                	je     0x70595880d1fa
    70595880d1d7:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    70595880d1de:	00 
    70595880d1df:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    70595880d1e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880d1ec:	89 c9                	mov    ecx,ecx
    70595880d1ee:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880d1f1:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    70595880d1f8:	eb 5d                	jmp    0x70595880d257
    70595880d1fa:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d201:	00 
    70595880d202:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    70595880d209:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    70595880d210:	00 
    70595880d211:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10226
    70595880d218:	02 01 00 
    70595880d21b:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880d222:	00 00 00 
    70595880d225:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    70595880d22c:	00 00 00 
    70595880d22f:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880d236:	63 00 00 
    70595880d239:	ff d0                	call   rax
    70595880d23b:	89 c1                	mov    ecx,eax
    70595880d23d:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d244:	00 
    70595880d245:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    70595880d24c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880d253:	75 1a                	jne    0x70595880d26f
    70595880d255:	eb 64                	jmp    0x70595880d2bb
    70595880d257:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d25e:	00 
    70595880d25f:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    70595880d266:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    70595880d26a:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    70595880d26d:	eb 5c                	jmp    0x70595880d2cb
    70595880d26f:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d276:	00 
    70595880d277:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d27d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d283:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d289:	be 05 00 00 00       	mov    esi,0x5
    70595880d28e:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d293:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d29a:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d2a1:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d2a8:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d2af:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d2b6:	e9 cb 07 00 00       	jmp    0x70595880da86
    70595880d2bb:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    70595880d2c2:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    70595880d2c9:	eb 8c                	jmp    0x70595880d257
    70595880d2cb:	eb 00                	jmp    0x70595880d2cd
    70595880d2cd:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d2d4:	00 
    70595880d2d5:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    70595880d2d9:	33 48 04             	xor    ecx,DWORD PTR [rax+0x4]
    70595880d2dc:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    70595880d2e0:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    70595880d2e3:	83 f9 00             	cmp    ecx,0x0
    70595880d2e6:	0f 94 c2             	sete   dl
    70595880d2e9:	80 e2 01             	and    dl,0x1
    70595880d2ec:	0f b6 d2             	movzx  edx,dl
    70595880d2ef:	c1 e9 1f             	shr    ecx,0x1f
    70595880d2f2:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880d2f8:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    70595880d2fe:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880d305:	00 00 00 
    70595880d308:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880d30f:	00 00 00 
    70595880d312:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880d319:	00 00 00 
    70595880d31c:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880d323:	00 00 00 
    70595880d326:	eb 00                	jmp    0x70595880d328
    70595880d328:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d32f:	00 
    70595880d330:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    70595880d337:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    70595880d33b:	8b 58 1c             	mov    ebx,DWORD PTR [rax+0x1c]
    70595880d33e:	89 cf                	mov    edi,ecx
    70595880d340:	01 df                	add    edi,ebx
    70595880d342:	89 7c 24 74          	mov    DWORD PTR [rsp+0x74],edi
    70595880d346:	89 78 04             	mov    DWORD PTR [rax+0x4],edi
    70595880d349:	89 ce                	mov    esi,ecx
    70595880d34b:	c1 ee 1f             	shr    esi,0x1f
    70595880d34e:	89 dd                	mov    ebp,ebx
    70595880d350:	c1 ed 1f             	shr    ebp,0x1f
    70595880d353:	41 89 f8             	mov    r8d,edi
    70595880d356:	41 c1 e8 1f          	shr    r8d,0x1f
    70595880d35a:	44 31 c5             	xor    ebp,r8d
    70595880d35d:	44 31 c6             	xor    esi,r8d
    70595880d360:	21 ee                	and    esi,ebp
    70595880d362:	83 f1 ff             	xor    ecx,0xffffffff
    70595880d365:	39 d9                	cmp    ecx,ebx
    70595880d367:	0f 92 c1             	setb   cl
    70595880d36a:	80 e1 01             	and    cl,0x1
    70595880d36d:	0f b6 c9             	movzx  ecx,cl
    70595880d370:	83 ff 00             	cmp    edi,0x0
    70595880d373:	0f 94 c3             	sete   bl
    70595880d376:	80 e3 01             	and    bl,0x1
    70595880d379:	0f b6 db             	movzx  ebx,bl
    70595880d37c:	c1 ef 1f             	shr    edi,0x1f
    70595880d37f:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    70595880d385:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    70595880d38b:	09 f2                	or     edx,esi
    70595880d38d:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    70595880d393:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    70595880d399:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    70595880d39f:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880d3a5:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    70595880d3ab:	eb 00                	jmp    0x70595880d3ad
    70595880d3ad:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    70595880d3b4:	83 f8 00             	cmp    eax,0x0
    70595880d3b7:	75 30                	jne    0x70595880d3e9
    70595880d3b9:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    70595880d3c0:	00 
    70595880d3c1:	c7 81 bc 00 00 00 1e 	mov    DWORD PTR [rcx+0xbc],0x1021e
    70595880d3c8:	02 01 00 
    70595880d3cb:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880d3d1:	83 c0 08             	add    eax,0x8
    70595880d3d4:	89 44 24 70          	mov    DWORD PTR [rsp+0x70],eax
    70595880d3d8:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880d3de:	0f 82 4f 06 00 00    	jb     0x70595880da33
    70595880d3e4:	e9 6b 06 00 00       	jmp    0x70595880da54
    70595880d3e9:	eb 00                	jmp    0x70595880d3eb
    70595880d3eb:	eb 00                	jmp    0x70595880d3ed
    70595880d3ed:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d3f4:	00 
    70595880d3f5:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    70595880d3f8:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    70595880d3fc:	83 e0 03             	and    eax,0x3
    70595880d3ff:	83 f8 00             	cmp    eax,0x0
    70595880d402:	0f 84 94 00 00 00    	je     0x70595880d49c
    70595880d408:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880d40f:	00 
    70595880d410:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    70595880d414:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    70595880d41b:	00 
    70595880d41c:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880d423:	02 01 00 
    70595880d426:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880d42d:	00 00 00 
    70595880d430:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880d437:	00 00 00 
    70595880d43a:	31 c0                	xor    eax,eax
    70595880d43c:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880d443:	63 00 00 
    70595880d446:	ba 2e 02 01 00       	mov    edx,0x1022e
    70595880d44b:	45 31 c0             	xor    r8d,r8d
    70595880d44e:	ff d0                	call   rax
    70595880d450:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d457:	00 
    70595880d458:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d45e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d464:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d46a:	be 09 00 00 00       	mov    esi,0x9
    70595880d46f:	b9 04 00 00 00       	mov    ecx,0x4
    70595880d474:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d47b:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d482:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d489:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d490:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d497:	e9 ea 05 00 00       	jmp    0x70595880da86
    70595880d49c:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880d4a3:	00 
    70595880d4a4:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    70595880d4a8:	c1 e9 0c             	shr    ecx,0xc
    70595880d4ab:	89 c9                	mov    ecx,ecx
    70595880d4ad:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880d4b1:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    70595880d4b6:	48 83 f8 00          	cmp    rax,0x0
    70595880d4ba:	74 1a                	je     0x70595880d4d6
    70595880d4bc:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595880d4c1:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    70595880d4c5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880d4cb:	89 c9                	mov    ecx,ecx
    70595880d4cd:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880d4d0:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880d4d4:	eb 57                	jmp    0x70595880d52d
    70595880d4d6:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d4dd:	00 
    70595880d4de:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    70595880d4e2:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    70595880d4e9:	00 
    70595880d4ea:	c7 80 bc 00 00 00 2e 	mov    DWORD PTR [rax+0xbc],0x1022e
    70595880d4f1:	02 01 00 
    70595880d4f4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880d4fb:	00 00 00 
    70595880d4fe:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    70595880d505:	00 00 00 
    70595880d508:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880d50f:	63 00 00 
    70595880d512:	ff d0                	call   rax
    70595880d514:	89 c1                	mov    ecx,eax
    70595880d516:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d51d:	00 
    70595880d51e:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    70595880d522:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880d529:	75 22                	jne    0x70595880d54d
    70595880d52b:	eb 6c                	jmp    0x70595880d599
    70595880d52d:	8b 44 24 6c          	mov    eax,DWORD PTR [rsp+0x6c]
    70595880d531:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880d535:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    70595880d539:	83 c0 04             	add    eax,0x4
    70595880d53c:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880d540:	83 e0 03             	and    eax,0x3
    70595880d543:	83 f8 00             	cmp    eax,0x0
    70595880d546:	75 5b                	jne    0x70595880d5a3
    70595880d548:	e9 ea 00 00 00       	jmp    0x70595880d637
    70595880d54d:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d554:	00 
    70595880d555:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d55b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d561:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d567:	be 09 00 00 00       	mov    esi,0x9
    70595880d56c:	b9 04 00 00 00       	mov    ecx,0x4
    70595880d571:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d578:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d57f:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d586:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d58d:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d594:	e9 ed 04 00 00       	jmp    0x70595880da86
    70595880d599:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    70595880d59d:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880d5a1:	eb 8a                	jmp    0x70595880d52d
    70595880d5a3:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880d5aa:	00 
    70595880d5ab:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880d5af:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    70595880d5b6:	00 
    70595880d5b7:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1022e
    70595880d5be:	02 01 00 
    70595880d5c1:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880d5c8:	00 00 00 
    70595880d5cb:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    70595880d5d2:	00 00 00 
    70595880d5d5:	31 c0                	xor    eax,eax
    70595880d5d7:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880d5de:	63 00 00 
    70595880d5e1:	ba 2e 02 01 00       	mov    edx,0x1022e
    70595880d5e6:	45 31 c0             	xor    r8d,r8d
    70595880d5e9:	ff d0                	call   rax
    70595880d5eb:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d5f2:	00 
    70595880d5f3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d5f9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d5ff:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d605:	be 09 00 00 00       	mov    esi,0x9
    70595880d60a:	b9 04 00 00 00       	mov    ecx,0x4
    70595880d60f:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d616:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d61d:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d624:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d62b:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d632:	e9 4f 04 00 00       	jmp    0x70595880da86
    70595880d637:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880d63e:	00 
    70595880d63f:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880d643:	c1 e9 0c             	shr    ecx,0xc
    70595880d646:	89 c9                	mov    ecx,ecx
    70595880d648:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880d64c:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    70595880d651:	48 83 f8 00          	cmp    rax,0x0
    70595880d655:	74 1a                	je     0x70595880d671
    70595880d657:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    70595880d65c:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880d660:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880d666:	89 c9                	mov    ecx,ecx
    70595880d668:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880d66b:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    70595880d66f:	eb 57                	jmp    0x70595880d6c8
    70595880d671:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d678:	00 
    70595880d679:	8b 74 24 54          	mov    esi,DWORD PTR [rsp+0x54]
    70595880d67d:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    70595880d684:	00 
    70595880d685:	c7 80 bc 00 00 00 2e 	mov    DWORD PTR [rax+0xbc],0x1022e
    70595880d68c:	02 01 00 
    70595880d68f:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880d696:	00 00 00 
    70595880d699:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    70595880d6a0:	00 00 00 
    70595880d6a3:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880d6aa:	63 00 00 
    70595880d6ad:	ff d0                	call   rax
    70595880d6af:	89 c1                	mov    ecx,eax
    70595880d6b1:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d6b8:	00 
    70595880d6b9:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    70595880d6bd:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880d6c4:	75 2f                	jne    0x70595880d6f5
    70595880d6c6:	eb 79                	jmp    0x70595880d741
    70595880d6c8:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d6cf:	00 
    70595880d6d0:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    70595880d6d4:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880d6d8:	8b 54 24 44          	mov    edx,DWORD PTR [rsp+0x44]
    70595880d6dc:	89 54 24 38          	mov    DWORD PTR [rsp+0x38],edx
    70595880d6e0:	83 c1 04             	add    ecx,0x4
    70595880d6e3:	89 4c 24 3c          	mov    DWORD PTR [rsp+0x3c],ecx
    70595880d6e7:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    70595880d6ea:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    70595880d6f0:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880d6f3:	eb 59                	jmp    0x70595880d74e
    70595880d6f5:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d6fc:	00 
    70595880d6fd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d703:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d709:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d70f:	be 09 00 00 00       	mov    esi,0x9
    70595880d714:	b9 04 00 00 00       	mov    ecx,0x4
    70595880d719:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d720:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d727:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d72e:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d735:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d73c:	e9 45 03 00 00       	jmp    0x70595880da86
    70595880d741:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    70595880d745:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    70595880d749:	e9 7a ff ff ff       	jmp    0x70595880d6c8
    70595880d74e:	eb 00                	jmp    0x70595880d750
    70595880d750:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d757:	00 
    70595880d758:	8b 54 24 74          	mov    edx,DWORD PTR [rsp+0x74]
    70595880d75c:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    70595880d760:	31 d1                	xor    ecx,edx
    70595880d762:	89 08                	mov    DWORD PTR [rax],ecx
    70595880d764:	83 f9 00             	cmp    ecx,0x0
    70595880d767:	0f 94 c2             	sete   dl
    70595880d76a:	80 e2 01             	and    dl,0x1
    70595880d76d:	0f b6 d2             	movzx  edx,dl
    70595880d770:	c1 e9 1f             	shr    ecx,0x1f
    70595880d773:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    70595880d779:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    70595880d77f:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    70595880d786:	00 00 00 
    70595880d789:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    70595880d790:	00 00 00 
    70595880d793:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    70595880d79a:	00 00 00 
    70595880d79d:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    70595880d7a4:	00 00 00 
    70595880d7a7:	eb 00                	jmp    0x70595880d7a9
    70595880d7a9:	8b 44 24 3c          	mov    eax,DWORD PTR [rsp+0x3c]
    70595880d7ad:	83 e0 03             	and    eax,0x3
    70595880d7b0:	83 f8 00             	cmp    eax,0x0
    70595880d7b3:	0f 84 94 00 00 00    	je     0x70595880d84d
    70595880d7b9:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880d7c0:	00 
    70595880d7c1:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    70595880d7c5:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    70595880d7cc:	00 
    70595880d7cd:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10234
    70595880d7d4:	02 01 00 
    70595880d7d7:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880d7de:	00 00 00 
    70595880d7e1:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    70595880d7e8:	00 00 00 
    70595880d7eb:	31 c0                	xor    eax,eax
    70595880d7ed:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880d7f4:	63 00 00 
    70595880d7f7:	ba 34 02 01 00       	mov    edx,0x10234
    70595880d7fc:	45 31 c0             	xor    r8d,r8d
    70595880d7ff:	ff d0                	call   rax
    70595880d801:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d808:	00 
    70595880d809:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d80f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d815:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d81b:	be 0b 00 00 00       	mov    esi,0xb
    70595880d820:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d825:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d82c:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d833:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d83a:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d841:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d848:	e9 39 02 00 00       	jmp    0x70595880da86
    70595880d84d:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    70595880d854:	00 
    70595880d855:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    70595880d859:	c1 e9 0c             	shr    ecx,0xc
    70595880d85c:	89 c9                	mov    ecx,ecx
    70595880d85e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880d862:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    70595880d867:	48 83 f8 00          	cmp    rax,0x0
    70595880d86b:	74 1a                	je     0x70595880d887
    70595880d86d:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    70595880d872:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    70595880d876:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880d87c:	89 c9                	mov    ecx,ecx
    70595880d87e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880d881:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    70595880d885:	eb 57                	jmp    0x70595880d8de
    70595880d887:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d88e:	00 
    70595880d88f:	8b 74 24 3c          	mov    esi,DWORD PTR [rsp+0x3c]
    70595880d893:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    70595880d89a:	00 
    70595880d89b:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10234
    70595880d8a2:	02 01 00 
    70595880d8a5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880d8ac:	00 00 00 
    70595880d8af:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    70595880d8b6:	00 00 00 
    70595880d8b9:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880d8c0:	63 00 00 
    70595880d8c3:	ff d0                	call   rax
    70595880d8c5:	89 c1                	mov    ecx,eax
    70595880d8c7:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d8ce:	00 
    70595880d8cf:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    70595880d8d3:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880d8da:	75 1d                	jne    0x70595880d8f9
    70595880d8dc:	eb 67                	jmp    0x70595880d945
    70595880d8de:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d8e5:	00 
    70595880d8e6:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    70595880d8ea:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    70595880d8ee:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    70595880d8f1:	83 c1 04             	add    ecx,0x4
    70595880d8f4:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880d8f7:	eb 56                	jmp    0x70595880d94f
    70595880d8f9:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d900:	00 
    70595880d901:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d907:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d90d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d913:	be 0b 00 00 00       	mov    esi,0xb
    70595880d918:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d91d:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d924:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d92b:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d932:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d939:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d940:	e9 41 01 00 00       	jmp    0x70595880da86
    70595880d945:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    70595880d949:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    70595880d94d:	eb 8f                	jmp    0x70595880d8de
    70595880d94f:	eb 00                	jmp    0x70595880d951
    70595880d951:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    70595880d955:	83 e0 01             	and    eax,0x1
    70595880d958:	83 f8 00             	cmp    eax,0x0
    70595880d95b:	75 3a                	jne    0x70595880d997
    70595880d95d:	8b 54 24 38          	mov    edx,DWORD PTR [rsp+0x38]
    70595880d961:	be 0c 00 00 00       	mov    esi,0xc
    70595880d966:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d96b:	b0 01                	mov    al,0x1
    70595880d96d:	89 d7                	mov    edi,edx
    70595880d96f:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880d976:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880d97d:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880d984:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880d98b:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880d992:	e9 ef 00 00 00       	jmp    0x70595880da86
    70595880d997:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    70595880d99e:	00 
    70595880d99f:	48 8b 94 24 c8 00 00 	mov    rdx,QWORD PTR [rsp+0xc8]
    70595880d9a6:	00 
    70595880d9a7:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10236
    70595880d9ae:	02 01 00 
    70595880d9b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880d9b8:	00 00 00 
    70595880d9bb:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    70595880d9c2:	00 00 00 
    70595880d9c5:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880d9cc:	63 00 00 
    70595880d9cf:	be 2a 00 00 00       	mov    esi,0x2a
    70595880d9d4:	ff d0                	call   rax
    70595880d9d6:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880d9dd:	00 
    70595880d9de:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880d9e4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880d9ea:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880d9f0:	be 0c 00 00 00       	mov    esi,0xc
    70595880d9f5:	b9 02 00 00 00       	mov    ecx,0x2
    70595880d9fa:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    70595880da01:	89 b4 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],esi
    70595880da08:	89 94 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edx
    70595880da0f:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    70595880da16:	88 84 24 a7 00 00 00 	mov    BYTE PTR [rsp+0xa7],al
    70595880da1d:	eb 67                	jmp    0x70595880da86
    70595880da1f:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880da26:	00 
    70595880da27:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880da2e:	e9 81 01 00 00       	jmp    0x70595880dbb4
    70595880da33:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880da3a:	00 
    70595880da3b:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    70595880da3f:	c7 80 bc 00 00 00 1e 	mov    DWORD PTR [rax+0xbc],0x1021e
    70595880da46:	02 01 00 
    70595880da49:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    70595880da4f:	e9 0d f5 ff ff       	jmp    0x70595880cf61
    70595880da54:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880da5b:	00 
    70595880da5c:	c7 80 bc 00 00 00 1e 	mov    DWORD PTR [rax+0xbc],0x1021e
    70595880da63:	02 01 00 
    70595880da66:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880da6d:	00 00 00 
    70595880da70:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    70595880da77:	00 00 00 
    70595880da7a:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880da81:	e9 2e 01 00 00       	jmp    0x70595880dbb4
    70595880da86:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    70595880da8d:	00 
    70595880da8e:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    70595880da95:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    70595880da9c:	8b b4 24 9c 00 00 00 	mov    esi,DWORD PTR [rsp+0x9c]
    70595880daa3:	8b bc 24 a0 00 00 00 	mov    edi,DWORD PTR [rsp+0xa0]
    70595880daaa:	8a 9c 24 a7 00 00 00 	mov    bl,BYTE PTR [rsp+0xa7]
    70595880dab1:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    70595880dab5:	89 c3                	mov    ebx,eax
    70595880dab7:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    70595880dabb:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    70595880dabf:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    70595880dac3:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    70595880dac7:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880dacd:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    70595880dad1:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880dad7:	73 0d                	jae    0x70595880dae6
    70595880dad9:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    70595880dadd:	3d 1e 02 01 00       	cmp    eax,0x1021e
    70595880dae2:	74 37                	je     0x70595880db1b
    70595880dae4:	eb 5d                	jmp    0x70595880db43
    70595880dae6:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880daed:	00 
    70595880daee:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    70595880daf2:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595880daf6:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    70595880dafa:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    70595880dafe:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    70595880db04:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    70595880db0a:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    70595880db10:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595880db16:	e9 99 00 00 00       	jmp    0x70595880dbb4
    70595880db1b:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    70595880db22:	00 
    70595880db23:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    70595880db27:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880db2b:	89 90 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edx
    70595880db31:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    70595880db37:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    70595880db3e:	e9 1e f4 ff ff       	jmp    0x70595880cf61
    70595880db43:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    70595880db4a:	00 
    70595880db4b:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880db4f:	89 d1                	mov    ecx,edx
    70595880db51:	c1 e9 01             	shr    ecx,0x1
    70595880db54:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880db5a:	89 c9                	mov    ecx,ecx
    70595880db5c:	48 c1 e1 04          	shl    rcx,0x4
    70595880db60:	48 89 c6             	mov    rsi,rax
    70595880db63:	48 01 ce             	add    rsi,rcx
    70595880db66:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    70595880db6b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880db6e:	0f 85 72 ff ff ff    	jne    0x70595880dae6
    70595880db74:	4c 8b b4 24 c8 00 00 	mov    r14,QWORD PTR [rsp+0xc8]
    70595880db7b:	00 
    70595880db7c:	4c 8b ac 24 d0 00 00 	mov    r13,QWORD PTR [rsp+0xd0]
    70595880db83:	00 
    70595880db84:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    70595880db89:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    70595880db8d:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    70595880db91:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    70595880db98:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880db9f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880dba6:	00 
    70595880dba7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880dbab:	48 81 c4 e8 00 00 00 	add    rsp,0xe8
    70595880dbb2:	ff e0                	jmp    rax
    70595880dbb4:	48 81 c4 e8 00 00 00 	add    rsp,0xe8
    70595880dbbb:	c2 08 00             	ret    0x8
