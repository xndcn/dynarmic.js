; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000103b8(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %chain_self, %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66488
  %6 = icmp ugt i32 %5, 42
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb15 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb15, 66490
  %11 = getelementptr i8, ptr %cpu, i64 148
  %guard_lt = load i32, ptr %11, align 4
  %12 = icmp eq i32 %guard_lt, 66488
  %13 = and i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000103b8_entry, label %lb_guard_miss, !prof !0

insn_0x000103b8_entry:                            ; preds = %chain_go, %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table34 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table34, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 20
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000103b8_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 5, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000103b8_entry, %28
  br label %insn_0x000103b8

insn_0x000103b8:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 36
  %ptr = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 0
  %val = load i32, ptr %31, align 4
  %32 = and i32 %ptr, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000103b8
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66488, i32 %ptr, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000103b8
  %37 = lshr i32 %ptr, 12
  %page_index = zext i32 %37 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %38 = and i32 %ptr, 4095
  %page_offset = zext i32 %38 to i64
  %39 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %39, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %42 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %42, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %ptr_inc = add i32 %ptr, 4
  %43 = getelementptr i8, ptr %cpu, i32 36
  store i32 %ptr_inc, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %45, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %46 = icmp ne i8 %cec_pending, 0
  br i1 %46, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %47 = getelementptr i8, ptr %cpu, i64 188
  %next_pc16 = load i32, ptr %47, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %48 = getelementptr i8, ptr %cpu, i32 188
  store i32 66490, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %50, align 4
  call void @cec_check_pending(ptr %cpu)
  %51 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %51, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x000103ba_entry

did_jump_exit1:                                   ; preds = %cec_check
  %52 = getelementptr i8, ptr %cpu, i64 188
  %next_pc17 = load i32, ptr %52, align 4
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x000103ba_entry:                            ; preds = %cec_checked
  br label %insn_0x000103ba

insn_0x000103ba:                                  ; preds = %insn_0x000103ba_entry
  %rd_add = add i32 %val, 1
  %53 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rd_add, ptr %53, align 4
  %flgs = lshr i32 %val, 31
  %flgn = lshr i32 %rd_add, 31
  %54 = xor i32 0, %flgn
  %55 = xor i32 %flgs, %flgn
  %overflow = and i32 %55, %54
  %56 = xor i32 %val, -1
  %57 = icmp ult i32 %56, 1
  %ac0 = zext i1 %57 to i32
  %58 = icmp eq i32 %rd_add, 0
  %az = zext i1 %58 to i32
  %an = lshr i32 %rd_add, 31
  %59 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %61, align 4
  %62 = or i32 %vs_cur, %overflow
  %63 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 256
  store i32 %62, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %68, align 4
  %69 = icmp ugt i32 %lc1, 1
  br i1 %69, label %hwloop_back, label %hwloop_end, !prof !2

hwloop_done:                                      ; preds = %hwloop_end
  br label %insn_0x000103bc_entry

hwloop_back:                                      ; preds = %insn_0x000103ba
  %70 = getelementptr i8, ptr %cpu, i32 156
  %71 = sub i32 %lc1, 1
  store i32 %71, ptr %70, align 4
  %72 = getelementptr i8, ptr %cpu, i32 188
  store i32 66488, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %73, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %74 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %74 monotonic, align 4, !range !3
  %75 = icmp ult i32 %chain_total, %chain_budget
  br i1 %75, label %chain_go, label %chain_leave18, !prof !0

hwloop_end:                                       ; preds = %insn_0x000103ba
  %76 = getelementptr i8, ptr %cpu, i32 156
  store i32 0, ptr %76, align 4
  br label %hwloop_done

insn_0x000103bc_entry:                            ; preds = %hwloop_done
  br label %insn_0x000103bc

insn_0x000103bc:                                  ; preds = %insn_0x000103bc_entry
  %77 = getelementptr i8, ptr %cpu, i32 32
  %old = load i32, ptr %77, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %78 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_hi, ptr %78, align 4
  br label %insn_0x000103c0_entry

insn_0x000103c0_entry:                            ; preds = %insn_0x000103bc
  br label %insn_0x000103c0

insn_0x000103c0:                                  ; preds = %insn_0x000103c0_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 37628
  %79 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_lo, ptr %79, align 4
  br label %insn_0x000103c4_entry

insn_0x000103c4_entry:                            ; preds = %insn_0x000103c0
  br label %insn_0x000103c4

insn_0x000103c4:                                  ; preds = %insn_0x000103c4_entry
  %80 = getelementptr i8, ptr %cpu, i32 48
  store i32 %with_lo, ptr %80, align 4
  br label %insn_0x000103c6_entry

insn_0x000103c6_entry:                            ; preds = %insn_0x000103c4
  br label %insn_0x000103c6

insn_0x000103c6:                                  ; preds = %insn_0x000103c6_entry
  %81 = getelementptr i8, ptr %cpu, i32 24
  %old5 = load i32, ptr %81, align 4
  %lo_kept6 = and i32 %old5, 65535
  %with_hi7 = or i32 %lo_kept6, 1638400
  %82 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_hi7, ptr %82, align 4
  br label %insn_0x000103ca_entry

insn_0x000103ca_entry:                            ; preds = %insn_0x000103c6
  br label %insn_0x000103ca

insn_0x000103ca:                                  ; preds = %insn_0x000103ca_entry
  %83 = getelementptr i8, ptr %cpu, i32 28
  %old8 = load i32, ptr %83, align 4
  %lo_kept9 = and i32 %old8, 65535
  %with_hi10 = or i32 %lo_kept9, 1013841920
  %84 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_hi10, ptr %84, align 4
  br label %insn_0x000103ce_entry

insn_0x000103ce_entry:                            ; preds = %insn_0x000103ca
  br label %insn_0x000103ce

insn_0x000103ce:                                  ; preds = %insn_0x000103ce_entry
  %85 = getelementptr i8, ptr %cpu, i32 44
  store i32 %with_lo, ptr %85, align 4
  br label %insn_0x000103d0_entry

insn_0x000103d0_entry:                            ; preds = %insn_0x000103ce
  br label %insn_0x000103d0

insn_0x000103d0:                                  ; preds = %insn_0x000103d0_entry
  %hi_kept11 = and i32 %with_hi7, -65536
  %with_lo12 = or i32 %hi_kept11, 26125
  %86 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_lo12, ptr %86, align 4
  br label %insn_0x000103d4_entry

insn_0x000103d4_entry:                            ; preds = %insn_0x000103d0
  br label %insn_0x000103d4

insn_0x000103d4:                                  ; preds = %insn_0x000103d4_entry
  %hi_kept13 = and i32 %with_hi10, -65536
  %with_lo14 = or i32 %hi_kept13, 62303
  %87 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_lo14, ptr %87, align 4
  br label %insn_0x000103d8_entry

insn_0x000103d8_entry:                            ; preds = %insn_0x000103d4
  br label %insn_0x000103d8

insn_0x000103d8:                                  ; preds = %insn_0x000103d8_entry
  %88 = getelementptr i8, ptr %cpu, i32 12
  store i32 8191, ptr %88, align 4
  br label %insn_0x000103dc_entry

insn_0x000103dc_entry:                            ; preds = %insn_0x000103d8
  br label %insn_0x000103dc

insn_0x000103dc:                                  ; preds = %insn_0x000103dc_entry
  %89 = getelementptr i8, ptr %cpu, i32 40
  store i32 8192, ptr %89, align 4
  br label %insn_0x000103e0_entry

insn_0x000103e0_entry:                            ; preds = %insn_0x000103dc
  br label %insn_0x000103e0

insn_0x000103e0:                                  ; preds = %insn_0x000103e0_entry
  %90 = getelementptr i8, ptr %cpu, i32 80
  store i32 %with_lo, ptr %90, align 4
  br label %insn_0x000103e2_entry

insn_0x000103e2_entry:                            ; preds = %insn_0x000103e0
  br label %insn_0x000103e2

insn_0x000103e2:                                  ; preds = %insn_0x000103e2_entry
  %91 = getelementptr i8, ptr %cpu, i32 148
  store i32 66534, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 164
  store i32 66554, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 156
  store i32 8192, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 296
  %95 = getelementptr i8, ptr %cpu, i32 188
  store i32 66534, ptr %95, align 4
  store i8 1, ptr %94, align 1
  %at_lb0 = icmp eq i32 %lb0, 66530
  %at_lb = or i1 %at_lb0, false
  br i1 %at_lb, label %hwloop_count, label %hwloop_counted, !prof !1

hwloop_count:                                     ; preds = %insn_0x000103e2
  %96 = getelementptr i8, ptr %cpu, i32 188
  store i32 66534, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %98, align 4
  call void @bfin_hwloop_step(ptr %cpu, i32 66530, i32 66530)
  br label %hwloop_counted

hwloop_counted:                                   ; preds = %hwloop_count, %insn_0x000103e2
  %99 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets21 = load i32, ptr %99, align 4
  %chain_total22 = add nuw i32 %chain_packets21, 14
  %100 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget23 = load atomic i32, ptr %100 monotonic, align 4, !range !3
  %101 = icmp ult i32 %chain_total22, %chain_budget23
  br i1 %101, label %chain_go19, label %chain_leave20, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %102 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %102, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %hwloop_back
  %103 = getelementptr i8, ptr %cpu, i64 188
  store i32 66488, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %104, align 4
  br label %insn_0x000103b8_entry

chain_leave18:                                    ; preds = %hwloop_back
  %105 = getelementptr i8, ptr %cpu, i64 188
  store i32 66488, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %108, align 1
  br label %return

chain_go19:                                       ; preds = %hwloop_counted
  %chain_slot = getelementptr i8, ptr %chain_table, i64 532272
  %109 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %109, align 4
  %110 = icmp eq i32 %slot_pc, 66534
  br i1 %110, label %chain_hit, label %chain_leave20, !prof !0

chain_leave20:                                    ; preds = %chain_go19, %hwloop_counted
  %111 = getelementptr i8, ptr %cpu, i64 188
  store i32 66534, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i64 308
  store i32 14, ptr %113, align 4
  br label %return

chain_hit:                                        ; preds = %chain_go19
  %114 = getelementptr i8, ptr %cpu, i64 188
  store i32 66534, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total22, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %116, align 1
  %117 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %117, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc24 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc16, %did_jump_exit ], [ %next_pc17, %did_jump_exit1 ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ]
  %tail25 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ]
  %118 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %118, align 4
  %chain_total28 = add nuw i32 %chain_packets27, %packets
  %119 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %119 monotonic, align 4, !range !3
  %120 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %120, label %chain_lookup, label %chain_leave26, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %121 = icmp eq i32 %next_pc24, 66488
  br i1 %121, label %chain_self, label %chain_other, !prof !2

chain_leave26:                                    ; preds = %chain_other, %chain_exit
  %122 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %122, align 4
  %123 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail25, ptr %123, align 4
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %124 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %125, align 1
  br label %lb_guard

chain_other:                                      ; preds = %chain_lookup
  %126 = lshr i32 %next_pc24, 1
  %127 = and i32 %126, 65535
  %128 = zext i32 %127 to i64
  %129 = mul i64 %128, 16
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 %129
  %130 = getelementptr i8, ptr %chain_slot30, i64 0
  %slot_pc31 = load i32, ptr %130, align 4
  %131 = icmp eq i32 %slot_pc31, %next_pc24
  br i1 %131, label %chain_hit32, label %chain_leave26, !prof !0

chain_hit32:                                      ; preds = %chain_other
  %132 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %133, align 1
  %134 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %134, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave26, %chain_leave20, %chain_leave18, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @bfin_hwloop_step(ptr, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{!"branch_weights", i32 63, i32 1}
!3 = !{i32 0, i32 -2147483648}
