
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66488-0-123529039211584.bin:     file format binary


Disassembly of section .data:

0000705958806c40 <.data>:
    705958806c40:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    705958806c47:	4c 89 74 24 70       	mov    QWORD PTR [rsp+0x70],r14
    705958806c4c:	4c 89 6c 24 78       	mov    QWORD PTR [rsp+0x78],r13
    705958806c51:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958806c58:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    705958806c5f:	00 
    705958806c60:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    705958806c67:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    705958806c6e:	00 
    705958806c6f:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    705958806c76:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    705958806c7d:	00 
    705958806c7e:	48 8b 54 24 78       	mov    rdx,QWORD PTR [rsp+0x78]
    705958806c83:	8b 8a a0 00 00 00    	mov    ecx,DWORD PTR [rdx+0xa0]
    705958806c89:	83 f9 00             	cmp    ecx,0x0
    705958806c8c:	0f 94 c0             	sete   al
    705958806c8f:	81 e9 b8 03 01 00    	sub    ecx,0x103b8
    705958806c95:	83 f9 2a             	cmp    ecx,0x2a
    705958806c98:	0f 97 c1             	seta   cl
    705958806c9b:	08 c8                	or     al,cl
    705958806c9d:	24 01                	and    al,0x1
    705958806c9f:	81 ba a4 00 00 00 ba 	cmp    DWORD PTR [rdx+0xa4],0x103ba
    705958806ca6:	03 01 00 
    705958806ca9:	0f 94 c1             	sete   cl
    705958806cac:	81 ba 94 00 00 00 b8 	cmp    DWORD PTR [rdx+0x94],0x103b8
    705958806cb3:	03 01 00 
    705958806cb6:	0f 94 c2             	sete   dl
    705958806cb9:	20 d1                	and    cl,dl
    705958806cbb:	20 c8                	and    al,cl
    705958806cbd:	a8 01                	test   al,0x1
    705958806cbf:	75 05                	jne    0x705958806cc6
    705958806cc1:	e9 81 04 00 00       	jmp    0x705958807147
    705958806cc6:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806ccb:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958806cd2:	48 89 c8             	mov    rax,rcx
    705958806cd5:	48 05 00 00 10 00    	add    rax,0x100000
    705958806cdb:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    705958806ce0:	8b 81 14 00 10 00    	mov    eax,DWORD PTR [rcx+0x100014]
    705958806ce6:	83 c0 01             	add    eax,0x1
    705958806ce9:	89 81 14 00 10 00    	mov    DWORD PTR [rcx+0x100014],eax
    705958806cef:	3d 30 75 00 00       	cmp    eax,0x7530
    705958806cf4:	75 40                	jne    0x705958806d36
    705958806cf6:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    705958806cfb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958806d01:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    705958806d05:	89 c2                	mov    edx,eax
    705958806d07:	83 c2 01             	add    edx,0x1
    705958806d0a:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958806d10:	3d 00 01 00 00       	cmp    eax,0x100
    705958806d15:	73 1d                	jae    0x705958806d34
    705958806d17:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958806d1c:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958806d20:	89 c9                	mov    ecx,ecx
    705958806d22:	48 c1 e1 02          	shl    rcx,0x2
    705958806d26:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958806d2d:	c7 04 08 05 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x5
    705958806d34:	eb 00                	jmp    0x705958806d36
    705958806d36:	eb 00                	jmp    0x705958806d38
    705958806d38:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958806d3d:	8b 41 24             	mov    eax,DWORD PTR [rcx+0x24]
    705958806d40:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    705958806d44:	8b 09                	mov    ecx,DWORD PTR [rcx]
    705958806d46:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    705958806d4a:	83 e0 03             	and    eax,0x3
    705958806d4d:	83 f8 00             	cmp    eax,0x0
    705958806d50:	74 5f                	je     0x705958806db1
    705958806d52:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    705958806d57:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958806d5b:	48 8b 74 24 70       	mov    rsi,QWORD PTR [rsp+0x70]
    705958806d60:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958806d67:	00 00 00 
    705958806d6a:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958806d71:	00 00 00 
    705958806d74:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958806d7b:	63 00 00 
    705958806d7e:	ba b8 03 01 00       	mov    edx,0x103b8
    705958806d83:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958806d89:	ff d0                	call   rax
    705958806d8b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806d90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958806d96:	b9 01 00 00 00       	mov    ecx,0x1
    705958806d9b:	b8 02 00 00 00       	mov    eax,0x2
    705958806da0:	89 54 24 50          	mov    DWORD PTR [rsp+0x50],edx
    705958806da4:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    705958806da8:	89 44 24 58          	mov    DWORD PTR [rsp+0x58],eax
    705958806dac:	e9 79 04 00 00       	jmp    0x70595880722a
    705958806db1:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958806db8:	00 
    705958806db9:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958806dbd:	c1 e9 0c             	shr    ecx,0xc
    705958806dc0:	89 c9                	mov    ecx,ecx
    705958806dc2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958806dc6:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    705958806dcb:	48 83 f8 00          	cmp    rax,0x0
    705958806dcf:	74 1a                	je     0x705958806deb
    705958806dd1:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    705958806dd6:	8b 54 24 60          	mov    edx,DWORD PTR [rsp+0x60]
    705958806dda:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958806dde:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958806de4:	89 c9                	mov    ecx,ecx
    705958806de6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958806de9:	eb 42                	jmp    0x705958806e2d
    705958806deb:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806df0:	8b 54 24 60          	mov    edx,DWORD PTR [rsp+0x60]
    705958806df4:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    705958806df8:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    705958806dfd:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958806e04:	00 00 00 
    705958806e07:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958806e0e:	00 00 00 
    705958806e11:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958806e18:	63 00 00 
    705958806e1b:	ff d0                	call   rax
    705958806e1d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806e22:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958806e29:	75 2a                	jne    0x705958806e55
    705958806e2b:	eb 4e                	jmp    0x705958806e7b
    705958806e2d:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    705958806e34:	00 
    705958806e35:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958806e3a:	8b 54 24 5c          	mov    edx,DWORD PTR [rsp+0x5c]
    705958806e3e:	83 c2 04             	add    edx,0x4
    705958806e41:	89 51 24             	mov    DWORD PTR [rcx+0x24],edx
    705958806e44:	8b 89 a0 00 00 00    	mov    ecx,DWORD PTR [rcx+0xa0]
    705958806e4a:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    705958806e4e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958806e51:	75 2a                	jne    0x705958806e7d
    705958806e53:	eb 67                	jmp    0x705958806ebc
    705958806e55:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806e5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958806e60:	b9 01 00 00 00       	mov    ecx,0x1
    705958806e65:	b8 02 00 00 00       	mov    eax,0x2
    705958806e6a:	89 54 24 50          	mov    DWORD PTR [rsp+0x50],edx
    705958806e6e:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    705958806e72:	89 44 24 58          	mov    DWORD PTR [rsp+0x58],eax
    705958806e76:	e9 af 03 00 00       	jmp    0x70595880722a
    705958806e7b:	eb b0                	jmp    0x705958806e2d
    705958806e7d:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    705958806e82:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x103ba
    705958806e89:	03 01 00 
    705958806e8c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958806e93:	00 00 00 
    705958806e96:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958806e9d:	00 00 00 
    705958806ea0:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958806ea7:	63 00 00 
    705958806eaa:	ff d0                	call   rax
    705958806eac:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806eb1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958806eb8:	75 04                	jne    0x705958806ebe
    705958806eba:	eb 28                	jmp    0x705958806ee4
    705958806ebc:	eb 28                	jmp    0x705958806ee6
    705958806ebe:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806ec3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958806ec9:	b9 01 00 00 00       	mov    ecx,0x1
    705958806ece:	b8 02 00 00 00       	mov    eax,0x2
    705958806ed3:	89 54 24 50          	mov    DWORD PTR [rsp+0x50],edx
    705958806ed7:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    705958806edb:	89 44 24 58          	mov    DWORD PTR [rsp+0x58],eax
    705958806edf:	e9 46 03 00 00       	jmp    0x70595880722a
    705958806ee4:	eb d6                	jmp    0x705958806ebc
    705958806ee6:	eb 00                	jmp    0x705958806ee8
    705958806ee8:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806eed:	8b 4c 24 60          	mov    ecx,DWORD PTR [rsp+0x60]
    705958806ef1:	89 ca                	mov    edx,ecx
    705958806ef3:	83 c2 01             	add    edx,0x1
    705958806ef6:	89 10                	mov    DWORD PTR [rax],edx
    705958806ef8:	89 ce                	mov    esi,ecx
    705958806efa:	c1 ee 1f             	shr    esi,0x1f
    705958806efd:	89 d3                	mov    ebx,edx
    705958806eff:	c1 eb 1f             	shr    ebx,0x1f
    705958806f02:	89 df                	mov    edi,ebx
    705958806f04:	83 f7 00             	xor    edi,0x0
    705958806f07:	31 de                	xor    esi,ebx
    705958806f09:	21 fe                	and    esi,edi
    705958806f0b:	83 f1 ff             	xor    ecx,0xffffffff
    705958806f0e:	83 f9 01             	cmp    ecx,0x1
    705958806f11:	0f 92 c1             	setb   cl
    705958806f14:	80 e1 01             	and    cl,0x1
    705958806f17:	0f b6 c9             	movzx  ecx,cl
    705958806f1a:	83 fa 00             	cmp    edx,0x0
    705958806f1d:	0f 94 c3             	sete   bl
    705958806f20:	80 e3 01             	and    bl,0x1
    705958806f23:	0f b6 fb             	movzx  edi,bl
    705958806f26:	c1 ea 1f             	shr    edx,0x1f
    705958806f29:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    705958806f2f:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958806f35:	89 f2                	mov    edx,esi
    705958806f37:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    705958806f3d:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    705958806f43:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    705958806f49:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    705958806f4f:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958806f55:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958806f5b:	8b 80 9c 00 00 00    	mov    eax,DWORD PTR [rax+0x9c]
    705958806f61:	89 44 24 40          	mov    DWORD PTR [rsp+0x40],eax
    705958806f65:	83 f8 01             	cmp    eax,0x1
    705958806f68:	77 04                	ja     0x705958806f6e
    705958806f6a:	eb 3c                	jmp    0x705958806fa8
    705958806f6c:	eb 4b                	jmp    0x705958806fb9
    705958806f6e:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958806f73:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    705958806f77:	83 e8 01             	sub    eax,0x1
    705958806f7a:	89 81 9c 00 00 00    	mov    DWORD PTR [rcx+0x9c],eax
    705958806f80:	c7 81 bc 00 00 00 b8 	mov    DWORD PTR [rcx+0xbc],0x103b8
    705958806f87:	03 01 00 
    705958806f8a:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958806f90:	83 c0 02             	add    eax,0x2
    705958806f93:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    705958806f97:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958806f9d:	0f 82 b5 01 00 00    	jb     0x705958807158
    705958806fa3:	e9 ce 01 00 00       	jmp    0x705958807176
    705958806fa8:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806fad:	c7 80 9c 00 00 00 00 	mov    DWORD PTR [rax+0x9c],0x0
    705958806fb4:	00 00 00 
    705958806fb7:	eb b3                	jmp    0x705958806f6c
    705958806fb9:	eb 00                	jmp    0x705958806fbb
    705958806fbb:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806fc0:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    705958806fc3:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958806fc9:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958806fcf:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    705958806fd3:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    705958806fd6:	eb 00                	jmp    0x705958806fd8
    705958806fd8:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806fdd:	8b 4c 24 38          	mov    ecx,DWORD PTR [rsp+0x38]
    705958806fe1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958806fe7:	81 c9 fc 92 00 00    	or     ecx,0x92fc
    705958806fed:	89 4c 24 34          	mov    DWORD PTR [rsp+0x34],ecx
    705958806ff1:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    705958806ff4:	eb 00                	jmp    0x705958806ff6
    705958806ff6:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958806ffb:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958806fff:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    705958807002:	eb 00                	jmp    0x705958807004
    705958807004:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807009:	8b 48 18             	mov    ecx,DWORD PTR [rax+0x18]
    70595880700c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958807012:	81 c9 00 00 19 00    	or     ecx,0x190000
    705958807018:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    70595880701c:	89 48 18             	mov    DWORD PTR [rax+0x18],ecx
    70595880701f:	eb 00                	jmp    0x705958807021
    705958807021:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807026:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    705958807029:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880702f:	81 c9 00 00 6e 3c    	or     ecx,0x3c6e0000
    705958807035:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    705958807039:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    70595880703c:	eb 00                	jmp    0x70595880703e
    70595880703e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807043:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958807047:	89 48 2c             	mov    DWORD PTR [rax+0x2c],ecx
    70595880704a:	eb 00                	jmp    0x70595880704c
    70595880704c:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807051:	8b 4c 24 30          	mov    ecx,DWORD PTR [rsp+0x30]
    705958807055:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880705b:	81 c9 0d 66 00 00    	or     ecx,0x660d
    705958807061:	89 48 18             	mov    DWORD PTR [rax+0x18],ecx
    705958807064:	eb 00                	jmp    0x705958807066
    705958807066:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880706b:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    70595880706f:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958807075:	81 c9 5f f3 00 00    	or     ecx,0xf35f
    70595880707b:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    70595880707e:	eb 00                	jmp    0x705958807080
    705958807080:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807085:	c7 40 0c ff 1f 00 00 	mov    DWORD PTR [rax+0xc],0x1fff
    70595880708c:	eb 00                	jmp    0x70595880708e
    70595880708e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807093:	c7 40 28 00 20 00 00 	mov    DWORD PTR [rax+0x28],0x2000
    70595880709a:	eb 00                	jmp    0x70595880709c
    70595880709c:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    7059588070a1:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    7059588070a5:	89 48 50             	mov    DWORD PTR [rax+0x50],ecx
    7059588070a8:	eb 00                	jmp    0x7059588070aa
    7059588070aa:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    7059588070ae:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    7059588070b3:	c7 81 94 00 00 00 e6 	mov    DWORD PTR [rcx+0x94],0x103e6
    7059588070ba:	03 01 00 
    7059588070bd:	c7 81 a4 00 00 00 fa 	mov    DWORD PTR [rcx+0xa4],0x103fa
    7059588070c4:	03 01 00 
    7059588070c7:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x2000
    7059588070ce:	20 00 00 
    7059588070d1:	c7 81 bc 00 00 00 e6 	mov    DWORD PTR [rcx+0xbc],0x103e6
    7059588070d8:	03 01 00 
    7059588070db:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    7059588070e2:	3d e2 03 01 00       	cmp    eax,0x103e2
    7059588070e7:	0f 94 c0             	sete   al
    7059588070ea:	0c 00                	or     al,0x0
    7059588070ec:	a8 01                	test   al,0x1
    7059588070ee:	75 02                	jne    0x7059588070f2
    7059588070f0:	eb 36                	jmp    0x705958807128
    7059588070f2:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    7059588070f7:	c7 87 bc 00 00 00 e6 	mov    DWORD PTR [rdi+0xbc],0x103e6
    7059588070fe:	03 01 00 
    705958807101:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958807108:	00 00 00 
    70595880710b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    705958807112:	00 00 00 
    705958807115:	48 b8 20 6d 8c 23 5a 	movabs rax,0x635a238c6d20
    70595880711c:	63 00 00 
    70595880711f:	ba e2 03 01 00       	mov    edx,0x103e2
    705958807124:	89 d6                	mov    esi,edx
    705958807126:	ff d0                	call   rax
    705958807128:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    70595880712d:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958807133:	83 c0 0e             	add    eax,0xe
    705958807136:	89 44 24 28          	mov    DWORD PTR [rsp+0x28],eax
    70595880713a:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958807140:	72 63                	jb     0x7059588071a5
    705958807142:	e9 81 00 00 00       	jmp    0x7059588071c8
    705958807147:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880714c:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958807153:	e9 a2 01 00 00       	jmp    0x7059588072fa
    705958807158:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880715d:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    705958807161:	c7 80 bc 00 00 00 b8 	mov    DWORD PTR [rax+0xbc],0x103b8
    705958807168:	03 01 00 
    70595880716b:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    705958807171:	e9 50 fb ff ff       	jmp    0x705958806cc6
    705958807176:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880717b:	c7 80 bc 00 00 00 b8 	mov    DWORD PTR [rax+0xbc],0x103b8
    705958807182:	03 01 00 
    705958807185:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880718c:	00 00 00 
    70595880718f:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958807196:	00 00 00 
    705958807199:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    7059588071a0:	e9 55 01 00 00       	jmp    0x7059588072fa
    7059588071a5:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    7059588071ac:	00 
    7059588071ad:	48 89 c1             	mov    rcx,rax
    7059588071b0:	48 81 c1 30 1f 08 00 	add    rcx,0x81f30
    7059588071b7:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    7059588071bc:	81 b8 30 1f 08 00 e6 	cmp    DWORD PTR [rax+0x81f30],0x103e6
    7059588071c3:	03 01 00 
    7059588071c6:	74 28                	je     0x7059588071f0
    7059588071c8:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    7059588071cd:	c7 80 bc 00 00 00 e6 	mov    DWORD PTR [rax+0xbc],0x103e6
    7059588071d4:	03 01 00 
    7059588071d7:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    7059588071de:	00 00 00 
    7059588071e1:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    7059588071e8:	00 00 00 
    7059588071eb:	e9 0a 01 00 00       	jmp    0x7059588072fa
    7059588071f0:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    7059588071f5:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    7059588071fa:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    7059588071ff:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    705958807203:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103e6
    70595880720a:	e6 03 01 00 
    70595880720e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958807215:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880721c:	00 
    70595880721d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958807221:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958807228:	ff e0                	jmp    rax
    70595880722a:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    70595880722f:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    705958807233:	8b 44 24 54          	mov    eax,DWORD PTR [rsp+0x54]
    705958807237:	8b 74 24 58          	mov    esi,DWORD PTR [rsp+0x58]
    70595880723b:	89 c7                	mov    edi,eax
    70595880723d:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    705958807241:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    705958807245:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    705958807249:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880724f:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    705958807253:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958807259:	73 0d                	jae    0x705958807268
    70595880725b:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    70595880725f:	3d b8 03 01 00       	cmp    eax,0x103b8
    705958807264:	74 1d                	je     0x705958807283
    705958807266:	eb 36                	jmp    0x70595880729e
    705958807268:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880726d:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    705958807271:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    705958807275:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    70595880727b:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    705958807281:	eb 77                	jmp    0x7059588072fa
    705958807283:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958807288:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    70595880728c:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    705958807292:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    705958807299:	e9 e0 f9 ff ff       	jmp    0x705958806c7e
    70595880729e:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    7059588072a5:	00 
    7059588072a6:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    7059588072aa:	89 d1                	mov    ecx,edx
    7059588072ac:	c1 e9 01             	shr    ecx,0x1
    7059588072af:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588072b5:	89 c9                	mov    ecx,ecx
    7059588072b7:	48 c1 e1 04          	shl    rcx,0x4
    7059588072bb:	48 89 c6             	mov    rsi,rax
    7059588072be:	48 01 ce             	add    rsi,rcx
    7059588072c1:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    7059588072c6:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    7059588072c9:	75 9d                	jne    0x705958807268
    7059588072cb:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    7059588072d0:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    7059588072d5:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    7059588072da:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    7059588072de:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7059588072e5:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7059588072ec:	00 
    7059588072ed:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588072f1:	48 81 c4 98 00 00 00 	add    rsp,0x98
    7059588072f8:	ff e0                	jmp    rax
    7059588072fa:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958807301:	c2 08 00             	ret    0x8
