
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66408-0-123529039219152.bin:     file format binary


Disassembly of section .data:

00007059588089d0 <.data>:
    7059588089d0:	48 81 ec 08 01 00 00 	sub    rsp,0x108
    7059588089d7:	4c 89 b4 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r14
    7059588089de:	00 
    7059588089df:	4c 89 ac 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r13
    7059588089e6:	00 
    7059588089e7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7059588089ee:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    7059588089f5:	00 
    7059588089f6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7059588089fd:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    705958808a04:	00 
    705958808a05:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    705958808a0c:	00 
    705958808a0d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958808a13:	83 fa 00             	cmp    edx,0x0
    705958808a16:	0f 94 c0             	sete   al
    705958808a19:	81 ea 68 03 01 00    	sub    edx,0x10368
    705958808a1f:	83 fa 06             	cmp    edx,0x6
    705958808a22:	0f 97 c2             	seta   dl
    705958808a25:	08 d0                	or     al,dl
    705958808a27:	24 01                	and    al,0x1
    705958808a29:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958808a2f:	81 fa 20 04 01 00    	cmp    edx,0x10420
    705958808a35:	0f 94 c1             	sete   cl
    705958808a38:	81 ea 68 03 01 00    	sub    edx,0x10368
    705958808a3e:	83 fa 06             	cmp    edx,0x6
    705958808a41:	0f 97 c2             	seta   dl
    705958808a44:	08 d1                	or     cl,dl
    705958808a46:	20 c8                	and    al,cl
    705958808a48:	a8 01                	test   al,0x1
    705958808a4a:	75 05                	jne    0x705958808a51
    705958808a4c:	e9 2f 0d 00 00       	jmp    0x705958809780
    705958808a51:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808a58:	00 
    705958808a59:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958808a60:	48 89 c8             	mov    rax,rcx
    705958808a63:	48 05 00 00 10 00    	add    rax,0x100000
    705958808a69:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    705958808a70:	00 
    705958808a71:	8b 81 20 00 10 00    	mov    eax,DWORD PTR [rcx+0x100020]
    705958808a77:	83 c0 01             	add    eax,0x1
    705958808a7a:	89 81 20 00 10 00    	mov    DWORD PTR [rcx+0x100020],eax
    705958808a80:	3d 30 75 00 00       	cmp    eax,0x7530
    705958808a85:	75 4c                	jne    0x705958808ad3
    705958808a87:	48 8b 8c 24 e0 00 00 	mov    rcx,QWORD PTR [rsp+0xe0]
    705958808a8e:	00 
    705958808a8f:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958808a95:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    705958808a9c:	89 c2                	mov    edx,eax
    705958808a9e:	83 c2 01             	add    edx,0x1
    705958808aa1:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958808aa7:	3d 00 01 00 00       	cmp    eax,0x100
    705958808aac:	73 23                	jae    0x705958808ad1
    705958808aae:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    705958808ab5:	00 
    705958808ab6:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    705958808abd:	89 c9                	mov    ecx,ecx
    705958808abf:	48 c1 e1 02          	shl    rcx,0x2
    705958808ac3:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958808aca:	c7 04 08 08 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x8
    705958808ad1:	eb 00                	jmp    0x705958808ad3
    705958808ad3:	eb 00                	jmp    0x705958808ad5
    705958808ad5:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808adc:	00 
    705958808add:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    705958808ae0:	89 84 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],eax
    705958808ae7:	83 e0 03             	and    eax,0x3
    705958808aea:	83 f8 00             	cmp    eax,0x0
    705958808aed:	0f 84 8d 00 00 00    	je     0x705958808b80
    705958808af3:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    705958808afa:	00 
    705958808afb:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    705958808b02:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    705958808b09:	00 
    705958808b0a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958808b11:	00 00 00 
    705958808b14:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958808b1b:	00 00 00 
    705958808b1e:	31 c0                	xor    eax,eax
    705958808b20:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958808b27:	63 00 00 
    705958808b2a:	ba 68 03 01 00       	mov    edx,0x10368
    705958808b2f:	45 31 c0             	xor    r8d,r8d
    705958808b32:	ff d0                	call   rax
    705958808b34:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808b3b:	00 
    705958808b3c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958808b42:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808b48:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958808b4e:	be 01 00 00 00       	mov    esi,0x1
    705958808b53:	b9 04 00 00 00       	mov    ecx,0x4
    705958808b58:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    705958808b5f:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958808b66:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958808b6d:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958808b74:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    705958808b7b:	e9 14 0c 00 00       	jmp    0x705958809794
    705958808b80:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    705958808b87:	00 
    705958808b88:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    705958808b8f:	c1 e9 0c             	shr    ecx,0xc
    705958808b92:	89 c9                	mov    ecx,ecx
    705958808b94:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958808b98:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    705958808b9f:	00 
    705958808ba0:	48 83 f8 00          	cmp    rax,0x0
    705958808ba4:	74 23                	je     0x705958808bc9
    705958808ba6:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958808bad:	00 
    705958808bae:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    705958808bb5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958808bbb:	89 c9                	mov    ecx,ecx
    705958808bbd:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958808bc0:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    705958808bc7:	eb 53                	jmp    0x705958808c1c
    705958808bc9:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808bd0:	00 
    705958808bd1:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    705958808bd8:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    705958808bdf:	00 
    705958808be0:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958808be7:	00 00 00 
    705958808bea:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958808bf1:	00 00 00 
    705958808bf4:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958808bfb:	63 00 00 
    705958808bfe:	ff d0                	call   rax
    705958808c00:	89 c1                	mov    ecx,eax
    705958808c02:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808c09:	00 
    705958808c0a:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    705958808c11:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958808c18:	75 2e                	jne    0x705958808c48
    705958808c1a:	eb 78                	jmp    0x705958808c94
    705958808c1c:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    705958808c23:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    705958808c2a:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    705958808c31:	83 c0 04             	add    eax,0x4
    705958808c34:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    705958808c3b:	83 e0 03             	and    eax,0x3
    705958808c3e:	83 f8 00             	cmp    eax,0x0
    705958808c41:	75 64                	jne    0x705958808ca7
    705958808c43:	e9 ec 00 00 00       	jmp    0x705958808d34
    705958808c48:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808c4f:	00 
    705958808c50:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958808c56:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808c5c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958808c62:	be 01 00 00 00       	mov    esi,0x1
    705958808c67:	b9 04 00 00 00       	mov    ecx,0x4
    705958808c6c:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    705958808c73:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958808c7a:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958808c81:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958808c88:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    705958808c8f:	e9 00 0b 00 00       	jmp    0x705958809794
    705958808c94:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    705958808c9b:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    705958808ca2:	e9 75 ff ff ff       	jmp    0x705958808c1c
    705958808ca7:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    705958808cae:	00 
    705958808caf:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958808cb6:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    705958808cbd:	00 
    705958808cbe:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958808cc5:	00 00 00 
    705958808cc8:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958808ccf:	00 00 00 
    705958808cd2:	31 c0                	xor    eax,eax
    705958808cd4:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958808cdb:	63 00 00 
    705958808cde:	ba 68 03 01 00       	mov    edx,0x10368
    705958808ce3:	45 31 c0             	xor    r8d,r8d
    705958808ce6:	ff d0                	call   rax
    705958808ce8:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808cef:	00 
    705958808cf0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958808cf6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808cfc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958808d02:	be 01 00 00 00       	mov    esi,0x1
    705958808d07:	b9 04 00 00 00       	mov    ecx,0x4
    705958808d0c:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    705958808d13:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958808d1a:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958808d21:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958808d28:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    705958808d2f:	e9 60 0a 00 00       	jmp    0x705958809794
    705958808d34:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    705958808d3b:	00 
    705958808d3c:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958808d43:	c1 e9 0c             	shr    ecx,0xc
    705958808d46:	89 c9                	mov    ecx,ecx
    705958808d48:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958808d4c:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    705958808d53:	00 
    705958808d54:	48 83 f8 00          	cmp    rax,0x0
    705958808d58:	74 23                	je     0x705958808d7d
    705958808d5a:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    705958808d61:	00 
    705958808d62:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958808d69:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958808d6f:	89 c9                	mov    ecx,ecx
    705958808d71:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958808d74:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    705958808d7b:	eb 56                	jmp    0x705958808dd3
    705958808d7d:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808d84:	00 
    705958808d85:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    705958808d8c:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    705958808d93:	00 
    705958808d94:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958808d9b:	00 00 00 
    705958808d9e:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958808da5:	00 00 00 
    705958808da8:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958808daf:	63 00 00 
    705958808db2:	ff d0                	call   rax
    705958808db4:	89 c1                	mov    ecx,eax
    705958808db6:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808dbd:	00 
    705958808dbe:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    705958808dc5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958808dcc:	75 41                	jne    0x705958808e0f
    705958808dce:	e9 88 00 00 00       	jmp    0x705958808e5b
    705958808dd3:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808dda:	00 
    705958808ddb:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    705958808de2:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958808de9:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    705958808df0:	89 94 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],edx
    705958808df7:	83 c1 04             	add    ecx,0x4
    705958808dfa:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    705958808e01:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    705958808e04:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    705958808e0a:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    705958808e0d:	eb 5f                	jmp    0x705958808e6e
    705958808e0f:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808e16:	00 
    705958808e17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958808e1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808e23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958808e29:	be 01 00 00 00       	mov    esi,0x1
    705958808e2e:	b9 04 00 00 00       	mov    ecx,0x4
    705958808e33:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    705958808e3a:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958808e41:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958808e48:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958808e4f:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    705958808e56:	e9 39 09 00 00       	jmp    0x705958809794
    705958808e5b:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    705958808e62:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    705958808e69:	e9 65 ff ff ff       	jmp    0x705958808dd3
    705958808e6e:	eb 00                	jmp    0x705958808e70
    705958808e70:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    705958808e77:	83 e0 03             	and    eax,0x3
    705958808e7a:	83 f8 00             	cmp    eax,0x0
    705958808e7d:	0f 84 94 00 00 00    	je     0x705958808f17
    705958808e83:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    705958808e8a:	00 
    705958808e8b:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    705958808e92:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    705958808e99:	00 
    705958808e9a:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958808ea1:	03 01 00 
    705958808ea4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958808eab:	00 00 00 
    705958808eae:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958808eb5:	00 00 00 
    705958808eb8:	31 c0                	xor    eax,eax
    705958808eba:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958808ec1:	63 00 00 
    705958808ec4:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958808ec9:	45 31 c0             	xor    r8d,r8d
    705958808ecc:	ff d0                	call   rax
    705958808ece:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808ed5:	00 
    705958808ed6:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958808edc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808ee2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958808ee8:	b9 02 00 00 00       	mov    ecx,0x2
    705958808eed:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    705958808ef4:	89 ce                	mov    esi,ecx
    705958808ef6:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958808efd:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958808f04:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958808f0b:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    705958808f12:	e9 7d 08 00 00       	jmp    0x705958809794
    705958808f17:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    705958808f1e:	00 
    705958808f1f:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    705958808f26:	c1 e9 0c             	shr    ecx,0xc
    705958808f29:	89 c9                	mov    ecx,ecx
    705958808f2b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958808f2f:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    705958808f36:	00 
    705958808f37:	48 83 f8 00          	cmp    rax,0x0
    705958808f3b:	74 23                	je     0x705958808f60
    705958808f3d:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    705958808f44:	00 
    705958808f45:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    705958808f4c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958808f52:	89 c9                	mov    ecx,ecx
    705958808f54:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958808f57:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    705958808f5e:	eb 5d                	jmp    0x705958808fbd
    705958808f60:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808f67:	00 
    705958808f68:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    705958808f6f:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    705958808f76:	00 
    705958808f77:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958808f7e:	03 01 00 
    705958808f81:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958808f88:	00 00 00 
    705958808f8b:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958808f92:	00 00 00 
    705958808f95:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958808f9c:	63 00 00 
    705958808f9f:	ff d0                	call   rax
    705958808fa1:	89 c1                	mov    ecx,eax
    705958808fa3:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808faa:	00 
    705958808fab:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    705958808fb2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958808fb9:	75 2f                	jne    0x705958808fea
    705958808fbb:	eb 76                	jmp    0x705958809033
    705958808fbd:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    705958808fc4:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    705958808fcb:	00 
    705958808fcc:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    705958808fd3:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    705958808fd6:	83 c0 04             	add    eax,0x4
    705958808fd9:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    705958808fdd:	83 e0 03             	and    eax,0x3
    705958808fe0:	83 f8 00             	cmp    eax,0x0
    705958808fe3:	75 61                	jne    0x705958809046
    705958808fe5:	e9 ed 00 00 00       	jmp    0x7059588090d7
    705958808fea:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958808ff1:	00 
    705958808ff2:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958808ff8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958808ffe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958809004:	b9 02 00 00 00       	mov    ecx,0x2
    705958809009:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    705958809010:	89 ce                	mov    esi,ecx
    705958809012:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958809019:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958809020:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809027:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880902e:	e9 61 07 00 00       	jmp    0x705958809794
    705958809033:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    70595880903a:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    705958809041:	e9 77 ff ff ff       	jmp    0x705958808fbd
    705958809046:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    70595880904d:	00 
    70595880904e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958809052:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    705958809059:	00 
    70595880905a:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958809061:	03 01 00 
    705958809064:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880906b:	00 00 00 
    70595880906e:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958809075:	00 00 00 
    705958809078:	31 c0                	xor    eax,eax
    70595880907a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958809081:	63 00 00 
    705958809084:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958809089:	45 31 c0             	xor    r8d,r8d
    70595880908c:	ff d0                	call   rax
    70595880908e:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809095:	00 
    705958809096:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    70595880909c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588090a2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588090a8:	b9 02 00 00 00       	mov    ecx,0x2
    7059588090ad:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    7059588090b4:	89 ce                	mov    esi,ecx
    7059588090b6:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    7059588090bd:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    7059588090c4:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    7059588090cb:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    7059588090d2:	e9 bd 06 00 00       	jmp    0x705958809794
    7059588090d7:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    7059588090de:	00 
    7059588090df:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    7059588090e3:	c1 e9 0c             	shr    ecx,0xc
    7059588090e6:	89 c9                	mov    ecx,ecx
    7059588090e8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588090ec:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    7059588090f1:	48 83 f8 00          	cmp    rax,0x0
    7059588090f5:	74 1a                	je     0x705958809111
    7059588090f7:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    7059588090fc:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958809100:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958809106:	89 c9                	mov    ecx,ecx
    705958809108:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880910b:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    70595880910f:	eb 57                	jmp    0x705958809168
    705958809111:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809118:	00 
    705958809119:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    70595880911d:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    705958809124:	00 
    705958809125:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    70595880912c:	03 01 00 
    70595880912f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958809136:	00 00 00 
    705958809139:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958809140:	00 00 00 
    705958809143:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880914a:	63 00 00 
    70595880914d:	ff d0                	call   rax
    70595880914f:	89 c1                	mov    ecx,eax
    705958809151:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809158:	00 
    705958809159:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    70595880915d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958809164:	75 29                	jne    0x70595880918f
    705958809166:	eb 70                	jmp    0x7059588091d8
    705958809168:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    70595880916c:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    705958809173:	00 
    705958809174:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    705958809178:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    70595880917b:	83 c0 04             	add    eax,0x4
    70595880917e:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    705958809182:	83 e0 03             	and    eax,0x3
    705958809185:	83 f8 00             	cmp    eax,0x0
    705958809188:	75 58                	jne    0x7059588091e2
    70595880918a:	e9 e4 00 00 00       	jmp    0x705958809273
    70595880918f:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809196:	00 
    705958809197:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    70595880919d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588091a3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588091a9:	b9 02 00 00 00       	mov    ecx,0x2
    7059588091ae:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    7059588091b5:	89 ce                	mov    esi,ecx
    7059588091b7:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    7059588091be:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    7059588091c5:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    7059588091cc:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    7059588091d3:	e9 bc 05 00 00       	jmp    0x705958809794
    7059588091d8:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    7059588091dc:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    7059588091e0:	eb 86                	jmp    0x705958809168
    7059588091e2:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    7059588091e9:	00 
    7059588091ea:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    7059588091ee:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    7059588091f5:	00 
    7059588091f6:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    7059588091fd:	03 01 00 
    705958809200:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958809207:	00 00 00 
    70595880920a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958809211:	00 00 00 
    705958809214:	31 c0                	xor    eax,eax
    705958809216:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880921d:	63 00 00 
    705958809220:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958809225:	45 31 c0             	xor    r8d,r8d
    705958809228:	ff d0                	call   rax
    70595880922a:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809231:	00 
    705958809232:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958809238:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880923e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958809244:	b9 02 00 00 00       	mov    ecx,0x2
    705958809249:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    705958809250:	89 ce                	mov    esi,ecx
    705958809252:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958809259:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958809260:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809267:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880926e:	e9 21 05 00 00       	jmp    0x705958809794
    705958809273:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    70595880927a:	00 
    70595880927b:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880927f:	c1 e9 0c             	shr    ecx,0xc
    705958809282:	89 c9                	mov    ecx,ecx
    705958809284:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958809288:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    70595880928d:	48 83 f8 00          	cmp    rax,0x0
    705958809291:	74 1a                	je     0x7059588092ad
    705958809293:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    705958809298:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880929c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588092a2:	89 c9                	mov    ecx,ecx
    7059588092a4:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588092a7:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    7059588092ab:	eb 57                	jmp    0x705958809304
    7059588092ad:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    7059588092b4:	00 
    7059588092b5:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    7059588092b9:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    7059588092c0:	00 
    7059588092c1:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    7059588092c8:	03 01 00 
    7059588092cb:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588092d2:	00 00 00 
    7059588092d5:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    7059588092dc:	00 00 00 
    7059588092df:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588092e6:	63 00 00 
    7059588092e9:	ff d0                	call   rax
    7059588092eb:	89 c1                	mov    ecx,eax
    7059588092ed:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    7059588092f4:	00 
    7059588092f5:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    7059588092f9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958809300:	75 29                	jne    0x70595880932b
    705958809302:	eb 70                	jmp    0x705958809374
    705958809304:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    705958809308:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    70595880930f:	00 
    705958809310:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    705958809314:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    705958809317:	83 c0 04             	add    eax,0x4
    70595880931a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    70595880931e:	83 e0 03             	and    eax,0x3
    705958809321:	83 f8 00             	cmp    eax,0x0
    705958809324:	75 58                	jne    0x70595880937e
    705958809326:	e9 e4 00 00 00       	jmp    0x70595880940f
    70595880932b:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809332:	00 
    705958809333:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958809339:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880933f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958809345:	b9 02 00 00 00       	mov    ecx,0x2
    70595880934a:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    705958809351:	89 ce                	mov    esi,ecx
    705958809353:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    70595880935a:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958809361:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809368:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880936f:	e9 20 04 00 00       	jmp    0x705958809794
    705958809374:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    705958809378:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880937c:	eb 86                	jmp    0x705958809304
    70595880937e:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    705958809385:	00 
    705958809386:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880938a:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    705958809391:	00 
    705958809392:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958809399:	03 01 00 
    70595880939c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588093a3:	00 00 00 
    7059588093a6:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    7059588093ad:	00 00 00 
    7059588093b0:	31 c0                	xor    eax,eax
    7059588093b2:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588093b9:	63 00 00 
    7059588093bc:	ba 6c 03 01 00       	mov    edx,0x1036c
    7059588093c1:	45 31 c0             	xor    r8d,r8d
    7059588093c4:	ff d0                	call   rax
    7059588093c6:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    7059588093cd:	00 
    7059588093ce:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    7059588093d4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588093da:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588093e0:	b9 02 00 00 00       	mov    ecx,0x2
    7059588093e5:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    7059588093ec:	89 ce                	mov    esi,ecx
    7059588093ee:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    7059588093f5:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    7059588093fc:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809403:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880940a:	e9 85 03 00 00       	jmp    0x705958809794
    70595880940f:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    705958809416:	00 
    705958809417:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880941b:	c1 e9 0c             	shr    ecx,0xc
    70595880941e:	89 c9                	mov    ecx,ecx
    705958809420:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958809424:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    705958809429:	48 83 f8 00          	cmp    rax,0x0
    70595880942d:	74 1a                	je     0x705958809449
    70595880942f:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    705958809434:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958809438:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880943e:	89 c9                	mov    ecx,ecx
    705958809440:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958809443:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    705958809447:	eb 57                	jmp    0x7059588094a0
    705958809449:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809450:	00 
    705958809451:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    705958809455:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    70595880945c:	00 
    70595880945d:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958809464:	03 01 00 
    705958809467:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880946e:	00 00 00 
    705958809471:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958809478:	00 00 00 
    70595880947b:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958809482:	63 00 00 
    705958809485:	ff d0                	call   rax
    705958809487:	89 c1                	mov    ecx,eax
    705958809489:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809490:	00 
    705958809491:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    705958809495:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880949c:	75 29                	jne    0x7059588094c7
    70595880949e:	eb 70                	jmp    0x705958809510
    7059588094a0:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    7059588094a4:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    7059588094ab:	00 
    7059588094ac:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    7059588094b0:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    7059588094b3:	83 c0 04             	add    eax,0x4
    7059588094b6:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    7059588094ba:	83 e0 03             	and    eax,0x3
    7059588094bd:	83 f8 00             	cmp    eax,0x0
    7059588094c0:	75 58                	jne    0x70595880951a
    7059588094c2:	e9 e4 00 00 00       	jmp    0x7059588095ab
    7059588094c7:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    7059588094ce:	00 
    7059588094cf:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    7059588094d5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588094db:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588094e1:	b9 02 00 00 00       	mov    ecx,0x2
    7059588094e6:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    7059588094ed:	89 ce                	mov    esi,ecx
    7059588094ef:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    7059588094f6:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    7059588094fd:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809504:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880950b:	e9 84 02 00 00       	jmp    0x705958809794
    705958809510:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    705958809514:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    705958809518:	eb 86                	jmp    0x7059588094a0
    70595880951a:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    705958809521:	00 
    705958809522:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958809526:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    70595880952d:	00 
    70595880952e:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958809535:	03 01 00 
    705958809538:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880953f:	00 00 00 
    705958809542:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958809549:	00 00 00 
    70595880954c:	31 c0                	xor    eax,eax
    70595880954e:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958809555:	63 00 00 
    705958809558:	ba 6c 03 01 00       	mov    edx,0x1036c
    70595880955d:	45 31 c0             	xor    r8d,r8d
    705958809560:	ff d0                	call   rax
    705958809562:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809569:	00 
    70595880956a:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958809570:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958809576:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880957c:	b9 02 00 00 00       	mov    ecx,0x2
    705958809581:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    705958809588:	89 ce                	mov    esi,ecx
    70595880958a:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958809591:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958809598:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    70595880959f:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    7059588095a6:	e9 e9 01 00 00       	jmp    0x705958809794
    7059588095ab:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    7059588095b2:	00 
    7059588095b3:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    7059588095b7:	c1 e9 0c             	shr    ecx,0xc
    7059588095ba:	89 c9                	mov    ecx,ecx
    7059588095bc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588095c0:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    7059588095c5:	48 83 f8 00          	cmp    rax,0x0
    7059588095c9:	74 1a                	je     0x7059588095e5
    7059588095cb:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    7059588095d0:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    7059588095d4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588095da:	89 c9                	mov    ecx,ecx
    7059588095dc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588095df:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    7059588095e3:	eb 57                	jmp    0x70595880963c
    7059588095e5:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    7059588095ec:	00 
    7059588095ed:	8b 74 24 34          	mov    esi,DWORD PTR [rsp+0x34]
    7059588095f1:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    7059588095f8:	00 
    7059588095f9:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958809600:	03 01 00 
    705958809603:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880960a:	00 00 00 
    70595880960d:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958809614:	00 00 00 
    705958809617:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880961e:	63 00 00 
    705958809621:	ff d0                	call   rax
    705958809623:	89 c1                	mov    ecx,eax
    705958809625:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880962c:	00 
    70595880962d:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    705958809631:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958809638:	75 1d                	jne    0x705958809657
    70595880963a:	eb 64                	jmp    0x7059588096a0
    70595880963c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809643:	00 
    705958809644:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958809648:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    70595880964c:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    70595880964f:	83 c1 04             	add    ecx,0x4
    705958809652:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    705958809655:	eb 53                	jmp    0x7059588096aa
    705958809657:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880965e:	00 
    70595880965f:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    705958809665:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880966b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958809671:	b9 02 00 00 00       	mov    ecx,0x2
    705958809676:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    70595880967d:	89 ce                	mov    esi,ecx
    70595880967f:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958809686:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    70595880968d:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809694:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880969b:	e9 f4 00 00 00       	jmp    0x705958809794
    7059588096a0:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    7059588096a4:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    7059588096a8:	eb 92                	jmp    0x70595880963c
    7059588096aa:	eb 00                	jmp    0x7059588096ac
    7059588096ac:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    7059588096b3:	83 e0 01             	and    eax,0x1
    7059588096b6:	83 f8 00             	cmp    eax,0x0
    7059588096b9:	75 3d                	jne    0x7059588096f8
    7059588096bb:	8b 94 24 90 00 00 00 	mov    edx,DWORD PTR [rsp+0x90]
    7059588096c2:	be 03 00 00 00       	mov    esi,0x3
    7059588096c7:	b9 02 00 00 00       	mov    ecx,0x2
    7059588096cc:	b0 01                	mov    al,0x1
    7059588096ce:	89 d7                	mov    edi,edx
    7059588096d0:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    7059588096d7:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    7059588096de:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    7059588096e5:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    7059588096ec:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    7059588096f3:	e9 9c 00 00 00       	jmp    0x705958809794
    7059588096f8:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    7059588096ff:	00 
    705958809700:	48 8b 94 24 e8 00 00 	mov    rdx,QWORD PTR [rsp+0xe8]
    705958809707:	00 
    705958809708:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    70595880970f:	03 01 00 
    705958809712:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958809719:	00 00 00 
    70595880971c:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958809723:	00 00 00 
    705958809726:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880972d:	63 00 00 
    705958809730:	be 2a 00 00 00       	mov    esi,0x2a
    705958809735:	ff d0                	call   rax
    705958809737:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880973e:	00 
    70595880973f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958809745:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880974b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958809751:	be 03 00 00 00       	mov    esi,0x3
    705958809756:	b9 02 00 00 00       	mov    ecx,0x2
    70595880975b:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    705958809762:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    705958809769:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    705958809770:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    705958809777:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    70595880977e:	eb 14                	jmp    0x705958809794
    705958809780:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    705958809787:	00 
    705958809788:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880978f:	e9 f0 00 00 00       	jmp    0x705958809884
    705958809794:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    70595880979b:	00 
    70595880979c:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    7059588097a3:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    7059588097aa:	8b b4 24 cc 00 00 00 	mov    esi,DWORD PTR [rsp+0xcc]
    7059588097b1:	8b bc 24 d0 00 00 00 	mov    edi,DWORD PTR [rsp+0xd0]
    7059588097b8:	8a 9c 24 d7 00 00 00 	mov    bl,BYTE PTR [rsp+0xd7]
    7059588097bf:	88 5c 24 0b          	mov    BYTE PTR [rsp+0xb],bl
    7059588097c3:	89 c3                	mov    ebx,eax
    7059588097c5:	89 5c 24 0c          	mov    DWORD PTR [rsp+0xc],ebx
    7059588097c9:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    7059588097cd:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    7059588097d1:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    7059588097d5:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    7059588097db:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7059588097df:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588097e5:	73 2c                	jae    0x705958809813
    7059588097e7:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    7059588097ee:	00 
    7059588097ef:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    7059588097f3:	89 d1                	mov    ecx,edx
    7059588097f5:	c1 e9 01             	shr    ecx,0x1
    7059588097f8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588097fe:	89 c9                	mov    ecx,ecx
    705958809800:	48 c1 e1 04          	shl    rcx,0x4
    705958809804:	48 89 c6             	mov    rsi,rax
    705958809807:	48 01 ce             	add    rsi,rcx
    70595880980a:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    70595880980e:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958809811:	74 32                	je     0x705958809845
    705958809813:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    70595880981a:	00 
    70595880981b:	8a 4c 24 0b          	mov    cl,BYTE PTR [rsp+0xb]
    70595880981f:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    705958809823:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    705958809827:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    70595880982b:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    705958809831:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    705958809837:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    70595880983d:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    705958809843:	eb 3f                	jmp    0x705958809884
    705958809845:	4c 8b b4 24 e8 00 00 	mov    r14,QWORD PTR [rsp+0xe8]
    70595880984c:	00 
    70595880984d:	4c 8b ac 24 f0 00 00 	mov    r13,QWORD PTR [rsp+0xf0]
    705958809854:	00 
    705958809855:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    705958809859:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    70595880985d:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    705958809861:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    705958809868:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880986f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958809876:	00 
    705958809877:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880987b:	48 81 c4 08 01 00 00 	add    rsp,0x108
    705958809882:	ff e0                	jmp    rax
    705958809884:	48 81 c4 08 01 00 00 	add    rsp,0x108
    70595880988b:	c2 08 00             	ret    0x8
