; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001021e(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 66078
  %5 = icmp ugt i32 %4, 24
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb63 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb63, 66592
  %10 = sub i32 %guard_lb63, 66078
  %11 = icmp ugt i32 %10, 24
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x0001021e_entry, label %lb_guard_miss, !prof !0

insn_0x0001021e_entry:                            ; preds = %chain_self, %chain_go, %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table81 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table81, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 56
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x0001021e_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 14, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x0001021e_entry, %27
  br label %insn_0x0001021e

insn_0x0001021e:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 8
  %regmv_src = load i32, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 32
  store i32 %regmv_src, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %32, align 4
  br label %insn_0x00010220_entry

insn_0x00010220_entry:                            ; preds = %insn_0x0001021e
  br label %insn_0x00010220

insn_0x00010220:                                  ; preds = %insn_0x00010220_entry
  %33 = getelementptr i8, ptr %cpu, i32 12
  %rd = load i32, ptr %33, align 4
  %rd_add = add i32 %rd, 1
  %34 = getelementptr i8, ptr %cpu, i32 12
  store i32 %rd_add, ptr %34, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %35 = xor i32 0, %flgn
  %36 = xor i32 %flgs, %flgn
  %overflow = and i32 %36, %35
  %37 = xor i32 %rd, -1
  %38 = icmp ult i32 %37, 1
  %ac0 = zext i1 %38 to i32
  %39 = icmp eq i32 %rd_add, 0
  %az = zext i1 %39 to i32
  %an = lshr i32 %rd_add, 31
  %40 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %42, align 4
  %43 = or i32 %vs_cur, %overflow
  %44 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 256
  store i32 %43, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %48, align 4
  br label %insn_0x00010222_entry

insn_0x00010222_entry:                            ; preds = %insn_0x00010220
  br label %insn_0x00010222

insn_0x00010222:                                  ; preds = %insn_0x00010222_entry
  %49 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %49, align 4
  %50 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %50 to i32
  %51 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %51, align 4
  %52 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %52 to i32
  %53 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %53 to i32
  %54 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %54 to i32
  %55 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac03, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac03, ptr %58, align 4
  br label %insn_0x00010224_entry

insn_0x00010224_entry:                            ; preds = %insn_0x00010222
  br label %insn_0x00010224

insn_0x00010224:                                  ; preds = %insn_0x00010224_entry
  %59 = shl i32 %regmv_src, 2
  %60 = getelementptr i8, ptr %cpu, i32 36
  %ps = load i32, ptr %60, align 4
  %plshift2 = add i32 %ps, %59
  %61 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift2, ptr %61, align 4
  br label %insn_0x00010226_entry

insn_0x00010226_entry:                            ; preds = %insn_0x00010224
  br label %insn_0x00010226

insn_0x00010226:                                  ; preds = %insn_0x00010226_entry
  %62 = and i32 %plshift2, 3
  %63 = icmp ne i32 %62, 0
  br i1 %63, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010226
  %64 = getelementptr i8, ptr %cpu, i32 188
  store i32 66086, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %66, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66086, i32 %plshift2, i32 0)
  %67 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i64 188
  %69 = load i32, ptr %68, align 4
  %70 = getelementptr i8, ptr %cpu, i64 296
  %71 = load i8, ptr %70, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010226
  %72 = lshr i32 %plshift2, 12
  %page_index = zext i32 %72 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %73 = and i32 %plshift2, 4095
  %page_offset = zext i32 %73 to i64
  %74 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %74, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %75 = getelementptr i8, ptr %cpu, i32 188
  store i32 66086, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %77, align 4
  %78 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %79 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %79, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %78, %did_jump_cont ]
  %80 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mem_val, ptr %80, align 4
  br label %insn_0x00010228_entry

did_jump_exit:                                    ; preds = %page_slow
  %81 = getelementptr i8, ptr %cpu, i64 188
  %next_pc64 = load i32, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 188
  %83 = load i32, ptr %82, align 4
  %84 = getelementptr i8, ptr %cpu, i64 296
  %85 = load i8, ptr %84, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x00010228_entry:                            ; preds = %page_done
  br label %insn_0x00010228

insn_0x00010228:                                  ; preds = %insn_0x00010228_entry
  %86 = getelementptr i8, ptr %cpu, i32 4
  %rt = load i32, ptr %86, align 4
  %xor32 = xor i32 %rt, %mem_val
  %87 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %87, align 4
  %88 = icmp eq i32 %xor32, 0
  %az4 = zext i1 %88 to i32
  %an5 = lshr i32 %xor32, 31
  %89 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az4, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an5, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %94, align 4
  br label %insn_0x0001022a_entry

insn_0x0001022a_entry:                            ; preds = %insn_0x00010228
  br label %insn_0x0001022a

insn_0x0001022a:                                  ; preds = %insn_0x0001022a_entry
  %95 = getelementptr i8, ptr %cpu, i32 28
  %rt6 = load i32, ptr %95, align 4
  %add32 = add i32 %xor32, %rt6
  %96 = getelementptr i8, ptr %cpu, i32 4
  store i32 %add32, ptr %96, align 4
  %flgs7 = lshr i32 %xor32, 31
  %flgo = lshr i32 %rt6, 31
  %flgn8 = lshr i32 %add32, 31
  %97 = xor i32 %flgo, %flgn8
  %98 = xor i32 %flgs7, %flgn8
  %99 = and i32 %98, %97
  %100 = xor i32 %xor32, -1
  %101 = icmp ult i32 %100, %rt6
  %ac09 = zext i1 %101 to i32
  %102 = icmp eq i32 %add32, 0
  %az10 = zext i1 %102 to i32
  %an11 = lshr i32 %add32, 31
  %103 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az10, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an11, ptr %104, align 4
  %105 = or i32 %43, %99
  %106 = getelementptr i8, ptr %cpu, i32 248
  store i32 %99, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i32 252
  store i32 %99, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 256
  store i32 %105, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac09, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac09, ptr %110, align 4
  br label %insn_0x0001022c_entry

insn_0x0001022c_entry:                            ; preds = %insn_0x0001022a
  br label %insn_0x0001022c

insn_0x0001022c:                                  ; preds = %insn_0x0001022c_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x0001022c
  %111 = getelementptr i8, ptr %cpu, i32 188
  store i32 66078, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %112, align 4
  %chain_total = add nuw i32 %chain_packets, 8
  %113 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %113 monotonic, align 4, !range !2
  %114 = icmp ult i32 %chain_total, %chain_budget
  br i1 %114, label %chain_go, label %chain_leave65, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x0001022c
  br label %insn_0x0001022e_entry

insn_0x0001022e_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x0001022e

insn_0x0001022e:                                  ; preds = %insn_0x0001022e_entry
  %115 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %115, align 4
  %116 = and i32 %fp, 3
  %117 = icmp ne i32 %116, 0
  br i1 %117, label %data_misaligned12, label %data_aligned13, !prof !1

data_misaligned12:                                ; preds = %insn_0x0001022e
  %118 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %120, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66094, i32 %fp, i32 0)
  %121 = getelementptr i8, ptr %cpu, i64 188
  %next_pc66 = load i32, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i64 188
  %123 = load i32, ptr %122, align 4
  %124 = getelementptr i8, ptr %cpu, i64 296
  %125 = load i8, ptr %124, align 1
  br label %chain_exit

data_aligned13:                                   ; preds = %insn_0x0001022e
  %126 = lshr i32 %fp, 12
  %page_index17 = zext i32 %126 to i64
  %page_slot18 = getelementptr ptr, ptr %page_table, i64 %page_index17
  %page19 = load ptr, ptr %page_slot18, align 8
  %page_mapped20 = icmp ne ptr %page19, null
  br i1 %page_mapped20, label %page_fast14, label %page_slow15, !prof !0

page_fast14:                                      ; preds = %data_aligned13
  %127 = and i32 %fp, 4095
  %page_offset21 = zext i32 %127 to i64
  %128 = getelementptr i8, ptr %page19, i64 %page_offset21
  %page_val22 = load i32, ptr %128, align 4
  br label %page_done16

page_slow15:                                      ; preds = %data_aligned13
  %129 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %131, align 4
  %132 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %133 = getelementptr i8, ptr %cpu, i32 296
  %dj25 = load i8, ptr %133, align 1
  %dj_set26 = icmp ne i8 %dj25, 0
  br i1 %dj_set26, label %did_jump_exit23, label %did_jump_cont24, !prof !1

page_done16:                                      ; preds = %did_jump_cont24, %page_fast14
  %mem_val27 = phi i32 [ %page_val22, %page_fast14 ], [ %132, %did_jump_cont24 ]
  %sp1 = add i32 %fp, 4
  %134 = and i32 %sp1, 3
  %135 = icmp ne i32 %134, 0
  br i1 %135, label %data_misaligned28, label %data_aligned29, !prof !1

did_jump_exit23:                                  ; preds = %page_slow15
  %136 = getelementptr i8, ptr %cpu, i64 188
  %next_pc67 = load i32, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i64 188
  %138 = load i32, ptr %137, align 4
  %139 = getelementptr i8, ptr %cpu, i64 296
  %140 = load i8, ptr %139, align 1
  br label %chain_exit

did_jump_cont24:                                  ; preds = %page_slow15
  br label %page_done16

data_misaligned28:                                ; preds = %page_done16
  %141 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %142, align 4
  %143 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %143, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66094, i32 %sp1, i32 0)
  %144 = getelementptr i8, ptr %cpu, i64 188
  %next_pc68 = load i32, ptr %144, align 4
  %145 = getelementptr i8, ptr %cpu, i64 188
  %146 = load i32, ptr %145, align 4
  %147 = getelementptr i8, ptr %cpu, i64 296
  %148 = load i8, ptr %147, align 1
  br label %chain_exit

data_aligned29:                                   ; preds = %page_done16
  %149 = lshr i32 %sp1, 12
  %page_index33 = zext i32 %149 to i64
  %page_slot34 = getelementptr ptr, ptr %page_table, i64 %page_index33
  %page35 = load ptr, ptr %page_slot34, align 8
  %page_mapped36 = icmp ne ptr %page35, null
  br i1 %page_mapped36, label %page_fast30, label %page_slow31, !prof !0

page_fast30:                                      ; preds = %data_aligned29
  %150 = and i32 %sp1, 4095
  %page_offset37 = zext i32 %150 to i64
  %151 = getelementptr i8, ptr %page35, i64 %page_offset37
  %page_val38 = load i32, ptr %151, align 4
  br label %page_done32

page_slow31:                                      ; preds = %data_aligned29
  %152 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %154, align 4
  %155 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %156 = getelementptr i8, ptr %cpu, i32 296
  %dj41 = load i8, ptr %156, align 1
  %dj_set42 = icmp ne i8 %dj41, 0
  br i1 %dj_set42, label %did_jump_exit39, label %did_jump_cont40, !prof !1

page_done32:                                      ; preds = %did_jump_cont40, %page_fast30
  %mem_val43 = phi i32 [ %page_val38, %page_fast30 ], [ %155, %did_jump_cont40 ]
  %sp2 = add i32 %sp1, 4
  %157 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val27, ptr %157, align 4
  %158 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val43, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %159, align 4
  br label %insn_0x00010232_entry

did_jump_exit39:                                  ; preds = %page_slow31
  %160 = getelementptr i8, ptr %cpu, i64 188
  %next_pc69 = load i32, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i64 188
  %162 = load i32, ptr %161, align 4
  %163 = getelementptr i8, ptr %cpu, i64 296
  %164 = load i8, ptr %163, align 1
  br label %chain_exit

did_jump_cont40:                                  ; preds = %page_slow31
  br label %page_done32

insn_0x00010232_entry:                            ; preds = %page_done32
  br label %insn_0x00010232

insn_0x00010232:                                  ; preds = %insn_0x00010232_entry
  %xor3244 = xor i32 %mem_val, %add32
  %165 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor3244, ptr %165, align 4
  %166 = icmp eq i32 %xor3244, 0
  %az45 = zext i1 %166 to i32
  %an46 = lshr i32 %xor3244, 31
  %167 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az45, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an46, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %172, align 4
  br label %insn_0x00010234_entry

insn_0x00010234_entry:                            ; preds = %insn_0x00010232
  br label %insn_0x00010234

insn_0x00010234:                                  ; preds = %insn_0x00010234_entry
  %173 = and i32 %sp2, 3
  %174 = icmp ne i32 %173, 0
  br i1 %174, label %data_misaligned47, label %data_aligned48, !prof !1

data_misaligned47:                                ; preds = %insn_0x00010234
  %175 = getelementptr i8, ptr %cpu, i32 188
  store i32 66100, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %177, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66100, i32 %sp2, i32 0)
  %178 = getelementptr i8, ptr %cpu, i64 188
  %next_pc70 = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 188
  %180 = load i32, ptr %179, align 4
  %181 = getelementptr i8, ptr %cpu, i64 296
  %182 = load i8, ptr %181, align 1
  br label %chain_exit

data_aligned48:                                   ; preds = %insn_0x00010234
  %183 = lshr i32 %sp2, 12
  %page_index52 = zext i32 %183 to i64
  %page_slot53 = getelementptr ptr, ptr %page_table, i64 %page_index52
  %page54 = load ptr, ptr %page_slot53, align 8
  %page_mapped55 = icmp ne ptr %page54, null
  br i1 %page_mapped55, label %page_fast49, label %page_slow50, !prof !0

page_fast49:                                      ; preds = %data_aligned48
  %184 = and i32 %sp2, 4095
  %page_offset56 = zext i32 %184 to i64
  %185 = getelementptr i8, ptr %page54, i64 %page_offset56
  %page_val57 = load i32, ptr %185, align 4
  br label %page_done51

page_slow50:                                      ; preds = %data_aligned48
  %186 = getelementptr i8, ptr %cpu, i32 188
  store i32 66100, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %188, align 4
  %189 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %190 = getelementptr i8, ptr %cpu, i32 296
  %dj60 = load i8, ptr %190, align 1
  %dj_set61 = icmp ne i8 %dj60, 0
  br i1 %dj_set61, label %did_jump_exit58, label %did_jump_cont59, !prof !1

page_done51:                                      ; preds = %did_jump_cont59, %page_fast49
  %mem_val62 = phi i32 [ %page_val57, %page_fast49 ], [ %189, %did_jump_cont59 ]
  %191 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val62, ptr %191, align 4
  %sp_inc = add i32 %sp2, 4
  %192 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc, ptr %192, align 4
  br label %insn_0x00010236_entry

did_jump_exit58:                                  ; preds = %page_slow50
  %193 = getelementptr i8, ptr %cpu, i64 188
  %next_pc71 = load i32, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i64 188
  %195 = load i32, ptr %194, align 4
  %196 = getelementptr i8, ptr %cpu, i64 296
  %197 = load i8, ptr %196, align 1
  br label %chain_exit

did_jump_cont59:                                  ; preds = %page_slow50
  br label %page_done51

insn_0x00010236_entry:                            ; preds = %page_done51
  br label %insn_0x00010236

insn_0x00010236:                                  ; preds = %insn_0x00010236_entry
  %lsb = and i32 %mem_val43, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x00010236
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x00010236
  %198 = getelementptr i8, ptr %cpu, i32 188
  store i32 66102, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %200, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %201 = getelementptr i8, ptr %cpu, i64 188
  %next_pc72 = load i32, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i64 188
  %203 = load i32, ptr %202, align 4
  %204 = getelementptr i8, ptr %cpu, i64 296
  %205 = load i8, ptr %204, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %206 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %206, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %207 = getelementptr i8, ptr %cpu, i64 188
  store i32 66078, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %208, align 4
  br label %insn_0x0001021e_entry

chain_leave65:                                    ; preds = %brcc_taken
  %209 = getelementptr i8, ptr %cpu, i64 188
  store i32 66078, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %210, align 4
  %211 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %211, align 4
  %212 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %212, align 1
  br label %return

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit58, %data_misaligned47, %did_jump_exit39, %data_misaligned28, %did_jump_exit23, %data_misaligned12, %did_jump_exit, %data_misaligned
  %next_pc73 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc64, %did_jump_exit ], [ %next_pc66, %data_misaligned12 ], [ %next_pc67, %did_jump_exit23 ], [ %next_pc68, %data_misaligned28 ], [ %next_pc69, %did_jump_exit39 ], [ %next_pc70, %data_misaligned47 ], [ %next_pc71, %did_jump_exit58 ], [ %mem_val43, %jump_aligned ], [ %next_pc72, %jump_misalign ]
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 9, %data_misaligned12 ], [ 9, %did_jump_exit23 ], [ 9, %data_misaligned28 ], [ 9, %did_jump_exit39 ], [ 11, %data_misaligned47 ], [ 11, %did_jump_exit58 ], [ 12, %jump_aligned ], [ 12, %jump_misalign ]
  %tail = phi i32 [ %69, %data_misaligned ], [ %83, %did_jump_exit ], [ %123, %data_misaligned12 ], [ %138, %did_jump_exit23 ], [ %146, %data_misaligned28 ], [ %162, %did_jump_exit39 ], [ %180, %data_misaligned47 ], [ %195, %did_jump_exit58 ], [ %mem_val43, %jump_aligned ], [ %203, %jump_misalign ]
  %tail74 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 4, %data_misaligned12 ], [ 4, %did_jump_exit23 ], [ 4, %data_misaligned28 ], [ 4, %did_jump_exit39 ], [ 2, %data_misaligned47 ], [ 2, %did_jump_exit58 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail75 = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 9, %data_misaligned12 ], [ 9, %did_jump_exit23 ], [ 9, %data_misaligned28 ], [ 9, %did_jump_exit39 ], [ 11, %data_misaligned47 ], [ 11, %did_jump_exit58 ], [ 12, %jump_aligned ], [ 12, %jump_misalign ]
  %tail76 = phi i8 [ %71, %data_misaligned ], [ %85, %did_jump_exit ], [ %125, %data_misaligned12 ], [ %140, %did_jump_exit23 ], [ %148, %data_misaligned28 ], [ %164, %did_jump_exit39 ], [ %182, %data_misaligned47 ], [ %197, %did_jump_exit58 ], [ 1, %jump_aligned ], [ %205, %jump_misalign ]
  %213 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets78 = load i32, ptr %213, align 4
  %chain_total79 = add nuw i32 %chain_packets78, %packets
  %214 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget80 = load atomic i32, ptr %214 monotonic, align 4, !range !2
  %215 = icmp ult i32 %chain_total79, %chain_budget80
  br i1 %215, label %chain_lookup, label %chain_leave77, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %216 = icmp eq i32 %next_pc73, 66078
  br i1 %216, label %chain_self, label %chain_other, !prof !3

chain_leave77:                                    ; preds = %chain_other, %chain_exit
  %217 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail74, ptr %218, align 4
  %219 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail75, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail76, ptr %220, align 1
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %221 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc73, ptr %221, align 4
  %222 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total79, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %223, align 1
  br label %insn_0x0001021e_entry

chain_other:                                      ; preds = %chain_lookup
  %224 = lshr i32 %next_pc73, 1
  %225 = and i32 %224, 65535
  %226 = zext i32 %225 to i64
  %227 = mul i64 %226, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %227
  %228 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %228, align 4
  %229 = icmp eq i32 %slot_pc, %next_pc73
  br i1 %229, label %chain_hit, label %chain_leave77, !prof !0

chain_hit:                                        ; preds = %chain_other
  %230 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc73, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total79, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %232, align 1
  %233 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %233, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave77, %chain_leave65, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
!3 = !{!"branch_weights", i32 63, i32 1}
