
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65682-0-123529039222928.bin:     file format binary


Disassembly of section .data:

0000705958809890 <.data>:
    705958809890:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    705958809897:	4c 89 74 24 70       	mov    QWORD PTR [rsp+0x70],r14
    70595880989c:	4c 89 6c 24 78       	mov    QWORD PTR [rsp+0x78],r13
    7059588098a1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    7059588098a8:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    7059588098af:	00 
    7059588098b0:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    7059588098b7:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    7059588098be:	00 
    7059588098bf:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    7059588098c6:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    7059588098cd:	00 
    7059588098ce:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    7059588098d3:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    7059588098d9:	83 fa 00             	cmp    edx,0x0
    7059588098dc:	0f 94 c0             	sete   al
    7059588098df:	81 ea 92 00 01 00    	sub    edx,0x10092
    7059588098e5:	83 fa 06             	cmp    edx,0x6
    7059588098e8:	0f 97 c2             	seta   dl
    7059588098eb:	08 d0                	or     al,dl
    7059588098ed:	24 01                	and    al,0x1
    7059588098ef:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    7059588098f5:	81 fa 20 04 01 00    	cmp    edx,0x10420
    7059588098fb:	0f 94 c1             	sete   cl
    7059588098fe:	81 ea 92 00 01 00    	sub    edx,0x10092
    705958809904:	83 fa 06             	cmp    edx,0x6
    705958809907:	0f 97 c2             	seta   dl
    70595880990a:	08 d1                	or     cl,dl
    70595880990c:	20 c8                	and    al,cl
    70595880990e:	a8 01                	test   al,0x1
    705958809910:	75 05                	jne    0x705958809917
    705958809912:	e9 4f 03 00 00       	jmp    0x705958809c66
    705958809917:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880991c:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958809923:	48 89 c8             	mov    rax,rcx
    705958809926:	48 05 00 00 10 00    	add    rax,0x100000
    70595880992c:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    705958809931:	8b 81 24 00 10 00    	mov    eax,DWORD PTR [rcx+0x100024]
    705958809937:	83 c0 01             	add    eax,0x1
    70595880993a:	89 81 24 00 10 00    	mov    DWORD PTR [rcx+0x100024],eax
    705958809940:	3d 30 75 00 00       	cmp    eax,0x7530
    705958809945:	75 40                	jne    0x705958809987
    705958809947:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    70595880994c:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958809952:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    705958809956:	89 c2                	mov    edx,eax
    705958809958:	83 c2 01             	add    edx,0x1
    70595880995b:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958809961:	3d 00 01 00 00       	cmp    eax,0x100
    705958809966:	73 1d                	jae    0x705958809985
    705958809968:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    70595880996d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958809971:	89 c9                	mov    ecx,ecx
    705958809973:	48 c1 e1 02          	shl    rcx,0x2
    705958809977:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880997e:	c7 04 08 09 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x9
    705958809985:	eb 00                	jmp    0x705958809987
    705958809987:	eb 00                	jmp    0x705958809989
    705958809989:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880998e:	8b 38                	mov    edi,DWORD PTR [rax]
    705958809990:	89 fa                	mov    edx,edi
    705958809992:	83 ea 00             	sub    edx,0x0
    705958809995:	83 fa 00             	cmp    edx,0x0
    705958809998:	0f 94 c1             	sete   cl
    70595880999b:	80 e1 01             	and    cl,0x1
    70595880999e:	0f b6 f1             	movzx  esi,cl
    7059588099a1:	89 74 24 58          	mov    DWORD PTR [rsp+0x58],esi
    7059588099a5:	c1 ea 1f             	shr    edx,0x1f
    7059588099a8:	89 f9                	mov    ecx,edi
    7059588099aa:	c1 e9 1f             	shr    ecx,0x1f
    7059588099ad:	89 d3                	mov    ebx,edx
    7059588099af:	31 cb                	xor    ebx,ecx
    7059588099b1:	83 f1 00             	xor    ecx,0x0
    7059588099b4:	21 d9                	and    ecx,ebx
    7059588099b6:	31 ca                	xor    edx,ecx
    7059588099b8:	31 c9                	xor    ecx,ecx
    7059588099ba:	39 f9                	cmp    ecx,edi
    7059588099bc:	0f 96 c1             	setbe  cl
    7059588099bf:	80 e1 01             	and    cl,0x1
    7059588099c2:	0f b6 c9             	movzx  ecx,cl
    7059588099c5:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    7059588099cb:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    7059588099d1:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    7059588099d7:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    7059588099dd:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    7059588099e3:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    7059588099e9:	89 4c 24 5c          	mov    DWORD PTR [rsp+0x5c],ecx
    7059588099ed:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    7059588099f3:	89 44 24 60          	mov    DWORD PTR [rsp+0x60],eax
    7059588099f7:	eb 00                	jmp    0x7059588099f9
    7059588099f9:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    7059588099fd:	83 f8 00             	cmp    eax,0x0
    705958809a00:	75 2d                	jne    0x705958809a2f
    705958809a02:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958809a07:	c7 81 bc 00 00 00 c0 	mov    DWORD PTR [rcx+0xbc],0x100c0
    705958809a0e:	00 01 00 
    705958809a11:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958809a17:	83 c0 02             	add    eax,0x2
    705958809a1a:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    705958809a1e:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958809a24:	0f 82 4d 02 00 00    	jb     0x705958809c77
    705958809a2a:	e9 6b 02 00 00       	jmp    0x705958809c9a
    705958809a2f:	eb 00                	jmp    0x705958809a31
    705958809a31:	eb 00                	jmp    0x705958809a33
    705958809a33:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958809a38:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    705958809a3b:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958809a3f:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    705958809a42:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    705958809a46:	83 e0 03             	and    eax,0x3
    705958809a49:	83 f8 00             	cmp    eax,0x0
    705958809a4c:	74 69                	je     0x705958809ab7
    705958809a4e:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    705958809a53:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958809a57:	48 8b 74 24 70       	mov    rsi,QWORD PTR [rsp+0x70]
    705958809a5c:	c7 87 bc 00 00 00 96 	mov    DWORD PTR [rdi+0xbc],0x10096
    705958809a63:	00 01 00 
    705958809a66:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958809a6d:	00 00 00 
    705958809a70:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958809a77:	00 00 00 
    705958809a7a:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958809a81:	63 00 00 
    705958809a84:	ba 96 00 01 00       	mov    edx,0x10096
    705958809a89:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958809a8f:	ff d0                	call   rax
    705958809a91:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809a96:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958809a9c:	b9 03 00 00 00       	mov    ecx,0x3
    705958809aa1:	b8 02 00 00 00       	mov    eax,0x2
    705958809aa6:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    705958809aaa:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    705958809aae:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    705958809ab2:	e9 c8 02 00 00       	jmp    0x705958809d7f
    705958809ab7:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    705958809abe:	00 
    705958809abf:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958809ac3:	c1 e9 0c             	shr    ecx,0xc
    705958809ac6:	89 c9                	mov    ecx,ecx
    705958809ac8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958809acc:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    705958809ad1:	48 83 f8 00          	cmp    rax,0x0
    705958809ad5:	74 1a                	je     0x705958809af1
    705958809ad7:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958809adc:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    705958809ae0:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958809ae4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958809aea:	89 c9                	mov    ecx,ecx
    705958809aec:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958809aef:	eb 4c                	jmp    0x705958809b3d
    705958809af1:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809af6:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    705958809afa:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    705958809afe:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    705958809b03:	c7 80 bc 00 00 00 96 	mov    DWORD PTR [rax+0xbc],0x10096
    705958809b0a:	00 01 00 
    705958809b0d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958809b14:	00 00 00 
    705958809b17:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    705958809b1e:	00 00 00 
    705958809b21:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958809b28:	63 00 00 
    705958809b2b:	ff d0                	call   rax
    705958809b2d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809b32:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958809b39:	75 11                	jne    0x705958809b4c
    705958809b3b:	eb 35                	jmp    0x705958809b72
    705958809b3d:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    705958809b44:	00 
    705958809b45:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958809b48:	75 2a                	jne    0x705958809b74
    705958809b4a:	eb 67                	jmp    0x705958809bb3
    705958809b4c:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809b51:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958809b57:	b9 03 00 00 00       	mov    ecx,0x3
    705958809b5c:	b8 02 00 00 00       	mov    eax,0x2
    705958809b61:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    705958809b65:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    705958809b69:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    705958809b6d:	e9 0d 02 00 00       	jmp    0x705958809d7f
    705958809b72:	eb c9                	jmp    0x705958809b3d
    705958809b74:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    705958809b79:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10098
    705958809b80:	00 01 00 
    705958809b83:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958809b8a:	00 00 00 
    705958809b8d:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958809b94:	00 00 00 
    705958809b97:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958809b9e:	63 00 00 
    705958809ba1:	ff d0                	call   rax
    705958809ba3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809ba8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958809baf:	75 04                	jne    0x705958809bb5
    705958809bb1:	eb 28                	jmp    0x705958809bdb
    705958809bb3:	eb 28                	jmp    0x705958809bdd
    705958809bb5:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809bba:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958809bc0:	b9 03 00 00 00       	mov    ecx,0x3
    705958809bc5:	b8 02 00 00 00       	mov    eax,0x2
    705958809bca:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    705958809bce:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    705958809bd2:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    705958809bd6:	e9 a4 01 00 00       	jmp    0x705958809d7f
    705958809bdb:	eb d6                	jmp    0x705958809bb3
    705958809bdd:	eb 00                	jmp    0x705958809bdf
    705958809bdf:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958809be4:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    705958809be8:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    705958809bec:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    705958809bf2:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    705958809bf8:	83 ff 01             	cmp    edi,0x1
    705958809bfb:	0f 97 c3             	seta   bl
    705958809bfe:	3d 98 00 01 00       	cmp    eax,0x10098
    705958809c03:	0f 94 c0             	sete   al
    705958809c06:	20 c3                	and    bl,al
    705958809c08:	b8 9c 00 01 00       	mov    eax,0x1009c
    705958809c0d:	f6 c3 01             	test   bl,0x1
    705958809c10:	0f 45 c2             	cmovne eax,edx
    705958809c13:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    705958809c19:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    705958809c1f:	83 ff 01             	cmp    edi,0x1
    705958809c22:	0f 97 c3             	seta   bl
    705958809c25:	81 fe 98 00 01 00    	cmp    esi,0x10098
    705958809c2b:	40 0f 94 c6          	sete   sil
    705958809c2f:	40 20 f3             	and    bl,sil
    705958809c32:	f6 c3 01             	test   bl,0x1
    705958809c35:	0f 45 c2             	cmovne eax,edx
    705958809c38:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    705958809c3e:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10428
    705958809c45:	04 01 00 
    705958809c48:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958809c4e:	83 c0 04             	add    eax,0x4
    705958809c51:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958809c55:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958809c5b:	0f 82 9a 00 00 00    	jb     0x705958809cfb
    705958809c61:	e9 b8 00 00 00       	jmp    0x705958809d1e
    705958809c66:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809c6b:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958809c72:	e9 b0 01 00 00       	jmp    0x705958809e27
    705958809c77:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958809c7e:	00 
    705958809c7f:	48 89 c1             	mov    rcx,rax
    705958809c82:	48 81 c1 00 06 08 00 	add    rcx,0x80600
    705958809c89:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    705958809c8e:	81 b8 00 06 08 00 c0 	cmp    DWORD PTR [rax+0x80600],0x100c0
    705958809c95:	00 01 00 
    705958809c98:	74 2f                	je     0x705958809cc9
    705958809c9a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809c9f:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x100c0
    705958809ca6:	00 01 00 
    705958809ca9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958809cb0:	00 00 00 
    705958809cb3:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958809cba:	00 00 00 
    705958809cbd:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    705958809cc4:	e9 5e 01 00 00       	jmp    0x705958809e27
    705958809cc9:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    705958809cce:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    705958809cd3:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958809cd8:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    705958809cdc:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    705958809ce3:	c0 00 01 00 
    705958809ce7:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958809cee:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958809cf2:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958809cf9:	ff e0                	jmp    rax
    705958809cfb:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958809d02:	00 
    705958809d03:	48 89 c1             	mov    rcx,rax
    705958809d06:	48 81 c1 40 21 08 00 	add    rcx,0x82140
    705958809d0d:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    705958809d12:	81 b8 40 21 08 00 28 	cmp    DWORD PTR [rax+0x82140],0x10428
    705958809d19:	04 01 00 
    705958809d1c:	74 2f                	je     0x705958809d4d
    705958809d1e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809d23:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10428
    705958809d2a:	04 01 00 
    705958809d2d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958809d34:	00 00 00 
    705958809d37:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    705958809d3e:	00 00 00 
    705958809d41:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    705958809d48:	e9 da 00 00 00       	jmp    0x705958809e27
    705958809d4d:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    705958809d52:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    705958809d57:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    705958809d5c:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    705958809d60:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    705958809d67:	28 04 01 00 
    705958809d6b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958809d72:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958809d76:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958809d7d:	ff e0                	jmp    rax
    705958809d7f:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    705958809d84:	8b 54 24 40          	mov    edx,DWORD PTR [rsp+0x40]
    705958809d88:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    705958809d8c:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    705958809d90:	89 c7                	mov    edi,eax
    705958809d92:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    705958809d96:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    705958809d9a:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    705958809d9e:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    705958809da4:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    705958809da8:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958809dae:	73 2d                	jae    0x705958809ddd
    705958809db0:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958809db7:	00 
    705958809db8:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    705958809dbc:	89 d1                	mov    ecx,edx
    705958809dbe:	c1 e9 01             	shr    ecx,0x1
    705958809dc1:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958809dc7:	89 c9                	mov    ecx,ecx
    705958809dc9:	48 c1 e1 04          	shl    rcx,0x4
    705958809dcd:	48 89 c6             	mov    rsi,rax
    705958809dd0:	48 01 ce             	add    rsi,rcx
    705958809dd3:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    705958809dd8:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958809ddb:	74 1b                	je     0x705958809df8
    705958809ddd:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958809de2:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    705958809de6:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    705958809dea:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    705958809df0:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    705958809df6:	eb 2f                	jmp    0x705958809e27
    705958809df8:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    705958809dfd:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    705958809e02:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958809e07:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    705958809e0b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958809e12:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958809e19:	00 
    705958809e1a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958809e1e:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958809e25:	ff e0                	jmp    rax
    705958809e27:	48 81 c4 98 00 00 00 	add    rsp,0x98
    705958809e2e:	c2 08 00             	ret    0x8
