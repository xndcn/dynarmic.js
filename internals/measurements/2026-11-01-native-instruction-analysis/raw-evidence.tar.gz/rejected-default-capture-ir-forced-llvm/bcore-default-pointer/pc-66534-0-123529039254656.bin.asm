
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66534-0-123529039254656.bin:     file format binary


Disassembly of section .data:

0000705958811480 <.data>:
    705958811480:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    705958811487:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    70595881148c:	4d 89 e9             	mov    r9,r13
    70595881148f:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    705958811496:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    70595881149d:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    7059588114a1:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    7059588114a5:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    7059588114a9:	45 8b 55 04          	mov    r10d,DWORD PTR [r13+0x4]
    7059588114ad:	41 8b 55 08          	mov    edx,DWORD PTR [r13+0x8]
    7059588114b1:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    7059588114b5:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    7059588114ba:	45 8b 7d 2c          	mov    r15d,DWORD PTR [r13+0x2c]
    7059588114be:	41 8b 4d 50          	mov    ecx,DWORD PTR [r13+0x50]
    7059588114c2:	45 8b 9d 9c 00 00 00 	mov    r11d,DWORD PTR [r13+0x9c]
    7059588114c9:	41 8b bd a0 00 00 00 	mov    edi,DWORD PTR [r13+0xa0]
    7059588114d0:	41 8b 85 a4 00 00 00 	mov    eax,DWORD PTR [r13+0xa4]
    7059588114d7:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    7059588114db:	41 8b ad bc 00 00 00 	mov    ebp,DWORD PTR [r13+0xbc]
    7059588114e2:	41 8b 85 e4 00 00 00 	mov    eax,DWORD PTR [r13+0xe4]
    7059588114e9:	89 04 24             	mov    DWORD PTR [rsp],eax
    7059588114ec:	41 8b b5 e8 00 00 00 	mov    esi,DWORD PTR [r13+0xe8]
    7059588114f3:	45 8b 85 ec 00 00 00 	mov    r8d,DWORD PTR [r13+0xec]
    7059588114fa:	41 8b 85 f0 00 00 00 	mov    eax,DWORD PTR [r13+0xf0]
    705958811501:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    705958811505:	41 8b 85 f8 00 00 00 	mov    eax,DWORD PTR [r13+0xf8]
    70595881150c:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    705958811510:	41 8b 85 fc 00 00 00 	mov    eax,DWORD PTR [r13+0xfc]
    705958811517:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    70595881151b:	45 8b b5 00 01 00 00 	mov    r14d,DWORD PTR [r13+0x100]
    705958811522:	41 8b 85 24 01 00 00 	mov    eax,DWORD PTR [r13+0x124]
    705958811529:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    70595881152d:	45 8b ad 34 01 00 00 	mov    r13d,DWORD PTR [r13+0x134]
    705958811534:	45 8b a1 5c 01 00 00 	mov    r12d,DWORD PTR [r9+0x15c]
    70595881153b:	48 89 7c 24 50       	mov    QWORD PTR [rsp+0x50],rdi
    705958811540:	81 c7 f1 fb fe ff    	add    edi,0xfffefbf1
    705958811546:	83 ff d6             	cmp    edi,0xffffffd6
    705958811549:	0f 87 13 0a 00 00    	ja     0x705958811f62
    70595881154f:	41 83 b9 80 00 00 00 	cmp    DWORD PTR [r9+0x80],0x0
    705958811556:	00 
    705958811557:	0f 85 05 0a 00 00    	jne    0x705958811f62
    70595881155d:	81 7c 24 30 fa 03 01 	cmp    DWORD PTR [rsp+0x30],0x103fa
    705958811564:	00 
    705958811565:	0f 85 f7 09 00 00    	jne    0x705958811f62
    70595881156b:	41 81 b9 94 00 00 00 	cmp    DWORD PTR [r9+0x94],0x103e6
    705958811572:	e6 03 01 00 
    705958811576:	0f 85 e6 09 00 00    	jne    0x705958811f62
    70595881157c:	49 8b 81 40 01 00 00 	mov    rax,QWORD PTR [r9+0x140]
    705958811583:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    705958811588:	49 8b 81 38 01 00 00 	mov    rax,QWORD PTR [r9+0x138]
    70595881158f:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958811594:	41 8b 41 20          	mov    eax,DWORD PTR [r9+0x20]
    705958811598:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    70595881159d:	41 8b 41 1c          	mov    eax,DWORD PTR [r9+0x1c]
    7059588115a1:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    7059588115a6:	41 8b 41 0c          	mov    eax,DWORD PTR [r9+0xc]
    7059588115aa:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    7059588115ae:	41 8b 41 18          	mov    eax,DWORD PTR [r9+0x18]
    7059588115b2:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    7059588115b6:	48 89 9c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rbx
    7059588115bd:	00 
    7059588115be:	66 90                	xchg   ax,ax
    7059588115c0:	44 89 f0             	mov    eax,r14d
    7059588115c3:	89 d6                	mov    esi,edx
    7059588115c5:	0f af 74 24 48       	imul   esi,DWORD PTR [rsp+0x48]
    7059588115ca:	48 8b 54 24 78       	mov    rdx,QWORD PTR [rsp+0x78]
    7059588115cf:	8d 3c 16             	lea    edi,[rsi+rdx*1]
    7059588115d2:	c1 ee 1f             	shr    esi,0x1f
    7059588115d5:	c1 ea 1f             	shr    edx,0x1f
    7059588115d8:	41 89 fe             	mov    r14d,edi
    7059588115db:	41 c1 ee 1f          	shr    r14d,0x1f
    7059588115df:	44 31 f2             	xor    edx,r14d
    7059588115e2:	41 31 f6             	xor    r14d,esi
    7059588115e5:	41 21 d6             	and    r14d,edx
    7059588115e8:	41 09 c6             	or     r14d,eax
    7059588115eb:	89 fb                	mov    ebx,edi
    7059588115ed:	c1 eb 08             	shr    ebx,0x8
    7059588115f0:	31 c0                	xor    eax,eax
    7059588115f2:	23 5c 24 4c          	and    ebx,DWORD PTR [rsp+0x4c]
    7059588115f6:	0f 94 c0             	sete   al
    7059588115f9:	89 04 24             	mov    DWORD PTR [rsp],eax
    7059588115fc:	f6 c1 03             	test   cl,0x3
    7059588115ff:	0f 85 e6 02 00 00    	jne    0x7059588118eb
    705958811605:	89 c8                	mov    eax,ecx
    705958811607:	c1 e8 0c             	shr    eax,0xc
    70595881160a:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    70595881160f:	48 8b 04 c6          	mov    rax,QWORD PTR [rsi+rax*8]
    705958811613:	48 85 c0             	test   rax,rax
    705958811616:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    70595881161a:	0f 84 72 03 00 00    	je     0x705958811992
    705958811620:	89 ca                	mov    edx,ecx
    705958811622:	81 e2 ff 0f 00 00    	and    edx,0xfff
    705958811628:	8b 04 10             	mov    eax,DWORD PTR [rax+rdx*1]
    70595881162b:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    70595881162f:	83 c1 04             	add    ecx,0x4
    705958811632:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    705958811637:	8d 2c 98             	lea    ebp,[rax+rbx*4]
    70595881163a:	40 f6 c5 03          	test   bpl,0x3
    70595881163e:	0f 85 2e 04 00 00    	jne    0x705958811a72
    705958811644:	89 e8                	mov    eax,ebp
    705958811646:	c1 e8 0c             	shr    eax,0xc
    705958811649:	48 8b 1c c6          	mov    rbx,QWORD PTR [rsi+rax*8]
    70595881164d:	41 89 ed             	mov    r13d,ebp
    705958811650:	41 81 e5 ff 0f 00 00 	and    r13d,0xfff
    705958811657:	48 85 db             	test   rbx,rbx
    70595881165a:	48 89 6c 24 28       	mov    QWORD PTR [rsp+0x28],rbp
    70595881165f:	0f 84 97 05 00 00    	je     0x705958811bfc
    705958811665:	46 8b 14 2b          	mov    r10d,DWORD PTR [rbx+r13*1]
    705958811669:	41 f6 c7 03          	test   r15b,0x3
    70595881166d:	0f 85 6b 06 00 00    	jne    0x705958811cde
    705958811673:	44 89 f8             	mov    eax,r15d
    705958811676:	c1 e8 0c             	shr    eax,0xc
    705958811679:	48 8b 04 c6          	mov    rax,QWORD PTR [rsi+rax*8]
    70595881167d:	48 85 c0             	test   rax,rax
    705958811680:	0f 84 0c 07 00 00    	je     0x705958811d92
    705958811686:	44 89 fa             	mov    edx,r15d
    705958811689:	81 e2 ff 0f 00 00    	and    edx,0xfff
    70595881168f:	44 89 14 10          	mov    DWORD PTR [rax+rdx*1],r10d
    705958811693:	41 83 c7 04          	add    r15d,0x4
    705958811697:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595881169c:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595881169f:	0f 85 d9 07 00 00    	jne    0x705958811e7e
    7059588116a5:	48 85 db             	test   rbx,rbx
    7059588116a8:	0f 84 cc 08 00 00    	je     0x705958811f7a
    7059588116ae:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    7059588116b2:	42 89 04 2b          	mov    DWORD PTR [rbx+r13*1],eax
    7059588116b6:	41 83 fb 02          	cmp    r11d,0x2
    7059588116ba:	0f 82 d5 00 00 00    	jb     0x705958811795
    7059588116c0:	41 ff cb             	dec    r11d
    7059588116c3:	c7 44 24 30 fa 03 01 	mov    DWORD PTR [rsp+0x30],0x103fa
    7059588116ca:	00 
    7059588116cb:	bd e6 03 01 00       	mov    ebp,0x103e6
    7059588116d0:	c7 44 24 10 00 00 00 	mov    DWORD PTR [rsp+0x10],0x0
    7059588116d7:	00 
    7059588116d8:	c7 44 24 3c 02 00 00 	mov    DWORD PTR [rsp+0x3c],0x2
    7059588116df:	00 
    7059588116e0:	bb 0a 00 00 00       	mov    ebx,0xa
    7059588116e5:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    7059588116ea:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7059588116ed:	0f 85 11 0a 00 00    	jne    0x705958812104
    7059588116f3:	b0 01                	mov    al,0x1
    7059588116f5:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    7059588116f9:	44 89 e7             	mov    edi,r12d
    7059588116fc:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    705958811703:	00 
    705958811704:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    70595881170b:	00 
    70595881170c:	45 31 c0             	xor    r8d,r8d
    70595881170f:	31 f6                	xor    esi,esi
    705958811711:	49 89 dd             	mov    r13,rbx
    705958811714:	44 8d 24 3b          	lea    r12d,[rbx+rdi*1]
    705958811718:	44 3b 64 24 6c       	cmp    r12d,DWORD PTR [rsp+0x6c]
    70595881171d:	0f 83 35 09 00 00    	jae    0x705958812058
    705958811723:	41 8b 99 58 01 00 00 	mov    ebx,DWORD PTR [r9+0x158]
    70595881172a:	85 db                	test   ebx,ebx
    70595881172c:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    705958811730:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958811737:	00 
    705958811738:	0f 84 1e 09 00 00    	je     0x70595881205c
    70595881173e:	81 fd e6 03 01 00    	cmp    ebp,0x103e6
    705958811744:	0f 85 db 00 00 00    	jne    0x705958811825
    70595881174a:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    70595881174f:	8d b8 f1 fb fe ff    	lea    edi,[rax-0x1040f]
    705958811755:	bd e6 03 01 00       	mov    ebp,0x103e6
    70595881175a:	83 ff d6             	cmp    edi,0xffffffd6
    70595881175d:	0f 87 ff 07 00 00    	ja     0x705958811f62
    705958811763:	41 83 b9 80 00 00 00 	cmp    DWORD PTR [r9+0x80],0x0
    70595881176a:	00 
    70595881176b:	0f 85 f1 07 00 00    	jne    0x705958811f62
    705958811771:	81 7c 24 30 fa 03 01 	cmp    DWORD PTR [rsp+0x30],0x103fa
    705958811778:	00 
    705958811779:	0f 85 e3 07 00 00    	jne    0x705958811f62
    70595881177f:	41 81 b9 94 00 00 00 	cmp    DWORD PTR [r9+0x94],0x103e6
    705958811786:	e6 03 01 00 
    70595881178a:	0f 84 30 fe ff ff    	je     0x7059588115c0
    705958811790:	e9 cd 07 00 00       	jmp    0x705958811f62
    705958811795:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595881179a:	80 38 00             	cmp    BYTE PTR [rax],0x0
    70595881179d:	0f 85 ac e8 fe 17    	jne    0x70597080004f
    7059588117a3:	41 c7 41 28 00 20 00 	mov    DWORD PTR [r9+0x28],0x2000
    7059588117aa:	00 
    7059588117ab:	41 c7 81 94 00 00 00 	mov    DWORD PTR [r9+0x94],0x10412
    7059588117b2:	12 04 01 00 
    7059588117b6:	81 7c 24 50 0e 04 01 	cmp    DWORD PTR [rsp+0x50],0x1040e
    7059588117bd:	00 
    7059588117be:	0f 84 5d e9 fe 17    	je     0x705970800121
    7059588117c4:	c7 44 24 08 ff 1f 00 	mov    DWORD PTR [rsp+0x8],0x1fff
    7059588117cb:	00 
    7059588117cc:	41 bf fc 12 01 00    	mov    r15d,0x112fc
    7059588117d2:	41 bb 00 20 00 00    	mov    r11d,0x2000
    7059588117d8:	c7 44 24 30 20 04 01 	mov    DWORD PTR [rsp+0x30],0x10420
    7059588117df:	00 
    7059588117e0:	bd 12 04 01 00       	mov    ebp,0x10412
    7059588117e5:	c7 44 24 10 00 00 00 	mov    DWORD PTR [rsp+0x10],0x0
    7059588117ec:	00 
    7059588117ed:	c7 44 24 3c 04 00 00 	mov    DWORD PTR [rsp+0x3c],0x4
    7059588117f4:	00 
    7059588117f5:	b0 01                	mov    al,0x1
    7059588117f7:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    7059588117fb:	bb 10 00 00 00       	mov    ebx,0x10
    705958811800:	44 89 e7             	mov    edi,r12d
    705958811803:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    70595881180a:	00 
    70595881180b:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    705958811812:	00 
    705958811813:	45 31 c0             	xor    r8d,r8d
    705958811816:	31 f6                	xor    esi,esi
    705958811818:	c7 44 24 04 00 00 00 	mov    DWORD PTR [rsp+0x4],0x0
    70595881181f:	00 
    705958811820:	e9 ec fe ff ff       	jmp    0x705958811711
    705958811825:	8d 1c ed 00 00 00 00 	lea    ebx,[rbp*8+0x0]
    70595881182c:	81 e3 f0 ff 0f 00    	and    ebx,0xffff0
    705958811832:	39 2c 18             	cmp    DWORD PTR [rax+rbx*1],ebp
    705958811835:	0f 85 21 08 00 00    	jne    0x70595881205c
    70595881183b:	48 8b 7c 18 08       	mov    rdi,QWORD PTR [rax+rbx*1+0x8]
    705958811840:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811844:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811847:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    70595881184b:	41 89 51 08          	mov    DWORD PTR [r9+0x8],edx
    70595881184f:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    705958811854:	41 89 51 24          	mov    DWORD PTR [r9+0x24],edx
    705958811858:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    70595881185c:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811860:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811867:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    70595881186b:	41 89 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],eax
    705958811872:	41 89 a9 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],ebp
    705958811879:	8b 0c 24             	mov    ecx,DWORD PTR [rsp]
    70595881187c:	41 89 89 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],ecx
    705958811883:	41 89 b1 e8 00 00 00 	mov    DWORD PTR [r9+0xe8],esi
    70595881188a:	45 89 81 ec 00 00 00 	mov    DWORD PTR [r9+0xec],r8d
    705958811891:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    705958811895:	41 89 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],eax
    70595881189c:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    7059588118a0:	41 89 81 f8 00 00 00 	mov    DWORD PTR [r9+0xf8],eax
    7059588118a7:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    7059588118ab:	41 89 81 fc 00 00 00 	mov    DWORD PTR [r9+0xfc],eax
    7059588118b2:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    7059588118b9:	8b 44 24 3c          	mov    eax,DWORD PTR [rsp+0x3c]
    7059588118bd:	41 89 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],eax
    7059588118c4:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    7059588118cb:	00 
    7059588118cc:	45 89 a9 34 01 00 00 	mov    DWORD PTR [r9+0x134],r13d
    7059588118d3:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    7059588118da:	4d 89 cd             	mov    r13,r9
    7059588118dd:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    7059588118e2:	48 81 c4 88 00 00 00 	add    rsp,0x88
    7059588118e9:	ff e7                	jmp    rdi
    7059588118eb:	41 89 19             	mov    DWORD PTR [r9],ebx
    7059588118ee:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    7059588118f2:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    7059588118f6:	41 89 59 24          	mov    DWORD PTR [r9+0x24],ebx
    7059588118fa:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    7059588118fe:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811902:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811909:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811910:	fa 03 01 00 
    705958811914:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f2
    70595881191b:	f2 03 01 00 
    70595881191f:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811922:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811929:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811930:	00 00 00 00 
    705958811934:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    70595881193b:	00 00 00 00 
    70595881193f:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811946:	00 00 00 00 
    70595881194a:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811951:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811958:	02 00 00 00 
    70595881195c:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811963:	00 
    705958811964:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x6
    70595881196b:	06 00 00 00 
    70595881196f:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811976:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595881197d:	63 00 00 
    705958811980:	4c 89 cf             	mov    rdi,r9
    705958811983:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    705958811988:	ba f2 03 01 00       	mov    edx,0x103f2
    70595881198d:	e9 88 01 00 00       	jmp    0x705958811b1a
    705958811992:	41 89 19             	mov    DWORD PTR [r9],ebx
    705958811995:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811999:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    70595881199d:	41 89 59 24          	mov    DWORD PTR [r9+0x24],ebx
    7059588119a1:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    7059588119a5:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    7059588119a9:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    7059588119b0:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    7059588119b7:	fa 03 01 00 
    7059588119bb:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f2
    7059588119c2:	f2 03 01 00 
    7059588119c6:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    7059588119c9:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    7059588119d0:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    7059588119d7:	00 00 00 00 
    7059588119db:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    7059588119e2:	00 00 00 00 
    7059588119e6:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    7059588119ed:	00 00 00 00 
    7059588119f1:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    7059588119f8:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    7059588119ff:	02 00 00 00 
    705958811a03:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811a0a:	00 
    705958811a0b:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x6
    705958811a12:	06 00 00 00 
    705958811a16:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811a1d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958811a24:	63 00 00 
    705958811a27:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    705958811a2c:	89 ce                	mov    esi,ecx
    705958811a2e:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    705958811a33:	48 89 cd             	mov    rbp,rcx
    705958811a36:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    705958811a3b:	45 89 dd             	mov    r13d,r11d
    705958811a3e:	ff d0                	call   rax
    705958811a40:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    705958811a45:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    705958811a4a:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    705958811a4e:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    705958811a55:	00 
    705958811a56:	84 d2                	test   dl,dl
    705958811a58:	0f 85 cf 00 00 00    	jne    0x705958811b2d
    705958811a5e:	45 89 eb             	mov    r11d,r13d
    705958811a61:	48 89 e9             	mov    rcx,rbp
    705958811a64:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    705958811a68:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    705958811a6d:	e9 bd fb ff ff       	jmp    0x70595881162f
    705958811a72:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811a76:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811a79:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811a7d:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    705958811a81:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    705958811a85:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811a89:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811a8d:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811a94:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811a9b:	fa 03 01 00 
    705958811a9f:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f6
    705958811aa6:	f6 03 01 00 
    705958811aaa:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811aad:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811ab4:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811abb:	00 00 00 00 
    705958811abf:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811ac6:	00 00 00 00 
    705958811aca:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811ad1:	00 00 00 00 
    705958811ad5:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811adc:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811ae3:	02 00 00 00 
    705958811ae7:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811aee:	00 
    705958811aef:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x8
    705958811af6:	08 00 00 00 
    705958811afa:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811b01:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958811b08:	63 00 00 
    705958811b0b:	4c 89 cf             	mov    rdi,r9
    705958811b0e:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    705958811b13:	ba f6 03 01 00       	mov    edx,0x103f6
    705958811b18:	89 e9                	mov    ecx,ebp
    705958811b1a:	45 31 c0             	xor    r8d,r8d
    705958811b1d:	4d 89 cd             	mov    r13,r9
    705958811b20:	ff d0                	call   rax
    705958811b22:	4d 89 e9             	mov    r9,r13
    705958811b25:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    705958811b2c:	00 
    705958811b2d:	41 8b 01             	mov    eax,DWORD PTR [r9]
    705958811b30:	89 44 24 04          	mov    DWORD PTR [rsp+0x4],eax
    705958811b34:	45 8b 51 04          	mov    r10d,DWORD PTR [r9+0x4]
    705958811b38:	41 8b 41 08          	mov    eax,DWORD PTR [r9+0x8]
    705958811b3c:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    705958811b40:	41 8b 41 0c          	mov    eax,DWORD PTR [r9+0xc]
    705958811b44:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958811b48:	41 8b 41 18          	mov    eax,DWORD PTR [r9+0x18]
    705958811b4c:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    705958811b50:	41 8b 41 1c          	mov    eax,DWORD PTR [r9+0x1c]
    705958811b54:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    705958811b59:	41 8b 41 20          	mov    eax,DWORD PTR [r9+0x20]
    705958811b5d:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    705958811b62:	41 8b 41 24          	mov    eax,DWORD PTR [r9+0x24]
    705958811b66:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    705958811b6b:	45 8b 79 2c          	mov    r15d,DWORD PTR [r9+0x2c]
    705958811b6f:	41 8b 49 50          	mov    ecx,DWORD PTR [r9+0x50]
    705958811b73:	45 8b 99 9c 00 00 00 	mov    r11d,DWORD PTR [r9+0x9c]
    705958811b7a:	41 8b 81 a0 00 00 00 	mov    eax,DWORD PTR [r9+0xa0]
    705958811b81:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    705958811b86:	41 8b 81 a4 00 00 00 	mov    eax,DWORD PTR [r9+0xa4]
    705958811b8d:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    705958811b91:	41 8b a9 bc 00 00 00 	mov    ebp,DWORD PTR [r9+0xbc]
    705958811b98:	89 d0                	mov    eax,edx
    705958811b9a:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    705958811b9e:	41 8b 81 e4 00 00 00 	mov    eax,DWORD PTR [r9+0xe4]
    705958811ba5:	89 04 24             	mov    DWORD PTR [rsp],eax
    705958811ba8:	41 8b b1 e8 00 00 00 	mov    esi,DWORD PTR [r9+0xe8]
    705958811baf:	45 8b 81 ec 00 00 00 	mov    r8d,DWORD PTR [r9+0xec]
    705958811bb6:	41 8b 81 f0 00 00 00 	mov    eax,DWORD PTR [r9+0xf0]
    705958811bbd:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    705958811bc1:	41 8b 81 f8 00 00 00 	mov    eax,DWORD PTR [r9+0xf8]
    705958811bc8:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    705958811bcc:	41 8b 81 fc 00 00 00 	mov    eax,DWORD PTR [r9+0xfc]
    705958811bd3:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    705958811bd7:	45 8b b1 00 01 00 00 	mov    r14d,DWORD PTR [r9+0x100]
    705958811bde:	41 8b 81 24 01 00 00 	mov    eax,DWORD PTR [r9+0x124]
    705958811be5:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    705958811be9:	41 8b 99 34 01 00 00 	mov    ebx,DWORD PTR [r9+0x134]
    705958811bf0:	41 8b b9 5c 01 00 00 	mov    edi,DWORD PTR [r9+0x15c]
    705958811bf7:	e9 15 fb ff ff       	jmp    0x705958811711
    705958811bfc:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811c00:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811c03:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811c07:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    705958811c0b:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    705958811c0f:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811c13:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811c17:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811c1e:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811c25:	fa 03 01 00 
    705958811c29:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f6
    705958811c30:	f6 03 01 00 
    705958811c34:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811c37:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811c3e:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811c45:	00 00 00 00 
    705958811c49:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811c50:	00 00 00 00 
    705958811c54:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811c5b:	00 00 00 00 
    705958811c5f:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811c66:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811c6d:	02 00 00 00 
    705958811c71:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811c78:	00 
    705958811c79:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x8
    705958811c80:	08 00 00 00 
    705958811c84:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811c8b:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958811c92:	63 00 00 
    705958811c95:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    705958811c9a:	89 ee                	mov    esi,ebp
    705958811c9c:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    705958811ca1:	48 89 cd             	mov    rbp,rcx
    705958811ca4:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    705958811ca9:	ff d0                	call   rax
    705958811cab:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    705958811cb0:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    705958811cb5:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    705958811cbc:	00 
    705958811cbd:	84 d2                	test   dl,dl
    705958811cbf:	0f 85 68 fe ff ff    	jne    0x705958811b2d
    705958811cc5:	48 89 e9             	mov    rcx,rbp
    705958811cc8:	41 89 c2             	mov    r10d,eax
    705958811ccb:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    705958811ccf:	48 8b 6c 24 28       	mov    rbp,QWORD PTR [rsp+0x28]
    705958811cd4:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
    705958811cd9:	e9 8b f9 ff ff       	jmp    0x705958811669
    705958811cde:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811ce2:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811ce5:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811ce9:	41 89 79 08          	mov    DWORD PTR [r9+0x8],edi
    705958811ced:	41 89 69 24          	mov    DWORD PTR [r9+0x24],ebp
    705958811cf1:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811cf5:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811cf9:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811d00:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811d07:	fa 03 01 00 
    705958811d0b:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f8
    705958811d12:	f8 03 01 00 
    705958811d16:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811d19:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811d20:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811d27:	00 00 00 00 
    705958811d2b:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811d32:	00 00 00 00 
    705958811d36:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811d3d:	00 00 00 00 
    705958811d41:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811d48:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811d4f:	02 00 00 00 
    705958811d53:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811d5a:	00 
    705958811d5b:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    705958811d62:	09 00 00 00 
    705958811d66:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811d6d:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958811d74:	63 00 00 
    705958811d77:	4c 89 cf             	mov    rdi,r9
    705958811d7a:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    705958811d7f:	ba f8 03 01 00       	mov    edx,0x103f8
    705958811d84:	44 89 f9             	mov    ecx,r15d
    705958811d87:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958811d8d:	e9 8b fd ff ff       	jmp    0x705958811b1d
    705958811d92:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811d96:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811d99:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811d9d:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    705958811da1:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    705958811da5:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958811daa:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    705958811dae:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811db2:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811db6:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811dbd:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811dc4:	fa 03 01 00 
    705958811dc8:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103f8
    705958811dcf:	f8 03 01 00 
    705958811dd3:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811dd6:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811ddd:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811de4:	00 00 00 00 
    705958811de8:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811def:	00 00 00 00 
    705958811df3:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811dfa:	00 00 00 00 
    705958811dfe:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811e05:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811e0c:	02 00 00 00 
    705958811e10:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811e17:	00 
    705958811e18:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    705958811e1f:	09 00 00 00 
    705958811e23:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811e2a:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958811e31:	63 00 00 
    705958811e34:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    705958811e39:	44 89 fe             	mov    esi,r15d
    705958811e3c:	44 89 d2             	mov    edx,r10d
    705958811e3f:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    705958811e44:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    705958811e49:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    705958811e4e:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    705958811e53:	ff d0                	call   rax
    705958811e55:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    705958811e5a:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    705958811e5f:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    705958811e64:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    705958811e69:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    705958811e70:	00 
    705958811e71:	84 d2                	test   dl,dl
    705958811e73:	0f 84 1a f8 ff ff    	je     0x705958811693
    705958811e79:	e9 af fc ff ff       	jmp    0x705958811b2d
    705958811e7e:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958811e82:	41 89 01             	mov    DWORD PTR [r9],eax
    705958811e85:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811e89:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    705958811e8d:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    705958811e91:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958811e96:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    705958811e9a:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811e9e:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811ea2:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811ea9:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811eb0:	fa 03 01 00 
    705958811eb4:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fa
    705958811ebb:	fa 03 01 00 
    705958811ebf:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811ec2:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811ec9:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811ed0:	00 00 00 00 
    705958811ed4:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811edb:	00 00 00 00 
    705958811edf:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811ee6:	00 00 00 00 
    705958811eea:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811ef1:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811ef8:	02 00 00 00 
    705958811efc:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811f03:	00 
    705958811f04:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x9
    705958811f0b:	09 00 00 00 
    705958811f0f:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958811f16:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958811f1d:	63 00 00 
    705958811f20:	4c 89 cf             	mov    rdi,r9
    705958811f23:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    705958811f28:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    705958811f2d:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    705958811f32:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    705958811f37:	ff d0                	call   rax
    705958811f39:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    705958811f3e:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    705958811f43:	48 8b 4c 24 30       	mov    rcx,QWORD PTR [rsp+0x30]
    705958811f48:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    705958811f4d:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    705958811f54:	00 
    705958811f55:	84 d2                	test   dl,dl
    705958811f57:	0f 84 48 f7 ff ff    	je     0x7059588116a5
    705958811f5d:	e9 cb fb ff ff       	jmp    0x705958811b2d
    705958811f62:	41 c6 81 65 01 00 00 	mov    BYTE PTR [r9+0x165],0x1
    705958811f69:	01 
    705958811f6a:	c7 44 24 38 00 00 00 	mov    DWORD PTR [rsp+0x38],0x0
    705958811f71:	00 
    705958811f72:	44 89 e7             	mov    edi,r12d
    705958811f75:	e9 e2 00 00 00       	jmp    0x70595881205c
    705958811f7a:	8b 54 24 04          	mov    edx,DWORD PTR [rsp+0x4]
    705958811f7e:	41 89 11             	mov    DWORD PTR [r9],edx
    705958811f81:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958811f85:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    705958811f89:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    705958811f8d:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    705958811f92:	41 89 71 24          	mov    DWORD PTR [r9+0x24],esi
    705958811f96:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958811f9a:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958811f9e:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958811fa5:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705958811fac:	fa 03 01 00 
    705958811fb0:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fa
    705958811fb7:	fa 03 01 00 
    705958811fbb:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811fbe:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958811fc5:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    705958811fcc:	00 00 00 00 
    705958811fd0:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958811fd7:	00 00 00 00 
    705958811fdb:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958811fe2:	00 00 00 00 
    705958811fe6:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    705958811fed:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958811ff4:	02 00 00 00 
    705958811ff8:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    705958811fff:	00 
    705958812000:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    705958812007:	0a 00 00 00 
    70595881200b:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    705958812012:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958812019:	63 00 00 
    70595881201c:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    705958812021:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    705958812026:	48 89 cb             	mov    rbx,rcx
    705958812029:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    70595881202e:	44 89 dd             	mov    ebp,r11d
    705958812031:	ff d0                	call   rax
    705958812033:	41 89 eb             	mov    r11d,ebp
    705958812036:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    70595881203b:	48 89 d9             	mov    rcx,rbx
    70595881203e:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    705958812043:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    70595881204a:	00 
    70595881204b:	84 d2                	test   dl,dl
    70595881204d:	0f 84 63 f6 ff ff    	je     0x7059588116b6
    705958812053:	e9 d5 fa ff ff       	jmp    0x705958811b2d
    705958812058:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    70595881205c:	8b 1c 24             	mov    ebx,DWORD PTR [rsp]
    70595881205f:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    705958812064:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958812068:	41 89 01             	mov    DWORD PTR [r9],eax
    70595881206b:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    70595881206f:	41 89 51 08          	mov    DWORD PTR [r9+0x8],edx
    705958812073:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
    705958812078:	41 89 51 24          	mov    DWORD PTR [r9+0x24],edx
    70595881207c:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    705958812080:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705958812084:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    70595881208b:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    70595881208f:	41 89 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],eax
    705958812096:	41 89 a9 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],ebp
    70595881209d:	41 89 99 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],ebx
    7059588120a4:	41 89 b1 e8 00 00 00 	mov    DWORD PTR [r9+0xe8],esi
    7059588120ab:	45 89 81 ec 00 00 00 	mov    DWORD PTR [r9+0xec],r8d
    7059588120b2:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    7059588120b6:	41 89 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],eax
    7059588120bd:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    7059588120c1:	41 89 81 f8 00 00 00 	mov    DWORD PTR [r9+0xf8],eax
    7059588120c8:	45 89 a1 fc 00 00 00 	mov    DWORD PTR [r9+0xfc],r12d
    7059588120cf:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    7059588120d6:	8b 44 24 3c          	mov    eax,DWORD PTR [rsp+0x3c]
    7059588120da:	41 89 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],eax
    7059588120e1:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    7059588120e5:	41 88 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],al
    7059588120ec:	45 89 a9 34 01 00 00 	mov    DWORD PTR [r9+0x134],r13d
    7059588120f3:	41 89 b9 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],edi
    7059588120fa:	48 81 c4 88 00 00 00 	add    rsp,0x88
    705958812101:	c2 08 00             	ret    0x8
    705958812104:	b0 01                	mov    al,0x1
    705958812106:	89 44 24 38          	mov    DWORD PTR [rsp+0x38],eax
    70595881210a:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    70595881210e:	41 89 01             	mov    DWORD PTR [r9],eax
    705958812111:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    705958812115:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    705958812119:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    70595881211d:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958812122:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    705958812126:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    70595881212a:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    70595881212e:	45 89 99 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],r11d
    705958812135:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    70595881213c:	fa 03 01 00 
    705958812140:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103e6
    705958812147:	e6 03 01 00 
    70595881214b:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    70595881214e:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705958812155:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    70595881215c:	00 00 00 00 
    705958812160:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705958812167:	00 00 00 00 
    70595881216b:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705958812172:	00 00 00 00 
    705958812176:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    70595881217d:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    705958812184:	02 00 00 00 
    705958812188:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x1
    70595881218f:	01 
    705958812190:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    705958812197:	0a 00 00 00 
    70595881219b:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    7059588121a2:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059588121a9:	63 00 00 
    7059588121ac:	4c 89 cf             	mov    rdi,r9
    7059588121af:	4c 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],r9
    7059588121b4:	48 89 cb             	mov    rbx,rcx
    7059588121b7:	44 89 54 24 0c       	mov    DWORD PTR [rsp+0xc],r10d
    7059588121bc:	44 89 5c 24 14       	mov    DWORD PTR [rsp+0x14],r11d
    7059588121c1:	ff d0                	call   rax
    7059588121c3:	44 8b 5c 24 14       	mov    r11d,DWORD PTR [rsp+0x14]
    7059588121c8:	44 8b 54 24 0c       	mov    r10d,DWORD PTR [rsp+0xc]
    7059588121cd:	48 89 d9             	mov    rcx,rbx
    7059588121d0:	bb 0a 00 00 00       	mov    ebx,0xa
    7059588121d5:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
    7059588121da:	41 0f b6 91 28 01 00 	movzx  edx,BYTE PTR [r9+0x128]
    7059588121e1:	00 
    7059588121e2:	44 89 e7             	mov    edi,r12d
    7059588121e5:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [rsp+0x1c],0x0
    7059588121ec:	00 
    7059588121ed:	c7 44 24 18 00 00 00 	mov    DWORD PTR [rsp+0x18],0x0
    7059588121f4:	00 
    7059588121f5:	41 b8 00 00 00 00    	mov    r8d,0x0
    7059588121fb:	be 00 00 00 00       	mov    esi,0x0
    705958812200:	84 d2                	test   dl,dl
    705958812202:	0f 84 09 f5 ff ff    	je     0x705958811711
    705958812208:	e9 20 f9 ff ff       	jmp    0x705958811b2d
