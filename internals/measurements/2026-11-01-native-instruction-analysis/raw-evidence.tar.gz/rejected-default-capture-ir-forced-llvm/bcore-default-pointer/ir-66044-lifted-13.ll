; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000101fc(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66044
  %6 = icmp ugt i32 %5, 58
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb120 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb120, 66592
  %11 = sub i32 %guard_lb120, 66044
  %12 = icmp ugt i32 %11, 58
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000101fc_entry, label %lb_guard_miss, !prof !0

insn_0x000101fc_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table159 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table159, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 52
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 43125
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000101fc_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 13, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000101fc_entry, %28
  br label %insn_0x000101fc

insn_0x000101fc:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 28
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000101fc
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66044, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 188
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  %40 = load i8, ptr %39, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000101fc
  %41 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %41 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %42 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %42 to i64
  %43 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %43, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %45, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %46 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %46, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %47 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %49, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %50 = icmp ne i8 %cec_pending, 0
  br i1 %50, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %51 = getelementptr i8, ptr %cpu, i64 188
  %next_pc121 = load i32, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 188
  %53 = load i32, ptr %52, align 4
  %54 = getelementptr i8, ptr %cpu, i64 296
  %55 = load i8, ptr %54, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %56 = getelementptr i8, ptr %cpu, i32 188
  store i32 66046, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %58, align 4
  call void @cec_check_pending(ptr %cpu)
  %59 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %59, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x000101fe_entry

did_jump_exit1:                                   ; preds = %cec_check
  %60 = getelementptr i8, ptr %cpu, i64 188
  %next_pc122 = load i32, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 188
  %62 = load i32, ptr %61, align 4
  %63 = getelementptr i8, ptr %cpu, i64 296
  %64 = load i8, ptr %63, align 1
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x000101fe_entry:                            ; preds = %cec_checked
  br label %insn_0x000101fe

insn_0x000101fe:                                  ; preds = %insn_0x000101fe_entry
  %65 = getelementptr i8, ptr %cpu, i32 8
  store i32 8191, ptr %65, align 4
  br label %insn_0x00010202_entry

insn_0x00010202_entry:                            ; preds = %insn_0x000101fe
  br label %insn_0x00010202

insn_0x00010202:                                  ; preds = %insn_0x00010202_entry
  %66 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %67, align 4
  %sp1 = sub i32 %sp_dec, 4
  %68 = and i32 %sp1, 3
  %69 = icmp ne i32 %68, 0
  br i1 %69, label %data_misaligned5, label %data_aligned6, !prof !1

data_misaligned5:                                 ; preds = %insn_0x00010202
  %70 = getelementptr i8, ptr %cpu, i32 188
  store i32 66050, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %72, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66050, i32 %sp1, i32 65536)
  %73 = getelementptr i8, ptr %cpu, i64 188
  %next_pc123 = load i32, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 188
  %75 = load i32, ptr %74, align 4
  %76 = getelementptr i8, ptr %cpu, i64 296
  %77 = load i8, ptr %76, align 1
  br label %chain_exit

data_aligned6:                                    ; preds = %insn_0x00010202
  %78 = lshr i32 %sp1, 12
  %page_index10 = zext i32 %78 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13 = icmp ne ptr %page12, null
  br i1 %page_mapped13, label %page_wr_fast7, label %page_wr_slow8, !prof !0

page_wr_fast7:                                    ; preds = %data_aligned6
  %79 = and i32 %sp1, 4095
  %page_offset14 = zext i32 %79 to i64
  %80 = getelementptr i8, ptr %page12, i64 %page_offset14
  store i32 %rets, ptr %80, align 4
  br label %page_wr_done9

page_wr_slow8:                                    ; preds = %data_aligned6
  %81 = getelementptr i8, ptr %cpu, i32 188
  store i32 66050, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %83, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %84 = getelementptr i8, ptr %cpu, i32 296
  %dj17 = load i8, ptr %84, align 1
  %dj_set18 = icmp ne i8 %dj17, 0
  br i1 %dj_set18, label %did_jump_exit15, label %did_jump_cont16, !prof !1

page_wr_done9:                                    ; preds = %did_jump_cont16, %page_wr_fast7
  %sp2 = sub i32 %sp1, 4
  %85 = and i32 %sp2, 3
  %86 = icmp ne i32 %85, 0
  br i1 %86, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit15:                                  ; preds = %page_wr_slow8
  %87 = getelementptr i8, ptr %cpu, i64 188
  %next_pc124 = load i32, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i64 188
  %89 = load i32, ptr %88, align 4
  %90 = getelementptr i8, ptr %cpu, i64 296
  %91 = load i8, ptr %90, align 1
  br label %chain_exit

did_jump_cont16:                                  ; preds = %page_wr_slow8
  br label %page_wr_done9

data_misaligned19:                                ; preds = %page_wr_done9
  %92 = getelementptr i8, ptr %cpu, i32 188
  store i32 66050, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %94, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66050, i32 %sp2, i32 65536)
  %95 = getelementptr i8, ptr %cpu, i64 188
  %next_pc125 = load i32, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 188
  %97 = load i32, ptr %96, align 4
  %98 = getelementptr i8, ptr %cpu, i64 296
  %99 = load i8, ptr %98, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_wr_done9
  %100 = lshr i32 %sp2, 12
  %page_index24 = zext i32 %100 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast21, label %page_wr_slow22, !prof !0

page_wr_fast21:                                   ; preds = %data_aligned20
  %101 = and i32 %sp2, 4095
  %page_offset28 = zext i32 %101 to i64
  %102 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %fp, ptr %102, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %data_aligned20
  %103 = getelementptr i8, ptr %cpu, i32 188
  store i32 66050, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %105, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %106 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %106, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done23:                                   ; preds = %did_jump_cont30, %page_wr_fast21
  %107 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %107, align 4
  %sp3 = sub i32 %sp2, 0
  %108 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %108, align 4
  %cec_pending33 = load i8, ptr %cec_pending_flag, align 1
  %109 = icmp ne i8 %cec_pending33, 0
  br i1 %109, label %cec_check34, label %cec_checked35, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %110 = getelementptr i8, ptr %cpu, i64 188
  %next_pc126 = load i32, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i64 188
  %112 = load i32, ptr %111, align 4
  %113 = getelementptr i8, ptr %cpu, i64 296
  %114 = load i8, ptr %113, align 1
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow22
  br label %page_wr_done23

cec_check34:                                      ; preds = %page_wr_done23
  %115 = getelementptr i8, ptr %cpu, i32 188
  store i32 66054, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %117, align 4
  call void @cec_check_pending(ptr %cpu)
  %118 = getelementptr i8, ptr %cpu, i32 296
  %dj38 = load i8, ptr %118, align 1
  %dj_set39 = icmp ne i8 %dj38, 0
  br i1 %dj_set39, label %did_jump_exit36, label %did_jump_cont37, !prof !1

cec_checked35:                                    ; preds = %did_jump_cont37, %page_wr_done23
  br label %insn_0x00010206_entry

did_jump_exit36:                                  ; preds = %cec_check34
  %119 = getelementptr i8, ptr %cpu, i64 188
  %next_pc127 = load i32, ptr %119, align 4
  %120 = getelementptr i8, ptr %cpu, i64 188
  %121 = load i32, ptr %120, align 4
  %122 = getelementptr i8, ptr %cpu, i64 296
  %123 = load i8, ptr %122, align 1
  br label %chain_exit

did_jump_cont37:                                  ; preds = %cec_check34
  br label %cec_checked35

insn_0x00010206_entry:                            ; preds = %cec_checked35
  br label %insn_0x00010206

insn_0x00010206:                                  ; preds = %insn_0x00010206_entry
  %124 = getelementptr i8, ptr %cpu, i32 4
  %rs = load i32, ptr %124, align 4
  %and32 = and i32 8191, %rs
  %125 = getelementptr i8, ptr %cpu, i32 8
  store i32 %and32, ptr %125, align 4
  %126 = icmp eq i32 %and32, 0
  %az = zext i1 %126 to i32
  %an = lshr i32 %and32, 31
  %127 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %132, align 4
  br label %insn_0x00010208_entry

insn_0x00010208_entry:                            ; preds = %insn_0x00010206
  br label %insn_0x00010208

insn_0x00010208:                                  ; preds = %insn_0x00010208_entry
  %133 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %133, align 4
  %diff = sub i32 %rx, 0
  %134 = icmp eq i32 %diff, 0
  %az40 = zext i1 %134 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %135 = xor i32 %flgn, %flgs
  %136 = xor i32 %flgs, 0
  %overflow = and i32 %136, %135
  %an41 = xor i32 %flgn, %overflow
  %137 = icmp ule i32 0, %rx
  %ac0 = zext i1 %137 to i32
  %138 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az40, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az40, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an41, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %142, align 4
  br label %insn_0x0001020a_entry

insn_0x0001020a_entry:                            ; preds = %insn_0x00010208
  br label %insn_0x0001020a

insn_0x0001020a:                                  ; preds = %insn_0x0001020a_entry
  %cc_true = icmp ne i32 %az40, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x0001020a
  %143 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %144, align 4
  %chain_total = add nuw i32 %chain_packets, 6
  %145 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %145 monotonic, align 4, !range !2
  %146 = icmp ult i32 %chain_total, %chain_budget
  br i1 %146, label %chain_go, label %chain_leave128, !prof !0

brt_fallthru:                                     ; preds = %insn_0x0001020a
  br label %insn_0x0001020c_entry

insn_0x0001020c_entry:                            ; preds = %brt_fallthru
  br label %insn_0x0001020c

insn_0x0001020c:                                  ; preds = %insn_0x0001020c_entry
  %147 = getelementptr i8, ptr %cpu, i32 36
  %old = load i32, ptr %147, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %148 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_hi, ptr %148, align 4
  br label %insn_0x00010210_entry

insn_0x00010210_entry:                            ; preds = %insn_0x0001020c
  br label %insn_0x00010210

insn_0x00010210:                                  ; preds = %insn_0x00010210_entry
  %lo_kept42 = and i32 %r, 65535
  %with_hi43 = or i32 %lo_kept42, -1640562688
  %149 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_hi43, ptr %149, align 4
  br label %insn_0x00010214_entry

insn_0x00010214_entry:                            ; preds = %insn_0x00010210
  br label %insn_0x00010214

insn_0x00010214:                                  ; preds = %insn_0x00010214_entry
  %150 = getelementptr i8, ptr %cpu, i32 12
  store i32 0, ptr %150, align 4
  br label %insn_0x00010216_entry

insn_0x00010216_entry:                            ; preds = %insn_0x00010214
  br label %insn_0x00010216

insn_0x00010216:                                  ; preds = %insn_0x00010216_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4860
  %151 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %151, align 4
  br label %insn_0x0001021a_entry

insn_0x0001021a_entry:                            ; preds = %insn_0x00010216
  br label %insn_0x0001021a

insn_0x0001021a:                                  ; preds = %insn_0x0001021a_entry
  %hi_kept44 = and i32 %with_hi43, -65536
  %with_lo45 = or i32 %hi_kept44, 31161
  %152 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_lo45, ptr %152, align 4
  br label %insn_0x0001021e_entry

insn_0x0001021e_entry:                            ; preds = %insn_0x0001021a
  br label %insn_0x0001021e

insn_0x0001021e:                                  ; preds = %insn_0x0001021e_entry
  %153 = getelementptr i8, ptr %cpu, i32 32
  store i32 %and32, ptr %153, align 4
  br label %insn_0x00010220_entry

insn_0x00010220_entry:                            ; preds = %insn_0x0001021e
  br label %insn_0x00010220

insn_0x00010220:                                  ; preds = %insn_0x00010220_entry
  %154 = getelementptr i8, ptr %cpu, i32 12
  store i32 1, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %157, align 4
  %158 = or i32 %vs_cur, 0
  %159 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 256
  store i32 %158, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %163, align 4
  br label %insn_0x00010222_entry

insn_0x00010222_entry:                            ; preds = %insn_0x00010220
  br label %insn_0x00010222

insn_0x00010222:                                  ; preds = %insn_0x00010222_entry
  %164 = icmp ule i32 %rx, 1
  %cc = zext i1 %164 to i32
  %165 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %165, align 4
  %166 = icmp eq i32 %rx, 1
  %az46 = zext i1 %166 to i32
  %167 = icmp ugt i32 1, %rx
  %an47 = zext i1 %167 to i32
  %168 = icmp ule i32 1, %rx
  %ac048 = zext i1 %168 to i32
  %169 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az46, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an47, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac048, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac048, ptr %172, align 4
  br label %insn_0x00010224_entry

insn_0x00010224_entry:                            ; preds = %insn_0x00010222
  br label %insn_0x00010224

insn_0x00010224:                                  ; preds = %insn_0x00010224_entry
  %173 = shl i32 %and32, 2
  %plshift2 = add i32 %with_lo, %173
  %174 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift2, ptr %174, align 4
  br label %insn_0x00010226_entry

insn_0x00010226_entry:                            ; preds = %insn_0x00010224
  br label %insn_0x00010226

insn_0x00010226:                                  ; preds = %insn_0x00010226_entry
  %175 = and i32 %plshift2, 3
  %176 = icmp ne i32 %175, 0
  br i1 %176, label %data_misaligned49, label %data_aligned50, !prof !1

data_misaligned49:                                ; preds = %insn_0x00010226
  %177 = getelementptr i8, ptr %cpu, i32 188
  store i32 66086, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %179, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66086, i32 %plshift2, i32 0)
  %180 = getelementptr i8, ptr %cpu, i64 188
  %next_pc129 = load i32, ptr %180, align 4
  %181 = getelementptr i8, ptr %cpu, i64 188
  %182 = load i32, ptr %181, align 4
  %183 = getelementptr i8, ptr %cpu, i64 296
  %184 = load i8, ptr %183, align 1
  br label %chain_exit

data_aligned50:                                   ; preds = %insn_0x00010226
  %185 = lshr i32 %plshift2, 12
  %page_index51 = zext i32 %185 to i64
  %page_slot52 = getelementptr ptr, ptr %page_table, i64 %page_index51
  %page53 = load ptr, ptr %page_slot52, align 8
  %page_mapped54 = icmp ne ptr %page53, null
  br i1 %page_mapped54, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned50
  %186 = and i32 %plshift2, 4095
  %page_offset55 = zext i32 %186 to i64
  %187 = getelementptr i8, ptr %page53, i64 %page_offset55
  %page_val = load i32, ptr %187, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned50
  %188 = getelementptr i8, ptr %cpu, i32 188
  store i32 66086, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %190, align 4
  %191 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %192 = getelementptr i8, ptr %cpu, i32 296
  %dj58 = load i8, ptr %192, align 1
  %dj_set59 = icmp ne i8 %dj58, 0
  br i1 %dj_set59, label %did_jump_exit56, label %did_jump_cont57, !prof !1

page_done:                                        ; preds = %did_jump_cont57, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %191, %did_jump_cont57 ]
  %193 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mem_val, ptr %193, align 4
  br label %insn_0x00010228_entry

did_jump_exit56:                                  ; preds = %page_slow
  %194 = getelementptr i8, ptr %cpu, i64 188
  %next_pc130 = load i32, ptr %194, align 4
  %195 = getelementptr i8, ptr %cpu, i64 188
  %196 = load i32, ptr %195, align 4
  %197 = getelementptr i8, ptr %cpu, i64 296
  %198 = load i8, ptr %197, align 1
  br label %chain_exit

did_jump_cont57:                                  ; preds = %page_slow
  br label %page_done

insn_0x00010228_entry:                            ; preds = %page_done
  br label %insn_0x00010228

insn_0x00010228:                                  ; preds = %insn_0x00010228_entry
  %xor32 = xor i32 %rs, %mem_val
  %199 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %199, align 4
  %200 = icmp eq i32 %xor32, 0
  %az60 = zext i1 %200 to i32
  %an61 = lshr i32 %xor32, 31
  %201 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az60, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an61, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %206, align 4
  br label %insn_0x0001022a_entry

insn_0x0001022a_entry:                            ; preds = %insn_0x00010228
  br label %insn_0x0001022a

insn_0x0001022a:                                  ; preds = %insn_0x0001022a_entry
  %add32 = add i32 %xor32, %with_lo45
  %207 = getelementptr i8, ptr %cpu, i32 4
  store i32 %add32, ptr %207, align 4
  %flgs62 = lshr i32 %xor32, 31
  %flgo = lshr i32 %with_lo45, 31
  %flgn63 = lshr i32 %add32, 31
  %208 = xor i32 %flgo, %flgn63
  %209 = xor i32 %flgs62, %flgn63
  %210 = and i32 %209, %208
  %211 = xor i32 %xor32, -1
  %212 = icmp ult i32 %211, %with_lo45
  %ac064 = zext i1 %212 to i32
  %213 = icmp eq i32 %add32, 0
  %az65 = zext i1 %213 to i32
  %an66 = lshr i32 %add32, 31
  %214 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az65, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an66, ptr %215, align 4
  %216 = or i32 %158, %210
  %217 = getelementptr i8, ptr %cpu, i32 248
  store i32 %210, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i32 252
  store i32 %210, ptr %218, align 4
  %219 = getelementptr i8, ptr %cpu, i32 256
  store i32 %216, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac064, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac064, ptr %221, align 4
  br label %insn_0x0001022c_entry

insn_0x0001022c_entry:                            ; preds = %insn_0x0001022a
  br label %insn_0x0001022c

insn_0x0001022c:                                  ; preds = %insn_0x0001022c_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x0001022c
  %222 = getelementptr i8, ptr %cpu, i32 188
  store i32 66078, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets133 = load i32, ptr %223, align 4
  %chain_total134 = add nuw i32 %chain_packets133, 19
  %224 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget135 = load atomic i32, ptr %224 monotonic, align 4, !range !2
  %225 = icmp ult i32 %chain_total134, %chain_budget135
  br i1 %225, label %chain_go131, label %chain_leave132, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x0001022c
  br label %insn_0x0001022e_entry

insn_0x0001022e_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x0001022e

insn_0x0001022e:                                  ; preds = %insn_0x0001022e_entry
  %226 = and i32 %sp2, 3
  %227 = icmp ne i32 %226, 0
  br i1 %227, label %data_misaligned67, label %data_aligned68, !prof !1

data_misaligned67:                                ; preds = %insn_0x0001022e
  %228 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %228, align 4
  %229 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %229, align 4
  %230 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %230, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66094, i32 %sp2, i32 0)
  %231 = getelementptr i8, ptr %cpu, i64 188
  %next_pc140 = load i32, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i64 188
  %233 = load i32, ptr %232, align 4
  %234 = getelementptr i8, ptr %cpu, i64 296
  %235 = load i8, ptr %234, align 1
  br label %chain_exit

data_aligned68:                                   ; preds = %insn_0x0001022e
  %236 = lshr i32 %sp2, 12
  %page_index72 = zext i32 %236 to i64
  %page_slot73 = getelementptr ptr, ptr %page_table, i64 %page_index72
  %page74 = load ptr, ptr %page_slot73, align 8
  %page_mapped75 = icmp ne ptr %page74, null
  br i1 %page_mapped75, label %page_fast69, label %page_slow70, !prof !0

page_fast69:                                      ; preds = %data_aligned68
  %237 = and i32 %sp2, 4095
  %page_offset76 = zext i32 %237 to i64
  %238 = getelementptr i8, ptr %page74, i64 %page_offset76
  %page_val77 = load i32, ptr %238, align 4
  br label %page_done71

page_slow70:                                      ; preds = %data_aligned68
  %239 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %240, align 4
  %241 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %241, align 4
  %242 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %243 = getelementptr i8, ptr %cpu, i32 296
  %dj80 = load i8, ptr %243, align 1
  %dj_set81 = icmp ne i8 %dj80, 0
  br i1 %dj_set81, label %did_jump_exit78, label %did_jump_cont79, !prof !1

page_done71:                                      ; preds = %did_jump_cont79, %page_fast69
  %mem_val82 = phi i32 [ %page_val77, %page_fast69 ], [ %242, %did_jump_cont79 ]
  %sp183 = add i32 %sp2, 4
  %244 = and i32 %sp183, 3
  %245 = icmp ne i32 %244, 0
  br i1 %245, label %data_misaligned84, label %data_aligned85, !prof !1

did_jump_exit78:                                  ; preds = %page_slow70
  %246 = getelementptr i8, ptr %cpu, i64 188
  %next_pc141 = load i32, ptr %246, align 4
  %247 = getelementptr i8, ptr %cpu, i64 188
  %248 = load i32, ptr %247, align 4
  %249 = getelementptr i8, ptr %cpu, i64 296
  %250 = load i8, ptr %249, align 1
  br label %chain_exit

did_jump_cont79:                                  ; preds = %page_slow70
  br label %page_done71

data_misaligned84:                                ; preds = %page_done71
  %251 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %251, align 4
  %252 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %252, align 4
  %253 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %253, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66094, i32 %sp183, i32 0)
  %254 = getelementptr i8, ptr %cpu, i64 188
  %next_pc142 = load i32, ptr %254, align 4
  %255 = getelementptr i8, ptr %cpu, i64 188
  %256 = load i32, ptr %255, align 4
  %257 = getelementptr i8, ptr %cpu, i64 296
  %258 = load i8, ptr %257, align 1
  br label %chain_exit

data_aligned85:                                   ; preds = %page_done71
  %259 = lshr i32 %sp183, 12
  %page_index89 = zext i32 %259 to i64
  %page_slot90 = getelementptr ptr, ptr %page_table, i64 %page_index89
  %page91 = load ptr, ptr %page_slot90, align 8
  %page_mapped92 = icmp ne ptr %page91, null
  br i1 %page_mapped92, label %page_fast86, label %page_slow87, !prof !0

page_fast86:                                      ; preds = %data_aligned85
  %260 = and i32 %sp183, 4095
  %page_offset93 = zext i32 %260 to i64
  %261 = getelementptr i8, ptr %page91, i64 %page_offset93
  %page_val94 = load i32, ptr %261, align 4
  br label %page_done88

page_slow87:                                      ; preds = %data_aligned85
  %262 = getelementptr i8, ptr %cpu, i32 188
  store i32 66094, ptr %262, align 4
  %263 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %263, align 4
  %264 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %264, align 4
  %265 = call i32 @mem_read32(ptr %mem, i32 %sp183)
  %266 = getelementptr i8, ptr %cpu, i32 296
  %dj97 = load i8, ptr %266, align 1
  %dj_set98 = icmp ne i8 %dj97, 0
  br i1 %dj_set98, label %did_jump_exit95, label %did_jump_cont96, !prof !1

page_done88:                                      ; preds = %did_jump_cont96, %page_fast86
  %mem_val99 = phi i32 [ %page_val94, %page_fast86 ], [ %265, %did_jump_cont96 ]
  %sp2100 = add i32 %sp183, 4
  %267 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val82, ptr %267, align 4
  %268 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val99, ptr %268, align 4
  %269 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2100, ptr %269, align 4
  br label %insn_0x00010232_entry

did_jump_exit95:                                  ; preds = %page_slow87
  %270 = getelementptr i8, ptr %cpu, i64 188
  %next_pc143 = load i32, ptr %270, align 4
  %271 = getelementptr i8, ptr %cpu, i64 188
  %272 = load i32, ptr %271, align 4
  %273 = getelementptr i8, ptr %cpu, i64 296
  %274 = load i8, ptr %273, align 1
  br label %chain_exit

did_jump_cont96:                                  ; preds = %page_slow87
  br label %page_done88

insn_0x00010232_entry:                            ; preds = %page_done88
  br label %insn_0x00010232

insn_0x00010232:                                  ; preds = %insn_0x00010232_entry
  %xor32101 = xor i32 %mem_val, %add32
  %275 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32101, ptr %275, align 4
  %276 = icmp eq i32 %xor32101, 0
  %az102 = zext i1 %276 to i32
  %an103 = lshr i32 %xor32101, 31
  %277 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az102, ptr %277, align 4
  %278 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an103, ptr %278, align 4
  %279 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %280, align 4
  %281 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %282, align 4
  br label %insn_0x00010234_entry

insn_0x00010234_entry:                            ; preds = %insn_0x00010232
  br label %insn_0x00010234

insn_0x00010234:                                  ; preds = %insn_0x00010234_entry
  %283 = and i32 %sp2100, 3
  %284 = icmp ne i32 %283, 0
  br i1 %284, label %data_misaligned104, label %data_aligned105, !prof !1

data_misaligned104:                               ; preds = %insn_0x00010234
  %285 = getelementptr i8, ptr %cpu, i32 188
  store i32 66100, ptr %285, align 4
  %286 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %286, align 4
  %287 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %287, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66100, i32 %sp2100, i32 0)
  %288 = getelementptr i8, ptr %cpu, i64 188
  %next_pc144 = load i32, ptr %288, align 4
  %289 = getelementptr i8, ptr %cpu, i64 188
  %290 = load i32, ptr %289, align 4
  %291 = getelementptr i8, ptr %cpu, i64 296
  %292 = load i8, ptr %291, align 1
  br label %chain_exit

data_aligned105:                                  ; preds = %insn_0x00010234
  %293 = lshr i32 %sp2100, 12
  %page_index109 = zext i32 %293 to i64
  %page_slot110 = getelementptr ptr, ptr %page_table, i64 %page_index109
  %page111 = load ptr, ptr %page_slot110, align 8
  %page_mapped112 = icmp ne ptr %page111, null
  br i1 %page_mapped112, label %page_fast106, label %page_slow107, !prof !0

page_fast106:                                     ; preds = %data_aligned105
  %294 = and i32 %sp2100, 4095
  %page_offset113 = zext i32 %294 to i64
  %295 = getelementptr i8, ptr %page111, i64 %page_offset113
  %page_val114 = load i32, ptr %295, align 4
  br label %page_done108

page_slow107:                                     ; preds = %data_aligned105
  %296 = getelementptr i8, ptr %cpu, i32 188
  store i32 66100, ptr %296, align 4
  %297 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %297, align 4
  %298 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %298, align 4
  %299 = call i32 @mem_read32(ptr %mem, i32 %sp2100)
  %300 = getelementptr i8, ptr %cpu, i32 296
  %dj117 = load i8, ptr %300, align 1
  %dj_set118 = icmp ne i8 %dj117, 0
  br i1 %dj_set118, label %did_jump_exit115, label %did_jump_cont116, !prof !1

page_done108:                                     ; preds = %did_jump_cont116, %page_fast106
  %mem_val119 = phi i32 [ %page_val114, %page_fast106 ], [ %299, %did_jump_cont116 ]
  %301 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val119, ptr %301, align 4
  %sp_inc = add i32 %sp2100, 4
  %302 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc, ptr %302, align 4
  br label %insn_0x00010236_entry

did_jump_exit115:                                 ; preds = %page_slow107
  %303 = getelementptr i8, ptr %cpu, i64 188
  %next_pc145 = load i32, ptr %303, align 4
  %304 = getelementptr i8, ptr %cpu, i64 188
  %305 = load i32, ptr %304, align 4
  %306 = getelementptr i8, ptr %cpu, i64 296
  %307 = load i8, ptr %306, align 1
  br label %chain_exit

did_jump_cont116:                                 ; preds = %page_slow107
  br label %page_done108

insn_0x00010236_entry:                            ; preds = %page_done108
  br label %insn_0x00010236

insn_0x00010236:                                  ; preds = %insn_0x00010236_entry
  %lsb = and i32 %mem_val99, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x00010236
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x00010236
  %308 = getelementptr i8, ptr %cpu, i32 188
  store i32 66102, ptr %308, align 4
  %309 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %309, align 4
  %310 = getelementptr i8, ptr %cpu, i32 308
  store i32 23, ptr %310, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %311 = getelementptr i8, ptr %cpu, i64 188
  %next_pc146 = load i32, ptr %311, align 4
  %312 = getelementptr i8, ptr %cpu, i64 188
  %313 = load i32, ptr %312, align 4
  %314 = getelementptr i8, ptr %cpu, i64 296
  %315 = load i8, ptr %314, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %316 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %316, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 528752
  %317 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %317, align 4
  %318 = icmp eq i32 %slot_pc, 66094
  br i1 %318, label %chain_hit, label %chain_leave128, !prof !0

chain_leave128:                                   ; preds = %chain_go, %brt_taken
  %319 = getelementptr i8, ptr %cpu, i64 188
  store i32 66094, ptr %319, align 4
  %320 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %320, align 4
  %321 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %321, align 4
  %322 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %322, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %323 = getelementptr i8, ptr %cpu, i64 188
  store i32 66094, ptr %323, align 4
  %324 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %324, align 4
  %325 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %325, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go131:                                      ; preds = %brcc_taken
  %chain_slot136 = getelementptr i8, ptr %chain_table, i64 528624
  %326 = getelementptr i8, ptr %chain_slot136, i64 0
  %slot_pc137 = load i32, ptr %326, align 4
  %327 = icmp eq i32 %slot_pc137, 66078
  br i1 %327, label %chain_hit138, label %chain_leave132, !prof !0

chain_leave132:                                   ; preds = %chain_go131, %brcc_taken
  %328 = getelementptr i8, ptr %cpu, i64 188
  store i32 66078, ptr %328, align 4
  %329 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %330, align 4
  %331 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %331, align 1
  br label %return

chain_hit138:                                     ; preds = %chain_go131
  %332 = getelementptr i8, ptr %cpu, i64 188
  store i32 66078, ptr %332, align 4
  %333 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total134, ptr %333, align 4
  %334 = getelementptr i8, ptr %chain_slot136, i64 8
  %chain_fn139 = load ptr, ptr %334, align 8
  musttail call swifttailcc void %chain_fn139(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit115, %data_misaligned104, %did_jump_exit95, %data_misaligned84, %did_jump_exit78, %data_misaligned67, %did_jump_exit56, %data_misaligned49, %did_jump_exit36, %did_jump_exit29, %data_misaligned19, %did_jump_exit15, %data_misaligned5, %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc147 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc121, %did_jump_exit ], [ %next_pc122, %did_jump_exit1 ], [ %next_pc123, %data_misaligned5 ], [ %next_pc124, %did_jump_exit15 ], [ %next_pc125, %data_misaligned19 ], [ %next_pc126, %did_jump_exit29 ], [ %next_pc127, %did_jump_exit36 ], [ %next_pc129, %data_misaligned49 ], [ %next_pc130, %did_jump_exit56 ], [ %next_pc140, %data_misaligned67 ], [ %next_pc141, %did_jump_exit78 ], [ %next_pc142, %data_misaligned84 ], [ %next_pc143, %did_jump_exit95 ], [ %next_pc144, %data_misaligned104 ], [ %next_pc145, %did_jump_exit115 ], [ %mem_val99, %jump_aligned ], [ %next_pc146, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 3, %data_misaligned5 ], [ 3, %did_jump_exit15 ], [ 3, %data_misaligned19 ], [ 3, %did_jump_exit29 ], [ 3, %did_jump_exit36 ], [ 16, %data_misaligned49 ], [ 16, %did_jump_exit56 ], [ 20, %data_misaligned67 ], [ 20, %did_jump_exit78 ], [ 20, %data_misaligned84 ], [ 20, %did_jump_exit95 ], [ 22, %data_misaligned104 ], [ 22, %did_jump_exit115 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail = phi i32 [ %38, %data_misaligned ], [ %53, %did_jump_exit ], [ %62, %did_jump_exit1 ], [ %75, %data_misaligned5 ], [ %89, %did_jump_exit15 ], [ %97, %data_misaligned19 ], [ %112, %did_jump_exit29 ], [ %121, %did_jump_exit36 ], [ %182, %data_misaligned49 ], [ %196, %did_jump_exit56 ], [ %233, %data_misaligned67 ], [ %248, %did_jump_exit78 ], [ %256, %data_misaligned84 ], [ %272, %did_jump_exit95 ], [ %290, %data_misaligned104 ], [ %305, %did_jump_exit115 ], [ %mem_val99, %jump_aligned ], [ %313, %jump_misalign ]
  %tail148 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ], [ 4, %data_misaligned5 ], [ 4, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit29 ], [ 4, %did_jump_exit36 ], [ 2, %data_misaligned49 ], [ 2, %did_jump_exit56 ], [ 4, %data_misaligned67 ], [ 4, %did_jump_exit78 ], [ 4, %data_misaligned84 ], [ 4, %did_jump_exit95 ], [ 2, %data_misaligned104 ], [ 2, %did_jump_exit115 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail149 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 3, %data_misaligned5 ], [ 3, %did_jump_exit15 ], [ 3, %data_misaligned19 ], [ 3, %did_jump_exit29 ], [ 3, %did_jump_exit36 ], [ 16, %data_misaligned49 ], [ 16, %did_jump_exit56 ], [ 20, %data_misaligned67 ], [ 20, %did_jump_exit78 ], [ 20, %data_misaligned84 ], [ 20, %did_jump_exit95 ], [ 22, %data_misaligned104 ], [ 22, %did_jump_exit115 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail150 = phi i8 [ %40, %data_misaligned ], [ %55, %did_jump_exit ], [ %64, %did_jump_exit1 ], [ %77, %data_misaligned5 ], [ %91, %did_jump_exit15 ], [ %99, %data_misaligned19 ], [ %114, %did_jump_exit29 ], [ %123, %did_jump_exit36 ], [ %184, %data_misaligned49 ], [ %198, %did_jump_exit56 ], [ %235, %data_misaligned67 ], [ %250, %did_jump_exit78 ], [ %258, %data_misaligned84 ], [ %274, %did_jump_exit95 ], [ %292, %data_misaligned104 ], [ %307, %did_jump_exit115 ], [ 1, %jump_aligned ], [ %315, %jump_misalign ]
  %335 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets152 = load i32, ptr %335, align 4
  %chain_total153 = add nuw i32 %chain_packets152, %packets
  %336 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget154 = load atomic i32, ptr %336 monotonic, align 4, !range !2
  %337 = icmp ult i32 %chain_total153, %chain_budget154
  br i1 %337, label %chain_lookup, label %chain_leave151, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %338 = lshr i32 %next_pc147, 1
  %339 = and i32 %338, 65535
  %340 = zext i32 %339 to i64
  %341 = mul i64 %340, 16
  %chain_slot155 = getelementptr i8, ptr %chain_table, i64 %341
  %342 = getelementptr i8, ptr %chain_slot155, i64 0
  %slot_pc156 = load i32, ptr %342, align 4
  %343 = icmp eq i32 %slot_pc156, %next_pc147
  br i1 %343, label %chain_hit157, label %chain_leave151, !prof !0

chain_leave151:                                   ; preds = %chain_lookup, %chain_exit
  %344 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %344, align 4
  %345 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail148, ptr %345, align 4
  %346 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail149, ptr %346, align 4
  %347 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail150, ptr %347, align 1
  br label %return

chain_hit157:                                     ; preds = %chain_lookup
  %348 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc147, ptr %348, align 4
  %349 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total153, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %350, align 1
  %351 = getelementptr i8, ptr %chain_slot155, i64 8
  %chain_fn158 = load ptr, ptr %351, align 8
  musttail call swifttailcc void %chain_fn158(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave151, %chain_leave132, %chain_leave128, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
