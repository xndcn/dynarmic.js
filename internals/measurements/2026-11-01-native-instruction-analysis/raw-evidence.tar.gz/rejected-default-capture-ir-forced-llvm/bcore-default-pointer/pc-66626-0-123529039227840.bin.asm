
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66626-0-123529039227840.bin:     file format binary


Disassembly of section .data:

000070595880abc0 <.data>:
    70595880abc0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    70595880abc7:	4c 89 74 24 68       	mov    QWORD PTR [rsp+0x68],r14
    70595880abcc:	4c 89 6c 24 70       	mov    QWORD PTR [rsp+0x70],r13
    70595880abd1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880abd8:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    70595880abdd:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880abe4:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    70595880abeb:	00 
    70595880abec:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    70595880abf1:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    70595880abf7:	83 fa 00             	cmp    edx,0x0
    70595880abfa:	0f 94 c0             	sete   al
    70595880abfd:	81 ea 42 04 01 00    	sub    edx,0x10442
    70595880ac03:	83 fa 0c             	cmp    edx,0xc
    70595880ac06:	0f 97 c2             	seta   dl
    70595880ac09:	08 d0                	or     al,dl
    70595880ac0b:	24 01                	and    al,0x1
    70595880ac0d:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880ac13:	81 fa 20 04 01 00    	cmp    edx,0x10420
    70595880ac19:	0f 94 c1             	sete   cl
    70595880ac1c:	81 ea 42 04 01 00    	sub    edx,0x10442
    70595880ac22:	83 fa 0c             	cmp    edx,0xc
    70595880ac25:	0f 97 c2             	seta   dl
    70595880ac28:	08 d1                	or     cl,dl
    70595880ac2a:	20 c8                	and    al,cl
    70595880ac2c:	a8 01                	test   al,0x1
    70595880ac2e:	75 05                	jne    0x70595880ac35
    70595880ac30:	e9 d6 02 00 00       	jmp    0x70595880af0b
    70595880ac35:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880ac3a:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880ac41:	48 89 c8             	mov    rax,rcx
    70595880ac44:	48 05 00 00 10 00    	add    rax,0x100000
    70595880ac4a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    70595880ac4f:	8b 81 2c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10002c]
    70595880ac55:	83 c0 01             	add    eax,0x1
    70595880ac58:	89 81 2c 00 10 00    	mov    DWORD PTR [rcx+0x10002c],eax
    70595880ac5e:	3d 30 75 00 00       	cmp    eax,0x7530
    70595880ac63:	75 40                	jne    0x70595880aca5
    70595880ac65:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    70595880ac6a:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    70595880ac70:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880ac74:	89 c2                	mov    edx,eax
    70595880ac76:	83 c2 01             	add    edx,0x1
    70595880ac79:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    70595880ac7f:	3d 00 01 00 00       	cmp    eax,0x100
    70595880ac84:	73 1d                	jae    0x70595880aca3
    70595880ac86:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    70595880ac8b:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880ac8f:	89 c9                	mov    ecx,ecx
    70595880ac91:	48 c1 e1 02          	shl    rcx,0x2
    70595880ac95:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880ac9c:	c7 04 08 0b 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xb
    70595880aca3:	eb 00                	jmp    0x70595880aca5
    70595880aca5:	eb 00                	jmp    0x70595880aca7
    70595880aca7:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880acac:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    70595880acaf:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880acb5:	81 c9 00 00 01 00    	or     ecx,0x10000
    70595880acbb:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    70595880acbf:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    70595880acc2:	eb 00                	jmp    0x70595880acc4
    70595880acc4:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880acc9:	8b 4c 24 58          	mov    ecx,DWORD PTR [rsp+0x58]
    70595880accd:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880acd3:	81 c9 9c 11 00 00    	or     ecx,0x119c
    70595880acd9:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    70595880acdd:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    70595880ace0:	eb 00                	jmp    0x70595880ace2
    70595880ace2:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880ace7:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    70595880aceb:	8b 50 28             	mov    edx,DWORD PTR [rax+0x28]
    70595880acee:	c1 e2 02             	shl    edx,0x2
    70595880acf1:	01 d1                	add    ecx,edx
    70595880acf3:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    70595880acf7:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880acfa:	eb 00                	jmp    0x70595880acfc
    70595880acfc:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    70595880ad00:	83 e0 03             	and    eax,0x3
    70595880ad03:	83 f8 00             	cmp    eax,0x0
    70595880ad06:	74 7c                	je     0x70595880ad84
    70595880ad08:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    70595880ad0d:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    70595880ad11:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    70595880ad16:	c7 87 bc 00 00 00 4c 	mov    DWORD PTR [rdi+0xbc],0x1044c
    70595880ad1d:	04 01 00 
    70595880ad20:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880ad27:	00 00 00 
    70595880ad2a:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    70595880ad31:	00 00 00 
    70595880ad34:	31 c0                	xor    eax,eax
    70595880ad36:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880ad3d:	63 00 00 
    70595880ad40:	ba 4c 04 01 00       	mov    edx,0x1044c
    70595880ad45:	45 31 c0             	xor    r8d,r8d
    70595880ad48:	ff d0                	call   rax
    70595880ad4a:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880ad4f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ad55:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ad5b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ad61:	be 04 00 00 00       	mov    esi,0x4
    70595880ad66:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ad6b:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    70595880ad6f:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    70595880ad73:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    70595880ad77:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880ad7b:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    70595880ad7f:	e9 98 01 00 00       	jmp    0x70595880af1c
    70595880ad84:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    70595880ad8b:	00 
    70595880ad8c:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    70595880ad90:	c1 e9 0c             	shr    ecx,0xc
    70595880ad93:	89 c9                	mov    ecx,ecx
    70595880ad95:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880ad99:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    70595880ad9e:	48 83 f8 00          	cmp    rax,0x0
    70595880ada2:	74 1a                	je     0x70595880adbe
    70595880ada4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    70595880ada9:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    70595880adad:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880adb3:	89 c9                	mov    ecx,ecx
    70595880adb5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880adb8:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    70595880adbc:	eb 4e                	jmp    0x70595880ae0c
    70595880adbe:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880adc3:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    70595880adc7:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    70595880adcc:	c7 80 bc 00 00 00 4c 	mov    DWORD PTR [rax+0xbc],0x1044c
    70595880add3:	04 01 00 
    70595880add6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880addd:	00 00 00 
    70595880ade0:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    70595880ade7:	00 00 00 
    70595880adea:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880adf1:	63 00 00 
    70595880adf4:	ff d0                	call   rax
    70595880adf6:	89 c1                	mov    ecx,eax
    70595880adf8:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880adfd:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    70595880ae01:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880ae08:	75 14                	jne    0x70595880ae1e
    70595880ae0a:	eb 4c                	jmp    0x70595880ae58
    70595880ae0c:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880ae11:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    70595880ae15:	89 4c 24 24          	mov    DWORD PTR [rsp+0x24],ecx
    70595880ae19:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880ae1c:	eb 44                	jmp    0x70595880ae62
    70595880ae1e:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880ae23:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880ae29:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880ae2f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880ae35:	be 04 00 00 00       	mov    esi,0x4
    70595880ae3a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ae3f:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    70595880ae43:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    70595880ae47:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    70595880ae4b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880ae4f:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    70595880ae53:	e9 c4 00 00 00       	jmp    0x70595880af1c
    70595880ae58:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    70595880ae5c:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    70595880ae60:	eb aa                	jmp    0x70595880ae0c
    70595880ae62:	eb 00                	jmp    0x70595880ae64
    70595880ae64:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    70595880ae68:	83 e0 01             	and    eax,0x1
    70595880ae6b:	83 f8 00             	cmp    eax,0x0
    70595880ae6e:	75 2b                	jne    0x70595880ae9b
    70595880ae70:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    70595880ae74:	be 05 00 00 00       	mov    esi,0x5
    70595880ae79:	b9 02 00 00 00       	mov    ecx,0x2
    70595880ae7e:	b0 01                	mov    al,0x1
    70595880ae80:	89 d7                	mov    edi,edx
    70595880ae82:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    70595880ae86:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    70595880ae8a:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    70595880ae8e:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880ae92:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    70595880ae96:	e9 81 00 00 00       	jmp    0x70595880af1c
    70595880ae9b:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    70595880aea0:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    70595880aea5:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1044e
    70595880aeac:	04 01 00 
    70595880aeaf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880aeb6:	00 00 00 
    70595880aeb9:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    70595880aec0:	00 00 00 
    70595880aec3:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    70595880aeca:	63 00 00 
    70595880aecd:	be 2a 00 00 00       	mov    esi,0x2a
    70595880aed2:	ff d0                	call   rax
    70595880aed4:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880aed9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880aedf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880aee5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880aeeb:	be 05 00 00 00       	mov    esi,0x5
    70595880aef0:	b9 02 00 00 00       	mov    ecx,0x2
    70595880aef5:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    70595880aef9:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    70595880aefd:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    70595880af01:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880af05:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    70595880af09:	eb 11                	jmp    0x70595880af1c
    70595880af0b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880af10:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880af17:	e9 d2 00 00 00       	jmp    0x70595880afee
    70595880af1c:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    70595880af21:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    70595880af25:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    70595880af29:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    70595880af2d:	8b 7c 24 48          	mov    edi,DWORD PTR [rsp+0x48]
    70595880af31:	8a 5c 24 4f          	mov    bl,BYTE PTR [rsp+0x4f]
    70595880af35:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    70595880af39:	89 c3                	mov    ebx,eax
    70595880af3b:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    70595880af3f:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    70595880af43:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    70595880af47:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    70595880af4b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880af51:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    70595880af55:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880af5b:	73 29                	jae    0x70595880af86
    70595880af5d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    70595880af62:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    70595880af66:	89 d1                	mov    ecx,edx
    70595880af68:	c1 e9 01             	shr    ecx,0x1
    70595880af6b:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880af71:	89 c9                	mov    ecx,ecx
    70595880af73:	48 c1 e1 04          	shl    rcx,0x4
    70595880af77:	48 89 c6             	mov    rsi,rax
    70595880af7a:	48 01 ce             	add    rsi,rcx
    70595880af7d:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    70595880af81:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880af84:	74 2f                	je     0x70595880afb5
    70595880af86:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880af8b:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    70595880af8f:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    70595880af93:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    70595880af97:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    70595880af9b:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    70595880afa1:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    70595880afa7:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    70595880afad:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595880afb3:	eb 39                	jmp    0x70595880afee
    70595880afb5:	4c 8b 74 24 68       	mov    r14,QWORD PTR [rsp+0x68]
    70595880afba:	4c 8b 6c 24 70       	mov    r13,QWORD PTR [rsp+0x70]
    70595880afbf:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    70595880afc3:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    70595880afc7:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    70595880afcb:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    70595880afd2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880afd9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880afe0:	00 
    70595880afe1:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880afe5:	48 81 c4 88 00 00 00 	add    rsp,0x88
    70595880afec:	ff e0                	jmp    rax
    70595880afee:	48 81 c4 88 00 00 00 	add    rsp,0x88
    70595880aff5:	c2 08 00             	ret    0x8
