
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65556-0-123529039184416.bin:     file format binary


Disassembly of section .data:

0000705958800220 <.data>:
    705958800220:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    705958800227:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    70595880022e:	00 
    70595880022f:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    705958800236:	00 
    705958800237:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880023e:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    705958800245:	00 
    705958800246:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    70595880024d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    705958800254:	00 
    705958800255:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880025c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    705958800263:	00 
    705958800264:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880026b:	00 
    70595880026c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958800272:	83 fa 00             	cmp    edx,0x0
    705958800275:	0f 94 c0             	sete   al
    705958800278:	81 ea 14 00 01 00    	sub    edx,0x10014
    70595880027e:	83 fa 2a             	cmp    edx,0x2a
    705958800281:	0f 97 c2             	seta   dl
    705958800284:	08 d0                	or     al,dl
    705958800286:	24 01                	and    al,0x1
    705958800288:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880028e:	83 fa 00             	cmp    edx,0x0
    705958800291:	0f 94 c1             	sete   cl
    705958800294:	81 ea 14 00 01 00    	sub    edx,0x10014
    70595880029a:	83 fa 2a             	cmp    edx,0x2a
    70595880029d:	0f 97 c2             	seta   dl
    7059588002a0:	08 d1                	or     cl,dl
    7059588002a2:	20 c8                	and    al,cl
    7059588002a4:	a8 01                	test   al,0x1
    7059588002a6:	75 05                	jne    0x7059588002ad
    7059588002a8:	e9 19 27 00 00       	jmp    0x7059588029c6
    7059588002ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588002b4:	00 
    7059588002b5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    7059588002bc:	48 89 c8             	mov    rax,rcx
    7059588002bf:	48 05 00 00 10 00    	add    rax,0x100000
    7059588002c5:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    7059588002cc:	00 
    7059588002cd:	8b 81 04 00 10 00    	mov    eax,DWORD PTR [rcx+0x100004]
    7059588002d3:	83 c0 01             	add    eax,0x1
    7059588002d6:	89 81 04 00 10 00    	mov    DWORD PTR [rcx+0x100004],eax
    7059588002dc:	3d 30 75 00 00       	cmp    eax,0x7530
    7059588002e1:	75 4c                	jne    0x70595880032f
    7059588002e3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    7059588002ea:	00 
    7059588002eb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    7059588002f1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    7059588002f8:	89 c2                	mov    edx,eax
    7059588002fa:	83 c2 01             	add    edx,0x1
    7059588002fd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958800303:	3d 00 01 00 00       	cmp    eax,0x100
    705958800308:	73 23                	jae    0x70595880032d
    70595880030a:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    705958800311:	00 
    705958800312:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    705958800319:	89 c9                	mov    ecx,ecx
    70595880031b:	48 c1 e1 02          	shl    rcx,0x2
    70595880031f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958800326:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    70595880032d:	eb 00                	jmp    0x70595880032f
    70595880032f:	eb 00                	jmp    0x705958800331
    705958800331:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800338:	00 
    705958800339:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    70595880033c:	83 e8 04             	sub    eax,0x4
    70595880033f:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    705958800346:	8b 49 10             	mov    ecx,DWORD PTR [rcx+0x10]
    705958800349:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    705958800350:	83 e0 03             	and    eax,0x3
    705958800353:	83 f8 00             	cmp    eax,0x0
    705958800356:	0f 84 8e 00 00 00    	je     0x7059588003ea
    70595880035c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800363:	00 
    705958800364:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    70595880036b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800372:	00 
    705958800373:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880037a:	00 00 00 
    70595880037d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800384:	00 00 00 
    705958800387:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880038e:	63 00 00 
    705958800391:	ba 14 00 01 00       	mov    edx,0x10014
    705958800396:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880039c:	ff d0                	call   rax
    70595880039e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588003a5:	00 
    7059588003a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588003ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588003b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588003b8:	be 01 00 00 00       	mov    esi,0x1
    7059588003bd:	b9 02 00 00 00       	mov    ecx,0x2
    7059588003c2:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588003c9:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588003d0:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588003d7:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588003de:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588003e5:	e9 80 26 00 00       	jmp    0x705958802a6a
    7059588003ea:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588003f1:	00 
    7059588003f2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    7059588003f9:	c1 e9 0c             	shr    ecx,0xc
    7059588003fc:	89 c9                	mov    ecx,ecx
    7059588003fe:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958800402:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    705958800409:	00 
    70595880040a:	48 83 f8 00          	cmp    rax,0x0
    70595880040e:	74 23                	je     0x705958800433
    705958800410:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    705958800417:	00 
    705958800418:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    70595880041f:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    705958800426:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880042c:	89 c9                	mov    ecx,ecx
    70595880042e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958800431:	eb 51                	jmp    0x705958800484
    705958800433:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880043a:	00 
    70595880043b:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    705958800442:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    705958800449:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958800450:	00 
    705958800451:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958800458:	00 00 00 
    70595880045b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800462:	00 00 00 
    705958800465:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880046c:	63 00 00 
    70595880046f:	ff d0                	call   rax
    705958800471:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800478:	00 
    705958800479:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800480:	75 32                	jne    0x7059588004b4
    705958800482:	eb 7c                	jmp    0x705958800500
    705958800484:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880048b:	00 
    70595880048c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    705958800493:	83 e8 04             	sub    eax,0x4
    705958800496:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    70595880049d:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    7059588004a0:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    7059588004a7:	83 e0 03             	and    eax,0x3
    7059588004aa:	83 f8 00             	cmp    eax,0x0
    7059588004ad:	75 53                	jne    0x705958800502
    7059588004af:	e9 dc 00 00 00       	jmp    0x705958800590
    7059588004b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588004bb:	00 
    7059588004bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588004c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588004c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588004ce:	be 01 00 00 00       	mov    esi,0x1
    7059588004d3:	b9 02 00 00 00       	mov    ecx,0x2
    7059588004d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588004df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588004e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588004ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588004f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588004fb:	e9 6a 25 00 00       	jmp    0x705958802a6a
    705958800500:	eb 82                	jmp    0x705958800484
    705958800502:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800509:	00 
    70595880050a:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    705958800511:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800518:	00 
    705958800519:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958800520:	00 00 00 
    705958800523:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595880052a:	00 00 00 
    70595880052d:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958800534:	63 00 00 
    705958800537:	ba 14 00 01 00       	mov    edx,0x10014
    70595880053c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958800542:	ff d0                	call   rax
    705958800544:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880054b:	00 
    70595880054c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800552:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800558:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880055e:	be 01 00 00 00       	mov    esi,0x1
    705958800563:	b9 02 00 00 00       	mov    ecx,0x2
    705958800568:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880056f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800576:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880057d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800584:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880058b:	e9 da 24 00 00       	jmp    0x705958802a6a
    705958800590:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958800597:	00 
    705958800598:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    70595880059f:	c1 e9 0c             	shr    ecx,0xc
    7059588005a2:	89 c9                	mov    ecx,ecx
    7059588005a4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588005a8:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    7059588005af:	00 
    7059588005b0:	48 83 f8 00          	cmp    rax,0x0
    7059588005b4:	74 23                	je     0x7059588005d9
    7059588005b6:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    7059588005bd:	00 
    7059588005be:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    7059588005c5:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    7059588005cc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588005d2:	89 c9                	mov    ecx,ecx
    7059588005d4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588005d7:	eb 51                	jmp    0x70595880062a
    7059588005d9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588005e0:	00 
    7059588005e1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    7059588005e8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    7059588005ef:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588005f6:	00 
    7059588005f7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588005fe:	00 00 00 
    705958800601:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800608:	00 00 00 
    70595880060b:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958800612:	63 00 00 
    705958800615:	ff d0                	call   rax
    705958800617:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880061e:	00 
    70595880061f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800626:	75 32                	jne    0x70595880065a
    705958800628:	eb 7c                	jmp    0x7059588006a6
    70595880062a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800631:	00 
    705958800632:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    705958800639:	83 e8 04             	sub    eax,0x4
    70595880063c:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    705958800643:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    705958800646:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    70595880064d:	83 e0 03             	and    eax,0x3
    705958800650:	83 f8 00             	cmp    eax,0x0
    705958800653:	75 53                	jne    0x7059588006a8
    705958800655:	e9 dc 00 00 00       	jmp    0x705958800736
    70595880065a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800661:	00 
    705958800662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880066e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800674:	be 01 00 00 00       	mov    esi,0x1
    705958800679:	b9 02 00 00 00       	mov    ecx,0x2
    70595880067e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880068c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880069a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588006a1:	e9 c4 23 00 00       	jmp    0x705958802a6a
    7059588006a6:	eb 82                	jmp    0x70595880062a
    7059588006a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588006af:	00 
    7059588006b0:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    7059588006b7:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588006be:	00 
    7059588006bf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588006c6:	00 00 00 
    7059588006c9:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    7059588006d0:	00 00 00 
    7059588006d3:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588006da:	63 00 00 
    7059588006dd:	ba 14 00 01 00       	mov    edx,0x10014
    7059588006e2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588006e8:	ff d0                	call   rax
    7059588006ea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588006f1:	00 
    7059588006f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588006f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588006fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800704:	be 01 00 00 00       	mov    esi,0x1
    705958800709:	b9 02 00 00 00       	mov    ecx,0x2
    70595880070e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800715:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880071c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800723:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880072a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800731:	e9 34 23 00 00       	jmp    0x705958802a6a
    705958800736:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    70595880073d:	00 
    70595880073e:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    705958800745:	c1 e9 0c             	shr    ecx,0xc
    705958800748:	89 c9                	mov    ecx,ecx
    70595880074a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880074e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    705958800755:	00 
    705958800756:	48 83 f8 00          	cmp    rax,0x0
    70595880075a:	74 23                	je     0x70595880077f
    70595880075c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    705958800763:	00 
    705958800764:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    70595880076b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    705958800772:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958800778:	89 c9                	mov    ecx,ecx
    70595880077a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880077d:	eb 51                	jmp    0x7059588007d0
    70595880077f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800786:	00 
    705958800787:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    70595880078e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    705958800795:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    70595880079c:	00 
    70595880079d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588007a4:	00 00 00 
    7059588007a7:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    7059588007ae:	00 00 00 
    7059588007b1:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588007b8:	63 00 00 
    7059588007bb:	ff d0                	call   rax
    7059588007bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588007c4:	00 
    7059588007c5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588007cc:	75 32                	jne    0x705958800800
    7059588007ce:	eb 7c                	jmp    0x70595880084c
    7059588007d0:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588007d7:	00 
    7059588007d8:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    7059588007df:	83 e8 04             	sub    eax,0x4
    7059588007e2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    7059588007e9:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    7059588007ec:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    7059588007f3:	83 e0 03             	and    eax,0x3
    7059588007f6:	83 f8 00             	cmp    eax,0x0
    7059588007f9:	75 53                	jne    0x70595880084e
    7059588007fb:	e9 dc 00 00 00       	jmp    0x7059588008dc
    705958800800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800807:	00 
    705958800808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880080e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880081a:	be 01 00 00 00       	mov    esi,0x1
    70595880081f:	b9 02 00 00 00       	mov    ecx,0x2
    705958800824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880082b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800847:	e9 1e 22 00 00       	jmp    0x705958802a6a
    70595880084c:	eb 82                	jmp    0x7059588007d0
    70595880084e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800855:	00 
    705958800856:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    70595880085d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800864:	00 
    705958800865:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880086c:	00 00 00 
    70595880086f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800876:	00 00 00 
    705958800879:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958800880:	63 00 00 
    705958800883:	ba 14 00 01 00       	mov    edx,0x10014
    705958800888:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880088e:	ff d0                	call   rax
    705958800890:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800897:	00 
    705958800898:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880089e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588008a4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588008aa:	be 01 00 00 00       	mov    esi,0x1
    7059588008af:	b9 02 00 00 00       	mov    ecx,0x2
    7059588008b4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588008bb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588008c2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588008c9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588008d0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588008d7:	e9 8e 21 00 00       	jmp    0x705958802a6a
    7059588008dc:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588008e3:	00 
    7059588008e4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    7059588008eb:	c1 e9 0c             	shr    ecx,0xc
    7059588008ee:	89 c9                	mov    ecx,ecx
    7059588008f0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588008f4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    7059588008fb:	00 
    7059588008fc:	48 83 f8 00          	cmp    rax,0x0
    705958800900:	74 23                	je     0x705958800925
    705958800902:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    705958800909:	00 
    70595880090a:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    705958800911:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    705958800918:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880091e:	89 c9                	mov    ecx,ecx
    705958800920:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958800923:	eb 51                	jmp    0x705958800976
    705958800925:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880092c:	00 
    70595880092d:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    705958800934:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    70595880093b:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958800942:	00 
    705958800943:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880094a:	00 00 00 
    70595880094d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800954:	00 00 00 
    705958800957:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880095e:	63 00 00 
    705958800961:	ff d0                	call   rax
    705958800963:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880096a:	00 
    70595880096b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800972:	75 32                	jne    0x7059588009a6
    705958800974:	eb 7c                	jmp    0x7059588009f2
    705958800976:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880097d:	00 
    70595880097e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    705958800985:	83 e8 04             	sub    eax,0x4
    705958800988:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    70595880098f:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    705958800992:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    705958800999:	83 e0 03             	and    eax,0x3
    70595880099c:	83 f8 00             	cmp    eax,0x0
    70595880099f:	75 53                	jne    0x7059588009f4
    7059588009a1:	e9 dc 00 00 00       	jmp    0x705958800a82
    7059588009a6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588009ad:	00 
    7059588009ae:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588009b4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588009ba:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588009c0:	be 01 00 00 00       	mov    esi,0x1
    7059588009c5:	b9 02 00 00 00       	mov    ecx,0x2
    7059588009ca:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588009d1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588009d8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588009df:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588009e6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588009ed:	e9 78 20 00 00       	jmp    0x705958802a6a
    7059588009f2:	eb 82                	jmp    0x705958800976
    7059588009f4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588009fb:	00 
    7059588009fc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    705958800a03:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800a0a:	00 
    705958800a0b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958800a12:	00 00 00 
    705958800a15:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800a1c:	00 00 00 
    705958800a1f:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958800a26:	63 00 00 
    705958800a29:	ba 14 00 01 00       	mov    edx,0x10014
    705958800a2e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958800a34:	ff d0                	call   rax
    705958800a36:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800a3d:	00 
    705958800a3e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800a44:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800a4a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800a50:	be 01 00 00 00       	mov    esi,0x1
    705958800a55:	b9 02 00 00 00       	mov    ecx,0x2
    705958800a5a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800a61:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800a68:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800a6f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800a76:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800a7d:	e9 e8 1f 00 00       	jmp    0x705958802a6a
    705958800a82:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958800a89:	00 
    705958800a8a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    705958800a91:	c1 e9 0c             	shr    ecx,0xc
    705958800a94:	89 c9                	mov    ecx,ecx
    705958800a96:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958800a9a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    705958800aa1:	00 
    705958800aa2:	48 83 f8 00          	cmp    rax,0x0
    705958800aa6:	74 23                	je     0x705958800acb
    705958800aa8:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    705958800aaf:	00 
    705958800ab0:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    705958800ab7:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    705958800abe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958800ac4:	89 c9                	mov    ecx,ecx
    705958800ac6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958800ac9:	eb 51                	jmp    0x705958800b1c
    705958800acb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800ad2:	00 
    705958800ad3:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    705958800ada:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    705958800ae1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958800ae8:	00 
    705958800ae9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958800af0:	00 00 00 
    705958800af3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800afa:	00 00 00 
    705958800afd:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958800b04:	63 00 00 
    705958800b07:	ff d0                	call   rax
    705958800b09:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800b10:	00 
    705958800b11:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800b18:	75 32                	jne    0x705958800b4c
    705958800b1a:	eb 7c                	jmp    0x705958800b98
    705958800b1c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800b23:	00 
    705958800b24:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    705958800b2b:	83 e8 04             	sub    eax,0x4
    705958800b2e:	89 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],eax
    705958800b35:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    705958800b38:	89 8c 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],ecx
    705958800b3f:	83 e0 03             	and    eax,0x3
    705958800b42:	83 f8 00             	cmp    eax,0x0
    705958800b45:	75 53                	jne    0x705958800b9a
    705958800b47:	e9 dc 00 00 00       	jmp    0x705958800c28
    705958800b4c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800b53:	00 
    705958800b54:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800b5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800b60:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800b66:	be 01 00 00 00       	mov    esi,0x1
    705958800b6b:	b9 02 00 00 00       	mov    ecx,0x2
    705958800b70:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800b77:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800b7e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800b85:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800b8c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800b93:	e9 d2 1e 00 00       	jmp    0x705958802a6a
    705958800b98:	eb 82                	jmp    0x705958800b1c
    705958800b9a:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800ba1:	00 
    705958800ba2:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    705958800ba9:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800bb0:	00 
    705958800bb1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958800bb8:	00 00 00 
    705958800bbb:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800bc2:	00 00 00 
    705958800bc5:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958800bcc:	63 00 00 
    705958800bcf:	ba 14 00 01 00       	mov    edx,0x10014
    705958800bd4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958800bda:	ff d0                	call   rax
    705958800bdc:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800be3:	00 
    705958800be4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800bea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800bf0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800bf6:	be 01 00 00 00       	mov    esi,0x1
    705958800bfb:	b9 02 00 00 00       	mov    ecx,0x2
    705958800c00:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800c07:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800c0e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800c15:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800c1c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800c23:	e9 42 1e 00 00       	jmp    0x705958802a6a
    705958800c28:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958800c2f:	00 
    705958800c30:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    705958800c37:	c1 e9 0c             	shr    ecx,0xc
    705958800c3a:	89 c9                	mov    ecx,ecx
    705958800c3c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958800c40:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
    705958800c47:	00 
    705958800c48:	48 83 f8 00          	cmp    rax,0x0
    705958800c4c:	74 23                	je     0x705958800c71
    705958800c4e:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    705958800c55:	00 
    705958800c56:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    705958800c5d:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    705958800c64:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958800c6a:	89 c9                	mov    ecx,ecx
    705958800c6c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958800c6f:	eb 51                	jmp    0x705958800cc2
    705958800c71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800c78:	00 
    705958800c79:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    705958800c80:	8b b4 24 78 01 00 00 	mov    esi,DWORD PTR [rsp+0x178]
    705958800c87:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958800c8e:	00 
    705958800c8f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958800c96:	00 00 00 
    705958800c99:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800ca0:	00 00 00 
    705958800ca3:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958800caa:	63 00 00 
    705958800cad:	ff d0                	call   rax
    705958800caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800cb6:	00 
    705958800cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800cbe:	75 32                	jne    0x705958800cf2
    705958800cc0:	eb 7c                	jmp    0x705958800d3e
    705958800cc2:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800cc9:	00 
    705958800cca:	8b 84 24 78 01 00 00 	mov    eax,DWORD PTR [rsp+0x178]
    705958800cd1:	83 e8 04             	sub    eax,0x4
    705958800cd4:	89 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],eax
    705958800cdb:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    705958800cde:	89 8c 24 6c 01 00 00 	mov    DWORD PTR [rsp+0x16c],ecx
    705958800ce5:	83 e0 03             	and    eax,0x3
    705958800ce8:	83 f8 00             	cmp    eax,0x0
    705958800ceb:	75 53                	jne    0x705958800d40
    705958800ced:	e9 dc 00 00 00       	jmp    0x705958800dce
    705958800cf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800cf9:	00 
    705958800cfa:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800d00:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800d06:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800d0c:	be 01 00 00 00       	mov    esi,0x1
    705958800d11:	b9 02 00 00 00       	mov    ecx,0x2
    705958800d16:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800d1d:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800d24:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800d2b:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800d32:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800d39:	e9 2c 1d 00 00       	jmp    0x705958802a6a
    705958800d3e:	eb 82                	jmp    0x705958800cc2
    705958800d40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800d47:	00 
    705958800d48:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    705958800d4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800d56:	00 
    705958800d57:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958800d5e:	00 00 00 
    705958800d61:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800d68:	00 00 00 
    705958800d6b:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958800d72:	63 00 00 
    705958800d75:	ba 14 00 01 00       	mov    edx,0x10014
    705958800d7a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958800d80:	ff d0                	call   rax
    705958800d82:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800d89:	00 
    705958800d8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800d90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800d96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800d9c:	be 01 00 00 00       	mov    esi,0x1
    705958800da1:	b9 02 00 00 00       	mov    ecx,0x2
    705958800da6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800dad:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800db4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800dbb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800dc2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800dc9:	e9 9c 1c 00 00       	jmp    0x705958802a6a
    705958800dce:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958800dd5:	00 
    705958800dd6:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    705958800ddd:	c1 e9 0c             	shr    ecx,0xc
    705958800de0:	89 c9                	mov    ecx,ecx
    705958800de2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958800de6:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    705958800ded:	00 
    705958800dee:	48 83 f8 00          	cmp    rax,0x0
    705958800df2:	74 23                	je     0x705958800e17
    705958800df4:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    705958800dfb:	00 
    705958800dfc:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    705958800e03:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    705958800e0a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958800e10:	89 c9                	mov    ecx,ecx
    705958800e12:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958800e15:	eb 51                	jmp    0x705958800e68
    705958800e17:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800e1e:	00 
    705958800e1f:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    705958800e26:	8b b4 24 68 01 00 00 	mov    esi,DWORD PTR [rsp+0x168]
    705958800e2d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958800e34:	00 
    705958800e35:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958800e3c:	00 00 00 
    705958800e3f:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958800e46:	00 00 00 
    705958800e49:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958800e50:	63 00 00 
    705958800e53:	ff d0                	call   rax
    705958800e55:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800e5c:	00 
    705958800e5d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800e64:	75 26                	jne    0x705958800e8c
    705958800e66:	eb 70                	jmp    0x705958800ed8
    705958800e68:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    705958800e6f:	00 
    705958800e70:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800e77:	00 
    705958800e78:	8b 94 24 68 01 00 00 	mov    edx,DWORD PTR [rsp+0x168]
    705958800e7f:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    705958800e82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958800e85:	75 53                	jne    0x705958800eda
    705958800e87:	e9 93 00 00 00       	jmp    0x705958800f1f
    705958800e8c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800e93:	00 
    705958800e94:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800e9a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800ea0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800ea6:	be 01 00 00 00       	mov    esi,0x1
    705958800eab:	b9 02 00 00 00       	mov    ecx,0x2
    705958800eb0:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800eb7:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800ebe:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800ec5:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800ecc:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800ed3:	e9 92 1b 00 00       	jmp    0x705958802a6a
    705958800ed8:	eb 8e                	jmp    0x705958800e68
    705958800eda:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800ee1:	00 
    705958800ee2:	c7 87 bc 00 00 00 16 	mov    DWORD PTR [rdi+0xbc],0x10016
    705958800ee9:	00 01 00 
    705958800eec:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958800ef3:	00 00 00 
    705958800ef6:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958800efd:	00 00 00 
    705958800f00:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958800f07:	63 00 00 
    705958800f0a:	ff d0                	call   rax
    705958800f0c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800f13:	00 
    705958800f14:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958800f1b:	75 04                	jne    0x705958800f21
    705958800f1d:	eb 4e                	jmp    0x705958800f6d
    705958800f1f:	eb 4e                	jmp    0x705958800f6f
    705958800f21:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800f28:	00 
    705958800f29:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958800f2f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958800f35:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958800f3b:	be 01 00 00 00       	mov    esi,0x1
    705958800f40:	b9 02 00 00 00       	mov    ecx,0x2
    705958800f45:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958800f4c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958800f53:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958800f5a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958800f61:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958800f68:	e9 fd 1a 00 00       	jmp    0x705958802a6a
    705958800f6d:	eb b0                	jmp    0x705958800f1f
    705958800f6f:	eb 00                	jmp    0x705958800f71
    705958800f71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958800f78:	00 
    705958800f79:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    705958800f7c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958800f82:	83 c9 00             	or     ecx,0x0
    705958800f85:	89 8c 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],ecx
    705958800f8c:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958800f8f:	eb 00                	jmp    0x705958800f91
    705958800f91:	8b 84 24 68 01 00 00 	mov    eax,DWORD PTR [rsp+0x168]
    705958800f98:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958800f9f:	00 
    705958800fa0:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    705958800fa6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    705958800fad:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    705958800fb0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    705958800fb7:	83 e8 04             	sub    eax,0x4
    705958800fba:	89 84 24 58 01 00 00 	mov    DWORD PTR [rsp+0x158],eax
    705958800fc1:	83 e0 03             	and    eax,0x3
    705958800fc4:	83 f8 00             	cmp    eax,0x0
    705958800fc7:	0f 84 98 00 00 00    	je     0x705958801065
    705958800fcd:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958800fd4:	00 
    705958800fd5:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    705958800fdc:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958800fe3:	00 
    705958800fe4:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    705958800feb:	00 01 00 
    705958800fee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958800ff5:	00 00 00 
    705958800ff8:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958800fff:	00 00 00 
    705958801002:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958801009:	63 00 00 
    70595880100c:	ba 1a 00 01 00       	mov    edx,0x1001a
    705958801011:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958801017:	ff d0                	call   rax
    705958801019:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801020:	00 
    705958801021:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801027:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880102d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801033:	be 03 00 00 00       	mov    esi,0x3
    705958801038:	b9 04 00 00 00       	mov    ecx,0x4
    70595880103d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801044:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880104b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801052:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801059:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801060:	e9 05 1a 00 00       	jmp    0x705958802a6a
    705958801065:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    70595880106c:	00 
    70595880106d:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    705958801074:	c1 e9 0c             	shr    ecx,0xc
    705958801077:	89 c9                	mov    ecx,ecx
    705958801079:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880107d:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
    705958801084:	00 
    705958801085:	48 83 f8 00          	cmp    rax,0x0
    705958801089:	74 23                	je     0x7059588010ae
    70595880108b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    705958801092:	00 
    705958801093:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    70595880109a:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    7059588010a1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588010a7:	89 c9                	mov    ecx,ecx
    7059588010a9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588010ac:	eb 5b                	jmp    0x705958801109
    7059588010ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588010b5:	00 
    7059588010b6:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    7059588010bd:	8b b4 24 58 01 00 00 	mov    esi,DWORD PTR [rsp+0x158]
    7059588010c4:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588010cb:	00 
    7059588010cc:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    7059588010d3:	00 01 00 
    7059588010d6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    7059588010dd:	00 00 00 
    7059588010e0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    7059588010e7:	00 00 00 
    7059588010ea:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588010f1:	63 00 00 
    7059588010f4:	ff d0                	call   rax
    7059588010f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588010fd:	00 
    7059588010fe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801105:	75 20                	jne    0x705958801127
    705958801107:	eb 6a                	jmp    0x705958801173
    705958801109:	8b 84 24 58 01 00 00 	mov    eax,DWORD PTR [rsp+0x158]
    705958801110:	83 e8 04             	sub    eax,0x4
    705958801113:	89 84 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],eax
    70595880111a:	83 e0 03             	and    eax,0x3
    70595880111d:	83 f8 00             	cmp    eax,0x0
    705958801120:	75 53                	jne    0x705958801175
    705958801122:	e9 e6 00 00 00       	jmp    0x70595880120d
    705958801127:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880112e:	00 
    70595880112f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801135:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880113b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801141:	be 03 00 00 00       	mov    esi,0x3
    705958801146:	b9 04 00 00 00       	mov    ecx,0x4
    70595880114b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801152:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801159:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801160:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801167:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880116e:	e9 f7 18 00 00       	jmp    0x705958802a6a
    705958801173:	eb 94                	jmp    0x705958801109
    705958801175:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880117c:	00 
    70595880117d:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    705958801184:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    70595880118b:	00 
    70595880118c:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    705958801193:	00 01 00 
    705958801196:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880119d:	00 00 00 
    7059588011a0:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    7059588011a7:	00 00 00 
    7059588011aa:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588011b1:	63 00 00 
    7059588011b4:	ba 1a 00 01 00       	mov    edx,0x1001a
    7059588011b9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588011bf:	ff d0                	call   rax
    7059588011c1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588011c8:	00 
    7059588011c9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588011cf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588011d5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588011db:	be 03 00 00 00       	mov    esi,0x3
    7059588011e0:	b9 04 00 00 00       	mov    ecx,0x4
    7059588011e5:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588011ec:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588011f3:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588011fa:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801201:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801208:	e9 5d 18 00 00       	jmp    0x705958802a6a
    70595880120d:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958801214:	00 
    705958801215:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    70595880121c:	c1 e9 0c             	shr    ecx,0xc
    70595880121f:	89 c9                	mov    ecx,ecx
    705958801221:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958801225:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    70595880122c:	00 
    70595880122d:	48 83 f8 00          	cmp    rax,0x0
    705958801231:	74 23                	je     0x705958801256
    705958801233:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    70595880123a:	00 
    70595880123b:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    705958801242:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    705958801249:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880124f:	89 c9                	mov    ecx,ecx
    705958801251:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958801254:	eb 5b                	jmp    0x7059588012b1
    705958801256:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880125d:	00 
    70595880125e:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    705958801265:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    70595880126c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801273:	00 
    705958801274:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    70595880127b:	00 01 00 
    70595880127e:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958801285:	00 00 00 
    705958801288:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    70595880128f:	00 00 00 
    705958801292:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958801299:	63 00 00 
    70595880129c:	ff d0                	call   rax
    70595880129e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588012a5:	00 
    7059588012a6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588012ad:	75 2c                	jne    0x7059588012db
    7059588012af:	eb 76                	jmp    0x705958801327
    7059588012b1:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    7059588012b8:	00 
    7059588012b9:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588012c0:	00 
    7059588012c1:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    7059588012c8:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    7059588012cb:	83 ea 14             	sub    edx,0x14
    7059588012ce:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    7059588012d1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7059588012d4:	75 53                	jne    0x705958801329
    7059588012d6:	e9 93 00 00 00       	jmp    0x70595880136e
    7059588012db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588012e2:	00 
    7059588012e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588012e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588012ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588012f5:	be 03 00 00 00       	mov    esi,0x3
    7059588012fa:	b9 04 00 00 00       	mov    ecx,0x4
    7059588012ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801306:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880130d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801314:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880131b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801322:	e9 43 17 00 00       	jmp    0x705958802a6a
    705958801327:	eb 88                	jmp    0x7059588012b1
    705958801329:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801330:	00 
    705958801331:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1001e
    705958801338:	00 01 00 
    70595880133b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958801342:	00 00 00 
    705958801345:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    70595880134c:	00 00 00 
    70595880134f:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958801356:	63 00 00 
    705958801359:	ff d0                	call   rax
    70595880135b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801362:	00 
    705958801363:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880136a:	75 04                	jne    0x705958801370
    70595880136c:	eb 4e                	jmp    0x7059588013bc
    70595880136e:	eb 4e                	jmp    0x7059588013be
    705958801370:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801377:	00 
    705958801378:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880137e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801384:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880138a:	be 03 00 00 00       	mov    esi,0x3
    70595880138f:	b9 04 00 00 00       	mov    ecx,0x4
    705958801394:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880139b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588013a2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588013a9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588013b0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588013b7:	e9 ae 16 00 00       	jmp    0x705958802a6a
    7059588013bc:	eb b0                	jmp    0x70595880136e
    7059588013be:	eb 00                	jmp    0x7059588013c0
    7059588013c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588013c7:	00 
    7059588013c8:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    7059588013cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588013d5:	81 c9 00 f0 00 00    	or     ecx,0xf000
    7059588013db:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    7059588013e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    7059588013e5:	eb 00                	jmp    0x7059588013e7
    7059588013e7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588013ee:	00 
    7059588013ef:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    7059588013f2:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588013f8:	81 c9 00 00 42 43    	or     ecx,0x43420000
    7059588013fe:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    705958801405:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    705958801408:	eb 00                	jmp    0x70595880140a
    70595880140a:	8b 84 24 34 01 00 00 	mov    eax,DWORD PTR [rsp+0x134]
    705958801411:	83 e0 03             	and    eax,0x3
    705958801414:	83 f8 00             	cmp    eax,0x0
    705958801417:	0f 84 97 00 00 00    	je     0x7059588014b4
    70595880141d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801424:	00 
    705958801425:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    70595880142c:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801433:	00 
    705958801434:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10026
    70595880143b:	00 01 00 
    70595880143e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958801445:	00 00 00 
    705958801448:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    70595880144f:	00 00 00 
    705958801452:	31 c0                	xor    eax,eax
    705958801454:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880145b:	63 00 00 
    70595880145e:	ba 26 00 01 00       	mov    edx,0x10026
    705958801463:	45 31 c0             	xor    r8d,r8d
    705958801466:	ff d0                	call   rax
    705958801468:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880146f:	00 
    705958801470:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801476:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880147c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801482:	be 06 00 00 00       	mov    esi,0x6
    705958801487:	b9 02 00 00 00       	mov    ecx,0x2
    70595880148c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801493:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880149a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588014a1:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588014a8:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588014af:	e9 b6 15 00 00       	jmp    0x705958802a6a
    7059588014b4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588014bb:	00 
    7059588014bc:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    7059588014c3:	c1 e9 0c             	shr    ecx,0xc
    7059588014c6:	89 c9                	mov    ecx,ecx
    7059588014c8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588014cc:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    7059588014d3:	00 
    7059588014d4:	48 83 f8 00          	cmp    rax,0x0
    7059588014d8:	74 23                	je     0x7059588014fd
    7059588014da:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    7059588014e1:	00 
    7059588014e2:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    7059588014e9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588014ef:	89 c9                	mov    ecx,ecx
    7059588014f1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588014f4:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    7059588014fb:	eb 5d                	jmp    0x70595880155a
    7059588014fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801504:	00 
    705958801505:	8b b4 24 34 01 00 00 	mov    esi,DWORD PTR [rsp+0x134]
    70595880150c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801513:	00 
    705958801514:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10026
    70595880151b:	00 01 00 
    70595880151e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958801525:	00 00 00 
    705958801528:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    70595880152f:	00 00 00 
    705958801532:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958801539:	63 00 00 
    70595880153c:	ff d0                	call   rax
    70595880153e:	89 c1                	mov    ecx,eax
    705958801540:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801547:	00 
    705958801548:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    70595880154f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801556:	75 1c                	jne    0x705958801574
    705958801558:	eb 66                	jmp    0x7059588015c0
    70595880155a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801561:	00 
    705958801562:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    705958801569:	89 8c 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],ecx
    705958801570:	89 08                	mov    DWORD PTR [rax],ecx
    705958801572:	eb 5c                	jmp    0x7059588015d0
    705958801574:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880157b:	00 
    70595880157c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801582:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801588:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880158e:	be 06 00 00 00       	mov    esi,0x6
    705958801593:	b9 02 00 00 00       	mov    ecx,0x2
    705958801598:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880159f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588015a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588015ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588015b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588015bb:	e9 aa 14 00 00       	jmp    0x705958802a6a
    7059588015c0:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    7059588015c7:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    7059588015ce:	eb 8a                	jmp    0x70595880155a
    7059588015d0:	eb 00                	jmp    0x7059588015d2
    7059588015d2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588015d9:	00 
    7059588015da:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    7059588015e1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588015e7:	81 c9 31 4e 00 00    	or     ecx,0x4e31
    7059588015ed:	89 8c 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],ecx
    7059588015f4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    7059588015f7:	eb 00                	jmp    0x7059588015f9
    7059588015f9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801600:	00 
    705958801601:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    705958801608:	8b bc 24 1c 01 00 00 	mov    edi,DWORD PTR [rsp+0x11c]
    70595880160f:	89 fa                	mov    edx,edi
    705958801611:	29 ca                	sub    edx,ecx
    705958801613:	83 fa 00             	cmp    edx,0x0
    705958801616:	0f 94 c3             	sete   bl
    705958801619:	80 e3 01             	and    bl,0x1
    70595880161c:	0f b6 f3             	movzx  esi,bl
    70595880161f:	89 b4 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],esi
    705958801626:	c1 ea 1f             	shr    edx,0x1f
    705958801629:	89 fb                	mov    ebx,edi
    70595880162b:	c1 eb 1f             	shr    ebx,0x1f
    70595880162e:	41 89 c8             	mov    r8d,ecx
    705958801631:	41 c1 e8 1f          	shr    r8d,0x1f
    705958801635:	89 d5                	mov    ebp,edx
    705958801637:	31 dd                	xor    ebp,ebx
    705958801639:	44 31 c3             	xor    ebx,r8d
    70595880163c:	21 eb                	and    ebx,ebp
    70595880163e:	31 da                	xor    edx,ebx
    705958801640:	39 f9                	cmp    ecx,edi
    705958801642:	0f 96 c1             	setbe  cl
    705958801645:	80 e1 01             	and    cl,0x1
    705958801648:	0f b6 c9             	movzx  ecx,cl
    70595880164b:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    705958801651:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958801657:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880165d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958801663:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958801669:	eb 00                	jmp    0x70595880166b
    70595880166b:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    705958801672:	83 f8 00             	cmp    eax,0x0
    705958801675:	74 33                	je     0x7059588016aa
    705958801677:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880167e:	00 
    70595880167f:	c7 81 bc 00 00 00 40 	mov    DWORD PTR [rcx+0xbc],0x10040
    705958801686:	00 01 00 
    705958801689:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880168f:	83 c0 09             	add    eax,0x9
    705958801692:	89 84 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],eax
    705958801699:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880169f:	0f 82 35 13 00 00    	jb     0x7059588029da
    7059588016a5:	e9 53 13 00 00       	jmp    0x7059588029fd
    7059588016aa:	eb 00                	jmp    0x7059588016ac
    7059588016ac:	eb 00                	jmp    0x7059588016ae
    7059588016ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588016b5:	00 
    7059588016b6:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    7059588016bc:	eb 00                	jmp    0x7059588016be
    7059588016be:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588016c5:	00 
    7059588016c6:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    7059588016cd:	83 c1 10             	add    ecx,0x10
    7059588016d0:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    7059588016d7:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    7059588016da:	eb 00                	jmp    0x7059588016dc
    7059588016dc:	8b 84 24 0c 01 00 00 	mov    eax,DWORD PTR [rsp+0x10c]
    7059588016e3:	83 e0 03             	and    eax,0x3
    7059588016e6:	83 f8 00             	cmp    eax,0x0
    7059588016e9:	0f 84 98 00 00 00    	je     0x705958801787
    7059588016ef:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588016f6:	00 
    7059588016f7:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    7059588016fe:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801705:	00 
    705958801706:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10034
    70595880170d:	00 01 00 
    705958801710:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958801717:	00 00 00 
    70595880171a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    705958801721:	00 00 00 
    705958801724:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880172b:	63 00 00 
    70595880172e:	ba 34 00 01 00       	mov    edx,0x10034
    705958801733:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958801739:	ff d0                	call   rax
    70595880173b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801742:	00 
    705958801743:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801749:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880174f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801755:	be 0c 00 00 00       	mov    esi,0xc
    70595880175a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880175f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801766:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880176d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801774:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880177b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801782:	e9 e3 12 00 00       	jmp    0x705958802a6a
    705958801787:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    70595880178e:	00 
    70595880178f:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    705958801796:	c1 e9 0c             	shr    ecx,0xc
    705958801799:	89 c9                	mov    ecx,ecx
    70595880179b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880179f:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    7059588017a6:	00 
    7059588017a7:	48 83 f8 00          	cmp    rax,0x0
    7059588017ab:	74 20                	je     0x7059588017cd
    7059588017ad:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    7059588017b4:	00 
    7059588017b5:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    7059588017bc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588017c2:	89 c9                	mov    ecx,ecx
    7059588017c4:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    7059588017cb:	eb 59                	jmp    0x705958801826
    7059588017cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588017d4:	00 
    7059588017d5:	8b b4 24 0c 01 00 00 	mov    esi,DWORD PTR [rsp+0x10c]
    7059588017dc:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588017e3:	00 
    7059588017e4:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10034
    7059588017eb:	00 01 00 
    7059588017ee:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588017f5:	00 00 00 
    7059588017f8:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    7059588017ff:	00 00 00 
    705958801802:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958801809:	63 00 00 
    70595880180c:	ba 03 00 00 00       	mov    edx,0x3
    705958801811:	ff d0                	call   rax
    705958801813:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880181a:	00 
    70595880181b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801822:	75 14                	jne    0x705958801838
    705958801824:	eb 5e                	jmp    0x705958801884
    705958801826:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    70595880182d:	00 
    70595880182e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958801831:	75 53                	jne    0x705958801886
    705958801833:	e9 93 00 00 00       	jmp    0x7059588018cb
    705958801838:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880183f:	00 
    705958801840:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801846:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880184c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801852:	be 0c 00 00 00       	mov    esi,0xc
    705958801857:	b9 02 00 00 00       	mov    ecx,0x2
    70595880185c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801863:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880186a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801871:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801878:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880187f:	e9 e6 11 00 00       	jmp    0x705958802a6a
    705958801884:	eb a0                	jmp    0x705958801826
    705958801886:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880188d:	00 
    70595880188e:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10036
    705958801895:	00 01 00 
    705958801898:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880189f:	00 00 00 
    7059588018a2:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    7059588018a9:	00 00 00 
    7059588018ac:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059588018b3:	63 00 00 
    7059588018b6:	ff d0                	call   rax
    7059588018b8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588018bf:	00 
    7059588018c0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588018c7:	75 04                	jne    0x7059588018cd
    7059588018c9:	eb 4e                	jmp    0x705958801919
    7059588018cb:	eb 4e                	jmp    0x70595880191b
    7059588018cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588018d4:	00 
    7059588018d5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588018db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588018e1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588018e7:	be 0c 00 00 00       	mov    esi,0xc
    7059588018ec:	b9 02 00 00 00       	mov    ecx,0x2
    7059588018f1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588018f8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588018ff:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801906:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880190d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801914:	e9 51 11 00 00       	jmp    0x705958802a6a
    705958801919:	eb b0                	jmp    0x7059588018cb
    70595880191b:	eb 00                	jmp    0x70595880191d
    70595880191d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801924:	00 
    705958801925:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    70595880192b:	eb 00                	jmp    0x70595880192d
    70595880192d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    705958801934:	83 e0 03             	and    eax,0x3
    705958801937:	83 f8 00             	cmp    eax,0x0
    70595880193a:	0f 84 97 00 00 00    	je     0x7059588019d7
    705958801940:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801947:	00 
    705958801948:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    70595880194f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801956:	00 
    705958801957:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    70595880195e:	00 01 00 
    705958801961:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958801968:	00 00 00 
    70595880196b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    705958801972:	00 00 00 
    705958801975:	31 c0                	xor    eax,eax
    705958801977:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880197e:	63 00 00 
    705958801981:	ba 38 00 01 00       	mov    edx,0x10038
    705958801986:	45 31 c0             	xor    r8d,r8d
    705958801989:	ff d0                	call   rax
    70595880198b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801992:	00 
    705958801993:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801999:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880199f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588019a5:	be 0e 00 00 00       	mov    esi,0xe
    7059588019aa:	b9 04 00 00 00       	mov    ecx,0x4
    7059588019af:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588019b6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588019bd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588019c4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588019cb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588019d2:	e9 93 10 00 00       	jmp    0x705958802a6a
    7059588019d7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588019de:	00 
    7059588019df:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    7059588019e6:	c1 e9 0c             	shr    ecx,0xc
    7059588019e9:	89 c9                	mov    ecx,ecx
    7059588019eb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588019ef:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    7059588019f6:	00 
    7059588019f7:	48 83 f8 00          	cmp    rax,0x0
    7059588019fb:	74 23                	je     0x705958801a20
    7059588019fd:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    705958801a04:	00 
    705958801a05:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    705958801a0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958801a12:	89 c9                	mov    ecx,ecx
    705958801a14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958801a17:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    705958801a1e:	eb 5d                	jmp    0x705958801a7d
    705958801a20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801a27:	00 
    705958801a28:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    705958801a2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801a36:	00 
    705958801a37:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    705958801a3e:	00 01 00 
    705958801a41:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958801a48:	00 00 00 
    705958801a4b:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    705958801a52:	00 00 00 
    705958801a55:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958801a5c:	63 00 00 
    705958801a5f:	ff d0                	call   rax
    705958801a61:	89 c1                	mov    ecx,eax
    705958801a63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801a6a:	00 
    705958801a6b:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    705958801a72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801a79:	75 2e                	jne    0x705958801aa9
    705958801a7b:	eb 78                	jmp    0x705958801af5
    705958801a7d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    705958801a84:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    705958801a8b:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    705958801a92:	83 c0 04             	add    eax,0x4
    705958801a95:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    705958801a9c:	83 e0 03             	and    eax,0x3
    705958801a9f:	83 f8 00             	cmp    eax,0x0
    705958801aa2:	75 64                	jne    0x705958801b08
    705958801aa4:	e9 f6 00 00 00       	jmp    0x705958801b9f
    705958801aa9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801ab0:	00 
    705958801ab1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801ab7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801abd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801ac3:	be 0e 00 00 00       	mov    esi,0xe
    705958801ac8:	b9 04 00 00 00       	mov    ecx,0x4
    705958801acd:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801ad4:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801adb:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801ae2:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801ae9:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801af0:	e9 75 0f 00 00       	jmp    0x705958802a6a
    705958801af5:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    705958801afc:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    705958801b03:	e9 75 ff ff ff       	jmp    0x705958801a7d
    705958801b08:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801b0f:	00 
    705958801b10:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    705958801b17:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801b1e:	00 
    705958801b1f:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    705958801b26:	00 01 00 
    705958801b29:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958801b30:	00 00 00 
    705958801b33:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    705958801b3a:	00 00 00 
    705958801b3d:	31 c0                	xor    eax,eax
    705958801b3f:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958801b46:	63 00 00 
    705958801b49:	ba 38 00 01 00       	mov    edx,0x10038
    705958801b4e:	45 31 c0             	xor    r8d,r8d
    705958801b51:	ff d0                	call   rax
    705958801b53:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801b5a:	00 
    705958801b5b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801b61:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801b67:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801b6d:	be 0e 00 00 00       	mov    esi,0xe
    705958801b72:	b9 04 00 00 00       	mov    ecx,0x4
    705958801b77:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801b7e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801b85:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801b8c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801b93:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801b9a:	e9 cb 0e 00 00       	jmp    0x705958802a6a
    705958801b9f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958801ba6:	00 
    705958801ba7:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    705958801bae:	c1 e9 0c             	shr    ecx,0xc
    705958801bb1:	89 c9                	mov    ecx,ecx
    705958801bb3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958801bb7:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    705958801bbe:	00 
    705958801bbf:	48 83 f8 00          	cmp    rax,0x0
    705958801bc3:	74 23                	je     0x705958801be8
    705958801bc5:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    705958801bcc:	00 
    705958801bcd:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    705958801bd4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958801bda:	89 c9                	mov    ecx,ecx
    705958801bdc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958801bdf:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    705958801be6:	eb 60                	jmp    0x705958801c48
    705958801be8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801bef:	00 
    705958801bf0:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    705958801bf7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801bfe:	00 
    705958801bff:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    705958801c06:	00 01 00 
    705958801c09:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958801c10:	00 00 00 
    705958801c13:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    705958801c1a:	00 00 00 
    705958801c1d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958801c24:	63 00 00 
    705958801c27:	ff d0                	call   rax
    705958801c29:	89 c1                	mov    ecx,eax
    705958801c2b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801c32:	00 
    705958801c33:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    705958801c3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801c41:	75 41                	jne    0x705958801c84
    705958801c43:	e9 88 00 00 00       	jmp    0x705958801cd0
    705958801c48:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801c4f:	00 
    705958801c50:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    705958801c57:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    705958801c5e:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    705958801c65:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    705958801c6c:	83 c1 04             	add    ecx,0x4
    705958801c6f:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    705958801c76:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    705958801c79:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    705958801c7f:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    705958801c82:	eb 5f                	jmp    0x705958801ce3
    705958801c84:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801c8b:	00 
    705958801c8c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801c92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801c98:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801c9e:	be 0e 00 00 00       	mov    esi,0xe
    705958801ca3:	b9 04 00 00 00       	mov    ecx,0x4
    705958801ca8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801caf:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801cb6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801cbd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801cc4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801ccb:	e9 9a 0d 00 00       	jmp    0x705958802a6a
    705958801cd0:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    705958801cd7:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    705958801cde:	e9 65 ff ff ff       	jmp    0x705958801c48
    705958801ce3:	eb 00                	jmp    0x705958801ce5
    705958801ce5:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    705958801cec:	83 e0 03             	and    eax,0x3
    705958801cef:	83 f8 00             	cmp    eax,0x0
    705958801cf2:	0f 84 97 00 00 00    	je     0x705958801d8f
    705958801cf8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801cff:	00 
    705958801d00:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    705958801d07:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801d0e:	00 
    705958801d0f:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    705958801d16:	00 01 00 
    705958801d19:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958801d20:	00 00 00 
    705958801d23:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    705958801d2a:	00 00 00 
    705958801d2d:	31 c0                	xor    eax,eax
    705958801d2f:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958801d36:	63 00 00 
    705958801d39:	ba 3c 00 01 00       	mov    edx,0x1003c
    705958801d3e:	45 31 c0             	xor    r8d,r8d
    705958801d41:	ff d0                	call   rax
    705958801d43:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801d4a:	00 
    705958801d4b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801d51:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801d57:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801d5d:	be 0f 00 00 00       	mov    esi,0xf
    705958801d62:	b9 02 00 00 00       	mov    ecx,0x2
    705958801d67:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801d6e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801d75:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801d7c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801d83:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801d8a:	e9 db 0c 00 00       	jmp    0x705958802a6a
    705958801d8f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958801d96:	00 
    705958801d97:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    705958801d9e:	c1 e9 0c             	shr    ecx,0xc
    705958801da1:	89 c9                	mov    ecx,ecx
    705958801da3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958801da7:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    705958801dae:	00 
    705958801daf:	48 83 f8 00          	cmp    rax,0x0
    705958801db3:	74 23                	je     0x705958801dd8
    705958801db5:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    705958801dbc:	00 
    705958801dbd:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    705958801dc4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958801dca:	89 c9                	mov    ecx,ecx
    705958801dcc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958801dcf:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    705958801dd6:	eb 5d                	jmp    0x705958801e35
    705958801dd8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801ddf:	00 
    705958801de0:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    705958801de7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801dee:	00 
    705958801def:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    705958801df6:	00 01 00 
    705958801df9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958801e00:	00 00 00 
    705958801e03:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    705958801e0a:	00 00 00 
    705958801e0d:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958801e14:	63 00 00 
    705958801e17:	ff d0                	call   rax
    705958801e19:	89 c1                	mov    ecx,eax
    705958801e1b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801e22:	00 
    705958801e23:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    705958801e2a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801e31:	75 32                	jne    0x705958801e65
    705958801e33:	eb 7c                	jmp    0x705958801eb1
    705958801e35:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    705958801e3c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958801e43:	00 
    705958801e44:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    705958801e4b:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    705958801e4e:	83 c0 04             	add    eax,0x4
    705958801e51:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    705958801e58:	83 e0 03             	and    eax,0x3
    705958801e5b:	83 f8 00             	cmp    eax,0x0
    705958801e5e:	75 64                	jne    0x705958801ec4
    705958801e60:	e9 f6 00 00 00       	jmp    0x705958801f5b
    705958801e65:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801e6c:	00 
    705958801e6d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801e73:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801e79:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801e7f:	be 0f 00 00 00       	mov    esi,0xf
    705958801e84:	b9 02 00 00 00       	mov    ecx,0x2
    705958801e89:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801e90:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801e97:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801e9e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801ea5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801eac:	e9 b9 0b 00 00       	jmp    0x705958802a6a
    705958801eb1:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    705958801eb8:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    705958801ebf:	e9 71 ff ff ff       	jmp    0x705958801e35
    705958801ec4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958801ecb:	00 
    705958801ecc:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    705958801ed3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958801eda:	00 
    705958801edb:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    705958801ee2:	00 01 00 
    705958801ee5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958801eec:	00 00 00 
    705958801eef:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    705958801ef6:	00 00 00 
    705958801ef9:	31 c0                	xor    eax,eax
    705958801efb:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958801f02:	63 00 00 
    705958801f05:	ba 3c 00 01 00       	mov    edx,0x1003c
    705958801f0a:	45 31 c0             	xor    r8d,r8d
    705958801f0d:	ff d0                	call   rax
    705958801f0f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801f16:	00 
    705958801f17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958801f1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958801f23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958801f29:	be 0f 00 00 00       	mov    esi,0xf
    705958801f2e:	b9 02 00 00 00       	mov    ecx,0x2
    705958801f33:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958801f3a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958801f41:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958801f48:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958801f4f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958801f56:	e9 0f 0b 00 00       	jmp    0x705958802a6a
    705958801f5b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958801f62:	00 
    705958801f63:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    705958801f6a:	c1 e9 0c             	shr    ecx,0xc
    705958801f6d:	89 c9                	mov    ecx,ecx
    705958801f6f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958801f73:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    705958801f7a:	00 
    705958801f7b:	48 83 f8 00          	cmp    rax,0x0
    705958801f7f:	74 23                	je     0x705958801fa4
    705958801f81:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    705958801f88:	00 
    705958801f89:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    705958801f90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958801f96:	89 c9                	mov    ecx,ecx
    705958801f98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958801f9b:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    705958801fa2:	eb 5d                	jmp    0x705958802001
    705958801fa4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801fab:	00 
    705958801fac:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    705958801fb3:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958801fba:	00 
    705958801fbb:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    705958801fc2:	00 01 00 
    705958801fc5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958801fcc:	00 00 00 
    705958801fcf:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    705958801fd6:	00 00 00 
    705958801fd9:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958801fe0:	63 00 00 
    705958801fe3:	ff d0                	call   rax
    705958801fe5:	89 c1                	mov    ecx,eax
    705958801fe7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958801fee:	00 
    705958801fef:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    705958801ff6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958801ffd:	75 32                	jne    0x705958802031
    705958801fff:	eb 7c                	jmp    0x70595880207d
    705958802001:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    705958802008:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880200f:	00 
    705958802010:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    705958802017:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    70595880201a:	83 c0 04             	add    eax,0x4
    70595880201d:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    705958802024:	83 e0 03             	and    eax,0x3
    705958802027:	83 f8 00             	cmp    eax,0x0
    70595880202a:	75 64                	jne    0x705958802090
    70595880202c:	e9 f6 00 00 00       	jmp    0x705958802127
    705958802031:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802038:	00 
    705958802039:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880203f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802045:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880204b:	be 0f 00 00 00       	mov    esi,0xf
    705958802050:	b9 02 00 00 00       	mov    ecx,0x2
    705958802055:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880205c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958802063:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880206a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958802071:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802078:	e9 ed 09 00 00       	jmp    0x705958802a6a
    70595880207d:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    705958802084:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    70595880208b:	e9 71 ff ff ff       	jmp    0x705958802001
    705958802090:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958802097:	00 
    705958802098:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880209f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588020a6:	00 
    7059588020a7:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    7059588020ae:	00 01 00 
    7059588020b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588020b8:	00 00 00 
    7059588020bb:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    7059588020c2:	00 00 00 
    7059588020c5:	31 c0                	xor    eax,eax
    7059588020c7:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588020ce:	63 00 00 
    7059588020d1:	ba 3c 00 01 00       	mov    edx,0x1003c
    7059588020d6:	45 31 c0             	xor    r8d,r8d
    7059588020d9:	ff d0                	call   rax
    7059588020db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588020e2:	00 
    7059588020e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588020e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588020ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588020f5:	be 0f 00 00 00       	mov    esi,0xf
    7059588020fa:	b9 02 00 00 00       	mov    ecx,0x2
    7059588020ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958802106:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880210d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802114:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880211b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802122:	e9 43 09 00 00       	jmp    0x705958802a6a
    705958802127:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    70595880212e:	00 
    70595880212f:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    705958802136:	c1 e9 0c             	shr    ecx,0xc
    705958802139:	89 c9                	mov    ecx,ecx
    70595880213b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880213f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    705958802146:	00 
    705958802147:	48 83 f8 00          	cmp    rax,0x0
    70595880214b:	74 23                	je     0x705958802170
    70595880214d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    705958802154:	00 
    705958802155:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    70595880215c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958802162:	89 c9                	mov    ecx,ecx
    705958802164:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958802167:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    70595880216e:	eb 5d                	jmp    0x7059588021cd
    705958802170:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802177:	00 
    705958802178:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    70595880217f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958802186:	00 
    705958802187:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    70595880218e:	00 01 00 
    705958802191:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802198:	00 00 00 
    70595880219b:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    7059588021a2:	00 00 00 
    7059588021a5:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588021ac:	63 00 00 
    7059588021af:	ff d0                	call   rax
    7059588021b1:	89 c1                	mov    ecx,eax
    7059588021b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588021ba:	00 
    7059588021bb:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    7059588021c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588021c9:	75 32                	jne    0x7059588021fd
    7059588021cb:	eb 7c                	jmp    0x705958802249
    7059588021cd:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    7059588021d4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588021db:	00 
    7059588021dc:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    7059588021e3:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    7059588021e6:	83 c0 04             	add    eax,0x4
    7059588021e9:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    7059588021f0:	83 e0 03             	and    eax,0x3
    7059588021f3:	83 f8 00             	cmp    eax,0x0
    7059588021f6:	75 64                	jne    0x70595880225c
    7059588021f8:	e9 f6 00 00 00       	jmp    0x7059588022f3
    7059588021fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802204:	00 
    705958802205:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880220b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802211:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958802217:	be 0f 00 00 00       	mov    esi,0xf
    70595880221c:	b9 02 00 00 00       	mov    ecx,0x2
    705958802221:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958802228:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880222f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802236:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880223d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802244:	e9 21 08 00 00       	jmp    0x705958802a6a
    705958802249:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    705958802250:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    705958802257:	e9 71 ff ff ff       	jmp    0x7059588021cd
    70595880225c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958802263:	00 
    705958802264:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    70595880226b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958802272:	00 
    705958802273:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    70595880227a:	00 01 00 
    70595880227d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958802284:	00 00 00 
    705958802287:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    70595880228e:	00 00 00 
    705958802291:	31 c0                	xor    eax,eax
    705958802293:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880229a:	63 00 00 
    70595880229d:	ba 3c 00 01 00       	mov    edx,0x1003c
    7059588022a2:	45 31 c0             	xor    r8d,r8d
    7059588022a5:	ff d0                	call   rax
    7059588022a7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588022ae:	00 
    7059588022af:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588022b5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588022bb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588022c1:	be 0f 00 00 00       	mov    esi,0xf
    7059588022c6:	b9 02 00 00 00       	mov    ecx,0x2
    7059588022cb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588022d2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588022d9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588022e0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588022e7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588022ee:	e9 77 07 00 00       	jmp    0x705958802a6a
    7059588022f3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588022fa:	00 
    7059588022fb:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    705958802302:	c1 e9 0c             	shr    ecx,0xc
    705958802305:	89 c9                	mov    ecx,ecx
    705958802307:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880230b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    705958802312:	00 
    705958802313:	48 83 f8 00          	cmp    rax,0x0
    705958802317:	74 20                	je     0x705958802339
    705958802319:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958802320:	00 
    705958802321:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    705958802328:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880232e:	89 c9                	mov    ecx,ecx
    705958802330:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958802333:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    705958802337:	eb 5a                	jmp    0x705958802393
    705958802339:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802340:	00 
    705958802341:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    705958802348:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    70595880234f:	00 
    705958802350:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    705958802357:	00 01 00 
    70595880235a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802361:	00 00 00 
    705958802364:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    70595880236b:	00 00 00 
    70595880236e:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958802375:	63 00 00 
    705958802378:	ff d0                	call   rax
    70595880237a:	89 c1                	mov    ecx,eax
    70595880237c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802383:	00 
    705958802384:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    705958802388:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880238f:	75 2c                	jne    0x7059588023bd
    705958802391:	eb 76                	jmp    0x705958802409
    705958802393:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    70595880239a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588023a1:	00 
    7059588023a2:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    7059588023a6:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    7059588023a9:	83 c0 04             	add    eax,0x4
    7059588023ac:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    7059588023b0:	83 e0 03             	and    eax,0x3
    7059588023b3:	83 f8 00             	cmp    eax,0x0
    7059588023b6:	75 5b                	jne    0x705958802413
    7059588023b8:	e9 ea 00 00 00       	jmp    0x7059588024a7
    7059588023bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588023c4:	00 
    7059588023c5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588023cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588023d1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588023d7:	be 0f 00 00 00       	mov    esi,0xf
    7059588023dc:	b9 02 00 00 00       	mov    ecx,0x2
    7059588023e1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588023e8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588023ef:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588023f6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588023fd:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802404:	e9 61 06 00 00       	jmp    0x705958802a6a
    705958802409:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    70595880240d:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    705958802411:	eb 80                	jmp    0x705958802393
    705958802413:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880241a:	00 
    70595880241b:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880241f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958802426:	00 
    705958802427:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    70595880242e:	00 01 00 
    705958802431:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958802438:	00 00 00 
    70595880243b:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    705958802442:	00 00 00 
    705958802445:	31 c0                	xor    eax,eax
    705958802447:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880244e:	63 00 00 
    705958802451:	ba 3c 00 01 00       	mov    edx,0x1003c
    705958802456:	45 31 c0             	xor    r8d,r8d
    705958802459:	ff d0                	call   rax
    70595880245b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802462:	00 
    705958802463:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958802469:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880246f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958802475:	be 0f 00 00 00       	mov    esi,0xf
    70595880247a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880247f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958802486:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880248d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802494:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880249b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588024a2:	e9 c3 05 00 00       	jmp    0x705958802a6a
    7059588024a7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588024ae:	00 
    7059588024af:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    7059588024b3:	c1 e9 0c             	shr    ecx,0xc
    7059588024b6:	89 c9                	mov    ecx,ecx
    7059588024b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588024bc:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    7059588024c1:	48 83 f8 00          	cmp    rax,0x0
    7059588024c5:	74 1a                	je     0x7059588024e1
    7059588024c7:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    7059588024cc:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    7059588024d0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588024d6:	89 c9                	mov    ecx,ecx
    7059588024d8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588024db:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    7059588024df:	eb 57                	jmp    0x705958802538
    7059588024e1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588024e8:	00 
    7059588024e9:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    7059588024ed:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588024f4:	00 
    7059588024f5:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    7059588024fc:	00 01 00 
    7059588024ff:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802506:	00 00 00 
    705958802509:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    705958802510:	00 00 00 
    705958802513:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880251a:	63 00 00 
    70595880251d:	ff d0                	call   rax
    70595880251f:	89 c1                	mov    ecx,eax
    705958802521:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802528:	00 
    705958802529:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    70595880252d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958802534:	75 29                	jne    0x70595880255f
    705958802536:	eb 73                	jmp    0x7059588025ab
    705958802538:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    70595880253c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958802543:	00 
    705958802544:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    705958802548:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    70595880254b:	83 c0 04             	add    eax,0x4
    70595880254e:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    705958802552:	83 e0 03             	and    eax,0x3
    705958802555:	83 f8 00             	cmp    eax,0x0
    705958802558:	75 5b                	jne    0x7059588025b5
    70595880255a:	e9 ea 00 00 00       	jmp    0x705958802649
    70595880255f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802566:	00 
    705958802567:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880256d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802573:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958802579:	be 0f 00 00 00       	mov    esi,0xf
    70595880257e:	b9 02 00 00 00       	mov    ecx,0x2
    705958802583:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880258a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958802591:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802598:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880259f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588025a6:	e9 bf 04 00 00       	jmp    0x705958802a6a
    7059588025ab:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    7059588025af:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    7059588025b3:	eb 83                	jmp    0x705958802538
    7059588025b5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588025bc:	00 
    7059588025bd:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    7059588025c1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588025c8:	00 
    7059588025c9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    7059588025d0:	00 01 00 
    7059588025d3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588025da:	00 00 00 
    7059588025dd:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    7059588025e4:	00 00 00 
    7059588025e7:	31 c0                	xor    eax,eax
    7059588025e9:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588025f0:	63 00 00 
    7059588025f3:	ba 3c 00 01 00       	mov    edx,0x1003c
    7059588025f8:	45 31 c0             	xor    r8d,r8d
    7059588025fb:	ff d0                	call   rax
    7059588025fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802604:	00 
    705958802605:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880260b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802611:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958802617:	be 0f 00 00 00       	mov    esi,0xf
    70595880261c:	b9 02 00 00 00       	mov    ecx,0x2
    705958802621:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958802628:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880262f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802636:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880263d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802644:	e9 21 04 00 00       	jmp    0x705958802a6a
    705958802649:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958802650:	00 
    705958802651:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958802655:	c1 e9 0c             	shr    ecx,0xc
    705958802658:	89 c9                	mov    ecx,ecx
    70595880265a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880265e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    705958802663:	48 83 f8 00          	cmp    rax,0x0
    705958802667:	74 1a                	je     0x705958802683
    705958802669:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    70595880266e:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    705958802672:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958802678:	89 c9                	mov    ecx,ecx
    70595880267a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880267d:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958802681:	eb 57                	jmp    0x7059588026da
    705958802683:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880268a:	00 
    70595880268b:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    70595880268f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958802696:	00 
    705958802697:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    70595880269e:	00 01 00 
    7059588026a1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588026a8:	00 00 00 
    7059588026ab:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    7059588026b2:	00 00 00 
    7059588026b5:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588026bc:	63 00 00 
    7059588026bf:	ff d0                	call   rax
    7059588026c1:	89 c1                	mov    ecx,eax
    7059588026c3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588026ca:	00 
    7059588026cb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    7059588026cf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588026d6:	75 29                	jne    0x705958802701
    7059588026d8:	eb 73                	jmp    0x70595880274d
    7059588026da:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    7059588026de:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588026e5:	00 
    7059588026e6:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    7059588026ea:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    7059588026ed:	83 c0 04             	add    eax,0x4
    7059588026f0:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    7059588026f4:	83 e0 03             	and    eax,0x3
    7059588026f7:	83 f8 00             	cmp    eax,0x0
    7059588026fa:	75 5b                	jne    0x705958802757
    7059588026fc:	e9 ea 00 00 00       	jmp    0x7059588027eb
    705958802701:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802708:	00 
    705958802709:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880270f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958802715:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880271b:	be 0f 00 00 00       	mov    esi,0xf
    705958802720:	b9 02 00 00 00       	mov    ecx,0x2
    705958802725:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880272c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958802733:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880273a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958802741:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802748:	e9 1d 03 00 00       	jmp    0x705958802a6a
    70595880274d:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    705958802751:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    705958802755:	eb 83                	jmp    0x7059588026da
    705958802757:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880275e:	00 
    70595880275f:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958802763:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    70595880276a:	00 
    70595880276b:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    705958802772:	00 01 00 
    705958802775:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880277c:	00 00 00 
    70595880277f:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    705958802786:	00 00 00 
    705958802789:	31 c0                	xor    eax,eax
    70595880278b:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958802792:	63 00 00 
    705958802795:	ba 3c 00 01 00       	mov    edx,0x1003c
    70595880279a:	45 31 c0             	xor    r8d,r8d
    70595880279d:	ff d0                	call   rax
    70595880279f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588027a6:	00 
    7059588027a7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588027ad:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588027b3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588027b9:	be 0f 00 00 00       	mov    esi,0xf
    7059588027be:	b9 02 00 00 00       	mov    ecx,0x2
    7059588027c3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588027ca:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588027d1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588027d8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588027df:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588027e6:	e9 7f 02 00 00       	jmp    0x705958802a6a
    7059588027eb:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588027f2:	00 
    7059588027f3:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    7059588027f7:	c1 e9 0c             	shr    ecx,0xc
    7059588027fa:	89 c9                	mov    ecx,ecx
    7059588027fc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958802800:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    705958802805:	48 83 f8 00          	cmp    rax,0x0
    705958802809:	74 1a                	je     0x705958802825
    70595880280b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958802810:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958802814:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880281a:	89 c9                	mov    ecx,ecx
    70595880281c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880281f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    705958802823:	eb 57                	jmp    0x70595880287c
    705958802825:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880282c:	00 
    70595880282d:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    705958802831:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958802838:	00 
    705958802839:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    705958802840:	00 01 00 
    705958802843:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880284a:	00 00 00 
    70595880284d:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    705958802854:	00 00 00 
    705958802857:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880285e:	63 00 00 
    705958802861:	ff d0                	call   rax
    705958802863:	89 c1                	mov    ecx,eax
    705958802865:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880286c:	00 
    70595880286d:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    705958802871:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958802878:	75 1d                	jne    0x705958802897
    70595880287a:	eb 67                	jmp    0x7059588028e3
    70595880287c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802883:	00 
    705958802884:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    705958802888:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    70595880288c:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    70595880288f:	83 c1 04             	add    ecx,0x4
    705958802892:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    705958802895:	eb 56                	jmp    0x7059588028ed
    705958802897:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880289e:	00 
    70595880289f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588028a5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588028ab:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588028b1:	be 0f 00 00 00       	mov    esi,0xf
    7059588028b6:	b9 02 00 00 00       	mov    ecx,0x2
    7059588028bb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588028c2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588028c9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588028d0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588028d7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588028de:	e9 87 01 00 00       	jmp    0x705958802a6a
    7059588028e3:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    7059588028e7:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    7059588028eb:	eb 8f                	jmp    0x70595880287c
    7059588028ed:	eb 00                	jmp    0x7059588028ef
    7059588028ef:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    7059588028f6:	83 e0 01             	and    eax,0x1
    7059588028f9:	83 f8 00             	cmp    eax,0x0
    7059588028fc:	75 3d                	jne    0x70595880293b
    7059588028fe:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    705958802905:	be 10 00 00 00       	mov    esi,0x10
    70595880290a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880290f:	b0 01                	mov    al,0x1
    705958802911:	89 d7                	mov    edi,edx
    705958802913:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880291a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958802921:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958802928:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880292f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958802936:	e9 2f 01 00 00       	jmp    0x705958802a6a
    70595880293b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958802942:	00 
    705958802943:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    70595880294a:	00 
    70595880294b:	c7 87 bc 00 00 00 3e 	mov    DWORD PTR [rdi+0xbc],0x1003e
    705958802952:	00 01 00 
    705958802955:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880295c:	00 00 00 
    70595880295f:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958802966:	00 00 00 
    705958802969:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    705958802970:	63 00 00 
    705958802973:	be 2a 00 00 00       	mov    esi,0x2a
    705958802978:	ff d0                	call   rax
    70595880297a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802981:	00 
    705958802982:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958802988:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880298e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958802994:	be 10 00 00 00       	mov    esi,0x10
    705958802999:	b9 02 00 00 00       	mov    ecx,0x2
    70595880299e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588029a5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588029ac:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588029b3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588029ba:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588029c1:	e9 a4 00 00 00       	jmp    0x705958802a6a
    7059588029c6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588029cd:	00 
    7059588029ce:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    7059588029d5:	e9 82 01 00 00       	jmp    0x705958802b5c
    7059588029da:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    7059588029e1:	00 
    7059588029e2:	48 89 c1             	mov    rcx,rax
    7059588029e5:	48 81 c1 00 02 08 00 	add    rcx,0x80200
    7059588029ec:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    7059588029f1:	81 b8 00 02 08 00 40 	cmp    DWORD PTR [rax+0x80200],0x10040
    7059588029f8:	00 01 00 
    7059588029fb:	74 32                	je     0x705958802a2f
    7059588029fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802a04:	00 
    705958802a05:	c7 80 bc 00 00 00 40 	mov    DWORD PTR [rax+0xbc],0x10040
    705958802a0c:	00 01 00 
    705958802a0f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958802a16:	00 00 00 
    705958802a19:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    705958802a20:	00 00 00 
    705958802a23:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    705958802a2a:	e9 2d 01 00 00       	jmp    0x705958802b5c
    705958802a2f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958802a36:	00 
    705958802a37:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    705958802a3e:	00 
    705958802a3f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705958802a44:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    705958802a4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    705958802a52:	40 00 01 00 
    705958802a56:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958802a5d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958802a61:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958802a68:	ff e0                	jmp    rax
    705958802a6a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958802a71:	00 
    705958802a72:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    705958802a79:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    705958802a80:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    705958802a87:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    705958802a8e:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    705958802a95:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    705958802a99:	89 c3                	mov    ebx,eax
    705958802a9b:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    705958802a9f:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    705958802aa3:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    705958802aa7:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    705958802aab:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    705958802ab1:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    705958802ab5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958802abb:	73 2d                	jae    0x705958802aea
    705958802abd:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958802ac4:	00 
    705958802ac5:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    705958802ac9:	89 d1                	mov    ecx,edx
    705958802acb:	c1 e9 01             	shr    ecx,0x1
    705958802ace:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958802ad4:	89 c9                	mov    ecx,ecx
    705958802ad6:	48 c1 e1 04          	shl    rcx,0x4
    705958802ada:	48 89 c6             	mov    rsi,rax
    705958802add:	48 01 ce             	add    rsi,rcx
    705958802ae0:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    705958802ae5:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958802ae8:	74 32                	je     0x705958802b1c
    705958802aea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958802af1:	00 
    705958802af2:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    705958802af6:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    705958802afa:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    705958802afe:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    705958802b02:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    705958802b08:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    705958802b0e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    705958802b14:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    705958802b1a:	eb 40                	jmp    0x705958802b5c
    705958802b1c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958802b23:	00 
    705958802b24:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    705958802b2b:	00 
    705958802b2c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958802b31:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    705958802b35:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    705958802b39:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    705958802b40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958802b47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958802b4e:	00 
    705958802b4f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958802b53:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958802b5a:	ff e0                	jmp    rax
    705958802b5c:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958802b63:	c2 08 00             	ret    0x8
