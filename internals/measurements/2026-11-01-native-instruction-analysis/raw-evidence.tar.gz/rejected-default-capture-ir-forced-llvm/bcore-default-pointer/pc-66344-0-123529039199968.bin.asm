
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66344-0-123529039199968.bin:     file format binary


Disassembly of section .data:

0000705958803ee0 <.data>:
    705958803ee0:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    705958803ee7:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    705958803eee:	00 
    705958803eef:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    705958803ef6:	00 
    705958803ef7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958803efe:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    705958803f05:	00 
    705958803f06:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    705958803f0d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    705958803f14:	00 
    705958803f15:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    705958803f1c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    705958803f23:	00 
    705958803f24:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958803f2b:	00 
    705958803f2c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958803f32:	83 fa 00             	cmp    edx,0x0
    705958803f35:	0f 94 c0             	sete   al
    705958803f38:	81 ea 28 03 01 00    	sub    edx,0x10328
    705958803f3e:	83 fa 46             	cmp    edx,0x46
    705958803f41:	0f 97 c2             	seta   dl
    705958803f44:	08 d0                	or     al,dl
    705958803f46:	24 01                	and    al,0x1
    705958803f48:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958803f4e:	83 fa 00             	cmp    edx,0x0
    705958803f51:	0f 94 c1             	sete   cl
    705958803f54:	81 ea 28 03 01 00    	sub    edx,0x10328
    705958803f5a:	83 fa 46             	cmp    edx,0x46
    705958803f5d:	0f 97 c2             	seta   dl
    705958803f60:	08 d1                	or     cl,dl
    705958803f62:	20 c8                	and    al,cl
    705958803f64:	a8 01                	test   al,0x1
    705958803f66:	75 05                	jne    0x705958803f6d
    705958803f68:	e9 79 26 00 00       	jmp    0x7059588065e6
    705958803f6d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958803f74:	00 
    705958803f75:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958803f7c:	48 89 c8             	mov    rax,rcx
    705958803f7f:	48 05 00 00 10 00    	add    rax,0x100000
    705958803f85:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    705958803f8c:	00 
    705958803f8d:	8b 81 0c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10000c]
    705958803f93:	83 c0 01             	add    eax,0x1
    705958803f96:	89 81 0c 00 10 00    	mov    DWORD PTR [rcx+0x10000c],eax
    705958803f9c:	3d c1 c5 00 00       	cmp    eax,0xc5c1
    705958803fa1:	75 4c                	jne    0x705958803fef
    705958803fa3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    705958803faa:	00 
    705958803fab:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958803fb1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    705958803fb8:	89 c2                	mov    edx,eax
    705958803fba:	83 c2 01             	add    edx,0x1
    705958803fbd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958803fc3:	3d 00 01 00 00       	cmp    eax,0x100
    705958803fc8:	73 23                	jae    0x705958803fed
    705958803fca:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    705958803fd1:	00 
    705958803fd2:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    705958803fd9:	89 c9                	mov    ecx,ecx
    705958803fdb:	48 c1 e1 02          	shl    rcx,0x2
    705958803fdf:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958803fe6:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    705958803fed:	eb 00                	jmp    0x705958803fef
    705958803fef:	eb 00                	jmp    0x705958803ff1
    705958803ff1:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958803ff8:	00 
    705958803ff9:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    705958803ffc:	83 e8 04             	sub    eax,0x4
    705958803fff:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    705958804006:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    705958804009:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    705958804010:	83 e0 03             	and    eax,0x3
    705958804013:	83 f8 00             	cmp    eax,0x0
    705958804016:	0f 84 8e 00 00 00    	je     0x7059588040aa
    70595880401c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804023:	00 
    705958804024:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    70595880402b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958804032:	00 
    705958804033:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880403a:	00 00 00 
    70595880403d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958804044:	00 00 00 
    705958804047:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880404e:	63 00 00 
    705958804051:	ba 28 03 01 00       	mov    edx,0x10328
    705958804056:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880405c:	ff d0                	call   rax
    70595880405e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804065:	00 
    705958804066:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880406c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804072:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804078:	be 01 00 00 00       	mov    esi,0x1
    70595880407d:	b9 02 00 00 00       	mov    ecx,0x2
    705958804082:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804089:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804090:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804097:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880409e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588040a5:	e9 20 28 00 00       	jmp    0x7059588068ca
    7059588040aa:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588040b1:	00 
    7059588040b2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    7059588040b9:	c1 e9 0c             	shr    ecx,0xc
    7059588040bc:	89 c9                	mov    ecx,ecx
    7059588040be:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588040c2:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    7059588040c9:	00 
    7059588040ca:	48 83 f8 00          	cmp    rax,0x0
    7059588040ce:	74 23                	je     0x7059588040f3
    7059588040d0:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    7059588040d7:	00 
    7059588040d8:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    7059588040df:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    7059588040e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588040ec:	89 c9                	mov    ecx,ecx
    7059588040ee:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588040f1:	eb 51                	jmp    0x705958804144
    7059588040f3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588040fa:	00 
    7059588040fb:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    705958804102:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    705958804109:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958804110:	00 
    705958804111:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958804118:	00 00 00 
    70595880411b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958804122:	00 00 00 
    705958804125:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880412c:	63 00 00 
    70595880412f:	ff d0                	call   rax
    705958804131:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804138:	00 
    705958804139:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958804140:	75 32                	jne    0x705958804174
    705958804142:	eb 7c                	jmp    0x7059588041c0
    705958804144:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880414b:	00 
    70595880414c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    705958804153:	83 e8 04             	sub    eax,0x4
    705958804156:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    70595880415d:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    705958804160:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    705958804167:	83 e0 03             	and    eax,0x3
    70595880416a:	83 f8 00             	cmp    eax,0x0
    70595880416d:	75 53                	jne    0x7059588041c2
    70595880416f:	e9 dc 00 00 00       	jmp    0x705958804250
    705958804174:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880417b:	00 
    70595880417c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804182:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804188:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880418e:	be 01 00 00 00       	mov    esi,0x1
    705958804193:	b9 02 00 00 00       	mov    ecx,0x2
    705958804198:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880419f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588041a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588041ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588041b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588041bb:	e9 0a 27 00 00       	jmp    0x7059588068ca
    7059588041c0:	eb 82                	jmp    0x705958804144
    7059588041c2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588041c9:	00 
    7059588041ca:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    7059588041d1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588041d8:	00 
    7059588041d9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588041e0:	00 00 00 
    7059588041e3:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    7059588041ea:	00 00 00 
    7059588041ed:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588041f4:	63 00 00 
    7059588041f7:	ba 28 03 01 00       	mov    edx,0x10328
    7059588041fc:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958804202:	ff d0                	call   rax
    705958804204:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880420b:	00 
    70595880420c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804212:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804218:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880421e:	be 01 00 00 00       	mov    esi,0x1
    705958804223:	b9 02 00 00 00       	mov    ecx,0x2
    705958804228:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880422f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804236:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880423d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804244:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880424b:	e9 7a 26 00 00       	jmp    0x7059588068ca
    705958804250:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958804257:	00 
    705958804258:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    70595880425f:	c1 e9 0c             	shr    ecx,0xc
    705958804262:	89 c9                	mov    ecx,ecx
    705958804264:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958804268:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    70595880426f:	00 
    705958804270:	48 83 f8 00          	cmp    rax,0x0
    705958804274:	74 23                	je     0x705958804299
    705958804276:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    70595880427d:	00 
    70595880427e:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    705958804285:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    70595880428c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958804292:	89 c9                	mov    ecx,ecx
    705958804294:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958804297:	eb 51                	jmp    0x7059588042ea
    705958804299:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588042a0:	00 
    7059588042a1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    7059588042a8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    7059588042af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588042b6:	00 
    7059588042b7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588042be:	00 00 00 
    7059588042c1:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    7059588042c8:	00 00 00 
    7059588042cb:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588042d2:	63 00 00 
    7059588042d5:	ff d0                	call   rax
    7059588042d7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588042de:	00 
    7059588042df:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588042e6:	75 32                	jne    0x70595880431a
    7059588042e8:	eb 7c                	jmp    0x705958804366
    7059588042ea:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588042f1:	00 
    7059588042f2:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    7059588042f9:	83 e8 04             	sub    eax,0x4
    7059588042fc:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    705958804303:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    705958804306:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    70595880430d:	83 e0 03             	and    eax,0x3
    705958804310:	83 f8 00             	cmp    eax,0x0
    705958804313:	75 53                	jne    0x705958804368
    705958804315:	e9 dc 00 00 00       	jmp    0x7059588043f6
    70595880431a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804321:	00 
    705958804322:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804328:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880432e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804334:	be 01 00 00 00       	mov    esi,0x1
    705958804339:	b9 02 00 00 00       	mov    ecx,0x2
    70595880433e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804345:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880434c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804353:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880435a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804361:	e9 64 25 00 00       	jmp    0x7059588068ca
    705958804366:	eb 82                	jmp    0x7059588042ea
    705958804368:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880436f:	00 
    705958804370:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    705958804377:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    70595880437e:	00 
    70595880437f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958804386:	00 00 00 
    705958804389:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958804390:	00 00 00 
    705958804393:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880439a:	63 00 00 
    70595880439d:	ba 28 03 01 00       	mov    edx,0x10328
    7059588043a2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588043a8:	ff d0                	call   rax
    7059588043aa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588043b1:	00 
    7059588043b2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588043b8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588043be:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588043c4:	be 01 00 00 00       	mov    esi,0x1
    7059588043c9:	b9 02 00 00 00       	mov    ecx,0x2
    7059588043ce:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588043d5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588043dc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588043e3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588043ea:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588043f1:	e9 d4 24 00 00       	jmp    0x7059588068ca
    7059588043f6:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588043fd:	00 
    7059588043fe:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    705958804405:	c1 e9 0c             	shr    ecx,0xc
    705958804408:	89 c9                	mov    ecx,ecx
    70595880440a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880440e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    705958804415:	00 
    705958804416:	48 83 f8 00          	cmp    rax,0x0
    70595880441a:	74 23                	je     0x70595880443f
    70595880441c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    705958804423:	00 
    705958804424:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    70595880442b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    705958804432:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958804438:	89 c9                	mov    ecx,ecx
    70595880443a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    70595880443d:	eb 51                	jmp    0x705958804490
    70595880443f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804446:	00 
    705958804447:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    70595880444e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    705958804455:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    70595880445c:	00 
    70595880445d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958804464:	00 00 00 
    705958804467:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    70595880446e:	00 00 00 
    705958804471:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958804478:	63 00 00 
    70595880447b:	ff d0                	call   rax
    70595880447d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804484:	00 
    705958804485:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880448c:	75 32                	jne    0x7059588044c0
    70595880448e:	eb 7c                	jmp    0x70595880450c
    705958804490:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958804497:	00 
    705958804498:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    70595880449f:	83 e8 04             	sub    eax,0x4
    7059588044a2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    7059588044a9:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    7059588044ac:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    7059588044b3:	83 e0 03             	and    eax,0x3
    7059588044b6:	83 f8 00             	cmp    eax,0x0
    7059588044b9:	75 53                	jne    0x70595880450e
    7059588044bb:	e9 dc 00 00 00       	jmp    0x70595880459c
    7059588044c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588044c7:	00 
    7059588044c8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588044ce:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588044d4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588044da:	be 01 00 00 00       	mov    esi,0x1
    7059588044df:	b9 02 00 00 00       	mov    ecx,0x2
    7059588044e4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588044eb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588044f2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588044f9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804500:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804507:	e9 be 23 00 00       	jmp    0x7059588068ca
    70595880450c:	eb 82                	jmp    0x705958804490
    70595880450e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804515:	00 
    705958804516:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    70595880451d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958804524:	00 
    705958804525:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880452c:	00 00 00 
    70595880452f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958804536:	00 00 00 
    705958804539:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958804540:	63 00 00 
    705958804543:	ba 28 03 01 00       	mov    edx,0x10328
    705958804548:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880454e:	ff d0                	call   rax
    705958804550:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804557:	00 
    705958804558:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880455e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804564:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880456a:	be 01 00 00 00       	mov    esi,0x1
    70595880456f:	b9 02 00 00 00       	mov    ecx,0x2
    705958804574:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880457b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804582:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804589:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804590:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804597:	e9 2e 23 00 00       	jmp    0x7059588068ca
    70595880459c:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588045a3:	00 
    7059588045a4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    7059588045ab:	c1 e9 0c             	shr    ecx,0xc
    7059588045ae:	89 c9                	mov    ecx,ecx
    7059588045b0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588045b4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    7059588045bb:	00 
    7059588045bc:	48 83 f8 00          	cmp    rax,0x0
    7059588045c0:	74 23                	je     0x7059588045e5
    7059588045c2:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    7059588045c9:	00 
    7059588045ca:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    7059588045d1:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    7059588045d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588045de:	89 c9                	mov    ecx,ecx
    7059588045e0:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588045e3:	eb 51                	jmp    0x705958804636
    7059588045e5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588045ec:	00 
    7059588045ed:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    7059588045f4:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    7059588045fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958804602:	00 
    705958804603:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880460a:	00 00 00 
    70595880460d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    705958804614:	00 00 00 
    705958804617:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880461e:	63 00 00 
    705958804621:	ff d0                	call   rax
    705958804623:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880462a:	00 
    70595880462b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958804632:	75 32                	jne    0x705958804666
    705958804634:	eb 7c                	jmp    0x7059588046b2
    705958804636:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    70595880463d:	00 
    70595880463e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    705958804645:	83 e8 04             	sub    eax,0x4
    705958804648:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    70595880464f:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    705958804652:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    705958804659:	83 e0 03             	and    eax,0x3
    70595880465c:	83 f8 00             	cmp    eax,0x0
    70595880465f:	75 53                	jne    0x7059588046b4
    705958804661:	e9 dc 00 00 00       	jmp    0x705958804742
    705958804666:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880466d:	00 
    70595880466e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804674:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880467a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804680:	be 01 00 00 00       	mov    esi,0x1
    705958804685:	b9 02 00 00 00       	mov    ecx,0x2
    70595880468a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804691:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804698:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880469f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588046a6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588046ad:	e9 18 22 00 00       	jmp    0x7059588068ca
    7059588046b2:	eb 82                	jmp    0x705958804636
    7059588046b4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588046bb:	00 
    7059588046bc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    7059588046c3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588046ca:	00 
    7059588046cb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588046d2:	00 00 00 
    7059588046d5:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    7059588046dc:	00 00 00 
    7059588046df:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588046e6:	63 00 00 
    7059588046e9:	ba 28 03 01 00       	mov    edx,0x10328
    7059588046ee:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588046f4:	ff d0                	call   rax
    7059588046f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588046fd:	00 
    7059588046fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804704:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880470a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804710:	be 01 00 00 00       	mov    esi,0x1
    705958804715:	b9 02 00 00 00       	mov    ecx,0x2
    70595880471a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804721:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804728:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880472f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804736:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880473d:	e9 88 21 00 00       	jmp    0x7059588068ca
    705958804742:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958804749:	00 
    70595880474a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    705958804751:	c1 e9 0c             	shr    ecx,0xc
    705958804754:	89 c9                	mov    ecx,ecx
    705958804756:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880475a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    705958804761:	00 
    705958804762:	48 83 f8 00          	cmp    rax,0x0
    705958804766:	74 23                	je     0x70595880478b
    705958804768:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    70595880476f:	00 
    705958804770:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    705958804777:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    70595880477e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958804784:	89 c9                	mov    ecx,ecx
    705958804786:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958804789:	eb 51                	jmp    0x7059588047dc
    70595880478b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804792:	00 
    705958804793:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    70595880479a:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    7059588047a1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588047a8:	00 
    7059588047a9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588047b0:	00 00 00 
    7059588047b3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    7059588047ba:	00 00 00 
    7059588047bd:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588047c4:	63 00 00 
    7059588047c7:	ff d0                	call   rax
    7059588047c9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588047d0:	00 
    7059588047d1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588047d8:	75 26                	jne    0x705958804800
    7059588047da:	eb 70                	jmp    0x70595880484c
    7059588047dc:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    7059588047e3:	00 
    7059588047e4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588047eb:	00 
    7059588047ec:	8b 94 24 88 01 00 00 	mov    edx,DWORD PTR [rsp+0x188]
    7059588047f3:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    7059588047f6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7059588047f9:	75 53                	jne    0x70595880484e
    7059588047fb:	e9 93 00 00 00       	jmp    0x705958804893
    705958804800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804807:	00 
    705958804808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880480e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880481a:	be 01 00 00 00       	mov    esi,0x1
    70595880481f:	b9 02 00 00 00       	mov    ecx,0x2
    705958804824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880482b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804847:	e9 7e 20 00 00       	jmp    0x7059588068ca
    70595880484c:	eb 8e                	jmp    0x7059588047dc
    70595880484e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804855:	00 
    705958804856:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    70595880485d:	03 01 00 
    705958804860:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958804867:	00 00 00 
    70595880486a:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958804871:	00 00 00 
    705958804874:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880487b:	63 00 00 
    70595880487e:	ff d0                	call   rax
    705958804880:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804887:	00 
    705958804888:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880488f:	75 04                	jne    0x705958804895
    705958804891:	eb 4e                	jmp    0x7059588048e1
    705958804893:	eb 4e                	jmp    0x7059588048e3
    705958804895:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880489c:	00 
    70595880489d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588048a3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588048a9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588048af:	be 01 00 00 00       	mov    esi,0x1
    7059588048b4:	b9 02 00 00 00       	mov    ecx,0x2
    7059588048b9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588048c0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588048c7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588048ce:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588048d5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588048dc:	e9 e9 1f 00 00       	jmp    0x7059588068ca
    7059588048e1:	eb b0                	jmp    0x705958804893
    7059588048e3:	eb 00                	jmp    0x7059588048e5
    7059588048e5:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    7059588048ec:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588048f3:	00 
    7059588048f4:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    7059588048fa:	89 94 24 74 01 00 00 	mov    DWORD PTR [rsp+0x174],edx
    705958804901:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    705958804904:	89 8c 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],ecx
    70595880490b:	83 e8 04             	sub    eax,0x4
    70595880490e:	89 84 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],eax
    705958804915:	83 e0 03             	and    eax,0x3
    705958804918:	83 f8 00             	cmp    eax,0x0
    70595880491b:	0f 84 98 00 00 00    	je     0x7059588049b9
    705958804921:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804928:	00 
    705958804929:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    705958804930:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958804937:	00 
    705958804938:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    70595880493f:	03 01 00 
    705958804942:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958804949:	00 00 00 
    70595880494c:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958804953:	00 00 00 
    705958804956:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880495d:	63 00 00 
    705958804960:	ba 2a 03 01 00       	mov    edx,0x1032a
    705958804965:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880496b:	ff d0                	call   rax
    70595880496d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804974:	00 
    705958804975:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880497b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804981:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804987:	be 02 00 00 00       	mov    esi,0x2
    70595880498c:	b9 04 00 00 00       	mov    ecx,0x4
    705958804991:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804998:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880499f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588049a6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588049ad:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588049b4:	e9 11 1f 00 00       	jmp    0x7059588068ca
    7059588049b9:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588049c0:	00 
    7059588049c1:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    7059588049c8:	c1 e9 0c             	shr    ecx,0xc
    7059588049cb:	89 c9                	mov    ecx,ecx
    7059588049cd:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588049d1:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    7059588049d8:	00 
    7059588049d9:	48 83 f8 00          	cmp    rax,0x0
    7059588049dd:	74 23                	je     0x705958804a02
    7059588049df:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    7059588049e6:	00 
    7059588049e7:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    7059588049ee:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    7059588049f5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588049fb:	89 c9                	mov    ecx,ecx
    7059588049fd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958804a00:	eb 5b                	jmp    0x705958804a5d
    705958804a02:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804a09:	00 
    705958804a0a:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    705958804a11:	8b b4 24 7c 01 00 00 	mov    esi,DWORD PTR [rsp+0x17c]
    705958804a18:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958804a1f:	00 
    705958804a20:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    705958804a27:	03 01 00 
    705958804a2a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958804a31:	00 00 00 
    705958804a34:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958804a3b:	00 00 00 
    705958804a3e:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958804a45:	63 00 00 
    705958804a48:	ff d0                	call   rax
    705958804a4a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804a51:	00 
    705958804a52:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958804a59:	75 20                	jne    0x705958804a7b
    705958804a5b:	eb 6a                	jmp    0x705958804ac7
    705958804a5d:	8b 84 24 7c 01 00 00 	mov    eax,DWORD PTR [rsp+0x17c]
    705958804a64:	83 e8 04             	sub    eax,0x4
    705958804a67:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    705958804a6e:	83 e0 03             	and    eax,0x3
    705958804a71:	83 f8 00             	cmp    eax,0x0
    705958804a74:	75 53                	jne    0x705958804ac9
    705958804a76:	e9 e6 00 00 00       	jmp    0x705958804b61
    705958804a7b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804a82:	00 
    705958804a83:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804a89:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804a8f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804a95:	be 02 00 00 00       	mov    esi,0x2
    705958804a9a:	b9 04 00 00 00       	mov    ecx,0x4
    705958804a9f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804aa6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804aad:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804ab4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804abb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804ac2:	e9 03 1e 00 00       	jmp    0x7059588068ca
    705958804ac7:	eb 94                	jmp    0x705958804a5d
    705958804ac9:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804ad0:	00 
    705958804ad1:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    705958804ad8:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958804adf:	00 
    705958804ae0:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    705958804ae7:	03 01 00 
    705958804aea:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958804af1:	00 00 00 
    705958804af4:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958804afb:	00 00 00 
    705958804afe:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958804b05:	63 00 00 
    705958804b08:	ba 2a 03 01 00       	mov    edx,0x1032a
    705958804b0d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958804b13:	ff d0                	call   rax
    705958804b15:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804b1c:	00 
    705958804b1d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804b23:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804b29:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804b2f:	be 02 00 00 00       	mov    esi,0x2
    705958804b34:	b9 04 00 00 00       	mov    ecx,0x4
    705958804b39:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804b40:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804b47:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804b4e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804b55:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804b5c:	e9 69 1d 00 00       	jmp    0x7059588068ca
    705958804b61:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958804b68:	00 
    705958804b69:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    705958804b70:	c1 e9 0c             	shr    ecx,0xc
    705958804b73:	89 c9                	mov    ecx,ecx
    705958804b75:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958804b79:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
    705958804b80:	00 
    705958804b81:	48 83 f8 00          	cmp    rax,0x0
    705958804b85:	74 23                	je     0x705958804baa
    705958804b87:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    705958804b8e:	00 
    705958804b8f:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    705958804b96:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    705958804b9d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958804ba3:	89 c9                	mov    ecx,ecx
    705958804ba5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958804ba8:	eb 5b                	jmp    0x705958804c05
    705958804baa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804bb1:	00 
    705958804bb2:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    705958804bb9:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    705958804bc0:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958804bc7:	00 
    705958804bc8:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    705958804bcf:	03 01 00 
    705958804bd2:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958804bd9:	00 00 00 
    705958804bdc:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    705958804be3:	00 00 00 
    705958804be6:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958804bed:	63 00 00 
    705958804bf0:	ff d0                	call   rax
    705958804bf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804bf9:	00 
    705958804bfa:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958804c01:	75 2c                	jne    0x705958804c2f
    705958804c03:	eb 76                	jmp    0x705958804c7b
    705958804c05:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    705958804c0c:	00 
    705958804c0d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958804c14:	00 
    705958804c15:	8b 94 24 64 01 00 00 	mov    edx,DWORD PTR [rsp+0x164]
    705958804c1c:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    705958804c1f:	83 ea 00             	sub    edx,0x0
    705958804c22:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    705958804c25:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958804c28:	75 53                	jne    0x705958804c7d
    705958804c2a:	e9 93 00 00 00       	jmp    0x705958804cc2
    705958804c2f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804c36:	00 
    705958804c37:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804c3d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804c43:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804c49:	be 02 00 00 00       	mov    esi,0x2
    705958804c4e:	b9 04 00 00 00       	mov    ecx,0x4
    705958804c53:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804c5a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804c61:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804c68:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804c6f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804c76:	e9 4f 1c 00 00       	jmp    0x7059588068ca
    705958804c7b:	eb 88                	jmp    0x705958804c05
    705958804c7d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804c84:	00 
    705958804c85:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1032e
    705958804c8c:	03 01 00 
    705958804c8f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958804c96:	00 00 00 
    705958804c99:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    705958804ca0:	00 00 00 
    705958804ca3:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958804caa:	63 00 00 
    705958804cad:	ff d0                	call   rax
    705958804caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804cb6:	00 
    705958804cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958804cbe:	75 04                	jne    0x705958804cc4
    705958804cc0:	eb 4e                	jmp    0x705958804d10
    705958804cc2:	eb 4e                	jmp    0x705958804d12
    705958804cc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804ccb:	00 
    705958804ccc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958804cd2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958804cd8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958804cde:	be 02 00 00 00       	mov    esi,0x2
    705958804ce3:	b9 04 00 00 00       	mov    ecx,0x4
    705958804ce8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958804cef:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958804cf6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958804cfd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958804d04:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958804d0b:	e9 ba 1b 00 00       	jmp    0x7059588068ca
    705958804d10:	eb b0                	jmp    0x705958804cc2
    705958804d12:	eb 00                	jmp    0x705958804d14
    705958804d14:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804d1b:	00 
    705958804d1c:	8b 38                	mov    edi,DWORD PTR [rax]
    705958804d1e:	89 bc 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edi
    705958804d25:	83 ff 04             	cmp    edi,0x4
    705958804d28:	0f 96 c1             	setbe  cl
    705958804d2b:	80 e1 01             	and    cl,0x1
    705958804d2e:	0f b6 c9             	movzx  ecx,cl
    705958804d31:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    705958804d38:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    705958804d3e:	83 ff 04             	cmp    edi,0x4
    705958804d41:	0f 94 c1             	sete   cl
    705958804d44:	80 e1 01             	and    cl,0x1
    705958804d47:	0f b6 f1             	movzx  esi,cl
    705958804d4a:	b9 04 00 00 00       	mov    ecx,0x4
    705958804d4f:	39 f9                	cmp    ecx,edi
    705958804d51:	0f 97 c1             	seta   cl
    705958804d54:	80 e1 01             	and    cl,0x1
    705958804d57:	0f b6 d1             	movzx  edx,cl
    705958804d5a:	b9 04 00 00 00       	mov    ecx,0x4
    705958804d5f:	39 f9                	cmp    ecx,edi
    705958804d61:	0f 96 c1             	setbe  cl
    705958804d64:	80 e1 01             	and    cl,0x1
    705958804d67:	0f b6 c9             	movzx  ecx,cl
    705958804d6a:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958804d70:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958804d76:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958804d7c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958804d82:	eb 00                	jmp    0x705958804d84
    705958804d84:	8b 84 24 54 01 00 00 	mov    eax,DWORD PTR [rsp+0x154]
    705958804d8b:	83 f8 00             	cmp    eax,0x0
    705958804d8e:	75 33                	jne    0x705958804dc3
    705958804d90:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958804d97:	00 
    705958804d98:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    705958804d9f:	03 01 00 
    705958804da2:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958804da8:	83 c0 04             	add    eax,0x4
    705958804dab:	89 84 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],eax
    705958804db2:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958804db8:	0f 82 3c 18 00 00    	jb     0x7059588065fa
    705958804dbe:	e9 5a 18 00 00       	jmp    0x70595880661d
    705958804dc3:	eb 00                	jmp    0x705958804dc5
    705958804dc5:	eb 00                	jmp    0x705958804dc7
    705958804dc7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804dce:	00 
    705958804dcf:	8b 78 04             	mov    edi,DWORD PTR [rax+0x4]
    705958804dd2:	89 bc 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],edi
    705958804dd9:	89 fa                	mov    edx,edi
    705958804ddb:	83 ea 00             	sub    edx,0x0
    705958804dde:	83 fa 00             	cmp    edx,0x0
    705958804de1:	0f 94 c1             	sete   cl
    705958804de4:	80 e1 01             	and    cl,0x1
    705958804de7:	0f b6 f1             	movzx  esi,cl
    705958804dea:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    705958804df1:	c1 ea 1f             	shr    edx,0x1f
    705958804df4:	89 f9                	mov    ecx,edi
    705958804df6:	c1 e9 1f             	shr    ecx,0x1f
    705958804df9:	89 d3                	mov    ebx,edx
    705958804dfb:	31 cb                	xor    ebx,ecx
    705958804dfd:	83 f1 00             	xor    ecx,0x0
    705958804e00:	21 d9                	and    ecx,ebx
    705958804e02:	31 ca                	xor    edx,ecx
    705958804e04:	31 c9                	xor    ecx,ecx
    705958804e06:	39 f9                	cmp    ecx,edi
    705958804e08:	0f 96 c1             	setbe  cl
    705958804e0b:	80 e1 01             	and    cl,0x1
    705958804e0e:	0f b6 c9             	movzx  ecx,cl
    705958804e11:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    705958804e17:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958804e1d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958804e23:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958804e29:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958804e2f:	eb 00                	jmp    0x705958804e31
    705958804e31:	8b 84 24 48 01 00 00 	mov    eax,DWORD PTR [rsp+0x148]
    705958804e38:	83 f8 00             	cmp    eax,0x0
    705958804e3b:	74 33                	je     0x705958804e70
    705958804e3d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958804e44:	00 
    705958804e45:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    705958804e4c:	03 01 00 
    705958804e4f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958804e55:	83 c0 06             	add    eax,0x6
    705958804e58:	89 84 24 40 01 00 00 	mov    DWORD PTR [rsp+0x140],eax
    705958804e5f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958804e65:	0f 82 1f 18 00 00    	jb     0x70595880668a
    705958804e6b:	e9 3d 18 00 00       	jmp    0x7059588066ad
    705958804e70:	eb 00                	jmp    0x705958804e72
    705958804e72:	eb 00                	jmp    0x705958804e74
    705958804e74:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804e7b:	00 
    705958804e7c:	c7 40 0c 09 3d 00 00 	mov    DWORD PTR [rax+0xc],0x3d09
    705958804e83:	eb 00                	jmp    0x705958804e85
    705958804e85:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804e8c:	00 
    705958804e8d:	c7 40 0c 00 48 e8 01 	mov    DWORD PTR [rax+0xc],0x1e84800
    705958804e94:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    705958804e9b:	00 00 00 
    705958804e9e:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    705958804ea5:	00 00 00 
    705958804ea8:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    705958804eaf:	00 00 00 
    705958804eb2:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    705958804eb9:	00 00 00 
    705958804ebc:	eb 00                	jmp    0x705958804ebe
    705958804ebe:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804ec5:	00 
    705958804ec6:	8b bc 24 44 01 00 00 	mov    edi,DWORD PTR [rsp+0x144]
    705958804ecd:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    705958804ed3:	0f 96 c1             	setbe  cl
    705958804ed6:	80 e1 01             	and    cl,0x1
    705958804ed9:	0f b6 c9             	movzx  ecx,cl
    705958804edc:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    705958804ee3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    705958804ee9:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    705958804eef:	0f 94 c1             	sete   cl
    705958804ef2:	80 e1 01             	and    cl,0x1
    705958804ef5:	0f b6 f1             	movzx  esi,cl
    705958804ef8:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    705958804efd:	39 f9                	cmp    ecx,edi
    705958804eff:	0f 97 c1             	seta   cl
    705958804f02:	80 e1 01             	and    cl,0x1
    705958804f05:	0f b6 d1             	movzx  edx,cl
    705958804f08:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    705958804f0d:	39 f9                	cmp    ecx,edi
    705958804f0f:	0f 96 c1             	setbe  cl
    705958804f12:	80 e1 01             	and    cl,0x1
    705958804f15:	0f b6 c9             	movzx  ecx,cl
    705958804f18:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958804f1e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958804f24:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    705958804f2a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958804f30:	eb 00                	jmp    0x705958804f32
    705958804f32:	8b 84 24 3c 01 00 00 	mov    eax,DWORD PTR [rsp+0x13c]
    705958804f39:	83 f8 00             	cmp    eax,0x0
    705958804f3c:	75 33                	jne    0x705958804f71
    705958804f3e:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958804f45:	00 
    705958804f46:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    705958804f4d:	03 01 00 
    705958804f50:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958804f56:	83 c0 0a             	add    eax,0xa
    705958804f59:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    705958804f60:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958804f66:	0f 82 ae 17 00 00    	jb     0x70595880671a
    705958804f6c:	e9 cc 17 00 00       	jmp    0x70595880673d
    705958804f71:	eb 00                	jmp    0x705958804f73
    705958804f73:	eb 00                	jmp    0x705958804f75
    705958804f75:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804f7c:	00 
    705958804f7d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    705958804f80:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958804f86:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958804f8c:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    705958804f93:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958804f96:	eb 00                	jmp    0x705958804f98
    705958804f98:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958804f9f:	00 
    705958804fa0:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    705958804fa7:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958804fad:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    705958804fb3:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    705958804fba:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958804fbd:	eb 00                	jmp    0x705958804fbf
    705958804fbf:	8b 84 24 30 01 00 00 	mov    eax,DWORD PTR [rsp+0x130]
    705958804fc6:	83 e0 03             	and    eax,0x3
    705958804fc9:	83 f8 00             	cmp    eax,0x0
    705958804fcc:	0f 84 98 00 00 00    	je     0x70595880506a
    705958804fd2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958804fd9:	00 
    705958804fda:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    705958804fe1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958804fe8:	00 
    705958804fe9:	c7 87 bc 00 00 00 48 	mov    DWORD PTR [rdi+0xbc],0x10348
    705958804ff0:	03 01 00 
    705958804ff3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958804ffa:	00 00 00 
    705958804ffd:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    705958805004:	00 00 00 
    705958805007:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880500e:	63 00 00 
    705958805011:	ba 48 03 01 00       	mov    edx,0x10348
    705958805016:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595880501c:	ff d0                	call   rax
    70595880501e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805025:	00 
    705958805026:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880502c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805032:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805038:	be 0d 00 00 00       	mov    esi,0xd
    70595880503d:	b9 02 00 00 00       	mov    ecx,0x2
    705958805042:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805049:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805050:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805057:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880505e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805065:	e9 60 18 00 00       	jmp    0x7059588068ca
    70595880506a:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958805071:	00 
    705958805072:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    705958805079:	c1 e9 0c             	shr    ecx,0xc
    70595880507c:	89 c9                	mov    ecx,ecx
    70595880507e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958805082:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    705958805089:	00 
    70595880508a:	48 83 f8 00          	cmp    rax,0x0
    70595880508e:	74 23                	je     0x7059588050b3
    705958805090:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    705958805097:	00 
    705958805098:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    70595880509f:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    7059588050a6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588050ac:	89 c9                	mov    ecx,ecx
    7059588050ae:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588050b1:	eb 5b                	jmp    0x70595880510e
    7059588050b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588050ba:	00 
    7059588050bb:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    7059588050c2:	8b b4 24 30 01 00 00 	mov    esi,DWORD PTR [rsp+0x130]
    7059588050c9:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588050d0:	00 
    7059588050d1:	c7 80 bc 00 00 00 48 	mov    DWORD PTR [rax+0xbc],0x10348
    7059588050d8:	03 01 00 
    7059588050db:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588050e2:	00 00 00 
    7059588050e5:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    7059588050ec:	00 00 00 
    7059588050ef:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588050f6:	63 00 00 
    7059588050f9:	ff d0                	call   rax
    7059588050fb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805102:	00 
    705958805103:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880510a:	75 14                	jne    0x705958805120
    70595880510c:	eb 5e                	jmp    0x70595880516c
    70595880510e:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    705958805115:	00 
    705958805116:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958805119:	75 53                	jne    0x70595880516e
    70595880511b:	e9 93 00 00 00       	jmp    0x7059588051b3
    705958805120:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805127:	00 
    705958805128:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880512e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805134:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880513a:	be 0d 00 00 00       	mov    esi,0xd
    70595880513f:	b9 02 00 00 00       	mov    ecx,0x2
    705958805144:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880514b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805152:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805159:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805160:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805167:	e9 5e 17 00 00       	jmp    0x7059588068ca
    70595880516c:	eb a0                	jmp    0x70595880510e
    70595880516e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805175:	00 
    705958805176:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1034a
    70595880517d:	03 01 00 
    705958805180:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958805187:	00 00 00 
    70595880518a:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    705958805191:	00 00 00 
    705958805194:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880519b:	63 00 00 
    70595880519e:	ff d0                	call   rax
    7059588051a0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588051a7:	00 
    7059588051a8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588051af:	75 04                	jne    0x7059588051b5
    7059588051b1:	eb 4e                	jmp    0x705958805201
    7059588051b3:	eb 4e                	jmp    0x705958805203
    7059588051b5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588051bc:	00 
    7059588051bd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588051c3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588051c9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588051cf:	be 0d 00 00 00       	mov    esi,0xd
    7059588051d4:	b9 02 00 00 00       	mov    ecx,0x2
    7059588051d9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588051e0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588051e7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588051ee:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588051f5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588051fc:	e9 c9 16 00 00       	jmp    0x7059588068ca
    705958805201:	eb b0                	jmp    0x7059588051b3
    705958805203:	eb 00                	jmp    0x705958805205
    705958805205:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880520c:	00 
    70595880520d:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    705958805214:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880521a:	81 c9 00 00 01 00    	or     ecx,0x10000
    705958805220:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    705958805227:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880522a:	eb 00                	jmp    0x70595880522c
    70595880522c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805233:	00 
    705958805234:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    70595880523b:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958805241:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    705958805247:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    70595880524e:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    705958805251:	eb 00                	jmp    0x705958805253
    705958805253:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    70595880525a:	83 e0 03             	and    eax,0x3
    70595880525d:	83 f8 00             	cmp    eax,0x0
    705958805260:	0f 84 98 00 00 00    	je     0x7059588052fe
    705958805266:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880526d:	00 
    70595880526e:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    705958805275:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    70595880527c:	00 
    70595880527d:	c7 87 bc 00 00 00 52 	mov    DWORD PTR [rdi+0xbc],0x10352
    705958805284:	03 01 00 
    705958805287:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880528e:	00 00 00 
    705958805291:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958805298:	00 00 00 
    70595880529b:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588052a2:	63 00 00 
    7059588052a5:	ba 52 03 01 00       	mov    edx,0x10352
    7059588052aa:	41 b8 00 00 01 00    	mov    r8d,0x10000
    7059588052b0:	ff d0                	call   rax
    7059588052b2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588052b9:	00 
    7059588052ba:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588052c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588052c6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588052cc:	be 10 00 00 00       	mov    esi,0x10
    7059588052d1:	b9 02 00 00 00       	mov    ecx,0x2
    7059588052d6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588052dd:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588052e4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588052eb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588052f2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588052f9:	e9 cc 15 00 00       	jmp    0x7059588068ca
    7059588052fe:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958805305:	00 
    705958805306:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    70595880530d:	c1 e9 0c             	shr    ecx,0xc
    705958805310:	89 c9                	mov    ecx,ecx
    705958805312:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958805316:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    70595880531d:	00 
    70595880531e:	48 83 f8 00          	cmp    rax,0x0
    705958805322:	74 23                	je     0x705958805347
    705958805324:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    70595880532b:	00 
    70595880532c:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    705958805333:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    70595880533a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958805340:	89 c9                	mov    ecx,ecx
    705958805342:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958805345:	eb 5b                	jmp    0x7059588053a2
    705958805347:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880534e:	00 
    70595880534f:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    705958805356:	8b b4 24 20 01 00 00 	mov    esi,DWORD PTR [rsp+0x120]
    70595880535d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958805364:	00 
    705958805365:	c7 80 bc 00 00 00 52 	mov    DWORD PTR [rax+0xbc],0x10352
    70595880536c:	03 01 00 
    70595880536f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958805376:	00 00 00 
    705958805379:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    705958805380:	00 00 00 
    705958805383:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    70595880538a:	63 00 00 
    70595880538d:	ff d0                	call   rax
    70595880538f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805396:	00 
    705958805397:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880539e:	75 14                	jne    0x7059588053b4
    7059588053a0:	eb 5e                	jmp    0x705958805400
    7059588053a2:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    7059588053a9:	00 
    7059588053aa:	80 38 00             	cmp    BYTE PTR [rax],0x0
    7059588053ad:	75 53                	jne    0x705958805402
    7059588053af:	e9 93 00 00 00       	jmp    0x705958805447
    7059588053b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588053bb:	00 
    7059588053bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588053c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588053c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588053ce:	be 10 00 00 00       	mov    esi,0x10
    7059588053d3:	b9 02 00 00 00       	mov    ecx,0x2
    7059588053d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588053df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588053e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588053ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588053f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588053fb:	e9 ca 14 00 00       	jmp    0x7059588068ca
    705958805400:	eb a0                	jmp    0x7059588053a2
    705958805402:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805409:	00 
    70595880540a:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10354
    705958805411:	03 01 00 
    705958805414:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880541b:	00 00 00 
    70595880541e:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    705958805425:	00 00 00 
    705958805428:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    70595880542f:	63 00 00 
    705958805432:	ff d0                	call   rax
    705958805434:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880543b:	00 
    70595880543c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958805443:	75 04                	jne    0x705958805449
    705958805445:	eb 4e                	jmp    0x705958805495
    705958805447:	eb 4e                	jmp    0x705958805497
    705958805449:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805450:	00 
    705958805451:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805457:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880545d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805463:	be 10 00 00 00       	mov    esi,0x10
    705958805468:	b9 02 00 00 00       	mov    ecx,0x2
    70595880546d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805474:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880547b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805482:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805489:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805490:	e9 35 14 00 00       	jmp    0x7059588068ca
    705958805495:	eb b0                	jmp    0x705958805447
    705958805497:	eb 00                	jmp    0x705958805499
    705958805499:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588054a0:	00 
    7059588054a1:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    7059588054a8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588054ae:	81 c9 00 00 01 00    	or     ecx,0x10000
    7059588054b4:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    7059588054bb:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    7059588054be:	eb 00                	jmp    0x7059588054c0
    7059588054c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588054c7:	00 
    7059588054c8:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    7059588054cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    7059588054d5:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    7059588054db:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    7059588054e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    7059588054e5:	eb 00                	jmp    0x7059588054e7
    7059588054e7:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    7059588054ee:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588054f5:	00 
    7059588054f6:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    7059588054f9:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    705958805500:	83 e0 03             	and    eax,0x3
    705958805503:	83 f8 00             	cmp    eax,0x0
    705958805506:	0f 84 98 00 00 00    	je     0x7059588055a4
    70595880550c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805513:	00 
    705958805514:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    70595880551b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958805522:	00 
    705958805523:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1035c
    70595880552a:	03 01 00 
    70595880552d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958805534:	00 00 00 
    705958805537:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    70595880553e:	00 00 00 
    705958805541:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958805548:	63 00 00 
    70595880554b:	ba 5c 03 01 00       	mov    edx,0x1035c
    705958805550:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958805556:	ff d0                	call   rax
    705958805558:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880555f:	00 
    705958805560:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805566:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880556c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805572:	be 13 00 00 00       	mov    esi,0x13
    705958805577:	b9 02 00 00 00       	mov    ecx,0x2
    70595880557c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805583:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880558a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805591:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805598:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880559f:	e9 26 13 00 00       	jmp    0x7059588068ca
    7059588055a4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588055ab:	00 
    7059588055ac:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    7059588055b3:	c1 e9 0c             	shr    ecx,0xc
    7059588055b6:	89 c9                	mov    ecx,ecx
    7059588055b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588055bc:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    7059588055c3:	00 
    7059588055c4:	48 83 f8 00          	cmp    rax,0x0
    7059588055c8:	74 23                	je     0x7059588055ed
    7059588055ca:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    7059588055d1:	00 
    7059588055d2:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    7059588055d9:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    7059588055e0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588055e6:	89 c9                	mov    ecx,ecx
    7059588055e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    7059588055eb:	eb 5b                	jmp    0x705958805648
    7059588055ed:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588055f4:	00 
    7059588055f5:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    7059588055fc:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    705958805603:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    70595880560a:	00 
    70595880560b:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1035c
    705958805612:	03 01 00 
    705958805615:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880561c:	00 00 00 
    70595880561f:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    705958805626:	00 00 00 
    705958805629:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958805630:	63 00 00 
    705958805633:	ff d0                	call   rax
    705958805635:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880563c:	00 
    70595880563d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958805644:	75 14                	jne    0x70595880565a
    705958805646:	eb 5e                	jmp    0x7059588056a6
    705958805648:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    70595880564f:	00 
    705958805650:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958805653:	75 53                	jne    0x7059588056a8
    705958805655:	e9 93 00 00 00       	jmp    0x7059588056ed
    70595880565a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805661:	00 
    705958805662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880566e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805674:	be 13 00 00 00       	mov    esi,0x13
    705958805679:	b9 02 00 00 00       	mov    ecx,0x2
    70595880567e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880568c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880569a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588056a1:	e9 24 12 00 00       	jmp    0x7059588068ca
    7059588056a6:	eb a0                	jmp    0x705958805648
    7059588056a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588056af:	00 
    7059588056b0:	c7 87 bc 00 00 00 5e 	mov    DWORD PTR [rdi+0xbc],0x1035e
    7059588056b7:	03 01 00 
    7059588056ba:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588056c1:	00 00 00 
    7059588056c4:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    7059588056cb:	00 00 00 
    7059588056ce:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059588056d5:	63 00 00 
    7059588056d8:	ff d0                	call   rax
    7059588056da:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588056e1:	00 
    7059588056e2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588056e9:	75 04                	jne    0x7059588056ef
    7059588056eb:	eb 4e                	jmp    0x70595880573b
    7059588056ed:	eb 4e                	jmp    0x70595880573d
    7059588056ef:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588056f6:	00 
    7059588056f7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588056fd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805703:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805709:	be 13 00 00 00       	mov    esi,0x13
    70595880570e:	b9 02 00 00 00       	mov    ecx,0x2
    705958805713:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880571a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805721:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805728:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880572f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805736:	e9 8f 11 00 00       	jmp    0x7059588068ca
    70595880573b:	eb b0                	jmp    0x7059588056ed
    70595880573d:	eb 00                	jmp    0x70595880573f
    70595880573f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805746:	00 
    705958805747:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    70595880574e:	89 fa                	mov    edx,edi
    705958805750:	83 ea 02             	sub    edx,0x2
    705958805753:	83 fa 00             	cmp    edx,0x0
    705958805756:	0f 94 c1             	sete   cl
    705958805759:	80 e1 01             	and    cl,0x1
    70595880575c:	0f b6 f1             	movzx  esi,cl
    70595880575f:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    705958805766:	c1 ea 1f             	shr    edx,0x1f
    705958805769:	89 f9                	mov    ecx,edi
    70595880576b:	c1 e9 1f             	shr    ecx,0x1f
    70595880576e:	89 d3                	mov    ebx,edx
    705958805770:	31 cb                	xor    ebx,ecx
    705958805772:	83 f1 00             	xor    ecx,0x0
    705958805775:	21 d9                	and    ecx,ebx
    705958805777:	31 ca                	xor    edx,ecx
    705958805779:	b9 02 00 00 00       	mov    ecx,0x2
    70595880577e:	39 f9                	cmp    ecx,edi
    705958805780:	0f 96 c1             	setbe  cl
    705958805783:	80 e1 01             	and    cl,0x1
    705958805786:	0f b6 c9             	movzx  ecx,cl
    705958805789:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    70595880578f:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958805795:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    70595880579b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    7059588057a1:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    7059588057a7:	eb 00                	jmp    0x7059588057a9
    7059588057a9:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    7059588057b0:	83 f8 00             	cmp    eax,0x0
    7059588057b3:	74 33                	je     0x7059588057e8
    7059588057b5:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588057bc:	00 
    7059588057bd:	c7 81 bc 00 00 00 7a 	mov    DWORD PTR [rcx+0xbc],0x1037a
    7059588057c4:	03 01 00 
    7059588057c7:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    7059588057cd:	83 c0 15             	add    eax,0x15
    7059588057d0:	89 84 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],eax
    7059588057d7:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588057dd:	0f 82 c7 0f 00 00    	jb     0x7059588067aa
    7059588057e3:	e9 e5 0f 00 00       	jmp    0x7059588067cd
    7059588057e8:	eb 00                	jmp    0x7059588057ea
    7059588057ea:	eb 00                	jmp    0x7059588057ec
    7059588057ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588057f3:	00 
    7059588057f4:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    7059588057fb:	89 fa                	mov    edx,edi
    7059588057fd:	83 ea 03             	sub    edx,0x3
    705958805800:	83 fa 00             	cmp    edx,0x0
    705958805803:	0f 94 c1             	sete   cl
    705958805806:	80 e1 01             	and    cl,0x1
    705958805809:	0f b6 f1             	movzx  esi,cl
    70595880580c:	89 b4 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],esi
    705958805813:	c1 ea 1f             	shr    edx,0x1f
    705958805816:	89 f9                	mov    ecx,edi
    705958805818:	c1 e9 1f             	shr    ecx,0x1f
    70595880581b:	89 d3                	mov    ebx,edx
    70595880581d:	31 cb                	xor    ebx,ecx
    70595880581f:	83 f1 00             	xor    ecx,0x0
    705958805822:	21 d9                	and    ecx,ebx
    705958805824:	31 ca                	xor    edx,ecx
    705958805826:	b9 03 00 00 00       	mov    ecx,0x3
    70595880582b:	39 f9                	cmp    ecx,edi
    70595880582d:	0f 96 c1             	setbe  cl
    705958805830:	80 e1 01             	and    cl,0x1
    705958805833:	0f b6 c9             	movzx  ecx,cl
    705958805836:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    70595880583c:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    705958805842:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    705958805848:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    70595880584e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    705958805854:	eb 00                	jmp    0x705958805856
    705958805856:	8b 84 24 f4 00 00 00 	mov    eax,DWORD PTR [rsp+0xf4]
    70595880585d:	83 f8 00             	cmp    eax,0x0
    705958805860:	74 33                	je     0x705958805895
    705958805862:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958805869:	00 
    70595880586a:	c7 81 bc 00 00 00 a4 	mov    DWORD PTR [rcx+0xbc],0x103a4
    705958805871:	03 01 00 
    705958805874:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880587a:	83 c0 17             	add    eax,0x17
    70595880587d:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    705958805884:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880588a:	0f 82 aa 0f 00 00    	jb     0x70595880683a
    705958805890:	e9 c8 0f 00 00       	jmp    0x70595880685d
    705958805895:	eb 00                	jmp    0x705958805897
    705958805897:	eb 00                	jmp    0x705958805899
    705958805899:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588058a0:	00 
    7059588058a1:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    7059588058a7:	eb 00                	jmp    0x7059588058a9
    7059588058a9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    7059588058b0:	83 e0 03             	and    eax,0x3
    7059588058b3:	83 f8 00             	cmp    eax,0x0
    7059588058b6:	0f 84 97 00 00 00    	je     0x705958805953
    7059588058bc:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588058c3:	00 
    7059588058c4:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    7059588058cb:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588058d2:	00 
    7059588058d3:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    7059588058da:	03 01 00 
    7059588058dd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    7059588058e4:	00 00 00 
    7059588058e7:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    7059588058ee:	00 00 00 
    7059588058f1:	31 c0                	xor    eax,eax
    7059588058f3:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588058fa:	63 00 00 
    7059588058fd:	ba 68 03 01 00       	mov    edx,0x10368
    705958805902:	45 31 c0             	xor    r8d,r8d
    705958805905:	ff d0                	call   rax
    705958805907:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880590e:	00 
    70595880590f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805915:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880591b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805921:	be 19 00 00 00       	mov    esi,0x19
    705958805926:	b9 04 00 00 00       	mov    ecx,0x4
    70595880592b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805932:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805939:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805940:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805947:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880594e:	e9 77 0f 00 00       	jmp    0x7059588068ca
    705958805953:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    70595880595a:	00 
    70595880595b:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    705958805962:	c1 e9 0c             	shr    ecx,0xc
    705958805965:	89 c9                	mov    ecx,ecx
    705958805967:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880596b:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    705958805972:	00 
    705958805973:	48 83 f8 00          	cmp    rax,0x0
    705958805977:	74 23                	je     0x70595880599c
    705958805979:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    705958805980:	00 
    705958805981:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    705958805988:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880598e:	89 c9                	mov    ecx,ecx
    705958805990:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958805993:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    70595880599a:	eb 5d                	jmp    0x7059588059f9
    70595880599c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588059a3:	00 
    7059588059a4:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    7059588059ab:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588059b2:	00 
    7059588059b3:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    7059588059ba:	03 01 00 
    7059588059bd:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    7059588059c4:	00 00 00 
    7059588059c7:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    7059588059ce:	00 00 00 
    7059588059d1:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588059d8:	63 00 00 
    7059588059db:	ff d0                	call   rax
    7059588059dd:	89 c1                	mov    ecx,eax
    7059588059df:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588059e6:	00 
    7059588059e7:	89 8c 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],ecx
    7059588059ee:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588059f5:	75 2e                	jne    0x705958805a25
    7059588059f7:	eb 78                	jmp    0x705958805a71
    7059588059f9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    705958805a00:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    705958805a07:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    705958805a0e:	83 c0 04             	add    eax,0x4
    705958805a11:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    705958805a18:	83 e0 03             	and    eax,0x3
    705958805a1b:	83 f8 00             	cmp    eax,0x0
    705958805a1e:	75 64                	jne    0x705958805a84
    705958805a20:	e9 f6 00 00 00       	jmp    0x705958805b1b
    705958805a25:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805a2c:	00 
    705958805a2d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805a33:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805a39:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805a3f:	be 19 00 00 00       	mov    esi,0x19
    705958805a44:	b9 04 00 00 00       	mov    ecx,0x4
    705958805a49:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805a50:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805a57:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805a5e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805a65:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805a6c:	e9 59 0e 00 00       	jmp    0x7059588068ca
    705958805a71:	8b 84 24 e0 00 00 00 	mov    eax,DWORD PTR [rsp+0xe0]
    705958805a78:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    705958805a7f:	e9 75 ff ff ff       	jmp    0x7059588059f9
    705958805a84:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805a8b:	00 
    705958805a8c:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    705958805a93:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958805a9a:	00 
    705958805a9b:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    705958805aa2:	03 01 00 
    705958805aa5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958805aac:	00 00 00 
    705958805aaf:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    705958805ab6:	00 00 00 
    705958805ab9:	31 c0                	xor    eax,eax
    705958805abb:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958805ac2:	63 00 00 
    705958805ac5:	ba 68 03 01 00       	mov    edx,0x10368
    705958805aca:	45 31 c0             	xor    r8d,r8d
    705958805acd:	ff d0                	call   rax
    705958805acf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805ad6:	00 
    705958805ad7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805add:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805ae3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805ae9:	be 19 00 00 00       	mov    esi,0x19
    705958805aee:	b9 04 00 00 00       	mov    ecx,0x4
    705958805af3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805afa:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805b01:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805b08:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805b0f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805b16:	e9 af 0d 00 00       	jmp    0x7059588068ca
    705958805b1b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958805b22:	00 
    705958805b23:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    705958805b2a:	c1 e9 0c             	shr    ecx,0xc
    705958805b2d:	89 c9                	mov    ecx,ecx
    705958805b2f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958805b33:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    705958805b3a:	00 
    705958805b3b:	48 83 f8 00          	cmp    rax,0x0
    705958805b3f:	74 23                	je     0x705958805b64
    705958805b41:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    705958805b48:	00 
    705958805b49:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    705958805b50:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958805b56:	89 c9                	mov    ecx,ecx
    705958805b58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958805b5b:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    705958805b62:	eb 60                	jmp    0x705958805bc4
    705958805b64:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805b6b:	00 
    705958805b6c:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    705958805b73:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958805b7a:	00 
    705958805b7b:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    705958805b82:	03 01 00 
    705958805b85:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    705958805b8c:	00 00 00 
    705958805b8f:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    705958805b96:	00 00 00 
    705958805b99:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958805ba0:	63 00 00 
    705958805ba3:	ff d0                	call   rax
    705958805ba5:	89 c1                	mov    ecx,eax
    705958805ba7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805bae:	00 
    705958805baf:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    705958805bb6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958805bbd:	75 41                	jne    0x705958805c00
    705958805bbf:	e9 88 00 00 00       	jmp    0x705958805c4c
    705958805bc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805bcb:	00 
    705958805bcc:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    705958805bd3:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    705958805bda:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    705958805be1:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    705958805be8:	83 c1 04             	add    ecx,0x4
    705958805beb:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    705958805bf2:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    705958805bf5:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    705958805bfb:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    705958805bfe:	eb 5f                	jmp    0x705958805c5f
    705958805c00:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805c07:	00 
    705958805c08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805c0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805c14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805c1a:	be 19 00 00 00       	mov    esi,0x19
    705958805c1f:	b9 04 00 00 00       	mov    ecx,0x4
    705958805c24:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805c2b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805c32:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805c39:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805c40:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805c47:	e9 7e 0c 00 00       	jmp    0x7059588068ca
    705958805c4c:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    705958805c53:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    705958805c5a:	e9 65 ff ff ff       	jmp    0x705958805bc4
    705958805c5f:	eb 00                	jmp    0x705958805c61
    705958805c61:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    705958805c68:	83 e0 03             	and    eax,0x3
    705958805c6b:	83 f8 00             	cmp    eax,0x0
    705958805c6e:	0f 84 97 00 00 00    	je     0x705958805d0b
    705958805c74:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805c7b:	00 
    705958805c7c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    705958805c83:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958805c8a:	00 
    705958805c8b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958805c92:	03 01 00 
    705958805c95:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958805c9c:	00 00 00 
    705958805c9f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    705958805ca6:	00 00 00 
    705958805ca9:	31 c0                	xor    eax,eax
    705958805cab:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958805cb2:	63 00 00 
    705958805cb5:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958805cba:	45 31 c0             	xor    r8d,r8d
    705958805cbd:	ff d0                	call   rax
    705958805cbf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805cc6:	00 
    705958805cc7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805ccd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805cd3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805cd9:	be 1a 00 00 00       	mov    esi,0x1a
    705958805cde:	b9 02 00 00 00       	mov    ecx,0x2
    705958805ce3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805cea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805cf1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805cf8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805cff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805d06:	e9 bf 0b 00 00       	jmp    0x7059588068ca
    705958805d0b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958805d12:	00 
    705958805d13:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    705958805d1a:	c1 e9 0c             	shr    ecx,0xc
    705958805d1d:	89 c9                	mov    ecx,ecx
    705958805d1f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958805d23:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    705958805d2a:	00 
    705958805d2b:	48 83 f8 00          	cmp    rax,0x0
    705958805d2f:	74 23                	je     0x705958805d54
    705958805d31:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    705958805d38:	00 
    705958805d39:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    705958805d40:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958805d46:	89 c9                	mov    ecx,ecx
    705958805d48:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958805d4b:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    705958805d52:	eb 5d                	jmp    0x705958805db1
    705958805d54:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805d5b:	00 
    705958805d5c:	8b b4 24 c4 00 00 00 	mov    esi,DWORD PTR [rsp+0xc4]
    705958805d63:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958805d6a:	00 
    705958805d6b:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958805d72:	03 01 00 
    705958805d75:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958805d7c:	00 00 00 
    705958805d7f:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    705958805d86:	00 00 00 
    705958805d89:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958805d90:	63 00 00 
    705958805d93:	ff d0                	call   rax
    705958805d95:	89 c1                	mov    ecx,eax
    705958805d97:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805d9e:	00 
    705958805d9f:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    705958805da6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958805dad:	75 32                	jne    0x705958805de1
    705958805daf:	eb 7c                	jmp    0x705958805e2d
    705958805db1:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    705958805db8:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958805dbf:	00 
    705958805dc0:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    705958805dc7:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    705958805dca:	83 c0 04             	add    eax,0x4
    705958805dcd:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    705958805dd4:	83 e0 03             	and    eax,0x3
    705958805dd7:	83 f8 00             	cmp    eax,0x0
    705958805dda:	75 64                	jne    0x705958805e40
    705958805ddc:	e9 f6 00 00 00       	jmp    0x705958805ed7
    705958805de1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805de8:	00 
    705958805de9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805def:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805df5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805dfb:	be 1a 00 00 00       	mov    esi,0x1a
    705958805e00:	b9 02 00 00 00       	mov    ecx,0x2
    705958805e05:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805e0c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805e13:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805e1a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805e21:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805e28:	e9 9d 0a 00 00       	jmp    0x7059588068ca
    705958805e2d:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    705958805e34:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    705958805e3b:	e9 71 ff ff ff       	jmp    0x705958805db1
    705958805e40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958805e47:	00 
    705958805e48:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958805e4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958805e56:	00 
    705958805e57:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958805e5e:	03 01 00 
    705958805e61:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958805e68:	00 00 00 
    705958805e6b:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    705958805e72:	00 00 00 
    705958805e75:	31 c0                	xor    eax,eax
    705958805e77:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958805e7e:	63 00 00 
    705958805e81:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958805e86:	45 31 c0             	xor    r8d,r8d
    705958805e89:	ff d0                	call   rax
    705958805e8b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805e92:	00 
    705958805e93:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805e99:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805e9f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805ea5:	be 1a 00 00 00       	mov    esi,0x1a
    705958805eaa:	b9 02 00 00 00       	mov    ecx,0x2
    705958805eaf:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805eb6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805ebd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805ec4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805ecb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805ed2:	e9 f3 09 00 00       	jmp    0x7059588068ca
    705958805ed7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958805ede:	00 
    705958805edf:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958805ee6:	c1 e9 0c             	shr    ecx,0xc
    705958805ee9:	89 c9                	mov    ecx,ecx
    705958805eeb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958805eef:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    705958805ef6:	00 
    705958805ef7:	48 83 f8 00          	cmp    rax,0x0
    705958805efb:	74 23                	je     0x705958805f20
    705958805efd:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    705958805f04:	00 
    705958805f05:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    705958805f0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958805f12:	89 c9                	mov    ecx,ecx
    705958805f14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    705958805f17:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    705958805f1e:	eb 5d                	jmp    0x705958805f7d
    705958805f20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805f27:	00 
    705958805f28:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    705958805f2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958805f36:	00 
    705958805f37:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958805f3e:	03 01 00 
    705958805f41:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958805f48:	00 00 00 
    705958805f4b:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    705958805f52:	00 00 00 
    705958805f55:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958805f5c:	63 00 00 
    705958805f5f:	ff d0                	call   rax
    705958805f61:	89 c1                	mov    ecx,eax
    705958805f63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805f6a:	00 
    705958805f6b:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    705958805f72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958805f79:	75 32                	jne    0x705958805fad
    705958805f7b:	eb 7c                	jmp    0x705958805ff9
    705958805f7d:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    705958805f84:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958805f8b:	00 
    705958805f8c:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    705958805f93:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    705958805f96:	83 c0 04             	add    eax,0x4
    705958805f99:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    705958805fa0:	83 e0 03             	and    eax,0x3
    705958805fa3:	83 f8 00             	cmp    eax,0x0
    705958805fa6:	75 64                	jne    0x70595880600c
    705958805fa8:	e9 f6 00 00 00       	jmp    0x7059588060a3
    705958805fad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958805fb4:	00 
    705958805fb5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958805fbb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958805fc1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958805fc7:	be 1a 00 00 00       	mov    esi,0x1a
    705958805fcc:	b9 02 00 00 00       	mov    ecx,0x2
    705958805fd1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958805fd8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958805fdf:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958805fe6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958805fed:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958805ff4:	e9 d1 08 00 00       	jmp    0x7059588068ca
    705958805ff9:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    705958806000:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    705958806007:	e9 71 ff ff ff       	jmp    0x705958805f7d
    70595880600c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958806013:	00 
    705958806014:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880601b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    705958806022:	00 
    705958806023:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    70595880602a:	03 01 00 
    70595880602d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958806034:	00 00 00 
    705958806037:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    70595880603e:	00 00 00 
    705958806041:	31 c0                	xor    eax,eax
    705958806043:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880604a:	63 00 00 
    70595880604d:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958806052:	45 31 c0             	xor    r8d,r8d
    705958806055:	ff d0                	call   rax
    705958806057:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880605e:	00 
    70595880605f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958806065:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880606b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958806071:	be 1a 00 00 00       	mov    esi,0x1a
    705958806076:	b9 02 00 00 00       	mov    ecx,0x2
    70595880607b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958806082:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958806089:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958806090:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958806097:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    70595880609e:	e9 27 08 00 00       	jmp    0x7059588068ca
    7059588060a3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    7059588060aa:	00 
    7059588060ab:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    7059588060b2:	c1 e9 0c             	shr    ecx,0xc
    7059588060b5:	89 c9                	mov    ecx,ecx
    7059588060b7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    7059588060bb:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    7059588060c2:	00 
    7059588060c3:	48 83 f8 00          	cmp    rax,0x0
    7059588060c7:	74 23                	je     0x7059588060ec
    7059588060c9:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    7059588060d0:	00 
    7059588060d1:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    7059588060d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    7059588060de:	89 c9                	mov    ecx,ecx
    7059588060e0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    7059588060e3:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    7059588060ea:	eb 5d                	jmp    0x705958806149
    7059588060ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588060f3:	00 
    7059588060f4:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    7059588060fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958806102:	00 
    705958806103:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    70595880610a:	03 01 00 
    70595880610d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958806114:	00 00 00 
    705958806117:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    70595880611e:	00 00 00 
    705958806121:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    705958806128:	63 00 00 
    70595880612b:	ff d0                	call   rax
    70595880612d:	89 c1                	mov    ecx,eax
    70595880612f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806136:	00 
    705958806137:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    70595880613e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958806145:	75 2f                	jne    0x705958806176
    705958806147:	eb 79                	jmp    0x7059588061c2
    705958806149:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    705958806150:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958806157:	00 
    705958806158:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    70595880615f:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    705958806162:	83 c0 04             	add    eax,0x4
    705958806165:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    705958806169:	83 e0 03             	and    eax,0x3
    70595880616c:	83 f8 00             	cmp    eax,0x0
    70595880616f:	75 64                	jne    0x7059588061d5
    705958806171:	e9 f3 00 00 00       	jmp    0x705958806269
    705958806176:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880617d:	00 
    70595880617e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    705958806184:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880618a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958806190:	be 1a 00 00 00       	mov    esi,0x1a
    705958806195:	b9 02 00 00 00       	mov    ecx,0x2
    70595880619a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588061a1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588061a8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588061af:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588061b6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588061bd:	e9 08 07 00 00       	jmp    0x7059588068ca
    7059588061c2:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    7059588061c9:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    7059588061d0:	e9 74 ff ff ff       	jmp    0x705958806149
    7059588061d5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    7059588061dc:	00 
    7059588061dd:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    7059588061e1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    7059588061e8:	00 
    7059588061e9:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    7059588061f0:	03 01 00 
    7059588061f3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588061fa:	00 00 00 
    7059588061fd:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    705958806204:	00 00 00 
    705958806207:	31 c0                	xor    eax,eax
    705958806209:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958806210:	63 00 00 
    705958806213:	ba 6c 03 01 00       	mov    edx,0x1036c
    705958806218:	45 31 c0             	xor    r8d,r8d
    70595880621b:	ff d0                	call   rax
    70595880621d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806224:	00 
    705958806225:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880622b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958806231:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    705958806237:	be 1a 00 00 00       	mov    esi,0x1a
    70595880623c:	b9 02 00 00 00       	mov    ecx,0x2
    705958806241:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    705958806248:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    70595880624f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958806256:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880625d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958806264:	e9 61 06 00 00       	jmp    0x7059588068ca
    705958806269:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958806270:	00 
    705958806271:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958806275:	c1 e9 0c             	shr    ecx,0xc
    705958806278:	89 c9                	mov    ecx,ecx
    70595880627a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880627e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    705958806283:	48 83 f8 00          	cmp    rax,0x0
    705958806287:	74 1a                	je     0x7059588062a3
    705958806289:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    70595880628e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    705958806292:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958806298:	89 c9                	mov    ecx,ecx
    70595880629a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880629d:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    7059588062a1:	eb 57                	jmp    0x7059588062fa
    7059588062a3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588062aa:	00 
    7059588062ab:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    7059588062af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    7059588062b6:	00 
    7059588062b7:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    7059588062be:	03 01 00 
    7059588062c1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588062c8:	00 00 00 
    7059588062cb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    7059588062d2:	00 00 00 
    7059588062d5:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    7059588062dc:	63 00 00 
    7059588062df:	ff d0                	call   rax
    7059588062e1:	89 c1                	mov    ecx,eax
    7059588062e3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588062ea:	00 
    7059588062eb:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    7059588062ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588062f6:	75 29                	jne    0x705958806321
    7059588062f8:	eb 73                	jmp    0x70595880636d
    7059588062fa:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    7059588062fe:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    705958806305:	00 
    705958806306:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    70595880630a:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    70595880630d:	83 c0 04             	add    eax,0x4
    705958806310:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    705958806314:	83 e0 03             	and    eax,0x3
    705958806317:	83 f8 00             	cmp    eax,0x0
    70595880631a:	75 5b                	jne    0x705958806377
    70595880631c:	e9 ea 00 00 00       	jmp    0x70595880640b
    705958806321:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806328:	00 
    705958806329:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    70595880632f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958806335:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    70595880633b:	be 1a 00 00 00       	mov    esi,0x1a
    705958806340:	b9 02 00 00 00       	mov    ecx,0x2
    705958806345:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880634c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958806353:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    70595880635a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    705958806361:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958806368:	e9 5d 05 00 00       	jmp    0x7059588068ca
    70595880636d:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    705958806371:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    705958806375:	eb 83                	jmp    0x7059588062fa
    705958806377:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    70595880637e:	00 
    70595880637f:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958806383:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    70595880638a:	00 
    70595880638b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    705958806392:	03 01 00 
    705958806395:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880639c:	00 00 00 
    70595880639f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    7059588063a6:	00 00 00 
    7059588063a9:	31 c0                	xor    eax,eax
    7059588063ab:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    7059588063b2:	63 00 00 
    7059588063b5:	ba 6c 03 01 00       	mov    edx,0x1036c
    7059588063ba:	45 31 c0             	xor    r8d,r8d
    7059588063bd:	ff d0                	call   rax
    7059588063bf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588063c6:	00 
    7059588063c7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588063cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588063d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588063d9:	be 1a 00 00 00       	mov    esi,0x1a
    7059588063de:	b9 02 00 00 00       	mov    ecx,0x2
    7059588063e3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588063ea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588063f1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588063f8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588063ff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958806406:	e9 bf 04 00 00       	jmp    0x7059588068ca
    70595880640b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    705958806412:	00 
    705958806413:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958806417:	c1 e9 0c             	shr    ecx,0xc
    70595880641a:	89 c9                	mov    ecx,ecx
    70595880641c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958806420:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958806425:	48 83 f8 00          	cmp    rax,0x0
    705958806429:	74 1a                	je     0x705958806445
    70595880642b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    705958806430:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    705958806434:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880643a:	89 c9                	mov    ecx,ecx
    70595880643c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880643f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    705958806443:	eb 57                	jmp    0x70595880649c
    705958806445:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880644c:	00 
    70595880644d:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    705958806451:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    705958806458:	00 
    705958806459:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    705958806460:	03 01 00 
    705958806463:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880646a:	00 00 00 
    70595880646d:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    705958806474:	00 00 00 
    705958806477:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880647e:	63 00 00 
    705958806481:	ff d0                	call   rax
    705958806483:	89 c1                	mov    ecx,eax
    705958806485:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    70595880648c:	00 
    70595880648d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    705958806491:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958806498:	75 1d                	jne    0x7059588064b7
    70595880649a:	eb 67                	jmp    0x705958806503
    70595880649c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588064a3:	00 
    7059588064a4:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    7059588064a8:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    7059588064ac:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    7059588064af:	83 c1 04             	add    ecx,0x4
    7059588064b2:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    7059588064b5:	eb 56                	jmp    0x70595880650d
    7059588064b7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588064be:	00 
    7059588064bf:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588064c5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588064cb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588064d1:	be 1a 00 00 00       	mov    esi,0x1a
    7059588064d6:	b9 02 00 00 00       	mov    ecx,0x2
    7059588064db:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588064e2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588064e9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588064f0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588064f7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588064fe:	e9 c7 03 00 00       	jmp    0x7059588068ca
    705958806503:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    705958806507:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    70595880650b:	eb 8f                	jmp    0x70595880649c
    70595880650d:	eb 00                	jmp    0x70595880650f
    70595880650f:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    705958806516:	83 e0 01             	and    eax,0x1
    705958806519:	83 f8 00             	cmp    eax,0x0
    70595880651c:	75 3d                	jne    0x70595880655b
    70595880651e:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    705958806525:	be 1b 00 00 00       	mov    esi,0x1b
    70595880652a:	b9 02 00 00 00       	mov    ecx,0x2
    70595880652f:	b0 01                	mov    al,0x1
    705958806531:	89 d7                	mov    edi,edx
    705958806533:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    70595880653a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    705958806541:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    705958806548:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    70595880654f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    705958806556:	e9 6f 03 00 00       	jmp    0x7059588068ca
    70595880655b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    705958806562:	00 
    705958806563:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    70595880656a:	00 
    70595880656b:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    705958806572:	03 01 00 
    705958806575:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880657c:	00 00 00 
    70595880657f:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    705958806586:	00 00 00 
    705958806589:	48 b8 d0 5a 8c 23 5a 	movabs rax,0x635a238c5ad0
    705958806590:	63 00 00 
    705958806593:	be 2a 00 00 00       	mov    esi,0x2a
    705958806598:	ff d0                	call   rax
    70595880659a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588065a1:	00 
    7059588065a2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    7059588065a8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    7059588065ae:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    7059588065b4:	be 1b 00 00 00       	mov    esi,0x1b
    7059588065b9:	b9 02 00 00 00       	mov    ecx,0x2
    7059588065be:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    7059588065c5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    7059588065cc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    7059588065d3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    7059588065da:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    7059588065e1:	e9 e4 02 00 00       	jmp    0x7059588068ca
    7059588065e6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588065ed:	00 
    7059588065ee:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    7059588065f5:	e9 c2 03 00 00       	jmp    0x7059588069bc
    7059588065fa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958806601:	00 
    705958806602:	48 89 c1             	mov    rcx,rax
    705958806605:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    70595880660c:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    705958806611:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    705958806618:	03 01 00 
    70595880661b:	74 32                	je     0x70595880664f
    70595880661d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806624:	00 
    705958806625:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    70595880662c:	03 01 00 
    70595880662f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958806636:	00 00 00 
    705958806639:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    705958806640:	00 00 00 
    705958806643:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880664a:	e9 6d 03 00 00       	jmp    0x7059588069bc
    70595880664f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958806656:	00 
    705958806657:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    70595880665e:	00 
    70595880665f:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    705958806664:	8b 8c 24 4c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x14c]
    70595880666b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    705958806672:	70 03 01 00 
    705958806676:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880667d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958806681:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958806688:	ff e0                	jmp    rax
    70595880668a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958806691:	00 
    705958806692:	48 89 c1             	mov    rcx,rax
    705958806695:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    70595880669c:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    7059588066a1:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    7059588066a8:	03 01 00 
    7059588066ab:	74 32                	je     0x7059588066df
    7059588066ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588066b4:	00 
    7059588066b5:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    7059588066bc:	03 01 00 
    7059588066bf:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588066c6:	00 00 00 
    7059588066c9:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    7059588066d0:	00 00 00 
    7059588066d3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    7059588066da:	e9 dd 02 00 00       	jmp    0x7059588069bc
    7059588066df:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    7059588066e6:	00 
    7059588066e7:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    7059588066ee:	00 
    7059588066ef:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    7059588066f4:	8b 8c 24 40 01 00 00 	mov    ecx,DWORD PTR [rsp+0x140]
    7059588066fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    705958806702:	70 03 01 00 
    705958806706:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880670d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958806711:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958806718:	ff e0                	jmp    rax
    70595880671a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958806721:	00 
    705958806722:	48 89 c1             	mov    rcx,rax
    705958806725:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    70595880672c:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    705958806731:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    705958806738:	03 01 00 
    70595880673b:	74 32                	je     0x70595880676f
    70595880673d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806744:	00 
    705958806745:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    70595880674c:	03 01 00 
    70595880674f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958806756:	00 00 00 
    705958806759:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    705958806760:	00 00 00 
    705958806763:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880676a:	e9 4d 02 00 00       	jmp    0x7059588069bc
    70595880676f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958806776:	00 
    705958806777:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    70595880677e:	00 
    70595880677f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    705958806784:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    70595880678b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    705958806792:	70 03 01 00 
    705958806796:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880679d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588067a1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    7059588067a8:	ff e0                	jmp    rax
    7059588067aa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    7059588067b1:	00 
    7059588067b2:	48 89 c1             	mov    rcx,rax
    7059588067b5:	48 81 c1 d0 1b 08 00 	add    rcx,0x81bd0
    7059588067bc:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    7059588067c1:	81 b8 d0 1b 08 00 7a 	cmp    DWORD PTR [rax+0x81bd0],0x1037a
    7059588067c8:	03 01 00 
    7059588067cb:	74 32                	je     0x7059588067ff
    7059588067cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    7059588067d4:	00 
    7059588067d5:	c7 80 bc 00 00 00 7a 	mov    DWORD PTR [rax+0xbc],0x1037a
    7059588067dc:	03 01 00 
    7059588067df:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    7059588067e6:	00 00 00 
    7059588067e9:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    7059588067f0:	00 00 00 
    7059588067f3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    7059588067fa:	e9 bd 01 00 00       	jmp    0x7059588069bc
    7059588067ff:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958806806:	00 
    705958806807:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    70595880680e:	00 
    70595880680f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958806814:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    70595880681b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    705958806822:	7a 03 01 00 
    705958806826:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880682d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958806831:	48 81 c4 18 02 00 00 	add    rsp,0x218
    705958806838:	ff e0                	jmp    rax
    70595880683a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958806841:	00 
    705958806842:	48 89 c1             	mov    rcx,rax
    705958806845:	48 81 c1 20 1d 08 00 	add    rcx,0x81d20
    70595880684c:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    705958806851:	81 b8 20 1d 08 00 a4 	cmp    DWORD PTR [rax+0x81d20],0x103a4
    705958806858:	03 01 00 
    70595880685b:	74 32                	je     0x70595880688f
    70595880685d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806864:	00 
    705958806865:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x103a4
    70595880686c:	03 01 00 
    70595880686f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958806876:	00 00 00 
    705958806879:	c7 80 34 01 00 00 17 	mov    DWORD PTR [rax+0x134],0x17
    705958806880:	00 00 00 
    705958806883:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880688a:	e9 2d 01 00 00       	jmp    0x7059588069bc
    70595880688f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958806896:	00 
    705958806897:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    70595880689e:	00 
    70595880689f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    7059588068a4:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf0]
    7059588068ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    7059588068b2:	a4 03 01 00 
    7059588068b6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7059588068bd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588068c1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    7059588068c8:	ff e0                	jmp    rax
    7059588068ca:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    7059588068d1:	00 
    7059588068d2:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    7059588068d9:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    7059588068e0:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    7059588068e7:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    7059588068ee:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    7059588068f5:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    7059588068f9:	89 c3                	mov    ebx,eax
    7059588068fb:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    7059588068ff:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    705958806903:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    705958806907:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    70595880690b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    705958806911:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    705958806915:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880691b:	73 2d                	jae    0x70595880694a
    70595880691d:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    705958806924:	00 
    705958806925:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    705958806929:	89 d1                	mov    ecx,edx
    70595880692b:	c1 e9 01             	shr    ecx,0x1
    70595880692e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958806934:	89 c9                	mov    ecx,ecx
    705958806936:	48 c1 e1 04          	shl    rcx,0x4
    70595880693a:	48 89 c6             	mov    rsi,rax
    70595880693d:	48 01 ce             	add    rsi,rcx
    705958806940:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    705958806945:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    705958806948:	74 32                	je     0x70595880697c
    70595880694a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    705958806951:	00 
    705958806952:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    705958806956:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595880695a:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    70595880695e:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    705958806962:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    705958806968:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    70595880696e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    705958806974:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    70595880697a:	eb 40                	jmp    0x7059588069bc
    70595880697c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    705958806983:	00 
    705958806984:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    70595880698b:	00 
    70595880698c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958806991:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    705958806995:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    705958806999:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    7059588069a0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    7059588069a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    7059588069ae:	00 
    7059588069af:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    7059588069b3:	48 81 c4 18 02 00 00 	add    rsp,0x218
    7059588069ba:	ff e0                	jmp    rax
    7059588069bc:	48 81 c4 18 02 00 00 	add    rsp,0x218
    7059588069c3:	c2 08 00             	ret    0x8
