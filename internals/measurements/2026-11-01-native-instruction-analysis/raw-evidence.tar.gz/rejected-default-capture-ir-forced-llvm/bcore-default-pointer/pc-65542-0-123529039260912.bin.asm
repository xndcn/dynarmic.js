
build-native-instruction-analysis/capture/bcore-default-pointer/pc-65542-0-123529039260912.bin:     file format binary


Disassembly of section .data:

0000705958812cf0 <.data>:
    705958812cf0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    705958812cf7:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    705958812cfc:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    705958812d01:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    705958812d08:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    705958812d0d:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    705958812d14:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    705958812d19:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    705958812d20:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    705958812d27:	00 
    705958812d28:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    705958812d2d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    705958812d33:	83 fa 00             	cmp    edx,0x0
    705958812d36:	0f 94 c0             	sete   al
    705958812d39:	81 ea 06 00 01 00    	sub    edx,0x10006
    705958812d3f:	83 fa 0a             	cmp    edx,0xa
    705958812d42:	0f 97 c2             	seta   dl
    705958812d45:	08 d0                	or     al,dl
    705958812d47:	24 01                	and    al,0x1
    705958812d49:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    705958812d4f:	81 fa 20 04 01 00    	cmp    edx,0x10420
    705958812d55:	0f 94 c1             	sete   cl
    705958812d58:	81 ea 06 00 01 00    	sub    edx,0x10006
    705958812d5e:	83 fa 0a             	cmp    edx,0xa
    705958812d61:	0f 97 c2             	seta   dl
    705958812d64:	08 d1                	or     cl,dl
    705958812d66:	20 c8                	and    al,cl
    705958812d68:	a8 01                	test   al,0x1
    705958812d6a:	75 05                	jne    0x705958812d71
    705958812d6c:	e9 75 02 00 00       	jmp    0x705958812fe6
    705958812d71:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812d76:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    705958812d7d:	48 89 c8             	mov    rax,rcx
    705958812d80:	48 05 00 00 10 00    	add    rax,0x100000
    705958812d86:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958812d8b:	8b 81 44 00 10 00    	mov    eax,DWORD PTR [rcx+0x100044]
    705958812d91:	83 c0 01             	add    eax,0x1
    705958812d94:	89 81 44 00 10 00    	mov    DWORD PTR [rcx+0x100044],eax
    705958812d9a:	3d 30 75 00 00       	cmp    eax,0x7530
    705958812d9f:	75 40                	jne    0x705958812de1
    705958812da1:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    705958812da6:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    705958812dac:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    705958812db0:	89 c2                	mov    edx,eax
    705958812db2:	83 c2 01             	add    edx,0x1
    705958812db5:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    705958812dbb:	3d 00 01 00 00       	cmp    eax,0x100
    705958812dc0:	73 1d                	jae    0x705958812ddf
    705958812dc2:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    705958812dc7:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    705958812dcb:	89 c9                	mov    ecx,ecx
    705958812dcd:	48 c1 e1 02          	shl    rcx,0x2
    705958812dd1:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    705958812dd8:	c7 04 08 11 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x11
    705958812ddf:	eb 00                	jmp    0x705958812de1
    705958812de1:	eb 00                	jmp    0x705958812de3
    705958812de3:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812de8:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    705958812deb:	81 e1 ff ff 00 00    	and    ecx,0xffff
    705958812df1:	81 c9 00 00 00 01    	or     ecx,0x1000000
    705958812df7:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    705958812dfb:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    705958812dfe:	eb 00                	jmp    0x705958812e00
    705958812e00:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812e05:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    705958812e09:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    705958812e0f:	83 c9 04             	or     ecx,0x4
    705958812e12:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    705958812e16:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    705958812e19:	eb 00                	jmp    0x705958812e1b
    705958812e1b:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    705958812e1f:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    705958812e24:	8b 09                	mov    ecx,DWORD PTR [rcx]
    705958812e26:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    705958812e2a:	83 e0 03             	and    eax,0x3
    705958812e2d:	83 f8 00             	cmp    eax,0x0
    705958812e30:	74 69                	je     0x705958812e9b
    705958812e32:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    705958812e37:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958812e3b:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    705958812e40:	c7 87 bc 00 00 00 0e 	mov    DWORD PTR [rdi+0xbc],0x1000e
    705958812e47:	00 01 00 
    705958812e4a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958812e51:	00 00 00 
    705958812e54:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958812e5b:	00 00 00 
    705958812e5e:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958812e65:	63 00 00 
    705958812e68:	ba 0e 00 01 00       	mov    edx,0x1000e
    705958812e6d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    705958812e73:	ff d0                	call   rax
    705958812e75:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812e7a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958812e80:	b9 03 00 00 00       	mov    ecx,0x3
    705958812e85:	b8 02 00 00 00       	mov    eax,0x2
    705958812e8a:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    705958812e8e:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    705958812e92:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    705958812e96:	e9 dd 01 00 00       	jmp    0x705958813078
    705958812e9b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    705958812ea2:	00 
    705958812ea3:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958812ea7:	c1 e9 0c             	shr    ecx,0xc
    705958812eaa:	89 c9                	mov    ecx,ecx
    705958812eac:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    705958812eb0:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    705958812eb5:	48 83 f8 00          	cmp    rax,0x0
    705958812eb9:	74 1a                	je     0x705958812ed5
    705958812ebb:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958812ec0:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    705958812ec4:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    705958812ec8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    705958812ece:	89 c9                	mov    ecx,ecx
    705958812ed0:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    705958812ed3:	eb 4c                	jmp    0x705958812f21
    705958812ed5:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812eda:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    705958812ede:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    705958812ee2:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    705958812ee7:	c7 80 bc 00 00 00 0e 	mov    DWORD PTR [rax+0xbc],0x1000e
    705958812eee:	00 01 00 
    705958812ef1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    705958812ef8:	00 00 00 
    705958812efb:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    705958812f02:	00 00 00 
    705958812f05:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    705958812f0c:	63 00 00 
    705958812f0f:	ff d0                	call   rax
    705958812f11:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812f16:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958812f1d:	75 0e                	jne    0x705958812f2d
    705958812f1f:	eb 32                	jmp    0x705958812f53
    705958812f21:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    705958812f26:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958812f29:	75 2a                	jne    0x705958812f55
    705958812f2b:	eb 67                	jmp    0x705958812f94
    705958812f2d:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812f32:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958812f38:	b9 03 00 00 00       	mov    ecx,0x3
    705958812f3d:	b8 02 00 00 00       	mov    eax,0x2
    705958812f42:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    705958812f46:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    705958812f4a:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    705958812f4e:	e9 25 01 00 00       	jmp    0x705958813078
    705958812f53:	eb cc                	jmp    0x705958812f21
    705958812f55:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    705958812f5a:	c7 87 bc 00 00 00 10 	mov    DWORD PTR [rdi+0xbc],0x10010
    705958812f61:	00 01 00 
    705958812f64:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958812f6b:	00 00 00 
    705958812f6e:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    705958812f75:	00 00 00 
    705958812f78:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958812f7f:	63 00 00 
    705958812f82:	ff d0                	call   rax
    705958812f84:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812f89:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    705958812f90:	75 04                	jne    0x705958812f96
    705958812f92:	eb 28                	jmp    0x705958812fbc
    705958812f94:	eb 28                	jmp    0x705958812fbe
    705958812f96:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812f9b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    705958812fa1:	b9 03 00 00 00       	mov    ecx,0x3
    705958812fa6:	b8 02 00 00 00       	mov    eax,0x2
    705958812fab:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    705958812faf:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    705958812fb3:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    705958812fb7:	e9 bc 00 00 00       	jmp    0x705958813078
    705958812fbc:	eb d6                	jmp    0x705958812f94
    705958812fbe:	eb 00                	jmp    0x705958812fc0
    705958812fc0:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    705958812fc5:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10010
    705958812fcc:	00 01 00 
    705958812fcf:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    705958812fd5:	83 c0 04             	add    eax,0x4
    705958812fd8:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    705958812fdc:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    705958812fe2:	72 13                	jb     0x705958812ff7
    705958812fe4:	eb 31                	jmp    0x705958813017
    705958812fe6:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    705958812feb:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    705958812ff2:	e9 26 01 00 00       	jmp    0x70595881311d
    705958812ff7:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    705958812ffc:	48 89 c1             	mov    rcx,rax
    705958812fff:	48 81 c1 80 00 08 00 	add    rcx,0x80080
    705958813006:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    70595881300b:	81 b8 80 00 08 00 10 	cmp    DWORD PTR [rax+0x80080],0x10010
    705958813012:	00 01 00 
    705958813015:	74 2f                	je     0x705958813046
    705958813017:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    70595881301c:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10010
    705958813023:	00 01 00 
    705958813026:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595881302d:	00 00 00 
    705958813030:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    705958813037:	00 00 00 
    70595881303a:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    705958813041:	e9 d7 00 00 00       	jmp    0x70595881311d
    705958813046:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    70595881304b:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    705958813050:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    705958813055:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    705958813059:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    705958813060:	10 00 01 00 
    705958813064:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595881306b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595881306f:	48 81 c4 88 00 00 00 	add    rsp,0x88
    705958813076:	ff e0                	jmp    rax
    705958813078:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    70595881307d:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    705958813081:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    705958813085:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    705958813089:	89 c7                	mov    edi,eax
    70595881308b:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    70595881308f:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    705958813093:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    705958813097:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595881309d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    7059588130a1:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    7059588130a7:	73 2a                	jae    0x7059588130d3
    7059588130a9:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    7059588130ae:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    7059588130b2:	89 d1                	mov    ecx,edx
    7059588130b4:	c1 e9 01             	shr    ecx,0x1
    7059588130b7:	81 e1 ff ff 00 00    	and    ecx,0xffff
    7059588130bd:	89 c9                	mov    ecx,ecx
    7059588130bf:	48 c1 e1 04          	shl    rcx,0x4
    7059588130c3:	48 89 c6             	mov    rsi,rax
    7059588130c6:	48 01 ce             	add    rsi,rcx
    7059588130c9:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    7059588130ce:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    7059588130d1:	74 1b                	je     0x7059588130ee
    7059588130d3:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    7059588130d8:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    7059588130dc:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    7059588130e0:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    7059588130e6:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    7059588130ec:	eb 2f                	jmp    0x70595881311d
    7059588130ee:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    7059588130f3:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    7059588130f8:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    7059588130fd:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    705958813101:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958813108:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595881310f:	00 
    705958813110:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    705958813114:	48 81 c4 88 00 00 00 	add    rsp,0x88
    70595881311b:	ff e0                	jmp    rax
    70595881311d:	48 81 c4 88 00 00 00 	add    rsp,0x88
    705958813124:	c2 08 00             	ret    0x8
