
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66488-0-123529039252048.bin:     file format binary


Disassembly of section .data:

0000705958810a50 <.data>:
    705958810a50:	48 83 ec 78          	sub    rsp,0x78
    705958810a54:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    705958810a59:	49 8b 9d 50 01 00 00 	mov    rbx,QWORD PTR [r13+0x150]
    705958810a60:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    705958810a67:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    705958810a6b:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    705958810a6f:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    705958810a74:	41 8b 45 24          	mov    eax,DWORD PTR [r13+0x24]
    705958810a78:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    705958810a7d:	45 8b bd 9c 00 00 00 	mov    r15d,DWORD PTR [r13+0x9c]
    705958810a84:	45 8b 8d a0 00 00 00 	mov    r9d,DWORD PTR [r13+0xa0]
    705958810a8b:	41 8b b5 a4 00 00 00 	mov    esi,DWORD PTR [r13+0xa4]
    705958810a92:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    705958810a99:	41 8b 8d e4 00 00 00 	mov    ecx,DWORD PTR [r13+0xe4]
    705958810aa0:	89 4c 24 04          	mov    DWORD PTR [rsp+0x4],ecx
    705958810aa4:	45 8b b5 e8 00 00 00 	mov    r14d,DWORD PTR [r13+0xe8]
    705958810aab:	45 8b a5 ec 00 00 00 	mov    r12d,DWORD PTR [r13+0xec]
    705958810ab2:	45 8b 9d f0 00 00 00 	mov    r11d,DWORD PTR [r13+0xf0]
    705958810ab9:	45 8b 95 f8 00 00 00 	mov    r10d,DWORD PTR [r13+0xf8]
    705958810ac0:	41 8b 8d fc 00 00 00 	mov    ecx,DWORD PTR [r13+0xfc]
    705958810ac7:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    705958810aca:	45 8b 85 00 01 00 00 	mov    r8d,DWORD PTR [r13+0x100]
    705958810ad1:	41 8b ad 24 01 00 00 	mov    ebp,DWORD PTR [r13+0x124]
    705958810ad8:	41 8b bd 34 01 00 00 	mov    edi,DWORD PTR [r13+0x134]
    705958810adf:	4c 89 6c 24 08       	mov    QWORD PTR [rsp+0x8],r13
    705958810ae4:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    705958810aeb:	41 8d 91 1d fc fe ff 	lea    edx,[r9-0x103e3]
    705958810af2:	83 fa d4             	cmp    edx,0xffffffd4
    705958810af5:	0f 87 2b f5 fe 17    	ja     0x705970800026
    705958810afb:	81 fe ba 03 01 00    	cmp    esi,0x103ba
    705958810b01:	0f 85 1f f5 fe 17    	jne    0x705970800026
    705958810b07:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    705958810b0c:	81 ba 94 00 00 00 b8 	cmp    DWORD PTR [rdx+0x94],0x103b8
    705958810b13:	03 01 00 
    705958810b16:	0f 85 0a f5 fe 17    	jne    0x705970800026
    705958810b1c:	48 89 5c 24 68       	mov    QWORD PTR [rsp+0x68],rbx
    705958810b21:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    705958810b26:	48 8b b2 40 01 00 00 	mov    rsi,QWORD PTR [rdx+0x140]
    705958810b2d:	48 89 74 24 30       	mov    QWORD PTR [rsp+0x30],rsi
    705958810b32:	48 8b 92 38 01 00 00 	mov    rdx,QWORD PTR [rdx+0x138]
    705958810b39:	48 89 54 24 40       	mov    QWORD PTR [rsp+0x40],rdx
    705958810b3e:	66 90                	xchg   ax,ax
    705958810b40:	4c 89 4c 24 70       	mov    QWORD PTR [rsp+0x70],r9
    705958810b45:	44 89 64 24 20       	mov    DWORD PTR [rsp+0x20],r12d
    705958810b4a:	8d 71 02             	lea    esi,[rcx+0x2]
    705958810b4d:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    705958810b51:	39 f2                	cmp    edx,esi
    705958810b53:	0f 47 f2             	cmova  esi,edx
    705958810b56:	89 ca                	mov    edx,ecx
    705958810b58:	f7 d2                	not    edx
    705958810b5a:	01 f2                	add    edx,esi
    705958810b5c:	d1 ea                	shr    edx,1
    705958810b5e:	41 83 ff 01          	cmp    r15d,0x1
    705958810b62:	44 89 ff             	mov    edi,r15d
    705958810b65:	83 d7 ff             	adc    edi,0xffffffff
    705958810b68:	39 fa                	cmp    edx,edi
    705958810b6a:	0f 42 fa             	cmovb  edi,edx
    705958810b6d:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    705958810b72:	f6 c3 03             	test   bl,0x3
    705958810b75:	44 89 7c 24 3c       	mov    DWORD PTR [rsp+0x3c],r15d
    705958810b7a:	0f 85 20 01 00 00    	jne    0x705958810ca0
    705958810b80:	89 de                	mov    esi,ebx
    705958810b82:	48 8d 2c be          	lea    rbp,[rsi+rdi*4]
    705958810b86:	bb fc ff ff ff       	mov    ebx,0xfffffffc
    705958810b8b:	48 39 dd             	cmp    rbp,rbx
    705958810b8e:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    705958810b93:	0f 87 07 01 00 00    	ja     0x705958810ca0
    705958810b99:	48 8d 3c be          	lea    rdi,[rsi+rdi*4]
    705958810b9d:	48 83 c7 03          	add    rdi,0x3
    705958810ba1:	48 31 f7             	xor    rdi,rsi
    705958810ba4:	48 81 ff ff 0f 00 00 	cmp    rdi,0xfff
    705958810bab:	0f 87 ef 00 00 00    	ja     0x705958810ca0
    705958810bb1:	48 89 f7             	mov    rdi,rsi
    705958810bb4:	48 c1 ef 0c          	shr    rdi,0xc
    705958810bb8:	48 8b 6c 24 40       	mov    rbp,QWORD PTR [rsp+0x40]
    705958810bbd:	48 8b 7c fd 00       	mov    rdi,QWORD PTR [rbp+rdi*8+0x0]
    705958810bc2:	48 85 ff             	test   rdi,rdi
    705958810bc5:	0f 84 d5 00 00 00    	je     0x705958810ca0
    705958810bcb:	81 e6 ff 0f 00 00    	and    esi,0xfff
    705958810bd1:	41 83 ff 01          	cmp    r15d,0x1
    705958810bd5:	44 89 f8             	mov    eax,r15d
    705958810bd8:	83 d0 ff             	adc    eax,0xffffffff
    705958810bdb:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    705958810be0:	89 d0                	mov    eax,edx
    705958810be2:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    705958810be7:	48 01 f7             	add    rdi,rsi
    705958810bea:	83 c3 04             	add    ebx,0x4
    705958810bed:	44 8b 64 24 10       	mov    r12d,DWORD PTR [rsp+0x10]
    705958810bf2:	89 d8                	mov    eax,ebx
    705958810bf4:	31 d2                	xor    edx,edx
    705958810bf6:	44 89 fb             	mov    ebx,r15d
    705958810bf9:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    705958810bfe:	66 90                	xchg   ax,ax
    705958810c00:	89 ce                	mov    esi,ecx
    705958810c02:	49 89 d7             	mov    r15,rdx
    705958810c05:	41 89 c5             	mov    r13d,eax
    705958810c08:	49 8d 2c 14          	lea    rbp,[r12+rdx*1]
    705958810c0c:	89 2c 97             	mov    DWORD PTR [rdi+rdx*4],ebp
    705958810c0f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958810c14:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958810c17:	0f 85 29 04 00 00    	jne    0x705958811046
    705958810c1d:	43 8d 04 3c          	lea    eax,[r12+r15*1]
    705958810c21:	47 8d 34 3c          	lea    r14d,[r12+r15*1]
    705958810c25:	41 ff c6             	inc    r14d
    705958810c28:	89 e9                	mov    ecx,ebp
    705958810c2a:	c1 e9 1f             	shr    ecx,0x1f
    705958810c2d:	41 c1 ee 1f          	shr    r14d,0x1f
    705958810c31:	c4 c2 70 f2 ce       	andn   ecx,ecx,r14d
    705958810c36:	45 31 db             	xor    r11d,r11d
    705958810c39:	83 fd ff             	cmp    ebp,0xffffffff
    705958810c3c:	41 0f 94 c3          	sete   r11b
    705958810c40:	45 31 c9             	xor    r9d,r9d
    705958810c43:	83 f8 ff             	cmp    eax,0xffffffff
    705958810c46:	41 0f 94 c1          	sete   r9b
    705958810c4a:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    705958810c4d:	41 09 c8             	or     r8d,ecx
    705958810c50:	4c 39 7c 24 58       	cmp    QWORD PTR [rsp+0x58],r15
    705958810c55:	0f 84 15 01 00 00    	je     0x705958810d70
    705958810c5b:	4c 39 7c 24 50       	cmp    QWORD PTR [rsp+0x50],r15
    705958810c60:	0f 84 e9 02 00 00    	je     0x705958810f4f
    705958810c66:	8d 4e 02             	lea    ecx,[rsi+0x2]
    705958810c69:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958810c6e:	48 89 fd             	mov    rbp,rdi
    705958810c71:	48 89 f7             	mov    rdi,rsi
    705958810c74:	8b b0 58 01 00 00    	mov    esi,DWORD PTR [rax+0x158]
    705958810c7a:	49 8d 57 01          	lea    rdx,[r15+0x1]
    705958810c7e:	41 8d 45 04          	lea    eax,[r13+0x4]
    705958810c82:	ff cb                	dec    ebx
    705958810c84:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    705958810c88:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    705958810c8d:	85 f6                	test   esi,esi
    705958810c8f:	48 89 fe             	mov    rsi,rdi
    705958810c92:	48 89 ef             	mov    rdi,rbp
    705958810c95:	0f 85 65 ff ff ff    	jne    0x705958810c00
    705958810c9b:	e9 af 02 00 00       	jmp    0x705958810f4f
    705958810ca0:	31 d2                	xor    edx,edx
    705958810ca2:	41 89 dd             	mov    r13d,ebx
    705958810ca5:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    705958810caa:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    705958810caf:	90                   	nop
    705958810cb0:	44 89 eb             	mov    ebx,r13d
    705958810cb3:	89 ce                	mov    esi,ecx
    705958810cb5:	41 89 d4             	mov    r12d,edx
    705958810cb8:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    705958810cbd:	42 8d 2c 21          	lea    ebp,[rcx+r12*1]
    705958810cc1:	f6 44 24 18 03       	test   BYTE PTR [rsp+0x18],0x3
    705958810cc6:	0f 85 33 04 00 00    	jne    0x7059588110ff
    705958810ccc:	89 d9                	mov    ecx,ebx
    705958810cce:	c1 e9 0c             	shr    ecx,0xc
    705958810cd1:	48 8b 0c cf          	mov    rcx,QWORD PTR [rdi+rcx*8]
    705958810cd5:	48 85 c9             	test   rcx,rcx
    705958810cd8:	44 89 54 24 58       	mov    DWORD PTR [rsp+0x58],r10d
    705958810cdd:	0f 84 39 05 00 00    	je     0x70595881121c
    705958810ce3:	89 d8                	mov    eax,ebx
    705958810ce5:	25 ff 0f 00 00       	and    eax,0xfff
    705958810cea:	89 2c 01             	mov    DWORD PTR [rcx+rax*1],ebp
    705958810ced:	44 8d 6b 04          	lea    r13d,[rbx+0x4]
    705958810cf1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    705958810cf6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    705958810cf9:	0f 85 f0 05 00 00    	jne    0x7059588112ef
    705958810cff:	45 31 c9             	xor    r9d,r9d
    705958810d02:	41 89 ee             	mov    r14d,ebp
    705958810d05:	41 ff c6             	inc    r14d
    705958810d08:	41 0f 94 c1          	sete   r9b
    705958810d0c:	89 e8                	mov    eax,ebp
    705958810d0e:	c1 e8 1f             	shr    eax,0x1f
    705958810d11:	41 c1 ee 1f          	shr    r14d,0x1f
    705958810d15:	c4 c2 78 f2 c6       	andn   eax,eax,r14d
    705958810d1a:	45 31 db             	xor    r11d,r11d
    705958810d1d:	83 fd ff             	cmp    ebp,0xffffffff
    705958810d20:	41 0f 94 c3          	sete   r11b
    705958810d24:	89 04 24             	mov    DWORD PTR [rsp],eax
    705958810d27:	41 09 c0             	or     r8d,eax
    705958810d2a:	41 83 ff 02          	cmp    r15d,0x2
    705958810d2e:	72 60                	jb     0x705958810d90
    705958810d30:	48 89 f5             	mov    rbp,rsi
    705958810d33:	8d 4e 02             	lea    ecx,[rsi+0x2]
    705958810d36:	3b 4c 24 24          	cmp    ecx,DWORD PTR [rsp+0x24]
    705958810d3a:	0f 83 48 02 00 00    	jae    0x705958810f88
    705958810d40:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958810d45:	8b b0 58 01 00 00    	mov    esi,DWORD PTR [rax+0x158]
    705958810d4b:	41 8d 54 24 01       	lea    edx,[r12+0x1]
    705958810d50:	41 ff cf             	dec    r15d
    705958810d53:	b8 b8 03 01 00       	mov    eax,0x103b8
    705958810d58:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    705958810d5c:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    705958810d61:	85 f6                	test   esi,esi
    705958810d63:	0f 85 47 ff ff ff    	jne    0x705958810cb0
    705958810d69:	e9 1a 02 00 00       	jmp    0x705958810f88
    705958810d6e:	66 90                	xchg   ax,ax
    705958810d70:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    705958810d75:	44 01 f8             	add    eax,r15d
    705958810d78:	ff c0                	inc    eax
    705958810d7a:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    705958810d7f:	eb 24                	jmp    0x705958810da5
    705958810d81:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    705958810d88:	0f 1f 84 00 00 00 00 
    705958810d8f:	00 
    705958810d90:	83 c3 04             	add    ebx,0x4
    705958810d93:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    705958810d98:	44 01 e0             	add    eax,r12d
    705958810d9b:	ff c0                	inc    eax
    705958810d9d:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    705958810da2:	41 89 dd             	mov    r13d,ebx
    705958810da5:	48 89 f5             	mov    rbp,rsi
    705958810da8:	4c 89 6c 24 18       	mov    QWORD PTR [rsp+0x18],r13
    705958810dad:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    705958810db2:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958810db7:	c7 40 20 fc 92 01 00 	mov    DWORD PTR [rax+0x20],0x192fc
    705958810dbe:	c7 40 30 fc 92 01 00 	mov    DWORD PTR [rax+0x30],0x192fc
    705958810dc5:	48 b9 0d 66 19 00 5f 	movabs rcx,0x3c6ef35f0019660d
    705958810dcc:	f3 6e 3c 
    705958810dcf:	48 89 48 18          	mov    QWORD PTR [rax+0x18],rcx
    705958810dd3:	c7 40 0c ff 1f 00 00 	mov    DWORD PTR [rax+0xc],0x1fff
    705958810dda:	48 b9 00 20 00 00 fc 	movabs rcx,0x192fc00002000
    705958810de1:	92 01 00 
    705958810de4:	48 89 48 28          	mov    QWORD PTR [rax+0x28],rcx
    705958810de8:	c7 40 50 fc 92 01 00 	mov    DWORD PTR [rax+0x50],0x192fc
    705958810def:	c7 80 94 00 00 00 e6 	mov    DWORD PTR [rax+0x94],0x103e6
    705958810df6:	03 01 00 
    705958810df9:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
    705958810dfe:	41 81 f9 e2 03 01 00 	cmp    r9d,0x103e2
    705958810e05:	0f 84 9c 05 00 00    	je     0x7059588113a7
    705958810e0b:	41 bf 00 20 00 00    	mov    r15d,0x2000
    705958810e11:	be fa 03 01 00       	mov    esi,0x103fa
    705958810e16:	b8 e6 03 01 00       	mov    eax,0x103e6
    705958810e1b:	41 bd 04 00 00 00    	mov    r13d,0x4
    705958810e21:	b2 01                	mov    dl,0x1
    705958810e23:	bf 0e 00 00 00       	mov    edi,0xe
    705958810e28:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    705958810e2c:	45 89 dc             	mov    r12d,r11d
    705958810e2f:	8d 0c 2f             	lea    ecx,[rdi+rbp*1]
    705958810e32:	3b 4c 24 24          	cmp    ecx,DWORD PTR [rsp+0x24]
    705958810e36:	73 54                	jae    0x705958810e8c
    705958810e38:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    705958810e3d:	8b 9b 58 01 00 00    	mov    ebx,DWORD PTR [rbx+0x158]
    705958810e43:	85 db                	test   ebx,ebx
    705958810e45:	74 45                	je     0x705958810e8c
    705958810e47:	3d b8 03 01 00       	cmp    eax,0x103b8
    705958810e4c:	75 4b                	jne    0x705958810e99
    705958810e4e:	41 8d 91 1d fc fe ff 	lea    edx,[r9-0x103e3]
    705958810e55:	b8 b8 03 01 00       	mov    eax,0x103b8
    705958810e5a:	83 fa d4             	cmp    edx,0xffffffd4
    705958810e5d:	77 1d                	ja     0x705958810e7c
    705958810e5f:	81 fe ba 03 01 00    	cmp    esi,0x103ba
    705958810e65:	75 15                	jne    0x705958810e7c
    705958810e67:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    705958810e6c:	81 ba 94 00 00 00 b8 	cmp    DWORD PTR [rdx+0x94],0x103b8
    705958810e73:	03 01 00 
    705958810e76:	0f 84 c4 fc ff ff    	je     0x705958810b40
    705958810e7c:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
    705958810e81:	c6 82 65 01 00 00 01 	mov    BYTE PTR [rdx+0x165],0x1
    705958810e88:	31 d2                	xor    edx,edx
    705958810e8a:	89 cd                	mov    ebp,ecx
    705958810e8c:	45 89 e9             	mov    r9d,r13d
    705958810e8f:	4c 8b 6c 24 18       	mov    r13,QWORD PTR [rsp+0x18]
    705958810e94:	e9 34 01 00 00       	jmp    0x705958810fcd
    705958810e99:	44 89 6c 24 30       	mov    DWORD PTR [rsp+0x30],r13d
    705958810e9e:	8d 1c c5 00 00 00 00 	lea    ebx,[rax*8+0x0]
    705958810ea5:	81 e3 f0 ff 0f 00    	and    ebx,0xffff0
    705958810eab:	4c 8b 4c 24 68       	mov    r9,QWORD PTR [rsp+0x68]
    705958810eb0:	41 39 04 19          	cmp    DWORD PTR [r9+rbx*1],eax
    705958810eb4:	0f 85 74 f1 fe 17    	jne    0x70597080002e
    705958810eba:	49 8b 54 19 08       	mov    rdx,QWORD PTR [r9+rbx*1+0x8]
    705958810ebf:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    705958810ec4:	4c 8b 6c 24 08       	mov    r13,QWORD PTR [rsp+0x8]
    705958810ec9:	41 89 5d 00          	mov    DWORD PTR [r13+0x0],ebx
    705958810ecd:	48 8b 5c 24 18       	mov    rbx,QWORD PTR [rsp+0x18]
    705958810ed2:	41 89 5d 24          	mov    DWORD PTR [r13+0x24],ebx
    705958810ed6:	45 89 bd 9c 00 00 00 	mov    DWORD PTR [r13+0x9c],r15d
    705958810edd:	41 89 b5 a4 00 00 00 	mov    DWORD PTR [r13+0xa4],esi
    705958810ee4:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    705958810eeb:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958810eef:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    705958810ef6:	45 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r14d
    705958810efd:	45 89 a5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],r12d
    705958810f04:	45 89 9d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],r11d
    705958810f0b:	45 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],r10d
    705958810f12:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958810f15:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    705958810f1c:	45 89 85 00 01 00 00 	mov    DWORD PTR [r13+0x100],r8d
    705958810f23:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    705958810f27:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    705958810f2e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    705958810f35:	00 
    705958810f36:	41 89 bd 34 01 00 00 	mov    DWORD PTR [r13+0x134],edi
    705958810f3d:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    705958810f44:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    705958810f49:	48 83 c4 78          	add    rsp,0x78
    705958810f4d:	ff e2                	jmp    rdx
    705958810f4f:	48 89 f5             	mov    rbp,rsi
    705958810f52:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    705958810f57:	44 89 f8             	mov    eax,r15d
    705958810f5a:	f7 d0                	not    eax
    705958810f5c:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    705958810f60:	01 c1                	add    ecx,eax
    705958810f62:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    705958810f67:	44 01 f8             	add    eax,r15d
    705958810f6a:	ff c0                	inc    eax
    705958810f6c:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    705958810f71:	41 89 cf             	mov    r15d,ecx
    705958810f74:	b2 01                	mov    dl,0x1
    705958810f76:	41 b9 02 00 00 00    	mov    r9d,0x2
    705958810f7c:	b8 b8 03 01 00       	mov    eax,0x103b8
    705958810f81:	be ba 03 01 00       	mov    esi,0x103ba
    705958810f86:	eb 39                	jmp    0x705958810fc1
    705958810f88:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    705958810f8d:	44 89 e0             	mov    eax,r12d
    705958810f90:	f7 d0                	not    eax
    705958810f92:	44 8b 7c 24 3c       	mov    r15d,DWORD PTR [rsp+0x3c]
    705958810f97:	41 01 c7             	add    r15d,eax
    705958810f9a:	83 c3 04             	add    ebx,0x4
    705958810f9d:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    705958810fa2:	44 01 e0             	add    eax,r12d
    705958810fa5:	ff c0                	inc    eax
    705958810fa7:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    705958810fac:	b2 01                	mov    dl,0x1
    705958810fae:	41 b9 02 00 00 00    	mov    r9d,0x2
    705958810fb4:	b8 b8 03 01 00       	mov    eax,0x103b8
    705958810fb9:	be ba 03 01 00       	mov    esi,0x103ba
    705958810fbe:	41 89 dd             	mov    r13d,ebx
    705958810fc1:	45 89 dc             	mov    r12d,r11d
    705958810fc4:	44 8b 14 24          	mov    r10d,DWORD PTR [rsp]
    705958810fc8:	bf 02 00 00 00       	mov    edi,0x2
    705958810fcd:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    705958810fd2:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    705958810fd7:	89 0b                	mov    DWORD PTR [rbx],ecx
    705958810fd9:	44 89 6b 24          	mov    DWORD PTR [rbx+0x24],r13d
    705958810fdd:	44 89 bb 9c 00 00 00 	mov    DWORD PTR [rbx+0x9c],r15d
    705958810fe4:	89 b3 a4 00 00 00    	mov    DWORD PTR [rbx+0xa4],esi
    705958810fea:	89 83 bc 00 00 00    	mov    DWORD PTR [rbx+0xbc],eax
    705958810ff0:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705958810ff4:	89 83 e4 00 00 00    	mov    DWORD PTR [rbx+0xe4],eax
    705958810ffa:	44 89 b3 e8 00 00 00 	mov    DWORD PTR [rbx+0xe8],r14d
    705958811001:	44 89 a3 ec 00 00 00 	mov    DWORD PTR [rbx+0xec],r12d
    705958811008:	44 89 9b f0 00 00 00 	mov    DWORD PTR [rbx+0xf0],r11d
    70595881100f:	44 89 93 f8 00 00 00 	mov    DWORD PTR [rbx+0xf8],r10d
    705958811016:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811019:	89 83 fc 00 00 00    	mov    DWORD PTR [rbx+0xfc],eax
    70595881101f:	44 89 83 00 01 00 00 	mov    DWORD PTR [rbx+0x100],r8d
    705958811026:	44 89 8b 24 01 00 00 	mov    DWORD PTR [rbx+0x124],r9d
    70595881102d:	88 93 28 01 00 00    	mov    BYTE PTR [rbx+0x128],dl
    705958811033:	89 bb 34 01 00 00    	mov    DWORD PTR [rbx+0x134],edi
    705958811039:	89 ab 5c 01 00 00    	mov    DWORD PTR [rbx+0x15c],ebp
    70595881103f:	48 83 c4 78          	add    rsp,0x78
    705958811043:	c2 08 00             	ret    0x8
    705958811046:	48 89 7c 24 18       	mov    QWORD PTR [rsp+0x18],rdi
    70595881104b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    705958811050:	89 2f                	mov    DWORD PTR [rdi],ebp
    705958811052:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    705958811056:	89 9f 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],ebx
    70595881105c:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    705958811063:	03 01 00 
    705958811066:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x103ba
    70595881106d:	03 01 00 
    705958811070:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    705958811077:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    70595881107e:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958811082:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    705958811088:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    70595881108f:	44 89 97 f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r10d
    705958811096:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811099:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    70595881109f:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    7059588110a6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    7059588110ad:	00 00 00 
    7059588110b0:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    7059588110b7:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    7059588110be:	00 00 00 
    7059588110c1:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    7059588110c7:	45 89 c6             	mov    r14d,r8d
    7059588110ca:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059588110d1:	63 00 00 
    7059588110d4:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    7059588110d9:	ff d0                	call   rax
    7059588110db:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
    7059588110e0:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    7059588110e5:	45 89 f0             	mov    r8d,r14d
    7059588110e8:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    7059588110ed:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    7059588110f4:	0f 84 23 fb ff ff    	je     0x705958810c1d
    7059588110fa:	e9 16 ef fe 17       	jmp    0x705970800015
    7059588110ff:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    705958811104:	89 2f                	mov    DWORD PTR [rdi],ebp
    705958811106:	89 5f 24             	mov    DWORD PTR [rdi+0x24],ebx
    705958811109:	44 89 bf 9c 00 00 00 	mov    DWORD PTR [rdi+0x9c],r15d
    705958811110:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    705958811117:	03 01 00 
    70595881111a:	89 87 bc 00 00 00    	mov    DWORD PTR [rdi+0xbc],eax
    705958811120:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    705958811127:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    70595881112e:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958811132:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    705958811138:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    70595881113f:	44 89 97 f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r10d
    705958811146:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811149:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    70595881114f:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    705958811156:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595881115d:	00 00 00 
    705958811160:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    705958811167:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    70595881116e:	00 00 00 
    705958811171:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    705958811177:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    70595881117c:	ba b8 03 01 00       	mov    edx,0x103b8
    705958811181:	89 d9                	mov    ecx,ebx
    705958811183:	49 89 fd             	mov    r13,rdi
    705958811186:	41 b8 00 00 01 00    	mov    r8d,0x10000
    70595881118c:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    705958811193:	63 00 00 
    705958811196:	ff d0                	call   rax
    705958811198:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    70595881119f:	00 
    7059588111a0:	48 8b 5c 24 08       	mov    rbx,QWORD PTR [rsp+0x8]
    7059588111a5:	8b 03                	mov    eax,DWORD PTR [rbx]
    7059588111a7:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
    7059588111ac:	8b 43 24             	mov    eax,DWORD PTR [rbx+0x24]
    7059588111af:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
    7059588111b4:	44 8b bb 9c 00 00 00 	mov    r15d,DWORD PTR [rbx+0x9c]
    7059588111bb:	44 8b 8b a0 00 00 00 	mov    r9d,DWORD PTR [rbx+0xa0]
    7059588111c2:	8b b3 a4 00 00 00    	mov    esi,DWORD PTR [rbx+0xa4]
    7059588111c8:	8b 83 bc 00 00 00    	mov    eax,DWORD PTR [rbx+0xbc]
    7059588111ce:	8b 8b e4 00 00 00    	mov    ecx,DWORD PTR [rbx+0xe4]
    7059588111d4:	89 4c 24 04          	mov    DWORD PTR [rsp+0x4],ecx
    7059588111d8:	44 8b b3 e8 00 00 00 	mov    r14d,DWORD PTR [rbx+0xe8]
    7059588111df:	44 8b a3 ec 00 00 00 	mov    r12d,DWORD PTR [rbx+0xec]
    7059588111e6:	44 8b 9b f0 00 00 00 	mov    r11d,DWORD PTR [rbx+0xf0]
    7059588111ed:	44 8b 93 f8 00 00 00 	mov    r10d,DWORD PTR [rbx+0xf8]
    7059588111f4:	8b 8b fc 00 00 00    	mov    ecx,DWORD PTR [rbx+0xfc]
    7059588111fa:	89 0c 24             	mov    DWORD PTR [rsp],ecx
    7059588111fd:	44 8b 83 00 01 00 00 	mov    r8d,DWORD PTR [rbx+0x100]
    705958811204:	44 8b ab 24 01 00 00 	mov    r13d,DWORD PTR [rbx+0x124]
    70595881120b:	8b bb 34 01 00 00    	mov    edi,DWORD PTR [rbx+0x134]
    705958811211:	8b ab 5c 01 00 00    	mov    ebp,DWORD PTR [rbx+0x15c]
    705958811217:	e9 13 fc ff ff       	jmp    0x705958810e2f
    70595881121c:	48 8b 4c 24 08       	mov    rcx,QWORD PTR [rsp+0x8]
    705958811221:	89 29                	mov    DWORD PTR [rcx],ebp
    705958811223:	89 59 24             	mov    DWORD PTR [rcx+0x24],ebx
    705958811226:	44 89 b9 9c 00 00 00 	mov    DWORD PTR [rcx+0x9c],r15d
    70595881122d:	c7 81 a4 00 00 00 ba 	mov    DWORD PTR [rcx+0xa4],0x103ba
    705958811234:	03 01 00 
    705958811237:	89 81 bc 00 00 00    	mov    DWORD PTR [rcx+0xbc],eax
    70595881123d:	44 89 89 e4 00 00 00 	mov    DWORD PTR [rcx+0xe4],r9d
    705958811244:	44 89 b1 e8 00 00 00 	mov    DWORD PTR [rcx+0xe8],r14d
    70595881124b:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    70595881124f:	89 81 ec 00 00 00    	mov    DWORD PTR [rcx+0xec],eax
    705958811255:	44 89 99 f0 00 00 00 	mov    DWORD PTR [rcx+0xf0],r11d
    70595881125c:	44 89 91 f8 00 00 00 	mov    DWORD PTR [rcx+0xf8],r10d
    705958811263:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811266:	89 81 fc 00 00 00    	mov    DWORD PTR [rcx+0xfc],eax
    70595881126c:	44 89 81 00 01 00 00 	mov    DWORD PTR [rcx+0x100],r8d
    705958811273:	c7 81 24 01 00 00 02 	mov    DWORD PTR [rcx+0x124],0x2
    70595881127a:	00 00 00 
    70595881127d:	c6 81 28 01 00 00 00 	mov    BYTE PTR [rcx+0x128],0x0
    705958811284:	c7 81 34 01 00 00 01 	mov    DWORD PTR [rcx+0x134],0x1
    70595881128b:	00 00 00 
    70595881128e:	89 b1 5c 01 00 00    	mov    DWORD PTR [rcx+0x15c],esi
    705958811294:	44 89 4c 24 04       	mov    DWORD PTR [rsp+0x4],r9d
    705958811299:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    70595881129e:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    7059588112a3:	89 de                	mov    esi,ebx
    7059588112a5:	89 ea                	mov    edx,ebp
    7059588112a7:	44 89 44 24 64       	mov    DWORD PTR [rsp+0x64],r8d
    7059588112ac:	44 89 5c 24 50       	mov    DWORD PTR [rsp+0x50],r11d
    7059588112b1:	48 b8 20 06 7b 23 5a 	movabs rax,0x635a237b0620
    7059588112b8:	63 00 00 
    7059588112bb:	ff d0                	call   rax
    7059588112bd:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    7059588112c2:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    7059588112c7:	44 8b 4c 24 04       	mov    r9d,DWORD PTR [rsp+0x4]
    7059588112cc:	44 8b 5c 24 50       	mov    r11d,DWORD PTR [rsp+0x50]
    7059588112d1:	44 8b 44 24 64       	mov    r8d,DWORD PTR [rsp+0x64]
    7059588112d6:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    7059588112db:	0f b6 90 28 01 00 00 	movzx  edx,BYTE PTR [rax+0x128]
    7059588112e2:	84 d2                	test   dl,dl
    7059588112e4:	0f 84 03 fa ff ff    	je     0x705958810ced
    7059588112ea:	e9 b1 fe ff ff       	jmp    0x7059588111a0
    7059588112ef:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7059588112f4:	89 2f                	mov    DWORD PTR [rdi],ebp
    7059588112f6:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    7059588112fa:	44 89 bf 9c 00 00 00 	mov    DWORD PTR [rdi+0x9c],r15d
    705958811301:	c7 87 a4 00 00 00 ba 	mov    DWORD PTR [rdi+0xa4],0x103ba
    705958811308:	03 01 00 
    70595881130b:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x103ba
    705958811312:	03 01 00 
    705958811315:	44 89 8f e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r9d
    70595881131c:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    705958811323:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    705958811327:	89 87 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],eax
    70595881132d:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    705958811334:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    705958811338:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    70595881133e:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705958811341:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    705958811347:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    70595881134e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    705958811355:	00 00 00 
    705958811358:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    70595881135f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    705958811366:	00 00 00 
    705958811369:	89 b7 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],esi
    70595881136f:	45 89 c6             	mov    r14d,r8d
    705958811372:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    705958811379:	63 00 00 
    70595881137c:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
    705958811381:	ff d0                	call   rax
    705958811383:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
    705958811388:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    70595881138d:	45 89 f0             	mov    r8d,r14d
    705958811390:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    705958811395:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595881139c:	0f 84 5d f9 ff ff    	je     0x705958810cff
    7059588113a2:	e9 6e ec fe 17       	jmp    0x705970800015
    7059588113a7:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    7059588113ac:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    7059588113b1:	89 07                	mov    DWORD PTR [rdi],eax
    7059588113b3:	48 8b 44 24 18       	mov    rax,QWORD PTR [rsp+0x18]
    7059588113b8:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    7059588113bb:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x2000
    7059588113c2:	20 00 00 
    7059588113c5:	c7 87 a4 00 00 00 fa 	mov    DWORD PTR [rdi+0xa4],0x103fa
    7059588113cc:	03 01 00 
    7059588113cf:	c7 87 bc 00 00 00 e6 	mov    DWORD PTR [rdi+0xbc],0x103e6
    7059588113d6:	03 01 00 
    7059588113d9:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    7059588113dd:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    7059588113e3:	44 89 b7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r14d
    7059588113ea:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    7059588113f1:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    7059588113f8:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    7059588113fb:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    705958811401:	89 87 fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],eax
    705958811407:	44 89 87 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r8d
    70595881140e:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    705958811415:	00 00 00 
    705958811418:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    70595881141f:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    705958811426:	00 00 00 
    705958811429:	89 af 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ebp
    70595881142f:	be e2 03 01 00       	mov    esi,0x103e2
    705958811434:	ba e2 03 01 00       	mov    edx,0x103e2
    705958811439:	49 89 fd             	mov    r13,rdi
    70595881143c:	48 b8 20 6d 8c 23 5a 	movabs rax,0x635a238c6d20
    705958811443:	63 00 00 
    705958811446:	ff d0                	call   rax
    705958811448:	e9 4b fd ff ff       	jmp    0x705958811198
