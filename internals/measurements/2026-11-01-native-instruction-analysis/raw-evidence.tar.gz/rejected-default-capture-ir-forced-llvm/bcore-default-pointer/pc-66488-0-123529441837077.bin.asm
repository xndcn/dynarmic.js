
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66488-0-123529441837077.bin:     file format binary


Disassembly of section .data:

0000705970800015 <.data>:
    705970800015:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    70597080001a:	0f b6 90 28 01 00 00 	movzx  edx,BYTE PTR [rax+0x128]
    705970800021:	e9 7a 11 01 e8       	jmp    0x7059588111a0
    705970800026:	41 89 ed             	mov    r13d,ebp
    705970800029:	e9 4e 0e 01 e8       	jmp    0x705958810e7c
    70597080002e:	4c 8b 6c 24 18       	mov    r13,QWORD PTR [rsp+0x18]
    705970800033:	44 8b 4c 24 30       	mov    r9d,DWORD PTR [rsp+0x30]
    705970800038:	e9 90 0f 01 e8       	jmp    0x705958810fcd
