; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000103e6(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %chain_self, %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66534
  %6 = icmp ugt i32 %5, 40
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb61 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb61, 66554
  %11 = getelementptr i8, ptr %cpu, i64 148
  %guard_lt = load i32, ptr %11, align 4
  %12 = icmp eq i32 %guard_lt, 66534
  %13 = and i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000103e6_entry, label %lb_guard_miss, !prof !0

insn_0x000103e6_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table83 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table83, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 24
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000103e6_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 6, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000103e6_entry, %28
  br label %insn_0x000103e6

insn_0x000103e6:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 8
  %a = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 24
  %b = load i32, ptr %31, align 4
  %mul = mul i32 %a, %b
  %32 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mul, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %34, align 4
  br label %insn_0x000103e8_entry

insn_0x000103e8_entry:                            ; preds = %insn_0x000103e6
  br label %insn_0x000103e8

insn_0x000103e8:                                  ; preds = %insn_0x000103e8_entry
  %35 = getelementptr i8, ptr %cpu, i32 28
  %rt = load i32, ptr %35, align 4
  %add32 = add i32 %mul, %rt
  %36 = getelementptr i8, ptr %cpu, i32 8
  store i32 %add32, ptr %36, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %37 = xor i32 %flgo, %flgn
  %38 = xor i32 %flgs, %flgn
  %39 = and i32 %38, %37
  %40 = xor i32 %mul, -1
  %41 = icmp ult i32 %40, %rt
  %ac0 = zext i1 %41 to i32
  %42 = icmp eq i32 %add32, 0
  %az = zext i1 %42 to i32
  %an = lshr i32 %add32, 31
  %43 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %45, align 4
  %46 = or i32 %vs_cur, %39
  %47 = getelementptr i8, ptr %cpu, i32 248
  store i32 %39, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 252
  store i32 %39, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 256
  store i32 %46, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %51, align 4
  br label %insn_0x000103ea_entry

insn_0x000103ea_entry:                            ; preds = %insn_0x000103e8
  br label %insn_0x000103ea

insn_0x000103ea:                                  ; preds = %insn_0x000103ea_entry
  %lsr32 = lshr i32 %add32, 8
  %52 = getelementptr i8, ptr %cpu, i32 0
  store i32 %lsr32, ptr %52, align 4
  %53 = icmp eq i32 %lsr32, 0
  %az1 = zext i1 %53 to i32
  %an2 = lshr i32 %lsr32, 31
  %54 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %57, align 4
  br label %insn_0x000103ee_entry

insn_0x000103ee_entry:                            ; preds = %insn_0x000103ea
  br label %insn_0x000103ee

insn_0x000103ee:                                  ; preds = %insn_0x000103ee_entry
  %58 = getelementptr i8, ptr %cpu, i32 12
  %rt3 = load i32, ptr %58, align 4
  %and32 = and i32 %rt3, %lsr32
  %59 = getelementptr i8, ptr %cpu, i32 0
  store i32 %and32, ptr %59, align 4
  %60 = icmp eq i32 %and32, 0
  %az4 = zext i1 %60 to i32
  %an5 = lshr i32 %and32, 31
  %61 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az4, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an5, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %66, align 4
  br label %insn_0x000103f0_entry

insn_0x000103f0_entry:                            ; preds = %insn_0x000103ee
  br label %insn_0x000103f0

insn_0x000103f0:                                  ; preds = %insn_0x000103f0_entry
  %67 = getelementptr i8, ptr %cpu, i32 36
  store i32 %and32, ptr %67, align 4
  br label %insn_0x000103f2_entry

insn_0x000103f2_entry:                            ; preds = %insn_0x000103f0
  br label %insn_0x000103f2

insn_0x000103f2:                                  ; preds = %insn_0x000103f2_entry
  %68 = getelementptr i8, ptr %cpu, i32 80
  %i_addr = load i32, ptr %68, align 4
  %69 = and i32 %i_addr, 3
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000103f2
  %71 = getelementptr i8, ptr %cpu, i32 188
  store i32 66546, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %73, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66546, i32 %i_addr, i32 0)
  %74 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %74, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000103f2
  %75 = lshr i32 %i_addr, 12
  %page_index = zext i32 %75 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %76 = and i32 %i_addr, 4095
  %page_offset = zext i32 %76 to i64
  %77 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %77, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %78 = getelementptr i8, ptr %cpu, i32 188
  store i32 66546, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %80, align 4
  %81 = call i32 @mem_read32(ptr %mem, i32 %i_addr)
  %82 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %82, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %81, %did_jump_cont ]
  %83 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i32 128
  %lreg = load i32, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 112
  %breg = load i32, ptr %85, align 4
  %i64 = zext i32 %i_addr to i64
  %l64 = zext i32 %lreg to i64
  %b64 = zext i32 %breg to i64
  %IM = add i64 %i64, 4
  %im32 = trunc i64 %IM to i32
  %LB = add i64 %l64, %b64
  %lb32 = trunc i64 %LB to i32
  %IML_pos = sub i64 %IM, %l64
  %iml32_pos = trunc i64 %IML_pos to i32
  %IM_car = and i64 %IM, 4294967296
  %LB_car = and i64 %LB, 4294967296
  %same_carry = icmp eq i64 %IM_car, %LB_car
  %cmp_pos = icmp ult i32 %im32, %lb32
  %pos_same = select i1 %cmp_pos, i32 %im32, i32 %iml32_pos
  %pos_diff = select i1 %cmp_pos, i32 %iml32_pos, i32 %im32
  %pos_res = select i1 %same_carry, i32 %pos_same, i32 %pos_diff
  %IML_neg = add i64 %IM, %l64
  %iml32_neg = trunc i64 %IML_neg to i32
  %i_msb_v = and i64 %i64, 2147483648
  %i_msb = icmp ne i64 %i_msb_v, 0
  %im_car_v = and i64 %IM, 4294967296
  %im_carry = icmp ne i64 %im_car_v, 0
  %flag_neg = or i1 %i_msb, %im_carry
  %cmp_neg = icmp ult i32 %im32, %breg
  %neg_flag = select i1 %cmp_neg, i32 %iml32_neg, i32 %im32
  %neg_noflag = select i1 %cmp_neg, i32 %im32, i32 %iml32_neg
  %neg_res = select i1 %flag_neg, i32 %neg_flag, i32 %neg_noflag
  %dag_result = select i1 false, i32 %neg_res, i32 %pos_res
  %86 = getelementptr i8, ptr %cpu, i32 80
  store i32 %dag_result, ptr %86, align 4
  br label %insn_0x000103f4_entry

did_jump_exit:                                    ; preds = %page_slow
  %87 = getelementptr i8, ptr %cpu, i64 188
  %next_pc62 = load i32, ptr %87, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x000103f4_entry:                            ; preds = %page_done
  br label %insn_0x000103f4

insn_0x000103f4:                                  ; preds = %insn_0x000103f4_entry
  %88 = shl i32 %and32, 2
  %89 = getelementptr i8, ptr %cpu, i32 32
  %ps = load i32, ptr %89, align 4
  %plshift2 = add i32 %ps, %88
  %90 = getelementptr i8, ptr %cpu, i32 36
  store i32 %plshift2, ptr %90, align 4
  br label %insn_0x000103f6_entry

insn_0x000103f6_entry:                            ; preds = %insn_0x000103f4
  br label %insn_0x000103f6

insn_0x000103f6:                                  ; preds = %insn_0x000103f6_entry
  %91 = and i32 %plshift2, 3
  %92 = icmp ne i32 %91, 0
  br i1 %92, label %data_misaligned6, label %data_aligned7, !prof !1

data_misaligned6:                                 ; preds = %insn_0x000103f6
  %93 = getelementptr i8, ptr %cpu, i32 188
  store i32 66550, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %95, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66550, i32 %plshift2, i32 0)
  %96 = getelementptr i8, ptr %cpu, i64 188
  %next_pc63 = load i32, ptr %96, align 4
  br label %chain_exit

data_aligned7:                                    ; preds = %insn_0x000103f6
  %97 = lshr i32 %plshift2, 12
  %page_index11 = zext i32 %97 to i64
  %page_slot12 = getelementptr ptr, ptr %page_table, i64 %page_index11
  %page13 = load ptr, ptr %page_slot12, align 8
  %page_mapped14 = icmp ne ptr %page13, null
  br i1 %page_mapped14, label %page_fast8, label %page_slow9, !prof !0

page_fast8:                                       ; preds = %data_aligned7
  %98 = and i32 %plshift2, 4095
  %page_offset15 = zext i32 %98 to i64
  %99 = getelementptr i8, ptr %page13, i64 %page_offset15
  %page_val16 = load i32, ptr %99, align 4
  br label %page_done10

page_slow9:                                       ; preds = %data_aligned7
  %100 = getelementptr i8, ptr %cpu, i32 188
  store i32 66550, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %102, align 4
  %103 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %104 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %104, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

page_done10:                                      ; preds = %did_jump_cont18, %page_fast8
  %mem_val21 = phi i32 [ %page_val16, %page_fast8 ], [ %103, %did_jump_cont18 ]
  %105 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val21, ptr %105, align 4
  br label %insn_0x000103f8_entry

did_jump_exit17:                                  ; preds = %page_slow9
  %106 = getelementptr i8, ptr %cpu, i64 188
  %next_pc64 = load i32, ptr %106, align 4
  br label %chain_exit

did_jump_cont18:                                  ; preds = %page_slow9
  br label %page_done10

insn_0x000103f8_entry:                            ; preds = %page_done10
  br label %insn_0x000103f8

insn_0x000103f8:                                  ; preds = %insn_0x000103f8_entry
  %107 = getelementptr i8, ptr %cpu, i32 44
  %ptr = load i32, ptr %107, align 4
  %108 = and i32 %ptr, 3
  %109 = icmp ne i32 %108, 0
  br i1 %109, label %data_misaligned22, label %data_aligned23, !prof !1

data_misaligned22:                                ; preds = %insn_0x000103f8
  %110 = getelementptr i8, ptr %cpu, i32 188
  store i32 66552, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %112, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66552, i32 %ptr, i32 65536)
  %113 = getelementptr i8, ptr %cpu, i64 188
  %next_pc65 = load i32, ptr %113, align 4
  br label %chain_exit

data_aligned23:                                   ; preds = %insn_0x000103f8
  %114 = lshr i32 %ptr, 12
  %page_index24 = zext i32 %114 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned23
  %115 = and i32 %ptr, 4095
  %page_offset28 = zext i32 %115 to i64
  %116 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %mem_val21, ptr %116, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned23
  %117 = getelementptr i8, ptr %cpu, i32 188
  store i32 66552, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %119, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %mem_val21)
  %120 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %120, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont30, %page_wr_fast
  %ptr_inc = add i32 %ptr, 4
  %121 = getelementptr i8, ptr %cpu, i32 44
  store i32 %ptr_inc, ptr %121, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %122 = icmp ne i8 %cec_pending, 0
  br i1 %122, label %cec_check, label %cec_checked, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow
  %123 = getelementptr i8, ptr %cpu, i64 188
  %next_pc66 = load i32, ptr %123, align 4
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %124 = getelementptr i8, ptr %cpu, i32 188
  store i32 66554, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %126, align 4
  call void @cec_check_pending(ptr %cpu)
  %127 = getelementptr i8, ptr %cpu, i32 296
  %dj35 = load i8, ptr %127, align 1
  %dj_set36 = icmp ne i8 %dj35, 0
  br i1 %dj_set36, label %did_jump_exit33, label %did_jump_cont34, !prof !1

cec_checked:                                      ; preds = %did_jump_cont34, %page_wr_done
  br label %insn_0x000103fa_entry

did_jump_exit33:                                  ; preds = %cec_check
  %128 = getelementptr i8, ptr %cpu, i64 188
  %next_pc67 = load i32, ptr %128, align 4
  br label %chain_exit

did_jump_cont34:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x000103fa_entry:                            ; preds = %cec_checked
  br label %insn_0x000103fa

insn_0x000103fa:                                  ; preds = %insn_0x000103fa_entry
  %129 = and i32 %plshift2, 3
  %130 = icmp ne i32 %129, 0
  br i1 %130, label %data_misaligned37, label %data_aligned38, !prof !1

data_misaligned37:                                ; preds = %insn_0x000103fa
  %131 = getelementptr i8, ptr %cpu, i32 188
  store i32 66554, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i32 308
  store i32 10, ptr %133, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66554, i32 %plshift2, i32 65536)
  %134 = getelementptr i8, ptr %cpu, i64 188
  %next_pc68 = load i32, ptr %134, align 4
  br label %chain_exit

data_aligned38:                                   ; preds = %insn_0x000103fa
  %135 = lshr i32 %plshift2, 12
  %page_index42 = zext i32 %135 to i64
  %page_slot43 = getelementptr ptr, ptr %page_table, i64 %page_index42
  %page44 = load ptr, ptr %page_slot43, align 8
  %page_mapped45 = icmp ne ptr %page44, null
  br i1 %page_mapped45, label %page_wr_fast39, label %page_wr_slow40, !prof !0

page_wr_fast39:                                   ; preds = %data_aligned38
  %136 = and i32 %plshift2, 4095
  %page_offset46 = zext i32 %136 to i64
  %137 = getelementptr i8, ptr %page44, i64 %page_offset46
  store i32 %mem_val, ptr %137, align 4
  br label %page_wr_done41

page_wr_slow40:                                   ; preds = %data_aligned38
  %138 = getelementptr i8, ptr %cpu, i32 188
  store i32 66554, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 10, ptr %140, align 4
  call void @mem_write32(ptr %mem, i32 %plshift2, i32 %mem_val)
  %141 = getelementptr i8, ptr %cpu, i32 296
  %dj49 = load i8, ptr %141, align 1
  %dj_set50 = icmp ne i8 %dj49, 0
  br i1 %dj_set50, label %did_jump_exit47, label %did_jump_cont48, !prof !1

page_wr_done41:                                   ; preds = %did_jump_cont48, %page_wr_fast39
  %142 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %142, align 4
  %143 = icmp ugt i32 %lc1, 1
  br i1 %143, label %hwloop_back, label %hwloop_end, !prof !2

did_jump_exit47:                                  ; preds = %page_wr_slow40
  %144 = getelementptr i8, ptr %cpu, i64 188
  %next_pc69 = load i32, ptr %144, align 4
  br label %chain_exit

did_jump_cont48:                                  ; preds = %page_wr_slow40
  br label %page_wr_done41

hwloop_done:                                      ; preds = %did_jump_cont58
  br label %insn_0x000103fc_entry

hwloop_back:                                      ; preds = %page_wr_done41
  %145 = getelementptr i8, ptr %cpu, i32 156
  %146 = sub i32 %lc1, 1
  store i32 %146, ptr %145, align 4
  %147 = getelementptr i8, ptr %cpu, i32 188
  store i32 66534, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i32 296
  store i8 1, ptr %148, align 1
  %cec_pending51 = load i8, ptr %cec_pending_flag, align 1
  %149 = icmp ne i8 %cec_pending51, 0
  br i1 %149, label %cec_check52, label %cec_checked53, !prof !1

hwloop_end:                                       ; preds = %page_wr_done41
  %150 = getelementptr i8, ptr %cpu, i32 156
  store i32 0, ptr %150, align 4
  %cec_pending54 = load i8, ptr %cec_pending_flag, align 1
  %151 = icmp ne i8 %cec_pending54, 0
  br i1 %151, label %cec_check55, label %cec_checked56, !prof !1

cec_check52:                                      ; preds = %hwloop_back
  %152 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 308
  store i32 10, ptr %153, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked53

cec_checked53:                                    ; preds = %cec_check52, %hwloop_back
  %154 = getelementptr i8, ptr %cpu, i64 188
  %next_pc70 = load i32, ptr %154, align 4
  br label %chain_exit

cec_check55:                                      ; preds = %hwloop_end
  %155 = getelementptr i8, ptr %cpu, i32 188
  store i32 66556, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 308
  store i32 10, ptr %157, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked56

cec_checked56:                                    ; preds = %cec_check55, %hwloop_end
  %158 = getelementptr i8, ptr %cpu, i32 296
  %dj59 = load i8, ptr %158, align 1
  %dj_set60 = icmp ne i8 %dj59, 0
  br i1 %dj_set60, label %did_jump_exit57, label %did_jump_cont58, !prof !1

did_jump_exit57:                                  ; preds = %cec_checked56
  %159 = getelementptr i8, ptr %cpu, i64 188
  %next_pc71 = load i32, ptr %159, align 4
  br label %chain_exit

did_jump_cont58:                                  ; preds = %cec_checked56
  br label %hwloop_done

insn_0x000103fc_entry:                            ; preds = %hwloop_done
  br label %insn_0x000103fc

insn_0x000103fc:                                  ; preds = %insn_0x000103fc_entry
  %lo_kept = and i32 %ptr_inc, 65535
  %with_hi = or i32 %lo_kept, 65536
  %160 = getelementptr i8, ptr %cpu, i32 44
  store i32 %with_hi, ptr %160, align 4
  br label %insn_0x00010400_entry

insn_0x00010400_entry:                            ; preds = %insn_0x000103fc
  br label %insn_0x00010400

insn_0x00010400:                                  ; preds = %insn_0x00010400_entry
  %161 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %161, align 4
  br label %insn_0x00010402_entry

insn_0x00010402_entry:                            ; preds = %insn_0x00010400
  br label %insn_0x00010402

insn_0x00010402:                                  ; preds = %insn_0x00010402_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4860
  %162 = getelementptr i8, ptr %cpu, i32 44
  store i32 %with_lo, ptr %162, align 4
  br label %insn_0x00010406_entry

insn_0x00010406_entry:                            ; preds = %insn_0x00010402
  br label %insn_0x00010406

insn_0x00010406:                                  ; preds = %insn_0x00010406_entry
  %163 = getelementptr i8, ptr %cpu, i32 8
  store i32 8191, ptr %163, align 4
  br label %insn_0x0001040a_entry

insn_0x0001040a_entry:                            ; preds = %insn_0x00010406
  br label %insn_0x0001040a

insn_0x0001040a:                                  ; preds = %insn_0x0001040a_entry
  %164 = getelementptr i8, ptr %cpu, i32 40
  store i32 8192, ptr %164, align 4
  br label %insn_0x0001040e_entry

insn_0x0001040e_entry:                            ; preds = %insn_0x0001040a
  br label %insn_0x0001040e

insn_0x0001040e:                                  ; preds = %insn_0x0001040e_entry
  %165 = getelementptr i8, ptr %cpu, i32 148
  store i32 66578, ptr %165, align 4
  %166 = getelementptr i8, ptr %cpu, i32 164
  store i32 66592, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i32 156
  store i32 8192, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 296
  %169 = getelementptr i8, ptr %cpu, i32 188
  store i32 66578, ptr %169, align 4
  store i8 1, ptr %168, align 1
  %at_lb0 = icmp eq i32 %lb0, 66574
  %at_lb = or i1 %at_lb0, false
  br i1 %at_lb, label %hwloop_count, label %hwloop_counted, !prof !1

hwloop_count:                                     ; preds = %insn_0x0001040e
  %170 = getelementptr i8, ptr %cpu, i32 188
  store i32 66578, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %172, align 4
  call void @bfin_hwloop_step(ptr %cpu, i32 66574, i32 66574)
  br label %hwloop_counted

hwloop_counted:                                   ; preds = %hwloop_count, %insn_0x0001040e
  %173 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %173, align 4
  %chain_total = add nuw i32 %chain_packets, 16
  %174 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %174 monotonic, align 4, !range !3
  %175 = icmp ult i32 %chain_total, %chain_budget
  br i1 %175, label %chain_go, label %chain_leave72, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %176 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %176, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %hwloop_counted
  %chain_slot = getelementptr i8, ptr %chain_table, i64 532624
  %177 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %177, align 4
  %178 = icmp eq i32 %slot_pc, 66578
  br i1 %178, label %chain_hit, label %chain_leave72, !prof !0

chain_leave72:                                    ; preds = %chain_go, %hwloop_counted
  %179 = getelementptr i8, ptr %cpu, i64 188
  store i32 66578, ptr %179, align 4
  %180 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %180, align 4
  %181 = getelementptr i8, ptr %cpu, i64 308
  store i32 16, ptr %181, align 4
  br label %return

chain_hit:                                        ; preds = %chain_go
  %182 = getelementptr i8, ptr %cpu, i64 188
  store i32 66578, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %184, align 1
  %185 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %185, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit57, %cec_checked53, %did_jump_exit47, %data_misaligned37, %did_jump_exit33, %did_jump_exit29, %data_misaligned22, %did_jump_exit17, %data_misaligned6, %did_jump_exit, %data_misaligned
  %next_pc73 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc62, %did_jump_exit ], [ %next_pc63, %data_misaligned6 ], [ %next_pc64, %did_jump_exit17 ], [ %next_pc65, %data_misaligned22 ], [ %next_pc66, %did_jump_exit29 ], [ %next_pc67, %did_jump_exit33 ], [ %next_pc68, %data_misaligned37 ], [ %next_pc69, %did_jump_exit47 ], [ %next_pc70, %cec_checked53 ], [ %next_pc71, %did_jump_exit57 ]
  %packets = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 8, %data_misaligned6 ], [ 8, %did_jump_exit17 ], [ 9, %data_misaligned22 ], [ 9, %did_jump_exit29 ], [ 9, %did_jump_exit33 ], [ 10, %data_misaligned37 ], [ 10, %did_jump_exit47 ], [ 10, %cec_checked53 ], [ 10, %did_jump_exit57 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned6 ], [ 2, %did_jump_exit17 ], [ 2, %data_misaligned22 ], [ 2, %did_jump_exit29 ], [ 2, %did_jump_exit33 ], [ 2, %data_misaligned37 ], [ 2, %did_jump_exit47 ], [ 2, %cec_checked53 ], [ 2, %did_jump_exit57 ]
  %tail74 = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 8, %data_misaligned6 ], [ 8, %did_jump_exit17 ], [ 9, %data_misaligned22 ], [ 9, %did_jump_exit29 ], [ 9, %did_jump_exit33 ], [ 10, %data_misaligned37 ], [ 10, %did_jump_exit47 ], [ 10, %cec_checked53 ], [ 10, %did_jump_exit57 ]
  %186 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets76 = load i32, ptr %186, align 4
  %chain_total77 = add nuw i32 %chain_packets76, %packets
  %187 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget78 = load atomic i32, ptr %187 monotonic, align 4, !range !3
  %188 = icmp ult i32 %chain_total77, %chain_budget78
  br i1 %188, label %chain_lookup, label %chain_leave75, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %189 = icmp eq i32 %next_pc73, 66534
  br i1 %189, label %chain_self, label %chain_other, !prof !2

chain_leave75:                                    ; preds = %chain_other, %chain_exit
  %190 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail74, ptr %191, align 4
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %192 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total77, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %193, align 1
  br label %lb_guard

chain_other:                                      ; preds = %chain_lookup
  %194 = lshr i32 %next_pc73, 1
  %195 = and i32 %194, 65535
  %196 = zext i32 %195 to i64
  %197 = mul i64 %196, 16
  %chain_slot79 = getelementptr i8, ptr %chain_table, i64 %197
  %198 = getelementptr i8, ptr %chain_slot79, i64 0
  %slot_pc80 = load i32, ptr %198, align 4
  %199 = icmp eq i32 %slot_pc80, %next_pc73
  br i1 %199, label %chain_hit81, label %chain_leave75, !prof !0

chain_hit81:                                      ; preds = %chain_other
  %200 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total77, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %201, align 1
  %202 = getelementptr i8, ptr %chain_slot79, i64 8
  %chain_fn82 = load ptr, ptr %202, align 8
  musttail call swifttailcc void %chain_fn82(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave75, %chain_leave72, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @bfin_hwloop_step(ptr, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{!"branch_weights", i32 63, i32 1}
!3 = !{i32 0, i32 -2147483648}
