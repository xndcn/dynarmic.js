; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010428(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66600
  %6 = icmp ugt i32 %5, 24
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb64 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb64, 66592
  %11 = sub i32 %guard_lb64, 66600
  %12 = icmp ugt i32 %11, 24
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010428_entry, label %lb_guard_miss, !prof !0

insn_0x00010428_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table89 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table89, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 40
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010428_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 10, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010428_entry, %28
  br label %insn_0x00010428

insn_0x00010428:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %30, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %31 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %33, align 4
  br label %insn_0x0001042c_entry

insn_0x0001042c_entry:                            ; preds = %insn_0x00010428
  br label %insn_0x0001042c

insn_0x0001042c:                                  ; preds = %insn_0x0001042c_entry
  %34 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %36, align 4
  %sp1 = sub i32 %sp, 4
  %37 = and i32 %sp1, 3
  %38 = icmp ne i32 %37, 0
  br i1 %38, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001042c
  %39 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %41, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66604, i32 %sp1, i32 65536)
  %42 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 188
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %cpu, i64 296
  %46 = load i8, ptr %45, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001042c
  %47 = lshr i32 %sp1, 12
  %page_index = zext i32 %47 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %48 = and i32 %sp1, 4095
  %page_offset = zext i32 %48 to i64
  %49 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %49, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %50 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %52, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %53 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %53, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp2 = sub i32 %sp1, 4
  %54 = and i32 %sp2, 3
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %data_misaligned1, label %data_aligned2, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %56 = getelementptr i8, ptr %cpu, i64 188
  %next_pc65 = load i32, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 188
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %cpu, i64 296
  %60 = load i8, ptr %59, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned1:                                 ; preds = %page_wr_done
  %61 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %63, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66604, i32 %sp2, i32 65536)
  %64 = getelementptr i8, ptr %cpu, i64 188
  %next_pc66 = load i32, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 188
  %66 = load i32, ptr %65, align 4
  %67 = getelementptr i8, ptr %cpu, i64 296
  %68 = load i8, ptr %67, align 1
  br label %chain_exit

data_aligned2:                                    ; preds = %page_wr_done
  %69 = lshr i32 %sp2, 12
  %page_index6 = zext i32 %69 to i64
  %page_slot7 = getelementptr ptr, ptr %page_table, i64 %page_index6
  %page8 = load ptr, ptr %page_slot7, align 8
  %page_mapped9 = icmp ne ptr %page8, null
  br i1 %page_mapped9, label %page_wr_fast3, label %page_wr_slow4, !prof !0

page_wr_fast3:                                    ; preds = %data_aligned2
  %70 = and i32 %sp2, 4095
  %page_offset10 = zext i32 %70 to i64
  %71 = getelementptr i8, ptr %page8, i64 %page_offset10
  store i32 %fp, ptr %71, align 4
  br label %page_wr_done5

page_wr_slow4:                                    ; preds = %data_aligned2
  %72 = getelementptr i8, ptr %cpu, i32 188
  store i32 66604, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %74, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %75 = getelementptr i8, ptr %cpu, i32 296
  %dj13 = load i8, ptr %75, align 1
  %dj_set14 = icmp ne i8 %dj13, 0
  br i1 %dj_set14, label %did_jump_exit11, label %did_jump_cont12, !prof !1

page_wr_done5:                                    ; preds = %did_jump_cont12, %page_wr_fast3
  %76 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %76, align 4
  %sp3 = sub i32 %sp2, 0
  %77 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %77, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %78 = icmp ne i8 %cec_pending, 0
  br i1 %78, label %cec_check, label %cec_checked, !prof !1

did_jump_exit11:                                  ; preds = %page_wr_slow4
  %79 = getelementptr i8, ptr %cpu, i64 188
  %next_pc67 = load i32, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 188
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr i8, ptr %cpu, i64 296
  %83 = load i8, ptr %82, align 1
  br label %chain_exit

did_jump_cont12:                                  ; preds = %page_wr_slow4
  br label %page_wr_done5

cec_check:                                        ; preds = %page_wr_done5
  %84 = getelementptr i8, ptr %cpu, i32 188
  store i32 66608, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %86, align 4
  call void @cec_check_pending(ptr %cpu)
  %87 = getelementptr i8, ptr %cpu, i32 296
  %dj17 = load i8, ptr %87, align 1
  %dj_set18 = icmp ne i8 %dj17, 0
  br i1 %dj_set18, label %did_jump_exit15, label %did_jump_cont16, !prof !1

cec_checked:                                      ; preds = %did_jump_cont16, %page_wr_done5
  br label %insn_0x00010430_entry

did_jump_exit15:                                  ; preds = %cec_check
  %88 = getelementptr i8, ptr %cpu, i64 188
  %next_pc68 = load i32, ptr %88, align 4
  %89 = getelementptr i8, ptr %cpu, i64 188
  %90 = load i32, ptr %89, align 4
  %91 = getelementptr i8, ptr %cpu, i64 296
  %92 = load i8, ptr %91, align 1
  br label %chain_exit

did_jump_cont16:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010430_entry:                            ; preds = %cec_checked
  br label %insn_0x00010430

insn_0x00010430:                                  ; preds = %insn_0x00010430_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4848
  %93 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %93, align 4
  br label %insn_0x00010434_entry

insn_0x00010434_entry:                            ; preds = %insn_0x00010430
  br label %insn_0x00010434

insn_0x00010434:                                  ; preds = %insn_0x00010434_entry
  %94 = and i32 %with_lo, 3
  %95 = icmp ne i32 %94, 0
  br i1 %95, label %data_misaligned19, label %data_aligned20, !prof !1

data_misaligned19:                                ; preds = %insn_0x00010434
  %96 = getelementptr i8, ptr %cpu, i32 188
  store i32 66612, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %98, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66612, i32 %with_lo, i32 0)
  %99 = getelementptr i8, ptr %cpu, i64 188
  %next_pc69 = load i32, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 188
  %101 = load i32, ptr %100, align 4
  %102 = getelementptr i8, ptr %cpu, i64 296
  %103 = load i8, ptr %102, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %insn_0x00010434
  %104 = lshr i32 %with_lo, 12
  %page_index21 = zext i32 %104 to i64
  %page_slot22 = getelementptr ptr, ptr %page_table, i64 %page_index21
  %page23 = load ptr, ptr %page_slot22, align 8
  %page_mapped24 = icmp ne ptr %page23, null
  br i1 %page_mapped24, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned20
  %105 = and i32 %with_lo, 4095
  %page_offset25 = zext i32 %105 to i64
  %106 = getelementptr i8, ptr %page23, i64 %page_offset25
  %page_val = load i32, ptr %106, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned20
  %107 = getelementptr i8, ptr %cpu, i32 188
  store i32 66612, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %109, align 4
  %110 = call i32 @mem_read32(ptr %mem, i32 %with_lo)
  %111 = getelementptr i8, ptr %cpu, i32 296
  %dj28 = load i8, ptr %111, align 1
  %dj_set29 = icmp ne i8 %dj28, 0
  br i1 %dj_set29, label %did_jump_exit26, label %did_jump_cont27, !prof !1

page_done:                                        ; preds = %did_jump_cont27, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %110, %did_jump_cont27 ]
  %112 = getelementptr i8, ptr %cpu, i32 40
  store i32 %mem_val, ptr %112, align 4
  br label %insn_0x00010436_entry

did_jump_exit26:                                  ; preds = %page_slow
  %113 = getelementptr i8, ptr %cpu, i64 188
  %next_pc70 = load i32, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 188
  %115 = load i32, ptr %114, align 4
  %116 = getelementptr i8, ptr %cpu, i64 296
  %117 = load i8, ptr %116, align 1
  br label %chain_exit

did_jump_cont27:                                  ; preds = %page_slow
  br label %page_done

insn_0x00010436_entry:                            ; preds = %page_done
  br label %insn_0x00010436

insn_0x00010436:                                  ; preds = %insn_0x00010436_entry
  %118 = icmp ule i32 %mem_val, 4
  %cc = zext i1 %118 to i32
  %119 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %119, align 4
  br label %insn_0x00010438_entry

insn_0x00010438_entry:                            ; preds = %insn_0x00010436
  br label %insn_0x00010438

insn_0x00010438:                                  ; preds = %insn_0x00010438_entry
  %cc_true = icmp ne i32 %cc, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x00010438
  %120 = getelementptr i8, ptr %cpu, i32 188
  store i32 66626, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %121, align 4
  %chain_total = add nuw i32 %chain_packets, 6
  %122 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %122 monotonic, align 4, !range !2
  %123 = icmp ult i32 %chain_total, %chain_budget
  br i1 %123, label %chain_go, label %chain_leave71, !prof !0

brt_fallthru:                                     ; preds = %insn_0x00010438
  br label %insn_0x0001043a_entry

insn_0x0001043a_entry:                            ; preds = %brt_fallthru
  br label %insn_0x0001043a

insn_0x0001043a:                                  ; preds = %insn_0x0001043a_entry
  %124 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %124, align 4
  br label %insn_0x0001043c_entry

insn_0x0001043c_entry:                            ; preds = %insn_0x0001043a
  br label %insn_0x0001043c

insn_0x0001043c:                                  ; preds = %insn_0x0001043c_entry
  %125 = and i32 %sp2, 3
  %126 = icmp ne i32 %125, 0
  br i1 %126, label %data_misaligned30, label %data_aligned31, !prof !1

data_misaligned30:                                ; preds = %insn_0x0001043c
  %127 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %129, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66620, i32 %sp2, i32 0)
  %130 = getelementptr i8, ptr %cpu, i64 188
  %next_pc72 = load i32, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 188
  %132 = load i32, ptr %131, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  %134 = load i8, ptr %133, align 1
  br label %chain_exit

data_aligned31:                                   ; preds = %insn_0x0001043c
  %135 = lshr i32 %sp2, 12
  %page_index35 = zext i32 %135 to i64
  %page_slot36 = getelementptr ptr, ptr %page_table, i64 %page_index35
  %page37 = load ptr, ptr %page_slot36, align 8
  %page_mapped38 = icmp ne ptr %page37, null
  br i1 %page_mapped38, label %page_fast32, label %page_slow33, !prof !0

page_fast32:                                      ; preds = %data_aligned31
  %136 = and i32 %sp2, 4095
  %page_offset39 = zext i32 %136 to i64
  %137 = getelementptr i8, ptr %page37, i64 %page_offset39
  %page_val40 = load i32, ptr %137, align 4
  br label %page_done34

page_slow33:                                      ; preds = %data_aligned31
  %138 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %140, align 4
  %141 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %142 = getelementptr i8, ptr %cpu, i32 296
  %dj43 = load i8, ptr %142, align 1
  %dj_set44 = icmp ne i8 %dj43, 0
  br i1 %dj_set44, label %did_jump_exit41, label %did_jump_cont42, !prof !1

page_done34:                                      ; preds = %did_jump_cont42, %page_fast32
  %mem_val45 = phi i32 [ %page_val40, %page_fast32 ], [ %141, %did_jump_cont42 ]
  %sp146 = add i32 %sp2, 4
  %143 = and i32 %sp146, 3
  %144 = icmp ne i32 %143, 0
  br i1 %144, label %data_misaligned47, label %data_aligned48, !prof !1

did_jump_exit41:                                  ; preds = %page_slow33
  %145 = getelementptr i8, ptr %cpu, i64 188
  %next_pc73 = load i32, ptr %145, align 4
  %146 = getelementptr i8, ptr %cpu, i64 188
  %147 = load i32, ptr %146, align 4
  %148 = getelementptr i8, ptr %cpu, i64 296
  %149 = load i8, ptr %148, align 1
  br label %chain_exit

did_jump_cont42:                                  ; preds = %page_slow33
  br label %page_done34

data_misaligned47:                                ; preds = %page_done34
  %150 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %152, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66620, i32 %sp146, i32 0)
  %153 = getelementptr i8, ptr %cpu, i64 188
  %next_pc74 = load i32, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i64 188
  %155 = load i32, ptr %154, align 4
  %156 = getelementptr i8, ptr %cpu, i64 296
  %157 = load i8, ptr %156, align 1
  br label %chain_exit

data_aligned48:                                   ; preds = %page_done34
  %158 = lshr i32 %sp146, 12
  %page_index52 = zext i32 %158 to i64
  %page_slot53 = getelementptr ptr, ptr %page_table, i64 %page_index52
  %page54 = load ptr, ptr %page_slot53, align 8
  %page_mapped55 = icmp ne ptr %page54, null
  br i1 %page_mapped55, label %page_fast49, label %page_slow50, !prof !0

page_fast49:                                      ; preds = %data_aligned48
  %159 = and i32 %sp146, 4095
  %page_offset56 = zext i32 %159 to i64
  %160 = getelementptr i8, ptr %page54, i64 %page_offset56
  %page_val57 = load i32, ptr %160, align 4
  br label %page_done51

page_slow50:                                      ; preds = %data_aligned48
  %161 = getelementptr i8, ptr %cpu, i32 188
  store i32 66620, ptr %161, align 4
  %162 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %163, align 4
  %164 = call i32 @mem_read32(ptr %mem, i32 %sp146)
  %165 = getelementptr i8, ptr %cpu, i32 296
  %dj60 = load i8, ptr %165, align 1
  %dj_set61 = icmp ne i8 %dj60, 0
  br i1 %dj_set61, label %did_jump_exit58, label %did_jump_cont59, !prof !1

page_done51:                                      ; preds = %did_jump_cont59, %page_fast49
  %mem_val62 = phi i32 [ %page_val57, %page_fast49 ], [ %164, %did_jump_cont59 ]
  %sp263 = add i32 %sp146, 4
  %166 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val45, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val62, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp263, ptr %168, align 4
  br label %insn_0x00010440_entry

did_jump_exit58:                                  ; preds = %page_slow50
  %169 = getelementptr i8, ptr %cpu, i64 188
  %next_pc75 = load i32, ptr %169, align 4
  %170 = getelementptr i8, ptr %cpu, i64 188
  %171 = load i32, ptr %170, align 4
  %172 = getelementptr i8, ptr %cpu, i64 296
  %173 = load i8, ptr %172, align 1
  br label %chain_exit

did_jump_cont59:                                  ; preds = %page_slow50
  br label %page_done51

insn_0x00010440_entry:                            ; preds = %page_done51
  br label %insn_0x00010440

insn_0x00010440:                                  ; preds = %insn_0x00010440_entry
  %lsb = and i32 %mem_val62, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x00010440
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x00010440
  %174 = getelementptr i8, ptr %cpu, i32 188
  store i32 66624, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 308
  store i32 9, ptr %176, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %177 = getelementptr i8, ptr %cpu, i64 188
  %next_pc76 = load i32, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i64 188
  %179 = load i32, ptr %178, align 4
  %180 = getelementptr i8, ptr %cpu, i64 296
  %181 = load i8, ptr %180, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %182 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %182, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 533008
  %183 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %183, align 4
  %184 = icmp eq i32 %slot_pc, 66626
  br i1 %184, label %chain_hit, label %chain_leave71, !prof !0

chain_leave71:                                    ; preds = %chain_go, %brt_taken
  %185 = getelementptr i8, ptr %cpu, i64 188
  store i32 66626, ptr %185, align 4
  %186 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %188, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %189 = getelementptr i8, ptr %cpu, i64 188
  store i32 66626, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %190, align 4
  %191 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %191, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit58, %data_misaligned47, %did_jump_exit41, %data_misaligned30, %did_jump_exit26, %data_misaligned19, %did_jump_exit15, %did_jump_exit11, %data_misaligned1, %did_jump_exit, %data_misaligned
  %next_pc77 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc65, %did_jump_exit ], [ %next_pc66, %data_misaligned1 ], [ %next_pc67, %did_jump_exit11 ], [ %next_pc68, %did_jump_exit15 ], [ %next_pc69, %data_misaligned19 ], [ %next_pc70, %did_jump_exit26 ], [ %next_pc72, %data_misaligned30 ], [ %next_pc73, %did_jump_exit41 ], [ %next_pc74, %data_misaligned47 ], [ %next_pc75, %did_jump_exit58 ], [ %mem_val62, %jump_aligned ], [ %next_pc76, %jump_misalign ]
  %packets = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned1 ], [ 2, %did_jump_exit11 ], [ 2, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit26 ], [ 8, %data_misaligned30 ], [ 8, %did_jump_exit41 ], [ 8, %data_misaligned47 ], [ 8, %did_jump_exit58 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail = phi i32 [ %44, %data_misaligned ], [ %58, %did_jump_exit ], [ %66, %data_misaligned1 ], [ %81, %did_jump_exit11 ], [ %90, %did_jump_exit15 ], [ %101, %data_misaligned19 ], [ %115, %did_jump_exit26 ], [ %132, %data_misaligned30 ], [ %147, %did_jump_exit41 ], [ %155, %data_misaligned47 ], [ %171, %did_jump_exit58 ], [ %mem_val62, %jump_aligned ], [ %179, %jump_misalign ]
  %tail78 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned1 ], [ 4, %did_jump_exit11 ], [ 4, %did_jump_exit15 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit26 ], [ 4, %data_misaligned30 ], [ 4, %did_jump_exit41 ], [ 4, %data_misaligned47 ], [ 4, %did_jump_exit58 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail79 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned1 ], [ 2, %did_jump_exit11 ], [ 2, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit26 ], [ 8, %data_misaligned30 ], [ 8, %did_jump_exit41 ], [ 8, %data_misaligned47 ], [ 8, %did_jump_exit58 ], [ 9, %jump_aligned ], [ 9, %jump_misalign ]
  %tail80 = phi i8 [ %46, %data_misaligned ], [ %60, %did_jump_exit ], [ %68, %data_misaligned1 ], [ %83, %did_jump_exit11 ], [ %92, %did_jump_exit15 ], [ %103, %data_misaligned19 ], [ %117, %did_jump_exit26 ], [ %134, %data_misaligned30 ], [ %149, %did_jump_exit41 ], [ %157, %data_misaligned47 ], [ %173, %did_jump_exit58 ], [ 1, %jump_aligned ], [ %181, %jump_misalign ]
  %192 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets82 = load i32, ptr %192, align 4
  %chain_total83 = add nuw i32 %chain_packets82, %packets
  %193 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget84 = load atomic i32, ptr %193 monotonic, align 4, !range !2
  %194 = icmp ult i32 %chain_total83, %chain_budget84
  br i1 %194, label %chain_lookup, label %chain_leave81, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %195 = lshr i32 %next_pc77, 1
  %196 = and i32 %195, 65535
  %197 = zext i32 %196 to i64
  %198 = mul i64 %197, 16
  %chain_slot85 = getelementptr i8, ptr %chain_table, i64 %198
  %199 = getelementptr i8, ptr %chain_slot85, i64 0
  %slot_pc86 = load i32, ptr %199, align 4
  %200 = icmp eq i32 %slot_pc86, %next_pc77
  br i1 %200, label %chain_hit87, label %chain_leave81, !prof !0

chain_leave81:                                    ; preds = %chain_lookup, %chain_exit
  %201 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail78, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail79, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail80, ptr %204, align 1
  br label %return

chain_hit87:                                      ; preds = %chain_lookup
  %205 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc77, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total83, ptr %206, align 4
  %207 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %207, align 1
  %208 = getelementptr i8, ptr %chain_slot85, i64 8
  %chain_fn88 = load ptr, ptr %208, align 8
  musttail call swifttailcc void %chain_fn88(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave81, %chain_leave71, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
