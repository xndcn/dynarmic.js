
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66640-0-123529039228928.bin:     file format binary


Disassembly of section .data:

000070595880b000 <.data>:
    70595880b000:	48 81 ec c8 00 00 00 	sub    rsp,0xc8
    70595880b007:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
    70595880b00e:	00 
    70595880b00f:	4c 89 ac 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r13
    70595880b016:	00 
    70595880b017:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    70595880b01e:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    70595880b025:	00 
    70595880b026:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    70595880b02d:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    70595880b034:	00 
    70595880b035:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    70595880b03c:	00 
    70595880b03d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    70595880b043:	83 fa 00             	cmp    edx,0x0
    70595880b046:	0f 94 c0             	sete   al
    70595880b049:	81 ea 50 04 01 00    	sub    edx,0x10450
    70595880b04f:	83 fa 18             	cmp    edx,0x18
    70595880b052:	0f 97 c2             	seta   dl
    70595880b055:	08 d0                	or     al,dl
    70595880b057:	24 01                	and    al,0x1
    70595880b059:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    70595880b05f:	81 fa 20 04 01 00    	cmp    edx,0x10420
    70595880b065:	0f 94 c1             	sete   cl
    70595880b068:	81 ea 50 04 01 00    	sub    edx,0x10450
    70595880b06e:	83 fa 18             	cmp    edx,0x18
    70595880b071:	0f 97 c2             	seta   dl
    70595880b074:	08 d1                	or     cl,dl
    70595880b076:	20 c8                	and    al,cl
    70595880b078:	a8 01                	test   al,0x1
    70595880b07a:	75 05                	jne    0x70595880b081
    70595880b07c:	e9 08 07 00 00       	jmp    0x70595880b789
    70595880b081:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b088:	00 
    70595880b089:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    70595880b090:	48 89 c8             	mov    rax,rcx
    70595880b093:	48 05 00 00 10 00    	add    rax,0x100000
    70595880b099:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    70595880b0a0:	00 
    70595880b0a1:	8b 81 30 00 10 00    	mov    eax,DWORD PTR [rcx+0x100030]
    70595880b0a7:	83 c0 01             	add    eax,0x1
    70595880b0aa:	89 81 30 00 10 00    	mov    DWORD PTR [rcx+0x100030],eax
    70595880b0b0:	3d 30 75 00 00       	cmp    eax,0x7530
    70595880b0b5:	75 4c                	jne    0x70595880b103
    70595880b0b7:	48 8b 8c 24 a0 00 00 	mov    rcx,QWORD PTR [rsp+0xa0]
    70595880b0be:	00 
    70595880b0bf:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    70595880b0c5:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    70595880b0cc:	89 c2                	mov    edx,eax
    70595880b0ce:	83 c2 01             	add    edx,0x1
    70595880b0d1:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    70595880b0d7:	3d 00 01 00 00       	cmp    eax,0x100
    70595880b0dc:	73 23                	jae    0x70595880b101
    70595880b0de:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    70595880b0e5:	00 
    70595880b0e6:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    70595880b0ed:	89 c9                	mov    ecx,ecx
    70595880b0ef:	48 c1 e1 02          	shl    rcx,0x2
    70595880b0f3:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    70595880b0fa:	c7 04 08 0c 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xc
    70595880b101:	eb 00                	jmp    0x70595880b103
    70595880b103:	eb 00                	jmp    0x70595880b105
    70595880b105:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b10c:	00 
    70595880b10d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    70595880b110:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880b116:	81 c9 00 00 01 00    	or     ecx,0x10000
    70595880b11c:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    70595880b123:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880b126:	eb 00                	jmp    0x70595880b128
    70595880b128:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b12f:	00 
    70595880b130:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    70595880b137:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880b13d:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    70595880b143:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    70595880b14a:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880b14d:	eb 00                	jmp    0x70595880b14f
    70595880b14f:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    70595880b156:	83 e0 03             	and    eax,0x3
    70595880b159:	83 f8 00             	cmp    eax,0x0
    70595880b15c:	74 7d                	je     0x70595880b1db
    70595880b15e:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    70595880b165:	00 
    70595880b166:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880b16d:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    70595880b174:	00 
    70595880b175:	c7 87 bc 00 00 00 58 	mov    DWORD PTR [rdi+0xbc],0x10458
    70595880b17c:	04 01 00 
    70595880b17f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880b186:	00 00 00 
    70595880b189:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    70595880b190:	00 00 00 
    70595880b193:	31 c0                	xor    eax,eax
    70595880b195:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880b19c:	63 00 00 
    70595880b19f:	ba 58 04 01 00       	mov    edx,0x10458
    70595880b1a4:	45 31 c0             	xor    r8d,r8d
    70595880b1a7:	ff d0                	call   rax
    70595880b1a9:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b1b0:	00 
    70595880b1b1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b1b7:	b9 03 00 00 00       	mov    ecx,0x3
    70595880b1bc:	b8 02 00 00 00       	mov    eax,0x2
    70595880b1c1:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b1c8:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b1cf:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b1d6:	e9 4f 06 00 00       	jmp    0x70595880b82a
    70595880b1db:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    70595880b1e2:	00 
    70595880b1e3:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880b1ea:	c1 e9 0c             	shr    ecx,0xc
    70595880b1ed:	89 c9                	mov    ecx,ecx
    70595880b1ef:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880b1f3:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    70595880b1fa:	00 
    70595880b1fb:	48 83 f8 00          	cmp    rax,0x0
    70595880b1ff:	74 20                	je     0x70595880b221
    70595880b201:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    70595880b208:	00 
    70595880b209:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880b210:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880b216:	89 c9                	mov    ecx,ecx
    70595880b218:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880b21b:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    70595880b21f:	eb 5a                	jmp    0x70595880b27b
    70595880b221:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b228:	00 
    70595880b229:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    70595880b230:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    70595880b237:	00 
    70595880b238:	c7 80 bc 00 00 00 58 	mov    DWORD PTR [rax+0xbc],0x10458
    70595880b23f:	04 01 00 
    70595880b242:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880b249:	00 00 00 
    70595880b24c:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    70595880b253:	00 00 00 
    70595880b256:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880b25d:	63 00 00 
    70595880b260:	ff d0                	call   rax
    70595880b262:	89 c1                	mov    ecx,eax
    70595880b264:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b26b:	00 
    70595880b26c:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    70595880b270:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880b277:	75 12                	jne    0x70595880b28b
    70595880b279:	eb 42                	jmp    0x70595880b2bd
    70595880b27b:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b282:	00 
    70595880b283:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    70595880b287:	89 08                	mov    DWORD PTR [rax],ecx
    70595880b289:	eb 3c                	jmp    0x70595880b2c7
    70595880b28b:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b292:	00 
    70595880b293:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b299:	b9 03 00 00 00       	mov    ecx,0x3
    70595880b29e:	b8 02 00 00 00       	mov    eax,0x2
    70595880b2a3:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b2aa:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b2b1:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b2b8:	e9 6d 05 00 00       	jmp    0x70595880b82a
    70595880b2bd:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    70595880b2c1:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    70595880b2c5:	eb b4                	jmp    0x70595880b27b
    70595880b2c7:	eb 00                	jmp    0x70595880b2c9
    70595880b2c9:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b2d0:	00 
    70595880b2d1:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    70595880b2d8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880b2de:	81 c9 00 00 01 00    	or     ecx,0x10000
    70595880b2e4:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    70595880b2e8:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880b2eb:	eb 00                	jmp    0x70595880b2ed
    70595880b2ed:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b2f4:	00 
    70595880b2f5:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    70595880b2f9:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    70595880b2ff:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    70595880b305:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    70595880b309:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    70595880b30c:	eb 00                	jmp    0x70595880b30e
    70595880b30e:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    70595880b312:	83 e0 03             	and    eax,0x3
    70595880b315:	83 f8 00             	cmp    eax,0x0
    70595880b318:	74 7a                	je     0x70595880b394
    70595880b31a:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    70595880b321:	00 
    70595880b322:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    70595880b326:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    70595880b32d:	00 
    70595880b32e:	c7 87 bc 00 00 00 62 	mov    DWORD PTR [rdi+0xbc],0x10462
    70595880b335:	04 01 00 
    70595880b338:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    70595880b33f:	00 00 00 
    70595880b342:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    70595880b349:	00 00 00 
    70595880b34c:	31 c0                	xor    eax,eax
    70595880b34e:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880b355:	63 00 00 
    70595880b358:	ba 62 04 01 00       	mov    edx,0x10462
    70595880b35d:	45 31 c0             	xor    r8d,r8d
    70595880b360:	ff d0                	call   rax
    70595880b362:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b369:	00 
    70595880b36a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b370:	b9 06 00 00 00       	mov    ecx,0x6
    70595880b375:	b8 02 00 00 00       	mov    eax,0x2
    70595880b37a:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b381:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b388:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b38f:	e9 96 04 00 00       	jmp    0x70595880b82a
    70595880b394:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    70595880b39b:	00 
    70595880b39c:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    70595880b3a0:	c1 e9 0c             	shr    ecx,0xc
    70595880b3a3:	89 c9                	mov    ecx,ecx
    70595880b3a5:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880b3a9:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    70595880b3ae:	48 83 f8 00          	cmp    rax,0x0
    70595880b3b2:	74 1a                	je     0x70595880b3ce
    70595880b3b4:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    70595880b3b9:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    70595880b3bd:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880b3c3:	89 c9                	mov    ecx,ecx
    70595880b3c5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880b3c8:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880b3cc:	eb 57                	jmp    0x70595880b425
    70595880b3ce:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b3d5:	00 
    70595880b3d6:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    70595880b3da:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    70595880b3e1:	00 
    70595880b3e2:	c7 80 bc 00 00 00 62 	mov    DWORD PTR [rax+0xbc],0x10462
    70595880b3e9:	04 01 00 
    70595880b3ec:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    70595880b3f3:	00 00 00 
    70595880b3f6:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    70595880b3fd:	00 00 00 
    70595880b400:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880b407:	63 00 00 
    70595880b40a:	ff d0                	call   rax
    70595880b40c:	89 c1                	mov    ecx,eax
    70595880b40e:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b415:	00 
    70595880b416:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    70595880b41a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880b421:	75 13                	jne    0x70595880b436
    70595880b423:	eb 43                	jmp    0x70595880b468
    70595880b425:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b42c:	00 
    70595880b42d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    70595880b431:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    70595880b434:	eb 3c                	jmp    0x70595880b472
    70595880b436:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b43d:	00 
    70595880b43e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b444:	b9 06 00 00 00       	mov    ecx,0x6
    70595880b449:	b8 02 00 00 00       	mov    eax,0x2
    70595880b44e:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b455:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b45c:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b463:	e9 c2 03 00 00       	jmp    0x70595880b82a
    70595880b468:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    70595880b46c:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    70595880b470:	eb b3                	jmp    0x70595880b425
    70595880b472:	eb 00                	jmp    0x70595880b474
    70595880b474:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b47b:	00 
    70595880b47c:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    70595880b47f:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    70595880b483:	83 e0 03             	and    eax,0x3
    70595880b486:	83 f8 00             	cmp    eax,0x0
    70595880b489:	74 7a                	je     0x70595880b505
    70595880b48b:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    70595880b492:	00 
    70595880b493:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880b497:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    70595880b49e:	00 
    70595880b49f:	c7 87 bc 00 00 00 64 	mov    DWORD PTR [rdi+0xbc],0x10464
    70595880b4a6:	04 01 00 
    70595880b4a9:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880b4b0:	00 00 00 
    70595880b4b3:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    70595880b4ba:	00 00 00 
    70595880b4bd:	31 c0                	xor    eax,eax
    70595880b4bf:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880b4c6:	63 00 00 
    70595880b4c9:	ba 64 04 01 00       	mov    edx,0x10464
    70595880b4ce:	45 31 c0             	xor    r8d,r8d
    70595880b4d1:	ff d0                	call   rax
    70595880b4d3:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b4da:	00 
    70595880b4db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b4e1:	b9 07 00 00 00       	mov    ecx,0x7
    70595880b4e6:	b8 04 00 00 00       	mov    eax,0x4
    70595880b4eb:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b4f2:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b4f9:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b500:	e9 25 03 00 00       	jmp    0x70595880b82a
    70595880b505:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    70595880b50c:	00 
    70595880b50d:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880b511:	c1 e9 0c             	shr    ecx,0xc
    70595880b514:	89 c9                	mov    ecx,ecx
    70595880b516:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880b51a:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    70595880b51f:	48 83 f8 00          	cmp    rax,0x0
    70595880b523:	74 1a                	je     0x70595880b53f
    70595880b525:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    70595880b52a:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    70595880b52e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880b534:	89 c9                	mov    ecx,ecx
    70595880b536:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880b539:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    70595880b53d:	eb 57                	jmp    0x70595880b596
    70595880b53f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b546:	00 
    70595880b547:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    70595880b54b:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    70595880b552:	00 
    70595880b553:	c7 80 bc 00 00 00 64 	mov    DWORD PTR [rax+0xbc],0x10464
    70595880b55a:	04 01 00 
    70595880b55d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880b564:	00 00 00 
    70595880b567:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    70595880b56e:	00 00 00 
    70595880b571:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880b578:	63 00 00 
    70595880b57b:	ff d0                	call   rax
    70595880b57d:	89 c1                	mov    ecx,eax
    70595880b57f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b586:	00 
    70595880b587:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    70595880b58b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880b592:	75 22                	jne    0x70595880b5b6
    70595880b594:	eb 52                	jmp    0x70595880b5e8
    70595880b596:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    70595880b59a:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    70595880b59e:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    70595880b5a2:	83 c0 04             	add    eax,0x4
    70595880b5a5:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    70595880b5a9:	83 e0 03             	and    eax,0x3
    70595880b5ac:	83 f8 00             	cmp    eax,0x0
    70595880b5af:	75 41                	jne    0x70595880b5f2
    70595880b5b1:	e9 b6 00 00 00       	jmp    0x70595880b66c
    70595880b5b6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b5bd:	00 
    70595880b5be:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b5c4:	b9 07 00 00 00       	mov    ecx,0x7
    70595880b5c9:	b8 04 00 00 00       	mov    eax,0x4
    70595880b5ce:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b5d5:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b5dc:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b5e3:	e9 42 02 00 00       	jmp    0x70595880b82a
    70595880b5e8:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    70595880b5ec:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    70595880b5f0:	eb a4                	jmp    0x70595880b596
    70595880b5f2:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    70595880b5f9:	00 
    70595880b5fa:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595880b5fe:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    70595880b605:	00 
    70595880b606:	c7 87 bc 00 00 00 64 	mov    DWORD PTR [rdi+0xbc],0x10464
    70595880b60d:	04 01 00 
    70595880b610:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    70595880b617:	00 00 00 
    70595880b61a:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    70595880b621:	00 00 00 
    70595880b624:	31 c0                	xor    eax,eax
    70595880b626:	48 b8 d0 68 8c 23 5a 	movabs rax,0x635a238c68d0
    70595880b62d:	63 00 00 
    70595880b630:	ba 64 04 01 00       	mov    edx,0x10464
    70595880b635:	45 31 c0             	xor    r8d,r8d
    70595880b638:	ff d0                	call   rax
    70595880b63a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b641:	00 
    70595880b642:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b648:	b9 07 00 00 00       	mov    ecx,0x7
    70595880b64d:	b8 04 00 00 00       	mov    eax,0x4
    70595880b652:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b659:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b660:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b667:	e9 be 01 00 00       	jmp    0x70595880b82a
    70595880b66c:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    70595880b673:	00 
    70595880b674:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595880b678:	c1 e9 0c             	shr    ecx,0xc
    70595880b67b:	89 c9                	mov    ecx,ecx
    70595880b67d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    70595880b681:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    70595880b686:	48 83 f8 00          	cmp    rax,0x0
    70595880b68a:	74 1a                	je     0x70595880b6a6
    70595880b68c:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    70595880b691:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595880b695:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    70595880b69b:	89 c9                	mov    ecx,ecx
    70595880b69d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    70595880b6a0:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    70595880b6a4:	eb 57                	jmp    0x70595880b6fd
    70595880b6a6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b6ad:	00 
    70595880b6ae:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    70595880b6b2:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    70595880b6b9:	00 
    70595880b6ba:	c7 80 bc 00 00 00 64 	mov    DWORD PTR [rax+0xbc],0x10464
    70595880b6c1:	04 01 00 
    70595880b6c4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880b6cb:	00 00 00 
    70595880b6ce:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    70595880b6d5:	00 00 00 
    70595880b6d8:	48 b8 f0 05 7b 23 5a 	movabs rax,0x635a237b05f0
    70595880b6df:	63 00 00 
    70595880b6e2:	ff d0                	call   rax
    70595880b6e4:	89 c1                	mov    ecx,eax
    70595880b6e6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b6ed:	00 
    70595880b6ee:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    70595880b6f2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    70595880b6f9:	75 27                	jne    0x70595880b722
    70595880b6fb:	eb 57                	jmp    0x70595880b754
    70595880b6fd:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b704:	00 
    70595880b705:	8b 74 24 40          	mov    esi,DWORD PTR [rsp+0x40]
    70595880b709:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    70595880b70d:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    70595880b711:	83 c1 04             	add    ecx,0x4
    70595880b714:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    70595880b717:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    70595880b71d:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    70595880b720:	eb 3c                	jmp    0x70595880b75e
    70595880b722:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b729:	00 
    70595880b72a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    70595880b730:	b9 07 00 00 00       	mov    ecx,0x7
    70595880b735:	b8 04 00 00 00       	mov    eax,0x4
    70595880b73a:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    70595880b741:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    70595880b748:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    70595880b74f:	e9 d6 00 00 00       	jmp    0x70595880b82a
    70595880b754:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    70595880b758:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    70595880b75c:	eb 9f                	jmp    0x70595880b6fd
    70595880b75e:	eb 00                	jmp    0x70595880b760
    70595880b760:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    70595880b767:	00 
    70595880b768:	c7 81 bc 00 00 00 fc 	mov    DWORD PTR [rcx+0xbc],0x101fc
    70595880b76f:	01 01 00 
    70595880b772:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    70595880b778:	83 c0 08             	add    eax,0x8
    70595880b77b:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    70595880b77f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880b785:	72 16                	jb     0x70595880b79d
    70595880b787:	eb 37                	jmp    0x70595880b7c0
    70595880b789:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b790:	00 
    70595880b791:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    70595880b798:	e9 4a 01 00 00       	jmp    0x70595880b8e7
    70595880b79d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880b7a4:	00 
    70595880b7a5:	48 89 c1             	mov    rcx,rax
    70595880b7a8:	48 81 c1 e0 0f 08 00 	add    rcx,0x80fe0
    70595880b7af:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    70595880b7b4:	81 b8 e0 0f 08 00 fc 	cmp    DWORD PTR [rax+0x80fe0],0x101fc
    70595880b7bb:	01 01 00 
    70595880b7be:	74 32                	je     0x70595880b7f2
    70595880b7c0:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b7c7:	00 
    70595880b7c8:	c7 80 bc 00 00 00 fc 	mov    DWORD PTR [rax+0xbc],0x101fc
    70595880b7cf:	01 01 00 
    70595880b7d2:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    70595880b7d9:	00 00 00 
    70595880b7dc:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    70595880b7e3:	00 00 00 
    70595880b7e6:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    70595880b7ed:	e9 f5 00 00 00       	jmp    0x70595880b8e7
    70595880b7f2:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    70595880b7f9:	00 
    70595880b7fa:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    70595880b801:	00 
    70595880b802:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    70595880b807:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    70595880b80b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101fc
    70595880b812:	fc 01 01 00 
    70595880b816:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880b81d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880b821:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    70595880b828:	ff e0                	jmp    rax
    70595880b82a:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    70595880b831:	00 
    70595880b832:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    70595880b839:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    70595880b840:	8b b4 24 90 00 00 00 	mov    esi,DWORD PTR [rsp+0x90]
    70595880b847:	89 c7                	mov    edi,eax
    70595880b849:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    70595880b84d:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    70595880b851:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    70595880b855:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    70595880b85b:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    70595880b85f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    70595880b865:	73 2d                	jae    0x70595880b894
    70595880b867:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    70595880b86e:	00 
    70595880b86f:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    70595880b873:	89 d1                	mov    ecx,edx
    70595880b875:	c1 e9 01             	shr    ecx,0x1
    70595880b878:	81 e1 ff ff 00 00    	and    ecx,0xffff
    70595880b87e:	89 c9                	mov    ecx,ecx
    70595880b880:	48 c1 e1 04          	shl    rcx,0x4
    70595880b884:	48 89 c6             	mov    rsi,rax
    70595880b887:	48 01 ce             	add    rsi,rcx
    70595880b88a:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    70595880b88f:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    70595880b892:	74 1e                	je     0x70595880b8b2
    70595880b894:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    70595880b89b:	00 
    70595880b89c:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    70595880b8a0:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    70595880b8a4:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    70595880b8aa:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    70595880b8b0:	eb 35                	jmp    0x70595880b8e7
    70595880b8b2:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    70595880b8b9:	00 
    70595880b8ba:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    70595880b8c1:	00 
    70595880b8c2:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    70595880b8c7:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    70595880b8cb:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    70595880b8d2:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    70595880b8d9:	00 
    70595880b8da:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    70595880b8de:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    70595880b8e5:	ff e0                	jmp    rax
    70595880b8e7:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    70595880b8ee:	c2 08 00             	ret    0x8
