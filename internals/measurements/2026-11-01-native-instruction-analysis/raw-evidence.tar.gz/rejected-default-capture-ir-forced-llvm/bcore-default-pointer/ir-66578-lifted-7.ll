; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010412(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66578
  %6 = icmp ugt i32 %5, 18
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb39 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb39, 66592
  %11 = getelementptr i8, ptr %cpu, i64 148
  %guard_lt = load i32, ptr %11, align 4
  %12 = icmp eq i32 %guard_lt, 66578
  %13 = and i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010412_entry, label %lb_guard_miss, !prof !0

insn_0x00010412_entry:                            ; preds = %chain_self, %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table58 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table58, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 28
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010412_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 7, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010412_entry, %28
  br label %insn_0x00010412

insn_0x00010412:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 0
  %rd = load i32, ptr %30, align 4
  %rd_add = add i32 %rd, 1
  %31 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rd_add, ptr %31, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %32 = xor i32 0, %flgn
  %33 = xor i32 %flgs, %flgn
  %overflow = and i32 %33, %32
  %34 = xor i32 %rd, -1
  %35 = icmp ult i32 %34, 1
  %ac0 = zext i1 %35 to i32
  %36 = icmp eq i32 %rd_add, 0
  %az = zext i1 %36 to i32
  %an = lshr i32 %rd_add, 31
  %37 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %39, align 4
  %40 = or i32 %vs_cur, %overflow
  %41 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 256
  store i32 %40, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %47, align 4
  br label %insn_0x00010414_entry

insn_0x00010414_entry:                            ; preds = %insn_0x00010412
  br label %insn_0x00010414

insn_0x00010414:                                  ; preds = %insn_0x00010414_entry
  %48 = getelementptr i8, ptr %cpu, i32 8
  %rt = load i32, ptr %48, align 4
  %and32 = and i32 %rt, %rd_add
  %49 = getelementptr i8, ptr %cpu, i32 4
  store i32 %and32, ptr %49, align 4
  %50 = icmp eq i32 %and32, 0
  %az1 = zext i1 %50 to i32
  %an2 = lshr i32 %and32, 31
  %51 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %56, align 4
  br label %insn_0x00010416_entry

insn_0x00010416_entry:                            ; preds = %insn_0x00010414
  br label %insn_0x00010416

insn_0x00010416:                                  ; preds = %insn_0x00010416_entry
  %57 = getelementptr i8, ptr %cpu, i32 48
  store i32 %and32, ptr %57, align 4
  br label %insn_0x00010418_entry

insn_0x00010418_entry:                            ; preds = %insn_0x00010416
  br label %insn_0x00010418

insn_0x00010418:                                  ; preds = %insn_0x00010418_entry
  %58 = getelementptr i8, ptr %cpu, i32 52
  %ptr = load i32, ptr %58, align 4
  %59 = and i32 %ptr, 3
  %60 = icmp ne i32 %59, 0
  br i1 %60, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010418
  %61 = getelementptr i8, ptr %cpu, i32 188
  store i32 66584, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %63, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66584, i32 %ptr, i32 0)
  %64 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %64, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010418
  %65 = lshr i32 %ptr, 12
  %page_index = zext i32 %65 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %66 = and i32 %ptr, 4095
  %page_offset = zext i32 %66 to i64
  %67 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %67, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %68 = getelementptr i8, ptr %cpu, i32 188
  store i32 66584, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %70, align 4
  %71 = call i32 @mem_read32(ptr %mem, i32 %ptr)
  %72 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %72, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %71, %did_jump_cont ]
  %73 = getelementptr i8, ptr %cpu, i32 36
  store i32 %mem_val, ptr %73, align 4
  %ptr_inc = add i32 %ptr, 4
  %74 = getelementptr i8, ptr %cpu, i32 52
  store i32 %ptr_inc, ptr %74, align 4
  br label %insn_0x0001041a_entry

did_jump_exit:                                    ; preds = %page_slow
  %75 = getelementptr i8, ptr %cpu, i64 188
  %next_pc40 = load i32, ptr %75, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x0001041a_entry:                            ; preds = %page_done
  br label %insn_0x0001041a

insn_0x0001041a:                                  ; preds = %insn_0x0001041a_entry
  %76 = shl i32 %and32, 2
  %77 = getelementptr i8, ptr %cpu, i32 32
  %ps = load i32, ptr %77, align 4
  %plshift2 = add i32 %ps, %76
  %78 = getelementptr i8, ptr %cpu, i32 48
  store i32 %plshift2, ptr %78, align 4
  br label %insn_0x0001041c_entry

insn_0x0001041c_entry:                            ; preds = %insn_0x0001041a
  br label %insn_0x0001041c

insn_0x0001041c:                                  ; preds = %insn_0x0001041c_entry
  %79 = shl i32 %mem_val, 2
  %80 = getelementptr i8, ptr %cpu, i32 44
  %ps3 = load i32, ptr %80, align 4
  %plshift24 = add i32 %ps3, %79
  %81 = getelementptr i8, ptr %cpu, i32 36
  store i32 %plshift24, ptr %81, align 4
  br label %insn_0x0001041e_entry

insn_0x0001041e_entry:                            ; preds = %insn_0x0001041c
  br label %insn_0x0001041e

insn_0x0001041e:                                  ; preds = %insn_0x0001041e_entry
  %82 = and i32 %plshift2, 3
  %83 = icmp ne i32 %82, 0
  br i1 %83, label %data_misaligned5, label %data_aligned6, !prof !1

data_misaligned5:                                 ; preds = %insn_0x0001041e
  %84 = getelementptr i8, ptr %cpu, i32 188
  store i32 66590, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %86, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66590, i32 %plshift2, i32 0)
  %87 = getelementptr i8, ptr %cpu, i64 188
  %next_pc41 = load i32, ptr %87, align 4
  br label %chain_exit

data_aligned6:                                    ; preds = %insn_0x0001041e
  %88 = lshr i32 %plshift2, 12
  %page_index10 = zext i32 %88 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13 = icmp ne ptr %page12, null
  br i1 %page_mapped13, label %page_fast7, label %page_slow8, !prof !0

page_fast7:                                       ; preds = %data_aligned6
  %89 = and i32 %plshift2, 4095
  %page_offset14 = zext i32 %89 to i64
  %90 = getelementptr i8, ptr %page12, i64 %page_offset14
  %page_val15 = load i32, ptr %90, align 4
  br label %page_done9

page_slow8:                                       ; preds = %data_aligned6
  %91 = getelementptr i8, ptr %cpu, i32 188
  store i32 66590, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %93, align 4
  %94 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %95 = getelementptr i8, ptr %cpu, i32 296
  %dj18 = load i8, ptr %95, align 1
  %dj_set19 = icmp ne i8 %dj18, 0
  br i1 %dj_set19, label %did_jump_exit16, label %did_jump_cont17, !prof !1

page_done9:                                       ; preds = %did_jump_cont17, %page_fast7
  %mem_val20 = phi i32 [ %page_val15, %page_fast7 ], [ %94, %did_jump_cont17 ]
  %96 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val20, ptr %96, align 4
  br label %insn_0x00010420_entry

did_jump_exit16:                                  ; preds = %page_slow8
  %97 = getelementptr i8, ptr %cpu, i64 188
  %next_pc42 = load i32, ptr %97, align 4
  br label %chain_exit

did_jump_cont17:                                  ; preds = %page_slow8
  br label %page_done9

insn_0x00010420_entry:                            ; preds = %page_done9
  br label %insn_0x00010420

insn_0x00010420:                                  ; preds = %insn_0x00010420_entry
  %98 = and i32 %plshift24, 3
  %99 = icmp ne i32 %98, 0
  br i1 %99, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x00010420
  %100 = getelementptr i8, ptr %cpu, i32 188
  store i32 66592, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %102, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66592, i32 %plshift24, i32 65536)
  %103 = getelementptr i8, ptr %cpu, i64 188
  %next_pc43 = load i32, ptr %103, align 4
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x00010420
  %104 = lshr i32 %plshift24, 12
  %page_index23 = zext i32 %104 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26 = icmp ne ptr %page25, null
  br i1 %page_mapped26, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned22
  %105 = and i32 %plshift24, 4095
  %page_offset27 = zext i32 %105 to i64
  %106 = getelementptr i8, ptr %page25, i64 %page_offset27
  store i32 %mem_val20, ptr %106, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned22
  %107 = getelementptr i8, ptr %cpu, i32 188
  store i32 66592, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %109, align 4
  call void @mem_write32(ptr %mem, i32 %plshift24, i32 %mem_val20)
  %110 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %110, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont29, %page_wr_fast
  %111 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %111, align 4
  %112 = icmp ugt i32 %lc1, 1
  br i1 %112, label %hwloop_back, label %hwloop_end, !prof !2

did_jump_exit28:                                  ; preds = %page_wr_slow
  %113 = getelementptr i8, ptr %cpu, i64 188
  %next_pc44 = load i32, ptr %113, align 4
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_wr_slow
  br label %page_wr_done

hwloop_done:                                      ; preds = %did_jump_cont36
  br label %insn_0x00010422_entry

hwloop_back:                                      ; preds = %page_wr_done
  %114 = getelementptr i8, ptr %cpu, i32 156
  %115 = sub i32 %lc1, 1
  store i32 %115, ptr %114, align 4
  %116 = getelementptr i8, ptr %cpu, i32 188
  store i32 66578, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i32 296
  store i8 1, ptr %117, align 1
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %118 = icmp ne i8 %cec_pending, 0
  br i1 %118, label %cec_check, label %cec_checked, !prof !1

hwloop_end:                                       ; preds = %page_wr_done
  %119 = getelementptr i8, ptr %cpu, i32 156
  store i32 0, ptr %119, align 4
  %cec_pending32 = load i8, ptr %cec_pending_flag, align 1
  %120 = icmp ne i8 %cec_pending32, 0
  br i1 %120, label %cec_check33, label %cec_checked34, !prof !1

cec_check:                                        ; preds = %hwloop_back
  %121 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %121, align 4
  %122 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %122, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked

cec_checked:                                      ; preds = %cec_check, %hwloop_back
  %123 = getelementptr i8, ptr %cpu, i64 188
  %next_pc45 = load i32, ptr %123, align 4
  br label %chain_exit

cec_check33:                                      ; preds = %hwloop_end
  %124 = getelementptr i8, ptr %cpu, i32 188
  store i32 66594, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %126, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked34

cec_checked34:                                    ; preds = %cec_check33, %hwloop_end
  %127 = getelementptr i8, ptr %cpu, i32 296
  %dj37 = load i8, ptr %127, align 1
  %dj_set38 = icmp ne i8 %dj37, 0
  br i1 %dj_set38, label %did_jump_exit35, label %did_jump_cont36, !prof !1

did_jump_exit35:                                  ; preds = %cec_checked34
  %128 = getelementptr i8, ptr %cpu, i64 188
  %next_pc46 = load i32, ptr %128, align 4
  br label %chain_exit

did_jump_cont36:                                  ; preds = %cec_checked34
  br label %hwloop_done

insn_0x00010422_entry:                            ; preds = %hwloop_done
  br label %insn_0x00010422

insn_0x00010422:                                  ; preds = %insn_0x00010422_entry
  %129 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %129, align 4
  br label %insn_0x00010424_entry

insn_0x00010424_entry:                            ; preds = %insn_0x00010422
  br label %insn_0x00010424

insn_0x00010424:                                  ; preds = %insn_0x00010424_entry
  %130 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %131, align 4
  %chain_total = add nuw i32 %chain_packets, 10
  %132 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %132 monotonic, align 4, !range !3
  %133 = icmp ult i32 %chain_total, %chain_budget
  br i1 %133, label %chain_go, label %chain_leave47, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %134 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %134, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %insn_0x00010424
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531264
  %135 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %135, align 4
  %136 = icmp eq i32 %slot_pc, 66408
  br i1 %136, label %chain_hit, label %chain_leave47, !prof !0

chain_leave47:                                    ; preds = %chain_go, %insn_0x00010424
  %137 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %137, align 4
  %138 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %140, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %141 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %142, align 4
  %143 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %143, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit35, %cec_checked, %did_jump_exit28, %data_misaligned21, %did_jump_exit16, %data_misaligned5, %did_jump_exit, %data_misaligned
  %next_pc48 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc40, %did_jump_exit ], [ %next_pc41, %data_misaligned5 ], [ %next_pc42, %did_jump_exit16 ], [ %next_pc43, %data_misaligned21 ], [ %next_pc44, %did_jump_exit28 ], [ %next_pc45, %cec_checked ], [ %next_pc46, %did_jump_exit35 ]
  %packets = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 7, %data_misaligned5 ], [ 7, %did_jump_exit16 ], [ 8, %data_misaligned21 ], [ 8, %did_jump_exit28 ], [ 8, %cec_checked ], [ 8, %did_jump_exit35 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned5 ], [ 2, %did_jump_exit16 ], [ 2, %data_misaligned21 ], [ 2, %did_jump_exit28 ], [ 2, %cec_checked ], [ 2, %did_jump_exit35 ]
  %tail49 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 7, %data_misaligned5 ], [ 7, %did_jump_exit16 ], [ 8, %data_misaligned21 ], [ 8, %did_jump_exit28 ], [ 8, %cec_checked ], [ 8, %did_jump_exit35 ]
  %144 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets51 = load i32, ptr %144, align 4
  %chain_total52 = add nuw i32 %chain_packets51, %packets
  %145 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget53 = load atomic i32, ptr %145 monotonic, align 4, !range !3
  %146 = icmp ult i32 %chain_total52, %chain_budget53
  br i1 %146, label %chain_lookup, label %chain_leave50, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %147 = icmp eq i32 %next_pc48, 66578
  br i1 %147, label %chain_self, label %chain_other, !prof !2

chain_leave50:                                    ; preds = %chain_other, %chain_exit
  %148 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail49, ptr %149, align 4
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %150 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total52, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %151, align 1
  br label %insn_0x00010412_entry

chain_other:                                      ; preds = %chain_lookup
  %152 = lshr i32 %next_pc48, 1
  %153 = and i32 %152, 65535
  %154 = zext i32 %153 to i64
  %155 = mul i64 %154, 16
  %chain_slot54 = getelementptr i8, ptr %chain_table, i64 %155
  %156 = getelementptr i8, ptr %chain_slot54, i64 0
  %slot_pc55 = load i32, ptr %156, align 4
  %157 = icmp eq i32 %slot_pc55, %next_pc48
  br i1 %157, label %chain_hit56, label %chain_leave50, !prof !0

chain_hit56:                                      ; preds = %chain_other
  %158 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total52, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %159, align 1
  %160 = getelementptr i8, ptr %chain_slot54, i64 8
  %chain_fn57 = load ptr, ptr %160, align 8
  musttail call swifttailcc void %chain_fn57(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave50, %chain_leave47, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{!"branch_weights", i32 63, i32 1}
!3 = !{i32 0, i32 -2147483648}
