
build-native-instruction-analysis/capture/bcore-default-pointer/pc-66534-0-123529441837135.bin:     file format binary


Disassembly of section .data:

000070597080004f <.data>:
    70597080004f:	8b 44 24 04          	mov    eax,DWORD PTR [rsp+0x4]
    705970800053:	41 89 01             	mov    DWORD PTR [r9],eax
    705970800056:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    70597080005a:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    70597080005e:	41 89 41 08          	mov    DWORD PTR [r9+0x8],eax
    705970800062:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705970800067:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    70597080006b:	45 89 79 2c          	mov    DWORD PTR [r9+0x2c],r15d
    70597080006f:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705970800073:	41 c7 81 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],0x0
    70597080007a:	00 00 00 00 
    70597080007e:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x103fa
    705970800085:	fa 03 01 00 
    705970800089:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x103fc
    705970800090:	fc 03 01 00 
    705970800094:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    705970800097:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    70597080009e:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    7059708000a5:	00 00 00 00 
    7059708000a9:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    7059708000b0:	00 00 00 00 
    7059708000b4:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    7059708000bb:	00 00 00 00 
    7059708000bf:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    7059708000c6:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x2
    7059708000cd:	02 00 00 00 
    7059708000d1:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x0
    7059708000d8:	00 
    7059708000d9:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0xa
    7059708000e0:	0a 00 00 00 
    7059708000e4:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    7059708000eb:	48 b8 00 66 8c 23 5a 	movabs rax,0x635a238c6600
    7059708000f2:	63 00 00 
    7059708000f5:	4c 89 cf             	mov    rdi,r9
    7059708000f8:	4d 89 cd             	mov    r13,r9
    7059708000fb:	48 89 cb             	mov    rbx,rcx
    7059708000fe:	44 89 d5             	mov    ebp,r10d
    705970800101:	ff d0                	call   rax
    705970800103:	41 89 ea             	mov    r10d,ebp
    705970800106:	48 89 d9             	mov    rcx,rbx
    705970800109:	4d 89 e9             	mov    r9,r13
    70597080010c:	41 0f b6 95 28 01 00 	movzx  edx,BYTE PTR [r13+0x128]
    705970800113:	00 
    705970800114:	84 d2                	test   dl,dl
    705970800116:	0f 84 87 16 01 e8    	je     0x7059588117a3
    70597080011c:	e9 0c 1a 01 e8       	jmp    0x705958811b2d
    705970800121:	41 c7 01 00 00 00 00 	mov    DWORD PTR [r9],0x0
    705970800128:	45 89 51 04          	mov    DWORD PTR [r9+0x4],r10d
    70597080012c:	41 c7 41 08 ff 1f 00 	mov    DWORD PTR [r9+0x8],0x1fff
    705970800133:	00 
    705970800134:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    705970800139:	41 89 41 24          	mov    DWORD PTR [r9+0x24],eax
    70597080013d:	41 c7 41 2c fc 12 01 	mov    DWORD PTR [r9+0x2c],0x112fc
    705970800144:	00 
    705970800145:	41 89 49 50          	mov    DWORD PTR [r9+0x50],ecx
    705970800149:	41 c7 81 9c 00 00 00 	mov    DWORD PTR [r9+0x9c],0x2000
    705970800150:	00 20 00 00 
    705970800154:	41 c7 81 a4 00 00 00 	mov    DWORD PTR [r9+0xa4],0x10420
    70597080015b:	20 04 01 00 
    70597080015f:	41 c7 81 bc 00 00 00 	mov    DWORD PTR [r9+0xbc],0x10412
    705970800166:	12 04 01 00 
    70597080016a:	8b 04 24             	mov    eax,DWORD PTR [rsp]
    70597080016d:	41 89 81 e4 00 00 00 	mov    DWORD PTR [r9+0xe4],eax
    705970800174:	49 c7 81 e8 00 00 00 	mov    QWORD PTR [r9+0xe8],0x0
    70597080017b:	00 00 00 00 
    70597080017f:	41 c7 81 f0 00 00 00 	mov    DWORD PTR [r9+0xf0],0x0
    705970800186:	00 00 00 00 
    70597080018a:	49 c7 81 f8 00 00 00 	mov    QWORD PTR [r9+0xf8],0x0
    705970800191:	00 00 00 00 
    705970800195:	45 89 b1 00 01 00 00 	mov    DWORD PTR [r9+0x100],r14d
    70597080019c:	41 c7 81 24 01 00 00 	mov    DWORD PTR [r9+0x124],0x4
    7059708001a3:	04 00 00 00 
    7059708001a7:	41 c6 81 28 01 00 00 	mov    BYTE PTR [r9+0x128],0x1
    7059708001ae:	01 
    7059708001af:	41 c7 81 34 01 00 00 	mov    DWORD PTR [r9+0x134],0x10
    7059708001b6:	10 00 00 00 
    7059708001ba:	45 89 a1 5c 01 00 00 	mov    DWORD PTR [r9+0x15c],r12d
    7059708001c1:	48 b8 20 6d 8c 23 5a 	movabs rax,0x635a238c6d20
    7059708001c8:	63 00 00 
    7059708001cb:	4c 89 cf             	mov    rdi,r9
    7059708001ce:	be 0e 04 01 00       	mov    esi,0x1040e
    7059708001d3:	ba 0e 04 01 00       	mov    edx,0x1040e
    7059708001d8:	4d 89 cd             	mov    r13,r9
    7059708001db:	ff d0                	call   rax
    7059708001dd:	e9 40 19 01 e8       	jmp    0x705958811b22
