
build-native-instruction-analysis/capture/bcore-default-stream/pc-66600-0-132432577726064.bin:     file format binary


Disassembly of section .data:

000078725cc08670 <.data>:
    78725cc08670:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    78725cc08677:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
    78725cc0867e:	00 
    78725cc0867f:	4c 89 ac 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r13
    78725cc08686:	00 
    78725cc08687:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0868e:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    78725cc08695:	00 
    78725cc08696:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0869d:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    78725cc086a4:	00 
    78725cc086a5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc086ac:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    78725cc086b3:	00 
    78725cc086b4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    78725cc086bb:	00 
    78725cc086bc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc086c2:	83 fa 00             	cmp    edx,0x0
    78725cc086c5:	0f 94 c0             	sete   al
    78725cc086c8:	81 ea 28 04 01 00    	sub    edx,0x10428
    78725cc086ce:	83 fa 18             	cmp    edx,0x18
    78725cc086d1:	0f 97 c2             	seta   dl
    78725cc086d4:	08 d0                	or     al,dl
    78725cc086d6:	24 01                	and    al,0x1
    78725cc086d8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc086de:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc086e4:	0f 94 c1             	sete   cl
    78725cc086e7:	81 ea 28 04 01 00    	sub    edx,0x10428
    78725cc086ed:	83 fa 18             	cmp    edx,0x18
    78725cc086f0:	0f 97 c2             	seta   dl
    78725cc086f3:	08 d1                	or     cl,dl
    78725cc086f5:	20 c8                	and    al,cl
    78725cc086f7:	a8 01                	test   al,0x1
    78725cc086f9:	75 05                	jne    0x78725cc08700
    78725cc086fb:	e9 4f 0b 00 00       	jmp    0x78725cc0924f
    78725cc08700:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08707:	00 
    78725cc08708:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc0870f:	48 89 c8             	mov    rax,rcx
    78725cc08712:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc08718:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    78725cc0871f:	00 
    78725cc08720:	8b 81 20 00 10 00    	mov    eax,DWORD PTR [rcx+0x100020]
    78725cc08726:	83 c0 01             	add    eax,0x1
    78725cc08729:	89 81 20 00 10 00    	mov    DWORD PTR [rcx+0x100020],eax
    78725cc0872f:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc08734:	75 4c                	jne    0x78725cc08782
    78725cc08736:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    78725cc0873d:	00 
    78725cc0873e:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc08744:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    78725cc0874b:	89 c2                	mov    edx,eax
    78725cc0874d:	83 c2 01             	add    edx,0x1
    78725cc08750:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc08756:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0875b:	73 23                	jae    0x78725cc08780
    78725cc0875d:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    78725cc08764:	00 
    78725cc08765:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc0876c:	89 c9                	mov    ecx,ecx
    78725cc0876e:	48 c1 e1 02          	shl    rcx,0x2
    78725cc08772:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc08779:	c7 04 08 08 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x8
    78725cc08780:	eb 00                	jmp    0x78725cc08782
    78725cc08782:	eb 00                	jmp    0x78725cc08784
    78725cc08784:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0878b:	00 
    78725cc0878c:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    78725cc0878f:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc08795:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc0879b:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    78725cc087a2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc087a5:	eb 00                	jmp    0x78725cc087a7
    78725cc087a7:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    78725cc087ae:	00 
    78725cc087af:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    78725cc087b2:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    78725cc087b8:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    78725cc087bf:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    78725cc087c2:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    78725cc087c9:	83 e8 04             	sub    eax,0x4
    78725cc087cc:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    78725cc087d3:	83 e0 03             	and    eax,0x3
    78725cc087d6:	83 f8 00             	cmp    eax,0x0
    78725cc087d9:	0f 84 98 00 00 00    	je     0x78725cc08877
    78725cc087df:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc087e6:	00 
    78725cc087e7:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc087ee:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    78725cc087f5:	00 
    78725cc087f6:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    78725cc087fd:	04 01 00 
    78725cc08800:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc08807:	00 00 00 
    78725cc0880a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc08811:	00 00 00 
    78725cc08814:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0881b:	60 00 00 
    78725cc0881e:	ba 2c 04 01 00       	mov    edx,0x1042c
    78725cc08823:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc08829:	ff d0                	call   rax
    78725cc0882b:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08832:	00 
    78725cc08833:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08839:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0883f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08845:	be 02 00 00 00       	mov    esi,0x2
    78725cc0884a:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0884f:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08856:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc0885d:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08864:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc0886b:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08872:	e9 79 0a 00 00       	jmp    0x78725cc092f0
    78725cc08877:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0887e:	00 
    78725cc0887f:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc08886:	c1 e9 0c             	shr    ecx,0xc
    78725cc08889:	89 c9                	mov    ecx,ecx
    78725cc0888b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0888f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    78725cc08896:	00 
    78725cc08897:	48 83 f8 00          	cmp    rax,0x0
    78725cc0889b:	74 23                	je     0x78725cc088c0
    78725cc0889d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc088a4:	00 
    78725cc088a5:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc088ac:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc088b3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc088b9:	89 c9                	mov    ecx,ecx
    78725cc088bb:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc088be:	eb 5b                	jmp    0x78725cc0891b
    78725cc088c0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc088c7:	00 
    78725cc088c8:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc088cf:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    78725cc088d6:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    78725cc088dd:	00 
    78725cc088de:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    78725cc088e5:	04 01 00 
    78725cc088e8:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc088ef:	00 00 00 
    78725cc088f2:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc088f9:	00 00 00 
    78725cc088fc:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc08903:	60 00 00 
    78725cc08906:	ff d0                	call   rax
    78725cc08908:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0890f:	00 
    78725cc08910:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08917:	75 20                	jne    0x78725cc08939
    78725cc08919:	eb 6a                	jmp    0x78725cc08985
    78725cc0891b:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    78725cc08922:	83 e8 04             	sub    eax,0x4
    78725cc08925:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc0892c:	83 e0 03             	and    eax,0x3
    78725cc0892f:	83 f8 00             	cmp    eax,0x0
    78725cc08932:	75 53                	jne    0x78725cc08987
    78725cc08934:	e9 e6 00 00 00       	jmp    0x78725cc08a1f
    78725cc08939:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08940:	00 
    78725cc08941:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08947:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0894d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08953:	be 02 00 00 00       	mov    esi,0x2
    78725cc08958:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0895d:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08964:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc0896b:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08972:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08979:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08980:	e9 6b 09 00 00       	jmp    0x78725cc092f0
    78725cc08985:	eb 94                	jmp    0x78725cc0891b
    78725cc08987:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc0898e:	00 
    78725cc0898f:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08996:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    78725cc0899d:	00 
    78725cc0899e:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    78725cc089a5:	04 01 00 
    78725cc089a8:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc089af:	00 00 00 
    78725cc089b2:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc089b9:	00 00 00 
    78725cc089bc:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc089c3:	60 00 00 
    78725cc089c6:	ba 2c 04 01 00       	mov    edx,0x1042c
    78725cc089cb:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc089d1:	ff d0                	call   rax
    78725cc089d3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc089da:	00 
    78725cc089db:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc089e1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc089e7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc089ed:	be 02 00 00 00       	mov    esi,0x2
    78725cc089f2:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc089f7:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc089fe:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08a05:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08a0c:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08a13:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08a1a:	e9 d1 08 00 00       	jmp    0x78725cc092f0
    78725cc08a1f:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc08a26:	00 
    78725cc08a27:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08a2e:	c1 e9 0c             	shr    ecx,0xc
    78725cc08a31:	89 c9                	mov    ecx,ecx
    78725cc08a33:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc08a37:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    78725cc08a3e:	00 
    78725cc08a3f:	48 83 f8 00          	cmp    rax,0x0
    78725cc08a43:	74 23                	je     0x78725cc08a68
    78725cc08a45:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    78725cc08a4c:	00 
    78725cc08a4d:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    78725cc08a54:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08a5b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc08a61:	89 c9                	mov    ecx,ecx
    78725cc08a63:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc08a66:	eb 5b                	jmp    0x78725cc08ac3
    78725cc08a68:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08a6f:	00 
    78725cc08a70:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    78725cc08a77:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    78725cc08a7e:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    78725cc08a85:	00 
    78725cc08a86:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    78725cc08a8d:	04 01 00 
    78725cc08a90:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc08a97:	00 00 00 
    78725cc08a9a:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc08aa1:	00 00 00 
    78725cc08aa4:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc08aab:	60 00 00 
    78725cc08aae:	ff d0                	call   rax
    78725cc08ab0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08ab7:	00 
    78725cc08ab8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08abf:	75 2c                	jne    0x78725cc08aed
    78725cc08ac1:	eb 76                	jmp    0x78725cc08b39
    78725cc08ac3:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    78725cc08aca:	00 
    78725cc08acb:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    78725cc08ad2:	00 
    78725cc08ad3:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    78725cc08ada:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    78725cc08add:	83 ea 00             	sub    edx,0x0
    78725cc08ae0:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc08ae3:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc08ae6:	75 53                	jne    0x78725cc08b3b
    78725cc08ae8:	e9 93 00 00 00       	jmp    0x78725cc08b80
    78725cc08aed:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08af4:	00 
    78725cc08af5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08afb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08b01:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08b07:	be 02 00 00 00       	mov    esi,0x2
    78725cc08b0c:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc08b11:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08b18:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08b1f:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08b26:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08b2d:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08b34:	e9 b7 07 00 00       	jmp    0x78725cc092f0
    78725cc08b39:	eb 88                	jmp    0x78725cc08ac3
    78725cc08b3b:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc08b42:	00 
    78725cc08b43:	c7 87 bc 00 00 00 30 	mov    DWORD PTR [rdi+0xbc],0x10430
    78725cc08b4a:	04 01 00 
    78725cc08b4d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc08b54:	00 00 00 
    78725cc08b57:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc08b5e:	00 00 00 
    78725cc08b61:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc08b68:	60 00 00 
    78725cc08b6b:	ff d0                	call   rax
    78725cc08b6d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08b74:	00 
    78725cc08b75:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08b7c:	75 04                	jne    0x78725cc08b82
    78725cc08b7e:	eb 4e                	jmp    0x78725cc08bce
    78725cc08b80:	eb 4e                	jmp    0x78725cc08bd0
    78725cc08b82:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08b89:	00 
    78725cc08b8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08b90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08b96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08b9c:	be 02 00 00 00       	mov    esi,0x2
    78725cc08ba1:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc08ba6:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08bad:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08bb4:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08bbb:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08bc2:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08bc9:	e9 22 07 00 00       	jmp    0x78725cc092f0
    78725cc08bce:	eb b0                	jmp    0x78725cc08b80
    78725cc08bd0:	eb 00                	jmp    0x78725cc08bd2
    78725cc08bd2:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08bd9:	00 
    78725cc08bda:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    78725cc08be1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc08be7:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    78725cc08bed:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    78725cc08bf4:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc08bf7:	eb 00                	jmp    0x78725cc08bf9
    78725cc08bf9:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    78725cc08c00:	83 e0 03             	and    eax,0x3
    78725cc08c03:	83 f8 00             	cmp    eax,0x0
    78725cc08c06:	0f 84 97 00 00 00    	je     0x78725cc08ca3
    78725cc08c0c:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc08c13:	00 
    78725cc08c14:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    78725cc08c1b:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    78725cc08c22:	00 
    78725cc08c23:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10434
    78725cc08c2a:	04 01 00 
    78725cc08c2d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc08c34:	00 00 00 
    78725cc08c37:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc08c3e:	00 00 00 
    78725cc08c41:	31 c0                	xor    eax,eax
    78725cc08c43:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc08c4a:	60 00 00 
    78725cc08c4d:	ba 34 04 01 00       	mov    edx,0x10434
    78725cc08c52:	45 31 c0             	xor    r8d,r8d
    78725cc08c55:	ff d0                	call   rax
    78725cc08c57:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08c5e:	00 
    78725cc08c5f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08c65:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08c6b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08c71:	be 04 00 00 00       	mov    esi,0x4
    78725cc08c76:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc08c7b:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08c82:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08c89:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08c90:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08c97:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08c9e:	e9 4d 06 00 00       	jmp    0x78725cc092f0
    78725cc08ca3:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc08caa:	00 
    78725cc08cab:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    78725cc08cb2:	c1 e9 0c             	shr    ecx,0xc
    78725cc08cb5:	89 c9                	mov    ecx,ecx
    78725cc08cb7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc08cbb:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc08cc0:	48 83 f8 00          	cmp    rax,0x0
    78725cc08cc4:	74 1d                	je     0x78725cc08ce3
    78725cc08cc6:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08ccb:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    78725cc08cd2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc08cd8:	89 c9                	mov    ecx,ecx
    78725cc08cda:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc08cdd:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc08ce1:	eb 5a                	jmp    0x78725cc08d3d
    78725cc08ce3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08cea:	00 
    78725cc08ceb:	8b b4 24 84 00 00 00 	mov    esi,DWORD PTR [rsp+0x84]
    78725cc08cf2:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    78725cc08cf9:	00 
    78725cc08cfa:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10434
    78725cc08d01:	04 01 00 
    78725cc08d04:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc08d0b:	00 00 00 
    78725cc08d0e:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc08d15:	00 00 00 
    78725cc08d18:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc08d1f:	60 00 00 
    78725cc08d22:	ff d0                	call   rax
    78725cc08d24:	89 c1                	mov    ecx,eax
    78725cc08d26:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08d2d:	00 
    78725cc08d2e:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    78725cc08d32:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08d39:	75 17                	jne    0x78725cc08d52
    78725cc08d3b:	eb 61                	jmp    0x78725cc08d9e
    78725cc08d3d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08d44:	00 
    78725cc08d45:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc08d49:	89 4c 24 6c          	mov    DWORD PTR [rsp+0x6c],ecx
    78725cc08d4d:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc08d50:	eb 56                	jmp    0x78725cc08da8
    78725cc08d52:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08d59:	00 
    78725cc08d5a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08d60:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08d66:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08d6c:	be 04 00 00 00       	mov    esi,0x4
    78725cc08d71:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc08d76:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08d7d:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08d84:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08d8b:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08d92:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08d99:	e9 52 05 00 00       	jmp    0x78725cc092f0
    78725cc08d9e:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    78725cc08da2:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc08da6:	eb 95                	jmp    0x78725cc08d3d
    78725cc08da8:	eb 00                	jmp    0x78725cc08daa
    78725cc08daa:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08db1:	00 
    78725cc08db2:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    78725cc08db6:	83 f9 04             	cmp    ecx,0x4
    78725cc08db9:	0f 96 c1             	setbe  cl
    78725cc08dbc:	80 e1 01             	and    cl,0x1
    78725cc08dbf:	0f b6 c9             	movzx  ecx,cl
    78725cc08dc2:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc08dc6:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    78725cc08dcc:	eb 00                	jmp    0x78725cc08dce
    78725cc08dce:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    78725cc08dd2:	83 f8 00             	cmp    eax,0x0
    78725cc08dd5:	74 30                	je     0x78725cc08e07
    78725cc08dd7:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    78725cc08dde:	00 
    78725cc08ddf:	c7 81 bc 00 00 00 42 	mov    DWORD PTR [rcx+0xbc],0x10442
    78725cc08de6:	04 01 00 
    78725cc08de9:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc08def:	83 c0 06             	add    eax,0x6
    78725cc08df2:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc08df6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc08dfc:	0f 82 61 04 00 00    	jb     0x78725cc09263
    78725cc08e02:	e9 7f 04 00 00       	jmp    0x78725cc09286
    78725cc08e07:	eb 00                	jmp    0x78725cc08e09
    78725cc08e09:	eb 00                	jmp    0x78725cc08e0b
    78725cc08e0b:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08e12:	00 
    78725cc08e13:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    78725cc08e19:	eb 00                	jmp    0x78725cc08e1b
    78725cc08e1b:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc08e22:	83 e0 03             	and    eax,0x3
    78725cc08e25:	83 f8 00             	cmp    eax,0x0
    78725cc08e28:	0f 84 97 00 00 00    	je     0x78725cc08ec5
    78725cc08e2e:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc08e35:	00 
    78725cc08e36:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08e3d:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    78725cc08e44:	00 
    78725cc08e45:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    78725cc08e4c:	04 01 00 
    78725cc08e4f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc08e56:	00 00 00 
    78725cc08e59:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc08e60:	00 00 00 
    78725cc08e63:	31 c0                	xor    eax,eax
    78725cc08e65:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc08e6c:	60 00 00 
    78725cc08e6f:	ba 3c 04 01 00       	mov    edx,0x1043c
    78725cc08e74:	45 31 c0             	xor    r8d,r8d
    78725cc08e77:	ff d0                	call   rax
    78725cc08e79:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08e80:	00 
    78725cc08e81:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08e87:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08e8d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08e93:	be 08 00 00 00       	mov    esi,0x8
    78725cc08e98:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc08e9d:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08ea4:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08eab:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08eb2:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08eb9:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08ec0:	e9 2b 04 00 00       	jmp    0x78725cc092f0
    78725cc08ec5:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc08ecc:	00 
    78725cc08ecd:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08ed4:	c1 e9 0c             	shr    ecx,0xc
    78725cc08ed7:	89 c9                	mov    ecx,ecx
    78725cc08ed9:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc08edd:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc08ee2:	48 83 f8 00          	cmp    rax,0x0
    78725cc08ee6:	74 1d                	je     0x78725cc08f05
    78725cc08ee8:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc08eed:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc08ef4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc08efa:	89 c9                	mov    ecx,ecx
    78725cc08efc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc08eff:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc08f03:	eb 5a                	jmp    0x78725cc08f5f
    78725cc08f05:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08f0c:	00 
    78725cc08f0d:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    78725cc08f14:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    78725cc08f1b:	00 
    78725cc08f1c:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    78725cc08f23:	04 01 00 
    78725cc08f26:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc08f2d:	00 00 00 
    78725cc08f30:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    78725cc08f37:	00 00 00 
    78725cc08f3a:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc08f41:	60 00 00 
    78725cc08f44:	ff d0                	call   rax
    78725cc08f46:	89 c1                	mov    ecx,eax
    78725cc08f48:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08f4f:	00 
    78725cc08f50:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc08f54:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08f5b:	75 25                	jne    0x78725cc08f82
    78725cc08f5d:	eb 6f                	jmp    0x78725cc08fce
    78725cc08f5f:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc08f66:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc08f6a:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc08f6e:	83 c0 04             	add    eax,0x4
    78725cc08f71:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc08f75:	83 e0 03             	and    eax,0x3
    78725cc08f78:	83 f8 00             	cmp    eax,0x0
    78725cc08f7b:	75 5b                	jne    0x78725cc08fd8
    78725cc08f7d:	e9 ea 00 00 00       	jmp    0x78725cc0906c
    78725cc08f82:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc08f89:	00 
    78725cc08f8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc08f90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08f96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc08f9c:	be 08 00 00 00       	mov    esi,0x8
    78725cc08fa1:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc08fa6:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc08fad:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc08fb4:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc08fbb:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc08fc2:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc08fc9:	e9 22 03 00 00       	jmp    0x78725cc092f0
    78725cc08fce:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc08fd2:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc08fd6:	eb 87                	jmp    0x78725cc08f5f
    78725cc08fd8:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc08fdf:	00 
    78725cc08fe0:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc08fe4:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    78725cc08feb:	00 
    78725cc08fec:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    78725cc08ff3:	04 01 00 
    78725cc08ff6:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc08ffd:	00 00 00 
    78725cc09000:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc09007:	00 00 00 
    78725cc0900a:	31 c0                	xor    eax,eax
    78725cc0900c:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc09013:	60 00 00 
    78725cc09016:	ba 3c 04 01 00       	mov    edx,0x1043c
    78725cc0901b:	45 31 c0             	xor    r8d,r8d
    78725cc0901e:	ff d0                	call   rax
    78725cc09020:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc09027:	00 
    78725cc09028:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0902e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09034:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0903a:	be 08 00 00 00       	mov    esi,0x8
    78725cc0903f:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc09044:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc0904b:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc09052:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc09059:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc09060:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc09067:	e9 84 02 00 00       	jmp    0x78725cc092f0
    78725cc0906c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc09073:	00 
    78725cc09074:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc09078:	c1 e9 0c             	shr    ecx,0xc
    78725cc0907b:	89 c9                	mov    ecx,ecx
    78725cc0907d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc09081:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    78725cc09086:	48 83 f8 00          	cmp    rax,0x0
    78725cc0908a:	74 1a                	je     0x78725cc090a6
    78725cc0908c:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc09091:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc09095:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0909b:	89 c9                	mov    ecx,ecx
    78725cc0909d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc090a0:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc090a4:	eb 57                	jmp    0x78725cc090fd
    78725cc090a6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc090ad:	00 
    78725cc090ae:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc090b2:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    78725cc090b9:	00 
    78725cc090ba:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    78725cc090c1:	04 01 00 
    78725cc090c4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc090cb:	00 00 00 
    78725cc090ce:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    78725cc090d5:	00 00 00 
    78725cc090d8:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc090df:	60 00 00 
    78725cc090e2:	ff d0                	call   rax
    78725cc090e4:	89 c1                	mov    ecx,eax
    78725cc090e6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc090ed:	00 
    78725cc090ee:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    78725cc090f2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc090f9:	75 2b                	jne    0x78725cc09126
    78725cc090fb:	eb 75                	jmp    0x78725cc09172
    78725cc090fd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc09104:	00 
    78725cc09105:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    78725cc09109:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc0910d:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    78725cc09111:	89 54 24 34          	mov    DWORD PTR [rsp+0x34],edx
    78725cc09115:	83 c1 04             	add    ecx,0x4
    78725cc09118:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc0911b:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc09121:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc09124:	eb 56                	jmp    0x78725cc0917c
    78725cc09126:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0912d:	00 
    78725cc0912e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc09134:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0913a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc09140:	be 08 00 00 00       	mov    esi,0x8
    78725cc09145:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0914a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc09151:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc09158:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc0915f:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc09166:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc0916d:	e9 7e 01 00 00       	jmp    0x78725cc092f0
    78725cc09172:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    78725cc09176:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc0917a:	eb 81                	jmp    0x78725cc090fd
    78725cc0917c:	eb 00                	jmp    0x78725cc0917e
    78725cc0917e:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    78725cc09182:	83 e0 01             	and    eax,0x1
    78725cc09185:	83 f8 00             	cmp    eax,0x0
    78725cc09188:	75 3a                	jne    0x78725cc091c4
    78725cc0918a:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    78725cc0918e:	be 09 00 00 00       	mov    esi,0x9
    78725cc09193:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc09198:	b0 01                	mov    al,0x1
    78725cc0919a:	89 d7                	mov    edi,edx
    78725cc0919c:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc091a3:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc091aa:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc091b1:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc091b8:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc091bf:	e9 2c 01 00 00       	jmp    0x78725cc092f0
    78725cc091c4:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    78725cc091cb:	00 
    78725cc091cc:	48 8b 94 24 d0 00 00 	mov    rdx,QWORD PTR [rsp+0xd0]
    78725cc091d3:	00 
    78725cc091d4:	c7 87 bc 00 00 00 40 	mov    DWORD PTR [rdi+0xbc],0x10440
    78725cc091db:	04 01 00 
    78725cc091de:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc091e5:	00 00 00 
    78725cc091e8:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    78725cc091ef:	00 00 00 
    78725cc091f2:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc091f9:	60 00 00 
    78725cc091fc:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc09201:	ff d0                	call   rax
    78725cc09203:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0920a:	00 
    78725cc0920b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc09211:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09217:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0921d:	be 09 00 00 00       	mov    esi,0x9
    78725cc09222:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc09227:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc0922e:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    78725cc09235:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    78725cc0923c:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    78725cc09243:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    78725cc0924a:	e9 a1 00 00 00       	jmp    0x78725cc092f0
    78725cc0924f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc09256:	00 
    78725cc09257:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc0925e:	e9 7f 01 00 00       	jmp    0x78725cc093e2
    78725cc09263:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    78725cc0926a:	00 
    78725cc0926b:	48 89 c1             	mov    rcx,rax
    78725cc0926e:	48 81 c1 10 22 08 00 	add    rcx,0x82210
    78725cc09275:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc0927a:	81 b8 10 22 08 00 42 	cmp    DWORD PTR [rax+0x82210],0x10442
    78725cc09281:	04 01 00 
    78725cc09284:	74 32                	je     0x78725cc092b8
    78725cc09286:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0928d:	00 
    78725cc0928e:	c7 80 bc 00 00 00 42 	mov    DWORD PTR [rax+0xbc],0x10442
    78725cc09295:	04 01 00 
    78725cc09298:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0929f:	00 00 00 
    78725cc092a2:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    78725cc092a9:	00 00 00 
    78725cc092ac:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc092b3:	e9 2a 01 00 00       	jmp    0x78725cc093e2
    78725cc092b8:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    78725cc092bf:	00 
    78725cc092c0:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    78725cc092c7:	00 
    78725cc092c8:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc092cd:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc092d1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    78725cc092d8:	42 04 01 00 
    78725cc092dc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc092e3:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc092e7:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    78725cc092ee:	ff e0                	jmp    rax
    78725cc092f0:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    78725cc092f7:	00 
    78725cc092f8:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    78725cc092ff:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    78725cc09306:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    78725cc0930d:	8b bc 24 ac 00 00 00 	mov    edi,DWORD PTR [rsp+0xac]
    78725cc09314:	8a 9c 24 b3 00 00 00 	mov    bl,BYTE PTR [rsp+0xb3]
    78725cc0931b:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    78725cc0931f:	89 c3                	mov    ebx,eax
    78725cc09321:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    78725cc09325:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    78725cc09329:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    78725cc0932d:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    78725cc09331:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc09337:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc0933b:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc09341:	73 2d                	jae    0x78725cc09370
    78725cc09343:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    78725cc0934a:	00 
    78725cc0934b:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc0934f:	89 d1                	mov    ecx,edx
    78725cc09351:	c1 e9 01             	shr    ecx,0x1
    78725cc09354:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0935a:	89 c9                	mov    ecx,ecx
    78725cc0935c:	48 c1 e1 04          	shl    rcx,0x4
    78725cc09360:	48 89 c6             	mov    rsi,rax
    78725cc09363:	48 01 ce             	add    rsi,rcx
    78725cc09366:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc0936b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0936e:	74 32                	je     0x78725cc093a2
    78725cc09370:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc09377:	00 
    78725cc09378:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    78725cc0937c:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc09380:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc09384:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    78725cc09388:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc0938e:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc09394:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc0939a:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc093a0:	eb 40                	jmp    0x78725cc093e2
    78725cc093a2:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    78725cc093a9:	00 
    78725cc093aa:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    78725cc093b1:	00 
    78725cc093b2:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc093b7:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    78725cc093bb:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc093bf:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc093c6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc093cd:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc093d4:	00 
    78725cc093d5:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc093d9:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    78725cc093e0:	ff e0                	jmp    rax
    78725cc093e2:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    78725cc093e9:	c2 08 00             	ret    0x8
