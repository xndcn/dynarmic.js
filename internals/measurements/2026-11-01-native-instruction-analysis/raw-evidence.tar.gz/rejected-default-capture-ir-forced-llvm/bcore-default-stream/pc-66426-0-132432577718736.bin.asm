
build-native-instruction-analysis/capture/bcore-default-stream/pc-66426-0-132432577718736.bin:     file format binary


Disassembly of section .data:

000078725cc069d0 <.data>:
    78725cc069d0:	48 83 ec 48          	sub    rsp,0x48
    78725cc069d4:	4c 89 74 24 30       	mov    QWORD PTR [rsp+0x30],r14
    78725cc069d9:	4c 89 6c 24 38       	mov    QWORD PTR [rsp+0x38],r13
    78725cc069de:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc069e5:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    78725cc069ea:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    78725cc069ef:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc069f5:	83 fa 00             	cmp    edx,0x0
    78725cc069f8:	0f 94 c0             	sete   al
    78725cc069fb:	81 ea 7a 03 01 00    	sub    edx,0x1037a
    78725cc06a01:	83 fa 1c             	cmp    edx,0x1c
    78725cc06a04:	0f 97 c2             	seta   dl
    78725cc06a07:	08 d0                	or     al,dl
    78725cc06a09:	24 01                	and    al,0x1
    78725cc06a0b:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc06a11:	83 fa 00             	cmp    edx,0x0
    78725cc06a14:	0f 94 c1             	sete   cl
    78725cc06a17:	81 ea 7a 03 01 00    	sub    edx,0x1037a
    78725cc06a1d:	83 fa 1c             	cmp    edx,0x1c
    78725cc06a20:	0f 97 c2             	seta   dl
    78725cc06a23:	08 d1                	or     cl,dl
    78725cc06a25:	20 c8                	and    al,cl
    78725cc06a27:	a8 01                	test   al,0x1
    78725cc06a29:	75 05                	jne    0x78725cc06a30
    78725cc06a2b:	e9 c6 01 00 00       	jmp    0x78725cc06bf6
    78725cc06a30:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06a35:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc06a3c:	48 89 c8             	mov    rax,rcx
    78725cc06a3f:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc06a45:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    78725cc06a4a:	8b 81 10 00 10 00    	mov    eax,DWORD PTR [rcx+0x100010]
    78725cc06a50:	83 c0 01             	add    eax,0x1
    78725cc06a53:	89 81 10 00 10 00    	mov    DWORD PTR [rcx+0x100010],eax
    78725cc06a59:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc06a5e:	75 40                	jne    0x78725cc06aa0
    78725cc06a60:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
    78725cc06a65:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc06a6b:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc06a6f:	89 c2                	mov    edx,eax
    78725cc06a71:	83 c2 01             	add    edx,0x1
    78725cc06a74:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc06a7a:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc06a7f:	73 1d                	jae    0x78725cc06a9e
    78725cc06a81:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc06a86:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    78725cc06a8a:	89 c9                	mov    ecx,ecx
    78725cc06a8c:	48 c1 e1 02          	shl    rcx,0x2
    78725cc06a90:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc06a97:	c7 04 08 04 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x4
    78725cc06a9e:	eb 00                	jmp    0x78725cc06aa0
    78725cc06aa0:	eb 00                	jmp    0x78725cc06aa2
    78725cc06aa2:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06aa7:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    78725cc06aaa:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc06ab0:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc06ab6:	89 4c 24 1c          	mov    DWORD PTR [rsp+0x1c],ecx
    78725cc06aba:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc06abd:	8b 80 a0 00 00 00    	mov    eax,DWORD PTR [rax+0xa0]
    78725cc06ac3:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    78725cc06ac7:	eb 00                	jmp    0x78725cc06ac9
    78725cc06ac9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06ace:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    78725cc06ad1:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc06ad7:	81 c9 00 00 19 00    	or     ecx,0x190000
    78725cc06add:	89 4c 24 18          	mov    DWORD PTR [rsp+0x18],ecx
    78725cc06ae1:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc06ae4:	eb 00                	jmp    0x78725cc06ae6
    78725cc06ae6:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06aeb:	8b 08                	mov    ecx,DWORD PTR [rax]
    78725cc06aed:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc06af3:	81 c9 00 00 6e 3c    	or     ecx,0x3c6e0000
    78725cc06af9:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    78725cc06afd:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc06aff:	eb 00                	jmp    0x78725cc06b01
    78725cc06b01:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06b06:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc06b0a:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc06b10:	81 c9 fc 12 00 00    	or     ecx,0x12fc
    78725cc06b16:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc06b19:	eb 00                	jmp    0x78725cc06b1b
    78725cc06b1b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06b20:	8b 4c 24 18          	mov    ecx,DWORD PTR [rsp+0x18]
    78725cc06b24:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc06b2a:	81 c9 0d 66 00 00    	or     ecx,0x660d
    78725cc06b30:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc06b33:	eb 00                	jmp    0x78725cc06b35
    78725cc06b35:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06b3a:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    78725cc06b3e:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc06b44:	81 c9 5f f3 00 00    	or     ecx,0xf35f
    78725cc06b4a:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc06b4c:	eb 00                	jmp    0x78725cc06b4e
    78725cc06b4e:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06b53:	c7 40 28 00 20 00 00 	mov    DWORD PTR [rax+0x28],0x2000
    78725cc06b5a:	eb 00                	jmp    0x78725cc06b5c
    78725cc06b5c:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc06b60:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    78725cc06b65:	c7 81 94 00 00 00 9a 	mov    DWORD PTR [rcx+0x94],0x1039a
    78725cc06b6c:	03 01 00 
    78725cc06b6f:	c7 81 a4 00 00 00 9e 	mov    DWORD PTR [rcx+0xa4],0x1039e
    78725cc06b76:	03 01 00 
    78725cc06b79:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x2000
    78725cc06b80:	20 00 00 
    78725cc06b83:	c7 81 bc 00 00 00 9a 	mov    DWORD PTR [rcx+0xbc],0x1039a
    78725cc06b8a:	03 01 00 
    78725cc06b8d:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    78725cc06b94:	3d 96 03 01 00       	cmp    eax,0x10396
    78725cc06b99:	0f 94 c0             	sete   al
    78725cc06b9c:	0c 00                	or     al,0x0
    78725cc06b9e:	a8 01                	test   al,0x1
    78725cc06ba0:	75 02                	jne    0x78725cc06ba4
    78725cc06ba2:	eb 36                	jmp    0x78725cc06bda
    78725cc06ba4:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
    78725cc06ba9:	c7 87 bc 00 00 00 9a 	mov    DWORD PTR [rdi+0xbc],0x1039a
    78725cc06bb0:	03 01 00 
    78725cc06bb3:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc06bba:	00 00 00 
    78725cc06bbd:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc06bc4:	00 00 00 
    78725cc06bc7:	48 b8 20 0d 15 8d 97 	movabs rax,0x60978d150d20
    78725cc06bce:	60 00 00 
    78725cc06bd1:	ba 96 03 01 00       	mov    edx,0x10396
    78725cc06bd6:	89 d6                	mov    esi,edx
    78725cc06bd8:	ff d0                	call   rax
    78725cc06bda:	48 8b 4c 24 38       	mov    rcx,QWORD PTR [rsp+0x38]
    78725cc06bdf:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc06be5:	83 c0 08             	add    eax,0x8
    78725cc06be8:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    78725cc06bec:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc06bf2:	72 10                	jb     0x78725cc06c04
    78725cc06bf4:	eb 2e                	jmp    0x78725cc06c24
    78725cc06bf6:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06bfb:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc06c02:	eb 7c                	jmp    0x78725cc06c80
    78725cc06c04:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc06c09:	48 89 c1             	mov    rcx,rax
    78725cc06c0c:	48 81 c1 d0 1c 08 00 	add    rcx,0x81cd0
    78725cc06c13:	48 89 4c 24 08       	mov    QWORD PTR [rsp+0x8],rcx
    78725cc06c18:	81 b8 d0 1c 08 00 9a 	cmp    DWORD PTR [rax+0x81cd0],0x1039a
    78725cc06c1f:	03 01 00 
    78725cc06c22:	74 25                	je     0x78725cc06c49
    78725cc06c24:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06c29:	c7 80 bc 00 00 00 9a 	mov    DWORD PTR [rax+0xbc],0x1039a
    78725cc06c30:	03 01 00 
    78725cc06c33:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc06c3a:	00 00 00 
    78725cc06c3d:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    78725cc06c44:	00 00 00 
    78725cc06c47:	eb 37                	jmp    0x78725cc06c80
    78725cc06c49:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
    78725cc06c4e:	4c 8b 6c 24 38       	mov    r13,QWORD PTR [rsp+0x38]
    78725cc06c53:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc06c58:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc06c5c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1039a
    78725cc06c63:	9a 03 01 00 
    78725cc06c67:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc06c6e:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc06c75:	00 
    78725cc06c76:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc06c7a:	48 83 c4 48          	add    rsp,0x48
    78725cc06c7e:	ff e0                	jmp    rax
    78725cc06c80:	48 83 c4 48          	add    rsp,0x48
    78725cc06c84:	c2 08 00             	ret    0x8
