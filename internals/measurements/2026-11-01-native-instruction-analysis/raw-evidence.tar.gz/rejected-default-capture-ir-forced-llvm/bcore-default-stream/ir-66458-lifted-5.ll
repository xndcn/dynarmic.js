; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001039a(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66458
  %6 = icmp ugt i32 %5, 8
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb8 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb8, 66462
  %11 = getelementptr i8, ptr %cpu, i64 148
  %guard_lt = load i32, ptr %11, align 4
  %12 = icmp eq i32 %guard_lt, 66458
  %13 = and i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x0001039a_entry, label %lb_guard_miss, !prof !0

insn_0x0001039a_entry:                            ; preds = %chain_self, %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table23 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table23, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 20
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x0001039a_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 5, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x0001039a_entry, %28
  br label %insn_0x0001039a

insn_0x0001039a:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 8
  %a = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 4
  %b = load i32, ptr %31, align 4
  %mul = mul i32 %a, %b
  %32 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mul, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %34, align 4
  br label %insn_0x0001039c_entry

insn_0x0001039c_entry:                            ; preds = %insn_0x0001039a
  br label %insn_0x0001039c

insn_0x0001039c:                                  ; preds = %insn_0x0001039c_entry
  %35 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %35, align 4
  %add32 = add i32 %mul, %rt
  %36 = getelementptr i8, ptr %cpu, i32 8
  store i32 %add32, ptr %36, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %37 = xor i32 %flgo, %flgn
  %38 = xor i32 %flgs, %flgn
  %39 = and i32 %38, %37
  %40 = xor i32 %mul, -1
  %41 = icmp ult i32 %40, %rt
  %ac0 = zext i1 %41 to i32
  %42 = icmp eq i32 %add32, 0
  %az = zext i1 %42 to i32
  %an = lshr i32 %add32, 31
  %43 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %45, align 4
  %46 = or i32 %vs_cur, %39
  %47 = getelementptr i8, ptr %cpu, i32 248
  store i32 %39, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 252
  store i32 %39, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 256
  store i32 %46, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %51, align 4
  br label %insn_0x0001039e_entry

insn_0x0001039e_entry:                            ; preds = %insn_0x0001039c
  br label %insn_0x0001039e

insn_0x0001039e:                                  ; preds = %insn_0x0001039e_entry
  %52 = getelementptr i8, ptr %cpu, i32 36
  %ptr = load i32, ptr %52, align 4
  %53 = and i32 %ptr, 3
  %54 = icmp ne i32 %53, 0
  br i1 %54, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001039e
  %55 = getelementptr i8, ptr %cpu, i32 188
  store i32 66462, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %57, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66462, i32 %ptr, i32 65536)
  %58 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %58, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001039e
  %59 = lshr i32 %ptr, 12
  %page_index = zext i32 %59 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %60 = and i32 %ptr, 4095
  %page_offset = zext i32 %60 to i64
  %61 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %add32, ptr %61, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %62 = getelementptr i8, ptr %cpu, i32 188
  store i32 66462, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %64, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %add32)
  %65 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %65, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %ptr_inc = add i32 %ptr, 4
  %66 = getelementptr i8, ptr %cpu, i32 36
  store i32 %ptr_inc, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %67, align 4
  %68 = icmp ugt i32 %lc1, 1
  br i1 %68, label %hwloop_back, label %hwloop_end, !prof !2

did_jump_exit:                                    ; preds = %page_wr_slow
  %69 = getelementptr i8, ptr %cpu, i64 188
  %next_pc9 = load i32, ptr %69, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

hwloop_done:                                      ; preds = %did_jump_cont5
  br label %insn_0x000103a0_entry

hwloop_back:                                      ; preds = %page_wr_done
  %70 = getelementptr i8, ptr %cpu, i32 156
  %71 = sub i32 %lc1, 1
  store i32 %71, ptr %70, align 4
  %72 = getelementptr i8, ptr %cpu, i32 188
  store i32 66458, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 296
  store i8 1, ptr %73, align 1
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %74 = icmp ne i8 %cec_pending, 0
  br i1 %74, label %cec_check, label %cec_checked, !prof !1

hwloop_end:                                       ; preds = %page_wr_done
  %75 = getelementptr i8, ptr %cpu, i32 156
  store i32 0, ptr %75, align 4
  %cec_pending1 = load i8, ptr %cec_pending_flag, align 1
  %76 = icmp ne i8 %cec_pending1, 0
  br i1 %76, label %cec_check2, label %cec_checked3, !prof !1

cec_check:                                        ; preds = %hwloop_back
  %77 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %78, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked

cec_checked:                                      ; preds = %cec_check, %hwloop_back
  %79 = getelementptr i8, ptr %cpu, i64 188
  %next_pc10 = load i32, ptr %79, align 4
  br label %chain_exit

cec_check2:                                       ; preds = %hwloop_end
  %80 = getelementptr i8, ptr %cpu, i32 188
  store i32 66464, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %82, align 4
  call void @cec_check_pending(ptr %cpu)
  br label %cec_checked3

cec_checked3:                                     ; preds = %cec_check2, %hwloop_end
  %83 = getelementptr i8, ptr %cpu, i32 296
  %dj6 = load i8, ptr %83, align 1
  %dj_set7 = icmp ne i8 %dj6, 0
  br i1 %dj_set7, label %did_jump_exit4, label %did_jump_cont5, !prof !1

did_jump_exit4:                                   ; preds = %cec_checked3
  %84 = getelementptr i8, ptr %cpu, i64 188
  %next_pc11 = load i32, ptr %84, align 4
  br label %chain_exit

did_jump_cont5:                                   ; preds = %cec_checked3
  br label %hwloop_done

insn_0x000103a0_entry:                            ; preds = %hwloop_done
  br label %insn_0x000103a0

insn_0x000103a0:                                  ; preds = %insn_0x000103a0_entry
  %85 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %85, align 4
  br label %insn_0x000103a2_entry

insn_0x000103a2_entry:                            ; preds = %insn_0x000103a0
  br label %insn_0x000103a2

insn_0x000103a2:                                  ; preds = %insn_0x000103a2_entry
  %86 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %87, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %88 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %88 monotonic, align 4, !range !3
  %89 = icmp ult i32 %chain_total, %chain_budget
  br i1 %89, label %chain_go, label %chain_leave12, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %90 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %90, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %insn_0x000103a2
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531264
  %91 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %91, align 4
  %92 = icmp eq i32 %slot_pc, 66408
  br i1 %92, label %chain_hit, label %chain_leave12, !prof !0

chain_leave12:                                    ; preds = %chain_go, %insn_0x000103a2
  %93 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %96, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %97 = getelementptr i8, ptr %cpu, i64 188
  store i32 66408, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %98, align 4
  %99 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %99, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit4, %cec_checked, %did_jump_exit, %data_misaligned
  %next_pc13 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc9, %did_jump_exit ], [ %next_pc10, %cec_checked ], [ %next_pc11, %did_jump_exit4 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %cec_checked ], [ 3, %did_jump_exit4 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %cec_checked ], [ 2, %did_jump_exit4 ]
  %tail14 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %cec_checked ], [ 3, %did_jump_exit4 ]
  %100 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets16 = load i32, ptr %100, align 4
  %chain_total17 = add nuw i32 %chain_packets16, %packets
  %101 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget18 = load atomic i32, ptr %101 monotonic, align 4, !range !3
  %102 = icmp ult i32 %chain_total17, %chain_budget18
  br i1 %102, label %chain_lookup, label %chain_leave15, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %103 = icmp eq i32 %next_pc13, 66458
  br i1 %103, label %chain_self, label %chain_other, !prof !2

chain_leave15:                                    ; preds = %chain_other, %chain_exit
  %104 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail14, ptr %105, align 4
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %106 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total17, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %107, align 1
  br label %insn_0x0001039a_entry

chain_other:                                      ; preds = %chain_lookup
  %108 = lshr i32 %next_pc13, 1
  %109 = and i32 %108, 65535
  %110 = zext i32 %109 to i64
  %111 = mul i64 %110, 16
  %chain_slot19 = getelementptr i8, ptr %chain_table, i64 %111
  %112 = getelementptr i8, ptr %chain_slot19, i64 0
  %slot_pc20 = load i32, ptr %112, align 4
  %113 = icmp eq i32 %slot_pc20, %next_pc13
  br i1 %113, label %chain_hit21, label %chain_leave15, !prof !0

chain_hit21:                                      ; preds = %chain_other
  %114 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total17, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %115, align 1
  %116 = getelementptr i8, ptr %chain_slot19, i64 8
  %chain_fn22 = load ptr, ptr %116, align 8
  musttail call swifttailcc void %chain_fn22(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave15, %chain_leave12, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{!"branch_weights", i32 63, i32 1}
!3 = !{i32 0, i32 -2147483648}
