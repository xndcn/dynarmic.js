
build-native-instruction-analysis/capture/bcore-default-stream/pc-65556-0-132432577692192.bin:     file format binary


Disassembly of section .data:

000078725cc00220 <.data>:
    78725cc00220:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    78725cc00227:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    78725cc0022e:	00 
    78725cc0022f:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    78725cc00236:	00 
    78725cc00237:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0023e:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    78725cc00245:	00 
    78725cc00246:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0024d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    78725cc00254:	00 
    78725cc00255:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0025c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    78725cc00263:	00 
    78725cc00264:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0026b:	00 
    78725cc0026c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc00272:	83 fa 00             	cmp    edx,0x0
    78725cc00275:	0f 94 c0             	sete   al
    78725cc00278:	81 ea 14 00 01 00    	sub    edx,0x10014
    78725cc0027e:	83 fa 2a             	cmp    edx,0x2a
    78725cc00281:	0f 97 c2             	seta   dl
    78725cc00284:	08 d0                	or     al,dl
    78725cc00286:	24 01                	and    al,0x1
    78725cc00288:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0028e:	83 fa 00             	cmp    edx,0x0
    78725cc00291:	0f 94 c1             	sete   cl
    78725cc00294:	81 ea 14 00 01 00    	sub    edx,0x10014
    78725cc0029a:	83 fa 2a             	cmp    edx,0x2a
    78725cc0029d:	0f 97 c2             	seta   dl
    78725cc002a0:	08 d1                	or     cl,dl
    78725cc002a2:	20 c8                	and    al,cl
    78725cc002a4:	a8 01                	test   al,0x1
    78725cc002a6:	75 05                	jne    0x78725cc002ad
    78725cc002a8:	e9 19 27 00 00       	jmp    0x78725cc029c6
    78725cc002ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc002b4:	00 
    78725cc002b5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc002bc:	48 89 c8             	mov    rax,rcx
    78725cc002bf:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc002c5:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    78725cc002cc:	00 
    78725cc002cd:	8b 81 04 00 10 00    	mov    eax,DWORD PTR [rcx+0x100004]
    78725cc002d3:	83 c0 01             	add    eax,0x1
    78725cc002d6:	89 81 04 00 10 00    	mov    DWORD PTR [rcx+0x100004],eax
    78725cc002dc:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc002e1:	75 4c                	jne    0x78725cc0032f
    78725cc002e3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    78725cc002ea:	00 
    78725cc002eb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc002f1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    78725cc002f8:	89 c2                	mov    edx,eax
    78725cc002fa:	83 c2 01             	add    edx,0x1
    78725cc002fd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc00303:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc00308:	73 23                	jae    0x78725cc0032d
    78725cc0030a:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    78725cc00311:	00 
    78725cc00312:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    78725cc00319:	89 c9                	mov    ecx,ecx
    78725cc0031b:	48 c1 e1 02          	shl    rcx,0x2
    78725cc0031f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc00326:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    78725cc0032d:	eb 00                	jmp    0x78725cc0032f
    78725cc0032f:	eb 00                	jmp    0x78725cc00331
    78725cc00331:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00338:	00 
    78725cc00339:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    78725cc0033c:	83 e8 04             	sub    eax,0x4
    78725cc0033f:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    78725cc00346:	8b 49 10             	mov    ecx,DWORD PTR [rcx+0x10]
    78725cc00349:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    78725cc00350:	83 e0 03             	and    eax,0x3
    78725cc00353:	83 f8 00             	cmp    eax,0x0
    78725cc00356:	0f 84 8e 00 00 00    	je     0x78725cc003ea
    78725cc0035c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00363:	00 
    78725cc00364:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc0036b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00372:	00 
    78725cc00373:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0037a:	00 00 00 
    78725cc0037d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00384:	00 00 00 
    78725cc00387:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0038e:	60 00 00 
    78725cc00391:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc00396:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0039c:	ff d0                	call   rax
    78725cc0039e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc003a5:	00 
    78725cc003a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc003ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc003b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc003b8:	be 01 00 00 00       	mov    esi,0x1
    78725cc003bd:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc003c2:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc003c9:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc003d0:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc003d7:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc003de:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc003e5:	e9 80 26 00 00       	jmp    0x78725cc02a6a
    78725cc003ea:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc003f1:	00 
    78725cc003f2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc003f9:	c1 e9 0c             	shr    ecx,0xc
    78725cc003fc:	89 c9                	mov    ecx,ecx
    78725cc003fe:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc00402:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    78725cc00409:	00 
    78725cc0040a:	48 83 f8 00          	cmp    rax,0x0
    78725cc0040e:	74 23                	je     0x78725cc00433
    78725cc00410:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    78725cc00417:	00 
    78725cc00418:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    78725cc0041f:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc00426:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0042c:	89 c9                	mov    ecx,ecx
    78725cc0042e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc00431:	eb 51                	jmp    0x78725cc00484
    78725cc00433:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0043a:	00 
    78725cc0043b:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    78725cc00442:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    78725cc00449:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc00450:	00 
    78725cc00451:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc00458:	00 00 00 
    78725cc0045b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00462:	00 00 00 
    78725cc00465:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0046c:	60 00 00 
    78725cc0046f:	ff d0                	call   rax
    78725cc00471:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00478:	00 
    78725cc00479:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00480:	75 32                	jne    0x78725cc004b4
    78725cc00482:	eb 7c                	jmp    0x78725cc00500
    78725cc00484:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0048b:	00 
    78725cc0048c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    78725cc00493:	83 e8 04             	sub    eax,0x4
    78725cc00496:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    78725cc0049d:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    78725cc004a0:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    78725cc004a7:	83 e0 03             	and    eax,0x3
    78725cc004aa:	83 f8 00             	cmp    eax,0x0
    78725cc004ad:	75 53                	jne    0x78725cc00502
    78725cc004af:	e9 dc 00 00 00       	jmp    0x78725cc00590
    78725cc004b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc004bb:	00 
    78725cc004bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc004c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc004c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc004ce:	be 01 00 00 00       	mov    esi,0x1
    78725cc004d3:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc004d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc004df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc004e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc004ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc004f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc004fb:	e9 6a 25 00 00       	jmp    0x78725cc02a6a
    78725cc00500:	eb 82                	jmp    0x78725cc00484
    78725cc00502:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00509:	00 
    78725cc0050a:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc00511:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00518:	00 
    78725cc00519:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc00520:	00 00 00 
    78725cc00523:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0052a:	00 00 00 
    78725cc0052d:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc00534:	60 00 00 
    78725cc00537:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc0053c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc00542:	ff d0                	call   rax
    78725cc00544:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0054b:	00 
    78725cc0054c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00552:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00558:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0055e:	be 01 00 00 00       	mov    esi,0x1
    78725cc00563:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00568:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0056f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00576:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0057d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00584:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0058b:	e9 da 24 00 00       	jmp    0x78725cc02a6a
    78725cc00590:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc00597:	00 
    78725cc00598:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc0059f:	c1 e9 0c             	shr    ecx,0xc
    78725cc005a2:	89 c9                	mov    ecx,ecx
    78725cc005a4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc005a8:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    78725cc005af:	00 
    78725cc005b0:	48 83 f8 00          	cmp    rax,0x0
    78725cc005b4:	74 23                	je     0x78725cc005d9
    78725cc005b6:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    78725cc005bd:	00 
    78725cc005be:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    78725cc005c5:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc005cc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc005d2:	89 c9                	mov    ecx,ecx
    78725cc005d4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc005d7:	eb 51                	jmp    0x78725cc0062a
    78725cc005d9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc005e0:	00 
    78725cc005e1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    78725cc005e8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    78725cc005ef:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc005f6:	00 
    78725cc005f7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc005fe:	00 00 00 
    78725cc00601:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00608:	00 00 00 
    78725cc0060b:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc00612:	60 00 00 
    78725cc00615:	ff d0                	call   rax
    78725cc00617:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0061e:	00 
    78725cc0061f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00626:	75 32                	jne    0x78725cc0065a
    78725cc00628:	eb 7c                	jmp    0x78725cc006a6
    78725cc0062a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00631:	00 
    78725cc00632:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    78725cc00639:	83 e8 04             	sub    eax,0x4
    78725cc0063c:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    78725cc00643:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    78725cc00646:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    78725cc0064d:	83 e0 03             	and    eax,0x3
    78725cc00650:	83 f8 00             	cmp    eax,0x0
    78725cc00653:	75 53                	jne    0x78725cc006a8
    78725cc00655:	e9 dc 00 00 00       	jmp    0x78725cc00736
    78725cc0065a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00661:	00 
    78725cc00662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0066e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00674:	be 01 00 00 00       	mov    esi,0x1
    78725cc00679:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0067e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0068c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0069a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc006a1:	e9 c4 23 00 00       	jmp    0x78725cc02a6a
    78725cc006a6:	eb 82                	jmp    0x78725cc0062a
    78725cc006a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc006af:	00 
    78725cc006b0:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc006b7:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc006be:	00 
    78725cc006bf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc006c6:	00 00 00 
    78725cc006c9:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc006d0:	00 00 00 
    78725cc006d3:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc006da:	60 00 00 
    78725cc006dd:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc006e2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc006e8:	ff d0                	call   rax
    78725cc006ea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc006f1:	00 
    78725cc006f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc006f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc006fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00704:	be 01 00 00 00       	mov    esi,0x1
    78725cc00709:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0070e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00715:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0071c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00723:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0072a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00731:	e9 34 23 00 00       	jmp    0x78725cc02a6a
    78725cc00736:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc0073d:	00 
    78725cc0073e:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc00745:	c1 e9 0c             	shr    ecx,0xc
    78725cc00748:	89 c9                	mov    ecx,ecx
    78725cc0074a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0074e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    78725cc00755:	00 
    78725cc00756:	48 83 f8 00          	cmp    rax,0x0
    78725cc0075a:	74 23                	je     0x78725cc0077f
    78725cc0075c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    78725cc00763:	00 
    78725cc00764:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    78725cc0076b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc00772:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc00778:	89 c9                	mov    ecx,ecx
    78725cc0077a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0077d:	eb 51                	jmp    0x78725cc007d0
    78725cc0077f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00786:	00 
    78725cc00787:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    78725cc0078e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    78725cc00795:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc0079c:	00 
    78725cc0079d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc007a4:	00 00 00 
    78725cc007a7:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc007ae:	00 00 00 
    78725cc007b1:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc007b8:	60 00 00 
    78725cc007bb:	ff d0                	call   rax
    78725cc007bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc007c4:	00 
    78725cc007c5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc007cc:	75 32                	jne    0x78725cc00800
    78725cc007ce:	eb 7c                	jmp    0x78725cc0084c
    78725cc007d0:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc007d7:	00 
    78725cc007d8:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    78725cc007df:	83 e8 04             	sub    eax,0x4
    78725cc007e2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    78725cc007e9:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    78725cc007ec:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    78725cc007f3:	83 e0 03             	and    eax,0x3
    78725cc007f6:	83 f8 00             	cmp    eax,0x0
    78725cc007f9:	75 53                	jne    0x78725cc0084e
    78725cc007fb:	e9 dc 00 00 00       	jmp    0x78725cc008dc
    78725cc00800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00807:	00 
    78725cc00808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0080e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0081a:	be 01 00 00 00       	mov    esi,0x1
    78725cc0081f:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0082b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00847:	e9 1e 22 00 00       	jmp    0x78725cc02a6a
    78725cc0084c:	eb 82                	jmp    0x78725cc007d0
    78725cc0084e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00855:	00 
    78725cc00856:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc0085d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00864:	00 
    78725cc00865:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0086c:	00 00 00 
    78725cc0086f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00876:	00 00 00 
    78725cc00879:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc00880:	60 00 00 
    78725cc00883:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc00888:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0088e:	ff d0                	call   rax
    78725cc00890:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00897:	00 
    78725cc00898:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0089e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc008a4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc008aa:	be 01 00 00 00       	mov    esi,0x1
    78725cc008af:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc008b4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc008bb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc008c2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc008c9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc008d0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc008d7:	e9 8e 21 00 00       	jmp    0x78725cc02a6a
    78725cc008dc:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc008e3:	00 
    78725cc008e4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc008eb:	c1 e9 0c             	shr    ecx,0xc
    78725cc008ee:	89 c9                	mov    ecx,ecx
    78725cc008f0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc008f4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    78725cc008fb:	00 
    78725cc008fc:	48 83 f8 00          	cmp    rax,0x0
    78725cc00900:	74 23                	je     0x78725cc00925
    78725cc00902:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc00909:	00 
    78725cc0090a:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    78725cc00911:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc00918:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0091e:	89 c9                	mov    ecx,ecx
    78725cc00920:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc00923:	eb 51                	jmp    0x78725cc00976
    78725cc00925:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0092c:	00 
    78725cc0092d:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    78725cc00934:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    78725cc0093b:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc00942:	00 
    78725cc00943:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0094a:	00 00 00 
    78725cc0094d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00954:	00 00 00 
    78725cc00957:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0095e:	60 00 00 
    78725cc00961:	ff d0                	call   rax
    78725cc00963:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0096a:	00 
    78725cc0096b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00972:	75 32                	jne    0x78725cc009a6
    78725cc00974:	eb 7c                	jmp    0x78725cc009f2
    78725cc00976:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0097d:	00 
    78725cc0097e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    78725cc00985:	83 e8 04             	sub    eax,0x4
    78725cc00988:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    78725cc0098f:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    78725cc00992:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    78725cc00999:	83 e0 03             	and    eax,0x3
    78725cc0099c:	83 f8 00             	cmp    eax,0x0
    78725cc0099f:	75 53                	jne    0x78725cc009f4
    78725cc009a1:	e9 dc 00 00 00       	jmp    0x78725cc00a82
    78725cc009a6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc009ad:	00 
    78725cc009ae:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc009b4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc009ba:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc009c0:	be 01 00 00 00       	mov    esi,0x1
    78725cc009c5:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc009ca:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc009d1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc009d8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc009df:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc009e6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc009ed:	e9 78 20 00 00       	jmp    0x78725cc02a6a
    78725cc009f2:	eb 82                	jmp    0x78725cc00976
    78725cc009f4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc009fb:	00 
    78725cc009fc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc00a03:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00a0a:	00 
    78725cc00a0b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc00a12:	00 00 00 
    78725cc00a15:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00a1c:	00 00 00 
    78725cc00a1f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc00a26:	60 00 00 
    78725cc00a29:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc00a2e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc00a34:	ff d0                	call   rax
    78725cc00a36:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00a3d:	00 
    78725cc00a3e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00a44:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00a4a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00a50:	be 01 00 00 00       	mov    esi,0x1
    78725cc00a55:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00a5a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00a61:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00a68:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00a6f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00a76:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00a7d:	e9 e8 1f 00 00       	jmp    0x78725cc02a6a
    78725cc00a82:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc00a89:	00 
    78725cc00a8a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc00a91:	c1 e9 0c             	shr    ecx,0xc
    78725cc00a94:	89 c9                	mov    ecx,ecx
    78725cc00a96:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc00a9a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    78725cc00aa1:	00 
    78725cc00aa2:	48 83 f8 00          	cmp    rax,0x0
    78725cc00aa6:	74 23                	je     0x78725cc00acb
    78725cc00aa8:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    78725cc00aaf:	00 
    78725cc00ab0:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    78725cc00ab7:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc00abe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc00ac4:	89 c9                	mov    ecx,ecx
    78725cc00ac6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc00ac9:	eb 51                	jmp    0x78725cc00b1c
    78725cc00acb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00ad2:	00 
    78725cc00ad3:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    78725cc00ada:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    78725cc00ae1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc00ae8:	00 
    78725cc00ae9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc00af0:	00 00 00 
    78725cc00af3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00afa:	00 00 00 
    78725cc00afd:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc00b04:	60 00 00 
    78725cc00b07:	ff d0                	call   rax
    78725cc00b09:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00b10:	00 
    78725cc00b11:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00b18:	75 32                	jne    0x78725cc00b4c
    78725cc00b1a:	eb 7c                	jmp    0x78725cc00b98
    78725cc00b1c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00b23:	00 
    78725cc00b24:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    78725cc00b2b:	83 e8 04             	sub    eax,0x4
    78725cc00b2e:	89 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],eax
    78725cc00b35:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    78725cc00b38:	89 8c 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],ecx
    78725cc00b3f:	83 e0 03             	and    eax,0x3
    78725cc00b42:	83 f8 00             	cmp    eax,0x0
    78725cc00b45:	75 53                	jne    0x78725cc00b9a
    78725cc00b47:	e9 dc 00 00 00       	jmp    0x78725cc00c28
    78725cc00b4c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00b53:	00 
    78725cc00b54:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00b5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00b60:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00b66:	be 01 00 00 00       	mov    esi,0x1
    78725cc00b6b:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00b70:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00b77:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00b7e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00b85:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00b8c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00b93:	e9 d2 1e 00 00       	jmp    0x78725cc02a6a
    78725cc00b98:	eb 82                	jmp    0x78725cc00b1c
    78725cc00b9a:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00ba1:	00 
    78725cc00ba2:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    78725cc00ba9:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00bb0:	00 
    78725cc00bb1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc00bb8:	00 00 00 
    78725cc00bbb:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00bc2:	00 00 00 
    78725cc00bc5:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc00bcc:	60 00 00 
    78725cc00bcf:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc00bd4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc00bda:	ff d0                	call   rax
    78725cc00bdc:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00be3:	00 
    78725cc00be4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00bea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00bf0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00bf6:	be 01 00 00 00       	mov    esi,0x1
    78725cc00bfb:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00c00:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00c07:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00c0e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00c15:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00c1c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00c23:	e9 42 1e 00 00       	jmp    0x78725cc02a6a
    78725cc00c28:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc00c2f:	00 
    78725cc00c30:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    78725cc00c37:	c1 e9 0c             	shr    ecx,0xc
    78725cc00c3a:	89 c9                	mov    ecx,ecx
    78725cc00c3c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc00c40:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
    78725cc00c47:	00 
    78725cc00c48:	48 83 f8 00          	cmp    rax,0x0
    78725cc00c4c:	74 23                	je     0x78725cc00c71
    78725cc00c4e:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc00c55:	00 
    78725cc00c56:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    78725cc00c5d:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    78725cc00c64:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc00c6a:	89 c9                	mov    ecx,ecx
    78725cc00c6c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc00c6f:	eb 51                	jmp    0x78725cc00cc2
    78725cc00c71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00c78:	00 
    78725cc00c79:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    78725cc00c80:	8b b4 24 78 01 00 00 	mov    esi,DWORD PTR [rsp+0x178]
    78725cc00c87:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc00c8e:	00 
    78725cc00c8f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc00c96:	00 00 00 
    78725cc00c99:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00ca0:	00 00 00 
    78725cc00ca3:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc00caa:	60 00 00 
    78725cc00cad:	ff d0                	call   rax
    78725cc00caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00cb6:	00 
    78725cc00cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00cbe:	75 32                	jne    0x78725cc00cf2
    78725cc00cc0:	eb 7c                	jmp    0x78725cc00d3e
    78725cc00cc2:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00cc9:	00 
    78725cc00cca:	8b 84 24 78 01 00 00 	mov    eax,DWORD PTR [rsp+0x178]
    78725cc00cd1:	83 e8 04             	sub    eax,0x4
    78725cc00cd4:	89 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],eax
    78725cc00cdb:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    78725cc00cde:	89 8c 24 6c 01 00 00 	mov    DWORD PTR [rsp+0x16c],ecx
    78725cc00ce5:	83 e0 03             	and    eax,0x3
    78725cc00ce8:	83 f8 00             	cmp    eax,0x0
    78725cc00ceb:	75 53                	jne    0x78725cc00d40
    78725cc00ced:	e9 dc 00 00 00       	jmp    0x78725cc00dce
    78725cc00cf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00cf9:	00 
    78725cc00cfa:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00d00:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00d06:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00d0c:	be 01 00 00 00       	mov    esi,0x1
    78725cc00d11:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00d16:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00d1d:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00d24:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00d2b:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00d32:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00d39:	e9 2c 1d 00 00       	jmp    0x78725cc02a6a
    78725cc00d3e:	eb 82                	jmp    0x78725cc00cc2
    78725cc00d40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00d47:	00 
    78725cc00d48:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    78725cc00d4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00d56:	00 
    78725cc00d57:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc00d5e:	00 00 00 
    78725cc00d61:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00d68:	00 00 00 
    78725cc00d6b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc00d72:	60 00 00 
    78725cc00d75:	ba 14 00 01 00       	mov    edx,0x10014
    78725cc00d7a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc00d80:	ff d0                	call   rax
    78725cc00d82:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00d89:	00 
    78725cc00d8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00d90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00d96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00d9c:	be 01 00 00 00       	mov    esi,0x1
    78725cc00da1:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00da6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00dad:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00db4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00dbb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00dc2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00dc9:	e9 9c 1c 00 00       	jmp    0x78725cc02a6a
    78725cc00dce:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc00dd5:	00 
    78725cc00dd6:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    78725cc00ddd:	c1 e9 0c             	shr    ecx,0xc
    78725cc00de0:	89 c9                	mov    ecx,ecx
    78725cc00de2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc00de6:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    78725cc00ded:	00 
    78725cc00dee:	48 83 f8 00          	cmp    rax,0x0
    78725cc00df2:	74 23                	je     0x78725cc00e17
    78725cc00df4:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    78725cc00dfb:	00 
    78725cc00dfc:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    78725cc00e03:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    78725cc00e0a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc00e10:	89 c9                	mov    ecx,ecx
    78725cc00e12:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc00e15:	eb 51                	jmp    0x78725cc00e68
    78725cc00e17:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00e1e:	00 
    78725cc00e1f:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    78725cc00e26:	8b b4 24 68 01 00 00 	mov    esi,DWORD PTR [rsp+0x168]
    78725cc00e2d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc00e34:	00 
    78725cc00e35:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc00e3c:	00 00 00 
    78725cc00e3f:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc00e46:	00 00 00 
    78725cc00e49:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc00e50:	60 00 00 
    78725cc00e53:	ff d0                	call   rax
    78725cc00e55:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00e5c:	00 
    78725cc00e5d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00e64:	75 26                	jne    0x78725cc00e8c
    78725cc00e66:	eb 70                	jmp    0x78725cc00ed8
    78725cc00e68:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc00e6f:	00 
    78725cc00e70:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00e77:	00 
    78725cc00e78:	8b 94 24 68 01 00 00 	mov    edx,DWORD PTR [rsp+0x168]
    78725cc00e7f:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc00e82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc00e85:	75 53                	jne    0x78725cc00eda
    78725cc00e87:	e9 93 00 00 00       	jmp    0x78725cc00f1f
    78725cc00e8c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00e93:	00 
    78725cc00e94:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00e9a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00ea0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00ea6:	be 01 00 00 00       	mov    esi,0x1
    78725cc00eab:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00eb0:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00eb7:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00ebe:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00ec5:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00ecc:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00ed3:	e9 92 1b 00 00       	jmp    0x78725cc02a6a
    78725cc00ed8:	eb 8e                	jmp    0x78725cc00e68
    78725cc00eda:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00ee1:	00 
    78725cc00ee2:	c7 87 bc 00 00 00 16 	mov    DWORD PTR [rdi+0xbc],0x10016
    78725cc00ee9:	00 01 00 
    78725cc00eec:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc00ef3:	00 00 00 
    78725cc00ef6:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc00efd:	00 00 00 
    78725cc00f00:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc00f07:	60 00 00 
    78725cc00f0a:	ff d0                	call   rax
    78725cc00f0c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00f13:	00 
    78725cc00f14:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc00f1b:	75 04                	jne    0x78725cc00f21
    78725cc00f1d:	eb 4e                	jmp    0x78725cc00f6d
    78725cc00f1f:	eb 4e                	jmp    0x78725cc00f6f
    78725cc00f21:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00f28:	00 
    78725cc00f29:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc00f2f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc00f35:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc00f3b:	be 01 00 00 00       	mov    esi,0x1
    78725cc00f40:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc00f45:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc00f4c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc00f53:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc00f5a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc00f61:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc00f68:	e9 fd 1a 00 00       	jmp    0x78725cc02a6a
    78725cc00f6d:	eb b0                	jmp    0x78725cc00f1f
    78725cc00f6f:	eb 00                	jmp    0x78725cc00f71
    78725cc00f71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc00f78:	00 
    78725cc00f79:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    78725cc00f7c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc00f82:	83 c9 00             	or     ecx,0x0
    78725cc00f85:	89 8c 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],ecx
    78725cc00f8c:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc00f8f:	eb 00                	jmp    0x78725cc00f91
    78725cc00f91:	8b 84 24 68 01 00 00 	mov    eax,DWORD PTR [rsp+0x168]
    78725cc00f98:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc00f9f:	00 
    78725cc00fa0:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    78725cc00fa6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc00fad:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    78725cc00fb0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc00fb7:	83 e8 04             	sub    eax,0x4
    78725cc00fba:	89 84 24 58 01 00 00 	mov    DWORD PTR [rsp+0x158],eax
    78725cc00fc1:	83 e0 03             	and    eax,0x3
    78725cc00fc4:	83 f8 00             	cmp    eax,0x0
    78725cc00fc7:	0f 84 98 00 00 00    	je     0x78725cc01065
    78725cc00fcd:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc00fd4:	00 
    78725cc00fd5:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    78725cc00fdc:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc00fe3:	00 
    78725cc00fe4:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    78725cc00feb:	00 01 00 
    78725cc00fee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc00ff5:	00 00 00 
    78725cc00ff8:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc00fff:	00 00 00 
    78725cc01002:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc01009:	60 00 00 
    78725cc0100c:	ba 1a 00 01 00       	mov    edx,0x1001a
    78725cc01011:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc01017:	ff d0                	call   rax
    78725cc01019:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01020:	00 
    78725cc01021:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01027:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0102d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01033:	be 03 00 00 00       	mov    esi,0x3
    78725cc01038:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0103d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01044:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0104b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01052:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01059:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01060:	e9 05 1a 00 00       	jmp    0x78725cc02a6a
    78725cc01065:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc0106c:	00 
    78725cc0106d:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    78725cc01074:	c1 e9 0c             	shr    ecx,0xc
    78725cc01077:	89 c9                	mov    ecx,ecx
    78725cc01079:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0107d:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
    78725cc01084:	00 
    78725cc01085:	48 83 f8 00          	cmp    rax,0x0
    78725cc01089:	74 23                	je     0x78725cc010ae
    78725cc0108b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    78725cc01092:	00 
    78725cc01093:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    78725cc0109a:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    78725cc010a1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc010a7:	89 c9                	mov    ecx,ecx
    78725cc010a9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc010ac:	eb 5b                	jmp    0x78725cc01109
    78725cc010ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc010b5:	00 
    78725cc010b6:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    78725cc010bd:	8b b4 24 58 01 00 00 	mov    esi,DWORD PTR [rsp+0x158]
    78725cc010c4:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc010cb:	00 
    78725cc010cc:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    78725cc010d3:	00 01 00 
    78725cc010d6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc010dd:	00 00 00 
    78725cc010e0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc010e7:	00 00 00 
    78725cc010ea:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc010f1:	60 00 00 
    78725cc010f4:	ff d0                	call   rax
    78725cc010f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc010fd:	00 
    78725cc010fe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01105:	75 20                	jne    0x78725cc01127
    78725cc01107:	eb 6a                	jmp    0x78725cc01173
    78725cc01109:	8b 84 24 58 01 00 00 	mov    eax,DWORD PTR [rsp+0x158]
    78725cc01110:	83 e8 04             	sub    eax,0x4
    78725cc01113:	89 84 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],eax
    78725cc0111a:	83 e0 03             	and    eax,0x3
    78725cc0111d:	83 f8 00             	cmp    eax,0x0
    78725cc01120:	75 53                	jne    0x78725cc01175
    78725cc01122:	e9 e6 00 00 00       	jmp    0x78725cc0120d
    78725cc01127:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0112e:	00 
    78725cc0112f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01135:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0113b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01141:	be 03 00 00 00       	mov    esi,0x3
    78725cc01146:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0114b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01152:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01159:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01160:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01167:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0116e:	e9 f7 18 00 00       	jmp    0x78725cc02a6a
    78725cc01173:	eb 94                	jmp    0x78725cc01109
    78725cc01175:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0117c:	00 
    78725cc0117d:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc01184:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc0118b:	00 
    78725cc0118c:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    78725cc01193:	00 01 00 
    78725cc01196:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0119d:	00 00 00 
    78725cc011a0:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc011a7:	00 00 00 
    78725cc011aa:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc011b1:	60 00 00 
    78725cc011b4:	ba 1a 00 01 00       	mov    edx,0x1001a
    78725cc011b9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc011bf:	ff d0                	call   rax
    78725cc011c1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc011c8:	00 
    78725cc011c9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc011cf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc011d5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc011db:	be 03 00 00 00       	mov    esi,0x3
    78725cc011e0:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc011e5:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc011ec:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc011f3:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc011fa:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01201:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01208:	e9 5d 18 00 00       	jmp    0x78725cc02a6a
    78725cc0120d:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc01214:	00 
    78725cc01215:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc0121c:	c1 e9 0c             	shr    ecx,0xc
    78725cc0121f:	89 c9                	mov    ecx,ecx
    78725cc01221:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc01225:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    78725cc0122c:	00 
    78725cc0122d:	48 83 f8 00          	cmp    rax,0x0
    78725cc01231:	74 23                	je     0x78725cc01256
    78725cc01233:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    78725cc0123a:	00 
    78725cc0123b:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    78725cc01242:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc01249:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0124f:	89 c9                	mov    ecx,ecx
    78725cc01251:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc01254:	eb 5b                	jmp    0x78725cc012b1
    78725cc01256:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0125d:	00 
    78725cc0125e:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    78725cc01265:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    78725cc0126c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01273:	00 
    78725cc01274:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    78725cc0127b:	00 01 00 
    78725cc0127e:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc01285:	00 00 00 
    78725cc01288:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc0128f:	00 00 00 
    78725cc01292:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc01299:	60 00 00 
    78725cc0129c:	ff d0                	call   rax
    78725cc0129e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc012a5:	00 
    78725cc012a6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc012ad:	75 2c                	jne    0x78725cc012db
    78725cc012af:	eb 76                	jmp    0x78725cc01327
    78725cc012b1:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc012b8:	00 
    78725cc012b9:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc012c0:	00 
    78725cc012c1:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    78725cc012c8:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    78725cc012cb:	83 ea 14             	sub    edx,0x14
    78725cc012ce:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc012d1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc012d4:	75 53                	jne    0x78725cc01329
    78725cc012d6:	e9 93 00 00 00       	jmp    0x78725cc0136e
    78725cc012db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc012e2:	00 
    78725cc012e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc012e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc012ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc012f5:	be 03 00 00 00       	mov    esi,0x3
    78725cc012fa:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc012ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01306:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0130d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01314:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0131b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01322:	e9 43 17 00 00       	jmp    0x78725cc02a6a
    78725cc01327:	eb 88                	jmp    0x78725cc012b1
    78725cc01329:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01330:	00 
    78725cc01331:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1001e
    78725cc01338:	00 01 00 
    78725cc0133b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc01342:	00 00 00 
    78725cc01345:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc0134c:	00 00 00 
    78725cc0134f:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc01356:	60 00 00 
    78725cc01359:	ff d0                	call   rax
    78725cc0135b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01362:	00 
    78725cc01363:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0136a:	75 04                	jne    0x78725cc01370
    78725cc0136c:	eb 4e                	jmp    0x78725cc013bc
    78725cc0136e:	eb 4e                	jmp    0x78725cc013be
    78725cc01370:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01377:	00 
    78725cc01378:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0137e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01384:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0138a:	be 03 00 00 00       	mov    esi,0x3
    78725cc0138f:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc01394:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0139b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc013a2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc013a9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc013b0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc013b7:	e9 ae 16 00 00       	jmp    0x78725cc02a6a
    78725cc013bc:	eb b0                	jmp    0x78725cc0136e
    78725cc013be:	eb 00                	jmp    0x78725cc013c0
    78725cc013c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc013c7:	00 
    78725cc013c8:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    78725cc013cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc013d5:	81 c9 00 f0 00 00    	or     ecx,0xf000
    78725cc013db:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc013e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc013e5:	eb 00                	jmp    0x78725cc013e7
    78725cc013e7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc013ee:	00 
    78725cc013ef:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    78725cc013f2:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc013f8:	81 c9 00 00 42 43    	or     ecx,0x43420000
    78725cc013fe:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    78725cc01405:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc01408:	eb 00                	jmp    0x78725cc0140a
    78725cc0140a:	8b 84 24 34 01 00 00 	mov    eax,DWORD PTR [rsp+0x134]
    78725cc01411:	83 e0 03             	and    eax,0x3
    78725cc01414:	83 f8 00             	cmp    eax,0x0
    78725cc01417:	0f 84 97 00 00 00    	je     0x78725cc014b4
    78725cc0141d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01424:	00 
    78725cc01425:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    78725cc0142c:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01433:	00 
    78725cc01434:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10026
    78725cc0143b:	00 01 00 
    78725cc0143e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc01445:	00 00 00 
    78725cc01448:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    78725cc0144f:	00 00 00 
    78725cc01452:	31 c0                	xor    eax,eax
    78725cc01454:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0145b:	60 00 00 
    78725cc0145e:	ba 26 00 01 00       	mov    edx,0x10026
    78725cc01463:	45 31 c0             	xor    r8d,r8d
    78725cc01466:	ff d0                	call   rax
    78725cc01468:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0146f:	00 
    78725cc01470:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01476:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0147c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01482:	be 06 00 00 00       	mov    esi,0x6
    78725cc01487:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0148c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01493:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0149a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc014a1:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc014a8:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc014af:	e9 b6 15 00 00       	jmp    0x78725cc02a6a
    78725cc014b4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc014bb:	00 
    78725cc014bc:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    78725cc014c3:	c1 e9 0c             	shr    ecx,0xc
    78725cc014c6:	89 c9                	mov    ecx,ecx
    78725cc014c8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc014cc:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    78725cc014d3:	00 
    78725cc014d4:	48 83 f8 00          	cmp    rax,0x0
    78725cc014d8:	74 23                	je     0x78725cc014fd
    78725cc014da:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    78725cc014e1:	00 
    78725cc014e2:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    78725cc014e9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc014ef:	89 c9                	mov    ecx,ecx
    78725cc014f1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc014f4:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    78725cc014fb:	eb 5d                	jmp    0x78725cc0155a
    78725cc014fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01504:	00 
    78725cc01505:	8b b4 24 34 01 00 00 	mov    esi,DWORD PTR [rsp+0x134]
    78725cc0150c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01513:	00 
    78725cc01514:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10026
    78725cc0151b:	00 01 00 
    78725cc0151e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc01525:	00 00 00 
    78725cc01528:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    78725cc0152f:	00 00 00 
    78725cc01532:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc01539:	60 00 00 
    78725cc0153c:	ff d0                	call   rax
    78725cc0153e:	89 c1                	mov    ecx,eax
    78725cc01540:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01547:	00 
    78725cc01548:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    78725cc0154f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01556:	75 1c                	jne    0x78725cc01574
    78725cc01558:	eb 66                	jmp    0x78725cc015c0
    78725cc0155a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01561:	00 
    78725cc01562:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    78725cc01569:	89 8c 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],ecx
    78725cc01570:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc01572:	eb 5c                	jmp    0x78725cc015d0
    78725cc01574:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0157b:	00 
    78725cc0157c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01582:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01588:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0158e:	be 06 00 00 00       	mov    esi,0x6
    78725cc01593:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc01598:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0159f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc015a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc015ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc015b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc015bb:	e9 aa 14 00 00       	jmp    0x78725cc02a6a
    78725cc015c0:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    78725cc015c7:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    78725cc015ce:	eb 8a                	jmp    0x78725cc0155a
    78725cc015d0:	eb 00                	jmp    0x78725cc015d2
    78725cc015d2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc015d9:	00 
    78725cc015da:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    78725cc015e1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc015e7:	81 c9 31 4e 00 00    	or     ecx,0x4e31
    78725cc015ed:	89 8c 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],ecx
    78725cc015f4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc015f7:	eb 00                	jmp    0x78725cc015f9
    78725cc015f9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01600:	00 
    78725cc01601:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    78725cc01608:	8b bc 24 1c 01 00 00 	mov    edi,DWORD PTR [rsp+0x11c]
    78725cc0160f:	89 fa                	mov    edx,edi
    78725cc01611:	29 ca                	sub    edx,ecx
    78725cc01613:	83 fa 00             	cmp    edx,0x0
    78725cc01616:	0f 94 c3             	sete   bl
    78725cc01619:	80 e3 01             	and    bl,0x1
    78725cc0161c:	0f b6 f3             	movzx  esi,bl
    78725cc0161f:	89 b4 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],esi
    78725cc01626:	c1 ea 1f             	shr    edx,0x1f
    78725cc01629:	89 fb                	mov    ebx,edi
    78725cc0162b:	c1 eb 1f             	shr    ebx,0x1f
    78725cc0162e:	41 89 c8             	mov    r8d,ecx
    78725cc01631:	41 c1 e8 1f          	shr    r8d,0x1f
    78725cc01635:	89 d5                	mov    ebp,edx
    78725cc01637:	31 dd                	xor    ebp,ebx
    78725cc01639:	44 31 c3             	xor    ebx,r8d
    78725cc0163c:	21 eb                	and    ebx,ebp
    78725cc0163e:	31 da                	xor    edx,ebx
    78725cc01640:	39 f9                	cmp    ecx,edi
    78725cc01642:	0f 96 c1             	setbe  cl
    78725cc01645:	80 e1 01             	and    cl,0x1
    78725cc01648:	0f b6 c9             	movzx  ecx,cl
    78725cc0164b:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc01651:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc01657:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0165d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc01663:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc01669:	eb 00                	jmp    0x78725cc0166b
    78725cc0166b:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    78725cc01672:	83 f8 00             	cmp    eax,0x0
    78725cc01675:	74 33                	je     0x78725cc016aa
    78725cc01677:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0167e:	00 
    78725cc0167f:	c7 81 bc 00 00 00 40 	mov    DWORD PTR [rcx+0xbc],0x10040
    78725cc01686:	00 01 00 
    78725cc01689:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0168f:	83 c0 09             	add    eax,0x9
    78725cc01692:	89 84 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],eax
    78725cc01699:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0169f:	0f 82 35 13 00 00    	jb     0x78725cc029da
    78725cc016a5:	e9 53 13 00 00       	jmp    0x78725cc029fd
    78725cc016aa:	eb 00                	jmp    0x78725cc016ac
    78725cc016ac:	eb 00                	jmp    0x78725cc016ae
    78725cc016ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc016b5:	00 
    78725cc016b6:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    78725cc016bc:	eb 00                	jmp    0x78725cc016be
    78725cc016be:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc016c5:	00 
    78725cc016c6:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    78725cc016cd:	83 c1 10             	add    ecx,0x10
    78725cc016d0:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    78725cc016d7:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc016da:	eb 00                	jmp    0x78725cc016dc
    78725cc016dc:	8b 84 24 0c 01 00 00 	mov    eax,DWORD PTR [rsp+0x10c]
    78725cc016e3:	83 e0 03             	and    eax,0x3
    78725cc016e6:	83 f8 00             	cmp    eax,0x0
    78725cc016e9:	0f 84 98 00 00 00    	je     0x78725cc01787
    78725cc016ef:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc016f6:	00 
    78725cc016f7:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    78725cc016fe:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01705:	00 
    78725cc01706:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10034
    78725cc0170d:	00 01 00 
    78725cc01710:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc01717:	00 00 00 
    78725cc0171a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    78725cc01721:	00 00 00 
    78725cc01724:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0172b:	60 00 00 
    78725cc0172e:	ba 34 00 01 00       	mov    edx,0x10034
    78725cc01733:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc01739:	ff d0                	call   rax
    78725cc0173b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01742:	00 
    78725cc01743:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01749:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0174f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01755:	be 0c 00 00 00       	mov    esi,0xc
    78725cc0175a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0175f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01766:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0176d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01774:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0177b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01782:	e9 e3 12 00 00       	jmp    0x78725cc02a6a
    78725cc01787:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc0178e:	00 
    78725cc0178f:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    78725cc01796:	c1 e9 0c             	shr    ecx,0xc
    78725cc01799:	89 c9                	mov    ecx,ecx
    78725cc0179b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0179f:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    78725cc017a6:	00 
    78725cc017a7:	48 83 f8 00          	cmp    rax,0x0
    78725cc017ab:	74 20                	je     0x78725cc017cd
    78725cc017ad:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc017b4:	00 
    78725cc017b5:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    78725cc017bc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc017c2:	89 c9                	mov    ecx,ecx
    78725cc017c4:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    78725cc017cb:	eb 59                	jmp    0x78725cc01826
    78725cc017cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc017d4:	00 
    78725cc017d5:	8b b4 24 0c 01 00 00 	mov    esi,DWORD PTR [rsp+0x10c]
    78725cc017dc:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc017e3:	00 
    78725cc017e4:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10034
    78725cc017eb:	00 01 00 
    78725cc017ee:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc017f5:	00 00 00 
    78725cc017f8:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    78725cc017ff:	00 00 00 
    78725cc01802:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc01809:	60 00 00 
    78725cc0180c:	ba 03 00 00 00       	mov    edx,0x3
    78725cc01811:	ff d0                	call   rax
    78725cc01813:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0181a:	00 
    78725cc0181b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01822:	75 14                	jne    0x78725cc01838
    78725cc01824:	eb 5e                	jmp    0x78725cc01884
    78725cc01826:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc0182d:	00 
    78725cc0182e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc01831:	75 53                	jne    0x78725cc01886
    78725cc01833:	e9 93 00 00 00       	jmp    0x78725cc018cb
    78725cc01838:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0183f:	00 
    78725cc01840:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01846:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0184c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01852:	be 0c 00 00 00       	mov    esi,0xc
    78725cc01857:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0185c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01863:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0186a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01871:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01878:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0187f:	e9 e6 11 00 00       	jmp    0x78725cc02a6a
    78725cc01884:	eb a0                	jmp    0x78725cc01826
    78725cc01886:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0188d:	00 
    78725cc0188e:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10036
    78725cc01895:	00 01 00 
    78725cc01898:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0189f:	00 00 00 
    78725cc018a2:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    78725cc018a9:	00 00 00 
    78725cc018ac:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc018b3:	60 00 00 
    78725cc018b6:	ff d0                	call   rax
    78725cc018b8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc018bf:	00 
    78725cc018c0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc018c7:	75 04                	jne    0x78725cc018cd
    78725cc018c9:	eb 4e                	jmp    0x78725cc01919
    78725cc018cb:	eb 4e                	jmp    0x78725cc0191b
    78725cc018cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc018d4:	00 
    78725cc018d5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc018db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc018e1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc018e7:	be 0c 00 00 00       	mov    esi,0xc
    78725cc018ec:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc018f1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc018f8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc018ff:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01906:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0190d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01914:	e9 51 11 00 00       	jmp    0x78725cc02a6a
    78725cc01919:	eb b0                	jmp    0x78725cc018cb
    78725cc0191b:	eb 00                	jmp    0x78725cc0191d
    78725cc0191d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01924:	00 
    78725cc01925:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    78725cc0192b:	eb 00                	jmp    0x78725cc0192d
    78725cc0192d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    78725cc01934:	83 e0 03             	and    eax,0x3
    78725cc01937:	83 f8 00             	cmp    eax,0x0
    78725cc0193a:	0f 84 97 00 00 00    	je     0x78725cc019d7
    78725cc01940:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01947:	00 
    78725cc01948:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc0194f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01956:	00 
    78725cc01957:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    78725cc0195e:	00 01 00 
    78725cc01961:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc01968:	00 00 00 
    78725cc0196b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc01972:	00 00 00 
    78725cc01975:	31 c0                	xor    eax,eax
    78725cc01977:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0197e:	60 00 00 
    78725cc01981:	ba 38 00 01 00       	mov    edx,0x10038
    78725cc01986:	45 31 c0             	xor    r8d,r8d
    78725cc01989:	ff d0                	call   rax
    78725cc0198b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01992:	00 
    78725cc01993:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01999:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0199f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc019a5:	be 0e 00 00 00       	mov    esi,0xe
    78725cc019aa:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc019af:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc019b6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc019bd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc019c4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc019cb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc019d2:	e9 93 10 00 00       	jmp    0x78725cc02a6a
    78725cc019d7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc019de:	00 
    78725cc019df:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc019e6:	c1 e9 0c             	shr    ecx,0xc
    78725cc019e9:	89 c9                	mov    ecx,ecx
    78725cc019eb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc019ef:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    78725cc019f6:	00 
    78725cc019f7:	48 83 f8 00          	cmp    rax,0x0
    78725cc019fb:	74 23                	je     0x78725cc01a20
    78725cc019fd:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    78725cc01a04:	00 
    78725cc01a05:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc01a0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc01a12:	89 c9                	mov    ecx,ecx
    78725cc01a14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc01a17:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    78725cc01a1e:	eb 5d                	jmp    0x78725cc01a7d
    78725cc01a20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01a27:	00 
    78725cc01a28:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    78725cc01a2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01a36:	00 
    78725cc01a37:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    78725cc01a3e:	00 01 00 
    78725cc01a41:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc01a48:	00 00 00 
    78725cc01a4b:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc01a52:	00 00 00 
    78725cc01a55:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc01a5c:	60 00 00 
    78725cc01a5f:	ff d0                	call   rax
    78725cc01a61:	89 c1                	mov    ecx,eax
    78725cc01a63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01a6a:	00 
    78725cc01a6b:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    78725cc01a72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01a79:	75 2e                	jne    0x78725cc01aa9
    78725cc01a7b:	eb 78                	jmp    0x78725cc01af5
    78725cc01a7d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    78725cc01a84:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    78725cc01a8b:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    78725cc01a92:	83 c0 04             	add    eax,0x4
    78725cc01a95:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    78725cc01a9c:	83 e0 03             	and    eax,0x3
    78725cc01a9f:	83 f8 00             	cmp    eax,0x0
    78725cc01aa2:	75 64                	jne    0x78725cc01b08
    78725cc01aa4:	e9 f6 00 00 00       	jmp    0x78725cc01b9f
    78725cc01aa9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01ab0:	00 
    78725cc01ab1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01ab7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01abd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01ac3:	be 0e 00 00 00       	mov    esi,0xe
    78725cc01ac8:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc01acd:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01ad4:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01adb:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01ae2:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01ae9:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01af0:	e9 75 0f 00 00       	jmp    0x78725cc02a6a
    78725cc01af5:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    78725cc01afc:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    78725cc01b03:	e9 75 ff ff ff       	jmp    0x78725cc01a7d
    78725cc01b08:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01b0f:	00 
    78725cc01b10:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc01b17:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01b1e:	00 
    78725cc01b1f:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    78725cc01b26:	00 01 00 
    78725cc01b29:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc01b30:	00 00 00 
    78725cc01b33:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc01b3a:	00 00 00 
    78725cc01b3d:	31 c0                	xor    eax,eax
    78725cc01b3f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc01b46:	60 00 00 
    78725cc01b49:	ba 38 00 01 00       	mov    edx,0x10038
    78725cc01b4e:	45 31 c0             	xor    r8d,r8d
    78725cc01b51:	ff d0                	call   rax
    78725cc01b53:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01b5a:	00 
    78725cc01b5b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01b61:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01b67:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01b6d:	be 0e 00 00 00       	mov    esi,0xe
    78725cc01b72:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc01b77:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01b7e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01b85:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01b8c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01b93:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01b9a:	e9 cb 0e 00 00       	jmp    0x78725cc02a6a
    78725cc01b9f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc01ba6:	00 
    78725cc01ba7:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc01bae:	c1 e9 0c             	shr    ecx,0xc
    78725cc01bb1:	89 c9                	mov    ecx,ecx
    78725cc01bb3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc01bb7:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    78725cc01bbe:	00 
    78725cc01bbf:	48 83 f8 00          	cmp    rax,0x0
    78725cc01bc3:	74 23                	je     0x78725cc01be8
    78725cc01bc5:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    78725cc01bcc:	00 
    78725cc01bcd:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc01bd4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc01bda:	89 c9                	mov    ecx,ecx
    78725cc01bdc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc01bdf:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc01be6:	eb 60                	jmp    0x78725cc01c48
    78725cc01be8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01bef:	00 
    78725cc01bf0:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    78725cc01bf7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01bfe:	00 
    78725cc01bff:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    78725cc01c06:	00 01 00 
    78725cc01c09:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc01c10:	00 00 00 
    78725cc01c13:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc01c1a:	00 00 00 
    78725cc01c1d:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc01c24:	60 00 00 
    78725cc01c27:	ff d0                	call   rax
    78725cc01c29:	89 c1                	mov    ecx,eax
    78725cc01c2b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01c32:	00 
    78725cc01c33:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    78725cc01c3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01c41:	75 41                	jne    0x78725cc01c84
    78725cc01c43:	e9 88 00 00 00       	jmp    0x78725cc01cd0
    78725cc01c48:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01c4f:	00 
    78725cc01c50:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    78725cc01c57:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc01c5e:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    78725cc01c65:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    78725cc01c6c:	83 c1 04             	add    ecx,0x4
    78725cc01c6f:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    78725cc01c76:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc01c79:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc01c7f:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc01c82:	eb 5f                	jmp    0x78725cc01ce3
    78725cc01c84:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01c8b:	00 
    78725cc01c8c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01c92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01c98:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01c9e:	be 0e 00 00 00       	mov    esi,0xe
    78725cc01ca3:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc01ca8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01caf:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01cb6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01cbd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01cc4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01ccb:	e9 9a 0d 00 00       	jmp    0x78725cc02a6a
    78725cc01cd0:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    78725cc01cd7:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc01cde:	e9 65 ff ff ff       	jmp    0x78725cc01c48
    78725cc01ce3:	eb 00                	jmp    0x78725cc01ce5
    78725cc01ce5:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    78725cc01cec:	83 e0 03             	and    eax,0x3
    78725cc01cef:	83 f8 00             	cmp    eax,0x0
    78725cc01cf2:	0f 84 97 00 00 00    	je     0x78725cc01d8f
    78725cc01cf8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01cff:	00 
    78725cc01d00:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc01d07:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01d0e:	00 
    78725cc01d0f:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc01d16:	00 01 00 
    78725cc01d19:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc01d20:	00 00 00 
    78725cc01d23:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc01d2a:	00 00 00 
    78725cc01d2d:	31 c0                	xor    eax,eax
    78725cc01d2f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc01d36:	60 00 00 
    78725cc01d39:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc01d3e:	45 31 c0             	xor    r8d,r8d
    78725cc01d41:	ff d0                	call   rax
    78725cc01d43:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01d4a:	00 
    78725cc01d4b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01d51:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01d57:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01d5d:	be 0f 00 00 00       	mov    esi,0xf
    78725cc01d62:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc01d67:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01d6e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01d75:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01d7c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01d83:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01d8a:	e9 db 0c 00 00       	jmp    0x78725cc02a6a
    78725cc01d8f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc01d96:	00 
    78725cc01d97:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc01d9e:	c1 e9 0c             	shr    ecx,0xc
    78725cc01da1:	89 c9                	mov    ecx,ecx
    78725cc01da3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc01da7:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    78725cc01dae:	00 
    78725cc01daf:	48 83 f8 00          	cmp    rax,0x0
    78725cc01db3:	74 23                	je     0x78725cc01dd8
    78725cc01db5:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    78725cc01dbc:	00 
    78725cc01dbd:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc01dc4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc01dca:	89 c9                	mov    ecx,ecx
    78725cc01dcc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc01dcf:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    78725cc01dd6:	eb 5d                	jmp    0x78725cc01e35
    78725cc01dd8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01ddf:	00 
    78725cc01de0:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    78725cc01de7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01dee:	00 
    78725cc01def:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc01df6:	00 01 00 
    78725cc01df9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc01e00:	00 00 00 
    78725cc01e03:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc01e0a:	00 00 00 
    78725cc01e0d:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc01e14:	60 00 00 
    78725cc01e17:	ff d0                	call   rax
    78725cc01e19:	89 c1                	mov    ecx,eax
    78725cc01e1b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01e22:	00 
    78725cc01e23:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    78725cc01e2a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01e31:	75 32                	jne    0x78725cc01e65
    78725cc01e33:	eb 7c                	jmp    0x78725cc01eb1
    78725cc01e35:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    78725cc01e3c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc01e43:	00 
    78725cc01e44:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    78725cc01e4b:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    78725cc01e4e:	83 c0 04             	add    eax,0x4
    78725cc01e51:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    78725cc01e58:	83 e0 03             	and    eax,0x3
    78725cc01e5b:	83 f8 00             	cmp    eax,0x0
    78725cc01e5e:	75 64                	jne    0x78725cc01ec4
    78725cc01e60:	e9 f6 00 00 00       	jmp    0x78725cc01f5b
    78725cc01e65:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01e6c:	00 
    78725cc01e6d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01e73:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01e79:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01e7f:	be 0f 00 00 00       	mov    esi,0xf
    78725cc01e84:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc01e89:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01e90:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01e97:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01e9e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01ea5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01eac:	e9 b9 0b 00 00       	jmp    0x78725cc02a6a
    78725cc01eb1:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    78725cc01eb8:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    78725cc01ebf:	e9 71 ff ff ff       	jmp    0x78725cc01e35
    78725cc01ec4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc01ecb:	00 
    78725cc01ecc:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc01ed3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc01eda:	00 
    78725cc01edb:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc01ee2:	00 01 00 
    78725cc01ee5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc01eec:	00 00 00 
    78725cc01eef:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc01ef6:	00 00 00 
    78725cc01ef9:	31 c0                	xor    eax,eax
    78725cc01efb:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc01f02:	60 00 00 
    78725cc01f05:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc01f0a:	45 31 c0             	xor    r8d,r8d
    78725cc01f0d:	ff d0                	call   rax
    78725cc01f0f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01f16:	00 
    78725cc01f17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc01f1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc01f23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc01f29:	be 0f 00 00 00       	mov    esi,0xf
    78725cc01f2e:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc01f33:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc01f3a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc01f41:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc01f48:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc01f4f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc01f56:	e9 0f 0b 00 00       	jmp    0x78725cc02a6a
    78725cc01f5b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc01f62:	00 
    78725cc01f63:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc01f6a:	c1 e9 0c             	shr    ecx,0xc
    78725cc01f6d:	89 c9                	mov    ecx,ecx
    78725cc01f6f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc01f73:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    78725cc01f7a:	00 
    78725cc01f7b:	48 83 f8 00          	cmp    rax,0x0
    78725cc01f7f:	74 23                	je     0x78725cc01fa4
    78725cc01f81:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc01f88:	00 
    78725cc01f89:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc01f90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc01f96:	89 c9                	mov    ecx,ecx
    78725cc01f98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc01f9b:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc01fa2:	eb 5d                	jmp    0x78725cc02001
    78725cc01fa4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01fab:	00 
    78725cc01fac:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    78725cc01fb3:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc01fba:	00 
    78725cc01fbb:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc01fc2:	00 01 00 
    78725cc01fc5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc01fcc:	00 00 00 
    78725cc01fcf:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc01fd6:	00 00 00 
    78725cc01fd9:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc01fe0:	60 00 00 
    78725cc01fe3:	ff d0                	call   rax
    78725cc01fe5:	89 c1                	mov    ecx,eax
    78725cc01fe7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc01fee:	00 
    78725cc01fef:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    78725cc01ff6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc01ffd:	75 32                	jne    0x78725cc02031
    78725cc01fff:	eb 7c                	jmp    0x78725cc0207d
    78725cc02001:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    78725cc02008:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0200f:	00 
    78725cc02010:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    78725cc02017:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    78725cc0201a:	83 c0 04             	add    eax,0x4
    78725cc0201d:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    78725cc02024:	83 e0 03             	and    eax,0x3
    78725cc02027:	83 f8 00             	cmp    eax,0x0
    78725cc0202a:	75 64                	jne    0x78725cc02090
    78725cc0202c:	e9 f6 00 00 00       	jmp    0x78725cc02127
    78725cc02031:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02038:	00 
    78725cc02039:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0203f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02045:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0204b:	be 0f 00 00 00       	mov    esi,0xf
    78725cc02050:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc02055:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0205c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc02063:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0206a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc02071:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02078:	e9 ed 09 00 00       	jmp    0x78725cc02a6a
    78725cc0207d:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    78725cc02084:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc0208b:	e9 71 ff ff ff       	jmp    0x78725cc02001
    78725cc02090:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc02097:	00 
    78725cc02098:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc0209f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc020a6:	00 
    78725cc020a7:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc020ae:	00 01 00 
    78725cc020b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc020b8:	00 00 00 
    78725cc020bb:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc020c2:	00 00 00 
    78725cc020c5:	31 c0                	xor    eax,eax
    78725cc020c7:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc020ce:	60 00 00 
    78725cc020d1:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc020d6:	45 31 c0             	xor    r8d,r8d
    78725cc020d9:	ff d0                	call   rax
    78725cc020db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc020e2:	00 
    78725cc020e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc020e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc020ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc020f5:	be 0f 00 00 00       	mov    esi,0xf
    78725cc020fa:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc020ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc02106:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0210d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02114:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0211b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02122:	e9 43 09 00 00       	jmp    0x78725cc02a6a
    78725cc02127:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc0212e:	00 
    78725cc0212f:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc02136:	c1 e9 0c             	shr    ecx,0xc
    78725cc02139:	89 c9                	mov    ecx,ecx
    78725cc0213b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0213f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    78725cc02146:	00 
    78725cc02147:	48 83 f8 00          	cmp    rax,0x0
    78725cc0214b:	74 23                	je     0x78725cc02170
    78725cc0214d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc02154:	00 
    78725cc02155:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc0215c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc02162:	89 c9                	mov    ecx,ecx
    78725cc02164:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc02167:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc0216e:	eb 5d                	jmp    0x78725cc021cd
    78725cc02170:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02177:	00 
    78725cc02178:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    78725cc0217f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc02186:	00 
    78725cc02187:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc0218e:	00 01 00 
    78725cc02191:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02198:	00 00 00 
    78725cc0219b:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc021a2:	00 00 00 
    78725cc021a5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc021ac:	60 00 00 
    78725cc021af:	ff d0                	call   rax
    78725cc021b1:	89 c1                	mov    ecx,eax
    78725cc021b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc021ba:	00 
    78725cc021bb:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    78725cc021c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc021c9:	75 32                	jne    0x78725cc021fd
    78725cc021cb:	eb 7c                	jmp    0x78725cc02249
    78725cc021cd:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    78725cc021d4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc021db:	00 
    78725cc021dc:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    78725cc021e3:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    78725cc021e6:	83 c0 04             	add    eax,0x4
    78725cc021e9:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    78725cc021f0:	83 e0 03             	and    eax,0x3
    78725cc021f3:	83 f8 00             	cmp    eax,0x0
    78725cc021f6:	75 64                	jne    0x78725cc0225c
    78725cc021f8:	e9 f6 00 00 00       	jmp    0x78725cc022f3
    78725cc021fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02204:	00 
    78725cc02205:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0220b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02211:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc02217:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0221c:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc02221:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc02228:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0222f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02236:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0223d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02244:	e9 21 08 00 00       	jmp    0x78725cc02a6a
    78725cc02249:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    78725cc02250:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc02257:	e9 71 ff ff ff       	jmp    0x78725cc021cd
    78725cc0225c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc02263:	00 
    78725cc02264:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0226b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc02272:	00 
    78725cc02273:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc0227a:	00 01 00 
    78725cc0227d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc02284:	00 00 00 
    78725cc02287:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc0228e:	00 00 00 
    78725cc02291:	31 c0                	xor    eax,eax
    78725cc02293:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0229a:	60 00 00 
    78725cc0229d:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc022a2:	45 31 c0             	xor    r8d,r8d
    78725cc022a5:	ff d0                	call   rax
    78725cc022a7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc022ae:	00 
    78725cc022af:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc022b5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc022bb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc022c1:	be 0f 00 00 00       	mov    esi,0xf
    78725cc022c6:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc022cb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc022d2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc022d9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc022e0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc022e7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc022ee:	e9 77 07 00 00       	jmp    0x78725cc02a6a
    78725cc022f3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc022fa:	00 
    78725cc022fb:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc02302:	c1 e9 0c             	shr    ecx,0xc
    78725cc02305:	89 c9                	mov    ecx,ecx
    78725cc02307:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0230b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc02312:	00 
    78725cc02313:	48 83 f8 00          	cmp    rax,0x0
    78725cc02317:	74 20                	je     0x78725cc02339
    78725cc02319:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc02320:	00 
    78725cc02321:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc02328:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0232e:	89 c9                	mov    ecx,ecx
    78725cc02330:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc02333:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc02337:	eb 5a                	jmp    0x78725cc02393
    78725cc02339:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02340:	00 
    78725cc02341:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    78725cc02348:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc0234f:	00 
    78725cc02350:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc02357:	00 01 00 
    78725cc0235a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02361:	00 00 00 
    78725cc02364:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc0236b:	00 00 00 
    78725cc0236e:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc02375:	60 00 00 
    78725cc02378:	ff d0                	call   rax
    78725cc0237a:	89 c1                	mov    ecx,eax
    78725cc0237c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02383:	00 
    78725cc02384:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    78725cc02388:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0238f:	75 2c                	jne    0x78725cc023bd
    78725cc02391:	eb 76                	jmp    0x78725cc02409
    78725cc02393:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    78725cc0239a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc023a1:	00 
    78725cc023a2:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    78725cc023a6:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    78725cc023a9:	83 c0 04             	add    eax,0x4
    78725cc023ac:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc023b0:	83 e0 03             	and    eax,0x3
    78725cc023b3:	83 f8 00             	cmp    eax,0x0
    78725cc023b6:	75 5b                	jne    0x78725cc02413
    78725cc023b8:	e9 ea 00 00 00       	jmp    0x78725cc024a7
    78725cc023bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc023c4:	00 
    78725cc023c5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc023cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc023d1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc023d7:	be 0f 00 00 00       	mov    esi,0xf
    78725cc023dc:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc023e1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc023e8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc023ef:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc023f6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc023fd:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02404:	e9 61 06 00 00       	jmp    0x78725cc02a6a
    78725cc02409:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    78725cc0240d:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc02411:	eb 80                	jmp    0x78725cc02393
    78725cc02413:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0241a:	00 
    78725cc0241b:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0241f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc02426:	00 
    78725cc02427:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc0242e:	00 01 00 
    78725cc02431:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc02438:	00 00 00 
    78725cc0243b:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc02442:	00 00 00 
    78725cc02445:	31 c0                	xor    eax,eax
    78725cc02447:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0244e:	60 00 00 
    78725cc02451:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc02456:	45 31 c0             	xor    r8d,r8d
    78725cc02459:	ff d0                	call   rax
    78725cc0245b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02462:	00 
    78725cc02463:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc02469:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0246f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc02475:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0247a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0247f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc02486:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0248d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02494:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0249b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc024a2:	e9 c3 05 00 00       	jmp    0x78725cc02a6a
    78725cc024a7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc024ae:	00 
    78725cc024af:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc024b3:	c1 e9 0c             	shr    ecx,0xc
    78725cc024b6:	89 c9                	mov    ecx,ecx
    78725cc024b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc024bc:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc024c1:	48 83 f8 00          	cmp    rax,0x0
    78725cc024c5:	74 1a                	je     0x78725cc024e1
    78725cc024c7:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc024cc:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc024d0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc024d6:	89 c9                	mov    ecx,ecx
    78725cc024d8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc024db:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc024df:	eb 57                	jmp    0x78725cc02538
    78725cc024e1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc024e8:	00 
    78725cc024e9:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    78725cc024ed:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc024f4:	00 
    78725cc024f5:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc024fc:	00 01 00 
    78725cc024ff:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02506:	00 00 00 
    78725cc02509:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc02510:	00 00 00 
    78725cc02513:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0251a:	60 00 00 
    78725cc0251d:	ff d0                	call   rax
    78725cc0251f:	89 c1                	mov    ecx,eax
    78725cc02521:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02528:	00 
    78725cc02529:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    78725cc0252d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc02534:	75 29                	jne    0x78725cc0255f
    78725cc02536:	eb 73                	jmp    0x78725cc025ab
    78725cc02538:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    78725cc0253c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc02543:	00 
    78725cc02544:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    78725cc02548:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    78725cc0254b:	83 c0 04             	add    eax,0x4
    78725cc0254e:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    78725cc02552:	83 e0 03             	and    eax,0x3
    78725cc02555:	83 f8 00             	cmp    eax,0x0
    78725cc02558:	75 5b                	jne    0x78725cc025b5
    78725cc0255a:	e9 ea 00 00 00       	jmp    0x78725cc02649
    78725cc0255f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02566:	00 
    78725cc02567:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0256d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02573:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc02579:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0257e:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc02583:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0258a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc02591:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02598:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0259f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc025a6:	e9 bf 04 00 00       	jmp    0x78725cc02a6a
    78725cc025ab:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    78725cc025af:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc025b3:	eb 83                	jmp    0x78725cc02538
    78725cc025b5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc025bc:	00 
    78725cc025bd:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc025c1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc025c8:	00 
    78725cc025c9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc025d0:	00 01 00 
    78725cc025d3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc025da:	00 00 00 
    78725cc025dd:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc025e4:	00 00 00 
    78725cc025e7:	31 c0                	xor    eax,eax
    78725cc025e9:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc025f0:	60 00 00 
    78725cc025f3:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc025f8:	45 31 c0             	xor    r8d,r8d
    78725cc025fb:	ff d0                	call   rax
    78725cc025fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02604:	00 
    78725cc02605:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0260b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02611:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc02617:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0261c:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc02621:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc02628:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0262f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02636:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0263d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02644:	e9 21 04 00 00       	jmp    0x78725cc02a6a
    78725cc02649:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc02650:	00 
    78725cc02651:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc02655:	c1 e9 0c             	shr    ecx,0xc
    78725cc02658:	89 c9                	mov    ecx,ecx
    78725cc0265a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0265e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc02663:	48 83 f8 00          	cmp    rax,0x0
    78725cc02667:	74 1a                	je     0x78725cc02683
    78725cc02669:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc0266e:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc02672:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc02678:	89 c9                	mov    ecx,ecx
    78725cc0267a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0267d:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc02681:	eb 57                	jmp    0x78725cc026da
    78725cc02683:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0268a:	00 
    78725cc0268b:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    78725cc0268f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc02696:	00 
    78725cc02697:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc0269e:	00 01 00 
    78725cc026a1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc026a8:	00 00 00 
    78725cc026ab:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc026b2:	00 00 00 
    78725cc026b5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc026bc:	60 00 00 
    78725cc026bf:	ff d0                	call   rax
    78725cc026c1:	89 c1                	mov    ecx,eax
    78725cc026c3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc026ca:	00 
    78725cc026cb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc026cf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc026d6:	75 29                	jne    0x78725cc02701
    78725cc026d8:	eb 73                	jmp    0x78725cc0274d
    78725cc026da:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    78725cc026de:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc026e5:	00 
    78725cc026e6:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    78725cc026ea:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    78725cc026ed:	83 c0 04             	add    eax,0x4
    78725cc026f0:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc026f4:	83 e0 03             	and    eax,0x3
    78725cc026f7:	83 f8 00             	cmp    eax,0x0
    78725cc026fa:	75 5b                	jne    0x78725cc02757
    78725cc026fc:	e9 ea 00 00 00       	jmp    0x78725cc027eb
    78725cc02701:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02708:	00 
    78725cc02709:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0270f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02715:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0271b:	be 0f 00 00 00       	mov    esi,0xf
    78725cc02720:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc02725:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0272c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc02733:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0273a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc02741:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02748:	e9 1d 03 00 00       	jmp    0x78725cc02a6a
    78725cc0274d:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc02751:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc02755:	eb 83                	jmp    0x78725cc026da
    78725cc02757:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0275e:	00 
    78725cc0275f:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc02763:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc0276a:	00 
    78725cc0276b:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    78725cc02772:	00 01 00 
    78725cc02775:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0277c:	00 00 00 
    78725cc0277f:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc02786:	00 00 00 
    78725cc02789:	31 c0                	xor    eax,eax
    78725cc0278b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc02792:	60 00 00 
    78725cc02795:	ba 3c 00 01 00       	mov    edx,0x1003c
    78725cc0279a:	45 31 c0             	xor    r8d,r8d
    78725cc0279d:	ff d0                	call   rax
    78725cc0279f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc027a6:	00 
    78725cc027a7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc027ad:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc027b3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc027b9:	be 0f 00 00 00       	mov    esi,0xf
    78725cc027be:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc027c3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc027ca:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc027d1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc027d8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc027df:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc027e6:	e9 7f 02 00 00       	jmp    0x78725cc02a6a
    78725cc027eb:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc027f2:	00 
    78725cc027f3:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc027f7:	c1 e9 0c             	shr    ecx,0xc
    78725cc027fa:	89 c9                	mov    ecx,ecx
    78725cc027fc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc02800:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc02805:	48 83 f8 00          	cmp    rax,0x0
    78725cc02809:	74 1a                	je     0x78725cc02825
    78725cc0280b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc02810:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc02814:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0281a:	89 c9                	mov    ecx,ecx
    78725cc0281c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0281f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc02823:	eb 57                	jmp    0x78725cc0287c
    78725cc02825:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0282c:	00 
    78725cc0282d:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc02831:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc02838:	00 
    78725cc02839:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    78725cc02840:	00 01 00 
    78725cc02843:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0284a:	00 00 00 
    78725cc0284d:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    78725cc02854:	00 00 00 
    78725cc02857:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0285e:	60 00 00 
    78725cc02861:	ff d0                	call   rax
    78725cc02863:	89 c1                	mov    ecx,eax
    78725cc02865:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0286c:	00 
    78725cc0286d:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc02871:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc02878:	75 1d                	jne    0x78725cc02897
    78725cc0287a:	eb 67                	jmp    0x78725cc028e3
    78725cc0287c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02883:	00 
    78725cc02884:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc02888:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    78725cc0288c:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    78725cc0288f:	83 c1 04             	add    ecx,0x4
    78725cc02892:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc02895:	eb 56                	jmp    0x78725cc028ed
    78725cc02897:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0289e:	00 
    78725cc0289f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc028a5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc028ab:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc028b1:	be 0f 00 00 00       	mov    esi,0xf
    78725cc028b6:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc028bb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc028c2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc028c9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc028d0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc028d7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc028de:	e9 87 01 00 00       	jmp    0x78725cc02a6a
    78725cc028e3:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc028e7:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc028eb:	eb 8f                	jmp    0x78725cc0287c
    78725cc028ed:	eb 00                	jmp    0x78725cc028ef
    78725cc028ef:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    78725cc028f6:	83 e0 01             	and    eax,0x1
    78725cc028f9:	83 f8 00             	cmp    eax,0x0
    78725cc028fc:	75 3d                	jne    0x78725cc0293b
    78725cc028fe:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    78725cc02905:	be 10 00 00 00       	mov    esi,0x10
    78725cc0290a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0290f:	b0 01                	mov    al,0x1
    78725cc02911:	89 d7                	mov    edi,edx
    78725cc02913:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0291a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc02921:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc02928:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0292f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc02936:	e9 2f 01 00 00       	jmp    0x78725cc02a6a
    78725cc0293b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc02942:	00 
    78725cc02943:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    78725cc0294a:	00 
    78725cc0294b:	c7 87 bc 00 00 00 3e 	mov    DWORD PTR [rdi+0xbc],0x1003e
    78725cc02952:	00 01 00 
    78725cc02955:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0295c:	00 00 00 
    78725cc0295f:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    78725cc02966:	00 00 00 
    78725cc02969:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc02970:	60 00 00 
    78725cc02973:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc02978:	ff d0                	call   rax
    78725cc0297a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02981:	00 
    78725cc02982:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc02988:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0298e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc02994:	be 10 00 00 00       	mov    esi,0x10
    78725cc02999:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0299e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc029a5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc029ac:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc029b3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc029ba:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc029c1:	e9 a4 00 00 00       	jmp    0x78725cc02a6a
    78725cc029c6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc029cd:	00 
    78725cc029ce:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc029d5:	e9 82 01 00 00       	jmp    0x78725cc02b5c
    78725cc029da:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc029e1:	00 
    78725cc029e2:	48 89 c1             	mov    rcx,rax
    78725cc029e5:	48 81 c1 00 02 08 00 	add    rcx,0x80200
    78725cc029ec:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc029f1:	81 b8 00 02 08 00 40 	cmp    DWORD PTR [rax+0x80200],0x10040
    78725cc029f8:	00 01 00 
    78725cc029fb:	74 32                	je     0x78725cc02a2f
    78725cc029fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02a04:	00 
    78725cc02a05:	c7 80 bc 00 00 00 40 	mov    DWORD PTR [rax+0xbc],0x10040
    78725cc02a0c:	00 01 00 
    78725cc02a0f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02a16:	00 00 00 
    78725cc02a19:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    78725cc02a20:	00 00 00 
    78725cc02a23:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc02a2a:	e9 2d 01 00 00       	jmp    0x78725cc02b5c
    78725cc02a2f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc02a36:	00 
    78725cc02a37:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc02a3e:	00 
    78725cc02a3f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc02a44:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc02a4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    78725cc02a52:	40 00 01 00 
    78725cc02a56:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc02a5d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc02a61:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc02a68:	ff e0                	jmp    rax
    78725cc02a6a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc02a71:	00 
    78725cc02a72:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    78725cc02a79:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    78725cc02a80:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    78725cc02a87:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    78725cc02a8e:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    78725cc02a95:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    78725cc02a99:	89 c3                	mov    ebx,eax
    78725cc02a9b:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    78725cc02a9f:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    78725cc02aa3:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    78725cc02aa7:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    78725cc02aab:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc02ab1:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc02ab5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc02abb:	73 2d                	jae    0x78725cc02aea
    78725cc02abd:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc02ac4:	00 
    78725cc02ac5:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc02ac9:	89 d1                	mov    ecx,edx
    78725cc02acb:	c1 e9 01             	shr    ecx,0x1
    78725cc02ace:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc02ad4:	89 c9                	mov    ecx,ecx
    78725cc02ad6:	48 c1 e1 04          	shl    rcx,0x4
    78725cc02ada:	48 89 c6             	mov    rsi,rax
    78725cc02add:	48 01 ce             	add    rsi,rcx
    78725cc02ae0:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc02ae5:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc02ae8:	74 32                	je     0x78725cc02b1c
    78725cc02aea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc02af1:	00 
    78725cc02af2:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    78725cc02af6:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc02afa:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc02afe:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    78725cc02b02:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc02b08:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc02b0e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc02b14:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc02b1a:	eb 40                	jmp    0x78725cc02b5c
    78725cc02b1c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc02b23:	00 
    78725cc02b24:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc02b2b:	00 
    78725cc02b2c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc02b31:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    78725cc02b35:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc02b39:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc02b40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc02b47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc02b4e:	00 
    78725cc02b4f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc02b53:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc02b5a:	ff e0                	jmp    rax
    78725cc02b5c:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc02b63:	c2 08 00             	ret    0x8
