
build-native-instruction-analysis/capture/bcore-default-stream/pc-66408-0-132432577720832.bin:     file format binary


Disassembly of section .data:

000078725cc07200 <.data>:
    78725cc07200:	48 81 ec 08 01 00 00 	sub    rsp,0x108
    78725cc07207:	4c 89 b4 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r14
    78725cc0720e:	00 
    78725cc0720f:	4c 89 ac 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r13
    78725cc07216:	00 
    78725cc07217:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0721e:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    78725cc07225:	00 
    78725cc07226:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0722d:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    78725cc07234:	00 
    78725cc07235:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc0723c:	00 
    78725cc0723d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc07243:	83 fa 00             	cmp    edx,0x0
    78725cc07246:	0f 94 c0             	sete   al
    78725cc07249:	81 ea 68 03 01 00    	sub    edx,0x10368
    78725cc0724f:	83 fa 06             	cmp    edx,0x6
    78725cc07252:	0f 97 c2             	seta   dl
    78725cc07255:	08 d0                	or     al,dl
    78725cc07257:	24 01                	and    al,0x1
    78725cc07259:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0725f:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc07265:	0f 94 c1             	sete   cl
    78725cc07268:	81 ea 68 03 01 00    	sub    edx,0x10368
    78725cc0726e:	83 fa 06             	cmp    edx,0x6
    78725cc07271:	0f 97 c2             	seta   dl
    78725cc07274:	08 d1                	or     cl,dl
    78725cc07276:	20 c8                	and    al,cl
    78725cc07278:	a8 01                	test   al,0x1
    78725cc0727a:	75 05                	jne    0x78725cc07281
    78725cc0727c:	e9 2f 0d 00 00       	jmp    0x78725cc07fb0
    78725cc07281:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07288:	00 
    78725cc07289:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc07290:	48 89 c8             	mov    rax,rcx
    78725cc07293:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc07299:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    78725cc072a0:	00 
    78725cc072a1:	8b 81 18 00 10 00    	mov    eax,DWORD PTR [rcx+0x100018]
    78725cc072a7:	83 c0 01             	add    eax,0x1
    78725cc072aa:	89 81 18 00 10 00    	mov    DWORD PTR [rcx+0x100018],eax
    78725cc072b0:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc072b5:	75 4c                	jne    0x78725cc07303
    78725cc072b7:	48 8b 8c 24 e0 00 00 	mov    rcx,QWORD PTR [rsp+0xe0]
    78725cc072be:	00 
    78725cc072bf:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc072c5:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc072cc:	89 c2                	mov    edx,eax
    78725cc072ce:	83 c2 01             	add    edx,0x1
    78725cc072d1:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc072d7:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc072dc:	73 23                	jae    0x78725cc07301
    78725cc072de:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    78725cc072e5:	00 
    78725cc072e6:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc072ed:	89 c9                	mov    ecx,ecx
    78725cc072ef:	48 c1 e1 02          	shl    rcx,0x2
    78725cc072f3:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc072fa:	c7 04 08 06 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x6
    78725cc07301:	eb 00                	jmp    0x78725cc07303
    78725cc07303:	eb 00                	jmp    0x78725cc07305
    78725cc07305:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0730c:	00 
    78725cc0730d:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc07310:	89 84 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],eax
    78725cc07317:	83 e0 03             	and    eax,0x3
    78725cc0731a:	83 f8 00             	cmp    eax,0x0
    78725cc0731d:	0f 84 8d 00 00 00    	je     0x78725cc073b0
    78725cc07323:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc0732a:	00 
    78725cc0732b:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    78725cc07332:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc07339:	00 
    78725cc0733a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc07341:	00 00 00 
    78725cc07344:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0734b:	00 00 00 
    78725cc0734e:	31 c0                	xor    eax,eax
    78725cc07350:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc07357:	60 00 00 
    78725cc0735a:	ba 68 03 01 00       	mov    edx,0x10368
    78725cc0735f:	45 31 c0             	xor    r8d,r8d
    78725cc07362:	ff d0                	call   rax
    78725cc07364:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0736b:	00 
    78725cc0736c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc07372:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07378:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0737e:	be 01 00 00 00       	mov    esi,0x1
    78725cc07383:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc07388:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc0738f:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07396:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc0739d:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc073a4:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc073ab:	e9 14 0c 00 00       	jmp    0x78725cc07fc4
    78725cc073b0:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc073b7:	00 
    78725cc073b8:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    78725cc073bf:	c1 e9 0c             	shr    ecx,0xc
    78725cc073c2:	89 c9                	mov    ecx,ecx
    78725cc073c4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc073c8:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    78725cc073cf:	00 
    78725cc073d0:	48 83 f8 00          	cmp    rax,0x0
    78725cc073d4:	74 23                	je     0x78725cc073f9
    78725cc073d6:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    78725cc073dd:	00 
    78725cc073de:	8b 8c 24 d8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd8]
    78725cc073e5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc073eb:	89 c9                	mov    ecx,ecx
    78725cc073ed:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc073f0:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    78725cc073f7:	eb 53                	jmp    0x78725cc0744c
    78725cc073f9:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07400:	00 
    78725cc07401:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    78725cc07408:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc0740f:	00 
    78725cc07410:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc07417:	00 00 00 
    78725cc0741a:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc07421:	00 00 00 
    78725cc07424:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0742b:	60 00 00 
    78725cc0742e:	ff d0                	call   rax
    78725cc07430:	89 c1                	mov    ecx,eax
    78725cc07432:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07439:	00 
    78725cc0743a:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    78725cc07441:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07448:	75 2e                	jne    0x78725cc07478
    78725cc0744a:	eb 78                	jmp    0x78725cc074c4
    78725cc0744c:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    78725cc07453:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    78725cc0745a:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    78725cc07461:	83 c0 04             	add    eax,0x4
    78725cc07464:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc0746b:	83 e0 03             	and    eax,0x3
    78725cc0746e:	83 f8 00             	cmp    eax,0x0
    78725cc07471:	75 64                	jne    0x78725cc074d7
    78725cc07473:	e9 ec 00 00 00       	jmp    0x78725cc07564
    78725cc07478:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0747f:	00 
    78725cc07480:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc07486:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0748c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07492:	be 01 00 00 00       	mov    esi,0x1
    78725cc07497:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0749c:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc074a3:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc074aa:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc074b1:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc074b8:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc074bf:	e9 00 0b 00 00       	jmp    0x78725cc07fc4
    78725cc074c4:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    78725cc074cb:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    78725cc074d2:	e9 75 ff ff ff       	jmp    0x78725cc0744c
    78725cc074d7:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc074de:	00 
    78725cc074df:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc074e6:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc074ed:	00 
    78725cc074ee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc074f5:	00 00 00 
    78725cc074f8:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc074ff:	00 00 00 
    78725cc07502:	31 c0                	xor    eax,eax
    78725cc07504:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0750b:	60 00 00 
    78725cc0750e:	ba 68 03 01 00       	mov    edx,0x10368
    78725cc07513:	45 31 c0             	xor    r8d,r8d
    78725cc07516:	ff d0                	call   rax
    78725cc07518:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0751f:	00 
    78725cc07520:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc07526:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0752c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07532:	be 01 00 00 00       	mov    esi,0x1
    78725cc07537:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0753c:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc07543:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc0754a:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07551:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07558:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc0755f:	e9 60 0a 00 00       	jmp    0x78725cc07fc4
    78725cc07564:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc0756b:	00 
    78725cc0756c:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc07573:	c1 e9 0c             	shr    ecx,0xc
    78725cc07576:	89 c9                	mov    ecx,ecx
    78725cc07578:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0757c:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    78725cc07583:	00 
    78725cc07584:	48 83 f8 00          	cmp    rax,0x0
    78725cc07588:	74 23                	je     0x78725cc075ad
    78725cc0758a:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc07591:	00 
    78725cc07592:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc07599:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0759f:	89 c9                	mov    ecx,ecx
    78725cc075a1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc075a4:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    78725cc075ab:	eb 56                	jmp    0x78725cc07603
    78725cc075ad:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc075b4:	00 
    78725cc075b5:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    78725cc075bc:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc075c3:	00 
    78725cc075c4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc075cb:	00 00 00 
    78725cc075ce:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc075d5:	00 00 00 
    78725cc075d8:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc075df:	60 00 00 
    78725cc075e2:	ff d0                	call   rax
    78725cc075e4:	89 c1                	mov    ecx,eax
    78725cc075e6:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc075ed:	00 
    78725cc075ee:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    78725cc075f5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc075fc:	75 41                	jne    0x78725cc0763f
    78725cc075fe:	e9 88 00 00 00       	jmp    0x78725cc0768b
    78725cc07603:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0760a:	00 
    78725cc0760b:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    78725cc07612:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc07619:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    78725cc07620:	89 94 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],edx
    78725cc07627:	83 c1 04             	add    ecx,0x4
    78725cc0762a:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    78725cc07631:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc07634:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc0763a:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0763d:	eb 5f                	jmp    0x78725cc0769e
    78725cc0763f:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07646:	00 
    78725cc07647:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0764d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07653:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07659:	be 01 00 00 00       	mov    esi,0x1
    78725cc0765e:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc07663:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc0766a:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07671:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07678:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc0767f:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07686:	e9 39 09 00 00       	jmp    0x78725cc07fc4
    78725cc0768b:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    78725cc07692:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    78725cc07699:	e9 65 ff ff ff       	jmp    0x78725cc07603
    78725cc0769e:	eb 00                	jmp    0x78725cc076a0
    78725cc076a0:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc076a7:	83 e0 03             	and    eax,0x3
    78725cc076aa:	83 f8 00             	cmp    eax,0x0
    78725cc076ad:	0f 84 94 00 00 00    	je     0x78725cc07747
    78725cc076b3:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc076ba:	00 
    78725cc076bb:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc076c2:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc076c9:	00 
    78725cc076ca:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc076d1:	03 01 00 
    78725cc076d4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc076db:	00 00 00 
    78725cc076de:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc076e5:	00 00 00 
    78725cc076e8:	31 c0                	xor    eax,eax
    78725cc076ea:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc076f1:	60 00 00 
    78725cc076f4:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc076f9:	45 31 c0             	xor    r8d,r8d
    78725cc076fc:	ff d0                	call   rax
    78725cc076fe:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07705:	00 
    78725cc07706:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc0770c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07712:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07718:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0771d:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07724:	89 ce                	mov    esi,ecx
    78725cc07726:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc0772d:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07734:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc0773b:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07742:	e9 7d 08 00 00       	jmp    0x78725cc07fc4
    78725cc07747:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc0774e:	00 
    78725cc0774f:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc07756:	c1 e9 0c             	shr    ecx,0xc
    78725cc07759:	89 c9                	mov    ecx,ecx
    78725cc0775b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0775f:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    78725cc07766:	00 
    78725cc07767:	48 83 f8 00          	cmp    rax,0x0
    78725cc0776b:	74 23                	je     0x78725cc07790
    78725cc0776d:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    78725cc07774:	00 
    78725cc07775:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc0777c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc07782:	89 c9                	mov    ecx,ecx
    78725cc07784:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc07787:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc0778e:	eb 5d                	jmp    0x78725cc077ed
    78725cc07790:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07797:	00 
    78725cc07798:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    78725cc0779f:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc077a6:	00 
    78725cc077a7:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc077ae:	03 01 00 
    78725cc077b1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc077b8:	00 00 00 
    78725cc077bb:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc077c2:	00 00 00 
    78725cc077c5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc077cc:	60 00 00 
    78725cc077cf:	ff d0                	call   rax
    78725cc077d1:	89 c1                	mov    ecx,eax
    78725cc077d3:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc077da:	00 
    78725cc077db:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    78725cc077e2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc077e9:	75 2f                	jne    0x78725cc0781a
    78725cc077eb:	eb 76                	jmp    0x78725cc07863
    78725cc077ed:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc077f4:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc077fb:	00 
    78725cc077fc:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    78725cc07803:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    78725cc07806:	83 c0 04             	add    eax,0x4
    78725cc07809:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0780d:	83 e0 03             	and    eax,0x3
    78725cc07810:	83 f8 00             	cmp    eax,0x0
    78725cc07813:	75 61                	jne    0x78725cc07876
    78725cc07815:	e9 ed 00 00 00       	jmp    0x78725cc07907
    78725cc0781a:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07821:	00 
    78725cc07822:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07828:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0782e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07834:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07839:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07840:	89 ce                	mov    esi,ecx
    78725cc07842:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07849:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07850:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07857:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc0785e:	e9 61 07 00 00       	jmp    0x78725cc07fc4
    78725cc07863:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    78725cc0786a:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc07871:	e9 77 ff ff ff       	jmp    0x78725cc077ed
    78725cc07876:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc0787d:	00 
    78725cc0787e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc07882:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc07889:	00 
    78725cc0788a:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc07891:	03 01 00 
    78725cc07894:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0789b:	00 00 00 
    78725cc0789e:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc078a5:	00 00 00 
    78725cc078a8:	31 c0                	xor    eax,eax
    78725cc078aa:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc078b1:	60 00 00 
    78725cc078b4:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc078b9:	45 31 c0             	xor    r8d,r8d
    78725cc078bc:	ff d0                	call   rax
    78725cc078be:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc078c5:	00 
    78725cc078c6:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc078cc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc078d2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc078d8:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc078dd:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc078e4:	89 ce                	mov    esi,ecx
    78725cc078e6:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc078ed:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc078f4:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc078fb:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07902:	e9 bd 06 00 00       	jmp    0x78725cc07fc4
    78725cc07907:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc0790e:	00 
    78725cc0790f:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc07913:	c1 e9 0c             	shr    ecx,0xc
    78725cc07916:	89 c9                	mov    ecx,ecx
    78725cc07918:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0791c:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc07921:	48 83 f8 00          	cmp    rax,0x0
    78725cc07925:	74 1a                	je     0x78725cc07941
    78725cc07927:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0792c:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc07930:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc07936:	89 c9                	mov    ecx,ecx
    78725cc07938:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0793b:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc0793f:	eb 57                	jmp    0x78725cc07998
    78725cc07941:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07948:	00 
    78725cc07949:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    78725cc0794d:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc07954:	00 
    78725cc07955:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc0795c:	03 01 00 
    78725cc0795f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc07966:	00 00 00 
    78725cc07969:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc07970:	00 00 00 
    78725cc07973:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0797a:	60 00 00 
    78725cc0797d:	ff d0                	call   rax
    78725cc0797f:	89 c1                	mov    ecx,eax
    78725cc07981:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07988:	00 
    78725cc07989:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc0798d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07994:	75 29                	jne    0x78725cc079bf
    78725cc07996:	eb 70                	jmp    0x78725cc07a08
    78725cc07998:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    78725cc0799c:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc079a3:	00 
    78725cc079a4:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    78725cc079a8:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    78725cc079ab:	83 c0 04             	add    eax,0x4
    78725cc079ae:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc079b2:	83 e0 03             	and    eax,0x3
    78725cc079b5:	83 f8 00             	cmp    eax,0x0
    78725cc079b8:	75 58                	jne    0x78725cc07a12
    78725cc079ba:	e9 e4 00 00 00       	jmp    0x78725cc07aa3
    78725cc079bf:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc079c6:	00 
    78725cc079c7:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc079cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc079d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc079d9:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc079de:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc079e5:	89 ce                	mov    esi,ecx
    78725cc079e7:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc079ee:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc079f5:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc079fc:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07a03:	e9 bc 05 00 00       	jmp    0x78725cc07fc4
    78725cc07a08:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    78725cc07a0c:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc07a10:	eb 86                	jmp    0x78725cc07998
    78725cc07a12:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc07a19:	00 
    78725cc07a1a:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc07a1e:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc07a25:	00 
    78725cc07a26:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc07a2d:	03 01 00 
    78725cc07a30:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc07a37:	00 00 00 
    78725cc07a3a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc07a41:	00 00 00 
    78725cc07a44:	31 c0                	xor    eax,eax
    78725cc07a46:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc07a4d:	60 00 00 
    78725cc07a50:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc07a55:	45 31 c0             	xor    r8d,r8d
    78725cc07a58:	ff d0                	call   rax
    78725cc07a5a:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07a61:	00 
    78725cc07a62:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07a68:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07a6e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07a74:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07a79:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07a80:	89 ce                	mov    esi,ecx
    78725cc07a82:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07a89:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07a90:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07a97:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07a9e:	e9 21 05 00 00       	jmp    0x78725cc07fc4
    78725cc07aa3:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc07aaa:	00 
    78725cc07aab:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc07aaf:	c1 e9 0c             	shr    ecx,0xc
    78725cc07ab2:	89 c9                	mov    ecx,ecx
    78725cc07ab4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc07ab8:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc07abd:	48 83 f8 00          	cmp    rax,0x0
    78725cc07ac1:	74 1a                	je     0x78725cc07add
    78725cc07ac3:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc07ac8:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc07acc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc07ad2:	89 c9                	mov    ecx,ecx
    78725cc07ad4:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc07ad7:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc07adb:	eb 57                	jmp    0x78725cc07b34
    78725cc07add:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07ae4:	00 
    78725cc07ae5:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    78725cc07ae9:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc07af0:	00 
    78725cc07af1:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc07af8:	03 01 00 
    78725cc07afb:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc07b02:	00 00 00 
    78725cc07b05:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc07b0c:	00 00 00 
    78725cc07b0f:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc07b16:	60 00 00 
    78725cc07b19:	ff d0                	call   rax
    78725cc07b1b:	89 c1                	mov    ecx,eax
    78725cc07b1d:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07b24:	00 
    78725cc07b25:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc07b29:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07b30:	75 29                	jne    0x78725cc07b5b
    78725cc07b32:	eb 70                	jmp    0x78725cc07ba4
    78725cc07b34:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    78725cc07b38:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc07b3f:	00 
    78725cc07b40:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    78725cc07b44:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    78725cc07b47:	83 c0 04             	add    eax,0x4
    78725cc07b4a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc07b4e:	83 e0 03             	and    eax,0x3
    78725cc07b51:	83 f8 00             	cmp    eax,0x0
    78725cc07b54:	75 58                	jne    0x78725cc07bae
    78725cc07b56:	e9 e4 00 00 00       	jmp    0x78725cc07c3f
    78725cc07b5b:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07b62:	00 
    78725cc07b63:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07b69:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07b6f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07b75:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07b7a:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07b81:	89 ce                	mov    esi,ecx
    78725cc07b83:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07b8a:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07b91:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07b98:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07b9f:	e9 20 04 00 00       	jmp    0x78725cc07fc4
    78725cc07ba4:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc07ba8:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc07bac:	eb 86                	jmp    0x78725cc07b34
    78725cc07bae:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc07bb5:	00 
    78725cc07bb6:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc07bba:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc07bc1:	00 
    78725cc07bc2:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc07bc9:	03 01 00 
    78725cc07bcc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc07bd3:	00 00 00 
    78725cc07bd6:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc07bdd:	00 00 00 
    78725cc07be0:	31 c0                	xor    eax,eax
    78725cc07be2:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc07be9:	60 00 00 
    78725cc07bec:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc07bf1:	45 31 c0             	xor    r8d,r8d
    78725cc07bf4:	ff d0                	call   rax
    78725cc07bf6:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07bfd:	00 
    78725cc07bfe:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07c04:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07c0a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07c10:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07c15:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07c1c:	89 ce                	mov    esi,ecx
    78725cc07c1e:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07c25:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07c2c:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07c33:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07c3a:	e9 85 03 00 00       	jmp    0x78725cc07fc4
    78725cc07c3f:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc07c46:	00 
    78725cc07c47:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc07c4b:	c1 e9 0c             	shr    ecx,0xc
    78725cc07c4e:	89 c9                	mov    ecx,ecx
    78725cc07c50:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc07c54:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    78725cc07c59:	48 83 f8 00          	cmp    rax,0x0
    78725cc07c5d:	74 1a                	je     0x78725cc07c79
    78725cc07c5f:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc07c64:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc07c68:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc07c6e:	89 c9                	mov    ecx,ecx
    78725cc07c70:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc07c73:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc07c77:	eb 57                	jmp    0x78725cc07cd0
    78725cc07c79:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07c80:	00 
    78725cc07c81:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc07c85:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc07c8c:	00 
    78725cc07c8d:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc07c94:	03 01 00 
    78725cc07c97:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc07c9e:	00 00 00 
    78725cc07ca1:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc07ca8:	00 00 00 
    78725cc07cab:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc07cb2:	60 00 00 
    78725cc07cb5:	ff d0                	call   rax
    78725cc07cb7:	89 c1                	mov    ecx,eax
    78725cc07cb9:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07cc0:	00 
    78725cc07cc1:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    78725cc07cc5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07ccc:	75 29                	jne    0x78725cc07cf7
    78725cc07cce:	eb 70                	jmp    0x78725cc07d40
    78725cc07cd0:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    78725cc07cd4:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc07cdb:	00 
    78725cc07cdc:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    78725cc07ce0:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    78725cc07ce3:	83 c0 04             	add    eax,0x4
    78725cc07ce6:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc07cea:	83 e0 03             	and    eax,0x3
    78725cc07ced:	83 f8 00             	cmp    eax,0x0
    78725cc07cf0:	75 58                	jne    0x78725cc07d4a
    78725cc07cf2:	e9 e4 00 00 00       	jmp    0x78725cc07ddb
    78725cc07cf7:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07cfe:	00 
    78725cc07cff:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07d05:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07d0b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07d11:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07d16:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07d1d:	89 ce                	mov    esi,ecx
    78725cc07d1f:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07d26:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07d2d:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07d34:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07d3b:	e9 84 02 00 00       	jmp    0x78725cc07fc4
    78725cc07d40:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    78725cc07d44:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc07d48:	eb 86                	jmp    0x78725cc07cd0
    78725cc07d4a:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc07d51:	00 
    78725cc07d52:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc07d56:	48 8b b4 24 e8 00 00 	mov    rsi,QWORD PTR [rsp+0xe8]
    78725cc07d5d:	00 
    78725cc07d5e:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc07d65:	03 01 00 
    78725cc07d68:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc07d6f:	00 00 00 
    78725cc07d72:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc07d79:	00 00 00 
    78725cc07d7c:	31 c0                	xor    eax,eax
    78725cc07d7e:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc07d85:	60 00 00 
    78725cc07d88:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc07d8d:	45 31 c0             	xor    r8d,r8d
    78725cc07d90:	ff d0                	call   rax
    78725cc07d92:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07d99:	00 
    78725cc07d9a:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07da0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07da6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07dac:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07db1:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07db8:	89 ce                	mov    esi,ecx
    78725cc07dba:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07dc1:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07dc8:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07dcf:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07dd6:	e9 e9 01 00 00       	jmp    0x78725cc07fc4
    78725cc07ddb:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc07de2:	00 
    78725cc07de3:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc07de7:	c1 e9 0c             	shr    ecx,0xc
    78725cc07dea:	89 c9                	mov    ecx,ecx
    78725cc07dec:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc07df0:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    78725cc07df5:	48 83 f8 00          	cmp    rax,0x0
    78725cc07df9:	74 1a                	je     0x78725cc07e15
    78725cc07dfb:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc07e00:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc07e04:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc07e0a:	89 c9                	mov    ecx,ecx
    78725cc07e0c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc07e0f:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc07e13:	eb 57                	jmp    0x78725cc07e6c
    78725cc07e15:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07e1c:	00 
    78725cc07e1d:	8b 74 24 34          	mov    esi,DWORD PTR [rsp+0x34]
    78725cc07e21:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    78725cc07e28:	00 
    78725cc07e29:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc07e30:	03 01 00 
    78725cc07e33:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc07e3a:	00 00 00 
    78725cc07e3d:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc07e44:	00 00 00 
    78725cc07e47:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc07e4e:	60 00 00 
    78725cc07e51:	ff d0                	call   rax
    78725cc07e53:	89 c1                	mov    ecx,eax
    78725cc07e55:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07e5c:	00 
    78725cc07e5d:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    78725cc07e61:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07e68:	75 1d                	jne    0x78725cc07e87
    78725cc07e6a:	eb 64                	jmp    0x78725cc07ed0
    78725cc07e6c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07e73:	00 
    78725cc07e74:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc07e78:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    78725cc07e7c:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    78725cc07e7f:	83 c1 04             	add    ecx,0x4
    78725cc07e82:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc07e85:	eb 53                	jmp    0x78725cc07eda
    78725cc07e87:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07e8e:	00 
    78725cc07e8f:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc07e95:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07e9b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07ea1:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07ea6:	89 b4 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],esi
    78725cc07ead:	89 ce                	mov    esi,ecx
    78725cc07eaf:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07eb6:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07ebd:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07ec4:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07ecb:	e9 f4 00 00 00       	jmp    0x78725cc07fc4
    78725cc07ed0:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc07ed4:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc07ed8:	eb 92                	jmp    0x78725cc07e6c
    78725cc07eda:	eb 00                	jmp    0x78725cc07edc
    78725cc07edc:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    78725cc07ee3:	83 e0 01             	and    eax,0x1
    78725cc07ee6:	83 f8 00             	cmp    eax,0x0
    78725cc07ee9:	75 3d                	jne    0x78725cc07f28
    78725cc07eeb:	8b 94 24 90 00 00 00 	mov    edx,DWORD PTR [rsp+0x90]
    78725cc07ef2:	be 03 00 00 00       	mov    esi,0x3
    78725cc07ef7:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07efc:	b0 01                	mov    al,0x1
    78725cc07efe:	89 d7                	mov    edi,edx
    78725cc07f00:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc07f07:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07f0e:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07f15:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07f1c:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07f23:	e9 9c 00 00 00       	jmp    0x78725cc07fc4
    78725cc07f28:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
    78725cc07f2f:	00 
    78725cc07f30:	48 8b 94 24 e8 00 00 	mov    rdx,QWORD PTR [rsp+0xe8]
    78725cc07f37:	00 
    78725cc07f38:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    78725cc07f3f:	03 01 00 
    78725cc07f42:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc07f49:	00 00 00 
    78725cc07f4c:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc07f53:	00 00 00 
    78725cc07f56:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc07f5d:	60 00 00 
    78725cc07f60:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc07f65:	ff d0                	call   rax
    78725cc07f67:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07f6e:	00 
    78725cc07f6f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc07f75:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07f7b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc07f81:	be 03 00 00 00       	mov    esi,0x3
    78725cc07f86:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc07f8b:	89 bc 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edi
    78725cc07f92:	89 b4 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],esi
    78725cc07f99:	89 94 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],edx
    78725cc07fa0:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc07fa7:	88 84 24 d7 00 00 00 	mov    BYTE PTR [rsp+0xd7],al
    78725cc07fae:	eb 14                	jmp    0x78725cc07fc4
    78725cc07fb0:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc07fb7:	00 
    78725cc07fb8:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc07fbf:	e9 f0 00 00 00       	jmp    0x78725cc080b4
    78725cc07fc4:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    78725cc07fcb:	00 
    78725cc07fcc:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    78725cc07fd3:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    78725cc07fda:	8b b4 24 cc 00 00 00 	mov    esi,DWORD PTR [rsp+0xcc]
    78725cc07fe1:	8b bc 24 d0 00 00 00 	mov    edi,DWORD PTR [rsp+0xd0]
    78725cc07fe8:	8a 9c 24 d7 00 00 00 	mov    bl,BYTE PTR [rsp+0xd7]
    78725cc07fef:	88 5c 24 0b          	mov    BYTE PTR [rsp+0xb],bl
    78725cc07ff3:	89 c3                	mov    ebx,eax
    78725cc07ff5:	89 5c 24 0c          	mov    DWORD PTR [rsp+0xc],ebx
    78725cc07ff9:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc07ffd:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc08001:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc08005:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0800b:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc0800f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc08015:	73 2c                	jae    0x78725cc08043
    78725cc08017:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    78725cc0801e:	00 
    78725cc0801f:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc08023:	89 d1                	mov    ecx,edx
    78725cc08025:	c1 e9 01             	shr    ecx,0x1
    78725cc08028:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0802e:	89 c9                	mov    ecx,ecx
    78725cc08030:	48 c1 e1 04          	shl    rcx,0x4
    78725cc08034:	48 89 c6             	mov    rsi,rax
    78725cc08037:	48 01 ce             	add    rsi,rcx
    78725cc0803a:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    78725cc0803e:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc08041:	74 32                	je     0x78725cc08075
    78725cc08043:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    78725cc0804a:	00 
    78725cc0804b:	8a 4c 24 0b          	mov    cl,BYTE PTR [rsp+0xb]
    78725cc0804f:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    78725cc08053:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    78725cc08057:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    78725cc0805b:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc08061:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc08067:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc0806d:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc08073:	eb 3f                	jmp    0x78725cc080b4
    78725cc08075:	4c 8b b4 24 e8 00 00 	mov    r14,QWORD PTR [rsp+0xe8]
    78725cc0807c:	00 
    78725cc0807d:	4c 8b ac 24 f0 00 00 	mov    r13,QWORD PTR [rsp+0xf0]
    78725cc08084:	00 
    78725cc08085:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    78725cc08089:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc0808d:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc08091:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc08098:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0809f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc080a6:	00 
    78725cc080a7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc080ab:	48 81 c4 08 01 00 00 	add    rsp,0x108
    78725cc080b2:	ff e0                	jmp    rax
    78725cc080b4:	48 81 c4 08 01 00 00 	add    rsp,0x108
    78725cc080bb:	c2 08 00             	ret    0x8
