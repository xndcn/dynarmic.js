
build-native-instruction-analysis/capture/bcore-default-stream/pc-65668-0-132432577756496.bin:     file format binary


Disassembly of section .data:

000078725cc0fd50 <.data>:
    78725cc0fd50:	48 81 ec a8 00 00 00 	sub    rsp,0xa8
    78725cc0fd57:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
    78725cc0fd5e:	00 
    78725cc0fd5f:	4c 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r13
    78725cc0fd66:	00 
    78725cc0fd67:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0fd6e:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    78725cc0fd75:	00 
    78725cc0fd76:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0fd7d:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    78725cc0fd84:	00 
    78725cc0fd85:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    78725cc0fd8c:	00 
    78725cc0fd8d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc0fd93:	83 fa 00             	cmp    edx,0x0
    78725cc0fd96:	0f 94 c0             	sete   al
    78725cc0fd99:	81 ea 84 00 01 00    	sub    edx,0x10084
    78725cc0fd9f:	83 fa 0a             	cmp    edx,0xa
    78725cc0fda2:	0f 97 c2             	seta   dl
    78725cc0fda5:	08 d0                	or     al,dl
    78725cc0fda7:	24 01                	and    al,0x1
    78725cc0fda9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0fdaf:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc0fdb5:	0f 94 c1             	sete   cl
    78725cc0fdb8:	81 ea 84 00 01 00    	sub    edx,0x10084
    78725cc0fdbe:	83 fa 0a             	cmp    edx,0xa
    78725cc0fdc1:	0f 97 c2             	seta   dl
    78725cc0fdc4:	08 d1                	or     cl,dl
    78725cc0fdc6:	20 c8                	and    al,cl
    78725cc0fdc8:	a8 01                	test   al,0x1
    78725cc0fdca:	75 05                	jne    0x78725cc0fdd1
    78725cc0fdcc:	e9 c9 03 00 00       	jmp    0x78725cc1019a
    78725cc0fdd1:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0fdd8:	00 
    78725cc0fdd9:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc0fde0:	48 89 c8             	mov    rax,rcx
    78725cc0fde3:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0fde9:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc0fdf0:	00 
    78725cc0fdf1:	8b 81 38 00 10 00    	mov    eax,DWORD PTR [rcx+0x100038]
    78725cc0fdf7:	83 c0 01             	add    eax,0x1
    78725cc0fdfa:	89 81 38 00 10 00    	mov    DWORD PTR [rcx+0x100038],eax
    78725cc0fe00:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc0fe05:	75 46                	jne    0x78725cc0fe4d
    78725cc0fe07:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    78725cc0fe0e:	00 
    78725cc0fe0f:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc0fe15:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0fe19:	89 c2                	mov    edx,eax
    78725cc0fe1b:	83 c2 01             	add    edx,0x1
    78725cc0fe1e:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc0fe24:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0fe29:	73 20                	jae    0x78725cc0fe4b
    78725cc0fe2b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc0fe32:	00 
    78725cc0fe33:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0fe37:	89 c9                	mov    ecx,ecx
    78725cc0fe39:	48 c1 e1 02          	shl    rcx,0x2
    78725cc0fe3d:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc0fe44:	c7 04 08 0e 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xe
    78725cc0fe4b:	eb 00                	jmp    0x78725cc0fe4d
    78725cc0fe4d:	eb 00                	jmp    0x78725cc0fe4f
    78725cc0fe4f:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0fe56:	00 
    78725cc0fe57:	8b 48 10             	mov    ecx,DWORD PTR [rax+0x10]
    78725cc0fe5a:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    78725cc0fe5e:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc0fe61:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc0fe65:	83 c0 fc             	add    eax,0xfffffffc
    78725cc0fe68:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    78725cc0fe6c:	83 e0 03             	and    eax,0x3
    78725cc0fe6f:	83 f8 00             	cmp    eax,0x0
    78725cc0fe72:	74 67                	je     0x78725cc0fedb
    78725cc0fe74:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    78725cc0fe7b:	00 
    78725cc0fe7c:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    78725cc0fe80:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    78725cc0fe87:	00 
    78725cc0fe88:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    78725cc0fe8f:	00 00 00 
    78725cc0fe92:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0fe99:	00 00 00 
    78725cc0fe9c:	31 c0                	xor    eax,eax
    78725cc0fe9e:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0fea5:	60 00 00 
    78725cc0fea8:	ba 84 00 01 00       	mov    edx,0x10084
    78725cc0fead:	45 31 c0             	xor    r8d,r8d
    78725cc0feb0:	ff d0                	call   rax
    78725cc0feb2:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0feb9:	00 
    78725cc0feba:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0fec0:	b9 01 00 00 00       	mov    ecx,0x1
    78725cc0fec5:	b8 08 00 00 00       	mov    eax,0x8
    78725cc0feca:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    78725cc0fece:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc0fed2:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc0fed6:	e9 60 03 00 00       	jmp    0x78725cc1023b
    78725cc0fedb:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc0fee2:	00 
    78725cc0fee3:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    78725cc0fee7:	c1 e9 0c             	shr    ecx,0xc
    78725cc0feea:	89 c9                	mov    ecx,ecx
    78725cc0feec:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0fef0:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc0fef5:	48 83 f8 00          	cmp    rax,0x0
    78725cc0fef9:	74 1a                	je     0x78725cc0ff15
    78725cc0fefb:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc0ff00:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    78725cc0ff04:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0ff0a:	89 c9                	mov    ecx,ecx
    78725cc0ff0c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0ff0f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0ff13:	eb 4d                	jmp    0x78725cc0ff62
    78725cc0ff15:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0ff1c:	00 
    78725cc0ff1d:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    78725cc0ff21:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    78725cc0ff28:	00 
    78725cc0ff29:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    78725cc0ff30:	00 00 00 
    78725cc0ff33:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc0ff3a:	00 00 00 
    78725cc0ff3d:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0ff44:	60 00 00 
    78725cc0ff47:	ff d0                	call   rax
    78725cc0ff49:	89 c1                	mov    ecx,eax
    78725cc0ff4b:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0ff52:	00 
    78725cc0ff53:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc0ff57:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0ff5e:	75 2d                	jne    0x78725cc0ff8d
    78725cc0ff60:	eb 54                	jmp    0x78725cc0ffb6
    78725cc0ff62:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0ff69:	00 
    78725cc0ff6a:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    78725cc0ff6e:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc0ff72:	89 10                	mov    DWORD PTR [rax],edx
    78725cc0ff74:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0ff77:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    78725cc0ff7d:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc0ff81:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    78725cc0ff87:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0ff8b:	eb 33                	jmp    0x78725cc0ffc0
    78725cc0ff8d:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc0ff94:	00 
    78725cc0ff95:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ff9b:	b9 01 00 00 00       	mov    ecx,0x1
    78725cc0ffa0:	b8 08 00 00 00       	mov    eax,0x8
    78725cc0ffa5:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    78725cc0ffa9:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc0ffad:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc0ffb1:	e9 85 02 00 00       	jmp    0x78725cc1023b
    78725cc0ffb6:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc0ffba:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0ffbe:	eb a2                	jmp    0x78725cc0ff62
    78725cc0ffc0:	eb 00                	jmp    0x78725cc0ffc2
    78725cc0ffc2:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    78725cc0ffc6:	83 c0 f8             	add    eax,0xfffffff8
    78725cc0ffc9:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc0ffcd:	83 e0 03             	and    eax,0x3
    78725cc0ffd0:	83 f8 00             	cmp    eax,0x0
    78725cc0ffd3:	74 6e                	je     0x78725cc10043
    78725cc0ffd5:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    78725cc0ffdc:	00 
    78725cc0ffdd:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0ffe1:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    78725cc0ffe8:	00 
    78725cc0ffe9:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    78725cc0fff0:	00 01 00 
    78725cc0fff3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0fffa:	00 00 00 
    78725cc0fffd:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc10004:	00 00 00 
    78725cc10007:	31 c0                	xor    eax,eax
    78725cc10009:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc10010:	60 00 00 
    78725cc10013:	ba 8c 00 01 00       	mov    edx,0x1008c
    78725cc10018:	45 31 c0             	xor    r8d,r8d
    78725cc1001b:	ff d0                	call   rax
    78725cc1001d:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc10024:	00 
    78725cc10025:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    78725cc1002b:	b8 02 00 00 00       	mov    eax,0x2
    78725cc10030:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    78725cc10034:	89 c1                	mov    ecx,eax
    78725cc10036:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc1003a:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc1003e:	e9 f8 01 00 00       	jmp    0x78725cc1023b
    78725cc10043:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc1004a:	00 
    78725cc1004b:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc1004f:	c1 e9 0c             	shr    ecx,0xc
    78725cc10052:	89 c9                	mov    ecx,ecx
    78725cc10054:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc10058:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc1005d:	48 83 f8 00          	cmp    rax,0x0
    78725cc10061:	74 1a                	je     0x78725cc1007d
    78725cc10063:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc10068:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc1006c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc10072:	89 c9                	mov    ecx,ecx
    78725cc10074:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc10077:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc1007b:	eb 57                	jmp    0x78725cc100d4
    78725cc1007d:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc10084:	00 
    78725cc10085:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc10089:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    78725cc10090:	00 
    78725cc10091:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    78725cc10098:	00 01 00 
    78725cc1009b:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc100a2:	00 00 00 
    78725cc100a5:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc100ac:	00 00 00 
    78725cc100af:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc100b6:	60 00 00 
    78725cc100b9:	ff d0                	call   rax
    78725cc100bb:	89 c1                	mov    ecx,eax
    78725cc100bd:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc100c4:	00 
    78725cc100c5:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc100c9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc100d0:	75 13                	jne    0x78725cc100e5
    78725cc100d2:	eb 37                	jmp    0x78725cc1010b
    78725cc100d4:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc100db:	00 
    78725cc100dc:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc100e0:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    78725cc100e3:	eb 30                	jmp    0x78725cc10115
    78725cc100e5:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc100ec:	00 
    78725cc100ed:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    78725cc100f3:	b8 02 00 00 00       	mov    eax,0x2
    78725cc100f8:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    78725cc100fc:	89 c1                	mov    ecx,eax
    78725cc100fe:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc10102:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc10106:	e9 30 01 00 00       	jmp    0x78725cc1023b
    78725cc1010b:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc1010f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc10113:	eb bf                	jmp    0x78725cc100d4
    78725cc10115:	eb 00                	jmp    0x78725cc10117
    78725cc10117:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    78725cc1011e:	00 
    78725cc1011f:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc10123:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc10127:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    78725cc1012d:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    78725cc10133:	83 ff 01             	cmp    edi,0x1
    78725cc10136:	0f 97 c3             	seta   bl
    78725cc10139:	3d 8e 00 01 00       	cmp    eax,0x1008e
    78725cc1013e:	0f 94 c0             	sete   al
    78725cc10141:	20 c3                	and    bl,al
    78725cc10143:	b8 92 00 01 00       	mov    eax,0x10092
    78725cc10148:	f6 c3 01             	test   bl,0x1
    78725cc1014b:	0f 45 c2             	cmovne eax,edx
    78725cc1014e:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    78725cc10154:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    78725cc1015a:	83 ff 01             	cmp    edi,0x1
    78725cc1015d:	0f 97 c3             	seta   bl
    78725cc10160:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    78725cc10166:	40 0f 94 c6          	sete   sil
    78725cc1016a:	40 20 f3             	and    bl,sil
    78725cc1016d:	f6 c3 01             	test   bl,0x1
    78725cc10170:	0f 45 c2             	cmovne eax,edx
    78725cc10173:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    78725cc10179:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    78725cc10180:	03 01 00 
    78725cc10183:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc10189:	83 c0 03             	add    eax,0x3
    78725cc1018c:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc10190:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc10196:	72 16                	jb     0x78725cc101ae
    78725cc10198:	eb 37                	jmp    0x78725cc101d1
    78725cc1019a:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc101a1:	00 
    78725cc101a2:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc101a9:	e9 41 01 00 00       	jmp    0x78725cc102ef
    78725cc101ae:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc101b5:	00 
    78725cc101b6:	48 89 c1             	mov    rcx,rax
    78725cc101b9:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    78725cc101c0:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc101c5:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    78725cc101cc:	03 01 00 
    78725cc101cf:	74 32                	je     0x78725cc10203
    78725cc101d1:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc101d8:	00 
    78725cc101d9:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    78725cc101e0:	03 01 00 
    78725cc101e3:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc101ea:	00 00 00 
    78725cc101ed:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc101f4:	00 00 00 
    78725cc101f7:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc101fe:	e9 ec 00 00 00       	jmp    0x78725cc102ef
    78725cc10203:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    78725cc1020a:	00 
    78725cc1020b:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    78725cc10212:	00 
    78725cc10213:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc10218:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc1021c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    78725cc10223:	28 03 01 00 
    78725cc10227:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc1022e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc10232:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    78725cc10239:	ff e0                	jmp    rax
    78725cc1023b:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    78725cc10242:	00 
    78725cc10243:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    78725cc10247:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    78725cc1024b:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    78725cc1024f:	89 c7                	mov    edi,eax
    78725cc10251:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc10255:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc10259:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc1025d:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc10263:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc10267:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc1026d:	73 2d                	jae    0x78725cc1029c
    78725cc1026f:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc10276:	00 
    78725cc10277:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc1027b:	89 d1                	mov    ecx,edx
    78725cc1027d:	c1 e9 01             	shr    ecx,0x1
    78725cc10280:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc10286:	89 c9                	mov    ecx,ecx
    78725cc10288:	48 c1 e1 04          	shl    rcx,0x4
    78725cc1028c:	48 89 c6             	mov    rsi,rax
    78725cc1028f:	48 01 ce             	add    rsi,rcx
    78725cc10292:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc10297:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc1029a:	74 1e                	je     0x78725cc102ba
    78725cc1029c:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc102a3:	00 
    78725cc102a4:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc102a8:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc102ac:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc102b2:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc102b8:	eb 35                	jmp    0x78725cc102ef
    78725cc102ba:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    78725cc102c1:	00 
    78725cc102c2:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    78725cc102c9:	00 
    78725cc102ca:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc102cf:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc102d3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc102da:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc102e1:	00 
    78725cc102e2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc102e6:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    78725cc102ed:	ff e0                	jmp    rax
    78725cc102ef:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    78725cc102f6:	c2 08 00             	ret    0x8
