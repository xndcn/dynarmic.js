; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001037a(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 66426
  %4 = icmp ugt i32 %3, 28
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb11 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb11, 0
  %9 = sub i32 %guard_lb11, 66426
  %10 = icmp ugt i32 %9, 28
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x0001037a_entry, label %lb_guard_miss, !prof !0

insn_0x0001037a_entry:                            ; preds = %lb_guard
  %13 = getelementptr i8, ptr %cpu, i64 336
  %chain_table13 = load ptr, ptr %13, align 8
  %tier_table = getelementptr i8, ptr %chain_table13, i64 1048576
  %14 = getelementptr i8, ptr %tier_table, i64 16
  %15 = load i32, ptr %14, align 4
  %tier_count = add i32 %15, 1
  store i32 %tier_count, ptr %14, align 4
  %16 = icmp eq i32 %tier_count, 30000
  br i1 %16, label %17, label %27, !prof !1

17:                                               ; preds = %insn_0x0001037a_entry
  %18 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %18, align 4
  %19 = add i32 %tier_requests, 1
  store i32 %19, ptr %18, align 4
  %20 = icmp ult i32 %tier_requests, 256
  br i1 %20, label %21, label %26

21:                                               ; preds = %17
  %22 = zext i32 %tier_requests to i64
  %23 = mul i64 %22, 4
  %24 = add i64 262148, %23
  %25 = getelementptr i8, ptr %tier_table, i64 %24
  store i32 4, ptr %25, align 4
  br label %26

26:                                               ; preds = %17, %21
  br label %27

27:                                               ; preds = %insn_0x0001037a_entry, %26
  br label %insn_0x0001037a

insn_0x0001037a:                                  ; preds = %27
  %28 = getelementptr i8, ptr %cpu, i32 36
  %old = load i32, ptr %28, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %29 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_hi, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %31, align 4
  br label %insn_0x0001037e_entry

insn_0x0001037e_entry:                            ; preds = %insn_0x0001037a
  br label %insn_0x0001037e

insn_0x0001037e:                                  ; preds = %insn_0x0001037e_entry
  %32 = getelementptr i8, ptr %cpu, i32 4
  %old1 = load i32, ptr %32, align 4
  %lo_kept2 = and i32 %old1, 65535
  %with_hi3 = or i32 %lo_kept2, 1638400
  %33 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_hi3, ptr %33, align 4
  br label %insn_0x00010382_entry

insn_0x00010382_entry:                            ; preds = %insn_0x0001037e
  br label %insn_0x00010382

insn_0x00010382:                                  ; preds = %insn_0x00010382_entry
  %34 = getelementptr i8, ptr %cpu, i32 0
  %old4 = load i32, ptr %34, align 4
  %lo_kept5 = and i32 %old4, 65535
  %with_hi6 = or i32 %lo_kept5, 1013841920
  %35 = getelementptr i8, ptr %cpu, i32 0
  store i32 %with_hi6, ptr %35, align 4
  br label %insn_0x00010386_entry

insn_0x00010386_entry:                            ; preds = %insn_0x00010382
  br label %insn_0x00010386

insn_0x00010386:                                  ; preds = %insn_0x00010386_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4860
  %36 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %36, align 4
  br label %insn_0x0001038a_entry

insn_0x0001038a_entry:                            ; preds = %insn_0x00010386
  br label %insn_0x0001038a

insn_0x0001038a:                                  ; preds = %insn_0x0001038a_entry
  %hi_kept7 = and i32 %with_hi3, -65536
  %with_lo8 = or i32 %hi_kept7, 26125
  %37 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_lo8, ptr %37, align 4
  br label %insn_0x0001038e_entry

insn_0x0001038e_entry:                            ; preds = %insn_0x0001038a
  br label %insn_0x0001038e

insn_0x0001038e:                                  ; preds = %insn_0x0001038e_entry
  %hi_kept9 = and i32 %with_hi6, -65536
  %with_lo10 = or i32 %hi_kept9, 62303
  %38 = getelementptr i8, ptr %cpu, i32 0
  store i32 %with_lo10, ptr %38, align 4
  br label %insn_0x00010392_entry

insn_0x00010392_entry:                            ; preds = %insn_0x0001038e
  br label %insn_0x00010392

insn_0x00010392:                                  ; preds = %insn_0x00010392_entry
  %39 = getelementptr i8, ptr %cpu, i32 40
  store i32 8192, ptr %39, align 4
  br label %insn_0x00010396_entry

insn_0x00010396_entry:                            ; preds = %insn_0x00010392
  br label %insn_0x00010396

insn_0x00010396:                                  ; preds = %insn_0x00010396_entry
  %40 = getelementptr i8, ptr %cpu, i32 148
  store i32 66458, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 164
  store i32 66462, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 156
  store i32 8192, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 296
  %44 = getelementptr i8, ptr %cpu, i32 188
  store i32 66458, ptr %44, align 4
  store i8 1, ptr %43, align 1
  %at_lb0 = icmp eq i32 %lb0, 66454
  %at_lb = or i1 %at_lb0, false
  br i1 %at_lb, label %hwloop_count, label %hwloop_counted, !prof !1

hwloop_count:                                     ; preds = %insn_0x00010396
  %45 = getelementptr i8, ptr %cpu, i32 188
  store i32 66458, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %47, align 4
  call void @bfin_hwloop_step(ptr %cpu, i32 66454, i32 66454)
  br label %hwloop_counted

hwloop_counted:                                   ; preds = %hwloop_count, %insn_0x00010396
  %48 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %48, align 4
  %chain_total = add nuw i32 %chain_packets, 8
  %49 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %49 monotonic, align 4, !range !2
  %50 = icmp ult i32 %chain_total, %chain_budget
  br i1 %50, label %chain_go, label %chain_leave12, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %51 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %51, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %hwloop_counted
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531664
  %52 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %52, align 4
  %53 = icmp eq i32 %slot_pc, 66458
  br i1 %53, label %chain_hit, label %chain_leave12, !prof !0

chain_leave12:                                    ; preds = %chain_go, %hwloop_counted
  %54 = getelementptr i8, ptr %cpu, i64 188
  store i32 66458, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %56, align 4
  br label %return

chain_hit:                                        ; preds = %chain_go
  %57 = getelementptr i8, ptr %cpu, i64 188
  store i32 66458, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %59, align 1
  %60 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %60, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave12, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @bfin_hwloop_step(ptr, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
