
build-native-instruction-analysis/capture/bcore-default-stream/pc-66458-0-132432577757952.bin:     file format binary


Disassembly of section .data:

000078725cc10300 <.data>:
    78725cc10300:	48 83 ec 68          	sub    rsp,0x68
    78725cc10304:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    78725cc10309:	4c 89 ef             	mov    rdi,r13
    78725cc1030c:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    78725cc10313:	45 8b 95 58 01 00 00 	mov    r10d,DWORD PTR [r13+0x158]
    78725cc1031a:	b8 5d fc fe ff       	mov    eax,0xfffefc5d
    78725cc1031f:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    78725cc10326:	83 f8 f6             	cmp    eax,0xfffffff6
    78725cc10329:	0f 87 67 fd fe 17    	ja     0x787274c00096
    78725cc1032f:	81 bf a4 00 00 00 9e 	cmp    DWORD PTR [rdi+0xa4],0x1039e
    78725cc10336:	03 01 00 
    78725cc10339:	0f 85 57 fd fe 17    	jne    0x787274c00096
    78725cc1033f:	81 bf 94 00 00 00 9a 	cmp    DWORD PTR [rdi+0x94],0x1039a
    78725cc10346:	03 01 00 
    78725cc10349:	0f 85 47 fd fe 17    	jne    0x787274c00096
    78725cc1034f:	48 8b 87 40 01 00 00 	mov    rax,QWORD PTR [rdi+0x140]
    78725cc10356:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc1035b:	48 8b 87 38 01 00 00 	mov    rax,QWORD PTR [rdi+0x138]
    78725cc10362:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    78725cc10367:	8b 07                	mov    eax,DWORD PTR [rdi]
    78725cc10369:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    78725cc1036d:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    78725cc10370:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc10374:	44 8b 67 08          	mov    r12d,DWORD PTR [rdi+0x8]
    78725cc10378:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    78725cc1037c:	8b 87 9c 00 00 00    	mov    eax,DWORD PTR [rdi+0x9c]
    78725cc10382:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    78725cc10386:	44 8b 8f 00 01 00 00 	mov    r9d,DWORD PTR [rdi+0x100]
    78725cc1038d:	44 8b bf 5c 01 00 00 	mov    r15d,DWORD PTR [rdi+0x15c]
    78725cc10394:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    78725cc1039b:	00 00 00 00 00 
    78725cc103a0:	44 0f af 64 24 44    	imul   r12d,DWORD PTR [rsp+0x44]
    78725cc103a6:	44 89 e5             	mov    ebp,r12d
    78725cc103a9:	c1 ed 1f             	shr    ebp,0x1f
    78725cc103ac:	8b 4c 24 14          	mov    ecx,DWORD PTR [rsp+0x14]
    78725cc103b0:	89 c8                	mov    eax,ecx
    78725cc103b2:	c1 e8 1f             	shr    eax,0x1f
    78725cc103b5:	45 31 db             	xor    r11d,r11d
    78725cc103b8:	41 01 cc             	add    r12d,ecx
    78725cc103bb:	41 0f 92 c3          	setb   r11b
    78725cc103bf:	44 89 e3             	mov    ebx,r12d
    78725cc103c2:	c1 eb 1f             	shr    ebx,0x1f
    78725cc103c5:	31 d8                	xor    eax,ebx
    78725cc103c7:	31 dd                	xor    ebp,ebx
    78725cc103c9:	21 c5                	and    ebp,eax
    78725cc103cb:	45 31 f6             	xor    r14d,r14d
    78725cc103ce:	45 85 e4             	test   r12d,r12d
    78725cc103d1:	41 0f 94 c6          	sete   r14b
    78725cc103d5:	41 09 e9             	or     r9d,ebp
    78725cc103d8:	41 f6 c5 03          	test   r13b,0x3
    78725cc103dc:	0f 85 79 02 00 00    	jne    0x78725cc1065b
    78725cc103e2:	44 89 74 24 10       	mov    DWORD PTR [rsp+0x10],r14d
    78725cc103e7:	44 89 e8             	mov    eax,r13d
    78725cc103ea:	c1 e8 0c             	shr    eax,0xc
    78725cc103ed:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    78725cc103f2:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
    78725cc103f6:	48 85 c0             	test   rax,rax
    78725cc103f9:	0f 84 81 03 00 00    	je     0x78725cc10780
    78725cc103ff:	44 89 e9             	mov    ecx,r13d
    78725cc10402:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc10408:	44 89 24 08          	mov    DWORD PTR [rax+rcx*1],r12d
    78725cc1040c:	41 83 c5 04          	add    r13d,0x4
    78725cc10410:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    78725cc10414:	83 f8 02             	cmp    eax,0x2
    78725cc10417:	72 6d                	jb     0x78725cc10486
    78725cc10419:	ff c8                	dec    eax
    78725cc1041b:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    78725cc1041f:	41 be 9a 03 01 00    	mov    r14d,0x1039a
    78725cc10425:	c7 44 24 34 02 00 00 	mov    DWORD PTR [rsp+0x34],0x2
    78725cc1042c:	00 
    78725cc1042d:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    78725cc10432:	b8 03 00 00 00       	mov    eax,0x3
    78725cc10437:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc1043c:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc10441:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc10444:	0f 85 09 04 00 00    	jne    0x78725cc10853
    78725cc1044a:	44 89 f9             	mov    ecx,r15d
    78725cc1044d:	89 e8                	mov    eax,ebp
    78725cc1044f:	44 89 da             	mov    edx,r11d
    78725cc10452:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
    78725cc10457:	44 8d 3c 0e          	lea    r15d,[rsi+rcx*1]
    78725cc1045b:	45 39 d7             	cmp    r15d,r10d
    78725cc1045e:	0f 83 7b 01 00 00    	jae    0x78725cc105df
    78725cc10464:	8b b7 58 01 00 00    	mov    esi,DWORD PTR [rdi+0x158]
    78725cc1046a:	85 f6                	test   esi,esi
    78725cc1046c:	0f 84 6d 01 00 00    	je     0x78725cc105df
    78725cc10472:	4c 89 f6             	mov    rsi,r14
    78725cc10475:	81 fe 9a 03 01 00    	cmp    esi,0x1039a
    78725cc1047b:	0f 84 1f ff ff ff    	je     0x78725cc103a0
    78725cc10481:	e9 ba 00 00 00       	jmp    0x78725cc10540
    78725cc10486:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc1048b:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc1048e:	0f 85 17 fc fe 17    	jne    0x787274c000ab
    78725cc10494:	41 8d 47 05          	lea    eax,[r15+0x5]
    78725cc10498:	44 39 d0             	cmp    eax,r10d
    78725cc1049b:	0f 83 79 fb fe 17    	jae    0x787274c0001a
    78725cc104a1:	8b 8f 58 01 00 00    	mov    ecx,DWORD PTR [rdi+0x158]
    78725cc104a7:	85 c9                	test   ecx,ecx
    78725cc104a9:	0f 84 6b fb fe 17    	je     0x787274c0001a
    78725cc104af:	41 81 b8 40 1b 08 00 	cmp    DWORD PTR [r8+0x81b40],0x10368
    78725cc104b6:	68 03 01 00 
    78725cc104ba:	0f 85 5a fb fe 17    	jne    0x787274c0001a
    78725cc104c0:	49 8b 88 48 1b 08 00 	mov    rcx,QWORD PTR [r8+0x81b48]
    78725cc104c7:	c7 07 00 00 00 00    	mov    DWORD PTR [rdi],0x0
    78725cc104cd:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc104d1:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc104d5:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    78725cc104dc:	00 00 00 
    78725cc104df:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    78725cc104e6:	03 01 00 
    78725cc104e9:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    78725cc104ed:	89 97 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],edx
    78725cc104f3:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc104f9:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    78725cc10500:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc10507:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    78725cc1050d:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc10513:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc1051a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc10521:	00 00 00 
    78725cc10524:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc1052b:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc10532:	00 00 00 
    78725cc10535:	89 87 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],eax
    78725cc1053b:	e9 91 00 00 00       	jmp    0x78725cc105d1
    78725cc10540:	49 89 f2             	mov    r10,rsi
    78725cc10543:	8d 34 f5 00 00 00 00 	lea    esi,[rsi*8+0x0]
    78725cc1054a:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    78725cc10550:	45 39 14 30          	cmp    DWORD PTR [r8+rsi*1],r10d
    78725cc10554:	0f 85 85 00 00 00    	jne    0x78725cc105df
    78725cc1055a:	49 8b 4c 30 08       	mov    rcx,QWORD PTR [r8+rsi*1+0x8]
    78725cc1055f:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    78725cc10563:	89 37                	mov    DWORD PTR [rdi],esi
    78725cc10565:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc10569:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc1056d:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc10571:	89 b7 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],esi
    78725cc10577:	44 89 b7 bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r14d
    78725cc1057e:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    78725cc10582:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    78725cc10588:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc1058e:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    78725cc10594:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc1059b:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    78725cc105a1:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc105a7:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc105ae:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    78725cc105b2:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    78725cc105b8:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc105bf:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc105c4:	89 87 34 01 00 00    	mov    DWORD PTR [rdi+0x134],eax
    78725cc105ca:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    78725cc105d1:	49 89 fd             	mov    r13,rdi
    78725cc105d4:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    78725cc105d9:	48 83 c4 68          	add    rsp,0x68
    78725cc105dd:	ff e1                	jmp    rcx
    78725cc105df:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    78725cc105e3:	89 37                	mov    DWORD PTR [rdi],esi
    78725cc105e5:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc105e9:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc105ed:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc105f1:	89 b7 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],esi
    78725cc105f7:	44 89 b7 bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r14d
    78725cc105fe:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    78725cc10602:	89 b7 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],esi
    78725cc10608:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc1060e:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    78725cc10614:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc1061b:	89 87 f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],eax
    78725cc10621:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc10627:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc1062e:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    78725cc10632:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    78725cc10638:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    78725cc1063d:	88 87 28 01 00 00    	mov    BYTE PTR [rdi+0x128],al
    78725cc10643:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc10648:	89 87 34 01 00 00    	mov    DWORD PTR [rdi+0x134],eax
    78725cc1064e:	89 8f 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ecx
    78725cc10654:	48 83 c4 68          	add    rsp,0x68
    78725cc10658:	c2 08 00             	ret    0x8
    78725cc1065b:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    78725cc1065f:	89 07                	mov    DWORD PTR [rdi],eax
    78725cc10661:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc10665:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc10669:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    78725cc1066d:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    78725cc10673:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1039e
    78725cc1067a:	03 01 00 
    78725cc1067d:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    78725cc10684:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc1068a:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    78725cc10691:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc10698:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    78725cc1069e:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc106a4:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc106ab:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc106b2:	00 00 00 
    78725cc106b5:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc106bc:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc106c3:	00 00 00 
    78725cc106c6:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    78725cc106cd:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc106d4:	60 00 00 
    78725cc106d7:	48 89 fb             	mov    rbx,rdi
    78725cc106da:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    78725cc106df:	ba 9e 03 01 00       	mov    edx,0x1039e
    78725cc106e4:	44 89 e9             	mov    ecx,r13d
    78725cc106e7:	4d 89 c7             	mov    r15,r8
    78725cc106ea:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc106f0:	44 89 d5             	mov    ebp,r10d
    78725cc106f3:	ff d0                	call   rax
    78725cc106f5:	41 89 ea             	mov    r10d,ebp
    78725cc106f8:	4d 89 f8             	mov    r8,r15
    78725cc106fb:	48 89 df             	mov    rdi,rbx
    78725cc106fe:	0f b6 b3 28 01 00 00 	movzx  esi,BYTE PTR [rbx+0x128]
    78725cc10705:	8b 07                	mov    eax,DWORD PTR [rdi]
    78725cc10707:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    78725cc1070b:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    78725cc1070e:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc10712:	44 8b 67 08          	mov    r12d,DWORD PTR [rdi+0x8]
    78725cc10716:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    78725cc1071a:	8b 87 9c 00 00 00    	mov    eax,DWORD PTR [rdi+0x9c]
    78725cc10720:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    78725cc10724:	44 8b b7 bc 00 00 00 	mov    r14d,DWORD PTR [rdi+0xbc]
    78725cc1072b:	8b 87 e4 00 00 00    	mov    eax,DWORD PTR [rdi+0xe4]
    78725cc10731:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    78725cc10735:	8b 9f e8 00 00 00    	mov    ebx,DWORD PTR [rdi+0xe8]
    78725cc1073b:	8b 97 ec 00 00 00    	mov    edx,DWORD PTR [rdi+0xec]
    78725cc10741:	44 8b 9f f0 00 00 00 	mov    r11d,DWORD PTR [rdi+0xf0]
    78725cc10748:	8b 87 f8 00 00 00    	mov    eax,DWORD PTR [rdi+0xf8]
    78725cc1074e:	8b af fc 00 00 00    	mov    ebp,DWORD PTR [rdi+0xfc]
    78725cc10754:	44 8b 8f 00 01 00 00 	mov    r9d,DWORD PTR [rdi+0x100]
    78725cc1075b:	8b 8f 24 01 00 00    	mov    ecx,DWORD PTR [rdi+0x124]
    78725cc10761:	89 4c 24 34          	mov    DWORD PTR [rsp+0x34],ecx
    78725cc10765:	40 88 74 24 0f       	mov    BYTE PTR [rsp+0xf],sil
    78725cc1076a:	8b 8f 34 01 00 00    	mov    ecx,DWORD PTR [rdi+0x134]
    78725cc10770:	48 89 4c 24 50       	mov    QWORD PTR [rsp+0x50],rcx
    78725cc10775:	8b 8f 5c 01 00 00    	mov    ecx,DWORD PTR [rdi+0x15c]
    78725cc1077b:	e9 d2 fc ff ff       	jmp    0x78725cc10452
    78725cc10780:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    78725cc10784:	89 07                	mov    DWORD PTR [rdi],eax
    78725cc10786:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc1078a:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc1078e:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    78725cc10792:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    78725cc10798:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1039e
    78725cc1079f:	03 01 00 
    78725cc107a2:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    78725cc107a6:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    78725cc107ac:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc107b2:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    78725cc107b9:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc107c0:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    78725cc107c6:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc107cc:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc107d3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc107da:	00 00 00 
    78725cc107dd:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc107e4:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc107eb:	00 00 00 
    78725cc107ee:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    78725cc107f5:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc107fc:	60 00 00 
    78725cc107ff:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    78725cc10804:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc10809:	44 89 ee             	mov    esi,r13d
    78725cc1080c:	44 89 e2             	mov    edx,r12d
    78725cc1080f:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    78725cc10814:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    78725cc10819:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    78725cc1081e:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    78725cc10823:	ff d0                	call   rax
    78725cc10825:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    78725cc1082a:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    78725cc1082f:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    78725cc10834:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    78725cc10839:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    78725cc1083e:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    78725cc10845:	40 84 f6             	test   sil,sil
    78725cc10848:	0f 84 be fb ff ff    	je     0x78725cc1040c
    78725cc1084e:	e9 b2 fe ff ff       	jmp    0x78725cc10705
    78725cc10853:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    78725cc10857:	89 07                	mov    DWORD PTR [rdi],eax
    78725cc10859:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc1085d:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc10861:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    78725cc10865:	89 87 9c 00 00 00    	mov    DWORD PTR [rdi+0x9c],eax
    78725cc1086b:	c7 87 bc 00 00 00 9a 	mov    DWORD PTR [rdi+0xbc],0x1039a
    78725cc10872:	03 01 00 
    78725cc10875:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    78725cc10879:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    78725cc1087f:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    78725cc10885:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    78725cc1088c:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    78725cc10893:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    78725cc10899:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    78725cc1089f:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    78725cc108a6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc108ad:	00 00 00 
    78725cc108b0:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    78725cc108b7:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc108be:	00 00 00 
    78725cc108c1:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    78725cc108c8:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc108cf:	60 00 00 
    78725cc108d2:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    78725cc108d7:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    78725cc108dc:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    78725cc108e1:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    78725cc108e6:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    78725cc108eb:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    78725cc108f0:	ff d0                	call   rax
    78725cc108f2:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    78725cc108f7:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    78725cc108fc:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    78725cc10901:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    78725cc10906:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    78725cc1090b:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    78725cc10912:	44 89 f9             	mov    ecx,r15d
    78725cc10915:	89 e8                	mov    eax,ebp
    78725cc10917:	44 89 da             	mov    edx,r11d
    78725cc1091a:	40 84 f6             	test   sil,sil
    78725cc1091d:	0f 84 2f fb ff ff    	je     0x78725cc10452
    78725cc10923:	e9 dd fd ff ff       	jmp    0x78725cc10705
