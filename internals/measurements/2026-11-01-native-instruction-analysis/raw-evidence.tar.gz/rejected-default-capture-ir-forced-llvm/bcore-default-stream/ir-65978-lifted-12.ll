; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000101ba(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65978
  %6 = icmp ugt i32 %5, 52
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb109 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb109, 66462
  %11 = sub i32 %guard_lb109, 65978
  %12 = icmp ugt i32 %11, 52
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000101ba_entry, label %lb_guard_miss, !prof !0

insn_0x000101ba_entry:                            ; preds = %chain_self, %chain_go, %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table132 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table132, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 48
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 45000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000101ba_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 12, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000101ba_entry, %28
  br label %insn_0x000101ba

insn_0x000101ba:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 8
  %rs = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 28
  %rt = load i32, ptr %31, align 4
  %and32 = and i32 %rt, %rs
  %32 = getelementptr i8, ptr %cpu, i32 4
  store i32 %and32, ptr %32, align 4
  %33 = icmp eq i32 %and32, 0
  %az = zext i1 %33 to i32
  %an = lshr i32 %and32, 31
  %34 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %41, align 4
  br label %insn_0x000101bc_entry

insn_0x000101bc_entry:                            ; preds = %insn_0x000101ba
  br label %insn_0x000101bc

insn_0x000101bc:                                  ; preds = %insn_0x000101bc_entry
  %42 = getelementptr i8, ptr %cpu, i32 40
  store i32 %and32, ptr %42, align 4
  br label %insn_0x000101be_entry

insn_0x000101be_entry:                            ; preds = %insn_0x000101bc
  br label %insn_0x000101be

insn_0x000101be:                                  ; preds = %insn_0x000101be_entry
  %43 = shl i32 %and32, 2
  %44 = getelementptr i8, ptr %cpu, i32 32
  %ps = load i32, ptr %44, align 4
  %plshift2 = add i32 %ps, %43
  %45 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift2, ptr %45, align 4
  br label %insn_0x000101c0_entry

insn_0x000101c0_entry:                            ; preds = %insn_0x000101be
  br label %insn_0x000101c0

insn_0x000101c0:                                  ; preds = %insn_0x000101c0_entry
  %46 = and i32 %plshift2, 3
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000101c0
  %48 = getelementptr i8, ptr %cpu, i32 188
  store i32 65984, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %50, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65984, i32 %plshift2, i32 0)
  %51 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 188
  %53 = load i32, ptr %52, align 4
  %54 = getelementptr i8, ptr %cpu, i64 296
  %55 = load i8, ptr %54, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000101c0
  %56 = lshr i32 %plshift2, 12
  %page_index = zext i32 %56 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %57 = and i32 %plshift2, 4095
  %page_offset = zext i32 %57 to i64
  %58 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %58, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %59 = getelementptr i8, ptr %cpu, i32 188
  store i32 65984, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 308
  store i32 4, ptr %61, align 4
  %62 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %63 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %63, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %62, %did_jump_cont ]
  %64 = getelementptr i8, ptr %cpu, i32 12
  store i32 %mem_val, ptr %64, align 4
  br label %insn_0x000101c2_entry

did_jump_exit:                                    ; preds = %page_slow
  %65 = getelementptr i8, ptr %cpu, i64 188
  %next_pc110 = load i32, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i64 188
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %cpu, i64 296
  %69 = load i8, ptr %68, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x000101c2_entry:                            ; preds = %page_done
  br label %insn_0x000101c2

insn_0x000101c2:                                  ; preds = %insn_0x000101c2_entry
  %add32 = add i32 %rs, %mem_val
  %70 = getelementptr i8, ptr %cpu, i32 12
  store i32 %add32, ptr %70, align 4
  %flgs = lshr i32 %rs, 31
  %flgo = lshr i32 %mem_val, 31
  %flgn = lshr i32 %add32, 31
  %71 = xor i32 %flgo, %flgn
  %72 = xor i32 %flgs, %flgn
  %73 = and i32 %72, %71
  %74 = xor i32 %rs, -1
  %75 = icmp ult i32 %74, %mem_val
  %ac0 = zext i1 %75 to i32
  %76 = icmp eq i32 %add32, 0
  %az1 = zext i1 %76 to i32
  %an2 = lshr i32 %add32, 31
  %77 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %79, align 4
  %80 = or i32 %vs_cur, %73
  %81 = getelementptr i8, ptr %cpu, i32 248
  store i32 %73, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 252
  store i32 %73, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i32 256
  store i32 %80, ptr %83, align 4
  %84 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %85, align 4
  br label %insn_0x000101c4_entry

insn_0x000101c4_entry:                            ; preds = %insn_0x000101c2
  br label %insn_0x000101c4

insn_0x000101c4:                                  ; preds = %insn_0x000101c4_entry
  %lsr32 = lshr i32 %add32, 11
  %86 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr32, ptr %86, align 4
  %87 = icmp eq i32 %lsr32, 0
  %az3 = zext i1 %87 to i32
  %an4 = lshr i32 %lsr32, 31
  %88 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az3, ptr %88, align 4
  %89 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an4, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %91, align 4
  br label %insn_0x000101c8_entry

insn_0x000101c8_entry:                            ; preds = %insn_0x000101c4
  br label %insn_0x000101c8

insn_0x000101c8:                                  ; preds = %insn_0x000101c8_entry
  %xor32 = xor i32 %add32, %lsr32
  %92 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %92, align 4
  %93 = icmp eq i32 %xor32, 0
  %az5 = zext i1 %93 to i32
  %an6 = lshr i32 %xor32, 31
  %94 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az5, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an6, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %99, align 4
  br label %insn_0x000101ca_entry

insn_0x000101ca_entry:                            ; preds = %insn_0x000101c8
  br label %insn_0x000101ca

insn_0x000101ca:                                  ; preds = %insn_0x000101ca_entry
  %100 = and i32 %plshift2, 3
  %101 = icmp ne i32 %100, 0
  br i1 %101, label %data_misaligned7, label %data_aligned8, !prof !1

data_misaligned7:                                 ; preds = %insn_0x000101ca
  %102 = getelementptr i8, ptr %cpu, i32 188
  store i32 65994, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %104, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65994, i32 %plshift2, i32 65536)
  %105 = getelementptr i8, ptr %cpu, i64 188
  %next_pc111 = load i32, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 188
  %107 = load i32, ptr %106, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  %109 = load i8, ptr %108, align 1
  br label %chain_exit

data_aligned8:                                    ; preds = %insn_0x000101ca
  %110 = lshr i32 %plshift2, 12
  %page_index9 = zext i32 %110 to i64
  %page_slot10 = getelementptr ptr, ptr %page_table, i64 %page_index9
  %page11 = load ptr, ptr %page_slot10, align 8
  %page_mapped12 = icmp ne ptr %page11, null
  br i1 %page_mapped12, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned8
  %111 = and i32 %plshift2, 4095
  %page_offset13 = zext i32 %111 to i64
  %112 = getelementptr i8, ptr %page11, i64 %page_offset13
  store i32 %xor32, ptr %112, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned8
  %113 = getelementptr i8, ptr %cpu, i32 188
  store i32 65994, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %115, align 4
  call void @mem_write32(ptr %mem, i32 %plshift2, i32 %xor32)
  %116 = getelementptr i8, ptr %cpu, i32 296
  %dj16 = load i8, ptr %116, align 1
  %dj_set17 = icmp ne i8 %dj16, 0
  br i1 %dj_set17, label %did_jump_exit14, label %did_jump_cont15, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont15, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %117 = icmp ne i8 %cec_pending, 0
  br i1 %117, label %cec_check, label %cec_checked, !prof !1

did_jump_exit14:                                  ; preds = %page_wr_slow
  %118 = getelementptr i8, ptr %cpu, i64 188
  %next_pc112 = load i32, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i64 188
  %120 = load i32, ptr %119, align 4
  %121 = getelementptr i8, ptr %cpu, i64 296
  %122 = load i8, ptr %121, align 1
  br label %chain_exit

did_jump_cont15:                                  ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 65996, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 8, ptr %125, align 4
  call void @cec_check_pending(ptr %cpu)
  %126 = getelementptr i8, ptr %cpu, i32 296
  %dj20 = load i8, ptr %126, align 1
  %dj_set21 = icmp ne i8 %dj20, 0
  br i1 %dj_set21, label %did_jump_exit18, label %did_jump_cont19, !prof !1

cec_checked:                                      ; preds = %did_jump_cont19, %page_wr_done
  br label %insn_0x000101cc_entry

did_jump_exit18:                                  ; preds = %cec_check
  %127 = getelementptr i8, ptr %cpu, i64 188
  %next_pc113 = load i32, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 188
  %129 = load i32, ptr %128, align 4
  %130 = getelementptr i8, ptr %cpu, i64 296
  %131 = load i8, ptr %130, align 1
  br label %chain_exit

did_jump_cont19:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x000101cc_entry:                            ; preds = %cec_checked
  br label %insn_0x000101cc

insn_0x000101cc:                                  ; preds = %insn_0x000101cc_entry
  %132 = getelementptr i8, ptr %cpu, i32 40
  store i32 %add32, ptr %132, align 4
  br label %insn_0x000101ce_entry

insn_0x000101ce_entry:                            ; preds = %insn_0x000101cc
  br label %insn_0x000101ce

insn_0x000101ce:                                  ; preds = %insn_0x000101ce_entry
  %rd_add = add i32 %rs, 1
  %133 = getelementptr i8, ptr %cpu, i32 8
  store i32 %rd_add, ptr %133, align 4
  %flgs22 = lshr i32 %rs, 31
  %flgn23 = lshr i32 %rd_add, 31
  %134 = xor i32 0, %flgn23
  %135 = xor i32 %flgs22, %flgn23
  %overflow = and i32 %135, %134
  %136 = xor i32 %rs, -1
  %137 = icmp ult i32 %136, 1
  %ac024 = zext i1 %137 to i32
  %138 = icmp eq i32 %rd_add, 0
  %az25 = zext i1 %138 to i32
  %an26 = lshr i32 %rd_add, 31
  %139 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az25, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an26, ptr %140, align 4
  %141 = or i32 %80, %overflow
  %142 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %142, align 4
  %143 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i32 256
  store i32 %141, ptr %144, align 4
  %145 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac024, ptr %145, align 4
  %146 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac024, ptr %146, align 4
  br label %insn_0x000101d0_entry

insn_0x000101d0_entry:                            ; preds = %insn_0x000101ce
  br label %insn_0x000101d0

insn_0x000101d0:                                  ; preds = %insn_0x000101d0_entry
  %147 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %147, align 4
  %148 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %148 to i32
  %149 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %149, align 4
  %150 = icmp eq i32 %rx, %rd_add
  %az27 = zext i1 %150 to i32
  %151 = icmp ugt i32 %rd_add, %rx
  %an28 = zext i1 %151 to i32
  %152 = icmp ule i32 %rd_add, %rx
  %ac029 = zext i1 %152 to i32
  %153 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az27, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an28, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac029, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac029, ptr %156, align 4
  br label %insn_0x000101d2_entry

insn_0x000101d2_entry:                            ; preds = %insn_0x000101d0
  br label %insn_0x000101d2

insn_0x000101d2:                                  ; preds = %insn_0x000101d2_entry
  %157 = getelementptr i8, ptr %cpu, i32 36
  %ps30 = load i32, ptr %157, align 4
  %padd = add i32 %ps30, %add32
  %158 = getelementptr i8, ptr %cpu, i32 36
  store i32 %padd, ptr %158, align 4
  br label %insn_0x000101d4_entry

insn_0x000101d4_entry:                            ; preds = %insn_0x000101d2
  br label %insn_0x000101d4

insn_0x000101d4:                                  ; preds = %insn_0x000101d4_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x000101d4
  %159 = getelementptr i8, ptr %cpu, i32 188
  store i32 65978, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %160, align 4
  %chain_total = add nuw i32 %chain_packets, 13
  %161 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %161 monotonic, align 4, !range !2
  %162 = icmp ult i32 %chain_total, %chain_budget
  br i1 %162, label %chain_go, label %chain_leave114, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x000101d4
  br label %insn_0x000101d6_entry

insn_0x000101d6_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x000101d6

insn_0x000101d6:                                  ; preds = %insn_0x000101d6_entry
  %163 = getelementptr i8, ptr %cpu, i32 4
  store i32 8191, ptr %163, align 4
  br label %insn_0x000101da_entry

insn_0x000101da_entry:                            ; preds = %insn_0x000101d6
  br label %insn_0x000101da

insn_0x000101da:                                  ; preds = %insn_0x000101da_entry
  %rd_add31 = add i32 %rx, -1
  %164 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rd_add31, ptr %164, align 4
  %flgs32 = lshr i32 %rx, 31
  %flgn33 = lshr i32 %rd_add31, 31
  %165 = xor i32 1, %flgn33
  %166 = xor i32 %flgs32, %flgn33
  %overflow34 = and i32 %166, %165
  %167 = xor i32 %rx, -1
  %168 = icmp ult i32 %167, -1
  %ac035 = zext i1 %168 to i32
  %169 = icmp eq i32 %rd_add31, 0
  %az36 = zext i1 %169 to i32
  %an37 = lshr i32 %rd_add31, 31
  %170 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az36, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an37, ptr %171, align 4
  %172 = or i32 %141, %overflow34
  %173 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow34, ptr %173, align 4
  %174 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow34, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i32 256
  store i32 %172, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac035, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac035, ptr %177, align 4
  br label %insn_0x000101dc_entry

insn_0x000101dc_entry:                            ; preds = %insn_0x000101da
  br label %insn_0x000101dc

insn_0x000101dc:                                  ; preds = %insn_0x000101dc_entry
  %and3238 = and i32 8191, %rd_add31
  %178 = getelementptr i8, ptr %cpu, i32 0
  store i32 %and3238, ptr %178, align 4
  %179 = icmp eq i32 %and3238, 0
  %az39 = zext i1 %179 to i32
  %an40 = lshr i32 %and3238, 31
  %180 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az39, ptr %180, align 4
  %181 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an40, ptr %181, align 4
  %182 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %185, align 4
  br label %insn_0x000101de_entry

insn_0x000101de_entry:                            ; preds = %insn_0x000101dc
  br label %insn_0x000101de

insn_0x000101de:                                  ; preds = %insn_0x000101de_entry
  %186 = getelementptr i8, ptr %cpu, i32 40
  store i32 %and3238, ptr %186, align 4
  br label %insn_0x000101e0_entry

insn_0x000101e0_entry:                            ; preds = %insn_0x000101de
  br label %insn_0x000101e0

insn_0x000101e0:                                  ; preds = %insn_0x000101e0_entry
  %187 = getelementptr i8, ptr %cpu, i32 4
  store i32 %padd, ptr %187, align 4
  br label %insn_0x000101e2_entry

insn_0x000101e2_entry:                            ; preds = %insn_0x000101e0
  br label %insn_0x000101e2

insn_0x000101e2:                                  ; preds = %insn_0x000101e2_entry
  %188 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %188, align 4
  %189 = and i32 %fp, 3
  %190 = icmp ne i32 %189, 0
  br i1 %190, label %data_misaligned41, label %data_aligned42, !prof !1

data_misaligned41:                                ; preds = %insn_0x000101e2
  %191 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %191, align 4
  %192 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %193, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66018, i32 %fp, i32 0)
  %194 = getelementptr i8, ptr %cpu, i64 188
  %next_pc115 = load i32, ptr %194, align 4
  %195 = getelementptr i8, ptr %cpu, i64 188
  %196 = load i32, ptr %195, align 4
  %197 = getelementptr i8, ptr %cpu, i64 296
  %198 = load i8, ptr %197, align 1
  br label %chain_exit

data_aligned42:                                   ; preds = %insn_0x000101e2
  %199 = lshr i32 %fp, 12
  %page_index46 = zext i32 %199 to i64
  %page_slot47 = getelementptr ptr, ptr %page_table, i64 %page_index46
  %page48 = load ptr, ptr %page_slot47, align 8
  %page_mapped49 = icmp ne ptr %page48, null
  br i1 %page_mapped49, label %page_fast43, label %page_slow44, !prof !0

page_fast43:                                      ; preds = %data_aligned42
  %200 = and i32 %fp, 4095
  %page_offset50 = zext i32 %200 to i64
  %201 = getelementptr i8, ptr %page48, i64 %page_offset50
  %page_val51 = load i32, ptr %201, align 4
  br label %page_done45

page_slow44:                                      ; preds = %data_aligned42
  %202 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %204, align 4
  %205 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %206 = getelementptr i8, ptr %cpu, i32 296
  %dj54 = load i8, ptr %206, align 1
  %dj_set55 = icmp ne i8 %dj54, 0
  br i1 %dj_set55, label %did_jump_exit52, label %did_jump_cont53, !prof !1

page_done45:                                      ; preds = %did_jump_cont53, %page_fast43
  %mem_val56 = phi i32 [ %page_val51, %page_fast43 ], [ %205, %did_jump_cont53 ]
  %sp1 = add i32 %fp, 4
  %207 = and i32 %sp1, 3
  %208 = icmp ne i32 %207, 0
  br i1 %208, label %data_misaligned57, label %data_aligned58, !prof !1

did_jump_exit52:                                  ; preds = %page_slow44
  %209 = getelementptr i8, ptr %cpu, i64 188
  %next_pc116 = load i32, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i64 188
  %211 = load i32, ptr %210, align 4
  %212 = getelementptr i8, ptr %cpu, i64 296
  %213 = load i8, ptr %212, align 1
  br label %chain_exit

did_jump_cont53:                                  ; preds = %page_slow44
  br label %page_done45

data_misaligned57:                                ; preds = %page_done45
  %214 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %216, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66018, i32 %sp1, i32 0)
  %217 = getelementptr i8, ptr %cpu, i64 188
  %next_pc117 = load i32, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i64 188
  %219 = load i32, ptr %218, align 4
  %220 = getelementptr i8, ptr %cpu, i64 296
  %221 = load i8, ptr %220, align 1
  br label %chain_exit

data_aligned58:                                   ; preds = %page_done45
  %222 = lshr i32 %sp1, 12
  %page_index62 = zext i32 %222 to i64
  %page_slot63 = getelementptr ptr, ptr %page_table, i64 %page_index62
  %page64 = load ptr, ptr %page_slot63, align 8
  %page_mapped65 = icmp ne ptr %page64, null
  br i1 %page_mapped65, label %page_fast59, label %page_slow60, !prof !0

page_fast59:                                      ; preds = %data_aligned58
  %223 = and i32 %sp1, 4095
  %page_offset66 = zext i32 %223 to i64
  %224 = getelementptr i8, ptr %page64, i64 %page_offset66
  %page_val67 = load i32, ptr %224, align 4
  br label %page_done61

page_slow60:                                      ; preds = %data_aligned58
  %225 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %225, align 4
  %226 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %226, align 4
  %227 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %227, align 4
  %228 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %229 = getelementptr i8, ptr %cpu, i32 296
  %dj70 = load i8, ptr %229, align 1
  %dj_set71 = icmp ne i8 %dj70, 0
  br i1 %dj_set71, label %did_jump_exit68, label %did_jump_cont69, !prof !1

page_done61:                                      ; preds = %did_jump_cont69, %page_fast59
  %mem_val72 = phi i32 [ %page_val67, %page_fast59 ], [ %228, %did_jump_cont69 ]
  %sp2 = add i32 %sp1, 4
  %230 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val56, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val72, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %232, align 4
  br label %insn_0x000101e6_entry

did_jump_exit68:                                  ; preds = %page_slow60
  %233 = getelementptr i8, ptr %cpu, i64 188
  %next_pc118 = load i32, ptr %233, align 4
  %234 = getelementptr i8, ptr %cpu, i64 188
  %235 = load i32, ptr %234, align 4
  %236 = getelementptr i8, ptr %cpu, i64 296
  %237 = load i8, ptr %236, align 1
  br label %chain_exit

did_jump_cont69:                                  ; preds = %page_slow60
  br label %page_done61

insn_0x000101e6_entry:                            ; preds = %page_done61
  br label %insn_0x000101e6

insn_0x000101e6:                                  ; preds = %insn_0x000101e6_entry
  %238 = and i32 %sp2, 3
  %239 = icmp ne i32 %238, 0
  br i1 %239, label %data_misaligned73, label %data_aligned74, !prof !1

data_misaligned73:                                ; preds = %insn_0x000101e6
  %240 = getelementptr i8, ptr %cpu, i32 188
  store i32 66022, ptr %240, align 4
  %241 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %241, align 4
  %242 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %242, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66022, i32 %sp2, i32 0)
  %243 = getelementptr i8, ptr %cpu, i64 188
  %next_pc119 = load i32, ptr %243, align 4
  %244 = getelementptr i8, ptr %cpu, i64 188
  %245 = load i32, ptr %244, align 4
  %246 = getelementptr i8, ptr %cpu, i64 296
  %247 = load i8, ptr %246, align 1
  br label %chain_exit

data_aligned74:                                   ; preds = %insn_0x000101e6
  %248 = lshr i32 %sp2, 12
  %page_index78 = zext i32 %248 to i64
  %page_slot79 = getelementptr ptr, ptr %page_table, i64 %page_index78
  %page80 = load ptr, ptr %page_slot79, align 8
  %page_mapped81 = icmp ne ptr %page80, null
  br i1 %page_mapped81, label %page_fast75, label %page_slow76, !prof !0

page_fast75:                                      ; preds = %data_aligned74
  %249 = and i32 %sp2, 4095
  %page_offset82 = zext i32 %249 to i64
  %250 = getelementptr i8, ptr %page80, i64 %page_offset82
  %page_val83 = load i32, ptr %250, align 4
  br label %page_done77

page_slow76:                                      ; preds = %data_aligned74
  %251 = getelementptr i8, ptr %cpu, i32 188
  store i32 66022, ptr %251, align 4
  %252 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %252, align 4
  %253 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %253, align 4
  %254 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %255 = getelementptr i8, ptr %cpu, i32 296
  %dj86 = load i8, ptr %255, align 1
  %dj_set87 = icmp ne i8 %dj86, 0
  br i1 %dj_set87, label %did_jump_exit84, label %did_jump_cont85, !prof !1

page_done77:                                      ; preds = %did_jump_cont85, %page_fast75
  %mem_val88 = phi i32 [ %page_val83, %page_fast75 ], [ %254, %did_jump_cont85 ]
  %256 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val88, ptr %256, align 4
  %sp_inc = add i32 %sp2, 4
  %257 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc, ptr %257, align 4
  br label %insn_0x000101e8_entry

did_jump_exit84:                                  ; preds = %page_slow76
  %258 = getelementptr i8, ptr %cpu, i64 188
  %next_pc120 = load i32, ptr %258, align 4
  %259 = getelementptr i8, ptr %cpu, i64 188
  %260 = load i32, ptr %259, align 4
  %261 = getelementptr i8, ptr %cpu, i64 296
  %262 = load i8, ptr %261, align 1
  br label %chain_exit

did_jump_cont85:                                  ; preds = %page_slow76
  br label %page_done77

insn_0x000101e8_entry:                            ; preds = %page_done77
  br label %insn_0x000101e8

insn_0x000101e8:                                  ; preds = %insn_0x000101e8_entry
  %263 = shl i32 %and3238, 2
  %plshift289 = add i32 %ps, %263
  %264 = getelementptr i8, ptr %cpu, i32 32
  store i32 %plshift289, ptr %264, align 4
  br label %insn_0x000101ea_entry

insn_0x000101ea_entry:                            ; preds = %insn_0x000101e8
  br label %insn_0x000101ea

insn_0x000101ea:                                  ; preds = %insn_0x000101ea_entry
  %265 = and i32 %plshift289, 3
  %266 = icmp ne i32 %265, 0
  br i1 %266, label %data_misaligned90, label %data_aligned91, !prof !1

data_misaligned90:                                ; preds = %insn_0x000101ea
  %267 = getelementptr i8, ptr %cpu, i32 188
  store i32 66026, ptr %267, align 4
  %268 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %268, align 4
  %269 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %269, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66026, i32 %plshift289, i32 0)
  %270 = getelementptr i8, ptr %cpu, i64 188
  %next_pc121 = load i32, ptr %270, align 4
  %271 = getelementptr i8, ptr %cpu, i64 188
  %272 = load i32, ptr %271, align 4
  %273 = getelementptr i8, ptr %cpu, i64 296
  %274 = load i8, ptr %273, align 1
  br label %chain_exit

data_aligned91:                                   ; preds = %insn_0x000101ea
  %275 = lshr i32 %plshift289, 12
  %page_index95 = zext i32 %275 to i64
  %page_slot96 = getelementptr ptr, ptr %page_table, i64 %page_index95
  %page97 = load ptr, ptr %page_slot96, align 8
  %page_mapped98 = icmp ne ptr %page97, null
  br i1 %page_mapped98, label %page_fast92, label %page_slow93, !prof !0

page_fast92:                                      ; preds = %data_aligned91
  %276 = and i32 %plshift289, 4095
  %page_offset99 = zext i32 %276 to i64
  %277 = getelementptr i8, ptr %page97, i64 %page_offset99
  %page_val100 = load i32, ptr %277, align 4
  br label %page_done94

page_slow93:                                      ; preds = %data_aligned91
  %278 = getelementptr i8, ptr %cpu, i32 188
  store i32 66026, ptr %278, align 4
  %279 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %280, align 4
  %281 = call i32 @mem_read32(ptr %mem, i32 %plshift289)
  %282 = getelementptr i8, ptr %cpu, i32 296
  %dj103 = load i8, ptr %282, align 1
  %dj_set104 = icmp ne i8 %dj103, 0
  br i1 %dj_set104, label %did_jump_exit101, label %did_jump_cont102, !prof !1

page_done94:                                      ; preds = %did_jump_cont102, %page_fast92
  %mem_val105 = phi i32 [ %page_val100, %page_fast92 ], [ %281, %did_jump_cont102 ]
  %283 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val105, ptr %283, align 4
  br label %insn_0x000101ec_entry

did_jump_exit101:                                 ; preds = %page_slow93
  %284 = getelementptr i8, ptr %cpu, i64 188
  %next_pc122 = load i32, ptr %284, align 4
  %285 = getelementptr i8, ptr %cpu, i64 188
  %286 = load i32, ptr %285, align 4
  %287 = getelementptr i8, ptr %cpu, i64 296
  %288 = load i8, ptr %287, align 1
  br label %chain_exit

did_jump_cont102:                                 ; preds = %page_slow93
  br label %page_done94

insn_0x000101ec_entry:                            ; preds = %page_done94
  br label %insn_0x000101ec

insn_0x000101ec:                                  ; preds = %insn_0x000101ec_entry
  %xor32106 = xor i32 %mem_val105, %padd
  %289 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32106, ptr %289, align 4
  %290 = icmp eq i32 %xor32106, 0
  %az107 = zext i1 %290 to i32
  %an108 = lshr i32 %xor32106, 31
  %291 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az107, ptr %291, align 4
  %292 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an108, ptr %292, align 4
  %293 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %293, align 4
  %294 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %294, align 4
  %295 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %295, align 4
  %296 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %296, align 4
  br label %insn_0x000101ee_entry

insn_0x000101ee_entry:                            ; preds = %insn_0x000101ec
  br label %insn_0x000101ee

insn_0x000101ee:                                  ; preds = %insn_0x000101ee_entry
  %lsb = and i32 %mem_val72, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x000101ee
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x000101ee
  %297 = getelementptr i8, ptr %cpu, i32 188
  store i32 66030, ptr %297, align 4
  %298 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %298, align 4
  %299 = getelementptr i8, ptr %cpu, i32 308
  store i32 24, ptr %299, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %300 = getelementptr i8, ptr %cpu, i64 188
  %next_pc123 = load i32, ptr %300, align 4
  %301 = getelementptr i8, ptr %cpu, i64 188
  %302 = load i32, ptr %301, align 4
  %303 = getelementptr i8, ptr %cpu, i64 296
  %304 = load i8, ptr %303, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %305 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %305, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %306 = getelementptr i8, ptr %cpu, i64 188
  store i32 65978, ptr %306, align 4
  %307 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %307, align 4
  br label %insn_0x000101ba_entry

chain_leave114:                                   ; preds = %brcc_taken
  %308 = getelementptr i8, ptr %cpu, i64 188
  store i32 65978, ptr %308, align 4
  %309 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %309, align 4
  %310 = getelementptr i8, ptr %cpu, i64 308
  store i32 13, ptr %310, align 4
  %311 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %311, align 1
  br label %return

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit101, %data_misaligned90, %did_jump_exit84, %data_misaligned73, %did_jump_exit68, %data_misaligned57, %did_jump_exit52, %data_misaligned41, %did_jump_exit18, %did_jump_exit14, %data_misaligned7, %did_jump_exit, %data_misaligned
  %next_pc124 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc110, %did_jump_exit ], [ %next_pc111, %data_misaligned7 ], [ %next_pc112, %did_jump_exit14 ], [ %next_pc113, %did_jump_exit18 ], [ %next_pc115, %data_misaligned41 ], [ %next_pc116, %did_jump_exit52 ], [ %next_pc117, %data_misaligned57 ], [ %next_pc118, %did_jump_exit68 ], [ %next_pc119, %data_misaligned73 ], [ %next_pc120, %did_jump_exit84 ], [ %next_pc121, %data_misaligned90 ], [ %next_pc122, %did_jump_exit101 ], [ %mem_val72, %jump_aligned ], [ %next_pc123, %jump_misalign ]
  %packets = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 8, %data_misaligned7 ], [ 8, %did_jump_exit14 ], [ 8, %did_jump_exit18 ], [ 19, %data_misaligned41 ], [ 19, %did_jump_exit52 ], [ 19, %data_misaligned57 ], [ 19, %did_jump_exit68 ], [ 20, %data_misaligned73 ], [ 20, %did_jump_exit84 ], [ 22, %data_misaligned90 ], [ 22, %did_jump_exit101 ], [ 24, %jump_aligned ], [ 24, %jump_misalign ]
  %tail = phi i32 [ %53, %data_misaligned ], [ %67, %did_jump_exit ], [ %107, %data_misaligned7 ], [ %120, %did_jump_exit14 ], [ %129, %did_jump_exit18 ], [ %196, %data_misaligned41 ], [ %211, %did_jump_exit52 ], [ %219, %data_misaligned57 ], [ %235, %did_jump_exit68 ], [ %245, %data_misaligned73 ], [ %260, %did_jump_exit84 ], [ %272, %data_misaligned90 ], [ %286, %did_jump_exit101 ], [ %mem_val72, %jump_aligned ], [ %302, %jump_misalign ]
  %tail125 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned7 ], [ 2, %did_jump_exit14 ], [ 2, %did_jump_exit18 ], [ 4, %data_misaligned41 ], [ 4, %did_jump_exit52 ], [ 4, %data_misaligned57 ], [ 4, %did_jump_exit68 ], [ 2, %data_misaligned73 ], [ 2, %did_jump_exit84 ], [ 2, %data_misaligned90 ], [ 2, %did_jump_exit101 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail126 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 8, %data_misaligned7 ], [ 8, %did_jump_exit14 ], [ 8, %did_jump_exit18 ], [ 19, %data_misaligned41 ], [ 19, %did_jump_exit52 ], [ 19, %data_misaligned57 ], [ 19, %did_jump_exit68 ], [ 20, %data_misaligned73 ], [ 20, %did_jump_exit84 ], [ 22, %data_misaligned90 ], [ 22, %did_jump_exit101 ], [ 24, %jump_aligned ], [ 24, %jump_misalign ]
  %tail127 = phi i8 [ %55, %data_misaligned ], [ %69, %did_jump_exit ], [ %109, %data_misaligned7 ], [ %122, %did_jump_exit14 ], [ %131, %did_jump_exit18 ], [ %198, %data_misaligned41 ], [ %213, %did_jump_exit52 ], [ %221, %data_misaligned57 ], [ %237, %did_jump_exit68 ], [ %247, %data_misaligned73 ], [ %262, %did_jump_exit84 ], [ %274, %data_misaligned90 ], [ %288, %did_jump_exit101 ], [ 1, %jump_aligned ], [ %304, %jump_misalign ]
  %312 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets129 = load i32, ptr %312, align 4
  %chain_total130 = add nuw i32 %chain_packets129, %packets
  %313 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget131 = load atomic i32, ptr %313 monotonic, align 4, !range !2
  %314 = icmp ult i32 %chain_total130, %chain_budget131
  br i1 %314, label %chain_lookup, label %chain_leave128, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %315 = icmp eq i32 %next_pc124, 65978
  br i1 %315, label %chain_self, label %chain_other, !prof !3

chain_leave128:                                   ; preds = %chain_other, %chain_exit
  %316 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %316, align 4
  %317 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail125, ptr %317, align 4
  %318 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail126, ptr %318, align 4
  %319 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail127, ptr %319, align 1
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %320 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc124, ptr %320, align 4
  %321 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total130, ptr %321, align 4
  %322 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %322, align 1
  br label %insn_0x000101ba_entry

chain_other:                                      ; preds = %chain_lookup
  %323 = lshr i32 %next_pc124, 1
  %324 = and i32 %323, 65535
  %325 = zext i32 %324 to i64
  %326 = mul i64 %325, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %326
  %327 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %327, align 4
  %328 = icmp eq i32 %slot_pc, %next_pc124
  br i1 %328, label %chain_hit, label %chain_leave128, !prof !0

chain_hit:                                        ; preds = %chain_other
  %329 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc124, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total130, ptr %330, align 4
  %331 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %331, align 1
  %332 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %332, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave128, %chain_leave114, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
!3 = !{!"branch_weights", i32 63, i32 1}
