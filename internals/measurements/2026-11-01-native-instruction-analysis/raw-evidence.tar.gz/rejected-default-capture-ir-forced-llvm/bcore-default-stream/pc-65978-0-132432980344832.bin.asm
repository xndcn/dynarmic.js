
build-native-instruction-analysis/capture/bcore-default-stream/pc-65978-0-132432980344832.bin:     file format binary


Disassembly of section .data:

0000787274c00000 <.data>:
    787274c00000:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    787274c00007:	01 
    787274c00008:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    787274c0000f:	00 
    787274c00010:	48 81 c4 88 00 00 00 	add    rsp,0x88
    787274c00017:	c2 08 00             	ret    0x8
