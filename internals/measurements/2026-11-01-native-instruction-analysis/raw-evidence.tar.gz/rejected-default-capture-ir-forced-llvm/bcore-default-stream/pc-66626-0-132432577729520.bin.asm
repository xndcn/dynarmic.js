
build-native-instruction-analysis/capture/bcore-default-stream/pc-66626-0-132432577729520.bin:     file format binary


Disassembly of section .data:

000078725cc093f0 <.data>:
    78725cc093f0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    78725cc093f7:	4c 89 74 24 68       	mov    QWORD PTR [rsp+0x68],r14
    78725cc093fc:	4c 89 6c 24 70       	mov    QWORD PTR [rsp+0x70],r13
    78725cc09401:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc09408:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc0940d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc09414:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc0941b:	00 
    78725cc0941c:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    78725cc09421:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc09427:	83 fa 00             	cmp    edx,0x0
    78725cc0942a:	0f 94 c0             	sete   al
    78725cc0942d:	81 ea 42 04 01 00    	sub    edx,0x10442
    78725cc09433:	83 fa 0c             	cmp    edx,0xc
    78725cc09436:	0f 97 c2             	seta   dl
    78725cc09439:	08 d0                	or     al,dl
    78725cc0943b:	24 01                	and    al,0x1
    78725cc0943d:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc09443:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc09449:	0f 94 c1             	sete   cl
    78725cc0944c:	81 ea 42 04 01 00    	sub    edx,0x10442
    78725cc09452:	83 fa 0c             	cmp    edx,0xc
    78725cc09455:	0f 97 c2             	seta   dl
    78725cc09458:	08 d1                	or     cl,dl
    78725cc0945a:	20 c8                	and    al,cl
    78725cc0945c:	a8 01                	test   al,0x1
    78725cc0945e:	75 05                	jne    0x78725cc09465
    78725cc09460:	e9 d6 02 00 00       	jmp    0x78725cc0973b
    78725cc09465:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0946a:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc09471:	48 89 c8             	mov    rax,rcx
    78725cc09474:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0947a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    78725cc0947f:	8b 81 24 00 10 00    	mov    eax,DWORD PTR [rcx+0x100024]
    78725cc09485:	83 c0 01             	add    eax,0x1
    78725cc09488:	89 81 24 00 10 00    	mov    DWORD PTR [rcx+0x100024],eax
    78725cc0948e:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc09493:	75 40                	jne    0x78725cc094d5
    78725cc09495:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    78725cc0949a:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc094a0:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    78725cc094a4:	89 c2                	mov    edx,eax
    78725cc094a6:	83 c2 01             	add    edx,0x1
    78725cc094a9:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc094af:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc094b4:	73 1d                	jae    0x78725cc094d3
    78725cc094b6:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    78725cc094bb:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc094bf:	89 c9                	mov    ecx,ecx
    78725cc094c1:	48 c1 e1 02          	shl    rcx,0x2
    78725cc094c5:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc094cc:	c7 04 08 09 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x9
    78725cc094d3:	eb 00                	jmp    0x78725cc094d5
    78725cc094d5:	eb 00                	jmp    0x78725cc094d7
    78725cc094d7:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc094dc:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    78725cc094df:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc094e5:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc094eb:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    78725cc094ef:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc094f2:	eb 00                	jmp    0x78725cc094f4
    78725cc094f4:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc094f9:	8b 4c 24 58          	mov    ecx,DWORD PTR [rsp+0x58]
    78725cc094fd:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc09503:	81 c9 9c 11 00 00    	or     ecx,0x119c
    78725cc09509:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    78725cc0950d:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc09510:	eb 00                	jmp    0x78725cc09512
    78725cc09512:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc09517:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc0951b:	8b 50 28             	mov    edx,DWORD PTR [rax+0x28]
    78725cc0951e:	c1 e2 02             	shl    edx,0x2
    78725cc09521:	01 d1                	add    ecx,edx
    78725cc09523:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc09527:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0952a:	eb 00                	jmp    0x78725cc0952c
    78725cc0952c:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc09530:	83 e0 03             	and    eax,0x3
    78725cc09533:	83 f8 00             	cmp    eax,0x0
    78725cc09536:	74 7c                	je     0x78725cc095b4
    78725cc09538:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    78725cc0953d:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    78725cc09541:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    78725cc09546:	c7 87 bc 00 00 00 4c 	mov    DWORD PTR [rdi+0xbc],0x1044c
    78725cc0954d:	04 01 00 
    78725cc09550:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc09557:	00 00 00 
    78725cc0955a:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc09561:	00 00 00 
    78725cc09564:	31 c0                	xor    eax,eax
    78725cc09566:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0956d:	60 00 00 
    78725cc09570:	ba 4c 04 01 00       	mov    edx,0x1044c
    78725cc09575:	45 31 c0             	xor    r8d,r8d
    78725cc09578:	ff d0                	call   rax
    78725cc0957a:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0957f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc09585:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0958b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc09591:	be 04 00 00 00       	mov    esi,0x4
    78725cc09596:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0959b:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    78725cc0959f:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    78725cc095a3:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    78725cc095a7:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc095ab:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    78725cc095af:	e9 98 01 00 00       	jmp    0x78725cc0974c
    78725cc095b4:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc095bb:	00 
    78725cc095bc:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    78725cc095c0:	c1 e9 0c             	shr    ecx,0xc
    78725cc095c3:	89 c9                	mov    ecx,ecx
    78725cc095c5:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc095c9:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    78725cc095ce:	48 83 f8 00          	cmp    rax,0x0
    78725cc095d2:	74 1a                	je     0x78725cc095ee
    78725cc095d4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc095d9:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    78725cc095dd:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc095e3:	89 c9                	mov    ecx,ecx
    78725cc095e5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc095e8:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc095ec:	eb 4e                	jmp    0x78725cc0963c
    78725cc095ee:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc095f3:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    78725cc095f7:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc095fc:	c7 80 bc 00 00 00 4c 	mov    DWORD PTR [rax+0xbc],0x1044c
    78725cc09603:	04 01 00 
    78725cc09606:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0960d:	00 00 00 
    78725cc09610:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc09617:	00 00 00 
    78725cc0961a:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc09621:	60 00 00 
    78725cc09624:	ff d0                	call   rax
    78725cc09626:	89 c1                	mov    ecx,eax
    78725cc09628:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0962d:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    78725cc09631:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc09638:	75 14                	jne    0x78725cc0964e
    78725cc0963a:	eb 4c                	jmp    0x78725cc09688
    78725cc0963c:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc09641:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc09645:	89 4c 24 24          	mov    DWORD PTR [rsp+0x24],ecx
    78725cc09649:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0964c:	eb 44                	jmp    0x78725cc09692
    78725cc0964e:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc09653:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc09659:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0965f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc09665:	be 04 00 00 00       	mov    esi,0x4
    78725cc0966a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0966f:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    78725cc09673:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    78725cc09677:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    78725cc0967b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc0967f:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    78725cc09683:	e9 c4 00 00 00       	jmp    0x78725cc0974c
    78725cc09688:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    78725cc0968c:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc09690:	eb aa                	jmp    0x78725cc0963c
    78725cc09692:	eb 00                	jmp    0x78725cc09694
    78725cc09694:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    78725cc09698:	83 e0 01             	and    eax,0x1
    78725cc0969b:	83 f8 00             	cmp    eax,0x0
    78725cc0969e:	75 2b                	jne    0x78725cc096cb
    78725cc096a0:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    78725cc096a4:	be 05 00 00 00       	mov    esi,0x5
    78725cc096a9:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc096ae:	b0 01                	mov    al,0x1
    78725cc096b0:	89 d7                	mov    edi,edx
    78725cc096b2:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    78725cc096b6:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    78725cc096ba:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    78725cc096be:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc096c2:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    78725cc096c6:	e9 81 00 00 00       	jmp    0x78725cc0974c
    78725cc096cb:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    78725cc096d0:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    78725cc096d5:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1044e
    78725cc096dc:	04 01 00 
    78725cc096df:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc096e6:	00 00 00 
    78725cc096e9:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    78725cc096f0:	00 00 00 
    78725cc096f3:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc096fa:	60 00 00 
    78725cc096fd:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc09702:	ff d0                	call   rax
    78725cc09704:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc09709:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0970f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09715:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0971b:	be 05 00 00 00       	mov    esi,0x5
    78725cc09720:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc09725:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    78725cc09729:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    78725cc0972d:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    78725cc09731:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc09735:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    78725cc09739:	eb 11                	jmp    0x78725cc0974c
    78725cc0973b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc09740:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc09747:	e9 d2 00 00 00       	jmp    0x78725cc0981e
    78725cc0974c:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    78725cc09751:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    78725cc09755:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    78725cc09759:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc0975d:	8b 7c 24 48          	mov    edi,DWORD PTR [rsp+0x48]
    78725cc09761:	8a 5c 24 4f          	mov    bl,BYTE PTR [rsp+0x4f]
    78725cc09765:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    78725cc09769:	89 c3                	mov    ebx,eax
    78725cc0976b:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    78725cc0976f:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    78725cc09773:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    78725cc09777:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    78725cc0977b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc09781:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    78725cc09785:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0978b:	73 29                	jae    0x78725cc097b6
    78725cc0978d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc09792:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    78725cc09796:	89 d1                	mov    ecx,edx
    78725cc09798:	c1 e9 01             	shr    ecx,0x1
    78725cc0979b:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc097a1:	89 c9                	mov    ecx,ecx
    78725cc097a3:	48 c1 e1 04          	shl    rcx,0x4
    78725cc097a7:	48 89 c6             	mov    rsi,rax
    78725cc097aa:	48 01 ce             	add    rsi,rcx
    78725cc097ad:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    78725cc097b1:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc097b4:	74 2f                	je     0x78725cc097e5
    78725cc097b6:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc097bb:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    78725cc097bf:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    78725cc097c3:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    78725cc097c7:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    78725cc097cb:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc097d1:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc097d7:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc097dd:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc097e3:	eb 39                	jmp    0x78725cc0981e
    78725cc097e5:	4c 8b 74 24 68       	mov    r14,QWORD PTR [rsp+0x68]
    78725cc097ea:	4c 8b 6c 24 70       	mov    r13,QWORD PTR [rsp+0x70]
    78725cc097ef:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    78725cc097f3:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    78725cc097f7:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    78725cc097fb:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc09802:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc09809:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc09810:	00 
    78725cc09811:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc09815:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc0981c:	ff e0                	jmp    rax
    78725cc0981e:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc09825:	c2 08 00             	ret    0x8
