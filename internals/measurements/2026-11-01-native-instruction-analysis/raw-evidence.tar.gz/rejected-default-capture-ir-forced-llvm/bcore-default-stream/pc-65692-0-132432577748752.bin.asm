
build-native-instruction-analysis/capture/bcore-default-stream/pc-65692-0-132432577748752.bin:     file format binary


Disassembly of section .data:

000078725cc0df10 <.data>:
    78725cc0df10:	48 81 ec 98 01 00 00 	sub    rsp,0x198
    78725cc0df17:	4c 89 b4 24 70 01 00 	mov    QWORD PTR [rsp+0x170],r14
    78725cc0df1e:	00 
    78725cc0df1f:	4c 89 ac 24 78 01 00 	mov    QWORD PTR [rsp+0x178],r13
    78725cc0df26:	00 
    78725cc0df27:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0df2e:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    78725cc0df35:	00 
    78725cc0df36:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0df3d:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    78725cc0df44:	00 
    78725cc0df45:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0df4c:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    78725cc0df53:	00 
    78725cc0df54:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0df5b:	00 
    78725cc0df5c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc0df62:	83 fa 00             	cmp    edx,0x0
    78725cc0df65:	0f 94 c0             	sete   al
    78725cc0df68:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    78725cc0df6e:	83 fa 22             	cmp    edx,0x22
    78725cc0df71:	0f 97 c2             	seta   dl
    78725cc0df74:	08 d0                	or     al,dl
    78725cc0df76:	24 01                	and    al,0x1
    78725cc0df78:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0df7e:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc0df84:	0f 94 c1             	sete   cl
    78725cc0df87:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    78725cc0df8d:	83 fa 22             	cmp    edx,0x22
    78725cc0df90:	0f 97 c2             	seta   dl
    78725cc0df93:	08 d1                	or     cl,dl
    78725cc0df95:	20 c8                	and    al,cl
    78725cc0df97:	a8 01                	test   al,0x1
    78725cc0df99:	75 05                	jne    0x78725cc0dfa0
    78725cc0df9b:	e9 0a 1c 00 00       	jmp    0x78725cc0fbaa
    78725cc0dfa0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0dfa7:	00 
    78725cc0dfa8:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc0dfaf:	48 89 c8             	mov    rax,rcx
    78725cc0dfb2:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0dfb8:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    78725cc0dfbf:	00 
    78725cc0dfc0:	8b 81 34 00 10 00    	mov    eax,DWORD PTR [rcx+0x100034]
    78725cc0dfc6:	83 c0 01             	add    eax,0x1
    78725cc0dfc9:	89 81 34 00 10 00    	mov    DWORD PTR [rcx+0x100034],eax
    78725cc0dfcf:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc0dfd4:	75 4c                	jne    0x78725cc0e022
    78725cc0dfd6:	48 8b 8c 24 68 01 00 	mov    rcx,QWORD PTR [rsp+0x168]
    78725cc0dfdd:	00 
    78725cc0dfde:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc0dfe4:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    78725cc0dfeb:	89 c2                	mov    edx,eax
    78725cc0dfed:	83 c2 01             	add    edx,0x1
    78725cc0dff0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc0dff6:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0dffb:	73 23                	jae    0x78725cc0e020
    78725cc0dffd:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    78725cc0e004:	00 
    78725cc0e005:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc0e00c:	89 c9                	mov    ecx,ecx
    78725cc0e00e:	48 c1 e1 02          	shl    rcx,0x2
    78725cc0e012:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc0e019:	c7 04 08 0d 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xd
    78725cc0e020:	eb 00                	jmp    0x78725cc0e022
    78725cc0e022:	eb 00                	jmp    0x78725cc0e024
    78725cc0e024:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0e02b:	00 
    78725cc0e02c:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    78725cc0e02f:	89 84 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],eax
    78725cc0e036:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    78725cc0e039:	89 8c 24 60 01 00 00 	mov    DWORD PTR [rsp+0x160],ecx
    78725cc0e040:	83 e0 03             	and    eax,0x3
    78725cc0e043:	83 f8 00             	cmp    eax,0x0
    78725cc0e046:	0f 84 8e 00 00 00    	je     0x78725cc0e0da
    78725cc0e04c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e053:	00 
    78725cc0e054:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    78725cc0e05b:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0e062:	00 
    78725cc0e063:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e06a:	00 00 00 
    78725cc0e06d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0e074:	00 00 00 
    78725cc0e077:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0e07e:	60 00 00 
    78725cc0e081:	ba 9c 00 01 00       	mov    edx,0x1009c
    78725cc0e086:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0e08c:	ff d0                	call   rax
    78725cc0e08e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e095:	00 
    78725cc0e096:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e09c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e0a2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e0a8:	be 01 00 00 00       	mov    esi,0x1
    78725cc0e0ad:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e0b2:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e0b9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e0c0:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e0c7:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e0ce:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e0d5:	e9 74 1b 00 00       	jmp    0x78725cc0fc4e
    78725cc0e0da:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0e0e1:	00 
    78725cc0e0e2:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    78725cc0e0e9:	c1 e9 0c             	shr    ecx,0xc
    78725cc0e0ec:	89 c9                	mov    ecx,ecx
    78725cc0e0ee:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0e0f2:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
    78725cc0e0f9:	00 
    78725cc0e0fa:	48 83 f8 00          	cmp    rax,0x0
    78725cc0e0fe:	74 23                	je     0x78725cc0e123
    78725cc0e100:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    78725cc0e107:	00 
    78725cc0e108:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    78725cc0e10f:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    78725cc0e116:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0e11c:	89 c9                	mov    ecx,ecx
    78725cc0e11e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0e121:	eb 51                	jmp    0x78725cc0e174
    78725cc0e123:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e12a:	00 
    78725cc0e12b:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    78725cc0e132:	8b b4 24 5c 01 00 00 	mov    esi,DWORD PTR [rsp+0x15c]
    78725cc0e139:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0e140:	00 
    78725cc0e141:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0e148:	00 00 00 
    78725cc0e14b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc0e152:	00 00 00 
    78725cc0e155:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0e15c:	60 00 00 
    78725cc0e15f:	ff d0                	call   rax
    78725cc0e161:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e168:	00 
    78725cc0e169:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e170:	75 14                	jne    0x78725cc0e186
    78725cc0e172:	eb 5e                	jmp    0x78725cc0e1d2
    78725cc0e174:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    78725cc0e17b:	00 
    78725cc0e17c:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0e17f:	75 53                	jne    0x78725cc0e1d4
    78725cc0e181:	e9 93 00 00 00       	jmp    0x78725cc0e219
    78725cc0e186:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e18d:	00 
    78725cc0e18e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e194:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e19a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e1a0:	be 01 00 00 00       	mov    esi,0x1
    78725cc0e1a5:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e1aa:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e1b1:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e1b8:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e1bf:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e1c6:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e1cd:	e9 7c 1a 00 00       	jmp    0x78725cc0fc4e
    78725cc0e1d2:	eb a0                	jmp    0x78725cc0e174
    78725cc0e1d4:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e1db:	00 
    78725cc0e1dc:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    78725cc0e1e3:	00 01 00 
    78725cc0e1e6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e1ed:	00 00 00 
    78725cc0e1f0:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0e1f7:	00 00 00 
    78725cc0e1fa:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0e201:	60 00 00 
    78725cc0e204:	ff d0                	call   rax
    78725cc0e206:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e20d:	00 
    78725cc0e20e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e215:	75 04                	jne    0x78725cc0e21b
    78725cc0e217:	eb 4e                	jmp    0x78725cc0e267
    78725cc0e219:	eb 4e                	jmp    0x78725cc0e269
    78725cc0e21b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e222:	00 
    78725cc0e223:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e229:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e22f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e235:	be 01 00 00 00       	mov    esi,0x1
    78725cc0e23a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e23f:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e246:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e24d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e254:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e25b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e262:	e9 e7 19 00 00       	jmp    0x78725cc0fc4e
    78725cc0e267:	eb b0                	jmp    0x78725cc0e219
    78725cc0e269:	eb 00                	jmp    0x78725cc0e26b
    78725cc0e26b:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0e272:	00 
    78725cc0e273:	8b 41 34             	mov    eax,DWORD PTR [rcx+0x34]
    78725cc0e276:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    78725cc0e27d:	8b 09                	mov    ecx,DWORD PTR [rcx]
    78725cc0e27f:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    78725cc0e286:	83 e0 03             	and    eax,0x3
    78725cc0e289:	83 f8 00             	cmp    eax,0x0
    78725cc0e28c:	0f 84 95 00 00 00    	je     0x78725cc0e327
    78725cc0e292:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e299:	00 
    78725cc0e29a:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    78725cc0e2a1:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0e2a8:	00 
    78725cc0e2a9:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    78725cc0e2b0:	00 01 00 
    78725cc0e2b3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e2ba:	00 00 00 
    78725cc0e2bd:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc0e2c4:	00 00 00 
    78725cc0e2c7:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0e2ce:	60 00 00 
    78725cc0e2d1:	ba 9e 00 01 00       	mov    edx,0x1009e
    78725cc0e2d6:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0e2dc:	ff d0                	call   rax
    78725cc0e2de:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e2e5:	00 
    78725cc0e2e6:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc0e2ec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e2f2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e2f8:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e2fd:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    78725cc0e304:	89 ce                	mov    esi,ecx
    78725cc0e306:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e30d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e314:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e31b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e322:	e9 27 19 00 00       	jmp    0x78725cc0fc4e
    78725cc0e327:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0e32e:	00 
    78725cc0e32f:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    78725cc0e336:	c1 e9 0c             	shr    ecx,0xc
    78725cc0e339:	89 c9                	mov    ecx,ecx
    78725cc0e33b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0e33f:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    78725cc0e346:	00 
    78725cc0e347:	48 83 f8 00          	cmp    rax,0x0
    78725cc0e34b:	74 23                	je     0x78725cc0e370
    78725cc0e34d:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0e354:	00 
    78725cc0e355:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    78725cc0e35c:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    78725cc0e363:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0e369:	89 c9                	mov    ecx,ecx
    78725cc0e36b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0e36e:	eb 5b                	jmp    0x78725cc0e3cb
    78725cc0e370:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e377:	00 
    78725cc0e378:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    78725cc0e37f:	8b b4 24 38 01 00 00 	mov    esi,DWORD PTR [rsp+0x138]
    78725cc0e386:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0e38d:	00 
    78725cc0e38e:	c7 80 bc 00 00 00 9e 	mov    DWORD PTR [rax+0xbc],0x1009e
    78725cc0e395:	00 01 00 
    78725cc0e398:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0e39f:	00 00 00 
    78725cc0e3a2:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc0e3a9:	00 00 00 
    78725cc0e3ac:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0e3b3:	60 00 00 
    78725cc0e3b6:	ff d0                	call   rax
    78725cc0e3b8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e3bf:	00 
    78725cc0e3c0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e3c7:	75 29                	jne    0x78725cc0e3f2
    78725cc0e3c9:	eb 70                	jmp    0x78725cc0e43b
    78725cc0e3cb:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    78725cc0e3d2:	00 
    78725cc0e3d3:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0e3da:	00 
    78725cc0e3db:	8b 94 24 38 01 00 00 	mov    edx,DWORD PTR [rsp+0x138]
    78725cc0e3e2:	83 c2 04             	add    edx,0x4
    78725cc0e3e5:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    78725cc0e3e8:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0e3eb:	75 50                	jne    0x78725cc0e43d
    78725cc0e3ed:	e9 90 00 00 00       	jmp    0x78725cc0e482
    78725cc0e3f2:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e3f9:	00 
    78725cc0e3fa:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc0e400:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e406:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e40c:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e411:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    78725cc0e418:	89 ce                	mov    esi,ecx
    78725cc0e41a:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e421:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e428:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e42f:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e436:	e9 13 18 00 00       	jmp    0x78725cc0fc4e
    78725cc0e43b:	eb 8e                	jmp    0x78725cc0e3cb
    78725cc0e43d:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e444:	00 
    78725cc0e445:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x100a0
    78725cc0e44c:	00 01 00 
    78725cc0e44f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e456:	00 00 00 
    78725cc0e459:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc0e460:	00 00 00 
    78725cc0e463:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0e46a:	60 00 00 
    78725cc0e46d:	ff d0                	call   rax
    78725cc0e46f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e476:	00 
    78725cc0e477:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e47e:	75 04                	jne    0x78725cc0e484
    78725cc0e480:	eb 4b                	jmp    0x78725cc0e4cd
    78725cc0e482:	eb 4b                	jmp    0x78725cc0e4cf
    78725cc0e484:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e48b:	00 
    78725cc0e48c:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    78725cc0e492:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e498:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e49e:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e4a3:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    78725cc0e4aa:	89 ce                	mov    esi,ecx
    78725cc0e4ac:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e4b3:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e4ba:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e4c1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e4c8:	e9 81 17 00 00       	jmp    0x78725cc0fc4e
    78725cc0e4cd:	eb b3                	jmp    0x78725cc0e482
    78725cc0e4cf:	eb 00                	jmp    0x78725cc0e4d1
    78725cc0e4d1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e4d8:	00 
    78725cc0e4d9:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    78725cc0e4dc:	89 ca                	mov    edx,ecx
    78725cc0e4de:	83 c2 01             	add    edx,0x1
    78725cc0e4e1:	89 94 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],edx
    78725cc0e4e8:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    78725cc0e4eb:	89 ce                	mov    esi,ecx
    78725cc0e4ed:	c1 ee 1f             	shr    esi,0x1f
    78725cc0e4f0:	89 d3                	mov    ebx,edx
    78725cc0e4f2:	c1 eb 1f             	shr    ebx,0x1f
    78725cc0e4f5:	89 df                	mov    edi,ebx
    78725cc0e4f7:	83 f7 00             	xor    edi,0x0
    78725cc0e4fa:	31 de                	xor    esi,ebx
    78725cc0e4fc:	21 fe                	and    esi,edi
    78725cc0e4fe:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc0e501:	83 f9 01             	cmp    ecx,0x1
    78725cc0e504:	0f 92 c1             	setb   cl
    78725cc0e507:	80 e1 01             	and    cl,0x1
    78725cc0e50a:	0f b6 c9             	movzx  ecx,cl
    78725cc0e50d:	83 fa 00             	cmp    edx,0x0
    78725cc0e510:	0f 94 c3             	sete   bl
    78725cc0e513:	80 e3 01             	and    bl,0x1
    78725cc0e516:	0f b6 fb             	movzx  edi,bl
    78725cc0e519:	c1 ea 1f             	shr    edx,0x1f
    78725cc0e51c:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    78725cc0e522:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0e528:	89 f2                	mov    edx,esi
    78725cc0e52a:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    78725cc0e530:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0e536:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0e53c:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0e542:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0e548:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0e54e:	eb 00                	jmp    0x78725cc0e550
    78725cc0e550:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e557:	00 
    78725cc0e558:	c7 00 06 00 00 00    	mov    DWORD PTR [rax],0x6
    78725cc0e55e:	eb 00                	jmp    0x78725cc0e560
    78725cc0e560:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e567:	00 
    78725cc0e568:	8b 40 2c             	mov    eax,DWORD PTR [rax+0x2c]
    78725cc0e56b:	89 84 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],eax
    78725cc0e572:	83 e0 03             	and    eax,0x3
    78725cc0e575:	83 f8 00             	cmp    eax,0x0
    78725cc0e578:	0f 84 98 00 00 00    	je     0x78725cc0e616
    78725cc0e57e:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e585:	00 
    78725cc0e586:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    78725cc0e58d:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0e594:	00 
    78725cc0e595:	c7 87 bc 00 00 00 a4 	mov    DWORD PTR [rdi+0xbc],0x100a4
    78725cc0e59c:	00 01 00 
    78725cc0e59f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e5a6:	00 00 00 
    78725cc0e5a9:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    78725cc0e5b0:	00 00 00 
    78725cc0e5b3:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0e5ba:	60 00 00 
    78725cc0e5bd:	ba a4 00 01 00       	mov    edx,0x100a4
    78725cc0e5c2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0e5c8:	ff d0                	call   rax
    78725cc0e5ca:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e5d1:	00 
    78725cc0e5d2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e5d8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e5de:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e5e4:	be 05 00 00 00       	mov    esi,0x5
    78725cc0e5e9:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e5ee:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e5f5:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e5fc:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e603:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e60a:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e611:	e9 38 16 00 00       	jmp    0x78725cc0fc4e
    78725cc0e616:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0e61d:	00 
    78725cc0e61e:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    78725cc0e625:	c1 e9 0c             	shr    ecx,0xc
    78725cc0e628:	89 c9                	mov    ecx,ecx
    78725cc0e62a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0e62e:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    78725cc0e635:	00 
    78725cc0e636:	48 83 f8 00          	cmp    rax,0x0
    78725cc0e63a:	74 23                	je     0x78725cc0e65f
    78725cc0e63c:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc0e643:	00 
    78725cc0e644:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    78725cc0e64b:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    78725cc0e652:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0e658:	89 c9                	mov    ecx,ecx
    78725cc0e65a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0e65d:	eb 5b                	jmp    0x78725cc0e6ba
    78725cc0e65f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e666:	00 
    78725cc0e667:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    78725cc0e66e:	8b b4 24 28 01 00 00 	mov    esi,DWORD PTR [rsp+0x128]
    78725cc0e675:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0e67c:	00 
    78725cc0e67d:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x100a4
    78725cc0e684:	00 01 00 
    78725cc0e687:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0e68e:	00 00 00 
    78725cc0e691:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    78725cc0e698:	00 00 00 
    78725cc0e69b:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0e6a2:	60 00 00 
    78725cc0e6a5:	ff d0                	call   rax
    78725cc0e6a7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e6ae:	00 
    78725cc0e6af:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e6b6:	75 14                	jne    0x78725cc0e6cc
    78725cc0e6b8:	eb 5e                	jmp    0x78725cc0e718
    78725cc0e6ba:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    78725cc0e6c1:	00 
    78725cc0e6c2:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0e6c5:	75 53                	jne    0x78725cc0e71a
    78725cc0e6c7:	e9 93 00 00 00       	jmp    0x78725cc0e75f
    78725cc0e6cc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e6d3:	00 
    78725cc0e6d4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e6da:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e6e0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e6e6:	be 05 00 00 00       	mov    esi,0x5
    78725cc0e6eb:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e6f0:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e6f7:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e6fe:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e705:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e70c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e713:	e9 36 15 00 00       	jmp    0x78725cc0fc4e
    78725cc0e718:	eb a0                	jmp    0x78725cc0e6ba
    78725cc0e71a:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e721:	00 
    78725cc0e722:	c7 87 bc 00 00 00 a6 	mov    DWORD PTR [rdi+0xbc],0x100a6
    78725cc0e729:	00 01 00 
    78725cc0e72c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e733:	00 00 00 
    78725cc0e736:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    78725cc0e73d:	00 00 00 
    78725cc0e740:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0e747:	60 00 00 
    78725cc0e74a:	ff d0                	call   rax
    78725cc0e74c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e753:	00 
    78725cc0e754:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e75b:	75 04                	jne    0x78725cc0e761
    78725cc0e75d:	eb 4e                	jmp    0x78725cc0e7ad
    78725cc0e75f:	eb 4e                	jmp    0x78725cc0e7af
    78725cc0e761:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e768:	00 
    78725cc0e769:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e76f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e775:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e77b:	be 05 00 00 00       	mov    esi,0x5
    78725cc0e780:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e785:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e78c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e793:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e79a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e7a1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e7a8:	e9 a1 14 00 00       	jmp    0x78725cc0fc4e
    78725cc0e7ad:	eb b0                	jmp    0x78725cc0e75f
    78725cc0e7af:	eb 00                	jmp    0x78725cc0e7b1
    78725cc0e7b1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e7b8:	00 
    78725cc0e7b9:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    78725cc0e7c0:	89 fa                	mov    edx,edi
    78725cc0e7c2:	83 ea 06             	sub    edx,0x6
    78725cc0e7c5:	83 fa 00             	cmp    edx,0x0
    78725cc0e7c8:	0f 94 c1             	sete   cl
    78725cc0e7cb:	80 e1 01             	and    cl,0x1
    78725cc0e7ce:	0f b6 f1             	movzx  esi,cl
    78725cc0e7d1:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    78725cc0e7d8:	c1 ea 1f             	shr    edx,0x1f
    78725cc0e7db:	89 f9                	mov    ecx,edi
    78725cc0e7dd:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0e7e0:	89 d3                	mov    ebx,edx
    78725cc0e7e2:	31 cb                	xor    ebx,ecx
    78725cc0e7e4:	83 f1 00             	xor    ecx,0x0
    78725cc0e7e7:	21 d9                	and    ecx,ebx
    78725cc0e7e9:	31 ca                	xor    edx,ecx
    78725cc0e7eb:	b9 06 00 00 00       	mov    ecx,0x6
    78725cc0e7f0:	39 f9                	cmp    ecx,edi
    78725cc0e7f2:	0f 96 c1             	setbe  cl
    78725cc0e7f5:	80 e1 01             	and    cl,0x1
    78725cc0e7f8:	0f b6 c9             	movzx  ecx,cl
    78725cc0e7fb:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc0e801:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc0e807:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0e80d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0e813:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0e819:	eb 00                	jmp    0x78725cc0e81b
    78725cc0e81b:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    78725cc0e822:	83 f8 00             	cmp    eax,0x0
    78725cc0e825:	75 33                	jne    0x78725cc0e85a
    78725cc0e827:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0e82e:	00 
    78725cc0e82f:	c7 81 bc 00 00 00 84 	mov    DWORD PTR [rcx+0xbc],0x10084
    78725cc0e836:	00 01 00 
    78725cc0e839:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0e83f:	83 c0 07             	add    eax,0x7
    78725cc0e842:	89 84 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],eax
    78725cc0e849:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0e84f:	0f 82 69 13 00 00    	jb     0x78725cc0fbbe
    78725cc0e855:	e9 87 13 00 00       	jmp    0x78725cc0fbe1
    78725cc0e85a:	eb 00                	jmp    0x78725cc0e85c
    78725cc0e85c:	eb 00                	jmp    0x78725cc0e85e
    78725cc0e85e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e865:	00 
    78725cc0e866:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    78725cc0e869:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0e86f:	83 c9 00             	or     ecx,0x0
    78725cc0e872:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    78725cc0e879:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0e87c:	eb 00                	jmp    0x78725cc0e87e
    78725cc0e87e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e885:	00 
    78725cc0e886:	c7 00 02 00 00 00    	mov    DWORD PTR [rax],0x2
    78725cc0e88c:	eb 00                	jmp    0x78725cc0e88e
    78725cc0e88e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e895:	00 
    78725cc0e896:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    78725cc0e89d:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc0e8a3:	81 c9 10 f0 00 00    	or     ecx,0xf010
    78725cc0e8a9:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    78725cc0e8b0:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0e8b3:	eb 00                	jmp    0x78725cc0e8b5
    78725cc0e8b5:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    78725cc0e8bc:	83 e0 03             	and    eax,0x3
    78725cc0e8bf:	83 f8 00             	cmp    eax,0x0
    78725cc0e8c2:	0f 84 98 00 00 00    	je     0x78725cc0e960
    78725cc0e8c8:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0e8cf:	00 
    78725cc0e8d0:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc0e8d7:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0e8de:	00 
    78725cc0e8df:	c7 87 bc 00 00 00 b4 	mov    DWORD PTR [rdi+0xbc],0x100b4
    78725cc0e8e6:	00 01 00 
    78725cc0e8e9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0e8f0:	00 00 00 
    78725cc0e8f3:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    78725cc0e8fa:	00 00 00 
    78725cc0e8fd:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0e904:	60 00 00 
    78725cc0e907:	ba b4 00 01 00       	mov    edx,0x100b4
    78725cc0e90c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0e912:	ff d0                	call   rax
    78725cc0e914:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e91b:	00 
    78725cc0e91c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0e922:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0e928:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0e92e:	be 0b 00 00 00       	mov    esi,0xb
    78725cc0e933:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0e938:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0e93f:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0e946:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0e94d:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0e954:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0e95b:	e9 ee 12 00 00       	jmp    0x78725cc0fc4e
    78725cc0e960:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0e967:	00 
    78725cc0e968:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc0e96f:	c1 e9 0c             	shr    ecx,0xc
    78725cc0e972:	89 c9                	mov    ecx,ecx
    78725cc0e974:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0e978:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    78725cc0e97f:	00 
    78725cc0e980:	48 83 f8 00          	cmp    rax,0x0
    78725cc0e984:	74 20                	je     0x78725cc0e9a6
    78725cc0e986:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0e98d:	00 
    78725cc0e98e:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc0e995:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0e99b:	89 c9                	mov    ecx,ecx
    78725cc0e99d:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    78725cc0e9a4:	eb 59                	jmp    0x78725cc0e9ff
    78725cc0e9a6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e9ad:	00 
    78725cc0e9ae:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    78725cc0e9b5:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0e9bc:	00 
    78725cc0e9bd:	c7 80 bc 00 00 00 b4 	mov    DWORD PTR [rax+0xbc],0x100b4
    78725cc0e9c4:	00 01 00 
    78725cc0e9c7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0e9ce:	00 00 00 
    78725cc0e9d1:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    78725cc0e9d8:	00 00 00 
    78725cc0e9db:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0e9e2:	60 00 00 
    78725cc0e9e5:	ba 02 00 00 00       	mov    edx,0x2
    78725cc0e9ea:	ff d0                	call   rax
    78725cc0e9ec:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0e9f3:	00 
    78725cc0e9f4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0e9fb:	75 14                	jne    0x78725cc0ea11
    78725cc0e9fd:	eb 5e                	jmp    0x78725cc0ea5d
    78725cc0e9ff:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    78725cc0ea06:	00 
    78725cc0ea07:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0ea0a:	75 53                	jne    0x78725cc0ea5f
    78725cc0ea0c:	e9 93 00 00 00       	jmp    0x78725cc0eaa4
    78725cc0ea11:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ea18:	00 
    78725cc0ea19:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ea1f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ea25:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ea2b:	be 0b 00 00 00       	mov    esi,0xb
    78725cc0ea30:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ea35:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0ea3c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ea43:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0ea4a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0ea51:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0ea58:	e9 f1 11 00 00       	jmp    0x78725cc0fc4e
    78725cc0ea5d:	eb a0                	jmp    0x78725cc0e9ff
    78725cc0ea5f:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0ea66:	00 
    78725cc0ea67:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    78725cc0ea6e:	00 01 00 
    78725cc0ea71:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0ea78:	00 00 00 
    78725cc0ea7b:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    78725cc0ea82:	00 00 00 
    78725cc0ea85:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0ea8c:	60 00 00 
    78725cc0ea8f:	ff d0                	call   rax
    78725cc0ea91:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ea98:	00 
    78725cc0ea99:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0eaa0:	75 04                	jne    0x78725cc0eaa6
    78725cc0eaa2:	eb 4e                	jmp    0x78725cc0eaf2
    78725cc0eaa4:	eb 4e                	jmp    0x78725cc0eaf4
    78725cc0eaa6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0eaad:	00 
    78725cc0eaae:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0eab4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0eaba:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0eac0:	be 0b 00 00 00       	mov    esi,0xb
    78725cc0eac5:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0eaca:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0ead1:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ead8:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0eadf:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0eae6:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0eaed:	e9 5c 11 00 00       	jmp    0x78725cc0fc4e
    78725cc0eaf2:	eb b0                	jmp    0x78725cc0eaa4
    78725cc0eaf4:	eb 00                	jmp    0x78725cc0eaf6
    78725cc0eaf6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0eafd:	00 
    78725cc0eafe:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc0eb01:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    78725cc0eb08:	83 e0 03             	and    eax,0x3
    78725cc0eb0b:	83 f8 00             	cmp    eax,0x0
    78725cc0eb0e:	0f 84 97 00 00 00    	je     0x78725cc0ebab
    78725cc0eb14:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0eb1b:	00 
    78725cc0eb1c:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0eb23:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0eb2a:	00 
    78725cc0eb2b:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    78725cc0eb32:	00 01 00 
    78725cc0eb35:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0eb3c:	00 00 00 
    78725cc0eb3f:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    78725cc0eb46:	00 00 00 
    78725cc0eb49:	31 c0                	xor    eax,eax
    78725cc0eb4b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0eb52:	60 00 00 
    78725cc0eb55:	ba b6 00 01 00       	mov    edx,0x100b6
    78725cc0eb5a:	45 31 c0             	xor    r8d,r8d
    78725cc0eb5d:	ff d0                	call   rax
    78725cc0eb5f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0eb66:	00 
    78725cc0eb67:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0eb6d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0eb73:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0eb79:	be 0c 00 00 00       	mov    esi,0xc
    78725cc0eb7e:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0eb83:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0eb8a:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0eb91:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0eb98:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0eb9f:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0eba6:	e9 a3 10 00 00       	jmp    0x78725cc0fc4e
    78725cc0ebab:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0ebb2:	00 
    78725cc0ebb3:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0ebba:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ebbd:	89 c9                	mov    ecx,ecx
    78725cc0ebbf:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ebc3:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    78725cc0ebca:	00 
    78725cc0ebcb:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ebcf:	74 23                	je     0x78725cc0ebf4
    78725cc0ebd1:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    78725cc0ebd8:	00 
    78725cc0ebd9:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0ebe0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0ebe6:	89 c9                	mov    ecx,ecx
    78725cc0ebe8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0ebeb:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    78725cc0ebf2:	eb 5d                	jmp    0x78725cc0ec51
    78725cc0ebf4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ebfb:	00 
    78725cc0ebfc:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    78725cc0ec03:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0ec0a:	00 
    78725cc0ec0b:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    78725cc0ec12:	00 01 00 
    78725cc0ec15:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0ec1c:	00 00 00 
    78725cc0ec1f:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    78725cc0ec26:	00 00 00 
    78725cc0ec29:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0ec30:	60 00 00 
    78725cc0ec33:	ff d0                	call   rax
    78725cc0ec35:	89 c1                	mov    ecx,eax
    78725cc0ec37:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ec3e:	00 
    78725cc0ec3f:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    78725cc0ec46:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0ec4d:	75 2e                	jne    0x78725cc0ec7d
    78725cc0ec4f:	eb 78                	jmp    0x78725cc0ecc9
    78725cc0ec51:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    78725cc0ec58:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    78725cc0ec5f:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    78725cc0ec66:	83 c0 04             	add    eax,0x4
    78725cc0ec69:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    78725cc0ec70:	83 e0 03             	and    eax,0x3
    78725cc0ec73:	83 f8 00             	cmp    eax,0x0
    78725cc0ec76:	75 64                	jne    0x78725cc0ecdc
    78725cc0ec78:	e9 f6 00 00 00       	jmp    0x78725cc0ed73
    78725cc0ec7d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ec84:	00 
    78725cc0ec85:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ec8b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ec91:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ec97:	be 0c 00 00 00       	mov    esi,0xc
    78725cc0ec9c:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0eca1:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0eca8:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ecaf:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0ecb6:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0ecbd:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0ecc4:	e9 85 0f 00 00       	jmp    0x78725cc0fc4e
    78725cc0ecc9:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    78725cc0ecd0:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    78725cc0ecd7:	e9 75 ff ff ff       	jmp    0x78725cc0ec51
    78725cc0ecdc:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0ece3:	00 
    78725cc0ece4:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc0eceb:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0ecf2:	00 
    78725cc0ecf3:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    78725cc0ecfa:	00 01 00 
    78725cc0ecfd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0ed04:	00 00 00 
    78725cc0ed07:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    78725cc0ed0e:	00 00 00 
    78725cc0ed11:	31 c0                	xor    eax,eax
    78725cc0ed13:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0ed1a:	60 00 00 
    78725cc0ed1d:	ba b6 00 01 00       	mov    edx,0x100b6
    78725cc0ed22:	45 31 c0             	xor    r8d,r8d
    78725cc0ed25:	ff d0                	call   rax
    78725cc0ed27:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ed2e:	00 
    78725cc0ed2f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ed35:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ed3b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ed41:	be 0c 00 00 00       	mov    esi,0xc
    78725cc0ed46:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0ed4b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0ed52:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ed59:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0ed60:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0ed67:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0ed6e:	e9 db 0e 00 00       	jmp    0x78725cc0fc4e
    78725cc0ed73:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0ed7a:	00 
    78725cc0ed7b:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc0ed82:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ed85:	89 c9                	mov    ecx,ecx
    78725cc0ed87:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ed8b:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    78725cc0ed92:	00 
    78725cc0ed93:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ed97:	74 23                	je     0x78725cc0edbc
    78725cc0ed99:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    78725cc0eda0:	00 
    78725cc0eda1:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc0eda8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0edae:	89 c9                	mov    ecx,ecx
    78725cc0edb0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0edb3:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc0edba:	eb 60                	jmp    0x78725cc0ee1c
    78725cc0edbc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0edc3:	00 
    78725cc0edc4:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    78725cc0edcb:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0edd2:	00 
    78725cc0edd3:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    78725cc0edda:	00 01 00 
    78725cc0eddd:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0ede4:	00 00 00 
    78725cc0ede7:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    78725cc0edee:	00 00 00 
    78725cc0edf1:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0edf8:	60 00 00 
    78725cc0edfb:	ff d0                	call   rax
    78725cc0edfd:	89 c1                	mov    ecx,eax
    78725cc0edff:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ee06:	00 
    78725cc0ee07:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    78725cc0ee0e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0ee15:	75 41                	jne    0x78725cc0ee58
    78725cc0ee17:	e9 88 00 00 00       	jmp    0x78725cc0eea4
    78725cc0ee1c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ee23:	00 
    78725cc0ee24:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    78725cc0ee2b:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc0ee32:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    78725cc0ee39:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    78725cc0ee40:	83 c1 04             	add    ecx,0x4
    78725cc0ee43:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    78725cc0ee4a:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc0ee4d:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc0ee53:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0ee56:	eb 5f                	jmp    0x78725cc0eeb7
    78725cc0ee58:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ee5f:	00 
    78725cc0ee60:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ee66:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ee6c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ee72:	be 0c 00 00 00       	mov    esi,0xc
    78725cc0ee77:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0ee7c:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0ee83:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ee8a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0ee91:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0ee98:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0ee9f:	e9 aa 0d 00 00       	jmp    0x78725cc0fc4e
    78725cc0eea4:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    78725cc0eeab:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc0eeb2:	e9 65 ff ff ff       	jmp    0x78725cc0ee1c
    78725cc0eeb7:	eb 00                	jmp    0x78725cc0eeb9
    78725cc0eeb9:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0eec0:	00 
    78725cc0eec1:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    78725cc0eec7:	eb 00                	jmp    0x78725cc0eec9
    78725cc0eec9:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    78725cc0eed0:	83 e0 03             	and    eax,0x3
    78725cc0eed3:	83 f8 00             	cmp    eax,0x0
    78725cc0eed6:	0f 84 97 00 00 00    	je     0x78725cc0ef73
    78725cc0eedc:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0eee3:	00 
    78725cc0eee4:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc0eeeb:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0eef2:	00 
    78725cc0eef3:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0eefa:	00 01 00 
    78725cc0eefd:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0ef04:	00 00 00 
    78725cc0ef07:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0ef0e:	00 00 00 
    78725cc0ef11:	31 c0                	xor    eax,eax
    78725cc0ef13:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0ef1a:	60 00 00 
    78725cc0ef1d:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0ef22:	45 31 c0             	xor    r8d,r8d
    78725cc0ef25:	ff d0                	call   rax
    78725cc0ef27:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0ef2e:	00 
    78725cc0ef2f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ef35:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ef3b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ef41:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0ef46:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ef4b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0ef52:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0ef59:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0ef60:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0ef67:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0ef6e:	e9 db 0c 00 00       	jmp    0x78725cc0fc4e
    78725cc0ef73:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0ef7a:	00 
    78725cc0ef7b:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc0ef82:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ef85:	89 c9                	mov    ecx,ecx
    78725cc0ef87:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ef8b:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    78725cc0ef92:	00 
    78725cc0ef93:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ef97:	74 23                	je     0x78725cc0efbc
    78725cc0ef99:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    78725cc0efa0:	00 
    78725cc0efa1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc0efa8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0efae:	89 c9                	mov    ecx,ecx
    78725cc0efb0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0efb3:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    78725cc0efba:	eb 5d                	jmp    0x78725cc0f019
    78725cc0efbc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0efc3:	00 
    78725cc0efc4:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    78725cc0efcb:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0efd2:	00 
    78725cc0efd3:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0efda:	00 01 00 
    78725cc0efdd:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0efe4:	00 00 00 
    78725cc0efe7:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0efee:	00 00 00 
    78725cc0eff1:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0eff8:	60 00 00 
    78725cc0effb:	ff d0                	call   rax
    78725cc0effd:	89 c1                	mov    ecx,eax
    78725cc0efff:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f006:	00 
    78725cc0f007:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    78725cc0f00e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f015:	75 32                	jne    0x78725cc0f049
    78725cc0f017:	eb 7c                	jmp    0x78725cc0f095
    78725cc0f019:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    78725cc0f020:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f027:	00 
    78725cc0f028:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    78725cc0f02f:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    78725cc0f032:	83 c0 04             	add    eax,0x4
    78725cc0f035:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    78725cc0f03c:	83 e0 03             	and    eax,0x3
    78725cc0f03f:	83 f8 00             	cmp    eax,0x0
    78725cc0f042:	75 64                	jne    0x78725cc0f0a8
    78725cc0f044:	e9 f6 00 00 00       	jmp    0x78725cc0f13f
    78725cc0f049:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f050:	00 
    78725cc0f051:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f057:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f05d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f063:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f068:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f06d:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f074:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f07b:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f082:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f089:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f090:	e9 b9 0b 00 00       	jmp    0x78725cc0fc4e
    78725cc0f095:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    78725cc0f09c:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    78725cc0f0a3:	e9 71 ff ff ff       	jmp    0x78725cc0f019
    78725cc0f0a8:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f0af:	00 
    78725cc0f0b0:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0f0b7:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f0be:	00 
    78725cc0f0bf:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f0c6:	00 01 00 
    78725cc0f0c9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f0d0:	00 00 00 
    78725cc0f0d3:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f0da:	00 00 00 
    78725cc0f0dd:	31 c0                	xor    eax,eax
    78725cc0f0df:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f0e6:	60 00 00 
    78725cc0f0e9:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f0ee:	45 31 c0             	xor    r8d,r8d
    78725cc0f0f1:	ff d0                	call   rax
    78725cc0f0f3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f0fa:	00 
    78725cc0f0fb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f101:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f107:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f10d:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f112:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f117:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f11e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f125:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f12c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f133:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f13a:	e9 0f 0b 00 00       	jmp    0x78725cc0fc4e
    78725cc0f13f:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f146:	00 
    78725cc0f147:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0f14e:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f151:	89 c9                	mov    ecx,ecx
    78725cc0f153:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f157:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    78725cc0f15e:	00 
    78725cc0f15f:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f163:	74 23                	je     0x78725cc0f188
    78725cc0f165:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc0f16c:	00 
    78725cc0f16d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0f174:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f17a:	89 c9                	mov    ecx,ecx
    78725cc0f17c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0f17f:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc0f186:	eb 5d                	jmp    0x78725cc0f1e5
    78725cc0f188:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f18f:	00 
    78725cc0f190:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    78725cc0f197:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0f19e:	00 
    78725cc0f19f:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0f1a6:	00 01 00 
    78725cc0f1a9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0f1b0:	00 00 00 
    78725cc0f1b3:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0f1ba:	00 00 00 
    78725cc0f1bd:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0f1c4:	60 00 00 
    78725cc0f1c7:	ff d0                	call   rax
    78725cc0f1c9:	89 c1                	mov    ecx,eax
    78725cc0f1cb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f1d2:	00 
    78725cc0f1d3:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    78725cc0f1da:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f1e1:	75 32                	jne    0x78725cc0f215
    78725cc0f1e3:	eb 7c                	jmp    0x78725cc0f261
    78725cc0f1e5:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    78725cc0f1ec:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f1f3:	00 
    78725cc0f1f4:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    78725cc0f1fb:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    78725cc0f1fe:	83 c0 04             	add    eax,0x4
    78725cc0f201:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    78725cc0f208:	83 e0 03             	and    eax,0x3
    78725cc0f20b:	83 f8 00             	cmp    eax,0x0
    78725cc0f20e:	75 64                	jne    0x78725cc0f274
    78725cc0f210:	e9 f6 00 00 00       	jmp    0x78725cc0f30b
    78725cc0f215:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f21c:	00 
    78725cc0f21d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f223:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f229:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f22f:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f234:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f239:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f240:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f247:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f24e:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f255:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f25c:	e9 ed 09 00 00       	jmp    0x78725cc0fc4e
    78725cc0f261:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    78725cc0f268:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc0f26f:	e9 71 ff ff ff       	jmp    0x78725cc0f1e5
    78725cc0f274:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f27b:	00 
    78725cc0f27c:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc0f283:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f28a:	00 
    78725cc0f28b:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f292:	00 01 00 
    78725cc0f295:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f29c:	00 00 00 
    78725cc0f29f:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f2a6:	00 00 00 
    78725cc0f2a9:	31 c0                	xor    eax,eax
    78725cc0f2ab:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f2b2:	60 00 00 
    78725cc0f2b5:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f2ba:	45 31 c0             	xor    r8d,r8d
    78725cc0f2bd:	ff d0                	call   rax
    78725cc0f2bf:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f2c6:	00 
    78725cc0f2c7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f2cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f2d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f2d9:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f2de:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f2e3:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f2ea:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f2f1:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f2f8:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f2ff:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f306:	e9 43 09 00 00       	jmp    0x78725cc0fc4e
    78725cc0f30b:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f312:	00 
    78725cc0f313:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc0f31a:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f31d:	89 c9                	mov    ecx,ecx
    78725cc0f31f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f323:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    78725cc0f32a:	00 
    78725cc0f32b:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f32f:	74 23                	je     0x78725cc0f354
    78725cc0f331:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc0f338:	00 
    78725cc0f339:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    78725cc0f340:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f346:	89 c9                	mov    ecx,ecx
    78725cc0f348:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0f34b:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc0f352:	eb 5d                	jmp    0x78725cc0f3b1
    78725cc0f354:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f35b:	00 
    78725cc0f35c:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    78725cc0f363:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0f36a:	00 
    78725cc0f36b:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0f372:	00 01 00 
    78725cc0f375:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0f37c:	00 00 00 
    78725cc0f37f:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0f386:	00 00 00 
    78725cc0f389:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0f390:	60 00 00 
    78725cc0f393:	ff d0                	call   rax
    78725cc0f395:	89 c1                	mov    ecx,eax
    78725cc0f397:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f39e:	00 
    78725cc0f39f:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    78725cc0f3a6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f3ad:	75 32                	jne    0x78725cc0f3e1
    78725cc0f3af:	eb 7c                	jmp    0x78725cc0f42d
    78725cc0f3b1:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    78725cc0f3b8:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f3bf:	00 
    78725cc0f3c0:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    78725cc0f3c7:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    78725cc0f3ca:	83 c0 04             	add    eax,0x4
    78725cc0f3cd:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    78725cc0f3d4:	83 e0 03             	and    eax,0x3
    78725cc0f3d7:	83 f8 00             	cmp    eax,0x0
    78725cc0f3da:	75 64                	jne    0x78725cc0f440
    78725cc0f3dc:	e9 f6 00 00 00       	jmp    0x78725cc0f4d7
    78725cc0f3e1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f3e8:	00 
    78725cc0f3e9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f3ef:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f3f5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f3fb:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f400:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f405:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f40c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f413:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f41a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f421:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f428:	e9 21 08 00 00       	jmp    0x78725cc0fc4e
    78725cc0f42d:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    78725cc0f434:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc0f43b:	e9 71 ff ff ff       	jmp    0x78725cc0f3b1
    78725cc0f440:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f447:	00 
    78725cc0f448:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0f44f:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f456:	00 
    78725cc0f457:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f45e:	00 01 00 
    78725cc0f461:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f468:	00 00 00 
    78725cc0f46b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f472:	00 00 00 
    78725cc0f475:	31 c0                	xor    eax,eax
    78725cc0f477:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f47e:	60 00 00 
    78725cc0f481:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f486:	45 31 c0             	xor    r8d,r8d
    78725cc0f489:	ff d0                	call   rax
    78725cc0f48b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f492:	00 
    78725cc0f493:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f499:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f49f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f4a5:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f4aa:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f4af:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f4b6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f4bd:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f4c4:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f4cb:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f4d2:	e9 77 07 00 00       	jmp    0x78725cc0fc4e
    78725cc0f4d7:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f4de:	00 
    78725cc0f4df:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0f4e6:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f4e9:	89 c9                	mov    ecx,ecx
    78725cc0f4eb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f4ef:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc0f4f6:	00 
    78725cc0f4f7:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f4fb:	74 20                	je     0x78725cc0f51d
    78725cc0f4fd:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc0f504:	00 
    78725cc0f505:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0f50c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f512:	89 c9                	mov    ecx,ecx
    78725cc0f514:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0f517:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0f51b:	eb 5a                	jmp    0x78725cc0f577
    78725cc0f51d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f524:	00 
    78725cc0f525:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    78725cc0f52c:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0f533:	00 
    78725cc0f534:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0f53b:	00 01 00 
    78725cc0f53e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0f545:	00 00 00 
    78725cc0f548:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0f54f:	00 00 00 
    78725cc0f552:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0f559:	60 00 00 
    78725cc0f55c:	ff d0                	call   rax
    78725cc0f55e:	89 c1                	mov    ecx,eax
    78725cc0f560:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f567:	00 
    78725cc0f568:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    78725cc0f56c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f573:	75 2c                	jne    0x78725cc0f5a1
    78725cc0f575:	eb 76                	jmp    0x78725cc0f5ed
    78725cc0f577:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    78725cc0f57e:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f585:	00 
    78725cc0f586:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    78725cc0f58a:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    78725cc0f58d:	83 c0 04             	add    eax,0x4
    78725cc0f590:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc0f594:	83 e0 03             	and    eax,0x3
    78725cc0f597:	83 f8 00             	cmp    eax,0x0
    78725cc0f59a:	75 5b                	jne    0x78725cc0f5f7
    78725cc0f59c:	e9 ea 00 00 00       	jmp    0x78725cc0f68b
    78725cc0f5a1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f5a8:	00 
    78725cc0f5a9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f5af:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f5b5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f5bb:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f5c0:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f5c5:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f5cc:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f5d3:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f5da:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f5e1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f5e8:	e9 61 06 00 00       	jmp    0x78725cc0fc4e
    78725cc0f5ed:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    78725cc0f5f1:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0f5f5:	eb 80                	jmp    0x78725cc0f577
    78725cc0f5f7:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f5fe:	00 
    78725cc0f5ff:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0f603:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f60a:	00 
    78725cc0f60b:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f612:	00 01 00 
    78725cc0f615:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f61c:	00 00 00 
    78725cc0f61f:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f626:	00 00 00 
    78725cc0f629:	31 c0                	xor    eax,eax
    78725cc0f62b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f632:	60 00 00 
    78725cc0f635:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f63a:	45 31 c0             	xor    r8d,r8d
    78725cc0f63d:	ff d0                	call   rax
    78725cc0f63f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f646:	00 
    78725cc0f647:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f64d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f653:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f659:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f65e:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f663:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f66a:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f671:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f678:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f67f:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f686:	e9 c3 05 00 00       	jmp    0x78725cc0fc4e
    78725cc0f68b:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f692:	00 
    78725cc0f693:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0f697:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f69a:	89 c9                	mov    ecx,ecx
    78725cc0f69c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f6a0:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc0f6a5:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f6a9:	74 1a                	je     0x78725cc0f6c5
    78725cc0f6ab:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0f6b0:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0f6b4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f6ba:	89 c9                	mov    ecx,ecx
    78725cc0f6bc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0f6bf:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc0f6c3:	eb 57                	jmp    0x78725cc0f71c
    78725cc0f6c5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f6cc:	00 
    78725cc0f6cd:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    78725cc0f6d1:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0f6d8:	00 
    78725cc0f6d9:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0f6e0:	00 01 00 
    78725cc0f6e3:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0f6ea:	00 00 00 
    78725cc0f6ed:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0f6f4:	00 00 00 
    78725cc0f6f7:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0f6fe:	60 00 00 
    78725cc0f701:	ff d0                	call   rax
    78725cc0f703:	89 c1                	mov    ecx,eax
    78725cc0f705:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f70c:	00 
    78725cc0f70d:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    78725cc0f711:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f718:	75 29                	jne    0x78725cc0f743
    78725cc0f71a:	eb 73                	jmp    0x78725cc0f78f
    78725cc0f71c:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    78725cc0f720:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f727:	00 
    78725cc0f728:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    78725cc0f72c:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    78725cc0f72f:	83 c0 04             	add    eax,0x4
    78725cc0f732:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    78725cc0f736:	83 e0 03             	and    eax,0x3
    78725cc0f739:	83 f8 00             	cmp    eax,0x0
    78725cc0f73c:	75 5b                	jne    0x78725cc0f799
    78725cc0f73e:	e9 ea 00 00 00       	jmp    0x78725cc0f82d
    78725cc0f743:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f74a:	00 
    78725cc0f74b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f751:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f757:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f75d:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f762:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f767:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f76e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f775:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f77c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f783:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f78a:	e9 bf 04 00 00       	jmp    0x78725cc0fc4e
    78725cc0f78f:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    78725cc0f793:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc0f797:	eb 83                	jmp    0x78725cc0f71c
    78725cc0f799:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f7a0:	00 
    78725cc0f7a1:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0f7a5:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f7ac:	00 
    78725cc0f7ad:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f7b4:	00 01 00 
    78725cc0f7b7:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f7be:	00 00 00 
    78725cc0f7c1:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f7c8:	00 00 00 
    78725cc0f7cb:	31 c0                	xor    eax,eax
    78725cc0f7cd:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f7d4:	60 00 00 
    78725cc0f7d7:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f7dc:	45 31 c0             	xor    r8d,r8d
    78725cc0f7df:	ff d0                	call   rax
    78725cc0f7e1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f7e8:	00 
    78725cc0f7e9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f7ef:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f7f5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f7fb:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f800:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f805:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f80c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f813:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f81a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f821:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f828:	e9 21 04 00 00       	jmp    0x78725cc0fc4e
    78725cc0f82d:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f834:	00 
    78725cc0f835:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0f839:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f83c:	89 c9                	mov    ecx,ecx
    78725cc0f83e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f842:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc0f847:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f84b:	74 1a                	je     0x78725cc0f867
    78725cc0f84d:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc0f852:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0f856:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f85c:	89 c9                	mov    ecx,ecx
    78725cc0f85e:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0f861:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0f865:	eb 57                	jmp    0x78725cc0f8be
    78725cc0f867:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f86e:	00 
    78725cc0f86f:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    78725cc0f873:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0f87a:	00 
    78725cc0f87b:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0f882:	00 01 00 
    78725cc0f885:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0f88c:	00 00 00 
    78725cc0f88f:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0f896:	00 00 00 
    78725cc0f899:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0f8a0:	60 00 00 
    78725cc0f8a3:	ff d0                	call   rax
    78725cc0f8a5:	89 c1                	mov    ecx,eax
    78725cc0f8a7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f8ae:	00 
    78725cc0f8af:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc0f8b3:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0f8ba:	75 29                	jne    0x78725cc0f8e5
    78725cc0f8bc:	eb 73                	jmp    0x78725cc0f931
    78725cc0f8be:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    78725cc0f8c2:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0f8c9:	00 
    78725cc0f8ca:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    78725cc0f8ce:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    78725cc0f8d1:	83 c0 04             	add    eax,0x4
    78725cc0f8d4:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc0f8d8:	83 e0 03             	and    eax,0x3
    78725cc0f8db:	83 f8 00             	cmp    eax,0x0
    78725cc0f8de:	75 5b                	jne    0x78725cc0f93b
    78725cc0f8e0:	e9 ea 00 00 00       	jmp    0x78725cc0f9cf
    78725cc0f8e5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f8ec:	00 
    78725cc0f8ed:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f8f3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f8f9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f8ff:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f904:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f909:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f910:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f917:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f91e:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f925:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f92c:	e9 1d 03 00 00       	jmp    0x78725cc0fc4e
    78725cc0f931:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc0f935:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0f939:	eb 83                	jmp    0x78725cc0f8be
    78725cc0f93b:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0f942:	00 
    78725cc0f943:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0f947:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    78725cc0f94e:	00 
    78725cc0f94f:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    78725cc0f956:	00 01 00 
    78725cc0f959:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0f960:	00 00 00 
    78725cc0f963:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    78725cc0f96a:	00 00 00 
    78725cc0f96d:	31 c0                	xor    eax,eax
    78725cc0f96f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0f976:	60 00 00 
    78725cc0f979:	ba bc 00 01 00       	mov    edx,0x100bc
    78725cc0f97e:	45 31 c0             	xor    r8d,r8d
    78725cc0f981:	ff d0                	call   rax
    78725cc0f983:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0f98a:	00 
    78725cc0f98b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0f991:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0f997:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0f99d:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0f9a2:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0f9a7:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0f9ae:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0f9b5:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0f9bc:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0f9c3:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0f9ca:	e9 7f 02 00 00       	jmp    0x78725cc0fc4e
    78725cc0f9cf:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc0f9d6:	00 
    78725cc0f9d7:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0f9db:	c1 e9 0c             	shr    ecx,0xc
    78725cc0f9de:	89 c9                	mov    ecx,ecx
    78725cc0f9e0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0f9e4:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc0f9e9:	48 83 f8 00          	cmp    rax,0x0
    78725cc0f9ed:	74 1a                	je     0x78725cc0fa09
    78725cc0f9ef:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0f9f4:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0f9f8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0f9fe:	89 c9                	mov    ecx,ecx
    78725cc0fa00:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0fa03:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc0fa07:	eb 57                	jmp    0x78725cc0fa60
    78725cc0fa09:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fa10:	00 
    78725cc0fa11:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc0fa15:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    78725cc0fa1c:	00 
    78725cc0fa1d:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    78725cc0fa24:	00 01 00 
    78725cc0fa27:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0fa2e:	00 00 00 
    78725cc0fa31:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    78725cc0fa38:	00 00 00 
    78725cc0fa3b:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0fa42:	60 00 00 
    78725cc0fa45:	ff d0                	call   rax
    78725cc0fa47:	89 c1                	mov    ecx,eax
    78725cc0fa49:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fa50:	00 
    78725cc0fa51:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc0fa55:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0fa5c:	75 1d                	jne    0x78725cc0fa7b
    78725cc0fa5e:	eb 67                	jmp    0x78725cc0fac7
    78725cc0fa60:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fa67:	00 
    78725cc0fa68:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0fa6c:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    78725cc0fa70:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    78725cc0fa73:	83 c1 04             	add    ecx,0x4
    78725cc0fa76:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0fa79:	eb 56                	jmp    0x78725cc0fad1
    78725cc0fa7b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fa82:	00 
    78725cc0fa83:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0fa89:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0fa8f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0fa95:	be 0e 00 00 00       	mov    esi,0xe
    78725cc0fa9a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0fa9f:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0faa6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0faad:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0fab4:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0fabb:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0fac2:	e9 87 01 00 00       	jmp    0x78725cc0fc4e
    78725cc0fac7:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc0facb:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc0facf:	eb 8f                	jmp    0x78725cc0fa60
    78725cc0fad1:	eb 00                	jmp    0x78725cc0fad3
    78725cc0fad3:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    78725cc0fada:	83 e0 01             	and    eax,0x1
    78725cc0fadd:	83 f8 00             	cmp    eax,0x0
    78725cc0fae0:	75 3d                	jne    0x78725cc0fb1f
    78725cc0fae2:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    78725cc0fae9:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0faee:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0faf3:	b0 01                	mov    al,0x1
    78725cc0faf5:	89 d7                	mov    edi,edx
    78725cc0faf7:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0fafe:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0fb05:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0fb0c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0fb13:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0fb1a:	e9 2f 01 00 00       	jmp    0x78725cc0fc4e
    78725cc0fb1f:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    78725cc0fb26:	00 
    78725cc0fb27:	48 8b 94 24 70 01 00 	mov    rdx,QWORD PTR [rsp+0x170]
    78725cc0fb2e:	00 
    78725cc0fb2f:	c7 87 bc 00 00 00 be 	mov    DWORD PTR [rdi+0xbc],0x100be
    78725cc0fb36:	00 01 00 
    78725cc0fb39:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0fb40:	00 00 00 
    78725cc0fb43:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    78725cc0fb4a:	00 00 00 
    78725cc0fb4d:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc0fb54:	60 00 00 
    78725cc0fb57:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc0fb5c:	ff d0                	call   rax
    78725cc0fb5e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fb65:	00 
    78725cc0fb66:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0fb6c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0fb72:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0fb78:	be 0f 00 00 00       	mov    esi,0xf
    78725cc0fb7d:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0fb82:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    78725cc0fb89:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    78725cc0fb90:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    78725cc0fb97:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc0fb9e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    78725cc0fba5:	e9 a4 00 00 00       	jmp    0x78725cc0fc4e
    78725cc0fbaa:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fbb1:	00 
    78725cc0fbb2:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc0fbb9:	e9 82 01 00 00       	jmp    0x78725cc0fd40
    78725cc0fbbe:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    78725cc0fbc5:	00 
    78725cc0fbc6:	48 89 c1             	mov    rcx,rax
    78725cc0fbc9:	48 81 c1 20 04 08 00 	add    rcx,0x80420
    78725cc0fbd0:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc0fbd5:	81 b8 20 04 08 00 84 	cmp    DWORD PTR [rax+0x80420],0x10084
    78725cc0fbdc:	00 01 00 
    78725cc0fbdf:	74 32                	je     0x78725cc0fc13
    78725cc0fbe1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fbe8:	00 
    78725cc0fbe9:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    78725cc0fbf0:	00 01 00 
    78725cc0fbf3:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0fbfa:	00 00 00 
    78725cc0fbfd:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    78725cc0fc04:	00 00 00 
    78725cc0fc07:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0fc0e:	e9 2d 01 00 00       	jmp    0x78725cc0fd40
    78725cc0fc13:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    78725cc0fc1a:	00 
    78725cc0fc1b:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    78725cc0fc22:	00 
    78725cc0fc23:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc0fc28:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    78725cc0fc2f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    78725cc0fc36:	84 00 01 00 
    78725cc0fc3a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0fc41:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0fc45:	48 81 c4 98 01 00 00 	add    rsp,0x198
    78725cc0fc4c:	ff e0                	jmp    rax
    78725cc0fc4e:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    78725cc0fc55:	00 
    78725cc0fc56:	8b 94 24 48 01 00 00 	mov    edx,DWORD PTR [rsp+0x148]
    78725cc0fc5d:	8b 84 24 4c 01 00 00 	mov    eax,DWORD PTR [rsp+0x14c]
    78725cc0fc64:	8b b4 24 50 01 00 00 	mov    esi,DWORD PTR [rsp+0x150]
    78725cc0fc6b:	8b bc 24 54 01 00 00 	mov    edi,DWORD PTR [rsp+0x154]
    78725cc0fc72:	8a 9c 24 5b 01 00 00 	mov    bl,BYTE PTR [rsp+0x15b]
    78725cc0fc79:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    78725cc0fc7d:	89 c3                	mov    ebx,eax
    78725cc0fc7f:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    78725cc0fc83:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    78725cc0fc87:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    78725cc0fc8b:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    78725cc0fc8f:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0fc95:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc0fc99:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0fc9f:	73 2d                	jae    0x78725cc0fcce
    78725cc0fca1:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    78725cc0fca8:	00 
    78725cc0fca9:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc0fcad:	89 d1                	mov    ecx,edx
    78725cc0fcaf:	c1 e9 01             	shr    ecx,0x1
    78725cc0fcb2:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0fcb8:	89 c9                	mov    ecx,ecx
    78725cc0fcba:	48 c1 e1 04          	shl    rcx,0x4
    78725cc0fcbe:	48 89 c6             	mov    rsi,rax
    78725cc0fcc1:	48 01 ce             	add    rsi,rcx
    78725cc0fcc4:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc0fcc9:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0fccc:	74 32                	je     0x78725cc0fd00
    78725cc0fcce:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    78725cc0fcd5:	00 
    78725cc0fcd6:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    78725cc0fcda:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc0fcde:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc0fce2:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    78725cc0fce6:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc0fcec:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc0fcf2:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc0fcf8:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc0fcfe:	eb 40                	jmp    0x78725cc0fd40
    78725cc0fd00:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    78725cc0fd07:	00 
    78725cc0fd08:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    78725cc0fd0f:	00 
    78725cc0fd10:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc0fd15:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    78725cc0fd19:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc0fd1d:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc0fd24:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0fd2b:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc0fd32:	00 
    78725cc0fd33:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0fd37:	48 81 c4 98 01 00 00 	add    rsp,0x198
    78725cc0fd3e:	ff e0                	jmp    rax
    78725cc0fd40:	48 81 c4 98 01 00 00 	add    rsp,0x198
    78725cc0fd47:	c2 08 00             	ret    0x8
