
build-native-instruction-analysis/capture/bcore-default-stream/pc-65600-0-132432577702768.bin:     file format binary


Disassembly of section .data:

000078725cc02b70 <.data>:
    78725cc02b70:	48 81 ec 28 01 00 00 	sub    rsp,0x128
    78725cc02b77:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
    78725cc02b7e:	00 
    78725cc02b7f:	4c 89 ac 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r13
    78725cc02b86:	00 
    78725cc02b87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc02b8e:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    78725cc02b95:	00 
    78725cc02b96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc02b9d:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    78725cc02ba4:	00 
    78725cc02ba5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc02bac:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    78725cc02bb3:	00 
    78725cc02bb4:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    78725cc02bbb:	00 
    78725cc02bbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc02bc2:	83 fa 00             	cmp    edx,0x0
    78725cc02bc5:	0f 94 c0             	sete   al
    78725cc02bc8:	81 ea 40 00 01 00    	sub    edx,0x10040
    78725cc02bce:	83 fa 4e             	cmp    edx,0x4e
    78725cc02bd1:	0f 97 c2             	seta   dl
    78725cc02bd4:	08 d0                	or     al,dl
    78725cc02bd6:	24 01                	and    al,0x1
    78725cc02bd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc02bde:	83 fa 00             	cmp    edx,0x0
    78725cc02be1:	0f 94 c1             	sete   cl
    78725cc02be4:	81 ea 40 00 01 00    	sub    edx,0x10040
    78725cc02bea:	83 fa 4e             	cmp    edx,0x4e
    78725cc02bed:	0f 97 c2             	seta   dl
    78725cc02bf0:	08 d1                	or     cl,dl
    78725cc02bf2:	20 c8                	and    al,cl
    78725cc02bf4:	a8 01                	test   al,0x1
    78725cc02bf6:	75 05                	jne    0x78725cc02bfd
    78725cc02bf8:	e9 6e 11 00 00       	jmp    0x78725cc03d6b
    78725cc02bfd:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02c04:	00 
    78725cc02c05:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc02c0c:	48 89 c8             	mov    rax,rcx
    78725cc02c0f:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc02c15:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    78725cc02c1c:	00 
    78725cc02c1d:	8b 81 08 00 10 00    	mov    eax,DWORD PTR [rcx+0x100008]
    78725cc02c23:	83 c0 01             	add    eax,0x1
    78725cc02c26:	89 81 08 00 10 00    	mov    DWORD PTR [rcx+0x100008],eax
    78725cc02c2c:	3d 14 cd 00 00       	cmp    eax,0xcd14
    78725cc02c31:	75 4c                	jne    0x78725cc02c7f
    78725cc02c33:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    78725cc02c3a:	00 
    78725cc02c3b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc02c41:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    78725cc02c48:	89 c2                	mov    edx,eax
    78725cc02c4a:	83 c2 01             	add    edx,0x1
    78725cc02c4d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc02c53:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc02c58:	73 23                	jae    0x78725cc02c7d
    78725cc02c5a:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    78725cc02c61:	00 
    78725cc02c62:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    78725cc02c69:	89 c9                	mov    ecx,ecx
    78725cc02c6b:	48 c1 e1 02          	shl    rcx,0x2
    78725cc02c6f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc02c76:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    78725cc02c7d:	eb 00                	jmp    0x78725cc02c7f
    78725cc02c7f:	eb 00                	jmp    0x78725cc02c81
    78725cc02c81:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02c88:	00 
    78725cc02c89:	c7 40 28 01 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c01
    78725cc02c90:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    78725cc02c96:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc02c9d:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    78725cc02ca3:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    78725cc02caa:	eb 00                	jmp    0x78725cc02cac
    78725cc02cac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02cb3:	00 
    78725cc02cb4:	c7 40 28 04 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf004
    78725cc02cbb:	eb 00                	jmp    0x78725cc02cbd
    78725cc02cbd:	31 c0                	xor    eax,eax
    78725cc02cbf:	a8 01                	test   al,0x1
    78725cc02cc1:	75 02                	jne    0x78725cc02cc5
    78725cc02cc3:	eb 7b                	jmp    0x78725cc02d40
    78725cc02cc5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc02ccc:	00 
    78725cc02ccd:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc02cd4:	00 
    78725cc02cd5:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10046
    78725cc02cdc:	00 01 00 
    78725cc02cdf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc02ce6:	00 00 00 
    78725cc02ce9:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc02cf0:	00 00 00 
    78725cc02cf3:	31 c0                	xor    eax,eax
    78725cc02cf5:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc02cfc:	60 00 00 
    78725cc02cff:	ba 46 00 01 00       	mov    edx,0x10046
    78725cc02d04:	b9 04 f0 00 00       	mov    ecx,0xf004
    78725cc02d09:	45 31 c0             	xor    r8d,r8d
    78725cc02d0c:	ff d0                	call   rax
    78725cc02d0e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02d15:	00 
    78725cc02d16:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02d1c:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc02d21:	b8 02 00 00 00       	mov    eax,0x2
    78725cc02d26:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc02d2d:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc02d34:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc02d3b:	e9 cc 10 00 00       	jmp    0x78725cc03e0c
    78725cc02d40:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc02d47:	00 
    78725cc02d48:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    78725cc02d4c:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    78725cc02d53:	00 
    78725cc02d54:	48 83 f8 00          	cmp    rax,0x0
    78725cc02d58:	74 14                	je     0x78725cc02d6e
    78725cc02d5a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc02d61:	00 
    78725cc02d62:	8b 40 04             	mov    eax,DWORD PTR [rax+0x4]
    78725cc02d65:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    78725cc02d6c:	eb 5b                	jmp    0x78725cc02dc9
    78725cc02d6e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02d75:	00 
    78725cc02d76:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc02d7d:	00 
    78725cc02d7e:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10046
    78725cc02d85:	00 01 00 
    78725cc02d88:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02d8f:	00 00 00 
    78725cc02d92:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc02d99:	00 00 00 
    78725cc02d9c:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc02da3:	60 00 00 
    78725cc02da6:	be 04 f0 00 00       	mov    esi,0xf004
    78725cc02dab:	ff d0                	call   rax
    78725cc02dad:	89 c1                	mov    ecx,eax
    78725cc02daf:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02db6:	00 
    78725cc02db7:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc02dbe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc02dc5:	75 1d                	jne    0x78725cc02de4
    78725cc02dc7:	eb 4d                	jmp    0x78725cc02e16
    78725cc02dc9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02dd0:	00 
    78725cc02dd1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc02dd8:	89 8c 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],ecx
    78725cc02ddf:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    78725cc02de2:	eb 42                	jmp    0x78725cc02e26
    78725cc02de4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02deb:	00 
    78725cc02dec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02df2:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc02df7:	b8 02 00 00 00       	mov    eax,0x2
    78725cc02dfc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc02e03:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc02e0a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc02e11:	e9 f6 0f 00 00       	jmp    0x78725cc03e0c
    78725cc02e16:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    78725cc02e1d:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    78725cc02e24:	eb a3                	jmp    0x78725cc02dc9
    78725cc02e26:	eb 00                	jmp    0x78725cc02e28
    78725cc02e28:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02e2f:	00 
    78725cc02e30:	c7 40 28 08 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf008
    78725cc02e37:	eb 00                	jmp    0x78725cc02e39
    78725cc02e39:	31 c0                	xor    eax,eax
    78725cc02e3b:	a8 01                	test   al,0x1
    78725cc02e3d:	75 02                	jne    0x78725cc02e41
    78725cc02e3f:	eb 7b                	jmp    0x78725cc02ebc
    78725cc02e41:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc02e48:	00 
    78725cc02e49:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc02e50:	00 
    78725cc02e51:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1004a
    78725cc02e58:	00 01 00 
    78725cc02e5b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc02e62:	00 00 00 
    78725cc02e65:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    78725cc02e6c:	00 00 00 
    78725cc02e6f:	31 c0                	xor    eax,eax
    78725cc02e71:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc02e78:	60 00 00 
    78725cc02e7b:	ba 4a 00 01 00       	mov    edx,0x1004a
    78725cc02e80:	b9 08 f0 00 00       	mov    ecx,0xf008
    78725cc02e85:	45 31 c0             	xor    r8d,r8d
    78725cc02e88:	ff d0                	call   rax
    78725cc02e8a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02e91:	00 
    78725cc02e92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02e98:	b9 05 00 00 00       	mov    ecx,0x5
    78725cc02e9d:	b8 02 00 00 00       	mov    eax,0x2
    78725cc02ea2:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc02ea9:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc02eb0:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc02eb7:	e9 50 0f 00 00       	jmp    0x78725cc03e0c
    78725cc02ebc:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc02ec3:	00 
    78725cc02ec4:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    78725cc02ec8:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    78725cc02ecf:	00 
    78725cc02ed0:	48 83 f8 00          	cmp    rax,0x0
    78725cc02ed4:	74 14                	je     0x78725cc02eea
    78725cc02ed6:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    78725cc02edd:	00 
    78725cc02ede:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    78725cc02ee1:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    78725cc02ee8:	eb 5b                	jmp    0x78725cc02f45
    78725cc02eea:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02ef1:	00 
    78725cc02ef2:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc02ef9:	00 
    78725cc02efa:	c7 80 bc 00 00 00 4a 	mov    DWORD PTR [rax+0xbc],0x1004a
    78725cc02f01:	00 01 00 
    78725cc02f04:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc02f0b:	00 00 00 
    78725cc02f0e:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    78725cc02f15:	00 00 00 
    78725cc02f18:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc02f1f:	60 00 00 
    78725cc02f22:	be 08 f0 00 00       	mov    esi,0xf008
    78725cc02f27:	ff d0                	call   rax
    78725cc02f29:	89 c1                	mov    ecx,eax
    78725cc02f2b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02f32:	00 
    78725cc02f33:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    78725cc02f3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc02f41:	75 1d                	jne    0x78725cc02f60
    78725cc02f43:	eb 4d                	jmp    0x78725cc02f92
    78725cc02f45:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02f4c:	00 
    78725cc02f4d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc02f54:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    78725cc02f5b:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc02f5e:	eb 42                	jmp    0x78725cc02fa2
    78725cc02f60:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02f67:	00 
    78725cc02f68:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc02f6e:	b9 05 00 00 00       	mov    ecx,0x5
    78725cc02f73:	b8 02 00 00 00       	mov    eax,0x2
    78725cc02f78:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc02f7f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc02f86:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc02f8d:	e9 7a 0e 00 00       	jmp    0x78725cc03e0c
    78725cc02f92:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [rsp+0xb8]
    78725cc02f99:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    78725cc02fa0:	eb a3                	jmp    0x78725cc02f45
    78725cc02fa2:	eb 00                	jmp    0x78725cc02fa4
    78725cc02fa4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02fab:	00 
    78725cc02fac:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    78725cc02fb2:	eb 00                	jmp    0x78725cc02fb4
    78725cc02fb4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02fbb:	00 
    78725cc02fbc:	c7 40 2c 05 3c 00 00 	mov    DWORD PTR [rax+0x2c],0x3c05
    78725cc02fc3:	eb 00                	jmp    0x78725cc02fc5
    78725cc02fc5:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02fcc:	00 
    78725cc02fcd:	c7 40 2c 14 f0 00 00 	mov    DWORD PTR [rax+0x2c],0xf014
    78725cc02fd4:	eb 00                	jmp    0x78725cc02fd6
    78725cc02fd6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc02fdd:	00 
    78725cc02fde:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc02fe1:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc02fe8:	83 c0 fc             	add    eax,0xfffffffc
    78725cc02feb:	89 84 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],eax
    78725cc02ff2:	83 e0 03             	and    eax,0x3
    78725cc02ff5:	83 f8 00             	cmp    eax,0x0
    78725cc02ff8:	74 7e                	je     0x78725cc03078
    78725cc02ffa:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03001:	00 
    78725cc03002:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    78725cc03009:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03010:	00 
    78725cc03011:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10054
    78725cc03018:	00 01 00 
    78725cc0301b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03022:	00 00 00 
    78725cc03025:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    78725cc0302c:	00 00 00 
    78725cc0302f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03036:	60 00 00 
    78725cc03039:	ba 54 00 01 00       	mov    edx,0x10054
    78725cc0303e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc03044:	ff d0                	call   rax
    78725cc03046:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0304d:	00 
    78725cc0304e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03054:	b9 09 00 00 00       	mov    ecx,0x9
    78725cc03059:	b8 02 00 00 00       	mov    eax,0x2
    78725cc0305e:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03065:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0306c:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03073:	e9 94 0d 00 00       	jmp    0x78725cc03e0c
    78725cc03078:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc0307f:	00 
    78725cc03080:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    78725cc03087:	c1 e9 0c             	shr    ecx,0xc
    78725cc0308a:	89 c9                	mov    ecx,ecx
    78725cc0308c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc03090:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    78725cc03097:	00 
    78725cc03098:	48 83 f8 00          	cmp    rax,0x0
    78725cc0309c:	74 23                	je     0x78725cc030c1
    78725cc0309e:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc030a5:	00 
    78725cc030a6:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc030ad:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    78725cc030b4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc030ba:	89 c9                	mov    ecx,ecx
    78725cc030bc:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc030bf:	eb 5b                	jmp    0x78725cc0311c
    78725cc030c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc030c8:	00 
    78725cc030c9:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc030d0:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    78725cc030d7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc030de:	00 
    78725cc030df:	c7 80 bc 00 00 00 54 	mov    DWORD PTR [rax+0xbc],0x10054
    78725cc030e6:	00 01 00 
    78725cc030e9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc030f0:	00 00 00 
    78725cc030f3:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    78725cc030fa:	00 00 00 
    78725cc030fd:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc03104:	60 00 00 
    78725cc03107:	ff d0                	call   rax
    78725cc03109:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03110:	00 
    78725cc03111:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03118:	75 11                	jne    0x78725cc0312b
    78725cc0311a:	eb 41                	jmp    0x78725cc0315d
    78725cc0311c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc03123:	00 
    78725cc03124:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc03127:	75 36                	jne    0x78725cc0315f
    78725cc03129:	eb 79                	jmp    0x78725cc031a4
    78725cc0312b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03132:	00 
    78725cc03133:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03139:	b9 09 00 00 00       	mov    ecx,0x9
    78725cc0313e:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03143:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc0314a:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03151:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03158:	e9 af 0c 00 00       	jmp    0x78725cc03e0c
    78725cc0315d:	eb bd                	jmp    0x78725cc0311c
    78725cc0315f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03166:	00 
    78725cc03167:	c7 87 bc 00 00 00 56 	mov    DWORD PTR [rdi+0xbc],0x10056
    78725cc0316e:	00 01 00 
    78725cc03171:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03178:	00 00 00 
    78725cc0317b:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    78725cc03182:	00 00 00 
    78725cc03185:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0318c:	60 00 00 
    78725cc0318f:	ff d0                	call   rax
    78725cc03191:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03198:	00 
    78725cc03199:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc031a0:	75 04                	jne    0x78725cc031a6
    78725cc031a2:	eb 34                	jmp    0x78725cc031d8
    78725cc031a4:	eb 34                	jmp    0x78725cc031da
    78725cc031a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc031ad:	00 
    78725cc031ae:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc031b4:	b9 09 00 00 00       	mov    ecx,0x9
    78725cc031b9:	b8 02 00 00 00       	mov    eax,0x2
    78725cc031be:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc031c5:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc031cc:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc031d3:	e9 34 0c 00 00       	jmp    0x78725cc03e0c
    78725cc031d8:	eb ca                	jmp    0x78725cc031a4
    78725cc031da:	eb 00                	jmp    0x78725cc031dc
    78725cc031dc:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc031e3:	00 
    78725cc031e4:	c7 40 28 03 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c03
    78725cc031eb:	eb 00                	jmp    0x78725cc031ed
    78725cc031ed:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc031f4:	00 
    78725cc031f5:	c7 40 28 0c f0 00 00 	mov    DWORD PTR [rax+0x28],0xf00c
    78725cc031fc:	eb 00                	jmp    0x78725cc031fe
    78725cc031fe:	31 c0                	xor    eax,eax
    78725cc03200:	a8 01                	test   al,0x1
    78725cc03202:	75 02                	jne    0x78725cc03206
    78725cc03204:	eb 7b                	jmp    0x78725cc03281
    78725cc03206:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc0320d:	00 
    78725cc0320e:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03215:	00 
    78725cc03216:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1005c
    78725cc0321d:	00 01 00 
    78725cc03220:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03227:	00 00 00 
    78725cc0322a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    78725cc03231:	00 00 00 
    78725cc03234:	31 c0                	xor    eax,eax
    78725cc03236:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0323d:	60 00 00 
    78725cc03240:	ba 5c 00 01 00       	mov    edx,0x1005c
    78725cc03245:	b9 0c f0 00 00       	mov    ecx,0xf00c
    78725cc0324a:	45 31 c0             	xor    r8d,r8d
    78725cc0324d:	ff d0                	call   rax
    78725cc0324f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03256:	00 
    78725cc03257:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0325d:	b9 0c 00 00 00       	mov    ecx,0xc
    78725cc03262:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03267:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc0326e:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03275:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc0327c:	e9 8b 0b 00 00       	jmp    0x78725cc03e0c
    78725cc03281:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc03288:	00 
    78725cc03289:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    78725cc0328d:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    78725cc03294:	00 
    78725cc03295:	48 83 f8 00          	cmp    rax,0x0
    78725cc03299:	74 14                	je     0x78725cc032af
    78725cc0329b:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    78725cc032a2:	00 
    78725cc032a3:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    78725cc032a6:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc032ad:	eb 5b                	jmp    0x78725cc0330a
    78725cc032af:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc032b6:	00 
    78725cc032b7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc032be:	00 
    78725cc032bf:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1005c
    78725cc032c6:	00 01 00 
    78725cc032c9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc032d0:	00 00 00 
    78725cc032d3:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    78725cc032da:	00 00 00 
    78725cc032dd:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc032e4:	60 00 00 
    78725cc032e7:	be 0c f0 00 00       	mov    esi,0xf00c
    78725cc032ec:	ff d0                	call   rax
    78725cc032ee:	89 c1                	mov    ecx,eax
    78725cc032f0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc032f7:	00 
    78725cc032f8:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    78725cc032ff:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03306:	75 1d                	jne    0x78725cc03325
    78725cc03308:	eb 4d                	jmp    0x78725cc03357
    78725cc0330a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03311:	00 
    78725cc03312:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc03319:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc03320:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc03323:	eb 42                	jmp    0x78725cc03367
    78725cc03325:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0332c:	00 
    78725cc0332d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03333:	b9 0c 00 00 00       	mov    ecx,0xc
    78725cc03338:	b8 02 00 00 00       	mov    eax,0x2
    78725cc0333d:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03344:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0334b:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03352:	e9 b5 0a 00 00       	jmp    0x78725cc03e0c
    78725cc03357:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    78725cc0335e:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc03365:	eb a3                	jmp    0x78725cc0330a
    78725cc03367:	eb 00                	jmp    0x78725cc03369
    78725cc03369:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03370:	00 
    78725cc03371:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    78725cc03374:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0337a:	83 c9 00             	or     ecx,0x0
    78725cc0337d:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    78725cc03384:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    78725cc03387:	eb 00                	jmp    0x78725cc03389
    78725cc03389:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03390:	00 
    78725cc03391:	8b 48 30             	mov    ecx,DWORD PTR [rax+0x30]
    78725cc03394:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0339a:	81 c9 00 00 00 01    	or     ecx,0x1000000
    78725cc033a0:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    78725cc033a7:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    78725cc033aa:	eb 00                	jmp    0x78725cc033ac
    78725cc033ac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc033b3:	00 
    78725cc033b4:	8b 8c 24 88 00 00 00 	mov    ecx,DWORD PTR [rsp+0x88]
    78725cc033bb:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc033c1:	81 c9 18 f0 00 00    	or     ecx,0xf018
    78725cc033c7:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    78725cc033ca:	eb 00                	jmp    0x78725cc033cc
    78725cc033cc:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    78725cc033d3:	83 c0 f8             	add    eax,0xfffffff8
    78725cc033d6:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    78725cc033dd:	83 e0 03             	and    eax,0x3
    78725cc033e0:	83 f8 00             	cmp    eax,0x0
    78725cc033e3:	74 7e                	je     0x78725cc03463
    78725cc033e5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc033ec:	00 
    78725cc033ed:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    78725cc033f4:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc033fb:	00 
    78725cc033fc:	c7 87 bc 00 00 00 6a 	mov    DWORD PTR [rdi+0xbc],0x1006a
    78725cc03403:	00 01 00 
    78725cc03406:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0340d:	00 00 00 
    78725cc03410:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    78725cc03417:	00 00 00 
    78725cc0341a:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03421:	60 00 00 
    78725cc03424:	ba 6a 00 01 00       	mov    edx,0x1006a
    78725cc03429:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0342f:	ff d0                	call   rax
    78725cc03431:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03438:	00 
    78725cc03439:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0343f:	b9 10 00 00 00       	mov    ecx,0x10
    78725cc03444:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03449:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03450:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03457:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc0345e:	e9 a9 09 00 00       	jmp    0x78725cc03e0c
    78725cc03463:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc0346a:	00 
    78725cc0346b:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    78725cc03472:	c1 e9 0c             	shr    ecx,0xc
    78725cc03475:	89 c9                	mov    ecx,ecx
    78725cc03477:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0347b:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc03480:	48 83 f8 00          	cmp    rax,0x0
    78725cc03484:	74 20                	je     0x78725cc034a6
    78725cc03486:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc0348b:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    78725cc03492:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    78725cc03499:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0349f:	89 c9                	mov    ecx,ecx
    78725cc034a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc034a4:	eb 5b                	jmp    0x78725cc03501
    78725cc034a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc034ad:	00 
    78725cc034ae:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    78725cc034b5:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    78725cc034bc:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc034c3:	00 
    78725cc034c4:	c7 80 bc 00 00 00 6a 	mov    DWORD PTR [rax+0xbc],0x1006a
    78725cc034cb:	00 01 00 
    78725cc034ce:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc034d5:	00 00 00 
    78725cc034d8:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    78725cc034df:	00 00 00 
    78725cc034e2:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc034e9:	60 00 00 
    78725cc034ec:	ff d0                	call   rax
    78725cc034ee:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc034f5:	00 
    78725cc034f6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc034fd:	75 11                	jne    0x78725cc03510
    78725cc034ff:	eb 41                	jmp    0x78725cc03542
    78725cc03501:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc03508:	00 
    78725cc03509:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0350c:	75 36                	jne    0x78725cc03544
    78725cc0350e:	eb 79                	jmp    0x78725cc03589
    78725cc03510:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03517:	00 
    78725cc03518:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0351e:	b9 10 00 00 00       	mov    ecx,0x10
    78725cc03523:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03528:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc0352f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03536:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc0353d:	e9 ca 08 00 00       	jmp    0x78725cc03e0c
    78725cc03542:	eb bd                	jmp    0x78725cc03501
    78725cc03544:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc0354b:	00 
    78725cc0354c:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1006c
    78725cc03553:	00 01 00 
    78725cc03556:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0355d:	00 00 00 
    78725cc03560:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    78725cc03567:	00 00 00 
    78725cc0356a:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc03571:	60 00 00 
    78725cc03574:	ff d0                	call   rax
    78725cc03576:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0357d:	00 
    78725cc0357e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03585:	75 04                	jne    0x78725cc0358b
    78725cc03587:	eb 34                	jmp    0x78725cc035bd
    78725cc03589:	eb 34                	jmp    0x78725cc035bf
    78725cc0358b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03592:	00 
    78725cc03593:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03599:	b9 10 00 00 00       	mov    ecx,0x10
    78725cc0359e:	b8 02 00 00 00       	mov    eax,0x2
    78725cc035a3:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc035aa:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc035b1:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc035b8:	e9 4f 08 00 00       	jmp    0x78725cc03e0c
    78725cc035bd:	eb ca                	jmp    0x78725cc03589
    78725cc035bf:	eb 00                	jmp    0x78725cc035c1
    78725cc035c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc035c8:	00 
    78725cc035c9:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc035d0:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc035d6:	83 c9 00             	or     ecx,0x0
    78725cc035d9:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    78725cc035dd:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc035e0:	eb 00                	jmp    0x78725cc035e2
    78725cc035e2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc035e9:	00 
    78725cc035ea:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc035ee:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc035f4:	81 c9 10 f0 00 00    	or     ecx,0xf010
    78725cc035fa:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    78725cc035fe:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc03601:	eb 00                	jmp    0x78725cc03603
    78725cc03603:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    78725cc03607:	83 e0 03             	and    eax,0x3
    78725cc0360a:	83 f8 00             	cmp    eax,0x0
    78725cc0360d:	74 7b                	je     0x78725cc0368a
    78725cc0360f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03616:	00 
    78725cc03617:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc0361b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03622:	00 
    78725cc03623:	c7 87 bc 00 00 00 74 	mov    DWORD PTR [rdi+0xbc],0x10074
    78725cc0362a:	00 01 00 
    78725cc0362d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03634:	00 00 00 
    78725cc03637:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc0363e:	00 00 00 
    78725cc03641:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03648:	60 00 00 
    78725cc0364b:	ba 74 00 01 00       	mov    edx,0x10074
    78725cc03650:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc03656:	ff d0                	call   rax
    78725cc03658:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0365f:	00 
    78725cc03660:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03666:	b9 13 00 00 00       	mov    ecx,0x13
    78725cc0366b:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03670:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03677:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0367e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03685:	e9 82 07 00 00       	jmp    0x78725cc03e0c
    78725cc0368a:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc03691:	00 
    78725cc03692:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc03696:	c1 e9 0c             	shr    ecx,0xc
    78725cc03699:	89 c9                	mov    ecx,ecx
    78725cc0369b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0369f:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc036a4:	48 83 f8 00          	cmp    rax,0x0
    78725cc036a8:	74 1a                	je     0x78725cc036c4
    78725cc036aa:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc036af:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc036b3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc036b9:	89 c9                	mov    ecx,ecx
    78725cc036bb:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    78725cc036c2:	eb 56                	jmp    0x78725cc0371a
    78725cc036c4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc036cb:	00 
    78725cc036cc:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    78725cc036d0:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc036d7:	00 
    78725cc036d8:	c7 80 bc 00 00 00 74 	mov    DWORD PTR [rax+0xbc],0x10074
    78725cc036df:	00 01 00 
    78725cc036e2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc036e9:	00 00 00 
    78725cc036ec:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    78725cc036f3:	00 00 00 
    78725cc036f6:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc036fd:	60 00 00 
    78725cc03700:	ba 01 00 00 00       	mov    edx,0x1
    78725cc03705:	ff d0                	call   rax
    78725cc03707:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0370e:	00 
    78725cc0370f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03716:	75 11                	jne    0x78725cc03729
    78725cc03718:	eb 41                	jmp    0x78725cc0375b
    78725cc0371a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc03721:	00 
    78725cc03722:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc03725:	75 36                	jne    0x78725cc0375d
    78725cc03727:	eb 79                	jmp    0x78725cc037a2
    78725cc03729:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03730:	00 
    78725cc03731:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03737:	b9 13 00 00 00       	mov    ecx,0x13
    78725cc0373c:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03741:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03748:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0374f:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03756:	e9 b1 06 00 00       	jmp    0x78725cc03e0c
    78725cc0375b:	eb bd                	jmp    0x78725cc0371a
    78725cc0375d:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03764:	00 
    78725cc03765:	c7 87 bc 00 00 00 76 	mov    DWORD PTR [rdi+0xbc],0x10076
    78725cc0376c:	00 01 00 
    78725cc0376f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03776:	00 00 00 
    78725cc03779:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc03780:	00 00 00 
    78725cc03783:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0378a:	60 00 00 
    78725cc0378d:	ff d0                	call   rax
    78725cc0378f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03796:	00 
    78725cc03797:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0379e:	75 04                	jne    0x78725cc037a4
    78725cc037a0:	eb 34                	jmp    0x78725cc037d6
    78725cc037a2:	eb 34                	jmp    0x78725cc037d8
    78725cc037a4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc037ab:	00 
    78725cc037ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc037b2:	b9 13 00 00 00       	mov    ecx,0x13
    78725cc037b7:	b8 02 00 00 00       	mov    eax,0x2
    78725cc037bc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc037c3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc037ca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc037d1:	e9 36 06 00 00       	jmp    0x78725cc03e0c
    78725cc037d6:	eb ca                	jmp    0x78725cc037a2
    78725cc037d8:	eb 00                	jmp    0x78725cc037da
    78725cc037da:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc037e1:	00 
    78725cc037e2:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    78725cc037e8:	eb 00                	jmp    0x78725cc037ea
    78725cc037ea:	31 c0                	xor    eax,eax
    78725cc037ec:	a8 01                	test   al,0x1
    78725cc037ee:	75 02                	jne    0x78725cc037f2
    78725cc037f0:	eb 7c                	jmp    0x78725cc0386e
    78725cc037f2:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc037f9:	00 
    78725cc037fa:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03801:	00 
    78725cc03802:	c7 87 bc 00 00 00 78 	mov    DWORD PTR [rdi+0xbc],0x10078
    78725cc03809:	00 01 00 
    78725cc0380c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03813:	00 00 00 
    78725cc03816:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    78725cc0381d:	00 00 00 
    78725cc03820:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03827:	60 00 00 
    78725cc0382a:	ba 78 00 01 00       	mov    edx,0x10078
    78725cc0382f:	b9 14 f0 00 00       	mov    ecx,0xf014
    78725cc03834:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0383a:	ff d0                	call   rax
    78725cc0383c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03843:	00 
    78725cc03844:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0384a:	b9 15 00 00 00       	mov    ecx,0x15
    78725cc0384f:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03854:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc0385b:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03862:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03869:	e9 9e 05 00 00       	jmp    0x78725cc03e0c
    78725cc0386e:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc03875:	00 
    78725cc03876:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    78725cc0387a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    78725cc0387f:	48 83 f8 00          	cmp    rax,0x0
    78725cc03883:	74 0e                	je     0x78725cc03893
    78725cc03885:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    78725cc0388a:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    78725cc03891:	eb 56                	jmp    0x78725cc038e9
    78725cc03893:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0389a:	00 
    78725cc0389b:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc038a2:	00 
    78725cc038a3:	c7 80 bc 00 00 00 78 	mov    DWORD PTR [rax+0xbc],0x10078
    78725cc038aa:	00 01 00 
    78725cc038ad:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc038b4:	00 00 00 
    78725cc038b7:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    78725cc038be:	00 00 00 
    78725cc038c1:	31 c0                	xor    eax,eax
    78725cc038c3:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc038ca:	60 00 00 
    78725cc038cd:	be 14 f0 00 00       	mov    esi,0xf014
    78725cc038d2:	31 d2                	xor    edx,edx
    78725cc038d4:	ff d0                	call   rax
    78725cc038d6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc038dd:	00 
    78725cc038de:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc038e5:	75 11                	jne    0x78725cc038f8
    78725cc038e7:	eb 41                	jmp    0x78725cc0392a
    78725cc038e9:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc038f0:	00 
    78725cc038f1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc038f4:	75 36                	jne    0x78725cc0392c
    78725cc038f6:	eb 79                	jmp    0x78725cc03971
    78725cc038f8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc038ff:	00 
    78725cc03900:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03906:	b9 15 00 00 00       	mov    ecx,0x15
    78725cc0390b:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03910:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03917:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0391e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03925:	e9 e2 04 00 00       	jmp    0x78725cc03e0c
    78725cc0392a:	eb bd                	jmp    0x78725cc038e9
    78725cc0392c:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03933:	00 
    78725cc03934:	c7 87 bc 00 00 00 7a 	mov    DWORD PTR [rdi+0xbc],0x1007a
    78725cc0393b:	00 01 00 
    78725cc0393e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03945:	00 00 00 
    78725cc03948:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    78725cc0394f:	00 00 00 
    78725cc03952:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc03959:	60 00 00 
    78725cc0395c:	ff d0                	call   rax
    78725cc0395e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03965:	00 
    78725cc03966:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0396d:	75 04                	jne    0x78725cc03973
    78725cc0396f:	eb 34                	jmp    0x78725cc039a5
    78725cc03971:	eb 34                	jmp    0x78725cc039a7
    78725cc03973:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0397a:	00 
    78725cc0397b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03981:	b9 15 00 00 00       	mov    ecx,0x15
    78725cc03986:	b8 02 00 00 00       	mov    eax,0x2
    78725cc0398b:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03992:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03999:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc039a0:	e9 67 04 00 00       	jmp    0x78725cc03e0c
    78725cc039a5:	eb ca                	jmp    0x78725cc03971
    78725cc039a7:	eb 00                	jmp    0x78725cc039a9
    78725cc039a9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc039b0:	00 
    78725cc039b1:	c7 40 1c 00 00 00 00 	mov    DWORD PTR [rax+0x1c],0x0
    78725cc039b8:	eb 00                	jmp    0x78725cc039ba
    78725cc039ba:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc039c1:	00 
    78725cc039c2:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    78725cc039c9:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc039cf:	83 c9 00             	or     ecx,0x0
    78725cc039d2:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    78725cc039d5:	eb 00                	jmp    0x78725cc039d7
    78725cc039d7:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc039de:	00 
    78725cc039df:	c7 40 18 00 00 00 00 	mov    DWORD PTR [rax+0x18],0x0
    78725cc039e6:	eb 00                	jmp    0x78725cc039e8
    78725cc039e8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc039ef:	00 
    78725cc039f0:	c7 40 14 01 00 00 00 	mov    DWORD PTR [rax+0x14],0x1
    78725cc039f7:	eb 00                	jmp    0x78725cc039f9
    78725cc039f9:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    78725cc03a00:	83 c0 fc             	add    eax,0xfffffffc
    78725cc03a03:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    78725cc03a07:	83 e0 03             	and    eax,0x3
    78725cc03a0a:	83 f8 00             	cmp    eax,0x0
    78725cc03a0d:	74 7a                	je     0x78725cc03a89
    78725cc03a0f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03a16:	00 
    78725cc03a17:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc03a1b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03a22:	00 
    78725cc03a23:	c7 87 bc 00 00 00 84 	mov    DWORD PTR [rdi+0xbc],0x10084
    78725cc03a2a:	00 01 00 
    78725cc03a2d:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    78725cc03a34:	00 00 00 
    78725cc03a37:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc03a3e:	00 00 00 
    78725cc03a41:	31 c0                	xor    eax,eax
    78725cc03a43:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03a4a:	60 00 00 
    78725cc03a4d:	ba 84 00 01 00       	mov    edx,0x10084
    78725cc03a52:	45 31 c0             	xor    r8d,r8d
    78725cc03a55:	ff d0                	call   rax
    78725cc03a57:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03a5e:	00 
    78725cc03a5f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03a65:	b9 1a 00 00 00       	mov    ecx,0x1a
    78725cc03a6a:	b8 08 00 00 00       	mov    eax,0x8
    78725cc03a6f:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03a76:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03a7d:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03a84:	e9 83 03 00 00       	jmp    0x78725cc03e0c
    78725cc03a89:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc03a90:	00 
    78725cc03a91:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc03a95:	c1 e9 0c             	shr    ecx,0xc
    78725cc03a98:	89 c9                	mov    ecx,ecx
    78725cc03a9a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc03a9e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc03aa3:	48 83 f8 00          	cmp    rax,0x0
    78725cc03aa7:	74 1a                	je     0x78725cc03ac3
    78725cc03aa9:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc03aae:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc03ab2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc03ab8:	89 c9                	mov    ecx,ecx
    78725cc03aba:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc03abd:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc03ac1:	eb 57                	jmp    0x78725cc03b1a
    78725cc03ac3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03aca:	00 
    78725cc03acb:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    78725cc03acf:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc03ad6:	00 
    78725cc03ad7:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    78725cc03ade:	00 01 00 
    78725cc03ae1:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    78725cc03ae8:	00 00 00 
    78725cc03aeb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc03af2:	00 00 00 
    78725cc03af5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc03afc:	60 00 00 
    78725cc03aff:	ff d0                	call   rax
    78725cc03b01:	89 c1                	mov    ecx,eax
    78725cc03b03:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03b0a:	00 
    78725cc03b0b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc03b0f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03b16:	75 1c                	jne    0x78725cc03b34
    78725cc03b18:	eb 4c                	jmp    0x78725cc03b66
    78725cc03b1a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03b21:	00 
    78725cc03b22:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    78725cc03b29:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc03b2d:	89 10                	mov    DWORD PTR [rax],edx
    78725cc03b2f:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc03b32:	eb 3c                	jmp    0x78725cc03b70
    78725cc03b34:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03b3b:	00 
    78725cc03b3c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03b42:	b9 1a 00 00 00       	mov    ecx,0x1a
    78725cc03b47:	b8 08 00 00 00       	mov    eax,0x8
    78725cc03b4c:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03b53:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03b5a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03b61:	e9 a6 02 00 00       	jmp    0x78725cc03e0c
    78725cc03b66:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc03b6a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc03b6e:	eb aa                	jmp    0x78725cc03b1a
    78725cc03b70:	eb 00                	jmp    0x78725cc03b72
    78725cc03b72:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    78725cc03b79:	83 c0 f8             	add    eax,0xfffffff8
    78725cc03b7c:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc03b80:	83 e0 03             	and    eax,0x3
    78725cc03b83:	83 f8 00             	cmp    eax,0x0
    78725cc03b86:	74 7a                	je     0x78725cc03c02
    78725cc03b88:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    78725cc03b8f:	00 
    78725cc03b90:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc03b94:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    78725cc03b9b:	00 
    78725cc03b9c:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    78725cc03ba3:	00 01 00 
    78725cc03ba6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc03bad:	00 00 00 
    78725cc03bb0:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    78725cc03bb7:	00 00 00 
    78725cc03bba:	31 c0                	xor    eax,eax
    78725cc03bbc:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc03bc3:	60 00 00 
    78725cc03bc6:	ba 8c 00 01 00       	mov    edx,0x1008c
    78725cc03bcb:	45 31 c0             	xor    r8d,r8d
    78725cc03bce:	ff d0                	call   rax
    78725cc03bd0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03bd7:	00 
    78725cc03bd8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03bde:	b9 1b 00 00 00       	mov    ecx,0x1b
    78725cc03be3:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03be8:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03bef:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03bf6:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03bfd:	e9 0a 02 00 00       	jmp    0x78725cc03e0c
    78725cc03c02:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc03c09:	00 
    78725cc03c0a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc03c0e:	c1 e9 0c             	shr    ecx,0xc
    78725cc03c11:	89 c9                	mov    ecx,ecx
    78725cc03c13:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc03c17:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc03c1c:	48 83 f8 00          	cmp    rax,0x0
    78725cc03c20:	74 1a                	je     0x78725cc03c3c
    78725cc03c22:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc03c27:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc03c2b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc03c31:	89 c9                	mov    ecx,ecx
    78725cc03c33:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc03c36:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc03c3a:	eb 57                	jmp    0x78725cc03c93
    78725cc03c3c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03c43:	00 
    78725cc03c44:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc03c48:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    78725cc03c4f:	00 
    78725cc03c50:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    78725cc03c57:	00 01 00 
    78725cc03c5a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc03c61:	00 00 00 
    78725cc03c64:	c7 80 34 01 00 00 1b 	mov    DWORD PTR [rax+0x134],0x1b
    78725cc03c6b:	00 00 00 
    78725cc03c6e:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc03c75:	60 00 00 
    78725cc03c78:	ff d0                	call   rax
    78725cc03c7a:	89 c1                	mov    ecx,eax
    78725cc03c7c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03c83:	00 
    78725cc03c84:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc03c88:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc03c8f:	75 13                	jne    0x78725cc03ca4
    78725cc03c91:	eb 43                	jmp    0x78725cc03cd6
    78725cc03c93:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03c9a:	00 
    78725cc03c9b:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc03c9f:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    78725cc03ca2:	eb 3c                	jmp    0x78725cc03ce0
    78725cc03ca4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03cab:	00 
    78725cc03cac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc03cb2:	b9 1b 00 00 00       	mov    ecx,0x1b
    78725cc03cb7:	b8 02 00 00 00       	mov    eax,0x2
    78725cc03cbc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    78725cc03cc3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc03cca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    78725cc03cd1:	e9 36 01 00 00       	jmp    0x78725cc03e0c
    78725cc03cd6:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc03cda:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc03cde:	eb b3                	jmp    0x78725cc03c93
    78725cc03ce0:	eb 00                	jmp    0x78725cc03ce2
    78725cc03ce2:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    78725cc03ce9:	00 
    78725cc03cea:	8b b4 24 f0 00 00 00 	mov    esi,DWORD PTR [rsp+0xf0]
    78725cc03cf1:	8b 84 24 ec 00 00 00 	mov    eax,DWORD PTR [rsp+0xec]
    78725cc03cf8:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    78725cc03cfe:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    78725cc03d04:	83 ff 01             	cmp    edi,0x1
    78725cc03d07:	0f 97 c3             	seta   bl
    78725cc03d0a:	3d 8e 00 01 00       	cmp    eax,0x1008e
    78725cc03d0f:	0f 94 c0             	sete   al
    78725cc03d12:	20 c3                	and    bl,al
    78725cc03d14:	b8 92 00 01 00       	mov    eax,0x10092
    78725cc03d19:	f6 c3 01             	test   bl,0x1
    78725cc03d1c:	0f 45 c2             	cmovne eax,edx
    78725cc03d1f:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    78725cc03d25:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    78725cc03d2b:	83 ff 01             	cmp    edi,0x1
    78725cc03d2e:	0f 97 c3             	seta   bl
    78725cc03d31:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    78725cc03d37:	40 0f 94 c6          	sete   sil
    78725cc03d3b:	40 20 f3             	and    bl,sil
    78725cc03d3e:	f6 c3 01             	test   bl,0x1
    78725cc03d41:	0f 45 c2             	cmovne eax,edx
    78725cc03d44:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    78725cc03d4a:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    78725cc03d51:	03 01 00 
    78725cc03d54:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc03d5a:	83 c0 1c             	add    eax,0x1c
    78725cc03d5d:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc03d61:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc03d67:	72 16                	jb     0x78725cc03d7f
    78725cc03d69:	eb 37                	jmp    0x78725cc03da2
    78725cc03d6b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03d72:	00 
    78725cc03d73:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc03d7a:	e9 4a 01 00 00       	jmp    0x78725cc03ec9
    78725cc03d7f:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    78725cc03d86:	00 
    78725cc03d87:	48 89 c1             	mov    rcx,rax
    78725cc03d8a:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    78725cc03d91:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc03d96:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    78725cc03d9d:	03 01 00 
    78725cc03da0:	74 32                	je     0x78725cc03dd4
    78725cc03da2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03da9:	00 
    78725cc03daa:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    78725cc03db1:	03 01 00 
    78725cc03db4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc03dbb:	00 00 00 
    78725cc03dbe:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    78725cc03dc5:	00 00 00 
    78725cc03dc8:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc03dcf:	e9 f5 00 00 00       	jmp    0x78725cc03ec9
    78725cc03dd4:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    78725cc03ddb:	00 
    78725cc03ddc:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    78725cc03de3:	00 
    78725cc03de4:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc03de9:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc03ded:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    78725cc03df4:	28 03 01 00 
    78725cc03df8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc03dff:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc03e03:	48 81 c4 28 01 00 00 	add    rsp,0x128
    78725cc03e0a:	ff e0                	jmp    rax
    78725cc03e0c:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    78725cc03e13:	00 
    78725cc03e14:	8b 94 24 e0 00 00 00 	mov    edx,DWORD PTR [rsp+0xe0]
    78725cc03e1b:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    78725cc03e22:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    78725cc03e29:	89 c7                	mov    edi,eax
    78725cc03e2b:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc03e2f:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc03e33:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc03e37:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc03e3d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc03e41:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc03e47:	73 2d                	jae    0x78725cc03e76
    78725cc03e49:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    78725cc03e50:	00 
    78725cc03e51:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc03e55:	89 d1                	mov    ecx,edx
    78725cc03e57:	c1 e9 01             	shr    ecx,0x1
    78725cc03e5a:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc03e60:	89 c9                	mov    ecx,ecx
    78725cc03e62:	48 c1 e1 04          	shl    rcx,0x4
    78725cc03e66:	48 89 c6             	mov    rsi,rax
    78725cc03e69:	48 01 ce             	add    rsi,rcx
    78725cc03e6c:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc03e71:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc03e74:	74 1e                	je     0x78725cc03e94
    78725cc03e76:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc03e7d:	00 
    78725cc03e7e:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc03e82:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc03e86:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc03e8c:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc03e92:	eb 35                	jmp    0x78725cc03ec9
    78725cc03e94:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    78725cc03e9b:	00 
    78725cc03e9c:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    78725cc03ea3:	00 
    78725cc03ea4:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc03ea9:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc03ead:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc03eb4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc03ebb:	00 
    78725cc03ebc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc03ec0:	48 81 c4 28 01 00 00 	add    rsp,0x128
    78725cc03ec7:	ff e0                	jmp    rax
    78725cc03ec9:	48 81 c4 28 01 00 00 	add    rsp,0x128
    78725cc03ed0:	c2 08 00             	ret    0x8
