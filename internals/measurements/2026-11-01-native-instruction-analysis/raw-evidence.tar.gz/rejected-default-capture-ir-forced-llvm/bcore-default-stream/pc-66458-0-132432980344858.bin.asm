
build-native-instruction-analysis/capture/bcore-default-stream/pc-66458-0-132432980344858.bin:     file format binary


Disassembly of section .data:

0000787274c0001a <.data>:
    787274c0001a:	c7 07 00 00 00 00    	mov    DWORD PTR [rdi],0x0
    787274c00020:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    787274c00024:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    787274c00028:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    787274c0002f:	00 00 00 
    787274c00032:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    787274c00039:	03 01 00 
    787274c0003c:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    787274c00040:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    787274c00046:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    787274c0004c:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    787274c00053:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    787274c0005a:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    787274c00060:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    787274c00066:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    787274c0006d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    787274c00074:	00 00 00 
    787274c00077:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    787274c0007e:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    787274c00085:	00 00 00 
    787274c00088:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    787274c0008f:	48 83 c4 68          	add    rsp,0x68
    787274c00093:	c2 08 00             	ret    0x8
    787274c00096:	c6 87 65 01 00 00 01 	mov    BYTE PTR [rdi+0x165],0x1
    787274c0009d:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    787274c000a4:	48 83 c4 68          	add    rsp,0x68
    787274c000a8:	c2 08 00             	ret    0x8
    787274c000ab:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    787274c000af:	89 07                	mov    DWORD PTR [rdi],eax
    787274c000b1:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    787274c000b5:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    787274c000b9:	c7 87 9c 00 00 00 00 	mov    DWORD PTR [rdi+0x9c],0x0
    787274c000c0:	00 00 00 
    787274c000c3:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x103a0
    787274c000ca:	03 01 00 
    787274c000cd:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    787274c000d1:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    787274c000d7:	89 9f e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebx
    787274c000dd:	44 89 9f ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r11d
    787274c000e4:	44 89 9f f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r11d
    787274c000eb:	89 af f8 00 00 00    	mov    DWORD PTR [rdi+0xf8],ebp
    787274c000f1:	89 af fc 00 00 00    	mov    DWORD PTR [rdi+0xfc],ebp
    787274c000f7:	44 89 8f 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r9d
    787274c000fe:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    787274c00105:	00 00 00 
    787274c00108:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    787274c0010f:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    787274c00116:	00 00 00 
    787274c00119:	44 89 bf 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r15d
    787274c00120:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    787274c00127:	60 00 00 
    787274c0012a:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
    787274c0012f:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    787274c00134:	4c 89 44 24 38       	mov    QWORD PTR [rsp+0x38],r8
    787274c00139:	44 89 4c 24 24       	mov    DWORD PTR [rsp+0x24],r9d
    787274c0013e:	44 89 54 24 1c       	mov    DWORD PTR [rsp+0x1c],r10d
    787274c00143:	44 89 5c 24 20       	mov    DWORD PTR [rsp+0x20],r11d
    787274c00148:	ff d0                	call   rax
    787274c0014a:	44 8b 5c 24 20       	mov    r11d,DWORD PTR [rsp+0x20]
    787274c0014f:	44 8b 54 24 1c       	mov    r10d,DWORD PTR [rsp+0x1c]
    787274c00154:	44 8b 4c 24 24       	mov    r9d,DWORD PTR [rsp+0x24]
    787274c00159:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
    787274c0015e:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
    787274c00163:	0f b6 b7 28 01 00 00 	movzx  esi,BYTE PTR [rdi+0x128]
    787274c0016a:	40 84 f6             	test   sil,sil
    787274c0016d:	0f 84 21 03 01 e8    	je     0x78725cc10494
    787274c00173:	e9 8d 05 01 e8       	jmp    0x78725cc10705
