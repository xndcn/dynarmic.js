; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000101a0(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65952
  %6 = icmp ugt i32 %5, 78
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb161 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb161, 66462
  %11 = sub i32 %guard_lb161, 65952
  %12 = icmp ugt i32 %11, 78
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000101a0_entry, label %lb_guard_miss, !prof !0

insn_0x000101a0_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table205 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table205, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 44
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 61875
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000101a0_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 11, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000101a0_entry, %28
  br label %insn_0x000101a0

insn_0x000101a0:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 28
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000101a0
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65952, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 188
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  %40 = load i8, ptr %39, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000101a0
  %41 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %41 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %42 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %42 to i64
  %43 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %43, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %45, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %46 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %46, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %47 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %49, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %50 = icmp ne i8 %cec_pending, 0
  br i1 %50, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %51 = getelementptr i8, ptr %cpu, i64 188
  %next_pc162 = load i32, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i64 188
  %53 = load i32, ptr %52, align 4
  %54 = getelementptr i8, ptr %cpu, i64 296
  %55 = load i8, ptr %54, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %56 = getelementptr i8, ptr %cpu, i32 188
  store i32 65954, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %58, align 4
  call void @cec_check_pending(ptr %cpu)
  %59 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %59, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x000101a2_entry

did_jump_exit1:                                   ; preds = %cec_check
  %60 = getelementptr i8, ptr %cpu, i64 188
  %next_pc163 = load i32, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 188
  %62 = load i32, ptr %61, align 4
  %63 = getelementptr i8, ptr %cpu, i64 296
  %64 = load i8, ptr %63, align 1
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x000101a2_entry:                            ; preds = %cec_checked
  br label %insn_0x000101a2

insn_0x000101a2:                                  ; preds = %insn_0x000101a2_entry
  %65 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %66, align 4
  %sp1 = sub i32 %sp_dec, 4
  %67 = and i32 %sp1, 3
  %68 = icmp ne i32 %67, 0
  br i1 %68, label %data_misaligned5, label %data_aligned6, !prof !1

data_misaligned5:                                 ; preds = %insn_0x000101a2
  %69 = getelementptr i8, ptr %cpu, i32 188
  store i32 65954, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %71, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65954, i32 %sp1, i32 65536)
  %72 = getelementptr i8, ptr %cpu, i64 188
  %next_pc164 = load i32, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 188
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %cpu, i64 296
  %76 = load i8, ptr %75, align 1
  br label %chain_exit

data_aligned6:                                    ; preds = %insn_0x000101a2
  %77 = lshr i32 %sp1, 12
  %page_index10 = zext i32 %77 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13 = icmp ne ptr %page12, null
  br i1 %page_mapped13, label %page_wr_fast7, label %page_wr_slow8, !prof !0

page_wr_fast7:                                    ; preds = %data_aligned6
  %78 = and i32 %sp1, 4095
  %page_offset14 = zext i32 %78 to i64
  %79 = getelementptr i8, ptr %page12, i64 %page_offset14
  store i32 %rets, ptr %79, align 4
  br label %page_wr_done9

page_wr_slow8:                                    ; preds = %data_aligned6
  %80 = getelementptr i8, ptr %cpu, i32 188
  store i32 65954, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %82, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %83 = getelementptr i8, ptr %cpu, i32 296
  %dj17 = load i8, ptr %83, align 1
  %dj_set18 = icmp ne i8 %dj17, 0
  br i1 %dj_set18, label %did_jump_exit15, label %did_jump_cont16, !prof !1

page_wr_done9:                                    ; preds = %did_jump_cont16, %page_wr_fast7
  %sp2 = sub i32 %sp1, 4
  %84 = and i32 %sp2, 3
  %85 = icmp ne i32 %84, 0
  br i1 %85, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit15:                                  ; preds = %page_wr_slow8
  %86 = getelementptr i8, ptr %cpu, i64 188
  %next_pc165 = load i32, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i64 188
  %88 = load i32, ptr %87, align 4
  %89 = getelementptr i8, ptr %cpu, i64 296
  %90 = load i8, ptr %89, align 1
  br label %chain_exit

did_jump_cont16:                                  ; preds = %page_wr_slow8
  br label %page_wr_done9

data_misaligned19:                                ; preds = %page_wr_done9
  %91 = getelementptr i8, ptr %cpu, i32 188
  store i32 65954, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %93, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65954, i32 %sp2, i32 65536)
  %94 = getelementptr i8, ptr %cpu, i64 188
  %next_pc166 = load i32, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i64 188
  %96 = load i32, ptr %95, align 4
  %97 = getelementptr i8, ptr %cpu, i64 296
  %98 = load i8, ptr %97, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_wr_done9
  %99 = lshr i32 %sp2, 12
  %page_index24 = zext i32 %99 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast21, label %page_wr_slow22, !prof !0

page_wr_fast21:                                   ; preds = %data_aligned20
  %100 = and i32 %sp2, 4095
  %page_offset28 = zext i32 %100 to i64
  %101 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %fp, ptr %101, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %data_aligned20
  %102 = getelementptr i8, ptr %cpu, i32 188
  store i32 65954, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %103, align 4
  %104 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %104, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %105 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %105, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done23:                                   ; preds = %did_jump_cont30, %page_wr_fast21
  %106 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %106, align 4
  %sp3 = sub i32 %sp2, 0
  %107 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %107, align 4
  %cec_pending33 = load i8, ptr %cec_pending_flag, align 1
  %108 = icmp ne i8 %cec_pending33, 0
  br i1 %108, label %cec_check34, label %cec_checked35, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %109 = getelementptr i8, ptr %cpu, i64 188
  %next_pc167 = load i32, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 188
  %111 = load i32, ptr %110, align 4
  %112 = getelementptr i8, ptr %cpu, i64 296
  %113 = load i8, ptr %112, align 1
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow22
  br label %page_wr_done23

cec_check34:                                      ; preds = %page_wr_done23
  %114 = getelementptr i8, ptr %cpu, i32 188
  store i32 65958, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %116, align 4
  call void @cec_check_pending(ptr %cpu)
  %117 = getelementptr i8, ptr %cpu, i32 296
  %dj38 = load i8, ptr %117, align 1
  %dj_set39 = icmp ne i8 %dj38, 0
  br i1 %dj_set39, label %did_jump_exit36, label %did_jump_cont37, !prof !1

cec_checked35:                                    ; preds = %did_jump_cont37, %page_wr_done23
  br label %insn_0x000101a6_entry

did_jump_exit36:                                  ; preds = %cec_check34
  %118 = getelementptr i8, ptr %cpu, i64 188
  %next_pc168 = load i32, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i64 188
  %120 = load i32, ptr %119, align 4
  %121 = getelementptr i8, ptr %cpu, i64 296
  %122 = load i8, ptr %121, align 1
  br label %chain_exit

did_jump_cont37:                                  ; preds = %cec_check34
  br label %cec_checked35

insn_0x000101a6_entry:                            ; preds = %cec_checked35
  br label %insn_0x000101a6

insn_0x000101a6:                                  ; preds = %insn_0x000101a6_entry
  %123 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %123, align 4
  %diff = sub i32 %rx, 0
  %124 = icmp eq i32 %diff, 0
  %az = zext i1 %124 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %125 = xor i32 %flgn, %flgs
  %126 = xor i32 %flgs, 0
  %overflow = and i32 %126, %125
  %an = xor i32 %flgn, %overflow
  %127 = icmp ule i32 0, %rx
  %ac0 = zext i1 %127 to i32
  %128 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %132, align 4
  br label %insn_0x000101a8_entry

insn_0x000101a8_entry:                            ; preds = %insn_0x000101a6
  br label %insn_0x000101a8

insn_0x000101a8:                                  ; preds = %insn_0x000101a8_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x000101a8
  %133 = getelementptr i8, ptr %cpu, i32 188
  store i32 66032, ptr %133, align 4
  %134 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %134, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %135 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %135 monotonic, align 4, !range !2
  %136 = icmp ult i32 %chain_total, %chain_budget
  br i1 %136, label %chain_go, label %chain_leave169, !prof !0

brt_fallthru:                                     ; preds = %insn_0x000101a8
  br label %insn_0x000101aa_entry

insn_0x000101aa_entry:                            ; preds = %brt_fallthru
  br label %insn_0x000101aa

insn_0x000101aa:                                  ; preds = %insn_0x000101aa_entry
  %137 = getelementptr i8, ptr %cpu, i32 32
  %old = load i32, ptr %137, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %138 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_hi, ptr %138, align 4
  br label %insn_0x000101ae_entry

insn_0x000101ae_entry:                            ; preds = %insn_0x000101aa
  br label %insn_0x000101ae

insn_0x000101ae:                                  ; preds = %insn_0x000101ae_entry
  %139 = getelementptr i8, ptr %cpu, i32 4
  %regmv_src = load i32, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 36
  store i32 %regmv_src, ptr %140, align 4
  br label %insn_0x000101b0_entry

insn_0x000101b0_entry:                            ; preds = %insn_0x000101ae
  br label %insn_0x000101b0

insn_0x000101b0:                                  ; preds = %insn_0x000101b0_entry
  %141 = getelementptr i8, ptr %cpu, i32 8
  store i32 0, ptr %141, align 4
  br label %insn_0x000101b2_entry

insn_0x000101b2_entry:                            ; preds = %insn_0x000101b0
  br label %insn_0x000101b2

insn_0x000101b2:                                  ; preds = %insn_0x000101b2_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4860
  %142 = getelementptr i8, ptr %cpu, i32 32
  store i32 %with_lo, ptr %142, align 4
  br label %insn_0x000101b6_entry

insn_0x000101b6_entry:                            ; preds = %insn_0x000101b2
  br label %insn_0x000101b6

insn_0x000101b6:                                  ; preds = %insn_0x000101b6_entry
  %143 = getelementptr i8, ptr %cpu, i32 28
  store i32 8191, ptr %143, align 4
  br label %insn_0x000101ba_entry

insn_0x000101ba_entry:                            ; preds = %insn_0x000101b6
  br label %insn_0x000101ba

insn_0x000101ba:                                  ; preds = %insn_0x000101ba_entry
  %144 = getelementptr i8, ptr %cpu, i32 4
  store i32 0, ptr %144, align 4
  %145 = getelementptr i8, ptr %cpu, i32 228
  store i32 1, ptr %145, align 4
  %146 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %146, align 4
  %147 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %150, align 4
  br label %insn_0x000101bc_entry

insn_0x000101bc_entry:                            ; preds = %insn_0x000101ba
  br label %insn_0x000101bc

insn_0x000101bc:                                  ; preds = %insn_0x000101bc_entry
  %151 = getelementptr i8, ptr %cpu, i32 40
  store i32 0, ptr %151, align 4
  br label %insn_0x000101be_entry

insn_0x000101be_entry:                            ; preds = %insn_0x000101bc
  br label %insn_0x000101be

insn_0x000101be:                                  ; preds = %insn_0x000101be_entry
  %plshift2 = add i32 %with_lo, 0
  %152 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift2, ptr %152, align 4
  br label %insn_0x000101c0_entry

insn_0x000101c0_entry:                            ; preds = %insn_0x000101be
  br label %insn_0x000101c0

insn_0x000101c0:                                  ; preds = %insn_0x000101c0_entry
  %153 = and i32 %plshift2, 3
  %154 = icmp ne i32 %153, 0
  br i1 %154, label %data_misaligned40, label %data_aligned41, !prof !1

data_misaligned40:                                ; preds = %insn_0x000101c0
  %155 = getelementptr i8, ptr %cpu, i32 188
  store i32 65984, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %157, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65984, i32 %plshift2, i32 0)
  %158 = getelementptr i8, ptr %cpu, i64 188
  %next_pc170 = load i32, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i64 188
  %160 = load i32, ptr %159, align 4
  %161 = getelementptr i8, ptr %cpu, i64 296
  %162 = load i8, ptr %161, align 1
  br label %chain_exit

data_aligned41:                                   ; preds = %insn_0x000101c0
  %163 = lshr i32 %plshift2, 12
  %page_index42 = zext i32 %163 to i64
  %page_slot43 = getelementptr ptr, ptr %page_table, i64 %page_index42
  %page44 = load ptr, ptr %page_slot43, align 8
  %page_mapped45 = icmp ne ptr %page44, null
  br i1 %page_mapped45, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned41
  %164 = and i32 %plshift2, 4095
  %page_offset46 = zext i32 %164 to i64
  %165 = getelementptr i8, ptr %page44, i64 %page_offset46
  %page_val = load i32, ptr %165, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned41
  %166 = getelementptr i8, ptr %cpu, i32 188
  store i32 65984, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %168, align 4
  %169 = call i32 @mem_read32(ptr %mem, i32 %plshift2)
  %170 = getelementptr i8, ptr %cpu, i32 296
  %dj49 = load i8, ptr %170, align 1
  %dj_set50 = icmp ne i8 %dj49, 0
  br i1 %dj_set50, label %did_jump_exit47, label %did_jump_cont48, !prof !1

page_done:                                        ; preds = %did_jump_cont48, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %169, %did_jump_cont48 ]
  %171 = getelementptr i8, ptr %cpu, i32 12
  store i32 %mem_val, ptr %171, align 4
  br label %insn_0x000101c2_entry

did_jump_exit47:                                  ; preds = %page_slow
  %172 = getelementptr i8, ptr %cpu, i64 188
  %next_pc171 = load i32, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i64 188
  %174 = load i32, ptr %173, align 4
  %175 = getelementptr i8, ptr %cpu, i64 296
  %176 = load i8, ptr %175, align 1
  br label %chain_exit

did_jump_cont48:                                  ; preds = %page_slow
  br label %page_done

insn_0x000101c2_entry:                            ; preds = %page_done
  br label %insn_0x000101c2

insn_0x000101c2:                                  ; preds = %insn_0x000101c2_entry
  %add32 = add i32 0, %mem_val
  %177 = getelementptr i8, ptr %cpu, i32 12
  store i32 %add32, ptr %177, align 4
  %flgo = lshr i32 %mem_val, 31
  %flgn51 = lshr i32 %add32, 31
  %178 = xor i32 %flgo, %flgn51
  %179 = xor i32 0, %flgn51
  %180 = and i32 %179, %178
  %181 = icmp ult i32 -1, %mem_val
  %ac052 = zext i1 %181 to i32
  %182 = icmp eq i32 %add32, 0
  %az53 = zext i1 %182 to i32
  %an54 = lshr i32 %add32, 31
  %183 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az53, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an54, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %185, align 4
  %186 = or i32 %vs_cur, %180
  %187 = getelementptr i8, ptr %cpu, i32 248
  store i32 %180, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i32 252
  store i32 %180, ptr %188, align 4
  %189 = getelementptr i8, ptr %cpu, i32 256
  store i32 %186, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac052, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac052, ptr %191, align 4
  br label %insn_0x000101c4_entry

insn_0x000101c4_entry:                            ; preds = %insn_0x000101c2
  br label %insn_0x000101c4

insn_0x000101c4:                                  ; preds = %insn_0x000101c4_entry
  %lsr32 = lshr i32 %add32, 11
  %192 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr32, ptr %192, align 4
  %193 = icmp eq i32 %lsr32, 0
  %az55 = zext i1 %193 to i32
  %an56 = lshr i32 %lsr32, 31
  %194 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az55, ptr %194, align 4
  %195 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an56, ptr %195, align 4
  %196 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %196, align 4
  %197 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %197, align 4
  br label %insn_0x000101c8_entry

insn_0x000101c8_entry:                            ; preds = %insn_0x000101c4
  br label %insn_0x000101c8

insn_0x000101c8:                                  ; preds = %insn_0x000101c8_entry
  %xor32 = xor i32 %add32, %lsr32
  %198 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %198, align 4
  %199 = icmp eq i32 %xor32, 0
  %az57 = zext i1 %199 to i32
  %an58 = lshr i32 %xor32, 31
  %200 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az57, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an58, ptr %201, align 4
  %202 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %205, align 4
  br label %insn_0x000101ca_entry

insn_0x000101ca_entry:                            ; preds = %insn_0x000101c8
  br label %insn_0x000101ca

insn_0x000101ca:                                  ; preds = %insn_0x000101ca_entry
  %206 = and i32 %plshift2, 3
  %207 = icmp ne i32 %206, 0
  br i1 %207, label %data_misaligned59, label %data_aligned60, !prof !1

data_misaligned59:                                ; preds = %insn_0x000101ca
  %208 = getelementptr i8, ptr %cpu, i32 188
  store i32 65994, ptr %208, align 4
  %209 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i32 308
  store i32 17, ptr %210, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65994, i32 %plshift2, i32 65536)
  %211 = getelementptr i8, ptr %cpu, i64 188
  %next_pc172 = load i32, ptr %211, align 4
  %212 = getelementptr i8, ptr %cpu, i64 188
  %213 = load i32, ptr %212, align 4
  %214 = getelementptr i8, ptr %cpu, i64 296
  %215 = load i8, ptr %214, align 1
  br label %chain_exit

data_aligned60:                                   ; preds = %insn_0x000101ca
  %216 = lshr i32 %plshift2, 12
  %page_index64 = zext i32 %216 to i64
  %page_slot65 = getelementptr ptr, ptr %page_table, i64 %page_index64
  %page66 = load ptr, ptr %page_slot65, align 8
  %page_mapped67 = icmp ne ptr %page66, null
  br i1 %page_mapped67, label %page_wr_fast61, label %page_wr_slow62, !prof !0

page_wr_fast61:                                   ; preds = %data_aligned60
  %217 = and i32 %plshift2, 4095
  %page_offset68 = zext i32 %217 to i64
  %218 = getelementptr i8, ptr %page66, i64 %page_offset68
  store i32 %xor32, ptr %218, align 4
  br label %page_wr_done63

page_wr_slow62:                                   ; preds = %data_aligned60
  %219 = getelementptr i8, ptr %cpu, i32 188
  store i32 65994, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 308
  store i32 17, ptr %221, align 4
  call void @mem_write32(ptr %mem, i32 %plshift2, i32 %xor32)
  %222 = getelementptr i8, ptr %cpu, i32 296
  %dj71 = load i8, ptr %222, align 1
  %dj_set72 = icmp ne i8 %dj71, 0
  br i1 %dj_set72, label %did_jump_exit69, label %did_jump_cont70, !prof !1

page_wr_done63:                                   ; preds = %did_jump_cont70, %page_wr_fast61
  %cec_pending73 = load i8, ptr %cec_pending_flag, align 1
  %223 = icmp ne i8 %cec_pending73, 0
  br i1 %223, label %cec_check74, label %cec_checked75, !prof !1

did_jump_exit69:                                  ; preds = %page_wr_slow62
  %224 = getelementptr i8, ptr %cpu, i64 188
  %next_pc173 = load i32, ptr %224, align 4
  %225 = getelementptr i8, ptr %cpu, i64 188
  %226 = load i32, ptr %225, align 4
  %227 = getelementptr i8, ptr %cpu, i64 296
  %228 = load i8, ptr %227, align 1
  br label %chain_exit

did_jump_cont70:                                  ; preds = %page_wr_slow62
  br label %page_wr_done63

cec_check74:                                      ; preds = %page_wr_done63
  %229 = getelementptr i8, ptr %cpu, i32 188
  store i32 65996, ptr %229, align 4
  %230 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i32 308
  store i32 17, ptr %231, align 4
  call void @cec_check_pending(ptr %cpu)
  %232 = getelementptr i8, ptr %cpu, i32 296
  %dj78 = load i8, ptr %232, align 1
  %dj_set79 = icmp ne i8 %dj78, 0
  br i1 %dj_set79, label %did_jump_exit76, label %did_jump_cont77, !prof !1

cec_checked75:                                    ; preds = %did_jump_cont77, %page_wr_done63
  br label %insn_0x000101cc_entry

did_jump_exit76:                                  ; preds = %cec_check74
  %233 = getelementptr i8, ptr %cpu, i64 188
  %next_pc174 = load i32, ptr %233, align 4
  %234 = getelementptr i8, ptr %cpu, i64 188
  %235 = load i32, ptr %234, align 4
  %236 = getelementptr i8, ptr %cpu, i64 296
  %237 = load i8, ptr %236, align 1
  br label %chain_exit

did_jump_cont77:                                  ; preds = %cec_check74
  br label %cec_checked75

insn_0x000101cc_entry:                            ; preds = %cec_checked75
  br label %insn_0x000101cc

insn_0x000101cc:                                  ; preds = %insn_0x000101cc_entry
  %238 = getelementptr i8, ptr %cpu, i32 40
  store i32 %add32, ptr %238, align 4
  br label %insn_0x000101ce_entry

insn_0x000101ce_entry:                            ; preds = %insn_0x000101cc
  br label %insn_0x000101ce

insn_0x000101ce:                                  ; preds = %insn_0x000101ce_entry
  %239 = getelementptr i8, ptr %cpu, i32 8
  store i32 1, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %240, align 4
  %241 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %241, align 4
  %242 = or i32 %186, 0
  %243 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %243, align 4
  %244 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %244, align 4
  %245 = getelementptr i8, ptr %cpu, i32 256
  store i32 %242, ptr %245, align 4
  %246 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %246, align 4
  %247 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %247, align 4
  br label %insn_0x000101d0_entry

insn_0x000101d0_entry:                            ; preds = %insn_0x000101ce
  br label %insn_0x000101d0

insn_0x000101d0:                                  ; preds = %insn_0x000101d0_entry
  %248 = icmp ule i32 %rx, 1
  %cc = zext i1 %248 to i32
  %249 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %249, align 4
  %250 = icmp eq i32 %rx, 1
  %az80 = zext i1 %250 to i32
  %251 = icmp ugt i32 1, %rx
  %an81 = zext i1 %251 to i32
  %252 = icmp ule i32 1, %rx
  %ac082 = zext i1 %252 to i32
  %253 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az80, ptr %253, align 4
  %254 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an81, ptr %254, align 4
  %255 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac082, ptr %255, align 4
  %256 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac082, ptr %256, align 4
  br label %insn_0x000101d2_entry

insn_0x000101d2_entry:                            ; preds = %insn_0x000101d0
  br label %insn_0x000101d2

insn_0x000101d2:                                  ; preds = %insn_0x000101d2_entry
  %padd = add i32 %regmv_src, %add32
  %257 = getelementptr i8, ptr %cpu, i32 36
  store i32 %padd, ptr %257, align 4
  br label %insn_0x000101d4_entry

insn_0x000101d4_entry:                            ; preds = %insn_0x000101d2
  br label %insn_0x000101d4

insn_0x000101d4:                                  ; preds = %insn_0x000101d4_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x000101d4
  %258 = getelementptr i8, ptr %cpu, i32 188
  store i32 65978, ptr %258, align 4
  %259 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets177 = load i32, ptr %259, align 4
  %chain_total178 = add nuw i32 %chain_packets177, 22
  %260 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget179 = load atomic i32, ptr %260 monotonic, align 4, !range !2
  %261 = icmp ult i32 %chain_total178, %chain_budget179
  br i1 %261, label %chain_go175, label %chain_leave176, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x000101d4
  br label %insn_0x000101d6_entry

insn_0x000101d6_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x000101d6

insn_0x000101d6:                                  ; preds = %insn_0x000101d6_entry
  %262 = getelementptr i8, ptr %cpu, i32 4
  store i32 8191, ptr %262, align 4
  br label %insn_0x000101da_entry

insn_0x000101da_entry:                            ; preds = %insn_0x000101d6
  br label %insn_0x000101da

insn_0x000101da:                                  ; preds = %insn_0x000101da_entry
  %rd_add = add i32 %rx, -1
  %263 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rd_add, ptr %263, align 4
  %flgs83 = lshr i32 %rx, 31
  %flgn84 = lshr i32 %rd_add, 31
  %264 = xor i32 1, %flgn84
  %265 = xor i32 %flgs83, %flgn84
  %overflow85 = and i32 %265, %264
  %266 = xor i32 %rx, -1
  %267 = icmp ult i32 %266, -1
  %ac086 = zext i1 %267 to i32
  %268 = icmp eq i32 %rd_add, 0
  %az87 = zext i1 %268 to i32
  %an88 = lshr i32 %rd_add, 31
  %269 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az87, ptr %269, align 4
  %270 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an88, ptr %270, align 4
  %271 = or i32 %242, %overflow85
  %272 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow85, ptr %272, align 4
  %273 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow85, ptr %273, align 4
  %274 = getelementptr i8, ptr %cpu, i32 256
  store i32 %271, ptr %274, align 4
  %275 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac086, ptr %275, align 4
  %276 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac086, ptr %276, align 4
  br label %insn_0x000101dc_entry

insn_0x000101dc_entry:                            ; preds = %insn_0x000101da
  br label %insn_0x000101dc

insn_0x000101dc:                                  ; preds = %insn_0x000101dc_entry
  %and32 = and i32 8191, %rd_add
  %277 = getelementptr i8, ptr %cpu, i32 0
  store i32 %and32, ptr %277, align 4
  %278 = icmp eq i32 %and32, 0
  %az89 = zext i1 %278 to i32
  %an90 = lshr i32 %and32, 31
  %279 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az89, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an90, ptr %280, align 4
  %281 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %282, align 4
  %283 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %283, align 4
  %284 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %284, align 4
  br label %insn_0x000101de_entry

insn_0x000101de_entry:                            ; preds = %insn_0x000101dc
  br label %insn_0x000101de

insn_0x000101de:                                  ; preds = %insn_0x000101de_entry
  %285 = getelementptr i8, ptr %cpu, i32 40
  store i32 %and32, ptr %285, align 4
  br label %insn_0x000101e0_entry

insn_0x000101e0_entry:                            ; preds = %insn_0x000101de
  br label %insn_0x000101e0

insn_0x000101e0:                                  ; preds = %insn_0x000101e0_entry
  %286 = getelementptr i8, ptr %cpu, i32 4
  store i32 %padd, ptr %286, align 4
  br label %insn_0x000101e2_entry

insn_0x000101e2_entry:                            ; preds = %insn_0x000101e0
  br label %insn_0x000101e2

insn_0x000101e2:                                  ; preds = %insn_0x000101e2_entry
  %287 = and i32 %sp2, 3
  %288 = icmp ne i32 %287, 0
  br i1 %288, label %data_misaligned91, label %data_aligned92, !prof !1

data_misaligned91:                                ; preds = %insn_0x000101e2
  %289 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %289, align 4
  %290 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %290, align 4
  %291 = getelementptr i8, ptr %cpu, i32 308
  store i32 28, ptr %291, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66018, i32 %sp2, i32 0)
  %292 = getelementptr i8, ptr %cpu, i64 188
  %next_pc184 = load i32, ptr %292, align 4
  %293 = getelementptr i8, ptr %cpu, i64 188
  %294 = load i32, ptr %293, align 4
  %295 = getelementptr i8, ptr %cpu, i64 296
  %296 = load i8, ptr %295, align 1
  br label %chain_exit

data_aligned92:                                   ; preds = %insn_0x000101e2
  %297 = lshr i32 %sp2, 12
  %page_index96 = zext i32 %297 to i64
  %page_slot97 = getelementptr ptr, ptr %page_table, i64 %page_index96
  %page98 = load ptr, ptr %page_slot97, align 8
  %page_mapped99 = icmp ne ptr %page98, null
  br i1 %page_mapped99, label %page_fast93, label %page_slow94, !prof !0

page_fast93:                                      ; preds = %data_aligned92
  %298 = and i32 %sp2, 4095
  %page_offset100 = zext i32 %298 to i64
  %299 = getelementptr i8, ptr %page98, i64 %page_offset100
  %page_val101 = load i32, ptr %299, align 4
  br label %page_done95

page_slow94:                                      ; preds = %data_aligned92
  %300 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %300, align 4
  %301 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %301, align 4
  %302 = getelementptr i8, ptr %cpu, i32 308
  store i32 28, ptr %302, align 4
  %303 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %304 = getelementptr i8, ptr %cpu, i32 296
  %dj104 = load i8, ptr %304, align 1
  %dj_set105 = icmp ne i8 %dj104, 0
  br i1 %dj_set105, label %did_jump_exit102, label %did_jump_cont103, !prof !1

page_done95:                                      ; preds = %did_jump_cont103, %page_fast93
  %mem_val106 = phi i32 [ %page_val101, %page_fast93 ], [ %303, %did_jump_cont103 ]
  %sp1107 = add i32 %sp2, 4
  %305 = and i32 %sp1107, 3
  %306 = icmp ne i32 %305, 0
  br i1 %306, label %data_misaligned108, label %data_aligned109, !prof !1

did_jump_exit102:                                 ; preds = %page_slow94
  %307 = getelementptr i8, ptr %cpu, i64 188
  %next_pc185 = load i32, ptr %307, align 4
  %308 = getelementptr i8, ptr %cpu, i64 188
  %309 = load i32, ptr %308, align 4
  %310 = getelementptr i8, ptr %cpu, i64 296
  %311 = load i8, ptr %310, align 1
  br label %chain_exit

did_jump_cont103:                                 ; preds = %page_slow94
  br label %page_done95

data_misaligned108:                               ; preds = %page_done95
  %312 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %312, align 4
  %313 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %313, align 4
  %314 = getelementptr i8, ptr %cpu, i32 308
  store i32 28, ptr %314, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66018, i32 %sp1107, i32 0)
  %315 = getelementptr i8, ptr %cpu, i64 188
  %next_pc186 = load i32, ptr %315, align 4
  %316 = getelementptr i8, ptr %cpu, i64 188
  %317 = load i32, ptr %316, align 4
  %318 = getelementptr i8, ptr %cpu, i64 296
  %319 = load i8, ptr %318, align 1
  br label %chain_exit

data_aligned109:                                  ; preds = %page_done95
  %320 = lshr i32 %sp1107, 12
  %page_index113 = zext i32 %320 to i64
  %page_slot114 = getelementptr ptr, ptr %page_table, i64 %page_index113
  %page115 = load ptr, ptr %page_slot114, align 8
  %page_mapped116 = icmp ne ptr %page115, null
  br i1 %page_mapped116, label %page_fast110, label %page_slow111, !prof !0

page_fast110:                                     ; preds = %data_aligned109
  %321 = and i32 %sp1107, 4095
  %page_offset117 = zext i32 %321 to i64
  %322 = getelementptr i8, ptr %page115, i64 %page_offset117
  %page_val118 = load i32, ptr %322, align 4
  br label %page_done112

page_slow111:                                     ; preds = %data_aligned109
  %323 = getelementptr i8, ptr %cpu, i32 188
  store i32 66018, ptr %323, align 4
  %324 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %324, align 4
  %325 = getelementptr i8, ptr %cpu, i32 308
  store i32 28, ptr %325, align 4
  %326 = call i32 @mem_read32(ptr %mem, i32 %sp1107)
  %327 = getelementptr i8, ptr %cpu, i32 296
  %dj121 = load i8, ptr %327, align 1
  %dj_set122 = icmp ne i8 %dj121, 0
  br i1 %dj_set122, label %did_jump_exit119, label %did_jump_cont120, !prof !1

page_done112:                                     ; preds = %did_jump_cont120, %page_fast110
  %mem_val123 = phi i32 [ %page_val118, %page_fast110 ], [ %326, %did_jump_cont120 ]
  %sp2124 = add i32 %sp1107, 4
  %328 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val106, ptr %328, align 4
  %329 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val123, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2124, ptr %330, align 4
  br label %insn_0x000101e6_entry

did_jump_exit119:                                 ; preds = %page_slow111
  %331 = getelementptr i8, ptr %cpu, i64 188
  %next_pc187 = load i32, ptr %331, align 4
  %332 = getelementptr i8, ptr %cpu, i64 188
  %333 = load i32, ptr %332, align 4
  %334 = getelementptr i8, ptr %cpu, i64 296
  %335 = load i8, ptr %334, align 1
  br label %chain_exit

did_jump_cont120:                                 ; preds = %page_slow111
  br label %page_done112

insn_0x000101e6_entry:                            ; preds = %page_done112
  br label %insn_0x000101e6

insn_0x000101e6:                                  ; preds = %insn_0x000101e6_entry
  %336 = and i32 %sp2124, 3
  %337 = icmp ne i32 %336, 0
  br i1 %337, label %data_misaligned125, label %data_aligned126, !prof !1

data_misaligned125:                               ; preds = %insn_0x000101e6
  %338 = getelementptr i8, ptr %cpu, i32 188
  store i32 66022, ptr %338, align 4
  %339 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %339, align 4
  %340 = getelementptr i8, ptr %cpu, i32 308
  store i32 29, ptr %340, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66022, i32 %sp2124, i32 0)
  %341 = getelementptr i8, ptr %cpu, i64 188
  %next_pc188 = load i32, ptr %341, align 4
  %342 = getelementptr i8, ptr %cpu, i64 188
  %343 = load i32, ptr %342, align 4
  %344 = getelementptr i8, ptr %cpu, i64 296
  %345 = load i8, ptr %344, align 1
  br label %chain_exit

data_aligned126:                                  ; preds = %insn_0x000101e6
  %346 = lshr i32 %sp2124, 12
  %page_index130 = zext i32 %346 to i64
  %page_slot131 = getelementptr ptr, ptr %page_table, i64 %page_index130
  %page132 = load ptr, ptr %page_slot131, align 8
  %page_mapped133 = icmp ne ptr %page132, null
  br i1 %page_mapped133, label %page_fast127, label %page_slow128, !prof !0

page_fast127:                                     ; preds = %data_aligned126
  %347 = and i32 %sp2124, 4095
  %page_offset134 = zext i32 %347 to i64
  %348 = getelementptr i8, ptr %page132, i64 %page_offset134
  %page_val135 = load i32, ptr %348, align 4
  br label %page_done129

page_slow128:                                     ; preds = %data_aligned126
  %349 = getelementptr i8, ptr %cpu, i32 188
  store i32 66022, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %350, align 4
  %351 = getelementptr i8, ptr %cpu, i32 308
  store i32 29, ptr %351, align 4
  %352 = call i32 @mem_read32(ptr %mem, i32 %sp2124)
  %353 = getelementptr i8, ptr %cpu, i32 296
  %dj138 = load i8, ptr %353, align 1
  %dj_set139 = icmp ne i8 %dj138, 0
  br i1 %dj_set139, label %did_jump_exit136, label %did_jump_cont137, !prof !1

page_done129:                                     ; preds = %did_jump_cont137, %page_fast127
  %mem_val140 = phi i32 [ %page_val135, %page_fast127 ], [ %352, %did_jump_cont137 ]
  %354 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val140, ptr %354, align 4
  %sp_inc = add i32 %sp2124, 4
  %355 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc, ptr %355, align 4
  br label %insn_0x000101e8_entry

did_jump_exit136:                                 ; preds = %page_slow128
  %356 = getelementptr i8, ptr %cpu, i64 188
  %next_pc189 = load i32, ptr %356, align 4
  %357 = getelementptr i8, ptr %cpu, i64 188
  %358 = load i32, ptr %357, align 4
  %359 = getelementptr i8, ptr %cpu, i64 296
  %360 = load i8, ptr %359, align 1
  br label %chain_exit

did_jump_cont137:                                 ; preds = %page_slow128
  br label %page_done129

insn_0x000101e8_entry:                            ; preds = %page_done129
  br label %insn_0x000101e8

insn_0x000101e8:                                  ; preds = %insn_0x000101e8_entry
  %361 = shl i32 %and32, 2
  %plshift2141 = add i32 %with_lo, %361
  %362 = getelementptr i8, ptr %cpu, i32 32
  store i32 %plshift2141, ptr %362, align 4
  br label %insn_0x000101ea_entry

insn_0x000101ea_entry:                            ; preds = %insn_0x000101e8
  br label %insn_0x000101ea

insn_0x000101ea:                                  ; preds = %insn_0x000101ea_entry
  %363 = and i32 %plshift2141, 3
  %364 = icmp ne i32 %363, 0
  br i1 %364, label %data_misaligned142, label %data_aligned143, !prof !1

data_misaligned142:                               ; preds = %insn_0x000101ea
  %365 = getelementptr i8, ptr %cpu, i32 188
  store i32 66026, ptr %365, align 4
  %366 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %366, align 4
  %367 = getelementptr i8, ptr %cpu, i32 308
  store i32 31, ptr %367, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66026, i32 %plshift2141, i32 0)
  %368 = getelementptr i8, ptr %cpu, i64 188
  %next_pc190 = load i32, ptr %368, align 4
  %369 = getelementptr i8, ptr %cpu, i64 188
  %370 = load i32, ptr %369, align 4
  %371 = getelementptr i8, ptr %cpu, i64 296
  %372 = load i8, ptr %371, align 1
  br label %chain_exit

data_aligned143:                                  ; preds = %insn_0x000101ea
  %373 = lshr i32 %plshift2141, 12
  %page_index147 = zext i32 %373 to i64
  %page_slot148 = getelementptr ptr, ptr %page_table, i64 %page_index147
  %page149 = load ptr, ptr %page_slot148, align 8
  %page_mapped150 = icmp ne ptr %page149, null
  br i1 %page_mapped150, label %page_fast144, label %page_slow145, !prof !0

page_fast144:                                     ; preds = %data_aligned143
  %374 = and i32 %plshift2141, 4095
  %page_offset151 = zext i32 %374 to i64
  %375 = getelementptr i8, ptr %page149, i64 %page_offset151
  %page_val152 = load i32, ptr %375, align 4
  br label %page_done146

page_slow145:                                     ; preds = %data_aligned143
  %376 = getelementptr i8, ptr %cpu, i32 188
  store i32 66026, ptr %376, align 4
  %377 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %377, align 4
  %378 = getelementptr i8, ptr %cpu, i32 308
  store i32 31, ptr %378, align 4
  %379 = call i32 @mem_read32(ptr %mem, i32 %plshift2141)
  %380 = getelementptr i8, ptr %cpu, i32 296
  %dj155 = load i8, ptr %380, align 1
  %dj_set156 = icmp ne i8 %dj155, 0
  br i1 %dj_set156, label %did_jump_exit153, label %did_jump_cont154, !prof !1

page_done146:                                     ; preds = %did_jump_cont154, %page_fast144
  %mem_val157 = phi i32 [ %page_val152, %page_fast144 ], [ %379, %did_jump_cont154 ]
  %381 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val157, ptr %381, align 4
  br label %insn_0x000101ec_entry

did_jump_exit153:                                 ; preds = %page_slow145
  %382 = getelementptr i8, ptr %cpu, i64 188
  %next_pc191 = load i32, ptr %382, align 4
  %383 = getelementptr i8, ptr %cpu, i64 188
  %384 = load i32, ptr %383, align 4
  %385 = getelementptr i8, ptr %cpu, i64 296
  %386 = load i8, ptr %385, align 1
  br label %chain_exit

did_jump_cont154:                                 ; preds = %page_slow145
  br label %page_done146

insn_0x000101ec_entry:                            ; preds = %page_done146
  br label %insn_0x000101ec

insn_0x000101ec:                                  ; preds = %insn_0x000101ec_entry
  %xor32158 = xor i32 %mem_val157, %padd
  %387 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32158, ptr %387, align 4
  %388 = icmp eq i32 %xor32158, 0
  %az159 = zext i1 %388 to i32
  %an160 = lshr i32 %xor32158, 31
  %389 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az159, ptr %389, align 4
  %390 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an160, ptr %390, align 4
  %391 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %391, align 4
  %392 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %392, align 4
  %393 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %393, align 4
  %394 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %394, align 4
  br label %insn_0x000101ee_entry

insn_0x000101ee_entry:                            ; preds = %insn_0x000101ec
  br label %insn_0x000101ee

insn_0x000101ee:                                  ; preds = %insn_0x000101ee_entry
  %lsb = and i32 %mem_val123, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x000101ee
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x000101ee
  %395 = getelementptr i8, ptr %cpu, i32 188
  store i32 66030, ptr %395, align 4
  %396 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %396, align 4
  %397 = getelementptr i8, ptr %cpu, i32 308
  store i32 33, ptr %397, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %398 = getelementptr i8, ptr %cpu, i64 188
  %next_pc192 = load i32, ptr %398, align 4
  %399 = getelementptr i8, ptr %cpu, i64 188
  %400 = load i32, ptr %399, align 4
  %401 = getelementptr i8, ptr %cpu, i64 296
  %402 = load i8, ptr %401, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %403 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %403, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 528256
  %404 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %404, align 4
  %405 = icmp eq i32 %slot_pc, 66032
  br i1 %405, label %chain_hit, label %chain_leave169, !prof !0

chain_leave169:                                   ; preds = %chain_go, %brt_taken
  %406 = getelementptr i8, ptr %cpu, i64 188
  store i32 66032, ptr %406, align 4
  %407 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %407, align 4
  %408 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %408, align 4
  %409 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %409, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %410 = getelementptr i8, ptr %cpu, i64 188
  store i32 66032, ptr %410, align 4
  %411 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %411, align 4
  %412 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %412, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go175:                                      ; preds = %brcc_taken
  %chain_slot180 = getelementptr i8, ptr %chain_table, i64 527824
  %413 = getelementptr i8, ptr %chain_slot180, i64 0
  %slot_pc181 = load i32, ptr %413, align 4
  %414 = icmp eq i32 %slot_pc181, 65978
  br i1 %414, label %chain_hit182, label %chain_leave176, !prof !0

chain_leave176:                                   ; preds = %chain_go175, %brcc_taken
  %415 = getelementptr i8, ptr %cpu, i64 188
  store i32 65978, ptr %415, align 4
  %416 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %416, align 4
  %417 = getelementptr i8, ptr %cpu, i64 308
  store i32 22, ptr %417, align 4
  %418 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %418, align 1
  br label %return

chain_hit182:                                     ; preds = %chain_go175
  %419 = getelementptr i8, ptr %cpu, i64 188
  store i32 65978, ptr %419, align 4
  %420 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total178, ptr %420, align 4
  %421 = getelementptr i8, ptr %chain_slot180, i64 8
  %chain_fn183 = load ptr, ptr %421, align 8
  musttail call swifttailcc void %chain_fn183(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit153, %data_misaligned142, %did_jump_exit136, %data_misaligned125, %did_jump_exit119, %data_misaligned108, %did_jump_exit102, %data_misaligned91, %did_jump_exit76, %did_jump_exit69, %data_misaligned59, %did_jump_exit47, %data_misaligned40, %did_jump_exit36, %did_jump_exit29, %data_misaligned19, %did_jump_exit15, %data_misaligned5, %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc193 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc162, %did_jump_exit ], [ %next_pc163, %did_jump_exit1 ], [ %next_pc164, %data_misaligned5 ], [ %next_pc165, %did_jump_exit15 ], [ %next_pc166, %data_misaligned19 ], [ %next_pc167, %did_jump_exit29 ], [ %next_pc168, %did_jump_exit36 ], [ %next_pc170, %data_misaligned40 ], [ %next_pc171, %did_jump_exit47 ], [ %next_pc172, %data_misaligned59 ], [ %next_pc173, %did_jump_exit69 ], [ %next_pc174, %did_jump_exit76 ], [ %next_pc184, %data_misaligned91 ], [ %next_pc185, %did_jump_exit102 ], [ %next_pc186, %data_misaligned108 ], [ %next_pc187, %did_jump_exit119 ], [ %next_pc188, %data_misaligned125 ], [ %next_pc189, %did_jump_exit136 ], [ %next_pc190, %data_misaligned142 ], [ %next_pc191, %did_jump_exit153 ], [ %mem_val123, %jump_aligned ], [ %next_pc192, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 2, %data_misaligned5 ], [ 2, %did_jump_exit15 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit29 ], [ 2, %did_jump_exit36 ], [ 13, %data_misaligned40 ], [ 13, %did_jump_exit47 ], [ 17, %data_misaligned59 ], [ 17, %did_jump_exit69 ], [ 17, %did_jump_exit76 ], [ 28, %data_misaligned91 ], [ 28, %did_jump_exit102 ], [ 28, %data_misaligned108 ], [ 28, %did_jump_exit119 ], [ 29, %data_misaligned125 ], [ 29, %did_jump_exit136 ], [ 31, %data_misaligned142 ], [ 31, %did_jump_exit153 ], [ 33, %jump_aligned ], [ 33, %jump_misalign ]
  %tail = phi i32 [ %38, %data_misaligned ], [ %53, %did_jump_exit ], [ %62, %did_jump_exit1 ], [ %74, %data_misaligned5 ], [ %88, %did_jump_exit15 ], [ %96, %data_misaligned19 ], [ %111, %did_jump_exit29 ], [ %120, %did_jump_exit36 ], [ %160, %data_misaligned40 ], [ %174, %did_jump_exit47 ], [ %213, %data_misaligned59 ], [ %226, %did_jump_exit69 ], [ %235, %did_jump_exit76 ], [ %294, %data_misaligned91 ], [ %309, %did_jump_exit102 ], [ %317, %data_misaligned108 ], [ %333, %did_jump_exit119 ], [ %343, %data_misaligned125 ], [ %358, %did_jump_exit136 ], [ %370, %data_misaligned142 ], [ %384, %did_jump_exit153 ], [ %mem_val123, %jump_aligned ], [ %400, %jump_misalign ]
  %tail194 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ], [ 4, %data_misaligned5 ], [ 4, %did_jump_exit15 ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit29 ], [ 4, %did_jump_exit36 ], [ 2, %data_misaligned40 ], [ 2, %did_jump_exit47 ], [ 2, %data_misaligned59 ], [ 2, %did_jump_exit69 ], [ 2, %did_jump_exit76 ], [ 4, %data_misaligned91 ], [ 4, %did_jump_exit102 ], [ 4, %data_misaligned108 ], [ 4, %did_jump_exit119 ], [ 2, %data_misaligned125 ], [ 2, %did_jump_exit136 ], [ 2, %data_misaligned142 ], [ 2, %did_jump_exit153 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail195 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %did_jump_exit1 ], [ 2, %data_misaligned5 ], [ 2, %did_jump_exit15 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit29 ], [ 2, %did_jump_exit36 ], [ 13, %data_misaligned40 ], [ 13, %did_jump_exit47 ], [ 17, %data_misaligned59 ], [ 17, %did_jump_exit69 ], [ 17, %did_jump_exit76 ], [ 28, %data_misaligned91 ], [ 28, %did_jump_exit102 ], [ 28, %data_misaligned108 ], [ 28, %did_jump_exit119 ], [ 29, %data_misaligned125 ], [ 29, %did_jump_exit136 ], [ 31, %data_misaligned142 ], [ 31, %did_jump_exit153 ], [ 33, %jump_aligned ], [ 33, %jump_misalign ]
  %tail196 = phi i8 [ %40, %data_misaligned ], [ %55, %did_jump_exit ], [ %64, %did_jump_exit1 ], [ %76, %data_misaligned5 ], [ %90, %did_jump_exit15 ], [ %98, %data_misaligned19 ], [ %113, %did_jump_exit29 ], [ %122, %did_jump_exit36 ], [ %162, %data_misaligned40 ], [ %176, %did_jump_exit47 ], [ %215, %data_misaligned59 ], [ %228, %did_jump_exit69 ], [ %237, %did_jump_exit76 ], [ %296, %data_misaligned91 ], [ %311, %did_jump_exit102 ], [ %319, %data_misaligned108 ], [ %335, %did_jump_exit119 ], [ %345, %data_misaligned125 ], [ %360, %did_jump_exit136 ], [ %372, %data_misaligned142 ], [ %386, %did_jump_exit153 ], [ 1, %jump_aligned ], [ %402, %jump_misalign ]
  %422 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets198 = load i32, ptr %422, align 4
  %chain_total199 = add nuw i32 %chain_packets198, %packets
  %423 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget200 = load atomic i32, ptr %423 monotonic, align 4, !range !2
  %424 = icmp ult i32 %chain_total199, %chain_budget200
  br i1 %424, label %chain_lookup, label %chain_leave197, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %425 = lshr i32 %next_pc193, 1
  %426 = and i32 %425, 65535
  %427 = zext i32 %426 to i64
  %428 = mul i64 %427, 16
  %chain_slot201 = getelementptr i8, ptr %chain_table, i64 %428
  %429 = getelementptr i8, ptr %chain_slot201, i64 0
  %slot_pc202 = load i32, ptr %429, align 4
  %430 = icmp eq i32 %slot_pc202, %next_pc193
  br i1 %430, label %chain_hit203, label %chain_leave197, !prof !0

chain_leave197:                                   ; preds = %chain_lookup, %chain_exit
  %431 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %431, align 4
  %432 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail194, ptr %432, align 4
  %433 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail195, ptr %433, align 4
  %434 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail196, ptr %434, align 1
  br label %return

chain_hit203:                                     ; preds = %chain_lookup
  %435 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc193, ptr %435, align 4
  %436 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total199, ptr %436, align 4
  %437 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %437, align 1
  %438 = getelementptr i8, ptr %chain_slot201, i64 8
  %chain_fn204 = load ptr, ptr %438, align 8
  musttail call swifttailcc void %chain_fn204(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave197, %chain_leave176, %chain_leave169, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
