
build-native-instruction-analysis/capture/bcore-default-stream/pc-65682-0-132432577724608.bin:     file format binary


Disassembly of section .data:

000078725cc080c0 <.data>:
    78725cc080c0:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    78725cc080c7:	4c 89 74 24 70       	mov    QWORD PTR [rsp+0x70],r14
    78725cc080cc:	4c 89 6c 24 78       	mov    QWORD PTR [rsp+0x78],r13
    78725cc080d1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc080d8:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc080df:	00 
    78725cc080e0:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc080e7:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    78725cc080ee:	00 
    78725cc080ef:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc080f6:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    78725cc080fd:	00 
    78725cc080fe:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    78725cc08103:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc08109:	83 fa 00             	cmp    edx,0x0
    78725cc0810c:	0f 94 c0             	sete   al
    78725cc0810f:	81 ea 92 00 01 00    	sub    edx,0x10092
    78725cc08115:	83 fa 06             	cmp    edx,0x6
    78725cc08118:	0f 97 c2             	seta   dl
    78725cc0811b:	08 d0                	or     al,dl
    78725cc0811d:	24 01                	and    al,0x1
    78725cc0811f:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc08125:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc0812b:	0f 94 c1             	sete   cl
    78725cc0812e:	81 ea 92 00 01 00    	sub    edx,0x10092
    78725cc08134:	83 fa 06             	cmp    edx,0x6
    78725cc08137:	0f 97 c2             	seta   dl
    78725cc0813a:	08 d1                	or     cl,dl
    78725cc0813c:	20 c8                	and    al,cl
    78725cc0813e:	a8 01                	test   al,0x1
    78725cc08140:	75 05                	jne    0x78725cc08147
    78725cc08142:	e9 4f 03 00 00       	jmp    0x78725cc08496
    78725cc08147:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc0814c:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc08153:	48 89 c8             	mov    rax,rcx
    78725cc08156:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0815c:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc08161:	8b 81 1c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10001c]
    78725cc08167:	83 c0 01             	add    eax,0x1
    78725cc0816a:	89 81 1c 00 10 00    	mov    DWORD PTR [rcx+0x10001c],eax
    78725cc08170:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc08175:	75 40                	jne    0x78725cc081b7
    78725cc08177:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc0817c:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc08182:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc08186:	89 c2                	mov    edx,eax
    78725cc08188:	83 c2 01             	add    edx,0x1
    78725cc0818b:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc08191:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc08196:	73 1d                	jae    0x78725cc081b5
    78725cc08198:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0819d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc081a1:	89 c9                	mov    ecx,ecx
    78725cc081a3:	48 c1 e1 02          	shl    rcx,0x2
    78725cc081a7:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc081ae:	c7 04 08 07 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x7
    78725cc081b5:	eb 00                	jmp    0x78725cc081b7
    78725cc081b7:	eb 00                	jmp    0x78725cc081b9
    78725cc081b9:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc081be:	8b 38                	mov    edi,DWORD PTR [rax]
    78725cc081c0:	89 fa                	mov    edx,edi
    78725cc081c2:	83 ea 00             	sub    edx,0x0
    78725cc081c5:	83 fa 00             	cmp    edx,0x0
    78725cc081c8:	0f 94 c1             	sete   cl
    78725cc081cb:	80 e1 01             	and    cl,0x1
    78725cc081ce:	0f b6 f1             	movzx  esi,cl
    78725cc081d1:	89 74 24 58          	mov    DWORD PTR [rsp+0x58],esi
    78725cc081d5:	c1 ea 1f             	shr    edx,0x1f
    78725cc081d8:	89 f9                	mov    ecx,edi
    78725cc081da:	c1 e9 1f             	shr    ecx,0x1f
    78725cc081dd:	89 d3                	mov    ebx,edx
    78725cc081df:	31 cb                	xor    ebx,ecx
    78725cc081e1:	83 f1 00             	xor    ecx,0x0
    78725cc081e4:	21 d9                	and    ecx,ebx
    78725cc081e6:	31 ca                	xor    edx,ecx
    78725cc081e8:	31 c9                	xor    ecx,ecx
    78725cc081ea:	39 f9                	cmp    ecx,edi
    78725cc081ec:	0f 96 c1             	setbe  cl
    78725cc081ef:	80 e1 01             	and    cl,0x1
    78725cc081f2:	0f b6 c9             	movzx  ecx,cl
    78725cc081f5:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc081fb:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc08201:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc08207:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0820d:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc08213:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    78725cc08219:	89 4c 24 5c          	mov    DWORD PTR [rsp+0x5c],ecx
    78725cc0821d:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    78725cc08223:	89 44 24 60          	mov    DWORD PTR [rsp+0x60],eax
    78725cc08227:	eb 00                	jmp    0x78725cc08229
    78725cc08229:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    78725cc0822d:	83 f8 00             	cmp    eax,0x0
    78725cc08230:	75 2d                	jne    0x78725cc0825f
    78725cc08232:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    78725cc08237:	c7 81 bc 00 00 00 c0 	mov    DWORD PTR [rcx+0xbc],0x100c0
    78725cc0823e:	00 01 00 
    78725cc08241:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc08247:	83 c0 02             	add    eax,0x2
    78725cc0824a:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0824e:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc08254:	0f 82 4d 02 00 00    	jb     0x78725cc084a7
    78725cc0825a:	e9 6b 02 00 00       	jmp    0x78725cc084ca
    78725cc0825f:	eb 00                	jmp    0x78725cc08261
    78725cc08261:	eb 00                	jmp    0x78725cc08263
    78725cc08263:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    78725cc08268:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    78725cc0826b:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0826f:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    78725cc08272:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc08276:	83 e0 03             	and    eax,0x3
    78725cc08279:	83 f8 00             	cmp    eax,0x0
    78725cc0827c:	74 69                	je     0x78725cc082e7
    78725cc0827e:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    78725cc08283:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc08287:	48 8b 74 24 70       	mov    rsi,QWORD PTR [rsp+0x70]
    78725cc0828c:	c7 87 bc 00 00 00 96 	mov    DWORD PTR [rdi+0xbc],0x10096
    78725cc08293:	00 01 00 
    78725cc08296:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0829d:	00 00 00 
    78725cc082a0:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc082a7:	00 00 00 
    78725cc082aa:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc082b1:	60 00 00 
    78725cc082b4:	ba 96 00 01 00       	mov    edx,0x10096
    78725cc082b9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc082bf:	ff d0                	call   rax
    78725cc082c1:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc082c6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc082cc:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc082d1:	b8 02 00 00 00       	mov    eax,0x2
    78725cc082d6:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    78725cc082da:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    78725cc082de:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    78725cc082e2:	e9 c8 02 00 00       	jmp    0x78725cc085af
    78725cc082e7:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    78725cc082ee:	00 
    78725cc082ef:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc082f3:	c1 e9 0c             	shr    ecx,0xc
    78725cc082f6:	89 c9                	mov    ecx,ecx
    78725cc082f8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc082fc:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc08301:	48 83 f8 00          	cmp    rax,0x0
    78725cc08305:	74 1a                	je     0x78725cc08321
    78725cc08307:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0830c:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    78725cc08310:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc08314:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0831a:	89 c9                	mov    ecx,ecx
    78725cc0831c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0831f:	eb 4c                	jmp    0x78725cc0836d
    78725cc08321:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08326:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    78725cc0832a:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc0832e:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    78725cc08333:	c7 80 bc 00 00 00 96 	mov    DWORD PTR [rax+0xbc],0x10096
    78725cc0833a:	00 01 00 
    78725cc0833d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc08344:	00 00 00 
    78725cc08347:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc0834e:	00 00 00 
    78725cc08351:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc08358:	60 00 00 
    78725cc0835b:	ff d0                	call   rax
    78725cc0835d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08362:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc08369:	75 11                	jne    0x78725cc0837c
    78725cc0836b:	eb 35                	jmp    0x78725cc083a2
    78725cc0836d:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    78725cc08374:	00 
    78725cc08375:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc08378:	75 2a                	jne    0x78725cc083a4
    78725cc0837a:	eb 67                	jmp    0x78725cc083e3
    78725cc0837c:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08381:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc08387:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc0838c:	b8 02 00 00 00       	mov    eax,0x2
    78725cc08391:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    78725cc08395:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    78725cc08399:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    78725cc0839d:	e9 0d 02 00 00       	jmp    0x78725cc085af
    78725cc083a2:	eb c9                	jmp    0x78725cc0836d
    78725cc083a4:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    78725cc083a9:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10098
    78725cc083b0:	00 01 00 
    78725cc083b3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc083ba:	00 00 00 
    78725cc083bd:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc083c4:	00 00 00 
    78725cc083c7:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc083ce:	60 00 00 
    78725cc083d1:	ff d0                	call   rax
    78725cc083d3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc083d8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc083df:	75 04                	jne    0x78725cc083e5
    78725cc083e1:	eb 28                	jmp    0x78725cc0840b
    78725cc083e3:	eb 28                	jmp    0x78725cc0840d
    78725cc083e5:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc083ea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc083f0:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc083f5:	b8 02 00 00 00       	mov    eax,0x2
    78725cc083fa:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    78725cc083fe:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    78725cc08402:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    78725cc08406:	e9 a4 01 00 00       	jmp    0x78725cc085af
    78725cc0840b:	eb d6                	jmp    0x78725cc083e3
    78725cc0840d:	eb 00                	jmp    0x78725cc0840f
    78725cc0840f:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    78725cc08414:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    78725cc08418:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    78725cc0841c:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    78725cc08422:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    78725cc08428:	83 ff 01             	cmp    edi,0x1
    78725cc0842b:	0f 97 c3             	seta   bl
    78725cc0842e:	3d 98 00 01 00       	cmp    eax,0x10098
    78725cc08433:	0f 94 c0             	sete   al
    78725cc08436:	20 c3                	and    bl,al
    78725cc08438:	b8 9c 00 01 00       	mov    eax,0x1009c
    78725cc0843d:	f6 c3 01             	test   bl,0x1
    78725cc08440:	0f 45 c2             	cmovne eax,edx
    78725cc08443:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    78725cc08449:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    78725cc0844f:	83 ff 01             	cmp    edi,0x1
    78725cc08452:	0f 97 c3             	seta   bl
    78725cc08455:	81 fe 98 00 01 00    	cmp    esi,0x10098
    78725cc0845b:	40 0f 94 c6          	sete   sil
    78725cc0845f:	40 20 f3             	and    bl,sil
    78725cc08462:	f6 c3 01             	test   bl,0x1
    78725cc08465:	0f 45 c2             	cmovne eax,edx
    78725cc08468:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    78725cc0846e:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10428
    78725cc08475:	04 01 00 
    78725cc08478:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0847e:	83 c0 04             	add    eax,0x4
    78725cc08481:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc08485:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0848b:	0f 82 9a 00 00 00    	jb     0x78725cc0852b
    78725cc08491:	e9 b8 00 00 00       	jmp    0x78725cc0854e
    78725cc08496:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc0849b:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc084a2:	e9 b0 01 00 00       	jmp    0x78725cc08657
    78725cc084a7:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc084ae:	00 
    78725cc084af:	48 89 c1             	mov    rcx,rax
    78725cc084b2:	48 81 c1 00 06 08 00 	add    rcx,0x80600
    78725cc084b9:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc084be:	81 b8 00 06 08 00 c0 	cmp    DWORD PTR [rax+0x80600],0x100c0
    78725cc084c5:	00 01 00 
    78725cc084c8:	74 2f                	je     0x78725cc084f9
    78725cc084ca:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc084cf:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x100c0
    78725cc084d6:	00 01 00 
    78725cc084d9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc084e0:	00 00 00 
    78725cc084e3:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc084ea:	00 00 00 
    78725cc084ed:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc084f4:	e9 5e 01 00 00       	jmp    0x78725cc08657
    78725cc084f9:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    78725cc084fe:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    78725cc08503:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc08508:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc0850c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    78725cc08513:	c0 00 01 00 
    78725cc08517:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0851e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc08522:	48 81 c4 98 00 00 00 	add    rsp,0x98
    78725cc08529:	ff e0                	jmp    rax
    78725cc0852b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc08532:	00 
    78725cc08533:	48 89 c1             	mov    rcx,rax
    78725cc08536:	48 81 c1 40 21 08 00 	add    rcx,0x82140
    78725cc0853d:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc08542:	81 b8 40 21 08 00 28 	cmp    DWORD PTR [rax+0x82140],0x10428
    78725cc08549:	04 01 00 
    78725cc0854c:	74 2f                	je     0x78725cc0857d
    78725cc0854e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08553:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10428
    78725cc0855a:	04 01 00 
    78725cc0855d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc08564:	00 00 00 
    78725cc08567:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc0856e:	00 00 00 
    78725cc08571:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc08578:	e9 da 00 00 00       	jmp    0x78725cc08657
    78725cc0857d:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    78725cc08582:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    78725cc08587:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc0858c:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc08590:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    78725cc08597:	28 04 01 00 
    78725cc0859b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc085a2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc085a6:	48 81 c4 98 00 00 00 	add    rsp,0x98
    78725cc085ad:	ff e0                	jmp    rax
    78725cc085af:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    78725cc085b4:	8b 54 24 40          	mov    edx,DWORD PTR [rsp+0x40]
    78725cc085b8:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    78725cc085bc:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    78725cc085c0:	89 c7                	mov    edi,eax
    78725cc085c2:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc085c6:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc085ca:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc085ce:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc085d4:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc085d8:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc085de:	73 2d                	jae    0x78725cc0860d
    78725cc085e0:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc085e7:	00 
    78725cc085e8:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc085ec:	89 d1                	mov    ecx,edx
    78725cc085ee:	c1 e9 01             	shr    ecx,0x1
    78725cc085f1:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc085f7:	89 c9                	mov    ecx,ecx
    78725cc085f9:	48 c1 e1 04          	shl    rcx,0x4
    78725cc085fd:	48 89 c6             	mov    rsi,rax
    78725cc08600:	48 01 ce             	add    rsi,rcx
    78725cc08603:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc08608:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0860b:	74 1b                	je     0x78725cc08628
    78725cc0860d:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc08612:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc08616:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc0861a:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc08620:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc08626:	eb 2f                	jmp    0x78725cc08657
    78725cc08628:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    78725cc0862d:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    78725cc08632:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc08637:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc0863b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc08642:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc08649:	00 
    78725cc0864a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0864e:	48 81 c4 98 00 00 00 	add    rsp,0x98
    78725cc08655:	ff e0                	jmp    rax
    78725cc08657:	48 81 c4 98 00 00 00 	add    rsp,0x98
    78725cc0865e:	c2 08 00             	ret    0x8
