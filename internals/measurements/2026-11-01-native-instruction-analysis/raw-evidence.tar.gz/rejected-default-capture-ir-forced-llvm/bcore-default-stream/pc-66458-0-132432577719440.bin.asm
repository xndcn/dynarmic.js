
build-native-instruction-analysis/capture/bcore-default-stream/pc-66458-0-132432577719440.bin:     file format binary


Disassembly of section .data:

000078725cc06c90 <.data>:
    78725cc06c90:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    78725cc06c97:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    78725cc06c9c:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    78725cc06ca1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc06ca8:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc06cad:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc06cb4:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc06cb9:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc06cc0:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc06cc7:	00 
    78725cc06cc8:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    78725cc06ccd:	8b 8a a0 00 00 00    	mov    ecx,DWORD PTR [rdx+0xa0]
    78725cc06cd3:	83 f9 00             	cmp    ecx,0x0
    78725cc06cd6:	0f 94 c0             	sete   al
    78725cc06cd9:	81 e9 9a 03 01 00    	sub    ecx,0x1039a
    78725cc06cdf:	83 f9 08             	cmp    ecx,0x8
    78725cc06ce2:	0f 97 c1             	seta   cl
    78725cc06ce5:	08 c8                	or     al,cl
    78725cc06ce7:	24 01                	and    al,0x1
    78725cc06ce9:	81 ba a4 00 00 00 9e 	cmp    DWORD PTR [rdx+0xa4],0x1039e
    78725cc06cf0:	03 01 00 
    78725cc06cf3:	0f 94 c1             	sete   cl
    78725cc06cf6:	81 ba 94 00 00 00 9a 	cmp    DWORD PTR [rdx+0x94],0x1039a
    78725cc06cfd:	03 01 00 
    78725cc06d00:	0f 94 c2             	sete   dl
    78725cc06d03:	20 d1                	and    cl,dl
    78725cc06d05:	20 c8                	and    al,cl
    78725cc06d07:	a8 01                	test   al,0x1
    78725cc06d09:	75 05                	jne    0x78725cc06d10
    78725cc06d0b:	e9 85 03 00 00       	jmp    0x78725cc07095
    78725cc06d10:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06d15:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc06d1c:	48 89 c8             	mov    rax,rcx
    78725cc06d1f:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc06d25:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc06d2a:	8b 81 14 00 10 00    	mov    eax,DWORD PTR [rcx+0x100014]
    78725cc06d30:	83 c0 01             	add    eax,0x1
    78725cc06d33:	89 81 14 00 10 00    	mov    DWORD PTR [rcx+0x100014],eax
    78725cc06d39:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc06d3e:	75 40                	jne    0x78725cc06d80
    78725cc06d40:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    78725cc06d45:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc06d4b:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc06d4f:	89 c2                	mov    edx,eax
    78725cc06d51:	83 c2 01             	add    edx,0x1
    78725cc06d54:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc06d5a:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc06d5f:	73 1d                	jae    0x78725cc06d7e
    78725cc06d61:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc06d66:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc06d6a:	89 c9                	mov    ecx,ecx
    78725cc06d6c:	48 c1 e1 02          	shl    rcx,0x2
    78725cc06d70:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc06d77:	c7 04 08 05 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x5
    78725cc06d7e:	eb 00                	jmp    0x78725cc06d80
    78725cc06d80:	eb 00                	jmp    0x78725cc06d82
    78725cc06d82:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06d87:	8b 48 08             	mov    ecx,DWORD PTR [rax+0x8]
    78725cc06d8a:	0f af 48 04          	imul   ecx,DWORD PTR [rax+0x4]
    78725cc06d8e:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc06d92:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    78725cc06d95:	eb 00                	jmp    0x78725cc06d97
    78725cc06d97:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06d9c:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    78725cc06da0:	8b 38                	mov    edi,DWORD PTR [rax]
    78725cc06da2:	89 ca                	mov    edx,ecx
    78725cc06da4:	01 fa                	add    edx,edi
    78725cc06da6:	89 54 24 4c          	mov    DWORD PTR [rsp+0x4c],edx
    78725cc06daa:	89 50 08             	mov    DWORD PTR [rax+0x8],edx
    78725cc06dad:	89 ce                	mov    esi,ecx
    78725cc06daf:	c1 ee 1f             	shr    esi,0x1f
    78725cc06db2:	89 fb                	mov    ebx,edi
    78725cc06db4:	c1 eb 1f             	shr    ebx,0x1f
    78725cc06db7:	89 d5                	mov    ebp,edx
    78725cc06db9:	c1 ed 1f             	shr    ebp,0x1f
    78725cc06dbc:	31 eb                	xor    ebx,ebp
    78725cc06dbe:	31 ee                	xor    esi,ebp
    78725cc06dc0:	21 de                	and    esi,ebx
    78725cc06dc2:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc06dc5:	39 f9                	cmp    ecx,edi
    78725cc06dc7:	0f 92 c1             	setb   cl
    78725cc06dca:	80 e1 01             	and    cl,0x1
    78725cc06dcd:	0f b6 c9             	movzx  ecx,cl
    78725cc06dd0:	83 fa 00             	cmp    edx,0x0
    78725cc06dd3:	0f 94 c3             	sete   bl
    78725cc06dd6:	80 e3 01             	and    bl,0x1
    78725cc06dd9:	0f b6 fb             	movzx  edi,bl
    78725cc06ddc:	c1 ea 1f             	shr    edx,0x1f
    78725cc06ddf:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    78725cc06de5:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc06deb:	89 f2                	mov    edx,esi
    78725cc06ded:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    78725cc06df3:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc06df9:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc06dff:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc06e05:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc06e0b:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc06e11:	eb 00                	jmp    0x78725cc06e13
    78725cc06e13:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06e18:	8b 40 24             	mov    eax,DWORD PTR [rax+0x24]
    78725cc06e1b:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    78725cc06e1f:	83 e0 03             	and    eax,0x3
    78725cc06e22:	83 f8 00             	cmp    eax,0x0
    78725cc06e25:	74 69                	je     0x78725cc06e90
    78725cc06e27:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc06e2c:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    78725cc06e30:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    78725cc06e35:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1039e
    78725cc06e3c:	03 01 00 
    78725cc06e3f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc06e46:	00 00 00 
    78725cc06e49:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc06e50:	00 00 00 
    78725cc06e53:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc06e5a:	60 00 00 
    78725cc06e5d:	ba 9e 03 01 00       	mov    edx,0x1039e
    78725cc06e62:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc06e68:	ff d0                	call   rax
    78725cc06e6a:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06e6f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc06e75:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc06e7a:	b8 02 00 00 00       	mov    eax,0x2
    78725cc06e7f:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc06e83:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc06e87:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc06e8b:	e9 97 02 00 00       	jmp    0x78725cc07127
    78725cc06e90:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc06e97:	00 
    78725cc06e98:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    78725cc06e9c:	c1 e9 0c             	shr    ecx,0xc
    78725cc06e9f:	89 c9                	mov    ecx,ecx
    78725cc06ea1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc06ea5:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    78725cc06eaa:	48 83 f8 00          	cmp    rax,0x0
    78725cc06eae:	74 1a                	je     0x78725cc06eca
    78725cc06eb0:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc06eb5:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    78725cc06eb9:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    78725cc06ebd:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc06ec3:	89 c9                	mov    ecx,ecx
    78725cc06ec5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc06ec8:	eb 4c                	jmp    0x78725cc06f16
    78725cc06eca:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06ecf:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    78725cc06ed3:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    78725cc06ed7:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc06edc:	c7 80 bc 00 00 00 9e 	mov    DWORD PTR [rax+0xbc],0x1039e
    78725cc06ee3:	03 01 00 
    78725cc06ee6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc06eed:	00 00 00 
    78725cc06ef0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc06ef7:	00 00 00 
    78725cc06efa:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc06f01:	60 00 00 
    78725cc06f04:	ff d0                	call   rax
    78725cc06f06:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06f0b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc06f12:	75 22                	jne    0x78725cc06f36
    78725cc06f14:	eb 46                	jmp    0x78725cc06f5c
    78725cc06f16:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06f1b:	8b 4c 24 48          	mov    ecx,DWORD PTR [rsp+0x48]
    78725cc06f1f:	83 c1 04             	add    ecx,0x4
    78725cc06f22:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc06f25:	8b 80 9c 00 00 00    	mov    eax,DWORD PTR [rax+0x9c]
    78725cc06f2b:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc06f2f:	83 f8 01             	cmp    eax,0x1
    78725cc06f32:	77 2f                	ja     0x78725cc06f63
    78725cc06f34:	eb 5c                	jmp    0x78725cc06f92
    78725cc06f36:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06f3b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc06f41:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc06f46:	b8 02 00 00 00       	mov    eax,0x2
    78725cc06f4b:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc06f4f:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc06f53:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc06f57:	e9 cb 01 00 00       	jmp    0x78725cc07127
    78725cc06f5c:	eb b8                	jmp    0x78725cc06f16
    78725cc06f5e:	e9 fd 00 00 00       	jmp    0x78725cc07060
    78725cc06f63:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc06f68:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc06f6d:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    78725cc06f71:	83 ea 01             	sub    edx,0x1
    78725cc06f74:	89 91 9c 00 00 00    	mov    DWORD PTR [rcx+0x9c],edx
    78725cc06f7a:	c7 81 bc 00 00 00 9a 	mov    DWORD PTR [rcx+0xbc],0x1039a
    78725cc06f81:	03 01 00 
    78725cc06f84:	c6 81 28 01 00 00 01 	mov    BYTE PTR [rcx+0x128],0x1
    78725cc06f8b:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc06f8e:	75 1d                	jne    0x78725cc06fad
    78725cc06f90:	eb 40                	jmp    0x78725cc06fd2
    78725cc06f92:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc06f97:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc06f9c:	c7 81 9c 00 00 00 00 	mov    DWORD PTR [rcx+0x9c],0x0
    78725cc06fa3:	00 00 00 
    78725cc06fa6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc06fa9:	75 4d                	jne    0x78725cc06ff8
    78725cc06fab:	eb 7a                	jmp    0x78725cc07027
    78725cc06fad:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc06fb2:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc06fb9:	00 00 00 
    78725cc06fbc:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc06fc3:	00 00 00 
    78725cc06fc6:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc06fcd:	60 00 00 
    78725cc06fd0:	ff d0                	call   rax
    78725cc06fd2:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc06fd7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc06fdd:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc06fe2:	b8 02 00 00 00       	mov    eax,0x2
    78725cc06fe7:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc06feb:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc06fef:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc06ff3:	e9 2f 01 00 00       	jmp    0x78725cc07127
    78725cc06ff8:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc06ffd:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x103a0
    78725cc07004:	03 01 00 
    78725cc07007:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0700e:	00 00 00 
    78725cc07011:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc07018:	00 00 00 
    78725cc0701b:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc07022:	60 00 00 
    78725cc07025:	ff d0                	call   rax
    78725cc07027:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0702c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc07033:	74 26                	je     0x78725cc0705b
    78725cc07035:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0703a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc07040:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc07045:	b8 02 00 00 00       	mov    eax,0x2
    78725cc0704a:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc0704e:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc07052:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc07056:	e9 cc 00 00 00       	jmp    0x78725cc07127
    78725cc0705b:	e9 fe fe ff ff       	jmp    0x78725cc06f5e
    78725cc07060:	eb 00                	jmp    0x78725cc07062
    78725cc07062:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc07067:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    78725cc0706d:	eb 00                	jmp    0x78725cc0706f
    78725cc0706f:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc07074:	c7 81 bc 00 00 00 68 	mov    DWORD PTR [rcx+0xbc],0x10368
    78725cc0707b:	03 01 00 
    78725cc0707e:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc07084:	83 c0 05             	add    eax,0x5
    78725cc07087:	89 44 24 28          	mov    DWORD PTR [rsp+0x28],eax
    78725cc0708b:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc07091:	72 13                	jb     0x78725cc070a6
    78725cc07093:	eb 31                	jmp    0x78725cc070c6
    78725cc07095:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0709a:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc070a1:	e9 4e 01 00 00       	jmp    0x78725cc071f4
    78725cc070a6:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc070ab:	48 89 c1             	mov    rcx,rax
    78725cc070ae:	48 81 c1 40 1b 08 00 	add    rcx,0x81b40
    78725cc070b5:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc070ba:	81 b8 40 1b 08 00 68 	cmp    DWORD PTR [rax+0x81b40],0x10368
    78725cc070c1:	03 01 00 
    78725cc070c4:	74 2f                	je     0x78725cc070f5
    78725cc070c6:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc070cb:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    78725cc070d2:	03 01 00 
    78725cc070d5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc070dc:	00 00 00 
    78725cc070df:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    78725cc070e6:	00 00 00 
    78725cc070e9:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc070f0:	e9 ff 00 00 00       	jmp    0x78725cc071f4
    78725cc070f5:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    78725cc070fa:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    78725cc070ff:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc07104:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    78725cc07108:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10368
    78725cc0710f:	68 03 01 00 
    78725cc07113:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0711a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0711e:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc07125:	ff e0                	jmp    rax
    78725cc07127:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc0712c:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    78725cc07130:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    78725cc07134:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc07138:	89 c7                	mov    edi,eax
    78725cc0713a:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc0713e:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc07142:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc07146:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0714c:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc07150:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc07156:	73 0d                	jae    0x78725cc07165
    78725cc07158:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    78725cc0715c:	3d 9a 03 01 00       	cmp    eax,0x1039a
    78725cc07161:	74 1d                	je     0x78725cc07180
    78725cc07163:	eb 36                	jmp    0x78725cc0719b
    78725cc07165:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0716a:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc0716e:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc07172:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc07178:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc0717e:	eb 74                	jmp    0x78725cc071f4
    78725cc07180:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc07185:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc07189:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    78725cc0718f:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    78725cc07196:	e9 75 fb ff ff       	jmp    0x78725cc06d10
    78725cc0719b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc071a0:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc071a4:	89 d1                	mov    ecx,edx
    78725cc071a6:	c1 e9 01             	shr    ecx,0x1
    78725cc071a9:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc071af:	89 c9                	mov    ecx,ecx
    78725cc071b1:	48 c1 e1 04          	shl    rcx,0x4
    78725cc071b5:	48 89 c6             	mov    rsi,rax
    78725cc071b8:	48 01 ce             	add    rsi,rcx
    78725cc071bb:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc071c0:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc071c3:	75 a0                	jne    0x78725cc07165
    78725cc071c5:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    78725cc071ca:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    78725cc071cf:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc071d4:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc071d8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc071df:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc071e6:	00 
    78725cc071e7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc071eb:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc071f2:	ff e0                	jmp    rax
    78725cc071f4:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc071fb:	c2 08 00             	ret    0x8
