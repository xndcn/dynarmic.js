
build-native-instruction-analysis/capture/bcore-default-stream/pc-65952-0-132432577732912.bin:     file format binary


Disassembly of section .data:

000078725cc0a130 <.data>:
    78725cc0a130:	48 81 ec 78 01 00 00 	sub    rsp,0x178
    78725cc0a137:	4c 89 b4 24 50 01 00 	mov    QWORD PTR [rsp+0x150],r14
    78725cc0a13e:	00 
    78725cc0a13f:	4c 89 ac 24 58 01 00 	mov    QWORD PTR [rsp+0x158],r13
    78725cc0a146:	00 
    78725cc0a147:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0a14e:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    78725cc0a155:	00 
    78725cc0a156:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0a15d:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    78725cc0a164:	00 
    78725cc0a165:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0a16c:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
    78725cc0a173:	00 
    78725cc0a174:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a17b:	00 
    78725cc0a17c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc0a182:	83 fa 00             	cmp    edx,0x0
    78725cc0a185:	0f 94 c0             	sete   al
    78725cc0a188:	81 ea a0 01 01 00    	sub    edx,0x101a0
    78725cc0a18e:	83 fa 4e             	cmp    edx,0x4e
    78725cc0a191:	0f 97 c2             	seta   dl
    78725cc0a194:	08 d0                	or     al,dl
    78725cc0a196:	24 01                	and    al,0x1
    78725cc0a198:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0a19e:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc0a1a4:	0f 94 c1             	sete   cl
    78725cc0a1a7:	81 ea a0 01 01 00    	sub    edx,0x101a0
    78725cc0a1ad:	83 fa 4e             	cmp    edx,0x4e
    78725cc0a1b0:	0f 97 c2             	seta   dl
    78725cc0a1b3:	08 d1                	or     cl,dl
    78725cc0a1b5:	20 c8                	and    al,cl
    78725cc0a1b7:	a8 01                	test   al,0x1
    78725cc0a1b9:	75 05                	jne    0x78725cc0a1c0
    78725cc0a1bb:	e9 8e 18 00 00       	jmp    0x78725cc0ba4e
    78725cc0a1c0:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a1c7:	00 
    78725cc0a1c8:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc0a1cf:	48 89 c8             	mov    rax,rcx
    78725cc0a1d2:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0a1d8:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
    78725cc0a1df:	00 
    78725cc0a1e0:	8b 81 2c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10002c]
    78725cc0a1e6:	83 c0 01             	add    eax,0x1
    78725cc0a1e9:	89 81 2c 00 10 00    	mov    DWORD PTR [rcx+0x10002c],eax
    78725cc0a1ef:	3d b3 f1 00 00       	cmp    eax,0xf1b3
    78725cc0a1f4:	75 4c                	jne    0x78725cc0a242
    78725cc0a1f6:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    78725cc0a1fd:	00 
    78725cc0a1fe:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc0a204:	89 84 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],eax
    78725cc0a20b:	89 c2                	mov    edx,eax
    78725cc0a20d:	83 c2 01             	add    edx,0x1
    78725cc0a210:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc0a216:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0a21b:	73 23                	jae    0x78725cc0a240
    78725cc0a21d:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    78725cc0a224:	00 
    78725cc0a225:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    78725cc0a22c:	89 c9                	mov    ecx,ecx
    78725cc0a22e:	48 c1 e1 02          	shl    rcx,0x2
    78725cc0a232:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc0a239:	c7 04 08 0b 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xb
    78725cc0a240:	eb 00                	jmp    0x78725cc0a242
    78725cc0a242:	eb 00                	jmp    0x78725cc0a244
    78725cc0a244:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a24b:	00 
    78725cc0a24c:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    78725cc0a24f:	83 e8 04             	sub    eax,0x4
    78725cc0a252:	89 84 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],eax
    78725cc0a259:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    78725cc0a25c:	89 8c 24 40 01 00 00 	mov    DWORD PTR [rsp+0x140],ecx
    78725cc0a263:	83 e0 03             	and    eax,0x3
    78725cc0a266:	83 f8 00             	cmp    eax,0x0
    78725cc0a269:	0f 84 8e 00 00 00    	je     0x78725cc0a2fd
    78725cc0a26f:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0a276:	00 
    78725cc0a277:	8b 8c 24 3c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x13c]
    78725cc0a27e:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0a285:	00 
    78725cc0a286:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0a28d:	00 00 00 
    78725cc0a290:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0a297:	00 00 00 
    78725cc0a29a:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0a2a1:	60 00 00 
    78725cc0a2a4:	ba a0 01 01 00       	mov    edx,0x101a0
    78725cc0a2a9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0a2af:	ff d0                	call   rax
    78725cc0a2b1:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a2b8:	00 
    78725cc0a2b9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a2bf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a2c5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a2cb:	be 01 00 00 00       	mov    esi,0x1
    78725cc0a2d0:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0a2d5:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a2dc:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a2e3:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a2ea:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a2f1:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a2f8:	e9 85 18 00 00       	jmp    0x78725cc0bb82
    78725cc0a2fd:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0a304:	00 
    78725cc0a305:	8b 8c 24 3c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x13c]
    78725cc0a30c:	c1 e9 0c             	shr    ecx,0xc
    78725cc0a30f:	89 c9                	mov    ecx,ecx
    78725cc0a311:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0a315:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    78725cc0a31c:	00 
    78725cc0a31d:	48 83 f8 00          	cmp    rax,0x0
    78725cc0a321:	74 23                	je     0x78725cc0a346
    78725cc0a323:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc0a32a:	00 
    78725cc0a32b:	8b 94 24 40 01 00 00 	mov    edx,DWORD PTR [rsp+0x140]
    78725cc0a332:	8b 8c 24 3c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x13c]
    78725cc0a339:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0a33f:	89 c9                	mov    ecx,ecx
    78725cc0a341:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0a344:	eb 51                	jmp    0x78725cc0a397
    78725cc0a346:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a34d:	00 
    78725cc0a34e:	8b 94 24 40 01 00 00 	mov    edx,DWORD PTR [rsp+0x140]
    78725cc0a355:	8b b4 24 3c 01 00 00 	mov    esi,DWORD PTR [rsp+0x13c]
    78725cc0a35c:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0a363:	00 
    78725cc0a364:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0a36b:	00 00 00 
    78725cc0a36e:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc0a375:	00 00 00 
    78725cc0a378:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0a37f:	60 00 00 
    78725cc0a382:	ff d0                	call   rax
    78725cc0a384:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a38b:	00 
    78725cc0a38c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0a393:	75 26                	jne    0x78725cc0a3bb
    78725cc0a395:	eb 70                	jmp    0x78725cc0a407
    78725cc0a397:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    78725cc0a39e:	00 
    78725cc0a39f:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a3a6:	00 
    78725cc0a3a7:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    78725cc0a3ae:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc0a3b1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0a3b4:	75 53                	jne    0x78725cc0a409
    78725cc0a3b6:	e9 93 00 00 00       	jmp    0x78725cc0a44e
    78725cc0a3bb:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a3c2:	00 
    78725cc0a3c3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a3c9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a3cf:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a3d5:	be 01 00 00 00       	mov    esi,0x1
    78725cc0a3da:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0a3df:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a3e6:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a3ed:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a3f4:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a3fb:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a402:	e9 7b 17 00 00       	jmp    0x78725cc0bb82
    78725cc0a407:	eb 8e                	jmp    0x78725cc0a397
    78725cc0a409:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0a410:	00 
    78725cc0a411:	c7 87 bc 00 00 00 a2 	mov    DWORD PTR [rdi+0xbc],0x101a2
    78725cc0a418:	01 01 00 
    78725cc0a41b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0a422:	00 00 00 
    78725cc0a425:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc0a42c:	00 00 00 
    78725cc0a42f:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0a436:	60 00 00 
    78725cc0a439:	ff d0                	call   rax
    78725cc0a43b:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a442:	00 
    78725cc0a443:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0a44a:	75 04                	jne    0x78725cc0a450
    78725cc0a44c:	eb 4e                	jmp    0x78725cc0a49c
    78725cc0a44e:	eb 4e                	jmp    0x78725cc0a49e
    78725cc0a450:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a457:	00 
    78725cc0a458:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a45e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a464:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a46a:	be 01 00 00 00       	mov    esi,0x1
    78725cc0a46f:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0a474:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a47b:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a482:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a489:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a490:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a497:	e9 e6 16 00 00       	jmp    0x78725cc0bb82
    78725cc0a49c:	eb b0                	jmp    0x78725cc0a44e
    78725cc0a49e:	eb 00                	jmp    0x78725cc0a4a0
    78725cc0a4a0:	8b 84 24 3c 01 00 00 	mov    eax,DWORD PTR [rsp+0x13c]
    78725cc0a4a7:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a4ae:	00 
    78725cc0a4af:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    78725cc0a4b5:	89 94 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],edx
    78725cc0a4bc:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    78725cc0a4bf:	89 8c 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],ecx
    78725cc0a4c6:	83 e8 04             	sub    eax,0x4
    78725cc0a4c9:	89 84 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],eax
    78725cc0a4d0:	83 e0 03             	and    eax,0x3
    78725cc0a4d3:	83 f8 00             	cmp    eax,0x0
    78725cc0a4d6:	0f 84 98 00 00 00    	je     0x78725cc0a574
    78725cc0a4dc:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0a4e3:	00 
    78725cc0a4e4:	8b 8c 24 1c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x11c]
    78725cc0a4eb:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0a4f2:	00 
    78725cc0a4f3:	c7 87 bc 00 00 00 a2 	mov    DWORD PTR [rdi+0xbc],0x101a2
    78725cc0a4fa:	01 01 00 
    78725cc0a4fd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0a504:	00 00 00 
    78725cc0a507:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc0a50e:	00 00 00 
    78725cc0a511:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0a518:	60 00 00 
    78725cc0a51b:	ba a2 01 01 00       	mov    edx,0x101a2
    78725cc0a520:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0a526:	ff d0                	call   rax
    78725cc0a528:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a52f:	00 
    78725cc0a530:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a536:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a53c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a542:	be 02 00 00 00       	mov    esi,0x2
    78725cc0a547:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0a54c:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a553:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a55a:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a561:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a568:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a56f:	e9 0e 16 00 00       	jmp    0x78725cc0bb82
    78725cc0a574:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0a57b:	00 
    78725cc0a57c:	8b 8c 24 1c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x11c]
    78725cc0a583:	c1 e9 0c             	shr    ecx,0xc
    78725cc0a586:	89 c9                	mov    ecx,ecx
    78725cc0a588:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0a58c:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    78725cc0a593:	00 
    78725cc0a594:	48 83 f8 00          	cmp    rax,0x0
    78725cc0a598:	74 23                	je     0x78725cc0a5bd
    78725cc0a59a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0a5a1:	00 
    78725cc0a5a2:	8b 94 24 14 01 00 00 	mov    edx,DWORD PTR [rsp+0x114]
    78725cc0a5a9:	8b 8c 24 1c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x11c]
    78725cc0a5b0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0a5b6:	89 c9                	mov    ecx,ecx
    78725cc0a5b8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0a5bb:	eb 5b                	jmp    0x78725cc0a618
    78725cc0a5bd:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a5c4:	00 
    78725cc0a5c5:	8b 94 24 14 01 00 00 	mov    edx,DWORD PTR [rsp+0x114]
    78725cc0a5cc:	8b b4 24 1c 01 00 00 	mov    esi,DWORD PTR [rsp+0x11c]
    78725cc0a5d3:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0a5da:	00 
    78725cc0a5db:	c7 80 bc 00 00 00 a2 	mov    DWORD PTR [rax+0xbc],0x101a2
    78725cc0a5e2:	01 01 00 
    78725cc0a5e5:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0a5ec:	00 00 00 
    78725cc0a5ef:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc0a5f6:	00 00 00 
    78725cc0a5f9:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0a600:	60 00 00 
    78725cc0a603:	ff d0                	call   rax
    78725cc0a605:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a60c:	00 
    78725cc0a60d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0a614:	75 20                	jne    0x78725cc0a636
    78725cc0a616:	eb 6a                	jmp    0x78725cc0a682
    78725cc0a618:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    78725cc0a61f:	83 e8 04             	sub    eax,0x4
    78725cc0a622:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    78725cc0a629:	83 e0 03             	and    eax,0x3
    78725cc0a62c:	83 f8 00             	cmp    eax,0x0
    78725cc0a62f:	75 53                	jne    0x78725cc0a684
    78725cc0a631:	e9 e6 00 00 00       	jmp    0x78725cc0a71c
    78725cc0a636:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a63d:	00 
    78725cc0a63e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a644:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a64a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a650:	be 02 00 00 00       	mov    esi,0x2
    78725cc0a655:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0a65a:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a661:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a668:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a66f:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a676:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a67d:	e9 00 15 00 00       	jmp    0x78725cc0bb82
    78725cc0a682:	eb 94                	jmp    0x78725cc0a618
    78725cc0a684:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0a68b:	00 
    78725cc0a68c:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0a693:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0a69a:	00 
    78725cc0a69b:	c7 87 bc 00 00 00 a2 	mov    DWORD PTR [rdi+0xbc],0x101a2
    78725cc0a6a2:	01 01 00 
    78725cc0a6a5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0a6ac:	00 00 00 
    78725cc0a6af:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc0a6b6:	00 00 00 
    78725cc0a6b9:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0a6c0:	60 00 00 
    78725cc0a6c3:	ba a2 01 01 00       	mov    edx,0x101a2
    78725cc0a6c8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0a6ce:	ff d0                	call   rax
    78725cc0a6d0:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a6d7:	00 
    78725cc0a6d8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a6de:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a6e4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a6ea:	be 02 00 00 00       	mov    esi,0x2
    78725cc0a6ef:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0a6f4:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a6fb:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a702:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a709:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a710:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a717:	e9 66 14 00 00       	jmp    0x78725cc0bb82
    78725cc0a71c:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0a723:	00 
    78725cc0a724:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0a72b:	c1 e9 0c             	shr    ecx,0xc
    78725cc0a72e:	89 c9                	mov    ecx,ecx
    78725cc0a730:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0a734:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    78725cc0a73b:	00 
    78725cc0a73c:	48 83 f8 00          	cmp    rax,0x0
    78725cc0a740:	74 23                	je     0x78725cc0a765
    78725cc0a742:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    78725cc0a749:	00 
    78725cc0a74a:	8b 94 24 18 01 00 00 	mov    edx,DWORD PTR [rsp+0x118]
    78725cc0a751:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0a758:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0a75e:	89 c9                	mov    ecx,ecx
    78725cc0a760:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0a763:	eb 5b                	jmp    0x78725cc0a7c0
    78725cc0a765:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a76c:	00 
    78725cc0a76d:	8b 94 24 18 01 00 00 	mov    edx,DWORD PTR [rsp+0x118]
    78725cc0a774:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    78725cc0a77b:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0a782:	00 
    78725cc0a783:	c7 80 bc 00 00 00 a2 	mov    DWORD PTR [rax+0xbc],0x101a2
    78725cc0a78a:	01 01 00 
    78725cc0a78d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0a794:	00 00 00 
    78725cc0a797:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc0a79e:	00 00 00 
    78725cc0a7a1:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0a7a8:	60 00 00 
    78725cc0a7ab:	ff d0                	call   rax
    78725cc0a7ad:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a7b4:	00 
    78725cc0a7b5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0a7bc:	75 2c                	jne    0x78725cc0a7ea
    78725cc0a7be:	eb 76                	jmp    0x78725cc0a836
    78725cc0a7c0:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    78725cc0a7c7:	00 
    78725cc0a7c8:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a7cf:	00 
    78725cc0a7d0:	8b 94 24 04 01 00 00 	mov    edx,DWORD PTR [rsp+0x104]
    78725cc0a7d7:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    78725cc0a7da:	83 ea 00             	sub    edx,0x0
    78725cc0a7dd:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc0a7e0:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0a7e3:	75 53                	jne    0x78725cc0a838
    78725cc0a7e5:	e9 93 00 00 00       	jmp    0x78725cc0a87d
    78725cc0a7ea:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a7f1:	00 
    78725cc0a7f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a7f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a7fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a804:	be 02 00 00 00       	mov    esi,0x2
    78725cc0a809:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0a80e:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a815:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a81c:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a823:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a82a:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a831:	e9 4c 13 00 00       	jmp    0x78725cc0bb82
    78725cc0a836:	eb 88                	jmp    0x78725cc0a7c0
    78725cc0a838:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0a83f:	00 
    78725cc0a840:	c7 87 bc 00 00 00 a6 	mov    DWORD PTR [rdi+0xbc],0x101a6
    78725cc0a847:	01 01 00 
    78725cc0a84a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0a851:	00 00 00 
    78725cc0a854:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc0a85b:	00 00 00 
    78725cc0a85e:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0a865:	60 00 00 
    78725cc0a868:	ff d0                	call   rax
    78725cc0a86a:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a871:	00 
    78725cc0a872:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0a879:	75 04                	jne    0x78725cc0a87f
    78725cc0a87b:	eb 4e                	jmp    0x78725cc0a8cb
    78725cc0a87d:	eb 4e                	jmp    0x78725cc0a8cd
    78725cc0a87f:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a886:	00 
    78725cc0a887:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0a88d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0a893:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0a899:	be 02 00 00 00       	mov    esi,0x2
    78725cc0a89e:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0a8a3:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0a8aa:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0a8b1:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0a8b8:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0a8bf:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0a8c6:	e9 b7 12 00 00       	jmp    0x78725cc0bb82
    78725cc0a8cb:	eb b0                	jmp    0x78725cc0a87d
    78725cc0a8cd:	eb 00                	jmp    0x78725cc0a8cf
    78725cc0a8cf:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a8d6:	00 
    78725cc0a8d7:	8b 38                	mov    edi,DWORD PTR [rax]
    78725cc0a8d9:	89 bc 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],edi
    78725cc0a8e0:	89 fa                	mov    edx,edi
    78725cc0a8e2:	83 ea 00             	sub    edx,0x0
    78725cc0a8e5:	83 fa 00             	cmp    edx,0x0
    78725cc0a8e8:	0f 94 c1             	sete   cl
    78725cc0a8eb:	80 e1 01             	and    cl,0x1
    78725cc0a8ee:	0f b6 f1             	movzx  esi,cl
    78725cc0a8f1:	89 b4 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],esi
    78725cc0a8f8:	c1 ea 1f             	shr    edx,0x1f
    78725cc0a8fb:	89 f9                	mov    ecx,edi
    78725cc0a8fd:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0a900:	89 d3                	mov    ebx,edx
    78725cc0a902:	31 cb                	xor    ebx,ecx
    78725cc0a904:	83 f1 00             	xor    ecx,0x0
    78725cc0a907:	21 d9                	and    ecx,ebx
    78725cc0a909:	31 ca                	xor    edx,ecx
    78725cc0a90b:	31 c9                	xor    ecx,ecx
    78725cc0a90d:	39 f9                	cmp    ecx,edi
    78725cc0a90f:	0f 96 c1             	setbe  cl
    78725cc0a912:	80 e1 01             	and    cl,0x1
    78725cc0a915:	0f b6 c9             	movzx  ecx,cl
    78725cc0a918:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc0a91e:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc0a924:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0a92a:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0a930:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0a936:	eb 00                	jmp    0x78725cc0a938
    78725cc0a938:	8b 84 24 f4 00 00 00 	mov    eax,DWORD PTR [rsp+0xf4]
    78725cc0a93f:	83 f8 00             	cmp    eax,0x0
    78725cc0a942:	74 33                	je     0x78725cc0a977
    78725cc0a944:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0a94b:	00 
    78725cc0a94c:	c7 81 bc 00 00 00 f0 	mov    DWORD PTR [rcx+0xbc],0x101f0
    78725cc0a953:	01 01 00 
    78725cc0a956:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0a95c:	83 c0 04             	add    eax,0x4
    78725cc0a95f:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    78725cc0a966:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0a96c:	0f 82 f0 10 00 00    	jb     0x78725cc0ba62
    78725cc0a972:	e9 0e 11 00 00       	jmp    0x78725cc0ba85
    78725cc0a977:	eb 00                	jmp    0x78725cc0a979
    78725cc0a979:	eb 00                	jmp    0x78725cc0a97b
    78725cc0a97b:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a982:	00 
    78725cc0a983:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    78725cc0a986:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0a98c:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc0a992:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    78725cc0a999:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc0a99c:	eb 00                	jmp    0x78725cc0a99e
    78725cc0a99e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a9a5:	00 
    78725cc0a9a6:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    78725cc0a9a9:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    78725cc0a9b0:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc0a9b3:	eb 00                	jmp    0x78725cc0a9b5
    78725cc0a9b5:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a9bc:	00 
    78725cc0a9bd:	c7 40 08 00 00 00 00 	mov    DWORD PTR [rax+0x8],0x0
    78725cc0a9c4:	eb 00                	jmp    0x78725cc0a9c6
    78725cc0a9c6:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a9cd:	00 
    78725cc0a9ce:	8b 8c 24 e8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe8]
    78725cc0a9d5:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc0a9db:	81 c9 fc 12 00 00    	or     ecx,0x12fc
    78725cc0a9e1:	89 8c 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],ecx
    78725cc0a9e8:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc0a9eb:	eb 00                	jmp    0x78725cc0a9ed
    78725cc0a9ed:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0a9f4:	00 
    78725cc0a9f5:	c7 40 1c ff 1f 00 00 	mov    DWORD PTR [rax+0x1c],0x1fff
    78725cc0a9fc:	eb 00                	jmp    0x78725cc0a9fe
    78725cc0a9fe:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aa05:	00 
    78725cc0aa06:	c7 40 04 00 00 00 00 	mov    DWORD PTR [rax+0x4],0x0
    78725cc0aa0d:	c7 80 e4 00 00 00 01 	mov    DWORD PTR [rax+0xe4],0x1
    78725cc0aa14:	00 00 00 
    78725cc0aa17:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    78725cc0aa1e:	00 00 00 
    78725cc0aa21:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0aa28:	00 00 00 
    78725cc0aa2b:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0aa32:	00 00 00 
    78725cc0aa35:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0aa3c:	00 00 00 
    78725cc0aa3f:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0aa46:	00 00 00 
    78725cc0aa49:	eb 00                	jmp    0x78725cc0aa4b
    78725cc0aa4b:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aa52:	00 
    78725cc0aa53:	c7 40 28 00 00 00 00 	mov    DWORD PTR [rax+0x28],0x0
    78725cc0aa5a:	eb 00                	jmp    0x78725cc0aa5c
    78725cc0aa5c:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aa63:	00 
    78725cc0aa64:	8b 8c 24 e0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe0]
    78725cc0aa6b:	83 c1 00             	add    ecx,0x0
    78725cc0aa6e:	89 8c 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],ecx
    78725cc0aa75:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0aa78:	eb 00                	jmp    0x78725cc0aa7a
    78725cc0aa7a:	8b 84 24 dc 00 00 00 	mov    eax,DWORD PTR [rsp+0xdc]
    78725cc0aa81:	83 e0 03             	and    eax,0x3
    78725cc0aa84:	83 f8 00             	cmp    eax,0x0
    78725cc0aa87:	0f 84 97 00 00 00    	je     0x78725cc0ab24
    78725cc0aa8d:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0aa94:	00 
    78725cc0aa95:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0aa9c:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0aaa3:	00 
    78725cc0aaa4:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    78725cc0aaab:	01 01 00 
    78725cc0aaae:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0aab5:	00 00 00 
    78725cc0aab8:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    78725cc0aabf:	00 00 00 
    78725cc0aac2:	31 c0                	xor    eax,eax
    78725cc0aac4:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0aacb:	60 00 00 
    78725cc0aace:	ba c0 01 01 00       	mov    edx,0x101c0
    78725cc0aad3:	45 31 c0             	xor    r8d,r8d
    78725cc0aad6:	ff d0                	call   rax
    78725cc0aad8:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aadf:	00 
    78725cc0aae0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0aae6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0aaec:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0aaf2:	be 0d 00 00 00       	mov    esi,0xd
    78725cc0aaf7:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0aafc:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0ab03:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0ab0a:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0ab11:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0ab18:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0ab1f:	e9 5e 10 00 00       	jmp    0x78725cc0bb82
    78725cc0ab24:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0ab2b:	00 
    78725cc0ab2c:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0ab33:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ab36:	89 c9                	mov    ecx,ecx
    78725cc0ab38:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ab3c:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    78725cc0ab43:	00 
    78725cc0ab44:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ab48:	74 23                	je     0x78725cc0ab6d
    78725cc0ab4a:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    78725cc0ab51:	00 
    78725cc0ab52:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0ab59:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0ab5f:	89 c9                	mov    ecx,ecx
    78725cc0ab61:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0ab64:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    78725cc0ab6b:	eb 5d                	jmp    0x78725cc0abca
    78725cc0ab6d:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ab74:	00 
    78725cc0ab75:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    78725cc0ab7c:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0ab83:	00 
    78725cc0ab84:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x101c0
    78725cc0ab8b:	01 01 00 
    78725cc0ab8e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0ab95:	00 00 00 
    78725cc0ab98:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    78725cc0ab9f:	00 00 00 
    78725cc0aba2:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0aba9:	60 00 00 
    78725cc0abac:	ff d0                	call   rax
    78725cc0abae:	89 c1                	mov    ecx,eax
    78725cc0abb0:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0abb7:	00 
    78725cc0abb8:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    78725cc0abbf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0abc6:	75 1d                	jne    0x78725cc0abe5
    78725cc0abc8:	eb 67                	jmp    0x78725cc0ac31
    78725cc0abca:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0abd1:	00 
    78725cc0abd2:	8b 8c 24 cc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xcc]
    78725cc0abd9:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    78725cc0abe0:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    78725cc0abe3:	eb 5c                	jmp    0x78725cc0ac41
    78725cc0abe5:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0abec:	00 
    78725cc0abed:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0abf3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0abf9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0abff:	be 0d 00 00 00       	mov    esi,0xd
    78725cc0ac04:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ac09:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0ac10:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0ac17:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0ac1e:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0ac25:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0ac2c:	e9 51 0f 00 00       	jmp    0x78725cc0bb82
    78725cc0ac31:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    78725cc0ac38:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    78725cc0ac3f:	eb 89                	jmp    0x78725cc0abca
    78725cc0ac41:	eb 00                	jmp    0x78725cc0ac43
    78725cc0ac43:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ac4a:	00 
    78725cc0ac4b:	8b bc 24 c4 00 00 00 	mov    edi,DWORD PTR [rsp+0xc4]
    78725cc0ac52:	89 fa                	mov    edx,edi
    78725cc0ac54:	83 c2 00             	add    edx,0x0
    78725cc0ac57:	89 94 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],edx
    78725cc0ac5e:	89 50 0c             	mov    DWORD PTR [rax+0xc],edx
    78725cc0ac61:	89 f9                	mov    ecx,edi
    78725cc0ac63:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0ac66:	89 d6                	mov    esi,edx
    78725cc0ac68:	c1 ee 1f             	shr    esi,0x1f
    78725cc0ac6b:	31 f1                	xor    ecx,esi
    78725cc0ac6d:	83 f6 00             	xor    esi,0x0
    78725cc0ac70:	21 ce                	and    esi,ecx
    78725cc0ac72:	b9 ff ff ff ff       	mov    ecx,0xffffffff
    78725cc0ac77:	39 f9                	cmp    ecx,edi
    78725cc0ac79:	0f 92 c1             	setb   cl
    78725cc0ac7c:	80 e1 01             	and    cl,0x1
    78725cc0ac7f:	0f b6 c9             	movzx  ecx,cl
    78725cc0ac82:	83 fa 00             	cmp    edx,0x0
    78725cc0ac85:	0f 94 c3             	sete   bl
    78725cc0ac88:	80 e3 01             	and    bl,0x1
    78725cc0ac8b:	0f b6 fb             	movzx  edi,bl
    78725cc0ac8e:	c1 ea 1f             	shr    edx,0x1f
    78725cc0ac91:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    78725cc0ac97:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0ac9d:	89 f2                	mov    edx,esi
    78725cc0ac9f:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    78725cc0aca5:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    78725cc0acac:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0acb2:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0acb8:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0acbe:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0acc4:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0acca:	eb 00                	jmp    0x78725cc0accc
    78725cc0accc:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0acd3:	00 
    78725cc0acd4:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0acdb:	c1 e9 0b             	shr    ecx,0xb
    78725cc0acde:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    78725cc0ace5:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0ace8:	83 f9 00             	cmp    ecx,0x0
    78725cc0aceb:	0f 94 c2             	sete   dl
    78725cc0acee:	80 e2 01             	and    dl,0x1
    78725cc0acf1:	0f b6 d2             	movzx  edx,dl
    78725cc0acf4:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0acf7:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0acfd:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0ad03:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0ad0a:	00 00 00 
    78725cc0ad0d:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0ad14:	00 00 00 
    78725cc0ad17:	eb 00                	jmp    0x78725cc0ad19
    78725cc0ad19:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ad20:	00 
    78725cc0ad21:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    78725cc0ad28:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0ad2f:	31 d1                	xor    ecx,edx
    78725cc0ad31:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    78725cc0ad38:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0ad3b:	83 f9 00             	cmp    ecx,0x0
    78725cc0ad3e:	0f 94 c2             	sete   dl
    78725cc0ad41:	80 e2 01             	and    dl,0x1
    78725cc0ad44:	0f b6 d2             	movzx  edx,dl
    78725cc0ad47:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0ad4a:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0ad50:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0ad56:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0ad5d:	00 00 00 
    78725cc0ad60:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0ad67:	00 00 00 
    78725cc0ad6a:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0ad71:	00 00 00 
    78725cc0ad74:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0ad7b:	00 00 00 
    78725cc0ad7e:	eb 00                	jmp    0x78725cc0ad80
    78725cc0ad80:	8b 84 24 dc 00 00 00 	mov    eax,DWORD PTR [rsp+0xdc]
    78725cc0ad87:	83 e0 03             	and    eax,0x3
    78725cc0ad8a:	83 f8 00             	cmp    eax,0x0
    78725cc0ad8d:	0f 84 98 00 00 00    	je     0x78725cc0ae2b
    78725cc0ad93:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0ad9a:	00 
    78725cc0ad9b:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0ada2:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0ada9:	00 
    78725cc0adaa:	c7 87 bc 00 00 00 ca 	mov    DWORD PTR [rdi+0xbc],0x101ca
    78725cc0adb1:	01 01 00 
    78725cc0adb4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0adbb:	00 00 00 
    78725cc0adbe:	c7 87 34 01 00 00 11 	mov    DWORD PTR [rdi+0x134],0x11
    78725cc0adc5:	00 00 00 
    78725cc0adc8:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0adcf:	60 00 00 
    78725cc0add2:	ba ca 01 01 00       	mov    edx,0x101ca
    78725cc0add7:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0addd:	ff d0                	call   rax
    78725cc0addf:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ade6:	00 
    78725cc0ade7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0aded:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0adf3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0adf9:	be 11 00 00 00       	mov    esi,0x11
    78725cc0adfe:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ae03:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0ae0a:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0ae11:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0ae18:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0ae1f:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0ae26:	e9 57 0d 00 00       	jmp    0x78725cc0bb82
    78725cc0ae2b:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0ae32:	00 
    78725cc0ae33:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0ae3a:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ae3d:	89 c9                	mov    ecx,ecx
    78725cc0ae3f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ae43:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    78725cc0ae4a:	00 
    78725cc0ae4b:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ae4f:	74 23                	je     0x78725cc0ae74
    78725cc0ae51:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    78725cc0ae58:	00 
    78725cc0ae59:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc0ae60:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc0ae67:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0ae6d:	89 c9                	mov    ecx,ecx
    78725cc0ae6f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0ae72:	eb 5b                	jmp    0x78725cc0aecf
    78725cc0ae74:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ae7b:	00 
    78725cc0ae7c:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc0ae83:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    78725cc0ae8a:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0ae91:	00 
    78725cc0ae92:	c7 80 bc 00 00 00 ca 	mov    DWORD PTR [rax+0xbc],0x101ca
    78725cc0ae99:	01 01 00 
    78725cc0ae9c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0aea3:	00 00 00 
    78725cc0aea6:	c7 80 34 01 00 00 11 	mov    DWORD PTR [rax+0x134],0x11
    78725cc0aead:	00 00 00 
    78725cc0aeb0:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0aeb7:	60 00 00 
    78725cc0aeba:	ff d0                	call   rax
    78725cc0aebc:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aec3:	00 
    78725cc0aec4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0aecb:	75 14                	jne    0x78725cc0aee1
    78725cc0aecd:	eb 5e                	jmp    0x78725cc0af2d
    78725cc0aecf:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    78725cc0aed6:	00 
    78725cc0aed7:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0aeda:	75 53                	jne    0x78725cc0af2f
    78725cc0aedc:	e9 93 00 00 00       	jmp    0x78725cc0af74
    78725cc0aee1:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0aee8:	00 
    78725cc0aee9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0aeef:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0aef5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0aefb:	be 11 00 00 00       	mov    esi,0x11
    78725cc0af00:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0af05:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0af0c:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0af13:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0af1a:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0af21:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0af28:	e9 55 0c 00 00       	jmp    0x78725cc0bb82
    78725cc0af2d:	eb a0                	jmp    0x78725cc0aecf
    78725cc0af2f:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0af36:	00 
    78725cc0af37:	c7 87 bc 00 00 00 cc 	mov    DWORD PTR [rdi+0xbc],0x101cc
    78725cc0af3e:	01 01 00 
    78725cc0af41:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0af48:	00 00 00 
    78725cc0af4b:	c7 87 34 01 00 00 11 	mov    DWORD PTR [rdi+0x134],0x11
    78725cc0af52:	00 00 00 
    78725cc0af55:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0af5c:	60 00 00 
    78725cc0af5f:	ff d0                	call   rax
    78725cc0af61:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0af68:	00 
    78725cc0af69:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0af70:	75 04                	jne    0x78725cc0af76
    78725cc0af72:	eb 4e                	jmp    0x78725cc0afc2
    78725cc0af74:	eb 4e                	jmp    0x78725cc0afc4
    78725cc0af76:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0af7d:	00 
    78725cc0af7e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0af84:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0af8a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0af90:	be 11 00 00 00       	mov    esi,0x11
    78725cc0af95:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0af9a:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0afa1:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0afa8:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0afaf:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0afb6:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0afbd:	e9 c0 0b 00 00       	jmp    0x78725cc0bb82
    78725cc0afc2:	eb b0                	jmp    0x78725cc0af74
    78725cc0afc4:	eb 00                	jmp    0x78725cc0afc6
    78725cc0afc6:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0afcd:	00 
    78725cc0afce:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    78725cc0afd5:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0afd8:	eb 00                	jmp    0x78725cc0afda
    78725cc0afda:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0afe1:	00 
    78725cc0afe2:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    78725cc0afe9:	c7 40 08 01 00 00 00 	mov    DWORD PTR [rax+0x8],0x1
    78725cc0aff0:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    78725cc0aff7:	00 00 00 
    78725cc0affa:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    78725cc0b001:	00 00 00 
    78725cc0b004:	83 c9 00             	or     ecx,0x0
    78725cc0b007:	89 8c 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],ecx
    78725cc0b00e:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0b015:	00 00 00 
    78725cc0b018:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0b01f:	00 00 00 
    78725cc0b022:	89 88 00 01 00 00    	mov    DWORD PTR [rax+0x100],ecx
    78725cc0b028:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0b02f:	00 00 00 
    78725cc0b032:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0b039:	00 00 00 
    78725cc0b03c:	eb 00                	jmp    0x78725cc0b03e
    78725cc0b03e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b045:	00 
    78725cc0b046:	8b bc 24 f0 00 00 00 	mov    edi,DWORD PTR [rsp+0xf0]
    78725cc0b04d:	83 ff 01             	cmp    edi,0x1
    78725cc0b050:	0f 96 c1             	setbe  cl
    78725cc0b053:	80 e1 01             	and    cl,0x1
    78725cc0b056:	0f b6 c9             	movzx  ecx,cl
    78725cc0b059:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    78725cc0b060:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    78725cc0b066:	83 ff 01             	cmp    edi,0x1
    78725cc0b069:	0f 94 c1             	sete   cl
    78725cc0b06c:	80 e1 01             	and    cl,0x1
    78725cc0b06f:	0f b6 f1             	movzx  esi,cl
    78725cc0b072:	b9 01 00 00 00       	mov    ecx,0x1
    78725cc0b077:	39 f9                	cmp    ecx,edi
    78725cc0b079:	0f 97 c1             	seta   cl
    78725cc0b07c:	80 e1 01             	and    cl,0x1
    78725cc0b07f:	0f b6 d1             	movzx  edx,cl
    78725cc0b082:	b9 01 00 00 00       	mov    ecx,0x1
    78725cc0b087:	39 f9                	cmp    ecx,edi
    78725cc0b089:	0f 96 c1             	setbe  cl
    78725cc0b08c:	80 e1 01             	and    cl,0x1
    78725cc0b08f:	0f b6 c9             	movzx  ecx,cl
    78725cc0b092:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc0b098:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0b09e:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0b0a4:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0b0aa:	eb 00                	jmp    0x78725cc0b0ac
    78725cc0b0ac:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b0b3:	00 
    78725cc0b0b4:	8b 94 24 bc 00 00 00 	mov    edx,DWORD PTR [rsp+0xbc]
    78725cc0b0bb:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    78725cc0b0c2:	01 d1                	add    ecx,edx
    78725cc0b0c4:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    78725cc0b0cb:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc0b0ce:	eb 00                	jmp    0x78725cc0b0d0
    78725cc0b0d0:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [rsp+0xa0]
    78725cc0b0d7:	83 f8 00             	cmp    eax,0x0
    78725cc0b0da:	75 33                	jne    0x78725cc0b10f
    78725cc0b0dc:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0b0e3:	00 
    78725cc0b0e4:	c7 81 bc 00 00 00 ba 	mov    DWORD PTR [rcx+0xbc],0x101ba
    78725cc0b0eb:	01 01 00 
    78725cc0b0ee:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0b0f4:	83 c0 16             	add    eax,0x16
    78725cc0b0f7:	89 84 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],eax
    78725cc0b0fe:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0b104:	0f 82 e8 09 00 00    	jb     0x78725cc0baf2
    78725cc0b10a:	e9 06 0a 00 00       	jmp    0x78725cc0bb15
    78725cc0b10f:	eb 00                	jmp    0x78725cc0b111
    78725cc0b111:	eb 00                	jmp    0x78725cc0b113
    78725cc0b113:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b11a:	00 
    78725cc0b11b:	c7 40 04 ff 1f 00 00 	mov    DWORD PTR [rax+0x4],0x1fff
    78725cc0b122:	eb 00                	jmp    0x78725cc0b124
    78725cc0b124:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b12b:	00 
    78725cc0b12c:	8b 94 24 a4 00 00 00 	mov    edx,DWORD PTR [rsp+0xa4]
    78725cc0b133:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf0]
    78725cc0b13a:	89 cf                	mov    edi,ecx
    78725cc0b13c:	83 c7 ff             	add    edi,0xffffffff
    78725cc0b13f:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    78725cc0b146:	89 38                	mov    DWORD PTR [rax],edi
    78725cc0b148:	89 ce                	mov    esi,ecx
    78725cc0b14a:	c1 ee 1f             	shr    esi,0x1f
    78725cc0b14d:	89 fd                	mov    ebp,edi
    78725cc0b14f:	c1 ed 1f             	shr    ebp,0x1f
    78725cc0b152:	89 eb                	mov    ebx,ebp
    78725cc0b154:	83 f3 01             	xor    ebx,0x1
    78725cc0b157:	31 ee                	xor    esi,ebp
    78725cc0b159:	21 de                	and    esi,ebx
    78725cc0b15b:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc0b15e:	83 f9 ff             	cmp    ecx,0xffffffff
    78725cc0b161:	0f 92 c1             	setb   cl
    78725cc0b164:	80 e1 01             	and    cl,0x1
    78725cc0b167:	0f b6 c9             	movzx  ecx,cl
    78725cc0b16a:	83 ff 00             	cmp    edi,0x0
    78725cc0b16d:	0f 94 c3             	sete   bl
    78725cc0b170:	80 e3 01             	and    bl,0x1
    78725cc0b173:	0f b6 db             	movzx  ebx,bl
    78725cc0b176:	c1 ef 1f             	shr    edi,0x1f
    78725cc0b179:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    78725cc0b17f:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    78725cc0b185:	09 f2                	or     edx,esi
    78725cc0b187:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0b18d:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0b193:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0b199:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0b19f:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0b1a5:	eb 00                	jmp    0x78725cc0b1a7
    78725cc0b1a7:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b1ae:	00 
    78725cc0b1af:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc0b1b6:	81 e1 ff 1f 00 00    	and    ecx,0x1fff
    78725cc0b1bc:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    78725cc0b1c3:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0b1c5:	83 f9 00             	cmp    ecx,0x0
    78725cc0b1c8:	0f 94 c2             	sete   dl
    78725cc0b1cb:	80 e2 01             	and    dl,0x1
    78725cc0b1ce:	0f b6 d2             	movzx  edx,dl
    78725cc0b1d1:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0b1d4:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0b1da:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0b1e0:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0b1e7:	00 00 00 
    78725cc0b1ea:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0b1f1:	00 00 00 
    78725cc0b1f4:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0b1fb:	00 00 00 
    78725cc0b1fe:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0b205:	00 00 00 
    78725cc0b208:	eb 00                	jmp    0x78725cc0b20a
    78725cc0b20a:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b211:	00 
    78725cc0b212:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    78725cc0b219:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0b21c:	eb 00                	jmp    0x78725cc0b21e
    78725cc0b21e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b225:	00 
    78725cc0b226:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    78725cc0b22d:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0b230:	eb 00                	jmp    0x78725cc0b232
    78725cc0b232:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    78725cc0b239:	83 e0 03             	and    eax,0x3
    78725cc0b23c:	83 f8 00             	cmp    eax,0x0
    78725cc0b23f:	0f 84 97 00 00 00    	je     0x78725cc0b2dc
    78725cc0b245:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0b24c:	00 
    78725cc0b24d:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0b254:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0b25b:	00 
    78725cc0b25c:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    78725cc0b263:	01 01 00 
    78725cc0b266:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0b26d:	00 00 00 
    78725cc0b270:	c7 87 34 01 00 00 1c 	mov    DWORD PTR [rdi+0x134],0x1c
    78725cc0b277:	00 00 00 
    78725cc0b27a:	31 c0                	xor    eax,eax
    78725cc0b27c:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0b283:	60 00 00 
    78725cc0b286:	ba e2 01 01 00       	mov    edx,0x101e2
    78725cc0b28b:	45 31 c0             	xor    r8d,r8d
    78725cc0b28e:	ff d0                	call   rax
    78725cc0b290:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b297:	00 
    78725cc0b298:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b29e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b2a4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b2aa:	be 1c 00 00 00       	mov    esi,0x1c
    78725cc0b2af:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0b2b4:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b2bb:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b2c2:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b2c9:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b2d0:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b2d7:	e9 a6 08 00 00       	jmp    0x78725cc0bb82
    78725cc0b2dc:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0b2e3:	00 
    78725cc0b2e4:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0b2eb:	c1 e9 0c             	shr    ecx,0xc
    78725cc0b2ee:	89 c9                	mov    ecx,ecx
    78725cc0b2f0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0b2f4:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    78725cc0b2fb:	00 
    78725cc0b2fc:	48 83 f8 00          	cmp    rax,0x0
    78725cc0b300:	74 23                	je     0x78725cc0b325
    78725cc0b302:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    78725cc0b309:	00 
    78725cc0b30a:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0b311:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0b317:	89 c9                	mov    ecx,ecx
    78725cc0b319:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0b31c:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc0b323:	eb 5d                	jmp    0x78725cc0b382
    78725cc0b325:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b32c:	00 
    78725cc0b32d:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    78725cc0b334:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0b33b:	00 
    78725cc0b33c:	c7 80 bc 00 00 00 e2 	mov    DWORD PTR [rax+0xbc],0x101e2
    78725cc0b343:	01 01 00 
    78725cc0b346:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0b34d:	00 00 00 
    78725cc0b350:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    78725cc0b357:	00 00 00 
    78725cc0b35a:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0b361:	60 00 00 
    78725cc0b364:	ff d0                	call   rax
    78725cc0b366:	89 c1                	mov    ecx,eax
    78725cc0b368:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b36f:	00 
    78725cc0b370:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    78725cc0b377:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0b37e:	75 28                	jne    0x78725cc0b3a8
    78725cc0b380:	eb 72                	jmp    0x78725cc0b3f4
    78725cc0b382:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    78725cc0b389:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    78725cc0b390:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    78725cc0b394:	83 c0 04             	add    eax,0x4
    78725cc0b397:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0b39b:	83 e0 03             	and    eax,0x3
    78725cc0b39e:	83 f8 00             	cmp    eax,0x0
    78725cc0b3a1:	75 64                	jne    0x78725cc0b407
    78725cc0b3a3:	e9 f3 00 00 00       	jmp    0x78725cc0b49b
    78725cc0b3a8:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b3af:	00 
    78725cc0b3b0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b3b6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b3bc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b3c2:	be 1c 00 00 00       	mov    esi,0x1c
    78725cc0b3c7:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0b3cc:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b3d3:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b3da:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b3e1:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b3e8:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b3ef:	e9 8e 07 00 00       	jmp    0x78725cc0bb82
    78725cc0b3f4:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    78725cc0b3fb:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc0b402:	e9 7b ff ff ff       	jmp    0x78725cc0b382
    78725cc0b407:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0b40e:	00 
    78725cc0b40f:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0b413:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0b41a:	00 
    78725cc0b41b:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    78725cc0b422:	01 01 00 
    78725cc0b425:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0b42c:	00 00 00 
    78725cc0b42f:	c7 87 34 01 00 00 1c 	mov    DWORD PTR [rdi+0x134],0x1c
    78725cc0b436:	00 00 00 
    78725cc0b439:	31 c0                	xor    eax,eax
    78725cc0b43b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0b442:	60 00 00 
    78725cc0b445:	ba e2 01 01 00       	mov    edx,0x101e2
    78725cc0b44a:	45 31 c0             	xor    r8d,r8d
    78725cc0b44d:	ff d0                	call   rax
    78725cc0b44f:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b456:	00 
    78725cc0b457:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b45d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b463:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b469:	be 1c 00 00 00       	mov    esi,0x1c
    78725cc0b46e:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0b473:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b47a:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b481:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b488:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b48f:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b496:	e9 e7 06 00 00       	jmp    0x78725cc0bb82
    78725cc0b49b:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0b4a2:	00 
    78725cc0b4a3:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0b4a7:	c1 e9 0c             	shr    ecx,0xc
    78725cc0b4aa:	89 c9                	mov    ecx,ecx
    78725cc0b4ac:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0b4b0:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc0b4b5:	48 83 f8 00          	cmp    rax,0x0
    78725cc0b4b9:	74 1a                	je     0x78725cc0b4d5
    78725cc0b4bb:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0b4c0:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0b4c4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0b4ca:	89 c9                	mov    ecx,ecx
    78725cc0b4cc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0b4cf:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc0b4d3:	eb 57                	jmp    0x78725cc0b52c
    78725cc0b4d5:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b4dc:	00 
    78725cc0b4dd:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    78725cc0b4e1:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0b4e8:	00 
    78725cc0b4e9:	c7 80 bc 00 00 00 e2 	mov    DWORD PTR [rax+0xbc],0x101e2
    78725cc0b4f0:	01 01 00 
    78725cc0b4f3:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0b4fa:	00 00 00 
    78725cc0b4fd:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    78725cc0b504:	00 00 00 
    78725cc0b507:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0b50e:	60 00 00 
    78725cc0b511:	ff d0                	call   rax
    78725cc0b513:	89 c1                	mov    ecx,eax
    78725cc0b515:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b51c:	00 
    78725cc0b51d:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc0b521:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0b528:	75 2f                	jne    0x78725cc0b559
    78725cc0b52a:	eb 79                	jmp    0x78725cc0b5a5
    78725cc0b52c:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b533:	00 
    78725cc0b534:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    78725cc0b538:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0b53c:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    78725cc0b540:	89 54 24 60          	mov    DWORD PTR [rsp+0x60],edx
    78725cc0b544:	83 c1 04             	add    ecx,0x4
    78725cc0b547:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    78725cc0b54b:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc0b54e:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc0b554:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0b557:	eb 59                	jmp    0x78725cc0b5b2
    78725cc0b559:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b560:	00 
    78725cc0b561:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b567:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b56d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b573:	be 1c 00 00 00       	mov    esi,0x1c
    78725cc0b578:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0b57d:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b584:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b58b:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b592:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b599:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b5a0:	e9 dd 05 00 00       	jmp    0x78725cc0bb82
    78725cc0b5a5:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    78725cc0b5a9:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc0b5ad:	e9 7a ff ff ff       	jmp    0x78725cc0b52c
    78725cc0b5b2:	eb 00                	jmp    0x78725cc0b5b4
    78725cc0b5b4:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    78725cc0b5b8:	83 e0 03             	and    eax,0x3
    78725cc0b5bb:	83 f8 00             	cmp    eax,0x0
    78725cc0b5be:	0f 84 94 00 00 00    	je     0x78725cc0b658
    78725cc0b5c4:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0b5cb:	00 
    78725cc0b5cc:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc0b5d0:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0b5d7:	00 
    78725cc0b5d8:	c7 87 bc 00 00 00 e6 	mov    DWORD PTR [rdi+0xbc],0x101e6
    78725cc0b5df:	01 01 00 
    78725cc0b5e2:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0b5e9:	00 00 00 
    78725cc0b5ec:	c7 87 34 01 00 00 1d 	mov    DWORD PTR [rdi+0x134],0x1d
    78725cc0b5f3:	00 00 00 
    78725cc0b5f6:	31 c0                	xor    eax,eax
    78725cc0b5f8:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0b5ff:	60 00 00 
    78725cc0b602:	ba e6 01 01 00       	mov    edx,0x101e6
    78725cc0b607:	45 31 c0             	xor    r8d,r8d
    78725cc0b60a:	ff d0                	call   rax
    78725cc0b60c:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b613:	00 
    78725cc0b614:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b61a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b620:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b626:	be 1d 00 00 00       	mov    esi,0x1d
    78725cc0b62b:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0b630:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b637:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b63e:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b645:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b64c:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b653:	e9 2a 05 00 00       	jmp    0x78725cc0bb82
    78725cc0b658:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0b65f:	00 
    78725cc0b660:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc0b664:	c1 e9 0c             	shr    ecx,0xc
    78725cc0b667:	89 c9                	mov    ecx,ecx
    78725cc0b669:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0b66d:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc0b672:	48 83 f8 00          	cmp    rax,0x0
    78725cc0b676:	74 1a                	je     0x78725cc0b692
    78725cc0b678:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc0b67d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc0b681:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0b687:	89 c9                	mov    ecx,ecx
    78725cc0b689:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0b68c:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0b690:	eb 57                	jmp    0x78725cc0b6e9
    78725cc0b692:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b699:	00 
    78725cc0b69a:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    78725cc0b69e:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0b6a5:	00 
    78725cc0b6a6:	c7 80 bc 00 00 00 e6 	mov    DWORD PTR [rax+0xbc],0x101e6
    78725cc0b6ad:	01 01 00 
    78725cc0b6b0:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0b6b7:	00 00 00 
    78725cc0b6ba:	c7 80 34 01 00 00 1d 	mov    DWORD PTR [rax+0x134],0x1d
    78725cc0b6c1:	00 00 00 
    78725cc0b6c4:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0b6cb:	60 00 00 
    78725cc0b6ce:	ff d0                	call   rax
    78725cc0b6d0:	89 c1                	mov    ecx,eax
    78725cc0b6d2:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b6d9:	00 
    78725cc0b6da:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc0b6de:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0b6e5:	75 1d                	jne    0x78725cc0b704
    78725cc0b6e7:	eb 67                	jmp    0x78725cc0b750
    78725cc0b6e9:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b6f0:	00 
    78725cc0b6f1:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc0b6f5:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    78725cc0b6f9:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    78725cc0b6fc:	83 c1 04             	add    ecx,0x4
    78725cc0b6ff:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0b702:	eb 56                	jmp    0x78725cc0b75a
    78725cc0b704:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b70b:	00 
    78725cc0b70c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b712:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b718:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b71e:	be 1d 00 00 00       	mov    esi,0x1d
    78725cc0b723:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0b728:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b72f:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b736:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b73d:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b744:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b74b:	e9 32 04 00 00       	jmp    0x78725cc0bb82
    78725cc0b750:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc0b754:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0b758:	eb 8f                	jmp    0x78725cc0b6e9
    78725cc0b75a:	eb 00                	jmp    0x78725cc0b75c
    78725cc0b75c:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b763:	00 
    78725cc0b764:	8b 8c 24 e0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe0]
    78725cc0b76b:	8b 94 24 90 00 00 00 	mov    edx,DWORD PTR [rsp+0x90]
    78725cc0b772:	c1 e2 02             	shl    edx,0x2
    78725cc0b775:	01 d1                	add    ecx,edx
    78725cc0b777:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    78725cc0b77b:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc0b77e:	eb 00                	jmp    0x78725cc0b780
    78725cc0b780:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    78725cc0b784:	83 e0 03             	and    eax,0x3
    78725cc0b787:	83 f8 00             	cmp    eax,0x0
    78725cc0b78a:	0f 84 94 00 00 00    	je     0x78725cc0b824
    78725cc0b790:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0b797:	00 
    78725cc0b798:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc0b79c:	48 8b b4 24 50 01 00 	mov    rsi,QWORD PTR [rsp+0x150]
    78725cc0b7a3:	00 
    78725cc0b7a4:	c7 87 bc 00 00 00 ea 	mov    DWORD PTR [rdi+0xbc],0x101ea
    78725cc0b7ab:	01 01 00 
    78725cc0b7ae:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0b7b5:	00 00 00 
    78725cc0b7b8:	c7 87 34 01 00 00 1f 	mov    DWORD PTR [rdi+0x134],0x1f
    78725cc0b7bf:	00 00 00 
    78725cc0b7c2:	31 c0                	xor    eax,eax
    78725cc0b7c4:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0b7cb:	60 00 00 
    78725cc0b7ce:	ba ea 01 01 00       	mov    edx,0x101ea
    78725cc0b7d3:	45 31 c0             	xor    r8d,r8d
    78725cc0b7d6:	ff d0                	call   rax
    78725cc0b7d8:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b7df:	00 
    78725cc0b7e0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b7e6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b7ec:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b7f2:	be 1f 00 00 00       	mov    esi,0x1f
    78725cc0b7f7:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0b7fc:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b803:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b80a:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b811:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b818:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b81f:	e9 5e 03 00 00       	jmp    0x78725cc0bb82
    78725cc0b824:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    78725cc0b82b:	00 
    78725cc0b82c:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc0b830:	c1 e9 0c             	shr    ecx,0xc
    78725cc0b833:	89 c9                	mov    ecx,ecx
    78725cc0b835:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0b839:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    78725cc0b83e:	48 83 f8 00          	cmp    rax,0x0
    78725cc0b842:	74 1a                	je     0x78725cc0b85e
    78725cc0b844:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0b849:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc0b84d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0b853:	89 c9                	mov    ecx,ecx
    78725cc0b855:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0b858:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc0b85c:	eb 57                	jmp    0x78725cc0b8b5
    78725cc0b85e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b865:	00 
    78725cc0b866:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc0b86a:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
    78725cc0b871:	00 
    78725cc0b872:	c7 80 bc 00 00 00 ea 	mov    DWORD PTR [rax+0xbc],0x101ea
    78725cc0b879:	01 01 00 
    78725cc0b87c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0b883:	00 00 00 
    78725cc0b886:	c7 80 34 01 00 00 1f 	mov    DWORD PTR [rax+0x134],0x1f
    78725cc0b88d:	00 00 00 
    78725cc0b890:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0b897:	60 00 00 
    78725cc0b89a:	ff d0                	call   rax
    78725cc0b89c:	89 c1                	mov    ecx,eax
    78725cc0b89e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b8a5:	00 
    78725cc0b8a6:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    78725cc0b8aa:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0b8b1:	75 16                	jne    0x78725cc0b8c9
    78725cc0b8b3:	eb 60                	jmp    0x78725cc0b915
    78725cc0b8b5:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b8bc:	00 
    78725cc0b8bd:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    78725cc0b8c1:	89 4c 24 34          	mov    DWORD PTR [rsp+0x34],ecx
    78725cc0b8c5:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0b8c7:	eb 56                	jmp    0x78725cc0b91f
    78725cc0b8c9:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b8d0:	00 
    78725cc0b8d1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0b8d7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0b8dd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0b8e3:	be 1f 00 00 00       	mov    esi,0x1f
    78725cc0b8e8:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0b8ed:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b8f4:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b8fb:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b902:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b909:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b910:	e9 6d 02 00 00       	jmp    0x78725cc0bb82
    78725cc0b915:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    78725cc0b919:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    78725cc0b91d:	eb 96                	jmp    0x78725cc0b8b5
    78725cc0b91f:	eb 00                	jmp    0x78725cc0b921
    78725cc0b921:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0b928:	00 
    78725cc0b929:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    78725cc0b930:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc0b934:	31 d1                	xor    ecx,edx
    78725cc0b936:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0b938:	83 f9 00             	cmp    ecx,0x0
    78725cc0b93b:	0f 94 c2             	sete   dl
    78725cc0b93e:	80 e2 01             	and    dl,0x1
    78725cc0b941:	0f b6 d2             	movzx  edx,dl
    78725cc0b944:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0b947:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0b94d:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0b953:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0b95a:	00 00 00 
    78725cc0b95d:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0b964:	00 00 00 
    78725cc0b967:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0b96e:	00 00 00 
    78725cc0b971:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0b978:	00 00 00 
    78725cc0b97b:	eb 00                	jmp    0x78725cc0b97d
    78725cc0b97d:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    78725cc0b981:	83 e0 01             	and    eax,0x1
    78725cc0b984:	83 f8 00             	cmp    eax,0x0
    78725cc0b987:	75 3a                	jne    0x78725cc0b9c3
    78725cc0b989:	8b 54 24 60          	mov    edx,DWORD PTR [rsp+0x60]
    78725cc0b98d:	be 21 00 00 00       	mov    esi,0x21
    78725cc0b992:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0b997:	b0 01                	mov    al,0x1
    78725cc0b999:	89 d7                	mov    edi,edx
    78725cc0b99b:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0b9a2:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0b9a9:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0b9b0:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0b9b7:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0b9be:	e9 bf 01 00 00       	jmp    0x78725cc0bb82
    78725cc0b9c3:	48 8b bc 24 58 01 00 	mov    rdi,QWORD PTR [rsp+0x158]
    78725cc0b9ca:	00 
    78725cc0b9cb:	48 8b 94 24 50 01 00 	mov    rdx,QWORD PTR [rsp+0x150]
    78725cc0b9d2:	00 
    78725cc0b9d3:	c7 87 bc 00 00 00 ee 	mov    DWORD PTR [rdi+0xbc],0x101ee
    78725cc0b9da:	01 01 00 
    78725cc0b9dd:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0b9e4:	00 00 00 
    78725cc0b9e7:	c7 87 34 01 00 00 21 	mov    DWORD PTR [rdi+0x134],0x21
    78725cc0b9ee:	00 00 00 
    78725cc0b9f1:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc0b9f8:	60 00 00 
    78725cc0b9fb:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc0ba00:	ff d0                	call   rax
    78725cc0ba02:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ba09:	00 
    78725cc0ba0a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ba10:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ba16:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ba1c:	be 21 00 00 00       	mov    esi,0x21
    78725cc0ba21:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ba26:	89 bc 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],edi
    78725cc0ba2d:	89 b4 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],esi
    78725cc0ba34:	89 94 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],edx
    78725cc0ba3b:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc0ba42:	88 84 24 3b 01 00 00 	mov    BYTE PTR [rsp+0x13b],al
    78725cc0ba49:	e9 34 01 00 00       	jmp    0x78725cc0bb82
    78725cc0ba4e:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ba55:	00 
    78725cc0ba56:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc0ba5d:	e9 10 02 00 00       	jmp    0x78725cc0bc72
    78725cc0ba62:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    78725cc0ba69:	00 
    78725cc0ba6a:	48 89 c1             	mov    rcx,rax
    78725cc0ba6d:	48 81 c1 80 0f 08 00 	add    rcx,0x80f80
    78725cc0ba74:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc0ba79:	81 b8 80 0f 08 00 f0 	cmp    DWORD PTR [rax+0x80f80],0x101f0
    78725cc0ba80:	01 01 00 
    78725cc0ba83:	74 32                	je     0x78725cc0bab7
    78725cc0ba85:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0ba8c:	00 
    78725cc0ba8d:	c7 80 bc 00 00 00 f0 	mov    DWORD PTR [rax+0xbc],0x101f0
    78725cc0ba94:	01 01 00 
    78725cc0ba97:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0ba9e:	00 00 00 
    78725cc0baa1:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc0baa8:	00 00 00 
    78725cc0baab:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0bab2:	e9 bb 01 00 00       	jmp    0x78725cc0bc72
    78725cc0bab7:	4c 8b b4 24 50 01 00 	mov    r14,QWORD PTR [rsp+0x150]
    78725cc0babe:	00 
    78725cc0babf:	4c 8b ac 24 58 01 00 	mov    r13,QWORD PTR [rsp+0x158]
    78725cc0bac6:	00 
    78725cc0bac7:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc0bacc:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    78725cc0bad3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101f0
    78725cc0bada:	f0 01 01 00 
    78725cc0bade:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0bae5:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0bae9:	48 81 c4 78 01 00 00 	add    rsp,0x178
    78725cc0baf0:	ff e0                	jmp    rax
    78725cc0baf2:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    78725cc0baf9:	00 
    78725cc0bafa:	48 89 c1             	mov    rcx,rax
    78725cc0bafd:	48 81 c1 d0 0d 08 00 	add    rcx,0x80dd0
    78725cc0bb04:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc0bb09:	81 b8 d0 0d 08 00 ba 	cmp    DWORD PTR [rax+0x80dd0],0x101ba
    78725cc0bb10:	01 01 00 
    78725cc0bb13:	74 32                	je     0x78725cc0bb47
    78725cc0bb15:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0bb1c:	00 
    78725cc0bb1d:	c7 80 bc 00 00 00 ba 	mov    DWORD PTR [rax+0xbc],0x101ba
    78725cc0bb24:	01 01 00 
    78725cc0bb27:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0bb2e:	00 00 00 
    78725cc0bb31:	c7 80 34 01 00 00 16 	mov    DWORD PTR [rax+0x134],0x16
    78725cc0bb38:	00 00 00 
    78725cc0bb3b:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0bb42:	e9 2b 01 00 00       	jmp    0x78725cc0bc72
    78725cc0bb47:	4c 8b b4 24 50 01 00 	mov    r14,QWORD PTR [rsp+0x150]
    78725cc0bb4e:	00 
    78725cc0bb4f:	4c 8b ac 24 58 01 00 	mov    r13,QWORD PTR [rsp+0x158]
    78725cc0bb56:	00 
    78725cc0bb57:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc0bb5c:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    78725cc0bb63:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101ba
    78725cc0bb6a:	ba 01 01 00 
    78725cc0bb6e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0bb75:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0bb79:	48 81 c4 78 01 00 00 	add    rsp,0x178
    78725cc0bb80:	ff e0                	jmp    rax
    78725cc0bb82:	48 8b 8c 24 58 01 00 	mov    rcx,QWORD PTR [rsp+0x158]
    78725cc0bb89:	00 
    78725cc0bb8a:	8b 94 24 28 01 00 00 	mov    edx,DWORD PTR [rsp+0x128]
    78725cc0bb91:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    78725cc0bb98:	8b b4 24 30 01 00 00 	mov    esi,DWORD PTR [rsp+0x130]
    78725cc0bb9f:	8b bc 24 34 01 00 00 	mov    edi,DWORD PTR [rsp+0x134]
    78725cc0bba6:	8a 9c 24 3b 01 00 00 	mov    bl,BYTE PTR [rsp+0x13b]
    78725cc0bbad:	88 5c 24 0b          	mov    BYTE PTR [rsp+0xb],bl
    78725cc0bbb1:	89 c3                	mov    ebx,eax
    78725cc0bbb3:	89 5c 24 0c          	mov    DWORD PTR [rsp+0xc],ebx
    78725cc0bbb7:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc0bbbb:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc0bbbf:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc0bbc3:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0bbc9:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc0bbcd:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0bbd3:	73 2c                	jae    0x78725cc0bc01
    78725cc0bbd5:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    78725cc0bbdc:	00 
    78725cc0bbdd:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc0bbe1:	89 d1                	mov    ecx,edx
    78725cc0bbe3:	c1 e9 01             	shr    ecx,0x1
    78725cc0bbe6:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0bbec:	89 c9                	mov    ecx,ecx
    78725cc0bbee:	48 c1 e1 04          	shl    rcx,0x4
    78725cc0bbf2:	48 89 c6             	mov    rsi,rax
    78725cc0bbf5:	48 01 ce             	add    rsi,rcx
    78725cc0bbf8:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    78725cc0bbfc:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0bbff:	74 32                	je     0x78725cc0bc33
    78725cc0bc01:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc0bc08:	00 
    78725cc0bc09:	8a 4c 24 0b          	mov    cl,BYTE PTR [rsp+0xb]
    78725cc0bc0d:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    78725cc0bc11:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    78725cc0bc15:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    78725cc0bc19:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc0bc1f:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc0bc25:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc0bc2b:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc0bc31:	eb 3f                	jmp    0x78725cc0bc72
    78725cc0bc33:	4c 8b b4 24 50 01 00 	mov    r14,QWORD PTR [rsp+0x150]
    78725cc0bc3a:	00 
    78725cc0bc3b:	4c 8b ac 24 58 01 00 	mov    r13,QWORD PTR [rsp+0x158]
    78725cc0bc42:	00 
    78725cc0bc43:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    78725cc0bc47:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc0bc4b:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc0bc4f:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc0bc56:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0bc5d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc0bc64:	00 
    78725cc0bc65:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0bc69:	48 81 c4 78 01 00 00 	add    rsp,0x178
    78725cc0bc70:	ff e0                	jmp    rax
    78725cc0bc72:	48 81 c4 78 01 00 00 	add    rsp,0x178
    78725cc0bc79:	c2 08 00             	ret    0x8
