
build-native-instruction-analysis/capture/bcore-default-stream/pc-66752-0-132432577730608.bin:     file format binary


Disassembly of section .data:

000078725cc09830 <.data>:
    78725cc09830:	48 81 ec c8 00 00 00 	sub    rsp,0xc8
    78725cc09837:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
    78725cc0983e:	00 
    78725cc0983f:	4c 89 ac 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r13
    78725cc09846:	00 
    78725cc09847:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0984e:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    78725cc09855:	00 
    78725cc09856:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0985d:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    78725cc09864:	00 
    78725cc09865:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    78725cc0986c:	00 
    78725cc0986d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc09873:	83 fa 00             	cmp    edx,0x0
    78725cc09876:	0f 94 c0             	sete   al
    78725cc09879:	81 ea c0 04 01 00    	sub    edx,0x104c0
    78725cc0987f:	83 fa 18             	cmp    edx,0x18
    78725cc09882:	0f 97 c2             	seta   dl
    78725cc09885:	08 d0                	or     al,dl
    78725cc09887:	24 01                	and    al,0x1
    78725cc09889:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0988f:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc09895:	0f 94 c1             	sete   cl
    78725cc09898:	81 ea c0 04 01 00    	sub    edx,0x104c0
    78725cc0989e:	83 fa 18             	cmp    edx,0x18
    78725cc098a1:	0f 97 c2             	seta   dl
    78725cc098a4:	08 d1                	or     cl,dl
    78725cc098a6:	20 c8                	and    al,cl
    78725cc098a8:	a8 01                	test   al,0x1
    78725cc098aa:	75 05                	jne    0x78725cc098b1
    78725cc098ac:	e9 08 07 00 00       	jmp    0x78725cc09fb9
    78725cc098b1:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc098b8:	00 
    78725cc098b9:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc098c0:	48 89 c8             	mov    rax,rcx
    78725cc098c3:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc098c9:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    78725cc098d0:	00 
    78725cc098d1:	8b 81 28 00 10 00    	mov    eax,DWORD PTR [rcx+0x100028]
    78725cc098d7:	83 c0 01             	add    eax,0x1
    78725cc098da:	89 81 28 00 10 00    	mov    DWORD PTR [rcx+0x100028],eax
    78725cc098e0:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc098e5:	75 4c                	jne    0x78725cc09933
    78725cc098e7:	48 8b 8c 24 a0 00 00 	mov    rcx,QWORD PTR [rsp+0xa0]
    78725cc098ee:	00 
    78725cc098ef:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc098f5:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    78725cc098fc:	89 c2                	mov    edx,eax
    78725cc098fe:	83 c2 01             	add    edx,0x1
    78725cc09901:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc09907:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0990c:	73 23                	jae    0x78725cc09931
    78725cc0990e:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc09915:	00 
    78725cc09916:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    78725cc0991d:	89 c9                	mov    ecx,ecx
    78725cc0991f:	48 c1 e1 02          	shl    rcx,0x2
    78725cc09923:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc0992a:	c7 04 08 0a 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xa
    78725cc09931:	eb 00                	jmp    0x78725cc09933
    78725cc09933:	eb 00                	jmp    0x78725cc09935
    78725cc09935:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc0993c:	00 
    78725cc0993d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    78725cc09940:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc09946:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc0994c:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    78725cc09953:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc09956:	eb 00                	jmp    0x78725cc09958
    78725cc09958:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc0995f:	00 
    78725cc09960:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    78725cc09967:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc0996d:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    78725cc09973:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    78725cc0997a:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0997d:	eb 00                	jmp    0x78725cc0997f
    78725cc0997f:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc09986:	83 e0 03             	and    eax,0x3
    78725cc09989:	83 f8 00             	cmp    eax,0x0
    78725cc0998c:	74 7d                	je     0x78725cc09a0b
    78725cc0998e:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    78725cc09995:	00 
    78725cc09996:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc0999d:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    78725cc099a4:	00 
    78725cc099a5:	c7 87 bc 00 00 00 c8 	mov    DWORD PTR [rdi+0xbc],0x104c8
    78725cc099ac:	04 01 00 
    78725cc099af:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc099b6:	00 00 00 
    78725cc099b9:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc099c0:	00 00 00 
    78725cc099c3:	31 c0                	xor    eax,eax
    78725cc099c5:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc099cc:	60 00 00 
    78725cc099cf:	ba c8 04 01 00       	mov    edx,0x104c8
    78725cc099d4:	45 31 c0             	xor    r8d,r8d
    78725cc099d7:	ff d0                	call   rax
    78725cc099d9:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc099e0:	00 
    78725cc099e1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc099e7:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc099ec:	b8 02 00 00 00       	mov    eax,0x2
    78725cc099f1:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc099f8:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc099ff:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09a06:	e9 4f 06 00 00       	jmp    0x78725cc0a05a
    78725cc09a0b:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    78725cc09a12:	00 
    78725cc09a13:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc09a1a:	c1 e9 0c             	shr    ecx,0xc
    78725cc09a1d:	89 c9                	mov    ecx,ecx
    78725cc09a1f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc09a23:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc09a2a:	00 
    78725cc09a2b:	48 83 f8 00          	cmp    rax,0x0
    78725cc09a2f:	74 20                	je     0x78725cc09a51
    78725cc09a31:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc09a38:	00 
    78725cc09a39:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc09a40:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc09a46:	89 c9                	mov    ecx,ecx
    78725cc09a48:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc09a4b:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc09a4f:	eb 5a                	jmp    0x78725cc09aab
    78725cc09a51:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09a58:	00 
    78725cc09a59:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    78725cc09a60:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    78725cc09a67:	00 
    78725cc09a68:	c7 80 bc 00 00 00 c8 	mov    DWORD PTR [rax+0xbc],0x104c8
    78725cc09a6f:	04 01 00 
    78725cc09a72:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc09a79:	00 00 00 
    78725cc09a7c:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc09a83:	00 00 00 
    78725cc09a86:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc09a8d:	60 00 00 
    78725cc09a90:	ff d0                	call   rax
    78725cc09a92:	89 c1                	mov    ecx,eax
    78725cc09a94:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09a9b:	00 
    78725cc09a9c:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    78725cc09aa0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc09aa7:	75 12                	jne    0x78725cc09abb
    78725cc09aa9:	eb 42                	jmp    0x78725cc09aed
    78725cc09aab:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09ab2:	00 
    78725cc09ab3:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc09ab7:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc09ab9:	eb 3c                	jmp    0x78725cc09af7
    78725cc09abb:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09ac2:	00 
    78725cc09ac3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09ac9:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc09ace:	b8 02 00 00 00       	mov    eax,0x2
    78725cc09ad3:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09ada:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09ae1:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09ae8:	e9 6d 05 00 00       	jmp    0x78725cc0a05a
    78725cc09aed:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    78725cc09af1:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc09af5:	eb b4                	jmp    0x78725cc09aab
    78725cc09af7:	eb 00                	jmp    0x78725cc09af9
    78725cc09af9:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09b00:	00 
    78725cc09b01:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc09b08:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc09b0e:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc09b14:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    78725cc09b18:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc09b1b:	eb 00                	jmp    0x78725cc09b1d
    78725cc09b1d:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09b24:	00 
    78725cc09b25:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc09b29:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc09b2f:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    78725cc09b35:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    78725cc09b39:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc09b3c:	eb 00                	jmp    0x78725cc09b3e
    78725cc09b3e:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    78725cc09b42:	83 e0 03             	and    eax,0x3
    78725cc09b45:	83 f8 00             	cmp    eax,0x0
    78725cc09b48:	74 7a                	je     0x78725cc09bc4
    78725cc09b4a:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    78725cc09b51:	00 
    78725cc09b52:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc09b56:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    78725cc09b5d:	00 
    78725cc09b5e:	c7 87 bc 00 00 00 d2 	mov    DWORD PTR [rdi+0xbc],0x104d2
    78725cc09b65:	04 01 00 
    78725cc09b68:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc09b6f:	00 00 00 
    78725cc09b72:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    78725cc09b79:	00 00 00 
    78725cc09b7c:	31 c0                	xor    eax,eax
    78725cc09b7e:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc09b85:	60 00 00 
    78725cc09b88:	ba d2 04 01 00       	mov    edx,0x104d2
    78725cc09b8d:	45 31 c0             	xor    r8d,r8d
    78725cc09b90:	ff d0                	call   rax
    78725cc09b92:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09b99:	00 
    78725cc09b9a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09ba0:	b9 06 00 00 00       	mov    ecx,0x6
    78725cc09ba5:	b8 02 00 00 00       	mov    eax,0x2
    78725cc09baa:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09bb1:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09bb8:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09bbf:	e9 96 04 00 00       	jmp    0x78725cc0a05a
    78725cc09bc4:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    78725cc09bcb:	00 
    78725cc09bcc:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc09bd0:	c1 e9 0c             	shr    ecx,0xc
    78725cc09bd3:	89 c9                	mov    ecx,ecx
    78725cc09bd5:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc09bd9:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc09bde:	48 83 f8 00          	cmp    rax,0x0
    78725cc09be2:	74 1a                	je     0x78725cc09bfe
    78725cc09be4:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc09be9:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    78725cc09bed:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc09bf3:	89 c9                	mov    ecx,ecx
    78725cc09bf5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc09bf8:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc09bfc:	eb 57                	jmp    0x78725cc09c55
    78725cc09bfe:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09c05:	00 
    78725cc09c06:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    78725cc09c0a:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    78725cc09c11:	00 
    78725cc09c12:	c7 80 bc 00 00 00 d2 	mov    DWORD PTR [rax+0xbc],0x104d2
    78725cc09c19:	04 01 00 
    78725cc09c1c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc09c23:	00 00 00 
    78725cc09c26:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    78725cc09c2d:	00 00 00 
    78725cc09c30:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc09c37:	60 00 00 
    78725cc09c3a:	ff d0                	call   rax
    78725cc09c3c:	89 c1                	mov    ecx,eax
    78725cc09c3e:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09c45:	00 
    78725cc09c46:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    78725cc09c4a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc09c51:	75 13                	jne    0x78725cc09c66
    78725cc09c53:	eb 43                	jmp    0x78725cc09c98
    78725cc09c55:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09c5c:	00 
    78725cc09c5d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc09c61:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc09c64:	eb 3c                	jmp    0x78725cc09ca2
    78725cc09c66:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09c6d:	00 
    78725cc09c6e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09c74:	b9 06 00 00 00       	mov    ecx,0x6
    78725cc09c79:	b8 02 00 00 00       	mov    eax,0x2
    78725cc09c7e:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09c85:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09c8c:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09c93:	e9 c2 03 00 00       	jmp    0x78725cc0a05a
    78725cc09c98:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    78725cc09c9c:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc09ca0:	eb b3                	jmp    0x78725cc09c55
    78725cc09ca2:	eb 00                	jmp    0x78725cc09ca4
    78725cc09ca4:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09cab:	00 
    78725cc09cac:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc09caf:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    78725cc09cb3:	83 e0 03             	and    eax,0x3
    78725cc09cb6:	83 f8 00             	cmp    eax,0x0
    78725cc09cb9:	74 7a                	je     0x78725cc09d35
    78725cc09cbb:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    78725cc09cc2:	00 
    78725cc09cc3:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc09cc7:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    78725cc09cce:	00 
    78725cc09ccf:	c7 87 bc 00 00 00 d4 	mov    DWORD PTR [rdi+0xbc],0x104d4
    78725cc09cd6:	04 01 00 
    78725cc09cd9:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc09ce0:	00 00 00 
    78725cc09ce3:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    78725cc09cea:	00 00 00 
    78725cc09ced:	31 c0                	xor    eax,eax
    78725cc09cef:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc09cf6:	60 00 00 
    78725cc09cf9:	ba d4 04 01 00       	mov    edx,0x104d4
    78725cc09cfe:	45 31 c0             	xor    r8d,r8d
    78725cc09d01:	ff d0                	call   rax
    78725cc09d03:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09d0a:	00 
    78725cc09d0b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09d11:	b9 07 00 00 00       	mov    ecx,0x7
    78725cc09d16:	b8 04 00 00 00       	mov    eax,0x4
    78725cc09d1b:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09d22:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09d29:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09d30:	e9 25 03 00 00       	jmp    0x78725cc0a05a
    78725cc09d35:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    78725cc09d3c:	00 
    78725cc09d3d:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc09d41:	c1 e9 0c             	shr    ecx,0xc
    78725cc09d44:	89 c9                	mov    ecx,ecx
    78725cc09d46:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc09d4a:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc09d4f:	48 83 f8 00          	cmp    rax,0x0
    78725cc09d53:	74 1a                	je     0x78725cc09d6f
    78725cc09d55:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc09d5a:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc09d5e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc09d64:	89 c9                	mov    ecx,ecx
    78725cc09d66:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc09d69:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc09d6d:	eb 57                	jmp    0x78725cc09dc6
    78725cc09d6f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09d76:	00 
    78725cc09d77:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    78725cc09d7b:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    78725cc09d82:	00 
    78725cc09d83:	c7 80 bc 00 00 00 d4 	mov    DWORD PTR [rax+0xbc],0x104d4
    78725cc09d8a:	04 01 00 
    78725cc09d8d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc09d94:	00 00 00 
    78725cc09d97:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    78725cc09d9e:	00 00 00 
    78725cc09da1:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc09da8:	60 00 00 
    78725cc09dab:	ff d0                	call   rax
    78725cc09dad:	89 c1                	mov    ecx,eax
    78725cc09daf:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09db6:	00 
    78725cc09db7:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc09dbb:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc09dc2:	75 22                	jne    0x78725cc09de6
    78725cc09dc4:	eb 52                	jmp    0x78725cc09e18
    78725cc09dc6:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    78725cc09dca:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc09dce:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc09dd2:	83 c0 04             	add    eax,0x4
    78725cc09dd5:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc09dd9:	83 e0 03             	and    eax,0x3
    78725cc09ddc:	83 f8 00             	cmp    eax,0x0
    78725cc09ddf:	75 41                	jne    0x78725cc09e22
    78725cc09de1:	e9 b6 00 00 00       	jmp    0x78725cc09e9c
    78725cc09de6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09ded:	00 
    78725cc09dee:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09df4:	b9 07 00 00 00       	mov    ecx,0x7
    78725cc09df9:	b8 04 00 00 00       	mov    eax,0x4
    78725cc09dfe:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09e05:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09e0c:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09e13:	e9 42 02 00 00       	jmp    0x78725cc0a05a
    78725cc09e18:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc09e1c:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc09e20:	eb a4                	jmp    0x78725cc09dc6
    78725cc09e22:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    78725cc09e29:	00 
    78725cc09e2a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc09e2e:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    78725cc09e35:	00 
    78725cc09e36:	c7 87 bc 00 00 00 d4 	mov    DWORD PTR [rdi+0xbc],0x104d4
    78725cc09e3d:	04 01 00 
    78725cc09e40:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc09e47:	00 00 00 
    78725cc09e4a:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    78725cc09e51:	00 00 00 
    78725cc09e54:	31 c0                	xor    eax,eax
    78725cc09e56:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc09e5d:	60 00 00 
    78725cc09e60:	ba d4 04 01 00       	mov    edx,0x104d4
    78725cc09e65:	45 31 c0             	xor    r8d,r8d
    78725cc09e68:	ff d0                	call   rax
    78725cc09e6a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09e71:	00 
    78725cc09e72:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09e78:	b9 07 00 00 00       	mov    ecx,0x7
    78725cc09e7d:	b8 04 00 00 00       	mov    eax,0x4
    78725cc09e82:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09e89:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09e90:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09e97:	e9 be 01 00 00       	jmp    0x78725cc0a05a
    78725cc09e9c:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    78725cc09ea3:	00 
    78725cc09ea4:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc09ea8:	c1 e9 0c             	shr    ecx,0xc
    78725cc09eab:	89 c9                	mov    ecx,ecx
    78725cc09ead:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc09eb1:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc09eb6:	48 83 f8 00          	cmp    rax,0x0
    78725cc09eba:	74 1a                	je     0x78725cc09ed6
    78725cc09ebc:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc09ec1:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc09ec5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc09ecb:	89 c9                	mov    ecx,ecx
    78725cc09ecd:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc09ed0:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc09ed4:	eb 57                	jmp    0x78725cc09f2d
    78725cc09ed6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09edd:	00 
    78725cc09ede:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc09ee2:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    78725cc09ee9:	00 
    78725cc09eea:	c7 80 bc 00 00 00 d4 	mov    DWORD PTR [rax+0xbc],0x104d4
    78725cc09ef1:	04 01 00 
    78725cc09ef4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc09efb:	00 00 00 
    78725cc09efe:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    78725cc09f05:	00 00 00 
    78725cc09f08:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc09f0f:	60 00 00 
    78725cc09f12:	ff d0                	call   rax
    78725cc09f14:	89 c1                	mov    ecx,eax
    78725cc09f16:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09f1d:	00 
    78725cc09f1e:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc09f22:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc09f29:	75 27                	jne    0x78725cc09f52
    78725cc09f2b:	eb 57                	jmp    0x78725cc09f84
    78725cc09f2d:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09f34:	00 
    78725cc09f35:	8b 74 24 40          	mov    esi,DWORD PTR [rsp+0x40]
    78725cc09f39:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc09f3d:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    78725cc09f41:	83 c1 04             	add    ecx,0x4
    78725cc09f44:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc09f47:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc09f4d:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc09f50:	eb 3c                	jmp    0x78725cc09f8e
    78725cc09f52:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09f59:	00 
    78725cc09f5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc09f60:	b9 07 00 00 00       	mov    ecx,0x7
    78725cc09f65:	b8 04 00 00 00       	mov    eax,0x4
    78725cc09f6a:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    78725cc09f71:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    78725cc09f78:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    78725cc09f7f:	e9 d6 00 00 00       	jmp    0x78725cc0a05a
    78725cc09f84:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc09f88:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc09f8c:	eb 9f                	jmp    0x78725cc09f2d
    78725cc09f8e:	eb 00                	jmp    0x78725cc09f90
    78725cc09f90:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    78725cc09f97:	00 
    78725cc09f98:	c7 81 bc 00 00 00 a0 	mov    DWORD PTR [rcx+0xbc],0x101a0
    78725cc09f9f:	01 01 00 
    78725cc09fa2:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc09fa8:	83 c0 08             	add    eax,0x8
    78725cc09fab:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc09faf:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc09fb5:	72 16                	jb     0x78725cc09fcd
    78725cc09fb7:	eb 37                	jmp    0x78725cc09ff0
    78725cc09fb9:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09fc0:	00 
    78725cc09fc1:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc09fc8:	e9 4a 01 00 00       	jmp    0x78725cc0a117
    78725cc09fcd:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    78725cc09fd4:	00 
    78725cc09fd5:	48 89 c1             	mov    rcx,rax
    78725cc09fd8:	48 81 c1 00 0d 08 00 	add    rcx,0x80d00
    78725cc09fdf:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc09fe4:	81 b8 00 0d 08 00 a0 	cmp    DWORD PTR [rax+0x80d00],0x101a0
    78725cc09feb:	01 01 00 
    78725cc09fee:	74 32                	je     0x78725cc0a022
    78725cc09ff0:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc09ff7:	00 
    78725cc09ff8:	c7 80 bc 00 00 00 a0 	mov    DWORD PTR [rax+0xbc],0x101a0
    78725cc09fff:	01 01 00 
    78725cc0a002:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0a009:	00 00 00 
    78725cc0a00c:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    78725cc0a013:	00 00 00 
    78725cc0a016:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0a01d:	e9 f5 00 00 00       	jmp    0x78725cc0a117
    78725cc0a022:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    78725cc0a029:	00 
    78725cc0a02a:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    78725cc0a031:	00 
    78725cc0a032:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc0a037:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc0a03b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x101a0
    78725cc0a042:	a0 01 01 00 
    78725cc0a046:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0a04d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0a051:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    78725cc0a058:	ff e0                	jmp    rax
    78725cc0a05a:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    78725cc0a061:	00 
    78725cc0a062:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    78725cc0a069:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    78725cc0a070:	8b b4 24 90 00 00 00 	mov    esi,DWORD PTR [rsp+0x90]
    78725cc0a077:	89 c7                	mov    edi,eax
    78725cc0a079:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc0a07d:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc0a081:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc0a085:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0a08b:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc0a08f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0a095:	73 2d                	jae    0x78725cc0a0c4
    78725cc0a097:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    78725cc0a09e:	00 
    78725cc0a09f:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc0a0a3:	89 d1                	mov    ecx,edx
    78725cc0a0a5:	c1 e9 01             	shr    ecx,0x1
    78725cc0a0a8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0a0ae:	89 c9                	mov    ecx,ecx
    78725cc0a0b0:	48 c1 e1 04          	shl    rcx,0x4
    78725cc0a0b4:	48 89 c6             	mov    rsi,rax
    78725cc0a0b7:	48 01 ce             	add    rsi,rcx
    78725cc0a0ba:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc0a0bf:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0a0c2:	74 1e                	je     0x78725cc0a0e2
    78725cc0a0c4:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc0a0cb:	00 
    78725cc0a0cc:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc0a0d0:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc0a0d4:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc0a0da:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc0a0e0:	eb 35                	jmp    0x78725cc0a117
    78725cc0a0e2:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    78725cc0a0e9:	00 
    78725cc0a0ea:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    78725cc0a0f1:	00 
    78725cc0a0f2:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc0a0f7:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc0a0fb:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0a102:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc0a109:	00 
    78725cc0a10a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0a10e:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    78725cc0a115:	ff e0                	jmp    rax
    78725cc0a117:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    78725cc0a11e:	c2 08 00             	ret    0x8
