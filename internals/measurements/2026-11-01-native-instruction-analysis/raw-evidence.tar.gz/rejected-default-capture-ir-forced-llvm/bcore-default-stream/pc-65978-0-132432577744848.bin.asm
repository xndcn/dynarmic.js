
build-native-instruction-analysis/capture/bcore-default-stream/pc-65978-0-132432577744848.bin:     file format binary


Disassembly of section .data:

000078725cc0cfd0 <.data>:
    78725cc0cfd0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    78725cc0cfd7:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
    78725cc0cfdc:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0cfe3:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc0cfe8:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    78725cc0cfef:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc0cff3:	b8 11 fe fe ff       	mov    eax,0xfffefe11
    78725cc0cff8:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    78725cc0cfff:	01 c1                	add    ecx,eax
    78725cc0d001:	83 f9 ca             	cmp    ecx,0xffffffca
    78725cc0d004:	0f 87 f6 2f ff 17    	ja     0x787274c00000
    78725cc0d00a:	41 03 85 a0 00 00 00 	add    eax,DWORD PTR [r13+0xa0]
    78725cc0d011:	83 f8 ca             	cmp    eax,0xffffffca
    78725cc0d014:	0f 87 e6 2f ff 17    	ja     0x787274c00000
    78725cc0d01a:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0d021:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    78725cc0d026:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0d02d:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc0d032:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    78725cc0d036:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc0d03a:	41 8b 45 08          	mov    eax,DWORD PTR [r13+0x8]
    78725cc0d03e:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc0d043:	41 8b 45 0c          	mov    eax,DWORD PTR [r13+0xc]
    78725cc0d047:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    78725cc0d04c:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    78725cc0d050:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    78725cc0d054:	41 8b 4d 20          	mov    ecx,DWORD PTR [r13+0x20]
    78725cc0d058:	41 8b 55 24          	mov    edx,DWORD PTR [r13+0x24]
    78725cc0d05c:	41 8b 85 00 01 00 00 	mov    eax,DWORD PTR [r13+0x100]
    78725cc0d063:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    78725cc0d067:	41 8b 85 14 01 00 00 	mov    eax,DWORD PTR [r13+0x114]
    78725cc0d06e:	89 44 24 30          	mov    DWORD PTR [rsp+0x30],eax
    78725cc0d072:	4c 89 6c 24 10       	mov    QWORD PTR [rsp+0x10],r13
    78725cc0d077:	45 8b 85 5c 01 00 00 	mov    r8d,DWORD PTR [r13+0x15c]
    78725cc0d07e:	49 89 d5             	mov    r13,rdx
    78725cc0d081:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    78725cc0d088:	0f 1f 84 00 00 00 00 
    78725cc0d08f:	00 
    78725cc0d090:	44 8b 54 24 20       	mov    r10d,DWORD PTR [rsp+0x20]
    78725cc0d095:	44 89 ea             	mov    edx,r13d
    78725cc0d098:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0d09d:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
    78725cc0d0a2:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0d0a7:	89 c3                	mov    ebx,eax
    78725cc0d0a9:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    78725cc0d0ae:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0d0b3:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    78725cc0d0b8:	48 89 4c 24 50       	mov    QWORD PTR [rsp+0x50],rcx
    78725cc0d0bd:	0f 1f 00             	nop    DWORD PTR [rax]
    78725cc0d0c0:	41 89 d4             	mov    r12d,edx
    78725cc0d0c3:	31 c0                	xor    eax,eax
    78725cc0d0c5:	89 da                	mov    edx,ebx
    78725cc0d0c7:	23 54 24 0c          	and    edx,DWORD PTR [rsp+0xc]
    78725cc0d0cb:	0f 94 c0             	sete   al
    78725cc0d0ce:	89 d5                	mov    ebp,edx
    78725cc0d0d0:	c1 ed 1f             	shr    ebp,0x1f
    78725cc0d0d3:	44 8d 2c 91          	lea    r13d,[rcx+rdx*4]
    78725cc0d0d7:	41 f6 c5 03          	test   r13b,0x3
    78725cc0d0db:	0f 85 23 04 00 00    	jne    0x78725cc0d504
    78725cc0d0e1:	44 89 ee             	mov    esi,r13d
    78725cc0d0e4:	c1 ee 0c             	shr    esi,0xc
    78725cc0d0e7:	4c 8b 34 f7          	mov    r14,QWORD PTR [rdi+rsi*8]
    78725cc0d0eb:	45 89 ef             	mov    r15d,r13d
    78725cc0d0ee:	41 81 e7 ff 0f 00 00 	and    r15d,0xfff
    78725cc0d0f5:	4d 85 f6             	test   r14,r14
    78725cc0d0f8:	48 89 5c 24 38       	mov    QWORD PTR [rsp+0x38],rbx
    78725cc0d0fd:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    78725cc0d102:	4c 89 64 24 30       	mov    QWORD PTR [rsp+0x30],r12
    78725cc0d107:	0f 84 3e 05 00 00    	je     0x78725cc0d64b
    78725cc0d10d:	44 89 d5             	mov    ebp,r10d
    78725cc0d110:	47 8b 14 3e          	mov    r10d,DWORD PTR [r14+r15*1]
    78725cc0d114:	41 8d 34 1a          	lea    esi,[r10+rbx*1]
    78725cc0d118:	41 89 dd             	mov    r13d,ebx
    78725cc0d11b:	41 c1 ed 1f          	shr    r13d,0x1f
    78725cc0d11f:	44 89 d0             	mov    eax,r10d
    78725cc0d122:	c1 e8 1f             	shr    eax,0x1f
    78725cc0d125:	41 89 f4             	mov    r12d,esi
    78725cc0d128:	41 c1 ec 1f          	shr    r12d,0x1f
    78725cc0d12c:	44 31 e0             	xor    eax,r12d
    78725cc0d12f:	44 89 e1             	mov    ecx,r12d
    78725cc0d132:	44 31 e9             	xor    ecx,r13d
    78725cc0d135:	21 c1                	and    ecx,eax
    78725cc0d137:	09 e9                	or     ecx,ebp
    78725cc0d139:	89 cd                	mov    ebp,ecx
    78725cc0d13b:	89 f2                	mov    edx,esi
    78725cc0d13d:	c1 ea 0b             	shr    edx,0xb
    78725cc0d140:	31 db                	xor    ebx,ebx
    78725cc0d142:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    78725cc0d147:	31 f2                	xor    edx,esi
    78725cc0d149:	0f 94 c3             	sete   bl
    78725cc0d14c:	4d 85 f6             	test   r14,r14
    78725cc0d14f:	89 54 24 58          	mov    DWORD PTR [rsp+0x58],edx
    78725cc0d153:	0f 84 c7 05 00 00    	je     0x78725cc0d720
    78725cc0d159:	43 89 14 3e          	mov    DWORD PTR [r14+r15*1],edx
    78725cc0d15d:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0d162:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0d165:	0f 85 98 06 00 00    	jne    0x78725cc0d803
    78725cc0d16b:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    78725cc0d170:	41 8d 5c 24 01       	lea    ebx,[r12+0x1]
    78725cc0d175:	89 d8                	mov    eax,ebx
    78725cc0d177:	c1 e8 1f             	shr    eax,0x1f
    78725cc0d17a:	c4 62 10 f2 f8       	andn   r15d,r13d,eax
    78725cc0d17f:	44 09 fd             	or     ebp,r15d
    78725cc0d182:	45 31 db             	xor    r11d,r11d
    78725cc0d185:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc0d189:	39 d9                	cmp    ecx,ebx
    78725cc0d18b:	41 0f 96 c3          	setbe  r11b
    78725cc0d18f:	76 3f                	jbe    0x78725cc0d1d0
    78725cc0d191:	4d 89 d5             	mov    r13,r10
    78725cc0d194:	4d 89 c6             	mov    r14,r8
    78725cc0d197:	41 83 c0 0d          	add    r8d,0xd
    78725cc0d19b:	45 39 c8             	cmp    r8d,r9d
    78725cc0d19e:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    78725cc0d1a3:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc0d1a8:	0f 83 9b 02 00 00    	jae    0x78725cc0d449
    78725cc0d1ae:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    78725cc0d1b3:	01 c2                	add    edx,eax
    78725cc0d1b5:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
    78725cc0d1ba:	8b b6 58 01 00 00    	mov    esi,DWORD PTR [rsi+0x158]
    78725cc0d1c0:	41 89 ea             	mov    r10d,ebp
    78725cc0d1c3:	85 f6                	test   esi,esi
    78725cc0d1c5:	0f 85 f5 fe ff ff    	jne    0x78725cc0d0c0
    78725cc0d1cb:	e9 79 02 00 00       	jmp    0x78725cc0d449
    78725cc0d1d0:	c4 e2 78 f3 d9       	blsi   eax,ecx
    78725cc0d1d5:	ff c9                	dec    ecx
    78725cc0d1d7:	c1 e8 1f             	shr    eax,0x1f
    78725cc0d1da:	09 c5                	or     ebp,eax
    78725cc0d1dc:	45 31 f6             	xor    r14d,r14d
    78725cc0d1df:	41 89 c9             	mov    r9d,ecx
    78725cc0d1e2:	41 81 e1 ff 1f 00 00 	and    r9d,0x1fff
    78725cc0d1e9:	41 0f 94 c6          	sete   r14b
    78725cc0d1ed:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d1f2:	8b 58 3c             	mov    ebx,DWORD PTR [rax+0x3c]
    78725cc0d1f5:	45 01 e2             	add    r10d,r12d
    78725cc0d1f8:	41 ff c4             	inc    r12d
    78725cc0d1fb:	4c 8b 6c 24 30       	mov    r13,QWORD PTR [rsp+0x30]
    78725cc0d200:	45 01 d5             	add    r13d,r10d
    78725cc0d203:	f6 c3 03             	test   bl,0x3
    78725cc0d206:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    78725cc0d20b:	0f 85 6d 07 00 00    	jne    0x78725cc0d97e
    78725cc0d211:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    78725cc0d216:	89 6c 24 20          	mov    DWORD PTR [rsp+0x20],ebp
    78725cc0d21a:	48 89 d8             	mov    rax,rbx
    78725cc0d21d:	48 c1 e8 0c          	shr    rax,0xc
    78725cc0d221:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    78725cc0d225:	48 85 c0             	test   rax,rax
    78725cc0d228:	44 89 5c 24 30       	mov    DWORD PTR [rsp+0x30],r11d
    78725cc0d22d:	4c 89 64 24 38       	mov    QWORD PTR [rsp+0x38],r12
    78725cc0d232:	4c 89 4c 24 58       	mov    QWORD PTR [rsp+0x58],r9
    78725cc0d237:	0f 84 e2 07 00 00    	je     0x78725cc0da1f
    78725cc0d23d:	89 da                	mov    edx,ebx
    78725cc0d23f:	81 e2 ff 0f 00 00    	and    edx,0xfff
    78725cc0d245:	44 8b 3c 10          	mov    r15d,DWORD PTR [rax+rdx*1]
    78725cc0d249:	8d 73 04             	lea    esi,[rbx+0x4]
    78725cc0d24c:	89 f0                	mov    eax,esi
    78725cc0d24e:	c1 e8 0c             	shr    eax,0xc
    78725cc0d251:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    78725cc0d255:	48 85 c0             	test   rax,rax
    78725cc0d258:	0f 84 a3 08 00 00    	je     0x78725cc0db01
    78725cc0d25e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    78725cc0d264:	8b 2c 30             	mov    ebp,DWORD PTR [rax+rsi*1]
    78725cc0d267:	8d 73 08             	lea    esi,[rbx+0x8]
    78725cc0d26a:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d26f:	44 89 78 3c          	mov    DWORD PTR [rax+0x3c],r15d
    78725cc0d273:	89 a8 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],ebp
    78725cc0d279:	89 70 38             	mov    DWORD PTR [rax+0x38],esi
    78725cc0d27c:	89 f0                	mov    eax,esi
    78725cc0d27e:	c1 e8 0c             	shr    eax,0xc
    78725cc0d281:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    78725cc0d285:	48 85 c0             	test   rax,rax
    78725cc0d288:	0f 84 53 09 00 00    	je     0x78725cc0dbe1
    78725cc0d28e:	81 e6 ff 0f 00 00    	and    esi,0xfff
    78725cc0d294:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    78725cc0d297:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    78725cc0d29b:	83 c3 0c             	add    ebx,0xc
    78725cc0d29e:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d2a3:	89 58 38             	mov    DWORD PTR [rax+0x38],ebx
    78725cc0d2a6:	42 8d 0c 89          	lea    ecx,[rcx+r9*4]
    78725cc0d2aa:	f6 c1 03             	test   cl,0x3
    78725cc0d2ad:	0f 85 15 0a 00 00    	jne    0x78725cc0dcc8
    78725cc0d2b3:	89 c8                	mov    eax,ecx
    78725cc0d2b5:	c1 e8 0c             	shr    eax,0xc
    78725cc0d2b8:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
    78725cc0d2bc:	48 85 c0             	test   rax,rax
    78725cc0d2bf:	0f 84 aa 0a 00 00    	je     0x78725cc0dd6f
    78725cc0d2c5:	89 ca                	mov    edx,ecx
    78725cc0d2c7:	81 e2 ff 0f 00 00    	and    edx,0xfff
    78725cc0d2cd:	8b 14 10             	mov    edx,DWORD PTR [rax+rdx*1]
    78725cc0d2d0:	45 31 e4             	xor    r12d,r12d
    78725cc0d2d3:	44 31 ea             	xor    edx,r13d
    78725cc0d2d6:	41 0f 94 c4          	sete   r12b
    78725cc0d2da:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    78725cc0d2de:	c1 ea 1f             	shr    edx,0x1f
    78725cc0d2e1:	40 f6 c5 01          	test   bpl,0x1
    78725cc0d2e5:	0f 85 5a 0b 00 00    	jne    0x78725cc0de45
    78725cc0d2eb:	49 89 e9             	mov    r9,rbp
    78725cc0d2ee:	c6 44 24 68 01       	mov    BYTE PTR [rsp+0x68],0x1
    78725cc0d2f3:	45 31 d2             	xor    r10d,r10d
    78725cc0d2f6:	c7 44 24 50 02 00 00 	mov    DWORD PTR [rsp+0x50],0x2
    78725cc0d2fd:	00 
    78725cc0d2fe:	be 18 00 00 00       	mov    esi,0x18
    78725cc0d303:	45 31 db             	xor    r11d,r11d
    78725cc0d306:	45 31 f6             	xor    r14d,r14d
    78725cc0d309:	45 31 ff             	xor    r15d,r15d
    78725cc0d30c:	44 89 e8             	mov    eax,r13d
    78725cc0d30f:	4c 89 c3             	mov    rbx,r8
    78725cc0d312:	41 01 f0             	add    r8d,esi
    78725cc0d315:	44 3b 44 24 2c       	cmp    r8d,DWORD PTR [rsp+0x2c]
    78725cc0d31a:	0f 83 bb 05 00 00    	jae    0x78725cc0d8db
    78725cc0d320:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d325:	8b af 58 01 00 00    	mov    ebp,DWORD PTR [rdi+0x158]
    78725cc0d32b:	85 ed                	test   ebp,ebp
    78725cc0d32d:	0f 84 a8 05 00 00    	je     0x78725cc0d8db
    78725cc0d333:	4c 89 cf             	mov    rdi,r9
    78725cc0d336:	81 ff ba 01 01 00    	cmp    edi,0x101ba
    78725cc0d33c:	0f 84 4e fd ff ff    	je     0x78725cc0d090
    78725cc0d342:	48 89 bc 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rdi
    78725cc0d349:	00 
    78725cc0d34a:	8d 3c fd 00 00 00 00 	lea    edi,[rdi*8+0x0]
    78725cc0d351:	81 e7 f0 ff 0f 00    	and    edi,0xffff0
    78725cc0d357:	48 89 7c 24 70       	mov    QWORD PTR [rsp+0x70],rdi
    78725cc0d35c:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    78725cc0d361:	48 8b ac 24 80 00 00 	mov    rbp,QWORD PTR [rsp+0x80]
    78725cc0d368:	00 
    78725cc0d369:	44 89 54 24 2c       	mov    DWORD PTR [rsp+0x2c],r10d
    78725cc0d36e:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
    78725cc0d373:	42 39 2c 17          	cmp    DWORD PTR [rdi+r10*1],ebp
    78725cc0d377:	44 8b 54 24 2c       	mov    r10d,DWORD PTR [rsp+0x2c]
    78725cc0d37c:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
    78725cc0d381:	0f 85 54 05 00 00    	jne    0x78725cc0d8db
    78725cc0d387:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    78725cc0d38c:	48 8b 6c 2f 08       	mov    rbp,QWORD PTR [rdi+rbp*1+0x8]
    78725cc0d391:	4c 89 ef             	mov    rdi,r13
    78725cc0d394:	4c 8b 6c 24 10       	mov    r13,QWORD PTR [rsp+0x10]
    78725cc0d399:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    78725cc0d39d:	41 89 5d 00          	mov    DWORD PTR [r13+0x0],ebx
    78725cc0d3a1:	41 89 45 04          	mov    DWORD PTR [r13+0x4],eax
    78725cc0d3a5:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0d3aa:	41 89 45 08          	mov    DWORD PTR [r13+0x8],eax
    78725cc0d3ae:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0d3b3:	41 89 45 0c          	mov    DWORD PTR [r13+0xc],eax
    78725cc0d3b7:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0d3bb:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    78725cc0d3bf:	41 89 4d 20          	mov    DWORD PTR [r13+0x20],ecx
    78725cc0d3c3:	41 89 7d 24          	mov    DWORD PTR [r13+0x24],edi
    78725cc0d3c7:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc0d3cc:	41 89 45 28          	mov    DWORD PTR [r13+0x28],eax
    78725cc0d3d0:	45 89 8d bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r9d
    78725cc0d3d7:	45 89 a5 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],r12d
    78725cc0d3de:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    78725cc0d3e5:	45 89 bd ec 00 00 00 	mov    DWORD PTR [r13+0xec],r15d
    78725cc0d3ec:	45 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],r14d
    78725cc0d3f3:	45 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],r11d
    78725cc0d3fa:	45 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],r10d
    78725cc0d401:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0d405:	41 89 85 00 01 00 00 	mov    DWORD PTR [r13+0x100],eax
    78725cc0d40c:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc0d410:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    78725cc0d417:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc0d41b:	41 89 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],eax
    78725cc0d422:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc0d429:	00 
    78725cc0d42a:	41 89 b5 34 01 00 00 	mov    DWORD PTR [r13+0x134],esi
    78725cc0d431:	45 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],r8d
    78725cc0d438:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
    78725cc0d43d:	48 89 e8             	mov    rax,rbp
    78725cc0d440:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc0d447:	ff e0                	jmp    rax
    78725cc0d449:	45 8d 44 24 01       	lea    r8d,[r12+0x1]
    78725cc0d44e:	31 d2                	xor    edx,edx
    78725cc0d450:	45 31 c9             	xor    r9d,r9d
    78725cc0d453:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    78725cc0d457:	41 39 f0             	cmp    r8d,esi
    78725cc0d45a:	0f 96 c2             	setbe  dl
    78725cc0d45d:	41 0f 97 c1          	seta   r9b
    78725cc0d461:	45 01 e5             	add    r13d,r12d
    78725cc0d464:	41 29 f4             	sub    r12d,esi
    78725cc0d467:	31 db                	xor    ebx,ebx
    78725cc0d469:	41 83 fc ff          	cmp    r12d,0xffffffff
    78725cc0d46d:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d472:	89 37                	mov    DWORD PTR [rdi],esi
    78725cc0d474:	8b 74 24 58          	mov    esi,DWORD PTR [rsp+0x58]
    78725cc0d478:	89 77 04             	mov    DWORD PTR [rdi+0x4],esi
    78725cc0d47b:	44 89 47 08          	mov    DWORD PTR [rdi+0x8],r8d
    78725cc0d47f:	44 89 6f 0c          	mov    DWORD PTR [rdi+0xc],r13d
    78725cc0d483:	8b 74 24 0c          	mov    esi,DWORD PTR [rsp+0xc]
    78725cc0d487:	89 77 1c             	mov    DWORD PTR [rdi+0x1c],esi
    78725cc0d48a:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0d48d:	0f 94 c3             	sete   bl
    78725cc0d490:	44 01 e8             	add    eax,r13d
    78725cc0d493:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    78725cc0d496:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    78725cc0d49a:	c7 87 bc 00 00 00 ba 	mov    DWORD PTR [rdi+0xbc],0x101ba
    78725cc0d4a1:	01 01 00 
    78725cc0d4a4:	89 9f e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],ebx
    78725cc0d4aa:	44 89 8f e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r9d
    78725cc0d4b1:	89 97 ec 00 00 00    	mov    DWORD PTR [rdi+0xec],edx
    78725cc0d4b7:	89 97 f0 00 00 00    	mov    DWORD PTR [rdi+0xf0],edx
    78725cc0d4bd:	44 89 bf f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r15d
    78725cc0d4c4:	44 89 bf fc 00 00 00 	mov    DWORD PTR [rdi+0xfc],r15d
    78725cc0d4cb:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    78725cc0d4d1:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0d4d8:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0d4df:	00 00 00 
    78725cc0d4e2:	c6 87 28 01 00 00 01 	mov    BYTE PTR [rdi+0x128],0x1
    78725cc0d4e9:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    78725cc0d4f0:	00 00 00 
    78725cc0d4f3:	44 89 b7 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r14d
    78725cc0d4fa:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc0d501:	c2 08 00             	ret    0x8
    78725cc0d504:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    78725cc0d508:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d50d:	89 37                	mov    DWORD PTR [rdi],esi
    78725cc0d50f:	89 57 04             	mov    DWORD PTR [rdi+0x4],edx
    78725cc0d512:	89 5f 08             	mov    DWORD PTR [rdi+0x8],ebx
    78725cc0d515:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    78725cc0d51a:	89 57 0c             	mov    DWORD PTR [rdi+0xc],edx
    78725cc0d51d:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    78725cc0d521:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    78725cc0d524:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0d527:	44 89 67 24          	mov    DWORD PTR [rdi+0x24],r12d
    78725cc0d52b:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    78725cc0d52f:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    78725cc0d536:	01 01 00 
    78725cc0d539:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    78725cc0d53f:	89 af e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebp
    78725cc0d545:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    78725cc0d54c:	00 00 00 00 
    78725cc0d550:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    78725cc0d557:	00 00 00 00 
    78725cc0d55b:	44 89 97 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r10d
    78725cc0d562:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0d569:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0d570:	00 00 00 
    78725cc0d573:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc0d57a:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc0d581:	00 00 00 
    78725cc0d584:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    78725cc0d58b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0d592:	60 00 00 
    78725cc0d595:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    78725cc0d59a:	ba c0 01 01 00       	mov    edx,0x101c0
    78725cc0d59f:	44 89 e9             	mov    ecx,r13d
    78725cc0d5a2:	45 31 c0             	xor    r8d,r8d
    78725cc0d5a5:	ff d0                	call   rax
    78725cc0d5a7:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d5ac:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0d5b3:	88 4c 24 68          	mov    BYTE PTR [rsp+0x68],cl
    78725cc0d5b7:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d5bc:	44 8b 8f bc 00 00 00 	mov    r9d,DWORD PTR [rdi+0xbc]
    78725cc0d5c3:	8b 07                	mov    eax,DWORD PTR [rdi]
    78725cc0d5c5:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc0d5c9:	8b 47 04             	mov    eax,DWORD PTR [rdi+0x4]
    78725cc0d5cc:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
    78725cc0d5cf:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    78725cc0d5d4:	8b 4f 0c             	mov    ecx,DWORD PTR [rdi+0xc]
    78725cc0d5d7:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    78725cc0d5dc:	8b 4f 1c             	mov    ecx,DWORD PTR [rdi+0x1c]
    78725cc0d5df:	89 4c 24 0c          	mov    DWORD PTR [rsp+0xc],ecx
    78725cc0d5e3:	8b 4f 20             	mov    ecx,DWORD PTR [rdi+0x20]
    78725cc0d5e6:	44 8b 6f 24          	mov    r13d,DWORD PTR [rdi+0x24]
    78725cc0d5ea:	8b 57 28             	mov    edx,DWORD PTR [rdi+0x28]
    78725cc0d5ed:	48 89 54 24 58       	mov    QWORD PTR [rsp+0x58],rdx
    78725cc0d5f2:	44 8b a7 e4 00 00 00 	mov    r12d,DWORD PTR [rdi+0xe4]
    78725cc0d5f9:	8b 97 e8 00 00 00    	mov    edx,DWORD PTR [rdi+0xe8]
    78725cc0d5ff:	44 8b bf ec 00 00 00 	mov    r15d,DWORD PTR [rdi+0xec]
    78725cc0d606:	44 8b b7 f0 00 00 00 	mov    r14d,DWORD PTR [rdi+0xf0]
    78725cc0d60d:	44 8b 9f f8 00 00 00 	mov    r11d,DWORD PTR [rdi+0xf8]
    78725cc0d614:	44 8b 97 fc 00 00 00 	mov    r10d,DWORD PTR [rdi+0xfc]
    78725cc0d61b:	8b b7 00 01 00 00    	mov    esi,DWORD PTR [rdi+0x100]
    78725cc0d621:	89 74 24 20          	mov    DWORD PTR [rsp+0x20],esi
    78725cc0d625:	8b b7 14 01 00 00    	mov    esi,DWORD PTR [rdi+0x114]
    78725cc0d62b:	89 74 24 30          	mov    DWORD PTR [rsp+0x30],esi
    78725cc0d62f:	8b b7 24 01 00 00    	mov    esi,DWORD PTR [rdi+0x124]
    78725cc0d635:	89 74 24 50          	mov    DWORD PTR [rsp+0x50],esi
    78725cc0d639:	8b b7 34 01 00 00    	mov    esi,DWORD PTR [rdi+0x134]
    78725cc0d63f:	44 8b 87 5c 01 00 00 	mov    r8d,DWORD PTR [rdi+0x15c]
    78725cc0d646:	e9 c4 fc ff ff       	jmp    0x78725cc0d30f
    78725cc0d64b:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    78725cc0d64f:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d654:	89 37                	mov    DWORD PTR [rdi],esi
    78725cc0d656:	89 57 04             	mov    DWORD PTR [rdi+0x4],edx
    78725cc0d659:	89 5f 08             	mov    DWORD PTR [rdi+0x8],ebx
    78725cc0d65c:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
    78725cc0d661:	89 57 0c             	mov    DWORD PTR [rdi+0xc],edx
    78725cc0d664:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    78725cc0d668:	89 57 1c             	mov    DWORD PTR [rdi+0x1c],edx
    78725cc0d66b:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0d66e:	44 89 67 24          	mov    DWORD PTR [rdi+0x24],r12d
    78725cc0d672:	44 89 6f 28          	mov    DWORD PTR [rdi+0x28],r13d
    78725cc0d676:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    78725cc0d67d:	01 01 00 
    78725cc0d680:	89 87 e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],eax
    78725cc0d686:	89 af e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],ebp
    78725cc0d68c:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    78725cc0d693:	00 00 00 00 
    78725cc0d697:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    78725cc0d69e:	00 00 00 00 
    78725cc0d6a2:	44 89 d5             	mov    ebp,r10d
    78725cc0d6a5:	44 89 97 00 01 00 00 	mov    DWORD PTR [rdi+0x100],r10d
    78725cc0d6ac:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0d6b3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0d6ba:	00 00 00 
    78725cc0d6bd:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc0d6c4:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc0d6cb:	00 00 00 
    78725cc0d6ce:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    78725cc0d6d5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0d6dc:	60 00 00 
    78725cc0d6df:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0d6e4:	44 89 ee             	mov    esi,r13d
    78725cc0d6e7:	44 89 db             	mov    ebx,r11d
    78725cc0d6ea:	4d 89 c4             	mov    r12,r8
    78725cc0d6ed:	ff d0                	call   rax
    78725cc0d6ef:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0d6f4:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    78725cc0d6f9:	41 89 c2             	mov    r10d,eax
    78725cc0d6fc:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d701:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0d708:	84 c9                	test   cl,cl
    78725cc0d70a:	0f 85 a3 fe ff ff    	jne    0x78725cc0d5b3
    78725cc0d710:	4d 89 e0             	mov    r8,r12
    78725cc0d713:	41 89 db             	mov    r11d,ebx
    78725cc0d716:	48 8b 5c 24 38       	mov    rbx,QWORD PTR [rsp+0x38]
    78725cc0d71b:	e9 f4 f9 ff ff       	jmp    0x78725cc0d114
    78725cc0d720:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    78725cc0d724:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    78725cc0d729:	89 01                	mov    DWORD PTR [rcx],eax
    78725cc0d72b:	89 51 04             	mov    DWORD PTR [rcx+0x4],edx
    78725cc0d72e:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0d733:	89 41 08             	mov    DWORD PTR [rcx+0x8],eax
    78725cc0d736:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc0d73b:	89 41 0c             	mov    DWORD PTR [rcx+0xc],eax
    78725cc0d73e:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0d742:	89 41 1c             	mov    DWORD PTR [rcx+0x1c],eax
    78725cc0d745:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc0d74a:	89 41 20             	mov    DWORD PTR [rcx+0x20],eax
    78725cc0d74d:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc0d752:	89 41 24             	mov    DWORD PTR [rcx+0x24],eax
    78725cc0d755:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    78725cc0d75a:	89 71 28             	mov    DWORD PTR [rcx+0x28],esi
    78725cc0d75d:	c7 81 bc 00 00 00 ca 	mov    DWORD PTR [rcx+0xbc],0x101ca
    78725cc0d764:	01 01 00 
    78725cc0d767:	89 99 e4 00 00 00    	mov    DWORD PTR [rcx+0xe4],ebx
    78725cc0d76d:	44 89 a1 e8 00 00 00 	mov    DWORD PTR [rcx+0xe8],r12d
    78725cc0d774:	48 c7 81 ec 00 00 00 	mov    QWORD PTR [rcx+0xec],0x0
    78725cc0d77b:	00 00 00 00 
    78725cc0d77f:	48 c7 81 f8 00 00 00 	mov    QWORD PTR [rcx+0xf8],0x0
    78725cc0d786:	00 00 00 00 
    78725cc0d78a:	89 a9 00 01 00 00    	mov    DWORD PTR [rcx+0x100],ebp
    78725cc0d790:	44 89 99 14 01 00 00 	mov    DWORD PTR [rcx+0x114],r11d
    78725cc0d797:	c7 81 24 01 00 00 02 	mov    DWORD PTR [rcx+0x124],0x2
    78725cc0d79e:	00 00 00 
    78725cc0d7a1:	c6 81 28 01 00 00 00 	mov    BYTE PTR [rcx+0x128],0x0
    78725cc0d7a8:	c7 81 34 01 00 00 08 	mov    DWORD PTR [rcx+0x134],0x8
    78725cc0d7af:	00 00 00 
    78725cc0d7b2:	44 89 81 5c 01 00 00 	mov    DWORD PTR [rcx+0x15c],r8d
    78725cc0d7b9:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0d7c0:	60 00 00 
    78725cc0d7c3:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0d7c8:	4c 89 54 24 40       	mov    QWORD PTR [rsp+0x40],r10
    78725cc0d7cd:	45 89 df             	mov    r15d,r11d
    78725cc0d7d0:	4d 89 c6             	mov    r14,r8
    78725cc0d7d3:	ff d0                	call   rax
    78725cc0d7d5:	4c 8b 54 24 40       	mov    r10,QWORD PTR [rsp+0x40]
    78725cc0d7da:	4d 89 f0             	mov    r8,r14
    78725cc0d7dd:	45 89 fb             	mov    r11d,r15d
    78725cc0d7e0:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0d7e5:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    78725cc0d7ea:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d7ef:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0d7f6:	84 c9                	test   cl,cl
    78725cc0d7f8:	0f 84 5f f9 ff ff    	je     0x78725cc0d15d
    78725cc0d7fe:	e9 b0 fd ff ff       	jmp    0x78725cc0d5b3
    78725cc0d803:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    78725cc0d807:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d80c:	89 07                	mov    DWORD PTR [rdi],eax
    78725cc0d80e:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    78725cc0d812:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    78725cc0d815:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0d81a:	89 47 08             	mov    DWORD PTR [rdi+0x8],eax
    78725cc0d81d:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc0d822:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    78725cc0d825:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0d829:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    78725cc0d82c:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc0d831:	89 47 20             	mov    DWORD PTR [rdi+0x20],eax
    78725cc0d834:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc0d839:	89 47 24             	mov    DWORD PTR [rdi+0x24],eax
    78725cc0d83c:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0d841:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    78725cc0d844:	c7 87 bc 00 00 00 cc 	mov    DWORD PTR [rdi+0xbc],0x101cc
    78725cc0d84b:	01 01 00 
    78725cc0d84e:	89 9f e4 00 00 00    	mov    DWORD PTR [rdi+0xe4],ebx
    78725cc0d854:	44 89 a7 e8 00 00 00 	mov    DWORD PTR [rdi+0xe8],r12d
    78725cc0d85b:	48 c7 87 ec 00 00 00 	mov    QWORD PTR [rdi+0xec],0x0
    78725cc0d862:	00 00 00 00 
    78725cc0d866:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    78725cc0d86d:	00 00 00 00 
    78725cc0d871:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    78725cc0d877:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0d87e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0d885:	00 00 00 
    78725cc0d888:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc0d88f:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc0d896:	00 00 00 
    78725cc0d899:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    78725cc0d8a0:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0d8a7:	60 00 00 
    78725cc0d8aa:	4c 89 c3             	mov    rbx,r8
    78725cc0d8ad:	4d 89 d6             	mov    r14,r10
    78725cc0d8b0:	ff d0                	call   rax
    78725cc0d8b2:	4d 89 f2             	mov    r10,r14
    78725cc0d8b5:	49 89 d8             	mov    r8,rbx
    78725cc0d8b8:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0d8bd:	44 8b 4c 24 2c       	mov    r9d,DWORD PTR [rsp+0x2c]
    78725cc0d8c2:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0d8c7:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0d8ce:	84 c9                	test   cl,cl
    78725cc0d8d0:	0f 84 95 f8 ff ff    	je     0x78725cc0d16b
    78725cc0d8d6:	e9 d8 fc ff ff       	jmp    0x78725cc0d5b3
    78725cc0d8db:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d8e0:	8b 6c 24 1c          	mov    ebp,DWORD PTR [rsp+0x1c]
    78725cc0d8e4:	89 2f                	mov    DWORD PTR [rdi],ebp
    78725cc0d8e6:	89 47 04             	mov    DWORD PTR [rdi+0x4],eax
    78725cc0d8e9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0d8ee:	89 47 08             	mov    DWORD PTR [rdi+0x8],eax
    78725cc0d8f1:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0d8f6:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    78725cc0d8f9:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0d8fd:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    78725cc0d900:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0d903:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc0d907:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc0d90c:	89 47 28             	mov    DWORD PTR [rdi+0x28],eax
    78725cc0d90f:	44 89 8f bc 00 00 00 	mov    DWORD PTR [rdi+0xbc],r9d
    78725cc0d916:	44 89 a7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r12d
    78725cc0d91d:	89 97 e8 00 00 00    	mov    DWORD PTR [rdi+0xe8],edx
    78725cc0d923:	44 89 bf ec 00 00 00 	mov    DWORD PTR [rdi+0xec],r15d
    78725cc0d92a:	44 89 b7 f0 00 00 00 	mov    DWORD PTR [rdi+0xf0],r14d
    78725cc0d931:	44 89 9f f8 00 00 00 	mov    DWORD PTR [rdi+0xf8],r11d
    78725cc0d938:	44 89 97 fc 00 00 00 	mov    DWORD PTR [rdi+0xfc],r10d
    78725cc0d93f:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0d943:	89 87 00 01 00 00    	mov    DWORD PTR [rdi+0x100],eax
    78725cc0d949:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc0d94d:	89 87 14 01 00 00    	mov    DWORD PTR [rdi+0x114],eax
    78725cc0d953:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc0d957:	89 87 24 01 00 00    	mov    DWORD PTR [rdi+0x124],eax
    78725cc0d95d:	0f b6 44 24 68       	movzx  eax,BYTE PTR [rsp+0x68]
    78725cc0d962:	88 87 28 01 00 00    	mov    BYTE PTR [rdi+0x128],al
    78725cc0d968:	89 b7 34 01 00 00    	mov    DWORD PTR [rdi+0x134],esi
    78725cc0d96e:	89 9f 5c 01 00 00    	mov    DWORD PTR [rdi+0x15c],ebx
    78725cc0d974:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc0d97b:	c2 08 00             	ret    0x8
    78725cc0d97e:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0d983:	44 89 0f             	mov    DWORD PTR [rdi],r9d
    78725cc0d986:	44 89 6f 04          	mov    DWORD PTR [rdi+0x4],r13d
    78725cc0d98a:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc0d98e:	44 89 57 0c          	mov    DWORD PTR [rdi+0xc],r10d
    78725cc0d992:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0d996:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    78725cc0d999:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0d99c:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc0d9a0:	44 89 4f 28          	mov    DWORD PTR [rdi+0x28],r9d
    78725cc0d9a4:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    78725cc0d9ab:	01 01 00 
    78725cc0d9ae:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    78725cc0d9b5:	48 c7 87 e8 00 00 00 	mov    QWORD PTR [rdi+0xe8],0x0
    78725cc0d9bc:	00 00 00 00 
    78725cc0d9c0:	c7 87 f0 00 00 00 00 	mov    DWORD PTR [rdi+0xf0],0x0
    78725cc0d9c7:	00 00 00 
    78725cc0d9ca:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    78725cc0d9d1:	00 00 00 00 
    78725cc0d9d5:	89 af 00 01 00 00    	mov    DWORD PTR [rdi+0x100],ebp
    78725cc0d9db:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0d9e2:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0d9e9:	00 00 00 
    78725cc0d9ec:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc0d9f3:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc0d9fa:	00 00 00 
    78725cc0d9fd:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    78725cc0da04:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0da0b:	60 00 00 
    78725cc0da0e:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    78725cc0da13:	ba e2 01 01 00       	mov    edx,0x101e2
    78725cc0da18:	89 d9                	mov    ecx,ebx
    78725cc0da1a:	e9 83 fb ff ff       	jmp    0x78725cc0d5a2
    78725cc0da1f:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    78725cc0da24:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    78725cc0da27:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    78725cc0da2b:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    78725cc0da2f:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0da34:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    78725cc0da37:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0da3b:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    78725cc0da3e:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    78725cc0da41:	4d 89 ec             	mov    r12,r13
    78725cc0da44:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    78725cc0da48:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    78725cc0da4c:	c7 82 bc 00 00 00 e2 	mov    DWORD PTR [rdx+0xbc],0x101e2
    78725cc0da53:	01 01 00 
    78725cc0da56:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    78725cc0da5d:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    78725cc0da64:	00 00 00 00 
    78725cc0da68:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    78725cc0da6f:	00 00 00 
    78725cc0da72:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    78725cc0da79:	00 00 00 00 
    78725cc0da7d:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0da81:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    78725cc0da87:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    78725cc0da8e:	c7 82 24 01 00 00 04 	mov    DWORD PTR [rdx+0x124],0x4
    78725cc0da95:	00 00 00 
    78725cc0da98:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    78725cc0da9f:	c7 82 34 01 00 00 13 	mov    DWORD PTR [rdx+0x134],0x13
    78725cc0daa6:	00 00 00 
    78725cc0daa9:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    78725cc0dab0:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0dab7:	60 00 00 
    78725cc0daba:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0dabf:	89 de                	mov    esi,ebx
    78725cc0dac1:	4c 89 c5             	mov    rbp,r8
    78725cc0dac4:	ff d0                	call   rax
    78725cc0dac6:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    78725cc0dacb:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0dad0:	41 89 c7             	mov    r15d,eax
    78725cc0dad3:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0dad8:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0dadf:	84 c9                	test   cl,cl
    78725cc0dae1:	0f 85 cc fa ff ff    	jne    0x78725cc0d5b3
    78725cc0dae7:	49 89 e8             	mov    r8,rbp
    78725cc0daea:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    78725cc0daef:	4d 89 e5             	mov    r13,r12
    78725cc0daf2:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    78725cc0daf7:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    78725cc0dafc:	e9 48 f7 ff ff       	jmp    0x78725cc0d249
    78725cc0db01:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    78725cc0db06:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    78725cc0db09:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    78725cc0db0d:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    78725cc0db11:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0db16:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    78725cc0db19:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0db1d:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    78725cc0db20:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    78725cc0db23:	4d 89 ec             	mov    r12,r13
    78725cc0db26:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    78725cc0db2a:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    78725cc0db2e:	c7 82 bc 00 00 00 e2 	mov    DWORD PTR [rdx+0xbc],0x101e2
    78725cc0db35:	01 01 00 
    78725cc0db38:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    78725cc0db3f:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    78725cc0db46:	00 00 00 00 
    78725cc0db4a:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    78725cc0db51:	00 00 00 
    78725cc0db54:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    78725cc0db5b:	00 00 00 00 
    78725cc0db5f:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0db63:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    78725cc0db69:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    78725cc0db70:	c7 82 24 01 00 00 04 	mov    DWORD PTR [rdx+0x124],0x4
    78725cc0db77:	00 00 00 
    78725cc0db7a:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    78725cc0db81:	c7 82 34 01 00 00 13 	mov    DWORD PTR [rdx+0x134],0x13
    78725cc0db88:	00 00 00 
    78725cc0db8b:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    78725cc0db92:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0db99:	60 00 00 
    78725cc0db9c:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0dba1:	4c 89 c5             	mov    rbp,r8
    78725cc0dba4:	ff d0                	call   rax
    78725cc0dba6:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    78725cc0dbab:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0dbb0:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    78725cc0dbb5:	0f b6 89 28 01 00 00 	movzx  ecx,BYTE PTR [rcx+0x128]
    78725cc0dbbc:	84 c9                	test   cl,cl
    78725cc0dbbe:	0f 85 ef f9 ff ff    	jne    0x78725cc0d5b3
    78725cc0dbc4:	49 89 e8             	mov    r8,rbp
    78725cc0dbc7:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    78725cc0dbcc:	4d 89 e5             	mov    r13,r12
    78725cc0dbcf:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    78725cc0dbd4:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    78725cc0dbd9:	48 89 c5             	mov    rbp,rax
    78725cc0dbdc:	e9 86 f6 ff ff       	jmp    0x78725cc0d267
    78725cc0dbe1:	49 89 ef             	mov    r15,rbp
    78725cc0dbe4:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    78725cc0dbe9:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    78725cc0dbec:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    78725cc0dbf0:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    78725cc0dbf4:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0dbf9:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    78725cc0dbfc:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0dc00:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    78725cc0dc03:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    78725cc0dc06:	4d 89 ec             	mov    r12,r13
    78725cc0dc09:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    78725cc0dc0d:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    78725cc0dc11:	c7 82 bc 00 00 00 e6 	mov    DWORD PTR [rdx+0xbc],0x101e6
    78725cc0dc18:	01 01 00 
    78725cc0dc1b:	44 89 b2 e4 00 00 00 	mov    DWORD PTR [rdx+0xe4],r14d
    78725cc0dc22:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    78725cc0dc29:	00 00 00 00 
    78725cc0dc2d:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    78725cc0dc34:	00 00 00 
    78725cc0dc37:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    78725cc0dc3e:	00 00 00 00 
    78725cc0dc42:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0dc46:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    78725cc0dc4c:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    78725cc0dc53:	c7 82 24 01 00 00 02 	mov    DWORD PTR [rdx+0x124],0x2
    78725cc0dc5a:	00 00 00 
    78725cc0dc5d:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    78725cc0dc64:	c7 82 34 01 00 00 14 	mov    DWORD PTR [rdx+0x134],0x14
    78725cc0dc6b:	00 00 00 
    78725cc0dc6e:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    78725cc0dc75:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0dc7c:	60 00 00 
    78725cc0dc7f:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0dc84:	4c 89 c5             	mov    rbp,r8
    78725cc0dc87:	ff d0                	call   rax
    78725cc0dc89:	44 8b 5c 24 30       	mov    r11d,DWORD PTR [rsp+0x30]
    78725cc0dc8e:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc0dc93:	89 44 24 0c          	mov    DWORD PTR [rsp+0xc],eax
    78725cc0dc97:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
    78725cc0dc9c:	0f b6 88 28 01 00 00 	movzx  ecx,BYTE PTR [rax+0x128]
    78725cc0dca3:	84 c9                	test   cl,cl
    78725cc0dca5:	0f 85 08 f9 ff ff    	jne    0x78725cc0d5b3
    78725cc0dcab:	49 89 e8             	mov    r8,rbp
    78725cc0dcae:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
    78725cc0dcb3:	4d 89 e5             	mov    r13,r12
    78725cc0dcb6:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
    78725cc0dcbb:	4c 8b 4c 24 58       	mov    r9,QWORD PTR [rsp+0x58]
    78725cc0dcc0:	4c 89 fd             	mov    rbp,r15
    78725cc0dcc3:	e9 d3 f5 ff ff       	jmp    0x78725cc0d29b
    78725cc0dcc8:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
    78725cc0dccd:	44 89 0f             	mov    DWORD PTR [rdi],r9d
    78725cc0dcd0:	44 89 6f 04          	mov    DWORD PTR [rdi+0x4],r13d
    78725cc0dcd4:	44 89 67 08          	mov    DWORD PTR [rdi+0x8],r12d
    78725cc0dcd8:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0dcdd:	89 47 0c             	mov    DWORD PTR [rdi+0xc],eax
    78725cc0dce0:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0dce4:	89 47 1c             	mov    DWORD PTR [rdi+0x1c],eax
    78725cc0dce7:	89 4f 20             	mov    DWORD PTR [rdi+0x20],ecx
    78725cc0dcea:	44 89 6f 24          	mov    DWORD PTR [rdi+0x24],r13d
    78725cc0dcee:	44 89 4f 28          	mov    DWORD PTR [rdi+0x28],r9d
    78725cc0dcf2:	c7 87 bc 00 00 00 ea 	mov    DWORD PTR [rdi+0xbc],0x101ea
    78725cc0dcf9:	01 01 00 
    78725cc0dcfc:	44 89 b7 e4 00 00 00 	mov    DWORD PTR [rdi+0xe4],r14d
    78725cc0dd03:	48 c7 87 e8 00 00 00 	mov    QWORD PTR [rdi+0xe8],0x0
    78725cc0dd0a:	00 00 00 00 
    78725cc0dd0e:	c7 87 f0 00 00 00 00 	mov    DWORD PTR [rdi+0xf0],0x0
    78725cc0dd15:	00 00 00 
    78725cc0dd18:	48 c7 87 f8 00 00 00 	mov    QWORD PTR [rdi+0xf8],0x0
    78725cc0dd1f:	00 00 00 00 
    78725cc0dd23:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0dd27:	89 87 00 01 00 00    	mov    DWORD PTR [rdi+0x100],eax
    78725cc0dd2d:	44 89 9f 14 01 00 00 	mov    DWORD PTR [rdi+0x114],r11d
    78725cc0dd34:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0dd3b:	00 00 00 
    78725cc0dd3e:	c6 87 28 01 00 00 00 	mov    BYTE PTR [rdi+0x128],0x0
    78725cc0dd45:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    78725cc0dd4c:	00 00 00 
    78725cc0dd4f:	44 89 87 5c 01 00 00 	mov    DWORD PTR [rdi+0x15c],r8d
    78725cc0dd56:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0dd5d:	60 00 00 
    78725cc0dd60:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
    78725cc0dd65:	ba ea 01 01 00       	mov    edx,0x101ea
    78725cc0dd6a:	e9 33 f8 ff ff       	jmp    0x78725cc0d5a2
    78725cc0dd6f:	49 89 ef             	mov    r15,rbp
    78725cc0dd72:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
    78725cc0dd77:	44 89 0a             	mov    DWORD PTR [rdx],r9d
    78725cc0dd7a:	44 89 6a 04          	mov    DWORD PTR [rdx+0x4],r13d
    78725cc0dd7e:	44 89 62 08          	mov    DWORD PTR [rdx+0x8],r12d
    78725cc0dd82:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0dd87:	89 42 0c             	mov    DWORD PTR [rdx+0xc],eax
    78725cc0dd8a:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0dd8e:	89 42 1c             	mov    DWORD PTR [rdx+0x1c],eax
    78725cc0dd91:	89 4a 20             	mov    DWORD PTR [rdx+0x20],ecx
    78725cc0dd94:	44 89 f0             	mov    eax,r14d
    78725cc0dd97:	4d 89 ee             	mov    r14,r13
    78725cc0dd9a:	44 89 6a 24          	mov    DWORD PTR [rdx+0x24],r13d
    78725cc0dd9e:	44 89 4a 28          	mov    DWORD PTR [rdx+0x28],r9d
    78725cc0dda2:	c7 82 bc 00 00 00 ea 	mov    DWORD PTR [rdx+0xbc],0x101ea
    78725cc0dda9:	01 01 00 
    78725cc0ddac:	89 82 e4 00 00 00    	mov    DWORD PTR [rdx+0xe4],eax
    78725cc0ddb2:	48 c7 82 e8 00 00 00 	mov    QWORD PTR [rdx+0xe8],0x0
    78725cc0ddb9:	00 00 00 00 
    78725cc0ddbd:	c7 82 f0 00 00 00 00 	mov    DWORD PTR [rdx+0xf0],0x0
    78725cc0ddc4:	00 00 00 
    78725cc0ddc7:	48 c7 82 f8 00 00 00 	mov    QWORD PTR [rdx+0xf8],0x0
    78725cc0ddce:	00 00 00 00 
    78725cc0ddd2:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0ddd6:	89 82 00 01 00 00    	mov    DWORD PTR [rdx+0x100],eax
    78725cc0dddc:	44 89 9a 14 01 00 00 	mov    DWORD PTR [rdx+0x114],r11d
    78725cc0dde3:	c7 82 24 01 00 00 02 	mov    DWORD PTR [rdx+0x124],0x2
    78725cc0ddea:	00 00 00 
    78725cc0dded:	c6 82 28 01 00 00 00 	mov    BYTE PTR [rdx+0x128],0x0
    78725cc0ddf4:	c7 82 34 01 00 00 16 	mov    DWORD PTR [rdx+0x134],0x16
    78725cc0ddfb:	00 00 00 
    78725cc0ddfe:	44 89 82 5c 01 00 00 	mov    DWORD PTR [rdx+0x15c],r8d
    78725cc0de05:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0de0c:	60 00 00 
    78725cc0de0f:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
    78725cc0de14:	48 89 cd             	mov    rbp,rcx
    78725cc0de17:	89 ce                	mov    esi,ecx
    78725cc0de19:	4c 89 c3             	mov    rbx,r8
    78725cc0de1c:	ff d0                	call   rax
    78725cc0de1e:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
    78725cc0de23:	0f b6 89 28 01 00 00 	movzx  ecx,BYTE PTR [rcx+0x128]
    78725cc0de2a:	84 c9                	test   cl,cl
    78725cc0de2c:	0f 85 81 f7 ff ff    	jne    0x78725cc0d5b3
    78725cc0de32:	49 89 d8             	mov    r8,rbx
    78725cc0de35:	48 89 e9             	mov    rcx,rbp
    78725cc0de38:	4d 89 f5             	mov    r13,r14
    78725cc0de3b:	89 c2                	mov    edx,eax
    78725cc0de3d:	4c 89 fd             	mov    rbp,r15
    78725cc0de40:	e9 8b f4 ff ff       	jmp    0x78725cc0d2d0
    78725cc0de45:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    78725cc0de4a:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    78725cc0de4e:	89 03                	mov    DWORD PTR [rbx],eax
    78725cc0de50:	44 89 6b 04          	mov    DWORD PTR [rbx+0x4],r13d
    78725cc0de54:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0de59:	89 43 08             	mov    DWORD PTR [rbx+0x8],eax
    78725cc0de5c:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc0de61:	89 43 0c             	mov    DWORD PTR [rbx+0xc],eax
    78725cc0de64:	8b 44 24 0c          	mov    eax,DWORD PTR [rsp+0xc]
    78725cc0de68:	89 43 1c             	mov    DWORD PTR [rbx+0x1c],eax
    78725cc0de6b:	89 4b 20             	mov    DWORD PTR [rbx+0x20],ecx
    78725cc0de6e:	44 89 6b 24          	mov    DWORD PTR [rbx+0x24],r13d
    78725cc0de72:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc0de77:	89 43 28             	mov    DWORD PTR [rbx+0x28],eax
    78725cc0de7a:	c7 83 bc 00 00 00 ee 	mov    DWORD PTR [rbx+0xbc],0x101ee
    78725cc0de81:	01 01 00 
    78725cc0de84:	44 89 a3 e4 00 00 00 	mov    DWORD PTR [rbx+0xe4],r12d
    78725cc0de8b:	89 93 e8 00 00 00    	mov    DWORD PTR [rbx+0xe8],edx
    78725cc0de91:	48 c7 83 ec 00 00 00 	mov    QWORD PTR [rbx+0xec],0x0
    78725cc0de98:	00 00 00 00 
    78725cc0de9c:	48 c7 83 f8 00 00 00 	mov    QWORD PTR [rbx+0xf8],0x0
    78725cc0dea3:	00 00 00 00 
    78725cc0dea7:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    78725cc0deab:	89 83 00 01 00 00    	mov    DWORD PTR [rbx+0x100],eax
    78725cc0deb1:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc0deb5:	89 83 14 01 00 00    	mov    DWORD PTR [rbx+0x114],eax
    78725cc0debb:	c7 83 24 01 00 00 02 	mov    DWORD PTR [rbx+0x124],0x2
    78725cc0dec2:	00 00 00 
    78725cc0dec5:	c6 83 28 01 00 00 00 	mov    BYTE PTR [rbx+0x128],0x0
    78725cc0decc:	c7 83 34 01 00 00 18 	mov    DWORD PTR [rbx+0x134],0x18
    78725cc0ded3:	00 00 00 
    78725cc0ded6:	44 89 83 5c 01 00 00 	mov    DWORD PTR [rbx+0x15c],r8d
    78725cc0dedd:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc0dee4:	60 00 00 
    78725cc0dee7:	48 89 df             	mov    rdi,rbx
    78725cc0deea:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc0deef:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    78725cc0def4:	ff d0                	call   rax
    78725cc0def6:	0f b6 8b 28 01 00 00 	movzx  ecx,BYTE PTR [rbx+0x128]
    78725cc0defd:	e9 b1 f6 ff ff       	jmp    0x78725cc0d5b3
