
build-native-instruction-analysis/capture/bcore-default-stream/pc-65542-0-132432577759584.bin:     file format binary


Disassembly of section .data:

000078725cc10960 <.data>:
    78725cc10960:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    78725cc10967:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    78725cc1096c:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    78725cc10971:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc10978:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc1097d:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc10984:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    78725cc10989:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc10990:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc10997:	00 
    78725cc10998:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc1099d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc109a3:	83 fa 00             	cmp    edx,0x0
    78725cc109a6:	0f 94 c0             	sete   al
    78725cc109a9:	81 ea 06 00 01 00    	sub    edx,0x10006
    78725cc109af:	83 fa 0a             	cmp    edx,0xa
    78725cc109b2:	0f 97 c2             	seta   dl
    78725cc109b5:	08 d0                	or     al,dl
    78725cc109b7:	24 01                	and    al,0x1
    78725cc109b9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc109bf:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc109c5:	0f 94 c1             	sete   cl
    78725cc109c8:	81 ea 06 00 01 00    	sub    edx,0x10006
    78725cc109ce:	83 fa 0a             	cmp    edx,0xa
    78725cc109d1:	0f 97 c2             	seta   dl
    78725cc109d4:	08 d1                	or     cl,dl
    78725cc109d6:	20 c8                	and    al,cl
    78725cc109d8:	a8 01                	test   al,0x1
    78725cc109da:	75 05                	jne    0x78725cc109e1
    78725cc109dc:	e9 75 02 00 00       	jmp    0x78725cc10c56
    78725cc109e1:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc109e6:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc109ed:	48 89 c8             	mov    rax,rcx
    78725cc109f0:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc109f6:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc109fb:	8b 81 3c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10003c]
    78725cc10a01:	83 c0 01             	add    eax,0x1
    78725cc10a04:	89 81 3c 00 10 00    	mov    DWORD PTR [rcx+0x10003c],eax
    78725cc10a0a:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc10a0f:	75 40                	jne    0x78725cc10a51
    78725cc10a11:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    78725cc10a16:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc10a1c:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc10a20:	89 c2                	mov    edx,eax
    78725cc10a22:	83 c2 01             	add    edx,0x1
    78725cc10a25:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc10a2b:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc10a30:	73 1d                	jae    0x78725cc10a4f
    78725cc10a32:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc10a37:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    78725cc10a3b:	89 c9                	mov    ecx,ecx
    78725cc10a3d:	48 c1 e1 02          	shl    rcx,0x2
    78725cc10a41:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc10a48:	c7 04 08 0f 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xf
    78725cc10a4f:	eb 00                	jmp    0x78725cc10a51
    78725cc10a51:	eb 00                	jmp    0x78725cc10a53
    78725cc10a53:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10a58:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    78725cc10a5b:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc10a61:	81 c9 00 00 00 01    	or     ecx,0x1000000
    78725cc10a67:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc10a6b:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc10a6e:	eb 00                	jmp    0x78725cc10a70
    78725cc10a70:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10a75:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    78725cc10a79:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc10a7f:	83 c9 04             	or     ecx,0x4
    78725cc10a82:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    78725cc10a86:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc10a89:	eb 00                	jmp    0x78725cc10a8b
    78725cc10a8b:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    78725cc10a8f:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc10a94:	8b 09                	mov    ecx,DWORD PTR [rcx]
    78725cc10a96:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc10a9a:	83 e0 03             	and    eax,0x3
    78725cc10a9d:	83 f8 00             	cmp    eax,0x0
    78725cc10aa0:	74 69                	je     0x78725cc10b0b
    78725cc10aa2:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc10aa7:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc10aab:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    78725cc10ab0:	c7 87 bc 00 00 00 0e 	mov    DWORD PTR [rdi+0xbc],0x1000e
    78725cc10ab7:	00 01 00 
    78725cc10aba:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc10ac1:	00 00 00 
    78725cc10ac4:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc10acb:	00 00 00 
    78725cc10ace:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc10ad5:	60 00 00 
    78725cc10ad8:	ba 0e 00 01 00       	mov    edx,0x1000e
    78725cc10add:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc10ae3:	ff d0                	call   rax
    78725cc10ae5:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10aea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc10af0:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc10af5:	b8 02 00 00 00       	mov    eax,0x2
    78725cc10afa:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc10afe:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc10b02:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc10b06:	e9 dd 01 00 00       	jmp    0x78725cc10ce8
    78725cc10b0b:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc10b12:	00 
    78725cc10b13:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc10b17:	c1 e9 0c             	shr    ecx,0xc
    78725cc10b1a:	89 c9                	mov    ecx,ecx
    78725cc10b1c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc10b20:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    78725cc10b25:	48 83 f8 00          	cmp    rax,0x0
    78725cc10b29:	74 1a                	je     0x78725cc10b45
    78725cc10b2b:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc10b30:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    78725cc10b34:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    78725cc10b38:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc10b3e:	89 c9                	mov    ecx,ecx
    78725cc10b40:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc10b43:	eb 4c                	jmp    0x78725cc10b91
    78725cc10b45:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10b4a:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    78725cc10b4e:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    78725cc10b52:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    78725cc10b57:	c7 80 bc 00 00 00 0e 	mov    DWORD PTR [rax+0xbc],0x1000e
    78725cc10b5e:	00 01 00 
    78725cc10b61:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc10b68:	00 00 00 
    78725cc10b6b:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    78725cc10b72:	00 00 00 
    78725cc10b75:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc10b7c:	60 00 00 
    78725cc10b7f:	ff d0                	call   rax
    78725cc10b81:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10b86:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc10b8d:	75 0e                	jne    0x78725cc10b9d
    78725cc10b8f:	eb 32                	jmp    0x78725cc10bc3
    78725cc10b91:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    78725cc10b96:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc10b99:	75 2a                	jne    0x78725cc10bc5
    78725cc10b9b:	eb 67                	jmp    0x78725cc10c04
    78725cc10b9d:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10ba2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc10ba8:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc10bad:	b8 02 00 00 00       	mov    eax,0x2
    78725cc10bb2:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc10bb6:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc10bba:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc10bbe:	e9 25 01 00 00       	jmp    0x78725cc10ce8
    78725cc10bc3:	eb cc                	jmp    0x78725cc10b91
    78725cc10bc5:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    78725cc10bca:	c7 87 bc 00 00 00 10 	mov    DWORD PTR [rdi+0xbc],0x10010
    78725cc10bd1:	00 01 00 
    78725cc10bd4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc10bdb:	00 00 00 
    78725cc10bde:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    78725cc10be5:	00 00 00 
    78725cc10be8:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc10bef:	60 00 00 
    78725cc10bf2:	ff d0                	call   rax
    78725cc10bf4:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10bf9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc10c00:	75 04                	jne    0x78725cc10c06
    78725cc10c02:	eb 28                	jmp    0x78725cc10c2c
    78725cc10c04:	eb 28                	jmp    0x78725cc10c2e
    78725cc10c06:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10c0b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc10c11:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc10c16:	b8 02 00 00 00       	mov    eax,0x2
    78725cc10c1b:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    78725cc10c1f:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    78725cc10c23:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    78725cc10c27:	e9 bc 00 00 00       	jmp    0x78725cc10ce8
    78725cc10c2c:	eb d6                	jmp    0x78725cc10c04
    78725cc10c2e:	eb 00                	jmp    0x78725cc10c30
    78725cc10c30:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc10c35:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10010
    78725cc10c3c:	00 01 00 
    78725cc10c3f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc10c45:	83 c0 04             	add    eax,0x4
    78725cc10c48:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    78725cc10c4c:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc10c52:	72 13                	jb     0x78725cc10c67
    78725cc10c54:	eb 31                	jmp    0x78725cc10c87
    78725cc10c56:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10c5b:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc10c62:	e9 26 01 00 00       	jmp    0x78725cc10d8d
    78725cc10c67:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc10c6c:	48 89 c1             	mov    rcx,rax
    78725cc10c6f:	48 81 c1 80 00 08 00 	add    rcx,0x80080
    78725cc10c76:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    78725cc10c7b:	81 b8 80 00 08 00 10 	cmp    DWORD PTR [rax+0x80080],0x10010
    78725cc10c82:	00 01 00 
    78725cc10c85:	74 2f                	je     0x78725cc10cb6
    78725cc10c87:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10c8c:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10010
    78725cc10c93:	00 01 00 
    78725cc10c96:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc10c9d:	00 00 00 
    78725cc10ca0:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc10ca7:	00 00 00 
    78725cc10caa:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc10cb1:	e9 d7 00 00 00       	jmp    0x78725cc10d8d
    78725cc10cb6:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    78725cc10cbb:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    78725cc10cc0:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    78725cc10cc5:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc10cc9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    78725cc10cd0:	10 00 01 00 
    78725cc10cd4:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc10cdb:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc10cdf:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc10ce6:	ff e0                	jmp    rax
    78725cc10ce8:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    78725cc10ced:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    78725cc10cf1:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    78725cc10cf5:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc10cf9:	89 c7                	mov    edi,eax
    78725cc10cfb:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    78725cc10cff:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    78725cc10d03:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    78725cc10d07:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc10d0d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    78725cc10d11:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc10d17:	73 2a                	jae    0x78725cc10d43
    78725cc10d19:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc10d1e:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc10d22:	89 d1                	mov    ecx,edx
    78725cc10d24:	c1 e9 01             	shr    ecx,0x1
    78725cc10d27:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc10d2d:	89 c9                	mov    ecx,ecx
    78725cc10d2f:	48 c1 e1 04          	shl    rcx,0x4
    78725cc10d33:	48 89 c6             	mov    rsi,rax
    78725cc10d36:	48 01 ce             	add    rsi,rcx
    78725cc10d39:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc10d3e:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc10d41:	74 1b                	je     0x78725cc10d5e
    78725cc10d43:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc10d48:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    78725cc10d4c:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc10d50:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    78725cc10d56:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    78725cc10d5c:	eb 2f                	jmp    0x78725cc10d8d
    78725cc10d5e:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    78725cc10d63:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    78725cc10d68:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc10d6d:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    78725cc10d71:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc10d78:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc10d7f:	00 
    78725cc10d80:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc10d84:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc10d8b:	ff e0                	jmp    rax
    78725cc10d8d:	48 81 c4 88 00 00 00 	add    rsp,0x88
    78725cc10d94:	c2 08 00             	ret    0x8
