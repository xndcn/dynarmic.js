
build-native-instruction-analysis/capture/bcore-default-stream/pc-65536-0-132432577691680.bin:     file format binary


Disassembly of section .data:

000078725cc00020 <.data>:
    78725cc00020:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    78725cc00025:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    78725cc0002a:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc00031:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    78725cc00036:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    78725cc0003b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc00041:	83 fa 00             	cmp    edx,0x0
    78725cc00044:	0f 94 c0             	sete   al
    78725cc00047:	81 ea 00 00 01 00    	sub    edx,0x10000
    78725cc0004d:	83 fa 02             	cmp    edx,0x2
    78725cc00050:	0f 97 c2             	seta   dl
    78725cc00053:	08 d0                	or     al,dl
    78725cc00055:	24 01                	and    al,0x1
    78725cc00057:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0005d:	83 fa 00             	cmp    edx,0x0
    78725cc00060:	0f 94 c1             	sete   cl
    78725cc00063:	81 ea 00 00 01 00    	sub    edx,0x10000
    78725cc00069:	83 fa 02             	cmp    edx,0x2
    78725cc0006c:	0f 97 c2             	seta   dl
    78725cc0006f:	08 d1                	or     cl,dl
    78725cc00071:	20 c8                	and    al,cl
    78725cc00073:	a8 01                	test   al,0x1
    78725cc00075:	75 05                	jne    0x78725cc0007c
    78725cc00077:	e9 16 01 00 00       	jmp    0x78725cc00192
    78725cc0007c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    78725cc00081:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc00088:	48 89 c8             	mov    rax,rcx
    78725cc0008b:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc00091:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    78725cc00096:	8b 81 00 00 10 00    	mov    eax,DWORD PTR [rcx+0x100000]
    78725cc0009c:	83 c0 01             	add    eax,0x1
    78725cc0009f:	89 81 00 00 10 00    	mov    DWORD PTR [rcx+0x100000],eax
    78725cc000a5:	3d 30 75 00 00       	cmp    eax,0x7530
    78725cc000aa:	75 40                	jne    0x78725cc000ec
    78725cc000ac:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    78725cc000b1:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc000b7:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    78725cc000bb:	89 c2                	mov    edx,eax
    78725cc000bd:	83 c2 01             	add    edx,0x1
    78725cc000c0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc000c6:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc000cb:	73 1d                	jae    0x78725cc000ea
    78725cc000cd:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    78725cc000d2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    78725cc000d6:	89 c9                	mov    ecx,ecx
    78725cc000d8:	48 c1 e1 02          	shl    rcx,0x2
    78725cc000dc:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc000e3:	c7 04 08 00 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x0
    78725cc000ea:	eb 00                	jmp    0x78725cc000ec
    78725cc000ec:	eb 00                	jmp    0x78725cc000ee
    78725cc000ee:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    78725cc000f3:	8b 48 38             	mov    ecx,DWORD PTR [rax+0x38]
    78725cc000f6:	83 c1 f4             	add    ecx,0xfffffff4
    78725cc000f9:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc000fc:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    78725cc00102:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    78725cc00106:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    78725cc0010c:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    78725cc00110:	eb 00                	jmp    0x78725cc00112
    78725cc00112:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    78725cc00117:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    78725cc0011b:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    78725cc0011f:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    78725cc00125:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    78725cc0012b:	83 ff 01             	cmp    edi,0x1
    78725cc0012e:	0f 97 c3             	seta   bl
    78725cc00131:	3d 02 00 01 00       	cmp    eax,0x10002
    78725cc00136:	0f 94 c0             	sete   al
    78725cc00139:	20 c3                	and    bl,al
    78725cc0013b:	b8 06 00 01 00       	mov    eax,0x10006
    78725cc00140:	f6 c3 01             	test   bl,0x1
    78725cc00143:	0f 45 c2             	cmovne eax,edx
    78725cc00146:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    78725cc0014c:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    78725cc00152:	83 ff 01             	cmp    edi,0x1
    78725cc00155:	0f 97 c3             	seta   bl
    78725cc00158:	81 fe 02 00 01 00    	cmp    esi,0x10002
    78725cc0015e:	40 0f 94 c6          	sete   sil
    78725cc00162:	40 20 f3             	and    bl,sil
    78725cc00165:	f6 c3 01             	test   bl,0x1
    78725cc00168:	0f 45 c2             	cmovne eax,edx
    78725cc0016b:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    78725cc00171:	c7 81 bc 00 00 00 14 	mov    DWORD PTR [rcx+0xbc],0x10014
    78725cc00178:	00 01 00 
    78725cc0017b:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc00181:	83 c0 02             	add    eax,0x2
    78725cc00184:	89 44 24 d0          	mov    DWORD PTR [rsp-0x30],eax
    78725cc00188:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0018e:	72 10                	jb     0x78725cc001a0
    78725cc00190:	eb 2e                	jmp    0x78725cc001c0
    78725cc00192:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    78725cc00197:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc0019e:	eb 77                	jmp    0x78725cc00217
    78725cc001a0:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    78725cc001a5:	48 89 c1             	mov    rcx,rax
    78725cc001a8:	48 81 c1 a0 00 08 00 	add    rcx,0x800a0
    78725cc001af:	48 89 4c 24 c8       	mov    QWORD PTR [rsp-0x38],rcx
    78725cc001b4:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    78725cc001bb:	00 01 00 
    78725cc001be:	74 2c                	je     0x78725cc001ec
    78725cc001c0:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    78725cc001c5:	c7 80 bc 00 00 00 14 	mov    DWORD PTR [rax+0xbc],0x10014
    78725cc001cc:	00 01 00 
    78725cc001cf:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc001d6:	00 00 00 
    78725cc001d9:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc001e0:	00 00 00 
    78725cc001e3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc001ea:	eb 2b                	jmp    0x78725cc00217
    78725cc001ec:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    78725cc001f1:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    78725cc001f6:	48 8b 44 24 c8       	mov    rax,QWORD PTR [rsp-0x38]
    78725cc001fb:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    78725cc001ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    78725cc00206:	14 00 01 00 
    78725cc0020a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc00211:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc00215:	ff e0                	jmp    rax
    78725cc00217:	c2 08 00             	ret    0x8
