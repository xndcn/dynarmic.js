
build-native-instruction-analysis/capture/bcore-default-stream/pc-65978-0-132432577739904.bin:     file format binary


Disassembly of section .data:

000078725cc0bc80 <.data>:
    78725cc0bc80:	48 81 ec 38 01 00 00 	sub    rsp,0x138
    78725cc0bc87:	4c 89 b4 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r14
    78725cc0bc8e:	00 
    78725cc0bc8f:	4c 89 ac 24 18 01 00 	mov    QWORD PTR [rsp+0x118],r13
    78725cc0bc96:	00 
    78725cc0bc97:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc0bc9e:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    78725cc0bca5:	00 
    78725cc0bca6:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc0bcad:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    78725cc0bcb4:	00 
    78725cc0bcb5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc0bcbc:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    78725cc0bcc3:	00 
    78725cc0bcc4:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
    78725cc0bccb:	00 
    78725cc0bccc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc0bcd2:	83 fa 00             	cmp    edx,0x0
    78725cc0bcd5:	0f 94 c0             	sete   al
    78725cc0bcd8:	81 ea ba 01 01 00    	sub    edx,0x101ba
    78725cc0bcde:	83 fa 34             	cmp    edx,0x34
    78725cc0bce1:	0f 97 c2             	seta   dl
    78725cc0bce4:	08 d0                	or     al,dl
    78725cc0bce6:	24 01                	and    al,0x1
    78725cc0bce8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc0bcee:	81 fa 9e 03 01 00    	cmp    edx,0x1039e
    78725cc0bcf4:	0f 94 c1             	sete   cl
    78725cc0bcf7:	81 ea ba 01 01 00    	sub    edx,0x101ba
    78725cc0bcfd:	83 fa 34             	cmp    edx,0x34
    78725cc0bd00:	0f 97 c2             	seta   dl
    78725cc0bd03:	08 d1                	or     cl,dl
    78725cc0bd05:	20 c8                	and    al,cl
    78725cc0bd07:	a8 01                	test   al,0x1
    78725cc0bd09:	75 05                	jne    0x78725cc0bd10
    78725cc0bd0b:	e9 16 11 00 00       	jmp    0x78725cc0ce26
    78725cc0bd10:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bd17:	00 
    78725cc0bd18:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc0bd1f:	48 89 c8             	mov    rax,rcx
    78725cc0bd22:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc0bd28:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    78725cc0bd2f:	00 
    78725cc0bd30:	8b 81 30 00 10 00    	mov    eax,DWORD PTR [rcx+0x100030]
    78725cc0bd36:	83 c0 01             	add    eax,0x1
    78725cc0bd39:	89 81 30 00 10 00    	mov    DWORD PTR [rcx+0x100030],eax
    78725cc0bd3f:	3d c8 af 00 00       	cmp    eax,0xafc8
    78725cc0bd44:	75 4c                	jne    0x78725cc0bd92
    78725cc0bd46:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    78725cc0bd4d:	00 
    78725cc0bd4e:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc0bd54:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    78725cc0bd5b:	89 c2                	mov    edx,eax
    78725cc0bd5d:	83 c2 01             	add    edx,0x1
    78725cc0bd60:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc0bd66:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc0bd6b:	73 23                	jae    0x78725cc0bd90
    78725cc0bd6d:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    78725cc0bd74:	00 
    78725cc0bd75:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    78725cc0bd7c:	89 c9                	mov    ecx,ecx
    78725cc0bd7e:	48 c1 e1 02          	shl    rcx,0x2
    78725cc0bd82:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc0bd89:	c7 04 08 0c 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xc
    78725cc0bd90:	eb 00                	jmp    0x78725cc0bd92
    78725cc0bd92:	eb 00                	jmp    0x78725cc0bd94
    78725cc0bd94:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bd9b:	00 
    78725cc0bd9c:	8b 48 08             	mov    ecx,DWORD PTR [rax+0x8]
    78725cc0bd9f:	89 8c 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],ecx
    78725cc0bda6:	23 48 1c             	and    ecx,DWORD PTR [rax+0x1c]
    78725cc0bda9:	89 8c 24 00 01 00 00 	mov    DWORD PTR [rsp+0x100],ecx
    78725cc0bdb0:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0bdb3:	83 f9 00             	cmp    ecx,0x0
    78725cc0bdb6:	0f 94 c2             	sete   dl
    78725cc0bdb9:	80 e2 01             	and    dl,0x1
    78725cc0bdbc:	0f b6 d2             	movzx  edx,dl
    78725cc0bdbf:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0bdc2:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0bdc8:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0bdce:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0bdd5:	00 00 00 
    78725cc0bdd8:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0bddf:	00 00 00 
    78725cc0bde2:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0bde9:	00 00 00 
    78725cc0bdec:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0bdf3:	00 00 00 
    78725cc0bdf6:	eb 00                	jmp    0x78725cc0bdf8
    78725cc0bdf8:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bdff:	00 
    78725cc0be00:	8b 8c 24 00 01 00 00 	mov    ecx,DWORD PTR [rsp+0x100]
    78725cc0be07:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0be0a:	eb 00                	jmp    0x78725cc0be0c
    78725cc0be0c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0be13:	00 
    78725cc0be14:	8b 94 24 00 01 00 00 	mov    edx,DWORD PTR [rsp+0x100]
    78725cc0be1b:	c1 e2 02             	shl    edx,0x2
    78725cc0be1e:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    78725cc0be21:	89 8c 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],ecx
    78725cc0be28:	01 d1                	add    ecx,edx
    78725cc0be2a:	89 8c 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],ecx
    78725cc0be31:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0be34:	eb 00                	jmp    0x78725cc0be36
    78725cc0be36:	8b 84 24 f8 00 00 00 	mov    eax,DWORD PTR [rsp+0xf8]
    78725cc0be3d:	83 e0 03             	and    eax,0x3
    78725cc0be40:	83 f8 00             	cmp    eax,0x0
    78725cc0be43:	0f 84 97 00 00 00    	je     0x78725cc0bee0
    78725cc0be49:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0be50:	00 
    78725cc0be51:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0be58:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0be5f:	00 
    78725cc0be60:	c7 87 bc 00 00 00 c0 	mov    DWORD PTR [rdi+0xbc],0x101c0
    78725cc0be67:	01 01 00 
    78725cc0be6a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0be71:	00 00 00 
    78725cc0be74:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    78725cc0be7b:	00 00 00 
    78725cc0be7e:	31 c0                	xor    eax,eax
    78725cc0be80:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0be87:	60 00 00 
    78725cc0be8a:	ba c0 01 01 00       	mov    edx,0x101c0
    78725cc0be8f:	45 31 c0             	xor    r8d,r8d
    78725cc0be92:	ff d0                	call   rax
    78725cc0be94:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0be9b:	00 
    78725cc0be9c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0bea2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0bea8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0beae:	be 04 00 00 00       	mov    esi,0x4
    78725cc0beb3:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0beb8:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0bebf:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0bec6:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0becd:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0bed4:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0bedb:	e9 b0 0f 00 00       	jmp    0x78725cc0ce90
    78725cc0bee0:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0bee7:	00 
    78725cc0bee8:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0beef:	c1 e9 0c             	shr    ecx,0xc
    78725cc0bef2:	89 c9                	mov    ecx,ecx
    78725cc0bef4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0bef8:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    78725cc0beff:	00 
    78725cc0bf00:	48 83 f8 00          	cmp    rax,0x0
    78725cc0bf04:	74 23                	je     0x78725cc0bf29
    78725cc0bf06:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    78725cc0bf0d:	00 
    78725cc0bf0e:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0bf15:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0bf1b:	89 c9                	mov    ecx,ecx
    78725cc0bf1d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0bf20:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    78725cc0bf27:	eb 5d                	jmp    0x78725cc0bf86
    78725cc0bf29:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bf30:	00 
    78725cc0bf31:	8b b4 24 f8 00 00 00 	mov    esi,DWORD PTR [rsp+0xf8]
    78725cc0bf38:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0bf3f:	00 
    78725cc0bf40:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x101c0
    78725cc0bf47:	01 01 00 
    78725cc0bf4a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0bf51:	00 00 00 
    78725cc0bf54:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc0bf5b:	00 00 00 
    78725cc0bf5e:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0bf65:	60 00 00 
    78725cc0bf68:	ff d0                	call   rax
    78725cc0bf6a:	89 c1                	mov    ecx,eax
    78725cc0bf6c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bf73:	00 
    78725cc0bf74:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    78725cc0bf7b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0bf82:	75 1d                	jne    0x78725cc0bfa1
    78725cc0bf84:	eb 67                	jmp    0x78725cc0bfed
    78725cc0bf86:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bf8d:	00 
    78725cc0bf8e:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    78725cc0bf95:	89 8c 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],ecx
    78725cc0bf9c:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    78725cc0bf9f:	eb 5c                	jmp    0x78725cc0bffd
    78725cc0bfa1:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0bfa8:	00 
    78725cc0bfa9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0bfaf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0bfb5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0bfbb:	be 04 00 00 00       	mov    esi,0x4
    78725cc0bfc0:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0bfc5:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0bfcc:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0bfd3:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0bfda:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0bfe1:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0bfe8:	e9 a3 0e 00 00       	jmp    0x78725cc0ce90
    78725cc0bfed:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    78725cc0bff4:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    78725cc0bffb:	eb 89                	jmp    0x78725cc0bf86
    78725cc0bffd:	eb 00                	jmp    0x78725cc0bfff
    78725cc0bfff:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c006:	00 
    78725cc0c007:	8b bc 24 cc 00 00 00 	mov    edi,DWORD PTR [rsp+0xcc]
    78725cc0c00e:	8b 8c 24 fc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xfc]
    78725cc0c015:	89 ca                	mov    edx,ecx
    78725cc0c017:	01 fa                	add    edx,edi
    78725cc0c019:	89 94 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],edx
    78725cc0c020:	89 50 0c             	mov    DWORD PTR [rax+0xc],edx
    78725cc0c023:	89 ce                	mov    esi,ecx
    78725cc0c025:	c1 ee 1f             	shr    esi,0x1f
    78725cc0c028:	89 fb                	mov    ebx,edi
    78725cc0c02a:	c1 eb 1f             	shr    ebx,0x1f
    78725cc0c02d:	89 d5                	mov    ebp,edx
    78725cc0c02f:	c1 ed 1f             	shr    ebp,0x1f
    78725cc0c032:	31 eb                	xor    ebx,ebp
    78725cc0c034:	31 ee                	xor    esi,ebp
    78725cc0c036:	21 de                	and    esi,ebx
    78725cc0c038:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc0c03b:	39 f9                	cmp    ecx,edi
    78725cc0c03d:	0f 92 c1             	setb   cl
    78725cc0c040:	80 e1 01             	and    cl,0x1
    78725cc0c043:	0f b6 c9             	movzx  ecx,cl
    78725cc0c046:	83 fa 00             	cmp    edx,0x0
    78725cc0c049:	0f 94 c3             	sete   bl
    78725cc0c04c:	80 e3 01             	and    bl,0x1
    78725cc0c04f:	0f b6 fb             	movzx  edi,bl
    78725cc0c052:	c1 ea 1f             	shr    edx,0x1f
    78725cc0c055:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    78725cc0c05b:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0c061:	89 f2                	mov    edx,esi
    78725cc0c063:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    78725cc0c069:	89 94 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edx
    78725cc0c070:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0c076:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0c07c:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0c082:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0c088:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0c08e:	eb 00                	jmp    0x78725cc0c090
    78725cc0c090:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c097:	00 
    78725cc0c098:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc0c09f:	c1 e9 0b             	shr    ecx,0xb
    78725cc0c0a2:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    78725cc0c0a9:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0c0ac:	83 f9 00             	cmp    ecx,0x0
    78725cc0c0af:	0f 94 c2             	sete   dl
    78725cc0c0b2:	80 e2 01             	and    dl,0x1
    78725cc0c0b5:	0f b6 d2             	movzx  edx,dl
    78725cc0c0b8:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0c0bb:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0c0c1:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0c0c7:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0c0ce:	00 00 00 
    78725cc0c0d1:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0c0d8:	00 00 00 
    78725cc0c0db:	eb 00                	jmp    0x78725cc0c0dd
    78725cc0c0dd:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c0e4:	00 
    78725cc0c0e5:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    78725cc0c0ec:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc0c0f3:	31 d1                	xor    ecx,edx
    78725cc0c0f5:	89 8c 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],ecx
    78725cc0c0fc:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0c0ff:	83 f9 00             	cmp    ecx,0x0
    78725cc0c102:	0f 94 c2             	sete   dl
    78725cc0c105:	80 e2 01             	and    dl,0x1
    78725cc0c108:	0f b6 d2             	movzx  edx,dl
    78725cc0c10b:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0c10e:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0c114:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0c11a:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0c121:	00 00 00 
    78725cc0c124:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0c12b:	00 00 00 
    78725cc0c12e:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0c135:	00 00 00 
    78725cc0c138:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0c13f:	00 00 00 
    78725cc0c142:	eb 00                	jmp    0x78725cc0c144
    78725cc0c144:	8b 84 24 f8 00 00 00 	mov    eax,DWORD PTR [rsp+0xf8]
    78725cc0c14b:	83 e0 03             	and    eax,0x3
    78725cc0c14e:	83 f8 00             	cmp    eax,0x0
    78725cc0c151:	0f 84 98 00 00 00    	je     0x78725cc0c1ef
    78725cc0c157:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0c15e:	00 
    78725cc0c15f:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0c166:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0c16d:	00 
    78725cc0c16e:	c7 87 bc 00 00 00 ca 	mov    DWORD PTR [rdi+0xbc],0x101ca
    78725cc0c175:	01 01 00 
    78725cc0c178:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0c17f:	00 00 00 
    78725cc0c182:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc0c189:	00 00 00 
    78725cc0c18c:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0c193:	60 00 00 
    78725cc0c196:	ba ca 01 01 00       	mov    edx,0x101ca
    78725cc0c19b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0c1a1:	ff d0                	call   rax
    78725cc0c1a3:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c1aa:	00 
    78725cc0c1ab:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c1b1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c1b7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c1bd:	be 08 00 00 00       	mov    esi,0x8
    78725cc0c1c2:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0c1c7:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c1ce:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c1d5:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c1dc:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c1e3:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c1ea:	e9 a1 0c 00 00       	jmp    0x78725cc0ce90
    78725cc0c1ef:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0c1f6:	00 
    78725cc0c1f7:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0c1fe:	c1 e9 0c             	shr    ecx,0xc
    78725cc0c201:	89 c9                	mov    ecx,ecx
    78725cc0c203:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0c207:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    78725cc0c20e:	00 
    78725cc0c20f:	48 83 f8 00          	cmp    rax,0x0
    78725cc0c213:	74 23                	je     0x78725cc0c238
    78725cc0c215:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    78725cc0c21c:	00 
    78725cc0c21d:	8b 94 24 bc 00 00 00 	mov    edx,DWORD PTR [rsp+0xbc]
    78725cc0c224:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0c22b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0c231:	89 c9                	mov    ecx,ecx
    78725cc0c233:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0c236:	eb 5b                	jmp    0x78725cc0c293
    78725cc0c238:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c23f:	00 
    78725cc0c240:	8b 94 24 bc 00 00 00 	mov    edx,DWORD PTR [rsp+0xbc]
    78725cc0c247:	8b b4 24 f8 00 00 00 	mov    esi,DWORD PTR [rsp+0xf8]
    78725cc0c24e:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0c255:	00 
    78725cc0c256:	c7 80 bc 00 00 00 ca 	mov    DWORD PTR [rax+0xbc],0x101ca
    78725cc0c25d:	01 01 00 
    78725cc0c260:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0c267:	00 00 00 
    78725cc0c26a:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    78725cc0c271:	00 00 00 
    78725cc0c274:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0c27b:	60 00 00 
    78725cc0c27e:	ff d0                	call   rax
    78725cc0c280:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c287:	00 
    78725cc0c288:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0c28f:	75 14                	jne    0x78725cc0c2a5
    78725cc0c291:	eb 5e                	jmp    0x78725cc0c2f1
    78725cc0c293:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    78725cc0c29a:	00 
    78725cc0c29b:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc0c29e:	75 53                	jne    0x78725cc0c2f3
    78725cc0c2a0:	e9 93 00 00 00       	jmp    0x78725cc0c338
    78725cc0c2a5:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c2ac:	00 
    78725cc0c2ad:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c2b3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c2b9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c2bf:	be 08 00 00 00       	mov    esi,0x8
    78725cc0c2c4:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0c2c9:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c2d0:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c2d7:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c2de:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c2e5:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c2ec:	e9 9f 0b 00 00       	jmp    0x78725cc0ce90
    78725cc0c2f1:	eb a0                	jmp    0x78725cc0c293
    78725cc0c2f3:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0c2fa:	00 
    78725cc0c2fb:	c7 87 bc 00 00 00 cc 	mov    DWORD PTR [rdi+0xbc],0x101cc
    78725cc0c302:	01 01 00 
    78725cc0c305:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0c30c:	00 00 00 
    78725cc0c30f:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    78725cc0c316:	00 00 00 
    78725cc0c319:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0c320:	60 00 00 
    78725cc0c323:	ff d0                	call   rax
    78725cc0c325:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c32c:	00 
    78725cc0c32d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0c334:	75 04                	jne    0x78725cc0c33a
    78725cc0c336:	eb 4e                	jmp    0x78725cc0c386
    78725cc0c338:	eb 4e                	jmp    0x78725cc0c388
    78725cc0c33a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c341:	00 
    78725cc0c342:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c348:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c34e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c354:	be 08 00 00 00       	mov    esi,0x8
    78725cc0c359:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0c35e:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c365:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c36c:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c373:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c37a:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c381:	e9 0a 0b 00 00       	jmp    0x78725cc0ce90
    78725cc0c386:	eb b0                	jmp    0x78725cc0c338
    78725cc0c388:	eb 00                	jmp    0x78725cc0c38a
    78725cc0c38a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c391:	00 
    78725cc0c392:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc0c399:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0c39c:	eb 00                	jmp    0x78725cc0c39e
    78725cc0c39e:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c3a5:	00 
    78725cc0c3a6:	8b 94 24 c8 00 00 00 	mov    edx,DWORD PTR [rsp+0xc8]
    78725cc0c3ad:	8b 8c 24 fc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xfc]
    78725cc0c3b4:	89 cf                	mov    edi,ecx
    78725cc0c3b6:	83 c7 01             	add    edi,0x1
    78725cc0c3b9:	89 bc 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edi
    78725cc0c3c0:	89 78 08             	mov    DWORD PTR [rax+0x8],edi
    78725cc0c3c3:	89 ce                	mov    esi,ecx
    78725cc0c3c5:	c1 ee 1f             	shr    esi,0x1f
    78725cc0c3c8:	89 fd                	mov    ebp,edi
    78725cc0c3ca:	c1 ed 1f             	shr    ebp,0x1f
    78725cc0c3cd:	89 eb                	mov    ebx,ebp
    78725cc0c3cf:	83 f3 00             	xor    ebx,0x0
    78725cc0c3d2:	31 ee                	xor    esi,ebp
    78725cc0c3d4:	21 de                	and    esi,ebx
    78725cc0c3d6:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc0c3d9:	83 f9 01             	cmp    ecx,0x1
    78725cc0c3dc:	0f 92 c1             	setb   cl
    78725cc0c3df:	80 e1 01             	and    cl,0x1
    78725cc0c3e2:	0f b6 c9             	movzx  ecx,cl
    78725cc0c3e5:	83 ff 00             	cmp    edi,0x0
    78725cc0c3e8:	0f 94 c3             	sete   bl
    78725cc0c3eb:	80 e3 01             	and    bl,0x1
    78725cc0c3ee:	0f b6 db             	movzx  ebx,bl
    78725cc0c3f1:	c1 ef 1f             	shr    edi,0x1f
    78725cc0c3f4:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    78725cc0c3fa:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    78725cc0c400:	09 f2                	or     edx,esi
    78725cc0c402:	89 94 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],edx
    78725cc0c409:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0c40f:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0c415:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0c41b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0c421:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0c427:	eb 00                	jmp    0x78725cc0c429
    78725cc0c429:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c430:	00 
    78725cc0c431:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    78725cc0c438:	8b 38                	mov    edi,DWORD PTR [rax]
    78725cc0c43a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    78725cc0c441:	39 cf                	cmp    edi,ecx
    78725cc0c443:	0f 96 c2             	setbe  dl
    78725cc0c446:	80 e2 01             	and    dl,0x1
    78725cc0c449:	0f b6 d2             	movzx  edx,dl
    78725cc0c44c:	89 94 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],edx
    78725cc0c453:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    78725cc0c459:	39 cf                	cmp    edi,ecx
    78725cc0c45b:	0f 94 c2             	sete   dl
    78725cc0c45e:	80 e2 01             	and    dl,0x1
    78725cc0c461:	0f b6 f2             	movzx  esi,dl
    78725cc0c464:	39 f9                	cmp    ecx,edi
    78725cc0c466:	0f 97 c2             	seta   dl
    78725cc0c469:	80 e2 01             	and    dl,0x1
    78725cc0c46c:	0f b6 d2             	movzx  edx,dl
    78725cc0c46f:	39 f9                	cmp    ecx,edi
    78725cc0c471:	0f 96 c1             	setbe  cl
    78725cc0c474:	80 e1 01             	and    cl,0x1
    78725cc0c477:	0f b6 c9             	movzx  ecx,cl
    78725cc0c47a:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc0c480:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0c486:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0c48c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0c492:	eb 00                	jmp    0x78725cc0c494
    78725cc0c494:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c49b:	00 
    78725cc0c49c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc0c4a3:	03 48 24             	add    ecx,DWORD PTR [rax+0x24]
    78725cc0c4a6:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    78725cc0c4ad:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    78725cc0c4b0:	eb 00                	jmp    0x78725cc0c4b2
    78725cc0c4b2:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    78725cc0c4b9:	83 f8 00             	cmp    eax,0x0
    78725cc0c4bc:	75 33                	jne    0x78725cc0c4f1
    78725cc0c4be:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
    78725cc0c4c5:	00 
    78725cc0c4c6:	c7 81 bc 00 00 00 ba 	mov    DWORD PTR [rcx+0xbc],0x101ba
    78725cc0c4cd:	01 01 00 
    78725cc0c4d0:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0c4d6:	83 c0 0d             	add    eax,0xd
    78725cc0c4d9:	89 84 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],eax
    78725cc0c4e0:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0c4e6:	0f 82 4e 09 00 00    	jb     0x78725cc0ce3a
    78725cc0c4ec:	e9 6d 09 00 00       	jmp    0x78725cc0ce5e
    78725cc0c4f1:	eb 00                	jmp    0x78725cc0c4f3
    78725cc0c4f3:	eb 00                	jmp    0x78725cc0c4f5
    78725cc0c4f5:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c4fc:	00 
    78725cc0c4fd:	c7 40 04 ff 1f 00 00 	mov    DWORD PTR [rax+0x4],0x1fff
    78725cc0c504:	eb 00                	jmp    0x78725cc0c506
    78725cc0c506:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c50d:	00 
    78725cc0c50e:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    78725cc0c515:	8b 8c 24 a0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa0]
    78725cc0c51c:	89 cf                	mov    edi,ecx
    78725cc0c51e:	83 c7 ff             	add    edi,0xffffffff
    78725cc0c521:	89 bc 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edi
    78725cc0c528:	89 38                	mov    DWORD PTR [rax],edi
    78725cc0c52a:	89 ce                	mov    esi,ecx
    78725cc0c52c:	c1 ee 1f             	shr    esi,0x1f
    78725cc0c52f:	89 fd                	mov    ebp,edi
    78725cc0c531:	c1 ed 1f             	shr    ebp,0x1f
    78725cc0c534:	89 eb                	mov    ebx,ebp
    78725cc0c536:	83 f3 01             	xor    ebx,0x1
    78725cc0c539:	31 ee                	xor    esi,ebp
    78725cc0c53b:	21 de                	and    esi,ebx
    78725cc0c53d:	83 f1 ff             	xor    ecx,0xffffffff
    78725cc0c540:	83 f9 ff             	cmp    ecx,0xffffffff
    78725cc0c543:	0f 92 c1             	setb   cl
    78725cc0c546:	80 e1 01             	and    cl,0x1
    78725cc0c549:	0f b6 c9             	movzx  ecx,cl
    78725cc0c54c:	83 ff 00             	cmp    edi,0x0
    78725cc0c54f:	0f 94 c3             	sete   bl
    78725cc0c552:	80 e3 01             	and    bl,0x1
    78725cc0c555:	0f b6 db             	movzx  ebx,bl
    78725cc0c558:	c1 ef 1f             	shr    edi,0x1f
    78725cc0c55b:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    78725cc0c561:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    78725cc0c567:	09 f2                	or     edx,esi
    78725cc0c569:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    78725cc0c56f:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    78725cc0c575:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    78725cc0c57b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0c581:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc0c587:	eb 00                	jmp    0x78725cc0c589
    78725cc0c589:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c590:	00 
    78725cc0c591:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc0c598:	81 e1 ff 1f 00 00    	and    ecx,0x1fff
    78725cc0c59e:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    78725cc0c5a5:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0c5a7:	83 f9 00             	cmp    ecx,0x0
    78725cc0c5aa:	0f 94 c2             	sete   dl
    78725cc0c5ad:	80 e2 01             	and    dl,0x1
    78725cc0c5b0:	0f b6 d2             	movzx  edx,dl
    78725cc0c5b3:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0c5b6:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0c5bc:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0c5c2:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0c5c9:	00 00 00 
    78725cc0c5cc:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0c5d3:	00 00 00 
    78725cc0c5d6:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0c5dd:	00 00 00 
    78725cc0c5e0:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0c5e7:	00 00 00 
    78725cc0c5ea:	eb 00                	jmp    0x78725cc0c5ec
    78725cc0c5ec:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c5f3:	00 
    78725cc0c5f4:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    78725cc0c5fb:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0c5fe:	eb 00                	jmp    0x78725cc0c600
    78725cc0c600:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c607:	00 
    78725cc0c608:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    78725cc0c60f:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    78725cc0c612:	eb 00                	jmp    0x78725cc0c614
    78725cc0c614:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c61b:	00 
    78725cc0c61c:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    78725cc0c61f:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    78725cc0c626:	83 e0 03             	and    eax,0x3
    78725cc0c629:	83 f8 00             	cmp    eax,0x0
    78725cc0c62c:	0f 84 97 00 00 00    	je     0x78725cc0c6c9
    78725cc0c632:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0c639:	00 
    78725cc0c63a:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0c641:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0c648:	00 
    78725cc0c649:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    78725cc0c650:	01 01 00 
    78725cc0c653:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0c65a:	00 00 00 
    78725cc0c65d:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc0c664:	00 00 00 
    78725cc0c667:	31 c0                	xor    eax,eax
    78725cc0c669:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0c670:	60 00 00 
    78725cc0c673:	ba e2 01 01 00       	mov    edx,0x101e2
    78725cc0c678:	45 31 c0             	xor    r8d,r8d
    78725cc0c67b:	ff d0                	call   rax
    78725cc0c67d:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c684:	00 
    78725cc0c685:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c68b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c691:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c697:	be 13 00 00 00       	mov    esi,0x13
    78725cc0c69c:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0c6a1:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c6a8:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c6af:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c6b6:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c6bd:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c6c4:	e9 c7 07 00 00       	jmp    0x78725cc0ce90
    78725cc0c6c9:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0c6d0:	00 
    78725cc0c6d1:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0c6d8:	c1 e9 0c             	shr    ecx,0xc
    78725cc0c6db:	89 c9                	mov    ecx,ecx
    78725cc0c6dd:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0c6e1:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    78725cc0c6e8:	00 
    78725cc0c6e9:	48 83 f8 00          	cmp    rax,0x0
    78725cc0c6ed:	74 20                	je     0x78725cc0c70f
    78725cc0c6ef:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    78725cc0c6f6:	00 
    78725cc0c6f7:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    78725cc0c6fe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0c704:	89 c9                	mov    ecx,ecx
    78725cc0c706:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0c709:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0c70d:	eb 5a                	jmp    0x78725cc0c769
    78725cc0c70f:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c716:	00 
    78725cc0c717:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    78725cc0c71e:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0c725:	00 
    78725cc0c726:	c7 80 bc 00 00 00 e2 	mov    DWORD PTR [rax+0xbc],0x101e2
    78725cc0c72d:	01 01 00 
    78725cc0c730:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0c737:	00 00 00 
    78725cc0c73a:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    78725cc0c741:	00 00 00 
    78725cc0c744:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0c74b:	60 00 00 
    78725cc0c74e:	ff d0                	call   rax
    78725cc0c750:	89 c1                	mov    ecx,eax
    78725cc0c752:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c759:	00 
    78725cc0c75a:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    78725cc0c75e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0c765:	75 25                	jne    0x78725cc0c78c
    78725cc0c767:	eb 6f                	jmp    0x78725cc0c7d8
    78725cc0c769:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    78725cc0c770:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc0c774:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    78725cc0c778:	83 c0 04             	add    eax,0x4
    78725cc0c77b:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    78725cc0c77f:	83 e0 03             	and    eax,0x3
    78725cc0c782:	83 f8 00             	cmp    eax,0x0
    78725cc0c785:	75 5b                	jne    0x78725cc0c7e2
    78725cc0c787:	e9 ea 00 00 00       	jmp    0x78725cc0c876
    78725cc0c78c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c793:	00 
    78725cc0c794:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c79a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c7a0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c7a6:	be 13 00 00 00       	mov    esi,0x13
    78725cc0c7ab:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0c7b0:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c7b7:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c7be:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c7c5:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c7cc:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c7d3:	e9 b8 06 00 00       	jmp    0x78725cc0ce90
    78725cc0c7d8:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    78725cc0c7dc:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc0c7e0:	eb 87                	jmp    0x78725cc0c769
    78725cc0c7e2:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0c7e9:	00 
    78725cc0c7ea:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0c7ee:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0c7f5:	00 
    78725cc0c7f6:	c7 87 bc 00 00 00 e2 	mov    DWORD PTR [rdi+0xbc],0x101e2
    78725cc0c7fd:	01 01 00 
    78725cc0c800:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc0c807:	00 00 00 
    78725cc0c80a:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc0c811:	00 00 00 
    78725cc0c814:	31 c0                	xor    eax,eax
    78725cc0c816:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0c81d:	60 00 00 
    78725cc0c820:	ba e2 01 01 00       	mov    edx,0x101e2
    78725cc0c825:	45 31 c0             	xor    r8d,r8d
    78725cc0c828:	ff d0                	call   rax
    78725cc0c82a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c831:	00 
    78725cc0c832:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c838:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c83e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c844:	be 13 00 00 00       	mov    esi,0x13
    78725cc0c849:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0c84e:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c855:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c85c:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c863:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c86a:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c871:	e9 1a 06 00 00       	jmp    0x78725cc0ce90
    78725cc0c876:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0c87d:	00 
    78725cc0c87e:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0c882:	c1 e9 0c             	shr    ecx,0xc
    78725cc0c885:	89 c9                	mov    ecx,ecx
    78725cc0c887:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0c88b:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    78725cc0c890:	48 83 f8 00          	cmp    rax,0x0
    78725cc0c894:	74 1a                	je     0x78725cc0c8b0
    78725cc0c896:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    78725cc0c89b:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0c89f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0c8a5:	89 c9                	mov    ecx,ecx
    78725cc0c8a7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0c8aa:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc0c8ae:	eb 57                	jmp    0x78725cc0c907
    78725cc0c8b0:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c8b7:	00 
    78725cc0c8b8:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    78725cc0c8bc:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0c8c3:	00 
    78725cc0c8c4:	c7 80 bc 00 00 00 e2 	mov    DWORD PTR [rax+0xbc],0x101e2
    78725cc0c8cb:	01 01 00 
    78725cc0c8ce:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc0c8d5:	00 00 00 
    78725cc0c8d8:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    78725cc0c8df:	00 00 00 
    78725cc0c8e2:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0c8e9:	60 00 00 
    78725cc0c8ec:	ff d0                	call   rax
    78725cc0c8ee:	89 c1                	mov    ecx,eax
    78725cc0c8f0:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c8f7:	00 
    78725cc0c8f8:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    78725cc0c8fc:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0c903:	75 2f                	jne    0x78725cc0c934
    78725cc0c905:	eb 79                	jmp    0x78725cc0c980
    78725cc0c907:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c90e:	00 
    78725cc0c90f:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    78725cc0c913:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    78725cc0c917:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    78725cc0c91b:	89 54 24 58          	mov    DWORD PTR [rsp+0x58],edx
    78725cc0c91f:	83 c1 04             	add    ecx,0x4
    78725cc0c922:	89 4c 24 5c          	mov    DWORD PTR [rsp+0x5c],ecx
    78725cc0c926:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc0c929:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc0c92f:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0c932:	eb 59                	jmp    0x78725cc0c98d
    78725cc0c934:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c93b:	00 
    78725cc0c93c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c942:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c948:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0c94e:	be 13 00 00 00       	mov    esi,0x13
    78725cc0c953:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0c958:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0c95f:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0c966:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0c96d:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0c974:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0c97b:	e9 10 05 00 00       	jmp    0x78725cc0ce90
    78725cc0c980:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    78725cc0c984:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc0c988:	e9 7a ff ff ff       	jmp    0x78725cc0c907
    78725cc0c98d:	eb 00                	jmp    0x78725cc0c98f
    78725cc0c98f:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    78725cc0c993:	83 e0 03             	and    eax,0x3
    78725cc0c996:	83 f8 00             	cmp    eax,0x0
    78725cc0c999:	0f 84 94 00 00 00    	je     0x78725cc0ca33
    78725cc0c99f:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0c9a6:	00 
    78725cc0c9a7:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0c9ab:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0c9b2:	00 
    78725cc0c9b3:	c7 87 bc 00 00 00 e6 	mov    DWORD PTR [rdi+0xbc],0x101e6
    78725cc0c9ba:	01 01 00 
    78725cc0c9bd:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0c9c4:	00 00 00 
    78725cc0c9c7:	c7 87 34 01 00 00 14 	mov    DWORD PTR [rdi+0x134],0x14
    78725cc0c9ce:	00 00 00 
    78725cc0c9d1:	31 c0                	xor    eax,eax
    78725cc0c9d3:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0c9da:	60 00 00 
    78725cc0c9dd:	ba e6 01 01 00       	mov    edx,0x101e6
    78725cc0c9e2:	45 31 c0             	xor    r8d,r8d
    78725cc0c9e5:	ff d0                	call   rax
    78725cc0c9e7:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0c9ee:	00 
    78725cc0c9ef:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0c9f5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0c9fb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ca01:	be 14 00 00 00       	mov    esi,0x14
    78725cc0ca06:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ca0b:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0ca12:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0ca19:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0ca20:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0ca27:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0ca2e:	e9 5d 04 00 00       	jmp    0x78725cc0ce90
    78725cc0ca33:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0ca3a:	00 
    78725cc0ca3b:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0ca3f:	c1 e9 0c             	shr    ecx,0xc
    78725cc0ca42:	89 c9                	mov    ecx,ecx
    78725cc0ca44:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0ca48:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    78725cc0ca4d:	48 83 f8 00          	cmp    rax,0x0
    78725cc0ca51:	74 1a                	je     0x78725cc0ca6d
    78725cc0ca53:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    78725cc0ca58:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0ca5c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0ca62:	89 c9                	mov    ecx,ecx
    78725cc0ca64:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0ca67:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0ca6b:	eb 57                	jmp    0x78725cc0cac4
    78725cc0ca6d:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0ca74:	00 
    78725cc0ca75:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    78725cc0ca79:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0ca80:	00 
    78725cc0ca81:	c7 80 bc 00 00 00 e6 	mov    DWORD PTR [rax+0xbc],0x101e6
    78725cc0ca88:	01 01 00 
    78725cc0ca8b:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0ca92:	00 00 00 
    78725cc0ca95:	c7 80 34 01 00 00 14 	mov    DWORD PTR [rax+0x134],0x14
    78725cc0ca9c:	00 00 00 
    78725cc0ca9f:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0caa6:	60 00 00 
    78725cc0caa9:	ff d0                	call   rax
    78725cc0caab:	89 c1                	mov    ecx,eax
    78725cc0caad:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cab4:	00 
    78725cc0cab5:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    78725cc0cab9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0cac0:	75 1d                	jne    0x78725cc0cadf
    78725cc0cac2:	eb 67                	jmp    0x78725cc0cb2b
    78725cc0cac4:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cacb:	00 
    78725cc0cacc:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    78725cc0cad0:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    78725cc0cad4:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    78725cc0cad7:	83 c1 04             	add    ecx,0x4
    78725cc0cada:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc0cadd:	eb 56                	jmp    0x78725cc0cb35
    78725cc0cadf:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cae6:	00 
    78725cc0cae7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0caed:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0caf3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0caf9:	be 14 00 00 00       	mov    esi,0x14
    78725cc0cafe:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0cb03:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0cb0a:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0cb11:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0cb18:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0cb1f:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0cb26:	e9 65 03 00 00       	jmp    0x78725cc0ce90
    78725cc0cb2b:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    78725cc0cb2f:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    78725cc0cb33:	eb 8f                	jmp    0x78725cc0cac4
    78725cc0cb35:	eb 00                	jmp    0x78725cc0cb37
    78725cc0cb37:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cb3e:	00 
    78725cc0cb3f:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    78725cc0cb46:	8b 94 24 90 00 00 00 	mov    edx,DWORD PTR [rsp+0x90]
    78725cc0cb4d:	c1 e2 02             	shl    edx,0x2
    78725cc0cb50:	01 d1                	add    ecx,edx
    78725cc0cb52:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    78725cc0cb56:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    78725cc0cb59:	eb 00                	jmp    0x78725cc0cb5b
    78725cc0cb5b:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    78725cc0cb5f:	83 e0 03             	and    eax,0x3
    78725cc0cb62:	83 f8 00             	cmp    eax,0x0
    78725cc0cb65:	0f 84 94 00 00 00    	je     0x78725cc0cbff
    78725cc0cb6b:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0cb72:	00 
    78725cc0cb73:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0cb77:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
    78725cc0cb7e:	00 
    78725cc0cb7f:	c7 87 bc 00 00 00 ea 	mov    DWORD PTR [rdi+0xbc],0x101ea
    78725cc0cb86:	01 01 00 
    78725cc0cb89:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0cb90:	00 00 00 
    78725cc0cb93:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    78725cc0cb9a:	00 00 00 
    78725cc0cb9d:	31 c0                	xor    eax,eax
    78725cc0cb9f:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0cba6:	60 00 00 
    78725cc0cba9:	ba ea 01 01 00       	mov    edx,0x101ea
    78725cc0cbae:	45 31 c0             	xor    r8d,r8d
    78725cc0cbb1:	ff d0                	call   rax
    78725cc0cbb3:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cbba:	00 
    78725cc0cbbb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0cbc1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0cbc7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0cbcd:	be 16 00 00 00       	mov    esi,0x16
    78725cc0cbd2:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0cbd7:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0cbde:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0cbe5:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0cbec:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0cbf3:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0cbfa:	e9 91 02 00 00       	jmp    0x78725cc0ce90
    78725cc0cbff:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    78725cc0cc06:	00 
    78725cc0cc07:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0cc0b:	c1 e9 0c             	shr    ecx,0xc
    78725cc0cc0e:	89 c9                	mov    ecx,ecx
    78725cc0cc10:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0cc14:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    78725cc0cc19:	48 83 f8 00          	cmp    rax,0x0
    78725cc0cc1d:	74 1a                	je     0x78725cc0cc39
    78725cc0cc1f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc0cc24:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    78725cc0cc28:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0cc2e:	89 c9                	mov    ecx,ecx
    78725cc0cc30:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0cc33:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc0cc37:	eb 57                	jmp    0x78725cc0cc90
    78725cc0cc39:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cc40:	00 
    78725cc0cc41:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    78725cc0cc45:	48 8b bc 24 10 01 00 	mov    rdi,QWORD PTR [rsp+0x110]
    78725cc0cc4c:	00 
    78725cc0cc4d:	c7 80 bc 00 00 00 ea 	mov    DWORD PTR [rax+0xbc],0x101ea
    78725cc0cc54:	01 01 00 
    78725cc0cc57:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0cc5e:	00 00 00 
    78725cc0cc61:	c7 80 34 01 00 00 16 	mov    DWORD PTR [rax+0x134],0x16
    78725cc0cc68:	00 00 00 
    78725cc0cc6b:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0cc72:	60 00 00 
    78725cc0cc75:	ff d0                	call   rax
    78725cc0cc77:	89 c1                	mov    ecx,eax
    78725cc0cc79:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cc80:	00 
    78725cc0cc81:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    78725cc0cc85:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0cc8c:	75 16                	jne    0x78725cc0cca4
    78725cc0cc8e:	eb 60                	jmp    0x78725cc0ccf0
    78725cc0cc90:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cc97:	00 
    78725cc0cc98:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    78725cc0cc9c:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    78725cc0cca0:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0cca2:	eb 56                	jmp    0x78725cc0ccfa
    78725cc0cca4:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0ccab:	00 
    78725cc0ccac:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0ccb2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0ccb8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0ccbe:	be 16 00 00 00       	mov    esi,0x16
    78725cc0ccc3:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ccc8:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0cccf:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0ccd6:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0ccdd:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0cce4:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0cceb:	e9 a0 01 00 00       	jmp    0x78725cc0ce90
    78725cc0ccf0:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    78725cc0ccf4:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    78725cc0ccf8:	eb 96                	jmp    0x78725cc0cc90
    78725cc0ccfa:	eb 00                	jmp    0x78725cc0ccfc
    78725cc0ccfc:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cd03:	00 
    78725cc0cd04:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    78725cc0cd0b:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    78725cc0cd0f:	31 d1                	xor    ecx,edx
    78725cc0cd11:	89 08                	mov    DWORD PTR [rax],ecx
    78725cc0cd13:	83 f9 00             	cmp    ecx,0x0
    78725cc0cd16:	0f 94 c2             	sete   dl
    78725cc0cd19:	80 e2 01             	and    dl,0x1
    78725cc0cd1c:	0f b6 d2             	movzx  edx,dl
    78725cc0cd1f:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0cd22:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    78725cc0cd28:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    78725cc0cd2e:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    78725cc0cd35:	00 00 00 
    78725cc0cd38:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    78725cc0cd3f:	00 00 00 
    78725cc0cd42:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc0cd49:	00 00 00 
    78725cc0cd4c:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc0cd53:	00 00 00 
    78725cc0cd56:	eb 00                	jmp    0x78725cc0cd58
    78725cc0cd58:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    78725cc0cd5c:	83 e0 01             	and    eax,0x1
    78725cc0cd5f:	83 f8 00             	cmp    eax,0x0
    78725cc0cd62:	75 3a                	jne    0x78725cc0cd9e
    78725cc0cd64:	8b 54 24 58          	mov    edx,DWORD PTR [rsp+0x58]
    78725cc0cd68:	be 18 00 00 00       	mov    esi,0x18
    78725cc0cd6d:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0cd72:	b0 01                	mov    al,0x1
    78725cc0cd74:	89 d7                	mov    edi,edx
    78725cc0cd76:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0cd7d:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0cd84:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0cd8b:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0cd92:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0cd99:	e9 f2 00 00 00       	jmp    0x78725cc0ce90
    78725cc0cd9e:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
    78725cc0cda5:	00 
    78725cc0cda6:	48 8b 94 24 10 01 00 	mov    rdx,QWORD PTR [rsp+0x110]
    78725cc0cdad:	00 
    78725cc0cdae:	c7 87 bc 00 00 00 ee 	mov    DWORD PTR [rdi+0xbc],0x101ee
    78725cc0cdb5:	01 01 00 
    78725cc0cdb8:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0cdbf:	00 00 00 
    78725cc0cdc2:	c7 87 34 01 00 00 18 	mov    DWORD PTR [rdi+0x134],0x18
    78725cc0cdc9:	00 00 00 
    78725cc0cdcc:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc0cdd3:	60 00 00 
    78725cc0cdd6:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc0cddb:	ff d0                	call   rax
    78725cc0cddd:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cde4:	00 
    78725cc0cde5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0cdeb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0cdf1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0cdf7:	be 18 00 00 00       	mov    esi,0x18
    78725cc0cdfc:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0ce01:	89 bc 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edi
    78725cc0ce08:	89 b4 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],esi
    78725cc0ce0f:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    78725cc0ce16:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    78725cc0ce1d:	88 84 24 f3 00 00 00 	mov    BYTE PTR [rsp+0xf3],al
    78725cc0ce24:	eb 6a                	jmp    0x78725cc0ce90
    78725cc0ce26:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0ce2d:	00 
    78725cc0ce2e:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc0ce35:	e9 84 01 00 00       	jmp    0x78725cc0cfbe
    78725cc0ce3a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0ce41:	00 
    78725cc0ce42:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    78725cc0ce49:	c7 80 bc 00 00 00 ba 	mov    DWORD PTR [rax+0xbc],0x101ba
    78725cc0ce50:	01 01 00 
    78725cc0ce53:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    78725cc0ce59:	e9 b2 ee ff ff       	jmp    0x78725cc0bd10
    78725cc0ce5e:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0ce65:	00 
    78725cc0ce66:	c7 80 bc 00 00 00 ba 	mov    DWORD PTR [rax+0xbc],0x101ba
    78725cc0ce6d:	01 01 00 
    78725cc0ce70:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0ce77:	00 00 00 
    78725cc0ce7a:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    78725cc0ce81:	00 00 00 
    78725cc0ce84:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0ce8b:	e9 2e 01 00 00       	jmp    0x78725cc0cfbe
    78725cc0ce90:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
    78725cc0ce97:	00 
    78725cc0ce98:	8b 94 24 e0 00 00 00 	mov    edx,DWORD PTR [rsp+0xe0]
    78725cc0ce9f:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    78725cc0cea6:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    78725cc0cead:	8b bc 24 ec 00 00 00 	mov    edi,DWORD PTR [rsp+0xec]
    78725cc0ceb4:	8a 9c 24 f3 00 00 00 	mov    bl,BYTE PTR [rsp+0xf3]
    78725cc0cebb:	88 5c 24 17          	mov    BYTE PTR [rsp+0x17],bl
    78725cc0cebf:	89 c3                	mov    ebx,eax
    78725cc0cec1:	89 5c 24 18          	mov    DWORD PTR [rsp+0x18],ebx
    78725cc0cec5:	89 7c 24 1c          	mov    DWORD PTR [rsp+0x1c],edi
    78725cc0cec9:	89 74 24 20          	mov    DWORD PTR [rsp+0x20],esi
    78725cc0cecd:	89 54 24 24          	mov    DWORD PTR [rsp+0x24],edx
    78725cc0ced1:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc0ced7:	89 44 24 28          	mov    DWORD PTR [rsp+0x28],eax
    78725cc0cedb:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0cee1:	73 0d                	jae    0x78725cc0cef0
    78725cc0cee3:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    78725cc0cee7:	3d ba 01 01 00       	cmp    eax,0x101ba
    78725cc0ceec:	74 37                	je     0x78725cc0cf25
    78725cc0ceee:	eb 5d                	jmp    0x78725cc0cf4d
    78725cc0cef0:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cef7:	00 
    78725cc0cef8:	8a 4c 24 17          	mov    cl,BYTE PTR [rsp+0x17]
    78725cc0cefc:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    78725cc0cf00:	8b 74 24 1c          	mov    esi,DWORD PTR [rsp+0x1c]
    78725cc0cf04:	8b 7c 24 20          	mov    edi,DWORD PTR [rsp+0x20]
    78725cc0cf08:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc0cf0e:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc0cf14:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc0cf1a:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc0cf20:	e9 99 00 00 00       	jmp    0x78725cc0cfbe
    78725cc0cf25:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0cf2c:	00 
    78725cc0cf2d:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    78725cc0cf31:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    78725cc0cf35:	89 90 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edx
    78725cc0cf3b:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    78725cc0cf41:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    78725cc0cf48:	e9 c3 ed ff ff       	jmp    0x78725cc0bd10
    78725cc0cf4d:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    78725cc0cf54:	00 
    78725cc0cf55:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    78725cc0cf59:	89 d1                	mov    ecx,edx
    78725cc0cf5b:	c1 e9 01             	shr    ecx,0x1
    78725cc0cf5e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0cf64:	89 c9                	mov    ecx,ecx
    78725cc0cf66:	48 c1 e1 04          	shl    rcx,0x4
    78725cc0cf6a:	48 89 c6             	mov    rsi,rax
    78725cc0cf6d:	48 01 ce             	add    rsi,rcx
    78725cc0cf70:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc0cf75:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc0cf78:	0f 85 72 ff ff ff    	jne    0x78725cc0cef0
    78725cc0cf7e:	4c 8b b4 24 10 01 00 	mov    r14,QWORD PTR [rsp+0x110]
    78725cc0cf85:	00 
    78725cc0cf86:	4c 8b ac 24 18 01 00 	mov    r13,QWORD PTR [rsp+0x118]
    78725cc0cf8d:	00 
    78725cc0cf8e:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc0cf93:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    78725cc0cf97:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    78725cc0cf9b:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc0cfa2:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0cfa9:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc0cfb0:	00 
    78725cc0cfb1:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc0cfb5:	48 81 c4 38 01 00 00 	add    rsp,0x138
    78725cc0cfbc:	ff e0                	jmp    rax
    78725cc0cfbe:	48 81 c4 38 01 00 00 	add    rsp,0x138
    78725cc0cfc5:	c2 08 00             	ret    0x8
