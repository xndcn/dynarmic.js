
build-native-instruction-analysis/capture/bcore-default-stream/pc-66344-0-132432577707744.bin:     file format binary


Disassembly of section .data:

000078725cc03ee0 <.data>:
    78725cc03ee0:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    78725cc03ee7:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    78725cc03eee:	00 
    78725cc03eef:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    78725cc03ef6:	00 
    78725cc03ef7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    78725cc03efe:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    78725cc03f05:	00 
    78725cc03f06:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    78725cc03f0d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    78725cc03f14:	00 
    78725cc03f15:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    78725cc03f1c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    78725cc03f23:	00 
    78725cc03f24:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc03f2b:	00 
    78725cc03f2c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    78725cc03f32:	83 fa 00             	cmp    edx,0x0
    78725cc03f35:	0f 94 c0             	sete   al
    78725cc03f38:	81 ea 28 03 01 00    	sub    edx,0x10328
    78725cc03f3e:	83 fa 46             	cmp    edx,0x46
    78725cc03f41:	0f 97 c2             	seta   dl
    78725cc03f44:	08 d0                	or     al,dl
    78725cc03f46:	24 01                	and    al,0x1
    78725cc03f48:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    78725cc03f4e:	83 fa 00             	cmp    edx,0x0
    78725cc03f51:	0f 94 c1             	sete   cl
    78725cc03f54:	81 ea 28 03 01 00    	sub    edx,0x10328
    78725cc03f5a:	83 fa 46             	cmp    edx,0x46
    78725cc03f5d:	0f 97 c2             	seta   dl
    78725cc03f60:	08 d1                	or     cl,dl
    78725cc03f62:	20 c8                	and    al,cl
    78725cc03f64:	a8 01                	test   al,0x1
    78725cc03f66:	75 05                	jne    0x78725cc03f6d
    78725cc03f68:	e9 79 26 00 00       	jmp    0x78725cc065e6
    78725cc03f6d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc03f74:	00 
    78725cc03f75:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    78725cc03f7c:	48 89 c8             	mov    rax,rcx
    78725cc03f7f:	48 05 00 00 10 00    	add    rax,0x100000
    78725cc03f85:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    78725cc03f8c:	00 
    78725cc03f8d:	8b 81 0c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10000c]
    78725cc03f93:	83 c0 01             	add    eax,0x1
    78725cc03f96:	89 81 0c 00 10 00    	mov    DWORD PTR [rcx+0x10000c],eax
    78725cc03f9c:	3d c1 c5 00 00       	cmp    eax,0xc5c1
    78725cc03fa1:	75 4c                	jne    0x78725cc03fef
    78725cc03fa3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    78725cc03faa:	00 
    78725cc03fab:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    78725cc03fb1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    78725cc03fb8:	89 c2                	mov    edx,eax
    78725cc03fba:	83 c2 01             	add    edx,0x1
    78725cc03fbd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    78725cc03fc3:	3d 00 01 00 00       	cmp    eax,0x100
    78725cc03fc8:	73 23                	jae    0x78725cc03fed
    78725cc03fca:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    78725cc03fd1:	00 
    78725cc03fd2:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    78725cc03fd9:	89 c9                	mov    ecx,ecx
    78725cc03fdb:	48 c1 e1 02          	shl    rcx,0x2
    78725cc03fdf:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    78725cc03fe6:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    78725cc03fed:	eb 00                	jmp    0x78725cc03fef
    78725cc03fef:	eb 00                	jmp    0x78725cc03ff1
    78725cc03ff1:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc03ff8:	00 
    78725cc03ff9:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    78725cc03ffc:	83 e8 04             	sub    eax,0x4
    78725cc03fff:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    78725cc04006:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    78725cc04009:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    78725cc04010:	83 e0 03             	and    eax,0x3
    78725cc04013:	83 f8 00             	cmp    eax,0x0
    78725cc04016:	0f 84 8e 00 00 00    	je     0x78725cc040aa
    78725cc0401c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04023:	00 
    78725cc04024:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc0402b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc04032:	00 
    78725cc04033:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0403a:	00 00 00 
    78725cc0403d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc04044:	00 00 00 
    78725cc04047:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0404e:	60 00 00 
    78725cc04051:	ba 28 03 01 00       	mov    edx,0x10328
    78725cc04056:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0405c:	ff d0                	call   rax
    78725cc0405e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04065:	00 
    78725cc04066:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0406c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04072:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04078:	be 01 00 00 00       	mov    esi,0x1
    78725cc0407d:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc04082:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04089:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04090:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04097:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0409e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc040a5:	e9 20 28 00 00       	jmp    0x78725cc068ca
    78725cc040aa:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc040b1:	00 
    78725cc040b2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc040b9:	c1 e9 0c             	shr    ecx,0xc
    78725cc040bc:	89 c9                	mov    ecx,ecx
    78725cc040be:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc040c2:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    78725cc040c9:	00 
    78725cc040ca:	48 83 f8 00          	cmp    rax,0x0
    78725cc040ce:	74 23                	je     0x78725cc040f3
    78725cc040d0:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    78725cc040d7:	00 
    78725cc040d8:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    78725cc040df:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    78725cc040e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc040ec:	89 c9                	mov    ecx,ecx
    78725cc040ee:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc040f1:	eb 51                	jmp    0x78725cc04144
    78725cc040f3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc040fa:	00 
    78725cc040fb:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    78725cc04102:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    78725cc04109:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc04110:	00 
    78725cc04111:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc04118:	00 00 00 
    78725cc0411b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc04122:	00 00 00 
    78725cc04125:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0412c:	60 00 00 
    78725cc0412f:	ff d0                	call   rax
    78725cc04131:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04138:	00 
    78725cc04139:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc04140:	75 32                	jne    0x78725cc04174
    78725cc04142:	eb 7c                	jmp    0x78725cc041c0
    78725cc04144:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0414b:	00 
    78725cc0414c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    78725cc04153:	83 e8 04             	sub    eax,0x4
    78725cc04156:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    78725cc0415d:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    78725cc04160:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    78725cc04167:	83 e0 03             	and    eax,0x3
    78725cc0416a:	83 f8 00             	cmp    eax,0x0
    78725cc0416d:	75 53                	jne    0x78725cc041c2
    78725cc0416f:	e9 dc 00 00 00       	jmp    0x78725cc04250
    78725cc04174:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0417b:	00 
    78725cc0417c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04182:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04188:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0418e:	be 01 00 00 00       	mov    esi,0x1
    78725cc04193:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc04198:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0419f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc041a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc041ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc041b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc041bb:	e9 0a 27 00 00       	jmp    0x78725cc068ca
    78725cc041c0:	eb 82                	jmp    0x78725cc04144
    78725cc041c2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc041c9:	00 
    78725cc041ca:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc041d1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc041d8:	00 
    78725cc041d9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc041e0:	00 00 00 
    78725cc041e3:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc041ea:	00 00 00 
    78725cc041ed:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc041f4:	60 00 00 
    78725cc041f7:	ba 28 03 01 00       	mov    edx,0x10328
    78725cc041fc:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc04202:	ff d0                	call   rax
    78725cc04204:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0420b:	00 
    78725cc0420c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04212:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04218:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0421e:	be 01 00 00 00       	mov    esi,0x1
    78725cc04223:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc04228:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0422f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04236:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0423d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04244:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0424b:	e9 7a 26 00 00       	jmp    0x78725cc068ca
    78725cc04250:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc04257:	00 
    78725cc04258:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc0425f:	c1 e9 0c             	shr    ecx,0xc
    78725cc04262:	89 c9                	mov    ecx,ecx
    78725cc04264:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc04268:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    78725cc0426f:	00 
    78725cc04270:	48 83 f8 00          	cmp    rax,0x0
    78725cc04274:	74 23                	je     0x78725cc04299
    78725cc04276:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    78725cc0427d:	00 
    78725cc0427e:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    78725cc04285:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    78725cc0428c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc04292:	89 c9                	mov    ecx,ecx
    78725cc04294:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc04297:	eb 51                	jmp    0x78725cc042ea
    78725cc04299:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc042a0:	00 
    78725cc042a1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    78725cc042a8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    78725cc042af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc042b6:	00 
    78725cc042b7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc042be:	00 00 00 
    78725cc042c1:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc042c8:	00 00 00 
    78725cc042cb:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc042d2:	60 00 00 
    78725cc042d5:	ff d0                	call   rax
    78725cc042d7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc042de:	00 
    78725cc042df:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc042e6:	75 32                	jne    0x78725cc0431a
    78725cc042e8:	eb 7c                	jmp    0x78725cc04366
    78725cc042ea:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc042f1:	00 
    78725cc042f2:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    78725cc042f9:	83 e8 04             	sub    eax,0x4
    78725cc042fc:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    78725cc04303:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    78725cc04306:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    78725cc0430d:	83 e0 03             	and    eax,0x3
    78725cc04310:	83 f8 00             	cmp    eax,0x0
    78725cc04313:	75 53                	jne    0x78725cc04368
    78725cc04315:	e9 dc 00 00 00       	jmp    0x78725cc043f6
    78725cc0431a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04321:	00 
    78725cc04322:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04328:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0432e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04334:	be 01 00 00 00       	mov    esi,0x1
    78725cc04339:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0433e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04345:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0434c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04353:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0435a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04361:	e9 64 25 00 00       	jmp    0x78725cc068ca
    78725cc04366:	eb 82                	jmp    0x78725cc042ea
    78725cc04368:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0436f:	00 
    78725cc04370:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc04377:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc0437e:	00 
    78725cc0437f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc04386:	00 00 00 
    78725cc04389:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc04390:	00 00 00 
    78725cc04393:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0439a:	60 00 00 
    78725cc0439d:	ba 28 03 01 00       	mov    edx,0x10328
    78725cc043a2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc043a8:	ff d0                	call   rax
    78725cc043aa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc043b1:	00 
    78725cc043b2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc043b8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc043be:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc043c4:	be 01 00 00 00       	mov    esi,0x1
    78725cc043c9:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc043ce:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc043d5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc043dc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc043e3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc043ea:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc043f1:	e9 d4 24 00 00       	jmp    0x78725cc068ca
    78725cc043f6:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc043fd:	00 
    78725cc043fe:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc04405:	c1 e9 0c             	shr    ecx,0xc
    78725cc04408:	89 c9                	mov    ecx,ecx
    78725cc0440a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0440e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    78725cc04415:	00 
    78725cc04416:	48 83 f8 00          	cmp    rax,0x0
    78725cc0441a:	74 23                	je     0x78725cc0443f
    78725cc0441c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    78725cc04423:	00 
    78725cc04424:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    78725cc0442b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    78725cc04432:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc04438:	89 c9                	mov    ecx,ecx
    78725cc0443a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc0443d:	eb 51                	jmp    0x78725cc04490
    78725cc0443f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04446:	00 
    78725cc04447:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    78725cc0444e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    78725cc04455:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc0445c:	00 
    78725cc0445d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc04464:	00 00 00 
    78725cc04467:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc0446e:	00 00 00 
    78725cc04471:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc04478:	60 00 00 
    78725cc0447b:	ff d0                	call   rax
    78725cc0447d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04484:	00 
    78725cc04485:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0448c:	75 32                	jne    0x78725cc044c0
    78725cc0448e:	eb 7c                	jmp    0x78725cc0450c
    78725cc04490:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc04497:	00 
    78725cc04498:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    78725cc0449f:	83 e8 04             	sub    eax,0x4
    78725cc044a2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    78725cc044a9:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    78725cc044ac:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    78725cc044b3:	83 e0 03             	and    eax,0x3
    78725cc044b6:	83 f8 00             	cmp    eax,0x0
    78725cc044b9:	75 53                	jne    0x78725cc0450e
    78725cc044bb:	e9 dc 00 00 00       	jmp    0x78725cc0459c
    78725cc044c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc044c7:	00 
    78725cc044c8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc044ce:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc044d4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc044da:	be 01 00 00 00       	mov    esi,0x1
    78725cc044df:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc044e4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc044eb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc044f2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc044f9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04500:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04507:	e9 be 23 00 00       	jmp    0x78725cc068ca
    78725cc0450c:	eb 82                	jmp    0x78725cc04490
    78725cc0450e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04515:	00 
    78725cc04516:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc0451d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc04524:	00 
    78725cc04525:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0452c:	00 00 00 
    78725cc0452f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc04536:	00 00 00 
    78725cc04539:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc04540:	60 00 00 
    78725cc04543:	ba 28 03 01 00       	mov    edx,0x10328
    78725cc04548:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0454e:	ff d0                	call   rax
    78725cc04550:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04557:	00 
    78725cc04558:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0455e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04564:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0456a:	be 01 00 00 00       	mov    esi,0x1
    78725cc0456f:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc04574:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0457b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04582:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04589:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04590:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04597:	e9 2e 23 00 00       	jmp    0x78725cc068ca
    78725cc0459c:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc045a3:	00 
    78725cc045a4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc045ab:	c1 e9 0c             	shr    ecx,0xc
    78725cc045ae:	89 c9                	mov    ecx,ecx
    78725cc045b0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc045b4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    78725cc045bb:	00 
    78725cc045bc:	48 83 f8 00          	cmp    rax,0x0
    78725cc045c0:	74 23                	je     0x78725cc045e5
    78725cc045c2:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    78725cc045c9:	00 
    78725cc045ca:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    78725cc045d1:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    78725cc045d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc045de:	89 c9                	mov    ecx,ecx
    78725cc045e0:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc045e3:	eb 51                	jmp    0x78725cc04636
    78725cc045e5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc045ec:	00 
    78725cc045ed:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    78725cc045f4:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    78725cc045fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc04602:	00 
    78725cc04603:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0460a:	00 00 00 
    78725cc0460d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc04614:	00 00 00 
    78725cc04617:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0461e:	60 00 00 
    78725cc04621:	ff d0                	call   rax
    78725cc04623:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0462a:	00 
    78725cc0462b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc04632:	75 32                	jne    0x78725cc04666
    78725cc04634:	eb 7c                	jmp    0x78725cc046b2
    78725cc04636:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc0463d:	00 
    78725cc0463e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    78725cc04645:	83 e8 04             	sub    eax,0x4
    78725cc04648:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    78725cc0464f:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    78725cc04652:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    78725cc04659:	83 e0 03             	and    eax,0x3
    78725cc0465c:	83 f8 00             	cmp    eax,0x0
    78725cc0465f:	75 53                	jne    0x78725cc046b4
    78725cc04661:	e9 dc 00 00 00       	jmp    0x78725cc04742
    78725cc04666:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0466d:	00 
    78725cc0466e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04674:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0467a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04680:	be 01 00 00 00       	mov    esi,0x1
    78725cc04685:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0468a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04691:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04698:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0469f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc046a6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc046ad:	e9 18 22 00 00       	jmp    0x78725cc068ca
    78725cc046b2:	eb 82                	jmp    0x78725cc04636
    78725cc046b4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc046bb:	00 
    78725cc046bc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc046c3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc046ca:	00 
    78725cc046cb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc046d2:	00 00 00 
    78725cc046d5:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc046dc:	00 00 00 
    78725cc046df:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc046e6:	60 00 00 
    78725cc046e9:	ba 28 03 01 00       	mov    edx,0x10328
    78725cc046ee:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc046f4:	ff d0                	call   rax
    78725cc046f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc046fd:	00 
    78725cc046fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04704:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0470a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04710:	be 01 00 00 00       	mov    esi,0x1
    78725cc04715:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0471a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04721:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04728:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0472f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04736:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0473d:	e9 88 21 00 00       	jmp    0x78725cc068ca
    78725cc04742:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc04749:	00 
    78725cc0474a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc04751:	c1 e9 0c             	shr    ecx,0xc
    78725cc04754:	89 c9                	mov    ecx,ecx
    78725cc04756:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0475a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    78725cc04761:	00 
    78725cc04762:	48 83 f8 00          	cmp    rax,0x0
    78725cc04766:	74 23                	je     0x78725cc0478b
    78725cc04768:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    78725cc0476f:	00 
    78725cc04770:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    78725cc04777:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    78725cc0477e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc04784:	89 c9                	mov    ecx,ecx
    78725cc04786:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc04789:	eb 51                	jmp    0x78725cc047dc
    78725cc0478b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04792:	00 
    78725cc04793:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    78725cc0479a:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    78725cc047a1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc047a8:	00 
    78725cc047a9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc047b0:	00 00 00 
    78725cc047b3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    78725cc047ba:	00 00 00 
    78725cc047bd:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc047c4:	60 00 00 
    78725cc047c7:	ff d0                	call   rax
    78725cc047c9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc047d0:	00 
    78725cc047d1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc047d8:	75 26                	jne    0x78725cc04800
    78725cc047da:	eb 70                	jmp    0x78725cc0484c
    78725cc047dc:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc047e3:	00 
    78725cc047e4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc047eb:	00 
    78725cc047ec:	8b 94 24 88 01 00 00 	mov    edx,DWORD PTR [rsp+0x188]
    78725cc047f3:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc047f6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc047f9:	75 53                	jne    0x78725cc0484e
    78725cc047fb:	e9 93 00 00 00       	jmp    0x78725cc04893
    78725cc04800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04807:	00 
    78725cc04808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0480e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0481a:	be 01 00 00 00       	mov    esi,0x1
    78725cc0481f:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc04824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0482b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04847:	e9 7e 20 00 00       	jmp    0x78725cc068ca
    78725cc0484c:	eb 8e                	jmp    0x78725cc047dc
    78725cc0484e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04855:	00 
    78725cc04856:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    78725cc0485d:	03 01 00 
    78725cc04860:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc04867:	00 00 00 
    78725cc0486a:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    78725cc04871:	00 00 00 
    78725cc04874:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0487b:	60 00 00 
    78725cc0487e:	ff d0                	call   rax
    78725cc04880:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04887:	00 
    78725cc04888:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0488f:	75 04                	jne    0x78725cc04895
    78725cc04891:	eb 4e                	jmp    0x78725cc048e1
    78725cc04893:	eb 4e                	jmp    0x78725cc048e3
    78725cc04895:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0489c:	00 
    78725cc0489d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc048a3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc048a9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc048af:	be 01 00 00 00       	mov    esi,0x1
    78725cc048b4:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc048b9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc048c0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc048c7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc048ce:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc048d5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc048dc:	e9 e9 1f 00 00       	jmp    0x78725cc068ca
    78725cc048e1:	eb b0                	jmp    0x78725cc04893
    78725cc048e3:	eb 00                	jmp    0x78725cc048e5
    78725cc048e5:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    78725cc048ec:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc048f3:	00 
    78725cc048f4:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    78725cc048fa:	89 94 24 74 01 00 00 	mov    DWORD PTR [rsp+0x174],edx
    78725cc04901:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    78725cc04904:	89 8c 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],ecx
    78725cc0490b:	83 e8 04             	sub    eax,0x4
    78725cc0490e:	89 84 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],eax
    78725cc04915:	83 e0 03             	and    eax,0x3
    78725cc04918:	83 f8 00             	cmp    eax,0x0
    78725cc0491b:	0f 84 98 00 00 00    	je     0x78725cc049b9
    78725cc04921:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04928:	00 
    78725cc04929:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    78725cc04930:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc04937:	00 
    78725cc04938:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    78725cc0493f:	03 01 00 
    78725cc04942:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc04949:	00 00 00 
    78725cc0494c:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc04953:	00 00 00 
    78725cc04956:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0495d:	60 00 00 
    78725cc04960:	ba 2a 03 01 00       	mov    edx,0x1032a
    78725cc04965:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0496b:	ff d0                	call   rax
    78725cc0496d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04974:	00 
    78725cc04975:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0497b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04981:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04987:	be 02 00 00 00       	mov    esi,0x2
    78725cc0498c:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04991:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04998:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0499f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc049a6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc049ad:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc049b4:	e9 11 1f 00 00       	jmp    0x78725cc068ca
    78725cc049b9:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc049c0:	00 
    78725cc049c1:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    78725cc049c8:	c1 e9 0c             	shr    ecx,0xc
    78725cc049cb:	89 c9                	mov    ecx,ecx
    78725cc049cd:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc049d1:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    78725cc049d8:	00 
    78725cc049d9:	48 83 f8 00          	cmp    rax,0x0
    78725cc049dd:	74 23                	je     0x78725cc04a02
    78725cc049df:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    78725cc049e6:	00 
    78725cc049e7:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    78725cc049ee:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    78725cc049f5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc049fb:	89 c9                	mov    ecx,ecx
    78725cc049fd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc04a00:	eb 5b                	jmp    0x78725cc04a5d
    78725cc04a02:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04a09:	00 
    78725cc04a0a:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    78725cc04a11:	8b b4 24 7c 01 00 00 	mov    esi,DWORD PTR [rsp+0x17c]
    78725cc04a18:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc04a1f:	00 
    78725cc04a20:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    78725cc04a27:	03 01 00 
    78725cc04a2a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc04a31:	00 00 00 
    78725cc04a34:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc04a3b:	00 00 00 
    78725cc04a3e:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc04a45:	60 00 00 
    78725cc04a48:	ff d0                	call   rax
    78725cc04a4a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04a51:	00 
    78725cc04a52:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc04a59:	75 20                	jne    0x78725cc04a7b
    78725cc04a5b:	eb 6a                	jmp    0x78725cc04ac7
    78725cc04a5d:	8b 84 24 7c 01 00 00 	mov    eax,DWORD PTR [rsp+0x17c]
    78725cc04a64:	83 e8 04             	sub    eax,0x4
    78725cc04a67:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    78725cc04a6e:	83 e0 03             	and    eax,0x3
    78725cc04a71:	83 f8 00             	cmp    eax,0x0
    78725cc04a74:	75 53                	jne    0x78725cc04ac9
    78725cc04a76:	e9 e6 00 00 00       	jmp    0x78725cc04b61
    78725cc04a7b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04a82:	00 
    78725cc04a83:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04a89:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04a8f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04a95:	be 02 00 00 00       	mov    esi,0x2
    78725cc04a9a:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04a9f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04aa6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04aad:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04ab4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04abb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04ac2:	e9 03 1e 00 00       	jmp    0x78725cc068ca
    78725cc04ac7:	eb 94                	jmp    0x78725cc04a5d
    78725cc04ac9:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04ad0:	00 
    78725cc04ad1:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc04ad8:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc04adf:	00 
    78725cc04ae0:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    78725cc04ae7:	03 01 00 
    78725cc04aea:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc04af1:	00 00 00 
    78725cc04af4:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc04afb:	00 00 00 
    78725cc04afe:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc04b05:	60 00 00 
    78725cc04b08:	ba 2a 03 01 00       	mov    edx,0x1032a
    78725cc04b0d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc04b13:	ff d0                	call   rax
    78725cc04b15:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04b1c:	00 
    78725cc04b1d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04b23:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04b29:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04b2f:	be 02 00 00 00       	mov    esi,0x2
    78725cc04b34:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04b39:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04b40:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04b47:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04b4e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04b55:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04b5c:	e9 69 1d 00 00       	jmp    0x78725cc068ca
    78725cc04b61:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc04b68:	00 
    78725cc04b69:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc04b70:	c1 e9 0c             	shr    ecx,0xc
    78725cc04b73:	89 c9                	mov    ecx,ecx
    78725cc04b75:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc04b79:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
    78725cc04b80:	00 
    78725cc04b81:	48 83 f8 00          	cmp    rax,0x0
    78725cc04b85:	74 23                	je     0x78725cc04baa
    78725cc04b87:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    78725cc04b8e:	00 
    78725cc04b8f:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    78725cc04b96:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc04b9d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc04ba3:	89 c9                	mov    ecx,ecx
    78725cc04ba5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc04ba8:	eb 5b                	jmp    0x78725cc04c05
    78725cc04baa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04bb1:	00 
    78725cc04bb2:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    78725cc04bb9:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    78725cc04bc0:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc04bc7:	00 
    78725cc04bc8:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    78725cc04bcf:	03 01 00 
    78725cc04bd2:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc04bd9:	00 00 00 
    78725cc04bdc:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    78725cc04be3:	00 00 00 
    78725cc04be6:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc04bed:	60 00 00 
    78725cc04bf0:	ff d0                	call   rax
    78725cc04bf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04bf9:	00 
    78725cc04bfa:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc04c01:	75 2c                	jne    0x78725cc04c2f
    78725cc04c03:	eb 76                	jmp    0x78725cc04c7b
    78725cc04c05:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc04c0c:	00 
    78725cc04c0d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc04c14:	00 
    78725cc04c15:	8b 94 24 64 01 00 00 	mov    edx,DWORD PTR [rsp+0x164]
    78725cc04c1c:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    78725cc04c1f:	83 ea 00             	sub    edx,0x0
    78725cc04c22:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    78725cc04c25:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc04c28:	75 53                	jne    0x78725cc04c7d
    78725cc04c2a:	e9 93 00 00 00       	jmp    0x78725cc04cc2
    78725cc04c2f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04c36:	00 
    78725cc04c37:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04c3d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04c43:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04c49:	be 02 00 00 00       	mov    esi,0x2
    78725cc04c4e:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04c53:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04c5a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04c61:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04c68:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04c6f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04c76:	e9 4f 1c 00 00       	jmp    0x78725cc068ca
    78725cc04c7b:	eb 88                	jmp    0x78725cc04c05
    78725cc04c7d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04c84:	00 
    78725cc04c85:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1032e
    78725cc04c8c:	03 01 00 
    78725cc04c8f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc04c96:	00 00 00 
    78725cc04c99:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    78725cc04ca0:	00 00 00 
    78725cc04ca3:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc04caa:	60 00 00 
    78725cc04cad:	ff d0                	call   rax
    78725cc04caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04cb6:	00 
    78725cc04cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc04cbe:	75 04                	jne    0x78725cc04cc4
    78725cc04cc0:	eb 4e                	jmp    0x78725cc04d10
    78725cc04cc2:	eb 4e                	jmp    0x78725cc04d12
    78725cc04cc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04ccb:	00 
    78725cc04ccc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc04cd2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc04cd8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc04cde:	be 02 00 00 00       	mov    esi,0x2
    78725cc04ce3:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04ce8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc04cef:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc04cf6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc04cfd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc04d04:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc04d0b:	e9 ba 1b 00 00       	jmp    0x78725cc068ca
    78725cc04d10:	eb b0                	jmp    0x78725cc04cc2
    78725cc04d12:	eb 00                	jmp    0x78725cc04d14
    78725cc04d14:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04d1b:	00 
    78725cc04d1c:	8b 38                	mov    edi,DWORD PTR [rax]
    78725cc04d1e:	89 bc 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edi
    78725cc04d25:	83 ff 04             	cmp    edi,0x4
    78725cc04d28:	0f 96 c1             	setbe  cl
    78725cc04d2b:	80 e1 01             	and    cl,0x1
    78725cc04d2e:	0f b6 c9             	movzx  ecx,cl
    78725cc04d31:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    78725cc04d38:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    78725cc04d3e:	83 ff 04             	cmp    edi,0x4
    78725cc04d41:	0f 94 c1             	sete   cl
    78725cc04d44:	80 e1 01             	and    cl,0x1
    78725cc04d47:	0f b6 f1             	movzx  esi,cl
    78725cc04d4a:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04d4f:	39 f9                	cmp    ecx,edi
    78725cc04d51:	0f 97 c1             	seta   cl
    78725cc04d54:	80 e1 01             	and    cl,0x1
    78725cc04d57:	0f b6 d1             	movzx  edx,cl
    78725cc04d5a:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc04d5f:	39 f9                	cmp    ecx,edi
    78725cc04d61:	0f 96 c1             	setbe  cl
    78725cc04d64:	80 e1 01             	and    cl,0x1
    78725cc04d67:	0f b6 c9             	movzx  ecx,cl
    78725cc04d6a:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc04d70:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc04d76:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc04d7c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc04d82:	eb 00                	jmp    0x78725cc04d84
    78725cc04d84:	8b 84 24 54 01 00 00 	mov    eax,DWORD PTR [rsp+0x154]
    78725cc04d8b:	83 f8 00             	cmp    eax,0x0
    78725cc04d8e:	75 33                	jne    0x78725cc04dc3
    78725cc04d90:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc04d97:	00 
    78725cc04d98:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    78725cc04d9f:	03 01 00 
    78725cc04da2:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc04da8:	83 c0 04             	add    eax,0x4
    78725cc04dab:	89 84 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],eax
    78725cc04db2:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc04db8:	0f 82 3c 18 00 00    	jb     0x78725cc065fa
    78725cc04dbe:	e9 5a 18 00 00       	jmp    0x78725cc0661d
    78725cc04dc3:	eb 00                	jmp    0x78725cc04dc5
    78725cc04dc5:	eb 00                	jmp    0x78725cc04dc7
    78725cc04dc7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04dce:	00 
    78725cc04dcf:	8b 78 04             	mov    edi,DWORD PTR [rax+0x4]
    78725cc04dd2:	89 bc 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],edi
    78725cc04dd9:	89 fa                	mov    edx,edi
    78725cc04ddb:	83 ea 00             	sub    edx,0x0
    78725cc04dde:	83 fa 00             	cmp    edx,0x0
    78725cc04de1:	0f 94 c1             	sete   cl
    78725cc04de4:	80 e1 01             	and    cl,0x1
    78725cc04de7:	0f b6 f1             	movzx  esi,cl
    78725cc04dea:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    78725cc04df1:	c1 ea 1f             	shr    edx,0x1f
    78725cc04df4:	89 f9                	mov    ecx,edi
    78725cc04df6:	c1 e9 1f             	shr    ecx,0x1f
    78725cc04df9:	89 d3                	mov    ebx,edx
    78725cc04dfb:	31 cb                	xor    ebx,ecx
    78725cc04dfd:	83 f1 00             	xor    ecx,0x0
    78725cc04e00:	21 d9                	and    ecx,ebx
    78725cc04e02:	31 ca                	xor    edx,ecx
    78725cc04e04:	31 c9                	xor    ecx,ecx
    78725cc04e06:	39 f9                	cmp    ecx,edi
    78725cc04e08:	0f 96 c1             	setbe  cl
    78725cc04e0b:	80 e1 01             	and    cl,0x1
    78725cc04e0e:	0f b6 c9             	movzx  ecx,cl
    78725cc04e11:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc04e17:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc04e1d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc04e23:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc04e29:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc04e2f:	eb 00                	jmp    0x78725cc04e31
    78725cc04e31:	8b 84 24 48 01 00 00 	mov    eax,DWORD PTR [rsp+0x148]
    78725cc04e38:	83 f8 00             	cmp    eax,0x0
    78725cc04e3b:	74 33                	je     0x78725cc04e70
    78725cc04e3d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc04e44:	00 
    78725cc04e45:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    78725cc04e4c:	03 01 00 
    78725cc04e4f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc04e55:	83 c0 06             	add    eax,0x6
    78725cc04e58:	89 84 24 40 01 00 00 	mov    DWORD PTR [rsp+0x140],eax
    78725cc04e5f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc04e65:	0f 82 1f 18 00 00    	jb     0x78725cc0668a
    78725cc04e6b:	e9 3d 18 00 00       	jmp    0x78725cc066ad
    78725cc04e70:	eb 00                	jmp    0x78725cc04e72
    78725cc04e72:	eb 00                	jmp    0x78725cc04e74
    78725cc04e74:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04e7b:	00 
    78725cc04e7c:	c7 40 0c 09 3d 00 00 	mov    DWORD PTR [rax+0xc],0x3d09
    78725cc04e83:	eb 00                	jmp    0x78725cc04e85
    78725cc04e85:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04e8c:	00 
    78725cc04e8d:	c7 40 0c 00 48 e8 01 	mov    DWORD PTR [rax+0xc],0x1e84800
    78725cc04e94:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    78725cc04e9b:	00 00 00 
    78725cc04e9e:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    78725cc04ea5:	00 00 00 
    78725cc04ea8:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    78725cc04eaf:	00 00 00 
    78725cc04eb2:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    78725cc04eb9:	00 00 00 
    78725cc04ebc:	eb 00                	jmp    0x78725cc04ebe
    78725cc04ebe:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04ec5:	00 
    78725cc04ec6:	8b bc 24 44 01 00 00 	mov    edi,DWORD PTR [rsp+0x144]
    78725cc04ecd:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    78725cc04ed3:	0f 96 c1             	setbe  cl
    78725cc04ed6:	80 e1 01             	and    cl,0x1
    78725cc04ed9:	0f b6 c9             	movzx  ecx,cl
    78725cc04edc:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    78725cc04ee3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    78725cc04ee9:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    78725cc04eef:	0f 94 c1             	sete   cl
    78725cc04ef2:	80 e1 01             	and    cl,0x1
    78725cc04ef5:	0f b6 f1             	movzx  esi,cl
    78725cc04ef8:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    78725cc04efd:	39 f9                	cmp    ecx,edi
    78725cc04eff:	0f 97 c1             	seta   cl
    78725cc04f02:	80 e1 01             	and    cl,0x1
    78725cc04f05:	0f b6 d1             	movzx  edx,cl
    78725cc04f08:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    78725cc04f0d:	39 f9                	cmp    ecx,edi
    78725cc04f0f:	0f 96 c1             	setbe  cl
    78725cc04f12:	80 e1 01             	and    cl,0x1
    78725cc04f15:	0f b6 c9             	movzx  ecx,cl
    78725cc04f18:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc04f1e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc04f24:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc04f2a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc04f30:	eb 00                	jmp    0x78725cc04f32
    78725cc04f32:	8b 84 24 3c 01 00 00 	mov    eax,DWORD PTR [rsp+0x13c]
    78725cc04f39:	83 f8 00             	cmp    eax,0x0
    78725cc04f3c:	75 33                	jne    0x78725cc04f71
    78725cc04f3e:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc04f45:	00 
    78725cc04f46:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    78725cc04f4d:	03 01 00 
    78725cc04f50:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc04f56:	83 c0 0a             	add    eax,0xa
    78725cc04f59:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    78725cc04f60:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc04f66:	0f 82 ae 17 00 00    	jb     0x78725cc0671a
    78725cc04f6c:	e9 cc 17 00 00       	jmp    0x78725cc0673d
    78725cc04f71:	eb 00                	jmp    0x78725cc04f73
    78725cc04f73:	eb 00                	jmp    0x78725cc04f75
    78725cc04f75:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04f7c:	00 
    78725cc04f7d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    78725cc04f80:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc04f86:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc04f8c:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    78725cc04f93:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc04f96:	eb 00                	jmp    0x78725cc04f98
    78725cc04f98:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc04f9f:	00 
    78725cc04fa0:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    78725cc04fa7:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc04fad:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    78725cc04fb3:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    78725cc04fba:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc04fbd:	eb 00                	jmp    0x78725cc04fbf
    78725cc04fbf:	8b 84 24 30 01 00 00 	mov    eax,DWORD PTR [rsp+0x130]
    78725cc04fc6:	83 e0 03             	and    eax,0x3
    78725cc04fc9:	83 f8 00             	cmp    eax,0x0
    78725cc04fcc:	0f 84 98 00 00 00    	je     0x78725cc0506a
    78725cc04fd2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc04fd9:	00 
    78725cc04fda:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    78725cc04fe1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc04fe8:	00 
    78725cc04fe9:	c7 87 bc 00 00 00 48 	mov    DWORD PTR [rdi+0xbc],0x10348
    78725cc04ff0:	03 01 00 
    78725cc04ff3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc04ffa:	00 00 00 
    78725cc04ffd:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    78725cc05004:	00 00 00 
    78725cc05007:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0500e:	60 00 00 
    78725cc05011:	ba 48 03 01 00       	mov    edx,0x10348
    78725cc05016:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc0501c:	ff d0                	call   rax
    78725cc0501e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05025:	00 
    78725cc05026:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0502c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05032:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05038:	be 0d 00 00 00       	mov    esi,0xd
    78725cc0503d:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05042:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05049:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05050:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05057:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0505e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05065:	e9 60 18 00 00       	jmp    0x78725cc068ca
    78725cc0506a:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc05071:	00 
    78725cc05072:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    78725cc05079:	c1 e9 0c             	shr    ecx,0xc
    78725cc0507c:	89 c9                	mov    ecx,ecx
    78725cc0507e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc05082:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    78725cc05089:	00 
    78725cc0508a:	48 83 f8 00          	cmp    rax,0x0
    78725cc0508e:	74 23                	je     0x78725cc050b3
    78725cc05090:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    78725cc05097:	00 
    78725cc05098:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    78725cc0509f:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    78725cc050a6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc050ac:	89 c9                	mov    ecx,ecx
    78725cc050ae:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc050b1:	eb 5b                	jmp    0x78725cc0510e
    78725cc050b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc050ba:	00 
    78725cc050bb:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    78725cc050c2:	8b b4 24 30 01 00 00 	mov    esi,DWORD PTR [rsp+0x130]
    78725cc050c9:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc050d0:	00 
    78725cc050d1:	c7 80 bc 00 00 00 48 	mov    DWORD PTR [rax+0xbc],0x10348
    78725cc050d8:	03 01 00 
    78725cc050db:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc050e2:	00 00 00 
    78725cc050e5:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    78725cc050ec:	00 00 00 
    78725cc050ef:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc050f6:	60 00 00 
    78725cc050f9:	ff d0                	call   rax
    78725cc050fb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05102:	00 
    78725cc05103:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0510a:	75 14                	jne    0x78725cc05120
    78725cc0510c:	eb 5e                	jmp    0x78725cc0516c
    78725cc0510e:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc05115:	00 
    78725cc05116:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc05119:	75 53                	jne    0x78725cc0516e
    78725cc0511b:	e9 93 00 00 00       	jmp    0x78725cc051b3
    78725cc05120:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05127:	00 
    78725cc05128:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0512e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05134:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0513a:	be 0d 00 00 00       	mov    esi,0xd
    78725cc0513f:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05144:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0514b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05152:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05159:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05160:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05167:	e9 5e 17 00 00       	jmp    0x78725cc068ca
    78725cc0516c:	eb a0                	jmp    0x78725cc0510e
    78725cc0516e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05175:	00 
    78725cc05176:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1034a
    78725cc0517d:	03 01 00 
    78725cc05180:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc05187:	00 00 00 
    78725cc0518a:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    78725cc05191:	00 00 00 
    78725cc05194:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0519b:	60 00 00 
    78725cc0519e:	ff d0                	call   rax
    78725cc051a0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc051a7:	00 
    78725cc051a8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc051af:	75 04                	jne    0x78725cc051b5
    78725cc051b1:	eb 4e                	jmp    0x78725cc05201
    78725cc051b3:	eb 4e                	jmp    0x78725cc05203
    78725cc051b5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc051bc:	00 
    78725cc051bd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc051c3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc051c9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc051cf:	be 0d 00 00 00       	mov    esi,0xd
    78725cc051d4:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc051d9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc051e0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc051e7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc051ee:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc051f5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc051fc:	e9 c9 16 00 00       	jmp    0x78725cc068ca
    78725cc05201:	eb b0                	jmp    0x78725cc051b3
    78725cc05203:	eb 00                	jmp    0x78725cc05205
    78725cc05205:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0520c:	00 
    78725cc0520d:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    78725cc05214:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc0521a:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc05220:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    78725cc05227:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc0522a:	eb 00                	jmp    0x78725cc0522c
    78725cc0522c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05233:	00 
    78725cc05234:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    78725cc0523b:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc05241:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    78725cc05247:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    78725cc0524e:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc05251:	eb 00                	jmp    0x78725cc05253
    78725cc05253:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    78725cc0525a:	83 e0 03             	and    eax,0x3
    78725cc0525d:	83 f8 00             	cmp    eax,0x0
    78725cc05260:	0f 84 98 00 00 00    	je     0x78725cc052fe
    78725cc05266:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0526d:	00 
    78725cc0526e:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    78725cc05275:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc0527c:	00 
    78725cc0527d:	c7 87 bc 00 00 00 52 	mov    DWORD PTR [rdi+0xbc],0x10352
    78725cc05284:	03 01 00 
    78725cc05287:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0528e:	00 00 00 
    78725cc05291:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    78725cc05298:	00 00 00 
    78725cc0529b:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc052a2:	60 00 00 
    78725cc052a5:	ba 52 03 01 00       	mov    edx,0x10352
    78725cc052aa:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc052b0:	ff d0                	call   rax
    78725cc052b2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc052b9:	00 
    78725cc052ba:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc052c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc052c6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc052cc:	be 10 00 00 00       	mov    esi,0x10
    78725cc052d1:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc052d6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc052dd:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc052e4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc052eb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc052f2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc052f9:	e9 cc 15 00 00       	jmp    0x78725cc068ca
    78725cc052fe:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc05305:	00 
    78725cc05306:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    78725cc0530d:	c1 e9 0c             	shr    ecx,0xc
    78725cc05310:	89 c9                	mov    ecx,ecx
    78725cc05312:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc05316:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    78725cc0531d:	00 
    78725cc0531e:	48 83 f8 00          	cmp    rax,0x0
    78725cc05322:	74 23                	je     0x78725cc05347
    78725cc05324:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    78725cc0532b:	00 
    78725cc0532c:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    78725cc05333:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    78725cc0533a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc05340:	89 c9                	mov    ecx,ecx
    78725cc05342:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc05345:	eb 5b                	jmp    0x78725cc053a2
    78725cc05347:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0534e:	00 
    78725cc0534f:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    78725cc05356:	8b b4 24 20 01 00 00 	mov    esi,DWORD PTR [rsp+0x120]
    78725cc0535d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc05364:	00 
    78725cc05365:	c7 80 bc 00 00 00 52 	mov    DWORD PTR [rax+0xbc],0x10352
    78725cc0536c:	03 01 00 
    78725cc0536f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc05376:	00 00 00 
    78725cc05379:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    78725cc05380:	00 00 00 
    78725cc05383:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc0538a:	60 00 00 
    78725cc0538d:	ff d0                	call   rax
    78725cc0538f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05396:	00 
    78725cc05397:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc0539e:	75 14                	jne    0x78725cc053b4
    78725cc053a0:	eb 5e                	jmp    0x78725cc05400
    78725cc053a2:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc053a9:	00 
    78725cc053aa:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc053ad:	75 53                	jne    0x78725cc05402
    78725cc053af:	e9 93 00 00 00       	jmp    0x78725cc05447
    78725cc053b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc053bb:	00 
    78725cc053bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc053c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc053c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc053ce:	be 10 00 00 00       	mov    esi,0x10
    78725cc053d3:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc053d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc053df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc053e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc053ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc053f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc053fb:	e9 ca 14 00 00       	jmp    0x78725cc068ca
    78725cc05400:	eb a0                	jmp    0x78725cc053a2
    78725cc05402:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05409:	00 
    78725cc0540a:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10354
    78725cc05411:	03 01 00 
    78725cc05414:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0541b:	00 00 00 
    78725cc0541e:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    78725cc05425:	00 00 00 
    78725cc05428:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc0542f:	60 00 00 
    78725cc05432:	ff d0                	call   rax
    78725cc05434:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0543b:	00 
    78725cc0543c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc05443:	75 04                	jne    0x78725cc05449
    78725cc05445:	eb 4e                	jmp    0x78725cc05495
    78725cc05447:	eb 4e                	jmp    0x78725cc05497
    78725cc05449:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05450:	00 
    78725cc05451:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05457:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0545d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05463:	be 10 00 00 00       	mov    esi,0x10
    78725cc05468:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0546d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05474:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0547b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05482:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05489:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05490:	e9 35 14 00 00       	jmp    0x78725cc068ca
    78725cc05495:	eb b0                	jmp    0x78725cc05447
    78725cc05497:	eb 00                	jmp    0x78725cc05499
    78725cc05499:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc054a0:	00 
    78725cc054a1:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    78725cc054a8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc054ae:	81 c9 00 00 01 00    	or     ecx,0x10000
    78725cc054b4:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    78725cc054bb:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc054be:	eb 00                	jmp    0x78725cc054c0
    78725cc054c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc054c7:	00 
    78725cc054c8:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    78725cc054cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    78725cc054d5:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    78725cc054db:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    78725cc054e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    78725cc054e5:	eb 00                	jmp    0x78725cc054e7
    78725cc054e7:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    78725cc054ee:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc054f5:	00 
    78725cc054f6:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    78725cc054f9:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    78725cc05500:	83 e0 03             	and    eax,0x3
    78725cc05503:	83 f8 00             	cmp    eax,0x0
    78725cc05506:	0f 84 98 00 00 00    	je     0x78725cc055a4
    78725cc0550c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05513:	00 
    78725cc05514:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc0551b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc05522:	00 
    78725cc05523:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1035c
    78725cc0552a:	03 01 00 
    78725cc0552d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc05534:	00 00 00 
    78725cc05537:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc0553e:	00 00 00 
    78725cc05541:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc05548:	60 00 00 
    78725cc0554b:	ba 5c 03 01 00       	mov    edx,0x1035c
    78725cc05550:	41 b8 00 00 01 00    	mov    r8d,0x10000
    78725cc05556:	ff d0                	call   rax
    78725cc05558:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0555f:	00 
    78725cc05560:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05566:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0556c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05572:	be 13 00 00 00       	mov    esi,0x13
    78725cc05577:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0557c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05583:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0558a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05591:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05598:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0559f:	e9 26 13 00 00       	jmp    0x78725cc068ca
    78725cc055a4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc055ab:	00 
    78725cc055ac:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc055b3:	c1 e9 0c             	shr    ecx,0xc
    78725cc055b6:	89 c9                	mov    ecx,ecx
    78725cc055b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc055bc:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    78725cc055c3:	00 
    78725cc055c4:	48 83 f8 00          	cmp    rax,0x0
    78725cc055c8:	74 23                	je     0x78725cc055ed
    78725cc055ca:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    78725cc055d1:	00 
    78725cc055d2:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    78725cc055d9:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    78725cc055e0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc055e6:	89 c9                	mov    ecx,ecx
    78725cc055e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    78725cc055eb:	eb 5b                	jmp    0x78725cc05648
    78725cc055ed:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc055f4:	00 
    78725cc055f5:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    78725cc055fc:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    78725cc05603:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc0560a:	00 
    78725cc0560b:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1035c
    78725cc05612:	03 01 00 
    78725cc05615:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0561c:	00 00 00 
    78725cc0561f:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    78725cc05626:	00 00 00 
    78725cc05629:	48 b8 20 a6 03 8d 97 	movabs rax,0x60978d03a620
    78725cc05630:	60 00 00 
    78725cc05633:	ff d0                	call   rax
    78725cc05635:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0563c:	00 
    78725cc0563d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc05644:	75 14                	jne    0x78725cc0565a
    78725cc05646:	eb 5e                	jmp    0x78725cc056a6
    78725cc05648:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    78725cc0564f:	00 
    78725cc05650:	80 38 00             	cmp    BYTE PTR [rax],0x0
    78725cc05653:	75 53                	jne    0x78725cc056a8
    78725cc05655:	e9 93 00 00 00       	jmp    0x78725cc056ed
    78725cc0565a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05661:	00 
    78725cc05662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0566e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05674:	be 13 00 00 00       	mov    esi,0x13
    78725cc05679:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0567e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0568c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0569a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc056a1:	e9 24 12 00 00       	jmp    0x78725cc068ca
    78725cc056a6:	eb a0                	jmp    0x78725cc05648
    78725cc056a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc056af:	00 
    78725cc056b0:	c7 87 bc 00 00 00 5e 	mov    DWORD PTR [rdi+0xbc],0x1035e
    78725cc056b7:	03 01 00 
    78725cc056ba:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc056c1:	00 00 00 
    78725cc056c4:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    78725cc056cb:	00 00 00 
    78725cc056ce:	48 b8 00 06 15 8d 97 	movabs rax,0x60978d150600
    78725cc056d5:	60 00 00 
    78725cc056d8:	ff d0                	call   rax
    78725cc056da:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc056e1:	00 
    78725cc056e2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc056e9:	75 04                	jne    0x78725cc056ef
    78725cc056eb:	eb 4e                	jmp    0x78725cc0573b
    78725cc056ed:	eb 4e                	jmp    0x78725cc0573d
    78725cc056ef:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc056f6:	00 
    78725cc056f7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc056fd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05703:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05709:	be 13 00 00 00       	mov    esi,0x13
    78725cc0570e:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05713:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0571a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05721:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05728:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0572f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05736:	e9 8f 11 00 00       	jmp    0x78725cc068ca
    78725cc0573b:	eb b0                	jmp    0x78725cc056ed
    78725cc0573d:	eb 00                	jmp    0x78725cc0573f
    78725cc0573f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05746:	00 
    78725cc05747:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    78725cc0574e:	89 fa                	mov    edx,edi
    78725cc05750:	83 ea 02             	sub    edx,0x2
    78725cc05753:	83 fa 00             	cmp    edx,0x0
    78725cc05756:	0f 94 c1             	sete   cl
    78725cc05759:	80 e1 01             	and    cl,0x1
    78725cc0575c:	0f b6 f1             	movzx  esi,cl
    78725cc0575f:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    78725cc05766:	c1 ea 1f             	shr    edx,0x1f
    78725cc05769:	89 f9                	mov    ecx,edi
    78725cc0576b:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0576e:	89 d3                	mov    ebx,edx
    78725cc05770:	31 cb                	xor    ebx,ecx
    78725cc05772:	83 f1 00             	xor    ecx,0x0
    78725cc05775:	21 d9                	and    ecx,ebx
    78725cc05777:	31 ca                	xor    edx,ecx
    78725cc05779:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0577e:	39 f9                	cmp    ecx,edi
    78725cc05780:	0f 96 c1             	setbe  cl
    78725cc05783:	80 e1 01             	and    cl,0x1
    78725cc05786:	0f b6 c9             	movzx  ecx,cl
    78725cc05789:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc0578f:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc05795:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc0579b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc057a1:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc057a7:	eb 00                	jmp    0x78725cc057a9
    78725cc057a9:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    78725cc057b0:	83 f8 00             	cmp    eax,0x0
    78725cc057b3:	74 33                	je     0x78725cc057e8
    78725cc057b5:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc057bc:	00 
    78725cc057bd:	c7 81 bc 00 00 00 7a 	mov    DWORD PTR [rcx+0xbc],0x1037a
    78725cc057c4:	03 01 00 
    78725cc057c7:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc057cd:	83 c0 15             	add    eax,0x15
    78725cc057d0:	89 84 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],eax
    78725cc057d7:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc057dd:	0f 82 c7 0f 00 00    	jb     0x78725cc067aa
    78725cc057e3:	e9 e5 0f 00 00       	jmp    0x78725cc067cd
    78725cc057e8:	eb 00                	jmp    0x78725cc057ea
    78725cc057ea:	eb 00                	jmp    0x78725cc057ec
    78725cc057ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc057f3:	00 
    78725cc057f4:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    78725cc057fb:	89 fa                	mov    edx,edi
    78725cc057fd:	83 ea 03             	sub    edx,0x3
    78725cc05800:	83 fa 00             	cmp    edx,0x0
    78725cc05803:	0f 94 c1             	sete   cl
    78725cc05806:	80 e1 01             	and    cl,0x1
    78725cc05809:	0f b6 f1             	movzx  esi,cl
    78725cc0580c:	89 b4 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],esi
    78725cc05813:	c1 ea 1f             	shr    edx,0x1f
    78725cc05816:	89 f9                	mov    ecx,edi
    78725cc05818:	c1 e9 1f             	shr    ecx,0x1f
    78725cc0581b:	89 d3                	mov    ebx,edx
    78725cc0581d:	31 cb                	xor    ebx,ecx
    78725cc0581f:	83 f1 00             	xor    ecx,0x0
    78725cc05822:	21 d9                	and    ecx,ebx
    78725cc05824:	31 ca                	xor    edx,ecx
    78725cc05826:	b9 03 00 00 00       	mov    ecx,0x3
    78725cc0582b:	39 f9                	cmp    ecx,edi
    78725cc0582d:	0f 96 c1             	setbe  cl
    78725cc05830:	80 e1 01             	and    cl,0x1
    78725cc05833:	0f b6 c9             	movzx  ecx,cl
    78725cc05836:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    78725cc0583c:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    78725cc05842:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    78725cc05848:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    78725cc0584e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    78725cc05854:	eb 00                	jmp    0x78725cc05856
    78725cc05856:	8b 84 24 f4 00 00 00 	mov    eax,DWORD PTR [rsp+0xf4]
    78725cc0585d:	83 f8 00             	cmp    eax,0x0
    78725cc05860:	74 33                	je     0x78725cc05895
    78725cc05862:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc05869:	00 
    78725cc0586a:	c7 81 bc 00 00 00 a4 	mov    DWORD PTR [rcx+0xbc],0x103a4
    78725cc05871:	03 01 00 
    78725cc05874:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    78725cc0587a:	83 c0 17             	add    eax,0x17
    78725cc0587d:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    78725cc05884:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0588a:	0f 82 aa 0f 00 00    	jb     0x78725cc0683a
    78725cc05890:	e9 c8 0f 00 00       	jmp    0x78725cc0685d
    78725cc05895:	eb 00                	jmp    0x78725cc05897
    78725cc05897:	eb 00                	jmp    0x78725cc05899
    78725cc05899:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc058a0:	00 
    78725cc058a1:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    78725cc058a7:	eb 00                	jmp    0x78725cc058a9
    78725cc058a9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    78725cc058b0:	83 e0 03             	and    eax,0x3
    78725cc058b3:	83 f8 00             	cmp    eax,0x0
    78725cc058b6:	0f 84 97 00 00 00    	je     0x78725cc05953
    78725cc058bc:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc058c3:	00 
    78725cc058c4:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc058cb:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc058d2:	00 
    78725cc058d3:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    78725cc058da:	03 01 00 
    78725cc058dd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc058e4:	00 00 00 
    78725cc058e7:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    78725cc058ee:	00 00 00 
    78725cc058f1:	31 c0                	xor    eax,eax
    78725cc058f3:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc058fa:	60 00 00 
    78725cc058fd:	ba 68 03 01 00       	mov    edx,0x10368
    78725cc05902:	45 31 c0             	xor    r8d,r8d
    78725cc05905:	ff d0                	call   rax
    78725cc05907:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0590e:	00 
    78725cc0590f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05915:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0591b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05921:	be 19 00 00 00       	mov    esi,0x19
    78725cc05926:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc0592b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05932:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05939:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05940:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05947:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0594e:	e9 77 0f 00 00       	jmp    0x78725cc068ca
    78725cc05953:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc0595a:	00 
    78725cc0595b:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc05962:	c1 e9 0c             	shr    ecx,0xc
    78725cc05965:	89 c9                	mov    ecx,ecx
    78725cc05967:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0596b:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    78725cc05972:	00 
    78725cc05973:	48 83 f8 00          	cmp    rax,0x0
    78725cc05977:	74 23                	je     0x78725cc0599c
    78725cc05979:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    78725cc05980:	00 
    78725cc05981:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    78725cc05988:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0598e:	89 c9                	mov    ecx,ecx
    78725cc05990:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc05993:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    78725cc0599a:	eb 5d                	jmp    0x78725cc059f9
    78725cc0599c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc059a3:	00 
    78725cc059a4:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    78725cc059ab:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc059b2:	00 
    78725cc059b3:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    78725cc059ba:	03 01 00 
    78725cc059bd:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc059c4:	00 00 00 
    78725cc059c7:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    78725cc059ce:	00 00 00 
    78725cc059d1:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc059d8:	60 00 00 
    78725cc059db:	ff d0                	call   rax
    78725cc059dd:	89 c1                	mov    ecx,eax
    78725cc059df:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc059e6:	00 
    78725cc059e7:	89 8c 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],ecx
    78725cc059ee:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc059f5:	75 2e                	jne    0x78725cc05a25
    78725cc059f7:	eb 78                	jmp    0x78725cc05a71
    78725cc059f9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    78725cc05a00:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    78725cc05a07:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    78725cc05a0e:	83 c0 04             	add    eax,0x4
    78725cc05a11:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    78725cc05a18:	83 e0 03             	and    eax,0x3
    78725cc05a1b:	83 f8 00             	cmp    eax,0x0
    78725cc05a1e:	75 64                	jne    0x78725cc05a84
    78725cc05a20:	e9 f6 00 00 00       	jmp    0x78725cc05b1b
    78725cc05a25:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05a2c:	00 
    78725cc05a2d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05a33:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05a39:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05a3f:	be 19 00 00 00       	mov    esi,0x19
    78725cc05a44:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc05a49:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05a50:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05a57:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05a5e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05a65:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05a6c:	e9 59 0e 00 00       	jmp    0x78725cc068ca
    78725cc05a71:	8b 84 24 e0 00 00 00 	mov    eax,DWORD PTR [rsp+0xe0]
    78725cc05a78:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    78725cc05a7f:	e9 75 ff ff ff       	jmp    0x78725cc059f9
    78725cc05a84:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05a8b:	00 
    78725cc05a8c:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc05a93:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc05a9a:	00 
    78725cc05a9b:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    78725cc05aa2:	03 01 00 
    78725cc05aa5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    78725cc05aac:	00 00 00 
    78725cc05aaf:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    78725cc05ab6:	00 00 00 
    78725cc05ab9:	31 c0                	xor    eax,eax
    78725cc05abb:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc05ac2:	60 00 00 
    78725cc05ac5:	ba 68 03 01 00       	mov    edx,0x10368
    78725cc05aca:	45 31 c0             	xor    r8d,r8d
    78725cc05acd:	ff d0                	call   rax
    78725cc05acf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05ad6:	00 
    78725cc05ad7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05add:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05ae3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05ae9:	be 19 00 00 00       	mov    esi,0x19
    78725cc05aee:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc05af3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05afa:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05b01:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05b08:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05b0f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05b16:	e9 af 0d 00 00       	jmp    0x78725cc068ca
    78725cc05b1b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc05b22:	00 
    78725cc05b23:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc05b2a:	c1 e9 0c             	shr    ecx,0xc
    78725cc05b2d:	89 c9                	mov    ecx,ecx
    78725cc05b2f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc05b33:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    78725cc05b3a:	00 
    78725cc05b3b:	48 83 f8 00          	cmp    rax,0x0
    78725cc05b3f:	74 23                	je     0x78725cc05b64
    78725cc05b41:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    78725cc05b48:	00 
    78725cc05b49:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc05b50:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc05b56:	89 c9                	mov    ecx,ecx
    78725cc05b58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc05b5b:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    78725cc05b62:	eb 60                	jmp    0x78725cc05bc4
    78725cc05b64:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05b6b:	00 
    78725cc05b6c:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    78725cc05b73:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc05b7a:	00 
    78725cc05b7b:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    78725cc05b82:	03 01 00 
    78725cc05b85:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    78725cc05b8c:	00 00 00 
    78725cc05b8f:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    78725cc05b96:	00 00 00 
    78725cc05b99:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc05ba0:	60 00 00 
    78725cc05ba3:	ff d0                	call   rax
    78725cc05ba5:	89 c1                	mov    ecx,eax
    78725cc05ba7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05bae:	00 
    78725cc05baf:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    78725cc05bb6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc05bbd:	75 41                	jne    0x78725cc05c00
    78725cc05bbf:	e9 88 00 00 00       	jmp    0x78725cc05c4c
    78725cc05bc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05bcb:	00 
    78725cc05bcc:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    78725cc05bd3:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    78725cc05bda:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    78725cc05be1:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    78725cc05be8:	83 c1 04             	add    ecx,0x4
    78725cc05beb:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    78725cc05bf2:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    78725cc05bf5:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    78725cc05bfb:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc05bfe:	eb 5f                	jmp    0x78725cc05c5f
    78725cc05c00:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05c07:	00 
    78725cc05c08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05c0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05c14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05c1a:	be 19 00 00 00       	mov    esi,0x19
    78725cc05c1f:	b9 04 00 00 00       	mov    ecx,0x4
    78725cc05c24:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05c2b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05c32:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05c39:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05c40:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05c47:	e9 7e 0c 00 00       	jmp    0x78725cc068ca
    78725cc05c4c:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    78725cc05c53:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    78725cc05c5a:	e9 65 ff ff ff       	jmp    0x78725cc05bc4
    78725cc05c5f:	eb 00                	jmp    0x78725cc05c61
    78725cc05c61:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    78725cc05c68:	83 e0 03             	and    eax,0x3
    78725cc05c6b:	83 f8 00             	cmp    eax,0x0
    78725cc05c6e:	0f 84 97 00 00 00    	je     0x78725cc05d0b
    78725cc05c74:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05c7b:	00 
    78725cc05c7c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc05c83:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc05c8a:	00 
    78725cc05c8b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc05c92:	03 01 00 
    78725cc05c95:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc05c9c:	00 00 00 
    78725cc05c9f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc05ca6:	00 00 00 
    78725cc05ca9:	31 c0                	xor    eax,eax
    78725cc05cab:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc05cb2:	60 00 00 
    78725cc05cb5:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc05cba:	45 31 c0             	xor    r8d,r8d
    78725cc05cbd:	ff d0                	call   rax
    78725cc05cbf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05cc6:	00 
    78725cc05cc7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05ccd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05cd3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05cd9:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc05cde:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05ce3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05cea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05cf1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05cf8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05cff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05d06:	e9 bf 0b 00 00       	jmp    0x78725cc068ca
    78725cc05d0b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc05d12:	00 
    78725cc05d13:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc05d1a:	c1 e9 0c             	shr    ecx,0xc
    78725cc05d1d:	89 c9                	mov    ecx,ecx
    78725cc05d1f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc05d23:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    78725cc05d2a:	00 
    78725cc05d2b:	48 83 f8 00          	cmp    rax,0x0
    78725cc05d2f:	74 23                	je     0x78725cc05d54
    78725cc05d31:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    78725cc05d38:	00 
    78725cc05d39:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    78725cc05d40:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc05d46:	89 c9                	mov    ecx,ecx
    78725cc05d48:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc05d4b:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    78725cc05d52:	eb 5d                	jmp    0x78725cc05db1
    78725cc05d54:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05d5b:	00 
    78725cc05d5c:	8b b4 24 c4 00 00 00 	mov    esi,DWORD PTR [rsp+0xc4]
    78725cc05d63:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc05d6a:	00 
    78725cc05d6b:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc05d72:	03 01 00 
    78725cc05d75:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc05d7c:	00 00 00 
    78725cc05d7f:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc05d86:	00 00 00 
    78725cc05d89:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc05d90:	60 00 00 
    78725cc05d93:	ff d0                	call   rax
    78725cc05d95:	89 c1                	mov    ecx,eax
    78725cc05d97:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05d9e:	00 
    78725cc05d9f:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    78725cc05da6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc05dad:	75 32                	jne    0x78725cc05de1
    78725cc05daf:	eb 7c                	jmp    0x78725cc05e2d
    78725cc05db1:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    78725cc05db8:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc05dbf:	00 
    78725cc05dc0:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    78725cc05dc7:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    78725cc05dca:	83 c0 04             	add    eax,0x4
    78725cc05dcd:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    78725cc05dd4:	83 e0 03             	and    eax,0x3
    78725cc05dd7:	83 f8 00             	cmp    eax,0x0
    78725cc05dda:	75 64                	jne    0x78725cc05e40
    78725cc05ddc:	e9 f6 00 00 00       	jmp    0x78725cc05ed7
    78725cc05de1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05de8:	00 
    78725cc05de9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05def:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05df5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05dfb:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc05e00:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05e05:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05e0c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05e13:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05e1a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05e21:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05e28:	e9 9d 0a 00 00       	jmp    0x78725cc068ca
    78725cc05e2d:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    78725cc05e34:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    78725cc05e3b:	e9 71 ff ff ff       	jmp    0x78725cc05db1
    78725cc05e40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc05e47:	00 
    78725cc05e48:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc05e4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc05e56:	00 
    78725cc05e57:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc05e5e:	03 01 00 
    78725cc05e61:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc05e68:	00 00 00 
    78725cc05e6b:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc05e72:	00 00 00 
    78725cc05e75:	31 c0                	xor    eax,eax
    78725cc05e77:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc05e7e:	60 00 00 
    78725cc05e81:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc05e86:	45 31 c0             	xor    r8d,r8d
    78725cc05e89:	ff d0                	call   rax
    78725cc05e8b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05e92:	00 
    78725cc05e93:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05e99:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05e9f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05ea5:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc05eaa:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05eaf:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05eb6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05ebd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05ec4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05ecb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05ed2:	e9 f3 09 00 00       	jmp    0x78725cc068ca
    78725cc05ed7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc05ede:	00 
    78725cc05edf:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc05ee6:	c1 e9 0c             	shr    ecx,0xc
    78725cc05ee9:	89 c9                	mov    ecx,ecx
    78725cc05eeb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc05eef:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    78725cc05ef6:	00 
    78725cc05ef7:	48 83 f8 00          	cmp    rax,0x0
    78725cc05efb:	74 23                	je     0x78725cc05f20
    78725cc05efd:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    78725cc05f04:	00 
    78725cc05f05:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    78725cc05f0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc05f12:	89 c9                	mov    ecx,ecx
    78725cc05f14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc05f17:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    78725cc05f1e:	eb 5d                	jmp    0x78725cc05f7d
    78725cc05f20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05f27:	00 
    78725cc05f28:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    78725cc05f2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc05f36:	00 
    78725cc05f37:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc05f3e:	03 01 00 
    78725cc05f41:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc05f48:	00 00 00 
    78725cc05f4b:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc05f52:	00 00 00 
    78725cc05f55:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc05f5c:	60 00 00 
    78725cc05f5f:	ff d0                	call   rax
    78725cc05f61:	89 c1                	mov    ecx,eax
    78725cc05f63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05f6a:	00 
    78725cc05f6b:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    78725cc05f72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc05f79:	75 32                	jne    0x78725cc05fad
    78725cc05f7b:	eb 7c                	jmp    0x78725cc05ff9
    78725cc05f7d:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    78725cc05f84:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc05f8b:	00 
    78725cc05f8c:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    78725cc05f93:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    78725cc05f96:	83 c0 04             	add    eax,0x4
    78725cc05f99:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    78725cc05fa0:	83 e0 03             	and    eax,0x3
    78725cc05fa3:	83 f8 00             	cmp    eax,0x0
    78725cc05fa6:	75 64                	jne    0x78725cc0600c
    78725cc05fa8:	e9 f6 00 00 00       	jmp    0x78725cc060a3
    78725cc05fad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc05fb4:	00 
    78725cc05fb5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc05fbb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc05fc1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc05fc7:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc05fcc:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc05fd1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc05fd8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc05fdf:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc05fe6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc05fed:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc05ff4:	e9 d1 08 00 00       	jmp    0x78725cc068ca
    78725cc05ff9:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    78725cc06000:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    78725cc06007:	e9 71 ff ff ff       	jmp    0x78725cc05f7d
    78725cc0600c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc06013:	00 
    78725cc06014:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc0601b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc06022:	00 
    78725cc06023:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc0602a:	03 01 00 
    78725cc0602d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc06034:	00 00 00 
    78725cc06037:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc0603e:	00 00 00 
    78725cc06041:	31 c0                	xor    eax,eax
    78725cc06043:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc0604a:	60 00 00 
    78725cc0604d:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc06052:	45 31 c0             	xor    r8d,r8d
    78725cc06055:	ff d0                	call   rax
    78725cc06057:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0605e:	00 
    78725cc0605f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc06065:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0606b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc06071:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc06076:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0607b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc06082:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc06089:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc06090:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc06097:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc0609e:	e9 27 08 00 00       	jmp    0x78725cc068ca
    78725cc060a3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc060aa:	00 
    78725cc060ab:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc060b2:	c1 e9 0c             	shr    ecx,0xc
    78725cc060b5:	89 c9                	mov    ecx,ecx
    78725cc060b7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc060bb:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    78725cc060c2:	00 
    78725cc060c3:	48 83 f8 00          	cmp    rax,0x0
    78725cc060c7:	74 23                	je     0x78725cc060ec
    78725cc060c9:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    78725cc060d0:	00 
    78725cc060d1:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    78725cc060d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc060de:	89 c9                	mov    ecx,ecx
    78725cc060e0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc060e3:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc060ea:	eb 5d                	jmp    0x78725cc06149
    78725cc060ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc060f3:	00 
    78725cc060f4:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    78725cc060fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc06102:	00 
    78725cc06103:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc0610a:	03 01 00 
    78725cc0610d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc06114:	00 00 00 
    78725cc06117:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc0611e:	00 00 00 
    78725cc06121:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc06128:	60 00 00 
    78725cc0612b:	ff d0                	call   rax
    78725cc0612d:	89 c1                	mov    ecx,eax
    78725cc0612f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06136:	00 
    78725cc06137:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    78725cc0613e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc06145:	75 2f                	jne    0x78725cc06176
    78725cc06147:	eb 79                	jmp    0x78725cc061c2
    78725cc06149:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    78725cc06150:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc06157:	00 
    78725cc06158:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    78725cc0615f:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    78725cc06162:	83 c0 04             	add    eax,0x4
    78725cc06165:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    78725cc06169:	83 e0 03             	and    eax,0x3
    78725cc0616c:	83 f8 00             	cmp    eax,0x0
    78725cc0616f:	75 64                	jne    0x78725cc061d5
    78725cc06171:	e9 f3 00 00 00       	jmp    0x78725cc06269
    78725cc06176:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0617d:	00 
    78725cc0617e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc06184:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc0618a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc06190:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc06195:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0619a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc061a1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc061a8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc061af:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc061b6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc061bd:	e9 08 07 00 00       	jmp    0x78725cc068ca
    78725cc061c2:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    78725cc061c9:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    78725cc061d0:	e9 74 ff ff ff       	jmp    0x78725cc06149
    78725cc061d5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc061dc:	00 
    78725cc061dd:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc061e1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc061e8:	00 
    78725cc061e9:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc061f0:	03 01 00 
    78725cc061f3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc061fa:	00 00 00 
    78725cc061fd:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc06204:	00 00 00 
    78725cc06207:	31 c0                	xor    eax,eax
    78725cc06209:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc06210:	60 00 00 
    78725cc06213:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc06218:	45 31 c0             	xor    r8d,r8d
    78725cc0621b:	ff d0                	call   rax
    78725cc0621d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06224:	00 
    78725cc06225:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0622b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc06231:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc06237:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc0623c:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc06241:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc06248:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc0624f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc06256:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0625d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc06264:	e9 61 06 00 00       	jmp    0x78725cc068ca
    78725cc06269:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc06270:	00 
    78725cc06271:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc06275:	c1 e9 0c             	shr    ecx,0xc
    78725cc06278:	89 c9                	mov    ecx,ecx
    78725cc0627a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc0627e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    78725cc06283:	48 83 f8 00          	cmp    rax,0x0
    78725cc06287:	74 1a                	je     0x78725cc062a3
    78725cc06289:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    78725cc0628e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    78725cc06292:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc06298:	89 c9                	mov    ecx,ecx
    78725cc0629a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0629d:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc062a1:	eb 57                	jmp    0x78725cc062fa
    78725cc062a3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc062aa:	00 
    78725cc062ab:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    78725cc062af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc062b6:	00 
    78725cc062b7:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc062be:	03 01 00 
    78725cc062c1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc062c8:	00 00 00 
    78725cc062cb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc062d2:	00 00 00 
    78725cc062d5:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc062dc:	60 00 00 
    78725cc062df:	ff d0                	call   rax
    78725cc062e1:	89 c1                	mov    ecx,eax
    78725cc062e3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc062ea:	00 
    78725cc062eb:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    78725cc062ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc062f6:	75 29                	jne    0x78725cc06321
    78725cc062f8:	eb 73                	jmp    0x78725cc0636d
    78725cc062fa:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    78725cc062fe:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc06305:	00 
    78725cc06306:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    78725cc0630a:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    78725cc0630d:	83 c0 04             	add    eax,0x4
    78725cc06310:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    78725cc06314:	83 e0 03             	and    eax,0x3
    78725cc06317:	83 f8 00             	cmp    eax,0x0
    78725cc0631a:	75 5b                	jne    0x78725cc06377
    78725cc0631c:	e9 ea 00 00 00       	jmp    0x78725cc0640b
    78725cc06321:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06328:	00 
    78725cc06329:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc0632f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc06335:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc0633b:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc06340:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc06345:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0634c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc06353:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc0635a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc06361:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc06368:	e9 5d 05 00 00       	jmp    0x78725cc068ca
    78725cc0636d:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    78725cc06371:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    78725cc06375:	eb 83                	jmp    0x78725cc062fa
    78725cc06377:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc0637e:	00 
    78725cc0637f:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc06383:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    78725cc0638a:	00 
    78725cc0638b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    78725cc06392:	03 01 00 
    78725cc06395:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0639c:	00 00 00 
    78725cc0639f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    78725cc063a6:	00 00 00 
    78725cc063a9:	31 c0                	xor    eax,eax
    78725cc063ab:	48 b8 d0 08 15 8d 97 	movabs rax,0x60978d1508d0
    78725cc063b2:	60 00 00 
    78725cc063b5:	ba 6c 03 01 00       	mov    edx,0x1036c
    78725cc063ba:	45 31 c0             	xor    r8d,r8d
    78725cc063bd:	ff d0                	call   rax
    78725cc063bf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc063c6:	00 
    78725cc063c7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc063cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc063d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc063d9:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc063de:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc063e3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc063ea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc063f1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc063f8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc063ff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc06406:	e9 bf 04 00 00       	jmp    0x78725cc068ca
    78725cc0640b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    78725cc06412:	00 
    78725cc06413:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc06417:	c1 e9 0c             	shr    ecx,0xc
    78725cc0641a:	89 c9                	mov    ecx,ecx
    78725cc0641c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    78725cc06420:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    78725cc06425:	48 83 f8 00          	cmp    rax,0x0
    78725cc06429:	74 1a                	je     0x78725cc06445
    78725cc0642b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    78725cc06430:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc06434:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    78725cc0643a:	89 c9                	mov    ecx,ecx
    78725cc0643c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    78725cc0643f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc06443:	eb 57                	jmp    0x78725cc0649c
    78725cc06445:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0644c:	00 
    78725cc0644d:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    78725cc06451:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    78725cc06458:	00 
    78725cc06459:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    78725cc06460:	03 01 00 
    78725cc06463:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc0646a:	00 00 00 
    78725cc0646d:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    78725cc06474:	00 00 00 
    78725cc06477:	48 b8 f0 a5 03 8d 97 	movabs rax,0x60978d03a5f0
    78725cc0647e:	60 00 00 
    78725cc06481:	ff d0                	call   rax
    78725cc06483:	89 c1                	mov    ecx,eax
    78725cc06485:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc0648c:	00 
    78725cc0648d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    78725cc06491:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    78725cc06498:	75 1d                	jne    0x78725cc064b7
    78725cc0649a:	eb 67                	jmp    0x78725cc06503
    78725cc0649c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc064a3:	00 
    78725cc064a4:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    78725cc064a8:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    78725cc064ac:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    78725cc064af:	83 c1 04             	add    ecx,0x4
    78725cc064b2:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    78725cc064b5:	eb 56                	jmp    0x78725cc0650d
    78725cc064b7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc064be:	00 
    78725cc064bf:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc064c5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc064cb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc064d1:	be 1a 00 00 00       	mov    esi,0x1a
    78725cc064d6:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc064db:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc064e2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc064e9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc064f0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc064f7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc064fe:	e9 c7 03 00 00       	jmp    0x78725cc068ca
    78725cc06503:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    78725cc06507:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    78725cc0650b:	eb 8f                	jmp    0x78725cc0649c
    78725cc0650d:	eb 00                	jmp    0x78725cc0650f
    78725cc0650f:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    78725cc06516:	83 e0 01             	and    eax,0x1
    78725cc06519:	83 f8 00             	cmp    eax,0x0
    78725cc0651c:	75 3d                	jne    0x78725cc0655b
    78725cc0651e:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    78725cc06525:	be 1b 00 00 00       	mov    esi,0x1b
    78725cc0652a:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc0652f:	b0 01                	mov    al,0x1
    78725cc06531:	89 d7                	mov    edi,edx
    78725cc06533:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc0653a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc06541:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc06548:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc0654f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc06556:	e9 6f 03 00 00       	jmp    0x78725cc068ca
    78725cc0655b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    78725cc06562:	00 
    78725cc06563:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    78725cc0656a:	00 
    78725cc0656b:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    78725cc06572:	03 01 00 
    78725cc06575:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    78725cc0657c:	00 00 00 
    78725cc0657f:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    78725cc06586:	00 00 00 
    78725cc06589:	48 b8 d0 fa 14 8d 97 	movabs rax,0x60978d14fad0
    78725cc06590:	60 00 00 
    78725cc06593:	be 2a 00 00 00       	mov    esi,0x2a
    78725cc06598:	ff d0                	call   rax
    78725cc0659a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc065a1:	00 
    78725cc065a2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    78725cc065a8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    78725cc065ae:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    78725cc065b4:	be 1b 00 00 00       	mov    esi,0x1b
    78725cc065b9:	b9 02 00 00 00       	mov    ecx,0x2
    78725cc065be:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    78725cc065c5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    78725cc065cc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    78725cc065d3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    78725cc065da:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    78725cc065e1:	e9 e4 02 00 00       	jmp    0x78725cc068ca
    78725cc065e6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc065ed:	00 
    78725cc065ee:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    78725cc065f5:	e9 c2 03 00 00       	jmp    0x78725cc069bc
    78725cc065fa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc06601:	00 
    78725cc06602:	48 89 c1             	mov    rcx,rax
    78725cc06605:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    78725cc0660c:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    78725cc06611:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    78725cc06618:	03 01 00 
    78725cc0661b:	74 32                	je     0x78725cc0664f
    78725cc0661d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06624:	00 
    78725cc06625:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    78725cc0662c:	03 01 00 
    78725cc0662f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc06636:	00 00 00 
    78725cc06639:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    78725cc06640:	00 00 00 
    78725cc06643:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0664a:	e9 6d 03 00 00       	jmp    0x78725cc069bc
    78725cc0664f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc06656:	00 
    78725cc06657:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc0665e:	00 
    78725cc0665f:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    78725cc06664:	8b 8c 24 4c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x14c]
    78725cc0666b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    78725cc06672:	70 03 01 00 
    78725cc06676:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0667d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc06681:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc06688:	ff e0                	jmp    rax
    78725cc0668a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc06691:	00 
    78725cc06692:	48 89 c1             	mov    rcx,rax
    78725cc06695:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    78725cc0669c:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    78725cc066a1:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    78725cc066a8:	03 01 00 
    78725cc066ab:	74 32                	je     0x78725cc066df
    78725cc066ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc066b4:	00 
    78725cc066b5:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    78725cc066bc:	03 01 00 
    78725cc066bf:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc066c6:	00 00 00 
    78725cc066c9:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    78725cc066d0:	00 00 00 
    78725cc066d3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc066da:	e9 dd 02 00 00       	jmp    0x78725cc069bc
    78725cc066df:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc066e6:	00 
    78725cc066e7:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc066ee:	00 
    78725cc066ef:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    78725cc066f4:	8b 8c 24 40 01 00 00 	mov    ecx,DWORD PTR [rsp+0x140]
    78725cc066fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    78725cc06702:	70 03 01 00 
    78725cc06706:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0670d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc06711:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc06718:	ff e0                	jmp    rax
    78725cc0671a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc06721:	00 
    78725cc06722:	48 89 c1             	mov    rcx,rax
    78725cc06725:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    78725cc0672c:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    78725cc06731:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    78725cc06738:	03 01 00 
    78725cc0673b:	74 32                	je     0x78725cc0676f
    78725cc0673d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06744:	00 
    78725cc06745:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    78725cc0674c:	03 01 00 
    78725cc0674f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc06756:	00 00 00 
    78725cc06759:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    78725cc06760:	00 00 00 
    78725cc06763:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0676a:	e9 4d 02 00 00       	jmp    0x78725cc069bc
    78725cc0676f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc06776:	00 
    78725cc06777:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc0677e:	00 
    78725cc0677f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    78725cc06784:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    78725cc0678b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    78725cc06792:	70 03 01 00 
    78725cc06796:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0679d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc067a1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc067a8:	ff e0                	jmp    rax
    78725cc067aa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc067b1:	00 
    78725cc067b2:	48 89 c1             	mov    rcx,rax
    78725cc067b5:	48 81 c1 d0 1b 08 00 	add    rcx,0x81bd0
    78725cc067bc:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    78725cc067c1:	81 b8 d0 1b 08 00 7a 	cmp    DWORD PTR [rax+0x81bd0],0x1037a
    78725cc067c8:	03 01 00 
    78725cc067cb:	74 32                	je     0x78725cc067ff
    78725cc067cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc067d4:	00 
    78725cc067d5:	c7 80 bc 00 00 00 7a 	mov    DWORD PTR [rax+0xbc],0x1037a
    78725cc067dc:	03 01 00 
    78725cc067df:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc067e6:	00 00 00 
    78725cc067e9:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    78725cc067f0:	00 00 00 
    78725cc067f3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc067fa:	e9 bd 01 00 00       	jmp    0x78725cc069bc
    78725cc067ff:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc06806:	00 
    78725cc06807:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc0680e:	00 
    78725cc0680f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    78725cc06814:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    78725cc0681b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    78725cc06822:	7a 03 01 00 
    78725cc06826:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc0682d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc06831:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc06838:	ff e0                	jmp    rax
    78725cc0683a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc06841:	00 
    78725cc06842:	48 89 c1             	mov    rcx,rax
    78725cc06845:	48 81 c1 20 1d 08 00 	add    rcx,0x81d20
    78725cc0684c:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    78725cc06851:	81 b8 20 1d 08 00 a4 	cmp    DWORD PTR [rax+0x81d20],0x103a4
    78725cc06858:	03 01 00 
    78725cc0685b:	74 32                	je     0x78725cc0688f
    78725cc0685d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06864:	00 
    78725cc06865:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x103a4
    78725cc0686c:	03 01 00 
    78725cc0686f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    78725cc06876:	00 00 00 
    78725cc06879:	c7 80 34 01 00 00 17 	mov    DWORD PTR [rax+0x134],0x17
    78725cc06880:	00 00 00 
    78725cc06883:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    78725cc0688a:	e9 2d 01 00 00       	jmp    0x78725cc069bc
    78725cc0688f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc06896:	00 
    78725cc06897:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc0689e:	00 
    78725cc0689f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    78725cc068a4:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf0]
    78725cc068ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    78725cc068b2:	a4 03 01 00 
    78725cc068b6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc068bd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc068c1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc068c8:	ff e0                	jmp    rax
    78725cc068ca:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    78725cc068d1:	00 
    78725cc068d2:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    78725cc068d9:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    78725cc068e0:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    78725cc068e7:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    78725cc068ee:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    78725cc068f5:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    78725cc068f9:	89 c3                	mov    ebx,eax
    78725cc068fb:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    78725cc068ff:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    78725cc06903:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    78725cc06907:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    78725cc0690b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    78725cc06911:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    78725cc06915:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    78725cc0691b:	73 2d                	jae    0x78725cc0694a
    78725cc0691d:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    78725cc06924:	00 
    78725cc06925:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc06929:	89 d1                	mov    ecx,edx
    78725cc0692b:	c1 e9 01             	shr    ecx,0x1
    78725cc0692e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    78725cc06934:	89 c9                	mov    ecx,ecx
    78725cc06936:	48 c1 e1 04          	shl    rcx,0x4
    78725cc0693a:	48 89 c6             	mov    rsi,rax
    78725cc0693d:	48 01 ce             	add    rsi,rcx
    78725cc06940:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    78725cc06945:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    78725cc06948:	74 32                	je     0x78725cc0697c
    78725cc0694a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    78725cc06951:	00 
    78725cc06952:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    78725cc06956:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    78725cc0695a:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    78725cc0695e:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    78725cc06962:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    78725cc06968:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    78725cc0696e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    78725cc06974:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    78725cc0697a:	eb 40                	jmp    0x78725cc069bc
    78725cc0697c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    78725cc06983:	00 
    78725cc06984:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    78725cc0698b:	00 
    78725cc0698c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    78725cc06991:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    78725cc06995:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    78725cc06999:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    78725cc069a0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    78725cc069a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    78725cc069ae:	00 
    78725cc069af:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    78725cc069b3:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc069ba:	ff e0                	jmp    rax
    78725cc069bc:	48 81 c4 18 02 00 00 	add    rsp,0x218
    78725cc069c3:	c2 08 00             	ret    0x8
