; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010092(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65682
  %6 = icmp ugt i32 %5, 6
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb11 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb11, 66462
  %11 = sub i32 %guard_lb11, 65682
  %12 = icmp ugt i32 %11, 6
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010092_entry, label %lb_guard_miss, !prof !0

insn_0x00010092_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table34 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table34, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 28
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010092_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 7, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010092_entry, %28
  br label %insn_0x00010092

insn_0x00010092:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %30, align 4
  %diff = sub i32 %rx, 0
  %31 = icmp eq i32 %diff, 0
  %az = zext i1 %31 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %32 = xor i32 %flgn, %flgs
  %33 = xor i32 %flgs, 0
  %overflow = and i32 %33, %32
  %an = xor i32 %flgn, %overflow
  %34 = icmp ule i32 0, %rx
  %ac0 = zext i1 %34 to i32
  %35 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %41, align 4
  br label %insn_0x00010094_entry

insn_0x00010094_entry:                            ; preds = %insn_0x00010092
  br label %insn_0x00010094

insn_0x00010094:                                  ; preds = %insn_0x00010094_entry
  %cc_false = icmp eq i32 %az, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010094
  %42 = getelementptr i8, ptr %cpu, i32 188
  store i32 65728, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %43, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %44 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %44 monotonic, align 4, !range !2
  %45 = icmp ult i32 %chain_total, %chain_budget
  br i1 %45, label %chain_go, label %chain_leave12, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010094
  br label %insn_0x00010096_entry

insn_0x00010096_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010096

insn_0x00010096:                                  ; preds = %insn_0x00010096_entry
  %46 = getelementptr i8, ptr %cpu, i32 48
  %ptr = load i32, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 24
  %val = load i32, ptr %47, align 4
  %48 = and i32 %ptr, 3
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010096
  %50 = getelementptr i8, ptr %cpu, i32 188
  store i32 65686, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %52, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65686, i32 %ptr, i32 65536)
  %53 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %53, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010096
  %54 = lshr i32 %ptr, 12
  %page_index = zext i32 %54 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %55 = and i32 %ptr, 4095
  %page_offset = zext i32 %55 to i64
  %56 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %val, ptr %56, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %57 = getelementptr i8, ptr %cpu, i32 188
  store i32 65686, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %59, align 4
  call void @mem_write32(ptr %mem, i32 %ptr, i32 %val)
  %60 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %60, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %61 = icmp ne i8 %cec_pending, 0
  br i1 %61, label %cec_check, label %cec_checked, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %62 = getelementptr i8, ptr %cpu, i64 188
  %next_pc13 = load i32, ptr %62, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

cec_check:                                        ; preds = %page_wr_done
  %63 = getelementptr i8, ptr %cpu, i32 188
  store i32 65688, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %65, align 4
  call void @cec_check_pending(ptr %cpu)
  %66 = getelementptr i8, ptr %cpu, i32 296
  %dj3 = load i8, ptr %66, align 1
  %dj_set4 = icmp ne i8 %dj3, 0
  br i1 %dj_set4, label %did_jump_exit1, label %did_jump_cont2, !prof !1

cec_checked:                                      ; preds = %did_jump_cont2, %page_wr_done
  br label %insn_0x00010098_entry

did_jump_exit1:                                   ; preds = %cec_check
  %67 = getelementptr i8, ptr %cpu, i64 188
  %next_pc14 = load i32, ptr %67, align 4
  br label %chain_exit

did_jump_cont2:                                   ; preds = %cec_check
  br label %cec_checked

insn_0x00010098_entry:                            ; preds = %cec_checked
  br label %insn_0x00010098

insn_0x00010098:                                  ; preds = %insn_0x00010098_entry
  %68 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %69, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65688
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65692
  %70 = getelementptr i8, ptr %cpu, i32 156
  %lc5 = load i32, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 148
  %lt6 = load i32, ptr %71, align 4
  %lc_gt17 = icmp ugt i32 %lc5, 1
  %at_lb8 = icmp eq i32 %lb1, 65688
  %hwloop_cond9 = and i1 %lc_gt17, %at_lb8
  %hwloop_rets10 = select i1 %hwloop_cond9, i32 %lt6, i32 %hwloop_rets
  %72 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets10, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 188
  store i32 66600, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets17 = load i32, ptr %74, align 4
  %chain_total18 = add nuw i32 %chain_packets17, 4
  %75 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget19 = load atomic i32, ptr %75 monotonic, align 4, !range !2
  %76 = icmp ult i32 %chain_total18, %chain_budget19
  br i1 %76, label %chain_go15, label %chain_leave16, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %77 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %77, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525824
  %78 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %78, align 4
  %79 = icmp eq i32 %slot_pc, 65728
  br i1 %79, label %chain_hit, label %chain_leave12, !prof !0

chain_leave12:                                    ; preds = %chain_go, %brcc_taken
  %80 = getelementptr i8, ptr %cpu, i64 188
  store i32 65728, ptr %80, align 4
  %81 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %82, align 4
  %83 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %83, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %84 = getelementptr i8, ptr %cpu, i64 188
  store i32 65728, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %85, align 4
  %86 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %86, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go15:                                       ; preds = %insn_0x00010098
  %chain_slot20 = getelementptr i8, ptr %chain_table, i64 532800
  %87 = getelementptr i8, ptr %chain_slot20, i64 0
  %slot_pc21 = load i32, ptr %87, align 4
  %88 = icmp eq i32 %slot_pc21, 66600
  br i1 %88, label %chain_hit22, label %chain_leave16, !prof !0

chain_leave16:                                    ; preds = %chain_go15, %insn_0x00010098
  %89 = getelementptr i8, ptr %cpu, i64 188
  store i32 66600, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %92, align 1
  br label %return

chain_hit22:                                      ; preds = %chain_go15
  %93 = getelementptr i8, ptr %cpu, i64 188
  store i32 66600, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total18, ptr %94, align 4
  %95 = getelementptr i8, ptr %chain_slot20, i64 8
  %chain_fn23 = load ptr, ptr %95, align 8
  musttail call swifttailcc void %chain_fn23(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit1, %did_jump_exit, %data_misaligned
  %next_pc24 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc13, %did_jump_exit ], [ %next_pc14, %did_jump_exit1 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %did_jump_exit1 ]
  %tail25 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 3, %did_jump_exit1 ]
  %96 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %96, align 4
  %chain_total28 = add nuw i32 %chain_packets27, %packets
  %97 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %97 monotonic, align 4, !range !2
  %98 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %98, label %chain_lookup, label %chain_leave26, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %99 = lshr i32 %next_pc24, 1
  %100 = and i32 %99, 65535
  %101 = zext i32 %100 to i64
  %102 = mul i64 %101, 16
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 %102
  %103 = getelementptr i8, ptr %chain_slot30, i64 0
  %slot_pc31 = load i32, ptr %103, align 4
  %104 = icmp eq i32 %slot_pc31, %next_pc24
  br i1 %104, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_lookup, %chain_exit
  %105 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail25, ptr %106, align 4
  br label %return

chain_hit32:                                      ; preds = %chain_lookup
  %107 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %108, align 1
  %109 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %109, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave26, %chain_leave16, %chain_leave12, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
