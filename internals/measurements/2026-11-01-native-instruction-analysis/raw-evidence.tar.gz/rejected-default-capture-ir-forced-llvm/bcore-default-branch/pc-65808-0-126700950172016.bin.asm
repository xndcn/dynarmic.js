
build-native-instruction-analysis/capture/bcore-default-branch/pc-65808-0-126700950172016.bin:     file format binary


Disassembly of section .data:

0000733bdd20b170 <.data>:
    733bdd20b170:	48 81 ec d8 00 00 00 	sub    rsp,0xd8
    733bdd20b177:	4c 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r14
    733bdd20b17e:	00 
    733bdd20b17f:	4c 89 ac 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r13
    733bdd20b186:	00 
    733bdd20b187:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20b18e:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    733bdd20b195:	00 
    733bdd20b196:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd20b19d:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    733bdd20b1a4:	00 
    733bdd20b1a5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20b1ac:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    733bdd20b1b3:	00 
    733bdd20b1b4:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20b1bb:	00 
    733bdd20b1bc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20b1c2:	83 fa 00             	cmp    edx,0x0
    733bdd20b1c5:	0f 94 c0             	sete   al
    733bdd20b1c8:	81 ea 10 01 01 00    	sub    edx,0x10110
    733bdd20b1ce:	83 fa 1e             	cmp    edx,0x1e
    733bdd20b1d1:	0f 97 c2             	seta   dl
    733bdd20b1d4:	08 d0                	or     al,dl
    733bdd20b1d6:	24 01                	and    al,0x1
    733bdd20b1d8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20b1de:	83 fa 00             	cmp    edx,0x0
    733bdd20b1e1:	0f 94 c1             	sete   cl
    733bdd20b1e4:	81 ea 10 01 01 00    	sub    edx,0x10110
    733bdd20b1ea:	83 fa 1e             	cmp    edx,0x1e
    733bdd20b1ed:	0f 97 c2             	seta   dl
    733bdd20b1f0:	08 d1                	or     cl,dl
    733bdd20b1f2:	20 c8                	and    al,cl
    733bdd20b1f4:	a8 01                	test   al,0x1
    733bdd20b1f6:	75 05                	jne    0x733bdd20b1fd
    733bdd20b1f8:	e9 8d 09 00 00       	jmp    0x733bdd20bb8a
    733bdd20b1fd:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b204:	00 
    733bdd20b205:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20b20c:	48 89 c8             	mov    rax,rcx
    733bdd20b20f:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20b215:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    733bdd20b21c:	00 
    733bdd20b21d:	8b 81 34 00 10 00    	mov    eax,DWORD PTR [rcx+0x100034]
    733bdd20b223:	83 c0 01             	add    eax,0x1
    733bdd20b226:	89 81 34 00 10 00    	mov    DWORD PTR [rcx+0x100034],eax
    733bdd20b22c:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20b231:	75 4c                	jne    0x733bdd20b27f
    733bdd20b233:	48 8b 8c 24 a8 00 00 	mov    rcx,QWORD PTR [rsp+0xa8]
    733bdd20b23a:	00 
    733bdd20b23b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20b241:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd20b248:	89 c2                	mov    edx,eax
    733bdd20b24a:	83 c2 01             	add    edx,0x1
    733bdd20b24d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20b253:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20b258:	73 23                	jae    0x733bdd20b27d
    733bdd20b25a:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    733bdd20b261:	00 
    733bdd20b262:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20b269:	89 c9                	mov    ecx,ecx
    733bdd20b26b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20b26f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20b276:	c7 04 08 0d 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xd
    733bdd20b27d:	eb 00                	jmp    0x733bdd20b27f
    733bdd20b27f:	eb 00                	jmp    0x733bdd20b281
    733bdd20b281:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b288:	00 
    733bdd20b289:	8b 08                	mov    ecx,DWORD PTR [rax]
    733bdd20b28b:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    733bdd20b292:	c1 e9 07             	shr    ecx,0x7
    733bdd20b295:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    733bdd20b29c:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20b29f:	83 f9 00             	cmp    ecx,0x0
    733bdd20b2a2:	0f 94 c2             	sete   dl
    733bdd20b2a5:	80 e2 01             	and    dl,0x1
    733bdd20b2a8:	0f b6 d2             	movzx  edx,dl
    733bdd20b2ab:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20b2ae:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20b2b4:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20b2ba:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20b2c1:	00 00 00 
    733bdd20b2c4:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20b2cb:	00 00 00 
    733bdd20b2ce:	eb 00                	jmp    0x733bdd20b2d0
    733bdd20b2d0:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b2d7:	00 
    733bdd20b2d8:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    733bdd20b2df:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20b2e6:	31 d1                	xor    ecx,edx
    733bdd20b2e8:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    733bdd20b2ef:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20b2f2:	83 f9 00             	cmp    ecx,0x0
    733bdd20b2f5:	0f 94 c2             	sete   dl
    733bdd20b2f8:	80 e2 01             	and    dl,0x1
    733bdd20b2fb:	0f b6 d2             	movzx  edx,dl
    733bdd20b2fe:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20b301:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20b307:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20b30d:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    733bdd20b314:	00 00 00 
    733bdd20b317:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    733bdd20b31e:	00 00 00 
    733bdd20b321:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20b328:	00 00 00 
    733bdd20b32b:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20b332:	00 00 00 
    733bdd20b335:	eb 00                	jmp    0x733bdd20b337
    733bdd20b337:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b33e:	00 
    733bdd20b33f:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    733bdd20b346:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20b349:	eb 00                	jmp    0x733bdd20b34b
    733bdd20b34b:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b352:	00 
    733bdd20b353:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    733bdd20b356:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20b35c:	81 c9 00 00 37 9e    	or     ecx,0x9e370000
    733bdd20b362:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    733bdd20b369:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    733bdd20b36c:	eb 00                	jmp    0x733bdd20b36e
    733bdd20b36e:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b375:	00 
    733bdd20b376:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20b37d:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20b383:	81 c9 b9 79 00 00    	or     ecx,0x79b9
    733bdd20b389:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    733bdd20b390:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    733bdd20b393:	eb 00                	jmp    0x733bdd20b395
    733bdd20b395:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20b39c:	00 
    733bdd20b39d:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd20b3a0:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd20b3a6:	89 94 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],edx
    733bdd20b3ad:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd20b3b0:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    733bdd20b3b7:	83 e8 04             	sub    eax,0x4
    733bdd20b3ba:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd20b3c1:	83 e0 03             	and    eax,0x3
    733bdd20b3c4:	83 f8 00             	cmp    eax,0x0
    733bdd20b3c7:	0f 84 8c 00 00 00    	je     0x733bdd20b459
    733bdd20b3cd:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20b3d4:	00 
    733bdd20b3d5:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20b3dc:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20b3e3:	00 
    733bdd20b3e4:	c7 87 bc 00 00 00 20 	mov    DWORD PTR [rdi+0xbc],0x10120
    733bdd20b3eb:	01 01 00 
    733bdd20b3ee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20b3f5:	00 00 00 
    733bdd20b3f8:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20b3ff:	00 00 00 
    733bdd20b402:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20b409:	59 00 00 
    733bdd20b40c:	ba 20 01 01 00       	mov    edx,0x10120
    733bdd20b411:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20b417:	ff d0                	call   rax
    733bdd20b419:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b420:	00 
    733bdd20b421:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b427:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b42d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b433:	be 06 00 00 00       	mov    esi,0x6
    733bdd20b438:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b43d:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b441:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b445:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b449:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b44d:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b454:	e9 45 07 00 00       	jmp    0x733bdd20bb9e
    733bdd20b459:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20b460:	00 
    733bdd20b461:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20b468:	c1 e9 0c             	shr    ecx,0xc
    733bdd20b46b:	89 c9                	mov    ecx,ecx
    733bdd20b46d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20b471:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd20b476:	48 83 f8 00          	cmp    rax,0x0
    733bdd20b47a:	74 20                	je     0x733bdd20b49c
    733bdd20b47c:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd20b481:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd20b488:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20b48f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20b495:	89 c9                	mov    ecx,ecx
    733bdd20b497:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20b49a:	eb 5b                	jmp    0x733bdd20b4f7
    733bdd20b49c:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b4a3:	00 
    733bdd20b4a4:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd20b4ab:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    733bdd20b4b2:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20b4b9:	00 
    733bdd20b4ba:	c7 80 bc 00 00 00 20 	mov    DWORD PTR [rax+0xbc],0x10120
    733bdd20b4c1:	01 01 00 
    733bdd20b4c4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20b4cb:	00 00 00 
    733bdd20b4ce:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20b4d5:	00 00 00 
    733bdd20b4d8:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20b4df:	59 00 00 
    733bdd20b4e2:	ff d0                	call   rax
    733bdd20b4e4:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b4eb:	00 
    733bdd20b4ec:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20b4f3:	75 1d                	jne    0x733bdd20b512
    733bdd20b4f5:	eb 5b                	jmp    0x733bdd20b552
    733bdd20b4f7:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    733bdd20b4fe:	83 e8 04             	sub    eax,0x4
    733bdd20b501:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd20b505:	83 e0 03             	and    eax,0x3
    733bdd20b508:	83 f8 00             	cmp    eax,0x0
    733bdd20b50b:	75 47                	jne    0x733bdd20b554
    733bdd20b50d:	e9 cb 00 00 00       	jmp    0x733bdd20b5dd
    733bdd20b512:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b519:	00 
    733bdd20b51a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b520:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b526:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b52c:	be 06 00 00 00       	mov    esi,0x6
    733bdd20b531:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b536:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b53a:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b53e:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b542:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b546:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b54d:	e9 4c 06 00 00       	jmp    0x733bdd20bb9e
    733bdd20b552:	eb a3                	jmp    0x733bdd20b4f7
    733bdd20b554:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20b55b:	00 
    733bdd20b55c:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b560:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20b567:	00 
    733bdd20b568:	c7 87 bc 00 00 00 20 	mov    DWORD PTR [rdi+0xbc],0x10120
    733bdd20b56f:	01 01 00 
    733bdd20b572:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20b579:	00 00 00 
    733bdd20b57c:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20b583:	00 00 00 
    733bdd20b586:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20b58d:	59 00 00 
    733bdd20b590:	ba 20 01 01 00       	mov    edx,0x10120
    733bdd20b595:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20b59b:	ff d0                	call   rax
    733bdd20b59d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b5a4:	00 
    733bdd20b5a5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b5ab:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b5b1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b5b7:	be 06 00 00 00       	mov    esi,0x6
    733bdd20b5bc:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b5c1:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b5c5:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b5c9:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b5cd:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b5d1:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b5d8:	e9 c1 05 00 00       	jmp    0x733bdd20bb9e
    733bdd20b5dd:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20b5e4:	00 
    733bdd20b5e5:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b5e9:	c1 e9 0c             	shr    ecx,0xc
    733bdd20b5ec:	89 c9                	mov    ecx,ecx
    733bdd20b5ee:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20b5f2:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd20b5f7:	48 83 f8 00          	cmp    rax,0x0
    733bdd20b5fb:	74 1d                	je     0x733bdd20b61a
    733bdd20b5fd:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd20b602:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    733bdd20b609:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b60d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20b613:	89 c9                	mov    ecx,ecx
    733bdd20b615:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20b618:	eb 58                	jmp    0x733bdd20b672
    733bdd20b61a:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b621:	00 
    733bdd20b622:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    733bdd20b629:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    733bdd20b62d:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20b634:	00 
    733bdd20b635:	c7 80 bc 00 00 00 20 	mov    DWORD PTR [rax+0xbc],0x10120
    733bdd20b63c:	01 01 00 
    733bdd20b63f:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20b646:	00 00 00 
    733bdd20b649:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20b650:	00 00 00 
    733bdd20b653:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20b65a:	59 00 00 
    733bdd20b65d:	ff d0                	call   rax
    733bdd20b65f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b666:	00 
    733bdd20b667:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20b66e:	75 29                	jne    0x733bdd20b699
    733bdd20b670:	eb 67                	jmp    0x733bdd20b6d9
    733bdd20b672:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    733bdd20b679:	00 
    733bdd20b67a:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20b681:	00 
    733bdd20b682:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    733bdd20b686:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd20b689:	83 ea 00             	sub    edx,0x0
    733bdd20b68c:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd20b68f:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20b692:	75 47                	jne    0x733bdd20b6db
    733bdd20b694:	e9 87 00 00 00       	jmp    0x733bdd20b720
    733bdd20b699:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b6a0:	00 
    733bdd20b6a1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b6a7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b6ad:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b6b3:	be 06 00 00 00       	mov    esi,0x6
    733bdd20b6b8:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b6bd:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b6c1:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b6c5:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b6c9:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b6cd:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b6d4:	e9 c5 04 00 00       	jmp    0x733bdd20bb9e
    733bdd20b6d9:	eb 97                	jmp    0x733bdd20b672
    733bdd20b6db:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20b6e2:	00 
    733bdd20b6e3:	c7 87 bc 00 00 00 24 	mov    DWORD PTR [rdi+0xbc],0x10124
    733bdd20b6ea:	01 01 00 
    733bdd20b6ed:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20b6f4:	00 00 00 
    733bdd20b6f7:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20b6fe:	00 00 00 
    733bdd20b701:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20b708:	59 00 00 
    733bdd20b70b:	ff d0                	call   rax
    733bdd20b70d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b714:	00 
    733bdd20b715:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20b71c:	75 04                	jne    0x733bdd20b722
    733bdd20b71e:	eb 42                	jmp    0x733bdd20b762
    733bdd20b720:	eb 42                	jmp    0x733bdd20b764
    733bdd20b722:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b729:	00 
    733bdd20b72a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b730:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b736:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b73c:	be 06 00 00 00       	mov    esi,0x6
    733bdd20b741:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b746:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b74a:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b74e:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b752:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b756:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b75d:	e9 3c 04 00 00       	jmp    0x733bdd20bb9e
    733bdd20b762:	eb bc                	jmp    0x733bdd20b720
    733bdd20b764:	eb 00                	jmp    0x733bdd20b766
    733bdd20b766:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    733bdd20b76a:	83 e0 03             	and    eax,0x3
    733bdd20b76d:	83 f8 00             	cmp    eax,0x0
    733bdd20b770:	0f 84 88 00 00 00    	je     0x733bdd20b7fe
    733bdd20b776:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20b77d:	00 
    733bdd20b77e:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b782:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20b789:	00 
    733bdd20b78a:	c7 87 bc 00 00 00 24 	mov    DWORD PTR [rdi+0xbc],0x10124
    733bdd20b791:	01 01 00 
    733bdd20b794:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20b79b:	00 00 00 
    733bdd20b79e:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    733bdd20b7a5:	00 00 00 
    733bdd20b7a8:	31 c0                	xor    eax,eax
    733bdd20b7aa:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20b7b1:	59 00 00 
    733bdd20b7b4:	ba 24 01 01 00       	mov    edx,0x10124
    733bdd20b7b9:	45 31 c0             	xor    r8d,r8d
    733bdd20b7bc:	ff d0                	call   rax
    733bdd20b7be:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b7c5:	00 
    733bdd20b7c6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b7cc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b7d2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b7d8:	be 07 00 00 00       	mov    esi,0x7
    733bdd20b7dd:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b7e2:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b7e6:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b7ea:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b7ee:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b7f2:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b7f9:	e9 a0 03 00 00       	jmp    0x733bdd20bb9e
    733bdd20b7fe:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20b805:	00 
    733bdd20b806:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b80a:	c1 e9 0c             	shr    ecx,0xc
    733bdd20b80d:	89 c9                	mov    ecx,ecx
    733bdd20b80f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20b813:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd20b818:	48 83 f8 00          	cmp    rax,0x0
    733bdd20b81c:	74 1a                	je     0x733bdd20b838
    733bdd20b81e:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd20b823:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20b827:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20b82d:	89 c9                	mov    ecx,ecx
    733bdd20b82f:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20b832:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20b836:	eb 57                	jmp    0x733bdd20b88f
    733bdd20b838:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b83f:	00 
    733bdd20b840:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    733bdd20b844:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20b84b:	00 
    733bdd20b84c:	c7 80 bc 00 00 00 24 	mov    DWORD PTR [rax+0xbc],0x10124
    733bdd20b853:	01 01 00 
    733bdd20b856:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20b85d:	00 00 00 
    733bdd20b860:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd20b867:	00 00 00 
    733bdd20b86a:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20b871:	59 00 00 
    733bdd20b874:	ff d0                	call   rax
    733bdd20b876:	89 c1                	mov    ecx,eax
    733bdd20b878:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b87f:	00 
    733bdd20b880:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd20b884:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20b88b:	75 22                	jne    0x733bdd20b8af
    733bdd20b88d:	eb 60                	jmp    0x733bdd20b8ef
    733bdd20b88f:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    733bdd20b893:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd20b897:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd20b89b:	83 c0 04             	add    eax,0x4
    733bdd20b89e:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20b8a2:	83 e0 03             	and    eax,0x3
    733bdd20b8a5:	83 f8 00             	cmp    eax,0x0
    733bdd20b8a8:	75 4f                	jne    0x733bdd20b8f9
    733bdd20b8aa:	e9 d2 00 00 00       	jmp    0x733bdd20b981
    733bdd20b8af:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b8b6:	00 
    733bdd20b8b7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b8bd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b8c3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b8c9:	be 07 00 00 00       	mov    esi,0x7
    733bdd20b8ce:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b8d3:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b8d7:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b8db:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b8df:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b8e3:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b8ea:	e9 af 02 00 00       	jmp    0x733bdd20bb9e
    733bdd20b8ef:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd20b8f3:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20b8f7:	eb 96                	jmp    0x733bdd20b88f
    733bdd20b8f9:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20b900:	00 
    733bdd20b901:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20b905:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20b90c:	00 
    733bdd20b90d:	c7 87 bc 00 00 00 24 	mov    DWORD PTR [rdi+0xbc],0x10124
    733bdd20b914:	01 01 00 
    733bdd20b917:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20b91e:	00 00 00 
    733bdd20b921:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    733bdd20b928:	00 00 00 
    733bdd20b92b:	31 c0                	xor    eax,eax
    733bdd20b92d:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20b934:	59 00 00 
    733bdd20b937:	ba 24 01 01 00       	mov    edx,0x10124
    733bdd20b93c:	45 31 c0             	xor    r8d,r8d
    733bdd20b93f:	ff d0                	call   rax
    733bdd20b941:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b948:	00 
    733bdd20b949:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20b94f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20b955:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20b95b:	be 07 00 00 00       	mov    esi,0x7
    733bdd20b960:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20b965:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20b969:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20b96d:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20b971:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20b975:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20b97c:	e9 1d 02 00 00       	jmp    0x733bdd20bb9e
    733bdd20b981:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20b988:	00 
    733bdd20b989:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20b98d:	c1 e9 0c             	shr    ecx,0xc
    733bdd20b990:	89 c9                	mov    ecx,ecx
    733bdd20b992:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20b996:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd20b99b:	48 83 f8 00          	cmp    rax,0x0
    733bdd20b99f:	74 1a                	je     0x733bdd20b9bb
    733bdd20b9a1:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd20b9a6:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20b9aa:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20b9b0:	89 c9                	mov    ecx,ecx
    733bdd20b9b2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20b9b5:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20b9b9:	eb 57                	jmp    0x733bdd20ba12
    733bdd20b9bb:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20b9c2:	00 
    733bdd20b9c3:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd20b9c7:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20b9ce:	00 
    733bdd20b9cf:	c7 80 bc 00 00 00 24 	mov    DWORD PTR [rax+0xbc],0x10124
    733bdd20b9d6:	01 01 00 
    733bdd20b9d9:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20b9e0:	00 00 00 
    733bdd20b9e3:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd20b9ea:	00 00 00 
    733bdd20b9ed:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20b9f4:	59 00 00 
    733bdd20b9f7:	ff d0                	call   rax
    733bdd20b9f9:	89 c1                	mov    ecx,eax
    733bdd20b9fb:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20ba02:	00 
    733bdd20ba03:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd20ba07:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20ba0e:	75 2b                	jne    0x733bdd20ba3b
    733bdd20ba10:	eb 69                	jmp    0x733bdd20ba7b
    733bdd20ba12:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20ba19:	00 
    733bdd20ba1a:	8b 74 24 40          	mov    esi,DWORD PTR [rsp+0x40]
    733bdd20ba1e:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20ba22:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    733bdd20ba26:	89 54 24 2c          	mov    DWORD PTR [rsp+0x2c],edx
    733bdd20ba2a:	83 c1 04             	add    ecx,0x4
    733bdd20ba2d:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd20ba30:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd20ba36:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20ba39:	eb 4a                	jmp    0x733bdd20ba85
    733bdd20ba3b:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20ba42:	00 
    733bdd20ba43:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ba49:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ba4f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20ba55:	be 07 00 00 00       	mov    esi,0x7
    733bdd20ba5a:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20ba5f:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20ba63:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20ba67:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20ba6b:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20ba6f:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20ba76:	e9 23 01 00 00       	jmp    0x733bdd20bb9e
    733bdd20ba7b:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd20ba7f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20ba83:	eb 8d                	jmp    0x733bdd20ba12
    733bdd20ba85:	eb 00                	jmp    0x733bdd20ba87
    733bdd20ba87:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20ba8e:	00 
    733bdd20ba8f:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    733bdd20ba96:	89 ca                	mov    edx,ecx
    733bdd20ba98:	c1 e2 01             	shl    edx,0x1
    733bdd20ba9b:	01 d1                	add    ecx,edx
    733bdd20ba9d:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    733bdd20baa1:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20baa4:	eb 00                	jmp    0x733bdd20baa6
    733bdd20baa6:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20baad:	00 
    733bdd20baae:	8b 94 24 90 00 00 00 	mov    edx,DWORD PTR [rsp+0x90]
    733bdd20bab5:	8b 4c 24 28          	mov    ecx,DWORD PTR [rsp+0x28]
    733bdd20bab9:	01 d1                	add    ecx,edx
    733bdd20babb:	89 4c 24 24          	mov    DWORD PTR [rsp+0x24],ecx
    733bdd20babf:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    733bdd20bac2:	eb 00                	jmp    0x733bdd20bac4
    733bdd20bac4:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20bacb:	00 
    733bdd20bacc:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    733bdd20bad0:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd20bad2:	eb 00                	jmp    0x733bdd20bad4
    733bdd20bad4:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    733bdd20bad8:	83 e0 01             	and    eax,0x1
    733bdd20badb:	83 f8 00             	cmp    eax,0x0
    733bdd20bade:	75 2e                	jne    0x733bdd20bb0e
    733bdd20bae0:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    733bdd20bae4:	be 0b 00 00 00       	mov    esi,0xb
    733bdd20bae9:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20baee:	b0 01                	mov    al,0x1
    733bdd20baf0:	89 d7                	mov    edi,edx
    733bdd20baf2:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20baf6:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20bafa:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20bafe:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20bb02:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20bb09:	e9 90 00 00 00       	jmp    0x733bdd20bb9e
    733bdd20bb0e:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20bb15:	00 
    733bdd20bb16:	48 8b 94 24 b0 00 00 	mov    rdx,QWORD PTR [rsp+0xb0]
    733bdd20bb1d:	00 
    733bdd20bb1e:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1012e
    733bdd20bb25:	01 01 00 
    733bdd20bb28:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20bb2f:	00 00 00 
    733bdd20bb32:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    733bdd20bb39:	00 00 00 
    733bdd20bb3c:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd20bb43:	59 00 00 
    733bdd20bb46:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd20bb4b:	ff d0                	call   rax
    733bdd20bb4d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20bb54:	00 
    733bdd20bb55:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20bb5b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20bb61:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20bb67:	be 0b 00 00 00       	mov    esi,0xb
    733bdd20bb6c:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20bb71:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20bb75:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20bb79:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20bb7d:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20bb81:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20bb88:	eb 14                	jmp    0x733bdd20bb9e
    733bdd20bb8a:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20bb91:	00 
    733bdd20bb92:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20bb99:	e9 e4 00 00 00       	jmp    0x733bdd20bc82
    733bdd20bb9e:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20bba5:	00 
    733bdd20bba6:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    733bdd20bbaa:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd20bbae:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    733bdd20bbb2:	8b 7c 24 7c          	mov    edi,DWORD PTR [rsp+0x7c]
    733bdd20bbb6:	8a 9c 24 83 00 00 00 	mov    bl,BYTE PTR [rsp+0x83]
    733bdd20bbbd:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    733bdd20bbc1:	89 c3                	mov    ebx,eax
    733bdd20bbc3:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    733bdd20bbc7:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    733bdd20bbcb:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    733bdd20bbcf:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    733bdd20bbd3:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20bbd9:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    733bdd20bbdd:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20bbe3:	73 2c                	jae    0x733bdd20bc11
    733bdd20bbe5:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd20bbec:	00 
    733bdd20bbed:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd20bbf1:	89 d1                	mov    ecx,edx
    733bdd20bbf3:	c1 e9 01             	shr    ecx,0x1
    733bdd20bbf6:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20bbfc:	89 c9                	mov    ecx,ecx
    733bdd20bbfe:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20bc02:	48 89 c6             	mov    rsi,rax
    733bdd20bc05:	48 01 ce             	add    rsi,rcx
    733bdd20bc08:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    733bdd20bc0c:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20bc0f:	74 32                	je     0x733bdd20bc43
    733bdd20bc11:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20bc18:	00 
    733bdd20bc19:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    733bdd20bc1d:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    733bdd20bc21:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    733bdd20bc25:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    733bdd20bc29:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd20bc2f:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd20bc35:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd20bc3b:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd20bc41:	eb 3f                	jmp    0x733bdd20bc82
    733bdd20bc43:	4c 8b b4 24 b0 00 00 	mov    r14,QWORD PTR [rsp+0xb0]
    733bdd20bc4a:	00 
    733bdd20bc4b:	4c 8b ac 24 b8 00 00 	mov    r13,QWORD PTR [rsp+0xb8]
    733bdd20bc52:	00 
    733bdd20bc53:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    733bdd20bc57:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    733bdd20bc5b:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd20bc5f:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd20bc66:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20bc6d:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20bc74:	00 
    733bdd20bc75:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20bc79:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    733bdd20bc80:	ff e0                	jmp    rax
    733bdd20bc82:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    733bdd20bc89:	c2 08 00             	ret    0x8
