
build-native-instruction-analysis/capture/bcore-default-branch/pc-65840-0-126700950167632.bin:     file format binary


Disassembly of section .data:

0000733bdd20a050 <.data>:
    733bdd20a050:	48 81 ec d8 00 00 00 	sub    rsp,0xd8
    733bdd20a057:	4c 89 b4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r14
    733bdd20a05e:	00 
    733bdd20a05f:	4c 89 ac 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r13
    733bdd20a066:	00 
    733bdd20a067:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20a06e:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    733bdd20a075:	00 
    733bdd20a076:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd20a07d:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    733bdd20a084:	00 
    733bdd20a085:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20a08c:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    733bdd20a093:	00 
    733bdd20a094:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20a09b:	00 
    733bdd20a09c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20a0a2:	83 fa 00             	cmp    edx,0x0
    733bdd20a0a5:	0f 94 c0             	sete   al
    733bdd20a0a8:	81 ea 30 01 01 00    	sub    edx,0x10130
    733bdd20a0ae:	83 fa 1a             	cmp    edx,0x1a
    733bdd20a0b1:	0f 97 c2             	seta   dl
    733bdd20a0b4:	08 d0                	or     al,dl
    733bdd20a0b6:	24 01                	and    al,0x1
    733bdd20a0b8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20a0be:	83 fa 00             	cmp    edx,0x0
    733bdd20a0c1:	0f 94 c1             	sete   cl
    733bdd20a0c4:	81 ea 30 01 01 00    	sub    edx,0x10130
    733bdd20a0ca:	83 fa 1a             	cmp    edx,0x1a
    733bdd20a0cd:	0f 97 c2             	seta   dl
    733bdd20a0d0:	08 d1                	or     cl,dl
    733bdd20a0d2:	20 c8                	and    al,cl
    733bdd20a0d4:	a8 01                	test   al,0x1
    733bdd20a0d6:	75 05                	jne    0x733bdd20a0dd
    733bdd20a0d8:	e9 f7 09 00 00       	jmp    0x733bdd20aad4
    733bdd20a0dd:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a0e4:	00 
    733bdd20a0e5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20a0ec:	48 89 c8             	mov    rax,rcx
    733bdd20a0ef:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20a0f5:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    733bdd20a0fc:	00 
    733bdd20a0fd:	8b 81 2c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10002c]
    733bdd20a103:	83 c0 01             	add    eax,0x1
    733bdd20a106:	89 81 2c 00 10 00    	mov    DWORD PTR [rcx+0x10002c],eax
    733bdd20a10c:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20a111:	75 4c                	jne    0x733bdd20a15f
    733bdd20a113:	48 8b 8c 24 a8 00 00 	mov    rcx,QWORD PTR [rsp+0xa8]
    733bdd20a11a:	00 
    733bdd20a11b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20a121:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd20a128:	89 c2                	mov    edx,eax
    733bdd20a12a:	83 c2 01             	add    edx,0x1
    733bdd20a12d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20a133:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20a138:	73 23                	jae    0x733bdd20a15d
    733bdd20a13a:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    733bdd20a141:	00 
    733bdd20a142:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20a149:	89 c9                	mov    ecx,ecx
    733bdd20a14b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20a14f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20a156:	c7 04 08 0b 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xb
    733bdd20a15d:	eb 00                	jmp    0x733bdd20a15f
    733bdd20a15f:	eb 00                	jmp    0x733bdd20a161
    733bdd20a161:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a168:	00 
    733bdd20a169:	8b 08                	mov    ecx,DWORD PTR [rax]
    733bdd20a16b:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    733bdd20a172:	c1 e1 05             	shl    ecx,0x5
    733bdd20a175:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    733bdd20a17c:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20a17f:	83 f9 00             	cmp    ecx,0x0
    733bdd20a182:	0f 94 c2             	sete   dl
    733bdd20a185:	80 e2 01             	and    dl,0x1
    733bdd20a188:	0f b6 d2             	movzx  edx,dl
    733bdd20a18b:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20a18e:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20a194:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20a19a:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20a1a1:	00 00 00 
    733bdd20a1a4:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20a1ab:	00 00 00 
    733bdd20a1ae:	eb 00                	jmp    0x733bdd20a1b0
    733bdd20a1b0:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a1b7:	00 
    733bdd20a1b8:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20a1bf:	c1 e9 1b             	shr    ecx,0x1b
    733bdd20a1c2:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    733bdd20a1c9:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd20a1cb:	83 f9 00             	cmp    ecx,0x0
    733bdd20a1ce:	0f 94 c2             	sete   dl
    733bdd20a1d1:	80 e2 01             	and    dl,0x1
    733bdd20a1d4:	0f b6 d2             	movzx  edx,dl
    733bdd20a1d7:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20a1da:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20a1e0:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20a1e6:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20a1ed:	00 00 00 
    733bdd20a1f0:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20a1f7:	00 00 00 
    733bdd20a1fa:	eb 00                	jmp    0x733bdd20a1fc
    733bdd20a1fc:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a203:	00 
    733bdd20a204:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    733bdd20a20b:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    733bdd20a212:	09 d1                	or     ecx,edx
    733bdd20a214:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    733bdd20a21b:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd20a21d:	83 f9 00             	cmp    ecx,0x0
    733bdd20a220:	0f 94 c2             	sete   dl
    733bdd20a223:	80 e2 01             	and    dl,0x1
    733bdd20a226:	0f b6 d2             	movzx  edx,dl
    733bdd20a229:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20a22c:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20a232:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20a238:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    733bdd20a23f:	00 00 00 
    733bdd20a242:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    733bdd20a249:	00 00 00 
    733bdd20a24c:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20a253:	00 00 00 
    733bdd20a256:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20a25d:	00 00 00 
    733bdd20a260:	eb 00                	jmp    0x733bdd20a262
    733bdd20a262:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a269:	00 
    733bdd20a26a:	8b 8c 24 a0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa0]
    733bdd20a271:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20a277:	81 c9 00 00 4a 7f    	or     ecx,0x7f4a0000
    733bdd20a27d:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    733bdd20a284:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20a287:	eb 00                	jmp    0x733bdd20a289
    733bdd20a289:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20a290:	00 
    733bdd20a291:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd20a294:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd20a29a:	89 94 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],edx
    733bdd20a2a1:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd20a2a4:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    733bdd20a2ab:	83 e8 04             	sub    eax,0x4
    733bdd20a2ae:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd20a2b5:	83 e0 03             	and    eax,0x3
    733bdd20a2b8:	83 f8 00             	cmp    eax,0x0
    733bdd20a2bb:	0f 84 8c 00 00 00    	je     0x733bdd20a34d
    733bdd20a2c1:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20a2c8:	00 
    733bdd20a2c9:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20a2d0:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20a2d7:	00 
    733bdd20a2d8:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1013c
    733bdd20a2df:	01 01 00 
    733bdd20a2e2:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20a2e9:	00 00 00 
    733bdd20a2ec:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20a2f3:	00 00 00 
    733bdd20a2f6:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20a2fd:	59 00 00 
    733bdd20a300:	ba 3c 01 01 00       	mov    edx,0x1013c
    733bdd20a305:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20a30b:	ff d0                	call   rax
    733bdd20a30d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a314:	00 
    733bdd20a315:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a31b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a321:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a327:	be 05 00 00 00       	mov    esi,0x5
    733bdd20a32c:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a331:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a335:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a339:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a33d:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a341:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a348:	e9 9b 07 00 00       	jmp    0x733bdd20aae8
    733bdd20a34d:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20a354:	00 
    733bdd20a355:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20a35c:	c1 e9 0c             	shr    ecx,0xc
    733bdd20a35f:	89 c9                	mov    ecx,ecx
    733bdd20a361:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20a365:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd20a36a:	48 83 f8 00          	cmp    rax,0x0
    733bdd20a36e:	74 20                	je     0x733bdd20a390
    733bdd20a370:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd20a375:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd20a37c:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20a383:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20a389:	89 c9                	mov    ecx,ecx
    733bdd20a38b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20a38e:	eb 5b                	jmp    0x733bdd20a3eb
    733bdd20a390:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a397:	00 
    733bdd20a398:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd20a39f:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    733bdd20a3a6:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20a3ad:	00 
    733bdd20a3ae:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1013c
    733bdd20a3b5:	01 01 00 
    733bdd20a3b8:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20a3bf:	00 00 00 
    733bdd20a3c2:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd20a3c9:	00 00 00 
    733bdd20a3cc:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20a3d3:	59 00 00 
    733bdd20a3d6:	ff d0                	call   rax
    733bdd20a3d8:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a3df:	00 
    733bdd20a3e0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20a3e7:	75 1d                	jne    0x733bdd20a406
    733bdd20a3e9:	eb 5b                	jmp    0x733bdd20a446
    733bdd20a3eb:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    733bdd20a3f2:	83 e8 04             	sub    eax,0x4
    733bdd20a3f5:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd20a3f9:	83 e0 03             	and    eax,0x3
    733bdd20a3fc:	83 f8 00             	cmp    eax,0x0
    733bdd20a3ff:	75 47                	jne    0x733bdd20a448
    733bdd20a401:	e9 cb 00 00 00       	jmp    0x733bdd20a4d1
    733bdd20a406:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a40d:	00 
    733bdd20a40e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a414:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a41a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a420:	be 05 00 00 00       	mov    esi,0x5
    733bdd20a425:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a42a:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a42e:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a432:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a436:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a43a:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a441:	e9 a2 06 00 00       	jmp    0x733bdd20aae8
    733bdd20a446:	eb a3                	jmp    0x733bdd20a3eb
    733bdd20a448:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20a44f:	00 
    733bdd20a450:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a454:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20a45b:	00 
    733bdd20a45c:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1013c
    733bdd20a463:	01 01 00 
    733bdd20a466:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20a46d:	00 00 00 
    733bdd20a470:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20a477:	00 00 00 
    733bdd20a47a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20a481:	59 00 00 
    733bdd20a484:	ba 3c 01 01 00       	mov    edx,0x1013c
    733bdd20a489:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20a48f:	ff d0                	call   rax
    733bdd20a491:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a498:	00 
    733bdd20a499:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a49f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a4a5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a4ab:	be 05 00 00 00       	mov    esi,0x5
    733bdd20a4b0:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a4b5:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a4b9:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a4bd:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a4c1:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a4c5:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a4cc:	e9 17 06 00 00       	jmp    0x733bdd20aae8
    733bdd20a4d1:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20a4d8:	00 
    733bdd20a4d9:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a4dd:	c1 e9 0c             	shr    ecx,0xc
    733bdd20a4e0:	89 c9                	mov    ecx,ecx
    733bdd20a4e2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20a4e6:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd20a4eb:	48 83 f8 00          	cmp    rax,0x0
    733bdd20a4ef:	74 1d                	je     0x733bdd20a50e
    733bdd20a4f1:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd20a4f6:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    733bdd20a4fd:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a501:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20a507:	89 c9                	mov    ecx,ecx
    733bdd20a509:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20a50c:	eb 58                	jmp    0x733bdd20a566
    733bdd20a50e:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a515:	00 
    733bdd20a516:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    733bdd20a51d:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    733bdd20a521:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20a528:	00 
    733bdd20a529:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1013c
    733bdd20a530:	01 01 00 
    733bdd20a533:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20a53a:	00 00 00 
    733bdd20a53d:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd20a544:	00 00 00 
    733bdd20a547:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20a54e:	59 00 00 
    733bdd20a551:	ff d0                	call   rax
    733bdd20a553:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a55a:	00 
    733bdd20a55b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20a562:	75 29                	jne    0x733bdd20a58d
    733bdd20a564:	eb 67                	jmp    0x733bdd20a5cd
    733bdd20a566:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    733bdd20a56d:	00 
    733bdd20a56e:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20a575:	00 
    733bdd20a576:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    733bdd20a57a:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd20a57d:	83 ea 00             	sub    edx,0x0
    733bdd20a580:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd20a583:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20a586:	75 47                	jne    0x733bdd20a5cf
    733bdd20a588:	e9 87 00 00 00       	jmp    0x733bdd20a614
    733bdd20a58d:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a594:	00 
    733bdd20a595:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a59b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a5a1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a5a7:	be 05 00 00 00       	mov    esi,0x5
    733bdd20a5ac:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a5b1:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a5b5:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a5b9:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a5bd:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a5c1:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a5c8:	e9 1b 05 00 00       	jmp    0x733bdd20aae8
    733bdd20a5cd:	eb 97                	jmp    0x733bdd20a566
    733bdd20a5cf:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20a5d6:	00 
    733bdd20a5d7:	c7 87 bc 00 00 00 40 	mov    DWORD PTR [rdi+0xbc],0x10140
    733bdd20a5de:	01 01 00 
    733bdd20a5e1:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20a5e8:	00 00 00 
    733bdd20a5eb:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20a5f2:	00 00 00 
    733bdd20a5f5:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20a5fc:	59 00 00 
    733bdd20a5ff:	ff d0                	call   rax
    733bdd20a601:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a608:	00 
    733bdd20a609:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20a610:	75 04                	jne    0x733bdd20a616
    733bdd20a612:	eb 42                	jmp    0x733bdd20a656
    733bdd20a614:	eb 42                	jmp    0x733bdd20a658
    733bdd20a616:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a61d:	00 
    733bdd20a61e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a624:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a62a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a630:	be 05 00 00 00       	mov    esi,0x5
    733bdd20a635:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a63a:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a63e:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a642:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a646:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a64a:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a651:	e9 92 04 00 00       	jmp    0x733bdd20aae8
    733bdd20a656:	eb bc                	jmp    0x733bdd20a614
    733bdd20a658:	eb 00                	jmp    0x733bdd20a65a
    733bdd20a65a:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a661:	00 
    733bdd20a662:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    733bdd20a669:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20a66f:	81 c9 15 7c 00 00    	or     ecx,0x7c15
    733bdd20a675:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    733bdd20a679:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20a67c:	eb 00                	jmp    0x733bdd20a67e
    733bdd20a67e:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a685:	00 
    733bdd20a686:	8b 7c 24 54          	mov    edi,DWORD PTR [rsp+0x54]
    733bdd20a68a:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20a691:	89 ca                	mov    edx,ecx
    733bdd20a693:	01 fa                	add    edx,edi
    733bdd20a695:	89 10                	mov    DWORD PTR [rax],edx
    733bdd20a697:	89 ce                	mov    esi,ecx
    733bdd20a699:	c1 ee 1f             	shr    esi,0x1f
    733bdd20a69c:	89 fb                	mov    ebx,edi
    733bdd20a69e:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20a6a1:	89 d5                	mov    ebp,edx
    733bdd20a6a3:	c1 ed 1f             	shr    ebp,0x1f
    733bdd20a6a6:	31 eb                	xor    ebx,ebp
    733bdd20a6a8:	31 ee                	xor    esi,ebp
    733bdd20a6aa:	21 de                	and    esi,ebx
    733bdd20a6ac:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd20a6af:	39 f9                	cmp    ecx,edi
    733bdd20a6b1:	0f 92 c1             	setb   cl
    733bdd20a6b4:	80 e1 01             	and    cl,0x1
    733bdd20a6b7:	0f b6 c9             	movzx  ecx,cl
    733bdd20a6ba:	83 fa 00             	cmp    edx,0x0
    733bdd20a6bd:	0f 94 c3             	sete   bl
    733bdd20a6c0:	80 e3 01             	and    bl,0x1
    733bdd20a6c3:	0f b6 fb             	movzx  edi,bl
    733bdd20a6c6:	c1 ea 1f             	shr    edx,0x1f
    733bdd20a6c9:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd20a6cf:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20a6d5:	89 f2                	mov    edx,esi
    733bdd20a6d7:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd20a6dd:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd20a6e3:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd20a6e9:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd20a6ef:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20a6f5:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20a6fb:	eb 00                	jmp    0x733bdd20a6fd
    733bdd20a6fd:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    733bdd20a701:	83 e0 03             	and    eax,0x3
    733bdd20a704:	83 f8 00             	cmp    eax,0x0
    733bdd20a707:	0f 84 88 00 00 00    	je     0x733bdd20a795
    733bdd20a70d:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20a714:	00 
    733bdd20a715:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a719:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20a720:	00 
    733bdd20a721:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10146
    733bdd20a728:	01 01 00 
    733bdd20a72b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20a732:	00 00 00 
    733bdd20a735:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    733bdd20a73c:	00 00 00 
    733bdd20a73f:	31 c0                	xor    eax,eax
    733bdd20a741:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20a748:	59 00 00 
    733bdd20a74b:	ba 46 01 01 00       	mov    edx,0x10146
    733bdd20a750:	45 31 c0             	xor    r8d,r8d
    733bdd20a753:	ff d0                	call   rax
    733bdd20a755:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a75c:	00 
    733bdd20a75d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a763:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a769:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a76f:	be 08 00 00 00       	mov    esi,0x8
    733bdd20a774:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a779:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a77d:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a781:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a785:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a789:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a790:	e9 53 03 00 00       	jmp    0x733bdd20aae8
    733bdd20a795:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20a79c:	00 
    733bdd20a79d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a7a1:	c1 e9 0c             	shr    ecx,0xc
    733bdd20a7a4:	89 c9                	mov    ecx,ecx
    733bdd20a7a6:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20a7aa:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    733bdd20a7af:	48 83 f8 00          	cmp    rax,0x0
    733bdd20a7b3:	74 1a                	je     0x733bdd20a7cf
    733bdd20a7b5:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    733bdd20a7ba:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20a7be:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20a7c4:	89 c9                	mov    ecx,ecx
    733bdd20a7c6:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20a7c9:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20a7cd:	eb 57                	jmp    0x733bdd20a826
    733bdd20a7cf:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a7d6:	00 
    733bdd20a7d7:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    733bdd20a7db:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20a7e2:	00 
    733bdd20a7e3:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10146
    733bdd20a7ea:	01 01 00 
    733bdd20a7ed:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20a7f4:	00 00 00 
    733bdd20a7f7:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd20a7fe:	00 00 00 
    733bdd20a801:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20a808:	59 00 00 
    733bdd20a80b:	ff d0                	call   rax
    733bdd20a80d:	89 c1                	mov    ecx,eax
    733bdd20a80f:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a816:	00 
    733bdd20a817:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd20a81b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20a822:	75 22                	jne    0x733bdd20a846
    733bdd20a824:	eb 60                	jmp    0x733bdd20a886
    733bdd20a826:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    733bdd20a82a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20a82e:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    733bdd20a832:	83 c0 04             	add    eax,0x4
    733bdd20a835:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    733bdd20a839:	83 e0 03             	and    eax,0x3
    733bdd20a83c:	83 f8 00             	cmp    eax,0x0
    733bdd20a83f:	75 4f                	jne    0x733bdd20a890
    733bdd20a841:	e9 d2 00 00 00       	jmp    0x733bdd20a918
    733bdd20a846:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a84d:	00 
    733bdd20a84e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a854:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a85a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a860:	be 08 00 00 00       	mov    esi,0x8
    733bdd20a865:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a86a:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a86e:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a872:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a876:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a87a:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a881:	e9 62 02 00 00       	jmp    0x733bdd20aae8
    733bdd20a886:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    733bdd20a88a:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20a88e:	eb 96                	jmp    0x733bdd20a826
    733bdd20a890:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20a897:	00 
    733bdd20a898:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20a89c:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
    733bdd20a8a3:	00 
    733bdd20a8a4:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10146
    733bdd20a8ab:	01 01 00 
    733bdd20a8ae:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20a8b5:	00 00 00 
    733bdd20a8b8:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    733bdd20a8bf:	00 00 00 
    733bdd20a8c2:	31 c0                	xor    eax,eax
    733bdd20a8c4:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20a8cb:	59 00 00 
    733bdd20a8ce:	ba 46 01 01 00       	mov    edx,0x10146
    733bdd20a8d3:	45 31 c0             	xor    r8d,r8d
    733bdd20a8d6:	ff d0                	call   rax
    733bdd20a8d8:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a8df:	00 
    733bdd20a8e0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a8e6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a8ec:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a8f2:	be 08 00 00 00       	mov    esi,0x8
    733bdd20a8f7:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a8fc:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a900:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a904:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20a908:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20a90c:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20a913:	e9 d0 01 00 00       	jmp    0x733bdd20aae8
    733bdd20a918:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd20a91f:	00 
    733bdd20a920:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20a924:	c1 e9 0c             	shr    ecx,0xc
    733bdd20a927:	89 c9                	mov    ecx,ecx
    733bdd20a929:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20a92d:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    733bdd20a932:	48 83 f8 00          	cmp    rax,0x0
    733bdd20a936:	74 1a                	je     0x733bdd20a952
    733bdd20a938:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd20a93d:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20a941:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20a947:	89 c9                	mov    ecx,ecx
    733bdd20a949:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20a94c:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd20a950:	eb 57                	jmp    0x733bdd20a9a9
    733bdd20a952:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a959:	00 
    733bdd20a95a:	8b 74 24 3c          	mov    esi,DWORD PTR [rsp+0x3c]
    733bdd20a95e:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20a965:	00 
    733bdd20a966:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10146
    733bdd20a96d:	01 01 00 
    733bdd20a970:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20a977:	00 00 00 
    733bdd20a97a:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd20a981:	00 00 00 
    733bdd20a984:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20a98b:	59 00 00 
    733bdd20a98e:	ff d0                	call   rax
    733bdd20a990:	89 c1                	mov    ecx,eax
    733bdd20a992:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a999:	00 
    733bdd20a99a:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    733bdd20a99e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20a9a5:	75 2b                	jne    0x733bdd20a9d2
    733bdd20a9a7:	eb 69                	jmp    0x733bdd20aa12
    733bdd20a9a9:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a9b0:	00 
    733bdd20a9b1:	8b 74 24 38          	mov    esi,DWORD PTR [rsp+0x38]
    733bdd20a9b5:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20a9b9:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    733bdd20a9bd:	89 54 24 24          	mov    DWORD PTR [rsp+0x24],edx
    733bdd20a9c1:	83 c1 04             	add    ecx,0x4
    733bdd20a9c4:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd20a9c7:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd20a9cd:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20a9d0:	eb 4a                	jmp    0x733bdd20aa1c
    733bdd20a9d2:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20a9d9:	00 
    733bdd20a9da:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20a9e0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20a9e6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20a9ec:	be 08 00 00 00       	mov    esi,0x8
    733bdd20a9f1:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20a9f6:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20a9fa:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20a9fe:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20aa02:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20aa06:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20aa0d:	e9 d6 00 00 00       	jmp    0x733bdd20aae8
    733bdd20aa12:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    733bdd20aa16:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd20aa1a:	eb 8d                	jmp    0x733bdd20a9a9
    733bdd20aa1c:	eb 00                	jmp    0x733bdd20aa1e
    733bdd20aa1e:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    733bdd20aa22:	83 e0 01             	and    eax,0x1
    733bdd20aa25:	83 f8 00             	cmp    eax,0x0
    733bdd20aa28:	75 2e                	jne    0x733bdd20aa58
    733bdd20aa2a:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    733bdd20aa2e:	be 09 00 00 00       	mov    esi,0x9
    733bdd20aa33:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20aa38:	b0 01                	mov    al,0x1
    733bdd20aa3a:	89 d7                	mov    edi,edx
    733bdd20aa3c:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20aa40:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20aa44:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20aa48:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20aa4c:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20aa53:	e9 90 00 00 00       	jmp    0x733bdd20aae8
    733bdd20aa58:	48 8b bc 24 b8 00 00 	mov    rdi,QWORD PTR [rsp+0xb8]
    733bdd20aa5f:	00 
    733bdd20aa60:	48 8b 94 24 b0 00 00 	mov    rdx,QWORD PTR [rsp+0xb0]
    733bdd20aa67:	00 
    733bdd20aa68:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1014a
    733bdd20aa6f:	01 01 00 
    733bdd20aa72:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20aa79:	00 00 00 
    733bdd20aa7c:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    733bdd20aa83:	00 00 00 
    733bdd20aa86:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd20aa8d:	59 00 00 
    733bdd20aa90:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd20aa95:	ff d0                	call   rax
    733bdd20aa97:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20aa9e:	00 
    733bdd20aa9f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20aaa5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20aaab:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20aab1:	be 09 00 00 00       	mov    esi,0x9
    733bdd20aab6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20aabb:	89 7c 24 70          	mov    DWORD PTR [rsp+0x70],edi
    733bdd20aabf:	89 74 24 74          	mov    DWORD PTR [rsp+0x74],esi
    733bdd20aac3:	89 54 24 78          	mov    DWORD PTR [rsp+0x78],edx
    733bdd20aac7:	89 4c 24 7c          	mov    DWORD PTR [rsp+0x7c],ecx
    733bdd20aacb:	88 84 24 83 00 00 00 	mov    BYTE PTR [rsp+0x83],al
    733bdd20aad2:	eb 14                	jmp    0x733bdd20aae8
    733bdd20aad4:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20aadb:	00 
    733bdd20aadc:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20aae3:	e9 e4 00 00 00       	jmp    0x733bdd20abcc
    733bdd20aae8:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
    733bdd20aaef:	00 
    733bdd20aaf0:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    733bdd20aaf4:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd20aaf8:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    733bdd20aafc:	8b 7c 24 7c          	mov    edi,DWORD PTR [rsp+0x7c]
    733bdd20ab00:	8a 9c 24 83 00 00 00 	mov    bl,BYTE PTR [rsp+0x83]
    733bdd20ab07:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    733bdd20ab0b:	89 c3                	mov    ebx,eax
    733bdd20ab0d:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    733bdd20ab11:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    733bdd20ab15:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    733bdd20ab19:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    733bdd20ab1d:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20ab23:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    733bdd20ab27:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20ab2d:	73 2c                	jae    0x733bdd20ab5b
    733bdd20ab2f:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd20ab36:	00 
    733bdd20ab37:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd20ab3b:	89 d1                	mov    ecx,edx
    733bdd20ab3d:	c1 e9 01             	shr    ecx,0x1
    733bdd20ab40:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20ab46:	89 c9                	mov    ecx,ecx
    733bdd20ab48:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20ab4c:	48 89 c6             	mov    rsi,rax
    733bdd20ab4f:	48 01 ce             	add    rsi,rcx
    733bdd20ab52:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    733bdd20ab56:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20ab59:	74 32                	je     0x733bdd20ab8d
    733bdd20ab5b:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20ab62:	00 
    733bdd20ab63:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    733bdd20ab67:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    733bdd20ab6b:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    733bdd20ab6f:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    733bdd20ab73:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd20ab79:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd20ab7f:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd20ab85:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd20ab8b:	eb 3f                	jmp    0x733bdd20abcc
    733bdd20ab8d:	4c 8b b4 24 b0 00 00 	mov    r14,QWORD PTR [rsp+0xb0]
    733bdd20ab94:	00 
    733bdd20ab95:	4c 8b ac 24 b8 00 00 	mov    r13,QWORD PTR [rsp+0xb8]
    733bdd20ab9c:	00 
    733bdd20ab9d:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    733bdd20aba1:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    733bdd20aba5:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd20aba9:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd20abb0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20abb7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20abbe:	00 
    733bdd20abbf:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20abc3:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    733bdd20abca:	ff e0                	jmp    rax
    733bdd20abcc:	48 81 c4 d8 00 00 00 	add    rsp,0xd8
    733bdd20abd3:	c2 08 00             	ret    0x8
