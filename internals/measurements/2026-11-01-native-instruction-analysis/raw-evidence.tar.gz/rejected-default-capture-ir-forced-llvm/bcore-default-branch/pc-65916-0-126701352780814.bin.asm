
build-native-instruction-analysis/capture/bcore-default-branch/pc-65916-0-126701352780814.bin:     file format binary


Disassembly of section .data:

0000733bf520040e <.data>:
    733bf520040e:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bf5200415:	70 01 01 00 
    733bf5200419:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200420:	02 00 00 00 
    733bf5200424:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf520042b:	05 00 00 00 
    733bf520042f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf5200436:	01 
    733bf5200437:	c2 08 00             	ret    0x8
    733bf520043a:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf5200441:	01 
    733bf5200442:	c2 08 00             	ret    0x8
    733bf5200445:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bf520044c:	10 01 01 00 
    733bf5200450:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200457:	04 00 00 00 
    733bf520045b:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    733bf5200462:	07 00 00 00 
    733bf5200466:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf520046d:	01 
    733bf520046e:	c2 08 00             	ret    0x8
