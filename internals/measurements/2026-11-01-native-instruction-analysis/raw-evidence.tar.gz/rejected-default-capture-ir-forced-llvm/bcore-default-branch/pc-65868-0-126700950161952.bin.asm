
build-native-instruction-analysis/capture/bcore-default-branch/pc-65868-0-126700950161952.bin:     file format binary


Disassembly of section .data:

0000733bdd208a20 <.data>:
    733bdd208a20:	48 81 ec 08 01 00 00 	sub    rsp,0x108
    733bdd208a27:	4c 89 b4 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],r14
    733bdd208a2e:	00 
    733bdd208a2f:	4c 89 ac 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r13
    733bdd208a36:	00 
    733bdd208a37:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd208a3e:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    733bdd208a45:	00 
    733bdd208a46:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd208a4d:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    733bdd208a54:	00 
    733bdd208a55:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd208a5c:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    733bdd208a63:	00 
    733bdd208a64:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd208a6b:	00 
    733bdd208a6c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd208a72:	83 fa 00             	cmp    edx,0x0
    733bdd208a75:	0f 94 c0             	sete   al
    733bdd208a78:	81 ea 4c 01 01 00    	sub    edx,0x1014c
    733bdd208a7e:	83 fa 22             	cmp    edx,0x22
    733bdd208a81:	0f 97 c2             	seta   dl
    733bdd208a84:	08 d0                	or     al,dl
    733bdd208a86:	24 01                	and    al,0x1
    733bdd208a88:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd208a8e:	83 fa 00             	cmp    edx,0x0
    733bdd208a91:	0f 94 c1             	sete   cl
    733bdd208a94:	81 ea 4c 01 01 00    	sub    edx,0x1014c
    733bdd208a9a:	83 fa 22             	cmp    edx,0x22
    733bdd208a9d:	0f 97 c2             	seta   dl
    733bdd208aa0:	08 d1                	or     cl,dl
    733bdd208aa2:	20 c8                	and    al,cl
    733bdd208aa4:	a8 01                	test   al,0x1
    733bdd208aa6:	75 05                	jne    0x733bdd208aad
    733bdd208aa8:	e9 49 0d 00 00       	jmp    0x733bdd2097f6
    733bdd208aad:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208ab4:	00 
    733bdd208ab5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd208abc:	48 89 c8             	mov    rax,rcx
    733bdd208abf:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd208ac5:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    733bdd208acc:	00 
    733bdd208acd:	8b 81 20 00 10 00    	mov    eax,DWORD PTR [rcx+0x100020]
    733bdd208ad3:	83 c0 01             	add    eax,0x1
    733bdd208ad6:	89 81 20 00 10 00    	mov    DWORD PTR [rcx+0x100020],eax
    733bdd208adc:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd208ae1:	75 4c                	jne    0x733bdd208b2f
    733bdd208ae3:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd208aea:	00 
    733bdd208aeb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd208af1:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    733bdd208af8:	89 c2                	mov    edx,eax
    733bdd208afa:	83 c2 01             	add    edx,0x1
    733bdd208afd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd208b03:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd208b08:	73 23                	jae    0x733bdd208b2d
    733bdd208b0a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd208b11:	00 
    733bdd208b12:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd208b19:	89 c9                	mov    ecx,ecx
    733bdd208b1b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd208b1f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd208b26:	c7 04 08 08 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x8
    733bdd208b2d:	eb 00                	jmp    0x733bdd208b2f
    733bdd208b2f:	eb 00                	jmp    0x733bdd208b31
    733bdd208b31:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd208b38:	00 
    733bdd208b39:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd208b3c:	83 e8 04             	sub    eax,0x4
    733bdd208b3f:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    733bdd208b46:	8b 49 10             	mov    ecx,DWORD PTR [rcx+0x10]
    733bdd208b49:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    733bdd208b50:	83 e0 03             	and    eax,0x3
    733bdd208b53:	83 f8 00             	cmp    eax,0x0
    733bdd208b56:	74 74                	je     0x733bdd208bcc
    733bdd208b58:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd208b5f:	00 
    733bdd208b60:	8b 8c 24 cc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xcc]
    733bdd208b67:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd208b6e:	00 
    733bdd208b6f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd208b76:	00 00 00 
    733bdd208b79:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd208b80:	00 00 00 
    733bdd208b83:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd208b8a:	59 00 00 
    733bdd208b8d:	ba 4c 01 01 00       	mov    edx,0x1014c
    733bdd208b92:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd208b98:	ff d0                	call   rax
    733bdd208b9a:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208ba1:	00 
    733bdd208ba2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208ba8:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208bad:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208bb2:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208bb9:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208bc0:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208bc7:	e9 58 0d 00 00       	jmp    0x733bdd209924
    733bdd208bcc:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd208bd3:	00 
    733bdd208bd4:	8b 8c 24 cc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xcc]
    733bdd208bdb:	c1 e9 0c             	shr    ecx,0xc
    733bdd208bde:	89 c9                	mov    ecx,ecx
    733bdd208be0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd208be4:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    733bdd208beb:	00 
    733bdd208bec:	48 83 f8 00          	cmp    rax,0x0
    733bdd208bf0:	74 23                	je     0x733bdd208c15
    733bdd208bf2:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd208bf9:	00 
    733bdd208bfa:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    733bdd208c01:	8b 8c 24 cc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xcc]
    733bdd208c08:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd208c0e:	89 c9                	mov    ecx,ecx
    733bdd208c10:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd208c13:	eb 51                	jmp    0x733bdd208c66
    733bdd208c15:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208c1c:	00 
    733bdd208c1d:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    733bdd208c24:	8b b4 24 cc 00 00 00 	mov    esi,DWORD PTR [rsp+0xcc]
    733bdd208c2b:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd208c32:	00 
    733bdd208c33:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd208c3a:	00 00 00 
    733bdd208c3d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd208c44:	00 00 00 
    733bdd208c47:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd208c4e:	59 00 00 
    733bdd208c51:	ff d0                	call   rax
    733bdd208c53:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208c5a:	00 
    733bdd208c5b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd208c62:	75 32                	jne    0x733bdd208c96
    733bdd208c64:	eb 62                	jmp    0x733bdd208cc8
    733bdd208c66:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd208c6d:	00 
    733bdd208c6e:	8b 84 24 cc 00 00 00 	mov    eax,DWORD PTR [rsp+0xcc]
    733bdd208c75:	83 e8 04             	sub    eax,0x4
    733bdd208c78:	89 84 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],eax
    733bdd208c7f:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    733bdd208c82:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    733bdd208c89:	83 e0 03             	and    eax,0x3
    733bdd208c8c:	83 f8 00             	cmp    eax,0x0
    733bdd208c8f:	75 39                	jne    0x733bdd208cca
    733bdd208c91:	e9 a8 00 00 00       	jmp    0x733bdd208d3e
    733bdd208c96:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208c9d:	00 
    733bdd208c9e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208ca4:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208ca9:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208cae:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208cb5:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208cbc:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208cc3:	e9 5c 0c 00 00       	jmp    0x733bdd209924
    733bdd208cc8:	eb 9c                	jmp    0x733bdd208c66
    733bdd208cca:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd208cd1:	00 
    733bdd208cd2:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd208cd9:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd208ce0:	00 
    733bdd208ce1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd208ce8:	00 00 00 
    733bdd208ceb:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd208cf2:	00 00 00 
    733bdd208cf5:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd208cfc:	59 00 00 
    733bdd208cff:	ba 4c 01 01 00       	mov    edx,0x1014c
    733bdd208d04:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd208d0a:	ff d0                	call   rax
    733bdd208d0c:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208d13:	00 
    733bdd208d14:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208d1a:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208d1f:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208d24:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208d2b:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208d32:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208d39:	e9 e6 0b 00 00       	jmp    0x733bdd209924
    733bdd208d3e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd208d45:	00 
    733bdd208d46:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd208d4d:	c1 e9 0c             	shr    ecx,0xc
    733bdd208d50:	89 c9                	mov    ecx,ecx
    733bdd208d52:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd208d56:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    733bdd208d5d:	00 
    733bdd208d5e:	48 83 f8 00          	cmp    rax,0x0
    733bdd208d62:	74 23                	je     0x733bdd208d87
    733bdd208d64:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    733bdd208d6b:	00 
    733bdd208d6c:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd208d73:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd208d7a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd208d80:	89 c9                	mov    ecx,ecx
    733bdd208d82:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd208d85:	eb 51                	jmp    0x733bdd208dd8
    733bdd208d87:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208d8e:	00 
    733bdd208d8f:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd208d96:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    733bdd208d9d:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd208da4:	00 
    733bdd208da5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd208dac:	00 00 00 
    733bdd208daf:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd208db6:	00 00 00 
    733bdd208db9:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd208dc0:	59 00 00 
    733bdd208dc3:	ff d0                	call   rax
    733bdd208dc5:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208dcc:	00 
    733bdd208dcd:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd208dd4:	75 32                	jne    0x733bdd208e08
    733bdd208dd6:	eb 62                	jmp    0x733bdd208e3a
    733bdd208dd8:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd208ddf:	00 
    733bdd208de0:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    733bdd208de7:	83 e8 04             	sub    eax,0x4
    733bdd208dea:	89 84 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],eax
    733bdd208df1:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    733bdd208df4:	89 8c 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],ecx
    733bdd208dfb:	83 e0 03             	and    eax,0x3
    733bdd208dfe:	83 f8 00             	cmp    eax,0x0
    733bdd208e01:	75 39                	jne    0x733bdd208e3c
    733bdd208e03:	e9 a8 00 00 00       	jmp    0x733bdd208eb0
    733bdd208e08:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208e0f:	00 
    733bdd208e10:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208e16:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208e1b:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208e20:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208e27:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208e2e:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208e35:	e9 ea 0a 00 00       	jmp    0x733bdd209924
    733bdd208e3a:	eb 9c                	jmp    0x733bdd208dd8
    733bdd208e3c:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd208e43:	00 
    733bdd208e44:	8b 8c 24 a0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa0]
    733bdd208e4b:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd208e52:	00 
    733bdd208e53:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd208e5a:	00 00 00 
    733bdd208e5d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd208e64:	00 00 00 
    733bdd208e67:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd208e6e:	59 00 00 
    733bdd208e71:	ba 4c 01 01 00       	mov    edx,0x1014c
    733bdd208e76:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd208e7c:	ff d0                	call   rax
    733bdd208e7e:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208e85:	00 
    733bdd208e86:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208e8c:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208e91:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208e96:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208e9d:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208ea4:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208eab:	e9 74 0a 00 00       	jmp    0x733bdd209924
    733bdd208eb0:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd208eb7:	00 
    733bdd208eb8:	8b 8c 24 a0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa0]
    733bdd208ebf:	c1 e9 0c             	shr    ecx,0xc
    733bdd208ec2:	89 c9                	mov    ecx,ecx
    733bdd208ec4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd208ec8:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd208ecf:	00 
    733bdd208ed0:	48 83 f8 00          	cmp    rax,0x0
    733bdd208ed4:	74 23                	je     0x733bdd208ef9
    733bdd208ed6:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd208edd:	00 
    733bdd208ede:	8b 94 24 a4 00 00 00 	mov    edx,DWORD PTR [rsp+0xa4]
    733bdd208ee5:	8b 8c 24 a0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa0]
    733bdd208eec:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd208ef2:	89 c9                	mov    ecx,ecx
    733bdd208ef4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd208ef7:	eb 51                	jmp    0x733bdd208f4a
    733bdd208ef9:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208f00:	00 
    733bdd208f01:	8b 94 24 a4 00 00 00 	mov    edx,DWORD PTR [rsp+0xa4]
    733bdd208f08:	8b b4 24 a0 00 00 00 	mov    esi,DWORD PTR [rsp+0xa0]
    733bdd208f0f:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd208f16:	00 
    733bdd208f17:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd208f1e:	00 00 00 
    733bdd208f21:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd208f28:	00 00 00 
    733bdd208f2b:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd208f32:	59 00 00 
    733bdd208f35:	ff d0                	call   rax
    733bdd208f37:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208f3e:	00 
    733bdd208f3f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd208f46:	75 32                	jne    0x733bdd208f7a
    733bdd208f48:	eb 62                	jmp    0x733bdd208fac
    733bdd208f4a:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd208f51:	00 
    733bdd208f52:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [rsp+0xa0]
    733bdd208f59:	83 e8 04             	sub    eax,0x4
    733bdd208f5c:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd208f63:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    733bdd208f66:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    733bdd208f6d:	83 e0 03             	and    eax,0x3
    733bdd208f70:	83 f8 00             	cmp    eax,0x0
    733bdd208f73:	75 39                	jne    0x733bdd208fae
    733bdd208f75:	e9 a8 00 00 00       	jmp    0x733bdd209022
    733bdd208f7a:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208f81:	00 
    733bdd208f82:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208f88:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd208f8d:	b8 02 00 00 00       	mov    eax,0x2
    733bdd208f92:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd208f99:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd208fa0:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd208fa7:	e9 78 09 00 00       	jmp    0x733bdd209924
    733bdd208fac:	eb 9c                	jmp    0x733bdd208f4a
    733bdd208fae:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd208fb5:	00 
    733bdd208fb6:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    733bdd208fbd:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd208fc4:	00 
    733bdd208fc5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd208fcc:	00 00 00 
    733bdd208fcf:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd208fd6:	00 00 00 
    733bdd208fd9:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd208fe0:	59 00 00 
    733bdd208fe3:	ba 4c 01 01 00       	mov    edx,0x1014c
    733bdd208fe8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd208fee:	ff d0                	call   rax
    733bdd208ff0:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd208ff7:	00 
    733bdd208ff8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208ffe:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd209003:	b8 02 00 00 00       	mov    eax,0x2
    733bdd209008:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd20900f:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd209016:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd20901d:	e9 02 09 00 00       	jmp    0x733bdd209924
    733bdd209022:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd209029:	00 
    733bdd20902a:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    733bdd209031:	c1 e9 0c             	shr    ecx,0xc
    733bdd209034:	89 c9                	mov    ecx,ecx
    733bdd209036:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20903a:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    733bdd209041:	00 
    733bdd209042:	48 83 f8 00          	cmp    rax,0x0
    733bdd209046:	74 23                	je     0x733bdd20906b
    733bdd209048:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    733bdd20904f:	00 
    733bdd209050:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    733bdd209057:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    733bdd20905e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd209064:	89 c9                	mov    ecx,ecx
    733bdd209066:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd209069:	eb 51                	jmp    0x733bdd2090bc
    733bdd20906b:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209072:	00 
    733bdd209073:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    733bdd20907a:	8b b4 24 90 00 00 00 	mov    esi,DWORD PTR [rsp+0x90]
    733bdd209081:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd209088:	00 
    733bdd209089:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd209090:	00 00 00 
    733bdd209093:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd20909a:	00 00 00 
    733bdd20909d:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2090a4:	59 00 00 
    733bdd2090a7:	ff d0                	call   rax
    733bdd2090a9:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2090b0:	00 
    733bdd2090b1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2090b8:	75 32                	jne    0x733bdd2090ec
    733bdd2090ba:	eb 62                	jmp    0x733bdd20911e
    733bdd2090bc:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd2090c3:	00 
    733bdd2090c4:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    733bdd2090cb:	83 e8 04             	sub    eax,0x4
    733bdd2090ce:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    733bdd2090d5:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    733bdd2090d8:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    733bdd2090df:	83 e0 03             	and    eax,0x3
    733bdd2090e2:	83 f8 00             	cmp    eax,0x0
    733bdd2090e5:	75 39                	jne    0x733bdd209120
    733bdd2090e7:	e9 a8 00 00 00       	jmp    0x733bdd209194
    733bdd2090ec:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2090f3:	00 
    733bdd2090f4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2090fa:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd2090ff:	b8 02 00 00 00       	mov    eax,0x2
    733bdd209104:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd20910b:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd209112:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd209119:	e9 06 08 00 00       	jmp    0x733bdd209924
    733bdd20911e:	eb 9c                	jmp    0x733bdd2090bc
    733bdd209120:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd209127:	00 
    733bdd209128:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd20912f:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd209136:	00 
    733bdd209137:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20913e:	00 00 00 
    733bdd209141:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd209148:	00 00 00 
    733bdd20914b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd209152:	59 00 00 
    733bdd209155:	ba 4c 01 01 00       	mov    edx,0x1014c
    733bdd20915a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd209160:	ff d0                	call   rax
    733bdd209162:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209169:	00 
    733bdd20916a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd209170:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd209175:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20917a:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd209181:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd209188:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd20918f:	e9 90 07 00 00       	jmp    0x733bdd209924
    733bdd209194:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20919b:	00 
    733bdd20919c:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd2091a3:	c1 e9 0c             	shr    ecx,0xc
    733bdd2091a6:	89 c9                	mov    ecx,ecx
    733bdd2091a8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2091ac:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd2091b1:	48 83 f8 00          	cmp    rax,0x0
    733bdd2091b5:	74 20                	je     0x733bdd2091d7
    733bdd2091b7:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd2091bc:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd2091c3:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd2091ca:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2091d0:	89 c9                	mov    ecx,ecx
    733bdd2091d2:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2091d5:	eb 51                	jmp    0x733bdd209228
    733bdd2091d7:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2091de:	00 
    733bdd2091df:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd2091e6:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    733bdd2091ed:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd2091f4:	00 
    733bdd2091f5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2091fc:	00 00 00 
    733bdd2091ff:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd209206:	00 00 00 
    733bdd209209:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd209210:	59 00 00 
    733bdd209213:	ff d0                	call   rax
    733bdd209215:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20921c:	00 
    733bdd20921d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd209224:	75 23                	jne    0x733bdd209249
    733bdd209226:	eb 53                	jmp    0x733bdd20927b
    733bdd209228:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    733bdd20922f:	00 
    733bdd209230:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd209237:	00 
    733bdd209238:	8b 94 24 80 00 00 00 	mov    edx,DWORD PTR [rsp+0x80]
    733bdd20923f:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd209242:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd209245:	75 36                	jne    0x733bdd20927d
    733bdd209247:	eb 79                	jmp    0x733bdd2092c2
    733bdd209249:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209250:	00 
    733bdd209251:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd209257:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd20925c:	b8 02 00 00 00       	mov    eax,0x2
    733bdd209261:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd209268:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd20926f:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd209276:	e9 a9 06 00 00       	jmp    0x733bdd209924
    733bdd20927b:	eb ab                	jmp    0x733bdd209228
    733bdd20927d:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd209284:	00 
    733bdd209285:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1014e
    733bdd20928c:	01 01 00 
    733bdd20928f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd209296:	00 00 00 
    733bdd209299:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd2092a0:	00 00 00 
    733bdd2092a3:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd2092aa:	59 00 00 
    733bdd2092ad:	ff d0                	call   rax
    733bdd2092af:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2092b6:	00 
    733bdd2092b7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2092be:	75 04                	jne    0x733bdd2092c4
    733bdd2092c0:	eb 34                	jmp    0x733bdd2092f6
    733bdd2092c2:	eb 34                	jmp    0x733bdd2092f8
    733bdd2092c4:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2092cb:	00 
    733bdd2092cc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2092d2:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd2092d7:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2092dc:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd2092e3:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd2092ea:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd2092f1:	e9 2e 06 00 00       	jmp    0x733bdd209924
    733bdd2092f6:	eb ca                	jmp    0x733bdd2092c2
    733bdd2092f8:	eb 00                	jmp    0x733bdd2092fa
    733bdd2092fa:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    733bdd209301:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd209308:	00 
    733bdd209309:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd20930f:	89 54 24 6c          	mov    DWORD PTR [rsp+0x6c],edx
    733bdd209313:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd209316:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd20931a:	83 e8 04             	sub    eax,0x4
    733bdd20931d:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd209321:	83 e0 03             	and    eax,0x3
    733bdd209324:	83 f8 00             	cmp    eax,0x0
    733bdd209327:	74 7b                	je     0x733bdd2093a4
    733bdd209329:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd209330:	00 
    733bdd209331:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd209335:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd20933c:	00 
    733bdd20933d:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1014e
    733bdd209344:	01 01 00 
    733bdd209347:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20934e:	00 00 00 
    733bdd209351:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd209358:	00 00 00 
    733bdd20935b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd209362:	59 00 00 
    733bdd209365:	ba 4e 01 01 00       	mov    edx,0x1014e
    733bdd20936a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd209370:	ff d0                	call   rax
    733bdd209372:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209379:	00 
    733bdd20937a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd209380:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd209385:	b8 04 00 00 00       	mov    eax,0x4
    733bdd20938a:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd209391:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd209398:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd20939f:	e9 80 05 00 00       	jmp    0x733bdd209924
    733bdd2093a4:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd2093ab:	00 
    733bdd2093ac:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd2093b0:	c1 e9 0c             	shr    ecx,0xc
    733bdd2093b3:	89 c9                	mov    ecx,ecx
    733bdd2093b5:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2093b9:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    733bdd2093be:	48 83 f8 00          	cmp    rax,0x0
    733bdd2093c2:	74 1a                	je     0x733bdd2093de
    733bdd2093c4:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    733bdd2093c9:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    733bdd2093cd:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd2093d1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2093d7:	89 c9                	mov    ecx,ecx
    733bdd2093d9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2093dc:	eb 55                	jmp    0x733bdd209433
    733bdd2093de:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2093e5:	00 
    733bdd2093e6:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    733bdd2093ea:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    733bdd2093ee:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd2093f5:	00 
    733bdd2093f6:	c7 80 bc 00 00 00 4e 	mov    DWORD PTR [rax+0xbc],0x1014e
    733bdd2093fd:	01 01 00 
    733bdd209400:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd209407:	00 00 00 
    733bdd20940a:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd209411:	00 00 00 
    733bdd209414:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20941b:	59 00 00 
    733bdd20941e:	ff d0                	call   rax
    733bdd209420:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209427:	00 
    733bdd209428:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20942f:	75 1a                	jne    0x733bdd20944b
    733bdd209431:	eb 4a                	jmp    0x733bdd20947d
    733bdd209433:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd209437:	83 e8 04             	sub    eax,0x4
    733bdd20943a:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd20943e:	83 e0 03             	and    eax,0x3
    733bdd209441:	83 f8 00             	cmp    eax,0x0
    733bdd209444:	75 39                	jne    0x733bdd20947f
    733bdd209446:	e9 af 00 00 00       	jmp    0x733bdd2094fa
    733bdd20944b:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209452:	00 
    733bdd209453:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd209459:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20945e:	b8 04 00 00 00       	mov    eax,0x4
    733bdd209463:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd20946a:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd209471:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd209478:	e9 a7 04 00 00       	jmp    0x733bdd209924
    733bdd20947d:	eb b4                	jmp    0x733bdd209433
    733bdd20947f:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd209486:	00 
    733bdd209487:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20948b:	48 8b b4 24 e0 00 00 	mov    rsi,QWORD PTR [rsp+0xe0]
    733bdd209492:	00 
    733bdd209493:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1014e
    733bdd20949a:	01 01 00 
    733bdd20949d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2094a4:	00 00 00 
    733bdd2094a7:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd2094ae:	00 00 00 
    733bdd2094b1:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2094b8:	59 00 00 
    733bdd2094bb:	ba 4e 01 01 00       	mov    edx,0x1014e
    733bdd2094c0:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2094c6:	ff d0                	call   rax
    733bdd2094c8:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2094cf:	00 
    733bdd2094d0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2094d6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2094db:	b8 04 00 00 00       	mov    eax,0x4
    733bdd2094e0:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd2094e7:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd2094ee:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd2094f5:	e9 2a 04 00 00       	jmp    0x733bdd209924
    733bdd2094fa:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd209501:	00 
    733bdd209502:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd209506:	c1 e9 0c             	shr    ecx,0xc
    733bdd209509:	89 c9                	mov    ecx,ecx
    733bdd20950b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20950f:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd209514:	48 83 f8 00          	cmp    rax,0x0
    733bdd209518:	74 1a                	je     0x733bdd209534
    733bdd20951a:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd20951f:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    733bdd209523:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd209527:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20952d:	89 c9                	mov    ecx,ecx
    733bdd20952f:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd209532:	eb 55                	jmp    0x733bdd209589
    733bdd209534:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20953b:	00 
    733bdd20953c:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    733bdd209540:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    733bdd209544:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
    733bdd20954b:	00 
    733bdd20954c:	c7 80 bc 00 00 00 4e 	mov    DWORD PTR [rax+0xbc],0x1014e
    733bdd209553:	01 01 00 
    733bdd209556:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20955d:	00 00 00 
    733bdd209560:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd209567:	00 00 00 
    733bdd20956a:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd209571:	59 00 00 
    733bdd209574:	ff d0                	call   rax
    733bdd209576:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20957d:	00 
    733bdd20957e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd209585:	75 26                	jne    0x733bdd2095ad
    733bdd209587:	eb 56                	jmp    0x733bdd2095df
    733bdd209589:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    733bdd209590:	00 
    733bdd209591:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd209598:	00 
    733bdd209599:	8b 54 24 5c          	mov    edx,DWORD PTR [rsp+0x5c]
    733bdd20959d:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd2095a0:	83 ea 0c             	sub    edx,0xc
    733bdd2095a3:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd2095a6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2095a9:	75 36                	jne    0x733bdd2095e1
    733bdd2095ab:	eb 79                	jmp    0x733bdd209626
    733bdd2095ad:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2095b4:	00 
    733bdd2095b5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2095bb:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2095c0:	b8 04 00 00 00       	mov    eax,0x4
    733bdd2095c5:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd2095cc:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd2095d3:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd2095da:	e9 45 03 00 00       	jmp    0x733bdd209924
    733bdd2095df:	eb a8                	jmp    0x733bdd209589
    733bdd2095e1:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
    733bdd2095e8:	00 
    733bdd2095e9:	c7 87 bc 00 00 00 52 	mov    DWORD PTR [rdi+0xbc],0x10152
    733bdd2095f0:	01 01 00 
    733bdd2095f3:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2095fa:	00 00 00 
    733bdd2095fd:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd209604:	00 00 00 
    733bdd209607:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20960e:	59 00 00 
    733bdd209611:	ff d0                	call   rax
    733bdd209613:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20961a:	00 
    733bdd20961b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd209622:	75 04                	jne    0x733bdd209628
    733bdd209624:	eb 34                	jmp    0x733bdd20965a
    733bdd209626:	eb 34                	jmp    0x733bdd20965c
    733bdd209628:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20962f:	00 
    733bdd209630:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd209636:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20963b:	b8 04 00 00 00       	mov    eax,0x4
    733bdd209640:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd209647:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd20964e:	89 84 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],eax
    733bdd209655:	e9 ca 02 00 00       	jmp    0x733bdd209924
    733bdd20965a:	eb ca                	jmp    0x733bdd209626
    733bdd20965c:	eb 00                	jmp    0x733bdd20965e
    733bdd20965e:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209665:	00 
    733bdd209666:	8b 08                	mov    ecx,DWORD PTR [rax]
    733bdd209668:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    733bdd20966c:	89 48 14             	mov    DWORD PTR [rax+0x14],ecx
    733bdd20966f:	eb 00                	jmp    0x733bdd209671
    733bdd209671:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209678:	00 
    733bdd209679:	8b 7c 24 4c          	mov    edi,DWORD PTR [rsp+0x4c]
    733bdd20967d:	89 fa                	mov    edx,edi
    733bdd20967f:	83 ea 00             	sub    edx,0x0
    733bdd209682:	83 fa 00             	cmp    edx,0x0
    733bdd209685:	0f 94 c1             	sete   cl
    733bdd209688:	80 e1 01             	and    cl,0x1
    733bdd20968b:	0f b6 f1             	movzx  esi,cl
    733bdd20968e:	89 74 24 48          	mov    DWORD PTR [rsp+0x48],esi
    733bdd209692:	c1 ea 1f             	shr    edx,0x1f
    733bdd209695:	89 f9                	mov    ecx,edi
    733bdd209697:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20969a:	89 d3                	mov    ebx,edx
    733bdd20969c:	31 cb                	xor    ebx,ecx
    733bdd20969e:	83 f1 00             	xor    ecx,0x0
    733bdd2096a1:	21 d9                	and    ecx,ebx
    733bdd2096a3:	31 ca                	xor    edx,ecx
    733bdd2096a5:	31 c9                	xor    ecx,ecx
    733bdd2096a7:	39 f9                	cmp    ecx,edi
    733bdd2096a9:	0f 96 c1             	setbe  cl
    733bdd2096ac:	80 e1 01             	and    cl,0x1
    733bdd2096af:	0f b6 c9             	movzx  ecx,cl
    733bdd2096b2:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd2096b8:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd2096be:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd2096c4:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd2096ca:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd2096d0:	eb 00                	jmp    0x733bdd2096d2
    733bdd2096d2:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd2096d6:	83 f8 00             	cmp    eax,0x0
    733bdd2096d9:	74 30                	je     0x733bdd20970b
    733bdd2096db:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd2096e2:	00 
    733bdd2096e3:	c7 81 bc 00 00 00 9c 	mov    DWORD PTR [rcx+0xbc],0x1019c
    733bdd2096ea:	01 01 00 
    733bdd2096ed:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd2096f3:	83 c0 05             	add    eax,0x5
    733bdd2096f6:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd2096fa:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd209700:	0f 82 04 01 00 00    	jb     0x733bdd20980a
    733bdd209706:	e9 22 01 00 00       	jmp    0x733bdd20982d
    733bdd20970b:	eb 00                	jmp    0x733bdd20970d
    733bdd20970d:	eb 00                	jmp    0x733bdd20970f
    733bdd20970f:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209716:	00 
    733bdd209717:	8b 8c 24 d0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd0]
    733bdd20971e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd209724:	81 c9 00 00 19 00    	or     ecx,0x190000
    733bdd20972a:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd20972e:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    733bdd209731:	eb 00                	jmp    0x733bdd209733
    733bdd209733:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20973a:	00 
    733bdd20973b:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd209742:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd209748:	81 c9 00 00 6e 3c    	or     ecx,0x3c6e0000
    733bdd20974e:	89 4c 24 3c          	mov    DWORD PTR [rsp+0x3c],ecx
    733bdd209752:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    733bdd209755:	eb 00                	jmp    0x733bdd209757
    733bdd209757:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd20975e:	00 
    733bdd20975f:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    733bdd209762:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    733bdd209766:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    733bdd209769:	eb 00                	jmp    0x733bdd20976b
    733bdd20976b:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209772:	00 
    733bdd209773:	8b 4c 24 38          	mov    ecx,DWORD PTR [rsp+0x38]
    733bdd209777:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd209779:	eb 00                	jmp    0x733bdd20977b
    733bdd20977b:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209782:	00 
    733bdd209783:	c7 40 18 00 00 00 00 	mov    DWORD PTR [rax+0x18],0x0
    733bdd20978a:	eb 00                	jmp    0x733bdd20978c
    733bdd20978c:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209793:	00 
    733bdd209794:	8b 4c 24 40          	mov    ecx,DWORD PTR [rsp+0x40]
    733bdd209798:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20979e:	81 c9 0d 66 00 00    	or     ecx,0x660d
    733bdd2097a4:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    733bdd2097a7:	eb 00                	jmp    0x733bdd2097a9
    733bdd2097a9:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2097b0:	00 
    733bdd2097b1:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd2097b5:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2097bb:	81 c9 5f f3 00 00    	or     ecx,0xf35f
    733bdd2097c1:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    733bdd2097c4:	eb 00                	jmp    0x733bdd2097c6
    733bdd2097c6:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd2097cd:	00 
    733bdd2097ce:	c7 81 bc 00 00 00 7c 	mov    DWORD PTR [rcx+0xbc],0x1017c
    733bdd2097d5:	01 01 00 
    733bdd2097d8:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd2097de:	83 c0 0d             	add    eax,0xd
    733bdd2097e1:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd2097e5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd2097eb:	0f 82 a6 00 00 00    	jb     0x733bdd209897
    733bdd2097f1:	e9 c4 00 00 00       	jmp    0x733bdd2098ba
    733bdd2097f6:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2097fd:	00 
    733bdd2097fe:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd209805:	e9 d7 01 00 00       	jmp    0x733bdd2099e1
    733bdd20980a:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd209811:	00 
    733bdd209812:	48 89 c1             	mov    rcx,rax
    733bdd209815:	48 81 c1 e0 0c 08 00 	add    rcx,0x80ce0
    733bdd20981c:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd209821:	81 b8 e0 0c 08 00 9c 	cmp    DWORD PTR [rax+0x80ce0],0x1019c
    733bdd209828:	01 01 00 
    733bdd20982b:	74 32                	je     0x733bdd20985f
    733bdd20982d:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209834:	00 
    733bdd209835:	c7 80 bc 00 00 00 9c 	mov    DWORD PTR [rax+0xbc],0x1019c
    733bdd20983c:	01 01 00 
    733bdd20983f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd209846:	00 00 00 
    733bdd209849:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd209850:	00 00 00 
    733bdd209853:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20985a:	e9 82 01 00 00       	jmp    0x733bdd2099e1
    733bdd20985f:	4c 8b b4 24 e0 00 00 	mov    r14,QWORD PTR [rsp+0xe0]
    733bdd209866:	00 
    733bdd209867:	4c 8b ac 24 e8 00 00 	mov    r13,QWORD PTR [rsp+0xe8]
    733bdd20986e:	00 
    733bdd20986f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd209874:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd209878:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019c
    733bdd20987f:	9c 01 01 00 
    733bdd209883:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20988a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20988e:	48 81 c4 08 01 00 00 	add    rsp,0x108
    733bdd209895:	ff e0                	jmp    rax
    733bdd209897:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd20989e:	00 
    733bdd20989f:	48 89 c1             	mov    rcx,rax
    733bdd2098a2:	48 81 c1 e0 0b 08 00 	add    rcx,0x80be0
    733bdd2098a9:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd2098ae:	81 b8 e0 0b 08 00 7c 	cmp    DWORD PTR [rax+0x80be0],0x1017c
    733bdd2098b5:	01 01 00 
    733bdd2098b8:	74 32                	je     0x733bdd2098ec
    733bdd2098ba:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2098c1:	00 
    733bdd2098c2:	c7 80 bc 00 00 00 7c 	mov    DWORD PTR [rax+0xbc],0x1017c
    733bdd2098c9:	01 01 00 
    733bdd2098cc:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2098d3:	00 00 00 
    733bdd2098d6:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    733bdd2098dd:	00 00 00 
    733bdd2098e0:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd2098e7:	e9 f5 00 00 00       	jmp    0x733bdd2099e1
    733bdd2098ec:	4c 8b b4 24 e0 00 00 	mov    r14,QWORD PTR [rsp+0xe0]
    733bdd2098f3:	00 
    733bdd2098f4:	4c 8b ac 24 e8 00 00 	mov    r13,QWORD PTR [rsp+0xe8]
    733bdd2098fb:	00 
    733bdd2098fc:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd209901:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    733bdd209905:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    733bdd20990c:	7c 01 01 00 
    733bdd209910:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd209917:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20991b:	48 81 c4 08 01 00 00 	add    rsp,0x108
    733bdd209922:	ff e0                	jmp    rax
    733bdd209924:	48 8b 8c 24 e8 00 00 	mov    rcx,QWORD PTR [rsp+0xe8]
    733bdd20992b:	00 
    733bdd20992c:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    733bdd209933:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    733bdd20993a:	8b b4 24 c8 00 00 00 	mov    esi,DWORD PTR [rsp+0xc8]
    733bdd209941:	89 c7                	mov    edi,eax
    733bdd209943:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd209947:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd20994b:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd20994f:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd209955:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd209959:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20995f:	73 2d                	jae    0x733bdd20998e
    733bdd209961:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd209968:	00 
    733bdd209969:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd20996d:	89 d1                	mov    ecx,edx
    733bdd20996f:	c1 e9 01             	shr    ecx,0x1
    733bdd209972:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd209978:	89 c9                	mov    ecx,ecx
    733bdd20997a:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20997e:	48 89 c6             	mov    rsi,rax
    733bdd209981:	48 01 ce             	add    rsi,rcx
    733bdd209984:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd209989:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20998c:	74 1e                	je     0x733bdd2099ac
    733bdd20998e:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd209995:	00 
    733bdd209996:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd20999a:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd20999e:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd2099a4:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd2099aa:	eb 35                	jmp    0x733bdd2099e1
    733bdd2099ac:	4c 8b b4 24 e0 00 00 	mov    r14,QWORD PTR [rsp+0xe0]
    733bdd2099b3:	00 
    733bdd2099b4:	4c 8b ac 24 e8 00 00 	mov    r13,QWORD PTR [rsp+0xe8]
    733bdd2099bb:	00 
    733bdd2099bc:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd2099c1:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd2099c5:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd2099cc:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd2099d3:	00 
    733bdd2099d4:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd2099d8:	48 81 c4 08 01 00 00 	add    rsp,0x108
    733bdd2099df:	ff e0                	jmp    rax
    733bdd2099e1:	48 81 c4 08 01 00 00 	add    rsp,0x108
    733bdd2099e8:	c2 08 00             	ret    0x8
