
build-native-instruction-analysis/capture/bcore-default-branch/pc-65692-0-126700950182736.bin:     file format binary


Disassembly of section .data:

0000733bdd20db50 <.data>:
    733bdd20db50:	48 81 ec 98 01 00 00 	sub    rsp,0x198
    733bdd20db57:	4c 89 b4 24 70 01 00 	mov    QWORD PTR [rsp+0x170],r14
    733bdd20db5e:	00 
    733bdd20db5f:	4c 89 ac 24 78 01 00 	mov    QWORD PTR [rsp+0x178],r13
    733bdd20db66:	00 
    733bdd20db67:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20db6e:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    733bdd20db75:	00 
    733bdd20db76:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd20db7d:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    733bdd20db84:	00 
    733bdd20db85:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20db8c:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    733bdd20db93:	00 
    733bdd20db94:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20db9b:	00 
    733bdd20db9c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20dba2:	83 fa 00             	cmp    edx,0x0
    733bdd20dba5:	0f 94 c0             	sete   al
    733bdd20dba8:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    733bdd20dbae:	83 fa 22             	cmp    edx,0x22
    733bdd20dbb1:	0f 97 c2             	seta   dl
    733bdd20dbb4:	08 d0                	or     al,dl
    733bdd20dbb6:	24 01                	and    al,0x1
    733bdd20dbb8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20dbbe:	83 fa 00             	cmp    edx,0x0
    733bdd20dbc1:	0f 94 c1             	sete   cl
    733bdd20dbc4:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    733bdd20dbca:	83 fa 22             	cmp    edx,0x22
    733bdd20dbcd:	0f 97 c2             	seta   dl
    733bdd20dbd0:	08 d1                	or     cl,dl
    733bdd20dbd2:	20 c8                	and    al,cl
    733bdd20dbd4:	a8 01                	test   al,0x1
    733bdd20dbd6:	75 05                	jne    0x733bdd20dbdd
    733bdd20dbd8:	e9 0a 1c 00 00       	jmp    0x733bdd20f7e7
    733bdd20dbdd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dbe4:	00 
    733bdd20dbe5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20dbec:	48 89 c8             	mov    rax,rcx
    733bdd20dbef:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20dbf5:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    733bdd20dbfc:	00 
    733bdd20dbfd:	8b 81 3c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10003c]
    733bdd20dc03:	83 c0 01             	add    eax,0x1
    733bdd20dc06:	89 81 3c 00 10 00    	mov    DWORD PTR [rcx+0x10003c],eax
    733bdd20dc0c:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20dc11:	75 4c                	jne    0x733bdd20dc5f
    733bdd20dc13:	48 8b 8c 24 68 01 00 	mov    rcx,QWORD PTR [rsp+0x168]
    733bdd20dc1a:	00 
    733bdd20dc1b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20dc21:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    733bdd20dc28:	89 c2                	mov    edx,eax
    733bdd20dc2a:	83 c2 01             	add    edx,0x1
    733bdd20dc2d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20dc33:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20dc38:	73 23                	jae    0x733bdd20dc5d
    733bdd20dc3a:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    733bdd20dc41:	00 
    733bdd20dc42:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd20dc49:	89 c9                	mov    ecx,ecx
    733bdd20dc4b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20dc4f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20dc56:	c7 04 08 0f 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xf
    733bdd20dc5d:	eb 00                	jmp    0x733bdd20dc5f
    733bdd20dc5f:	eb 00                	jmp    0x733bdd20dc61
    733bdd20dc61:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20dc68:	00 
    733bdd20dc69:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    733bdd20dc6c:	89 84 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],eax
    733bdd20dc73:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    733bdd20dc76:	89 8c 24 60 01 00 00 	mov    DWORD PTR [rsp+0x160],ecx
    733bdd20dc7d:	83 e0 03             	and    eax,0x3
    733bdd20dc80:	83 f8 00             	cmp    eax,0x0
    733bdd20dc83:	0f 84 8e 00 00 00    	je     0x733bdd20dd17
    733bdd20dc89:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20dc90:	00 
    733bdd20dc91:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    733bdd20dc98:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20dc9f:	00 
    733bdd20dca0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20dca7:	00 00 00 
    733bdd20dcaa:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd20dcb1:	00 00 00 
    733bdd20dcb4:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20dcbb:	59 00 00 
    733bdd20dcbe:	ba 9c 00 01 00       	mov    edx,0x1009c
    733bdd20dcc3:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20dcc9:	ff d0                	call   rax
    733bdd20dccb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dcd2:	00 
    733bdd20dcd3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20dcd9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20dcdf:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20dce5:	be 01 00 00 00       	mov    esi,0x1
    733bdd20dcea:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20dcef:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20dcf6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20dcfd:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20dd04:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20dd0b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20dd12:	e9 74 1b 00 00       	jmp    0x733bdd20f88b
    733bdd20dd17:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20dd1e:	00 
    733bdd20dd1f:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    733bdd20dd26:	c1 e9 0c             	shr    ecx,0xc
    733bdd20dd29:	89 c9                	mov    ecx,ecx
    733bdd20dd2b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20dd2f:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
    733bdd20dd36:	00 
    733bdd20dd37:	48 83 f8 00          	cmp    rax,0x0
    733bdd20dd3b:	74 23                	je     0x733bdd20dd60
    733bdd20dd3d:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    733bdd20dd44:	00 
    733bdd20dd45:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    733bdd20dd4c:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    733bdd20dd53:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20dd59:	89 c9                	mov    ecx,ecx
    733bdd20dd5b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20dd5e:	eb 51                	jmp    0x733bdd20ddb1
    733bdd20dd60:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dd67:	00 
    733bdd20dd68:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    733bdd20dd6f:	8b b4 24 5c 01 00 00 	mov    esi,DWORD PTR [rsp+0x15c]
    733bdd20dd76:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20dd7d:	00 
    733bdd20dd7e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20dd85:	00 00 00 
    733bdd20dd88:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd20dd8f:	00 00 00 
    733bdd20dd92:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20dd99:	59 00 00 
    733bdd20dd9c:	ff d0                	call   rax
    733bdd20dd9e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dda5:	00 
    733bdd20dda6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20ddad:	75 14                	jne    0x733bdd20ddc3
    733bdd20ddaf:	eb 5e                	jmp    0x733bdd20de0f
    733bdd20ddb1:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    733bdd20ddb8:	00 
    733bdd20ddb9:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20ddbc:	75 53                	jne    0x733bdd20de11
    733bdd20ddbe:	e9 93 00 00 00       	jmp    0x733bdd20de56
    733bdd20ddc3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ddca:	00 
    733bdd20ddcb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ddd1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ddd7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20dddd:	be 01 00 00 00       	mov    esi,0x1
    733bdd20dde2:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20dde7:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20ddee:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20ddf5:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20ddfc:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20de03:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20de0a:	e9 7c 1a 00 00       	jmp    0x733bdd20f88b
    733bdd20de0f:	eb a0                	jmp    0x733bdd20ddb1
    733bdd20de11:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20de18:	00 
    733bdd20de19:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    733bdd20de20:	00 01 00 
    733bdd20de23:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20de2a:	00 00 00 
    733bdd20de2d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd20de34:	00 00 00 
    733bdd20de37:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20de3e:	59 00 00 
    733bdd20de41:	ff d0                	call   rax
    733bdd20de43:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20de4a:	00 
    733bdd20de4b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20de52:	75 04                	jne    0x733bdd20de58
    733bdd20de54:	eb 4e                	jmp    0x733bdd20dea4
    733bdd20de56:	eb 4e                	jmp    0x733bdd20dea6
    733bdd20de58:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20de5f:	00 
    733bdd20de60:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20de66:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20de6c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20de72:	be 01 00 00 00       	mov    esi,0x1
    733bdd20de77:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20de7c:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20de83:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20de8a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20de91:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20de98:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20de9f:	e9 e7 19 00 00       	jmp    0x733bdd20f88b
    733bdd20dea4:	eb b0                	jmp    0x733bdd20de56
    733bdd20dea6:	eb 00                	jmp    0x733bdd20dea8
    733bdd20dea8:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20deaf:	00 
    733bdd20deb0:	8b 41 34             	mov    eax,DWORD PTR [rcx+0x34]
    733bdd20deb3:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    733bdd20deba:	8b 09                	mov    ecx,DWORD PTR [rcx]
    733bdd20debc:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    733bdd20dec3:	83 e0 03             	and    eax,0x3
    733bdd20dec6:	83 f8 00             	cmp    eax,0x0
    733bdd20dec9:	0f 84 95 00 00 00    	je     0x733bdd20df64
    733bdd20decf:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20ded6:	00 
    733bdd20ded7:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    733bdd20dede:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20dee5:	00 
    733bdd20dee6:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    733bdd20deed:	00 01 00 
    733bdd20def0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20def7:	00 00 00 
    733bdd20defa:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd20df01:	00 00 00 
    733bdd20df04:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20df0b:	59 00 00 
    733bdd20df0e:	ba 9e 00 01 00       	mov    edx,0x1009e
    733bdd20df13:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20df19:	ff d0                	call   rax
    733bdd20df1b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20df22:	00 
    733bdd20df23:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    733bdd20df29:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20df2f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20df35:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20df3a:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    733bdd20df41:	89 ce                	mov    esi,ecx
    733bdd20df43:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20df4a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20df51:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20df58:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20df5f:	e9 27 19 00 00       	jmp    0x733bdd20f88b
    733bdd20df64:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20df6b:	00 
    733bdd20df6c:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    733bdd20df73:	c1 e9 0c             	shr    ecx,0xc
    733bdd20df76:	89 c9                	mov    ecx,ecx
    733bdd20df78:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20df7c:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    733bdd20df83:	00 
    733bdd20df84:	48 83 f8 00          	cmp    rax,0x0
    733bdd20df88:	74 23                	je     0x733bdd20dfad
    733bdd20df8a:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    733bdd20df91:	00 
    733bdd20df92:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    733bdd20df99:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    733bdd20dfa0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20dfa6:	89 c9                	mov    ecx,ecx
    733bdd20dfa8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20dfab:	eb 5b                	jmp    0x733bdd20e008
    733bdd20dfad:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dfb4:	00 
    733bdd20dfb5:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    733bdd20dfbc:	8b b4 24 38 01 00 00 	mov    esi,DWORD PTR [rsp+0x138]
    733bdd20dfc3:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20dfca:	00 
    733bdd20dfcb:	c7 80 bc 00 00 00 9e 	mov    DWORD PTR [rax+0xbc],0x1009e
    733bdd20dfd2:	00 01 00 
    733bdd20dfd5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20dfdc:	00 00 00 
    733bdd20dfdf:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd20dfe6:	00 00 00 
    733bdd20dfe9:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20dff0:	59 00 00 
    733bdd20dff3:	ff d0                	call   rax
    733bdd20dff5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20dffc:	00 
    733bdd20dffd:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e004:	75 29                	jne    0x733bdd20e02f
    733bdd20e006:	eb 70                	jmp    0x733bdd20e078
    733bdd20e008:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    733bdd20e00f:	00 
    733bdd20e010:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20e017:	00 
    733bdd20e018:	8b 94 24 38 01 00 00 	mov    edx,DWORD PTR [rsp+0x138]
    733bdd20e01f:	83 c2 04             	add    edx,0x4
    733bdd20e022:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    733bdd20e025:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20e028:	75 50                	jne    0x733bdd20e07a
    733bdd20e02a:	e9 90 00 00 00       	jmp    0x733bdd20e0bf
    733bdd20e02f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e036:	00 
    733bdd20e037:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    733bdd20e03d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e043:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e049:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e04e:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    733bdd20e055:	89 ce                	mov    esi,ecx
    733bdd20e057:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e05e:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e065:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e06c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e073:	e9 13 18 00 00       	jmp    0x733bdd20f88b
    733bdd20e078:	eb 8e                	jmp    0x733bdd20e008
    733bdd20e07a:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e081:	00 
    733bdd20e082:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x100a0
    733bdd20e089:	00 01 00 
    733bdd20e08c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20e093:	00 00 00 
    733bdd20e096:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd20e09d:	00 00 00 
    733bdd20e0a0:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20e0a7:	59 00 00 
    733bdd20e0aa:	ff d0                	call   rax
    733bdd20e0ac:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e0b3:	00 
    733bdd20e0b4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e0bb:	75 04                	jne    0x733bdd20e0c1
    733bdd20e0bd:	eb 4b                	jmp    0x733bdd20e10a
    733bdd20e0bf:	eb 4b                	jmp    0x733bdd20e10c
    733bdd20e0c1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e0c8:	00 
    733bdd20e0c9:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    733bdd20e0cf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e0d5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e0db:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e0e0:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    733bdd20e0e7:	89 ce                	mov    esi,ecx
    733bdd20e0e9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e0f0:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e0f7:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e0fe:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e105:	e9 81 17 00 00       	jmp    0x733bdd20f88b
    733bdd20e10a:	eb b3                	jmp    0x733bdd20e0bf
    733bdd20e10c:	eb 00                	jmp    0x733bdd20e10e
    733bdd20e10e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e115:	00 
    733bdd20e116:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    733bdd20e119:	89 ca                	mov    edx,ecx
    733bdd20e11b:	83 c2 01             	add    edx,0x1
    733bdd20e11e:	89 94 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],edx
    733bdd20e125:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    733bdd20e128:	89 ce                	mov    esi,ecx
    733bdd20e12a:	c1 ee 1f             	shr    esi,0x1f
    733bdd20e12d:	89 d3                	mov    ebx,edx
    733bdd20e12f:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20e132:	89 df                	mov    edi,ebx
    733bdd20e134:	83 f7 00             	xor    edi,0x0
    733bdd20e137:	31 de                	xor    esi,ebx
    733bdd20e139:	21 fe                	and    esi,edi
    733bdd20e13b:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd20e13e:	83 f9 01             	cmp    ecx,0x1
    733bdd20e141:	0f 92 c1             	setb   cl
    733bdd20e144:	80 e1 01             	and    cl,0x1
    733bdd20e147:	0f b6 c9             	movzx  ecx,cl
    733bdd20e14a:	83 fa 00             	cmp    edx,0x0
    733bdd20e14d:	0f 94 c3             	sete   bl
    733bdd20e150:	80 e3 01             	and    bl,0x1
    733bdd20e153:	0f b6 fb             	movzx  edi,bl
    733bdd20e156:	c1 ea 1f             	shr    edx,0x1f
    733bdd20e159:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd20e15f:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20e165:	89 f2                	mov    edx,esi
    733bdd20e167:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd20e16d:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd20e173:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd20e179:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd20e17f:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20e185:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20e18b:	eb 00                	jmp    0x733bdd20e18d
    733bdd20e18d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e194:	00 
    733bdd20e195:	c7 00 06 00 00 00    	mov    DWORD PTR [rax],0x6
    733bdd20e19b:	eb 00                	jmp    0x733bdd20e19d
    733bdd20e19d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e1a4:	00 
    733bdd20e1a5:	8b 40 2c             	mov    eax,DWORD PTR [rax+0x2c]
    733bdd20e1a8:	89 84 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],eax
    733bdd20e1af:	83 e0 03             	and    eax,0x3
    733bdd20e1b2:	83 f8 00             	cmp    eax,0x0
    733bdd20e1b5:	0f 84 98 00 00 00    	je     0x733bdd20e253
    733bdd20e1bb:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e1c2:	00 
    733bdd20e1c3:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    733bdd20e1ca:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20e1d1:	00 
    733bdd20e1d2:	c7 87 bc 00 00 00 a4 	mov    DWORD PTR [rdi+0xbc],0x100a4
    733bdd20e1d9:	00 01 00 
    733bdd20e1dc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20e1e3:	00 00 00 
    733bdd20e1e6:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20e1ed:	00 00 00 
    733bdd20e1f0:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20e1f7:	59 00 00 
    733bdd20e1fa:	ba a4 00 01 00       	mov    edx,0x100a4
    733bdd20e1ff:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20e205:	ff d0                	call   rax
    733bdd20e207:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e20e:	00 
    733bdd20e20f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e215:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e21b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e221:	be 05 00 00 00       	mov    esi,0x5
    733bdd20e226:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e22b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e232:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e239:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e240:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e247:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e24e:	e9 38 16 00 00       	jmp    0x733bdd20f88b
    733bdd20e253:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20e25a:	00 
    733bdd20e25b:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    733bdd20e262:	c1 e9 0c             	shr    ecx,0xc
    733bdd20e265:	89 c9                	mov    ecx,ecx
    733bdd20e267:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20e26b:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    733bdd20e272:	00 
    733bdd20e273:	48 83 f8 00          	cmp    rax,0x0
    733bdd20e277:	74 23                	je     0x733bdd20e29c
    733bdd20e279:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd20e280:	00 
    733bdd20e281:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    733bdd20e288:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    733bdd20e28f:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20e295:	89 c9                	mov    ecx,ecx
    733bdd20e297:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20e29a:	eb 5b                	jmp    0x733bdd20e2f7
    733bdd20e29c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e2a3:	00 
    733bdd20e2a4:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    733bdd20e2ab:	8b b4 24 28 01 00 00 	mov    esi,DWORD PTR [rsp+0x128]
    733bdd20e2b2:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20e2b9:	00 
    733bdd20e2ba:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x100a4
    733bdd20e2c1:	00 01 00 
    733bdd20e2c4:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20e2cb:	00 00 00 
    733bdd20e2ce:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd20e2d5:	00 00 00 
    733bdd20e2d8:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20e2df:	59 00 00 
    733bdd20e2e2:	ff d0                	call   rax
    733bdd20e2e4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e2eb:	00 
    733bdd20e2ec:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e2f3:	75 14                	jne    0x733bdd20e309
    733bdd20e2f5:	eb 5e                	jmp    0x733bdd20e355
    733bdd20e2f7:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    733bdd20e2fe:	00 
    733bdd20e2ff:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20e302:	75 53                	jne    0x733bdd20e357
    733bdd20e304:	e9 93 00 00 00       	jmp    0x733bdd20e39c
    733bdd20e309:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e310:	00 
    733bdd20e311:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e317:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e31d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e323:	be 05 00 00 00       	mov    esi,0x5
    733bdd20e328:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e32d:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e334:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e33b:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e342:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e349:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e350:	e9 36 15 00 00       	jmp    0x733bdd20f88b
    733bdd20e355:	eb a0                	jmp    0x733bdd20e2f7
    733bdd20e357:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e35e:	00 
    733bdd20e35f:	c7 87 bc 00 00 00 a6 	mov    DWORD PTR [rdi+0xbc],0x100a6
    733bdd20e366:	00 01 00 
    733bdd20e369:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20e370:	00 00 00 
    733bdd20e373:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20e37a:	00 00 00 
    733bdd20e37d:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20e384:	59 00 00 
    733bdd20e387:	ff d0                	call   rax
    733bdd20e389:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e390:	00 
    733bdd20e391:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e398:	75 04                	jne    0x733bdd20e39e
    733bdd20e39a:	eb 4e                	jmp    0x733bdd20e3ea
    733bdd20e39c:	eb 4e                	jmp    0x733bdd20e3ec
    733bdd20e39e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e3a5:	00 
    733bdd20e3a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e3ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e3b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e3b8:	be 05 00 00 00       	mov    esi,0x5
    733bdd20e3bd:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e3c2:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e3c9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e3d0:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e3d7:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e3de:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e3e5:	e9 a1 14 00 00       	jmp    0x733bdd20f88b
    733bdd20e3ea:	eb b0                	jmp    0x733bdd20e39c
    733bdd20e3ec:	eb 00                	jmp    0x733bdd20e3ee
    733bdd20e3ee:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e3f5:	00 
    733bdd20e3f6:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    733bdd20e3fd:	89 fa                	mov    edx,edi
    733bdd20e3ff:	83 ea 06             	sub    edx,0x6
    733bdd20e402:	83 fa 00             	cmp    edx,0x0
    733bdd20e405:	0f 94 c1             	sete   cl
    733bdd20e408:	80 e1 01             	and    cl,0x1
    733bdd20e40b:	0f b6 f1             	movzx  esi,cl
    733bdd20e40e:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    733bdd20e415:	c1 ea 1f             	shr    edx,0x1f
    733bdd20e418:	89 f9                	mov    ecx,edi
    733bdd20e41a:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20e41d:	89 d3                	mov    ebx,edx
    733bdd20e41f:	31 cb                	xor    ebx,ecx
    733bdd20e421:	83 f1 00             	xor    ecx,0x0
    733bdd20e424:	21 d9                	and    ecx,ebx
    733bdd20e426:	31 ca                	xor    edx,ecx
    733bdd20e428:	b9 06 00 00 00       	mov    ecx,0x6
    733bdd20e42d:	39 f9                	cmp    ecx,edi
    733bdd20e42f:	0f 96 c1             	setbe  cl
    733bdd20e432:	80 e1 01             	and    cl,0x1
    733bdd20e435:	0f b6 c9             	movzx  ecx,cl
    733bdd20e438:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd20e43e:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd20e444:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20e44a:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20e450:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20e456:	eb 00                	jmp    0x733bdd20e458
    733bdd20e458:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    733bdd20e45f:	83 f8 00             	cmp    eax,0x0
    733bdd20e462:	75 33                	jne    0x733bdd20e497
    733bdd20e464:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20e46b:	00 
    733bdd20e46c:	c7 81 bc 00 00 00 84 	mov    DWORD PTR [rcx+0xbc],0x10084
    733bdd20e473:	00 01 00 
    733bdd20e476:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20e47c:	83 c0 07             	add    eax,0x7
    733bdd20e47f:	89 84 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],eax
    733bdd20e486:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20e48c:	0f 82 69 13 00 00    	jb     0x733bdd20f7fb
    733bdd20e492:	e9 87 13 00 00       	jmp    0x733bdd20f81e
    733bdd20e497:	eb 00                	jmp    0x733bdd20e499
    733bdd20e499:	eb 00                	jmp    0x733bdd20e49b
    733bdd20e49b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e4a2:	00 
    733bdd20e4a3:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    733bdd20e4a6:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20e4ac:	83 c9 00             	or     ecx,0x0
    733bdd20e4af:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    733bdd20e4b6:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20e4b9:	eb 00                	jmp    0x733bdd20e4bb
    733bdd20e4bb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e4c2:	00 
    733bdd20e4c3:	c7 00 02 00 00 00    	mov    DWORD PTR [rax],0x2
    733bdd20e4c9:	eb 00                	jmp    0x733bdd20e4cb
    733bdd20e4cb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e4d2:	00 
    733bdd20e4d3:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    733bdd20e4da:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20e4e0:	81 c9 10 f0 00 00    	or     ecx,0xf010
    733bdd20e4e6:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    733bdd20e4ed:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20e4f0:	eb 00                	jmp    0x733bdd20e4f2
    733bdd20e4f2:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    733bdd20e4f9:	83 e0 03             	and    eax,0x3
    733bdd20e4fc:	83 f8 00             	cmp    eax,0x0
    733bdd20e4ff:	0f 84 98 00 00 00    	je     0x733bdd20e59d
    733bdd20e505:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e50c:	00 
    733bdd20e50d:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd20e514:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20e51b:	00 
    733bdd20e51c:	c7 87 bc 00 00 00 b4 	mov    DWORD PTR [rdi+0xbc],0x100b4
    733bdd20e523:	00 01 00 
    733bdd20e526:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20e52d:	00 00 00 
    733bdd20e530:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    733bdd20e537:	00 00 00 
    733bdd20e53a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20e541:	59 00 00 
    733bdd20e544:	ba b4 00 01 00       	mov    edx,0x100b4
    733bdd20e549:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20e54f:	ff d0                	call   rax
    733bdd20e551:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e558:	00 
    733bdd20e559:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e55f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e565:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e56b:	be 0b 00 00 00       	mov    esi,0xb
    733bdd20e570:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e575:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e57c:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e583:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e58a:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e591:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e598:	e9 ee 12 00 00       	jmp    0x733bdd20f88b
    733bdd20e59d:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20e5a4:	00 
    733bdd20e5a5:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd20e5ac:	c1 e9 0c             	shr    ecx,0xc
    733bdd20e5af:	89 c9                	mov    ecx,ecx
    733bdd20e5b1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20e5b5:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    733bdd20e5bc:	00 
    733bdd20e5bd:	48 83 f8 00          	cmp    rax,0x0
    733bdd20e5c1:	74 20                	je     0x733bdd20e5e3
    733bdd20e5c3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20e5ca:	00 
    733bdd20e5cb:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd20e5d2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20e5d8:	89 c9                	mov    ecx,ecx
    733bdd20e5da:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    733bdd20e5e1:	eb 59                	jmp    0x733bdd20e63c
    733bdd20e5e3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e5ea:	00 
    733bdd20e5eb:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    733bdd20e5f2:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20e5f9:	00 
    733bdd20e5fa:	c7 80 bc 00 00 00 b4 	mov    DWORD PTR [rax+0xbc],0x100b4
    733bdd20e601:	00 01 00 
    733bdd20e604:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20e60b:	00 00 00 
    733bdd20e60e:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    733bdd20e615:	00 00 00 
    733bdd20e618:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20e61f:	59 00 00 
    733bdd20e622:	ba 02 00 00 00       	mov    edx,0x2
    733bdd20e627:	ff d0                	call   rax
    733bdd20e629:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e630:	00 
    733bdd20e631:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e638:	75 14                	jne    0x733bdd20e64e
    733bdd20e63a:	eb 5e                	jmp    0x733bdd20e69a
    733bdd20e63c:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    733bdd20e643:	00 
    733bdd20e644:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20e647:	75 53                	jne    0x733bdd20e69c
    733bdd20e649:	e9 93 00 00 00       	jmp    0x733bdd20e6e1
    733bdd20e64e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e655:	00 
    733bdd20e656:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e65c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e662:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e668:	be 0b 00 00 00       	mov    esi,0xb
    733bdd20e66d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e672:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e679:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e680:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e687:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e68e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e695:	e9 f1 11 00 00       	jmp    0x733bdd20f88b
    733bdd20e69a:	eb a0                	jmp    0x733bdd20e63c
    733bdd20e69c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e6a3:	00 
    733bdd20e6a4:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    733bdd20e6ab:	00 01 00 
    733bdd20e6ae:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20e6b5:	00 00 00 
    733bdd20e6b8:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    733bdd20e6bf:	00 00 00 
    733bdd20e6c2:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20e6c9:	59 00 00 
    733bdd20e6cc:	ff d0                	call   rax
    733bdd20e6ce:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e6d5:	00 
    733bdd20e6d6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e6dd:	75 04                	jne    0x733bdd20e6e3
    733bdd20e6df:	eb 4e                	jmp    0x733bdd20e72f
    733bdd20e6e1:	eb 4e                	jmp    0x733bdd20e731
    733bdd20e6e3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e6ea:	00 
    733bdd20e6eb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e6f1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e6f7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e6fd:	be 0b 00 00 00       	mov    esi,0xb
    733bdd20e702:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20e707:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e70e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e715:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e71c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e723:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e72a:	e9 5c 11 00 00       	jmp    0x733bdd20f88b
    733bdd20e72f:	eb b0                	jmp    0x733bdd20e6e1
    733bdd20e731:	eb 00                	jmp    0x733bdd20e733
    733bdd20e733:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e73a:	00 
    733bdd20e73b:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    733bdd20e73e:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    733bdd20e745:	83 e0 03             	and    eax,0x3
    733bdd20e748:	83 f8 00             	cmp    eax,0x0
    733bdd20e74b:	0f 84 97 00 00 00    	je     0x733bdd20e7e8
    733bdd20e751:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e758:	00 
    733bdd20e759:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    733bdd20e760:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20e767:	00 
    733bdd20e768:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    733bdd20e76f:	00 01 00 
    733bdd20e772:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20e779:	00 00 00 
    733bdd20e77c:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    733bdd20e783:	00 00 00 
    733bdd20e786:	31 c0                	xor    eax,eax
    733bdd20e788:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20e78f:	59 00 00 
    733bdd20e792:	ba b6 00 01 00       	mov    edx,0x100b6
    733bdd20e797:	45 31 c0             	xor    r8d,r8d
    733bdd20e79a:	ff d0                	call   rax
    733bdd20e79c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e7a3:	00 
    733bdd20e7a4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e7aa:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e7b0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e7b6:	be 0c 00 00 00       	mov    esi,0xc
    733bdd20e7bb:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20e7c0:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e7c7:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e7ce:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e7d5:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e7dc:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e7e3:	e9 a3 10 00 00       	jmp    0x733bdd20f88b
    733bdd20e7e8:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20e7ef:	00 
    733bdd20e7f0:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    733bdd20e7f7:	c1 e9 0c             	shr    ecx,0xc
    733bdd20e7fa:	89 c9                	mov    ecx,ecx
    733bdd20e7fc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20e800:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    733bdd20e807:	00 
    733bdd20e808:	48 83 f8 00          	cmp    rax,0x0
    733bdd20e80c:	74 23                	je     0x733bdd20e831
    733bdd20e80e:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    733bdd20e815:	00 
    733bdd20e816:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    733bdd20e81d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20e823:	89 c9                	mov    ecx,ecx
    733bdd20e825:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20e828:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    733bdd20e82f:	eb 5d                	jmp    0x733bdd20e88e
    733bdd20e831:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e838:	00 
    733bdd20e839:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    733bdd20e840:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20e847:	00 
    733bdd20e848:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    733bdd20e84f:	00 01 00 
    733bdd20e852:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20e859:	00 00 00 
    733bdd20e85c:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    733bdd20e863:	00 00 00 
    733bdd20e866:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20e86d:	59 00 00 
    733bdd20e870:	ff d0                	call   rax
    733bdd20e872:	89 c1                	mov    ecx,eax
    733bdd20e874:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e87b:	00 
    733bdd20e87c:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    733bdd20e883:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20e88a:	75 2e                	jne    0x733bdd20e8ba
    733bdd20e88c:	eb 78                	jmp    0x733bdd20e906
    733bdd20e88e:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    733bdd20e895:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    733bdd20e89c:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    733bdd20e8a3:	83 c0 04             	add    eax,0x4
    733bdd20e8a6:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    733bdd20e8ad:	83 e0 03             	and    eax,0x3
    733bdd20e8b0:	83 f8 00             	cmp    eax,0x0
    733bdd20e8b3:	75 64                	jne    0x733bdd20e919
    733bdd20e8b5:	e9 f6 00 00 00       	jmp    0x733bdd20e9b0
    733bdd20e8ba:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e8c1:	00 
    733bdd20e8c2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e8c8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e8ce:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e8d4:	be 0c 00 00 00       	mov    esi,0xc
    733bdd20e8d9:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20e8de:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e8e5:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e8ec:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e8f3:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e8fa:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e901:	e9 85 0f 00 00       	jmp    0x733bdd20f88b
    733bdd20e906:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    733bdd20e90d:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    733bdd20e914:	e9 75 ff ff ff       	jmp    0x733bdd20e88e
    733bdd20e919:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20e920:	00 
    733bdd20e921:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd20e928:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20e92f:	00 
    733bdd20e930:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    733bdd20e937:	00 01 00 
    733bdd20e93a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20e941:	00 00 00 
    733bdd20e944:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    733bdd20e94b:	00 00 00 
    733bdd20e94e:	31 c0                	xor    eax,eax
    733bdd20e950:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20e957:	59 00 00 
    733bdd20e95a:	ba b6 00 01 00       	mov    edx,0x100b6
    733bdd20e95f:	45 31 c0             	xor    r8d,r8d
    733bdd20e962:	ff d0                	call   rax
    733bdd20e964:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20e96b:	00 
    733bdd20e96c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20e972:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20e978:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20e97e:	be 0c 00 00 00       	mov    esi,0xc
    733bdd20e983:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20e988:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20e98f:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20e996:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20e99d:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20e9a4:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20e9ab:	e9 db 0e 00 00       	jmp    0x733bdd20f88b
    733bdd20e9b0:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20e9b7:	00 
    733bdd20e9b8:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd20e9bf:	c1 e9 0c             	shr    ecx,0xc
    733bdd20e9c2:	89 c9                	mov    ecx,ecx
    733bdd20e9c4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20e9c8:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    733bdd20e9cf:	00 
    733bdd20e9d0:	48 83 f8 00          	cmp    rax,0x0
    733bdd20e9d4:	74 23                	je     0x733bdd20e9f9
    733bdd20e9d6:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    733bdd20e9dd:	00 
    733bdd20e9de:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd20e9e5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20e9eb:	89 c9                	mov    ecx,ecx
    733bdd20e9ed:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20e9f0:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd20e9f7:	eb 60                	jmp    0x733bdd20ea59
    733bdd20e9f9:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ea00:	00 
    733bdd20ea01:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    733bdd20ea08:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20ea0f:	00 
    733bdd20ea10:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    733bdd20ea17:	00 01 00 
    733bdd20ea1a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20ea21:	00 00 00 
    733bdd20ea24:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    733bdd20ea2b:	00 00 00 
    733bdd20ea2e:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20ea35:	59 00 00 
    733bdd20ea38:	ff d0                	call   rax
    733bdd20ea3a:	89 c1                	mov    ecx,eax
    733bdd20ea3c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ea43:	00 
    733bdd20ea44:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    733bdd20ea4b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20ea52:	75 41                	jne    0x733bdd20ea95
    733bdd20ea54:	e9 88 00 00 00       	jmp    0x733bdd20eae1
    733bdd20ea59:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ea60:	00 
    733bdd20ea61:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    733bdd20ea68:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd20ea6f:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    733bdd20ea76:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20ea7d:	83 c1 04             	add    ecx,0x4
    733bdd20ea80:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20ea87:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd20ea8a:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd20ea90:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20ea93:	eb 5f                	jmp    0x733bdd20eaf4
    733bdd20ea95:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ea9c:	00 
    733bdd20ea9d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20eaa3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20eaa9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20eaaf:	be 0c 00 00 00       	mov    esi,0xc
    733bdd20eab4:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20eab9:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20eac0:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20eac7:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20eace:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20ead5:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20eadc:	e9 aa 0d 00 00       	jmp    0x733bdd20f88b
    733bdd20eae1:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    733bdd20eae8:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd20eaef:	e9 65 ff ff ff       	jmp    0x733bdd20ea59
    733bdd20eaf4:	eb 00                	jmp    0x733bdd20eaf6
    733bdd20eaf6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20eafd:	00 
    733bdd20eafe:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    733bdd20eb04:	eb 00                	jmp    0x733bdd20eb06
    733bdd20eb06:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    733bdd20eb0d:	83 e0 03             	and    eax,0x3
    733bdd20eb10:	83 f8 00             	cmp    eax,0x0
    733bdd20eb13:	0f 84 97 00 00 00    	je     0x733bdd20ebb0
    733bdd20eb19:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20eb20:	00 
    733bdd20eb21:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd20eb28:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20eb2f:	00 
    733bdd20eb30:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20eb37:	00 01 00 
    733bdd20eb3a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20eb41:	00 00 00 
    733bdd20eb44:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20eb4b:	00 00 00 
    733bdd20eb4e:	31 c0                	xor    eax,eax
    733bdd20eb50:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20eb57:	59 00 00 
    733bdd20eb5a:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20eb5f:	45 31 c0             	xor    r8d,r8d
    733bdd20eb62:	ff d0                	call   rax
    733bdd20eb64:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20eb6b:	00 
    733bdd20eb6c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20eb72:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20eb78:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20eb7e:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20eb83:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20eb88:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20eb8f:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20eb96:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20eb9d:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20eba4:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20ebab:	e9 db 0c 00 00       	jmp    0x733bdd20f88b
    733bdd20ebb0:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20ebb7:	00 
    733bdd20ebb8:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd20ebbf:	c1 e9 0c             	shr    ecx,0xc
    733bdd20ebc2:	89 c9                	mov    ecx,ecx
    733bdd20ebc4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20ebc8:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    733bdd20ebcf:	00 
    733bdd20ebd0:	48 83 f8 00          	cmp    rax,0x0
    733bdd20ebd4:	74 23                	je     0x733bdd20ebf9
    733bdd20ebd6:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    733bdd20ebdd:	00 
    733bdd20ebde:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd20ebe5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20ebeb:	89 c9                	mov    ecx,ecx
    733bdd20ebed:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20ebf0:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    733bdd20ebf7:	eb 5d                	jmp    0x733bdd20ec56
    733bdd20ebf9:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ec00:	00 
    733bdd20ec01:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    733bdd20ec08:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20ec0f:	00 
    733bdd20ec10:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20ec17:	00 01 00 
    733bdd20ec1a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20ec21:	00 00 00 
    733bdd20ec24:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20ec2b:	00 00 00 
    733bdd20ec2e:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20ec35:	59 00 00 
    733bdd20ec38:	ff d0                	call   rax
    733bdd20ec3a:	89 c1                	mov    ecx,eax
    733bdd20ec3c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ec43:	00 
    733bdd20ec44:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    733bdd20ec4b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20ec52:	75 32                	jne    0x733bdd20ec86
    733bdd20ec54:	eb 7c                	jmp    0x733bdd20ecd2
    733bdd20ec56:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    733bdd20ec5d:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20ec64:	00 
    733bdd20ec65:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    733bdd20ec6c:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    733bdd20ec6f:	83 c0 04             	add    eax,0x4
    733bdd20ec72:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd20ec79:	83 e0 03             	and    eax,0x3
    733bdd20ec7c:	83 f8 00             	cmp    eax,0x0
    733bdd20ec7f:	75 64                	jne    0x733bdd20ece5
    733bdd20ec81:	e9 f6 00 00 00       	jmp    0x733bdd20ed7c
    733bdd20ec86:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ec8d:	00 
    733bdd20ec8e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ec94:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ec9a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20eca0:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20eca5:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20ecaa:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20ecb1:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20ecb8:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20ecbf:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20ecc6:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20eccd:	e9 b9 0b 00 00       	jmp    0x733bdd20f88b
    733bdd20ecd2:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    733bdd20ecd9:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    733bdd20ece0:	e9 71 ff ff ff       	jmp    0x733bdd20ec56
    733bdd20ece5:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20ecec:	00 
    733bdd20eced:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd20ecf4:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20ecfb:	00 
    733bdd20ecfc:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20ed03:	00 01 00 
    733bdd20ed06:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20ed0d:	00 00 00 
    733bdd20ed10:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20ed17:	00 00 00 
    733bdd20ed1a:	31 c0                	xor    eax,eax
    733bdd20ed1c:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20ed23:	59 00 00 
    733bdd20ed26:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20ed2b:	45 31 c0             	xor    r8d,r8d
    733bdd20ed2e:	ff d0                	call   rax
    733bdd20ed30:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ed37:	00 
    733bdd20ed38:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ed3e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ed44:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20ed4a:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20ed4f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20ed54:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20ed5b:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20ed62:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20ed69:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20ed70:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20ed77:	e9 0f 0b 00 00       	jmp    0x733bdd20f88b
    733bdd20ed7c:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20ed83:	00 
    733bdd20ed84:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd20ed8b:	c1 e9 0c             	shr    ecx,0xc
    733bdd20ed8e:	89 c9                	mov    ecx,ecx
    733bdd20ed90:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20ed94:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    733bdd20ed9b:	00 
    733bdd20ed9c:	48 83 f8 00          	cmp    rax,0x0
    733bdd20eda0:	74 23                	je     0x733bdd20edc5
    733bdd20eda2:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd20eda9:	00 
    733bdd20edaa:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd20edb1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20edb7:	89 c9                	mov    ecx,ecx
    733bdd20edb9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20edbc:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd20edc3:	eb 5d                	jmp    0x733bdd20ee22
    733bdd20edc5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20edcc:	00 
    733bdd20edcd:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    733bdd20edd4:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20eddb:	00 
    733bdd20eddc:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20ede3:	00 01 00 
    733bdd20ede6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20eded:	00 00 00 
    733bdd20edf0:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20edf7:	00 00 00 
    733bdd20edfa:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20ee01:	59 00 00 
    733bdd20ee04:	ff d0                	call   rax
    733bdd20ee06:	89 c1                	mov    ecx,eax
    733bdd20ee08:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ee0f:	00 
    733bdd20ee10:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    733bdd20ee17:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20ee1e:	75 32                	jne    0x733bdd20ee52
    733bdd20ee20:	eb 7c                	jmp    0x733bdd20ee9e
    733bdd20ee22:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    733bdd20ee29:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20ee30:	00 
    733bdd20ee31:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    733bdd20ee38:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    733bdd20ee3b:	83 c0 04             	add    eax,0x4
    733bdd20ee3e:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd20ee45:	83 e0 03             	and    eax,0x3
    733bdd20ee48:	83 f8 00             	cmp    eax,0x0
    733bdd20ee4b:	75 64                	jne    0x733bdd20eeb1
    733bdd20ee4d:	e9 f6 00 00 00       	jmp    0x733bdd20ef48
    733bdd20ee52:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ee59:	00 
    733bdd20ee5a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ee60:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ee66:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20ee6c:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20ee71:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20ee76:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20ee7d:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20ee84:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20ee8b:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20ee92:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20ee99:	e9 ed 09 00 00       	jmp    0x733bdd20f88b
    733bdd20ee9e:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    733bdd20eea5:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd20eeac:	e9 71 ff ff ff       	jmp    0x733bdd20ee22
    733bdd20eeb1:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20eeb8:	00 
    733bdd20eeb9:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20eec0:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20eec7:	00 
    733bdd20eec8:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20eecf:	00 01 00 
    733bdd20eed2:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20eed9:	00 00 00 
    733bdd20eedc:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20eee3:	00 00 00 
    733bdd20eee6:	31 c0                	xor    eax,eax
    733bdd20eee8:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20eeef:	59 00 00 
    733bdd20eef2:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20eef7:	45 31 c0             	xor    r8d,r8d
    733bdd20eefa:	ff d0                	call   rax
    733bdd20eefc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ef03:	00 
    733bdd20ef04:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20ef0a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ef10:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20ef16:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20ef1b:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20ef20:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20ef27:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20ef2e:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20ef35:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20ef3c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20ef43:	e9 43 09 00 00       	jmp    0x733bdd20f88b
    733bdd20ef48:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20ef4f:	00 
    733bdd20ef50:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20ef57:	c1 e9 0c             	shr    ecx,0xc
    733bdd20ef5a:	89 c9                	mov    ecx,ecx
    733bdd20ef5c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20ef60:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd20ef67:	00 
    733bdd20ef68:	48 83 f8 00          	cmp    rax,0x0
    733bdd20ef6c:	74 23                	je     0x733bdd20ef91
    733bdd20ef6e:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd20ef75:	00 
    733bdd20ef76:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20ef7d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20ef83:	89 c9                	mov    ecx,ecx
    733bdd20ef85:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20ef88:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd20ef8f:	eb 5d                	jmp    0x733bdd20efee
    733bdd20ef91:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20ef98:	00 
    733bdd20ef99:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    733bdd20efa0:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20efa7:	00 
    733bdd20efa8:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20efaf:	00 01 00 
    733bdd20efb2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20efb9:	00 00 00 
    733bdd20efbc:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20efc3:	00 00 00 
    733bdd20efc6:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20efcd:	59 00 00 
    733bdd20efd0:	ff d0                	call   rax
    733bdd20efd2:	89 c1                	mov    ecx,eax
    733bdd20efd4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20efdb:	00 
    733bdd20efdc:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    733bdd20efe3:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20efea:	75 32                	jne    0x733bdd20f01e
    733bdd20efec:	eb 7c                	jmp    0x733bdd20f06a
    733bdd20efee:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    733bdd20eff5:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20effc:	00 
    733bdd20effd:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    733bdd20f004:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    733bdd20f007:	83 c0 04             	add    eax,0x4
    733bdd20f00a:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd20f011:	83 e0 03             	and    eax,0x3
    733bdd20f014:	83 f8 00             	cmp    eax,0x0
    733bdd20f017:	75 64                	jne    0x733bdd20f07d
    733bdd20f019:	e9 f6 00 00 00       	jmp    0x733bdd20f114
    733bdd20f01e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f025:	00 
    733bdd20f026:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f02c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f032:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f038:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f03d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f042:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f049:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f050:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f057:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f05e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f065:	e9 21 08 00 00       	jmp    0x733bdd20f88b
    733bdd20f06a:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    733bdd20f071:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd20f078:	e9 71 ff ff ff       	jmp    0x733bdd20efee
    733bdd20f07d:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20f084:	00 
    733bdd20f085:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20f08c:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20f093:	00 
    733bdd20f094:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20f09b:	00 01 00 
    733bdd20f09e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20f0a5:	00 00 00 
    733bdd20f0a8:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20f0af:	00 00 00 
    733bdd20f0b2:	31 c0                	xor    eax,eax
    733bdd20f0b4:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20f0bb:	59 00 00 
    733bdd20f0be:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20f0c3:	45 31 c0             	xor    r8d,r8d
    733bdd20f0c6:	ff d0                	call   rax
    733bdd20f0c8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f0cf:	00 
    733bdd20f0d0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f0d6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f0dc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f0e2:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f0e7:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f0ec:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f0f3:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f0fa:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f101:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f108:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f10f:	e9 77 07 00 00       	jmp    0x733bdd20f88b
    733bdd20f114:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20f11b:	00 
    733bdd20f11c:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20f123:	c1 e9 0c             	shr    ecx,0xc
    733bdd20f126:	89 c9                	mov    ecx,ecx
    733bdd20f128:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20f12c:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd20f133:	00 
    733bdd20f134:	48 83 f8 00          	cmp    rax,0x0
    733bdd20f138:	74 20                	je     0x733bdd20f15a
    733bdd20f13a:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd20f141:	00 
    733bdd20f142:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20f149:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20f14f:	89 c9                	mov    ecx,ecx
    733bdd20f151:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20f154:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd20f158:	eb 5a                	jmp    0x733bdd20f1b4
    733bdd20f15a:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f161:	00 
    733bdd20f162:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    733bdd20f169:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20f170:	00 
    733bdd20f171:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20f178:	00 01 00 
    733bdd20f17b:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20f182:	00 00 00 
    733bdd20f185:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20f18c:	00 00 00 
    733bdd20f18f:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20f196:	59 00 00 
    733bdd20f199:	ff d0                	call   rax
    733bdd20f19b:	89 c1                	mov    ecx,eax
    733bdd20f19d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f1a4:	00 
    733bdd20f1a5:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    733bdd20f1a9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20f1b0:	75 2c                	jne    0x733bdd20f1de
    733bdd20f1b2:	eb 76                	jmp    0x733bdd20f22a
    733bdd20f1b4:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    733bdd20f1bb:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20f1c2:	00 
    733bdd20f1c3:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    733bdd20f1c7:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    733bdd20f1ca:	83 c0 04             	add    eax,0x4
    733bdd20f1cd:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd20f1d1:	83 e0 03             	and    eax,0x3
    733bdd20f1d4:	83 f8 00             	cmp    eax,0x0
    733bdd20f1d7:	75 5b                	jne    0x733bdd20f234
    733bdd20f1d9:	e9 ea 00 00 00       	jmp    0x733bdd20f2c8
    733bdd20f1de:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f1e5:	00 
    733bdd20f1e6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f1ec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f1f2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f1f8:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f1fd:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f202:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f209:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f210:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f217:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f21e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f225:	e9 61 06 00 00       	jmp    0x733bdd20f88b
    733bdd20f22a:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    733bdd20f22e:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd20f232:	eb 80                	jmp    0x733bdd20f1b4
    733bdd20f234:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20f23b:	00 
    733bdd20f23c:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd20f240:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20f247:	00 
    733bdd20f248:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20f24f:	00 01 00 
    733bdd20f252:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20f259:	00 00 00 
    733bdd20f25c:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20f263:	00 00 00 
    733bdd20f266:	31 c0                	xor    eax,eax
    733bdd20f268:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20f26f:	59 00 00 
    733bdd20f272:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20f277:	45 31 c0             	xor    r8d,r8d
    733bdd20f27a:	ff d0                	call   rax
    733bdd20f27c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f283:	00 
    733bdd20f284:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f28a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f290:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f296:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f29b:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f2a0:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f2a7:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f2ae:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f2b5:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f2bc:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f2c3:	e9 c3 05 00 00       	jmp    0x733bdd20f88b
    733bdd20f2c8:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20f2cf:	00 
    733bdd20f2d0:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd20f2d4:	c1 e9 0c             	shr    ecx,0xc
    733bdd20f2d7:	89 c9                	mov    ecx,ecx
    733bdd20f2d9:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20f2dd:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd20f2e2:	48 83 f8 00          	cmp    rax,0x0
    733bdd20f2e6:	74 1a                	je     0x733bdd20f302
    733bdd20f2e8:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd20f2ed:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd20f2f1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20f2f7:	89 c9                	mov    ecx,ecx
    733bdd20f2f9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20f2fc:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd20f300:	eb 57                	jmp    0x733bdd20f359
    733bdd20f302:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f309:	00 
    733bdd20f30a:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    733bdd20f30e:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20f315:	00 
    733bdd20f316:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20f31d:	00 01 00 
    733bdd20f320:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20f327:	00 00 00 
    733bdd20f32a:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20f331:	00 00 00 
    733bdd20f334:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20f33b:	59 00 00 
    733bdd20f33e:	ff d0                	call   rax
    733bdd20f340:	89 c1                	mov    ecx,eax
    733bdd20f342:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f349:	00 
    733bdd20f34a:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    733bdd20f34e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20f355:	75 29                	jne    0x733bdd20f380
    733bdd20f357:	eb 73                	jmp    0x733bdd20f3cc
    733bdd20f359:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd20f35d:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20f364:	00 
    733bdd20f365:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    733bdd20f369:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    733bdd20f36c:	83 c0 04             	add    eax,0x4
    733bdd20f36f:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd20f373:	83 e0 03             	and    eax,0x3
    733bdd20f376:	83 f8 00             	cmp    eax,0x0
    733bdd20f379:	75 5b                	jne    0x733bdd20f3d6
    733bdd20f37b:	e9 ea 00 00 00       	jmp    0x733bdd20f46a
    733bdd20f380:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f387:	00 
    733bdd20f388:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f38e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f394:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f39a:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f39f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f3a4:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f3ab:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f3b2:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f3b9:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f3c0:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f3c7:	e9 bf 04 00 00       	jmp    0x733bdd20f88b
    733bdd20f3cc:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    733bdd20f3d0:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd20f3d4:	eb 83                	jmp    0x733bdd20f359
    733bdd20f3d6:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20f3dd:	00 
    733bdd20f3de:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20f3e2:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20f3e9:	00 
    733bdd20f3ea:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20f3f1:	00 01 00 
    733bdd20f3f4:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20f3fb:	00 00 00 
    733bdd20f3fe:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20f405:	00 00 00 
    733bdd20f408:	31 c0                	xor    eax,eax
    733bdd20f40a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20f411:	59 00 00 
    733bdd20f414:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20f419:	45 31 c0             	xor    r8d,r8d
    733bdd20f41c:	ff d0                	call   rax
    733bdd20f41e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f425:	00 
    733bdd20f426:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f42c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f432:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f438:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f43d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f442:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f449:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f450:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f457:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f45e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f465:	e9 21 04 00 00       	jmp    0x733bdd20f88b
    733bdd20f46a:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20f471:	00 
    733bdd20f472:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20f476:	c1 e9 0c             	shr    ecx,0xc
    733bdd20f479:	89 c9                	mov    ecx,ecx
    733bdd20f47b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20f47f:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd20f484:	48 83 f8 00          	cmp    rax,0x0
    733bdd20f488:	74 1a                	je     0x733bdd20f4a4
    733bdd20f48a:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd20f48f:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20f493:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20f499:	89 c9                	mov    ecx,ecx
    733bdd20f49b:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20f49e:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20f4a2:	eb 57                	jmp    0x733bdd20f4fb
    733bdd20f4a4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f4ab:	00 
    733bdd20f4ac:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    733bdd20f4b0:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20f4b7:	00 
    733bdd20f4b8:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20f4bf:	00 01 00 
    733bdd20f4c2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20f4c9:	00 00 00 
    733bdd20f4cc:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20f4d3:	00 00 00 
    733bdd20f4d6:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20f4dd:	59 00 00 
    733bdd20f4e0:	ff d0                	call   rax
    733bdd20f4e2:	89 c1                	mov    ecx,eax
    733bdd20f4e4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f4eb:	00 
    733bdd20f4ec:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd20f4f0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20f4f7:	75 29                	jne    0x733bdd20f522
    733bdd20f4f9:	eb 73                	jmp    0x733bdd20f56e
    733bdd20f4fb:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    733bdd20f4ff:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20f506:	00 
    733bdd20f507:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    733bdd20f50b:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    733bdd20f50e:	83 c0 04             	add    eax,0x4
    733bdd20f511:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20f515:	83 e0 03             	and    eax,0x3
    733bdd20f518:	83 f8 00             	cmp    eax,0x0
    733bdd20f51b:	75 5b                	jne    0x733bdd20f578
    733bdd20f51d:	e9 ea 00 00 00       	jmp    0x733bdd20f60c
    733bdd20f522:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f529:	00 
    733bdd20f52a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f530:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f536:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f53c:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f541:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f546:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f54d:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f554:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f55b:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f562:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f569:	e9 1d 03 00 00       	jmp    0x733bdd20f88b
    733bdd20f56e:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd20f572:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20f576:	eb 83                	jmp    0x733bdd20f4fb
    733bdd20f578:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20f57f:	00 
    733bdd20f580:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20f584:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    733bdd20f58b:	00 
    733bdd20f58c:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    733bdd20f593:	00 01 00 
    733bdd20f596:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20f59d:	00 00 00 
    733bdd20f5a0:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd20f5a7:	00 00 00 
    733bdd20f5aa:	31 c0                	xor    eax,eax
    733bdd20f5ac:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20f5b3:	59 00 00 
    733bdd20f5b6:	ba bc 00 01 00       	mov    edx,0x100bc
    733bdd20f5bb:	45 31 c0             	xor    r8d,r8d
    733bdd20f5be:	ff d0                	call   rax
    733bdd20f5c0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f5c7:	00 
    733bdd20f5c8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f5ce:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f5d4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f5da:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f5df:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f5e4:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f5eb:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f5f2:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f5f9:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f600:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f607:	e9 7f 02 00 00       	jmp    0x733bdd20f88b
    733bdd20f60c:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd20f613:	00 
    733bdd20f614:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20f618:	c1 e9 0c             	shr    ecx,0xc
    733bdd20f61b:	89 c9                	mov    ecx,ecx
    733bdd20f61d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20f621:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd20f626:	48 83 f8 00          	cmp    rax,0x0
    733bdd20f62a:	74 1a                	je     0x733bdd20f646
    733bdd20f62c:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd20f631:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20f635:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20f63b:	89 c9                	mov    ecx,ecx
    733bdd20f63d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20f640:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20f644:	eb 57                	jmp    0x733bdd20f69d
    733bdd20f646:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f64d:	00 
    733bdd20f64e:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd20f652:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    733bdd20f659:	00 
    733bdd20f65a:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    733bdd20f661:	00 01 00 
    733bdd20f664:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20f66b:	00 00 00 
    733bdd20f66e:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd20f675:	00 00 00 
    733bdd20f678:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20f67f:	59 00 00 
    733bdd20f682:	ff d0                	call   rax
    733bdd20f684:	89 c1                	mov    ecx,eax
    733bdd20f686:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f68d:	00 
    733bdd20f68e:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd20f692:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20f699:	75 1d                	jne    0x733bdd20f6b8
    733bdd20f69b:	eb 67                	jmp    0x733bdd20f704
    733bdd20f69d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f6a4:	00 
    733bdd20f6a5:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20f6a9:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    733bdd20f6ad:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    733bdd20f6b0:	83 c1 04             	add    ecx,0x4
    733bdd20f6b3:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20f6b6:	eb 56                	jmp    0x733bdd20f70e
    733bdd20f6b8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f6bf:	00 
    733bdd20f6c0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f6c6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f6cc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f6d2:	be 0e 00 00 00       	mov    esi,0xe
    733bdd20f6d7:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f6dc:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f6e3:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f6ea:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f6f1:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f6f8:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f6ff:	e9 87 01 00 00       	jmp    0x733bdd20f88b
    733bdd20f704:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd20f708:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20f70c:	eb 8f                	jmp    0x733bdd20f69d
    733bdd20f70e:	eb 00                	jmp    0x733bdd20f710
    733bdd20f710:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    733bdd20f717:	83 e0 01             	and    eax,0x1
    733bdd20f71a:	83 f8 00             	cmp    eax,0x0
    733bdd20f71d:	75 3d                	jne    0x733bdd20f75c
    733bdd20f71f:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    733bdd20f726:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20f72b:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f730:	b0 01                	mov    al,0x1
    733bdd20f732:	89 d7                	mov    edi,edx
    733bdd20f734:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f73b:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f742:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f749:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f750:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f757:	e9 2f 01 00 00       	jmp    0x733bdd20f88b
    733bdd20f75c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    733bdd20f763:	00 
    733bdd20f764:	48 8b 94 24 70 01 00 	mov    rdx,QWORD PTR [rsp+0x170]
    733bdd20f76b:	00 
    733bdd20f76c:	c7 87 bc 00 00 00 be 	mov    DWORD PTR [rdi+0xbc],0x100be
    733bdd20f773:	00 01 00 
    733bdd20f776:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20f77d:	00 00 00 
    733bdd20f780:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd20f787:	00 00 00 
    733bdd20f78a:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd20f791:	59 00 00 
    733bdd20f794:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd20f799:	ff d0                	call   rax
    733bdd20f79b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f7a2:	00 
    733bdd20f7a3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20f7a9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20f7af:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20f7b5:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20f7ba:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20f7bf:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    733bdd20f7c6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    733bdd20f7cd:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd20f7d4:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd20f7db:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    733bdd20f7e2:	e9 a4 00 00 00       	jmp    0x733bdd20f88b
    733bdd20f7e7:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f7ee:	00 
    733bdd20f7ef:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20f7f6:	e9 82 01 00 00       	jmp    0x733bdd20f97d
    733bdd20f7fb:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    733bdd20f802:	00 
    733bdd20f803:	48 89 c1             	mov    rcx,rax
    733bdd20f806:	48 81 c1 20 04 08 00 	add    rcx,0x80420
    733bdd20f80d:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd20f812:	81 b8 20 04 08 00 84 	cmp    DWORD PTR [rax+0x80420],0x10084
    733bdd20f819:	00 01 00 
    733bdd20f81c:	74 32                	je     0x733bdd20f850
    733bdd20f81e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f825:	00 
    733bdd20f826:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    733bdd20f82d:	00 01 00 
    733bdd20f830:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20f837:	00 00 00 
    733bdd20f83a:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd20f841:	00 00 00 
    733bdd20f844:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20f84b:	e9 2d 01 00 00       	jmp    0x733bdd20f97d
    733bdd20f850:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    733bdd20f857:	00 
    733bdd20f858:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    733bdd20f85f:	00 
    733bdd20f860:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd20f865:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    733bdd20f86c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    733bdd20f873:	84 00 01 00 
    733bdd20f877:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20f87e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20f882:	48 81 c4 98 01 00 00 	add    rsp,0x198
    733bdd20f889:	ff e0                	jmp    rax
    733bdd20f88b:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    733bdd20f892:	00 
    733bdd20f893:	8b 94 24 48 01 00 00 	mov    edx,DWORD PTR [rsp+0x148]
    733bdd20f89a:	8b 84 24 4c 01 00 00 	mov    eax,DWORD PTR [rsp+0x14c]
    733bdd20f8a1:	8b b4 24 50 01 00 00 	mov    esi,DWORD PTR [rsp+0x150]
    733bdd20f8a8:	8b bc 24 54 01 00 00 	mov    edi,DWORD PTR [rsp+0x154]
    733bdd20f8af:	8a 9c 24 5b 01 00 00 	mov    bl,BYTE PTR [rsp+0x15b]
    733bdd20f8b6:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    733bdd20f8ba:	89 c3                	mov    ebx,eax
    733bdd20f8bc:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    733bdd20f8c0:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    733bdd20f8c4:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    733bdd20f8c8:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    733bdd20f8cc:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20f8d2:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    733bdd20f8d6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20f8dc:	73 2d                	jae    0x733bdd20f90b
    733bdd20f8de:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    733bdd20f8e5:	00 
    733bdd20f8e6:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd20f8ea:	89 d1                	mov    ecx,edx
    733bdd20f8ec:	c1 e9 01             	shr    ecx,0x1
    733bdd20f8ef:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20f8f5:	89 c9                	mov    ecx,ecx
    733bdd20f8f7:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20f8fb:	48 89 c6             	mov    rsi,rax
    733bdd20f8fe:	48 01 ce             	add    rsi,rcx
    733bdd20f901:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd20f906:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20f909:	74 32                	je     0x733bdd20f93d
    733bdd20f90b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    733bdd20f912:	00 
    733bdd20f913:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    733bdd20f917:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd20f91b:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    733bdd20f91f:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    733bdd20f923:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd20f929:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd20f92f:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd20f935:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd20f93b:	eb 40                	jmp    0x733bdd20f97d
    733bdd20f93d:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    733bdd20f944:	00 
    733bdd20f945:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    733bdd20f94c:	00 
    733bdd20f94d:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd20f952:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    733bdd20f956:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd20f95a:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd20f961:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20f968:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20f96f:	00 
    733bdd20f970:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20f974:	48 81 c4 98 01 00 00 	add    rsp,0x198
    733bdd20f97b:	ff e0                	jmp    rax
    733bdd20f97d:	48 81 c4 98 01 00 00 	add    rsp,0x198
    733bdd20f984:	c2 08 00             	ret    0x8
