
build-native-instruction-analysis/capture/bcore-default-branch/pc-65808-0-126700950181424.bin:     file format binary


Disassembly of section .data:

0000733bdd20d630 <.data>:
    733bdd20d630:	48 83 ec 28          	sub    rsp,0x28
    733bdd20d634:	b8 d1 fe fe ff       	mov    eax,0xfffefed1
    733bdd20d639:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    733bdd20d640:	01 c1                	add    ecx,eax
    733bdd20d642:	83 f9 e0             	cmp    ecx,0xffffffe0
    733bdd20d645:	0f 87 26 2e ff 17    	ja     0x733bf5200471
    733bdd20d64b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    733bdd20d652:	83 f8 e0             	cmp    eax,0xffffffe0
    733bdd20d655:	0f 87 16 2e ff 17    	ja     0x733bf5200471
    733bdd20d65b:	4d 89 f0             	mov    r8,r14
    733bdd20d65e:	49 8b bd 50 01 00 00 	mov    rdi,QWORD PTR [r13+0x150]
    733bdd20d665:	4d 8b 8d 38 01 00 00 	mov    r9,QWORD PTR [r13+0x138]
    733bdd20d66c:	4d 8b 95 40 01 00 00 	mov    r10,QWORD PTR [r13+0x140]
    733bdd20d673:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    733bdd20d677:	41 8b 75 38          	mov    esi,DWORD PTR [r13+0x38]
    733bdd20d67b:	41 89 c4             	mov    r12d,eax
    733bdd20d67e:	41 c1 ec 07          	shr    r12d,0x7
    733bdd20d682:	31 c9                	xor    ecx,ecx
    733bdd20d684:	41 31 c4             	xor    r12d,eax
    733bdd20d687:	45 89 65 04          	mov    DWORD PTR [r13+0x4],r12d
    733bdd20d68b:	0f 94 c1             	sete   cl
    733bdd20d68e:	c1 e8 1f             	shr    eax,0x1f
    733bdd20d691:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    733bdd20d698:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    733bdd20d69f:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    733bdd20d6a6:	00 00 00 00 
    733bdd20d6aa:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    733bdd20d6b1:	00 00 00 00 
    733bdd20d6b5:	45 89 65 28          	mov    DWORD PTR [r13+0x28],r12d
    733bdd20d6b9:	41 c7 45 24 b9 79 37 	mov    DWORD PTR [r13+0x24],0x9e3779b9
    733bdd20d6c0:	9e 
    733bdd20d6c1:	8d 5e fc             	lea    ebx,[rsi-0x4]
    733bdd20d6c4:	40 f6 c6 03          	test   sil,0x3
    733bdd20d6c8:	0f 85 b2 2d ff 17    	jne    0x733bf5200480
    733bdd20d6ce:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    733bdd20d6d5:	45 8b 5d 3c          	mov    r11d,DWORD PTR [r13+0x3c]
    733bdd20d6d9:	41 89 de             	mov    r14d,ebx
    733bdd20d6dc:	41 c1 ee 0c          	shr    r14d,0xc
    733bdd20d6e0:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    733bdd20d6e4:	48 85 c0             	test   rax,rax
    733bdd20d6e7:	0f 84 fd 2d ff 17    	je     0x733bf52004ea
    733bdd20d6ed:	89 d9                	mov    ecx,ebx
    733bdd20d6ef:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20d6f5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20d6f8:	8d 6e f8             	lea    ebp,[rsi-0x8]
    733bdd20d6fb:	41 89 ef             	mov    r15d,ebp
    733bdd20d6fe:	41 c1 ef 0c          	shr    r15d,0xc
    733bdd20d702:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    733bdd20d706:	48 85 c0             	test   rax,rax
    733bdd20d709:	0f 84 54 2e ff 17    	je     0x733bf5200563
    733bdd20d70f:	89 e9                	mov    ecx,ebp
    733bdd20d711:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20d717:	44 89 1c 08          	mov    DWORD PTR [rax+rcx*1],r11d
    733bdd20d71b:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    733bdd20d71f:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    733bdd20d723:	41 80 3a 00          	cmp    BYTE PTR [r10],0x0
    733bdd20d727:	0f 85 ad 2e ff 17    	jne    0x733bf52005da
    733bdd20d72d:	4b 8b 04 f9          	mov    rax,QWORD PTR [r9+r15*8]
    733bdd20d731:	48 85 c0             	test   rax,rax
    733bdd20d734:	0f 84 18 2f ff 17    	je     0x733bf5200652
    733bdd20d73a:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    733bdd20d740:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    733bdd20d743:	4b 8b 04 f1          	mov    rax,QWORD PTR [r9+r14*8]
    733bdd20d747:	48 85 c0             	test   rax,rax
    733bdd20d74a:	0f 84 6d 2f ff 17    	je     0x733bf52006bd
    733bdd20d750:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    733bdd20d756:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    733bdd20d759:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    733bdd20d75d:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    733bdd20d764:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    733bdd20d768:	43 8d 0c 64          	lea    ecx,[r12+r12*2]
    733bdd20d76c:	41 89 4d 28          	mov    DWORD PTR [r13+0x28],ecx
    733bdd20d770:	43 8d 8c 64 b9 79 37 	lea    ecx,[r12+r12*2-0x61c88647]
    733bdd20d777:	9e 
    733bdd20d778:	41 89 4d 24          	mov    DWORD PTR [r13+0x24],ecx
    733bdd20d77c:	41 89 4d 00          	mov    DWORD PTR [r13+0x0],ecx
    733bdd20d780:	b1 01                	mov    cl,0x1
    733bdd20d782:	bb 0b 00 00 00       	mov    ebx,0xb
    733bdd20d787:	bd 02 00 00 00       	mov    ebp,0x2
    733bdd20d78c:	a8 01                	test   al,0x1
    733bdd20d78e:	0f 85 84 2f ff 17    	jne    0x733bf5200718
    733bdd20d794:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    733bdd20d79b:	01 da                	add    edx,ebx
    733bdd20d79d:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    733bdd20d7a4:	39 f2                	cmp    edx,esi
    733bdd20d7a6:	73 36                	jae    0x733bdd20d7de
    733bdd20d7a8:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    733bdd20d7af:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    733bdd20d7b5:	39 04 37             	cmp    DWORD PTR [rdi+rsi*1],eax
    733bdd20d7b8:	75 24                	jne    0x733bdd20d7de
    733bdd20d7ba:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    733bdd20d7c1:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    733bdd20d7c8:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20d7cf:	00 
    733bdd20d7d0:	48 8b 44 37 08       	mov    rax,QWORD PTR [rdi+rsi*1+0x8]
    733bdd20d7d5:	4d 89 c6             	mov    r14,r8
    733bdd20d7d8:	48 83 c4 28          	add    rsp,0x28
    733bdd20d7dc:	ff e0                	jmp    rax
    733bdd20d7de:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    733bdd20d7e5:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    733bdd20d7ec:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    733bdd20d7f3:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    733bdd20d7fa:	48 83 c4 28          	add    rsp,0x28
    733bdd20d7fe:	c2 08 00             	ret    0x8
