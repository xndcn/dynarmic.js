
build-native-instruction-analysis/capture/bcore-default-branch/pc-65536-0-126700950126624.bin:     file format binary


Disassembly of section .data:

0000733bdd200020 <.data>:
    733bdd200020:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    733bdd200025:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    733bdd20002a:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd200031:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    733bdd200036:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd20003b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd200041:	83 fa 00             	cmp    edx,0x0
    733bdd200044:	0f 94 c0             	sete   al
    733bdd200047:	81 ea 00 00 01 00    	sub    edx,0x10000
    733bdd20004d:	83 fa 02             	cmp    edx,0x2
    733bdd200050:	0f 97 c2             	seta   dl
    733bdd200053:	08 d0                	or     al,dl
    733bdd200055:	24 01                	and    al,0x1
    733bdd200057:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20005d:	83 fa 00             	cmp    edx,0x0
    733bdd200060:	0f 94 c1             	sete   cl
    733bdd200063:	81 ea 00 00 01 00    	sub    edx,0x10000
    733bdd200069:	83 fa 02             	cmp    edx,0x2
    733bdd20006c:	0f 97 c2             	seta   dl
    733bdd20006f:	08 d1                	or     cl,dl
    733bdd200071:	20 c8                	and    al,cl
    733bdd200073:	a8 01                	test   al,0x1
    733bdd200075:	75 05                	jne    0x733bdd20007c
    733bdd200077:	e9 16 01 00 00       	jmp    0x733bdd200192
    733bdd20007c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd200081:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd200088:	48 89 c8             	mov    rax,rcx
    733bdd20008b:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd200091:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    733bdd200096:	8b 81 00 00 10 00    	mov    eax,DWORD PTR [rcx+0x100000]
    733bdd20009c:	83 c0 01             	add    eax,0x1
    733bdd20009f:	89 81 00 00 10 00    	mov    DWORD PTR [rcx+0x100000],eax
    733bdd2000a5:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd2000aa:	75 40                	jne    0x733bdd2000ec
    733bdd2000ac:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    733bdd2000b1:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd2000b7:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    733bdd2000bb:	89 c2                	mov    edx,eax
    733bdd2000bd:	83 c2 01             	add    edx,0x1
    733bdd2000c0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd2000c6:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd2000cb:	73 1d                	jae    0x733bdd2000ea
    733bdd2000cd:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    733bdd2000d2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    733bdd2000d6:	89 c9                	mov    ecx,ecx
    733bdd2000d8:	48 c1 e1 02          	shl    rcx,0x2
    733bdd2000dc:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd2000e3:	c7 04 08 00 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x0
    733bdd2000ea:	eb 00                	jmp    0x733bdd2000ec
    733bdd2000ec:	eb 00                	jmp    0x733bdd2000ee
    733bdd2000ee:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd2000f3:	8b 48 38             	mov    ecx,DWORD PTR [rax+0x38]
    733bdd2000f6:	83 c1 f4             	add    ecx,0xfffffff4
    733bdd2000f9:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd2000fc:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd200102:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    733bdd200106:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd20010c:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    733bdd200110:	eb 00                	jmp    0x733bdd200112
    733bdd200112:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd200117:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    733bdd20011b:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    733bdd20011f:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd200125:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd20012b:	83 ff 01             	cmp    edi,0x1
    733bdd20012e:	0f 97 c3             	seta   bl
    733bdd200131:	3d 02 00 01 00       	cmp    eax,0x10002
    733bdd200136:	0f 94 c0             	sete   al
    733bdd200139:	20 c3                	and    bl,al
    733bdd20013b:	b8 06 00 01 00       	mov    eax,0x10006
    733bdd200140:	f6 c3 01             	test   bl,0x1
    733bdd200143:	0f 45 c2             	cmovne eax,edx
    733bdd200146:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd20014c:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd200152:	83 ff 01             	cmp    edi,0x1
    733bdd200155:	0f 97 c3             	seta   bl
    733bdd200158:	81 fe 02 00 01 00    	cmp    esi,0x10002
    733bdd20015e:	40 0f 94 c6          	sete   sil
    733bdd200162:	40 20 f3             	and    bl,sil
    733bdd200165:	f6 c3 01             	test   bl,0x1
    733bdd200168:	0f 45 c2             	cmovne eax,edx
    733bdd20016b:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd200171:	c7 81 bc 00 00 00 14 	mov    DWORD PTR [rcx+0xbc],0x10014
    733bdd200178:	00 01 00 
    733bdd20017b:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd200181:	83 c0 02             	add    eax,0x2
    733bdd200184:	89 44 24 d0          	mov    DWORD PTR [rsp-0x30],eax
    733bdd200188:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20018e:	72 10                	jb     0x733bdd2001a0
    733bdd200190:	eb 2e                	jmp    0x733bdd2001c0
    733bdd200192:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd200197:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20019e:	eb 77                	jmp    0x733bdd200217
    733bdd2001a0:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd2001a5:	48 89 c1             	mov    rcx,rax
    733bdd2001a8:	48 81 c1 a0 00 08 00 	add    rcx,0x800a0
    733bdd2001af:	48 89 4c 24 c8       	mov    QWORD PTR [rsp-0x38],rcx
    733bdd2001b4:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    733bdd2001bb:	00 01 00 
    733bdd2001be:	74 2c                	je     0x733bdd2001ec
    733bdd2001c0:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd2001c5:	c7 80 bc 00 00 00 14 	mov    DWORD PTR [rax+0xbc],0x10014
    733bdd2001cc:	00 01 00 
    733bdd2001cf:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2001d6:	00 00 00 
    733bdd2001d9:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd2001e0:	00 00 00 
    733bdd2001e3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd2001ea:	eb 2b                	jmp    0x733bdd200217
    733bdd2001ec:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd2001f1:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd2001f6:	48 8b 44 24 c8       	mov    rax,QWORD PTR [rsp-0x38]
    733bdd2001fb:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    733bdd2001ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    733bdd200206:	14 00 01 00 
    733bdd20020a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd200211:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd200215:	ff e0                	jmp    rax
    733bdd200217:	c2 08 00             	ret    0x8
