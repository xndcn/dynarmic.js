
build-native-instruction-analysis/capture/bcore-default-branch/pc-65840-0-126700950179600.bin:     file format binary


Disassembly of section .data:

0000733bdd20cf10 <.data>:
    733bdd20cf10:	48 83 ec 38          	sub    rsp,0x38
    733bdd20cf14:	b8 b5 fe fe ff       	mov    eax,0xfffefeb5
    733bdd20cf19:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    733bdd20cf20:	01 c1                	add    ecx,eax
    733bdd20cf22:	83 f9 e4             	cmp    ecx,0xffffffe4
    733bdd20cf25:	0f 87 0c 31 ff 17    	ja     0x733bf5200037
    733bdd20cf2b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    733bdd20cf32:	83 f8 e4             	cmp    eax,0xffffffe4
    733bdd20cf35:	0f 87 fc 30 ff 17    	ja     0x733bf5200037
    733bdd20cf3b:	4d 89 f3             	mov    r11,r14
    733bdd20cf3e:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    733bdd20cf45:	4d 8b 95 38 01 00 00 	mov    r10,QWORD PTR [r13+0x138]
    733bdd20cf4c:	49 8b b5 40 01 00 00 	mov    rsi,QWORD PTR [r13+0x140]
    733bdd20cf53:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    733bdd20cf57:	45 8b 4d 38          	mov    r9d,DWORD PTR [r13+0x38]
    733bdd20cf5b:	41 89 c7             	mov    r15d,eax
    733bdd20cf5e:	41 c1 e7 05          	shl    r15d,0x5
    733bdd20cf62:	41 0f b7 cf          	movzx  ecx,r15w
    733bdd20cf66:	41 c1 ef 1f          	shr    r15d,0x1f
    733bdd20cf6a:	c4 63 7b f0 f0 1b    	rorx   r14d,eax,0x1b
    733bdd20cf70:	45 89 75 00          	mov    DWORD PTR [r13+0x0],r14d
    733bdd20cf74:	31 d2                	xor    edx,edx
    733bdd20cf76:	85 c0                	test   eax,eax
    733bdd20cf78:	0f 94 c2             	sete   dl
    733bdd20cf7b:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    733bdd20cf82:	45 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],r15d
    733bdd20cf89:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    733bdd20cf90:	00 00 00 00 
    733bdd20cf94:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    733bdd20cf9b:	00 00 00 00 
    733bdd20cf9f:	81 c9 00 00 4a 7f    	or     ecx,0x7f4a0000
    733bdd20cfa5:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    733bdd20cfa9:	41 8d 59 fc          	lea    ebx,[r9-0x4]
    733bdd20cfad:	41 f6 c1 03          	test   r9b,0x3
    733bdd20cfb1:	0f 85 8f 30 ff 17    	jne    0x733bf5200046
    733bdd20cfb7:	41 8b 95 a8 00 00 00 	mov    edx,DWORD PTR [r13+0xa8]
    733bdd20cfbe:	41 8b 7d 3c          	mov    edi,DWORD PTR [r13+0x3c]
    733bdd20cfc2:	89 d8                	mov    eax,ebx
    733bdd20cfc4:	c1 e8 0c             	shr    eax,0xc
    733bdd20cfc7:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    733bdd20cfcc:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    733bdd20cfd0:	48 85 c0             	test   rax,rax
    733bdd20cfd3:	0f 84 d7 30 ff 17    	je     0x733bf52000b0
    733bdd20cfd9:	89 d9                	mov    ecx,ebx
    733bdd20cfdb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20cfe1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20cfe4:	41 8d 69 f8          	lea    ebp,[r9-0x8]
    733bdd20cfe8:	41 89 ec             	mov    r12d,ebp
    733bdd20cfeb:	41 c1 ec 0c          	shr    r12d,0xc
    733bdd20cfef:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    733bdd20cff3:	48 85 c0             	test   rax,rax
    733bdd20cff6:	0f 84 2d 31 ff 17    	je     0x733bf5200129
    733bdd20cffc:	89 e9                	mov    ecx,ebp
    733bdd20cffe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20d004:	89 3c 08             	mov    DWORD PTR [rax+rcx*1],edi
    733bdd20d007:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    733bdd20d00b:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    733bdd20d00f:	80 3e 00             	cmp    BYTE PTR [rsi],0x0
    733bdd20d012:	0f 85 89 31 ff 17    	jne    0x733bf52001a1
    733bdd20d018:	41 c7 45 04 15 7c 4a 	mov    DWORD PTR [r13+0x4],0x7f4a7c15
    733bdd20d01f:	7f 
    733bdd20d020:	41 8d 86 15 7c 4a 7f 	lea    eax,[r14+0x7f4a7c15]
    733bdd20d027:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    733bdd20d02b:	89 c1                	mov    ecx,eax
    733bdd20d02d:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20d030:	c4 e2 00 f2 d1       	andn   edx,r15d,ecx
    733bdd20d035:	31 f6                	xor    esi,esi
    733bdd20d037:	41 81 fe eb 83 b5 80 	cmp    r14d,0x80b583eb
    733bdd20d03e:	40 0f 93 c6          	setae  sil
    733bdd20d042:	31 ff                	xor    edi,edi
    733bdd20d044:	85 c0                	test   eax,eax
    733bdd20d046:	40 0f 94 c7          	sete   dil
    733bdd20d04a:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    733bdd20d051:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    733bdd20d058:	41 89 95 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edx
    733bdd20d05f:	41 89 95 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edx
    733bdd20d066:	41 09 95 00 01 00 00 	or     DWORD PTR [r13+0x100],edx
    733bdd20d06d:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    733bdd20d074:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    733bdd20d07b:	4b 8b 04 e2          	mov    rax,QWORD PTR [r10+r12*8]
    733bdd20d07f:	48 85 c0             	test   rax,rax
    733bdd20d082:	0f 84 8d 31 ff 17    	je     0x733bf5200215
    733bdd20d088:	81 e5 ff 0f 00 00    	and    ebp,0xfff
    733bdd20d08e:	8b 2c 28             	mov    ebp,DWORD PTR [rax+rbp*1]
    733bdd20d091:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd20d096:	49 8b 04 c2          	mov    rax,QWORD PTR [r10+rax*8]
    733bdd20d09a:	48 85 c0             	test   rax,rax
    733bdd20d09d:	0f 84 dd 31 ff 17    	je     0x733bf5200280
    733bdd20d0a3:	81 e3 ff 0f 00 00    	and    ebx,0xfff
    733bdd20d0a9:	8b 04 18             	mov    eax,DWORD PTR [rax+rbx*1]
    733bdd20d0ac:	41 89 6d 3c          	mov    DWORD PTR [r13+0x3c],ebp
    733bdd20d0b0:	41 89 85 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],eax
    733bdd20d0b7:	45 89 4d 38          	mov    DWORD PTR [r13+0x38],r9d
    733bdd20d0bb:	b1 01                	mov    cl,0x1
    733bdd20d0bd:	bb 09 00 00 00       	mov    ebx,0x9
    733bdd20d0c2:	bd 02 00 00 00       	mov    ebp,0x2
    733bdd20d0c7:	a8 01                	test   al,0x1
    733bdd20d0c9:	0f 85 0a 32 ff 17    	jne    0x733bf52002d9
    733bdd20d0cf:	41 8b 95 5c 01 00 00 	mov    edx,DWORD PTR [r13+0x15c]
    733bdd20d0d6:	01 da                	add    edx,ebx
    733bdd20d0d8:	41 8b b5 58 01 00 00 	mov    esi,DWORD PTR [r13+0x158]
    733bdd20d0df:	39 f2                	cmp    edx,esi
    733bdd20d0e1:	73 37                	jae    0x733bdd20d11a
    733bdd20d0e3:	8d 34 c5 00 00 00 00 	lea    esi,[rax*8+0x0]
    733bdd20d0ea:	81 e6 f0 ff 0f 00    	and    esi,0xffff0
    733bdd20d0f0:	41 39 04 30          	cmp    DWORD PTR [r8+rsi*1],eax
    733bdd20d0f4:	75 24                	jne    0x733bdd20d11a
    733bdd20d0f6:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    733bdd20d0fd:	41 89 95 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],edx
    733bdd20d104:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20d10b:	00 
    733bdd20d10c:	49 8b 44 30 08       	mov    rax,QWORD PTR [r8+rsi*1+0x8]
    733bdd20d111:	4d 89 de             	mov    r14,r11
    733bdd20d114:	48 83 c4 38          	add    rsp,0x38
    733bdd20d118:	ff e0                	jmp    rax
    733bdd20d11a:	41 89 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],eax
    733bdd20d121:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    733bdd20d128:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    733bdd20d12f:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    733bdd20d136:	48 83 c4 38          	add    rsp,0x38
    733bdd20d13a:	c2 08 00             	ret    0x8
