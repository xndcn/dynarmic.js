
build-native-instruction-analysis/capture/bcore-default-branch/pc-65600-0-126700950137712.bin:     file format binary


Disassembly of section .data:

0000733bdd202b70 <.data>:
    733bdd202b70:	48 81 ec 28 01 00 00 	sub    rsp,0x128
    733bdd202b77:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
    733bdd202b7e:	00 
    733bdd202b7f:	4c 89 ac 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r13
    733bdd202b86:	00 
    733bdd202b87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd202b8e:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    733bdd202b95:	00 
    733bdd202b96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd202b9d:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    733bdd202ba4:	00 
    733bdd202ba5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd202bac:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    733bdd202bb3:	00 
    733bdd202bb4:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    733bdd202bbb:	00 
    733bdd202bbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd202bc2:	83 fa 00             	cmp    edx,0x0
    733bdd202bc5:	0f 94 c0             	sete   al
    733bdd202bc8:	81 ea 40 00 01 00    	sub    edx,0x10040
    733bdd202bce:	83 fa 4e             	cmp    edx,0x4e
    733bdd202bd1:	0f 97 c2             	seta   dl
    733bdd202bd4:	08 d0                	or     al,dl
    733bdd202bd6:	24 01                	and    al,0x1
    733bdd202bd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd202bde:	83 fa 00             	cmp    edx,0x0
    733bdd202be1:	0f 94 c1             	sete   cl
    733bdd202be4:	81 ea 40 00 01 00    	sub    edx,0x10040
    733bdd202bea:	83 fa 4e             	cmp    edx,0x4e
    733bdd202bed:	0f 97 c2             	seta   dl
    733bdd202bf0:	08 d1                	or     cl,dl
    733bdd202bf2:	20 c8                	and    al,cl
    733bdd202bf4:	a8 01                	test   al,0x1
    733bdd202bf6:	75 05                	jne    0x733bdd202bfd
    733bdd202bf8:	e9 6e 11 00 00       	jmp    0x733bdd203d6b
    733bdd202bfd:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202c04:	00 
    733bdd202c05:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd202c0c:	48 89 c8             	mov    rax,rcx
    733bdd202c0f:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd202c15:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    733bdd202c1c:	00 
    733bdd202c1d:	8b 81 08 00 10 00    	mov    eax,DWORD PTR [rcx+0x100008]
    733bdd202c23:	83 c0 01             	add    eax,0x1
    733bdd202c26:	89 81 08 00 10 00    	mov    DWORD PTR [rcx+0x100008],eax
    733bdd202c2c:	3d 14 cd 00 00       	cmp    eax,0xcd14
    733bdd202c31:	75 4c                	jne    0x733bdd202c7f
    733bdd202c33:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    733bdd202c3a:	00 
    733bdd202c3b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd202c41:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    733bdd202c48:	89 c2                	mov    edx,eax
    733bdd202c4a:	83 c2 01             	add    edx,0x1
    733bdd202c4d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd202c53:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd202c58:	73 23                	jae    0x733bdd202c7d
    733bdd202c5a:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    733bdd202c61:	00 
    733bdd202c62:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    733bdd202c69:	89 c9                	mov    ecx,ecx
    733bdd202c6b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd202c6f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd202c76:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    733bdd202c7d:	eb 00                	jmp    0x733bdd202c7f
    733bdd202c7f:	eb 00                	jmp    0x733bdd202c81
    733bdd202c81:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202c88:	00 
    733bdd202c89:	c7 40 28 01 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c01
    733bdd202c90:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd202c96:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    733bdd202c9d:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd202ca3:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    733bdd202caa:	eb 00                	jmp    0x733bdd202cac
    733bdd202cac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202cb3:	00 
    733bdd202cb4:	c7 40 28 04 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf004
    733bdd202cbb:	eb 00                	jmp    0x733bdd202cbd
    733bdd202cbd:	31 c0                	xor    eax,eax
    733bdd202cbf:	a8 01                	test   al,0x1
    733bdd202cc1:	75 02                	jne    0x733bdd202cc5
    733bdd202cc3:	eb 7b                	jmp    0x733bdd202d40
    733bdd202cc5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd202ccc:	00 
    733bdd202ccd:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd202cd4:	00 
    733bdd202cd5:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10046
    733bdd202cdc:	00 01 00 
    733bdd202cdf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd202ce6:	00 00 00 
    733bdd202ce9:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd202cf0:	00 00 00 
    733bdd202cf3:	31 c0                	xor    eax,eax
    733bdd202cf5:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd202cfc:	59 00 00 
    733bdd202cff:	ba 46 00 01 00       	mov    edx,0x10046
    733bdd202d04:	b9 04 f0 00 00       	mov    ecx,0xf004
    733bdd202d09:	45 31 c0             	xor    r8d,r8d
    733bdd202d0c:	ff d0                	call   rax
    733bdd202d0e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202d15:	00 
    733bdd202d16:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202d1c:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd202d21:	b8 02 00 00 00       	mov    eax,0x2
    733bdd202d26:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd202d2d:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd202d34:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd202d3b:	e9 cc 10 00 00       	jmp    0x733bdd203e0c
    733bdd202d40:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd202d47:	00 
    733bdd202d48:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    733bdd202d4c:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    733bdd202d53:	00 
    733bdd202d54:	48 83 f8 00          	cmp    rax,0x0
    733bdd202d58:	74 14                	je     0x733bdd202d6e
    733bdd202d5a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd202d61:	00 
    733bdd202d62:	8b 40 04             	mov    eax,DWORD PTR [rax+0x4]
    733bdd202d65:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    733bdd202d6c:	eb 5b                	jmp    0x733bdd202dc9
    733bdd202d6e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202d75:	00 
    733bdd202d76:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd202d7d:	00 
    733bdd202d7e:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10046
    733bdd202d85:	00 01 00 
    733bdd202d88:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202d8f:	00 00 00 
    733bdd202d92:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd202d99:	00 00 00 
    733bdd202d9c:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd202da3:	59 00 00 
    733bdd202da6:	be 04 f0 00 00       	mov    esi,0xf004
    733bdd202dab:	ff d0                	call   rax
    733bdd202dad:	89 c1                	mov    ecx,eax
    733bdd202daf:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202db6:	00 
    733bdd202db7:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    733bdd202dbe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd202dc5:	75 1d                	jne    0x733bdd202de4
    733bdd202dc7:	eb 4d                	jmp    0x733bdd202e16
    733bdd202dc9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202dd0:	00 
    733bdd202dd1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd202dd8:	89 8c 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],ecx
    733bdd202ddf:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    733bdd202de2:	eb 42                	jmp    0x733bdd202e26
    733bdd202de4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202deb:	00 
    733bdd202dec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202df2:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd202df7:	b8 02 00 00 00       	mov    eax,0x2
    733bdd202dfc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd202e03:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd202e0a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd202e11:	e9 f6 0f 00 00       	jmp    0x733bdd203e0c
    733bdd202e16:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    733bdd202e1d:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    733bdd202e24:	eb a3                	jmp    0x733bdd202dc9
    733bdd202e26:	eb 00                	jmp    0x733bdd202e28
    733bdd202e28:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202e2f:	00 
    733bdd202e30:	c7 40 28 08 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf008
    733bdd202e37:	eb 00                	jmp    0x733bdd202e39
    733bdd202e39:	31 c0                	xor    eax,eax
    733bdd202e3b:	a8 01                	test   al,0x1
    733bdd202e3d:	75 02                	jne    0x733bdd202e41
    733bdd202e3f:	eb 7b                	jmp    0x733bdd202ebc
    733bdd202e41:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd202e48:	00 
    733bdd202e49:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd202e50:	00 
    733bdd202e51:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1004a
    733bdd202e58:	00 01 00 
    733bdd202e5b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd202e62:	00 00 00 
    733bdd202e65:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd202e6c:	00 00 00 
    733bdd202e6f:	31 c0                	xor    eax,eax
    733bdd202e71:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd202e78:	59 00 00 
    733bdd202e7b:	ba 4a 00 01 00       	mov    edx,0x1004a
    733bdd202e80:	b9 08 f0 00 00       	mov    ecx,0xf008
    733bdd202e85:	45 31 c0             	xor    r8d,r8d
    733bdd202e88:	ff d0                	call   rax
    733bdd202e8a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202e91:	00 
    733bdd202e92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202e98:	b9 05 00 00 00       	mov    ecx,0x5
    733bdd202e9d:	b8 02 00 00 00       	mov    eax,0x2
    733bdd202ea2:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd202ea9:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd202eb0:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd202eb7:	e9 50 0f 00 00       	jmp    0x733bdd203e0c
    733bdd202ebc:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd202ec3:	00 
    733bdd202ec4:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    733bdd202ec8:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    733bdd202ecf:	00 
    733bdd202ed0:	48 83 f8 00          	cmp    rax,0x0
    733bdd202ed4:	74 14                	je     0x733bdd202eea
    733bdd202ed6:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd202edd:	00 
    733bdd202ede:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    733bdd202ee1:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd202ee8:	eb 5b                	jmp    0x733bdd202f45
    733bdd202eea:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202ef1:	00 
    733bdd202ef2:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd202ef9:	00 
    733bdd202efa:	c7 80 bc 00 00 00 4a 	mov    DWORD PTR [rax+0xbc],0x1004a
    733bdd202f01:	00 01 00 
    733bdd202f04:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202f0b:	00 00 00 
    733bdd202f0e:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd202f15:	00 00 00 
    733bdd202f18:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd202f1f:	59 00 00 
    733bdd202f22:	be 08 f0 00 00       	mov    esi,0xf008
    733bdd202f27:	ff d0                	call   rax
    733bdd202f29:	89 c1                	mov    ecx,eax
    733bdd202f2b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202f32:	00 
    733bdd202f33:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    733bdd202f3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd202f41:	75 1d                	jne    0x733bdd202f60
    733bdd202f43:	eb 4d                	jmp    0x733bdd202f92
    733bdd202f45:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202f4c:	00 
    733bdd202f4d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd202f54:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    733bdd202f5b:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd202f5e:	eb 42                	jmp    0x733bdd202fa2
    733bdd202f60:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202f67:	00 
    733bdd202f68:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202f6e:	b9 05 00 00 00       	mov    ecx,0x5
    733bdd202f73:	b8 02 00 00 00       	mov    eax,0x2
    733bdd202f78:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd202f7f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd202f86:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd202f8d:	e9 7a 0e 00 00       	jmp    0x733bdd203e0c
    733bdd202f92:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [rsp+0xb8]
    733bdd202f99:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd202fa0:	eb a3                	jmp    0x733bdd202f45
    733bdd202fa2:	eb 00                	jmp    0x733bdd202fa4
    733bdd202fa4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202fab:	00 
    733bdd202fac:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    733bdd202fb2:	eb 00                	jmp    0x733bdd202fb4
    733bdd202fb4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202fbb:	00 
    733bdd202fbc:	c7 40 2c 05 3c 00 00 	mov    DWORD PTR [rax+0x2c],0x3c05
    733bdd202fc3:	eb 00                	jmp    0x733bdd202fc5
    733bdd202fc5:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202fcc:	00 
    733bdd202fcd:	c7 40 2c 14 f0 00 00 	mov    DWORD PTR [rax+0x2c],0xf014
    733bdd202fd4:	eb 00                	jmp    0x733bdd202fd6
    733bdd202fd6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd202fdd:	00 
    733bdd202fde:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    733bdd202fe1:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd202fe8:	83 c0 fc             	add    eax,0xfffffffc
    733bdd202feb:	89 84 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],eax
    733bdd202ff2:	83 e0 03             	and    eax,0x3
    733bdd202ff5:	83 f8 00             	cmp    eax,0x0
    733bdd202ff8:	74 7e                	je     0x733bdd203078
    733bdd202ffa:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203001:	00 
    733bdd203002:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd203009:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203010:	00 
    733bdd203011:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10054
    733bdd203018:	00 01 00 
    733bdd20301b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203022:	00 00 00 
    733bdd203025:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    733bdd20302c:	00 00 00 
    733bdd20302f:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203036:	59 00 00 
    733bdd203039:	ba 54 00 01 00       	mov    edx,0x10054
    733bdd20303e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd203044:	ff d0                	call   rax
    733bdd203046:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20304d:	00 
    733bdd20304e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203054:	b9 09 00 00 00       	mov    ecx,0x9
    733bdd203059:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20305e:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203065:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd20306c:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203073:	e9 94 0d 00 00       	jmp    0x733bdd203e0c
    733bdd203078:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd20307f:	00 
    733bdd203080:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd203087:	c1 e9 0c             	shr    ecx,0xc
    733bdd20308a:	89 c9                	mov    ecx,ecx
    733bdd20308c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd203090:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    733bdd203097:	00 
    733bdd203098:	48 83 f8 00          	cmp    rax,0x0
    733bdd20309c:	74 23                	je     0x733bdd2030c1
    733bdd20309e:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    733bdd2030a5:	00 
    733bdd2030a6:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd2030ad:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    733bdd2030b4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2030ba:	89 c9                	mov    ecx,ecx
    733bdd2030bc:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2030bf:	eb 5b                	jmp    0x733bdd20311c
    733bdd2030c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2030c8:	00 
    733bdd2030c9:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd2030d0:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    733bdd2030d7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd2030de:	00 
    733bdd2030df:	c7 80 bc 00 00 00 54 	mov    DWORD PTR [rax+0xbc],0x10054
    733bdd2030e6:	00 01 00 
    733bdd2030e9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2030f0:	00 00 00 
    733bdd2030f3:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    733bdd2030fa:	00 00 00 
    733bdd2030fd:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd203104:	59 00 00 
    733bdd203107:	ff d0                	call   rax
    733bdd203109:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203110:	00 
    733bdd203111:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203118:	75 11                	jne    0x733bdd20312b
    733bdd20311a:	eb 41                	jmp    0x733bdd20315d
    733bdd20311c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    733bdd203123:	00 
    733bdd203124:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd203127:	75 36                	jne    0x733bdd20315f
    733bdd203129:	eb 79                	jmp    0x733bdd2031a4
    733bdd20312b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203132:	00 
    733bdd203133:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203139:	b9 09 00 00 00       	mov    ecx,0x9
    733bdd20313e:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203143:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd20314a:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203151:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203158:	e9 af 0c 00 00       	jmp    0x733bdd203e0c
    733bdd20315d:	eb bd                	jmp    0x733bdd20311c
    733bdd20315f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203166:	00 
    733bdd203167:	c7 87 bc 00 00 00 56 	mov    DWORD PTR [rdi+0xbc],0x10056
    733bdd20316e:	00 01 00 
    733bdd203171:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203178:	00 00 00 
    733bdd20317b:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    733bdd203182:	00 00 00 
    733bdd203185:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20318c:	59 00 00 
    733bdd20318f:	ff d0                	call   rax
    733bdd203191:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203198:	00 
    733bdd203199:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2031a0:	75 04                	jne    0x733bdd2031a6
    733bdd2031a2:	eb 34                	jmp    0x733bdd2031d8
    733bdd2031a4:	eb 34                	jmp    0x733bdd2031da
    733bdd2031a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2031ad:	00 
    733bdd2031ae:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2031b4:	b9 09 00 00 00       	mov    ecx,0x9
    733bdd2031b9:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2031be:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd2031c5:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd2031cc:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd2031d3:	e9 34 0c 00 00       	jmp    0x733bdd203e0c
    733bdd2031d8:	eb ca                	jmp    0x733bdd2031a4
    733bdd2031da:	eb 00                	jmp    0x733bdd2031dc
    733bdd2031dc:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2031e3:	00 
    733bdd2031e4:	c7 40 28 03 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c03
    733bdd2031eb:	eb 00                	jmp    0x733bdd2031ed
    733bdd2031ed:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2031f4:	00 
    733bdd2031f5:	c7 40 28 0c f0 00 00 	mov    DWORD PTR [rax+0x28],0xf00c
    733bdd2031fc:	eb 00                	jmp    0x733bdd2031fe
    733bdd2031fe:	31 c0                	xor    eax,eax
    733bdd203200:	a8 01                	test   al,0x1
    733bdd203202:	75 02                	jne    0x733bdd203206
    733bdd203204:	eb 7b                	jmp    0x733bdd203281
    733bdd203206:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd20320d:	00 
    733bdd20320e:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203215:	00 
    733bdd203216:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1005c
    733bdd20321d:	00 01 00 
    733bdd203220:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203227:	00 00 00 
    733bdd20322a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    733bdd203231:	00 00 00 
    733bdd203234:	31 c0                	xor    eax,eax
    733bdd203236:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20323d:	59 00 00 
    733bdd203240:	ba 5c 00 01 00       	mov    edx,0x1005c
    733bdd203245:	b9 0c f0 00 00       	mov    ecx,0xf00c
    733bdd20324a:	45 31 c0             	xor    r8d,r8d
    733bdd20324d:	ff d0                	call   rax
    733bdd20324f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203256:	00 
    733bdd203257:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20325d:	b9 0c 00 00 00       	mov    ecx,0xc
    733bdd203262:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203267:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd20326e:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203275:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd20327c:	e9 8b 0b 00 00       	jmp    0x733bdd203e0c
    733bdd203281:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd203288:	00 
    733bdd203289:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    733bdd20328d:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd203294:	00 
    733bdd203295:	48 83 f8 00          	cmp    rax,0x0
    733bdd203299:	74 14                	je     0x733bdd2032af
    733bdd20329b:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd2032a2:	00 
    733bdd2032a3:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    733bdd2032a6:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd2032ad:	eb 5b                	jmp    0x733bdd20330a
    733bdd2032af:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2032b6:	00 
    733bdd2032b7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd2032be:	00 
    733bdd2032bf:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1005c
    733bdd2032c6:	00 01 00 
    733bdd2032c9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2032d0:	00 00 00 
    733bdd2032d3:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    733bdd2032da:	00 00 00 
    733bdd2032dd:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2032e4:	59 00 00 
    733bdd2032e7:	be 0c f0 00 00       	mov    esi,0xf00c
    733bdd2032ec:	ff d0                	call   rax
    733bdd2032ee:	89 c1                	mov    ecx,eax
    733bdd2032f0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2032f7:	00 
    733bdd2032f8:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    733bdd2032ff:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203306:	75 1d                	jne    0x733bdd203325
    733bdd203308:	eb 4d                	jmp    0x733bdd203357
    733bdd20330a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203311:	00 
    733bdd203312:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd203319:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd203320:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd203323:	eb 42                	jmp    0x733bdd203367
    733bdd203325:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20332c:	00 
    733bdd20332d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203333:	b9 0c 00 00 00       	mov    ecx,0xc
    733bdd203338:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20333d:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203344:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd20334b:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203352:	e9 b5 0a 00 00       	jmp    0x733bdd203e0c
    733bdd203357:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    733bdd20335e:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd203365:	eb a3                	jmp    0x733bdd20330a
    733bdd203367:	eb 00                	jmp    0x733bdd203369
    733bdd203369:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203370:	00 
    733bdd203371:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    733bdd203374:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20337a:	83 c9 00             	or     ecx,0x0
    733bdd20337d:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    733bdd203384:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    733bdd203387:	eb 00                	jmp    0x733bdd203389
    733bdd203389:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203390:	00 
    733bdd203391:	8b 48 30             	mov    ecx,DWORD PTR [rax+0x30]
    733bdd203394:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20339a:	81 c9 00 00 00 01    	or     ecx,0x1000000
    733bdd2033a0:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    733bdd2033a7:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    733bdd2033aa:	eb 00                	jmp    0x733bdd2033ac
    733bdd2033ac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2033b3:	00 
    733bdd2033b4:	8b 8c 24 88 00 00 00 	mov    ecx,DWORD PTR [rsp+0x88]
    733bdd2033bb:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2033c1:	81 c9 18 f0 00 00    	or     ecx,0xf018
    733bdd2033c7:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    733bdd2033ca:	eb 00                	jmp    0x733bdd2033cc
    733bdd2033cc:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    733bdd2033d3:	83 c0 f8             	add    eax,0xfffffff8
    733bdd2033d6:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    733bdd2033dd:	83 e0 03             	and    eax,0x3
    733bdd2033e0:	83 f8 00             	cmp    eax,0x0
    733bdd2033e3:	74 7e                	je     0x733bdd203463
    733bdd2033e5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd2033ec:	00 
    733bdd2033ed:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd2033f4:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd2033fb:	00 
    733bdd2033fc:	c7 87 bc 00 00 00 6a 	mov    DWORD PTR [rdi+0xbc],0x1006a
    733bdd203403:	00 01 00 
    733bdd203406:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20340d:	00 00 00 
    733bdd203410:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    733bdd203417:	00 00 00 
    733bdd20341a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203421:	59 00 00 
    733bdd203424:	ba 6a 00 01 00       	mov    edx,0x1006a
    733bdd203429:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20342f:	ff d0                	call   rax
    733bdd203431:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203438:	00 
    733bdd203439:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20343f:	b9 10 00 00 00       	mov    ecx,0x10
    733bdd203444:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203449:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203450:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203457:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd20345e:	e9 a9 09 00 00       	jmp    0x733bdd203e0c
    733bdd203463:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd20346a:	00 
    733bdd20346b:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd203472:	c1 e9 0c             	shr    ecx,0xc
    733bdd203475:	89 c9                	mov    ecx,ecx
    733bdd203477:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20347b:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd203480:	48 83 f8 00          	cmp    rax,0x0
    733bdd203484:	74 20                	je     0x733bdd2034a6
    733bdd203486:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd20348b:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    733bdd203492:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    733bdd203499:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20349f:	89 c9                	mov    ecx,ecx
    733bdd2034a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2034a4:	eb 5b                	jmp    0x733bdd203501
    733bdd2034a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2034ad:	00 
    733bdd2034ae:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    733bdd2034b5:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    733bdd2034bc:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd2034c3:	00 
    733bdd2034c4:	c7 80 bc 00 00 00 6a 	mov    DWORD PTR [rax+0xbc],0x1006a
    733bdd2034cb:	00 01 00 
    733bdd2034ce:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2034d5:	00 00 00 
    733bdd2034d8:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    733bdd2034df:	00 00 00 
    733bdd2034e2:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2034e9:	59 00 00 
    733bdd2034ec:	ff d0                	call   rax
    733bdd2034ee:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2034f5:	00 
    733bdd2034f6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2034fd:	75 11                	jne    0x733bdd203510
    733bdd2034ff:	eb 41                	jmp    0x733bdd203542
    733bdd203501:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    733bdd203508:	00 
    733bdd203509:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd20350c:	75 36                	jne    0x733bdd203544
    733bdd20350e:	eb 79                	jmp    0x733bdd203589
    733bdd203510:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203517:	00 
    733bdd203518:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20351e:	b9 10 00 00 00       	mov    ecx,0x10
    733bdd203523:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203528:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd20352f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203536:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd20353d:	e9 ca 08 00 00       	jmp    0x733bdd203e0c
    733bdd203542:	eb bd                	jmp    0x733bdd203501
    733bdd203544:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd20354b:	00 
    733bdd20354c:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1006c
    733bdd203553:	00 01 00 
    733bdd203556:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20355d:	00 00 00 
    733bdd203560:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    733bdd203567:	00 00 00 
    733bdd20356a:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd203571:	59 00 00 
    733bdd203574:	ff d0                	call   rax
    733bdd203576:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20357d:	00 
    733bdd20357e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203585:	75 04                	jne    0x733bdd20358b
    733bdd203587:	eb 34                	jmp    0x733bdd2035bd
    733bdd203589:	eb 34                	jmp    0x733bdd2035bf
    733bdd20358b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203592:	00 
    733bdd203593:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203599:	b9 10 00 00 00       	mov    ecx,0x10
    733bdd20359e:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2035a3:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd2035aa:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd2035b1:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd2035b8:	e9 4f 08 00 00       	jmp    0x733bdd203e0c
    733bdd2035bd:	eb ca                	jmp    0x733bdd203589
    733bdd2035bf:	eb 00                	jmp    0x733bdd2035c1
    733bdd2035c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2035c8:	00 
    733bdd2035c9:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd2035d0:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd2035d6:	83 c9 00             	or     ecx,0x0
    733bdd2035d9:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    733bdd2035dd:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2035e0:	eb 00                	jmp    0x733bdd2035e2
    733bdd2035e2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2035e9:	00 
    733bdd2035ea:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd2035ee:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2035f4:	81 c9 10 f0 00 00    	or     ecx,0xf010
    733bdd2035fa:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd2035fe:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd203601:	eb 00                	jmp    0x733bdd203603
    733bdd203603:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    733bdd203607:	83 e0 03             	and    eax,0x3
    733bdd20360a:	83 f8 00             	cmp    eax,0x0
    733bdd20360d:	74 7b                	je     0x733bdd20368a
    733bdd20360f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203616:	00 
    733bdd203617:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd20361b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203622:	00 
    733bdd203623:	c7 87 bc 00 00 00 74 	mov    DWORD PTR [rdi+0xbc],0x10074
    733bdd20362a:	00 01 00 
    733bdd20362d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203634:	00 00 00 
    733bdd203637:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    733bdd20363e:	00 00 00 
    733bdd203641:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203648:	59 00 00 
    733bdd20364b:	ba 74 00 01 00       	mov    edx,0x10074
    733bdd203650:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd203656:	ff d0                	call   rax
    733bdd203658:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20365f:	00 
    733bdd203660:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203666:	b9 13 00 00 00       	mov    ecx,0x13
    733bdd20366b:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203670:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203677:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd20367e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203685:	e9 82 07 00 00       	jmp    0x733bdd203e0c
    733bdd20368a:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd203691:	00 
    733bdd203692:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd203696:	c1 e9 0c             	shr    ecx,0xc
    733bdd203699:	89 c9                	mov    ecx,ecx
    733bdd20369b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20369f:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd2036a4:	48 83 f8 00          	cmp    rax,0x0
    733bdd2036a8:	74 1a                	je     0x733bdd2036c4
    733bdd2036aa:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2036af:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd2036b3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2036b9:	89 c9                	mov    ecx,ecx
    733bdd2036bb:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    733bdd2036c2:	eb 56                	jmp    0x733bdd20371a
    733bdd2036c4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2036cb:	00 
    733bdd2036cc:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    733bdd2036d0:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd2036d7:	00 
    733bdd2036d8:	c7 80 bc 00 00 00 74 	mov    DWORD PTR [rax+0xbc],0x10074
    733bdd2036df:	00 01 00 
    733bdd2036e2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2036e9:	00 00 00 
    733bdd2036ec:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    733bdd2036f3:	00 00 00 
    733bdd2036f6:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2036fd:	59 00 00 
    733bdd203700:	ba 01 00 00 00       	mov    edx,0x1
    733bdd203705:	ff d0                	call   rax
    733bdd203707:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20370e:	00 
    733bdd20370f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203716:	75 11                	jne    0x733bdd203729
    733bdd203718:	eb 41                	jmp    0x733bdd20375b
    733bdd20371a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    733bdd203721:	00 
    733bdd203722:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd203725:	75 36                	jne    0x733bdd20375d
    733bdd203727:	eb 79                	jmp    0x733bdd2037a2
    733bdd203729:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203730:	00 
    733bdd203731:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203737:	b9 13 00 00 00       	mov    ecx,0x13
    733bdd20373c:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203741:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203748:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd20374f:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203756:	e9 b1 06 00 00       	jmp    0x733bdd203e0c
    733bdd20375b:	eb bd                	jmp    0x733bdd20371a
    733bdd20375d:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203764:	00 
    733bdd203765:	c7 87 bc 00 00 00 76 	mov    DWORD PTR [rdi+0xbc],0x10076
    733bdd20376c:	00 01 00 
    733bdd20376f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203776:	00 00 00 
    733bdd203779:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    733bdd203780:	00 00 00 
    733bdd203783:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20378a:	59 00 00 
    733bdd20378d:	ff d0                	call   rax
    733bdd20378f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203796:	00 
    733bdd203797:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20379e:	75 04                	jne    0x733bdd2037a4
    733bdd2037a0:	eb 34                	jmp    0x733bdd2037d6
    733bdd2037a2:	eb 34                	jmp    0x733bdd2037d8
    733bdd2037a4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2037ab:	00 
    733bdd2037ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2037b2:	b9 13 00 00 00       	mov    ecx,0x13
    733bdd2037b7:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2037bc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd2037c3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd2037ca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd2037d1:	e9 36 06 00 00       	jmp    0x733bdd203e0c
    733bdd2037d6:	eb ca                	jmp    0x733bdd2037a2
    733bdd2037d8:	eb 00                	jmp    0x733bdd2037da
    733bdd2037da:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2037e1:	00 
    733bdd2037e2:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    733bdd2037e8:	eb 00                	jmp    0x733bdd2037ea
    733bdd2037ea:	31 c0                	xor    eax,eax
    733bdd2037ec:	a8 01                	test   al,0x1
    733bdd2037ee:	75 02                	jne    0x733bdd2037f2
    733bdd2037f0:	eb 7c                	jmp    0x733bdd20386e
    733bdd2037f2:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd2037f9:	00 
    733bdd2037fa:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203801:	00 
    733bdd203802:	c7 87 bc 00 00 00 78 	mov    DWORD PTR [rdi+0xbc],0x10078
    733bdd203809:	00 01 00 
    733bdd20380c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203813:	00 00 00 
    733bdd203816:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    733bdd20381d:	00 00 00 
    733bdd203820:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203827:	59 00 00 
    733bdd20382a:	ba 78 00 01 00       	mov    edx,0x10078
    733bdd20382f:	b9 14 f0 00 00       	mov    ecx,0xf014
    733bdd203834:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20383a:	ff d0                	call   rax
    733bdd20383c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203843:	00 
    733bdd203844:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20384a:	b9 15 00 00 00       	mov    ecx,0x15
    733bdd20384f:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203854:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd20385b:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203862:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203869:	e9 9e 05 00 00       	jmp    0x733bdd203e0c
    733bdd20386e:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd203875:	00 
    733bdd203876:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    733bdd20387a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    733bdd20387f:	48 83 f8 00          	cmp    rax,0x0
    733bdd203883:	74 0e                	je     0x733bdd203893
    733bdd203885:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    733bdd20388a:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    733bdd203891:	eb 56                	jmp    0x733bdd2038e9
    733bdd203893:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20389a:	00 
    733bdd20389b:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd2038a2:	00 
    733bdd2038a3:	c7 80 bc 00 00 00 78 	mov    DWORD PTR [rax+0xbc],0x10078
    733bdd2038aa:	00 01 00 
    733bdd2038ad:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2038b4:	00 00 00 
    733bdd2038b7:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    733bdd2038be:	00 00 00 
    733bdd2038c1:	31 c0                	xor    eax,eax
    733bdd2038c3:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2038ca:	59 00 00 
    733bdd2038cd:	be 14 f0 00 00       	mov    esi,0xf014
    733bdd2038d2:	31 d2                	xor    edx,edx
    733bdd2038d4:	ff d0                	call   rax
    733bdd2038d6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2038dd:	00 
    733bdd2038de:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2038e5:	75 11                	jne    0x733bdd2038f8
    733bdd2038e7:	eb 41                	jmp    0x733bdd20392a
    733bdd2038e9:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    733bdd2038f0:	00 
    733bdd2038f1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2038f4:	75 36                	jne    0x733bdd20392c
    733bdd2038f6:	eb 79                	jmp    0x733bdd203971
    733bdd2038f8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2038ff:	00 
    733bdd203900:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203906:	b9 15 00 00 00       	mov    ecx,0x15
    733bdd20390b:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203910:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203917:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd20391e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203925:	e9 e2 04 00 00       	jmp    0x733bdd203e0c
    733bdd20392a:	eb bd                	jmp    0x733bdd2038e9
    733bdd20392c:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203933:	00 
    733bdd203934:	c7 87 bc 00 00 00 7a 	mov    DWORD PTR [rdi+0xbc],0x1007a
    733bdd20393b:	00 01 00 
    733bdd20393e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203945:	00 00 00 
    733bdd203948:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    733bdd20394f:	00 00 00 
    733bdd203952:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd203959:	59 00 00 
    733bdd20395c:	ff d0                	call   rax
    733bdd20395e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203965:	00 
    733bdd203966:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20396d:	75 04                	jne    0x733bdd203973
    733bdd20396f:	eb 34                	jmp    0x733bdd2039a5
    733bdd203971:	eb 34                	jmp    0x733bdd2039a7
    733bdd203973:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20397a:	00 
    733bdd20397b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203981:	b9 15 00 00 00       	mov    ecx,0x15
    733bdd203986:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20398b:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203992:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203999:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd2039a0:	e9 67 04 00 00       	jmp    0x733bdd203e0c
    733bdd2039a5:	eb ca                	jmp    0x733bdd203971
    733bdd2039a7:	eb 00                	jmp    0x733bdd2039a9
    733bdd2039a9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2039b0:	00 
    733bdd2039b1:	c7 40 1c 00 00 00 00 	mov    DWORD PTR [rax+0x1c],0x0
    733bdd2039b8:	eb 00                	jmp    0x733bdd2039ba
    733bdd2039ba:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2039c1:	00 
    733bdd2039c2:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd2039c9:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2039cf:	83 c9 00             	or     ecx,0x0
    733bdd2039d2:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    733bdd2039d5:	eb 00                	jmp    0x733bdd2039d7
    733bdd2039d7:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2039de:	00 
    733bdd2039df:	c7 40 18 00 00 00 00 	mov    DWORD PTR [rax+0x18],0x0
    733bdd2039e6:	eb 00                	jmp    0x733bdd2039e8
    733bdd2039e8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd2039ef:	00 
    733bdd2039f0:	c7 40 14 01 00 00 00 	mov    DWORD PTR [rax+0x14],0x1
    733bdd2039f7:	eb 00                	jmp    0x733bdd2039f9
    733bdd2039f9:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    733bdd203a00:	83 c0 fc             	add    eax,0xfffffffc
    733bdd203a03:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd203a07:	83 e0 03             	and    eax,0x3
    733bdd203a0a:	83 f8 00             	cmp    eax,0x0
    733bdd203a0d:	74 7a                	je     0x733bdd203a89
    733bdd203a0f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203a16:	00 
    733bdd203a17:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd203a1b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203a22:	00 
    733bdd203a23:	c7 87 bc 00 00 00 84 	mov    DWORD PTR [rdi+0xbc],0x10084
    733bdd203a2a:	00 01 00 
    733bdd203a2d:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    733bdd203a34:	00 00 00 
    733bdd203a37:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd203a3e:	00 00 00 
    733bdd203a41:	31 c0                	xor    eax,eax
    733bdd203a43:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203a4a:	59 00 00 
    733bdd203a4d:	ba 84 00 01 00       	mov    edx,0x10084
    733bdd203a52:	45 31 c0             	xor    r8d,r8d
    733bdd203a55:	ff d0                	call   rax
    733bdd203a57:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203a5e:	00 
    733bdd203a5f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203a65:	b9 1a 00 00 00       	mov    ecx,0x1a
    733bdd203a6a:	b8 08 00 00 00       	mov    eax,0x8
    733bdd203a6f:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203a76:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203a7d:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203a84:	e9 83 03 00 00       	jmp    0x733bdd203e0c
    733bdd203a89:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd203a90:	00 
    733bdd203a91:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd203a95:	c1 e9 0c             	shr    ecx,0xc
    733bdd203a98:	89 c9                	mov    ecx,ecx
    733bdd203a9a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd203a9e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd203aa3:	48 83 f8 00          	cmp    rax,0x0
    733bdd203aa7:	74 1a                	je     0x733bdd203ac3
    733bdd203aa9:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd203aae:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd203ab2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd203ab8:	89 c9                	mov    ecx,ecx
    733bdd203aba:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd203abd:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd203ac1:	eb 57                	jmp    0x733bdd203b1a
    733bdd203ac3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203aca:	00 
    733bdd203acb:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    733bdd203acf:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd203ad6:	00 
    733bdd203ad7:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    733bdd203ade:	00 01 00 
    733bdd203ae1:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    733bdd203ae8:	00 00 00 
    733bdd203aeb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd203af2:	00 00 00 
    733bdd203af5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd203afc:	59 00 00 
    733bdd203aff:	ff d0                	call   rax
    733bdd203b01:	89 c1                	mov    ecx,eax
    733bdd203b03:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203b0a:	00 
    733bdd203b0b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd203b0f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203b16:	75 1c                	jne    0x733bdd203b34
    733bdd203b18:	eb 4c                	jmp    0x733bdd203b66
    733bdd203b1a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203b21:	00 
    733bdd203b22:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    733bdd203b29:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd203b2d:	89 10                	mov    DWORD PTR [rax],edx
    733bdd203b2f:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd203b32:	eb 3c                	jmp    0x733bdd203b70
    733bdd203b34:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203b3b:	00 
    733bdd203b3c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203b42:	b9 1a 00 00 00       	mov    ecx,0x1a
    733bdd203b47:	b8 08 00 00 00       	mov    eax,0x8
    733bdd203b4c:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203b53:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203b5a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203b61:	e9 a6 02 00 00       	jmp    0x733bdd203e0c
    733bdd203b66:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd203b6a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd203b6e:	eb aa                	jmp    0x733bdd203b1a
    733bdd203b70:	eb 00                	jmp    0x733bdd203b72
    733bdd203b72:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    733bdd203b79:	83 c0 f8             	add    eax,0xfffffff8
    733bdd203b7c:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd203b80:	83 e0 03             	and    eax,0x3
    733bdd203b83:	83 f8 00             	cmp    eax,0x0
    733bdd203b86:	74 7a                	je     0x733bdd203c02
    733bdd203b88:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    733bdd203b8f:	00 
    733bdd203b90:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd203b94:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    733bdd203b9b:	00 
    733bdd203b9c:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    733bdd203ba3:	00 01 00 
    733bdd203ba6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd203bad:	00 00 00 
    733bdd203bb0:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    733bdd203bb7:	00 00 00 
    733bdd203bba:	31 c0                	xor    eax,eax
    733bdd203bbc:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd203bc3:	59 00 00 
    733bdd203bc6:	ba 8c 00 01 00       	mov    edx,0x1008c
    733bdd203bcb:	45 31 c0             	xor    r8d,r8d
    733bdd203bce:	ff d0                	call   rax
    733bdd203bd0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203bd7:	00 
    733bdd203bd8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203bde:	b9 1b 00 00 00       	mov    ecx,0x1b
    733bdd203be3:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203be8:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203bef:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203bf6:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203bfd:	e9 0a 02 00 00       	jmp    0x733bdd203e0c
    733bdd203c02:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    733bdd203c09:	00 
    733bdd203c0a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd203c0e:	c1 e9 0c             	shr    ecx,0xc
    733bdd203c11:	89 c9                	mov    ecx,ecx
    733bdd203c13:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd203c17:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd203c1c:	48 83 f8 00          	cmp    rax,0x0
    733bdd203c20:	74 1a                	je     0x733bdd203c3c
    733bdd203c22:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd203c27:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd203c2b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd203c31:	89 c9                	mov    ecx,ecx
    733bdd203c33:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd203c36:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd203c3a:	eb 57                	jmp    0x733bdd203c93
    733bdd203c3c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203c43:	00 
    733bdd203c44:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd203c48:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd203c4f:	00 
    733bdd203c50:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    733bdd203c57:	00 01 00 
    733bdd203c5a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd203c61:	00 00 00 
    733bdd203c64:	c7 80 34 01 00 00 1b 	mov    DWORD PTR [rax+0x134],0x1b
    733bdd203c6b:	00 00 00 
    733bdd203c6e:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd203c75:	59 00 00 
    733bdd203c78:	ff d0                	call   rax
    733bdd203c7a:	89 c1                	mov    ecx,eax
    733bdd203c7c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203c83:	00 
    733bdd203c84:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd203c88:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd203c8f:	75 13                	jne    0x733bdd203ca4
    733bdd203c91:	eb 43                	jmp    0x733bdd203cd6
    733bdd203c93:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203c9a:	00 
    733bdd203c9b:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    733bdd203c9f:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    733bdd203ca2:	eb 3c                	jmp    0x733bdd203ce0
    733bdd203ca4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203cab:	00 
    733bdd203cac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd203cb2:	b9 1b 00 00 00       	mov    ecx,0x1b
    733bdd203cb7:	b8 02 00 00 00       	mov    eax,0x2
    733bdd203cbc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    733bdd203cc3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    733bdd203cca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    733bdd203cd1:	e9 36 01 00 00       	jmp    0x733bdd203e0c
    733bdd203cd6:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd203cda:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd203cde:	eb b3                	jmp    0x733bdd203c93
    733bdd203ce0:	eb 00                	jmp    0x733bdd203ce2
    733bdd203ce2:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    733bdd203ce9:	00 
    733bdd203cea:	8b b4 24 f0 00 00 00 	mov    esi,DWORD PTR [rsp+0xf0]
    733bdd203cf1:	8b 84 24 ec 00 00 00 	mov    eax,DWORD PTR [rsp+0xec]
    733bdd203cf8:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd203cfe:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd203d04:	83 ff 01             	cmp    edi,0x1
    733bdd203d07:	0f 97 c3             	seta   bl
    733bdd203d0a:	3d 8e 00 01 00       	cmp    eax,0x1008e
    733bdd203d0f:	0f 94 c0             	sete   al
    733bdd203d12:	20 c3                	and    bl,al
    733bdd203d14:	b8 92 00 01 00       	mov    eax,0x10092
    733bdd203d19:	f6 c3 01             	test   bl,0x1
    733bdd203d1c:	0f 45 c2             	cmovne eax,edx
    733bdd203d1f:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd203d25:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd203d2b:	83 ff 01             	cmp    edi,0x1
    733bdd203d2e:	0f 97 c3             	seta   bl
    733bdd203d31:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    733bdd203d37:	40 0f 94 c6          	sete   sil
    733bdd203d3b:	40 20 f3             	and    bl,sil
    733bdd203d3e:	f6 c3 01             	test   bl,0x1
    733bdd203d41:	0f 45 c2             	cmovne eax,edx
    733bdd203d44:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd203d4a:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    733bdd203d51:	03 01 00 
    733bdd203d54:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd203d5a:	83 c0 1c             	add    eax,0x1c
    733bdd203d5d:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd203d61:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd203d67:	72 16                	jb     0x733bdd203d7f
    733bdd203d69:	eb 37                	jmp    0x733bdd203da2
    733bdd203d6b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203d72:	00 
    733bdd203d73:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd203d7a:	e9 4a 01 00 00       	jmp    0x733bdd203ec9
    733bdd203d7f:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd203d86:	00 
    733bdd203d87:	48 89 c1             	mov    rcx,rax
    733bdd203d8a:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    733bdd203d91:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd203d96:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    733bdd203d9d:	03 01 00 
    733bdd203da0:	74 32                	je     0x733bdd203dd4
    733bdd203da2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203da9:	00 
    733bdd203daa:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    733bdd203db1:	03 01 00 
    733bdd203db4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd203dbb:	00 00 00 
    733bdd203dbe:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    733bdd203dc5:	00 00 00 
    733bdd203dc8:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd203dcf:	e9 f5 00 00 00       	jmp    0x733bdd203ec9
    733bdd203dd4:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    733bdd203ddb:	00 
    733bdd203ddc:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    733bdd203de3:	00 
    733bdd203de4:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd203de9:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    733bdd203ded:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    733bdd203df4:	28 03 01 00 
    733bdd203df8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd203dff:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd203e03:	48 81 c4 28 01 00 00 	add    rsp,0x128
    733bdd203e0a:	ff e0                	jmp    rax
    733bdd203e0c:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    733bdd203e13:	00 
    733bdd203e14:	8b 94 24 e0 00 00 00 	mov    edx,DWORD PTR [rsp+0xe0]
    733bdd203e1b:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    733bdd203e22:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    733bdd203e29:	89 c7                	mov    edi,eax
    733bdd203e2b:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd203e2f:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd203e33:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd203e37:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd203e3d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd203e41:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd203e47:	73 2d                	jae    0x733bdd203e76
    733bdd203e49:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd203e50:	00 
    733bdd203e51:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd203e55:	89 d1                	mov    ecx,edx
    733bdd203e57:	c1 e9 01             	shr    ecx,0x1
    733bdd203e5a:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd203e60:	89 c9                	mov    ecx,ecx
    733bdd203e62:	48 c1 e1 04          	shl    rcx,0x4
    733bdd203e66:	48 89 c6             	mov    rsi,rax
    733bdd203e69:	48 01 ce             	add    rsi,rcx
    733bdd203e6c:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd203e71:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd203e74:	74 1e                	je     0x733bdd203e94
    733bdd203e76:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd203e7d:	00 
    733bdd203e7e:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd203e82:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd203e86:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd203e8c:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd203e92:	eb 35                	jmp    0x733bdd203ec9
    733bdd203e94:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    733bdd203e9b:	00 
    733bdd203e9c:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    733bdd203ea3:	00 
    733bdd203ea4:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd203ea9:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd203ead:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd203eb4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd203ebb:	00 
    733bdd203ebc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd203ec0:	48 81 c4 28 01 00 00 	add    rsp,0x128
    733bdd203ec7:	ff e0                	jmp    rax
    733bdd203ec9:	48 81 c4 28 01 00 00 	add    rsp,0x128
    733bdd203ed0:	c2 08 00             	ret    0x8
