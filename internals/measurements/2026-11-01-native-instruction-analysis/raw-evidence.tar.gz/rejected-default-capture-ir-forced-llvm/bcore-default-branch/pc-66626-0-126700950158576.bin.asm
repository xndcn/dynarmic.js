
build-native-instruction-analysis/capture/bcore-default-branch/pc-66626-0-126700950158576.bin:     file format binary


Disassembly of section .data:

0000733bdd207cf0 <.data>:
    733bdd207cf0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    733bdd207cf7:	4c 89 74 24 68       	mov    QWORD PTR [rsp+0x68],r14
    733bdd207cfc:	4c 89 6c 24 70       	mov    QWORD PTR [rsp+0x70],r13
    733bdd207d01:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd207d08:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd207d0d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd207d14:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd207d1b:	00 
    733bdd207d1c:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    733bdd207d21:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd207d27:	83 fa 00             	cmp    edx,0x0
    733bdd207d2a:	0f 94 c0             	sete   al
    733bdd207d2d:	81 ea 42 04 01 00    	sub    edx,0x10442
    733bdd207d33:	83 fa 0c             	cmp    edx,0xc
    733bdd207d36:	0f 97 c2             	seta   dl
    733bdd207d39:	08 d0                	or     al,dl
    733bdd207d3b:	24 01                	and    al,0x1
    733bdd207d3d:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd207d43:	83 fa 00             	cmp    edx,0x0
    733bdd207d46:	0f 94 c1             	sete   cl
    733bdd207d49:	81 ea 42 04 01 00    	sub    edx,0x10442
    733bdd207d4f:	83 fa 0c             	cmp    edx,0xc
    733bdd207d52:	0f 97 c2             	seta   dl
    733bdd207d55:	08 d1                	or     cl,dl
    733bdd207d57:	20 c8                	and    al,cl
    733bdd207d59:	a8 01                	test   al,0x1
    733bdd207d5b:	75 05                	jne    0x733bdd207d62
    733bdd207d5d:	e9 d6 02 00 00       	jmp    0x733bdd208038
    733bdd207d62:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207d67:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd207d6e:	48 89 c8             	mov    rax,rcx
    733bdd207d71:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd207d77:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    733bdd207d7c:	8b 81 18 00 10 00    	mov    eax,DWORD PTR [rcx+0x100018]
    733bdd207d82:	83 c0 01             	add    eax,0x1
    733bdd207d85:	89 81 18 00 10 00    	mov    DWORD PTR [rcx+0x100018],eax
    733bdd207d8b:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd207d90:	75 40                	jne    0x733bdd207dd2
    733bdd207d92:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    733bdd207d97:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd207d9d:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd207da1:	89 c2                	mov    edx,eax
    733bdd207da3:	83 c2 01             	add    edx,0x1
    733bdd207da6:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd207dac:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd207db1:	73 1d                	jae    0x733bdd207dd0
    733bdd207db3:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    733bdd207db8:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd207dbc:	89 c9                	mov    ecx,ecx
    733bdd207dbe:	48 c1 e1 02          	shl    rcx,0x2
    733bdd207dc2:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd207dc9:	c7 04 08 06 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x6
    733bdd207dd0:	eb 00                	jmp    0x733bdd207dd2
    733bdd207dd2:	eb 00                	jmp    0x733bdd207dd4
    733bdd207dd4:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207dd9:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    733bdd207ddc:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd207de2:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd207de8:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    733bdd207dec:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    733bdd207def:	eb 00                	jmp    0x733bdd207df1
    733bdd207df1:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207df6:	8b 4c 24 58          	mov    ecx,DWORD PTR [rsp+0x58]
    733bdd207dfa:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd207e00:	81 c9 9c 11 00 00    	or     ecx,0x119c
    733bdd207e06:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    733bdd207e0a:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    733bdd207e0d:	eb 00                	jmp    0x733bdd207e0f
    733bdd207e0f:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207e14:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd207e18:	8b 50 28             	mov    edx,DWORD PTR [rax+0x28]
    733bdd207e1b:	c1 e2 02             	shl    edx,0x2
    733bdd207e1e:	01 d1                	add    ecx,edx
    733bdd207e20:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd207e24:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd207e27:	eb 00                	jmp    0x733bdd207e29
    733bdd207e29:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    733bdd207e2d:	83 e0 03             	and    eax,0x3
    733bdd207e30:	83 f8 00             	cmp    eax,0x0
    733bdd207e33:	74 7c                	je     0x733bdd207eb1
    733bdd207e35:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    733bdd207e3a:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    733bdd207e3e:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    733bdd207e43:	c7 87 bc 00 00 00 4c 	mov    DWORD PTR [rdi+0xbc],0x1044c
    733bdd207e4a:	04 01 00 
    733bdd207e4d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd207e54:	00 00 00 
    733bdd207e57:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    733bdd207e5e:	00 00 00 
    733bdd207e61:	31 c0                	xor    eax,eax
    733bdd207e63:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd207e6a:	59 00 00 
    733bdd207e6d:	ba 4c 04 01 00       	mov    edx,0x1044c
    733bdd207e72:	45 31 c0             	xor    r8d,r8d
    733bdd207e75:	ff d0                	call   rax
    733bdd207e77:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207e7c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207e82:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207e88:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207e8e:	be 04 00 00 00       	mov    esi,0x4
    733bdd207e93:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207e98:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    733bdd207e9c:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    733bdd207ea0:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    733bdd207ea4:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd207ea8:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    733bdd207eac:	e9 98 01 00 00       	jmp    0x733bdd208049
    733bdd207eb1:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd207eb8:	00 
    733bdd207eb9:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    733bdd207ebd:	c1 e9 0c             	shr    ecx,0xc
    733bdd207ec0:	89 c9                	mov    ecx,ecx
    733bdd207ec2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd207ec6:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    733bdd207ecb:	48 83 f8 00          	cmp    rax,0x0
    733bdd207ecf:	74 1a                	je     0x733bdd207eeb
    733bdd207ed1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd207ed6:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    733bdd207eda:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd207ee0:	89 c9                	mov    ecx,ecx
    733bdd207ee2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd207ee5:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd207ee9:	eb 4e                	jmp    0x733bdd207f39
    733bdd207eeb:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207ef0:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    733bdd207ef4:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    733bdd207ef9:	c7 80 bc 00 00 00 4c 	mov    DWORD PTR [rax+0xbc],0x1044c
    733bdd207f00:	04 01 00 
    733bdd207f03:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd207f0a:	00 00 00 
    733bdd207f0d:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    733bdd207f14:	00 00 00 
    733bdd207f17:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd207f1e:	59 00 00 
    733bdd207f21:	ff d0                	call   rax
    733bdd207f23:	89 c1                	mov    ecx,eax
    733bdd207f25:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207f2a:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    733bdd207f2e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd207f35:	75 14                	jne    0x733bdd207f4b
    733bdd207f37:	eb 4c                	jmp    0x733bdd207f85
    733bdd207f39:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207f3e:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    733bdd207f42:	89 4c 24 24          	mov    DWORD PTR [rsp+0x24],ecx
    733bdd207f46:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd207f49:	eb 44                	jmp    0x733bdd207f8f
    733bdd207f4b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd207f50:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207f56:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207f5c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207f62:	be 04 00 00 00       	mov    esi,0x4
    733bdd207f67:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207f6c:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    733bdd207f70:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    733bdd207f74:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    733bdd207f78:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd207f7c:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    733bdd207f80:	e9 c4 00 00 00       	jmp    0x733bdd208049
    733bdd207f85:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    733bdd207f89:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd207f8d:	eb aa                	jmp    0x733bdd207f39
    733bdd207f8f:	eb 00                	jmp    0x733bdd207f91
    733bdd207f91:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    733bdd207f95:	83 e0 01             	and    eax,0x1
    733bdd207f98:	83 f8 00             	cmp    eax,0x0
    733bdd207f9b:	75 2b                	jne    0x733bdd207fc8
    733bdd207f9d:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    733bdd207fa1:	be 05 00 00 00       	mov    esi,0x5
    733bdd207fa6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207fab:	b0 01                	mov    al,0x1
    733bdd207fad:	89 d7                	mov    edi,edx
    733bdd207faf:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    733bdd207fb3:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    733bdd207fb7:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    733bdd207fbb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd207fbf:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    733bdd207fc3:	e9 81 00 00 00       	jmp    0x733bdd208049
    733bdd207fc8:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    733bdd207fcd:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    733bdd207fd2:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1044e
    733bdd207fd9:	04 01 00 
    733bdd207fdc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd207fe3:	00 00 00 
    733bdd207fe6:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd207fed:	00 00 00 
    733bdd207ff0:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd207ff7:	59 00 00 
    733bdd207ffa:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd207fff:	ff d0                	call   rax
    733bdd208001:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd208006:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20800c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208012:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd208018:	be 05 00 00 00       	mov    esi,0x5
    733bdd20801d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd208022:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    733bdd208026:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    733bdd20802a:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    733bdd20802e:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd208032:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    733bdd208036:	eb 11                	jmp    0x733bdd208049
    733bdd208038:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd20803d:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd208044:	e9 d2 00 00 00       	jmp    0x733bdd20811b
    733bdd208049:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    733bdd20804e:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    733bdd208052:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    733bdd208056:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd20805a:	8b 7c 24 48          	mov    edi,DWORD PTR [rsp+0x48]
    733bdd20805e:	8a 5c 24 4f          	mov    bl,BYTE PTR [rsp+0x4f]
    733bdd208062:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    733bdd208066:	89 c3                	mov    ebx,eax
    733bdd208068:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    733bdd20806c:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    733bdd208070:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    733bdd208074:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    733bdd208078:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20807e:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    733bdd208082:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd208088:	73 29                	jae    0x733bdd2080b3
    733bdd20808a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd20808f:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd208093:	89 d1                	mov    ecx,edx
    733bdd208095:	c1 e9 01             	shr    ecx,0x1
    733bdd208098:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20809e:	89 c9                	mov    ecx,ecx
    733bdd2080a0:	48 c1 e1 04          	shl    rcx,0x4
    733bdd2080a4:	48 89 c6             	mov    rsi,rax
    733bdd2080a7:	48 01 ce             	add    rsi,rcx
    733bdd2080aa:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    733bdd2080ae:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd2080b1:	74 2f                	je     0x733bdd2080e2
    733bdd2080b3:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd2080b8:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    733bdd2080bc:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    733bdd2080c0:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    733bdd2080c4:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    733bdd2080c8:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd2080ce:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd2080d4:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd2080da:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd2080e0:	eb 39                	jmp    0x733bdd20811b
    733bdd2080e2:	4c 8b 74 24 68       	mov    r14,QWORD PTR [rsp+0x68]
    733bdd2080e7:	4c 8b 6c 24 70       	mov    r13,QWORD PTR [rsp+0x70]
    733bdd2080ec:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    733bdd2080f0:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    733bdd2080f4:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    733bdd2080f8:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd2080ff:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd208106:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20810d:	00 
    733bdd20810e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd208112:	48 81 c4 88 00 00 00 	add    rsp,0x88
    733bdd208119:	ff e0                	jmp    rax
    733bdd20811b:	48 81 c4 88 00 00 00 	add    rsp,0x88
    733bdd208122:	c2 08 00             	ret    0x8
