
build-native-instruction-analysis/capture/bcore-default-branch/pc-65904-0-126700950179264.bin:     file format binary


Disassembly of section .data:

0000733bdd20cdc0 <.data>:
    733bdd20cdc0:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    733bdd20cdc7:	8d 82 8d fe fe ff    	lea    eax,[rdx-0x10173]
    733bdd20cdcd:	83 f8 fc             	cmp    eax,0xfffffffc
    733bdd20cdd0:	0f 87 56 32 ff 17    	ja     0x733bf520002c
    733bdd20cdd6:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    733bdd20cddd:	8d 81 8d fe fe ff    	lea    eax,[rcx-0x10173]
    733bdd20cde3:	83 f8 fc             	cmp    eax,0xfffffffc
    733bdd20cde6:	0f 87 40 32 ff 17    	ja     0x733bf520002c
    733bdd20cdec:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    733bdd20cdf3:	41 8b 75 00          	mov    esi,DWORD PTR [r13+0x0]
    733bdd20cdf7:	41 8b 7d 1c          	mov    edi,DWORD PTR [r13+0x1c]
    733bdd20cdfb:	89 fb                	mov    ebx,edi
    733bdd20cdfd:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20ce00:	89 f5                	mov    ebp,esi
    733bdd20ce02:	c1 ed 1f             	shr    ebp,0x1f
    733bdd20ce05:	31 c0                	xor    eax,eax
    733bdd20ce07:	01 f7                	add    edi,esi
    733bdd20ce09:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    733bdd20ce0d:	0f 92 c0             	setb   al
    733bdd20ce10:	89 fe                	mov    esi,edi
    733bdd20ce12:	c1 ee 1f             	shr    esi,0x1f
    733bdd20ce15:	31 f5                	xor    ebp,esi
    733bdd20ce17:	31 f3                	xor    ebx,esi
    733bdd20ce19:	21 eb                	and    ebx,ebp
    733bdd20ce1b:	31 ed                	xor    ebp,ebp
    733bdd20ce1d:	85 ff                	test   edi,edi
    733bdd20ce1f:	40 0f 94 c5          	sete   bpl
    733bdd20ce23:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    733bdd20ce2a:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    733bdd20ce31:	41 89 9d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebx
    733bdd20ce38:	41 89 9d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebx
    733bdd20ce3f:	41 09 9d 00 01 00 00 	or     DWORD PTR [r13+0x100],ebx
    733bdd20ce46:	41 89 85 ec 00 00 00 	mov    DWORD PTR [r13+0xec],eax
    733bdd20ce4d:	41 89 85 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],eax
    733bdd20ce54:	41 8b bd 98 00 00 00 	mov    edi,DWORD PTR [r13+0x98]
    733bdd20ce5b:	be 76 01 01 00       	mov    esi,0x10176
    733bdd20ce60:	bb 76 01 01 00       	mov    ebx,0x10176
    733bdd20ce65:	81 fa 72 01 01 00    	cmp    edx,0x10172
    733bdd20ce6b:	75 07                	jne    0x733bdd20ce74
    733bdd20ce6d:	41 8b 9d 90 00 00 00 	mov    ebx,DWORD PTR [r13+0x90]
    733bdd20ce74:	83 ff 02             	cmp    edi,0x2
    733bdd20ce77:	0f 43 f3             	cmovae esi,ebx
    733bdd20ce7a:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    733bdd20ce81:	89 f7                	mov    edi,esi
    733bdd20ce83:	81 f9 72 01 01 00    	cmp    ecx,0x10172
    733bdd20ce89:	75 07                	jne    0x733bdd20ce92
    733bdd20ce8b:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    733bdd20ce92:	83 fa 02             	cmp    edx,0x2
    733bdd20ce95:	0f 43 f7             	cmovae esi,edi
    733bdd20ce98:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    733bdd20ce9f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    733bdd20cea6:	30 01 01 00 
    733bdd20ceaa:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20ceb1:	83 c1 02             	add    ecx,0x2
    733bdd20ceb4:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    733bdd20cebb:	39 c1                	cmp    ecx,eax
    733bdd20cebd:	0f 83 3d 31 ff 17    	jae    0x733bf5200000
    733bdd20cec3:	41 81 b8 80 09 08 00 	cmp    DWORD PTR [r8+0x80980],0x10130
    733bdd20ceca:	30 01 01 00 
    733bdd20cece:	0f 85 2c 31 ff 17    	jne    0x733bf5200000
    733bdd20ced4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    733bdd20cedb:	30 01 01 00 
    733bdd20cedf:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20cee6:	49 8b 80 88 09 08 00 	mov    rax,QWORD PTR [r8+0x80988]
    733bdd20ceed:	ff e0                	jmp    rax
