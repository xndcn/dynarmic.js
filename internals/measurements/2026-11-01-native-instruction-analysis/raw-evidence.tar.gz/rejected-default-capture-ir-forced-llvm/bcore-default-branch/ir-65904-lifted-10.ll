; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010170(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65904
  %4 = icmp ugt i32 %3, 2
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb7 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb7, 0
  %9 = sub i32 %guard_lb7, 65904
  %10 = icmp ugt i32 %9, 2
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x00010170_entry, label %lb_guard_miss, !prof !0

insn_0x00010170_entry:                            ; preds = %lb_guard
  %13 = getelementptr i8, ptr %cpu, i64 336
  %chain_table9 = load ptr, ptr %13, align 8
  %tier_table = getelementptr i8, ptr %chain_table9, i64 1048576
  %14 = getelementptr i8, ptr %tier_table, i64 40
  %15 = load i32, ptr %14, align 4
  %tier_count = add i32 %15, 1
  store i32 %tier_count, ptr %14, align 4
  %16 = icmp eq i32 %tier_count, 30000
  br i1 %16, label %17, label %27, !prof !1

17:                                               ; preds = %insn_0x00010170_entry
  %18 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %18, align 4
  %19 = add i32 %tier_requests, 1
  store i32 %19, ptr %18, align 4
  %20 = icmp ult i32 %tier_requests, 256
  br i1 %20, label %21, label %26

21:                                               ; preds = %17
  %22 = zext i32 %tier_requests to i64
  %23 = mul i64 %22, 4
  %24 = add i64 262148, %23
  %25 = getelementptr i8, ptr %tier_table, i64 %24
  store i32 10, ptr %25, align 4
  br label %26

26:                                               ; preds = %17, %21
  br label %27

27:                                               ; preds = %insn_0x00010170_entry, %26
  br label %insn_0x00010170

insn_0x00010170:                                  ; preds = %27
  %28 = getelementptr i8, ptr %cpu, i32 28
  %rs = load i32, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %29, align 4
  %add32 = add i32 %rs, %rt
  %30 = getelementptr i8, ptr %cpu, i32 0
  store i32 %add32, ptr %30, align 4
  %flgs = lshr i32 %rs, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %31 = xor i32 %flgo, %flgn
  %32 = xor i32 %flgs, %flgn
  %33 = and i32 %32, %31
  %34 = xor i32 %rs, -1
  %35 = icmp ult i32 %34, %rt
  %ac0 = zext i1 %35 to i32
  %36 = icmp eq i32 %add32, 0
  %az = zext i1 %36 to i32
  %an = lshr i32 %add32, 31
  %37 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %38, align 4
  %39 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %39, align 4
  %40 = or i32 %vs_cur, %33
  %41 = getelementptr i8, ptr %cpu, i32 248
  store i32 %33, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 252
  store i32 %33, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 256
  store i32 %40, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %47, align 4
  br label %insn_0x00010172_entry

insn_0x00010172_entry:                            ; preds = %insn_0x00010170
  br label %insn_0x00010172

insn_0x00010172:                                  ; preds = %insn_0x00010172_entry
  %48 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %49, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65906
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65910
  %50 = getelementptr i8, ptr %cpu, i32 156
  %lc1 = load i32, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i32 148
  %lt2 = load i32, ptr %51, align 4
  %lc_gt13 = icmp ugt i32 %lc1, 1
  %at_lb4 = icmp eq i32 %lb1, 65906
  %hwloop_cond5 = and i1 %lc_gt13, %at_lb4
  %hwloop_rets6 = select i1 %hwloop_cond5, i32 %lt2, i32 %hwloop_rets
  %52 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets6, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 188
  store i32 65840, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %54, align 4
  %chain_total = add nuw i32 %chain_packets, 2
  %55 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %55 monotonic, align 4, !range !2
  %56 = icmp ult i32 %chain_total, %chain_budget
  br i1 %56, label %chain_go, label %chain_leave8, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %57 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %57, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %insn_0x00010172
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526720
  %58 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %58, align 4
  %59 = icmp eq i32 %slot_pc, 65840
  br i1 %59, label %chain_hit, label %chain_leave8, !prof !0

chain_leave8:                                     ; preds = %chain_go, %insn_0x00010172
  %60 = getelementptr i8, ptr %cpu, i64 188
  store i32 65840, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i64 308
  store i32 2, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %63, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %64 = getelementptr i8, ptr %cpu, i64 188
  store i32 65840, ptr %64, align 4
  %65 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %65, align 4
  %66 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %66, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave8, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
