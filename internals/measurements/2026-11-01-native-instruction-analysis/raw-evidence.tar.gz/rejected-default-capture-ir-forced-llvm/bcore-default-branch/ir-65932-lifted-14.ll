; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001018c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 65932
  %5 = icmp ugt i32 %4, 14
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb106 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb106, 0
  %10 = sub i32 %guard_lb106, 65932
  %11 = icmp ugt i32 %10, 14
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x0001018c_entry, label %lb_guard_miss, !prof !0

insn_0x0001018c_entry:                            ; preds = %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table134 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table134, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 56
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x0001018c_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 14, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x0001018c_entry, %27
  br label %insn_0x0001018c

insn_0x0001018c:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 24
  %rd = load i32, ptr %29, align 4
  %rd_add = add i32 %rd, 1
  %30 = getelementptr i8, ptr %cpu, i32 24
  store i32 %rd_add, ptr %30, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %31 = xor i32 0, %flgn
  %32 = xor i32 %flgs, %flgn
  %overflow = and i32 %32, %31
  %33 = xor i32 %rd, -1
  %34 = icmp ult i32 %33, 1
  %ac0 = zext i1 %34 to i32
  %35 = icmp eq i32 %rd_add, 0
  %az = zext i1 %35 to i32
  %an = lshr i32 %rd_add, 31
  %36 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %38, align 4
  %39 = or i32 %vs_cur, %overflow
  %40 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 256
  store i32 %39, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %46, align 4
  br label %insn_0x0001018e_entry

insn_0x0001018e_entry:                            ; preds = %insn_0x0001018c
  br label %insn_0x0001018e

insn_0x0001018e:                                  ; preds = %insn_0x0001018e_entry
  %47 = getelementptr i8, ptr %cpu, i32 20
  %rx = load i32, ptr %47, align 4
  %48 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %48 to i32
  %49 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %49, align 4
  %50 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %50 to i32
  %51 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %51 to i32
  %52 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %52 to i32
  %53 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac03, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac03, ptr %56, align 4
  br label %insn_0x00010190_entry

insn_0x00010190_entry:                            ; preds = %insn_0x0001018e
  br label %insn_0x00010190

insn_0x00010190:                                  ; preds = %insn_0x00010190_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010190
  %57 = getelementptr i8, ptr %cpu, i32 188
  store i32 65916, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %58, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %59 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %59 monotonic, align 4, !range !2
  %60 = icmp ult i32 %chain_total, %chain_budget
  br i1 %60, label %chain_go, label %chain_leave107, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010190
  br label %insn_0x00010192_entry

insn_0x00010192_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010192

insn_0x00010192:                                  ; preds = %insn_0x00010192_entry
  %61 = getelementptr i8, ptr %cpu, i32 28
  %rs = load i32, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %62, align 4
  %xor32 = xor i32 %rt, %rs
  %63 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %63, align 4
  %64 = icmp eq i32 %xor32, 0
  %az4 = zext i1 %64 to i32
  %an5 = lshr i32 %xor32, 31
  %65 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az4, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an5, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %70, align 4
  br label %insn_0x00010194_entry

insn_0x00010194_entry:                            ; preds = %insn_0x00010192
  br label %insn_0x00010194

insn_0x00010194:                                  ; preds = %insn_0x00010194_entry
  %71 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %71, align 4
  %72 = and i32 %fp, 3
  %73 = icmp ne i32 %72, 0
  br i1 %73, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010194
  %74 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %76, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65940, i32 %fp, i32 0)
  %77 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 188
  %79 = load i32, ptr %78, align 4
  %80 = getelementptr i8, ptr %cpu, i64 296
  %81 = load i8, ptr %80, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010194
  %82 = lshr i32 %fp, 12
  %page_index = zext i32 %82 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %83 = and i32 %fp, 4095
  %page_offset = zext i32 %83 to i64
  %84 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %84, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %85 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %87, align 4
  %88 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %89 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %89, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %88, %did_jump_cont ]
  %sp1 = add i32 %fp, 4
  %90 = and i32 %sp1, 3
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %data_misaligned6, label %data_aligned7, !prof !1

did_jump_exit:                                    ; preds = %page_slow
  %92 = getelementptr i8, ptr %cpu, i64 188
  %next_pc108 = load i32, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 188
  %94 = load i32, ptr %93, align 4
  %95 = getelementptr i8, ptr %cpu, i64 296
  %96 = load i8, ptr %95, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

data_misaligned6:                                 ; preds = %page_done
  %97 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %99, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65940, i32 %sp1, i32 0)
  %100 = getelementptr i8, ptr %cpu, i64 188
  %next_pc109 = load i32, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i64 188
  %102 = load i32, ptr %101, align 4
  %103 = getelementptr i8, ptr %cpu, i64 296
  %104 = load i8, ptr %103, align 1
  br label %chain_exit

data_aligned7:                                    ; preds = %page_done
  %105 = lshr i32 %sp1, 12
  %page_index11 = zext i32 %105 to i64
  %page_slot12 = getelementptr ptr, ptr %page_table, i64 %page_index11
  %page13 = load ptr, ptr %page_slot12, align 8
  %page_mapped14 = icmp ne ptr %page13, null
  br i1 %page_mapped14, label %page_fast8, label %page_slow9, !prof !0

page_fast8:                                       ; preds = %data_aligned7
  %106 = and i32 %sp1, 4095
  %page_offset15 = zext i32 %106 to i64
  %107 = getelementptr i8, ptr %page13, i64 %page_offset15
  %page_val16 = load i32, ptr %107, align 4
  br label %page_done10

page_slow9:                                       ; preds = %data_aligned7
  %108 = getelementptr i8, ptr %cpu, i32 188
  store i32 65940, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 308
  store i32 5, ptr %110, align 4
  %111 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %112 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %112, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

page_done10:                                      ; preds = %did_jump_cont18, %page_fast8
  %mem_val21 = phi i32 [ %page_val16, %page_fast8 ], [ %111, %did_jump_cont18 ]
  %sp2 = add i32 %sp1, 4
  %113 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val21, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %115, align 4
  br label %insn_0x00010198_entry

did_jump_exit17:                                  ; preds = %page_slow9
  %116 = getelementptr i8, ptr %cpu, i64 188
  %next_pc110 = load i32, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i64 188
  %118 = load i32, ptr %117, align 4
  %119 = getelementptr i8, ptr %cpu, i64 296
  %120 = load i8, ptr %119, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %page_slow9
  br label %page_done10

insn_0x00010198_entry:                            ; preds = %page_done10
  br label %insn_0x00010198

insn_0x00010198:                                  ; preds = %insn_0x00010198_entry
  %121 = and i32 %sp2, 3
  %122 = icmp ne i32 %121, 0
  br i1 %122, label %data_misaligned22, label %data_aligned23, !prof !1

data_misaligned22:                                ; preds = %insn_0x00010198
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %125, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp2, i32 0)
  %126 = getelementptr i8, ptr %cpu, i64 188
  %next_pc111 = load i32, ptr %126, align 4
  %127 = getelementptr i8, ptr %cpu, i64 188
  %128 = load i32, ptr %127, align 4
  %129 = getelementptr i8, ptr %cpu, i64 296
  %130 = load i8, ptr %129, align 1
  br label %chain_exit

data_aligned23:                                   ; preds = %insn_0x00010198
  %131 = lshr i32 %sp2, 12
  %page_index27 = zext i32 %131 to i64
  %page_slot28 = getelementptr ptr, ptr %page_table, i64 %page_index27
  %page29 = load ptr, ptr %page_slot28, align 8
  %page_mapped30 = icmp ne ptr %page29, null
  br i1 %page_mapped30, label %page_fast24, label %page_slow25, !prof !0

page_fast24:                                      ; preds = %data_aligned23
  %132 = and i32 %sp2, 4095
  %page_offset31 = zext i32 %132 to i64
  %133 = getelementptr i8, ptr %page29, i64 %page_offset31
  %page_val32 = load i32, ptr %133, align 4
  br label %page_done26

page_slow25:                                      ; preds = %data_aligned23
  %134 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %136, align 4
  %137 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %138 = getelementptr i8, ptr %cpu, i32 296
  %dj35 = load i8, ptr %138, align 1
  %dj_set36 = icmp ne i8 %dj35, 0
  br i1 %dj_set36, label %did_jump_exit33, label %did_jump_cont34, !prof !1

page_done26:                                      ; preds = %did_jump_cont34, %page_fast24
  %mem_val37 = phi i32 [ %page_val32, %page_fast24 ], [ %137, %did_jump_cont34 ]
  %139 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val37, ptr %139, align 4
  %sp_inc = add i32 %sp2, 4
  %140 = and i32 %sp_inc, 3
  %141 = icmp ne i32 %140, 0
  br i1 %141, label %data_misaligned38, label %data_aligned39, !prof !1

did_jump_exit33:                                  ; preds = %page_slow25
  %142 = getelementptr i8, ptr %cpu, i64 188
  %next_pc112 = load i32, ptr %142, align 4
  %143 = getelementptr i8, ptr %cpu, i64 188
  %144 = load i32, ptr %143, align 4
  %145 = getelementptr i8, ptr %cpu, i64 296
  %146 = load i8, ptr %145, align 1
  br label %chain_exit

did_jump_cont34:                                  ; preds = %page_slow25
  br label %page_done26

data_misaligned38:                                ; preds = %page_done26
  %147 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %148, align 4
  %149 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %149, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc, i32 0)
  %150 = getelementptr i8, ptr %cpu, i64 188
  %next_pc113 = load i32, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i64 188
  %152 = load i32, ptr %151, align 4
  %153 = getelementptr i8, ptr %cpu, i64 296
  %154 = load i8, ptr %153, align 1
  br label %chain_exit

data_aligned39:                                   ; preds = %page_done26
  %155 = lshr i32 %sp_inc, 12
  %page_index43 = zext i32 %155 to i64
  %page_slot44 = getelementptr ptr, ptr %page_table, i64 %page_index43
  %page45 = load ptr, ptr %page_slot44, align 8
  %page_mapped46 = icmp ne ptr %page45, null
  br i1 %page_mapped46, label %page_fast40, label %page_slow41, !prof !0

page_fast40:                                      ; preds = %data_aligned39
  %156 = and i32 %sp_inc, 4095
  %page_offset47 = zext i32 %156 to i64
  %157 = getelementptr i8, ptr %page45, i64 %page_offset47
  %page_val48 = load i32, ptr %157, align 4
  br label %page_done42

page_slow41:                                      ; preds = %data_aligned39
  %158 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %158, align 4
  %159 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %160, align 4
  %161 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %162 = getelementptr i8, ptr %cpu, i32 296
  %dj51 = load i8, ptr %162, align 1
  %dj_set52 = icmp ne i8 %dj51, 0
  br i1 %dj_set52, label %did_jump_exit49, label %did_jump_cont50, !prof !1

page_done42:                                      ; preds = %did_jump_cont50, %page_fast40
  %mem_val53 = phi i32 [ %page_val48, %page_fast40 ], [ %161, %did_jump_cont50 ]
  %163 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val53, ptr %163, align 4
  %sp_inc54 = add i32 %sp_inc, 4
  %164 = and i32 %sp_inc54, 3
  %165 = icmp ne i32 %164, 0
  br i1 %165, label %data_misaligned55, label %data_aligned56, !prof !1

did_jump_exit49:                                  ; preds = %page_slow41
  %166 = getelementptr i8, ptr %cpu, i64 188
  %next_pc114 = load i32, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i64 188
  %168 = load i32, ptr %167, align 4
  %169 = getelementptr i8, ptr %cpu, i64 296
  %170 = load i8, ptr %169, align 1
  br label %chain_exit

did_jump_cont50:                                  ; preds = %page_slow41
  br label %page_done42

data_misaligned55:                                ; preds = %page_done42
  %171 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %171, align 4
  %172 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %173, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc54, i32 0)
  %174 = getelementptr i8, ptr %cpu, i64 188
  %next_pc115 = load i32, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i64 188
  %176 = load i32, ptr %175, align 4
  %177 = getelementptr i8, ptr %cpu, i64 296
  %178 = load i8, ptr %177, align 1
  br label %chain_exit

data_aligned56:                                   ; preds = %page_done42
  %179 = lshr i32 %sp_inc54, 12
  %page_index60 = zext i32 %179 to i64
  %page_slot61 = getelementptr ptr, ptr %page_table, i64 %page_index60
  %page62 = load ptr, ptr %page_slot61, align 8
  %page_mapped63 = icmp ne ptr %page62, null
  br i1 %page_mapped63, label %page_fast57, label %page_slow58, !prof !0

page_fast57:                                      ; preds = %data_aligned56
  %180 = and i32 %sp_inc54, 4095
  %page_offset64 = zext i32 %180 to i64
  %181 = getelementptr i8, ptr %page62, i64 %page_offset64
  %page_val65 = load i32, ptr %181, align 4
  br label %page_done59

page_slow58:                                      ; preds = %data_aligned56
  %182 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %184, align 4
  %185 = call i32 @mem_read32(ptr %mem, i32 %sp_inc54)
  %186 = getelementptr i8, ptr %cpu, i32 296
  %dj68 = load i8, ptr %186, align 1
  %dj_set69 = icmp ne i8 %dj68, 0
  br i1 %dj_set69, label %did_jump_exit66, label %did_jump_cont67, !prof !1

page_done59:                                      ; preds = %did_jump_cont67, %page_fast57
  %mem_val70 = phi i32 [ %page_val65, %page_fast57 ], [ %185, %did_jump_cont67 ]
  %187 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val70, ptr %187, align 4
  %sp_inc71 = add i32 %sp_inc54, 4
  %188 = and i32 %sp_inc71, 3
  %189 = icmp ne i32 %188, 0
  br i1 %189, label %data_misaligned72, label %data_aligned73, !prof !1

did_jump_exit66:                                  ; preds = %page_slow58
  %190 = getelementptr i8, ptr %cpu, i64 188
  %next_pc116 = load i32, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i64 188
  %192 = load i32, ptr %191, align 4
  %193 = getelementptr i8, ptr %cpu, i64 296
  %194 = load i8, ptr %193, align 1
  br label %chain_exit

did_jump_cont67:                                  ; preds = %page_slow58
  br label %page_done59

data_misaligned72:                                ; preds = %page_done59
  %195 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %195, align 4
  %196 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %196, align 4
  %197 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %197, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc71, i32 0)
  %198 = getelementptr i8, ptr %cpu, i64 188
  %next_pc117 = load i32, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i64 188
  %200 = load i32, ptr %199, align 4
  %201 = getelementptr i8, ptr %cpu, i64 296
  %202 = load i8, ptr %201, align 1
  br label %chain_exit

data_aligned73:                                   ; preds = %page_done59
  %203 = lshr i32 %sp_inc71, 12
  %page_index77 = zext i32 %203 to i64
  %page_slot78 = getelementptr ptr, ptr %page_table, i64 %page_index77
  %page79 = load ptr, ptr %page_slot78, align 8
  %page_mapped80 = icmp ne ptr %page79, null
  br i1 %page_mapped80, label %page_fast74, label %page_slow75, !prof !0

page_fast74:                                      ; preds = %data_aligned73
  %204 = and i32 %sp_inc71, 4095
  %page_offset81 = zext i32 %204 to i64
  %205 = getelementptr i8, ptr %page79, i64 %page_offset81
  %page_val82 = load i32, ptr %205, align 4
  br label %page_done76

page_slow75:                                      ; preds = %data_aligned73
  %206 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %206, align 4
  %207 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %208, align 4
  %209 = call i32 @mem_read32(ptr %mem, i32 %sp_inc71)
  %210 = getelementptr i8, ptr %cpu, i32 296
  %dj85 = load i8, ptr %210, align 1
  %dj_set86 = icmp ne i8 %dj85, 0
  br i1 %dj_set86, label %did_jump_exit83, label %did_jump_cont84, !prof !1

page_done76:                                      ; preds = %did_jump_cont84, %page_fast74
  %mem_val87 = phi i32 [ %page_val82, %page_fast74 ], [ %209, %did_jump_cont84 ]
  %211 = getelementptr i8, ptr %cpu, i32 20
  store i32 %mem_val87, ptr %211, align 4
  %sp_inc88 = add i32 %sp_inc71, 4
  %212 = and i32 %sp_inc88, 3
  %213 = icmp ne i32 %212, 0
  br i1 %213, label %data_misaligned89, label %data_aligned90, !prof !1

did_jump_exit83:                                  ; preds = %page_slow75
  %214 = getelementptr i8, ptr %cpu, i64 188
  %next_pc118 = load i32, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i64 188
  %216 = load i32, ptr %215, align 4
  %217 = getelementptr i8, ptr %cpu, i64 296
  %218 = load i8, ptr %217, align 1
  br label %chain_exit

did_jump_cont84:                                  ; preds = %page_slow75
  br label %page_done76

data_misaligned89:                                ; preds = %page_done76
  %219 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %221, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65944, i32 %sp_inc88, i32 0)
  %222 = getelementptr i8, ptr %cpu, i64 188
  %next_pc119 = load i32, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 188
  %224 = load i32, ptr %223, align 4
  %225 = getelementptr i8, ptr %cpu, i64 296
  %226 = load i8, ptr %225, align 1
  br label %chain_exit

data_aligned90:                                   ; preds = %page_done76
  %227 = lshr i32 %sp_inc88, 12
  %page_index94 = zext i32 %227 to i64
  %page_slot95 = getelementptr ptr, ptr %page_table, i64 %page_index94
  %page96 = load ptr, ptr %page_slot95, align 8
  %page_mapped97 = icmp ne ptr %page96, null
  br i1 %page_mapped97, label %page_fast91, label %page_slow92, !prof !0

page_fast91:                                      ; preds = %data_aligned90
  %228 = and i32 %sp_inc88, 4095
  %page_offset98 = zext i32 %228 to i64
  %229 = getelementptr i8, ptr %page96, i64 %page_offset98
  %page_val99 = load i32, ptr %229, align 4
  br label %page_done93

page_slow92:                                      ; preds = %data_aligned90
  %230 = getelementptr i8, ptr %cpu, i32 188
  store i32 65944, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %232, align 4
  %233 = call i32 @mem_read32(ptr %mem, i32 %sp_inc88)
  %234 = getelementptr i8, ptr %cpu, i32 296
  %dj102 = load i8, ptr %234, align 1
  %dj_set103 = icmp ne i8 %dj102, 0
  br i1 %dj_set103, label %did_jump_exit100, label %did_jump_cont101, !prof !1

page_done93:                                      ; preds = %did_jump_cont101, %page_fast91
  %mem_val104 = phi i32 [ %page_val99, %page_fast91 ], [ %233, %did_jump_cont101 ]
  %235 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val104, ptr %235, align 4
  %sp_inc105 = add i32 %sp_inc88, 4
  %236 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc105, ptr %236, align 4
  br label %insn_0x0001019a_entry

did_jump_exit100:                                 ; preds = %page_slow92
  %237 = getelementptr i8, ptr %cpu, i64 188
  %next_pc120 = load i32, ptr %237, align 4
  %238 = getelementptr i8, ptr %cpu, i64 188
  %239 = load i32, ptr %238, align 4
  %240 = getelementptr i8, ptr %cpu, i64 296
  %241 = load i8, ptr %240, align 1
  br label %chain_exit

did_jump_cont101:                                 ; preds = %page_slow92
  br label %page_done93

insn_0x0001019a_entry:                            ; preds = %page_done93
  br label %insn_0x0001019a

insn_0x0001019a:                                  ; preds = %insn_0x0001019a_entry
  %lsb = and i32 %mem_val21, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001019a
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001019a
  %242 = getelementptr i8, ptr %cpu, i32 188
  store i32 65946, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %243, align 4
  %244 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %244, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %245 = getelementptr i8, ptr %cpu, i64 188
  %next_pc121 = load i32, ptr %245, align 4
  %246 = getelementptr i8, ptr %cpu, i64 188
  %247 = load i32, ptr %246, align 4
  %248 = getelementptr i8, ptr %cpu, i64 296
  %249 = load i8, ptr %248, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %250 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %250, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527328
  %251 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %251, align 4
  %252 = icmp eq i32 %slot_pc, 65916
  br i1 %252, label %chain_hit, label %chain_leave107, !prof !0

chain_leave107:                                   ; preds = %chain_go, %brcc_taken
  %253 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %253, align 4
  %254 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %254, align 4
  %255 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %255, align 4
  %256 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %256, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %257 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %257, align 4
  %258 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %258, align 4
  %259 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %259, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit100, %data_misaligned89, %did_jump_exit83, %data_misaligned72, %did_jump_exit66, %data_misaligned55, %did_jump_exit49, %data_misaligned38, %did_jump_exit33, %data_misaligned22, %did_jump_exit17, %data_misaligned6, %did_jump_exit, %data_misaligned
  %next_pc122 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc108, %did_jump_exit ], [ %next_pc109, %data_misaligned6 ], [ %next_pc110, %did_jump_exit17 ], [ %next_pc111, %data_misaligned22 ], [ %next_pc112, %did_jump_exit33 ], [ %next_pc113, %data_misaligned38 ], [ %next_pc114, %did_jump_exit49 ], [ %next_pc115, %data_misaligned55 ], [ %next_pc116, %did_jump_exit66 ], [ %next_pc117, %data_misaligned72 ], [ %next_pc118, %did_jump_exit83 ], [ %next_pc119, %data_misaligned89 ], [ %next_pc120, %did_jump_exit100 ], [ %mem_val21, %jump_aligned ], [ %next_pc121, %jump_misalign ]
  %packets = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned6 ], [ 5, %did_jump_exit17 ], [ 6, %data_misaligned22 ], [ 6, %did_jump_exit33 ], [ 6, %data_misaligned38 ], [ 6, %did_jump_exit49 ], [ 6, %data_misaligned55 ], [ 6, %did_jump_exit66 ], [ 6, %data_misaligned72 ], [ 6, %did_jump_exit83 ], [ 6, %data_misaligned89 ], [ 6, %did_jump_exit100 ], [ 7, %jump_aligned ], [ 7, %jump_misalign ]
  %tail = phi i32 [ %79, %data_misaligned ], [ %94, %did_jump_exit ], [ %102, %data_misaligned6 ], [ %118, %did_jump_exit17 ], [ %128, %data_misaligned22 ], [ %144, %did_jump_exit33 ], [ %152, %data_misaligned38 ], [ %168, %did_jump_exit49 ], [ %176, %data_misaligned55 ], [ %192, %did_jump_exit66 ], [ %200, %data_misaligned72 ], [ %216, %did_jump_exit83 ], [ %224, %data_misaligned89 ], [ %239, %did_jump_exit100 ], [ %mem_val21, %jump_aligned ], [ %247, %jump_misalign ]
  %tail123 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned6 ], [ 4, %did_jump_exit17 ], [ 2, %data_misaligned22 ], [ 2, %did_jump_exit33 ], [ 2, %data_misaligned38 ], [ 2, %did_jump_exit49 ], [ 2, %data_misaligned55 ], [ 2, %did_jump_exit66 ], [ 2, %data_misaligned72 ], [ 2, %did_jump_exit83 ], [ 2, %data_misaligned89 ], [ 2, %did_jump_exit100 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail124 = phi i32 [ 5, %data_misaligned ], [ 5, %did_jump_exit ], [ 5, %data_misaligned6 ], [ 5, %did_jump_exit17 ], [ 6, %data_misaligned22 ], [ 6, %did_jump_exit33 ], [ 6, %data_misaligned38 ], [ 6, %did_jump_exit49 ], [ 6, %data_misaligned55 ], [ 6, %did_jump_exit66 ], [ 6, %data_misaligned72 ], [ 6, %did_jump_exit83 ], [ 6, %data_misaligned89 ], [ 6, %did_jump_exit100 ], [ 7, %jump_aligned ], [ 7, %jump_misalign ]
  %tail125 = phi i8 [ %81, %data_misaligned ], [ %96, %did_jump_exit ], [ %104, %data_misaligned6 ], [ %120, %did_jump_exit17 ], [ %130, %data_misaligned22 ], [ %146, %did_jump_exit33 ], [ %154, %data_misaligned38 ], [ %170, %did_jump_exit49 ], [ %178, %data_misaligned55 ], [ %194, %did_jump_exit66 ], [ %202, %data_misaligned72 ], [ %218, %did_jump_exit83 ], [ %226, %data_misaligned89 ], [ %241, %did_jump_exit100 ], [ 1, %jump_aligned ], [ %249, %jump_misalign ]
  %260 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets127 = load i32, ptr %260, align 4
  %chain_total128 = add nuw i32 %chain_packets127, %packets
  %261 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget129 = load atomic i32, ptr %261 monotonic, align 4, !range !2
  %262 = icmp ult i32 %chain_total128, %chain_budget129
  br i1 %262, label %chain_lookup, label %chain_leave126, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %263 = lshr i32 %next_pc122, 1
  %264 = and i32 %263, 65535
  %265 = zext i32 %264 to i64
  %266 = mul i64 %265, 16
  %chain_slot130 = getelementptr i8, ptr %chain_table, i64 %266
  %267 = getelementptr i8, ptr %chain_slot130, i64 0
  %slot_pc131 = load i32, ptr %267, align 4
  %268 = icmp eq i32 %slot_pc131, %next_pc122
  br i1 %268, label %chain_hit132, label %chain_leave126, !prof !0

chain_leave126:                                   ; preds = %chain_lookup, %chain_exit
  %269 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %269, align 4
  %270 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail123, ptr %270, align 4
  %271 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail124, ptr %271, align 4
  %272 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail125, ptr %272, align 1
  br label %return

chain_hit132:                                     ; preds = %chain_lookup
  %273 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc122, ptr %273, align 4
  %274 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total128, ptr %274, align 4
  %275 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %275, align 1
  %276 = getelementptr i8, ptr %chain_slot130, i64 8
  %chain_fn133 = load ptr, ptr %276, align 8
  musttail call swifttailcc void %chain_fn133(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave126, %chain_leave107, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
