
build-native-instruction-analysis/capture/bcore-default-branch/pc-65840-0-126701352779831.bin:     file format binary


Disassembly of section .data:

0000733bf5200037 <.data>:
    733bf5200037:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf520003e:	01 
    733bf520003f:	48 83 c4 38          	add    rsp,0x38
    733bf5200043:	c2 08 00             	ret    0x8
    733bf5200046:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    733bf520004d:	3c 01 01 00 
    733bf5200051:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200058:	04 00 00 00 
    733bf520005c:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf5200063:	05 00 00 00 
    733bf5200067:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bf520006e:	59 00 00 
    733bf5200071:	4c 89 ef             	mov    rdi,r13
    733bf5200074:	4c 89 de             	mov    rsi,r11
    733bf5200077:	ba 3c 01 01 00       	mov    edx,0x1013c
    733bf520007c:	89 d9                	mov    ecx,ebx
    733bf520007e:	4d 89 de             	mov    r14,r11
    733bf5200081:	4c 89 c3             	mov    rbx,r8
    733bf5200084:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bf520008a:	ff d0                	call   rax
    733bf520008c:	49 89 d8             	mov    r8,rbx
    733bf520008f:	4d 89 f3             	mov    r11,r14
    733bf5200092:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200099:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52000a0:	00 
    733bf52000a1:	bb 05 00 00 00       	mov    ebx,0x5
    733bf52000a6:	bd 04 00 00 00       	mov    ebp,0x4
    733bf52000ab:	e9 1f d0 00 e8       	jmp    0x733bdd20d0cf
    733bf52000b0:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    733bf52000b7:	3c 01 01 00 
    733bf52000bb:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52000c2:	04 00 00 00 
    733bf52000c6:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf52000cd:	05 00 00 00 
    733bf52000d1:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bf52000d8:	59 00 00 
    733bf52000db:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    733bf52000df:	4c 89 df             	mov    rdi,r11
    733bf52000e2:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    733bf52000e7:	89 de                	mov    esi,ebx
    733bf52000e9:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    733bf52000ee:	4c 89 c5             	mov    rbp,r8
    733bf52000f1:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    733bf52000f6:	4d 89 d4             	mov    r12,r10
    733bf52000f9:	ff d0                	call   rax
    733bf52000fb:	8b 7c 24 08          	mov    edi,DWORD PTR [rsp+0x8]
    733bf52000ff:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    733bf5200104:	4d 89 e2             	mov    r10,r12
    733bf5200107:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    733bf520010c:	49 89 e8             	mov    r8,rbp
    733bf520010f:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    733bf5200114:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520011b:	00 
    733bf520011c:	84 c9                	test   cl,cl
    733bf520011e:	0f 84 c0 ce 00 e8    	je     0x733bdd20cfe4
    733bf5200124:	e9 e0 00 00 00       	jmp    0x733bf5200209
    733bf5200129:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1013c
    733bf5200130:	3c 01 01 00 
    733bf5200134:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf520013b:	04 00 00 00 
    733bf520013f:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf5200146:	05 00 00 00 
    733bf520014a:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bf5200151:	59 00 00 
    733bf5200154:	89 fa                	mov    edx,edi
    733bf5200156:	4c 89 df             	mov    rdi,r11
    733bf5200159:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    733bf520015e:	89 ee                	mov    esi,ebp
    733bf5200160:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    733bf5200165:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf520016a:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    733bf520016f:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    733bf5200174:	ff d0                	call   rax
    733bf5200176:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
    733bf520017b:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    733bf5200180:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    733bf5200185:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf520018a:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    733bf520018f:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200196:	00 
    733bf5200197:	84 c9                	test   cl,cl
    733bf5200199:	0f 84 68 ce 00 e8    	je     0x733bdd20d007
    733bf520019f:	eb 68                	jmp    0x733bf5200209
    733bf52001a1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10140
    733bf52001a8:	40 01 01 00 
    733bf52001ac:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52001b3:	04 00 00 00 
    733bf52001b7:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf52001be:	05 00 00 00 
    733bf52001c2:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bf52001c9:	59 00 00 
    733bf52001cc:	4c 89 ef             	mov    rdi,r13
    733bf52001cf:	4c 89 5c 24 18       	mov    QWORD PTR [rsp+0x18],r11
    733bf52001d4:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf52001d9:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    733bf52001de:	4c 89 54 24 28       	mov    QWORD PTR [rsp+0x28],r10
    733bf52001e3:	ff d0                	call   rax
    733bf52001e5:	4c 8b 54 24 28       	mov    r10,QWORD PTR [rsp+0x28]
    733bf52001ea:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    733bf52001ef:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf52001f4:	4c 8b 5c 24 18       	mov    r11,QWORD PTR [rsp+0x18]
    733bf52001f9:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200200:	00 
    733bf5200201:	84 c9                	test   cl,cl
    733bf5200203:	0f 84 0f ce 00 e8    	je     0x733bdd20d018
    733bf5200209:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200210:	e9 8c fe ff ff       	jmp    0x733bf52000a1
    733bf5200215:	49 89 de             	mov    r14,rbx
    733bf5200218:	4d 89 d4             	mov    r12,r10
    733bf520021b:	4c 89 cb             	mov    rbx,r9
    733bf520021e:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200223:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    733bf520022a:	46 01 01 00 
    733bf520022e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200235:	04 00 00 00 
    733bf5200239:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    733bf5200240:	08 00 00 00 
    733bf5200244:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf520024b:	59 00 00 
    733bf520024e:	4d 89 df             	mov    r15,r11
    733bf5200251:	4c 89 df             	mov    rdi,r11
    733bf5200254:	89 ee                	mov    esi,ebp
    733bf5200256:	ff d0                	call   rax
    733bf5200258:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520025f:	00 
    733bf5200260:	84 c9                	test   cl,cl
    733bf5200262:	0f 85 c9 00 00 00    	jne    0x733bf5200331
    733bf5200268:	89 c5                	mov    ebp,eax
    733bf520026a:	4d 89 fb             	mov    r11,r15
    733bf520026d:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200272:	49 89 d9             	mov    r9,rbx
    733bf5200275:	4d 89 e2             	mov    r10,r12
    733bf5200278:	4c 89 f3             	mov    rbx,r14
    733bf520027b:	e9 11 ce 00 e8       	jmp    0x733bdd20d091
    733bf5200280:	4d 89 cc             	mov    r12,r9
    733bf5200283:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200288:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10146
    733bf520028f:	46 01 01 00 
    733bf5200293:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf520029a:	04 00 00 00 
    733bf520029e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    733bf52002a5:	08 00 00 00 
    733bf52002a9:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf52002b0:	59 00 00 
    733bf52002b3:	4d 89 df             	mov    r15,r11
    733bf52002b6:	4c 89 df             	mov    rdi,r11
    733bf52002b9:	89 de                	mov    esi,ebx
    733bf52002bb:	ff d0                	call   rax
    733bf52002bd:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52002c4:	00 
    733bf52002c5:	84 c9                	test   cl,cl
    733bf52002c7:	75 68                	jne    0x733bf5200331
    733bf52002c9:	4d 89 fb             	mov    r11,r15
    733bf52002cc:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf52002d1:	4d 89 e1             	mov    r9,r12
    733bf52002d4:	e9 d3 cd 00 e8       	jmp    0x733bdd20d0ac
    733bf52002d9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014a
    733bf52002e0:	4a 01 01 00 
    733bf52002e4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf52002eb:	02 00 00 00 
    733bf52002ef:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x9
    733bf52002f6:	09 00 00 00 
    733bf52002fa:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bf5200301:	59 00 00 
    733bf5200304:	4c 89 ef             	mov    rdi,r13
    733bf5200307:	be 2a 00 00 00       	mov    esi,0x2a
    733bf520030c:	4c 89 da             	mov    rdx,r11
    733bf520030f:	4d 89 de             	mov    r14,r11
    733bf5200312:	4d 89 c7             	mov    r15,r8
    733bf5200315:	ff d0                	call   rax
    733bf5200317:	4d 89 f8             	mov    r8,r15
    733bf520031a:	4d 89 f3             	mov    r11,r14
    733bf520031d:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200324:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520032b:	00 
    733bf520032c:	e9 9e cd 00 e8       	jmp    0x733bdd20d0cf
    733bf5200331:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200338:	bb 08 00 00 00       	mov    ebx,0x8
    733bf520033d:	bd 04 00 00 00       	mov    ebp,0x4
    733bf5200342:	4d 89 fb             	mov    r11,r15
    733bf5200345:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf520034a:	e9 80 cd 00 e8       	jmp    0x733bdd20d0cf
