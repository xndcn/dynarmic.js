
build-native-instruction-analysis/capture/bcore-default-branch/pc-65916-0-126700950180928.bin:     file format binary


Disassembly of section .data:

0000733bdd20d440 <.data>:
    733bdd20d440:	41 8b 95 a0 00 00 00 	mov    edx,DWORD PTR [r13+0xa0]
    733bdd20d447:	8d 82 77 fe fe ff    	lea    eax,[rdx-0x10189]
    733bdd20d44d:	83 f8 f2             	cmp    eax,0xfffffff2
    733bdd20d450:	0f 87 e4 2f ff 17    	ja     0x733bf520043a
    733bdd20d456:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    733bdd20d45d:	8d 81 77 fe fe ff    	lea    eax,[rcx-0x10189]
    733bdd20d463:	83 f8 f2             	cmp    eax,0xfffffff2
    733bdd20d466:	0f 87 ce 2f ff 17    	ja     0x733bf520043a
    733bdd20d46c:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20d473:	41 8b 7d 1c          	mov    edi,DWORD PTR [r13+0x1c]
    733bdd20d477:	41 8b 6d 34          	mov    ebp,DWORD PTR [r13+0x34]
    733bdd20d47b:	41 0f af 7d 10       	imul   edi,DWORD PTR [r13+0x10]
    733bdd20d480:	41 89 6d 04          	mov    DWORD PTR [r13+0x4],ebp
    733bdd20d484:	8d 34 2f             	lea    esi,[rdi+rbp*1]
    733bdd20d487:	41 89 75 1c          	mov    DWORD PTR [r13+0x1c],esi
    733bdd20d48b:	c1 ef 1f             	shr    edi,0x1f
    733bdd20d48e:	c1 ed 1f             	shr    ebp,0x1f
    733bdd20d491:	89 f3                	mov    ebx,esi
    733bdd20d493:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20d496:	31 dd                	xor    ebp,ebx
    733bdd20d498:	31 df                	xor    edi,ebx
    733bdd20d49a:	21 ef                	and    edi,ebp
    733bdd20d49c:	41 09 bd 00 01 00 00 	or     DWORD PTR [r13+0x100],edi
    733bdd20d4a3:	31 ed                	xor    ebp,ebp
    733bdd20d4a5:	85 f6                	test   esi,esi
    733bdd20d4a7:	40 0f 94 c5          	sete   bpl
    733bdd20d4ab:	41 89 bd f8 00 00 00 	mov    DWORD PTR [r13+0xf8],edi
    733bdd20d4b2:	41 89 bd fc 00 00 00 	mov    DWORD PTR [r13+0xfc],edi
    733bdd20d4b9:	41 89 9d 14 01 00 00 	mov    DWORD PTR [r13+0x114],ebx
    733bdd20d4c0:	41 89 ad e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebp
    733bdd20d4c7:	41 89 9d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebx
    733bdd20d4ce:	48 bf 01 00 00 00 01 	movabs rdi,0x100000001
    733bdd20d4d5:	00 00 00 
    733bdd20d4d8:	49 89 bd ec 00 00 00 	mov    QWORD PTR [r13+0xec],rdi
    733bdd20d4df:	78 4f                	js     0x733bdd20d530
    733bdd20d4e1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd20d4e8:	70 01 01 00 
    733bdd20d4ec:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20d4f3:	83 c1 05             	add    ecx,0x5
    733bdd20d4f6:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    733bdd20d4fd:	39 d1                	cmp    ecx,edx
    733bdd20d4ff:	0f 83 09 2f ff 17    	jae    0x733bf520040e
    733bdd20d505:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    733bdd20d50c:	01 01 00 
    733bdd20d50f:	0f 85 f9 2e ff 17    	jne    0x733bf520040e
    733bdd20d515:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd20d51c:	70 01 01 00 
    733bdd20d520:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20d527:	48 8b 80 88 0b 08 00 	mov    rax,QWORD PTR [rax+0x80b88]
    733bdd20d52e:	ff e0                	jmp    rax
    733bdd20d530:	31 ff                	xor    edi,edi
    733bdd20d532:	41 33 75 00          	xor    esi,DWORD PTR [r13+0x0]
    733bdd20d536:	41 89 75 00          	mov    DWORD PTR [r13+0x0],esi
    733bdd20d53a:	40 0f 94 c7          	sete   dil
    733bdd20d53e:	c1 ee 1f             	shr    esi,0x1f
    733bdd20d541:	41 89 bd e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edi
    733bdd20d548:	41 89 b5 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],esi
    733bdd20d54f:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    733bdd20d556:	00 00 00 00 
    733bdd20d55a:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    733bdd20d561:	00 00 00 00 
    733bdd20d565:	be 8c 01 01 00       	mov    esi,0x1018c
    733bdd20d56a:	bf 8c 01 01 00       	mov    edi,0x1018c
    733bdd20d56f:	81 fa 88 01 01 00    	cmp    edx,0x10188
    733bdd20d575:	75 07                	jne    0x733bdd20d57e
    733bdd20d577:	41 8b bd 90 00 00 00 	mov    edi,DWORD PTR [r13+0x90]
    733bdd20d57e:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    733bdd20d585:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    733bdd20d58c:	02 
    733bdd20d58d:	0f 43 f7             	cmovae esi,edi
    733bdd20d590:	89 f7                	mov    edi,esi
    733bdd20d592:	81 f9 88 01 01 00    	cmp    ecx,0x10188
    733bdd20d598:	75 07                	jne    0x733bdd20d5a1
    733bdd20d59a:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    733bdd20d5a1:	83 fa 02             	cmp    edx,0x2
    733bdd20d5a4:	0f 43 f7             	cmovae esi,edi
    733bdd20d5a7:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    733bdd20d5ae:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd20d5b5:	10 01 01 00 
    733bdd20d5b9:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20d5c0:	83 c1 07             	add    ecx,0x7
    733bdd20d5c3:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    733bdd20d5ca:	39 d1                	cmp    ecx,edx
    733bdd20d5cc:	0f 83 73 2e ff 17    	jae    0x733bf5200445
    733bdd20d5d2:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    733bdd20d5d9:	01 01 00 
    733bdd20d5dc:	0f 85 63 2e ff 17    	jne    0x733bf5200445
    733bdd20d5e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd20d5e9:	10 01 01 00 
    733bdd20d5ed:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20d5f4:	48 8b 80 88 08 08 00 	mov    rax,QWORD PTR [rax+0x80888]
    733bdd20d5fb:	ff e0                	jmp    rax
