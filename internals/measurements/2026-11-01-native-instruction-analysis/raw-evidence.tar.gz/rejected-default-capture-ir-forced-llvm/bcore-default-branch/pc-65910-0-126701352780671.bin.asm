
build-native-instruction-analysis/capture/bcore-default-branch/pc-65910-0-126701352780671.bin:     file format binary


Disassembly of section .data:

0000733bf520037f <.data>:
    733bf520037f:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf5200386:	01 
    733bf5200387:	c2 08 00             	ret    0x8
    733bf520038a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    733bf5200391:	92 01 01 00 
    733bf5200395:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf520039c:	02 00 00 00 
    733bf52003a0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    733bf52003a7:	03 00 00 00 
    733bf52003ab:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf52003b2:	01 
    733bf52003b3:	c2 08 00             	ret    0x8
    733bf52003b6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bf52003bd:	70 01 01 00 
    733bf52003c1:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf52003c8:	02 00 00 00 
    733bf52003cc:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x8
    733bf52003d3:	08 00 00 00 
    733bf52003d7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf52003de:	01 
    733bf52003df:	c2 08 00             	ret    0x8
    733bf52003e2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bf52003e9:	10 01 01 00 
    733bf52003ed:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52003f4:	04 00 00 00 
    733bf52003f8:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xa
    733bf52003ff:	0a 00 00 00 
    733bf5200403:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf520040a:	01 
    733bf520040b:	c2 08 00             	ret    0x8
