
build-native-instruction-analysis/capture/bcore-default-branch/pc-65916-0-126700950166000.bin:     file format binary


Disassembly of section .data:

0000733bdd2099f0 <.data>:
    733bdd2099f0:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    733bdd2099f5:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    733bdd2099fa:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd209a01:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    733bdd209a06:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd209a0b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd209a11:	83 fa 00             	cmp    edx,0x0
    733bdd209a14:	0f 94 c0             	sete   al
    733bdd209a17:	81 ea 7c 01 01 00    	sub    edx,0x1017c
    733bdd209a1d:	83 fa 0c             	cmp    edx,0xc
    733bdd209a20:	0f 97 c2             	seta   dl
    733bdd209a23:	08 d0                	or     al,dl
    733bdd209a25:	24 01                	and    al,0x1
    733bdd209a27:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd209a2d:	83 fa 00             	cmp    edx,0x0
    733bdd209a30:	0f 94 c1             	sete   cl
    733bdd209a33:	81 ea 7c 01 01 00    	sub    edx,0x1017c
    733bdd209a39:	83 fa 0c             	cmp    edx,0xc
    733bdd209a3c:	0f 97 c2             	seta   dl
    733bdd209a3f:	08 d1                	or     cl,dl
    733bdd209a41:	20 c8                	and    al,cl
    733bdd209a43:	a8 01                	test   al,0x1
    733bdd209a45:	75 05                	jne    0x733bdd209a4c
    733bdd209a47:	e9 9b 02 00 00       	jmp    0x733bdd209ce7
    733bdd209a4c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209a51:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd209a58:	48 89 c8             	mov    rax,rcx
    733bdd209a5b:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd209a61:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    733bdd209a66:	8b 81 24 00 10 00    	mov    eax,DWORD PTR [rcx+0x100024]
    733bdd209a6c:	83 c0 01             	add    eax,0x1
    733bdd209a6f:	89 81 24 00 10 00    	mov    DWORD PTR [rcx+0x100024],eax
    733bdd209a75:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd209a7a:	75 40                	jne    0x733bdd209abc
    733bdd209a7c:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    733bdd209a81:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd209a87:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    733bdd209a8b:	89 c2                	mov    edx,eax
    733bdd209a8d:	83 c2 01             	add    edx,0x1
    733bdd209a90:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd209a96:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd209a9b:	73 1d                	jae    0x733bdd209aba
    733bdd209a9d:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    733bdd209aa2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    733bdd209aa6:	89 c9                	mov    ecx,ecx
    733bdd209aa8:	48 c1 e1 02          	shl    rcx,0x2
    733bdd209aac:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd209ab3:	c7 04 08 09 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x9
    733bdd209aba:	eb 00                	jmp    0x733bdd209abc
    733bdd209abc:	eb 00                	jmp    0x733bdd209abe
    733bdd209abe:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209ac3:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    733bdd209ac6:	0f af 48 10          	imul   ecx,DWORD PTR [rax+0x10]
    733bdd209aca:	89 4c 24 d0          	mov    DWORD PTR [rsp-0x30],ecx
    733bdd209ace:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    733bdd209ad1:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd209ad7:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    733bdd209adb:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd209ae1:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    733bdd209ae5:	eb 00                	jmp    0x733bdd209ae7
    733bdd209ae7:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209aec:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    733bdd209aef:	89 4c 24 cc          	mov    DWORD PTR [rsp-0x34],ecx
    733bdd209af3:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd209af6:	eb 00                	jmp    0x733bdd209af8
    733bdd209af8:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209afd:	8b 7c 24 cc          	mov    edi,DWORD PTR [rsp-0x34]
    733bdd209b01:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    733bdd209b05:	89 ca                	mov    edx,ecx
    733bdd209b07:	01 fa                	add    edx,edi
    733bdd209b09:	89 54 24 c8          	mov    DWORD PTR [rsp-0x38],edx
    733bdd209b0d:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    733bdd209b10:	89 ce                	mov    esi,ecx
    733bdd209b12:	c1 ee 1f             	shr    esi,0x1f
    733bdd209b15:	89 fb                	mov    ebx,edi
    733bdd209b17:	c1 eb 1f             	shr    ebx,0x1f
    733bdd209b1a:	89 d5                	mov    ebp,edx
    733bdd209b1c:	c1 ed 1f             	shr    ebp,0x1f
    733bdd209b1f:	31 eb                	xor    ebx,ebp
    733bdd209b21:	31 ee                	xor    esi,ebp
    733bdd209b23:	21 de                	and    esi,ebx
    733bdd209b25:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd209b28:	39 f9                	cmp    ecx,edi
    733bdd209b2a:	0f 92 c1             	setb   cl
    733bdd209b2d:	80 e1 01             	and    cl,0x1
    733bdd209b30:	0f b6 c9             	movzx  ecx,cl
    733bdd209b33:	83 fa 00             	cmp    edx,0x0
    733bdd209b36:	0f 94 c3             	sete   bl
    733bdd209b39:	80 e3 01             	and    bl,0x1
    733bdd209b3c:	0f b6 fb             	movzx  edi,bl
    733bdd209b3f:	c1 ea 1f             	shr    edx,0x1f
    733bdd209b42:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd209b48:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd209b4e:	89 f2                	mov    edx,esi
    733bdd209b50:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd209b56:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd209b5c:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd209b62:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd209b68:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd209b6e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd209b74:	eb 00                	jmp    0x733bdd209b76
    733bdd209b76:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209b7b:	8b 7c 24 c8          	mov    edi,DWORD PTR [rsp-0x38]
    733bdd209b7f:	89 fa                	mov    edx,edi
    733bdd209b81:	83 ea 00             	sub    edx,0x0
    733bdd209b84:	83 fa 00             	cmp    edx,0x0
    733bdd209b87:	0f 94 c1             	sete   cl
    733bdd209b8a:	80 e1 01             	and    cl,0x1
    733bdd209b8d:	0f b6 f1             	movzx  esi,cl
    733bdd209b90:	c1 ea 1f             	shr    edx,0x1f
    733bdd209b93:	89 f9                	mov    ecx,edi
    733bdd209b95:	c1 e9 1f             	shr    ecx,0x1f
    733bdd209b98:	89 d3                	mov    ebx,edx
    733bdd209b9a:	31 cb                	xor    ebx,ecx
    733bdd209b9c:	83 f1 00             	xor    ecx,0x0
    733bdd209b9f:	21 d9                	and    ecx,ebx
    733bdd209ba1:	31 ca                	xor    edx,ecx
    733bdd209ba3:	89 54 24 c4          	mov    DWORD PTR [rsp-0x3c],edx
    733bdd209ba7:	31 c9                	xor    ecx,ecx
    733bdd209ba9:	39 f9                	cmp    ecx,edi
    733bdd209bab:	0f 96 c1             	setbe  cl
    733bdd209bae:	80 e1 01             	and    cl,0x1
    733bdd209bb1:	0f b6 c9             	movzx  ecx,cl
    733bdd209bb4:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    733bdd209bba:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd209bc0:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd209bc6:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd209bcc:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd209bd2:	eb 00                	jmp    0x733bdd209bd4
    733bdd209bd4:	8b 44 24 c4          	mov    eax,DWORD PTR [rsp-0x3c]
    733bdd209bd8:	83 f8 00             	cmp    eax,0x0
    733bdd209bdb:	75 2d                	jne    0x733bdd209c0a
    733bdd209bdd:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd209be2:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10170
    733bdd209be9:	01 01 00 
    733bdd209bec:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd209bf2:	83 c0 05             	add    eax,0x5
    733bdd209bf5:	89 44 24 c0          	mov    DWORD PTR [rsp-0x40],eax
    733bdd209bf9:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd209bff:	0f 82 f3 00 00 00    	jb     0x733bdd209cf8
    733bdd209c05:	e9 0e 01 00 00       	jmp    0x733bdd209d18
    733bdd209c0a:	eb 00                	jmp    0x733bdd209c0c
    733bdd209c0c:	eb 00                	jmp    0x733bdd209c0e
    733bdd209c0e:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209c13:	8b 4c 24 c8          	mov    ecx,DWORD PTR [rsp-0x38]
    733bdd209c17:	33 08                	xor    ecx,DWORD PTR [rax]
    733bdd209c19:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd209c1b:	83 f9 00             	cmp    ecx,0x0
    733bdd209c1e:	0f 94 c2             	sete   dl
    733bdd209c21:	80 e2 01             	and    dl,0x1
    733bdd209c24:	0f b6 d2             	movzx  edx,dl
    733bdd209c27:	c1 e9 1f             	shr    ecx,0x1f
    733bdd209c2a:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd209c30:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd209c36:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    733bdd209c3d:	00 00 00 
    733bdd209c40:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    733bdd209c47:	00 00 00 
    733bdd209c4a:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd209c51:	00 00 00 
    733bdd209c54:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd209c5b:	00 00 00 
    733bdd209c5e:	eb 00                	jmp    0x733bdd209c60
    733bdd209c60:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd209c65:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    733bdd209c69:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    733bdd209c6d:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd209c73:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd209c79:	83 ff 01             	cmp    edi,0x1
    733bdd209c7c:	0f 97 c3             	seta   bl
    733bdd209c7f:	3d 88 01 01 00       	cmp    eax,0x10188
    733bdd209c84:	0f 94 c0             	sete   al
    733bdd209c87:	20 c3                	and    bl,al
    733bdd209c89:	b8 8c 01 01 00       	mov    eax,0x1018c
    733bdd209c8e:	f6 c3 01             	test   bl,0x1
    733bdd209c91:	0f 45 c2             	cmovne eax,edx
    733bdd209c94:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd209c9a:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd209ca0:	83 ff 01             	cmp    edi,0x1
    733bdd209ca3:	0f 97 c3             	seta   bl
    733bdd209ca6:	81 fe 88 01 01 00    	cmp    esi,0x10188
    733bdd209cac:	40 0f 94 c6          	sete   sil
    733bdd209cb0:	40 20 f3             	and    bl,sil
    733bdd209cb3:	f6 c3 01             	test   bl,0x1
    733bdd209cb6:	0f 45 c2             	cmovne eax,edx
    733bdd209cb9:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd209cbf:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10110
    733bdd209cc6:	01 01 00 
    733bdd209cc9:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd209ccf:	83 c0 07             	add    eax,0x7
    733bdd209cd2:	89 44 24 bc          	mov    DWORD PTR [rsp-0x44],eax
    733bdd209cd6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd209cdc:	0f 82 90 00 00 00    	jb     0x733bdd209d72
    733bdd209ce2:	e9 ab 00 00 00       	jmp    0x733bdd209d92
    733bdd209ce7:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209cec:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd209cf3:	e9 f1 00 00 00       	jmp    0x733bdd209de9
    733bdd209cf8:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd209cfd:	48 89 c1             	mov    rcx,rax
    733bdd209d00:	48 81 c1 80 0b 08 00 	add    rcx,0x80b80
    733bdd209d07:	48 89 4c 24 b0       	mov    QWORD PTR [rsp-0x50],rcx
    733bdd209d0c:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    733bdd209d13:	01 01 00 
    733bdd209d16:	74 2f                	je     0x733bdd209d47
    733bdd209d18:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209d1d:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10170
    733bdd209d24:	01 01 00 
    733bdd209d27:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd209d2e:	00 00 00 
    733bdd209d31:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd209d38:	00 00 00 
    733bdd209d3b:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd209d42:	e9 a2 00 00 00       	jmp    0x733bdd209de9
    733bdd209d47:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd209d4c:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd209d51:	48 8b 44 24 b0       	mov    rax,QWORD PTR [rsp-0x50]
    733bdd209d56:	8b 4c 24 c0          	mov    ecx,DWORD PTR [rsp-0x40]
    733bdd209d5a:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd209d61:	70 01 01 00 
    733bdd209d65:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd209d6c:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd209d70:	ff e0                	jmp    rax
    733bdd209d72:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd209d77:	48 89 c1             	mov    rcx,rax
    733bdd209d7a:	48 81 c1 80 08 08 00 	add    rcx,0x80880
    733bdd209d81:	48 89 4c 24 a8       	mov    QWORD PTR [rsp-0x58],rcx
    733bdd209d86:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    733bdd209d8d:	01 01 00 
    733bdd209d90:	74 2c                	je     0x733bdd209dbe
    733bdd209d92:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209d97:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10110
    733bdd209d9e:	01 01 00 
    733bdd209da1:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd209da8:	00 00 00 
    733bdd209dab:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd209db2:	00 00 00 
    733bdd209db5:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd209dbc:	eb 2b                	jmp    0x733bdd209de9
    733bdd209dbe:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd209dc3:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd209dc8:	48 8b 44 24 a8       	mov    rax,QWORD PTR [rsp-0x58]
    733bdd209dcd:	8b 4c 24 bc          	mov    ecx,DWORD PTR [rsp-0x44]
    733bdd209dd1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd209dd8:	10 01 01 00 
    733bdd209ddc:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd209de3:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd209de7:	ff e0                	jmp    rax
    733bdd209de9:	c2 08 00             	ret    0x8
