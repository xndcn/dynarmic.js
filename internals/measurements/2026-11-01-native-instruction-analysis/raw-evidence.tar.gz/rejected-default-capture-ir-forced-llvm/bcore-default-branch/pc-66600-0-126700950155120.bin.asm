
build-native-instruction-analysis/capture/bcore-default-branch/pc-66600-0-126700950155120.bin:     file format binary


Disassembly of section .data:

0000733bdd206f70 <.data>:
    733bdd206f70:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    733bdd206f77:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
    733bdd206f7e:	00 
    733bdd206f7f:	4c 89 ac 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r13
    733bdd206f86:	00 
    733bdd206f87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd206f8e:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    733bdd206f95:	00 
    733bdd206f96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd206f9d:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    733bdd206fa4:	00 
    733bdd206fa5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd206fac:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    733bdd206fb3:	00 
    733bdd206fb4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd206fbb:	00 
    733bdd206fbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd206fc2:	83 fa 00             	cmp    edx,0x0
    733bdd206fc5:	0f 94 c0             	sete   al
    733bdd206fc8:	81 ea 28 04 01 00    	sub    edx,0x10428
    733bdd206fce:	83 fa 18             	cmp    edx,0x18
    733bdd206fd1:	0f 97 c2             	seta   dl
    733bdd206fd4:	08 d0                	or     al,dl
    733bdd206fd6:	24 01                	and    al,0x1
    733bdd206fd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd206fde:	83 fa 00             	cmp    edx,0x0
    733bdd206fe1:	0f 94 c1             	sete   cl
    733bdd206fe4:	81 ea 28 04 01 00    	sub    edx,0x10428
    733bdd206fea:	83 fa 18             	cmp    edx,0x18
    733bdd206fed:	0f 97 c2             	seta   dl
    733bdd206ff0:	08 d1                	or     cl,dl
    733bdd206ff2:	20 c8                	and    al,cl
    733bdd206ff4:	a8 01                	test   al,0x1
    733bdd206ff6:	75 05                	jne    0x733bdd206ffd
    733bdd206ff8:	e9 4f 0b 00 00       	jmp    0x733bdd207b4c
    733bdd206ffd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207004:	00 
    733bdd207005:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20700c:	48 89 c8             	mov    rax,rcx
    733bdd20700f:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd207015:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    733bdd20701c:	00 
    733bdd20701d:	8b 81 14 00 10 00    	mov    eax,DWORD PTR [rcx+0x100014]
    733bdd207023:	83 c0 01             	add    eax,0x1
    733bdd207026:	89 81 14 00 10 00    	mov    DWORD PTR [rcx+0x100014],eax
    733bdd20702c:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd207031:	75 4c                	jne    0x733bdd20707f
    733bdd207033:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    733bdd20703a:	00 
    733bdd20703b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd207041:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    733bdd207048:	89 c2                	mov    edx,eax
    733bdd20704a:	83 c2 01             	add    edx,0x1
    733bdd20704d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd207053:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd207058:	73 23                	jae    0x733bdd20707d
    733bdd20705a:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    733bdd207061:	00 
    733bdd207062:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    733bdd207069:	89 c9                	mov    ecx,ecx
    733bdd20706b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20706f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd207076:	c7 04 08 05 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x5
    733bdd20707d:	eb 00                	jmp    0x733bdd20707f
    733bdd20707f:	eb 00                	jmp    0x733bdd207081
    733bdd207081:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207088:	00 
    733bdd207089:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    733bdd20708c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd207092:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd207098:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    733bdd20709f:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2070a2:	eb 00                	jmp    0x733bdd2070a4
    733bdd2070a4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd2070ab:	00 
    733bdd2070ac:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd2070af:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd2070b5:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    733bdd2070bc:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd2070bf:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    733bdd2070c6:	83 e8 04             	sub    eax,0x4
    733bdd2070c9:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd2070d0:	83 e0 03             	and    eax,0x3
    733bdd2070d3:	83 f8 00             	cmp    eax,0x0
    733bdd2070d6:	0f 84 98 00 00 00    	je     0x733bdd207174
    733bdd2070dc:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd2070e3:	00 
    733bdd2070e4:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd2070eb:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    733bdd2070f2:	00 
    733bdd2070f3:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    733bdd2070fa:	04 01 00 
    733bdd2070fd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd207104:	00 00 00 
    733bdd207107:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd20710e:	00 00 00 
    733bdd207111:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd207118:	59 00 00 
    733bdd20711b:	ba 2c 04 01 00       	mov    edx,0x1042c
    733bdd207120:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd207126:	ff d0                	call   rax
    733bdd207128:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20712f:	00 
    733bdd207130:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207136:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20713c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207142:	be 02 00 00 00       	mov    esi,0x2
    733bdd207147:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20714c:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207153:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd20715a:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207161:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207168:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd20716f:	e9 79 0a 00 00       	jmp    0x733bdd207bed
    733bdd207174:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd20717b:	00 
    733bdd20717c:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd207183:	c1 e9 0c             	shr    ecx,0xc
    733bdd207186:	89 c9                	mov    ecx,ecx
    733bdd207188:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20718c:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd207193:	00 
    733bdd207194:	48 83 f8 00          	cmp    rax,0x0
    733bdd207198:	74 23                	je     0x733bdd2071bd
    733bdd20719a:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd2071a1:	00 
    733bdd2071a2:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd2071a9:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd2071b0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2071b6:	89 c9                	mov    ecx,ecx
    733bdd2071b8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2071bb:	eb 5b                	jmp    0x733bdd207218
    733bdd2071bd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2071c4:	00 
    733bdd2071c5:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd2071cc:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    733bdd2071d3:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    733bdd2071da:	00 
    733bdd2071db:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    733bdd2071e2:	04 01 00 
    733bdd2071e5:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2071ec:	00 00 00 
    733bdd2071ef:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd2071f6:	00 00 00 
    733bdd2071f9:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd207200:	59 00 00 
    733bdd207203:	ff d0                	call   rax
    733bdd207205:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20720c:	00 
    733bdd20720d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd207214:	75 20                	jne    0x733bdd207236
    733bdd207216:	eb 6a                	jmp    0x733bdd207282
    733bdd207218:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    733bdd20721f:	83 e8 04             	sub    eax,0x4
    733bdd207222:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd207229:	83 e0 03             	and    eax,0x3
    733bdd20722c:	83 f8 00             	cmp    eax,0x0
    733bdd20722f:	75 53                	jne    0x733bdd207284
    733bdd207231:	e9 e6 00 00 00       	jmp    0x733bdd20731c
    733bdd207236:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20723d:	00 
    733bdd20723e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207244:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20724a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207250:	be 02 00 00 00       	mov    esi,0x2
    733bdd207255:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20725a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207261:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207268:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd20726f:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207276:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd20727d:	e9 6b 09 00 00       	jmp    0x733bdd207bed
    733bdd207282:	eb 94                	jmp    0x733bdd207218
    733bdd207284:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd20728b:	00 
    733bdd20728c:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd207293:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    733bdd20729a:	00 
    733bdd20729b:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    733bdd2072a2:	04 01 00 
    733bdd2072a5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2072ac:	00 00 00 
    733bdd2072af:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd2072b6:	00 00 00 
    733bdd2072b9:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2072c0:	59 00 00 
    733bdd2072c3:	ba 2c 04 01 00       	mov    edx,0x1042c
    733bdd2072c8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2072ce:	ff d0                	call   rax
    733bdd2072d0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2072d7:	00 
    733bdd2072d8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2072de:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2072e4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2072ea:	be 02 00 00 00       	mov    esi,0x2
    733bdd2072ef:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2072f4:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd2072fb:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207302:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207309:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207310:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207317:	e9 d1 08 00 00       	jmp    0x733bdd207bed
    733bdd20731c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd207323:	00 
    733bdd207324:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20732b:	c1 e9 0c             	shr    ecx,0xc
    733bdd20732e:	89 c9                	mov    ecx,ecx
    733bdd207330:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd207334:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    733bdd20733b:	00 
    733bdd20733c:	48 83 f8 00          	cmp    rax,0x0
    733bdd207340:	74 23                	je     0x733bdd207365
    733bdd207342:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    733bdd207349:	00 
    733bdd20734a:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    733bdd207351:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd207358:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20735e:	89 c9                	mov    ecx,ecx
    733bdd207360:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd207363:	eb 5b                	jmp    0x733bdd2073c0
    733bdd207365:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20736c:	00 
    733bdd20736d:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    733bdd207374:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    733bdd20737b:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    733bdd207382:	00 
    733bdd207383:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    733bdd20738a:	04 01 00 
    733bdd20738d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd207394:	00 00 00 
    733bdd207397:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd20739e:	00 00 00 
    733bdd2073a1:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2073a8:	59 00 00 
    733bdd2073ab:	ff d0                	call   rax
    733bdd2073ad:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2073b4:	00 
    733bdd2073b5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2073bc:	75 2c                	jne    0x733bdd2073ea
    733bdd2073be:	eb 76                	jmp    0x733bdd207436
    733bdd2073c0:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd2073c7:	00 
    733bdd2073c8:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd2073cf:	00 
    733bdd2073d0:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    733bdd2073d7:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd2073da:	83 ea 00             	sub    edx,0x0
    733bdd2073dd:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd2073e0:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2073e3:	75 53                	jne    0x733bdd207438
    733bdd2073e5:	e9 93 00 00 00       	jmp    0x733bdd20747d
    733bdd2073ea:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2073f1:	00 
    733bdd2073f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2073f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2073fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207404:	be 02 00 00 00       	mov    esi,0x2
    733bdd207409:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20740e:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207415:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd20741c:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207423:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd20742a:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207431:	e9 b7 07 00 00       	jmp    0x733bdd207bed
    733bdd207436:	eb 88                	jmp    0x733bdd2073c0
    733bdd207438:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd20743f:	00 
    733bdd207440:	c7 87 bc 00 00 00 30 	mov    DWORD PTR [rdi+0xbc],0x10430
    733bdd207447:	04 01 00 
    733bdd20744a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd207451:	00 00 00 
    733bdd207454:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd20745b:	00 00 00 
    733bdd20745e:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd207465:	59 00 00 
    733bdd207468:	ff d0                	call   rax
    733bdd20746a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207471:	00 
    733bdd207472:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd207479:	75 04                	jne    0x733bdd20747f
    733bdd20747b:	eb 4e                	jmp    0x733bdd2074cb
    733bdd20747d:	eb 4e                	jmp    0x733bdd2074cd
    733bdd20747f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207486:	00 
    733bdd207487:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20748d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207493:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207499:	be 02 00 00 00       	mov    esi,0x2
    733bdd20749e:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2074a3:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd2074aa:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd2074b1:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd2074b8:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd2074bf:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd2074c6:	e9 22 07 00 00       	jmp    0x733bdd207bed
    733bdd2074cb:	eb b0                	jmp    0x733bdd20747d
    733bdd2074cd:	eb 00                	jmp    0x733bdd2074cf
    733bdd2074cf:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2074d6:	00 
    733bdd2074d7:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    733bdd2074de:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2074e4:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    733bdd2074ea:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    733bdd2074f1:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2074f4:	eb 00                	jmp    0x733bdd2074f6
    733bdd2074f6:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    733bdd2074fd:	83 e0 03             	and    eax,0x3
    733bdd207500:	83 f8 00             	cmp    eax,0x0
    733bdd207503:	0f 84 97 00 00 00    	je     0x733bdd2075a0
    733bdd207509:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd207510:	00 
    733bdd207511:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd207518:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    733bdd20751f:	00 
    733bdd207520:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10434
    733bdd207527:	04 01 00 
    733bdd20752a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd207531:	00 00 00 
    733bdd207534:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    733bdd20753b:	00 00 00 
    733bdd20753e:	31 c0                	xor    eax,eax
    733bdd207540:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd207547:	59 00 00 
    733bdd20754a:	ba 34 04 01 00       	mov    edx,0x10434
    733bdd20754f:	45 31 c0             	xor    r8d,r8d
    733bdd207552:	ff d0                	call   rax
    733bdd207554:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20755b:	00 
    733bdd20755c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207562:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207568:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20756e:	be 04 00 00 00       	mov    esi,0x4
    733bdd207573:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207578:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd20757f:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207586:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd20758d:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207594:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd20759b:	e9 4d 06 00 00       	jmp    0x733bdd207bed
    733bdd2075a0:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd2075a7:	00 
    733bdd2075a8:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd2075af:	c1 e9 0c             	shr    ecx,0xc
    733bdd2075b2:	89 c9                	mov    ecx,ecx
    733bdd2075b4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2075b8:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd2075bd:	48 83 f8 00          	cmp    rax,0x0
    733bdd2075c1:	74 1d                	je     0x733bdd2075e0
    733bdd2075c3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd2075c8:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd2075cf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2075d5:	89 c9                	mov    ecx,ecx
    733bdd2075d7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2075da:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd2075de:	eb 5a                	jmp    0x733bdd20763a
    733bdd2075e0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2075e7:	00 
    733bdd2075e8:	8b b4 24 84 00 00 00 	mov    esi,DWORD PTR [rsp+0x84]
    733bdd2075ef:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    733bdd2075f6:	00 
    733bdd2075f7:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10434
    733bdd2075fe:	04 01 00 
    733bdd207601:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd207608:	00 00 00 
    733bdd20760b:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    733bdd207612:	00 00 00 
    733bdd207615:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20761c:	59 00 00 
    733bdd20761f:	ff d0                	call   rax
    733bdd207621:	89 c1                	mov    ecx,eax
    733bdd207623:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20762a:	00 
    733bdd20762b:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd20762f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd207636:	75 17                	jne    0x733bdd20764f
    733bdd207638:	eb 61                	jmp    0x733bdd20769b
    733bdd20763a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207641:	00 
    733bdd207642:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd207646:	89 4c 24 6c          	mov    DWORD PTR [rsp+0x6c],ecx
    733bdd20764a:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20764d:	eb 56                	jmp    0x733bdd2076a5
    733bdd20764f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207656:	00 
    733bdd207657:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20765d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207663:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207669:	be 04 00 00 00       	mov    esi,0x4
    733bdd20766e:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207673:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd20767a:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207681:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207688:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd20768f:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207696:	e9 52 05 00 00       	jmp    0x733bdd207bed
    733bdd20769b:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    733bdd20769f:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd2076a3:	eb 95                	jmp    0x733bdd20763a
    733bdd2076a5:	eb 00                	jmp    0x733bdd2076a7
    733bdd2076a7:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2076ae:	00 
    733bdd2076af:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    733bdd2076b3:	83 f9 04             	cmp    ecx,0x4
    733bdd2076b6:	0f 96 c1             	setbe  cl
    733bdd2076b9:	80 e1 01             	and    cl,0x1
    733bdd2076bc:	0f b6 c9             	movzx  ecx,cl
    733bdd2076bf:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd2076c3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    733bdd2076c9:	eb 00                	jmp    0x733bdd2076cb
    733bdd2076cb:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    733bdd2076cf:	83 f8 00             	cmp    eax,0x0
    733bdd2076d2:	74 30                	je     0x733bdd207704
    733bdd2076d4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd2076db:	00 
    733bdd2076dc:	c7 81 bc 00 00 00 42 	mov    DWORD PTR [rcx+0xbc],0x10442
    733bdd2076e3:	04 01 00 
    733bdd2076e6:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd2076ec:	83 c0 06             	add    eax,0x6
    733bdd2076ef:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd2076f3:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd2076f9:	0f 82 61 04 00 00    	jb     0x733bdd207b60
    733bdd2076ff:	e9 7f 04 00 00       	jmp    0x733bdd207b83
    733bdd207704:	eb 00                	jmp    0x733bdd207706
    733bdd207706:	eb 00                	jmp    0x733bdd207708
    733bdd207708:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20770f:	00 
    733bdd207710:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    733bdd207716:	eb 00                	jmp    0x733bdd207718
    733bdd207718:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    733bdd20771f:	83 e0 03             	and    eax,0x3
    733bdd207722:	83 f8 00             	cmp    eax,0x0
    733bdd207725:	0f 84 97 00 00 00    	je     0x733bdd2077c2
    733bdd20772b:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd207732:	00 
    733bdd207733:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20773a:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    733bdd207741:	00 
    733bdd207742:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    733bdd207749:	04 01 00 
    733bdd20774c:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd207753:	00 00 00 
    733bdd207756:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    733bdd20775d:	00 00 00 
    733bdd207760:	31 c0                	xor    eax,eax
    733bdd207762:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd207769:	59 00 00 
    733bdd20776c:	ba 3c 04 01 00       	mov    edx,0x1043c
    733bdd207771:	45 31 c0             	xor    r8d,r8d
    733bdd207774:	ff d0                	call   rax
    733bdd207776:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20777d:	00 
    733bdd20777e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207784:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20778a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207790:	be 08 00 00 00       	mov    esi,0x8
    733bdd207795:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20779a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd2077a1:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd2077a8:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd2077af:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd2077b6:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd2077bd:	e9 2b 04 00 00       	jmp    0x733bdd207bed
    733bdd2077c2:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd2077c9:	00 
    733bdd2077ca:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd2077d1:	c1 e9 0c             	shr    ecx,0xc
    733bdd2077d4:	89 c9                	mov    ecx,ecx
    733bdd2077d6:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2077da:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd2077df:	48 83 f8 00          	cmp    rax,0x0
    733bdd2077e3:	74 1d                	je     0x733bdd207802
    733bdd2077e5:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd2077ea:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd2077f1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2077f7:	89 c9                	mov    ecx,ecx
    733bdd2077f9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2077fc:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd207800:	eb 5a                	jmp    0x733bdd20785c
    733bdd207802:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207809:	00 
    733bdd20780a:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    733bdd207811:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    733bdd207818:	00 
    733bdd207819:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    733bdd207820:	04 01 00 
    733bdd207823:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20782a:	00 00 00 
    733bdd20782d:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd207834:	00 00 00 
    733bdd207837:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20783e:	59 00 00 
    733bdd207841:	ff d0                	call   rax
    733bdd207843:	89 c1                	mov    ecx,eax
    733bdd207845:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd20784c:	00 
    733bdd20784d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd207851:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd207858:	75 25                	jne    0x733bdd20787f
    733bdd20785a:	eb 6f                	jmp    0x733bdd2078cb
    733bdd20785c:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    733bdd207863:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd207867:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd20786b:	83 c0 04             	add    eax,0x4
    733bdd20786e:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd207872:	83 e0 03             	and    eax,0x3
    733bdd207875:	83 f8 00             	cmp    eax,0x0
    733bdd207878:	75 5b                	jne    0x733bdd2078d5
    733bdd20787a:	e9 ea 00 00 00       	jmp    0x733bdd207969
    733bdd20787f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207886:	00 
    733bdd207887:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20788d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207893:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207899:	be 08 00 00 00       	mov    esi,0x8
    733bdd20789e:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2078a3:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd2078aa:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd2078b1:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd2078b8:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd2078bf:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd2078c6:	e9 22 03 00 00       	jmp    0x733bdd207bed
    733bdd2078cb:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    733bdd2078cf:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd2078d3:	eb 87                	jmp    0x733bdd20785c
    733bdd2078d5:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd2078dc:	00 
    733bdd2078dd:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd2078e1:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    733bdd2078e8:	00 
    733bdd2078e9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    733bdd2078f0:	04 01 00 
    733bdd2078f3:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2078fa:	00 00 00 
    733bdd2078fd:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    733bdd207904:	00 00 00 
    733bdd207907:	31 c0                	xor    eax,eax
    733bdd207909:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd207910:	59 00 00 
    733bdd207913:	ba 3c 04 01 00       	mov    edx,0x1043c
    733bdd207918:	45 31 c0             	xor    r8d,r8d
    733bdd20791b:	ff d0                	call   rax
    733bdd20791d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207924:	00 
    733bdd207925:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20792b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207931:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207937:	be 08 00 00 00       	mov    esi,0x8
    733bdd20793c:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd207941:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207948:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd20794f:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207956:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd20795d:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207964:	e9 84 02 00 00       	jmp    0x733bdd207bed
    733bdd207969:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd207970:	00 
    733bdd207971:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd207975:	c1 e9 0c             	shr    ecx,0xc
    733bdd207978:	89 c9                	mov    ecx,ecx
    733bdd20797a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20797e:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    733bdd207983:	48 83 f8 00          	cmp    rax,0x0
    733bdd207987:	74 1a                	je     0x733bdd2079a3
    733bdd207989:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    733bdd20798e:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd207992:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd207998:	89 c9                	mov    ecx,ecx
    733bdd20799a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20799d:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    733bdd2079a1:	eb 57                	jmp    0x733bdd2079fa
    733bdd2079a3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2079aa:	00 
    733bdd2079ab:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    733bdd2079af:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    733bdd2079b6:	00 
    733bdd2079b7:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    733bdd2079be:	04 01 00 
    733bdd2079c1:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2079c8:	00 00 00 
    733bdd2079cb:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd2079d2:	00 00 00 
    733bdd2079d5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2079dc:	59 00 00 
    733bdd2079df:	ff d0                	call   rax
    733bdd2079e1:	89 c1                	mov    ecx,eax
    733bdd2079e3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd2079ea:	00 
    733bdd2079eb:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    733bdd2079ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2079f6:	75 2b                	jne    0x733bdd207a23
    733bdd2079f8:	eb 75                	jmp    0x733bdd207a6f
    733bdd2079fa:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207a01:	00 
    733bdd207a02:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    733bdd207a06:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd207a0a:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    733bdd207a0e:	89 54 24 34          	mov    DWORD PTR [rsp+0x34],edx
    733bdd207a12:	83 c1 04             	add    ecx,0x4
    733bdd207a15:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd207a18:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd207a1e:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd207a21:	eb 56                	jmp    0x733bdd207a79
    733bdd207a23:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207a2a:	00 
    733bdd207a2b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207a31:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207a37:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207a3d:	be 08 00 00 00       	mov    esi,0x8
    733bdd207a42:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd207a47:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207a4e:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207a55:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207a5c:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207a63:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207a6a:	e9 7e 01 00 00       	jmp    0x733bdd207bed
    733bdd207a6f:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    733bdd207a73:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    733bdd207a77:	eb 81                	jmp    0x733bdd2079fa
    733bdd207a79:	eb 00                	jmp    0x733bdd207a7b
    733bdd207a7b:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    733bdd207a7f:	83 e0 01             	and    eax,0x1
    733bdd207a82:	83 f8 00             	cmp    eax,0x0
    733bdd207a85:	75 3a                	jne    0x733bdd207ac1
    733bdd207a87:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    733bdd207a8b:	be 09 00 00 00       	mov    esi,0x9
    733bdd207a90:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207a95:	b0 01                	mov    al,0x1
    733bdd207a97:	89 d7                	mov    edi,edx
    733bdd207a99:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207aa0:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207aa7:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207aae:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207ab5:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207abc:	e9 2c 01 00 00       	jmp    0x733bdd207bed
    733bdd207ac1:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    733bdd207ac8:	00 
    733bdd207ac9:	48 8b 94 24 d0 00 00 	mov    rdx,QWORD PTR [rsp+0xd0]
    733bdd207ad0:	00 
    733bdd207ad1:	c7 87 bc 00 00 00 40 	mov    DWORD PTR [rdi+0xbc],0x10440
    733bdd207ad8:	04 01 00 
    733bdd207adb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd207ae2:	00 00 00 
    733bdd207ae5:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    733bdd207aec:	00 00 00 
    733bdd207aef:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd207af6:	59 00 00 
    733bdd207af9:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd207afe:	ff d0                	call   rax
    733bdd207b00:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207b07:	00 
    733bdd207b08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd207b0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd207b14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd207b1a:	be 09 00 00 00       	mov    esi,0x9
    733bdd207b1f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd207b24:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    733bdd207b2b:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    733bdd207b32:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    733bdd207b39:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    733bdd207b40:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    733bdd207b47:	e9 a1 00 00 00       	jmp    0x733bdd207bed
    733bdd207b4c:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207b53:	00 
    733bdd207b54:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd207b5b:	e9 7f 01 00 00       	jmp    0x733bdd207cdf
    733bdd207b60:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    733bdd207b67:	00 
    733bdd207b68:	48 89 c1             	mov    rcx,rax
    733bdd207b6b:	48 81 c1 10 22 08 00 	add    rcx,0x82210
    733bdd207b72:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd207b77:	81 b8 10 22 08 00 42 	cmp    DWORD PTR [rax+0x82210],0x10442
    733bdd207b7e:	04 01 00 
    733bdd207b81:	74 32                	je     0x733bdd207bb5
    733bdd207b83:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207b8a:	00 
    733bdd207b8b:	c7 80 bc 00 00 00 42 	mov    DWORD PTR [rax+0xbc],0x10442
    733bdd207b92:	04 01 00 
    733bdd207b95:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd207b9c:	00 00 00 
    733bdd207b9f:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd207ba6:	00 00 00 
    733bdd207ba9:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd207bb0:	e9 2a 01 00 00       	jmp    0x733bdd207cdf
    733bdd207bb5:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    733bdd207bbc:	00 
    733bdd207bbd:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    733bdd207bc4:	00 
    733bdd207bc5:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd207bca:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd207bce:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    733bdd207bd5:	42 04 01 00 
    733bdd207bd9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd207be0:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd207be4:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    733bdd207beb:	ff e0                	jmp    rax
    733bdd207bed:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    733bdd207bf4:	00 
    733bdd207bf5:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    733bdd207bfc:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    733bdd207c03:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    733bdd207c0a:	8b bc 24 ac 00 00 00 	mov    edi,DWORD PTR [rsp+0xac]
    733bdd207c11:	8a 9c 24 b3 00 00 00 	mov    bl,BYTE PTR [rsp+0xb3]
    733bdd207c18:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    733bdd207c1c:	89 c3                	mov    ebx,eax
    733bdd207c1e:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    733bdd207c22:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    733bdd207c26:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    733bdd207c2a:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    733bdd207c2e:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd207c34:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    733bdd207c38:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd207c3e:	73 2d                	jae    0x733bdd207c6d
    733bdd207c40:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    733bdd207c47:	00 
    733bdd207c48:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd207c4c:	89 d1                	mov    ecx,edx
    733bdd207c4e:	c1 e9 01             	shr    ecx,0x1
    733bdd207c51:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd207c57:	89 c9                	mov    ecx,ecx
    733bdd207c59:	48 c1 e1 04          	shl    rcx,0x4
    733bdd207c5d:	48 89 c6             	mov    rsi,rax
    733bdd207c60:	48 01 ce             	add    rsi,rcx
    733bdd207c63:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd207c68:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd207c6b:	74 32                	je     0x733bdd207c9f
    733bdd207c6d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    733bdd207c74:	00 
    733bdd207c75:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    733bdd207c79:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd207c7d:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    733bdd207c81:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    733bdd207c85:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd207c8b:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd207c91:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd207c97:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd207c9d:	eb 40                	jmp    0x733bdd207cdf
    733bdd207c9f:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    733bdd207ca6:	00 
    733bdd207ca7:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    733bdd207cae:	00 
    733bdd207caf:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd207cb4:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    733bdd207cb8:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd207cbc:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd207cc3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd207cca:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd207cd1:	00 
    733bdd207cd2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd207cd6:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    733bdd207cdd:	ff e0                	jmp    rax
    733bdd207cdf:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    733bdd207ce6:	c2 08 00             	ret    0x8
