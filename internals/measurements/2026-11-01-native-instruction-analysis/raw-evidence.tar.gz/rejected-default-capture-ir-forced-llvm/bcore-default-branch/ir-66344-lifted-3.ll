; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010328(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 66344
  %6 = icmp ugt i32 %5, 70
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb318 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb318, 0
  %11 = sub i32 %guard_lb318, 66344
  %12 = icmp ugt i32 %11, 70
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010328_entry, label %lb_guard_miss, !prof !0

insn_0x00010328_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table407 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table407, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 12
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 50625
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010328_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 3, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010328_entry, %28
  br label %insn_0x00010328

insn_0x00010328:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 24
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010328
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 188
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  %40 = load i8, ptr %39, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010328
  %41 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %41 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %42 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %42 to i64
  %43 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %43, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %45, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %46 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %46, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %47 = getelementptr i8, ptr %cpu, i32 28
  %r2 = load i32, ptr %47, align 4
  %48 = and i32 %sp_dec1, 3
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %50 = getelementptr i8, ptr %cpu, i64 188
  %next_pc319 = load i32, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 188
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %cpu, i64 296
  %54 = load i8, ptr %53, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %55 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %56, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec1, i32 65536)
  %57 = getelementptr i8, ptr %cpu, i64 188
  %next_pc320 = load i32, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 188
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %cpu, i64 296
  %61 = load i8, ptr %60, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %62 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %62 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %63 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %63 to i64
  %64 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %64, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %65 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %66, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %67 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %67, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %sp_dec17 = sub i32 %sp_dec1, 4
  %68 = getelementptr i8, ptr %cpu, i32 44
  %p = load i32, ptr %68, align 4
  %69 = and i32 %sp_dec17, 3
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %data_misaligned18, label %data_aligned19, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %71 = getelementptr i8, ptr %cpu, i64 188
  %next_pc321 = load i32, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i64 188
  %73 = load i32, ptr %72, align 4
  %74 = getelementptr i8, ptr %cpu, i64 296
  %75 = load i8, ptr %74, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

data_misaligned18:                                ; preds = %page_wr_done7
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %77, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec17, i32 65536)
  %78 = getelementptr i8, ptr %cpu, i64 188
  %next_pc322 = load i32, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 188
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %cpu, i64 296
  %82 = load i8, ptr %81, align 1
  br label %chain_exit

data_aligned19:                                   ; preds = %page_wr_done7
  %83 = lshr i32 %sp_dec17, 12
  %page_index23 = zext i32 %83 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26 = icmp ne ptr %page25, null
  br i1 %page_mapped26, label %page_wr_fast20, label %page_wr_slow21, !prof !0

page_wr_fast20:                                   ; preds = %data_aligned19
  %84 = and i32 %sp_dec17, 4095
  %page_offset27 = zext i32 %84 to i64
  %85 = getelementptr i8, ptr %page25, i64 %page_offset27
  store i32 %p, ptr %85, align 4
  br label %page_wr_done22

page_wr_slow21:                                   ; preds = %data_aligned19
  %86 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %87, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %p)
  %88 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %88, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_wr_done22:                                   ; preds = %did_jump_cont29, %page_wr_fast20
  %sp_dec32 = sub i32 %sp_dec17, 4
  %89 = getelementptr i8, ptr %cpu, i32 48
  %p33 = load i32, ptr %89, align 4
  %90 = and i32 %sp_dec32, 3
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %data_misaligned34, label %data_aligned35, !prof !1

did_jump_exit28:                                  ; preds = %page_wr_slow21
  %92 = getelementptr i8, ptr %cpu, i64 188
  %next_pc323 = load i32, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 188
  %94 = load i32, ptr %93, align 4
  %95 = getelementptr i8, ptr %cpu, i64 296
  %96 = load i8, ptr %95, align 1
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_wr_slow21
  br label %page_wr_done22

data_misaligned34:                                ; preds = %page_wr_done22
  %97 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %98, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec32, i32 65536)
  %99 = getelementptr i8, ptr %cpu, i64 188
  %next_pc324 = load i32, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 188
  %101 = load i32, ptr %100, align 4
  %102 = getelementptr i8, ptr %cpu, i64 296
  %103 = load i8, ptr %102, align 1
  br label %chain_exit

data_aligned35:                                   ; preds = %page_wr_done22
  %104 = lshr i32 %sp_dec32, 12
  %page_index39 = zext i32 %104 to i64
  %page_slot40 = getelementptr ptr, ptr %page_table, i64 %page_index39
  %page41 = load ptr, ptr %page_slot40, align 8
  %page_mapped42 = icmp ne ptr %page41, null
  br i1 %page_mapped42, label %page_wr_fast36, label %page_wr_slow37, !prof !0

page_wr_fast36:                                   ; preds = %data_aligned35
  %105 = and i32 %sp_dec32, 4095
  %page_offset43 = zext i32 %105 to i64
  %106 = getelementptr i8, ptr %page41, i64 %page_offset43
  store i32 %p33, ptr %106, align 4
  br label %page_wr_done38

page_wr_slow37:                                   ; preds = %data_aligned35
  %107 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %108, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec32, i32 %p33)
  %109 = getelementptr i8, ptr %cpu, i32 296
  %dj46 = load i8, ptr %109, align 1
  %dj_set47 = icmp ne i8 %dj46, 0
  br i1 %dj_set47, label %did_jump_exit44, label %did_jump_cont45, !prof !1

page_wr_done38:                                   ; preds = %did_jump_cont45, %page_wr_fast36
  %sp_dec48 = sub i32 %sp_dec32, 4
  %110 = getelementptr i8, ptr %cpu, i32 52
  %p49 = load i32, ptr %110, align 4
  %111 = and i32 %sp_dec48, 3
  %112 = icmp ne i32 %111, 0
  br i1 %112, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit44:                                  ; preds = %page_wr_slow37
  %113 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 188
  %115 = load i32, ptr %114, align 4
  %116 = getelementptr i8, ptr %cpu, i64 296
  %117 = load i8, ptr %116, align 1
  br label %chain_exit

did_jump_cont45:                                  ; preds = %page_wr_slow37
  br label %page_wr_done38

data_misaligned50:                                ; preds = %page_wr_done38
  %118 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %119, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66344, i32 %sp_dec48, i32 65536)
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc326 = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

data_aligned51:                                   ; preds = %page_wr_done38
  %125 = lshr i32 %sp_dec48, 12
  %page_index55 = zext i32 %125 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_wr_fast52, label %page_wr_slow53, !prof !0

page_wr_fast52:                                   ; preds = %data_aligned51
  %126 = and i32 %sp_dec48, 4095
  %page_offset59 = zext i32 %126 to i64
  %127 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p49, ptr %127, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %data_aligned51
  %128 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %129, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec48, i32 %p49)
  %130 = getelementptr i8, ptr %cpu, i32 296
  %dj62 = load i8, ptr %130, align 1
  %dj_set63 = icmp ne i8 %dj62, 0
  br i1 %dj_set63, label %did_jump_exit60, label %did_jump_cont61, !prof !1

page_wr_done54:                                   ; preds = %did_jump_cont61, %page_wr_fast52
  %131 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec48, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %133, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %134 = icmp ne i8 %cec_pending, 0
  br i1 %134, label %cec_check, label %cec_checked, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %135 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i64 188
  %137 = load i32, ptr %136, align 4
  %138 = getelementptr i8, ptr %cpu, i64 296
  %139 = load i8, ptr %138, align 1
  br label %chain_exit

did_jump_cont61:                                  ; preds = %page_wr_slow53
  br label %page_wr_done54

cec_check:                                        ; preds = %page_wr_done54
  %140 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %142, align 4
  call void @cec_check_pending(ptr %cpu)
  %143 = getelementptr i8, ptr %cpu, i32 296
  %dj66 = load i8, ptr %143, align 1
  %dj_set67 = icmp ne i8 %dj66, 0
  br i1 %dj_set67, label %did_jump_exit64, label %did_jump_cont65, !prof !1

cec_checked:                                      ; preds = %did_jump_cont65, %page_wr_done54
  br label %insn_0x0001032a_entry

did_jump_exit64:                                  ; preds = %cec_check
  %144 = getelementptr i8, ptr %cpu, i64 188
  %next_pc328 = load i32, ptr %144, align 4
  %145 = getelementptr i8, ptr %cpu, i64 188
  %146 = load i32, ptr %145, align 4
  %147 = getelementptr i8, ptr %cpu, i64 296
  %148 = load i8, ptr %147, align 1
  br label %chain_exit

did_jump_cont65:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x0001032a_entry:                            ; preds = %cec_checked
  br label %insn_0x0001032a

insn_0x0001032a:                                  ; preds = %insn_0x0001032a_entry
  %149 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %150, align 4
  %sp1 = sub i32 %sp_dec48, 4
  %151 = and i32 %sp1, 3
  %152 = icmp ne i32 %151, 0
  br i1 %152, label %data_misaligned68, label %data_aligned69, !prof !1

data_misaligned68:                                ; preds = %insn_0x0001032a
  %153 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %153, align 4
  %154 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %155, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66346, i32 %sp1, i32 65536)
  %156 = getelementptr i8, ptr %cpu, i64 188
  %next_pc329 = load i32, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i64 188
  %158 = load i32, ptr %157, align 4
  %159 = getelementptr i8, ptr %cpu, i64 296
  %160 = load i8, ptr %159, align 1
  br label %chain_exit

data_aligned69:                                   ; preds = %insn_0x0001032a
  %161 = lshr i32 %sp1, 12
  %page_index73 = zext i32 %161 to i64
  %page_slot74 = getelementptr ptr, ptr %page_table, i64 %page_index73
  %page75 = load ptr, ptr %page_slot74, align 8
  %page_mapped76 = icmp ne ptr %page75, null
  br i1 %page_mapped76, label %page_wr_fast70, label %page_wr_slow71, !prof !0

page_wr_fast70:                                   ; preds = %data_aligned69
  %162 = and i32 %sp1, 4095
  %page_offset77 = zext i32 %162 to i64
  %163 = getelementptr i8, ptr %page75, i64 %page_offset77
  store i32 %rets, ptr %163, align 4
  br label %page_wr_done72

page_wr_slow71:                                   ; preds = %data_aligned69
  %164 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %165, align 4
  %166 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %166, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %167 = getelementptr i8, ptr %cpu, i32 296
  %dj80 = load i8, ptr %167, align 1
  %dj_set81 = icmp ne i8 %dj80, 0
  br i1 %dj_set81, label %did_jump_exit78, label %did_jump_cont79, !prof !1

page_wr_done72:                                   ; preds = %did_jump_cont79, %page_wr_fast70
  %sp2 = sub i32 %sp1, 4
  %168 = and i32 %sp2, 3
  %169 = icmp ne i32 %168, 0
  br i1 %169, label %data_misaligned82, label %data_aligned83, !prof !1

did_jump_exit78:                                  ; preds = %page_wr_slow71
  %170 = getelementptr i8, ptr %cpu, i64 188
  %next_pc330 = load i32, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i64 188
  %172 = load i32, ptr %171, align 4
  %173 = getelementptr i8, ptr %cpu, i64 296
  %174 = load i8, ptr %173, align 1
  br label %chain_exit

did_jump_cont79:                                  ; preds = %page_wr_slow71
  br label %page_wr_done72

data_misaligned82:                                ; preds = %page_wr_done72
  %175 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %177, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66346, i32 %sp2, i32 65536)
  %178 = getelementptr i8, ptr %cpu, i64 188
  %next_pc331 = load i32, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i64 188
  %180 = load i32, ptr %179, align 4
  %181 = getelementptr i8, ptr %cpu, i64 296
  %182 = load i8, ptr %181, align 1
  br label %chain_exit

data_aligned83:                                   ; preds = %page_wr_done72
  %183 = lshr i32 %sp2, 12
  %page_index87 = zext i32 %183 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90 = icmp ne ptr %page89, null
  br i1 %page_mapped90, label %page_wr_fast84, label %page_wr_slow85, !prof !0

page_wr_fast84:                                   ; preds = %data_aligned83
  %184 = and i32 %sp2, 4095
  %page_offset91 = zext i32 %184 to i64
  %185 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %fp, ptr %185, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %data_aligned83
  %186 = getelementptr i8, ptr %cpu, i32 188
  store i32 66346, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %187, align 4
  %188 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %188, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %189 = getelementptr i8, ptr %cpu, i32 296
  %dj94 = load i8, ptr %189, align 1
  %dj_set95 = icmp ne i8 %dj94, 0
  br i1 %dj_set95, label %did_jump_exit92, label %did_jump_cont93, !prof !1

page_wr_done86:                                   ; preds = %did_jump_cont93, %page_wr_fast84
  %190 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %190, align 4
  %sp3 = sub i32 %sp2, 0
  %191 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %191, align 4
  %cec_pending96 = load i8, ptr %cec_pending_flag, align 1
  %192 = icmp ne i8 %cec_pending96, 0
  br i1 %192, label %cec_check97, label %cec_checked98, !prof !1

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %193 = getelementptr i8, ptr %cpu, i64 188
  %next_pc332 = load i32, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i64 188
  %195 = load i32, ptr %194, align 4
  %196 = getelementptr i8, ptr %cpu, i64 296
  %197 = load i8, ptr %196, align 1
  br label %chain_exit

did_jump_cont93:                                  ; preds = %page_wr_slow85
  br label %page_wr_done86

cec_check97:                                      ; preds = %page_wr_done86
  %198 = getelementptr i8, ptr %cpu, i32 188
  store i32 66350, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %200, align 4
  call void @cec_check_pending(ptr %cpu)
  %201 = getelementptr i8, ptr %cpu, i32 296
  %dj101 = load i8, ptr %201, align 1
  %dj_set102 = icmp ne i8 %dj101, 0
  br i1 %dj_set102, label %did_jump_exit99, label %did_jump_cont100, !prof !1

cec_checked98:                                    ; preds = %did_jump_cont100, %page_wr_done86
  br label %insn_0x0001032e_entry

did_jump_exit99:                                  ; preds = %cec_check97
  %202 = getelementptr i8, ptr %cpu, i64 188
  %next_pc333 = load i32, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i64 188
  %204 = load i32, ptr %203, align 4
  %205 = getelementptr i8, ptr %cpu, i64 296
  %206 = load i8, ptr %205, align 1
  br label %chain_exit

did_jump_cont100:                                 ; preds = %cec_check97
  br label %cec_checked98

insn_0x0001032e_entry:                            ; preds = %cec_checked98
  br label %insn_0x0001032e

insn_0x0001032e:                                  ; preds = %insn_0x0001032e_entry
  %207 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %207, align 4
  %208 = icmp ule i32 %rx, 4
  %cc = zext i1 %208 to i32
  %209 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %209, align 4
  %210 = icmp eq i32 %rx, 4
  %az = zext i1 %210 to i32
  %211 = icmp ugt i32 4, %rx
  %an = zext i1 %211 to i32
  %212 = icmp ule i32 4, %rx
  %ac0 = zext i1 %212 to i32
  %213 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %213, align 4
  %214 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %216, align 4
  br label %insn_0x00010330_entry

insn_0x00010330_entry:                            ; preds = %insn_0x0001032e
  br label %insn_0x00010330

insn_0x00010330:                                  ; preds = %insn_0x00010330_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010330
  %217 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %218, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %219 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %219 monotonic, align 4, !range !2
  %220 = icmp ult i32 %chain_total, %chain_budget
  br i1 %220, label %chain_go, label %chain_leave334, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010330
  br label %insn_0x00010332_entry

insn_0x00010332_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010332

insn_0x00010332:                                  ; preds = %insn_0x00010332_entry
  %221 = getelementptr i8, ptr %cpu, i32 4
  %rx103 = load i32, ptr %221, align 4
  %diff = sub i32 %rx103, 0
  %222 = icmp eq i32 %diff, 0
  %az104 = zext i1 %222 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx103, 31
  %223 = xor i32 %flgn, %flgs
  %224 = xor i32 %flgs, 0
  %overflow = and i32 %224, %223
  %an105 = xor i32 %flgn, %overflow
  %225 = icmp ule i32 0, %rx103
  %ac0106 = zext i1 %225 to i32
  %226 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az104, ptr %226, align 4
  %227 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az104, ptr %227, align 4
  %228 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an105, ptr %228, align 4
  %229 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0106, ptr %229, align 4
  %230 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0106, ptr %230, align 4
  br label %insn_0x00010334_entry

insn_0x00010334_entry:                            ; preds = %insn_0x00010332
  br label %insn_0x00010334

insn_0x00010334:                                  ; preds = %insn_0x00010334_entry
  %cc_true = icmp ne i32 %az104, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x00010334
  %231 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets337 = load i32, ptr %232, align 4
  %chain_total338 = add nuw i32 %chain_packets337, 6
  %233 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget339 = load atomic i32, ptr %233 monotonic, align 4, !range !2
  %234 = icmp ult i32 %chain_total338, %chain_budget339
  br i1 %234, label %chain_go335, label %chain_leave336, !prof !0

brt_fallthru:                                     ; preds = %insn_0x00010334
  br label %insn_0x00010336_entry

insn_0x00010336_entry:                            ; preds = %brt_fallthru
  br label %insn_0x00010336

insn_0x00010336:                                  ; preds = %insn_0x00010336_entry
  %235 = getelementptr i8, ptr %cpu, i32 12
  store i32 15625, ptr %235, align 4
  br label %insn_0x0001033a_entry

insn_0x0001033a_entry:                            ; preds = %insn_0x00010336
  br label %insn_0x0001033a

insn_0x0001033a:                                  ; preds = %insn_0x0001033a_entry
  %236 = getelementptr i8, ptr %cpu, i32 12
  store i32 32000000, ptr %236, align 4
  %237 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %237, align 4
  %238 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %238, align 4
  %239 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %240, align 4
  br label %insn_0x0001033c_entry

insn_0x0001033c_entry:                            ; preds = %insn_0x0001033a
  br label %insn_0x0001033c

insn_0x0001033c:                                  ; preds = %insn_0x0001033c_entry
  %241 = icmp ule i32 %rx103, 32000000
  %cc107 = zext i1 %241 to i32
  %242 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc107, ptr %242, align 4
  %243 = icmp eq i32 %rx103, 32000000
  %az108 = zext i1 %243 to i32
  %244 = icmp ugt i32 32000000, %rx103
  %an109 = zext i1 %244 to i32
  %245 = icmp ule i32 32000000, %rx103
  %ac0110 = zext i1 %245 to i32
  %246 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az108, ptr %246, align 4
  %247 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an109, ptr %247, align 4
  %248 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0110, ptr %248, align 4
  %249 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0110, ptr %249, align 4
  br label %insn_0x0001033e_entry

insn_0x0001033e_entry:                            ; preds = %insn_0x0001033c
  br label %insn_0x0001033e

insn_0x0001033e:                                  ; preds = %insn_0x0001033e_entry
  %cc_false111 = icmp eq i32 %cc107, 0
  br i1 %cc_false111, label %brcc_taken112, label %brcc_fallthru113

brcc_taken112:                                    ; preds = %insn_0x0001033e
  %250 = getelementptr i8, ptr %cpu, i32 188
  store i32 66416, ptr %250, align 4
  %251 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets346 = load i32, ptr %251, align 4
  %chain_total347 = add nuw i32 %chain_packets346, 10
  %252 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget348 = load atomic i32, ptr %252 monotonic, align 4, !range !2
  %253 = icmp ult i32 %chain_total347, %chain_budget348
  br i1 %253, label %chain_go344, label %chain_leave345, !prof !0

brcc_fallthru113:                                 ; preds = %insn_0x0001033e
  br label %insn_0x00010340_entry

insn_0x00010340_entry:                            ; preds = %brcc_fallthru113
  br label %insn_0x00010340

insn_0x00010340:                                  ; preds = %insn_0x00010340_entry
  %254 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %254, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %255 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %255, align 4
  br label %insn_0x00010344_entry

insn_0x00010344_entry:                            ; preds = %insn_0x00010340
  br label %insn_0x00010344

insn_0x00010344:                                  ; preds = %insn_0x00010344_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4848
  %256 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %256, align 4
  br label %insn_0x00010348_entry

insn_0x00010348_entry:                            ; preds = %insn_0x00010344
  br label %insn_0x00010348

insn_0x00010348:                                  ; preds = %insn_0x00010348_entry
  %257 = and i32 %with_lo, 3
  %258 = icmp ne i32 %257, 0
  br i1 %258, label %data_misaligned114, label %data_aligned115, !prof !1

data_misaligned114:                               ; preds = %insn_0x00010348
  %259 = getelementptr i8, ptr %cpu, i32 188
  store i32 66376, ptr %259, align 4
  %260 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %260, align 4
  %261 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %261, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66376, i32 %with_lo, i32 65536)
  %262 = getelementptr i8, ptr %cpu, i64 188
  %next_pc353 = load i32, ptr %262, align 4
  %263 = getelementptr i8, ptr %cpu, i64 188
  %264 = load i32, ptr %263, align 4
  %265 = getelementptr i8, ptr %cpu, i64 296
  %266 = load i8, ptr %265, align 1
  br label %chain_exit

data_aligned115:                                  ; preds = %insn_0x00010348
  %267 = lshr i32 %with_lo, 12
  %page_index119 = zext i32 %267 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122 = icmp ne ptr %page121, null
  br i1 %page_mapped122, label %page_wr_fast116, label %page_wr_slow117, !prof !0

page_wr_fast116:                                  ; preds = %data_aligned115
  %268 = and i32 %with_lo, 4095
  %page_offset123 = zext i32 %268 to i64
  %269 = getelementptr i8, ptr %page121, i64 %page_offset123
  store i32 %rx, ptr %269, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %data_aligned115
  %270 = getelementptr i8, ptr %cpu, i32 188
  store i32 66376, ptr %270, align 4
  %271 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %271, align 4
  %272 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %272, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo, i32 %rx)
  %273 = getelementptr i8, ptr %cpu, i32 296
  %dj126 = load i8, ptr %273, align 1
  %dj_set127 = icmp ne i8 %dj126, 0
  br i1 %dj_set127, label %did_jump_exit124, label %did_jump_cont125, !prof !1

page_wr_done118:                                  ; preds = %did_jump_cont125, %page_wr_fast116
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %274 = icmp ne i8 %cec_pending128, 0
  br i1 %274, label %cec_check129, label %cec_checked130, !prof !1

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %275 = getelementptr i8, ptr %cpu, i64 188
  %next_pc354 = load i32, ptr %275, align 4
  %276 = getelementptr i8, ptr %cpu, i64 188
  %277 = load i32, ptr %276, align 4
  %278 = getelementptr i8, ptr %cpu, i64 296
  %279 = load i8, ptr %278, align 1
  br label %chain_exit

did_jump_cont125:                                 ; preds = %page_wr_slow117
  br label %page_wr_done118

cec_check129:                                     ; preds = %page_wr_done118
  %280 = getelementptr i8, ptr %cpu, i32 188
  store i32 66378, ptr %280, align 4
  %281 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %282, align 4
  call void @cec_check_pending(ptr %cpu)
  %283 = getelementptr i8, ptr %cpu, i32 296
  %dj133 = load i8, ptr %283, align 1
  %dj_set134 = icmp ne i8 %dj133, 0
  br i1 %dj_set134, label %did_jump_exit131, label %did_jump_cont132, !prof !1

cec_checked130:                                   ; preds = %did_jump_cont132, %page_wr_done118
  br label %insn_0x0001034a_entry

did_jump_exit131:                                 ; preds = %cec_check129
  %284 = getelementptr i8, ptr %cpu, i64 188
  %next_pc355 = load i32, ptr %284, align 4
  %285 = getelementptr i8, ptr %cpu, i64 188
  %286 = load i32, ptr %285, align 4
  %287 = getelementptr i8, ptr %cpu, i64 296
  %288 = load i8, ptr %287, align 1
  br label %chain_exit

did_jump_cont132:                                 ; preds = %cec_check129
  br label %cec_checked130

insn_0x0001034a_entry:                            ; preds = %cec_checked130
  br label %insn_0x0001034a

insn_0x0001034a:                                  ; preds = %insn_0x0001034a_entry
  %lo_kept135 = and i32 %with_lo, 65535
  %with_hi136 = or i32 %lo_kept135, 65536
  %289 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi136, ptr %289, align 4
  br label %insn_0x0001034e_entry

insn_0x0001034e_entry:                            ; preds = %insn_0x0001034a
  br label %insn_0x0001034e

insn_0x0001034e:                                  ; preds = %insn_0x0001034e_entry
  %hi_kept137 = and i32 %with_hi136, -65536
  %with_lo138 = or i32 %hi_kept137, 4852
  %290 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo138, ptr %290, align 4
  br label %insn_0x00010352_entry

insn_0x00010352_entry:                            ; preds = %insn_0x0001034e
  br label %insn_0x00010352

insn_0x00010352:                                  ; preds = %insn_0x00010352_entry
  %291 = and i32 %with_lo138, 3
  %292 = icmp ne i32 %291, 0
  br i1 %292, label %data_misaligned139, label %data_aligned140, !prof !1

data_misaligned139:                               ; preds = %insn_0x00010352
  %293 = getelementptr i8, ptr %cpu, i32 188
  store i32 66386, ptr %293, align 4
  %294 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %294, align 4
  %295 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %295, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66386, i32 %with_lo138, i32 65536)
  %296 = getelementptr i8, ptr %cpu, i64 188
  %next_pc356 = load i32, ptr %296, align 4
  %297 = getelementptr i8, ptr %cpu, i64 188
  %298 = load i32, ptr %297, align 4
  %299 = getelementptr i8, ptr %cpu, i64 296
  %300 = load i8, ptr %299, align 1
  br label %chain_exit

data_aligned140:                                  ; preds = %insn_0x00010352
  %301 = lshr i32 %with_lo138, 12
  %page_index144 = zext i32 %301 to i64
  %page_slot145 = getelementptr ptr, ptr %page_table, i64 %page_index144
  %page146 = load ptr, ptr %page_slot145, align 8
  %page_mapped147 = icmp ne ptr %page146, null
  br i1 %page_mapped147, label %page_wr_fast141, label %page_wr_slow142, !prof !0

page_wr_fast141:                                  ; preds = %data_aligned140
  %302 = and i32 %with_lo138, 4095
  %page_offset148 = zext i32 %302 to i64
  %303 = getelementptr i8, ptr %page146, i64 %page_offset148
  store i32 %rx103, ptr %303, align 4
  br label %page_wr_done143

page_wr_slow142:                                  ; preds = %data_aligned140
  %304 = getelementptr i8, ptr %cpu, i32 188
  store i32 66386, ptr %304, align 4
  %305 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %305, align 4
  %306 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %306, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo138, i32 %rx103)
  %307 = getelementptr i8, ptr %cpu, i32 296
  %dj151 = load i8, ptr %307, align 1
  %dj_set152 = icmp ne i8 %dj151, 0
  br i1 %dj_set152, label %did_jump_exit149, label %did_jump_cont150, !prof !1

page_wr_done143:                                  ; preds = %did_jump_cont150, %page_wr_fast141
  %cec_pending153 = load i8, ptr %cec_pending_flag, align 1
  %308 = icmp ne i8 %cec_pending153, 0
  br i1 %308, label %cec_check154, label %cec_checked155, !prof !1

did_jump_exit149:                                 ; preds = %page_wr_slow142
  %309 = getelementptr i8, ptr %cpu, i64 188
  %next_pc357 = load i32, ptr %309, align 4
  %310 = getelementptr i8, ptr %cpu, i64 188
  %311 = load i32, ptr %310, align 4
  %312 = getelementptr i8, ptr %cpu, i64 296
  %313 = load i8, ptr %312, align 1
  br label %chain_exit

did_jump_cont150:                                 ; preds = %page_wr_slow142
  br label %page_wr_done143

cec_check154:                                     ; preds = %page_wr_done143
  %314 = getelementptr i8, ptr %cpu, i32 188
  store i32 66388, ptr %314, align 4
  %315 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %315, align 4
  %316 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %316, align 4
  call void @cec_check_pending(ptr %cpu)
  %317 = getelementptr i8, ptr %cpu, i32 296
  %dj158 = load i8, ptr %317, align 1
  %dj_set159 = icmp ne i8 %dj158, 0
  br i1 %dj_set159, label %did_jump_exit156, label %did_jump_cont157, !prof !1

cec_checked155:                                   ; preds = %did_jump_cont157, %page_wr_done143
  br label %insn_0x00010354_entry

did_jump_exit156:                                 ; preds = %cec_check154
  %318 = getelementptr i8, ptr %cpu, i64 188
  %next_pc358 = load i32, ptr %318, align 4
  %319 = getelementptr i8, ptr %cpu, i64 188
  %320 = load i32, ptr %319, align 4
  %321 = getelementptr i8, ptr %cpu, i64 296
  %322 = load i8, ptr %321, align 1
  br label %chain_exit

did_jump_cont157:                                 ; preds = %cec_check154
  br label %cec_checked155

insn_0x00010354_entry:                            ; preds = %cec_checked155
  br label %insn_0x00010354

insn_0x00010354:                                  ; preds = %insn_0x00010354_entry
  %lo_kept160 = and i32 %with_lo138, 65535
  %with_hi161 = or i32 %lo_kept160, 65536
  %323 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi161, ptr %323, align 4
  br label %insn_0x00010358_entry

insn_0x00010358_entry:                            ; preds = %insn_0x00010354
  br label %insn_0x00010358

insn_0x00010358:                                  ; preds = %insn_0x00010358_entry
  %hi_kept162 = and i32 %with_hi161, -65536
  %with_lo163 = or i32 %hi_kept162, 4856
  %324 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo163, ptr %324, align 4
  br label %insn_0x0001035c_entry

insn_0x0001035c_entry:                            ; preds = %insn_0x00010358
  br label %insn_0x0001035c

insn_0x0001035c:                                  ; preds = %insn_0x0001035c_entry
  %325 = getelementptr i8, ptr %cpu, i32 8
  %val = load i32, ptr %325, align 4
  %326 = and i32 %with_lo163, 3
  %327 = icmp ne i32 %326, 0
  br i1 %327, label %data_misaligned164, label %data_aligned165, !prof !1

data_misaligned164:                               ; preds = %insn_0x0001035c
  %328 = getelementptr i8, ptr %cpu, i32 188
  store i32 66396, ptr %328, align 4
  %329 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %330, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66396, i32 %with_lo163, i32 65536)
  %331 = getelementptr i8, ptr %cpu, i64 188
  %next_pc359 = load i32, ptr %331, align 4
  %332 = getelementptr i8, ptr %cpu, i64 188
  %333 = load i32, ptr %332, align 4
  %334 = getelementptr i8, ptr %cpu, i64 296
  %335 = load i8, ptr %334, align 1
  br label %chain_exit

data_aligned165:                                  ; preds = %insn_0x0001035c
  %336 = lshr i32 %with_lo163, 12
  %page_index169 = zext i32 %336 to i64
  %page_slot170 = getelementptr ptr, ptr %page_table, i64 %page_index169
  %page171 = load ptr, ptr %page_slot170, align 8
  %page_mapped172 = icmp ne ptr %page171, null
  br i1 %page_mapped172, label %page_wr_fast166, label %page_wr_slow167, !prof !0

page_wr_fast166:                                  ; preds = %data_aligned165
  %337 = and i32 %with_lo163, 4095
  %page_offset173 = zext i32 %337 to i64
  %338 = getelementptr i8, ptr %page171, i64 %page_offset173
  store i32 %val, ptr %338, align 4
  br label %page_wr_done168

page_wr_slow167:                                  ; preds = %data_aligned165
  %339 = getelementptr i8, ptr %cpu, i32 188
  store i32 66396, ptr %339, align 4
  %340 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %340, align 4
  %341 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %341, align 4
  call void @mem_write32(ptr %mem, i32 %with_lo163, i32 %val)
  %342 = getelementptr i8, ptr %cpu, i32 296
  %dj176 = load i8, ptr %342, align 1
  %dj_set177 = icmp ne i8 %dj176, 0
  br i1 %dj_set177, label %did_jump_exit174, label %did_jump_cont175, !prof !1

page_wr_done168:                                  ; preds = %did_jump_cont175, %page_wr_fast166
  %cec_pending178 = load i8, ptr %cec_pending_flag, align 1
  %343 = icmp ne i8 %cec_pending178, 0
  br i1 %343, label %cec_check179, label %cec_checked180, !prof !1

did_jump_exit174:                                 ; preds = %page_wr_slow167
  %344 = getelementptr i8, ptr %cpu, i64 188
  %next_pc360 = load i32, ptr %344, align 4
  %345 = getelementptr i8, ptr %cpu, i64 188
  %346 = load i32, ptr %345, align 4
  %347 = getelementptr i8, ptr %cpu, i64 296
  %348 = load i8, ptr %347, align 1
  br label %chain_exit

did_jump_cont175:                                 ; preds = %page_wr_slow167
  br label %page_wr_done168

cec_check179:                                     ; preds = %page_wr_done168
  %349 = getelementptr i8, ptr %cpu, i32 188
  store i32 66398, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %350, align 4
  %351 = getelementptr i8, ptr %cpu, i32 308
  store i32 19, ptr %351, align 4
  call void @cec_check_pending(ptr %cpu)
  %352 = getelementptr i8, ptr %cpu, i32 296
  %dj183 = load i8, ptr %352, align 1
  %dj_set184 = icmp ne i8 %dj183, 0
  br i1 %dj_set184, label %did_jump_exit181, label %did_jump_cont182, !prof !1

cec_checked180:                                   ; preds = %did_jump_cont182, %page_wr_done168
  br label %insn_0x0001035e_entry

did_jump_exit181:                                 ; preds = %cec_check179
  %353 = getelementptr i8, ptr %cpu, i64 188
  %next_pc361 = load i32, ptr %353, align 4
  %354 = getelementptr i8, ptr %cpu, i64 188
  %355 = load i32, ptr %354, align 4
  %356 = getelementptr i8, ptr %cpu, i64 296
  %357 = load i8, ptr %356, align 1
  br label %chain_exit

did_jump_cont182:                                 ; preds = %cec_check179
  br label %cec_checked180

insn_0x0001035e_entry:                            ; preds = %cec_checked180
  br label %insn_0x0001035e

insn_0x0001035e:                                  ; preds = %insn_0x0001035e_entry
  %diff185 = sub i32 %rx, 2
  %358 = icmp eq i32 %diff185, 0
  %az186 = zext i1 %358 to i32
  %flgn187 = lshr i32 %diff185, 31
  %flgs188 = lshr i32 %rx, 31
  %359 = xor i32 %flgn187, %flgs188
  %360 = xor i32 %flgs188, 0
  %overflow189 = and i32 %360, %359
  %an190 = xor i32 %flgn187, %overflow189
  %361 = icmp ule i32 2, %rx
  %ac0191 = zext i1 %361 to i32
  %362 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az186, ptr %362, align 4
  %363 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az186, ptr %363, align 4
  %364 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an190, ptr %364, align 4
  %365 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0191, ptr %365, align 4
  %366 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0191, ptr %366, align 4
  br label %insn_0x00010360_entry

insn_0x00010360_entry:                            ; preds = %insn_0x0001035e
  br label %insn_0x00010360

insn_0x00010360:                                  ; preds = %insn_0x00010360_entry
  %cc_true192 = icmp ne i32 %az186, 0
  br i1 %cc_true192, label %brt_taken193, label %brt_fallthru194

brt_taken193:                                     ; preds = %insn_0x00010360
  %367 = getelementptr i8, ptr %cpu, i32 188
  store i32 66426, ptr %367, align 4
  %368 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets364 = load i32, ptr %368, align 4
  %chain_total365 = add nuw i32 %chain_packets364, 21
  %369 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget366 = load atomic i32, ptr %369 monotonic, align 4, !range !2
  %370 = icmp ult i32 %chain_total365, %chain_budget366
  br i1 %370, label %chain_go362, label %chain_leave363, !prof !0

brt_fallthru194:                                  ; preds = %insn_0x00010360
  br label %insn_0x00010362_entry

insn_0x00010362_entry:                            ; preds = %brt_fallthru194
  br label %insn_0x00010362

insn_0x00010362:                                  ; preds = %insn_0x00010362_entry
  %diff195 = sub i32 %rx, 3
  %371 = icmp eq i32 %diff195, 0
  %az196 = zext i1 %371 to i32
  %flgn197 = lshr i32 %diff195, 31
  %flgs198 = lshr i32 %rx, 31
  %372 = xor i32 %flgn197, %flgs198
  %373 = xor i32 %flgs198, 0
  %overflow199 = and i32 %373, %372
  %an200 = xor i32 %flgn197, %overflow199
  %374 = icmp ule i32 3, %rx
  %ac0201 = zext i1 %374 to i32
  %375 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az196, ptr %375, align 4
  %376 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az196, ptr %376, align 4
  %377 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an200, ptr %377, align 4
  %378 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0201, ptr %378, align 4
  %379 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0201, ptr %379, align 4
  br label %insn_0x00010364_entry

insn_0x00010364_entry:                            ; preds = %insn_0x00010362
  br label %insn_0x00010364

insn_0x00010364:                                  ; preds = %insn_0x00010364_entry
  %cc_true202 = icmp ne i32 %az196, 0
  br i1 %cc_true202, label %brt_taken203, label %brt_fallthru204

brt_taken203:                                     ; preds = %insn_0x00010364
  %380 = getelementptr i8, ptr %cpu, i32 188
  store i32 66468, ptr %380, align 4
  %381 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets373 = load i32, ptr %381, align 4
  %chain_total374 = add nuw i32 %chain_packets373, 23
  %382 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget375 = load atomic i32, ptr %382 monotonic, align 4, !range !2
  %383 = icmp ult i32 %chain_total374, %chain_budget375
  br i1 %383, label %chain_go371, label %chain_leave372, !prof !0

brt_fallthru204:                                  ; preds = %insn_0x00010364
  br label %insn_0x00010366_entry

insn_0x00010366_entry:                            ; preds = %brt_fallthru204
  br label %insn_0x00010366

insn_0x00010366:                                  ; preds = %insn_0x00010366_entry
  %384 = getelementptr i8, ptr %cpu, i32 0
  store i32 0, ptr %384, align 4
  br label %insn_0x00010368_entry

insn_0x00010368_entry:                            ; preds = %insn_0x00010366
  br label %insn_0x00010368

insn_0x00010368:                                  ; preds = %insn_0x00010368_entry
  %385 = and i32 %sp2, 3
  %386 = icmp ne i32 %385, 0
  br i1 %386, label %data_misaligned205, label %data_aligned206, !prof !1

data_misaligned205:                               ; preds = %insn_0x00010368
  %387 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %387, align 4
  %388 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %388, align 4
  %389 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %389, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %sp2, i32 0)
  %390 = getelementptr i8, ptr %cpu, i64 188
  %next_pc380 = load i32, ptr %390, align 4
  %391 = getelementptr i8, ptr %cpu, i64 188
  %392 = load i32, ptr %391, align 4
  %393 = getelementptr i8, ptr %cpu, i64 296
  %394 = load i8, ptr %393, align 1
  br label %chain_exit

data_aligned206:                                  ; preds = %insn_0x00010368
  %395 = lshr i32 %sp2, 12
  %page_index207 = zext i32 %395 to i64
  %page_slot208 = getelementptr ptr, ptr %page_table, i64 %page_index207
  %page209 = load ptr, ptr %page_slot208, align 8
  %page_mapped210 = icmp ne ptr %page209, null
  br i1 %page_mapped210, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned206
  %396 = and i32 %sp2, 4095
  %page_offset211 = zext i32 %396 to i64
  %397 = getelementptr i8, ptr %page209, i64 %page_offset211
  %page_val = load i32, ptr %397, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned206
  %398 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %398, align 4
  %399 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %399, align 4
  %400 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %400, align 4
  %401 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %402 = getelementptr i8, ptr %cpu, i32 296
  %dj214 = load i8, ptr %402, align 1
  %dj_set215 = icmp ne i8 %dj214, 0
  br i1 %dj_set215, label %did_jump_exit212, label %did_jump_cont213, !prof !1

page_done:                                        ; preds = %did_jump_cont213, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %401, %did_jump_cont213 ]
  %sp1216 = add i32 %sp2, 4
  %403 = and i32 %sp1216, 3
  %404 = icmp ne i32 %403, 0
  br i1 %404, label %data_misaligned217, label %data_aligned218, !prof !1

did_jump_exit212:                                 ; preds = %page_slow
  %405 = getelementptr i8, ptr %cpu, i64 188
  %next_pc381 = load i32, ptr %405, align 4
  %406 = getelementptr i8, ptr %cpu, i64 188
  %407 = load i32, ptr %406, align 4
  %408 = getelementptr i8, ptr %cpu, i64 296
  %409 = load i8, ptr %408, align 1
  br label %chain_exit

did_jump_cont213:                                 ; preds = %page_slow
  br label %page_done

data_misaligned217:                               ; preds = %page_done
  %410 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %410, align 4
  %411 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %411, align 4
  %412 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %412, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66408, i32 %sp1216, i32 0)
  %413 = getelementptr i8, ptr %cpu, i64 188
  %next_pc382 = load i32, ptr %413, align 4
  %414 = getelementptr i8, ptr %cpu, i64 188
  %415 = load i32, ptr %414, align 4
  %416 = getelementptr i8, ptr %cpu, i64 296
  %417 = load i8, ptr %416, align 1
  br label %chain_exit

data_aligned218:                                  ; preds = %page_done
  %418 = lshr i32 %sp1216, 12
  %page_index222 = zext i32 %418 to i64
  %page_slot223 = getelementptr ptr, ptr %page_table, i64 %page_index222
  %page224 = load ptr, ptr %page_slot223, align 8
  %page_mapped225 = icmp ne ptr %page224, null
  br i1 %page_mapped225, label %page_fast219, label %page_slow220, !prof !0

page_fast219:                                     ; preds = %data_aligned218
  %419 = and i32 %sp1216, 4095
  %page_offset226 = zext i32 %419 to i64
  %420 = getelementptr i8, ptr %page224, i64 %page_offset226
  %page_val227 = load i32, ptr %420, align 4
  br label %page_done221

page_slow220:                                     ; preds = %data_aligned218
  %421 = getelementptr i8, ptr %cpu, i32 188
  store i32 66408, ptr %421, align 4
  %422 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %422, align 4
  %423 = getelementptr i8, ptr %cpu, i32 308
  store i32 25, ptr %423, align 4
  %424 = call i32 @mem_read32(ptr %mem, i32 %sp1216)
  %425 = getelementptr i8, ptr %cpu, i32 296
  %dj230 = load i8, ptr %425, align 1
  %dj_set231 = icmp ne i8 %dj230, 0
  br i1 %dj_set231, label %did_jump_exit228, label %did_jump_cont229, !prof !1

page_done221:                                     ; preds = %did_jump_cont229, %page_fast219
  %mem_val232 = phi i32 [ %page_val227, %page_fast219 ], [ %424, %did_jump_cont229 ]
  %sp2233 = add i32 %sp1216, 4
  %426 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %426, align 4
  %427 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val232, ptr %427, align 4
  %428 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2233, ptr %428, align 4
  br label %insn_0x0001036c_entry

did_jump_exit228:                                 ; preds = %page_slow220
  %429 = getelementptr i8, ptr %cpu, i64 188
  %next_pc383 = load i32, ptr %429, align 4
  %430 = getelementptr i8, ptr %cpu, i64 188
  %431 = load i32, ptr %430, align 4
  %432 = getelementptr i8, ptr %cpu, i64 296
  %433 = load i8, ptr %432, align 1
  br label %chain_exit

did_jump_cont229:                                 ; preds = %page_slow220
  br label %page_done221

insn_0x0001036c_entry:                            ; preds = %page_done221
  br label %insn_0x0001036c

insn_0x0001036c:                                  ; preds = %insn_0x0001036c_entry
  %434 = and i32 %sp2233, 3
  %435 = icmp ne i32 %434, 0
  br i1 %435, label %data_misaligned234, label %data_aligned235, !prof !1

data_misaligned234:                               ; preds = %insn_0x0001036c
  %436 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %436, align 4
  %437 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %437, align 4
  %438 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %438, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp2233, i32 0)
  %439 = getelementptr i8, ptr %cpu, i64 188
  %next_pc384 = load i32, ptr %439, align 4
  %440 = getelementptr i8, ptr %cpu, i64 188
  %441 = load i32, ptr %440, align 4
  %442 = getelementptr i8, ptr %cpu, i64 296
  %443 = load i8, ptr %442, align 1
  br label %chain_exit

data_aligned235:                                  ; preds = %insn_0x0001036c
  %444 = lshr i32 %sp2233, 12
  %page_index239 = zext i32 %444 to i64
  %page_slot240 = getelementptr ptr, ptr %page_table, i64 %page_index239
  %page241 = load ptr, ptr %page_slot240, align 8
  %page_mapped242 = icmp ne ptr %page241, null
  br i1 %page_mapped242, label %page_fast236, label %page_slow237, !prof !0

page_fast236:                                     ; preds = %data_aligned235
  %445 = and i32 %sp2233, 4095
  %page_offset243 = zext i32 %445 to i64
  %446 = getelementptr i8, ptr %page241, i64 %page_offset243
  %page_val244 = load i32, ptr %446, align 4
  br label %page_done238

page_slow237:                                     ; preds = %data_aligned235
  %447 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %447, align 4
  %448 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %448, align 4
  %449 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %449, align 4
  %450 = call i32 @mem_read32(ptr %mem, i32 %sp2233)
  %451 = getelementptr i8, ptr %cpu, i32 296
  %dj247 = load i8, ptr %451, align 1
  %dj_set248 = icmp ne i8 %dj247, 0
  br i1 %dj_set248, label %did_jump_exit245, label %did_jump_cont246, !prof !1

page_done238:                                     ; preds = %did_jump_cont246, %page_fast236
  %mem_val249 = phi i32 [ %page_val244, %page_fast236 ], [ %450, %did_jump_cont246 ]
  %452 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val249, ptr %452, align 4
  %sp_inc = add i32 %sp2233, 4
  %453 = and i32 %sp_inc, 3
  %454 = icmp ne i32 %453, 0
  br i1 %454, label %data_misaligned250, label %data_aligned251, !prof !1

did_jump_exit245:                                 ; preds = %page_slow237
  %455 = getelementptr i8, ptr %cpu, i64 188
  %next_pc385 = load i32, ptr %455, align 4
  %456 = getelementptr i8, ptr %cpu, i64 188
  %457 = load i32, ptr %456, align 4
  %458 = getelementptr i8, ptr %cpu, i64 296
  %459 = load i8, ptr %458, align 1
  br label %chain_exit

did_jump_cont246:                                 ; preds = %page_slow237
  br label %page_done238

data_misaligned250:                               ; preds = %page_done238
  %460 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %460, align 4
  %461 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %461, align 4
  %462 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %462, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc, i32 0)
  %463 = getelementptr i8, ptr %cpu, i64 188
  %next_pc386 = load i32, ptr %463, align 4
  %464 = getelementptr i8, ptr %cpu, i64 188
  %465 = load i32, ptr %464, align 4
  %466 = getelementptr i8, ptr %cpu, i64 296
  %467 = load i8, ptr %466, align 1
  br label %chain_exit

data_aligned251:                                  ; preds = %page_done238
  %468 = lshr i32 %sp_inc, 12
  %page_index255 = zext i32 %468 to i64
  %page_slot256 = getelementptr ptr, ptr %page_table, i64 %page_index255
  %page257 = load ptr, ptr %page_slot256, align 8
  %page_mapped258 = icmp ne ptr %page257, null
  br i1 %page_mapped258, label %page_fast252, label %page_slow253, !prof !0

page_fast252:                                     ; preds = %data_aligned251
  %469 = and i32 %sp_inc, 4095
  %page_offset259 = zext i32 %469 to i64
  %470 = getelementptr i8, ptr %page257, i64 %page_offset259
  %page_val260 = load i32, ptr %470, align 4
  br label %page_done254

page_slow253:                                     ; preds = %data_aligned251
  %471 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %471, align 4
  %472 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %472, align 4
  %473 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %473, align 4
  %474 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %475 = getelementptr i8, ptr %cpu, i32 296
  %dj263 = load i8, ptr %475, align 1
  %dj_set264 = icmp ne i8 %dj263, 0
  br i1 %dj_set264, label %did_jump_exit261, label %did_jump_cont262, !prof !1

page_done254:                                     ; preds = %did_jump_cont262, %page_fast252
  %mem_val265 = phi i32 [ %page_val260, %page_fast252 ], [ %474, %did_jump_cont262 ]
  %476 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val265, ptr %476, align 4
  %sp_inc266 = add i32 %sp_inc, 4
  %477 = and i32 %sp_inc266, 3
  %478 = icmp ne i32 %477, 0
  br i1 %478, label %data_misaligned267, label %data_aligned268, !prof !1

did_jump_exit261:                                 ; preds = %page_slow253
  %479 = getelementptr i8, ptr %cpu, i64 188
  %next_pc387 = load i32, ptr %479, align 4
  %480 = getelementptr i8, ptr %cpu, i64 188
  %481 = load i32, ptr %480, align 4
  %482 = getelementptr i8, ptr %cpu, i64 296
  %483 = load i8, ptr %482, align 1
  br label %chain_exit

did_jump_cont262:                                 ; preds = %page_slow253
  br label %page_done254

data_misaligned267:                               ; preds = %page_done254
  %484 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %484, align 4
  %485 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %485, align 4
  %486 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %486, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc266, i32 0)
  %487 = getelementptr i8, ptr %cpu, i64 188
  %next_pc388 = load i32, ptr %487, align 4
  %488 = getelementptr i8, ptr %cpu, i64 188
  %489 = load i32, ptr %488, align 4
  %490 = getelementptr i8, ptr %cpu, i64 296
  %491 = load i8, ptr %490, align 1
  br label %chain_exit

data_aligned268:                                  ; preds = %page_done254
  %492 = lshr i32 %sp_inc266, 12
  %page_index272 = zext i32 %492 to i64
  %page_slot273 = getelementptr ptr, ptr %page_table, i64 %page_index272
  %page274 = load ptr, ptr %page_slot273, align 8
  %page_mapped275 = icmp ne ptr %page274, null
  br i1 %page_mapped275, label %page_fast269, label %page_slow270, !prof !0

page_fast269:                                     ; preds = %data_aligned268
  %493 = and i32 %sp_inc266, 4095
  %page_offset276 = zext i32 %493 to i64
  %494 = getelementptr i8, ptr %page274, i64 %page_offset276
  %page_val277 = load i32, ptr %494, align 4
  br label %page_done271

page_slow270:                                     ; preds = %data_aligned268
  %495 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %495, align 4
  %496 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %496, align 4
  %497 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %497, align 4
  %498 = call i32 @mem_read32(ptr %mem, i32 %sp_inc266)
  %499 = getelementptr i8, ptr %cpu, i32 296
  %dj280 = load i8, ptr %499, align 1
  %dj_set281 = icmp ne i8 %dj280, 0
  br i1 %dj_set281, label %did_jump_exit278, label %did_jump_cont279, !prof !1

page_done271:                                     ; preds = %did_jump_cont279, %page_fast269
  %mem_val282 = phi i32 [ %page_val277, %page_fast269 ], [ %498, %did_jump_cont279 ]
  %500 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val282, ptr %500, align 4
  %sp_inc283 = add i32 %sp_inc266, 4
  %501 = and i32 %sp_inc283, 3
  %502 = icmp ne i32 %501, 0
  br i1 %502, label %data_misaligned284, label %data_aligned285, !prof !1

did_jump_exit278:                                 ; preds = %page_slow270
  %503 = getelementptr i8, ptr %cpu, i64 188
  %next_pc389 = load i32, ptr %503, align 4
  %504 = getelementptr i8, ptr %cpu, i64 188
  %505 = load i32, ptr %504, align 4
  %506 = getelementptr i8, ptr %cpu, i64 296
  %507 = load i8, ptr %506, align 1
  br label %chain_exit

did_jump_cont279:                                 ; preds = %page_slow270
  br label %page_done271

data_misaligned284:                               ; preds = %page_done271
  %508 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %508, align 4
  %509 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %509, align 4
  %510 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %510, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc283, i32 0)
  %511 = getelementptr i8, ptr %cpu, i64 188
  %next_pc390 = load i32, ptr %511, align 4
  %512 = getelementptr i8, ptr %cpu, i64 188
  %513 = load i32, ptr %512, align 4
  %514 = getelementptr i8, ptr %cpu, i64 296
  %515 = load i8, ptr %514, align 1
  br label %chain_exit

data_aligned285:                                  ; preds = %page_done271
  %516 = lshr i32 %sp_inc283, 12
  %page_index289 = zext i32 %516 to i64
  %page_slot290 = getelementptr ptr, ptr %page_table, i64 %page_index289
  %page291 = load ptr, ptr %page_slot290, align 8
  %page_mapped292 = icmp ne ptr %page291, null
  br i1 %page_mapped292, label %page_fast286, label %page_slow287, !prof !0

page_fast286:                                     ; preds = %data_aligned285
  %517 = and i32 %sp_inc283, 4095
  %page_offset293 = zext i32 %517 to i64
  %518 = getelementptr i8, ptr %page291, i64 %page_offset293
  %page_val294 = load i32, ptr %518, align 4
  br label %page_done288

page_slow287:                                     ; preds = %data_aligned285
  %519 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %519, align 4
  %520 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %520, align 4
  %521 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %521, align 4
  %522 = call i32 @mem_read32(ptr %mem, i32 %sp_inc283)
  %523 = getelementptr i8, ptr %cpu, i32 296
  %dj297 = load i8, ptr %523, align 1
  %dj_set298 = icmp ne i8 %dj297, 0
  br i1 %dj_set298, label %did_jump_exit295, label %did_jump_cont296, !prof !1

page_done288:                                     ; preds = %did_jump_cont296, %page_fast286
  %mem_val299 = phi i32 [ %page_val294, %page_fast286 ], [ %522, %did_jump_cont296 ]
  %524 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val299, ptr %524, align 4
  %sp_inc300 = add i32 %sp_inc283, 4
  %525 = and i32 %sp_inc300, 3
  %526 = icmp ne i32 %525, 0
  br i1 %526, label %data_misaligned301, label %data_aligned302, !prof !1

did_jump_exit295:                                 ; preds = %page_slow287
  %527 = getelementptr i8, ptr %cpu, i64 188
  %next_pc391 = load i32, ptr %527, align 4
  %528 = getelementptr i8, ptr %cpu, i64 188
  %529 = load i32, ptr %528, align 4
  %530 = getelementptr i8, ptr %cpu, i64 296
  %531 = load i8, ptr %530, align 1
  br label %chain_exit

did_jump_cont296:                                 ; preds = %page_slow287
  br label %page_done288

data_misaligned301:                               ; preds = %page_done288
  %532 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %532, align 4
  %533 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %533, align 4
  %534 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %534, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66412, i32 %sp_inc300, i32 0)
  %535 = getelementptr i8, ptr %cpu, i64 188
  %next_pc392 = load i32, ptr %535, align 4
  %536 = getelementptr i8, ptr %cpu, i64 188
  %537 = load i32, ptr %536, align 4
  %538 = getelementptr i8, ptr %cpu, i64 296
  %539 = load i8, ptr %538, align 1
  br label %chain_exit

data_aligned302:                                  ; preds = %page_done288
  %540 = lshr i32 %sp_inc300, 12
  %page_index306 = zext i32 %540 to i64
  %page_slot307 = getelementptr ptr, ptr %page_table, i64 %page_index306
  %page308 = load ptr, ptr %page_slot307, align 8
  %page_mapped309 = icmp ne ptr %page308, null
  br i1 %page_mapped309, label %page_fast303, label %page_slow304, !prof !0

page_fast303:                                     ; preds = %data_aligned302
  %541 = and i32 %sp_inc300, 4095
  %page_offset310 = zext i32 %541 to i64
  %542 = getelementptr i8, ptr %page308, i64 %page_offset310
  %page_val311 = load i32, ptr %542, align 4
  br label %page_done305

page_slow304:                                     ; preds = %data_aligned302
  %543 = getelementptr i8, ptr %cpu, i32 188
  store i32 66412, ptr %543, align 4
  %544 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %544, align 4
  %545 = getelementptr i8, ptr %cpu, i32 308
  store i32 26, ptr %545, align 4
  %546 = call i32 @mem_read32(ptr %mem, i32 %sp_inc300)
  %547 = getelementptr i8, ptr %cpu, i32 296
  %dj314 = load i8, ptr %547, align 1
  %dj_set315 = icmp ne i8 %dj314, 0
  br i1 %dj_set315, label %did_jump_exit312, label %did_jump_cont313, !prof !1

page_done305:                                     ; preds = %did_jump_cont313, %page_fast303
  %mem_val316 = phi i32 [ %page_val311, %page_fast303 ], [ %546, %did_jump_cont313 ]
  %548 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val316, ptr %548, align 4
  %sp_inc317 = add i32 %sp_inc300, 4
  %549 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc317, ptr %549, align 4
  br label %insn_0x0001036e_entry

did_jump_exit312:                                 ; preds = %page_slow304
  %550 = getelementptr i8, ptr %cpu, i64 188
  %next_pc393 = load i32, ptr %550, align 4
  %551 = getelementptr i8, ptr %cpu, i64 188
  %552 = load i32, ptr %551, align 4
  %553 = getelementptr i8, ptr %cpu, i64 296
  %554 = load i8, ptr %553, align 1
  br label %chain_exit

did_jump_cont313:                                 ; preds = %page_slow304
  br label %page_done305

insn_0x0001036e_entry:                            ; preds = %page_done305
  br label %insn_0x0001036e

insn_0x0001036e:                                  ; preds = %insn_0x0001036e_entry
  %lsb = and i32 %mem_val232, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001036e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001036e
  %555 = getelementptr i8, ptr %cpu, i32 188
  store i32 66414, ptr %555, align 4
  %556 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %556, align 4
  %557 = getelementptr i8, ptr %cpu, i32 308
  store i32 27, ptr %557, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %558 = getelementptr i8, ptr %cpu, i64 188
  %next_pc394 = load i32, ptr %558, align 4
  %559 = getelementptr i8, ptr %cpu, i64 188
  %560 = load i32, ptr %559, align 4
  %561 = getelementptr i8, ptr %cpu, i64 296
  %562 = load i8, ptr %561, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %563 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %563, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 531328
  %564 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %564, align 4
  %565 = icmp eq i32 %slot_pc, 66416
  br i1 %565, label %chain_hit, label %chain_leave334, !prof !0

chain_leave334:                                   ; preds = %chain_go, %brcc_taken
  %566 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %566, align 4
  %567 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %567, align 4
  %568 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %568, align 4
  %569 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %569, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %570 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %570, align 4
  %571 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %571, align 4
  %572 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %572, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go335:                                      ; preds = %brt_taken
  %chain_slot340 = getelementptr i8, ptr %chain_table, i64 531328
  %573 = getelementptr i8, ptr %chain_slot340, i64 0
  %slot_pc341 = load i32, ptr %573, align 4
  %574 = icmp eq i32 %slot_pc341, 66416
  br i1 %574, label %chain_hit342, label %chain_leave336, !prof !0

chain_leave336:                                   ; preds = %chain_go335, %brt_taken
  %575 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %575, align 4
  %576 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %576, align 4
  %577 = getelementptr i8, ptr %cpu, i64 308
  store i32 6, ptr %577, align 4
  %578 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %578, align 1
  br label %return

chain_hit342:                                     ; preds = %chain_go335
  %579 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %579, align 4
  %580 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total338, ptr %580, align 4
  %581 = getelementptr i8, ptr %chain_slot340, i64 8
  %chain_fn343 = load ptr, ptr %581, align 8
  musttail call swifttailcc void %chain_fn343(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go344:                                      ; preds = %brcc_taken112
  %chain_slot349 = getelementptr i8, ptr %chain_table, i64 531328
  %582 = getelementptr i8, ptr %chain_slot349, i64 0
  %slot_pc350 = load i32, ptr %582, align 4
  %583 = icmp eq i32 %slot_pc350, 66416
  br i1 %583, label %chain_hit351, label %chain_leave345, !prof !0

chain_leave345:                                   ; preds = %chain_go344, %brcc_taken112
  %584 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %584, align 4
  %585 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %585, align 4
  %586 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %586, align 4
  %587 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %587, align 1
  br label %return

chain_hit351:                                     ; preds = %chain_go344
  %588 = getelementptr i8, ptr %cpu, i64 188
  store i32 66416, ptr %588, align 4
  %589 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total347, ptr %589, align 4
  %590 = getelementptr i8, ptr %chain_slot349, i64 8
  %chain_fn352 = load ptr, ptr %590, align 8
  musttail call swifttailcc void %chain_fn352(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go362:                                      ; preds = %brt_taken193
  %chain_slot367 = getelementptr i8, ptr %chain_table, i64 531408
  %591 = getelementptr i8, ptr %chain_slot367, i64 0
  %slot_pc368 = load i32, ptr %591, align 4
  %592 = icmp eq i32 %slot_pc368, 66426
  br i1 %592, label %chain_hit369, label %chain_leave363, !prof !0

chain_leave363:                                   ; preds = %chain_go362, %brt_taken193
  %593 = getelementptr i8, ptr %cpu, i64 188
  store i32 66426, ptr %593, align 4
  %594 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %594, align 4
  %595 = getelementptr i8, ptr %cpu, i64 308
  store i32 21, ptr %595, align 4
  %596 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %596, align 1
  br label %return

chain_hit369:                                     ; preds = %chain_go362
  %597 = getelementptr i8, ptr %cpu, i64 188
  store i32 66426, ptr %597, align 4
  %598 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total365, ptr %598, align 4
  %599 = getelementptr i8, ptr %chain_slot367, i64 8
  %chain_fn370 = load ptr, ptr %599, align 8
  musttail call swifttailcc void %chain_fn370(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go371:                                      ; preds = %brt_taken203
  %chain_slot376 = getelementptr i8, ptr %chain_table, i64 531744
  %600 = getelementptr i8, ptr %chain_slot376, i64 0
  %slot_pc377 = load i32, ptr %600, align 4
  %601 = icmp eq i32 %slot_pc377, 66468
  br i1 %601, label %chain_hit378, label %chain_leave372, !prof !0

chain_leave372:                                   ; preds = %chain_go371, %brt_taken203
  %602 = getelementptr i8, ptr %cpu, i64 188
  store i32 66468, ptr %602, align 4
  %603 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %603, align 4
  %604 = getelementptr i8, ptr %cpu, i64 308
  store i32 23, ptr %604, align 4
  %605 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %605, align 1
  br label %return

chain_hit378:                                     ; preds = %chain_go371
  %606 = getelementptr i8, ptr %cpu, i64 188
  store i32 66468, ptr %606, align 4
  %607 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total374, ptr %607, align 4
  %608 = getelementptr i8, ptr %chain_slot376, i64 8
  %chain_fn379 = load ptr, ptr %608, align 8
  musttail call swifttailcc void %chain_fn379(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit312, %data_misaligned301, %did_jump_exit295, %data_misaligned284, %did_jump_exit278, %data_misaligned267, %did_jump_exit261, %data_misaligned250, %did_jump_exit245, %data_misaligned234, %did_jump_exit228, %data_misaligned217, %did_jump_exit212, %data_misaligned205, %did_jump_exit181, %did_jump_exit174, %data_misaligned164, %did_jump_exit156, %did_jump_exit149, %data_misaligned139, %did_jump_exit131, %did_jump_exit124, %data_misaligned114, %did_jump_exit99, %did_jump_exit92, %data_misaligned82, %did_jump_exit78, %data_misaligned68, %did_jump_exit64, %did_jump_exit60, %data_misaligned50, %did_jump_exit44, %data_misaligned34, %did_jump_exit28, %data_misaligned18, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc395 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc319, %did_jump_exit ], [ %next_pc320, %data_misaligned3 ], [ %next_pc321, %did_jump_exit13 ], [ %next_pc322, %data_misaligned18 ], [ %next_pc323, %did_jump_exit28 ], [ %next_pc324, %data_misaligned34 ], [ %next_pc325, %did_jump_exit44 ], [ %next_pc326, %data_misaligned50 ], [ %next_pc327, %did_jump_exit60 ], [ %next_pc328, %did_jump_exit64 ], [ %next_pc329, %data_misaligned68 ], [ %next_pc330, %did_jump_exit78 ], [ %next_pc331, %data_misaligned82 ], [ %next_pc332, %did_jump_exit92 ], [ %next_pc333, %did_jump_exit99 ], [ %next_pc353, %data_misaligned114 ], [ %next_pc354, %did_jump_exit124 ], [ %next_pc355, %did_jump_exit131 ], [ %next_pc356, %data_misaligned139 ], [ %next_pc357, %did_jump_exit149 ], [ %next_pc358, %did_jump_exit156 ], [ %next_pc359, %data_misaligned164 ], [ %next_pc360, %did_jump_exit174 ], [ %next_pc361, %did_jump_exit181 ], [ %next_pc380, %data_misaligned205 ], [ %next_pc381, %did_jump_exit212 ], [ %next_pc382, %data_misaligned217 ], [ %next_pc383, %did_jump_exit228 ], [ %next_pc384, %data_misaligned234 ], [ %next_pc385, %did_jump_exit245 ], [ %next_pc386, %data_misaligned250 ], [ %next_pc387, %did_jump_exit261 ], [ %next_pc388, %data_misaligned267 ], [ %next_pc389, %did_jump_exit278 ], [ %next_pc390, %data_misaligned284 ], [ %next_pc391, %did_jump_exit295 ], [ %next_pc392, %data_misaligned301 ], [ %next_pc393, %did_jump_exit312 ], [ %mem_val232, %jump_aligned ], [ %next_pc394, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned18 ], [ 1, %did_jump_exit28 ], [ 1, %data_misaligned34 ], [ 1, %did_jump_exit44 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ], [ 13, %data_misaligned114 ], [ 13, %did_jump_exit124 ], [ 13, %did_jump_exit131 ], [ 16, %data_misaligned139 ], [ 16, %did_jump_exit149 ], [ 16, %did_jump_exit156 ], [ 19, %data_misaligned164 ], [ 19, %did_jump_exit174 ], [ 19, %did_jump_exit181 ], [ 25, %data_misaligned205 ], [ 25, %did_jump_exit212 ], [ 25, %data_misaligned217 ], [ 25, %did_jump_exit228 ], [ 26, %data_misaligned234 ], [ 26, %did_jump_exit245 ], [ 26, %data_misaligned250 ], [ 26, %did_jump_exit261 ], [ 26, %data_misaligned267 ], [ 26, %did_jump_exit278 ], [ 26, %data_misaligned284 ], [ 26, %did_jump_exit295 ], [ 26, %data_misaligned301 ], [ 26, %did_jump_exit312 ], [ 27, %jump_aligned ], [ 27, %jump_misalign ]
  %tail = phi i32 [ %38, %data_misaligned ], [ %52, %did_jump_exit ], [ %59, %data_misaligned3 ], [ %73, %did_jump_exit13 ], [ %80, %data_misaligned18 ], [ %94, %did_jump_exit28 ], [ %101, %data_misaligned34 ], [ %115, %did_jump_exit44 ], [ %122, %data_misaligned50 ], [ %137, %did_jump_exit60 ], [ %146, %did_jump_exit64 ], [ %158, %data_misaligned68 ], [ %172, %did_jump_exit78 ], [ %180, %data_misaligned82 ], [ %195, %did_jump_exit92 ], [ %204, %did_jump_exit99 ], [ %264, %data_misaligned114 ], [ %277, %did_jump_exit124 ], [ %286, %did_jump_exit131 ], [ %298, %data_misaligned139 ], [ %311, %did_jump_exit149 ], [ %320, %did_jump_exit156 ], [ %333, %data_misaligned164 ], [ %346, %did_jump_exit174 ], [ %355, %did_jump_exit181 ], [ %392, %data_misaligned205 ], [ %407, %did_jump_exit212 ], [ %415, %data_misaligned217 ], [ %431, %did_jump_exit228 ], [ %441, %data_misaligned234 ], [ %457, %did_jump_exit245 ], [ %465, %data_misaligned250 ], [ %481, %did_jump_exit261 ], [ %489, %data_misaligned267 ], [ %505, %did_jump_exit278 ], [ %513, %data_misaligned284 ], [ %529, %did_jump_exit295 ], [ %537, %data_misaligned301 ], [ %552, %did_jump_exit312 ], [ %mem_val232, %jump_aligned ], [ %560, %jump_misalign ]
  %tail396 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %data_misaligned18 ], [ 2, %did_jump_exit28 ], [ 2, %data_misaligned34 ], [ 2, %did_jump_exit44 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit60 ], [ 2, %did_jump_exit64 ], [ 4, %data_misaligned68 ], [ 4, %did_jump_exit78 ], [ 4, %data_misaligned82 ], [ 4, %did_jump_exit92 ], [ 4, %did_jump_exit99 ], [ 2, %data_misaligned114 ], [ 2, %did_jump_exit124 ], [ 2, %did_jump_exit131 ], [ 2, %data_misaligned139 ], [ 2, %did_jump_exit149 ], [ 2, %did_jump_exit156 ], [ 2, %data_misaligned164 ], [ 2, %did_jump_exit174 ], [ 2, %did_jump_exit181 ], [ 4, %data_misaligned205 ], [ 4, %did_jump_exit212 ], [ 4, %data_misaligned217 ], [ 4, %did_jump_exit228 ], [ 2, %data_misaligned234 ], [ 2, %did_jump_exit245 ], [ 2, %data_misaligned250 ], [ 2, %did_jump_exit261 ], [ 2, %data_misaligned267 ], [ 2, %did_jump_exit278 ], [ 2, %data_misaligned284 ], [ 2, %did_jump_exit295 ], [ 2, %data_misaligned301 ], [ 2, %did_jump_exit312 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail397 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned18 ], [ 1, %did_jump_exit28 ], [ 1, %data_misaligned34 ], [ 1, %did_jump_exit44 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ], [ 13, %data_misaligned114 ], [ 13, %did_jump_exit124 ], [ 13, %did_jump_exit131 ], [ 16, %data_misaligned139 ], [ 16, %did_jump_exit149 ], [ 16, %did_jump_exit156 ], [ 19, %data_misaligned164 ], [ 19, %did_jump_exit174 ], [ 19, %did_jump_exit181 ], [ 25, %data_misaligned205 ], [ 25, %did_jump_exit212 ], [ 25, %data_misaligned217 ], [ 25, %did_jump_exit228 ], [ 26, %data_misaligned234 ], [ 26, %did_jump_exit245 ], [ 26, %data_misaligned250 ], [ 26, %did_jump_exit261 ], [ 26, %data_misaligned267 ], [ 26, %did_jump_exit278 ], [ 26, %data_misaligned284 ], [ 26, %did_jump_exit295 ], [ 26, %data_misaligned301 ], [ 26, %did_jump_exit312 ], [ 27, %jump_aligned ], [ 27, %jump_misalign ]
  %tail398 = phi i8 [ %40, %data_misaligned ], [ %54, %did_jump_exit ], [ %61, %data_misaligned3 ], [ %75, %did_jump_exit13 ], [ %82, %data_misaligned18 ], [ %96, %did_jump_exit28 ], [ %103, %data_misaligned34 ], [ %117, %did_jump_exit44 ], [ %124, %data_misaligned50 ], [ %139, %did_jump_exit60 ], [ %148, %did_jump_exit64 ], [ %160, %data_misaligned68 ], [ %174, %did_jump_exit78 ], [ %182, %data_misaligned82 ], [ %197, %did_jump_exit92 ], [ %206, %did_jump_exit99 ], [ %266, %data_misaligned114 ], [ %279, %did_jump_exit124 ], [ %288, %did_jump_exit131 ], [ %300, %data_misaligned139 ], [ %313, %did_jump_exit149 ], [ %322, %did_jump_exit156 ], [ %335, %data_misaligned164 ], [ %348, %did_jump_exit174 ], [ %357, %did_jump_exit181 ], [ %394, %data_misaligned205 ], [ %409, %did_jump_exit212 ], [ %417, %data_misaligned217 ], [ %433, %did_jump_exit228 ], [ %443, %data_misaligned234 ], [ %459, %did_jump_exit245 ], [ %467, %data_misaligned250 ], [ %483, %did_jump_exit261 ], [ %491, %data_misaligned267 ], [ %507, %did_jump_exit278 ], [ %515, %data_misaligned284 ], [ %531, %did_jump_exit295 ], [ %539, %data_misaligned301 ], [ %554, %did_jump_exit312 ], [ 1, %jump_aligned ], [ %562, %jump_misalign ]
  %609 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets400 = load i32, ptr %609, align 4
  %chain_total401 = add nuw i32 %chain_packets400, %packets
  %610 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget402 = load atomic i32, ptr %610 monotonic, align 4, !range !2
  %611 = icmp ult i32 %chain_total401, %chain_budget402
  br i1 %611, label %chain_lookup, label %chain_leave399, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %612 = lshr i32 %next_pc395, 1
  %613 = and i32 %612, 65535
  %614 = zext i32 %613 to i64
  %615 = mul i64 %614, 16
  %chain_slot403 = getelementptr i8, ptr %chain_table, i64 %615
  %616 = getelementptr i8, ptr %chain_slot403, i64 0
  %slot_pc404 = load i32, ptr %616, align 4
  %617 = icmp eq i32 %slot_pc404, %next_pc395
  br i1 %617, label %chain_hit405, label %chain_leave399, !prof !0

chain_leave399:                                   ; preds = %chain_lookup, %chain_exit
  %618 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %618, align 4
  %619 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail396, ptr %619, align 4
  %620 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail397, ptr %620, align 4
  %621 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail398, ptr %621, align 1
  br label %return

chain_hit405:                                     ; preds = %chain_lookup
  %622 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc395, ptr %622, align 4
  %623 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total401, ptr %623, align 4
  %624 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %624, align 1
  %625 = getelementptr i8, ptr %chain_slot403, i64 8
  %chain_fn406 = load ptr, ptr %625, align 8
  musttail call swifttailcc void %chain_fn406(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave399, %chain_leave372, %chain_leave363, %chain_leave345, %chain_leave336, %chain_leave334, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
