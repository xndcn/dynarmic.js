; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001014c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65868
  %6 = icmp ugt i32 %5, 34
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb108 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb108, 0
  %11 = sub i32 %guard_lb108, 65868
  %12 = icmp ugt i32 %11, 34
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x0001014c_entry, label %lb_guard_miss, !prof !0

insn_0x0001014c_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table144 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table144, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 32
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x0001014c_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 8, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x0001014c_entry, %28
  br label %insn_0x0001014c

insn_0x0001014c:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 16
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x0001014c
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x0001014c
  %37 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %37 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %38 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %38 to i64
  %39 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %39, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %42 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %42, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %43 = getelementptr i8, ptr %cpu, i32 20
  %r2 = load i32, ptr %43, align 4
  %44 = and i32 %sp_dec1, 3
  %45 = icmp ne i32 %44, 0
  br i1 %45, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %46 = getelementptr i8, ptr %cpu, i64 188
  %next_pc109 = load i32, ptr %46, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %47 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %48, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec1, i32 65536)
  %49 = getelementptr i8, ptr %cpu, i64 188
  %next_pc110 = load i32, ptr %49, align 4
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %50 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %50 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %51 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %51 to i64
  %52 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %52, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %53 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %54, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %55 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %55, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %sp_dec17 = sub i32 %sp_dec1, 4
  %56 = getelementptr i8, ptr %cpu, i32 24
  %r18 = load i32, ptr %56, align 4
  %57 = and i32 %sp_dec17, 3
  %58 = icmp ne i32 %57, 0
  br i1 %58, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %59 = getelementptr i8, ptr %cpu, i64 188
  %next_pc111 = load i32, ptr %59, align 4
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

data_misaligned19:                                ; preds = %page_wr_done7
  %60 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %61, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec17, i32 65536)
  %62 = getelementptr i8, ptr %cpu, i64 188
  %next_pc112 = load i32, ptr %62, align 4
  br label %chain_exit

data_aligned20:                                   ; preds = %page_wr_done7
  %63 = lshr i32 %sp_dec17, 12
  %page_index24 = zext i32 %63 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast21, label %page_wr_slow22, !prof !0

page_wr_fast21:                                   ; preds = %data_aligned20
  %64 = and i32 %sp_dec17, 4095
  %page_offset28 = zext i32 %64 to i64
  %65 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %r18, ptr %65, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %data_aligned20
  %66 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %66, align 4
  %67 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %67, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %r18)
  %68 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %68, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done23:                                   ; preds = %did_jump_cont30, %page_wr_fast21
  %sp_dec33 = sub i32 %sp_dec17, 4
  %69 = getelementptr i8, ptr %cpu, i32 28
  %r34 = load i32, ptr %69, align 4
  %70 = and i32 %sp_dec33, 3
  %71 = icmp ne i32 %70, 0
  br i1 %71, label %data_misaligned35, label %data_aligned36, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %72 = getelementptr i8, ptr %cpu, i64 188
  %next_pc113 = load i32, ptr %72, align 4
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow22
  br label %page_wr_done23

data_misaligned35:                                ; preds = %page_wr_done23
  %73 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %74, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec33, i32 65536)
  %75 = getelementptr i8, ptr %cpu, i64 188
  %next_pc114 = load i32, ptr %75, align 4
  br label %chain_exit

data_aligned36:                                   ; preds = %page_wr_done23
  %76 = lshr i32 %sp_dec33, 12
  %page_index40 = zext i32 %76 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_wr_fast37, label %page_wr_slow38, !prof !0

page_wr_fast37:                                   ; preds = %data_aligned36
  %77 = and i32 %sp_dec33, 4095
  %page_offset44 = zext i32 %77 to i64
  %78 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %r34, ptr %78, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %data_aligned36
  %79 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %80, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec33, i32 %r34)
  %81 = getelementptr i8, ptr %cpu, i32 296
  %dj47 = load i8, ptr %81, align 1
  %dj_set48 = icmp ne i8 %dj47, 0
  br i1 %dj_set48, label %did_jump_exit45, label %did_jump_cont46, !prof !1

page_wr_done39:                                   ; preds = %did_jump_cont46, %page_wr_fast37
  %sp_dec49 = sub i32 %sp_dec33, 4
  %82 = getelementptr i8, ptr %cpu, i32 52
  %p = load i32, ptr %82, align 4
  %83 = and i32 %sp_dec49, 3
  %84 = icmp ne i32 %83, 0
  br i1 %84, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %85 = getelementptr i8, ptr %cpu, i64 188
  %next_pc115 = load i32, ptr %85, align 4
  br label %chain_exit

did_jump_cont46:                                  ; preds = %page_wr_slow38
  br label %page_wr_done39

data_misaligned50:                                ; preds = %page_wr_done39
  %86 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %87, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65868, i32 %sp_dec49, i32 65536)
  %88 = getelementptr i8, ptr %cpu, i64 188
  %next_pc116 = load i32, ptr %88, align 4
  br label %chain_exit

data_aligned51:                                   ; preds = %page_wr_done39
  %89 = lshr i32 %sp_dec49, 12
  %page_index55 = zext i32 %89 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_wr_fast52, label %page_wr_slow53, !prof !0

page_wr_fast52:                                   ; preds = %data_aligned51
  %90 = and i32 %sp_dec49, 4095
  %page_offset59 = zext i32 %90 to i64
  %91 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p, ptr %91, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %data_aligned51
  %92 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %93, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec49, i32 %p)
  %94 = getelementptr i8, ptr %cpu, i32 296
  %dj62 = load i8, ptr %94, align 1
  %dj_set63 = icmp ne i8 %dj62, 0
  br i1 %dj_set63, label %did_jump_exit60, label %did_jump_cont61, !prof !1

page_wr_done54:                                   ; preds = %did_jump_cont61, %page_wr_fast52
  %95 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec49, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %97, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %98 = icmp ne i8 %cec_pending, 0
  br i1 %98, label %cec_check, label %cec_checked, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %99 = getelementptr i8, ptr %cpu, i64 188
  %next_pc117 = load i32, ptr %99, align 4
  br label %chain_exit

did_jump_cont61:                                  ; preds = %page_wr_slow53
  br label %page_wr_done54

cec_check:                                        ; preds = %page_wr_done54
  %100 = getelementptr i8, ptr %cpu, i32 188
  store i32 65870, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %102, align 4
  call void @cec_check_pending(ptr %cpu)
  %103 = getelementptr i8, ptr %cpu, i32 296
  %dj66 = load i8, ptr %103, align 1
  %dj_set67 = icmp ne i8 %dj66, 0
  br i1 %dj_set67, label %did_jump_exit64, label %did_jump_cont65, !prof !1

cec_checked:                                      ; preds = %did_jump_cont65, %page_wr_done54
  br label %insn_0x0001014e_entry

did_jump_exit64:                                  ; preds = %cec_check
  %104 = getelementptr i8, ptr %cpu, i64 188
  %next_pc118 = load i32, ptr %104, align 4
  br label %chain_exit

did_jump_cont65:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x0001014e_entry:                            ; preds = %cec_checked
  br label %insn_0x0001014e

insn_0x0001014e:                                  ; preds = %insn_0x0001014e_entry
  %105 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %106, align 4
  %sp1 = sub i32 %sp_dec49, 4
  %107 = and i32 %sp1, 3
  %108 = icmp ne i32 %107, 0
  br i1 %108, label %data_misaligned68, label %data_aligned69, !prof !1

data_misaligned68:                                ; preds = %insn_0x0001014e
  %109 = getelementptr i8, ptr %cpu, i32 188
  store i32 65870, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %111, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65870, i32 %sp1, i32 65536)
  %112 = getelementptr i8, ptr %cpu, i64 188
  %next_pc119 = load i32, ptr %112, align 4
  br label %chain_exit

data_aligned69:                                   ; preds = %insn_0x0001014e
  %113 = lshr i32 %sp1, 12
  %page_index73 = zext i32 %113 to i64
  %page_slot74 = getelementptr ptr, ptr %page_table, i64 %page_index73
  %page75 = load ptr, ptr %page_slot74, align 8
  %page_mapped76 = icmp ne ptr %page75, null
  br i1 %page_mapped76, label %page_wr_fast70, label %page_wr_slow71, !prof !0

page_wr_fast70:                                   ; preds = %data_aligned69
  %114 = and i32 %sp1, 4095
  %page_offset77 = zext i32 %114 to i64
  %115 = getelementptr i8, ptr %page75, i64 %page_offset77
  store i32 %rets, ptr %115, align 4
  br label %page_wr_done72

page_wr_slow71:                                   ; preds = %data_aligned69
  %116 = getelementptr i8, ptr %cpu, i32 188
  store i32 65870, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %118, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %119 = getelementptr i8, ptr %cpu, i32 296
  %dj80 = load i8, ptr %119, align 1
  %dj_set81 = icmp ne i8 %dj80, 0
  br i1 %dj_set81, label %did_jump_exit78, label %did_jump_cont79, !prof !1

page_wr_done72:                                   ; preds = %did_jump_cont79, %page_wr_fast70
  %sp2 = sub i32 %sp1, 4
  %120 = and i32 %sp2, 3
  %121 = icmp ne i32 %120, 0
  br i1 %121, label %data_misaligned82, label %data_aligned83, !prof !1

did_jump_exit78:                                  ; preds = %page_wr_slow71
  %122 = getelementptr i8, ptr %cpu, i64 188
  %next_pc120 = load i32, ptr %122, align 4
  br label %chain_exit

did_jump_cont79:                                  ; preds = %page_wr_slow71
  br label %page_wr_done72

data_misaligned82:                                ; preds = %page_wr_done72
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 65870, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %125, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65870, i32 %sp2, i32 65536)
  %126 = getelementptr i8, ptr %cpu, i64 188
  %next_pc121 = load i32, ptr %126, align 4
  br label %chain_exit

data_aligned83:                                   ; preds = %page_wr_done72
  %127 = lshr i32 %sp2, 12
  %page_index87 = zext i32 %127 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90 = icmp ne ptr %page89, null
  br i1 %page_mapped90, label %page_wr_fast84, label %page_wr_slow85, !prof !0

page_wr_fast84:                                   ; preds = %data_aligned83
  %128 = and i32 %sp2, 4095
  %page_offset91 = zext i32 %128 to i64
  %129 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %fp, ptr %129, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %data_aligned83
  %130 = getelementptr i8, ptr %cpu, i32 188
  store i32 65870, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %131, align 4
  %132 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %132, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %133 = getelementptr i8, ptr %cpu, i32 296
  %dj94 = load i8, ptr %133, align 1
  %dj_set95 = icmp ne i8 %dj94, 0
  br i1 %dj_set95, label %did_jump_exit92, label %did_jump_cont93, !prof !1

page_wr_done86:                                   ; preds = %did_jump_cont93, %page_wr_fast84
  %134 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %134, align 4
  %sp3 = sub i32 %sp2, 12
  %135 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %135, align 4
  %cec_pending96 = load i8, ptr %cec_pending_flag, align 1
  %136 = icmp ne i8 %cec_pending96, 0
  br i1 %136, label %cec_check97, label %cec_checked98, !prof !1

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %137 = getelementptr i8, ptr %cpu, i64 188
  %next_pc122 = load i32, ptr %137, align 4
  br label %chain_exit

did_jump_cont93:                                  ; preds = %page_wr_slow85
  br label %page_wr_done86

cec_check97:                                      ; preds = %page_wr_done86
  %138 = getelementptr i8, ptr %cpu, i32 188
  store i32 65874, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %140, align 4
  call void @cec_check_pending(ptr %cpu)
  %141 = getelementptr i8, ptr %cpu, i32 296
  %dj101 = load i8, ptr %141, align 1
  %dj_set102 = icmp ne i8 %dj101, 0
  br i1 %dj_set102, label %did_jump_exit99, label %did_jump_cont100, !prof !1

cec_checked98:                                    ; preds = %did_jump_cont100, %page_wr_done86
  br label %insn_0x00010152_entry

did_jump_exit99:                                  ; preds = %cec_check97
  %142 = getelementptr i8, ptr %cpu, i64 188
  %next_pc123 = load i32, ptr %142, align 4
  br label %chain_exit

did_jump_cont100:                                 ; preds = %cec_check97
  br label %cec_checked98

insn_0x00010152_entry:                            ; preds = %cec_checked98
  br label %insn_0x00010152

insn_0x00010152:                                  ; preds = %insn_0x00010152_entry
  %143 = getelementptr i8, ptr %cpu, i32 0
  %regmv_src = load i32, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i32 20
  store i32 %regmv_src, ptr %144, align 4
  br label %insn_0x00010154_entry

insn_0x00010154_entry:                            ; preds = %insn_0x00010152
  br label %insn_0x00010154

insn_0x00010154:                                  ; preds = %insn_0x00010154_entry
  %diff = sub i32 %regmv_src, 0
  %145 = icmp eq i32 %diff, 0
  %az = zext i1 %145 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %regmv_src, 31
  %146 = xor i32 %flgn, %flgs
  %147 = xor i32 %flgs, 0
  %overflow = and i32 %147, %146
  %an = xor i32 %flgn, %overflow
  %148 = icmp ule i32 0, %regmv_src
  %ac0 = zext i1 %148 to i32
  %149 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %153, align 4
  br label %insn_0x00010156_entry

insn_0x00010156_entry:                            ; preds = %insn_0x00010154
  br label %insn_0x00010156

insn_0x00010156:                                  ; preds = %insn_0x00010156_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x00010156
  %154 = getelementptr i8, ptr %cpu, i32 188
  store i32 65948, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %155, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %156 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %156 monotonic, align 4, !range !2
  %157 = icmp ult i32 %chain_total, %chain_budget
  br i1 %157, label %chain_go, label %chain_leave124, !prof !0

brt_fallthru:                                     ; preds = %insn_0x00010156
  br label %insn_0x00010158_entry

insn_0x00010158_entry:                            ; preds = %brt_fallthru
  br label %insn_0x00010158

insn_0x00010158:                                  ; preds = %insn_0x00010158_entry
  %lo_kept = and i32 %r, 65535
  %with_hi = or i32 %lo_kept, 1638400
  %158 = getelementptr i8, ptr %cpu, i32 16
  store i32 %with_hi, ptr %158, align 4
  br label %insn_0x0001015c_entry

insn_0x0001015c_entry:                            ; preds = %insn_0x00010158
  br label %insn_0x0001015c

insn_0x0001015c:                                  ; preds = %insn_0x0001015c_entry
  %lo_kept103 = and i32 %p, 65535
  %with_hi104 = or i32 %lo_kept103, 1013841920
  %159 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_hi104, ptr %159, align 4
  br label %insn_0x00010160_entry

insn_0x00010160_entry:                            ; preds = %insn_0x0001015c
  br label %insn_0x00010160

insn_0x00010160:                                  ; preds = %insn_0x00010160_entry
  %160 = getelementptr i8, ptr %cpu, i32 4
  %regmv_src105 = load i32, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 28
  store i32 %regmv_src105, ptr %161, align 4
  br label %insn_0x00010162_entry

insn_0x00010162_entry:                            ; preds = %insn_0x00010160
  br label %insn_0x00010162

insn_0x00010162:                                  ; preds = %insn_0x00010162_entry
  %162 = getelementptr i8, ptr %cpu, i32 0
  store i32 %regmv_src105, ptr %162, align 4
  br label %insn_0x00010164_entry

insn_0x00010164_entry:                            ; preds = %insn_0x00010162
  br label %insn_0x00010164

insn_0x00010164:                                  ; preds = %insn_0x00010164_entry
  %163 = getelementptr i8, ptr %cpu, i32 24
  store i32 0, ptr %163, align 4
  br label %insn_0x00010166_entry

insn_0x00010166_entry:                            ; preds = %insn_0x00010164
  br label %insn_0x00010166

insn_0x00010166:                                  ; preds = %insn_0x00010166_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 26125
  %164 = getelementptr i8, ptr %cpu, i32 16
  store i32 %with_lo, ptr %164, align 4
  br label %insn_0x0001016a_entry

insn_0x0001016a_entry:                            ; preds = %insn_0x00010166
  br label %insn_0x0001016a

insn_0x0001016a:                                  ; preds = %insn_0x0001016a_entry
  %hi_kept106 = and i32 %with_hi104, -65536
  %with_lo107 = or i32 %hi_kept106, 62303
  %165 = getelementptr i8, ptr %cpu, i32 52
  store i32 %with_lo107, ptr %165, align 4
  br label %insn_0x0001016e_entry

insn_0x0001016e_entry:                            ; preds = %insn_0x0001016a
  br label %insn_0x0001016e

insn_0x0001016e:                                  ; preds = %insn_0x0001016e_entry
  %166 = getelementptr i8, ptr %cpu, i32 188
  store i32 65916, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets127 = load i32, ptr %167, align 4
  %chain_total128 = add nuw i32 %chain_packets127, 13
  %168 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget129 = load atomic i32, ptr %168 monotonic, align 4, !range !2
  %169 = icmp ult i32 %chain_total128, %chain_budget129
  br i1 %169, label %chain_go125, label %chain_leave126, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %170 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %170, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527584
  %171 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %171, align 4
  %172 = icmp eq i32 %slot_pc, 65948
  br i1 %172, label %chain_hit, label %chain_leave124, !prof !0

chain_leave124:                                   ; preds = %chain_go, %brt_taken
  %173 = getelementptr i8, ptr %cpu, i64 188
  store i32 65948, ptr %173, align 4
  %174 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %175, align 4
  %176 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %176, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %177 = getelementptr i8, ptr %cpu, i64 188
  store i32 65948, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %178, align 4
  %179 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %179, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go125:                                      ; preds = %insn_0x0001016e
  %chain_slot130 = getelementptr i8, ptr %chain_table, i64 527328
  %180 = getelementptr i8, ptr %chain_slot130, i64 0
  %slot_pc131 = load i32, ptr %180, align 4
  %181 = icmp eq i32 %slot_pc131, 65916
  br i1 %181, label %chain_hit132, label %chain_leave126, !prof !0

chain_leave126:                                   ; preds = %chain_go125, %insn_0x0001016e
  %182 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 308
  store i32 13, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %185, align 1
  br label %return

chain_hit132:                                     ; preds = %chain_go125
  %186 = getelementptr i8, ptr %cpu, i64 188
  store i32 65916, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total128, ptr %187, align 4
  %188 = getelementptr i8, ptr %chain_slot130, i64 8
  %chain_fn133 = load ptr, ptr %188, align 8
  musttail call swifttailcc void %chain_fn133(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit99, %did_jump_exit92, %data_misaligned82, %did_jump_exit78, %data_misaligned68, %did_jump_exit64, %did_jump_exit60, %data_misaligned50, %did_jump_exit45, %data_misaligned35, %did_jump_exit29, %data_misaligned19, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc134 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc109, %did_jump_exit ], [ %next_pc110, %data_misaligned3 ], [ %next_pc111, %did_jump_exit13 ], [ %next_pc112, %data_misaligned19 ], [ %next_pc113, %did_jump_exit29 ], [ %next_pc114, %data_misaligned35 ], [ %next_pc115, %did_jump_exit45 ], [ %next_pc116, %data_misaligned50 ], [ %next_pc117, %did_jump_exit60 ], [ %next_pc118, %did_jump_exit64 ], [ %next_pc119, %data_misaligned68 ], [ %next_pc120, %did_jump_exit78 ], [ %next_pc121, %data_misaligned82 ], [ %next_pc122, %did_jump_exit92 ], [ %next_pc123, %did_jump_exit99 ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit29 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit60 ], [ 2, %did_jump_exit64 ], [ 4, %data_misaligned68 ], [ 4, %did_jump_exit78 ], [ 4, %data_misaligned82 ], [ 4, %did_jump_exit92 ], [ 4, %did_jump_exit99 ]
  %tail135 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %did_jump_exit64 ], [ 2, %data_misaligned68 ], [ 2, %did_jump_exit78 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit99 ]
  %189 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets137 = load i32, ptr %189, align 4
  %chain_total138 = add nuw i32 %chain_packets137, %packets
  %190 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget139 = load atomic i32, ptr %190 monotonic, align 4, !range !2
  %191 = icmp ult i32 %chain_total138, %chain_budget139
  br i1 %191, label %chain_lookup, label %chain_leave136, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %192 = lshr i32 %next_pc134, 1
  %193 = and i32 %192, 65535
  %194 = zext i32 %193 to i64
  %195 = mul i64 %194, 16
  %chain_slot140 = getelementptr i8, ptr %chain_table, i64 %195
  %196 = getelementptr i8, ptr %chain_slot140, i64 0
  %slot_pc141 = load i32, ptr %196, align 4
  %197 = icmp eq i32 %slot_pc141, %next_pc134
  br i1 %197, label %chain_hit142, label %chain_leave136, !prof !0

chain_leave136:                                   ; preds = %chain_lookup, %chain_exit
  %198 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail135, ptr %199, align 4
  br label %return

chain_hit142:                                     ; preds = %chain_lookup
  %200 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total138, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %201, align 1
  %202 = getelementptr i8, ptr %chain_slot140, i64 8
  %chain_fn143 = load ptr, ptr %202, align 8
  musttail call swifttailcc void %chain_fn143(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave136, %chain_leave126, %chain_leave124, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
