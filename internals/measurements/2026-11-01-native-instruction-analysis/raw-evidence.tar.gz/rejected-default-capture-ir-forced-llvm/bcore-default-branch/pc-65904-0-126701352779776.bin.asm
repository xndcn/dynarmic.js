
build-native-instruction-analysis/capture/bcore-default-branch/pc-65904-0-126701352779776.bin:     file format binary


Disassembly of section .data:

0000733bf5200000 <.data>:
    733bf5200000:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    733bf5200007:	30 01 01 00 
    733bf520000b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200012:	04 00 00 00 
    733bf5200016:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x2
    733bf520001d:	02 00 00 00 
    733bf5200021:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf5200028:	01 
    733bf5200029:	c2 08 00             	ret    0x8
    733bf520002c:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf5200033:	01 
    733bf5200034:	c2 08 00             	ret    0x8
