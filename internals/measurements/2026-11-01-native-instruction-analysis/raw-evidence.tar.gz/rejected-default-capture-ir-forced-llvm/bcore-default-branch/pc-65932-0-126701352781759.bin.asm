
build-native-instruction-analysis/capture/bcore-default-branch/pc-65932-0-126701352781759.bin:     file format binary


Disassembly of section .data:

0000733bf52007bf <.data>:
    733bf52007bf:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf52007c6:	01 
    733bf52007c7:	48 83 c4 18          	add    rsp,0x18
    733bf52007cb:	c2 08 00             	ret    0x8
    733bf52007ce:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    733bf52007d5:	41 89 ad 24 01 00 00 	mov    DWORD PTR [r13+0x124],ebp
    733bf52007dc:	41 89 9d 34 01 00 00 	mov    DWORD PTR [r13+0x134],ebx
    733bf52007e3:	41 88 8d 28 01 00 00 	mov    BYTE PTR [r13+0x128],cl
    733bf52007ea:	48 83 c4 18          	add    rsp,0x18
    733bf52007ee:	c2 08 00             	ret    0x8
    733bf52007f1:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    733bf52007f8:	7c 01 01 00 
    733bf52007fc:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200803:	02 00 00 00 
    733bf5200807:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x3
    733bf520080e:	03 00 00 00 
    733bf5200812:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x1
    733bf5200819:	01 
    733bf520081a:	48 83 c4 18          	add    rsp,0x18
    733bf520081e:	c2 08 00             	ret    0x8
    733bf5200821:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    733bf5200828:	94 01 01 00 
    733bf520082c:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200833:	04 00 00 00 
    733bf5200837:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf520083e:	05 00 00 00 
    733bf5200842:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bf5200849:	59 00 00 
    733bf520084c:	4c 89 ef             	mov    rdi,r13
    733bf520084f:	4c 89 f6             	mov    rsi,r14
    733bf5200852:	ba 94 01 01 00       	mov    edx,0x10194
    733bf5200857:	89 e9                	mov    ecx,ebp
    733bf5200859:	4c 89 c3             	mov    rbx,r8
    733bf520085c:	45 31 c0             	xor    r8d,r8d
    733bf520085f:	ff d0                	call   rax
    733bf5200861:	49 89 d8             	mov    r8,rbx
    733bf5200864:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    733bf520086b:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200872:	00 
    733bf5200873:	bb 05 00 00 00       	mov    ebx,0x5
    733bf5200878:	bd 04 00 00 00       	mov    ebp,0x4
    733bf520087d:	e9 c3 d1 00 e8       	jmp    0x733bdd20da45
    733bf5200882:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200887:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    733bf520088e:	94 01 01 00 
    733bf5200892:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200899:	04 00 00 00 
    733bf520089d:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf52008a4:	05 00 00 00 
    733bf52008a8:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf52008af:	59 00 00 
    733bf52008b2:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf52008b7:	4c 89 f7             	mov    rdi,r14
    733bf52008ba:	89 ee                	mov    esi,ebp
    733bf52008bc:	ff d0                	call   rax
    733bf52008be:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52008c5:	00 
    733bf52008c6:	84 c9                	test   cl,cl
    733bf52008c8:	0f 85 98 02 00 00    	jne    0x733bf5200b66
    733bf52008ce:	89 c3                	mov    ebx,eax
    733bf52008d0:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf52008d5:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf52008da:	e9 71 d0 00 e8       	jmp    0x733bdd20d950
    733bf52008df:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf52008e4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10194
    733bf52008eb:	94 01 01 00 
    733bf52008ef:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52008f6:	04 00 00 00 
    733bf52008fa:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x5
    733bf5200901:	05 00 00 00 
    733bf5200905:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf520090c:	59 00 00 
    733bf520090f:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf5200914:	4c 89 f7             	mov    rdi,r14
    733bf5200917:	ff d0                	call   rax
    733bf5200919:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200920:	00 
    733bf5200921:	84 c9                	test   cl,cl
    733bf5200923:	0f 85 3d 02 00 00    	jne    0x733bf5200b66
    733bf5200929:	41 89 c7             	mov    r15d,eax
    733bf520092c:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf5200931:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200936:	e9 34 d0 00 e8       	jmp    0x733bdd20d96f
    733bf520093b:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200940:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    733bf5200947:	98 01 01 00 
    733bf520094b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200952:	02 00 00 00 
    733bf5200956:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf520095d:	06 00 00 00 
    733bf5200961:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf5200968:	59 00 00 
    733bf520096b:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf5200970:	4c 89 f7             	mov    rdi,r14
    733bf5200973:	ff d0                	call   rax
    733bf5200975:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520097c:	00 
    733bf520097d:	84 c9                	test   cl,cl
    733bf520097f:	0f 85 c1 01 00 00    	jne    0x733bf5200b46
    733bf5200985:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf520098a:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf520098f:	e9 08 d0 00 e8       	jmp    0x733bdd20d99c
    733bf5200994:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200999:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    733bf52009a0:	98 01 01 00 
    733bf52009a4:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf52009ab:	02 00 00 00 
    733bf52009af:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf52009b6:	06 00 00 00 
    733bf52009ba:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf52009c1:	59 00 00 
    733bf52009c4:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf52009c9:	4c 89 f7             	mov    rdi,r14
    733bf52009cc:	ff d0                	call   rax
    733bf52009ce:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52009d5:	00 
    733bf52009d6:	84 c9                	test   cl,cl
    733bf52009d8:	0f 85 68 01 00 00    	jne    0x733bf5200b46
    733bf52009de:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf52009e3:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf52009e8:	e9 d1 cf 00 e8       	jmp    0x733bdd20d9be
    733bf52009ed:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf52009f2:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    733bf52009f9:	98 01 01 00 
    733bf52009fd:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200a04:	02 00 00 00 
    733bf5200a08:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf5200a0f:	06 00 00 00 
    733bf5200a13:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf5200a1a:	59 00 00 
    733bf5200a1d:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf5200a22:	4c 89 f7             	mov    rdi,r14
    733bf5200a25:	ff d0                	call   rax
    733bf5200a27:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200a2e:	00 
    733bf5200a2f:	84 c9                	test   cl,cl
    733bf5200a31:	0f 85 0f 01 00 00    	jne    0x733bf5200b46
    733bf5200a37:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf5200a3c:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200a41:	e9 9a cf 00 e8       	jmp    0x733bdd20d9e0
    733bf5200a46:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200a4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    733bf5200a52:	98 01 01 00 
    733bf5200a56:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200a5d:	02 00 00 00 
    733bf5200a61:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf5200a68:	06 00 00 00 
    733bf5200a6c:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf5200a73:	59 00 00 
    733bf5200a76:	4c 89 74 24 10       	mov    QWORD PTR [rsp+0x10],r14
    733bf5200a7b:	4c 89 f7             	mov    rdi,r14
    733bf5200a7e:	ff d0                	call   rax
    733bf5200a80:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200a87:	00 
    733bf5200a88:	84 c9                	test   cl,cl
    733bf5200a8a:	0f 85 b6 00 00 00    	jne    0x733bf5200b46
    733bf5200a90:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf5200a95:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200a9a:	e9 63 cf 00 e8       	jmp    0x733bdd20da02
    733bf5200a9f:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
    733bf5200aa4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10198
    733bf5200aab:	98 01 01 00 
    733bf5200aaf:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200ab6:	02 00 00 00 
    733bf5200aba:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf5200ac1:	06 00 00 00 
    733bf5200ac5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf5200acc:	59 00 00 
    733bf5200acf:	4d 89 f4             	mov    r12,r14
    733bf5200ad2:	4c 89 f7             	mov    rdi,r14
    733bf5200ad5:	ff d0                	call   rax
    733bf5200ad7:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200ade:	00 
    733bf5200adf:	84 c9                	test   cl,cl
    733bf5200ae1:	0f 85 92 00 00 00    	jne    0x733bf5200b79
    733bf5200ae7:	4d 89 e6             	mov    r14,r12
    733bf5200aea:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200aef:	e9 30 cf 00 e8       	jmp    0x733bdd20da24
    733bf5200af4:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1019a
    733bf5200afb:	9a 01 01 00 
    733bf5200aff:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf5200b06:	02 00 00 00 
    733bf5200b0a:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    733bf5200b11:	07 00 00 00 
    733bf5200b15:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bf5200b1c:	59 00 00 
    733bf5200b1f:	4c 89 ef             	mov    rdi,r13
    733bf5200b22:	be 2a 00 00 00       	mov    esi,0x2a
    733bf5200b27:	4c 89 f2             	mov    rdx,r14
    733bf5200b2a:	4d 89 c7             	mov    r15,r8
    733bf5200b2d:	ff d0                	call   rax
    733bf5200b2f:	4d 89 f8             	mov    r8,r15
    733bf5200b32:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    733bf5200b39:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200b40:	00 
    733bf5200b41:	e9 ff ce 00 e8       	jmp    0x733bdd20da45
    733bf5200b46:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    733bf5200b4d:	bb 06 00 00 00       	mov    ebx,0x6
    733bf5200b52:	bd 02 00 00 00       	mov    ebp,0x2
    733bf5200b57:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
    733bf5200b5c:	4c 8b 44 24 08       	mov    r8,QWORD PTR [rsp+0x8]
    733bf5200b61:	e9 df ce 00 e8       	jmp    0x733bdd20da45
    733bf5200b66:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    733bf5200b6d:	bb 05 00 00 00       	mov    ebx,0x5
    733bf5200b72:	bd 04 00 00 00       	mov    ebp,0x4
    733bf5200b77:	eb de                	jmp    0x733bf5200b57
    733bf5200b79:	45 8b bd bc 00 00 00 	mov    r15d,DWORD PTR [r13+0xbc]
    733bf5200b80:	bb 06 00 00 00       	mov    ebx,0x6
    733bf5200b85:	bd 02 00 00 00       	mov    ebp,0x2
    733bf5200b8a:	4d 89 e6             	mov    r14,r12
    733bf5200b8d:	eb cd                	jmp    0x733bf5200b5c
