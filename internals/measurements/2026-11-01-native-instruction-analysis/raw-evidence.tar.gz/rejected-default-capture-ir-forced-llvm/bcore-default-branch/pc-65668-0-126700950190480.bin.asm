
build-native-instruction-analysis/capture/bcore-default-branch/pc-65668-0-126700950190480.bin:     file format binary


Disassembly of section .data:

0000733bdd20f990 <.data>:
    733bdd20f990:	48 81 ec a8 00 00 00 	sub    rsp,0xa8
    733bdd20f997:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
    733bdd20f99e:	00 
    733bdd20f99f:	4c 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r13
    733bdd20f9a6:	00 
    733bdd20f9a7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20f9ae:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd20f9b5:	00 
    733bdd20f9b6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20f9bd:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    733bdd20f9c4:	00 
    733bdd20f9c5:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    733bdd20f9cc:	00 
    733bdd20f9cd:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20f9d3:	83 fa 00             	cmp    edx,0x0
    733bdd20f9d6:	0f 94 c0             	sete   al
    733bdd20f9d9:	81 ea 84 00 01 00    	sub    edx,0x10084
    733bdd20f9df:	83 fa 0a             	cmp    edx,0xa
    733bdd20f9e2:	0f 97 c2             	seta   dl
    733bdd20f9e5:	08 d0                	or     al,dl
    733bdd20f9e7:	24 01                	and    al,0x1
    733bdd20f9e9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20f9ef:	83 fa 00             	cmp    edx,0x0
    733bdd20f9f2:	0f 94 c1             	sete   cl
    733bdd20f9f5:	81 ea 84 00 01 00    	sub    edx,0x10084
    733bdd20f9fb:	83 fa 0a             	cmp    edx,0xa
    733bdd20f9fe:	0f 97 c2             	seta   dl
    733bdd20fa01:	08 d1                	or     cl,dl
    733bdd20fa03:	20 c8                	and    al,cl
    733bdd20fa05:	a8 01                	test   al,0x1
    733bdd20fa07:	75 05                	jne    0x733bdd20fa0e
    733bdd20fa09:	e9 c9 03 00 00       	jmp    0x733bdd20fdd7
    733bdd20fa0e:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fa15:	00 
    733bdd20fa16:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20fa1d:	48 89 c8             	mov    rax,rcx
    733bdd20fa20:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20fa26:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd20fa2d:	00 
    733bdd20fa2e:	8b 81 40 00 10 00    	mov    eax,DWORD PTR [rcx+0x100040]
    733bdd20fa34:	83 c0 01             	add    eax,0x1
    733bdd20fa37:	89 81 40 00 10 00    	mov    DWORD PTR [rcx+0x100040],eax
    733bdd20fa3d:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20fa42:	75 46                	jne    0x733bdd20fa8a
    733bdd20fa44:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    733bdd20fa4b:	00 
    733bdd20fa4c:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20fa52:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd20fa56:	89 c2                	mov    edx,eax
    733bdd20fa58:	83 c2 01             	add    edx,0x1
    733bdd20fa5b:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20fa61:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20fa66:	73 20                	jae    0x733bdd20fa88
    733bdd20fa68:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd20fa6f:	00 
    733bdd20fa70:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    733bdd20fa74:	89 c9                	mov    ecx,ecx
    733bdd20fa76:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20fa7a:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20fa81:	c7 04 08 10 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x10
    733bdd20fa88:	eb 00                	jmp    0x733bdd20fa8a
    733bdd20fa8a:	eb 00                	jmp    0x733bdd20fa8c
    733bdd20fa8c:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fa93:	00 
    733bdd20fa94:	8b 48 10             	mov    ecx,DWORD PTR [rax+0x10]
    733bdd20fa97:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd20fa9b:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    733bdd20fa9e:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd20faa2:	83 c0 fc             	add    eax,0xfffffffc
    733bdd20faa5:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    733bdd20faa9:	83 e0 03             	and    eax,0x3
    733bdd20faac:	83 f8 00             	cmp    eax,0x0
    733bdd20faaf:	74 67                	je     0x733bdd20fb18
    733bdd20fab1:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    733bdd20fab8:	00 
    733bdd20fab9:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    733bdd20fabd:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    733bdd20fac4:	00 
    733bdd20fac5:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    733bdd20facc:	00 00 00 
    733bdd20facf:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd20fad6:	00 00 00 
    733bdd20fad9:	31 c0                	xor    eax,eax
    733bdd20fadb:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20fae2:	59 00 00 
    733bdd20fae5:	ba 84 00 01 00       	mov    edx,0x10084
    733bdd20faea:	45 31 c0             	xor    r8d,r8d
    733bdd20faed:	ff d0                	call   rax
    733bdd20faef:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20faf6:	00 
    733bdd20faf7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20fafd:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd20fb02:	b8 08 00 00 00       	mov    eax,0x8
    733bdd20fb07:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    733bdd20fb0b:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd20fb0f:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd20fb13:	e9 60 03 00 00       	jmp    0x733bdd20fe78
    733bdd20fb18:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    733bdd20fb1f:	00 
    733bdd20fb20:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    733bdd20fb24:	c1 e9 0c             	shr    ecx,0xc
    733bdd20fb27:	89 c9                	mov    ecx,ecx
    733bdd20fb29:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20fb2d:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd20fb32:	48 83 f8 00          	cmp    rax,0x0
    733bdd20fb36:	74 1a                	je     0x733bdd20fb52
    733bdd20fb38:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd20fb3d:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    733bdd20fb41:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20fb47:	89 c9                	mov    ecx,ecx
    733bdd20fb49:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20fb4c:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd20fb50:	eb 4d                	jmp    0x733bdd20fb9f
    733bdd20fb52:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fb59:	00 
    733bdd20fb5a:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    733bdd20fb5e:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    733bdd20fb65:	00 
    733bdd20fb66:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    733bdd20fb6d:	00 00 00 
    733bdd20fb70:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd20fb77:	00 00 00 
    733bdd20fb7a:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20fb81:	59 00 00 
    733bdd20fb84:	ff d0                	call   rax
    733bdd20fb86:	89 c1                	mov    ecx,eax
    733bdd20fb88:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fb8f:	00 
    733bdd20fb90:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd20fb94:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20fb9b:	75 2d                	jne    0x733bdd20fbca
    733bdd20fb9d:	eb 54                	jmp    0x733bdd20fbf3
    733bdd20fb9f:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fba6:	00 
    733bdd20fba7:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    733bdd20fbab:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd20fbaf:	89 10                	mov    DWORD PTR [rax],edx
    733bdd20fbb1:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20fbb4:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd20fbba:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd20fbbe:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd20fbc4:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20fbc8:	eb 33                	jmp    0x733bdd20fbfd
    733bdd20fbca:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fbd1:	00 
    733bdd20fbd2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20fbd8:	b9 01 00 00 00       	mov    ecx,0x1
    733bdd20fbdd:	b8 08 00 00 00       	mov    eax,0x8
    733bdd20fbe2:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    733bdd20fbe6:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd20fbea:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd20fbee:	e9 85 02 00 00       	jmp    0x733bdd20fe78
    733bdd20fbf3:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    733bdd20fbf7:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd20fbfb:	eb a2                	jmp    0x733bdd20fb9f
    733bdd20fbfd:	eb 00                	jmp    0x733bdd20fbff
    733bdd20fbff:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd20fc03:	83 c0 f8             	add    eax,0xfffffff8
    733bdd20fc06:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20fc0a:	83 e0 03             	and    eax,0x3
    733bdd20fc0d:	83 f8 00             	cmp    eax,0x0
    733bdd20fc10:	74 6e                	je     0x733bdd20fc80
    733bdd20fc12:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    733bdd20fc19:	00 
    733bdd20fc1a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20fc1e:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    733bdd20fc25:	00 
    733bdd20fc26:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    733bdd20fc2d:	00 01 00 
    733bdd20fc30:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20fc37:	00 00 00 
    733bdd20fc3a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd20fc41:	00 00 00 
    733bdd20fc44:	31 c0                	xor    eax,eax
    733bdd20fc46:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20fc4d:	59 00 00 
    733bdd20fc50:	ba 8c 00 01 00       	mov    edx,0x1008c
    733bdd20fc55:	45 31 c0             	xor    r8d,r8d
    733bdd20fc58:	ff d0                	call   rax
    733bdd20fc5a:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fc61:	00 
    733bdd20fc62:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    733bdd20fc68:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20fc6d:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    733bdd20fc71:	89 c1                	mov    ecx,eax
    733bdd20fc73:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd20fc77:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd20fc7b:	e9 f8 01 00 00       	jmp    0x733bdd20fe78
    733bdd20fc80:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    733bdd20fc87:	00 
    733bdd20fc88:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20fc8c:	c1 e9 0c             	shr    ecx,0xc
    733bdd20fc8f:	89 c9                	mov    ecx,ecx
    733bdd20fc91:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20fc95:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd20fc9a:	48 83 f8 00          	cmp    rax,0x0
    733bdd20fc9e:	74 1a                	je     0x733bdd20fcba
    733bdd20fca0:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd20fca5:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20fca9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20fcaf:	89 c9                	mov    ecx,ecx
    733bdd20fcb1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20fcb4:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20fcb8:	eb 57                	jmp    0x733bdd20fd11
    733bdd20fcba:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fcc1:	00 
    733bdd20fcc2:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd20fcc6:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    733bdd20fccd:	00 
    733bdd20fcce:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    733bdd20fcd5:	00 01 00 
    733bdd20fcd8:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20fcdf:	00 00 00 
    733bdd20fce2:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd20fce9:	00 00 00 
    733bdd20fcec:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20fcf3:	59 00 00 
    733bdd20fcf6:	ff d0                	call   rax
    733bdd20fcf8:	89 c1                	mov    ecx,eax
    733bdd20fcfa:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fd01:	00 
    733bdd20fd02:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd20fd06:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20fd0d:	75 13                	jne    0x733bdd20fd22
    733bdd20fd0f:	eb 37                	jmp    0x733bdd20fd48
    733bdd20fd11:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fd18:	00 
    733bdd20fd19:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    733bdd20fd1d:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    733bdd20fd20:	eb 30                	jmp    0x733bdd20fd52
    733bdd20fd22:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fd29:	00 
    733bdd20fd2a:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    733bdd20fd30:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20fd35:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    733bdd20fd39:	89 c1                	mov    ecx,eax
    733bdd20fd3b:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd20fd3f:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd20fd43:	e9 30 01 00 00       	jmp    0x733bdd20fe78
    733bdd20fd48:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd20fd4c:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd20fd50:	eb bf                	jmp    0x733bdd20fd11
    733bdd20fd52:	eb 00                	jmp    0x733bdd20fd54
    733bdd20fd54:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    733bdd20fd5b:	00 
    733bdd20fd5c:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    733bdd20fd60:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd20fd64:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd20fd6a:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd20fd70:	83 ff 01             	cmp    edi,0x1
    733bdd20fd73:	0f 97 c3             	seta   bl
    733bdd20fd76:	3d 8e 00 01 00       	cmp    eax,0x1008e
    733bdd20fd7b:	0f 94 c0             	sete   al
    733bdd20fd7e:	20 c3                	and    bl,al
    733bdd20fd80:	b8 92 00 01 00       	mov    eax,0x10092
    733bdd20fd85:	f6 c3 01             	test   bl,0x1
    733bdd20fd88:	0f 45 c2             	cmovne eax,edx
    733bdd20fd8b:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd20fd91:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd20fd97:	83 ff 01             	cmp    edi,0x1
    733bdd20fd9a:	0f 97 c3             	seta   bl
    733bdd20fd9d:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    733bdd20fda3:	40 0f 94 c6          	sete   sil
    733bdd20fda7:	40 20 f3             	and    bl,sil
    733bdd20fdaa:	f6 c3 01             	test   bl,0x1
    733bdd20fdad:	0f 45 c2             	cmovne eax,edx
    733bdd20fdb0:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd20fdb6:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    733bdd20fdbd:	03 01 00 
    733bdd20fdc0:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20fdc6:	83 c0 03             	add    eax,0x3
    733bdd20fdc9:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd20fdcd:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20fdd3:	72 16                	jb     0x733bdd20fdeb
    733bdd20fdd5:	eb 37                	jmp    0x733bdd20fe0e
    733bdd20fdd7:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fdde:	00 
    733bdd20fddf:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20fde6:	e9 41 01 00 00       	jmp    0x733bdd20ff2c
    733bdd20fdeb:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd20fdf2:	00 
    733bdd20fdf3:	48 89 c1             	mov    rcx,rax
    733bdd20fdf6:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    733bdd20fdfd:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd20fe02:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    733bdd20fe09:	03 01 00 
    733bdd20fe0c:	74 32                	je     0x733bdd20fe40
    733bdd20fe0e:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fe15:	00 
    733bdd20fe16:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    733bdd20fe1d:	03 01 00 
    733bdd20fe20:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20fe27:	00 00 00 
    733bdd20fe2a:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd20fe31:	00 00 00 
    733bdd20fe34:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20fe3b:	e9 ec 00 00 00       	jmp    0x733bdd20ff2c
    733bdd20fe40:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    733bdd20fe47:	00 
    733bdd20fe48:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    733bdd20fe4f:	00 
    733bdd20fe50:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd20fe55:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    733bdd20fe59:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    733bdd20fe60:	28 03 01 00 
    733bdd20fe64:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20fe6b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20fe6f:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    733bdd20fe76:	ff e0                	jmp    rax
    733bdd20fe78:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    733bdd20fe7f:	00 
    733bdd20fe80:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    733bdd20fe84:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    733bdd20fe88:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    733bdd20fe8c:	89 c7                	mov    edi,eax
    733bdd20fe8e:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd20fe92:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd20fe96:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd20fe9a:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20fea0:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd20fea4:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20feaa:	73 2d                	jae    0x733bdd20fed9
    733bdd20feac:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd20feb3:	00 
    733bdd20feb4:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd20feb8:	89 d1                	mov    ecx,edx
    733bdd20feba:	c1 e9 01             	shr    ecx,0x1
    733bdd20febd:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20fec3:	89 c9                	mov    ecx,ecx
    733bdd20fec5:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20fec9:	48 89 c6             	mov    rsi,rax
    733bdd20fecc:	48 01 ce             	add    rsi,rcx
    733bdd20fecf:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd20fed4:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20fed7:	74 1e                	je     0x733bdd20fef7
    733bdd20fed9:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20fee0:	00 
    733bdd20fee1:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd20fee5:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd20fee9:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd20feef:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd20fef5:	eb 35                	jmp    0x733bdd20ff2c
    733bdd20fef7:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    733bdd20fefe:	00 
    733bdd20feff:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    733bdd20ff06:	00 
    733bdd20ff07:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd20ff0c:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd20ff10:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20ff17:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20ff1e:	00 
    733bdd20ff1f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20ff23:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    733bdd20ff2a:	ff e0                	jmp    rax
    733bdd20ff2c:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    733bdd20ff33:	c2 08 00             	ret    0x8
