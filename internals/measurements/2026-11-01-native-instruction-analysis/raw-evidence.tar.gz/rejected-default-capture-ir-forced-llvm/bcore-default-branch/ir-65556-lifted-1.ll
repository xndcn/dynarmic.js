; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010014(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65556
  %6 = icmp ugt i32 %5, 42
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb324 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb324, 0
  %11 = sub i32 %guard_lb324, 65556
  %12 = icmp ugt i32 %11, 42
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010014_entry, label %lb_guard_miss, !prof !0

insn_0x00010014_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table381 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table381, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 4
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010014_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 1, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010014_entry, %28
  br label %insn_0x00010014

insn_0x00010014:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 16
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010014
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 188
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  %40 = load i8, ptr %39, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010014
  %41 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %41 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %42 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %42 to i64
  %43 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %43, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %45, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %46 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %46, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %47 = getelementptr i8, ptr %cpu, i32 20
  %r2 = load i32, ptr %47, align 4
  %48 = and i32 %sp_dec1, 3
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %50 = getelementptr i8, ptr %cpu, i64 188
  %next_pc325 = load i32, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 188
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %cpu, i64 296
  %54 = load i8, ptr %53, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %55 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %56, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec1, i32 65536)
  %57 = getelementptr i8, ptr %cpu, i64 188
  %next_pc326 = load i32, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 188
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %cpu, i64 296
  %61 = load i8, ptr %60, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %62 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %62 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %63 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %63 to i64
  %64 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %64, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %65 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %66, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %67 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %67, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %sp_dec17 = sub i32 %sp_dec1, 4
  %68 = getelementptr i8, ptr %cpu, i32 24
  %r18 = load i32, ptr %68, align 4
  %69 = and i32 %sp_dec17, 3
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %71 = getelementptr i8, ptr %cpu, i64 188
  %next_pc327 = load i32, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i64 188
  %73 = load i32, ptr %72, align 4
  %74 = getelementptr i8, ptr %cpu, i64 296
  %75 = load i8, ptr %74, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

data_misaligned19:                                ; preds = %page_wr_done7
  %76 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %77, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec17, i32 65536)
  %78 = getelementptr i8, ptr %cpu, i64 188
  %next_pc328 = load i32, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 188
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %cpu, i64 296
  %82 = load i8, ptr %81, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_wr_done7
  %83 = lshr i32 %sp_dec17, 12
  %page_index24 = zext i32 %83 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_wr_fast21, label %page_wr_slow22, !prof !0

page_wr_fast21:                                   ; preds = %data_aligned20
  %84 = and i32 %sp_dec17, 4095
  %page_offset28 = zext i32 %84 to i64
  %85 = getelementptr i8, ptr %page26, i64 %page_offset28
  store i32 %r18, ptr %85, align 4
  br label %page_wr_done23

page_wr_slow22:                                   ; preds = %data_aligned20
  %86 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %87, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec17, i32 %r18)
  %88 = getelementptr i8, ptr %cpu, i32 296
  %dj31 = load i8, ptr %88, align 1
  %dj_set32 = icmp ne i8 %dj31, 0
  br i1 %dj_set32, label %did_jump_exit29, label %did_jump_cont30, !prof !1

page_wr_done23:                                   ; preds = %did_jump_cont30, %page_wr_fast21
  %sp_dec33 = sub i32 %sp_dec17, 4
  %89 = getelementptr i8, ptr %cpu, i32 28
  %r34 = load i32, ptr %89, align 4
  %90 = and i32 %sp_dec33, 3
  %91 = icmp ne i32 %90, 0
  br i1 %91, label %data_misaligned35, label %data_aligned36, !prof !1

did_jump_exit29:                                  ; preds = %page_wr_slow22
  %92 = getelementptr i8, ptr %cpu, i64 188
  %next_pc329 = load i32, ptr %92, align 4
  %93 = getelementptr i8, ptr %cpu, i64 188
  %94 = load i32, ptr %93, align 4
  %95 = getelementptr i8, ptr %cpu, i64 296
  %96 = load i8, ptr %95, align 1
  br label %chain_exit

did_jump_cont30:                                  ; preds = %page_wr_slow22
  br label %page_wr_done23

data_misaligned35:                                ; preds = %page_wr_done23
  %97 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %98, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec33, i32 65536)
  %99 = getelementptr i8, ptr %cpu, i64 188
  %next_pc330 = load i32, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i64 188
  %101 = load i32, ptr %100, align 4
  %102 = getelementptr i8, ptr %cpu, i64 296
  %103 = load i8, ptr %102, align 1
  br label %chain_exit

data_aligned36:                                   ; preds = %page_wr_done23
  %104 = lshr i32 %sp_dec33, 12
  %page_index40 = zext i32 %104 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_wr_fast37, label %page_wr_slow38, !prof !0

page_wr_fast37:                                   ; preds = %data_aligned36
  %105 = and i32 %sp_dec33, 4095
  %page_offset44 = zext i32 %105 to i64
  %106 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %r34, ptr %106, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %data_aligned36
  %107 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %108, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec33, i32 %r34)
  %109 = getelementptr i8, ptr %cpu, i32 296
  %dj47 = load i8, ptr %109, align 1
  %dj_set48 = icmp ne i8 %dj47, 0
  br i1 %dj_set48, label %did_jump_exit45, label %did_jump_cont46, !prof !1

page_wr_done39:                                   ; preds = %did_jump_cont46, %page_wr_fast37
  %sp_dec49 = sub i32 %sp_dec33, 4
  %110 = getelementptr i8, ptr %cpu, i32 44
  %p = load i32, ptr %110, align 4
  %111 = and i32 %sp_dec49, 3
  %112 = icmp ne i32 %111, 0
  br i1 %112, label %data_misaligned50, label %data_aligned51, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %113 = getelementptr i8, ptr %cpu, i64 188
  %next_pc331 = load i32, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 188
  %115 = load i32, ptr %114, align 4
  %116 = getelementptr i8, ptr %cpu, i64 296
  %117 = load i8, ptr %116, align 1
  br label %chain_exit

did_jump_cont46:                                  ; preds = %page_wr_slow38
  br label %page_wr_done39

data_misaligned50:                                ; preds = %page_wr_done39
  %118 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %119, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec49, i32 65536)
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc332 = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

data_aligned51:                                   ; preds = %page_wr_done39
  %125 = lshr i32 %sp_dec49, 12
  %page_index55 = zext i32 %125 to i64
  %page_slot56 = getelementptr ptr, ptr %page_table, i64 %page_index55
  %page57 = load ptr, ptr %page_slot56, align 8
  %page_mapped58 = icmp ne ptr %page57, null
  br i1 %page_mapped58, label %page_wr_fast52, label %page_wr_slow53, !prof !0

page_wr_fast52:                                   ; preds = %data_aligned51
  %126 = and i32 %sp_dec49, 4095
  %page_offset59 = zext i32 %126 to i64
  %127 = getelementptr i8, ptr %page57, i64 %page_offset59
  store i32 %p, ptr %127, align 4
  br label %page_wr_done54

page_wr_slow53:                                   ; preds = %data_aligned51
  %128 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %129, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec49, i32 %p)
  %130 = getelementptr i8, ptr %cpu, i32 296
  %dj62 = load i8, ptr %130, align 1
  %dj_set63 = icmp ne i8 %dj62, 0
  br i1 %dj_set63, label %did_jump_exit60, label %did_jump_cont61, !prof !1

page_wr_done54:                                   ; preds = %did_jump_cont61, %page_wr_fast52
  %sp_dec64 = sub i32 %sp_dec49, 4
  %131 = getelementptr i8, ptr %cpu, i32 48
  %p65 = load i32, ptr %131, align 4
  %132 = and i32 %sp_dec64, 3
  %133 = icmp ne i32 %132, 0
  br i1 %133, label %data_misaligned66, label %data_aligned67, !prof !1

did_jump_exit60:                                  ; preds = %page_wr_slow53
  %134 = getelementptr i8, ptr %cpu, i64 188
  %next_pc333 = load i32, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i64 188
  %136 = load i32, ptr %135, align 4
  %137 = getelementptr i8, ptr %cpu, i64 296
  %138 = load i8, ptr %137, align 1
  br label %chain_exit

did_jump_cont61:                                  ; preds = %page_wr_slow53
  br label %page_wr_done54

data_misaligned66:                                ; preds = %page_wr_done54
  %139 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %140, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec64, i32 65536)
  %141 = getelementptr i8, ptr %cpu, i64 188
  %next_pc334 = load i32, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i64 188
  %143 = load i32, ptr %142, align 4
  %144 = getelementptr i8, ptr %cpu, i64 296
  %145 = load i8, ptr %144, align 1
  br label %chain_exit

data_aligned67:                                   ; preds = %page_wr_done54
  %146 = lshr i32 %sp_dec64, 12
  %page_index71 = zext i32 %146 to i64
  %page_slot72 = getelementptr ptr, ptr %page_table, i64 %page_index71
  %page73 = load ptr, ptr %page_slot72, align 8
  %page_mapped74 = icmp ne ptr %page73, null
  br i1 %page_mapped74, label %page_wr_fast68, label %page_wr_slow69, !prof !0

page_wr_fast68:                                   ; preds = %data_aligned67
  %147 = and i32 %sp_dec64, 4095
  %page_offset75 = zext i32 %147 to i64
  %148 = getelementptr i8, ptr %page73, i64 %page_offset75
  store i32 %p65, ptr %148, align 4
  br label %page_wr_done70

page_wr_slow69:                                   ; preds = %data_aligned67
  %149 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %150, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec64, i32 %p65)
  %151 = getelementptr i8, ptr %cpu, i32 296
  %dj78 = load i8, ptr %151, align 1
  %dj_set79 = icmp ne i8 %dj78, 0
  br i1 %dj_set79, label %did_jump_exit76, label %did_jump_cont77, !prof !1

page_wr_done70:                                   ; preds = %did_jump_cont77, %page_wr_fast68
  %sp_dec80 = sub i32 %sp_dec64, 4
  %152 = getelementptr i8, ptr %cpu, i32 52
  %p81 = load i32, ptr %152, align 4
  %153 = and i32 %sp_dec80, 3
  %154 = icmp ne i32 %153, 0
  br i1 %154, label %data_misaligned82, label %data_aligned83, !prof !1

did_jump_exit76:                                  ; preds = %page_wr_slow69
  %155 = getelementptr i8, ptr %cpu, i64 188
  %next_pc335 = load i32, ptr %155, align 4
  %156 = getelementptr i8, ptr %cpu, i64 188
  %157 = load i32, ptr %156, align 4
  %158 = getelementptr i8, ptr %cpu, i64 296
  %159 = load i8, ptr %158, align 1
  br label %chain_exit

did_jump_cont77:                                  ; preds = %page_wr_slow69
  br label %page_wr_done70

data_misaligned82:                                ; preds = %page_wr_done70
  %160 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %160, align 4
  %161 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %161, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65556, i32 %sp_dec80, i32 65536)
  %162 = getelementptr i8, ptr %cpu, i64 188
  %next_pc336 = load i32, ptr %162, align 4
  %163 = getelementptr i8, ptr %cpu, i64 188
  %164 = load i32, ptr %163, align 4
  %165 = getelementptr i8, ptr %cpu, i64 296
  %166 = load i8, ptr %165, align 1
  br label %chain_exit

data_aligned83:                                   ; preds = %page_wr_done70
  %167 = lshr i32 %sp_dec80, 12
  %page_index87 = zext i32 %167 to i64
  %page_slot88 = getelementptr ptr, ptr %page_table, i64 %page_index87
  %page89 = load ptr, ptr %page_slot88, align 8
  %page_mapped90 = icmp ne ptr %page89, null
  br i1 %page_mapped90, label %page_wr_fast84, label %page_wr_slow85, !prof !0

page_wr_fast84:                                   ; preds = %data_aligned83
  %168 = and i32 %sp_dec80, 4095
  %page_offset91 = zext i32 %168 to i64
  %169 = getelementptr i8, ptr %page89, i64 %page_offset91
  store i32 %p81, ptr %169, align 4
  br label %page_wr_done86

page_wr_slow85:                                   ; preds = %data_aligned83
  %170 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %171, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec80, i32 %p81)
  %172 = getelementptr i8, ptr %cpu, i32 296
  %dj94 = load i8, ptr %172, align 1
  %dj_set95 = icmp ne i8 %dj94, 0
  br i1 %dj_set95, label %did_jump_exit92, label %did_jump_cont93, !prof !1

page_wr_done86:                                   ; preds = %did_jump_cont93, %page_wr_fast84
  %173 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec80, ptr %173, align 4
  %174 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %174, align 4
  %175 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %175, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %176 = icmp ne i8 %cec_pending, 0
  br i1 %176, label %cec_check, label %cec_checked, !prof !1

did_jump_exit92:                                  ; preds = %page_wr_slow85
  %177 = getelementptr i8, ptr %cpu, i64 188
  %next_pc337 = load i32, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i64 188
  %179 = load i32, ptr %178, align 4
  %180 = getelementptr i8, ptr %cpu, i64 296
  %181 = load i8, ptr %180, align 1
  br label %chain_exit

did_jump_cont93:                                  ; preds = %page_wr_slow85
  br label %page_wr_done86

cec_check:                                        ; preds = %page_wr_done86
  %182 = getelementptr i8, ptr %cpu, i32 188
  store i32 65558, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %184, align 4
  call void @cec_check_pending(ptr %cpu)
  %185 = getelementptr i8, ptr %cpu, i32 296
  %dj98 = load i8, ptr %185, align 1
  %dj_set99 = icmp ne i8 %dj98, 0
  br i1 %dj_set99, label %did_jump_exit96, label %did_jump_cont97, !prof !1

cec_checked:                                      ; preds = %did_jump_cont97, %page_wr_done86
  br label %insn_0x00010016_entry

did_jump_exit96:                                  ; preds = %cec_check
  %186 = getelementptr i8, ptr %cpu, i64 188
  %next_pc338 = load i32, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 188
  %188 = load i32, ptr %187, align 4
  %189 = getelementptr i8, ptr %cpu, i64 296
  %190 = load i8, ptr %189, align 1
  br label %chain_exit

did_jump_cont97:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010016_entry:                            ; preds = %cec_checked
  br label %insn_0x00010016

insn_0x00010016:                                  ; preds = %insn_0x00010016_entry
  %191 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %191, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 0
  %192 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %192, align 4
  br label %insn_0x0001001a_entry

insn_0x0001001a_entry:                            ; preds = %insn_0x00010016
  br label %insn_0x0001001a

insn_0x0001001a:                                  ; preds = %insn_0x0001001a_entry
  %193 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %194, align 4
  %sp1 = sub i32 %sp_dec80, 4
  %195 = and i32 %sp1, 3
  %196 = icmp ne i32 %195, 0
  br i1 %196, label %data_misaligned100, label %data_aligned101, !prof !1

data_misaligned100:                               ; preds = %insn_0x0001001a
  %197 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %199, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65562, i32 %sp1, i32 65536)
  %200 = getelementptr i8, ptr %cpu, i64 188
  %next_pc339 = load i32, ptr %200, align 4
  %201 = getelementptr i8, ptr %cpu, i64 188
  %202 = load i32, ptr %201, align 4
  %203 = getelementptr i8, ptr %cpu, i64 296
  %204 = load i8, ptr %203, align 1
  br label %chain_exit

data_aligned101:                                  ; preds = %insn_0x0001001a
  %205 = lshr i32 %sp1, 12
  %page_index105 = zext i32 %205 to i64
  %page_slot106 = getelementptr ptr, ptr %page_table, i64 %page_index105
  %page107 = load ptr, ptr %page_slot106, align 8
  %page_mapped108 = icmp ne ptr %page107, null
  br i1 %page_mapped108, label %page_wr_fast102, label %page_wr_slow103, !prof !0

page_wr_fast102:                                  ; preds = %data_aligned101
  %206 = and i32 %sp1, 4095
  %page_offset109 = zext i32 %206 to i64
  %207 = getelementptr i8, ptr %page107, i64 %page_offset109
  store i32 %rets, ptr %207, align 4
  br label %page_wr_done104

page_wr_slow103:                                  ; preds = %data_aligned101
  %208 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %208, align 4
  %209 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %210, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %211 = getelementptr i8, ptr %cpu, i32 296
  %dj112 = load i8, ptr %211, align 1
  %dj_set113 = icmp ne i8 %dj112, 0
  br i1 %dj_set113, label %did_jump_exit110, label %did_jump_cont111, !prof !1

page_wr_done104:                                  ; preds = %did_jump_cont111, %page_wr_fast102
  %sp2 = sub i32 %sp1, 4
  %212 = and i32 %sp2, 3
  %213 = icmp ne i32 %212, 0
  br i1 %213, label %data_misaligned114, label %data_aligned115, !prof !1

did_jump_exit110:                                 ; preds = %page_wr_slow103
  %214 = getelementptr i8, ptr %cpu, i64 188
  %next_pc340 = load i32, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i64 188
  %216 = load i32, ptr %215, align 4
  %217 = getelementptr i8, ptr %cpu, i64 296
  %218 = load i8, ptr %217, align 1
  br label %chain_exit

did_jump_cont111:                                 ; preds = %page_wr_slow103
  br label %page_wr_done104

data_misaligned114:                               ; preds = %page_wr_done104
  %219 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %221, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65562, i32 %sp2, i32 65536)
  %222 = getelementptr i8, ptr %cpu, i64 188
  %next_pc341 = load i32, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i64 188
  %224 = load i32, ptr %223, align 4
  %225 = getelementptr i8, ptr %cpu, i64 296
  %226 = load i8, ptr %225, align 1
  br label %chain_exit

data_aligned115:                                  ; preds = %page_wr_done104
  %227 = lshr i32 %sp2, 12
  %page_index119 = zext i32 %227 to i64
  %page_slot120 = getelementptr ptr, ptr %page_table, i64 %page_index119
  %page121 = load ptr, ptr %page_slot120, align 8
  %page_mapped122 = icmp ne ptr %page121, null
  br i1 %page_mapped122, label %page_wr_fast116, label %page_wr_slow117, !prof !0

page_wr_fast116:                                  ; preds = %data_aligned115
  %228 = and i32 %sp2, 4095
  %page_offset123 = zext i32 %228 to i64
  %229 = getelementptr i8, ptr %page121, i64 %page_offset123
  store i32 %fp, ptr %229, align 4
  br label %page_wr_done118

page_wr_slow117:                                  ; preds = %data_aligned115
  %230 = getelementptr i8, ptr %cpu, i32 188
  store i32 65562, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %232, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %233 = getelementptr i8, ptr %cpu, i32 296
  %dj126 = load i8, ptr %233, align 1
  %dj_set127 = icmp ne i8 %dj126, 0
  br i1 %dj_set127, label %did_jump_exit124, label %did_jump_cont125, !prof !1

page_wr_done118:                                  ; preds = %did_jump_cont125, %page_wr_fast116
  %234 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %234, align 4
  %sp3 = sub i32 %sp2, 20
  %235 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %235, align 4
  %cec_pending128 = load i8, ptr %cec_pending_flag, align 1
  %236 = icmp ne i8 %cec_pending128, 0
  br i1 %236, label %cec_check129, label %cec_checked130, !prof !1

did_jump_exit124:                                 ; preds = %page_wr_slow117
  %237 = getelementptr i8, ptr %cpu, i64 188
  %next_pc342 = load i32, ptr %237, align 4
  %238 = getelementptr i8, ptr %cpu, i64 188
  %239 = load i32, ptr %238, align 4
  %240 = getelementptr i8, ptr %cpu, i64 296
  %241 = load i8, ptr %240, align 1
  br label %chain_exit

did_jump_cont125:                                 ; preds = %page_wr_slow117
  br label %page_wr_done118

cec_check129:                                     ; preds = %page_wr_done118
  %242 = getelementptr i8, ptr %cpu, i32 188
  store i32 65566, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %243, align 4
  %244 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %244, align 4
  call void @cec_check_pending(ptr %cpu)
  %245 = getelementptr i8, ptr %cpu, i32 296
  %dj133 = load i8, ptr %245, align 1
  %dj_set134 = icmp ne i8 %dj133, 0
  br i1 %dj_set134, label %did_jump_exit131, label %did_jump_cont132, !prof !1

cec_checked130:                                   ; preds = %did_jump_cont132, %page_wr_done118
  br label %insn_0x0001001e_entry

did_jump_exit131:                                 ; preds = %cec_check129
  %246 = getelementptr i8, ptr %cpu, i64 188
  %next_pc343 = load i32, ptr %246, align 4
  %247 = getelementptr i8, ptr %cpu, i64 188
  %248 = load i32, ptr %247, align 4
  %249 = getelementptr i8, ptr %cpu, i64 296
  %250 = load i8, ptr %249, align 1
  br label %chain_exit

did_jump_cont132:                                 ; preds = %cec_check129
  br label %cec_checked130

insn_0x0001001e_entry:                            ; preds = %cec_checked130
  br label %insn_0x0001001e

insn_0x0001001e:                                  ; preds = %insn_0x0001001e_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 61440
  %251 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %251, align 4
  br label %insn_0x00010022_entry

insn_0x00010022_entry:                            ; preds = %insn_0x0001001e
  br label %insn_0x00010022

insn_0x00010022:                                  ; preds = %insn_0x00010022_entry
  %252 = getelementptr i8, ptr %cpu, i32 4
  %old135 = load i32, ptr %252, align 4
  %lo_kept136 = and i32 %old135, 65535
  %with_hi137 = or i32 %lo_kept136, 1128398848
  %253 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_hi137, ptr %253, align 4
  br label %insn_0x00010026_entry

insn_0x00010026_entry:                            ; preds = %insn_0x00010022
  br label %insn_0x00010026

insn_0x00010026:                                  ; preds = %insn_0x00010026_entry
  %254 = and i32 %with_lo, 3
  %255 = icmp ne i32 %254, 0
  br i1 %255, label %data_misaligned138, label %data_aligned139, !prof !1

data_misaligned138:                               ; preds = %insn_0x00010026
  %256 = getelementptr i8, ptr %cpu, i32 188
  store i32 65574, ptr %256, align 4
  %257 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %257, align 4
  %258 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %258, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65574, i32 %with_lo, i32 0)
  %259 = getelementptr i8, ptr %cpu, i64 188
  %next_pc344 = load i32, ptr %259, align 4
  %260 = getelementptr i8, ptr %cpu, i64 188
  %261 = load i32, ptr %260, align 4
  %262 = getelementptr i8, ptr %cpu, i64 296
  %263 = load i8, ptr %262, align 1
  br label %chain_exit

data_aligned139:                                  ; preds = %insn_0x00010026
  %264 = lshr i32 %with_lo, 12
  %page_index140 = zext i32 %264 to i64
  %page_slot141 = getelementptr ptr, ptr %page_table, i64 %page_index140
  %page142 = load ptr, ptr %page_slot141, align 8
  %page_mapped143 = icmp ne ptr %page142, null
  br i1 %page_mapped143, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned139
  %265 = and i32 %with_lo, 4095
  %page_offset144 = zext i32 %265 to i64
  %266 = getelementptr i8, ptr %page142, i64 %page_offset144
  %page_val = load i32, ptr %266, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned139
  %267 = getelementptr i8, ptr %cpu, i32 188
  store i32 65574, ptr %267, align 4
  %268 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %268, align 4
  %269 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %269, align 4
  %270 = call i32 @mem_read32(ptr %mem, i32 %with_lo)
  %271 = getelementptr i8, ptr %cpu, i32 296
  %dj147 = load i8, ptr %271, align 1
  %dj_set148 = icmp ne i8 %dj147, 0
  br i1 %dj_set148, label %did_jump_exit145, label %did_jump_cont146, !prof !1

page_done:                                        ; preds = %did_jump_cont146, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %270, %did_jump_cont146 ]
  %272 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val, ptr %272, align 4
  br label %insn_0x00010028_entry

did_jump_exit145:                                 ; preds = %page_slow
  %273 = getelementptr i8, ptr %cpu, i64 188
  %next_pc345 = load i32, ptr %273, align 4
  %274 = getelementptr i8, ptr %cpu, i64 188
  %275 = load i32, ptr %274, align 4
  %276 = getelementptr i8, ptr %cpu, i64 296
  %277 = load i8, ptr %276, align 1
  br label %chain_exit

did_jump_cont146:                                 ; preds = %page_slow
  br label %page_done

insn_0x00010028_entry:                            ; preds = %page_done
  br label %insn_0x00010028

insn_0x00010028:                                  ; preds = %insn_0x00010028_entry
  %hi_kept149 = and i32 %with_hi137, -65536
  %with_lo150 = or i32 %hi_kept149, 20017
  %278 = getelementptr i8, ptr %cpu, i32 4
  store i32 %with_lo150, ptr %278, align 4
  br label %insn_0x0001002c_entry

insn_0x0001002c_entry:                            ; preds = %insn_0x00010028
  br label %insn_0x0001002c

insn_0x0001002c:                                  ; preds = %insn_0x0001002c_entry
  %diff = sub i32 %mem_val, %with_lo150
  %279 = icmp eq i32 %diff, 0
  %az = zext i1 %279 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %mem_val, 31
  %flgo = lshr i32 %with_lo150, 31
  %280 = xor i32 %flgn, %flgs
  %281 = xor i32 %flgs, %flgo
  %overflow = and i32 %281, %280
  %an = xor i32 %flgn, %overflow
  %282 = icmp ule i32 %with_lo150, %mem_val
  %ac0 = zext i1 %282 to i32
  %283 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %283, align 4
  %284 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %284, align 4
  %285 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %285, align 4
  %286 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %286, align 4
  %287 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %287, align 4
  br label %insn_0x0001002e_entry

insn_0x0001002e_entry:                            ; preds = %insn_0x0001002c
  br label %insn_0x0001002e

insn_0x0001002e:                                  ; preds = %insn_0x0001002e_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x0001002e
  %288 = getelementptr i8, ptr %cpu, i32 188
  store i32 65600, ptr %288, align 4
  %289 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %289, align 4
  %chain_total = add nuw i32 %chain_packets, 9
  %290 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %290 monotonic, align 4, !range !2
  %291 = icmp ult i32 %chain_total, %chain_budget
  br i1 %291, label %chain_go, label %chain_leave346, !prof !0

brt_fallthru:                                     ; preds = %insn_0x0001002e
  br label %insn_0x00010030_entry

insn_0x00010030_entry:                            ; preds = %brt_fallthru
  br label %insn_0x00010030

insn_0x00010030:                                  ; preds = %insn_0x00010030_entry
  %292 = getelementptr i8, ptr %cpu, i32 0
  store i32 3, ptr %292, align 4
  br label %insn_0x00010032_entry

insn_0x00010032_entry:                            ; preds = %insn_0x00010030
  br label %insn_0x00010032

insn_0x00010032:                                  ; preds = %insn_0x00010032_entry
  %pd_add = add i32 %with_lo, 16
  %293 = getelementptr i8, ptr %cpu, i32 40
  store i32 %pd_add, ptr %293, align 4
  br label %insn_0x00010034_entry

insn_0x00010034_entry:                            ; preds = %insn_0x00010032
  br label %insn_0x00010034

insn_0x00010034:                                  ; preds = %insn_0x00010034_entry
  %294 = and i32 %pd_add, 3
  %295 = icmp ne i32 %294, 0
  br i1 %295, label %data_misaligned151, label %data_aligned152, !prof !1

data_misaligned151:                               ; preds = %insn_0x00010034
  %296 = getelementptr i8, ptr %cpu, i32 188
  store i32 65588, ptr %296, align 4
  %297 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %297, align 4
  %298 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %298, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65588, i32 %pd_add, i32 65536)
  %299 = getelementptr i8, ptr %cpu, i64 188
  %next_pc347 = load i32, ptr %299, align 4
  %300 = getelementptr i8, ptr %cpu, i64 188
  %301 = load i32, ptr %300, align 4
  %302 = getelementptr i8, ptr %cpu, i64 296
  %303 = load i8, ptr %302, align 1
  br label %chain_exit

data_aligned152:                                  ; preds = %insn_0x00010034
  %304 = lshr i32 %pd_add, 12
  %page_index156 = zext i32 %304 to i64
  %page_slot157 = getelementptr ptr, ptr %page_table, i64 %page_index156
  %page158 = load ptr, ptr %page_slot157, align 8
  %page_mapped159 = icmp ne ptr %page158, null
  br i1 %page_mapped159, label %page_wr_fast153, label %page_wr_slow154, !prof !0

page_wr_fast153:                                  ; preds = %data_aligned152
  %305 = and i32 %pd_add, 4095
  %page_offset160 = zext i32 %305 to i64
  %306 = getelementptr i8, ptr %page158, i64 %page_offset160
  store i32 3, ptr %306, align 4
  br label %page_wr_done155

page_wr_slow154:                                  ; preds = %data_aligned152
  %307 = getelementptr i8, ptr %cpu, i32 188
  store i32 65588, ptr %307, align 4
  %308 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %308, align 4
  %309 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %309, align 4
  call void @mem_write32(ptr %mem, i32 %pd_add, i32 3)
  %310 = getelementptr i8, ptr %cpu, i32 296
  %dj163 = load i8, ptr %310, align 1
  %dj_set164 = icmp ne i8 %dj163, 0
  br i1 %dj_set164, label %did_jump_exit161, label %did_jump_cont162, !prof !1

page_wr_done155:                                  ; preds = %did_jump_cont162, %page_wr_fast153
  %cec_pending165 = load i8, ptr %cec_pending_flag, align 1
  %311 = icmp ne i8 %cec_pending165, 0
  br i1 %311, label %cec_check166, label %cec_checked167, !prof !1

did_jump_exit161:                                 ; preds = %page_wr_slow154
  %312 = getelementptr i8, ptr %cpu, i64 188
  %next_pc348 = load i32, ptr %312, align 4
  %313 = getelementptr i8, ptr %cpu, i64 188
  %314 = load i32, ptr %313, align 4
  %315 = getelementptr i8, ptr %cpu, i64 296
  %316 = load i8, ptr %315, align 1
  br label %chain_exit

did_jump_cont162:                                 ; preds = %page_wr_slow154
  br label %page_wr_done155

cec_check166:                                     ; preds = %page_wr_done155
  %317 = getelementptr i8, ptr %cpu, i32 188
  store i32 65590, ptr %317, align 4
  %318 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %318, align 4
  %319 = getelementptr i8, ptr %cpu, i32 308
  store i32 12, ptr %319, align 4
  call void @cec_check_pending(ptr %cpu)
  %320 = getelementptr i8, ptr %cpu, i32 296
  %dj170 = load i8, ptr %320, align 1
  %dj_set171 = icmp ne i8 %dj170, 0
  br i1 %dj_set171, label %did_jump_exit168, label %did_jump_cont169, !prof !1

cec_checked167:                                   ; preds = %did_jump_cont169, %page_wr_done155
  br label %insn_0x00010036_entry

did_jump_exit168:                                 ; preds = %cec_check166
  %321 = getelementptr i8, ptr %cpu, i64 188
  %next_pc349 = load i32, ptr %321, align 4
  %322 = getelementptr i8, ptr %cpu, i64 188
  %323 = load i32, ptr %322, align 4
  %324 = getelementptr i8, ptr %cpu, i64 296
  %325 = load i8, ptr %324, align 1
  br label %chain_exit

did_jump_cont169:                                 ; preds = %cec_check166
  br label %cec_checked167

insn_0x00010036_entry:                            ; preds = %cec_checked167
  br label %insn_0x00010036

insn_0x00010036:                                  ; preds = %insn_0x00010036_entry
  %326 = getelementptr i8, ptr %cpu, i32 0
  store i32 1, ptr %326, align 4
  br label %insn_0x00010038_entry

insn_0x00010038_entry:                            ; preds = %insn_0x00010036
  br label %insn_0x00010038

insn_0x00010038:                                  ; preds = %insn_0x00010038_entry
  %327 = and i32 %sp2, 3
  %328 = icmp ne i32 %327, 0
  br i1 %328, label %data_misaligned172, label %data_aligned173, !prof !1

data_misaligned172:                               ; preds = %insn_0x00010038
  %329 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %329, align 4
  %330 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %330, align 4
  %331 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %331, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65592, i32 %sp2, i32 0)
  %332 = getelementptr i8, ptr %cpu, i64 188
  %next_pc350 = load i32, ptr %332, align 4
  %333 = getelementptr i8, ptr %cpu, i64 188
  %334 = load i32, ptr %333, align 4
  %335 = getelementptr i8, ptr %cpu, i64 296
  %336 = load i8, ptr %335, align 1
  br label %chain_exit

data_aligned173:                                  ; preds = %insn_0x00010038
  %337 = lshr i32 %sp2, 12
  %page_index177 = zext i32 %337 to i64
  %page_slot178 = getelementptr ptr, ptr %page_table, i64 %page_index177
  %page179 = load ptr, ptr %page_slot178, align 8
  %page_mapped180 = icmp ne ptr %page179, null
  br i1 %page_mapped180, label %page_fast174, label %page_slow175, !prof !0

page_fast174:                                     ; preds = %data_aligned173
  %338 = and i32 %sp2, 4095
  %page_offset181 = zext i32 %338 to i64
  %339 = getelementptr i8, ptr %page179, i64 %page_offset181
  %page_val182 = load i32, ptr %339, align 4
  br label %page_done176

page_slow175:                                     ; preds = %data_aligned173
  %340 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %340, align 4
  %341 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %341, align 4
  %342 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %342, align 4
  %343 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %344 = getelementptr i8, ptr %cpu, i32 296
  %dj185 = load i8, ptr %344, align 1
  %dj_set186 = icmp ne i8 %dj185, 0
  br i1 %dj_set186, label %did_jump_exit183, label %did_jump_cont184, !prof !1

page_done176:                                     ; preds = %did_jump_cont184, %page_fast174
  %mem_val187 = phi i32 [ %page_val182, %page_fast174 ], [ %343, %did_jump_cont184 ]
  %sp1188 = add i32 %sp2, 4
  %345 = and i32 %sp1188, 3
  %346 = icmp ne i32 %345, 0
  br i1 %346, label %data_misaligned189, label %data_aligned190, !prof !1

did_jump_exit183:                                 ; preds = %page_slow175
  %347 = getelementptr i8, ptr %cpu, i64 188
  %next_pc351 = load i32, ptr %347, align 4
  %348 = getelementptr i8, ptr %cpu, i64 188
  %349 = load i32, ptr %348, align 4
  %350 = getelementptr i8, ptr %cpu, i64 296
  %351 = load i8, ptr %350, align 1
  br label %chain_exit

did_jump_cont184:                                 ; preds = %page_slow175
  br label %page_done176

data_misaligned189:                               ; preds = %page_done176
  %352 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %352, align 4
  %353 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %353, align 4
  %354 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %354, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65592, i32 %sp1188, i32 0)
  %355 = getelementptr i8, ptr %cpu, i64 188
  %next_pc352 = load i32, ptr %355, align 4
  %356 = getelementptr i8, ptr %cpu, i64 188
  %357 = load i32, ptr %356, align 4
  %358 = getelementptr i8, ptr %cpu, i64 296
  %359 = load i8, ptr %358, align 1
  br label %chain_exit

data_aligned190:                                  ; preds = %page_done176
  %360 = lshr i32 %sp1188, 12
  %page_index194 = zext i32 %360 to i64
  %page_slot195 = getelementptr ptr, ptr %page_table, i64 %page_index194
  %page196 = load ptr, ptr %page_slot195, align 8
  %page_mapped197 = icmp ne ptr %page196, null
  br i1 %page_mapped197, label %page_fast191, label %page_slow192, !prof !0

page_fast191:                                     ; preds = %data_aligned190
  %361 = and i32 %sp1188, 4095
  %page_offset198 = zext i32 %361 to i64
  %362 = getelementptr i8, ptr %page196, i64 %page_offset198
  %page_val199 = load i32, ptr %362, align 4
  br label %page_done193

page_slow192:                                     ; preds = %data_aligned190
  %363 = getelementptr i8, ptr %cpu, i32 188
  store i32 65592, ptr %363, align 4
  %364 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %364, align 4
  %365 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %365, align 4
  %366 = call i32 @mem_read32(ptr %mem, i32 %sp1188)
  %367 = getelementptr i8, ptr %cpu, i32 296
  %dj202 = load i8, ptr %367, align 1
  %dj_set203 = icmp ne i8 %dj202, 0
  br i1 %dj_set203, label %did_jump_exit200, label %did_jump_cont201, !prof !1

page_done193:                                     ; preds = %did_jump_cont201, %page_fast191
  %mem_val204 = phi i32 [ %page_val199, %page_fast191 ], [ %366, %did_jump_cont201 ]
  %sp2205 = add i32 %sp1188, 4
  %368 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val187, ptr %368, align 4
  %369 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val204, ptr %369, align 4
  %370 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2205, ptr %370, align 4
  br label %insn_0x0001003c_entry

did_jump_exit200:                                 ; preds = %page_slow192
  %371 = getelementptr i8, ptr %cpu, i64 188
  %next_pc353 = load i32, ptr %371, align 4
  %372 = getelementptr i8, ptr %cpu, i64 188
  %373 = load i32, ptr %372, align 4
  %374 = getelementptr i8, ptr %cpu, i64 296
  %375 = load i8, ptr %374, align 1
  br label %chain_exit

did_jump_cont201:                                 ; preds = %page_slow192
  br label %page_done193

insn_0x0001003c_entry:                            ; preds = %page_done193
  br label %insn_0x0001003c

insn_0x0001003c:                                  ; preds = %insn_0x0001003c_entry
  %376 = and i32 %sp2205, 3
  %377 = icmp ne i32 %376, 0
  br i1 %377, label %data_misaligned206, label %data_aligned207, !prof !1

data_misaligned206:                               ; preds = %insn_0x0001003c
  %378 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %378, align 4
  %379 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %379, align 4
  %380 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %380, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp2205, i32 0)
  %381 = getelementptr i8, ptr %cpu, i64 188
  %next_pc354 = load i32, ptr %381, align 4
  %382 = getelementptr i8, ptr %cpu, i64 188
  %383 = load i32, ptr %382, align 4
  %384 = getelementptr i8, ptr %cpu, i64 296
  %385 = load i8, ptr %384, align 1
  br label %chain_exit

data_aligned207:                                  ; preds = %insn_0x0001003c
  %386 = lshr i32 %sp2205, 12
  %page_index211 = zext i32 %386 to i64
  %page_slot212 = getelementptr ptr, ptr %page_table, i64 %page_index211
  %page213 = load ptr, ptr %page_slot212, align 8
  %page_mapped214 = icmp ne ptr %page213, null
  br i1 %page_mapped214, label %page_fast208, label %page_slow209, !prof !0

page_fast208:                                     ; preds = %data_aligned207
  %387 = and i32 %sp2205, 4095
  %page_offset215 = zext i32 %387 to i64
  %388 = getelementptr i8, ptr %page213, i64 %page_offset215
  %page_val216 = load i32, ptr %388, align 4
  br label %page_done210

page_slow209:                                     ; preds = %data_aligned207
  %389 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %389, align 4
  %390 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %390, align 4
  %391 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %391, align 4
  %392 = call i32 @mem_read32(ptr %mem, i32 %sp2205)
  %393 = getelementptr i8, ptr %cpu, i32 296
  %dj219 = load i8, ptr %393, align 1
  %dj_set220 = icmp ne i8 %dj219, 0
  br i1 %dj_set220, label %did_jump_exit217, label %did_jump_cont218, !prof !1

page_done210:                                     ; preds = %did_jump_cont218, %page_fast208
  %mem_val221 = phi i32 [ %page_val216, %page_fast208 ], [ %392, %did_jump_cont218 ]
  %394 = getelementptr i8, ptr %cpu, i32 52
  store i32 %mem_val221, ptr %394, align 4
  %sp_inc = add i32 %sp2205, 4
  %395 = and i32 %sp_inc, 3
  %396 = icmp ne i32 %395, 0
  br i1 %396, label %data_misaligned222, label %data_aligned223, !prof !1

did_jump_exit217:                                 ; preds = %page_slow209
  %397 = getelementptr i8, ptr %cpu, i64 188
  %next_pc355 = load i32, ptr %397, align 4
  %398 = getelementptr i8, ptr %cpu, i64 188
  %399 = load i32, ptr %398, align 4
  %400 = getelementptr i8, ptr %cpu, i64 296
  %401 = load i8, ptr %400, align 1
  br label %chain_exit

did_jump_cont218:                                 ; preds = %page_slow209
  br label %page_done210

data_misaligned222:                               ; preds = %page_done210
  %402 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %402, align 4
  %403 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %403, align 4
  %404 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %404, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc, i32 0)
  %405 = getelementptr i8, ptr %cpu, i64 188
  %next_pc356 = load i32, ptr %405, align 4
  %406 = getelementptr i8, ptr %cpu, i64 188
  %407 = load i32, ptr %406, align 4
  %408 = getelementptr i8, ptr %cpu, i64 296
  %409 = load i8, ptr %408, align 1
  br label %chain_exit

data_aligned223:                                  ; preds = %page_done210
  %410 = lshr i32 %sp_inc, 12
  %page_index227 = zext i32 %410 to i64
  %page_slot228 = getelementptr ptr, ptr %page_table, i64 %page_index227
  %page229 = load ptr, ptr %page_slot228, align 8
  %page_mapped230 = icmp ne ptr %page229, null
  br i1 %page_mapped230, label %page_fast224, label %page_slow225, !prof !0

page_fast224:                                     ; preds = %data_aligned223
  %411 = and i32 %sp_inc, 4095
  %page_offset231 = zext i32 %411 to i64
  %412 = getelementptr i8, ptr %page229, i64 %page_offset231
  %page_val232 = load i32, ptr %412, align 4
  br label %page_done226

page_slow225:                                     ; preds = %data_aligned223
  %413 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %413, align 4
  %414 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %414, align 4
  %415 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %415, align 4
  %416 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %417 = getelementptr i8, ptr %cpu, i32 296
  %dj235 = load i8, ptr %417, align 1
  %dj_set236 = icmp ne i8 %dj235, 0
  br i1 %dj_set236, label %did_jump_exit233, label %did_jump_cont234, !prof !1

page_done226:                                     ; preds = %did_jump_cont234, %page_fast224
  %mem_val237 = phi i32 [ %page_val232, %page_fast224 ], [ %416, %did_jump_cont234 ]
  %418 = getelementptr i8, ptr %cpu, i32 48
  store i32 %mem_val237, ptr %418, align 4
  %sp_inc238 = add i32 %sp_inc, 4
  %419 = and i32 %sp_inc238, 3
  %420 = icmp ne i32 %419, 0
  br i1 %420, label %data_misaligned239, label %data_aligned240, !prof !1

did_jump_exit233:                                 ; preds = %page_slow225
  %421 = getelementptr i8, ptr %cpu, i64 188
  %next_pc357 = load i32, ptr %421, align 4
  %422 = getelementptr i8, ptr %cpu, i64 188
  %423 = load i32, ptr %422, align 4
  %424 = getelementptr i8, ptr %cpu, i64 296
  %425 = load i8, ptr %424, align 1
  br label %chain_exit

did_jump_cont234:                                 ; preds = %page_slow225
  br label %page_done226

data_misaligned239:                               ; preds = %page_done226
  %426 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %426, align 4
  %427 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %427, align 4
  %428 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %428, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc238, i32 0)
  %429 = getelementptr i8, ptr %cpu, i64 188
  %next_pc358 = load i32, ptr %429, align 4
  %430 = getelementptr i8, ptr %cpu, i64 188
  %431 = load i32, ptr %430, align 4
  %432 = getelementptr i8, ptr %cpu, i64 296
  %433 = load i8, ptr %432, align 1
  br label %chain_exit

data_aligned240:                                  ; preds = %page_done226
  %434 = lshr i32 %sp_inc238, 12
  %page_index244 = zext i32 %434 to i64
  %page_slot245 = getelementptr ptr, ptr %page_table, i64 %page_index244
  %page246 = load ptr, ptr %page_slot245, align 8
  %page_mapped247 = icmp ne ptr %page246, null
  br i1 %page_mapped247, label %page_fast241, label %page_slow242, !prof !0

page_fast241:                                     ; preds = %data_aligned240
  %435 = and i32 %sp_inc238, 4095
  %page_offset248 = zext i32 %435 to i64
  %436 = getelementptr i8, ptr %page246, i64 %page_offset248
  %page_val249 = load i32, ptr %436, align 4
  br label %page_done243

page_slow242:                                     ; preds = %data_aligned240
  %437 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %437, align 4
  %438 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %438, align 4
  %439 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %439, align 4
  %440 = call i32 @mem_read32(ptr %mem, i32 %sp_inc238)
  %441 = getelementptr i8, ptr %cpu, i32 296
  %dj252 = load i8, ptr %441, align 1
  %dj_set253 = icmp ne i8 %dj252, 0
  br i1 %dj_set253, label %did_jump_exit250, label %did_jump_cont251, !prof !1

page_done243:                                     ; preds = %did_jump_cont251, %page_fast241
  %mem_val254 = phi i32 [ %page_val249, %page_fast241 ], [ %440, %did_jump_cont251 ]
  %442 = getelementptr i8, ptr %cpu, i32 44
  store i32 %mem_val254, ptr %442, align 4
  %sp_inc255 = add i32 %sp_inc238, 4
  %443 = and i32 %sp_inc255, 3
  %444 = icmp ne i32 %443, 0
  br i1 %444, label %data_misaligned256, label %data_aligned257, !prof !1

did_jump_exit250:                                 ; preds = %page_slow242
  %445 = getelementptr i8, ptr %cpu, i64 188
  %next_pc359 = load i32, ptr %445, align 4
  %446 = getelementptr i8, ptr %cpu, i64 188
  %447 = load i32, ptr %446, align 4
  %448 = getelementptr i8, ptr %cpu, i64 296
  %449 = load i8, ptr %448, align 1
  br label %chain_exit

did_jump_cont251:                                 ; preds = %page_slow242
  br label %page_done243

data_misaligned256:                               ; preds = %page_done243
  %450 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %450, align 4
  %451 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %451, align 4
  %452 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %452, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc255, i32 0)
  %453 = getelementptr i8, ptr %cpu, i64 188
  %next_pc360 = load i32, ptr %453, align 4
  %454 = getelementptr i8, ptr %cpu, i64 188
  %455 = load i32, ptr %454, align 4
  %456 = getelementptr i8, ptr %cpu, i64 296
  %457 = load i8, ptr %456, align 1
  br label %chain_exit

data_aligned257:                                  ; preds = %page_done243
  %458 = lshr i32 %sp_inc255, 12
  %page_index261 = zext i32 %458 to i64
  %page_slot262 = getelementptr ptr, ptr %page_table, i64 %page_index261
  %page263 = load ptr, ptr %page_slot262, align 8
  %page_mapped264 = icmp ne ptr %page263, null
  br i1 %page_mapped264, label %page_fast258, label %page_slow259, !prof !0

page_fast258:                                     ; preds = %data_aligned257
  %459 = and i32 %sp_inc255, 4095
  %page_offset265 = zext i32 %459 to i64
  %460 = getelementptr i8, ptr %page263, i64 %page_offset265
  %page_val266 = load i32, ptr %460, align 4
  br label %page_done260

page_slow259:                                     ; preds = %data_aligned257
  %461 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %461, align 4
  %462 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %462, align 4
  %463 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %463, align 4
  %464 = call i32 @mem_read32(ptr %mem, i32 %sp_inc255)
  %465 = getelementptr i8, ptr %cpu, i32 296
  %dj269 = load i8, ptr %465, align 1
  %dj_set270 = icmp ne i8 %dj269, 0
  br i1 %dj_set270, label %did_jump_exit267, label %did_jump_cont268, !prof !1

page_done260:                                     ; preds = %did_jump_cont268, %page_fast258
  %mem_val271 = phi i32 [ %page_val266, %page_fast258 ], [ %464, %did_jump_cont268 ]
  %466 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val271, ptr %466, align 4
  %sp_inc272 = add i32 %sp_inc255, 4
  %467 = and i32 %sp_inc272, 3
  %468 = icmp ne i32 %467, 0
  br i1 %468, label %data_misaligned273, label %data_aligned274, !prof !1

did_jump_exit267:                                 ; preds = %page_slow259
  %469 = getelementptr i8, ptr %cpu, i64 188
  %next_pc361 = load i32, ptr %469, align 4
  %470 = getelementptr i8, ptr %cpu, i64 188
  %471 = load i32, ptr %470, align 4
  %472 = getelementptr i8, ptr %cpu, i64 296
  %473 = load i8, ptr %472, align 1
  br label %chain_exit

did_jump_cont268:                                 ; preds = %page_slow259
  br label %page_done260

data_misaligned273:                               ; preds = %page_done260
  %474 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %474, align 4
  %475 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %475, align 4
  %476 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %476, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc272, i32 0)
  %477 = getelementptr i8, ptr %cpu, i64 188
  %next_pc362 = load i32, ptr %477, align 4
  %478 = getelementptr i8, ptr %cpu, i64 188
  %479 = load i32, ptr %478, align 4
  %480 = getelementptr i8, ptr %cpu, i64 296
  %481 = load i8, ptr %480, align 1
  br label %chain_exit

data_aligned274:                                  ; preds = %page_done260
  %482 = lshr i32 %sp_inc272, 12
  %page_index278 = zext i32 %482 to i64
  %page_slot279 = getelementptr ptr, ptr %page_table, i64 %page_index278
  %page280 = load ptr, ptr %page_slot279, align 8
  %page_mapped281 = icmp ne ptr %page280, null
  br i1 %page_mapped281, label %page_fast275, label %page_slow276, !prof !0

page_fast275:                                     ; preds = %data_aligned274
  %483 = and i32 %sp_inc272, 4095
  %page_offset282 = zext i32 %483 to i64
  %484 = getelementptr i8, ptr %page280, i64 %page_offset282
  %page_val283 = load i32, ptr %484, align 4
  br label %page_done277

page_slow276:                                     ; preds = %data_aligned274
  %485 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %485, align 4
  %486 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %486, align 4
  %487 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %487, align 4
  %488 = call i32 @mem_read32(ptr %mem, i32 %sp_inc272)
  %489 = getelementptr i8, ptr %cpu, i32 296
  %dj286 = load i8, ptr %489, align 1
  %dj_set287 = icmp ne i8 %dj286, 0
  br i1 %dj_set287, label %did_jump_exit284, label %did_jump_cont285, !prof !1

page_done277:                                     ; preds = %did_jump_cont285, %page_fast275
  %mem_val288 = phi i32 [ %page_val283, %page_fast275 ], [ %488, %did_jump_cont285 ]
  %490 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val288, ptr %490, align 4
  %sp_inc289 = add i32 %sp_inc272, 4
  %491 = and i32 %sp_inc289, 3
  %492 = icmp ne i32 %491, 0
  br i1 %492, label %data_misaligned290, label %data_aligned291, !prof !1

did_jump_exit284:                                 ; preds = %page_slow276
  %493 = getelementptr i8, ptr %cpu, i64 188
  %next_pc363 = load i32, ptr %493, align 4
  %494 = getelementptr i8, ptr %cpu, i64 188
  %495 = load i32, ptr %494, align 4
  %496 = getelementptr i8, ptr %cpu, i64 296
  %497 = load i8, ptr %496, align 1
  br label %chain_exit

did_jump_cont285:                                 ; preds = %page_slow276
  br label %page_done277

data_misaligned290:                               ; preds = %page_done277
  %498 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %498, align 4
  %499 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %499, align 4
  %500 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %500, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc289, i32 0)
  %501 = getelementptr i8, ptr %cpu, i64 188
  %next_pc364 = load i32, ptr %501, align 4
  %502 = getelementptr i8, ptr %cpu, i64 188
  %503 = load i32, ptr %502, align 4
  %504 = getelementptr i8, ptr %cpu, i64 296
  %505 = load i8, ptr %504, align 1
  br label %chain_exit

data_aligned291:                                  ; preds = %page_done277
  %506 = lshr i32 %sp_inc289, 12
  %page_index295 = zext i32 %506 to i64
  %page_slot296 = getelementptr ptr, ptr %page_table, i64 %page_index295
  %page297 = load ptr, ptr %page_slot296, align 8
  %page_mapped298 = icmp ne ptr %page297, null
  br i1 %page_mapped298, label %page_fast292, label %page_slow293, !prof !0

page_fast292:                                     ; preds = %data_aligned291
  %507 = and i32 %sp_inc289, 4095
  %page_offset299 = zext i32 %507 to i64
  %508 = getelementptr i8, ptr %page297, i64 %page_offset299
  %page_val300 = load i32, ptr %508, align 4
  br label %page_done294

page_slow293:                                     ; preds = %data_aligned291
  %509 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %509, align 4
  %510 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %510, align 4
  %511 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %511, align 4
  %512 = call i32 @mem_read32(ptr %mem, i32 %sp_inc289)
  %513 = getelementptr i8, ptr %cpu, i32 296
  %dj303 = load i8, ptr %513, align 1
  %dj_set304 = icmp ne i8 %dj303, 0
  br i1 %dj_set304, label %did_jump_exit301, label %did_jump_cont302, !prof !1

page_done294:                                     ; preds = %did_jump_cont302, %page_fast292
  %mem_val305 = phi i32 [ %page_val300, %page_fast292 ], [ %512, %did_jump_cont302 ]
  %514 = getelementptr i8, ptr %cpu, i32 20
  store i32 %mem_val305, ptr %514, align 4
  %sp_inc306 = add i32 %sp_inc289, 4
  %515 = and i32 %sp_inc306, 3
  %516 = icmp ne i32 %515, 0
  br i1 %516, label %data_misaligned307, label %data_aligned308, !prof !1

did_jump_exit301:                                 ; preds = %page_slow293
  %517 = getelementptr i8, ptr %cpu, i64 188
  %next_pc365 = load i32, ptr %517, align 4
  %518 = getelementptr i8, ptr %cpu, i64 188
  %519 = load i32, ptr %518, align 4
  %520 = getelementptr i8, ptr %cpu, i64 296
  %521 = load i8, ptr %520, align 1
  br label %chain_exit

did_jump_cont302:                                 ; preds = %page_slow293
  br label %page_done294

data_misaligned307:                               ; preds = %page_done294
  %522 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %522, align 4
  %523 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %523, align 4
  %524 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %524, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65596, i32 %sp_inc306, i32 0)
  %525 = getelementptr i8, ptr %cpu, i64 188
  %next_pc366 = load i32, ptr %525, align 4
  %526 = getelementptr i8, ptr %cpu, i64 188
  %527 = load i32, ptr %526, align 4
  %528 = getelementptr i8, ptr %cpu, i64 296
  %529 = load i8, ptr %528, align 1
  br label %chain_exit

data_aligned308:                                  ; preds = %page_done294
  %530 = lshr i32 %sp_inc306, 12
  %page_index312 = zext i32 %530 to i64
  %page_slot313 = getelementptr ptr, ptr %page_table, i64 %page_index312
  %page314 = load ptr, ptr %page_slot313, align 8
  %page_mapped315 = icmp ne ptr %page314, null
  br i1 %page_mapped315, label %page_fast309, label %page_slow310, !prof !0

page_fast309:                                     ; preds = %data_aligned308
  %531 = and i32 %sp_inc306, 4095
  %page_offset316 = zext i32 %531 to i64
  %532 = getelementptr i8, ptr %page314, i64 %page_offset316
  %page_val317 = load i32, ptr %532, align 4
  br label %page_done311

page_slow310:                                     ; preds = %data_aligned308
  %533 = getelementptr i8, ptr %cpu, i32 188
  store i32 65596, ptr %533, align 4
  %534 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %534, align 4
  %535 = getelementptr i8, ptr %cpu, i32 308
  store i32 15, ptr %535, align 4
  %536 = call i32 @mem_read32(ptr %mem, i32 %sp_inc306)
  %537 = getelementptr i8, ptr %cpu, i32 296
  %dj320 = load i8, ptr %537, align 1
  %dj_set321 = icmp ne i8 %dj320, 0
  br i1 %dj_set321, label %did_jump_exit318, label %did_jump_cont319, !prof !1

page_done311:                                     ; preds = %did_jump_cont319, %page_fast309
  %mem_val322 = phi i32 [ %page_val317, %page_fast309 ], [ %536, %did_jump_cont319 ]
  %538 = getelementptr i8, ptr %cpu, i32 16
  store i32 %mem_val322, ptr %538, align 4
  %sp_inc323 = add i32 %sp_inc306, 4
  %539 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc323, ptr %539, align 4
  br label %insn_0x0001003e_entry

did_jump_exit318:                                 ; preds = %page_slow310
  %540 = getelementptr i8, ptr %cpu, i64 188
  %next_pc367 = load i32, ptr %540, align 4
  %541 = getelementptr i8, ptr %cpu, i64 188
  %542 = load i32, ptr %541, align 4
  %543 = getelementptr i8, ptr %cpu, i64 296
  %544 = load i8, ptr %543, align 1
  br label %chain_exit

did_jump_cont319:                                 ; preds = %page_slow310
  br label %page_done311

insn_0x0001003e_entry:                            ; preds = %page_done311
  br label %insn_0x0001003e

insn_0x0001003e:                                  ; preds = %insn_0x0001003e_entry
  %lsb = and i32 %mem_val204, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001003e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001003e
  %545 = getelementptr i8, ptr %cpu, i32 188
  store i32 65598, ptr %545, align 4
  %546 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %546, align 4
  %547 = getelementptr i8, ptr %cpu, i32 308
  store i32 16, ptr %547, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %548 = getelementptr i8, ptr %cpu, i64 188
  %next_pc368 = load i32, ptr %548, align 4
  %549 = getelementptr i8, ptr %cpu, i64 188
  %550 = load i32, ptr %549, align 4
  %551 = getelementptr i8, ptr %cpu, i64 296
  %552 = load i8, ptr %551, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %553 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %553, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 524800
  %554 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %554, align 4
  %555 = icmp eq i32 %slot_pc, 65600
  br i1 %555, label %chain_hit, label %chain_leave346, !prof !0

chain_leave346:                                   ; preds = %chain_go, %brt_taken
  %556 = getelementptr i8, ptr %cpu, i64 188
  store i32 65600, ptr %556, align 4
  %557 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %557, align 4
  %558 = getelementptr i8, ptr %cpu, i64 308
  store i32 9, ptr %558, align 4
  %559 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %559, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %560 = getelementptr i8, ptr %cpu, i64 188
  store i32 65600, ptr %560, align 4
  %561 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %561, align 4
  %562 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %562, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit318, %data_misaligned307, %did_jump_exit301, %data_misaligned290, %did_jump_exit284, %data_misaligned273, %did_jump_exit267, %data_misaligned256, %did_jump_exit250, %data_misaligned239, %did_jump_exit233, %data_misaligned222, %did_jump_exit217, %data_misaligned206, %did_jump_exit200, %data_misaligned189, %did_jump_exit183, %data_misaligned172, %did_jump_exit168, %did_jump_exit161, %data_misaligned151, %did_jump_exit145, %data_misaligned138, %did_jump_exit131, %did_jump_exit124, %data_misaligned114, %did_jump_exit110, %data_misaligned100, %did_jump_exit96, %did_jump_exit92, %data_misaligned82, %did_jump_exit76, %data_misaligned66, %did_jump_exit60, %data_misaligned50, %did_jump_exit45, %data_misaligned35, %did_jump_exit29, %data_misaligned19, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc369 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc325, %did_jump_exit ], [ %next_pc326, %data_misaligned3 ], [ %next_pc327, %did_jump_exit13 ], [ %next_pc328, %data_misaligned19 ], [ %next_pc329, %did_jump_exit29 ], [ %next_pc330, %data_misaligned35 ], [ %next_pc331, %did_jump_exit45 ], [ %next_pc332, %data_misaligned50 ], [ %next_pc333, %did_jump_exit60 ], [ %next_pc334, %data_misaligned66 ], [ %next_pc335, %did_jump_exit76 ], [ %next_pc336, %data_misaligned82 ], [ %next_pc337, %did_jump_exit92 ], [ %next_pc338, %did_jump_exit96 ], [ %next_pc339, %data_misaligned100 ], [ %next_pc340, %did_jump_exit110 ], [ %next_pc341, %data_misaligned114 ], [ %next_pc342, %did_jump_exit124 ], [ %next_pc343, %did_jump_exit131 ], [ %next_pc344, %data_misaligned138 ], [ %next_pc345, %did_jump_exit145 ], [ %next_pc347, %data_misaligned151 ], [ %next_pc348, %did_jump_exit161 ], [ %next_pc349, %did_jump_exit168 ], [ %next_pc350, %data_misaligned172 ], [ %next_pc351, %did_jump_exit183 ], [ %next_pc352, %data_misaligned189 ], [ %next_pc353, %did_jump_exit200 ], [ %next_pc354, %data_misaligned206 ], [ %next_pc355, %did_jump_exit217 ], [ %next_pc356, %data_misaligned222 ], [ %next_pc357, %did_jump_exit233 ], [ %next_pc358, %data_misaligned239 ], [ %next_pc359, %did_jump_exit250 ], [ %next_pc360, %data_misaligned256 ], [ %next_pc361, %did_jump_exit267 ], [ %next_pc362, %data_misaligned273 ], [ %next_pc363, %did_jump_exit284 ], [ %next_pc364, %data_misaligned290 ], [ %next_pc365, %did_jump_exit301 ], [ %next_pc366, %data_misaligned307 ], [ %next_pc367, %did_jump_exit318 ], [ %mem_val204, %jump_aligned ], [ %next_pc368, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %data_misaligned66 ], [ 1, %did_jump_exit76 ], [ 1, %data_misaligned82 ], [ 1, %did_jump_exit92 ], [ 1, %did_jump_exit96 ], [ 3, %data_misaligned100 ], [ 3, %did_jump_exit110 ], [ 3, %data_misaligned114 ], [ 3, %did_jump_exit124 ], [ 3, %did_jump_exit131 ], [ 6, %data_misaligned138 ], [ 6, %did_jump_exit145 ], [ 12, %data_misaligned151 ], [ 12, %did_jump_exit161 ], [ 12, %did_jump_exit168 ], [ 14, %data_misaligned172 ], [ 14, %did_jump_exit183 ], [ 14, %data_misaligned189 ], [ 14, %did_jump_exit200 ], [ 15, %data_misaligned206 ], [ 15, %did_jump_exit217 ], [ 15, %data_misaligned222 ], [ 15, %did_jump_exit233 ], [ 15, %data_misaligned239 ], [ 15, %did_jump_exit250 ], [ 15, %data_misaligned256 ], [ 15, %did_jump_exit267 ], [ 15, %data_misaligned273 ], [ 15, %did_jump_exit284 ], [ 15, %data_misaligned290 ], [ 15, %did_jump_exit301 ], [ 15, %data_misaligned307 ], [ 15, %did_jump_exit318 ], [ 16, %jump_aligned ], [ 16, %jump_misalign ]
  %tail = phi i32 [ %38, %data_misaligned ], [ %52, %did_jump_exit ], [ %59, %data_misaligned3 ], [ %73, %did_jump_exit13 ], [ %80, %data_misaligned19 ], [ %94, %did_jump_exit29 ], [ %101, %data_misaligned35 ], [ %115, %did_jump_exit45 ], [ %122, %data_misaligned50 ], [ %136, %did_jump_exit60 ], [ %143, %data_misaligned66 ], [ %157, %did_jump_exit76 ], [ %164, %data_misaligned82 ], [ %179, %did_jump_exit92 ], [ %188, %did_jump_exit96 ], [ %202, %data_misaligned100 ], [ %216, %did_jump_exit110 ], [ %224, %data_misaligned114 ], [ %239, %did_jump_exit124 ], [ %248, %did_jump_exit131 ], [ %261, %data_misaligned138 ], [ %275, %did_jump_exit145 ], [ %301, %data_misaligned151 ], [ %314, %did_jump_exit161 ], [ %323, %did_jump_exit168 ], [ %334, %data_misaligned172 ], [ %349, %did_jump_exit183 ], [ %357, %data_misaligned189 ], [ %373, %did_jump_exit200 ], [ %383, %data_misaligned206 ], [ %399, %did_jump_exit217 ], [ %407, %data_misaligned222 ], [ %423, %did_jump_exit233 ], [ %431, %data_misaligned239 ], [ %447, %did_jump_exit250 ], [ %455, %data_misaligned256 ], [ %471, %did_jump_exit267 ], [ %479, %data_misaligned273 ], [ %495, %did_jump_exit284 ], [ %503, %data_misaligned290 ], [ %519, %did_jump_exit301 ], [ %527, %data_misaligned307 ], [ %542, %did_jump_exit318 ], [ %mem_val204, %jump_aligned ], [ %550, %jump_misalign ]
  %tail370 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %data_misaligned19 ], [ 2, %did_jump_exit29 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %data_misaligned50 ], [ 2, %did_jump_exit60 ], [ 2, %data_misaligned66 ], [ 2, %did_jump_exit76 ], [ 2, %data_misaligned82 ], [ 2, %did_jump_exit92 ], [ 2, %did_jump_exit96 ], [ 4, %data_misaligned100 ], [ 4, %did_jump_exit110 ], [ 4, %data_misaligned114 ], [ 4, %did_jump_exit124 ], [ 4, %did_jump_exit131 ], [ 2, %data_misaligned138 ], [ 2, %did_jump_exit145 ], [ 2, %data_misaligned151 ], [ 2, %did_jump_exit161 ], [ 2, %did_jump_exit168 ], [ 4, %data_misaligned172 ], [ 4, %did_jump_exit183 ], [ 4, %data_misaligned189 ], [ 4, %did_jump_exit200 ], [ 2, %data_misaligned206 ], [ 2, %did_jump_exit217 ], [ 2, %data_misaligned222 ], [ 2, %did_jump_exit233 ], [ 2, %data_misaligned239 ], [ 2, %did_jump_exit250 ], [ 2, %data_misaligned256 ], [ 2, %did_jump_exit267 ], [ 2, %data_misaligned273 ], [ 2, %did_jump_exit284 ], [ 2, %data_misaligned290 ], [ 2, %did_jump_exit301 ], [ 2, %data_misaligned307 ], [ 2, %did_jump_exit318 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail371 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %data_misaligned19 ], [ 1, %did_jump_exit29 ], [ 1, %data_misaligned35 ], [ 1, %did_jump_exit45 ], [ 1, %data_misaligned50 ], [ 1, %did_jump_exit60 ], [ 1, %data_misaligned66 ], [ 1, %did_jump_exit76 ], [ 1, %data_misaligned82 ], [ 1, %did_jump_exit92 ], [ 1, %did_jump_exit96 ], [ 3, %data_misaligned100 ], [ 3, %did_jump_exit110 ], [ 3, %data_misaligned114 ], [ 3, %did_jump_exit124 ], [ 3, %did_jump_exit131 ], [ 6, %data_misaligned138 ], [ 6, %did_jump_exit145 ], [ 12, %data_misaligned151 ], [ 12, %did_jump_exit161 ], [ 12, %did_jump_exit168 ], [ 14, %data_misaligned172 ], [ 14, %did_jump_exit183 ], [ 14, %data_misaligned189 ], [ 14, %did_jump_exit200 ], [ 15, %data_misaligned206 ], [ 15, %did_jump_exit217 ], [ 15, %data_misaligned222 ], [ 15, %did_jump_exit233 ], [ 15, %data_misaligned239 ], [ 15, %did_jump_exit250 ], [ 15, %data_misaligned256 ], [ 15, %did_jump_exit267 ], [ 15, %data_misaligned273 ], [ 15, %did_jump_exit284 ], [ 15, %data_misaligned290 ], [ 15, %did_jump_exit301 ], [ 15, %data_misaligned307 ], [ 15, %did_jump_exit318 ], [ 16, %jump_aligned ], [ 16, %jump_misalign ]
  %tail372 = phi i8 [ %40, %data_misaligned ], [ %54, %did_jump_exit ], [ %61, %data_misaligned3 ], [ %75, %did_jump_exit13 ], [ %82, %data_misaligned19 ], [ %96, %did_jump_exit29 ], [ %103, %data_misaligned35 ], [ %117, %did_jump_exit45 ], [ %124, %data_misaligned50 ], [ %138, %did_jump_exit60 ], [ %145, %data_misaligned66 ], [ %159, %did_jump_exit76 ], [ %166, %data_misaligned82 ], [ %181, %did_jump_exit92 ], [ %190, %did_jump_exit96 ], [ %204, %data_misaligned100 ], [ %218, %did_jump_exit110 ], [ %226, %data_misaligned114 ], [ %241, %did_jump_exit124 ], [ %250, %did_jump_exit131 ], [ %263, %data_misaligned138 ], [ %277, %did_jump_exit145 ], [ %303, %data_misaligned151 ], [ %316, %did_jump_exit161 ], [ %325, %did_jump_exit168 ], [ %336, %data_misaligned172 ], [ %351, %did_jump_exit183 ], [ %359, %data_misaligned189 ], [ %375, %did_jump_exit200 ], [ %385, %data_misaligned206 ], [ %401, %did_jump_exit217 ], [ %409, %data_misaligned222 ], [ %425, %did_jump_exit233 ], [ %433, %data_misaligned239 ], [ %449, %did_jump_exit250 ], [ %457, %data_misaligned256 ], [ %473, %did_jump_exit267 ], [ %481, %data_misaligned273 ], [ %497, %did_jump_exit284 ], [ %505, %data_misaligned290 ], [ %521, %did_jump_exit301 ], [ %529, %data_misaligned307 ], [ %544, %did_jump_exit318 ], [ 1, %jump_aligned ], [ %552, %jump_misalign ]
  %563 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets374 = load i32, ptr %563, align 4
  %chain_total375 = add nuw i32 %chain_packets374, %packets
  %564 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget376 = load atomic i32, ptr %564 monotonic, align 4, !range !2
  %565 = icmp ult i32 %chain_total375, %chain_budget376
  br i1 %565, label %chain_lookup, label %chain_leave373, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %566 = lshr i32 %next_pc369, 1
  %567 = and i32 %566, 65535
  %568 = zext i32 %567 to i64
  %569 = mul i64 %568, 16
  %chain_slot377 = getelementptr i8, ptr %chain_table, i64 %569
  %570 = getelementptr i8, ptr %chain_slot377, i64 0
  %slot_pc378 = load i32, ptr %570, align 4
  %571 = icmp eq i32 %slot_pc378, %next_pc369
  br i1 %571, label %chain_hit379, label %chain_leave373, !prof !0

chain_leave373:                                   ; preds = %chain_lookup, %chain_exit
  %572 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %572, align 4
  %573 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail370, ptr %573, align 4
  %574 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail371, ptr %574, align 4
  %575 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail372, ptr %575, align 1
  br label %return

chain_hit379:                                     ; preds = %chain_lookup
  %576 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc369, ptr %576, align 4
  %577 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total375, ptr %577, align 4
  %578 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %578, align 1
  %579 = getelementptr i8, ptr %chain_slot377, i64 8
  %chain_fn380 = load ptr, ptr %579, align 8
  musttail call swifttailcc void %chain_fn380(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave373, %chain_leave346, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
