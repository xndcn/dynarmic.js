
build-native-instruction-analysis/capture/bcore-default-branch/pc-65910-0-126700950180224.bin:     file format binary


Disassembly of section .data:

0000733bdd20d180 <.data>:
    733bdd20d180:	45 8b 95 a0 00 00 00 	mov    r10d,DWORD PTR [r13+0xa0]
    733bdd20d187:	41 8d 82 77 fe fe ff 	lea    eax,[r10-0x10189]
    733bdd20d18e:	83 f8 ec             	cmp    eax,0xffffffec
    733bdd20d191:	0f 87 e8 31 ff 17    	ja     0x733bf520037f
    733bdd20d197:	45 8b 85 a4 00 00 00 	mov    r8d,DWORD PTR [r13+0xa4]
    733bdd20d19e:	41 8d 80 77 fe fe ff 	lea    eax,[r8-0x10189]
    733bdd20d1a5:	83 f8 ec             	cmp    eax,0xffffffec
    733bdd20d1a8:	0f 87 d1 31 ff 17    	ja     0x733bf520037f
    733bdd20d1ae:	4d 8b 8d 50 01 00 00 	mov    r9,QWORD PTR [r13+0x150]
    733bdd20d1b5:	41 8b 7d 14          	mov    edi,DWORD PTR [r13+0x14]
    733bdd20d1b9:	41 8b 75 18          	mov    esi,DWORD PTR [r13+0x18]
    733bdd20d1bd:	8d 5e 01             	lea    ebx,[rsi+0x1]
    733bdd20d1c0:	41 89 5d 18          	mov    DWORD PTR [r13+0x18],ebx
    733bdd20d1c4:	c1 ee 1f             	shr    esi,0x1f
    733bdd20d1c7:	89 dd                	mov    ebp,ebx
    733bdd20d1c9:	c1 ed 1f             	shr    ebp,0x1f
    733bdd20d1cc:	c4 e2 48 f2 ed       	andn   ebp,esi,ebp
    733bdd20d1d1:	41 8b b5 00 01 00 00 	mov    esi,DWORD PTR [r13+0x100]
    733bdd20d1d8:	09 ee                	or     esi,ebp
    733bdd20d1da:	41 89 ad f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ebp
    733bdd20d1e1:	41 89 ad fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ebp
    733bdd20d1e8:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    733bdd20d1ef:	31 ed                	xor    ebp,ebp
    733bdd20d1f1:	31 c9                	xor    ecx,ecx
    733bdd20d1f3:	31 c0                	xor    eax,eax
    733bdd20d1f5:	31 d2                	xor    edx,edx
    733bdd20d1f7:	39 fb                	cmp    ebx,edi
    733bdd20d1f9:	40 0f 97 c5          	seta   bpl
    733bdd20d1fd:	0f 96 c1             	setbe  cl
    733bdd20d200:	0f 93 c0             	setae  al
    733bdd20d203:	41 89 85 14 01 00 00 	mov    DWORD PTR [r13+0x114],eax
    733bdd20d20a:	0f 94 c2             	sete   dl
    733bdd20d20d:	41 89 95 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],edx
    733bdd20d214:	41 89 ad e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ebp
    733bdd20d21b:	41 89 8d ec 00 00 00 	mov    DWORD PTR [r13+0xec],ecx
    733bdd20d222:	41 89 8d f0 00 00 00 	mov    DWORD PTR [r13+0xf0],ecx
    733bdd20d229:	72 50                	jb     0x733bdd20d27b
    733bdd20d22b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    733bdd20d232:	92 01 01 00 
    733bdd20d236:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20d23d:	83 c1 03             	add    ecx,0x3
    733bdd20d240:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    733bdd20d247:	39 c1                	cmp    ecx,eax
    733bdd20d249:	0f 83 3b 31 ff 17    	jae    0x733bf520038a
    733bdd20d24f:	41 81 b9 90 0c 08 00 	cmp    DWORD PTR [r9+0x80c90],0x10192
    733bdd20d256:	92 01 01 00 
    733bdd20d25a:	0f 85 2a 31 ff 17    	jne    0x733bf520038a
    733bdd20d260:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    733bdd20d267:	92 01 01 00 
    733bdd20d26b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20d272:	49 8b 81 98 0c 08 00 	mov    rax,QWORD PTR [r9+0x80c98]
    733bdd20d279:	ff e0                	jmp    rax
    733bdd20d27b:	41 8b 45 1c          	mov    eax,DWORD PTR [r13+0x1c]
    733bdd20d27f:	41 8b 4d 34          	mov    ecx,DWORD PTR [r13+0x34]
    733bdd20d283:	41 0f af 45 10       	imul   eax,DWORD PTR [r13+0x10]
    733bdd20d288:	41 89 4d 04          	mov    DWORD PTR [r13+0x4],ecx
    733bdd20d28c:	8d 3c 08             	lea    edi,[rax+rcx*1]
    733bdd20d28f:	41 89 7d 1c          	mov    DWORD PTR [r13+0x1c],edi
    733bdd20d293:	c1 e8 1f             	shr    eax,0x1f
    733bdd20d296:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20d299:	89 fa                	mov    edx,edi
    733bdd20d29b:	c1 ea 1f             	shr    edx,0x1f
    733bdd20d29e:	31 d1                	xor    ecx,edx
    733bdd20d2a0:	31 d0                	xor    eax,edx
    733bdd20d2a2:	21 c8                	and    eax,ecx
    733bdd20d2a4:	09 c6                	or     esi,eax
    733bdd20d2a6:	31 c9                	xor    ecx,ecx
    733bdd20d2a8:	85 ff                	test   edi,edi
    733bdd20d2aa:	0f 94 c1             	sete   cl
    733bdd20d2ad:	41 89 85 f8 00 00 00 	mov    DWORD PTR [r13+0xf8],eax
    733bdd20d2b4:	41 89 85 fc 00 00 00 	mov    DWORD PTR [r13+0xfc],eax
    733bdd20d2bb:	41 89 b5 00 01 00 00 	mov    DWORD PTR [r13+0x100],esi
    733bdd20d2c2:	41 89 95 14 01 00 00 	mov    DWORD PTR [r13+0x114],edx
    733bdd20d2c9:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    733bdd20d2d0:	41 89 95 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edx
    733bdd20d2d7:	48 b8 01 00 00 00 01 	movabs rax,0x100000001
    733bdd20d2de:	00 00 00 
    733bdd20d2e1:	49 89 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],rax
    733bdd20d2e8:	78 50                	js     0x733bdd20d33a
    733bdd20d2ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd20d2f1:	70 01 01 00 
    733bdd20d2f5:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20d2fc:	83 c1 08             	add    ecx,0x8
    733bdd20d2ff:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    733bdd20d306:	39 c1                	cmp    ecx,eax
    733bdd20d308:	0f 83 a8 30 ff 17    	jae    0x733bf52003b6
    733bdd20d30e:	41 81 b9 80 0b 08 00 	cmp    DWORD PTR [r9+0x80b80],0x10170
    733bdd20d315:	70 01 01 00 
    733bdd20d319:	0f 85 97 30 ff 17    	jne    0x733bf52003b6
    733bdd20d31f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd20d326:	70 01 01 00 
    733bdd20d32a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20d331:	49 8b 81 88 0b 08 00 	mov    rax,QWORD PTR [r9+0x80b88]
    733bdd20d338:	ff e0                	jmp    rax
    733bdd20d33a:	31 c0                	xor    eax,eax
    733bdd20d33c:	41 33 7d 00          	xor    edi,DWORD PTR [r13+0x0]
    733bdd20d340:	41 89 7d 00          	mov    DWORD PTR [r13+0x0],edi
    733bdd20d344:	0f 94 c0             	sete   al
    733bdd20d347:	c1 ef 1f             	shr    edi,0x1f
    733bdd20d34a:	41 89 85 e4 00 00 00 	mov    DWORD PTR [r13+0xe4],eax
    733bdd20d351:	41 89 bd e8 00 00 00 	mov    DWORD PTR [r13+0xe8],edi
    733bdd20d358:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    733bdd20d35f:	00 00 00 00 
    733bdd20d363:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    733bdd20d36a:	00 00 00 00 
    733bdd20d36e:	be 8c 01 01 00       	mov    esi,0x1018c
    733bdd20d373:	bf 8c 01 01 00       	mov    edi,0x1018c
    733bdd20d378:	41 81 fa 88 01 01 00 	cmp    r10d,0x10188
    733bdd20d37f:	75 07                	jne    0x733bdd20d388
    733bdd20d381:	41 8b bd 90 00 00 00 	mov    edi,DWORD PTR [r13+0x90]
    733bdd20d388:	41 8b 95 9c 00 00 00 	mov    edx,DWORD PTR [r13+0x9c]
    733bdd20d38f:	41 83 bd 98 00 00 00 	cmp    DWORD PTR [r13+0x98],0x2
    733bdd20d396:	02 
    733bdd20d397:	0f 43 f7             	cmovae esi,edi
    733bdd20d39a:	89 f7                	mov    edi,esi
    733bdd20d39c:	41 81 f8 88 01 01 00 	cmp    r8d,0x10188
    733bdd20d3a3:	75 07                	jne    0x733bdd20d3ac
    733bdd20d3a5:	41 8b bd 94 00 00 00 	mov    edi,DWORD PTR [r13+0x94]
    733bdd20d3ac:	83 fa 02             	cmp    edx,0x2
    733bdd20d3af:	0f 43 f7             	cmovae esi,edi
    733bdd20d3b2:	41 89 b5 a8 00 00 00 	mov    DWORD PTR [r13+0xa8],esi
    733bdd20d3b9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd20d3c0:	10 01 01 00 
    733bdd20d3c4:	41 8b 8d 5c 01 00 00 	mov    ecx,DWORD PTR [r13+0x15c]
    733bdd20d3cb:	83 c1 0a             	add    ecx,0xa
    733bdd20d3ce:	41 8b 85 58 01 00 00 	mov    eax,DWORD PTR [r13+0x158]
    733bdd20d3d5:	39 c1                	cmp    ecx,eax
    733bdd20d3d7:	0f 83 05 30 ff 17    	jae    0x733bf52003e2
    733bdd20d3dd:	41 81 b9 80 08 08 00 	cmp    DWORD PTR [r9+0x80880],0x10110
    733bdd20d3e4:	10 01 01 00 
    733bdd20d3e8:	0f 85 f4 2f ff 17    	jne    0x733bf52003e2
    733bdd20d3ee:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd20d3f5:	10 01 01 00 
    733bdd20d3f9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20d400:	49 8b 81 88 08 08 00 	mov    rax,QWORD PTR [r9+0x80888]
    733bdd20d407:	ff e0                	jmp    rax
