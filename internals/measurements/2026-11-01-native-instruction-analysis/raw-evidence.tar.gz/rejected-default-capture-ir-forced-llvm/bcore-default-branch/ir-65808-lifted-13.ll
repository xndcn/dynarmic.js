; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010110(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65808
  %6 = icmp ugt i32 %5, 30
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb50 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb50, 0
  %11 = sub i32 %guard_lb50, 65808
  %12 = icmp ugt i32 %11, 30
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x00010110_entry, label %lb_guard_miss, !prof !0

insn_0x00010110_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table65 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table65, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 52
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 30000
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x00010110_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 13, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x00010110_entry, %28
  br label %insn_0x00010110

insn_0x00010110:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 0
  %rs = load i32, ptr %30, align 4
  %lsr32 = lshr i32 %rs, 7
  %31 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr32, ptr %31, align 4
  %32 = icmp eq i32 %lsr32, 0
  %az = zext i1 %32 to i32
  %an = lshr i32 %lsr32, 31
  %33 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %38, align 4
  br label %insn_0x00010114_entry

insn_0x00010114_entry:                            ; preds = %insn_0x00010110
  br label %insn_0x00010114

insn_0x00010114:                                  ; preds = %insn_0x00010114_entry
  %xor32 = xor i32 %rs, %lsr32
  %39 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %39, align 4
  %40 = icmp eq i32 %xor32, 0
  %az1 = zext i1 %40 to i32
  %an2 = lshr i32 %xor32, 31
  %41 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %46, align 4
  br label %insn_0x00010116_entry

insn_0x00010116_entry:                            ; preds = %insn_0x00010114
  br label %insn_0x00010116

insn_0x00010116:                                  ; preds = %insn_0x00010116_entry
  %47 = getelementptr i8, ptr %cpu, i32 40
  store i32 %xor32, ptr %47, align 4
  br label %insn_0x00010118_entry

insn_0x00010118_entry:                            ; preds = %insn_0x00010116
  br label %insn_0x00010118

insn_0x00010118:                                  ; preds = %insn_0x00010118_entry
  %48 = getelementptr i8, ptr %cpu, i32 36
  %old = load i32, ptr %48, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, -1640562688
  %49 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_hi, ptr %49, align 4
  br label %insn_0x0001011c_entry

insn_0x0001011c_entry:                            ; preds = %insn_0x00010118
  br label %insn_0x0001011c

insn_0x0001011c:                                  ; preds = %insn_0x0001011c_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 31161
  %50 = getelementptr i8, ptr %cpu, i32 36
  store i32 %with_lo, ptr %50, align 4
  br label %insn_0x00010120_entry

insn_0x00010120_entry:                            ; preds = %insn_0x0001011c
  br label %insn_0x00010120

insn_0x00010120:                                  ; preds = %insn_0x00010120_entry
  %51 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %53, align 4
  %sp1 = sub i32 %sp, 4
  %54 = and i32 %sp1, 3
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010120
  %56 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %58, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65824, i32 %sp1, i32 65536)
  %59 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i64 188
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %cpu, i64 296
  %63 = load i8, ptr %62, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010120
  %64 = lshr i32 %sp1, 12
  %page_index = zext i32 %64 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %65 = and i32 %sp1, 4095
  %page_offset = zext i32 %65 to i64
  %66 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %rets, ptr %66, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %67 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %69, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %70 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %70, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp2 = sub i32 %sp1, 4
  %71 = and i32 %sp2, 3
  %72 = icmp ne i32 %71, 0
  br i1 %72, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %73 = getelementptr i8, ptr %cpu, i64 188
  %next_pc51 = load i32, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i64 188
  %75 = load i32, ptr %74, align 4
  %76 = getelementptr i8, ptr %cpu, i64 296
  %77 = load i8, ptr %76, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %78 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %80, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65824, i32 %sp2, i32 65536)
  %81 = getelementptr i8, ptr %cpu, i64 188
  %next_pc52 = load i32, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 188
  %83 = load i32, ptr %82, align 4
  %84 = getelementptr i8, ptr %cpu, i64 296
  %85 = load i8, ptr %84, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %86 = lshr i32 %sp2, 12
  %page_index8 = zext i32 %86 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %87 = and i32 %sp2, 4095
  %page_offset12 = zext i32 %87 to i64
  %88 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %fp, ptr %88, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %89 = getelementptr i8, ptr %cpu, i32 188
  store i32 65824, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %91, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %92 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %92, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %93 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %93, align 4
  %sp3 = sub i32 %sp2, 0
  %94 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %94, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %95 = icmp ne i8 %cec_pending, 0
  br i1 %95, label %cec_check, label %cec_checked, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %96 = getelementptr i8, ptr %cpu, i64 188
  %next_pc53 = load i32, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 188
  %98 = load i32, ptr %97, align 4
  %99 = getelementptr i8, ptr %cpu, i64 296
  %100 = load i8, ptr %99, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

cec_check:                                        ; preds = %page_wr_done7
  %101 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %103, align 4
  call void @cec_check_pending(ptr %cpu)
  %104 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %104, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

cec_checked:                                      ; preds = %did_jump_cont18, %page_wr_done7
  br label %insn_0x00010124_entry

did_jump_exit17:                                  ; preds = %cec_check
  %105 = getelementptr i8, ptr %cpu, i64 188
  %next_pc54 = load i32, ptr %105, align 4
  %106 = getelementptr i8, ptr %cpu, i64 188
  %107 = load i32, ptr %106, align 4
  %108 = getelementptr i8, ptr %cpu, i64 296
  %109 = load i8, ptr %108, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x00010124_entry:                            ; preds = %cec_checked
  br label %insn_0x00010124

insn_0x00010124:                                  ; preds = %insn_0x00010124_entry
  %110 = and i32 %sp2, 3
  %111 = icmp ne i32 %110, 0
  br i1 %111, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x00010124
  %112 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %114, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65828, i32 %sp2, i32 0)
  %115 = getelementptr i8, ptr %cpu, i64 188
  %next_pc55 = load i32, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 188
  %117 = load i32, ptr %116, align 4
  %118 = getelementptr i8, ptr %cpu, i64 296
  %119 = load i8, ptr %118, align 1
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x00010124
  %120 = lshr i32 %sp2, 12
  %page_index23 = zext i32 %120 to i64
  %page_slot24 = getelementptr ptr, ptr %page_table, i64 %page_index23
  %page25 = load ptr, ptr %page_slot24, align 8
  %page_mapped26 = icmp ne ptr %page25, null
  br i1 %page_mapped26, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned22
  %121 = and i32 %sp2, 4095
  %page_offset27 = zext i32 %121 to i64
  %122 = getelementptr i8, ptr %page25, i64 %page_offset27
  %page_val = load i32, ptr %122, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned22
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %125, align 4
  %126 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %127 = getelementptr i8, ptr %cpu, i32 296
  %dj30 = load i8, ptr %127, align 1
  %dj_set31 = icmp ne i8 %dj30, 0
  br i1 %dj_set31, label %did_jump_exit28, label %did_jump_cont29, !prof !1

page_done:                                        ; preds = %did_jump_cont29, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %126, %did_jump_cont29 ]
  %sp132 = add i32 %sp2, 4
  %128 = and i32 %sp132, 3
  %129 = icmp ne i32 %128, 0
  br i1 %129, label %data_misaligned33, label %data_aligned34, !prof !1

did_jump_exit28:                                  ; preds = %page_slow
  %130 = getelementptr i8, ptr %cpu, i64 188
  %next_pc56 = load i32, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 188
  %132 = load i32, ptr %131, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  %134 = load i8, ptr %133, align 1
  br label %chain_exit

did_jump_cont29:                                  ; preds = %page_slow
  br label %page_done

data_misaligned33:                                ; preds = %page_done
  %135 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %137, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65828, i32 %sp132, i32 0)
  %138 = getelementptr i8, ptr %cpu, i64 188
  %next_pc57 = load i32, ptr %138, align 4
  %139 = getelementptr i8, ptr %cpu, i64 188
  %140 = load i32, ptr %139, align 4
  %141 = getelementptr i8, ptr %cpu, i64 296
  %142 = load i8, ptr %141, align 1
  br label %chain_exit

data_aligned34:                                   ; preds = %page_done
  %143 = lshr i32 %sp132, 12
  %page_index38 = zext i32 %143 to i64
  %page_slot39 = getelementptr ptr, ptr %page_table, i64 %page_index38
  %page40 = load ptr, ptr %page_slot39, align 8
  %page_mapped41 = icmp ne ptr %page40, null
  br i1 %page_mapped41, label %page_fast35, label %page_slow36, !prof !0

page_fast35:                                      ; preds = %data_aligned34
  %144 = and i32 %sp132, 4095
  %page_offset42 = zext i32 %144 to i64
  %145 = getelementptr i8, ptr %page40, i64 %page_offset42
  %page_val43 = load i32, ptr %145, align 4
  br label %page_done37

page_slow36:                                      ; preds = %data_aligned34
  %146 = getelementptr i8, ptr %cpu, i32 188
  store i32 65828, ptr %146, align 4
  %147 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %147, align 4
  %148 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %148, align 4
  %149 = call i32 @mem_read32(ptr %mem, i32 %sp132)
  %150 = getelementptr i8, ptr %cpu, i32 296
  %dj46 = load i8, ptr %150, align 1
  %dj_set47 = icmp ne i8 %dj46, 0
  br i1 %dj_set47, label %did_jump_exit44, label %did_jump_cont45, !prof !1

page_done37:                                      ; preds = %did_jump_cont45, %page_fast35
  %mem_val48 = phi i32 [ %page_val43, %page_fast35 ], [ %149, %did_jump_cont45 ]
  %sp249 = add i32 %sp132, 4
  %151 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val48, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp249, ptr %153, align 4
  br label %insn_0x00010128_entry

did_jump_exit44:                                  ; preds = %page_slow36
  %154 = getelementptr i8, ptr %cpu, i64 188
  %next_pc58 = load i32, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 188
  %156 = load i32, ptr %155, align 4
  %157 = getelementptr i8, ptr %cpu, i64 296
  %158 = load i8, ptr %157, align 1
  br label %chain_exit

did_jump_cont45:                                  ; preds = %page_slow36
  br label %page_done37

insn_0x00010128_entry:                            ; preds = %page_done37
  br label %insn_0x00010128

insn_0x00010128:                                  ; preds = %insn_0x00010128_entry
  %159 = shl i32 %xor32, 1
  %plshift1 = add i32 %xor32, %159
  %160 = getelementptr i8, ptr %cpu, i32 40
  store i32 %plshift1, ptr %160, align 4
  br label %insn_0x0001012a_entry

insn_0x0001012a_entry:                            ; preds = %insn_0x00010128
  br label %insn_0x0001012a

insn_0x0001012a:                                  ; preds = %insn_0x0001012a_entry
  %padd = add i32 %plshift1, %with_lo
  %161 = getelementptr i8, ptr %cpu, i32 36
  store i32 %padd, ptr %161, align 4
  br label %insn_0x0001012c_entry

insn_0x0001012c_entry:                            ; preds = %insn_0x0001012a
  br label %insn_0x0001012c

insn_0x0001012c:                                  ; preds = %insn_0x0001012c_entry
  %162 = getelementptr i8, ptr %cpu, i32 0
  store i32 %padd, ptr %162, align 4
  br label %insn_0x0001012e_entry

insn_0x0001012e_entry:                            ; preds = %insn_0x0001012c
  br label %insn_0x0001012e

insn_0x0001012e:                                  ; preds = %insn_0x0001012e_entry
  %lsb = and i32 %mem_val48, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001012e
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001012e
  %163 = getelementptr i8, ptr %cpu, i32 188
  store i32 65838, ptr %163, align 4
  %164 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %164, align 4
  %165 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %165, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %166 = getelementptr i8, ptr %cpu, i64 188
  %next_pc59 = load i32, ptr %166, align 4
  %167 = getelementptr i8, ptr %cpu, i64 188
  %168 = load i32, ptr %167, align 4
  %169 = getelementptr i8, ptr %cpu, i64 296
  %170 = load i8, ptr %169, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %171 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %171, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit44, %data_misaligned33, %did_jump_exit28, %data_misaligned21, %did_jump_exit17, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc60 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc51, %did_jump_exit ], [ %next_pc52, %data_misaligned3 ], [ %next_pc53, %did_jump_exit13 ], [ %next_pc54, %did_jump_exit17 ], [ %next_pc55, %data_misaligned21 ], [ %next_pc56, %did_jump_exit28 ], [ %next_pc57, %data_misaligned33 ], [ %next_pc58, %did_jump_exit44 ], [ %mem_val48, %jump_aligned ], [ %next_pc59, %jump_misalign ]
  %packets = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 6, %data_misaligned3 ], [ 6, %did_jump_exit13 ], [ 6, %did_jump_exit17 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit28 ], [ 7, %data_misaligned33 ], [ 7, %did_jump_exit44 ], [ 11, %jump_aligned ], [ 11, %jump_misalign ]
  %tail = phi i32 [ %61, %data_misaligned ], [ %75, %did_jump_exit ], [ %83, %data_misaligned3 ], [ %98, %did_jump_exit13 ], [ %107, %did_jump_exit17 ], [ %117, %data_misaligned21 ], [ %132, %did_jump_exit28 ], [ %140, %data_misaligned33 ], [ %156, %did_jump_exit44 ], [ %mem_val48, %jump_aligned ], [ %168, %jump_misalign ]
  %tail61 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned3 ], [ 4, %did_jump_exit13 ], [ 4, %did_jump_exit17 ], [ 4, %data_misaligned21 ], [ 4, %did_jump_exit28 ], [ 4, %data_misaligned33 ], [ 4, %did_jump_exit44 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail62 = phi i32 [ 6, %data_misaligned ], [ 6, %did_jump_exit ], [ 6, %data_misaligned3 ], [ 6, %did_jump_exit13 ], [ 6, %did_jump_exit17 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit28 ], [ 7, %data_misaligned33 ], [ 7, %did_jump_exit44 ], [ 11, %jump_aligned ], [ 11, %jump_misalign ]
  %tail63 = phi i8 [ %63, %data_misaligned ], [ %77, %did_jump_exit ], [ %85, %data_misaligned3 ], [ %100, %did_jump_exit13 ], [ %109, %did_jump_exit17 ], [ %119, %data_misaligned21 ], [ %134, %did_jump_exit28 ], [ %142, %data_misaligned33 ], [ %158, %did_jump_exit44 ], [ 1, %jump_aligned ], [ %170, %jump_misalign ]
  %172 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %172, align 4
  %chain_total = add nuw i32 %chain_packets, %packets
  %173 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %173 monotonic, align 4, !range !2
  %174 = icmp ult i32 %chain_total, %chain_budget
  br i1 %174, label %chain_lookup, label %chain_leave64, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %175 = lshr i32 %next_pc60, 1
  %176 = and i32 %175, 65535
  %177 = zext i32 %176 to i64
  %178 = mul i64 %177, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %178
  %179 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %179, align 4
  %180 = icmp eq i32 %slot_pc, %next_pc60
  br i1 %180, label %chain_hit, label %chain_leave64, !prof !0

chain_leave64:                                    ; preds = %chain_lookup, %chain_exit
  %181 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %181, align 4
  %182 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail61, ptr %182, align 4
  %183 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail62, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail63, ptr %184, align 1
  br label %return

chain_hit:                                        ; preds = %chain_lookup
  %185 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc60, ptr %185, align 4
  %186 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %187, align 1
  %188 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %188, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave64, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
