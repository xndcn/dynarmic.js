
build-native-instruction-analysis/capture/bcore-default-branch/pc-65932-0-126700950174864.bin:     file format binary


Disassembly of section .data:

0000733bdd20bc90 <.data>:
    733bdd20bc90:	48 81 ec 18 01 00 00 	sub    rsp,0x118
    733bdd20bc97:	4c 89 b4 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r14
    733bdd20bc9e:	00 
    733bdd20bc9f:	4c 89 ac 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r13
    733bdd20bca6:	00 
    733bdd20bca7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20bcae:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    733bdd20bcb5:	00 
    733bdd20bcb6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20bcbd:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    733bdd20bcc4:	00 
    733bdd20bcc5:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20bccc:	00 
    733bdd20bccd:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20bcd3:	83 fa 00             	cmp    edx,0x0
    733bdd20bcd6:	0f 94 c0             	sete   al
    733bdd20bcd9:	81 ea 8c 01 01 00    	sub    edx,0x1018c
    733bdd20bcdf:	83 fa 0e             	cmp    edx,0xe
    733bdd20bce2:	0f 97 c2             	seta   dl
    733bdd20bce5:	08 d0                	or     al,dl
    733bdd20bce7:	24 01                	and    al,0x1
    733bdd20bce9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20bcef:	83 fa 00             	cmp    edx,0x0
    733bdd20bcf2:	0f 94 c1             	sete   cl
    733bdd20bcf5:	81 ea 8c 01 01 00    	sub    edx,0x1018c
    733bdd20bcfb:	83 fa 0e             	cmp    edx,0xe
    733bdd20bcfe:	0f 97 c2             	seta   dl
    733bdd20bd01:	08 d1                	or     cl,dl
    733bdd20bd03:	20 c8                	and    al,cl
    733bdd20bd05:	a8 01                	test   al,0x1
    733bdd20bd07:	75 05                	jne    0x733bdd20bd0e
    733bdd20bd09:	e9 05 0f 00 00       	jmp    0x733bdd20cc13
    733bdd20bd0e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20bd15:	00 
    733bdd20bd16:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20bd1d:	48 89 c8             	mov    rax,rcx
    733bdd20bd20:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20bd26:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    733bdd20bd2d:	00 
    733bdd20bd2e:	8b 81 38 00 10 00    	mov    eax,DWORD PTR [rcx+0x100038]
    733bdd20bd34:	83 c0 01             	add    eax,0x1
    733bdd20bd37:	89 81 38 00 10 00    	mov    DWORD PTR [rcx+0x100038],eax
    733bdd20bd3d:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20bd42:	75 4c                	jne    0x733bdd20bd90
    733bdd20bd44:	48 8b 8c 24 f0 00 00 	mov    rcx,QWORD PTR [rsp+0xf0]
    733bdd20bd4b:	00 
    733bdd20bd4c:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20bd52:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    733bdd20bd59:	89 c2                	mov    edx,eax
    733bdd20bd5b:	83 c2 01             	add    edx,0x1
    733bdd20bd5e:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20bd64:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20bd69:	73 23                	jae    0x733bdd20bd8e
    733bdd20bd6b:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    733bdd20bd72:	00 
    733bdd20bd73:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd20bd7a:	89 c9                	mov    ecx,ecx
    733bdd20bd7c:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20bd80:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20bd87:	c7 04 08 0e 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xe
    733bdd20bd8e:	eb 00                	jmp    0x733bdd20bd90
    733bdd20bd90:	eb 00                	jmp    0x733bdd20bd92
    733bdd20bd92:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20bd99:	00 
    733bdd20bd9a:	8b 48 18             	mov    ecx,DWORD PTR [rax+0x18]
    733bdd20bd9d:	89 ca                	mov    edx,ecx
    733bdd20bd9f:	83 c2 01             	add    edx,0x1
    733bdd20bda2:	89 94 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],edx
    733bdd20bda9:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    733bdd20bdac:	89 ce                	mov    esi,ecx
    733bdd20bdae:	c1 ee 1f             	shr    esi,0x1f
    733bdd20bdb1:	89 d3                	mov    ebx,edx
    733bdd20bdb3:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20bdb6:	89 df                	mov    edi,ebx
    733bdd20bdb8:	83 f7 00             	xor    edi,0x0
    733bdd20bdbb:	31 de                	xor    esi,ebx
    733bdd20bdbd:	21 fe                	and    esi,edi
    733bdd20bdbf:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd20bdc2:	83 f9 01             	cmp    ecx,0x1
    733bdd20bdc5:	0f 92 c1             	setb   cl
    733bdd20bdc8:	80 e1 01             	and    cl,0x1
    733bdd20bdcb:	0f b6 c9             	movzx  ecx,cl
    733bdd20bdce:	83 fa 00             	cmp    edx,0x0
    733bdd20bdd1:	0f 94 c3             	sete   bl
    733bdd20bdd4:	80 e3 01             	and    bl,0x1
    733bdd20bdd7:	0f b6 fb             	movzx  edi,bl
    733bdd20bdda:	c1 ea 1f             	shr    edx,0x1f
    733bdd20bddd:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd20bde3:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20bde9:	89 f2                	mov    edx,esi
    733bdd20bdeb:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd20bdf1:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd20bdf7:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd20bdfd:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd20be03:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20be09:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20be0f:	eb 00                	jmp    0x733bdd20be11
    733bdd20be11:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20be18:	00 
    733bdd20be19:	8b 8c 24 e8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe8]
    733bdd20be20:	8b 78 14             	mov    edi,DWORD PTR [rax+0x14]
    733bdd20be23:	39 cf                	cmp    edi,ecx
    733bdd20be25:	0f 96 c2             	setbe  dl
    733bdd20be28:	80 e2 01             	and    dl,0x1
    733bdd20be2b:	0f b6 d2             	movzx  edx,dl
    733bdd20be2e:	89 94 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],edx
    733bdd20be35:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    733bdd20be3b:	39 cf                	cmp    edi,ecx
    733bdd20be3d:	0f 94 c2             	sete   dl
    733bdd20be40:	80 e2 01             	and    dl,0x1
    733bdd20be43:	0f b6 f2             	movzx  esi,dl
    733bdd20be46:	39 f9                	cmp    ecx,edi
    733bdd20be48:	0f 97 c2             	seta   dl
    733bdd20be4b:	80 e2 01             	and    dl,0x1
    733bdd20be4e:	0f b6 d2             	movzx  edx,dl
    733bdd20be51:	39 f9                	cmp    ecx,edi
    733bdd20be53:	0f 96 c1             	setbe  cl
    733bdd20be56:	80 e1 01             	and    cl,0x1
    733bdd20be59:	0f b6 c9             	movzx  ecx,cl
    733bdd20be5c:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd20be62:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20be68:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20be6e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20be74:	eb 00                	jmp    0x733bdd20be76
    733bdd20be76:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    733bdd20be7d:	83 f8 00             	cmp    eax,0x0
    733bdd20be80:	75 33                	jne    0x733bdd20beb5
    733bdd20be82:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20be89:	00 
    733bdd20be8a:	c7 81 bc 00 00 00 7c 	mov    DWORD PTR [rcx+0xbc],0x1017c
    733bdd20be91:	01 01 00 
    733bdd20be94:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20be9a:	83 c0 03             	add    eax,0x3
    733bdd20be9d:	89 84 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],eax
    733bdd20bea4:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20beaa:	0f 82 77 0d 00 00    	jb     0x733bdd20cc27
    733bdd20beb0:	e9 95 0d 00 00       	jmp    0x733bdd20cc4a
    733bdd20beb5:	eb 00                	jmp    0x733bdd20beb7
    733bdd20beb7:	eb 00                	jmp    0x733bdd20beb9
    733bdd20beb9:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20bec0:	00 
    733bdd20bec1:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    733bdd20bec4:	33 08                	xor    ecx,DWORD PTR [rax]
    733bdd20bec6:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd20bec8:	83 f9 00             	cmp    ecx,0x0
    733bdd20becb:	0f 94 c2             	sete   dl
    733bdd20bece:	80 e2 01             	and    dl,0x1
    733bdd20bed1:	0f b6 d2             	movzx  edx,dl
    733bdd20bed4:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20bed7:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20bedd:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20bee3:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    733bdd20beea:	00 00 00 
    733bdd20beed:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    733bdd20bef4:	00 00 00 
    733bdd20bef7:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20befe:	00 00 00 
    733bdd20bf01:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20bf08:	00 00 00 
    733bdd20bf0b:	eb 00                	jmp    0x733bdd20bf0d
    733bdd20bf0d:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20bf14:	00 
    733bdd20bf15:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    733bdd20bf18:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd20bf1f:	83 e0 03             	and    eax,0x3
    733bdd20bf22:	83 f8 00             	cmp    eax,0x0
    733bdd20bf25:	0f 84 97 00 00 00    	je     0x733bdd20bfc2
    733bdd20bf2b:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20bf32:	00 
    733bdd20bf33:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd20bf3a:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20bf41:	00 
    733bdd20bf42:	c7 87 bc 00 00 00 94 	mov    DWORD PTR [rdi+0xbc],0x10194
    733bdd20bf49:	01 01 00 
    733bdd20bf4c:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20bf53:	00 00 00 
    733bdd20bf56:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20bf5d:	00 00 00 
    733bdd20bf60:	31 c0                	xor    eax,eax
    733bdd20bf62:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20bf69:	59 00 00 
    733bdd20bf6c:	ba 94 01 01 00       	mov    edx,0x10194
    733bdd20bf71:	45 31 c0             	xor    r8d,r8d
    733bdd20bf74:	ff d0                	call   rax
    733bdd20bf76:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20bf7d:	00 
    733bdd20bf7e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20bf84:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20bf8a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20bf90:	be 05 00 00 00       	mov    esi,0x5
    733bdd20bf95:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20bf9a:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20bfa1:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20bfa8:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20bfaf:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20bfb6:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20bfbd:	e9 f5 0c 00 00       	jmp    0x733bdd20ccb7
    733bdd20bfc2:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20bfc9:	00 
    733bdd20bfca:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd20bfd1:	c1 e9 0c             	shr    ecx,0xc
    733bdd20bfd4:	89 c9                	mov    ecx,ecx
    733bdd20bfd6:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20bfda:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    733bdd20bfe1:	00 
    733bdd20bfe2:	48 83 f8 00          	cmp    rax,0x0
    733bdd20bfe6:	74 23                	je     0x733bdd20c00b
    733bdd20bfe8:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd20bfef:	00 
    733bdd20bff0:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd20bff7:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20bffd:	89 c9                	mov    ecx,ecx
    733bdd20bfff:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c002:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd20c009:	eb 5d                	jmp    0x733bdd20c068
    733bdd20c00b:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c012:	00 
    733bdd20c013:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    733bdd20c01a:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c021:	00 
    733bdd20c022:	c7 80 bc 00 00 00 94 	mov    DWORD PTR [rax+0xbc],0x10194
    733bdd20c029:	01 01 00 
    733bdd20c02c:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20c033:	00 00 00 
    733bdd20c036:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd20c03d:	00 00 00 
    733bdd20c040:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c047:	59 00 00 
    733bdd20c04a:	ff d0                	call   rax
    733bdd20c04c:	89 c1                	mov    ecx,eax
    733bdd20c04e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c055:	00 
    733bdd20c056:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    733bdd20c05d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c064:	75 2e                	jne    0x733bdd20c094
    733bdd20c066:	eb 78                	jmp    0x733bdd20c0e0
    733bdd20c068:	8b 84 24 dc 00 00 00 	mov    eax,DWORD PTR [rsp+0xdc]
    733bdd20c06f:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd20c076:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    733bdd20c07d:	83 c0 04             	add    eax,0x4
    733bdd20c080:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    733bdd20c087:	83 e0 03             	and    eax,0x3
    733bdd20c08a:	83 f8 00             	cmp    eax,0x0
    733bdd20c08d:	75 64                	jne    0x733bdd20c0f3
    733bdd20c08f:	e9 f6 00 00 00       	jmp    0x733bdd20c18a
    733bdd20c094:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c09b:	00 
    733bdd20c09c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c0a2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c0a8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c0ae:	be 05 00 00 00       	mov    esi,0x5
    733bdd20c0b3:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20c0b8:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c0bf:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c0c6:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c0cd:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c0d4:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c0db:	e9 d7 0b 00 00       	jmp    0x733bdd20ccb7
    733bdd20c0e0:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [rsp+0xb8]
    733bdd20c0e7:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd20c0ee:	e9 75 ff ff ff       	jmp    0x733bdd20c068
    733bdd20c0f3:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c0fa:	00 
    733bdd20c0fb:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    733bdd20c102:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c109:	00 
    733bdd20c10a:	c7 87 bc 00 00 00 94 	mov    DWORD PTR [rdi+0xbc],0x10194
    733bdd20c111:	01 01 00 
    733bdd20c114:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20c11b:	00 00 00 
    733bdd20c11e:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    733bdd20c125:	00 00 00 
    733bdd20c128:	31 c0                	xor    eax,eax
    733bdd20c12a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c131:	59 00 00 
    733bdd20c134:	ba 94 01 01 00       	mov    edx,0x10194
    733bdd20c139:	45 31 c0             	xor    r8d,r8d
    733bdd20c13c:	ff d0                	call   rax
    733bdd20c13e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c145:	00 
    733bdd20c146:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c14c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c152:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c158:	be 05 00 00 00       	mov    esi,0x5
    733bdd20c15d:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20c162:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c169:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c170:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c177:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c17e:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c185:	e9 2d 0b 00 00       	jmp    0x733bdd20ccb7
    733bdd20c18a:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20c191:	00 
    733bdd20c192:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    733bdd20c199:	c1 e9 0c             	shr    ecx,0xc
    733bdd20c19c:	89 c9                	mov    ecx,ecx
    733bdd20c19e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20c1a2:	48 89 84 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rax
    733bdd20c1a9:	00 
    733bdd20c1aa:	48 83 f8 00          	cmp    rax,0x0
    733bdd20c1ae:	74 23                	je     0x733bdd20c1d3
    733bdd20c1b0:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
    733bdd20c1b7:	00 
    733bdd20c1b8:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    733bdd20c1bf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20c1c5:	89 c9                	mov    ecx,ecx
    733bdd20c1c7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c1ca:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd20c1d1:	eb 60                	jmp    0x733bdd20c233
    733bdd20c1d3:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c1da:	00 
    733bdd20c1db:	8b b4 24 b4 00 00 00 	mov    esi,DWORD PTR [rsp+0xb4]
    733bdd20c1e2:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c1e9:	00 
    733bdd20c1ea:	c7 80 bc 00 00 00 94 	mov    DWORD PTR [rax+0xbc],0x10194
    733bdd20c1f1:	01 01 00 
    733bdd20c1f4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20c1fb:	00 00 00 
    733bdd20c1fe:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    733bdd20c205:	00 00 00 
    733bdd20c208:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c20f:	59 00 00 
    733bdd20c212:	ff d0                	call   rax
    733bdd20c214:	89 c1                	mov    ecx,eax
    733bdd20c216:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c21d:	00 
    733bdd20c21e:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    733bdd20c225:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c22c:	75 41                	jne    0x733bdd20c26f
    733bdd20c22e:	e9 88 00 00 00       	jmp    0x733bdd20c2bb
    733bdd20c233:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c23a:	00 
    733bdd20c23b:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    733bdd20c242:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    733bdd20c249:	8b 94 24 a4 00 00 00 	mov    edx,DWORD PTR [rsp+0xa4]
    733bdd20c250:	89 94 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],edx
    733bdd20c257:	83 c1 04             	add    ecx,0x4
    733bdd20c25a:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    733bdd20c261:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd20c264:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd20c26a:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20c26d:	eb 5f                	jmp    0x733bdd20c2ce
    733bdd20c26f:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c276:	00 
    733bdd20c277:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c27d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c283:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c289:	be 05 00 00 00       	mov    esi,0x5
    733bdd20c28e:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20c293:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c29a:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c2a1:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c2a8:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c2af:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c2b6:	e9 fc 09 00 00       	jmp    0x733bdd20ccb7
    733bdd20c2bb:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [rsp+0xa0]
    733bdd20c2c2:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd20c2c9:	e9 65 ff ff ff       	jmp    0x733bdd20c233
    733bdd20c2ce:	eb 00                	jmp    0x733bdd20c2d0
    733bdd20c2d0:	8b 84 24 9c 00 00 00 	mov    eax,DWORD PTR [rsp+0x9c]
    733bdd20c2d7:	83 e0 03             	and    eax,0x3
    733bdd20c2da:	83 f8 00             	cmp    eax,0x0
    733bdd20c2dd:	0f 84 97 00 00 00    	je     0x733bdd20c37a
    733bdd20c2e3:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c2ea:	00 
    733bdd20c2eb:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20c2f2:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c2f9:	00 
    733bdd20c2fa:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10198
    733bdd20c301:	01 01 00 
    733bdd20c304:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20c30b:	00 00 00 
    733bdd20c30e:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20c315:	00 00 00 
    733bdd20c318:	31 c0                	xor    eax,eax
    733bdd20c31a:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c321:	59 00 00 
    733bdd20c324:	ba 98 01 01 00       	mov    edx,0x10198
    733bdd20c329:	45 31 c0             	xor    r8d,r8d
    733bdd20c32c:	ff d0                	call   rax
    733bdd20c32e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c335:	00 
    733bdd20c336:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c33c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c342:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c348:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c34d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c352:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c359:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c360:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c367:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c36e:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c375:	e9 3d 09 00 00       	jmp    0x733bdd20ccb7
    733bdd20c37a:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20c381:	00 
    733bdd20c382:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20c389:	c1 e9 0c             	shr    ecx,0xc
    733bdd20c38c:	89 c9                	mov    ecx,ecx
    733bdd20c38e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20c392:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    733bdd20c399:	00 
    733bdd20c39a:	48 83 f8 00          	cmp    rax,0x0
    733bdd20c39e:	74 23                	je     0x733bdd20c3c3
    733bdd20c3a0:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd20c3a7:	00 
    733bdd20c3a8:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20c3af:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20c3b5:	89 c9                	mov    ecx,ecx
    733bdd20c3b7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c3ba:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd20c3c1:	eb 5d                	jmp    0x733bdd20c420
    733bdd20c3c3:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c3ca:	00 
    733bdd20c3cb:	8b b4 24 9c 00 00 00 	mov    esi,DWORD PTR [rsp+0x9c]
    733bdd20c3d2:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c3d9:	00 
    733bdd20c3da:	c7 80 bc 00 00 00 98 	mov    DWORD PTR [rax+0xbc],0x10198
    733bdd20c3e1:	01 01 00 
    733bdd20c3e4:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20c3eb:	00 00 00 
    733bdd20c3ee:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20c3f5:	00 00 00 
    733bdd20c3f8:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c3ff:	59 00 00 
    733bdd20c402:	ff d0                	call   rax
    733bdd20c404:	89 c1                	mov    ecx,eax
    733bdd20c406:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c40d:	00 
    733bdd20c40e:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    733bdd20c415:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c41c:	75 32                	jne    0x733bdd20c450
    733bdd20c41e:	eb 7c                	jmp    0x733bdd20c49c
    733bdd20c420:	8b 84 24 9c 00 00 00 	mov    eax,DWORD PTR [rsp+0x9c]
    733bdd20c427:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20c42e:	00 
    733bdd20c42f:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    733bdd20c436:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    733bdd20c439:	83 c0 04             	add    eax,0x4
    733bdd20c43c:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    733bdd20c443:	83 e0 03             	and    eax,0x3
    733bdd20c446:	83 f8 00             	cmp    eax,0x0
    733bdd20c449:	75 64                	jne    0x733bdd20c4af
    733bdd20c44b:	e9 f6 00 00 00       	jmp    0x733bdd20c546
    733bdd20c450:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c457:	00 
    733bdd20c458:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c45e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c464:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c46a:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c46f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c474:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c47b:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c482:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c489:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c490:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c497:	e9 1b 08 00 00       	jmp    0x733bdd20ccb7
    733bdd20c49c:	8b 84 24 88 00 00 00 	mov    eax,DWORD PTR [rsp+0x88]
    733bdd20c4a3:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd20c4aa:	e9 71 ff ff ff       	jmp    0x733bdd20c420
    733bdd20c4af:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c4b6:	00 
    733bdd20c4b7:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd20c4be:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c4c5:	00 
    733bdd20c4c6:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10198
    733bdd20c4cd:	01 01 00 
    733bdd20c4d0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20c4d7:	00 00 00 
    733bdd20c4da:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20c4e1:	00 00 00 
    733bdd20c4e4:	31 c0                	xor    eax,eax
    733bdd20c4e6:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c4ed:	59 00 00 
    733bdd20c4f0:	ba 98 01 01 00       	mov    edx,0x10198
    733bdd20c4f5:	45 31 c0             	xor    r8d,r8d
    733bdd20c4f8:	ff d0                	call   rax
    733bdd20c4fa:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c501:	00 
    733bdd20c502:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c508:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c50e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c514:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c519:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c51e:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c525:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c52c:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c533:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c53a:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c541:	e9 71 07 00 00       	jmp    0x733bdd20ccb7
    733bdd20c546:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20c54d:	00 
    733bdd20c54e:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd20c555:	c1 e9 0c             	shr    ecx,0xc
    733bdd20c558:	89 c9                	mov    ecx,ecx
    733bdd20c55a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20c55e:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd20c563:	48 83 f8 00          	cmp    rax,0x0
    733bdd20c567:	74 1d                	je     0x733bdd20c586
    733bdd20c569:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd20c56e:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    733bdd20c575:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20c57b:	89 c9                	mov    ecx,ecx
    733bdd20c57d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c580:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd20c584:	eb 5a                	jmp    0x733bdd20c5e0
    733bdd20c586:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c58d:	00 
    733bdd20c58e:	8b b4 24 84 00 00 00 	mov    esi,DWORD PTR [rsp+0x84]
    733bdd20c595:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c59c:	00 
    733bdd20c59d:	c7 80 bc 00 00 00 98 	mov    DWORD PTR [rax+0xbc],0x10198
    733bdd20c5a4:	01 01 00 
    733bdd20c5a7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20c5ae:	00 00 00 
    733bdd20c5b1:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20c5b8:	00 00 00 
    733bdd20c5bb:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c5c2:	59 00 00 
    733bdd20c5c5:	ff d0                	call   rax
    733bdd20c5c7:	89 c1                	mov    ecx,eax
    733bdd20c5c9:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c5d0:	00 
    733bdd20c5d1:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd20c5d5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c5dc:	75 2c                	jne    0x733bdd20c60a
    733bdd20c5de:	eb 76                	jmp    0x733bdd20c656
    733bdd20c5e0:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    733bdd20c5e7:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20c5ee:	00 
    733bdd20c5ef:	8b 54 24 74          	mov    edx,DWORD PTR [rsp+0x74]
    733bdd20c5f3:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    733bdd20c5f6:	83 c0 04             	add    eax,0x4
    733bdd20c5f9:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd20c5fd:	83 e0 03             	and    eax,0x3
    733bdd20c600:	83 f8 00             	cmp    eax,0x0
    733bdd20c603:	75 5b                	jne    0x733bdd20c660
    733bdd20c605:	e9 ea 00 00 00       	jmp    0x733bdd20c6f4
    733bdd20c60a:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c611:	00 
    733bdd20c612:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c618:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c61e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c624:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c629:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c62e:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c635:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c63c:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c643:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c64a:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c651:	e9 61 06 00 00       	jmp    0x733bdd20ccb7
    733bdd20c656:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    733bdd20c65a:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd20c65e:	eb 80                	jmp    0x733bdd20c5e0
    733bdd20c660:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c667:	00 
    733bdd20c668:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    733bdd20c66c:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c673:	00 
    733bdd20c674:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10198
    733bdd20c67b:	01 01 00 
    733bdd20c67e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20c685:	00 00 00 
    733bdd20c688:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20c68f:	00 00 00 
    733bdd20c692:	31 c0                	xor    eax,eax
    733bdd20c694:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c69b:	59 00 00 
    733bdd20c69e:	ba 98 01 01 00       	mov    edx,0x10198
    733bdd20c6a3:	45 31 c0             	xor    r8d,r8d
    733bdd20c6a6:	ff d0                	call   rax
    733bdd20c6a8:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c6af:	00 
    733bdd20c6b0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c6b6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c6bc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c6c2:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c6c7:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c6cc:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c6d3:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c6da:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c6e1:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c6e8:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c6ef:	e9 c3 05 00 00       	jmp    0x733bdd20ccb7
    733bdd20c6f4:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20c6fb:	00 
    733bdd20c6fc:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    733bdd20c700:	c1 e9 0c             	shr    ecx,0xc
    733bdd20c703:	89 c9                	mov    ecx,ecx
    733bdd20c705:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20c709:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    733bdd20c70e:	48 83 f8 00          	cmp    rax,0x0
    733bdd20c712:	74 1a                	je     0x733bdd20c72e
    733bdd20c714:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    733bdd20c719:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    733bdd20c71d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20c723:	89 c9                	mov    ecx,ecx
    733bdd20c725:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c728:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd20c72c:	eb 57                	jmp    0x733bdd20c785
    733bdd20c72e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c735:	00 
    733bdd20c736:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    733bdd20c73a:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c741:	00 
    733bdd20c742:	c7 80 bc 00 00 00 98 	mov    DWORD PTR [rax+0xbc],0x10198
    733bdd20c749:	01 01 00 
    733bdd20c74c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20c753:	00 00 00 
    733bdd20c756:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20c75d:	00 00 00 
    733bdd20c760:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c767:	59 00 00 
    733bdd20c76a:	ff d0                	call   rax
    733bdd20c76c:	89 c1                	mov    ecx,eax
    733bdd20c76e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c775:	00 
    733bdd20c776:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    733bdd20c77a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c781:	75 29                	jne    0x733bdd20c7ac
    733bdd20c783:	eb 73                	jmp    0x733bdd20c7f8
    733bdd20c785:	8b 44 24 6c          	mov    eax,DWORD PTR [rsp+0x6c]
    733bdd20c789:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20c790:	00 
    733bdd20c791:	8b 54 24 5c          	mov    edx,DWORD PTR [rsp+0x5c]
    733bdd20c795:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    733bdd20c798:	83 c0 04             	add    eax,0x4
    733bdd20c79b:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd20c79f:	83 e0 03             	and    eax,0x3
    733bdd20c7a2:	83 f8 00             	cmp    eax,0x0
    733bdd20c7a5:	75 5b                	jne    0x733bdd20c802
    733bdd20c7a7:	e9 ea 00 00 00       	jmp    0x733bdd20c896
    733bdd20c7ac:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c7b3:	00 
    733bdd20c7b4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c7ba:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c7c0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c7c6:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c7cb:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c7d0:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c7d7:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c7de:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c7e5:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c7ec:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c7f3:	e9 bf 04 00 00       	jmp    0x733bdd20ccb7
    733bdd20c7f8:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    733bdd20c7fc:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd20c800:	eb 83                	jmp    0x733bdd20c785
    733bdd20c802:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c809:	00 
    733bdd20c80a:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd20c80e:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c815:	00 
    733bdd20c816:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10198
    733bdd20c81d:	01 01 00 
    733bdd20c820:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20c827:	00 00 00 
    733bdd20c82a:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20c831:	00 00 00 
    733bdd20c834:	31 c0                	xor    eax,eax
    733bdd20c836:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c83d:	59 00 00 
    733bdd20c840:	ba 98 01 01 00       	mov    edx,0x10198
    733bdd20c845:	45 31 c0             	xor    r8d,r8d
    733bdd20c848:	ff d0                	call   rax
    733bdd20c84a:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c851:	00 
    733bdd20c852:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c858:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c85e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c864:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c869:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c86e:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c875:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c87c:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c883:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c88a:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c891:	e9 21 04 00 00       	jmp    0x733bdd20ccb7
    733bdd20c896:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20c89d:	00 
    733bdd20c89e:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd20c8a2:	c1 e9 0c             	shr    ecx,0xc
    733bdd20c8a5:	89 c9                	mov    ecx,ecx
    733bdd20c8a7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20c8ab:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    733bdd20c8b0:	48 83 f8 00          	cmp    rax,0x0
    733bdd20c8b4:	74 1a                	je     0x733bdd20c8d0
    733bdd20c8b6:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    733bdd20c8bb:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd20c8bf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20c8c5:	89 c9                	mov    ecx,ecx
    733bdd20c8c7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20c8ca:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20c8ce:	eb 57                	jmp    0x733bdd20c927
    733bdd20c8d0:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c8d7:	00 
    733bdd20c8d8:	8b 74 24 54          	mov    esi,DWORD PTR [rsp+0x54]
    733bdd20c8dc:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20c8e3:	00 
    733bdd20c8e4:	c7 80 bc 00 00 00 98 	mov    DWORD PTR [rax+0xbc],0x10198
    733bdd20c8eb:	01 01 00 
    733bdd20c8ee:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20c8f5:	00 00 00 
    733bdd20c8f8:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20c8ff:	00 00 00 
    733bdd20c902:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20c909:	59 00 00 
    733bdd20c90c:	ff d0                	call   rax
    733bdd20c90e:	89 c1                	mov    ecx,eax
    733bdd20c910:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c917:	00 
    733bdd20c918:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd20c91c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20c923:	75 29                	jne    0x733bdd20c94e
    733bdd20c925:	eb 73                	jmp    0x733bdd20c99a
    733bdd20c927:	8b 44 24 54          	mov    eax,DWORD PTR [rsp+0x54]
    733bdd20c92b:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20c932:	00 
    733bdd20c933:	8b 54 24 44          	mov    edx,DWORD PTR [rsp+0x44]
    733bdd20c937:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    733bdd20c93a:	83 c0 04             	add    eax,0x4
    733bdd20c93d:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    733bdd20c941:	83 e0 03             	and    eax,0x3
    733bdd20c944:	83 f8 00             	cmp    eax,0x0
    733bdd20c947:	75 5b                	jne    0x733bdd20c9a4
    733bdd20c949:	e9 ea 00 00 00       	jmp    0x733bdd20ca38
    733bdd20c94e:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c955:	00 
    733bdd20c956:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c95c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20c962:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20c968:	be 06 00 00 00       	mov    esi,0x6
    733bdd20c96d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20c972:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20c979:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20c980:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20c987:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20c98e:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20c995:	e9 1d 03 00 00       	jmp    0x733bdd20ccb7
    733bdd20c99a:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    733bdd20c99e:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd20c9a2:	eb 83                	jmp    0x733bdd20c927
    733bdd20c9a4:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20c9ab:	00 
    733bdd20c9ac:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20c9b0:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
    733bdd20c9b7:	00 
    733bdd20c9b8:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10198
    733bdd20c9bf:	01 01 00 
    733bdd20c9c2:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20c9c9:	00 00 00 
    733bdd20c9cc:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20c9d3:	00 00 00 
    733bdd20c9d6:	31 c0                	xor    eax,eax
    733bdd20c9d8:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20c9df:	59 00 00 
    733bdd20c9e2:	ba 98 01 01 00       	mov    edx,0x10198
    733bdd20c9e7:	45 31 c0             	xor    r8d,r8d
    733bdd20c9ea:	ff d0                	call   rax
    733bdd20c9ec:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20c9f3:	00 
    733bdd20c9f4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20c9fa:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20ca00:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20ca06:	be 06 00 00 00       	mov    esi,0x6
    733bdd20ca0b:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20ca10:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20ca17:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20ca1e:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20ca25:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20ca2c:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20ca33:	e9 7f 02 00 00       	jmp    0x733bdd20ccb7
    733bdd20ca38:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    733bdd20ca3f:	00 
    733bdd20ca40:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20ca44:	c1 e9 0c             	shr    ecx,0xc
    733bdd20ca47:	89 c9                	mov    ecx,ecx
    733bdd20ca49:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20ca4d:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    733bdd20ca52:	48 83 f8 00          	cmp    rax,0x0
    733bdd20ca56:	74 1a                	je     0x733bdd20ca72
    733bdd20ca58:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd20ca5d:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20ca61:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20ca67:	89 c9                	mov    ecx,ecx
    733bdd20ca69:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20ca6c:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd20ca70:	eb 57                	jmp    0x733bdd20cac9
    733bdd20ca72:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20ca79:	00 
    733bdd20ca7a:	8b 74 24 3c          	mov    esi,DWORD PTR [rsp+0x3c]
    733bdd20ca7e:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
    733bdd20ca85:	00 
    733bdd20ca86:	c7 80 bc 00 00 00 98 	mov    DWORD PTR [rax+0xbc],0x10198
    733bdd20ca8d:	01 01 00 
    733bdd20ca90:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20ca97:	00 00 00 
    733bdd20ca9a:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20caa1:	00 00 00 
    733bdd20caa4:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20caab:	59 00 00 
    733bdd20caae:	ff d0                	call   rax
    733bdd20cab0:	89 c1                	mov    ecx,eax
    733bdd20cab2:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cab9:	00 
    733bdd20caba:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    733bdd20cabe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20cac5:	75 1d                	jne    0x733bdd20cae4
    733bdd20cac7:	eb 67                	jmp    0x733bdd20cb30
    733bdd20cac9:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cad0:	00 
    733bdd20cad1:	8b 4c 24 3c          	mov    ecx,DWORD PTR [rsp+0x3c]
    733bdd20cad5:	8b 54 24 2c          	mov    edx,DWORD PTR [rsp+0x2c]
    733bdd20cad9:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    733bdd20cadc:	83 c1 04             	add    ecx,0x4
    733bdd20cadf:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20cae2:	eb 56                	jmp    0x733bdd20cb3a
    733bdd20cae4:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20caeb:	00 
    733bdd20caec:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20caf2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20caf8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20cafe:	be 06 00 00 00       	mov    esi,0x6
    733bdd20cb03:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20cb08:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20cb0f:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20cb16:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20cb1d:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20cb24:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20cb2b:	e9 87 01 00 00       	jmp    0x733bdd20ccb7
    733bdd20cb30:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    733bdd20cb34:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd20cb38:	eb 8f                	jmp    0x733bdd20cac9
    733bdd20cb3a:	eb 00                	jmp    0x733bdd20cb3c
    733bdd20cb3c:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    733bdd20cb43:	83 e0 01             	and    eax,0x1
    733bdd20cb46:	83 f8 00             	cmp    eax,0x0
    733bdd20cb49:	75 3d                	jne    0x733bdd20cb88
    733bdd20cb4b:	8b 94 24 98 00 00 00 	mov    edx,DWORD PTR [rsp+0x98]
    733bdd20cb52:	be 07 00 00 00       	mov    esi,0x7
    733bdd20cb57:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20cb5c:	b0 01                	mov    al,0x1
    733bdd20cb5e:	89 d7                	mov    edi,edx
    733bdd20cb60:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20cb67:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20cb6e:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20cb75:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20cb7c:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20cb83:	e9 2f 01 00 00       	jmp    0x733bdd20ccb7
    733bdd20cb88:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    733bdd20cb8f:	00 
    733bdd20cb90:	48 8b 94 24 f8 00 00 	mov    rdx,QWORD PTR [rsp+0xf8]
    733bdd20cb97:	00 
    733bdd20cb98:	c7 87 bc 00 00 00 9a 	mov    DWORD PTR [rdi+0xbc],0x1019a
    733bdd20cb9f:	01 01 00 
    733bdd20cba2:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20cba9:	00 00 00 
    733bdd20cbac:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    733bdd20cbb3:	00 00 00 
    733bdd20cbb6:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd20cbbd:	59 00 00 
    733bdd20cbc0:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd20cbc5:	ff d0                	call   rax
    733bdd20cbc7:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cbce:	00 
    733bdd20cbcf:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20cbd5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20cbdb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20cbe1:	be 07 00 00 00       	mov    esi,0x7
    733bdd20cbe6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20cbeb:	89 bc 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],edi
    733bdd20cbf2:	89 b4 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],esi
    733bdd20cbf9:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd20cc00:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd20cc07:	88 84 24 db 00 00 00 	mov    BYTE PTR [rsp+0xdb],al
    733bdd20cc0e:	e9 a4 00 00 00       	jmp    0x733bdd20ccb7
    733bdd20cc13:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cc1a:	00 
    733bdd20cc1b:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20cc22:	e9 80 01 00 00       	jmp    0x733bdd20cda7
    733bdd20cc27:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20cc2e:	00 
    733bdd20cc2f:	48 89 c1             	mov    rcx,rax
    733bdd20cc32:	48 81 c1 e0 0b 08 00 	add    rcx,0x80be0
    733bdd20cc39:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd20cc3e:	81 b8 e0 0b 08 00 7c 	cmp    DWORD PTR [rax+0x80be0],0x1017c
    733bdd20cc45:	01 01 00 
    733bdd20cc48:	74 32                	je     0x733bdd20cc7c
    733bdd20cc4a:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cc51:	00 
    733bdd20cc52:	c7 80 bc 00 00 00 7c 	mov    DWORD PTR [rax+0xbc],0x1017c
    733bdd20cc59:	01 01 00 
    733bdd20cc5c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20cc63:	00 00 00 
    733bdd20cc66:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd20cc6d:	00 00 00 
    733bdd20cc70:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20cc77:	e9 2b 01 00 00       	jmp    0x733bdd20cda7
    733bdd20cc7c:	4c 8b b4 24 f8 00 00 	mov    r14,QWORD PTR [rsp+0xf8]
    733bdd20cc83:	00 
    733bdd20cc84:	4c 8b ac 24 00 01 00 	mov    r13,QWORD PTR [rsp+0x100]
    733bdd20cc8b:	00 
    733bdd20cc8c:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd20cc91:	8b 8c 24 e0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe0]
    733bdd20cc98:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    733bdd20cc9f:	7c 01 01 00 
    733bdd20cca3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20ccaa:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20ccae:	48 81 c4 18 01 00 00 	add    rsp,0x118
    733bdd20ccb5:	ff e0                	jmp    rax
    733bdd20ccb7:	48 8b 8c 24 00 01 00 	mov    rcx,QWORD PTR [rsp+0x100]
    733bdd20ccbe:	00 
    733bdd20ccbf:	8b 94 24 c8 00 00 00 	mov    edx,DWORD PTR [rsp+0xc8]
    733bdd20ccc6:	8b 84 24 cc 00 00 00 	mov    eax,DWORD PTR [rsp+0xcc]
    733bdd20cccd:	8b b4 24 d0 00 00 00 	mov    esi,DWORD PTR [rsp+0xd0]
    733bdd20ccd4:	8b bc 24 d4 00 00 00 	mov    edi,DWORD PTR [rsp+0xd4]
    733bdd20ccdb:	8a 9c 24 db 00 00 00 	mov    bl,BYTE PTR [rsp+0xdb]
    733bdd20cce2:	88 5c 24 0b          	mov    BYTE PTR [rsp+0xb],bl
    733bdd20cce6:	89 c3                	mov    ebx,eax
    733bdd20cce8:	89 5c 24 0c          	mov    DWORD PTR [rsp+0xc],ebx
    733bdd20ccec:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd20ccf0:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd20ccf4:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd20ccf8:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd20ccfe:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd20cd02:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20cd08:	73 2c                	jae    0x733bdd20cd36
    733bdd20cd0a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    733bdd20cd11:	00 
    733bdd20cd12:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd20cd16:	89 d1                	mov    ecx,edx
    733bdd20cd18:	c1 e9 01             	shr    ecx,0x1
    733bdd20cd1b:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20cd21:	89 c9                	mov    ecx,ecx
    733bdd20cd23:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20cd27:	48 89 c6             	mov    rsi,rax
    733bdd20cd2a:	48 01 ce             	add    rsi,rcx
    733bdd20cd2d:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    733bdd20cd31:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd20cd34:	74 32                	je     0x733bdd20cd68
    733bdd20cd36:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd20cd3d:	00 
    733bdd20cd3e:	8a 4c 24 0b          	mov    cl,BYTE PTR [rsp+0xb]
    733bdd20cd42:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    733bdd20cd46:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    733bdd20cd4a:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    733bdd20cd4e:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd20cd54:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd20cd5a:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd20cd60:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd20cd66:	eb 3f                	jmp    0x733bdd20cda7
    733bdd20cd68:	4c 8b b4 24 f8 00 00 	mov    r14,QWORD PTR [rsp+0xf8]
    733bdd20cd6f:	00 
    733bdd20cd70:	4c 8b ac 24 00 01 00 	mov    r13,QWORD PTR [rsp+0x100]
    733bdd20cd77:	00 
    733bdd20cd78:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    733bdd20cd7c:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd20cd80:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd20cd84:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd20cd8b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20cd92:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20cd99:	00 
    733bdd20cd9a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20cd9e:	48 81 c4 18 01 00 00 	add    rsp,0x118
    733bdd20cda5:	ff e0                	jmp    rax
    733bdd20cda7:	48 81 c4 18 01 00 00 	add    rsp,0x118
    733bdd20cdae:	c2 08 00             	ret    0x8
