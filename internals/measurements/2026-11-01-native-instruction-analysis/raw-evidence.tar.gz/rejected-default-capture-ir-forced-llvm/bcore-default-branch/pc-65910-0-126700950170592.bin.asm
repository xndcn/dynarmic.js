
build-native-instruction-analysis/capture/bcore-default-branch/pc-65910-0-126700950170592.bin:     file format binary


Disassembly of section .data:

0000733bdd20abe0 <.data>:
    733bdd20abe0:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    733bdd20abe5:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    733bdd20abea:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20abf1:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    733bdd20abf6:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd20abfb:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20ac01:	83 fa 00             	cmp    edx,0x0
    733bdd20ac04:	0f 94 c0             	sete   al
    733bdd20ac07:	81 ea 76 01 01 00    	sub    edx,0x10176
    733bdd20ac0d:	83 fa 12             	cmp    edx,0x12
    733bdd20ac10:	0f 97 c2             	seta   dl
    733bdd20ac13:	08 d0                	or     al,dl
    733bdd20ac15:	24 01                	and    al,0x1
    733bdd20ac17:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20ac1d:	83 fa 00             	cmp    edx,0x0
    733bdd20ac20:	0f 94 c1             	sete   cl
    733bdd20ac23:	81 ea 76 01 01 00    	sub    edx,0x10176
    733bdd20ac29:	83 fa 12             	cmp    edx,0x12
    733bdd20ac2c:	0f 97 c2             	seta   dl
    733bdd20ac2f:	08 d1                	or     cl,dl
    733bdd20ac31:	20 c8                	and    al,cl
    733bdd20ac33:	a8 01                	test   al,0x1
    733bdd20ac35:	75 05                	jne    0x733bdd20ac3c
    733bdd20ac37:	e9 b0 03 00 00       	jmp    0x733bdd20afec
    733bdd20ac3c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20ac41:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20ac48:	48 89 c8             	mov    rax,rcx
    733bdd20ac4b:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20ac51:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    733bdd20ac56:	8b 81 30 00 10 00    	mov    eax,DWORD PTR [rcx+0x100030]
    733bdd20ac5c:	83 c0 01             	add    eax,0x1
    733bdd20ac5f:	89 81 30 00 10 00    	mov    DWORD PTR [rcx+0x100030],eax
    733bdd20ac65:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20ac6a:	75 40                	jne    0x733bdd20acac
    733bdd20ac6c:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    733bdd20ac71:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20ac77:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    733bdd20ac7b:	89 c2                	mov    edx,eax
    733bdd20ac7d:	83 c2 01             	add    edx,0x1
    733bdd20ac80:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd20ac86:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd20ac8b:	73 1d                	jae    0x733bdd20acaa
    733bdd20ac8d:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    733bdd20ac92:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    733bdd20ac96:	89 c9                	mov    ecx,ecx
    733bdd20ac98:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20ac9c:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd20aca3:	c7 04 08 0c 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xc
    733bdd20acaa:	eb 00                	jmp    0x733bdd20acac
    733bdd20acac:	eb 00                	jmp    0x733bdd20acae
    733bdd20acae:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20acb3:	8b 48 18             	mov    ecx,DWORD PTR [rax+0x18]
    733bdd20acb6:	89 ca                	mov    edx,ecx
    733bdd20acb8:	83 c2 01             	add    edx,0x1
    733bdd20acbb:	89 54 24 cc          	mov    DWORD PTR [rsp-0x34],edx
    733bdd20acbf:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    733bdd20acc2:	89 ce                	mov    esi,ecx
    733bdd20acc4:	c1 ee 1f             	shr    esi,0x1f
    733bdd20acc7:	89 d3                	mov    ebx,edx
    733bdd20acc9:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20accc:	89 df                	mov    edi,ebx
    733bdd20acce:	83 f7 00             	xor    edi,0x0
    733bdd20acd1:	31 de                	xor    esi,ebx
    733bdd20acd3:	21 fe                	and    esi,edi
    733bdd20acd5:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd20acd8:	83 f9 01             	cmp    ecx,0x1
    733bdd20acdb:	0f 92 c1             	setb   cl
    733bdd20acde:	80 e1 01             	and    cl,0x1
    733bdd20ace1:	0f b6 c9             	movzx  ecx,cl
    733bdd20ace4:	83 fa 00             	cmp    edx,0x0
    733bdd20ace7:	0f 94 c3             	sete   bl
    733bdd20acea:	80 e3 01             	and    bl,0x1
    733bdd20aced:	0f b6 fb             	movzx  edi,bl
    733bdd20acf0:	c1 ea 1f             	shr    edx,0x1f
    733bdd20acf3:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd20acf9:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20acff:	89 f2                	mov    edx,esi
    733bdd20ad01:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd20ad07:	89 54 24 d0          	mov    DWORD PTR [rsp-0x30],edx
    733bdd20ad0b:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd20ad11:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd20ad17:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd20ad1d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20ad23:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20ad29:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd20ad2f:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    733bdd20ad33:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd20ad39:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    733bdd20ad3d:	eb 00                	jmp    0x733bdd20ad3f
    733bdd20ad3f:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20ad44:	8b 4c 24 cc          	mov    ecx,DWORD PTR [rsp-0x34]
    733bdd20ad48:	8b 78 14             	mov    edi,DWORD PTR [rax+0x14]
    733bdd20ad4b:	39 cf                	cmp    edi,ecx
    733bdd20ad4d:	0f 96 c2             	setbe  dl
    733bdd20ad50:	80 e2 01             	and    dl,0x1
    733bdd20ad53:	0f b6 d2             	movzx  edx,dl
    733bdd20ad56:	89 54 24 c8          	mov    DWORD PTR [rsp-0x38],edx
    733bdd20ad5a:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    733bdd20ad60:	39 cf                	cmp    edi,ecx
    733bdd20ad62:	0f 94 c2             	sete   dl
    733bdd20ad65:	80 e2 01             	and    dl,0x1
    733bdd20ad68:	0f b6 f2             	movzx  esi,dl
    733bdd20ad6b:	39 f9                	cmp    ecx,edi
    733bdd20ad6d:	0f 97 c2             	seta   dl
    733bdd20ad70:	80 e2 01             	and    dl,0x1
    733bdd20ad73:	0f b6 d2             	movzx  edx,dl
    733bdd20ad76:	39 f9                	cmp    ecx,edi
    733bdd20ad78:	0f 96 c1             	setbe  cl
    733bdd20ad7b:	80 e1 01             	and    cl,0x1
    733bdd20ad7e:	0f b6 c9             	movzx  ecx,cl
    733bdd20ad81:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd20ad87:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20ad8d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20ad93:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20ad99:	eb 00                	jmp    0x733bdd20ad9b
    733bdd20ad9b:	8b 44 24 c8          	mov    eax,DWORD PTR [rsp-0x38]
    733bdd20ad9f:	83 f8 00             	cmp    eax,0x0
    733bdd20ada2:	74 2d                	je     0x733bdd20add1
    733bdd20ada4:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd20ada9:	c7 81 bc 00 00 00 92 	mov    DWORD PTR [rcx+0xbc],0x10192
    733bdd20adb0:	01 01 00 
    733bdd20adb3:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20adb9:	83 c0 03             	add    eax,0x3
    733bdd20adbc:	89 44 24 c4          	mov    DWORD PTR [rsp-0x3c],eax
    733bdd20adc0:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20adc6:	0f 82 31 02 00 00    	jb     0x733bdd20affd
    733bdd20adcc:	e9 4c 02 00 00       	jmp    0x733bdd20b01d
    733bdd20add1:	eb 00                	jmp    0x733bdd20add3
    733bdd20add3:	eb 00                	jmp    0x733bdd20add5
    733bdd20add5:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20adda:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    733bdd20addd:	0f af 48 10          	imul   ecx,DWORD PTR [rax+0x10]
    733bdd20ade1:	89 4c 24 c0          	mov    DWORD PTR [rsp-0x40],ecx
    733bdd20ade5:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    733bdd20ade8:	eb 00                	jmp    0x733bdd20adea
    733bdd20adea:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20adef:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    733bdd20adf2:	89 4c 24 bc          	mov    DWORD PTR [rsp-0x44],ecx
    733bdd20adf6:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd20adf9:	eb 00                	jmp    0x733bdd20adfb
    733bdd20adfb:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20ae00:	8b 54 24 d0          	mov    edx,DWORD PTR [rsp-0x30]
    733bdd20ae04:	8b 5c 24 bc          	mov    ebx,DWORD PTR [rsp-0x44]
    733bdd20ae08:	8b 4c 24 c0          	mov    ecx,DWORD PTR [rsp-0x40]
    733bdd20ae0c:	89 cf                	mov    edi,ecx
    733bdd20ae0e:	01 df                	add    edi,ebx
    733bdd20ae10:	89 7c 24 b8          	mov    DWORD PTR [rsp-0x48],edi
    733bdd20ae14:	89 78 1c             	mov    DWORD PTR [rax+0x1c],edi
    733bdd20ae17:	89 ce                	mov    esi,ecx
    733bdd20ae19:	c1 ee 1f             	shr    esi,0x1f
    733bdd20ae1c:	89 dd                	mov    ebp,ebx
    733bdd20ae1e:	c1 ed 1f             	shr    ebp,0x1f
    733bdd20ae21:	41 89 f8             	mov    r8d,edi
    733bdd20ae24:	41 c1 e8 1f          	shr    r8d,0x1f
    733bdd20ae28:	44 31 c5             	xor    ebp,r8d
    733bdd20ae2b:	44 31 c6             	xor    esi,r8d
    733bdd20ae2e:	21 ee                	and    esi,ebp
    733bdd20ae30:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd20ae33:	39 d9                	cmp    ecx,ebx
    733bdd20ae35:	0f 92 c1             	setb   cl
    733bdd20ae38:	80 e1 01             	and    cl,0x1
    733bdd20ae3b:	0f b6 c9             	movzx  ecx,cl
    733bdd20ae3e:	83 ff 00             	cmp    edi,0x0
    733bdd20ae41:	0f 94 c3             	sete   bl
    733bdd20ae44:	80 e3 01             	and    bl,0x1
    733bdd20ae47:	0f b6 db             	movzx  ebx,bl
    733bdd20ae4a:	c1 ef 1f             	shr    edi,0x1f
    733bdd20ae4d:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    733bdd20ae53:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    733bdd20ae59:	09 f2                	or     edx,esi
    733bdd20ae5b:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd20ae61:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd20ae67:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd20ae6d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20ae73:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20ae79:	eb 00                	jmp    0x733bdd20ae7b
    733bdd20ae7b:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20ae80:	8b 7c 24 b8          	mov    edi,DWORD PTR [rsp-0x48]
    733bdd20ae84:	89 fa                	mov    edx,edi
    733bdd20ae86:	83 ea 00             	sub    edx,0x0
    733bdd20ae89:	83 fa 00             	cmp    edx,0x0
    733bdd20ae8c:	0f 94 c1             	sete   cl
    733bdd20ae8f:	80 e1 01             	and    cl,0x1
    733bdd20ae92:	0f b6 f1             	movzx  esi,cl
    733bdd20ae95:	c1 ea 1f             	shr    edx,0x1f
    733bdd20ae98:	89 f9                	mov    ecx,edi
    733bdd20ae9a:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20ae9d:	89 d3                	mov    ebx,edx
    733bdd20ae9f:	31 cb                	xor    ebx,ecx
    733bdd20aea1:	83 f1 00             	xor    ecx,0x0
    733bdd20aea4:	21 d9                	and    ecx,ebx
    733bdd20aea6:	31 ca                	xor    edx,ecx
    733bdd20aea8:	89 54 24 b4          	mov    DWORD PTR [rsp-0x4c],edx
    733bdd20aeac:	31 c9                	xor    ecx,ecx
    733bdd20aeae:	39 f9                	cmp    ecx,edi
    733bdd20aeb0:	0f 96 c1             	setbe  cl
    733bdd20aeb3:	80 e1 01             	and    cl,0x1
    733bdd20aeb6:	0f b6 c9             	movzx  ecx,cl
    733bdd20aeb9:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    733bdd20aebf:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd20aec5:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20aecb:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20aed1:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd20aed7:	eb 00                	jmp    0x733bdd20aed9
    733bdd20aed9:	8b 44 24 b4          	mov    eax,DWORD PTR [rsp-0x4c]
    733bdd20aedd:	83 f8 00             	cmp    eax,0x0
    733bdd20aee0:	75 2d                	jne    0x733bdd20af0f
    733bdd20aee2:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd20aee7:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10170
    733bdd20aeee:	01 01 00 
    733bdd20aef1:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20aef7:	83 c0 08             	add    eax,0x8
    733bdd20aefa:	89 44 24 b0          	mov    DWORD PTR [rsp-0x50],eax
    733bdd20aefe:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20af04:	0f 82 6d 01 00 00    	jb     0x733bdd20b077
    733bdd20af0a:	e9 88 01 00 00       	jmp    0x733bdd20b097
    733bdd20af0f:	eb 00                	jmp    0x733bdd20af11
    733bdd20af11:	eb 00                	jmp    0x733bdd20af13
    733bdd20af13:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20af18:	8b 4c 24 b8          	mov    ecx,DWORD PTR [rsp-0x48]
    733bdd20af1c:	33 08                	xor    ecx,DWORD PTR [rax]
    733bdd20af1e:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd20af20:	83 f9 00             	cmp    ecx,0x0
    733bdd20af23:	0f 94 c2             	sete   dl
    733bdd20af26:	80 e2 01             	and    dl,0x1
    733bdd20af29:	0f b6 d2             	movzx  edx,dl
    733bdd20af2c:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20af2f:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    733bdd20af35:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    733bdd20af3b:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    733bdd20af42:	00 00 00 
    733bdd20af45:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    733bdd20af4c:	00 00 00 
    733bdd20af4f:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd20af56:	00 00 00 
    733bdd20af59:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd20af60:	00 00 00 
    733bdd20af63:	eb 00                	jmp    0x733bdd20af65
    733bdd20af65:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd20af6a:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    733bdd20af6e:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    733bdd20af72:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd20af78:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd20af7e:	83 ff 01             	cmp    edi,0x1
    733bdd20af81:	0f 97 c3             	seta   bl
    733bdd20af84:	3d 88 01 01 00       	cmp    eax,0x10188
    733bdd20af89:	0f 94 c0             	sete   al
    733bdd20af8c:	20 c3                	and    bl,al
    733bdd20af8e:	b8 8c 01 01 00       	mov    eax,0x1018c
    733bdd20af93:	f6 c3 01             	test   bl,0x1
    733bdd20af96:	0f 45 c2             	cmovne eax,edx
    733bdd20af99:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd20af9f:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd20afa5:	83 ff 01             	cmp    edi,0x1
    733bdd20afa8:	0f 97 c3             	seta   bl
    733bdd20afab:	81 fe 88 01 01 00    	cmp    esi,0x10188
    733bdd20afb1:	40 0f 94 c6          	sete   sil
    733bdd20afb5:	40 20 f3             	and    bl,sil
    733bdd20afb8:	f6 c3 01             	test   bl,0x1
    733bdd20afbb:	0f 45 c2             	cmovne eax,edx
    733bdd20afbe:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd20afc4:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10110
    733bdd20afcb:	01 01 00 
    733bdd20afce:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20afd4:	83 c0 0a             	add    eax,0xa
    733bdd20afd7:	89 44 24 ac          	mov    DWORD PTR [rsp-0x54],eax
    733bdd20afdb:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20afe1:	0f 82 0a 01 00 00    	jb     0x733bdd20b0f1
    733bdd20afe7:	e9 25 01 00 00       	jmp    0x733bdd20b111
    733bdd20afec:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20aff1:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd20aff8:	e9 6b 01 00 00       	jmp    0x733bdd20b168
    733bdd20affd:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd20b002:	48 89 c1             	mov    rcx,rax
    733bdd20b005:	48 81 c1 90 0c 08 00 	add    rcx,0x80c90
    733bdd20b00c:	48 89 4c 24 a0       	mov    QWORD PTR [rsp-0x60],rcx
    733bdd20b011:	81 b8 90 0c 08 00 92 	cmp    DWORD PTR [rax+0x80c90],0x10192
    733bdd20b018:	01 01 00 
    733bdd20b01b:	74 2f                	je     0x733bdd20b04c
    733bdd20b01d:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20b022:	c7 80 bc 00 00 00 92 	mov    DWORD PTR [rax+0xbc],0x10192
    733bdd20b029:	01 01 00 
    733bdd20b02c:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20b033:	00 00 00 
    733bdd20b036:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd20b03d:	00 00 00 
    733bdd20b040:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20b047:	e9 1c 01 00 00       	jmp    0x733bdd20b168
    733bdd20b04c:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd20b051:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd20b056:	48 8b 44 24 a0       	mov    rax,QWORD PTR [rsp-0x60]
    733bdd20b05b:	8b 4c 24 c4          	mov    ecx,DWORD PTR [rsp-0x3c]
    733bdd20b05f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10192
    733bdd20b066:	92 01 01 00 
    733bdd20b06a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20b071:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20b075:	ff e0                	jmp    rax
    733bdd20b077:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd20b07c:	48 89 c1             	mov    rcx,rax
    733bdd20b07f:	48 81 c1 80 0b 08 00 	add    rcx,0x80b80
    733bdd20b086:	48 89 4c 24 98       	mov    QWORD PTR [rsp-0x68],rcx
    733bdd20b08b:	81 b8 80 0b 08 00 70 	cmp    DWORD PTR [rax+0x80b80],0x10170
    733bdd20b092:	01 01 00 
    733bdd20b095:	74 2f                	je     0x733bdd20b0c6
    733bdd20b097:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20b09c:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10170
    733bdd20b0a3:	01 01 00 
    733bdd20b0a6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20b0ad:	00 00 00 
    733bdd20b0b0:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd20b0b7:	00 00 00 
    733bdd20b0ba:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20b0c1:	e9 a2 00 00 00       	jmp    0x733bdd20b168
    733bdd20b0c6:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd20b0cb:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd20b0d0:	48 8b 44 24 98       	mov    rax,QWORD PTR [rsp-0x68]
    733bdd20b0d5:	8b 4c 24 b0          	mov    ecx,DWORD PTR [rsp-0x50]
    733bdd20b0d9:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10170
    733bdd20b0e0:	70 01 01 00 
    733bdd20b0e4:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20b0eb:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20b0ef:	ff e0                	jmp    rax
    733bdd20b0f1:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd20b0f6:	48 89 c1             	mov    rcx,rax
    733bdd20b0f9:	48 81 c1 80 08 08 00 	add    rcx,0x80880
    733bdd20b100:	48 89 4c 24 90       	mov    QWORD PTR [rsp-0x70],rcx
    733bdd20b105:	81 b8 80 08 08 00 10 	cmp    DWORD PTR [rax+0x80880],0x10110
    733bdd20b10c:	01 01 00 
    733bdd20b10f:	74 2c                	je     0x733bdd20b13d
    733bdd20b111:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd20b116:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10110
    733bdd20b11d:	01 01 00 
    733bdd20b120:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20b127:	00 00 00 
    733bdd20b12a:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    733bdd20b131:	00 00 00 
    733bdd20b134:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20b13b:	eb 2b                	jmp    0x733bdd20b168
    733bdd20b13d:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd20b142:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd20b147:	48 8b 44 24 90       	mov    rax,QWORD PTR [rsp-0x70]
    733bdd20b14c:	8b 4c 24 ac          	mov    ecx,DWORD PTR [rsp-0x54]
    733bdd20b150:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10110
    733bdd20b157:	10 01 01 00 
    733bdd20b15b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20b162:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20b166:	ff e0                	jmp    rax
    733bdd20b168:	c2 08 00             	ret    0x8
