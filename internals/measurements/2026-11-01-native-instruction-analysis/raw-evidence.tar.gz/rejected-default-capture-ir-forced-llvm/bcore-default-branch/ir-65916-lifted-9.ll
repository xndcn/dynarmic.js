; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x0001017c(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65916
  %4 = icmp ugt i32 %3, 12
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb14 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb14, 0
  %9 = sub i32 %guard_lb14, 65916
  %10 = icmp ugt i32 %9, 12
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x0001017c_entry, label %lb_guard_miss, !prof !0

insn_0x0001017c_entry:                            ; preds = %lb_guard
  %13 = getelementptr i8, ptr %cpu, i64 336
  %chain_table25 = load ptr, ptr %13, align 8
  %tier_table = getelementptr i8, ptr %chain_table25, i64 1048576
  %14 = getelementptr i8, ptr %tier_table, i64 36
  %15 = load i32, ptr %14, align 4
  %tier_count = add i32 %15, 1
  store i32 %tier_count, ptr %14, align 4
  %16 = icmp eq i32 %tier_count, 30000
  br i1 %16, label %17, label %27, !prof !1

17:                                               ; preds = %insn_0x0001017c_entry
  %18 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %18, align 4
  %19 = add i32 %tier_requests, 1
  store i32 %19, ptr %18, align 4
  %20 = icmp ult i32 %tier_requests, 256
  br i1 %20, label %21, label %26

21:                                               ; preds = %17
  %22 = zext i32 %tier_requests to i64
  %23 = mul i64 %22, 4
  %24 = add i64 262148, %23
  %25 = getelementptr i8, ptr %tier_table, i64 %24
  store i32 9, ptr %25, align 4
  br label %26

26:                                               ; preds = %17, %21
  br label %27

27:                                               ; preds = %insn_0x0001017c_entry, %26
  br label %insn_0x0001017c

insn_0x0001017c:                                  ; preds = %27
  %28 = getelementptr i8, ptr %cpu, i32 28
  %a = load i32, ptr %28, align 4
  %29 = getelementptr i8, ptr %cpu, i32 16
  %b = load i32, ptr %29, align 4
  %mul = mul i32 %a, %b
  %30 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mul, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %32, align 4
  br label %insn_0x0001017e_entry

insn_0x0001017e_entry:                            ; preds = %insn_0x0001017c
  br label %insn_0x0001017e

insn_0x0001017e:                                  ; preds = %insn_0x0001017e_entry
  %33 = getelementptr i8, ptr %cpu, i32 52
  %regmv_src = load i32, ptr %33, align 4
  %34 = getelementptr i8, ptr %cpu, i32 4
  store i32 %regmv_src, ptr %34, align 4
  br label %insn_0x00010180_entry

insn_0x00010180_entry:                            ; preds = %insn_0x0001017e
  br label %insn_0x00010180

insn_0x00010180:                                  ; preds = %insn_0x00010180_entry
  %add32 = add i32 %mul, %regmv_src
  %35 = getelementptr i8, ptr %cpu, i32 28
  store i32 %add32, ptr %35, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn = lshr i32 %add32, 31
  %36 = xor i32 %flgo, %flgn
  %37 = xor i32 %flgs, %flgn
  %38 = and i32 %37, %36
  %39 = xor i32 %mul, -1
  %40 = icmp ult i32 %39, %regmv_src
  %ac0 = zext i1 %40 to i32
  %41 = icmp eq i32 %add32, 0
  %az = zext i1 %41 to i32
  %an = lshr i32 %add32, 31
  %42 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %44, align 4
  %45 = or i32 %vs_cur, %38
  %46 = getelementptr i8, ptr %cpu, i32 248
  store i32 %38, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 252
  store i32 %38, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 256
  store i32 %45, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %50, align 4
  br label %insn_0x00010182_entry

insn_0x00010182_entry:                            ; preds = %insn_0x00010180
  br label %insn_0x00010182

insn_0x00010182:                                  ; preds = %insn_0x00010182_entry
  %diff = sub i32 %add32, 0
  %51 = icmp eq i32 %diff, 0
  %az1 = zext i1 %51 to i32
  %flgn2 = lshr i32 %diff, 31
  %flgs3 = lshr i32 %add32, 31
  %52 = xor i32 %flgn2, %flgs3
  %53 = xor i32 %flgs3, 0
  %overflow = and i32 %53, %52
  %an4 = xor i32 %flgn2, %overflow
  %54 = icmp ule i32 0, %add32
  %ac05 = zext i1 %54 to i32
  %55 = getelementptr i8, ptr %cpu, i32 276
  store i32 %an4, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an4, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac05, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac05, ptr %59, align 4
  br label %insn_0x00010184_entry

insn_0x00010184_entry:                            ; preds = %insn_0x00010182
  br label %insn_0x00010184

insn_0x00010184:                                  ; preds = %insn_0x00010184_entry
  %cc_false = icmp eq i32 %an4, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010184
  %60 = getelementptr i8, ptr %cpu, i32 188
  store i32 65904, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %61, align 4
  %chain_total = add nuw i32 %chain_packets, 5
  %62 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %62 monotonic, align 4, !range !2
  %63 = icmp ult i32 %chain_total, %chain_budget
  br i1 %63, label %chain_go, label %chain_leave15, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010184
  br label %insn_0x00010186_entry

insn_0x00010186_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010186

insn_0x00010186:                                  ; preds = %insn_0x00010186_entry
  %64 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %64, align 4
  %xor32 = xor i32 %rt, %add32
  %65 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %65, align 4
  %66 = icmp eq i32 %xor32, 0
  %az6 = zext i1 %66 to i32
  %an7 = lshr i32 %xor32, 31
  %67 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az6, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an7, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %72, align 4
  br label %insn_0x00010188_entry

insn_0x00010188_entry:                            ; preds = %insn_0x00010186
  br label %insn_0x00010188

insn_0x00010188:                                  ; preds = %insn_0x00010188_entry
  %73 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %74, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65928
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65932
  %75 = getelementptr i8, ptr %cpu, i32 156
  %lc8 = load i32, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 148
  %lt9 = load i32, ptr %76, align 4
  %lc_gt110 = icmp ugt i32 %lc8, 1
  %at_lb11 = icmp eq i32 %lb1, 65928
  %hwloop_cond12 = and i1 %lc_gt110, %at_lb11
  %hwloop_rets13 = select i1 %hwloop_cond12, i32 %lt9, i32 %hwloop_rets
  %77 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets13, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 188
  store i32 65808, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets18 = load i32, ptr %79, align 4
  %chain_total19 = add nuw i32 %chain_packets18, 7
  %80 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget20 = load atomic i32, ptr %80 monotonic, align 4, !range !2
  %81 = icmp ult i32 %chain_total19, %chain_budget20
  br i1 %81, label %chain_go16, label %chain_leave17, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %82 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %82, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527232
  %83 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %83, align 4
  %84 = icmp eq i32 %slot_pc, 65904
  br i1 %84, label %chain_hit, label %chain_leave15, !prof !0

chain_leave15:                                    ; preds = %chain_go, %brcc_taken
  %85 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i64 308
  store i32 5, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %88, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %89 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %90, align 4
  %91 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %91, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go16:                                       ; preds = %insn_0x00010188
  %chain_slot21 = getelementptr i8, ptr %chain_table, i64 526464
  %92 = getelementptr i8, ptr %chain_slot21, i64 0
  %slot_pc22 = load i32, ptr %92, align 4
  %93 = icmp eq i32 %slot_pc22, 65808
  br i1 %93, label %chain_hit23, label %chain_leave17, !prof !0

chain_leave17:                                    ; preds = %chain_go16, %insn_0x00010188
  %94 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 308
  store i32 7, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %97, align 1
  br label %return

chain_hit23:                                      ; preds = %chain_go16
  %98 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total19, ptr %99, align 4
  %100 = getelementptr i8, ptr %chain_slot21, i64 8
  %chain_fn24 = load ptr, ptr %100, align 8
  musttail call swifttailcc void %chain_fn24(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave17, %chain_leave15, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
