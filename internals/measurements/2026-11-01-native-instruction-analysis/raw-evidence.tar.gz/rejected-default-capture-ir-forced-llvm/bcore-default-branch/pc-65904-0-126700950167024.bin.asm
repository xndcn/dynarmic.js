
build-native-instruction-analysis/capture/bcore-default-branch/pc-65904-0-126700950167024.bin:     file format binary


Disassembly of section .data:

0000733bdd209df0 <.data>:
    733bdd209df0:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    733bdd209df5:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    733bdd209dfa:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd209e01:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    733bdd209e06:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd209e0b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd209e11:	83 fa 00             	cmp    edx,0x0
    733bdd209e14:	0f 94 c0             	sete   al
    733bdd209e17:	81 ea 70 01 01 00    	sub    edx,0x10170
    733bdd209e1d:	83 fa 02             	cmp    edx,0x2
    733bdd209e20:	0f 97 c2             	seta   dl
    733bdd209e23:	08 d0                	or     al,dl
    733bdd209e25:	24 01                	and    al,0x1
    733bdd209e27:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd209e2d:	83 fa 00             	cmp    edx,0x0
    733bdd209e30:	0f 94 c1             	sete   cl
    733bdd209e33:	81 ea 70 01 01 00    	sub    edx,0x10170
    733bdd209e39:	83 fa 02             	cmp    edx,0x2
    733bdd209e3c:	0f 97 c2             	seta   dl
    733bdd209e3f:	08 d1                	or     cl,dl
    733bdd209e41:	20 c8                	and    al,cl
    733bdd209e43:	a8 01                	test   al,0x1
    733bdd209e45:	75 05                	jne    0x733bdd209e4c
    733bdd209e47:	e9 7c 01 00 00       	jmp    0x733bdd209fc8
    733bdd209e4c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209e51:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd209e58:	48 89 c8             	mov    rax,rcx
    733bdd209e5b:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd209e61:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    733bdd209e66:	8b 81 28 00 10 00    	mov    eax,DWORD PTR [rcx+0x100028]
    733bdd209e6c:	83 c0 01             	add    eax,0x1
    733bdd209e6f:	89 81 28 00 10 00    	mov    DWORD PTR [rcx+0x100028],eax
    733bdd209e75:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd209e7a:	75 40                	jne    0x733bdd209ebc
    733bdd209e7c:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    733bdd209e81:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd209e87:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    733bdd209e8b:	89 c2                	mov    edx,eax
    733bdd209e8d:	83 c2 01             	add    edx,0x1
    733bdd209e90:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd209e96:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd209e9b:	73 1d                	jae    0x733bdd209eba
    733bdd209e9d:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    733bdd209ea2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    733bdd209ea6:	89 c9                	mov    ecx,ecx
    733bdd209ea8:	48 c1 e1 02          	shl    rcx,0x2
    733bdd209eac:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd209eb3:	c7 04 08 0a 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xa
    733bdd209eba:	eb 00                	jmp    0x733bdd209ebc
    733bdd209ebc:	eb 00                	jmp    0x733bdd209ebe
    733bdd209ebe:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209ec3:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    733bdd209ec6:	8b 38                	mov    edi,DWORD PTR [rax]
    733bdd209ec8:	89 ca                	mov    edx,ecx
    733bdd209eca:	01 fa                	add    edx,edi
    733bdd209ecc:	89 10                	mov    DWORD PTR [rax],edx
    733bdd209ece:	89 ce                	mov    esi,ecx
    733bdd209ed0:	c1 ee 1f             	shr    esi,0x1f
    733bdd209ed3:	89 fb                	mov    ebx,edi
    733bdd209ed5:	c1 eb 1f             	shr    ebx,0x1f
    733bdd209ed8:	89 d5                	mov    ebp,edx
    733bdd209eda:	c1 ed 1f             	shr    ebp,0x1f
    733bdd209edd:	31 eb                	xor    ebx,ebp
    733bdd209edf:	31 ee                	xor    esi,ebp
    733bdd209ee1:	21 de                	and    esi,ebx
    733bdd209ee3:	83 f1 ff             	xor    ecx,0xffffffff
    733bdd209ee6:	39 f9                	cmp    ecx,edi
    733bdd209ee8:	0f 92 c1             	setb   cl
    733bdd209eeb:	80 e1 01             	and    cl,0x1
    733bdd209eee:	0f b6 c9             	movzx  ecx,cl
    733bdd209ef1:	83 fa 00             	cmp    edx,0x0
    733bdd209ef4:	0f 94 c3             	sete   bl
    733bdd209ef7:	80 e3 01             	and    bl,0x1
    733bdd209efa:	0f b6 fb             	movzx  edi,bl
    733bdd209efd:	c1 ea 1f             	shr    edx,0x1f
    733bdd209f00:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    733bdd209f06:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd209f0c:	89 f2                	mov    edx,esi
    733bdd209f0e:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    733bdd209f14:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    733bdd209f1a:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    733bdd209f20:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    733bdd209f26:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd209f2c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd209f32:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd209f38:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    733bdd209f3c:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd209f42:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    733bdd209f46:	eb 00                	jmp    0x733bdd209f48
    733bdd209f48:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    733bdd209f4d:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    733bdd209f51:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    733bdd209f55:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd209f5b:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd209f61:	83 ff 01             	cmp    edi,0x1
    733bdd209f64:	0f 97 c3             	seta   bl
    733bdd209f67:	3d 72 01 01 00       	cmp    eax,0x10172
    733bdd209f6c:	0f 94 c0             	sete   al
    733bdd209f6f:	20 c3                	and    bl,al
    733bdd209f71:	b8 76 01 01 00       	mov    eax,0x10176
    733bdd209f76:	f6 c3 01             	test   bl,0x1
    733bdd209f79:	0f 45 c2             	cmovne eax,edx
    733bdd209f7c:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd209f82:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd209f88:	83 ff 01             	cmp    edi,0x1
    733bdd209f8b:	0f 97 c3             	seta   bl
    733bdd209f8e:	81 fe 72 01 01 00    	cmp    esi,0x10172
    733bdd209f94:	40 0f 94 c6          	sete   sil
    733bdd209f98:	40 20 f3             	and    bl,sil
    733bdd209f9b:	f6 c3 01             	test   bl,0x1
    733bdd209f9e:	0f 45 c2             	cmovne eax,edx
    733bdd209fa1:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd209fa7:	c7 81 bc 00 00 00 30 	mov    DWORD PTR [rcx+0xbc],0x10130
    733bdd209fae:	01 01 00 
    733bdd209fb1:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd209fb7:	83 c0 02             	add    eax,0x2
    733bdd209fba:	89 44 24 d0          	mov    DWORD PTR [rsp-0x30],eax
    733bdd209fbe:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd209fc4:	72 10                	jb     0x733bdd209fd6
    733bdd209fc6:	eb 2e                	jmp    0x733bdd209ff6
    733bdd209fc8:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209fcd:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd209fd4:	eb 77                	jmp    0x733bdd20a04d
    733bdd209fd6:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    733bdd209fdb:	48 89 c1             	mov    rcx,rax
    733bdd209fde:	48 81 c1 80 09 08 00 	add    rcx,0x80980
    733bdd209fe5:	48 89 4c 24 c8       	mov    QWORD PTR [rsp-0x38],rcx
    733bdd209fea:	81 b8 80 09 08 00 30 	cmp    DWORD PTR [rax+0x80980],0x10130
    733bdd209ff1:	01 01 00 
    733bdd209ff4:	74 2c                	je     0x733bdd20a022
    733bdd209ff6:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    733bdd209ffb:	c7 80 bc 00 00 00 30 	mov    DWORD PTR [rax+0xbc],0x10130
    733bdd20a002:	01 01 00 
    733bdd20a005:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd20a00c:	00 00 00 
    733bdd20a00f:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd20a016:	00 00 00 
    733bdd20a019:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20a020:	eb 2b                	jmp    0x733bdd20a04d
    733bdd20a022:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    733bdd20a027:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    733bdd20a02c:	48 8b 44 24 c8       	mov    rax,QWORD PTR [rsp-0x38]
    733bdd20a031:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    733bdd20a035:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10130
    733bdd20a03c:	30 01 01 00 
    733bdd20a040:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20a047:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20a04b:	ff e0                	jmp    rax
    733bdd20a04d:	c2 08 00             	ret    0x8
