
build-native-instruction-analysis/capture/bcore-default-branch/pc-66344-0-126700950142688.bin:     file format binary


Disassembly of section .data:

0000733bdd203ee0 <.data>:
    733bdd203ee0:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    733bdd203ee7:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    733bdd203eee:	00 
    733bdd203eef:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    733bdd203ef6:	00 
    733bdd203ef7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd203efe:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    733bdd203f05:	00 
    733bdd203f06:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd203f0d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    733bdd203f14:	00 
    733bdd203f15:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd203f1c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    733bdd203f23:	00 
    733bdd203f24:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd203f2b:	00 
    733bdd203f2c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd203f32:	83 fa 00             	cmp    edx,0x0
    733bdd203f35:	0f 94 c0             	sete   al
    733bdd203f38:	81 ea 28 03 01 00    	sub    edx,0x10328
    733bdd203f3e:	83 fa 46             	cmp    edx,0x46
    733bdd203f41:	0f 97 c2             	seta   dl
    733bdd203f44:	08 d0                	or     al,dl
    733bdd203f46:	24 01                	and    al,0x1
    733bdd203f48:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd203f4e:	83 fa 00             	cmp    edx,0x0
    733bdd203f51:	0f 94 c1             	sete   cl
    733bdd203f54:	81 ea 28 03 01 00    	sub    edx,0x10328
    733bdd203f5a:	83 fa 46             	cmp    edx,0x46
    733bdd203f5d:	0f 97 c2             	seta   dl
    733bdd203f60:	08 d1                	or     cl,dl
    733bdd203f62:	20 c8                	and    al,cl
    733bdd203f64:	a8 01                	test   al,0x1
    733bdd203f66:	75 05                	jne    0x733bdd203f6d
    733bdd203f68:	e9 79 26 00 00       	jmp    0x733bdd2065e6
    733bdd203f6d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd203f74:	00 
    733bdd203f75:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd203f7c:	48 89 c8             	mov    rax,rcx
    733bdd203f7f:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd203f85:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    733bdd203f8c:	00 
    733bdd203f8d:	8b 81 0c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10000c]
    733bdd203f93:	83 c0 01             	add    eax,0x1
    733bdd203f96:	89 81 0c 00 10 00    	mov    DWORD PTR [rcx+0x10000c],eax
    733bdd203f9c:	3d c1 c5 00 00       	cmp    eax,0xc5c1
    733bdd203fa1:	75 4c                	jne    0x733bdd203fef
    733bdd203fa3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    733bdd203faa:	00 
    733bdd203fab:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd203fb1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    733bdd203fb8:	89 c2                	mov    edx,eax
    733bdd203fba:	83 c2 01             	add    edx,0x1
    733bdd203fbd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd203fc3:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd203fc8:	73 23                	jae    0x733bdd203fed
    733bdd203fca:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    733bdd203fd1:	00 
    733bdd203fd2:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    733bdd203fd9:	89 c9                	mov    ecx,ecx
    733bdd203fdb:	48 c1 e1 02          	shl    rcx,0x2
    733bdd203fdf:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd203fe6:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    733bdd203fed:	eb 00                	jmp    0x733bdd203fef
    733bdd203fef:	eb 00                	jmp    0x733bdd203ff1
    733bdd203ff1:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd203ff8:	00 
    733bdd203ff9:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd203ffc:	83 e8 04             	sub    eax,0x4
    733bdd203fff:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    733bdd204006:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    733bdd204009:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    733bdd204010:	83 e0 03             	and    eax,0x3
    733bdd204013:	83 f8 00             	cmp    eax,0x0
    733bdd204016:	0f 84 8e 00 00 00    	je     0x733bdd2040aa
    733bdd20401c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204023:	00 
    733bdd204024:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd20402b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd204032:	00 
    733bdd204033:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20403a:	00 00 00 
    733bdd20403d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd204044:	00 00 00 
    733bdd204047:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20404e:	59 00 00 
    733bdd204051:	ba 28 03 01 00       	mov    edx,0x10328
    733bdd204056:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20405c:	ff d0                	call   rax
    733bdd20405e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204065:	00 
    733bdd204066:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20406c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204072:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204078:	be 01 00 00 00       	mov    esi,0x1
    733bdd20407d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd204082:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204089:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204090:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204097:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20409e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2040a5:	e9 20 28 00 00       	jmp    0x733bdd2068ca
    733bdd2040aa:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2040b1:	00 
    733bdd2040b2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd2040b9:	c1 e9 0c             	shr    ecx,0xc
    733bdd2040bc:	89 c9                	mov    ecx,ecx
    733bdd2040be:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2040c2:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    733bdd2040c9:	00 
    733bdd2040ca:	48 83 f8 00          	cmp    rax,0x0
    733bdd2040ce:	74 23                	je     0x733bdd2040f3
    733bdd2040d0:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    733bdd2040d7:	00 
    733bdd2040d8:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    733bdd2040df:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd2040e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2040ec:	89 c9                	mov    ecx,ecx
    733bdd2040ee:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2040f1:	eb 51                	jmp    0x733bdd204144
    733bdd2040f3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2040fa:	00 
    733bdd2040fb:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    733bdd204102:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    733bdd204109:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd204110:	00 
    733bdd204111:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd204118:	00 00 00 
    733bdd20411b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd204122:	00 00 00 
    733bdd204125:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20412c:	59 00 00 
    733bdd20412f:	ff d0                	call   rax
    733bdd204131:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204138:	00 
    733bdd204139:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd204140:	75 32                	jne    0x733bdd204174
    733bdd204142:	eb 7c                	jmp    0x733bdd2041c0
    733bdd204144:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20414b:	00 
    733bdd20414c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    733bdd204153:	83 e8 04             	sub    eax,0x4
    733bdd204156:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    733bdd20415d:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    733bdd204160:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    733bdd204167:	83 e0 03             	and    eax,0x3
    733bdd20416a:	83 f8 00             	cmp    eax,0x0
    733bdd20416d:	75 53                	jne    0x733bdd2041c2
    733bdd20416f:	e9 dc 00 00 00       	jmp    0x733bdd204250
    733bdd204174:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20417b:	00 
    733bdd20417c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204182:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204188:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20418e:	be 01 00 00 00       	mov    esi,0x1
    733bdd204193:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd204198:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20419f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2041a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2041ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2041b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2041bb:	e9 0a 27 00 00       	jmp    0x733bdd2068ca
    733bdd2041c0:	eb 82                	jmp    0x733bdd204144
    733bdd2041c2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2041c9:	00 
    733bdd2041ca:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd2041d1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2041d8:	00 
    733bdd2041d9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2041e0:	00 00 00 
    733bdd2041e3:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd2041ea:	00 00 00 
    733bdd2041ed:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2041f4:	59 00 00 
    733bdd2041f7:	ba 28 03 01 00       	mov    edx,0x10328
    733bdd2041fc:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd204202:	ff d0                	call   rax
    733bdd204204:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20420b:	00 
    733bdd20420c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204212:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204218:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20421e:	be 01 00 00 00       	mov    esi,0x1
    733bdd204223:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd204228:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20422f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204236:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20423d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204244:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20424b:	e9 7a 26 00 00       	jmp    0x733bdd2068ca
    733bdd204250:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd204257:	00 
    733bdd204258:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd20425f:	c1 e9 0c             	shr    ecx,0xc
    733bdd204262:	89 c9                	mov    ecx,ecx
    733bdd204264:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd204268:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    733bdd20426f:	00 
    733bdd204270:	48 83 f8 00          	cmp    rax,0x0
    733bdd204274:	74 23                	je     0x733bdd204299
    733bdd204276:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    733bdd20427d:	00 
    733bdd20427e:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    733bdd204285:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd20428c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd204292:	89 c9                	mov    ecx,ecx
    733bdd204294:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd204297:	eb 51                	jmp    0x733bdd2042ea
    733bdd204299:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2042a0:	00 
    733bdd2042a1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    733bdd2042a8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    733bdd2042af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2042b6:	00 
    733bdd2042b7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2042be:	00 00 00 
    733bdd2042c1:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd2042c8:	00 00 00 
    733bdd2042cb:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2042d2:	59 00 00 
    733bdd2042d5:	ff d0                	call   rax
    733bdd2042d7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2042de:	00 
    733bdd2042df:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2042e6:	75 32                	jne    0x733bdd20431a
    733bdd2042e8:	eb 7c                	jmp    0x733bdd204366
    733bdd2042ea:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2042f1:	00 
    733bdd2042f2:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    733bdd2042f9:	83 e8 04             	sub    eax,0x4
    733bdd2042fc:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    733bdd204303:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    733bdd204306:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    733bdd20430d:	83 e0 03             	and    eax,0x3
    733bdd204310:	83 f8 00             	cmp    eax,0x0
    733bdd204313:	75 53                	jne    0x733bdd204368
    733bdd204315:	e9 dc 00 00 00       	jmp    0x733bdd2043f6
    733bdd20431a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204321:	00 
    733bdd204322:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204328:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20432e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204334:	be 01 00 00 00       	mov    esi,0x1
    733bdd204339:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20433e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204345:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20434c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204353:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20435a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204361:	e9 64 25 00 00       	jmp    0x733bdd2068ca
    733bdd204366:	eb 82                	jmp    0x733bdd2042ea
    733bdd204368:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20436f:	00 
    733bdd204370:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd204377:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd20437e:	00 
    733bdd20437f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd204386:	00 00 00 
    733bdd204389:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd204390:	00 00 00 
    733bdd204393:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20439a:	59 00 00 
    733bdd20439d:	ba 28 03 01 00       	mov    edx,0x10328
    733bdd2043a2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2043a8:	ff d0                	call   rax
    733bdd2043aa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2043b1:	00 
    733bdd2043b2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2043b8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2043be:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2043c4:	be 01 00 00 00       	mov    esi,0x1
    733bdd2043c9:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2043ce:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2043d5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2043dc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2043e3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2043ea:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2043f1:	e9 d4 24 00 00       	jmp    0x733bdd2068ca
    733bdd2043f6:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2043fd:	00 
    733bdd2043fe:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd204405:	c1 e9 0c             	shr    ecx,0xc
    733bdd204408:	89 c9                	mov    ecx,ecx
    733bdd20440a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20440e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    733bdd204415:	00 
    733bdd204416:	48 83 f8 00          	cmp    rax,0x0
    733bdd20441a:	74 23                	je     0x733bdd20443f
    733bdd20441c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    733bdd204423:	00 
    733bdd204424:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    733bdd20442b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd204432:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd204438:	89 c9                	mov    ecx,ecx
    733bdd20443a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20443d:	eb 51                	jmp    0x733bdd204490
    733bdd20443f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204446:	00 
    733bdd204447:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    733bdd20444e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    733bdd204455:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd20445c:	00 
    733bdd20445d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd204464:	00 00 00 
    733bdd204467:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd20446e:	00 00 00 
    733bdd204471:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd204478:	59 00 00 
    733bdd20447b:	ff d0                	call   rax
    733bdd20447d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204484:	00 
    733bdd204485:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20448c:	75 32                	jne    0x733bdd2044c0
    733bdd20448e:	eb 7c                	jmp    0x733bdd20450c
    733bdd204490:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd204497:	00 
    733bdd204498:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    733bdd20449f:	83 e8 04             	sub    eax,0x4
    733bdd2044a2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    733bdd2044a9:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    733bdd2044ac:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    733bdd2044b3:	83 e0 03             	and    eax,0x3
    733bdd2044b6:	83 f8 00             	cmp    eax,0x0
    733bdd2044b9:	75 53                	jne    0x733bdd20450e
    733bdd2044bb:	e9 dc 00 00 00       	jmp    0x733bdd20459c
    733bdd2044c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2044c7:	00 
    733bdd2044c8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2044ce:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2044d4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2044da:	be 01 00 00 00       	mov    esi,0x1
    733bdd2044df:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2044e4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2044eb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2044f2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2044f9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204500:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204507:	e9 be 23 00 00       	jmp    0x733bdd2068ca
    733bdd20450c:	eb 82                	jmp    0x733bdd204490
    733bdd20450e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204515:	00 
    733bdd204516:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd20451d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd204524:	00 
    733bdd204525:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20452c:	00 00 00 
    733bdd20452f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd204536:	00 00 00 
    733bdd204539:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd204540:	59 00 00 
    733bdd204543:	ba 28 03 01 00       	mov    edx,0x10328
    733bdd204548:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20454e:	ff d0                	call   rax
    733bdd204550:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204557:	00 
    733bdd204558:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20455e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204564:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20456a:	be 01 00 00 00       	mov    esi,0x1
    733bdd20456f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd204574:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20457b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204582:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204589:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204590:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204597:	e9 2e 23 00 00       	jmp    0x733bdd2068ca
    733bdd20459c:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2045a3:	00 
    733bdd2045a4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd2045ab:	c1 e9 0c             	shr    ecx,0xc
    733bdd2045ae:	89 c9                	mov    ecx,ecx
    733bdd2045b0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2045b4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    733bdd2045bb:	00 
    733bdd2045bc:	48 83 f8 00          	cmp    rax,0x0
    733bdd2045c0:	74 23                	je     0x733bdd2045e5
    733bdd2045c2:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd2045c9:	00 
    733bdd2045ca:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    733bdd2045d1:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd2045d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2045de:	89 c9                	mov    ecx,ecx
    733bdd2045e0:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2045e3:	eb 51                	jmp    0x733bdd204636
    733bdd2045e5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2045ec:	00 
    733bdd2045ed:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    733bdd2045f4:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    733bdd2045fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd204602:	00 
    733bdd204603:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20460a:	00 00 00 
    733bdd20460d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd204614:	00 00 00 
    733bdd204617:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20461e:	59 00 00 
    733bdd204621:	ff d0                	call   rax
    733bdd204623:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20462a:	00 
    733bdd20462b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd204632:	75 32                	jne    0x733bdd204666
    733bdd204634:	eb 7c                	jmp    0x733bdd2046b2
    733bdd204636:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20463d:	00 
    733bdd20463e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    733bdd204645:	83 e8 04             	sub    eax,0x4
    733bdd204648:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    733bdd20464f:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    733bdd204652:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    733bdd204659:	83 e0 03             	and    eax,0x3
    733bdd20465c:	83 f8 00             	cmp    eax,0x0
    733bdd20465f:	75 53                	jne    0x733bdd2046b4
    733bdd204661:	e9 dc 00 00 00       	jmp    0x733bdd204742
    733bdd204666:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20466d:	00 
    733bdd20466e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204674:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20467a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204680:	be 01 00 00 00       	mov    esi,0x1
    733bdd204685:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20468a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204691:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204698:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20469f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2046a6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2046ad:	e9 18 22 00 00       	jmp    0x733bdd2068ca
    733bdd2046b2:	eb 82                	jmp    0x733bdd204636
    733bdd2046b4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2046bb:	00 
    733bdd2046bc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd2046c3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2046ca:	00 
    733bdd2046cb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2046d2:	00 00 00 
    733bdd2046d5:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd2046dc:	00 00 00 
    733bdd2046df:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2046e6:	59 00 00 
    733bdd2046e9:	ba 28 03 01 00       	mov    edx,0x10328
    733bdd2046ee:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2046f4:	ff d0                	call   rax
    733bdd2046f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2046fd:	00 
    733bdd2046fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204704:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20470a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204710:	be 01 00 00 00       	mov    esi,0x1
    733bdd204715:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20471a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204721:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204728:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20472f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204736:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20473d:	e9 88 21 00 00       	jmp    0x733bdd2068ca
    733bdd204742:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd204749:	00 
    733bdd20474a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd204751:	c1 e9 0c             	shr    ecx,0xc
    733bdd204754:	89 c9                	mov    ecx,ecx
    733bdd204756:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20475a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    733bdd204761:	00 
    733bdd204762:	48 83 f8 00          	cmp    rax,0x0
    733bdd204766:	74 23                	je     0x733bdd20478b
    733bdd204768:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    733bdd20476f:	00 
    733bdd204770:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    733bdd204777:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd20477e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd204784:	89 c9                	mov    ecx,ecx
    733bdd204786:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd204789:	eb 51                	jmp    0x733bdd2047dc
    733bdd20478b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204792:	00 
    733bdd204793:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    733bdd20479a:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    733bdd2047a1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2047a8:	00 
    733bdd2047a9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2047b0:	00 00 00 
    733bdd2047b3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd2047ba:	00 00 00 
    733bdd2047bd:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2047c4:	59 00 00 
    733bdd2047c7:	ff d0                	call   rax
    733bdd2047c9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2047d0:	00 
    733bdd2047d1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2047d8:	75 26                	jne    0x733bdd204800
    733bdd2047da:	eb 70                	jmp    0x733bdd20484c
    733bdd2047dc:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd2047e3:	00 
    733bdd2047e4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2047eb:	00 
    733bdd2047ec:	8b 94 24 88 01 00 00 	mov    edx,DWORD PTR [rsp+0x188]
    733bdd2047f3:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd2047f6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2047f9:	75 53                	jne    0x733bdd20484e
    733bdd2047fb:	e9 93 00 00 00       	jmp    0x733bdd204893
    733bdd204800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204807:	00 
    733bdd204808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20480e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20481a:	be 01 00 00 00       	mov    esi,0x1
    733bdd20481f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd204824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20482b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204847:	e9 7e 20 00 00       	jmp    0x733bdd2068ca
    733bdd20484c:	eb 8e                	jmp    0x733bdd2047dc
    733bdd20484e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204855:	00 
    733bdd204856:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    733bdd20485d:	03 01 00 
    733bdd204860:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd204867:	00 00 00 
    733bdd20486a:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd204871:	00 00 00 
    733bdd204874:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20487b:	59 00 00 
    733bdd20487e:	ff d0                	call   rax
    733bdd204880:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204887:	00 
    733bdd204888:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20488f:	75 04                	jne    0x733bdd204895
    733bdd204891:	eb 4e                	jmp    0x733bdd2048e1
    733bdd204893:	eb 4e                	jmp    0x733bdd2048e3
    733bdd204895:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20489c:	00 
    733bdd20489d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2048a3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2048a9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2048af:	be 01 00 00 00       	mov    esi,0x1
    733bdd2048b4:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2048b9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2048c0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2048c7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2048ce:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2048d5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2048dc:	e9 e9 1f 00 00       	jmp    0x733bdd2068ca
    733bdd2048e1:	eb b0                	jmp    0x733bdd204893
    733bdd2048e3:	eb 00                	jmp    0x733bdd2048e5
    733bdd2048e5:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    733bdd2048ec:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2048f3:	00 
    733bdd2048f4:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd2048fa:	89 94 24 74 01 00 00 	mov    DWORD PTR [rsp+0x174],edx
    733bdd204901:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd204904:	89 8c 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],ecx
    733bdd20490b:	83 e8 04             	sub    eax,0x4
    733bdd20490e:	89 84 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],eax
    733bdd204915:	83 e0 03             	and    eax,0x3
    733bdd204918:	83 f8 00             	cmp    eax,0x0
    733bdd20491b:	0f 84 98 00 00 00    	je     0x733bdd2049b9
    733bdd204921:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204928:	00 
    733bdd204929:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    733bdd204930:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd204937:	00 
    733bdd204938:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    733bdd20493f:	03 01 00 
    733bdd204942:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd204949:	00 00 00 
    733bdd20494c:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd204953:	00 00 00 
    733bdd204956:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20495d:	59 00 00 
    733bdd204960:	ba 2a 03 01 00       	mov    edx,0x1032a
    733bdd204965:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20496b:	ff d0                	call   rax
    733bdd20496d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204974:	00 
    733bdd204975:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20497b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204981:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204987:	be 02 00 00 00       	mov    esi,0x2
    733bdd20498c:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204991:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204998:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20499f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2049a6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2049ad:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2049b4:	e9 11 1f 00 00       	jmp    0x733bdd2068ca
    733bdd2049b9:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2049c0:	00 
    733bdd2049c1:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    733bdd2049c8:	c1 e9 0c             	shr    ecx,0xc
    733bdd2049cb:	89 c9                	mov    ecx,ecx
    733bdd2049cd:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2049d1:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    733bdd2049d8:	00 
    733bdd2049d9:	48 83 f8 00          	cmp    rax,0x0
    733bdd2049dd:	74 23                	je     0x733bdd204a02
    733bdd2049df:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    733bdd2049e6:	00 
    733bdd2049e7:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    733bdd2049ee:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    733bdd2049f5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2049fb:	89 c9                	mov    ecx,ecx
    733bdd2049fd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd204a00:	eb 5b                	jmp    0x733bdd204a5d
    733bdd204a02:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204a09:	00 
    733bdd204a0a:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    733bdd204a11:	8b b4 24 7c 01 00 00 	mov    esi,DWORD PTR [rsp+0x17c]
    733bdd204a18:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd204a1f:	00 
    733bdd204a20:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    733bdd204a27:	03 01 00 
    733bdd204a2a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd204a31:	00 00 00 
    733bdd204a34:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd204a3b:	00 00 00 
    733bdd204a3e:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd204a45:	59 00 00 
    733bdd204a48:	ff d0                	call   rax
    733bdd204a4a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204a51:	00 
    733bdd204a52:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd204a59:	75 20                	jne    0x733bdd204a7b
    733bdd204a5b:	eb 6a                	jmp    0x733bdd204ac7
    733bdd204a5d:	8b 84 24 7c 01 00 00 	mov    eax,DWORD PTR [rsp+0x17c]
    733bdd204a64:	83 e8 04             	sub    eax,0x4
    733bdd204a67:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    733bdd204a6e:	83 e0 03             	and    eax,0x3
    733bdd204a71:	83 f8 00             	cmp    eax,0x0
    733bdd204a74:	75 53                	jne    0x733bdd204ac9
    733bdd204a76:	e9 e6 00 00 00       	jmp    0x733bdd204b61
    733bdd204a7b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204a82:	00 
    733bdd204a83:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204a89:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204a8f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204a95:	be 02 00 00 00       	mov    esi,0x2
    733bdd204a9a:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204a9f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204aa6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204aad:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204ab4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204abb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204ac2:	e9 03 1e 00 00       	jmp    0x733bdd2068ca
    733bdd204ac7:	eb 94                	jmp    0x733bdd204a5d
    733bdd204ac9:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204ad0:	00 
    733bdd204ad1:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd204ad8:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd204adf:	00 
    733bdd204ae0:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    733bdd204ae7:	03 01 00 
    733bdd204aea:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd204af1:	00 00 00 
    733bdd204af4:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd204afb:	00 00 00 
    733bdd204afe:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd204b05:	59 00 00 
    733bdd204b08:	ba 2a 03 01 00       	mov    edx,0x1032a
    733bdd204b0d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd204b13:	ff d0                	call   rax
    733bdd204b15:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204b1c:	00 
    733bdd204b1d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204b23:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204b29:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204b2f:	be 02 00 00 00       	mov    esi,0x2
    733bdd204b34:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204b39:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204b40:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204b47:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204b4e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204b55:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204b5c:	e9 69 1d 00 00       	jmp    0x733bdd2068ca
    733bdd204b61:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd204b68:	00 
    733bdd204b69:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd204b70:	c1 e9 0c             	shr    ecx,0xc
    733bdd204b73:	89 c9                	mov    ecx,ecx
    733bdd204b75:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd204b79:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
    733bdd204b80:	00 
    733bdd204b81:	48 83 f8 00          	cmp    rax,0x0
    733bdd204b85:	74 23                	je     0x733bdd204baa
    733bdd204b87:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    733bdd204b8e:	00 
    733bdd204b8f:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    733bdd204b96:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd204b9d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd204ba3:	89 c9                	mov    ecx,ecx
    733bdd204ba5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd204ba8:	eb 5b                	jmp    0x733bdd204c05
    733bdd204baa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204bb1:	00 
    733bdd204bb2:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    733bdd204bb9:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    733bdd204bc0:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd204bc7:	00 
    733bdd204bc8:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    733bdd204bcf:	03 01 00 
    733bdd204bd2:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd204bd9:	00 00 00 
    733bdd204bdc:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd204be3:	00 00 00 
    733bdd204be6:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd204bed:	59 00 00 
    733bdd204bf0:	ff d0                	call   rax
    733bdd204bf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204bf9:	00 
    733bdd204bfa:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd204c01:	75 2c                	jne    0x733bdd204c2f
    733bdd204c03:	eb 76                	jmp    0x733bdd204c7b
    733bdd204c05:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd204c0c:	00 
    733bdd204c0d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd204c14:	00 
    733bdd204c15:	8b 94 24 64 01 00 00 	mov    edx,DWORD PTR [rsp+0x164]
    733bdd204c1c:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd204c1f:	83 ea 00             	sub    edx,0x0
    733bdd204c22:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd204c25:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd204c28:	75 53                	jne    0x733bdd204c7d
    733bdd204c2a:	e9 93 00 00 00       	jmp    0x733bdd204cc2
    733bdd204c2f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204c36:	00 
    733bdd204c37:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204c3d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204c43:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204c49:	be 02 00 00 00       	mov    esi,0x2
    733bdd204c4e:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204c53:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204c5a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204c61:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204c68:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204c6f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204c76:	e9 4f 1c 00 00       	jmp    0x733bdd2068ca
    733bdd204c7b:	eb 88                	jmp    0x733bdd204c05
    733bdd204c7d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204c84:	00 
    733bdd204c85:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1032e
    733bdd204c8c:	03 01 00 
    733bdd204c8f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd204c96:	00 00 00 
    733bdd204c99:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    733bdd204ca0:	00 00 00 
    733bdd204ca3:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd204caa:	59 00 00 
    733bdd204cad:	ff d0                	call   rax
    733bdd204caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204cb6:	00 
    733bdd204cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd204cbe:	75 04                	jne    0x733bdd204cc4
    733bdd204cc0:	eb 4e                	jmp    0x733bdd204d10
    733bdd204cc2:	eb 4e                	jmp    0x733bdd204d12
    733bdd204cc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204ccb:	00 
    733bdd204ccc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd204cd2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd204cd8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd204cde:	be 02 00 00 00       	mov    esi,0x2
    733bdd204ce3:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204ce8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd204cef:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd204cf6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd204cfd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd204d04:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd204d0b:	e9 ba 1b 00 00       	jmp    0x733bdd2068ca
    733bdd204d10:	eb b0                	jmp    0x733bdd204cc2
    733bdd204d12:	eb 00                	jmp    0x733bdd204d14
    733bdd204d14:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204d1b:	00 
    733bdd204d1c:	8b 38                	mov    edi,DWORD PTR [rax]
    733bdd204d1e:	89 bc 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edi
    733bdd204d25:	83 ff 04             	cmp    edi,0x4
    733bdd204d28:	0f 96 c1             	setbe  cl
    733bdd204d2b:	80 e1 01             	and    cl,0x1
    733bdd204d2e:	0f b6 c9             	movzx  ecx,cl
    733bdd204d31:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd204d38:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    733bdd204d3e:	83 ff 04             	cmp    edi,0x4
    733bdd204d41:	0f 94 c1             	sete   cl
    733bdd204d44:	80 e1 01             	and    cl,0x1
    733bdd204d47:	0f b6 f1             	movzx  esi,cl
    733bdd204d4a:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204d4f:	39 f9                	cmp    ecx,edi
    733bdd204d51:	0f 97 c1             	seta   cl
    733bdd204d54:	80 e1 01             	and    cl,0x1
    733bdd204d57:	0f b6 d1             	movzx  edx,cl
    733bdd204d5a:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd204d5f:	39 f9                	cmp    ecx,edi
    733bdd204d61:	0f 96 c1             	setbe  cl
    733bdd204d64:	80 e1 01             	and    cl,0x1
    733bdd204d67:	0f b6 c9             	movzx  ecx,cl
    733bdd204d6a:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd204d70:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd204d76:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd204d7c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd204d82:	eb 00                	jmp    0x733bdd204d84
    733bdd204d84:	8b 84 24 54 01 00 00 	mov    eax,DWORD PTR [rsp+0x154]
    733bdd204d8b:	83 f8 00             	cmp    eax,0x0
    733bdd204d8e:	75 33                	jne    0x733bdd204dc3
    733bdd204d90:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd204d97:	00 
    733bdd204d98:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    733bdd204d9f:	03 01 00 
    733bdd204da2:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd204da8:	83 c0 04             	add    eax,0x4
    733bdd204dab:	89 84 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],eax
    733bdd204db2:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd204db8:	0f 82 3c 18 00 00    	jb     0x733bdd2065fa
    733bdd204dbe:	e9 5a 18 00 00       	jmp    0x733bdd20661d
    733bdd204dc3:	eb 00                	jmp    0x733bdd204dc5
    733bdd204dc5:	eb 00                	jmp    0x733bdd204dc7
    733bdd204dc7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204dce:	00 
    733bdd204dcf:	8b 78 04             	mov    edi,DWORD PTR [rax+0x4]
    733bdd204dd2:	89 bc 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],edi
    733bdd204dd9:	89 fa                	mov    edx,edi
    733bdd204ddb:	83 ea 00             	sub    edx,0x0
    733bdd204dde:	83 fa 00             	cmp    edx,0x0
    733bdd204de1:	0f 94 c1             	sete   cl
    733bdd204de4:	80 e1 01             	and    cl,0x1
    733bdd204de7:	0f b6 f1             	movzx  esi,cl
    733bdd204dea:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    733bdd204df1:	c1 ea 1f             	shr    edx,0x1f
    733bdd204df4:	89 f9                	mov    ecx,edi
    733bdd204df6:	c1 e9 1f             	shr    ecx,0x1f
    733bdd204df9:	89 d3                	mov    ebx,edx
    733bdd204dfb:	31 cb                	xor    ebx,ecx
    733bdd204dfd:	83 f1 00             	xor    ecx,0x0
    733bdd204e00:	21 d9                	and    ecx,ebx
    733bdd204e02:	31 ca                	xor    edx,ecx
    733bdd204e04:	31 c9                	xor    ecx,ecx
    733bdd204e06:	39 f9                	cmp    ecx,edi
    733bdd204e08:	0f 96 c1             	setbe  cl
    733bdd204e0b:	80 e1 01             	and    cl,0x1
    733bdd204e0e:	0f b6 c9             	movzx  ecx,cl
    733bdd204e11:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd204e17:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd204e1d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd204e23:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd204e29:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd204e2f:	eb 00                	jmp    0x733bdd204e31
    733bdd204e31:	8b 84 24 48 01 00 00 	mov    eax,DWORD PTR [rsp+0x148]
    733bdd204e38:	83 f8 00             	cmp    eax,0x0
    733bdd204e3b:	74 33                	je     0x733bdd204e70
    733bdd204e3d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd204e44:	00 
    733bdd204e45:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    733bdd204e4c:	03 01 00 
    733bdd204e4f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd204e55:	83 c0 06             	add    eax,0x6
    733bdd204e58:	89 84 24 40 01 00 00 	mov    DWORD PTR [rsp+0x140],eax
    733bdd204e5f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd204e65:	0f 82 1f 18 00 00    	jb     0x733bdd20668a
    733bdd204e6b:	e9 3d 18 00 00       	jmp    0x733bdd2066ad
    733bdd204e70:	eb 00                	jmp    0x733bdd204e72
    733bdd204e72:	eb 00                	jmp    0x733bdd204e74
    733bdd204e74:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204e7b:	00 
    733bdd204e7c:	c7 40 0c 09 3d 00 00 	mov    DWORD PTR [rax+0xc],0x3d09
    733bdd204e83:	eb 00                	jmp    0x733bdd204e85
    733bdd204e85:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204e8c:	00 
    733bdd204e8d:	c7 40 0c 00 48 e8 01 	mov    DWORD PTR [rax+0xc],0x1e84800
    733bdd204e94:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    733bdd204e9b:	00 00 00 
    733bdd204e9e:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    733bdd204ea5:	00 00 00 
    733bdd204ea8:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    733bdd204eaf:	00 00 00 
    733bdd204eb2:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    733bdd204eb9:	00 00 00 
    733bdd204ebc:	eb 00                	jmp    0x733bdd204ebe
    733bdd204ebe:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204ec5:	00 
    733bdd204ec6:	8b bc 24 44 01 00 00 	mov    edi,DWORD PTR [rsp+0x144]
    733bdd204ecd:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    733bdd204ed3:	0f 96 c1             	setbe  cl
    733bdd204ed6:	80 e1 01             	and    cl,0x1
    733bdd204ed9:	0f b6 c9             	movzx  ecx,cl
    733bdd204edc:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    733bdd204ee3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    733bdd204ee9:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    733bdd204eef:	0f 94 c1             	sete   cl
    733bdd204ef2:	80 e1 01             	and    cl,0x1
    733bdd204ef5:	0f b6 f1             	movzx  esi,cl
    733bdd204ef8:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    733bdd204efd:	39 f9                	cmp    ecx,edi
    733bdd204eff:	0f 97 c1             	seta   cl
    733bdd204f02:	80 e1 01             	and    cl,0x1
    733bdd204f05:	0f b6 d1             	movzx  edx,cl
    733bdd204f08:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    733bdd204f0d:	39 f9                	cmp    ecx,edi
    733bdd204f0f:	0f 96 c1             	setbe  cl
    733bdd204f12:	80 e1 01             	and    cl,0x1
    733bdd204f15:	0f b6 c9             	movzx  ecx,cl
    733bdd204f18:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd204f1e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd204f24:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd204f2a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd204f30:	eb 00                	jmp    0x733bdd204f32
    733bdd204f32:	8b 84 24 3c 01 00 00 	mov    eax,DWORD PTR [rsp+0x13c]
    733bdd204f39:	83 f8 00             	cmp    eax,0x0
    733bdd204f3c:	75 33                	jne    0x733bdd204f71
    733bdd204f3e:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd204f45:	00 
    733bdd204f46:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    733bdd204f4d:	03 01 00 
    733bdd204f50:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd204f56:	83 c0 0a             	add    eax,0xa
    733bdd204f59:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    733bdd204f60:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd204f66:	0f 82 ae 17 00 00    	jb     0x733bdd20671a
    733bdd204f6c:	e9 cc 17 00 00       	jmp    0x733bdd20673d
    733bdd204f71:	eb 00                	jmp    0x733bdd204f73
    733bdd204f73:	eb 00                	jmp    0x733bdd204f75
    733bdd204f75:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204f7c:	00 
    733bdd204f7d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    733bdd204f80:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd204f86:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd204f8c:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    733bdd204f93:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd204f96:	eb 00                	jmp    0x733bdd204f98
    733bdd204f98:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd204f9f:	00 
    733bdd204fa0:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    733bdd204fa7:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd204fad:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    733bdd204fb3:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    733bdd204fba:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd204fbd:	eb 00                	jmp    0x733bdd204fbf
    733bdd204fbf:	8b 84 24 30 01 00 00 	mov    eax,DWORD PTR [rsp+0x130]
    733bdd204fc6:	83 e0 03             	and    eax,0x3
    733bdd204fc9:	83 f8 00             	cmp    eax,0x0
    733bdd204fcc:	0f 84 98 00 00 00    	je     0x733bdd20506a
    733bdd204fd2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd204fd9:	00 
    733bdd204fda:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    733bdd204fe1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd204fe8:	00 
    733bdd204fe9:	c7 87 bc 00 00 00 48 	mov    DWORD PTR [rdi+0xbc],0x10348
    733bdd204ff0:	03 01 00 
    733bdd204ff3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd204ffa:	00 00 00 
    733bdd204ffd:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    733bdd205004:	00 00 00 
    733bdd205007:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20500e:	59 00 00 
    733bdd205011:	ba 48 03 01 00       	mov    edx,0x10348
    733bdd205016:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20501c:	ff d0                	call   rax
    733bdd20501e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205025:	00 
    733bdd205026:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20502c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205032:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205038:	be 0d 00 00 00       	mov    esi,0xd
    733bdd20503d:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205042:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205049:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205050:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205057:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20505e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205065:	e9 60 18 00 00       	jmp    0x733bdd2068ca
    733bdd20506a:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd205071:	00 
    733bdd205072:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    733bdd205079:	c1 e9 0c             	shr    ecx,0xc
    733bdd20507c:	89 c9                	mov    ecx,ecx
    733bdd20507e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd205082:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    733bdd205089:	00 
    733bdd20508a:	48 83 f8 00          	cmp    rax,0x0
    733bdd20508e:	74 23                	je     0x733bdd2050b3
    733bdd205090:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    733bdd205097:	00 
    733bdd205098:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    733bdd20509f:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    733bdd2050a6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2050ac:	89 c9                	mov    ecx,ecx
    733bdd2050ae:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2050b1:	eb 5b                	jmp    0x733bdd20510e
    733bdd2050b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2050ba:	00 
    733bdd2050bb:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    733bdd2050c2:	8b b4 24 30 01 00 00 	mov    esi,DWORD PTR [rsp+0x130]
    733bdd2050c9:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2050d0:	00 
    733bdd2050d1:	c7 80 bc 00 00 00 48 	mov    DWORD PTR [rax+0xbc],0x10348
    733bdd2050d8:	03 01 00 
    733bdd2050db:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2050e2:	00 00 00 
    733bdd2050e5:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    733bdd2050ec:	00 00 00 
    733bdd2050ef:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2050f6:	59 00 00 
    733bdd2050f9:	ff d0                	call   rax
    733bdd2050fb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205102:	00 
    733bdd205103:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20510a:	75 14                	jne    0x733bdd205120
    733bdd20510c:	eb 5e                	jmp    0x733bdd20516c
    733bdd20510e:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd205115:	00 
    733bdd205116:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd205119:	75 53                	jne    0x733bdd20516e
    733bdd20511b:	e9 93 00 00 00       	jmp    0x733bdd2051b3
    733bdd205120:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205127:	00 
    733bdd205128:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20512e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205134:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20513a:	be 0d 00 00 00       	mov    esi,0xd
    733bdd20513f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205144:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20514b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205152:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205159:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205160:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205167:	e9 5e 17 00 00       	jmp    0x733bdd2068ca
    733bdd20516c:	eb a0                	jmp    0x733bdd20510e
    733bdd20516e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205175:	00 
    733bdd205176:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1034a
    733bdd20517d:	03 01 00 
    733bdd205180:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd205187:	00 00 00 
    733bdd20518a:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    733bdd205191:	00 00 00 
    733bdd205194:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20519b:	59 00 00 
    733bdd20519e:	ff d0                	call   rax
    733bdd2051a0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2051a7:	00 
    733bdd2051a8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2051af:	75 04                	jne    0x733bdd2051b5
    733bdd2051b1:	eb 4e                	jmp    0x733bdd205201
    733bdd2051b3:	eb 4e                	jmp    0x733bdd205203
    733bdd2051b5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2051bc:	00 
    733bdd2051bd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2051c3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2051c9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2051cf:	be 0d 00 00 00       	mov    esi,0xd
    733bdd2051d4:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2051d9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2051e0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2051e7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2051ee:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2051f5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2051fc:	e9 c9 16 00 00       	jmp    0x733bdd2068ca
    733bdd205201:	eb b0                	jmp    0x733bdd2051b3
    733bdd205203:	eb 00                	jmp    0x733bdd205205
    733bdd205205:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20520c:	00 
    733bdd20520d:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    733bdd205214:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20521a:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd205220:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    733bdd205227:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20522a:	eb 00                	jmp    0x733bdd20522c
    733bdd20522c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205233:	00 
    733bdd205234:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    733bdd20523b:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd205241:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    733bdd205247:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    733bdd20524e:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd205251:	eb 00                	jmp    0x733bdd205253
    733bdd205253:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    733bdd20525a:	83 e0 03             	and    eax,0x3
    733bdd20525d:	83 f8 00             	cmp    eax,0x0
    733bdd205260:	0f 84 98 00 00 00    	je     0x733bdd2052fe
    733bdd205266:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20526d:	00 
    733bdd20526e:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    733bdd205275:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd20527c:	00 
    733bdd20527d:	c7 87 bc 00 00 00 52 	mov    DWORD PTR [rdi+0xbc],0x10352
    733bdd205284:	03 01 00 
    733bdd205287:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20528e:	00 00 00 
    733bdd205291:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    733bdd205298:	00 00 00 
    733bdd20529b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2052a2:	59 00 00 
    733bdd2052a5:	ba 52 03 01 00       	mov    edx,0x10352
    733bdd2052aa:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2052b0:	ff d0                	call   rax
    733bdd2052b2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2052b9:	00 
    733bdd2052ba:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2052c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2052c6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2052cc:	be 10 00 00 00       	mov    esi,0x10
    733bdd2052d1:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2052d6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2052dd:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2052e4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2052eb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2052f2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2052f9:	e9 cc 15 00 00       	jmp    0x733bdd2068ca
    733bdd2052fe:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd205305:	00 
    733bdd205306:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    733bdd20530d:	c1 e9 0c             	shr    ecx,0xc
    733bdd205310:	89 c9                	mov    ecx,ecx
    733bdd205312:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd205316:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    733bdd20531d:	00 
    733bdd20531e:	48 83 f8 00          	cmp    rax,0x0
    733bdd205322:	74 23                	je     0x733bdd205347
    733bdd205324:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    733bdd20532b:	00 
    733bdd20532c:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    733bdd205333:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    733bdd20533a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd205340:	89 c9                	mov    ecx,ecx
    733bdd205342:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd205345:	eb 5b                	jmp    0x733bdd2053a2
    733bdd205347:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20534e:	00 
    733bdd20534f:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    733bdd205356:	8b b4 24 20 01 00 00 	mov    esi,DWORD PTR [rsp+0x120]
    733bdd20535d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd205364:	00 
    733bdd205365:	c7 80 bc 00 00 00 52 	mov    DWORD PTR [rax+0xbc],0x10352
    733bdd20536c:	03 01 00 
    733bdd20536f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd205376:	00 00 00 
    733bdd205379:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    733bdd205380:	00 00 00 
    733bdd205383:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20538a:	59 00 00 
    733bdd20538d:	ff d0                	call   rax
    733bdd20538f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205396:	00 
    733bdd205397:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20539e:	75 14                	jne    0x733bdd2053b4
    733bdd2053a0:	eb 5e                	jmp    0x733bdd205400
    733bdd2053a2:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd2053a9:	00 
    733bdd2053aa:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2053ad:	75 53                	jne    0x733bdd205402
    733bdd2053af:	e9 93 00 00 00       	jmp    0x733bdd205447
    733bdd2053b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2053bb:	00 
    733bdd2053bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2053c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2053c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2053ce:	be 10 00 00 00       	mov    esi,0x10
    733bdd2053d3:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2053d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2053df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2053e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2053ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2053f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2053fb:	e9 ca 14 00 00       	jmp    0x733bdd2068ca
    733bdd205400:	eb a0                	jmp    0x733bdd2053a2
    733bdd205402:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205409:	00 
    733bdd20540a:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10354
    733bdd205411:	03 01 00 
    733bdd205414:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20541b:	00 00 00 
    733bdd20541e:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    733bdd205425:	00 00 00 
    733bdd205428:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd20542f:	59 00 00 
    733bdd205432:	ff d0                	call   rax
    733bdd205434:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20543b:	00 
    733bdd20543c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd205443:	75 04                	jne    0x733bdd205449
    733bdd205445:	eb 4e                	jmp    0x733bdd205495
    733bdd205447:	eb 4e                	jmp    0x733bdd205497
    733bdd205449:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205450:	00 
    733bdd205451:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205457:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20545d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205463:	be 10 00 00 00       	mov    esi,0x10
    733bdd205468:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20546d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205474:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20547b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205482:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205489:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205490:	e9 35 14 00 00       	jmp    0x733bdd2068ca
    733bdd205495:	eb b0                	jmp    0x733bdd205447
    733bdd205497:	eb 00                	jmp    0x733bdd205499
    733bdd205499:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2054a0:	00 
    733bdd2054a1:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    733bdd2054a8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd2054ae:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd2054b4:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    733bdd2054bb:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2054be:	eb 00                	jmp    0x733bdd2054c0
    733bdd2054c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2054c7:	00 
    733bdd2054c8:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    733bdd2054cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2054d5:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    733bdd2054db:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    733bdd2054e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2054e5:	eb 00                	jmp    0x733bdd2054e7
    733bdd2054e7:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    733bdd2054ee:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2054f5:	00 
    733bdd2054f6:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    733bdd2054f9:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    733bdd205500:	83 e0 03             	and    eax,0x3
    733bdd205503:	83 f8 00             	cmp    eax,0x0
    733bdd205506:	0f 84 98 00 00 00    	je     0x733bdd2055a4
    733bdd20550c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205513:	00 
    733bdd205514:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd20551b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd205522:	00 
    733bdd205523:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1035c
    733bdd20552a:	03 01 00 
    733bdd20552d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd205534:	00 00 00 
    733bdd205537:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    733bdd20553e:	00 00 00 
    733bdd205541:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd205548:	59 00 00 
    733bdd20554b:	ba 5c 03 01 00       	mov    edx,0x1035c
    733bdd205550:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd205556:	ff d0                	call   rax
    733bdd205558:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20555f:	00 
    733bdd205560:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205566:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20556c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205572:	be 13 00 00 00       	mov    esi,0x13
    733bdd205577:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20557c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205583:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20558a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205591:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205598:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20559f:	e9 26 13 00 00       	jmp    0x733bdd2068ca
    733bdd2055a4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2055ab:	00 
    733bdd2055ac:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd2055b3:	c1 e9 0c             	shr    ecx,0xc
    733bdd2055b6:	89 c9                	mov    ecx,ecx
    733bdd2055b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2055bc:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    733bdd2055c3:	00 
    733bdd2055c4:	48 83 f8 00          	cmp    rax,0x0
    733bdd2055c8:	74 23                	je     0x733bdd2055ed
    733bdd2055ca:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd2055d1:	00 
    733bdd2055d2:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    733bdd2055d9:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd2055e0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2055e6:	89 c9                	mov    ecx,ecx
    733bdd2055e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2055eb:	eb 5b                	jmp    0x733bdd205648
    733bdd2055ed:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2055f4:	00 
    733bdd2055f5:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    733bdd2055fc:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    733bdd205603:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd20560a:	00 
    733bdd20560b:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1035c
    733bdd205612:	03 01 00 
    733bdd205615:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20561c:	00 00 00 
    733bdd20561f:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    733bdd205626:	00 00 00 
    733bdd205629:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd205630:	59 00 00 
    733bdd205633:	ff d0                	call   rax
    733bdd205635:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20563c:	00 
    733bdd20563d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd205644:	75 14                	jne    0x733bdd20565a
    733bdd205646:	eb 5e                	jmp    0x733bdd2056a6
    733bdd205648:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd20564f:	00 
    733bdd205650:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd205653:	75 53                	jne    0x733bdd2056a8
    733bdd205655:	e9 93 00 00 00       	jmp    0x733bdd2056ed
    733bdd20565a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205661:	00 
    733bdd205662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20566e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205674:	be 13 00 00 00       	mov    esi,0x13
    733bdd205679:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20567e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20568c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20569a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2056a1:	e9 24 12 00 00       	jmp    0x733bdd2068ca
    733bdd2056a6:	eb a0                	jmp    0x733bdd205648
    733bdd2056a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2056af:	00 
    733bdd2056b0:	c7 87 bc 00 00 00 5e 	mov    DWORD PTR [rdi+0xbc],0x1035e
    733bdd2056b7:	03 01 00 
    733bdd2056ba:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2056c1:	00 00 00 
    733bdd2056c4:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    733bdd2056cb:	00 00 00 
    733bdd2056ce:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd2056d5:	59 00 00 
    733bdd2056d8:	ff d0                	call   rax
    733bdd2056da:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2056e1:	00 
    733bdd2056e2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2056e9:	75 04                	jne    0x733bdd2056ef
    733bdd2056eb:	eb 4e                	jmp    0x733bdd20573b
    733bdd2056ed:	eb 4e                	jmp    0x733bdd20573d
    733bdd2056ef:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2056f6:	00 
    733bdd2056f7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2056fd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205703:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205709:	be 13 00 00 00       	mov    esi,0x13
    733bdd20570e:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205713:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20571a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205721:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205728:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20572f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205736:	e9 8f 11 00 00       	jmp    0x733bdd2068ca
    733bdd20573b:	eb b0                	jmp    0x733bdd2056ed
    733bdd20573d:	eb 00                	jmp    0x733bdd20573f
    733bdd20573f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205746:	00 
    733bdd205747:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    733bdd20574e:	89 fa                	mov    edx,edi
    733bdd205750:	83 ea 02             	sub    edx,0x2
    733bdd205753:	83 fa 00             	cmp    edx,0x0
    733bdd205756:	0f 94 c1             	sete   cl
    733bdd205759:	80 e1 01             	and    cl,0x1
    733bdd20575c:	0f b6 f1             	movzx  esi,cl
    733bdd20575f:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    733bdd205766:	c1 ea 1f             	shr    edx,0x1f
    733bdd205769:	89 f9                	mov    ecx,edi
    733bdd20576b:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20576e:	89 d3                	mov    ebx,edx
    733bdd205770:	31 cb                	xor    ebx,ecx
    733bdd205772:	83 f1 00             	xor    ecx,0x0
    733bdd205775:	21 d9                	and    ecx,ebx
    733bdd205777:	31 ca                	xor    edx,ecx
    733bdd205779:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20577e:	39 f9                	cmp    ecx,edi
    733bdd205780:	0f 96 c1             	setbe  cl
    733bdd205783:	80 e1 01             	and    cl,0x1
    733bdd205786:	0f b6 c9             	movzx  ecx,cl
    733bdd205789:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd20578f:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd205795:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20579b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd2057a1:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd2057a7:	eb 00                	jmp    0x733bdd2057a9
    733bdd2057a9:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    733bdd2057b0:	83 f8 00             	cmp    eax,0x0
    733bdd2057b3:	74 33                	je     0x733bdd2057e8
    733bdd2057b5:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2057bc:	00 
    733bdd2057bd:	c7 81 bc 00 00 00 7a 	mov    DWORD PTR [rcx+0xbc],0x1037a
    733bdd2057c4:	03 01 00 
    733bdd2057c7:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd2057cd:	83 c0 15             	add    eax,0x15
    733bdd2057d0:	89 84 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],eax
    733bdd2057d7:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd2057dd:	0f 82 c7 0f 00 00    	jb     0x733bdd2067aa
    733bdd2057e3:	e9 e5 0f 00 00       	jmp    0x733bdd2067cd
    733bdd2057e8:	eb 00                	jmp    0x733bdd2057ea
    733bdd2057ea:	eb 00                	jmp    0x733bdd2057ec
    733bdd2057ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2057f3:	00 
    733bdd2057f4:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    733bdd2057fb:	89 fa                	mov    edx,edi
    733bdd2057fd:	83 ea 03             	sub    edx,0x3
    733bdd205800:	83 fa 00             	cmp    edx,0x0
    733bdd205803:	0f 94 c1             	sete   cl
    733bdd205806:	80 e1 01             	and    cl,0x1
    733bdd205809:	0f b6 f1             	movzx  esi,cl
    733bdd20580c:	89 b4 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],esi
    733bdd205813:	c1 ea 1f             	shr    edx,0x1f
    733bdd205816:	89 f9                	mov    ecx,edi
    733bdd205818:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20581b:	89 d3                	mov    ebx,edx
    733bdd20581d:	31 cb                	xor    ebx,ecx
    733bdd20581f:	83 f1 00             	xor    ecx,0x0
    733bdd205822:	21 d9                	and    ecx,ebx
    733bdd205824:	31 ca                	xor    edx,ecx
    733bdd205826:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd20582b:	39 f9                	cmp    ecx,edi
    733bdd20582d:	0f 96 c1             	setbe  cl
    733bdd205830:	80 e1 01             	and    cl,0x1
    733bdd205833:	0f b6 c9             	movzx  ecx,cl
    733bdd205836:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd20583c:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd205842:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd205848:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd20584e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd205854:	eb 00                	jmp    0x733bdd205856
    733bdd205856:	8b 84 24 f4 00 00 00 	mov    eax,DWORD PTR [rsp+0xf4]
    733bdd20585d:	83 f8 00             	cmp    eax,0x0
    733bdd205860:	74 33                	je     0x733bdd205895
    733bdd205862:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd205869:	00 
    733bdd20586a:	c7 81 bc 00 00 00 a4 	mov    DWORD PTR [rcx+0xbc],0x103a4
    733bdd205871:	03 01 00 
    733bdd205874:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20587a:	83 c0 17             	add    eax,0x17
    733bdd20587d:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    733bdd205884:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20588a:	0f 82 aa 0f 00 00    	jb     0x733bdd20683a
    733bdd205890:	e9 c8 0f 00 00       	jmp    0x733bdd20685d
    733bdd205895:	eb 00                	jmp    0x733bdd205897
    733bdd205897:	eb 00                	jmp    0x733bdd205899
    733bdd205899:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2058a0:	00 
    733bdd2058a1:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    733bdd2058a7:	eb 00                	jmp    0x733bdd2058a9
    733bdd2058a9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    733bdd2058b0:	83 e0 03             	and    eax,0x3
    733bdd2058b3:	83 f8 00             	cmp    eax,0x0
    733bdd2058b6:	0f 84 97 00 00 00    	je     0x733bdd205953
    733bdd2058bc:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2058c3:	00 
    733bdd2058c4:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd2058cb:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2058d2:	00 
    733bdd2058d3:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    733bdd2058da:	03 01 00 
    733bdd2058dd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2058e4:	00 00 00 
    733bdd2058e7:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    733bdd2058ee:	00 00 00 
    733bdd2058f1:	31 c0                	xor    eax,eax
    733bdd2058f3:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2058fa:	59 00 00 
    733bdd2058fd:	ba 68 03 01 00       	mov    edx,0x10368
    733bdd205902:	45 31 c0             	xor    r8d,r8d
    733bdd205905:	ff d0                	call   rax
    733bdd205907:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20590e:	00 
    733bdd20590f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205915:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20591b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205921:	be 19 00 00 00       	mov    esi,0x19
    733bdd205926:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20592b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205932:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205939:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205940:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205947:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20594e:	e9 77 0f 00 00       	jmp    0x733bdd2068ca
    733bdd205953:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd20595a:	00 
    733bdd20595b:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd205962:	c1 e9 0c             	shr    ecx,0xc
    733bdd205965:	89 c9                	mov    ecx,ecx
    733bdd205967:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20596b:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    733bdd205972:	00 
    733bdd205973:	48 83 f8 00          	cmp    rax,0x0
    733bdd205977:	74 23                	je     0x733bdd20599c
    733bdd205979:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    733bdd205980:	00 
    733bdd205981:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    733bdd205988:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20598e:	89 c9                	mov    ecx,ecx
    733bdd205990:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd205993:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    733bdd20599a:	eb 5d                	jmp    0x733bdd2059f9
    733bdd20599c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2059a3:	00 
    733bdd2059a4:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    733bdd2059ab:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2059b2:	00 
    733bdd2059b3:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    733bdd2059ba:	03 01 00 
    733bdd2059bd:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2059c4:	00 00 00 
    733bdd2059c7:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    733bdd2059ce:	00 00 00 
    733bdd2059d1:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2059d8:	59 00 00 
    733bdd2059db:	ff d0                	call   rax
    733bdd2059dd:	89 c1                	mov    ecx,eax
    733bdd2059df:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2059e6:	00 
    733bdd2059e7:	89 8c 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],ecx
    733bdd2059ee:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2059f5:	75 2e                	jne    0x733bdd205a25
    733bdd2059f7:	eb 78                	jmp    0x733bdd205a71
    733bdd2059f9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    733bdd205a00:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    733bdd205a07:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    733bdd205a0e:	83 c0 04             	add    eax,0x4
    733bdd205a11:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd205a18:	83 e0 03             	and    eax,0x3
    733bdd205a1b:	83 f8 00             	cmp    eax,0x0
    733bdd205a1e:	75 64                	jne    0x733bdd205a84
    733bdd205a20:	e9 f6 00 00 00       	jmp    0x733bdd205b1b
    733bdd205a25:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205a2c:	00 
    733bdd205a2d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205a33:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205a39:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205a3f:	be 19 00 00 00       	mov    esi,0x19
    733bdd205a44:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd205a49:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205a50:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205a57:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205a5e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205a65:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205a6c:	e9 59 0e 00 00       	jmp    0x733bdd2068ca
    733bdd205a71:	8b 84 24 e0 00 00 00 	mov    eax,DWORD PTR [rsp+0xe0]
    733bdd205a78:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    733bdd205a7f:	e9 75 ff ff ff       	jmp    0x733bdd2059f9
    733bdd205a84:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205a8b:	00 
    733bdd205a8c:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd205a93:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd205a9a:	00 
    733bdd205a9b:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    733bdd205aa2:	03 01 00 
    733bdd205aa5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd205aac:	00 00 00 
    733bdd205aaf:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    733bdd205ab6:	00 00 00 
    733bdd205ab9:	31 c0                	xor    eax,eax
    733bdd205abb:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd205ac2:	59 00 00 
    733bdd205ac5:	ba 68 03 01 00       	mov    edx,0x10368
    733bdd205aca:	45 31 c0             	xor    r8d,r8d
    733bdd205acd:	ff d0                	call   rax
    733bdd205acf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205ad6:	00 
    733bdd205ad7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205add:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205ae3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205ae9:	be 19 00 00 00       	mov    esi,0x19
    733bdd205aee:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd205af3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205afa:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205b01:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205b08:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205b0f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205b16:	e9 af 0d 00 00       	jmp    0x733bdd2068ca
    733bdd205b1b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd205b22:	00 
    733bdd205b23:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd205b2a:	c1 e9 0c             	shr    ecx,0xc
    733bdd205b2d:	89 c9                	mov    ecx,ecx
    733bdd205b2f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd205b33:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    733bdd205b3a:	00 
    733bdd205b3b:	48 83 f8 00          	cmp    rax,0x0
    733bdd205b3f:	74 23                	je     0x733bdd205b64
    733bdd205b41:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    733bdd205b48:	00 
    733bdd205b49:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd205b50:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd205b56:	89 c9                	mov    ecx,ecx
    733bdd205b58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd205b5b:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    733bdd205b62:	eb 60                	jmp    0x733bdd205bc4
    733bdd205b64:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205b6b:	00 
    733bdd205b6c:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    733bdd205b73:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd205b7a:	00 
    733bdd205b7b:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    733bdd205b82:	03 01 00 
    733bdd205b85:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd205b8c:	00 00 00 
    733bdd205b8f:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    733bdd205b96:	00 00 00 
    733bdd205b99:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd205ba0:	59 00 00 
    733bdd205ba3:	ff d0                	call   rax
    733bdd205ba5:	89 c1                	mov    ecx,eax
    733bdd205ba7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205bae:	00 
    733bdd205baf:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    733bdd205bb6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd205bbd:	75 41                	jne    0x733bdd205c00
    733bdd205bbf:	e9 88 00 00 00       	jmp    0x733bdd205c4c
    733bdd205bc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205bcb:	00 
    733bdd205bcc:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    733bdd205bd3:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    733bdd205bda:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    733bdd205be1:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    733bdd205be8:	83 c1 04             	add    ecx,0x4
    733bdd205beb:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    733bdd205bf2:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd205bf5:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd205bfb:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd205bfe:	eb 5f                	jmp    0x733bdd205c5f
    733bdd205c00:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205c07:	00 
    733bdd205c08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205c0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205c14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205c1a:	be 19 00 00 00       	mov    esi,0x19
    733bdd205c1f:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd205c24:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205c2b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205c32:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205c39:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205c40:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205c47:	e9 7e 0c 00 00       	jmp    0x733bdd2068ca
    733bdd205c4c:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    733bdd205c53:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    733bdd205c5a:	e9 65 ff ff ff       	jmp    0x733bdd205bc4
    733bdd205c5f:	eb 00                	jmp    0x733bdd205c61
    733bdd205c61:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    733bdd205c68:	83 e0 03             	and    eax,0x3
    733bdd205c6b:	83 f8 00             	cmp    eax,0x0
    733bdd205c6e:	0f 84 97 00 00 00    	je     0x733bdd205d0b
    733bdd205c74:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205c7b:	00 
    733bdd205c7c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    733bdd205c83:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd205c8a:	00 
    733bdd205c8b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    733bdd205c92:	03 01 00 
    733bdd205c95:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd205c9c:	00 00 00 
    733bdd205c9f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd205ca6:	00 00 00 
    733bdd205ca9:	31 c0                	xor    eax,eax
    733bdd205cab:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd205cb2:	59 00 00 
    733bdd205cb5:	ba 6c 03 01 00       	mov    edx,0x1036c
    733bdd205cba:	45 31 c0             	xor    r8d,r8d
    733bdd205cbd:	ff d0                	call   rax
    733bdd205cbf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205cc6:	00 
    733bdd205cc7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205ccd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205cd3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205cd9:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd205cde:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205ce3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205cea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205cf1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205cf8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205cff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205d06:	e9 bf 0b 00 00       	jmp    0x733bdd2068ca
    733bdd205d0b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd205d12:	00 
    733bdd205d13:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    733bdd205d1a:	c1 e9 0c             	shr    ecx,0xc
    733bdd205d1d:	89 c9                	mov    ecx,ecx
    733bdd205d1f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd205d23:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    733bdd205d2a:	00 
    733bdd205d2b:	48 83 f8 00          	cmp    rax,0x0
    733bdd205d2f:	74 23                	je     0x733bdd205d54
    733bdd205d31:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd205d38:	00 
    733bdd205d39:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    733bdd205d40:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd205d46:	89 c9                	mov    ecx,ecx
    733bdd205d48:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd205d4b:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    733bdd205d52:	eb 5d                	jmp    0x733bdd205db1
    733bdd205d54:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205d5b:	00 
    733bdd205d5c:	8b b4 24 c4 00 00 00 	mov    esi,DWORD PTR [rsp+0xc4]
    733bdd205d63:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd205d6a:	00 
    733bdd205d6b:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    733bdd205d72:	03 01 00 
    733bdd205d75:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd205d7c:	00 00 00 
    733bdd205d7f:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd205d86:	00 00 00 
    733bdd205d89:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd205d90:	59 00 00 
    733bdd205d93:	ff d0                	call   rax
    733bdd205d95:	89 c1                	mov    ecx,eax
    733bdd205d97:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205d9e:	00 
    733bdd205d9f:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    733bdd205da6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd205dad:	75 32                	jne    0x733bdd205de1
    733bdd205daf:	eb 7c                	jmp    0x733bdd205e2d
    733bdd205db1:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    733bdd205db8:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd205dbf:	00 
    733bdd205dc0:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    733bdd205dc7:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    733bdd205dca:	83 c0 04             	add    eax,0x4
    733bdd205dcd:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd205dd4:	83 e0 03             	and    eax,0x3
    733bdd205dd7:	83 f8 00             	cmp    eax,0x0
    733bdd205dda:	75 64                	jne    0x733bdd205e40
    733bdd205ddc:	e9 f6 00 00 00       	jmp    0x733bdd205ed7
    733bdd205de1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205de8:	00 
    733bdd205de9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205def:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205df5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205dfb:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd205e00:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205e05:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205e0c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205e13:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205e1a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205e21:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205e28:	e9 9d 0a 00 00       	jmp    0x733bdd2068ca
    733bdd205e2d:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    733bdd205e34:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    733bdd205e3b:	e9 71 ff ff ff       	jmp    0x733bdd205db1
    733bdd205e40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd205e47:	00 
    733bdd205e48:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    733bdd205e4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd205e56:	00 
    733bdd205e57:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    733bdd205e5e:	03 01 00 
    733bdd205e61:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd205e68:	00 00 00 
    733bdd205e6b:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd205e72:	00 00 00 
    733bdd205e75:	31 c0                	xor    eax,eax
    733bdd205e77:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd205e7e:	59 00 00 
    733bdd205e81:	ba 6c 03 01 00       	mov    edx,0x1036c
    733bdd205e86:	45 31 c0             	xor    r8d,r8d
    733bdd205e89:	ff d0                	call   rax
    733bdd205e8b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205e92:	00 
    733bdd205e93:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205e99:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205e9f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205ea5:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd205eaa:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205eaf:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205eb6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205ebd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205ec4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205ecb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205ed2:	e9 f3 09 00 00       	jmp    0x733bdd2068ca
    733bdd205ed7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd205ede:	00 
    733bdd205edf:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    733bdd205ee6:	c1 e9 0c             	shr    ecx,0xc
    733bdd205ee9:	89 c9                	mov    ecx,ecx
    733bdd205eeb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd205eef:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    733bdd205ef6:	00 
    733bdd205ef7:	48 83 f8 00          	cmp    rax,0x0
    733bdd205efb:	74 23                	je     0x733bdd205f20
    733bdd205efd:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    733bdd205f04:	00 
    733bdd205f05:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    733bdd205f0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd205f12:	89 c9                	mov    ecx,ecx
    733bdd205f14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd205f17:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    733bdd205f1e:	eb 5d                	jmp    0x733bdd205f7d
    733bdd205f20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205f27:	00 
    733bdd205f28:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    733bdd205f2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd205f36:	00 
    733bdd205f37:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    733bdd205f3e:	03 01 00 
    733bdd205f41:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd205f48:	00 00 00 
    733bdd205f4b:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd205f52:	00 00 00 
    733bdd205f55:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd205f5c:	59 00 00 
    733bdd205f5f:	ff d0                	call   rax
    733bdd205f61:	89 c1                	mov    ecx,eax
    733bdd205f63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205f6a:	00 
    733bdd205f6b:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    733bdd205f72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd205f79:	75 32                	jne    0x733bdd205fad
    733bdd205f7b:	eb 7c                	jmp    0x733bdd205ff9
    733bdd205f7d:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    733bdd205f84:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd205f8b:	00 
    733bdd205f8c:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    733bdd205f93:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    733bdd205f96:	83 c0 04             	add    eax,0x4
    733bdd205f99:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd205fa0:	83 e0 03             	and    eax,0x3
    733bdd205fa3:	83 f8 00             	cmp    eax,0x0
    733bdd205fa6:	75 64                	jne    0x733bdd20600c
    733bdd205fa8:	e9 f6 00 00 00       	jmp    0x733bdd2060a3
    733bdd205fad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd205fb4:	00 
    733bdd205fb5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd205fbb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd205fc1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd205fc7:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd205fcc:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd205fd1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd205fd8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd205fdf:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd205fe6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd205fed:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd205ff4:	e9 d1 08 00 00       	jmp    0x733bdd2068ca
    733bdd205ff9:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    733bdd206000:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    733bdd206007:	e9 71 ff ff ff       	jmp    0x733bdd205f7d
    733bdd20600c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd206013:	00 
    733bdd206014:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20601b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd206022:	00 
    733bdd206023:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    733bdd20602a:	03 01 00 
    733bdd20602d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd206034:	00 00 00 
    733bdd206037:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd20603e:	00 00 00 
    733bdd206041:	31 c0                	xor    eax,eax
    733bdd206043:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20604a:	59 00 00 
    733bdd20604d:	ba 6c 03 01 00       	mov    edx,0x1036c
    733bdd206052:	45 31 c0             	xor    r8d,r8d
    733bdd206055:	ff d0                	call   rax
    733bdd206057:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20605e:	00 
    733bdd20605f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd206065:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20606b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd206071:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd206076:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20607b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd206082:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd206089:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd206090:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd206097:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20609e:	e9 27 08 00 00       	jmp    0x733bdd2068ca
    733bdd2060a3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2060aa:	00 
    733bdd2060ab:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd2060b2:	c1 e9 0c             	shr    ecx,0xc
    733bdd2060b5:	89 c9                	mov    ecx,ecx
    733bdd2060b7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2060bb:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    733bdd2060c2:	00 
    733bdd2060c3:	48 83 f8 00          	cmp    rax,0x0
    733bdd2060c7:	74 23                	je     0x733bdd2060ec
    733bdd2060c9:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    733bdd2060d0:	00 
    733bdd2060d1:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd2060d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2060de:	89 c9                	mov    ecx,ecx
    733bdd2060e0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2060e3:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    733bdd2060ea:	eb 5d                	jmp    0x733bdd206149
    733bdd2060ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2060f3:	00 
    733bdd2060f4:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    733bdd2060fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd206102:	00 
    733bdd206103:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    733bdd20610a:	03 01 00 
    733bdd20610d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206114:	00 00 00 
    733bdd206117:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd20611e:	00 00 00 
    733bdd206121:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd206128:	59 00 00 
    733bdd20612b:	ff d0                	call   rax
    733bdd20612d:	89 c1                	mov    ecx,eax
    733bdd20612f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206136:	00 
    733bdd206137:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    733bdd20613e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd206145:	75 2f                	jne    0x733bdd206176
    733bdd206147:	eb 79                	jmp    0x733bdd2061c2
    733bdd206149:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    733bdd206150:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd206157:	00 
    733bdd206158:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    733bdd20615f:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    733bdd206162:	83 c0 04             	add    eax,0x4
    733bdd206165:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd206169:	83 e0 03             	and    eax,0x3
    733bdd20616c:	83 f8 00             	cmp    eax,0x0
    733bdd20616f:	75 64                	jne    0x733bdd2061d5
    733bdd206171:	e9 f3 00 00 00       	jmp    0x733bdd206269
    733bdd206176:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20617d:	00 
    733bdd20617e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd206184:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20618a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd206190:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd206195:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20619a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2061a1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2061a8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2061af:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2061b6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2061bd:	e9 08 07 00 00       	jmp    0x733bdd2068ca
    733bdd2061c2:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    733bdd2061c9:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    733bdd2061d0:	e9 74 ff ff ff       	jmp    0x733bdd206149
    733bdd2061d5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2061dc:	00 
    733bdd2061dd:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    733bdd2061e1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2061e8:	00 
    733bdd2061e9:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    733bdd2061f0:	03 01 00 
    733bdd2061f3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2061fa:	00 00 00 
    733bdd2061fd:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd206204:	00 00 00 
    733bdd206207:	31 c0                	xor    eax,eax
    733bdd206209:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd206210:	59 00 00 
    733bdd206213:	ba 6c 03 01 00       	mov    edx,0x1036c
    733bdd206218:	45 31 c0             	xor    r8d,r8d
    733bdd20621b:	ff d0                	call   rax
    733bdd20621d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206224:	00 
    733bdd206225:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20622b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd206231:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd206237:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd20623c:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd206241:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd206248:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20624f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd206256:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20625d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd206264:	e9 61 06 00 00       	jmp    0x733bdd2068ca
    733bdd206269:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd206270:	00 
    733bdd206271:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    733bdd206275:	c1 e9 0c             	shr    ecx,0xc
    733bdd206278:	89 c9                	mov    ecx,ecx
    733bdd20627a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20627e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    733bdd206283:	48 83 f8 00          	cmp    rax,0x0
    733bdd206287:	74 1a                	je     0x733bdd2062a3
    733bdd206289:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd20628e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    733bdd206292:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd206298:	89 c9                	mov    ecx,ecx
    733bdd20629a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20629d:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd2062a1:	eb 57                	jmp    0x733bdd2062fa
    733bdd2062a3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2062aa:	00 
    733bdd2062ab:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    733bdd2062af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2062b6:	00 
    733bdd2062b7:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    733bdd2062be:	03 01 00 
    733bdd2062c1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2062c8:	00 00 00 
    733bdd2062cb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd2062d2:	00 00 00 
    733bdd2062d5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2062dc:	59 00 00 
    733bdd2062df:	ff d0                	call   rax
    733bdd2062e1:	89 c1                	mov    ecx,eax
    733bdd2062e3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2062ea:	00 
    733bdd2062eb:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    733bdd2062ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2062f6:	75 29                	jne    0x733bdd206321
    733bdd2062f8:	eb 73                	jmp    0x733bdd20636d
    733bdd2062fa:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    733bdd2062fe:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd206305:	00 
    733bdd206306:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    733bdd20630a:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    733bdd20630d:	83 c0 04             	add    eax,0x4
    733bdd206310:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd206314:	83 e0 03             	and    eax,0x3
    733bdd206317:	83 f8 00             	cmp    eax,0x0
    733bdd20631a:	75 5b                	jne    0x733bdd206377
    733bdd20631c:	e9 ea 00 00 00       	jmp    0x733bdd20640b
    733bdd206321:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206328:	00 
    733bdd206329:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20632f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd206335:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20633b:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd206340:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd206345:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20634c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd206353:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20635a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd206361:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd206368:	e9 5d 05 00 00       	jmp    0x733bdd2068ca
    733bdd20636d:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    733bdd206371:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    733bdd206375:	eb 83                	jmp    0x733bdd2062fa
    733bdd206377:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20637e:	00 
    733bdd20637f:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd206383:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd20638a:	00 
    733bdd20638b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    733bdd206392:	03 01 00 
    733bdd206395:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20639c:	00 00 00 
    733bdd20639f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    733bdd2063a6:	00 00 00 
    733bdd2063a9:	31 c0                	xor    eax,eax
    733bdd2063ab:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2063b2:	59 00 00 
    733bdd2063b5:	ba 6c 03 01 00       	mov    edx,0x1036c
    733bdd2063ba:	45 31 c0             	xor    r8d,r8d
    733bdd2063bd:	ff d0                	call   rax
    733bdd2063bf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2063c6:	00 
    733bdd2063c7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2063cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2063d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2063d9:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd2063de:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2063e3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2063ea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2063f1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2063f8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2063ff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd206406:	e9 bf 04 00 00       	jmp    0x733bdd2068ca
    733bdd20640b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd206412:	00 
    733bdd206413:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd206417:	c1 e9 0c             	shr    ecx,0xc
    733bdd20641a:	89 c9                	mov    ecx,ecx
    733bdd20641c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd206420:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd206425:	48 83 f8 00          	cmp    rax,0x0
    733bdd206429:	74 1a                	je     0x733bdd206445
    733bdd20642b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd206430:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd206434:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20643a:	89 c9                	mov    ecx,ecx
    733bdd20643c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20643f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd206443:	eb 57                	jmp    0x733bdd20649c
    733bdd206445:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20644c:	00 
    733bdd20644d:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    733bdd206451:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd206458:	00 
    733bdd206459:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    733bdd206460:	03 01 00 
    733bdd206463:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20646a:	00 00 00 
    733bdd20646d:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    733bdd206474:	00 00 00 
    733bdd206477:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20647e:	59 00 00 
    733bdd206481:	ff d0                	call   rax
    733bdd206483:	89 c1                	mov    ecx,eax
    733bdd206485:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20648c:	00 
    733bdd20648d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd206491:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd206498:	75 1d                	jne    0x733bdd2064b7
    733bdd20649a:	eb 67                	jmp    0x733bdd206503
    733bdd20649c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2064a3:	00 
    733bdd2064a4:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd2064a8:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    733bdd2064ac:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    733bdd2064af:	83 c1 04             	add    ecx,0x4
    733bdd2064b2:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd2064b5:	eb 56                	jmp    0x733bdd20650d
    733bdd2064b7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2064be:	00 
    733bdd2064bf:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2064c5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2064cb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2064d1:	be 1a 00 00 00       	mov    esi,0x1a
    733bdd2064d6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2064db:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2064e2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2064e9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2064f0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2064f7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2064fe:	e9 c7 03 00 00       	jmp    0x733bdd2068ca
    733bdd206503:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    733bdd206507:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd20650b:	eb 8f                	jmp    0x733bdd20649c
    733bdd20650d:	eb 00                	jmp    0x733bdd20650f
    733bdd20650f:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    733bdd206516:	83 e0 01             	and    eax,0x1
    733bdd206519:	83 f8 00             	cmp    eax,0x0
    733bdd20651c:	75 3d                	jne    0x733bdd20655b
    733bdd20651e:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    733bdd206525:	be 1b 00 00 00       	mov    esi,0x1b
    733bdd20652a:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20652f:	b0 01                	mov    al,0x1
    733bdd206531:	89 d7                	mov    edi,edx
    733bdd206533:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20653a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd206541:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd206548:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20654f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd206556:	e9 6f 03 00 00       	jmp    0x733bdd2068ca
    733bdd20655b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd206562:	00 
    733bdd206563:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    733bdd20656a:	00 
    733bdd20656b:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    733bdd206572:	03 01 00 
    733bdd206575:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20657c:	00 00 00 
    733bdd20657f:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    733bdd206586:	00 00 00 
    733bdd206589:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd206590:	59 00 00 
    733bdd206593:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd206598:	ff d0                	call   rax
    733bdd20659a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2065a1:	00 
    733bdd2065a2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2065a8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2065ae:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2065b4:	be 1b 00 00 00       	mov    esi,0x1b
    733bdd2065b9:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2065be:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2065c5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2065cc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2065d3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2065da:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2065e1:	e9 e4 02 00 00       	jmp    0x733bdd2068ca
    733bdd2065e6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2065ed:	00 
    733bdd2065ee:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd2065f5:	e9 c2 03 00 00       	jmp    0x733bdd2069bc
    733bdd2065fa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd206601:	00 
    733bdd206602:	48 89 c1             	mov    rcx,rax
    733bdd206605:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    733bdd20660c:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    733bdd206611:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    733bdd206618:	03 01 00 
    733bdd20661b:	74 32                	je     0x733bdd20664f
    733bdd20661d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206624:	00 
    733bdd206625:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    733bdd20662c:	03 01 00 
    733bdd20662f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206636:	00 00 00 
    733bdd206639:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    733bdd206640:	00 00 00 
    733bdd206643:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20664a:	e9 6d 03 00 00       	jmp    0x733bdd2069bc
    733bdd20664f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd206656:	00 
    733bdd206657:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd20665e:	00 
    733bdd20665f:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    733bdd206664:	8b 8c 24 4c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x14c]
    733bdd20666b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    733bdd206672:	70 03 01 00 
    733bdd206676:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20667d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206681:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd206688:	ff e0                	jmp    rax
    733bdd20668a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd206691:	00 
    733bdd206692:	48 89 c1             	mov    rcx,rax
    733bdd206695:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    733bdd20669c:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    733bdd2066a1:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    733bdd2066a8:	03 01 00 
    733bdd2066ab:	74 32                	je     0x733bdd2066df
    733bdd2066ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2066b4:	00 
    733bdd2066b5:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    733bdd2066bc:	03 01 00 
    733bdd2066bf:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2066c6:	00 00 00 
    733bdd2066c9:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd2066d0:	00 00 00 
    733bdd2066d3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd2066da:	e9 dd 02 00 00       	jmp    0x733bdd2069bc
    733bdd2066df:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd2066e6:	00 
    733bdd2066e7:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd2066ee:	00 
    733bdd2066ef:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    733bdd2066f4:	8b 8c 24 40 01 00 00 	mov    ecx,DWORD PTR [rsp+0x140]
    733bdd2066fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    733bdd206702:	70 03 01 00 
    733bdd206706:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20670d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206711:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd206718:	ff e0                	jmp    rax
    733bdd20671a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd206721:	00 
    733bdd206722:	48 89 c1             	mov    rcx,rax
    733bdd206725:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    733bdd20672c:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    733bdd206731:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    733bdd206738:	03 01 00 
    733bdd20673b:	74 32                	je     0x733bdd20676f
    733bdd20673d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206744:	00 
    733bdd206745:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    733bdd20674c:	03 01 00 
    733bdd20674f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206756:	00 00 00 
    733bdd206759:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    733bdd206760:	00 00 00 
    733bdd206763:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20676a:	e9 4d 02 00 00       	jmp    0x733bdd2069bc
    733bdd20676f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd206776:	00 
    733bdd206777:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd20677e:	00 
    733bdd20677f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd206784:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    733bdd20678b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    733bdd206792:	70 03 01 00 
    733bdd206796:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20679d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd2067a1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd2067a8:	ff e0                	jmp    rax
    733bdd2067aa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd2067b1:	00 
    733bdd2067b2:	48 89 c1             	mov    rcx,rax
    733bdd2067b5:	48 81 c1 d0 1b 08 00 	add    rcx,0x81bd0
    733bdd2067bc:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    733bdd2067c1:	81 b8 d0 1b 08 00 7a 	cmp    DWORD PTR [rax+0x81bd0],0x1037a
    733bdd2067c8:	03 01 00 
    733bdd2067cb:	74 32                	je     0x733bdd2067ff
    733bdd2067cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2067d4:	00 
    733bdd2067d5:	c7 80 bc 00 00 00 7a 	mov    DWORD PTR [rax+0xbc],0x1037a
    733bdd2067dc:	03 01 00 
    733bdd2067df:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2067e6:	00 00 00 
    733bdd2067e9:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    733bdd2067f0:	00 00 00 
    733bdd2067f3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd2067fa:	e9 bd 01 00 00       	jmp    0x733bdd2069bc
    733bdd2067ff:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd206806:	00 
    733bdd206807:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd20680e:	00 
    733bdd20680f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd206814:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    733bdd20681b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    733bdd206822:	7a 03 01 00 
    733bdd206826:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20682d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206831:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd206838:	ff e0                	jmp    rax
    733bdd20683a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd206841:	00 
    733bdd206842:	48 89 c1             	mov    rcx,rax
    733bdd206845:	48 81 c1 20 1d 08 00 	add    rcx,0x81d20
    733bdd20684c:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd206851:	81 b8 20 1d 08 00 a4 	cmp    DWORD PTR [rax+0x81d20],0x103a4
    733bdd206858:	03 01 00 
    733bdd20685b:	74 32                	je     0x733bdd20688f
    733bdd20685d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206864:	00 
    733bdd206865:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x103a4
    733bdd20686c:	03 01 00 
    733bdd20686f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206876:	00 00 00 
    733bdd206879:	c7 80 34 01 00 00 17 	mov    DWORD PTR [rax+0x134],0x17
    733bdd206880:	00 00 00 
    733bdd206883:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20688a:	e9 2d 01 00 00       	jmp    0x733bdd2069bc
    733bdd20688f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd206896:	00 
    733bdd206897:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd20689e:	00 
    733bdd20689f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd2068a4:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf0]
    733bdd2068ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    733bdd2068b2:	a4 03 01 00 
    733bdd2068b6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd2068bd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd2068c1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd2068c8:	ff e0                	jmp    rax
    733bdd2068ca:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2068d1:	00 
    733bdd2068d2:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    733bdd2068d9:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    733bdd2068e0:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    733bdd2068e7:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    733bdd2068ee:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    733bdd2068f5:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    733bdd2068f9:	89 c3                	mov    ebx,eax
    733bdd2068fb:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    733bdd2068ff:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    733bdd206903:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    733bdd206907:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    733bdd20690b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd206911:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    733bdd206915:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20691b:	73 2d                	jae    0x733bdd20694a
    733bdd20691d:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd206924:	00 
    733bdd206925:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd206929:	89 d1                	mov    ecx,edx
    733bdd20692b:	c1 e9 01             	shr    ecx,0x1
    733bdd20692e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd206934:	89 c9                	mov    ecx,ecx
    733bdd206936:	48 c1 e1 04          	shl    rcx,0x4
    733bdd20693a:	48 89 c6             	mov    rsi,rax
    733bdd20693d:	48 01 ce             	add    rsi,rcx
    733bdd206940:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd206945:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd206948:	74 32                	je     0x733bdd20697c
    733bdd20694a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd206951:	00 
    733bdd206952:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    733bdd206956:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd20695a:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    733bdd20695e:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    733bdd206962:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd206968:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd20696e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd206974:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd20697a:	eb 40                	jmp    0x733bdd2069bc
    733bdd20697c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd206983:	00 
    733bdd206984:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd20698b:	00 
    733bdd20698c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd206991:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    733bdd206995:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd206999:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd2069a0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd2069a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd2069ae:	00 
    733bdd2069af:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd2069b3:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd2069ba:	ff e0                	jmp    rax
    733bdd2069bc:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd2069c3:	c2 08 00             	ret    0x8
