
build-native-instruction-analysis/capture/bcore-default-branch/pc-65542-0-126700950191936.bin:     file format binary


Disassembly of section .data:

0000733bdd20ff40 <.data>:
    733bdd20ff40:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    733bdd20ff47:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    733bdd20ff4c:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    733bdd20ff51:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20ff58:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    733bdd20ff5d:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd20ff64:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    733bdd20ff69:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20ff70:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd20ff77:	00 
    733bdd20ff78:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    733bdd20ff7d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd20ff83:	83 fa 00             	cmp    edx,0x0
    733bdd20ff86:	0f 94 c0             	sete   al
    733bdd20ff89:	81 ea 06 00 01 00    	sub    edx,0x10006
    733bdd20ff8f:	83 fa 0a             	cmp    edx,0xa
    733bdd20ff92:	0f 97 c2             	seta   dl
    733bdd20ff95:	08 d0                	or     al,dl
    733bdd20ff97:	24 01                	and    al,0x1
    733bdd20ff99:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20ff9f:	83 fa 00             	cmp    edx,0x0
    733bdd20ffa2:	0f 94 c1             	sete   cl
    733bdd20ffa5:	81 ea 06 00 01 00    	sub    edx,0x10006
    733bdd20ffab:	83 fa 0a             	cmp    edx,0xa
    733bdd20ffae:	0f 97 c2             	seta   dl
    733bdd20ffb1:	08 d1                	or     cl,dl
    733bdd20ffb3:	20 c8                	and    al,cl
    733bdd20ffb5:	a8 01                	test   al,0x1
    733bdd20ffb7:	75 05                	jne    0x733bdd20ffbe
    733bdd20ffb9:	e9 75 02 00 00       	jmp    0x733bdd210233
    733bdd20ffbe:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd20ffc3:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd20ffca:	48 89 c8             	mov    rax,rcx
    733bdd20ffcd:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd20ffd3:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    733bdd20ffd8:	8b 81 44 00 10 00    	mov    eax,DWORD PTR [rcx+0x100044]
    733bdd20ffde:	83 c0 01             	add    eax,0x1
    733bdd20ffe1:	89 81 44 00 10 00    	mov    DWORD PTR [rcx+0x100044],eax
    733bdd20ffe7:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd20ffec:	75 40                	jne    0x733bdd21002e
    733bdd20ffee:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    733bdd20fff3:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd20fff9:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd20fffd:	89 c2                	mov    edx,eax
    733bdd20ffff:	83 c2 01             	add    edx,0x1
    733bdd210002:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd210008:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd21000d:	73 1d                	jae    0x733bdd21002c
    733bdd21000f:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    733bdd210014:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd210018:	89 c9                	mov    ecx,ecx
    733bdd21001a:	48 c1 e1 02          	shl    rcx,0x2
    733bdd21001e:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd210025:	c7 04 08 11 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x11
    733bdd21002c:	eb 00                	jmp    0x733bdd21002e
    733bdd21002e:	eb 00                	jmp    0x733bdd210030
    733bdd210030:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210035:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    733bdd210038:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd21003e:	81 c9 00 00 00 01    	or     ecx,0x1000000
    733bdd210044:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd210048:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    733bdd21004b:	eb 00                	jmp    0x733bdd21004d
    733bdd21004d:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210052:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    733bdd210056:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd21005c:	83 c9 04             	or     ecx,0x4
    733bdd21005f:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    733bdd210063:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    733bdd210066:	eb 00                	jmp    0x733bdd210068
    733bdd210068:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    733bdd21006c:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    733bdd210071:	8b 09                	mov    ecx,DWORD PTR [rcx]
    733bdd210073:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd210077:	83 e0 03             	and    eax,0x3
    733bdd21007a:	83 f8 00             	cmp    eax,0x0
    733bdd21007d:	74 69                	je     0x733bdd2100e8
    733bdd21007f:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    733bdd210084:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd210088:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    733bdd21008d:	c7 87 bc 00 00 00 0e 	mov    DWORD PTR [rdi+0xbc],0x1000e
    733bdd210094:	00 01 00 
    733bdd210097:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd21009e:	00 00 00 
    733bdd2100a1:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd2100a8:	00 00 00 
    733bdd2100ab:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2100b2:	59 00 00 
    733bdd2100b5:	ba 0e 00 01 00       	mov    edx,0x1000e
    733bdd2100ba:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2100c0:	ff d0                	call   rax
    733bdd2100c2:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2100c7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2100cd:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd2100d2:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2100d7:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    733bdd2100db:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd2100df:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd2100e3:	e9 dd 01 00 00       	jmp    0x733bdd2102c5
    733bdd2100e8:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd2100ef:	00 
    733bdd2100f0:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd2100f4:	c1 e9 0c             	shr    ecx,0xc
    733bdd2100f7:	89 c9                	mov    ecx,ecx
    733bdd2100f9:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2100fd:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    733bdd210102:	48 83 f8 00          	cmp    rax,0x0
    733bdd210106:	74 1a                	je     0x733bdd210122
    733bdd210108:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    733bdd21010d:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    733bdd210111:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd210115:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd21011b:	89 c9                	mov    ecx,ecx
    733bdd21011d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd210120:	eb 4c                	jmp    0x733bdd21016e
    733bdd210122:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210127:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    733bdd21012b:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    733bdd21012f:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    733bdd210134:	c7 80 bc 00 00 00 0e 	mov    DWORD PTR [rax+0xbc],0x1000e
    733bdd21013b:	00 01 00 
    733bdd21013e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd210145:	00 00 00 
    733bdd210148:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd21014f:	00 00 00 
    733bdd210152:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd210159:	59 00 00 
    733bdd21015c:	ff d0                	call   rax
    733bdd21015e:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210163:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd21016a:	75 0e                	jne    0x733bdd21017a
    733bdd21016c:	eb 32                	jmp    0x733bdd2101a0
    733bdd21016e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd210173:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd210176:	75 2a                	jne    0x733bdd2101a2
    733bdd210178:	eb 67                	jmp    0x733bdd2101e1
    733bdd21017a:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd21017f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd210185:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd21018a:	b8 02 00 00 00       	mov    eax,0x2
    733bdd21018f:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    733bdd210193:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd210197:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd21019b:	e9 25 01 00 00       	jmp    0x733bdd2102c5
    733bdd2101a0:	eb cc                	jmp    0x733bdd21016e
    733bdd2101a2:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    733bdd2101a7:	c7 87 bc 00 00 00 10 	mov    DWORD PTR [rdi+0xbc],0x10010
    733bdd2101ae:	00 01 00 
    733bdd2101b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2101b8:	00 00 00 
    733bdd2101bb:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd2101c2:	00 00 00 
    733bdd2101c5:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd2101cc:	59 00 00 
    733bdd2101cf:	ff d0                	call   rax
    733bdd2101d1:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2101d6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2101dd:	75 04                	jne    0x733bdd2101e3
    733bdd2101df:	eb 28                	jmp    0x733bdd210209
    733bdd2101e1:	eb 28                	jmp    0x733bdd21020b
    733bdd2101e3:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2101e8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2101ee:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd2101f3:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2101f8:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    733bdd2101fc:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd210200:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd210204:	e9 bc 00 00 00       	jmp    0x733bdd2102c5
    733bdd210209:	eb d6                	jmp    0x733bdd2101e1
    733bdd21020b:	eb 00                	jmp    0x733bdd21020d
    733bdd21020d:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    733bdd210212:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10010
    733bdd210219:	00 01 00 
    733bdd21021c:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd210222:	83 c0 04             	add    eax,0x4
    733bdd210225:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd210229:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd21022f:	72 13                	jb     0x733bdd210244
    733bdd210231:	eb 31                	jmp    0x733bdd210264
    733bdd210233:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210238:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd21023f:	e9 26 01 00 00       	jmp    0x733bdd21036a
    733bdd210244:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd210249:	48 89 c1             	mov    rcx,rax
    733bdd21024c:	48 81 c1 80 00 08 00 	add    rcx,0x80080
    733bdd210253:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd210258:	81 b8 80 00 08 00 10 	cmp    DWORD PTR [rax+0x80080],0x10010
    733bdd21025f:	00 01 00 
    733bdd210262:	74 2f                	je     0x733bdd210293
    733bdd210264:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210269:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10010
    733bdd210270:	00 01 00 
    733bdd210273:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd21027a:	00 00 00 
    733bdd21027d:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    733bdd210284:	00 00 00 
    733bdd210287:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd21028e:	e9 d7 00 00 00       	jmp    0x733bdd21036a
    733bdd210293:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    733bdd210298:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    733bdd21029d:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd2102a2:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    733bdd2102a6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    733bdd2102ad:	10 00 01 00 
    733bdd2102b1:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd2102b8:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd2102bc:	48 81 c4 88 00 00 00 	add    rsp,0x88
    733bdd2102c3:	ff e0                	jmp    rax
    733bdd2102c5:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    733bdd2102ca:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    733bdd2102ce:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    733bdd2102d2:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd2102d6:	89 c7                	mov    edi,eax
    733bdd2102d8:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd2102dc:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd2102e0:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd2102e4:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd2102ea:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd2102ee:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd2102f4:	73 2a                	jae    0x733bdd210320
    733bdd2102f6:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    733bdd2102fb:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd2102ff:	89 d1                	mov    ecx,edx
    733bdd210301:	c1 e9 01             	shr    ecx,0x1
    733bdd210304:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd21030a:	89 c9                	mov    ecx,ecx
    733bdd21030c:	48 c1 e1 04          	shl    rcx,0x4
    733bdd210310:	48 89 c6             	mov    rsi,rax
    733bdd210313:	48 01 ce             	add    rsi,rcx
    733bdd210316:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd21031b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd21031e:	74 1b                	je     0x733bdd21033b
    733bdd210320:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd210325:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd210329:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd21032d:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd210333:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd210339:	eb 2f                	jmp    0x733bdd21036a
    733bdd21033b:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    733bdd210340:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    733bdd210345:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd21034a:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd21034e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd210355:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd21035c:	00 
    733bdd21035d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd210361:	48 81 c4 88 00 00 00 	add    rsp,0x88
    733bdd210368:	ff e0                	jmp    rax
    733bdd21036a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    733bdd210371:	c2 08 00             	ret    0x8
