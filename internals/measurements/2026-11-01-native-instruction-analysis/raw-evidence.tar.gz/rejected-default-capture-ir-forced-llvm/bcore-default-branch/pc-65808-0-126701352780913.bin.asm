
build-native-instruction-analysis/capture/bcore-default-branch/pc-65808-0-126701352780913.bin:     file format binary


Disassembly of section .data:

0000733bf5200471 <.data>:
    733bf5200471:	41 c6 85 65 01 00 00 	mov    BYTE PTR [r13+0x165],0x1
    733bf5200478:	01 
    733bf5200479:	48 83 c4 28          	add    rsp,0x28
    733bf520047d:	c2 08 00             	ret    0x8
    733bf5200480:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    733bf5200487:	20 01 01 00 
    733bf520048b:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200492:	04 00 00 00 
    733bf5200496:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf520049d:	06 00 00 00 
    733bf52004a1:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bf52004a8:	59 00 00 
    733bf52004ab:	48 89 fd             	mov    rbp,rdi
    733bf52004ae:	4c 89 ef             	mov    rdi,r13
    733bf52004b1:	4c 89 c6             	mov    rsi,r8
    733bf52004b4:	ba 20 01 01 00       	mov    edx,0x10120
    733bf52004b9:	89 d9                	mov    ecx,ebx
    733bf52004bb:	4d 89 c6             	mov    r14,r8
    733bf52004be:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bf52004c4:	ff d0                	call   rax
    733bf52004c6:	48 89 ef             	mov    rdi,rbp
    733bf52004c9:	4d 89 f0             	mov    r8,r14
    733bf52004cc:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf52004d3:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52004da:	00 
    733bf52004db:	bb 06 00 00 00       	mov    ebx,0x6
    733bf52004e0:	bd 04 00 00 00       	mov    ebp,0x4
    733bf52004e5:	e9 aa d2 00 e8       	jmp    0x733bdd20d794
    733bf52004ea:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    733bf52004f1:	20 01 01 00 
    733bf52004f5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52004fc:	04 00 00 00 
    733bf5200500:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf5200507:	06 00 00 00 
    733bf520050b:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bf5200512:	59 00 00 
    733bf5200515:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    733bf520051a:	4c 89 c7             	mov    rdi,r8
    733bf520051d:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    733bf5200522:	89 de                	mov    esi,ebx
    733bf5200524:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    733bf5200528:	4c 89 cd             	mov    rbp,r9
    733bf520052b:	4d 89 d7             	mov    r15,r10
    733bf520052e:	44 89 5c 24 10       	mov    DWORD PTR [rsp+0x10],r11d
    733bf5200533:	ff d0                	call   rax
    733bf5200535:	44 8b 5c 24 10       	mov    r11d,DWORD PTR [rsp+0x10]
    733bf520053a:	4d 89 fa             	mov    r10,r15
    733bf520053d:	49 89 e9             	mov    r9,rbp
    733bf5200540:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    733bf5200545:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf520054a:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf520054e:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200555:	00 
    733bf5200556:	84 c9                	test   cl,cl
    733bf5200558:	0f 84 9a d1 00 e8    	je     0x733bdd20d6f8
    733bf520055e:	e9 e3 00 00 00       	jmp    0x733bf5200646
    733bf5200563:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10120
    733bf520056a:	20 01 01 00 
    733bf520056e:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200575:	04 00 00 00 
    733bf5200579:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf5200580:	06 00 00 00 
    733bf5200584:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bf520058b:	59 00 00 
    733bf520058e:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    733bf5200593:	4c 89 c7             	mov    rdi,r8
    733bf5200596:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    733bf520059b:	89 ee                	mov    esi,ebp
    733bf520059d:	44 89 da             	mov    edx,r11d
    733bf52005a0:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    733bf52005a4:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    733bf52005a9:	4c 89 54 24 20       	mov    QWORD PTR [rsp+0x20],r10
    733bf52005ae:	ff d0                	call   rax
    733bf52005b0:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
    733bf52005b5:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    733bf52005ba:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    733bf52005bf:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf52005c4:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf52005c8:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf52005cf:	00 
    733bf52005d0:	84 c9                	test   cl,cl
    733bf52005d2:	0f 84 43 d1 00 e8    	je     0x733bdd20d71b
    733bf52005d8:	eb 6c                	jmp    0x733bf5200646
    733bf52005da:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    733bf52005e1:	24 01 01 00 
    733bf52005e5:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52005ec:	04 00 00 00 
    733bf52005f0:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x6
    733bf52005f7:	06 00 00 00 
    733bf52005fb:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bf5200602:	59 00 00 
    733bf5200605:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    733bf520060a:	4c 89 ef             	mov    rdi,r13
    733bf520060d:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    733bf5200611:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
    733bf5200616:	48 89 5c 24 10       	mov    QWORD PTR [rsp+0x10],rbx
    733bf520061b:	4c 89 cb             	mov    rbx,r9
    733bf520061e:	ff d0                	call   rax
    733bf5200620:	49 89 d9             	mov    r9,rbx
    733bf5200623:	48 8b 5c 24 10       	mov    rbx,QWORD PTR [rsp+0x10]
    733bf5200628:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
    733bf520062d:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf5200632:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf5200636:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520063d:	00 
    733bf520063e:	84 c9                	test   cl,cl
    733bf5200640:	0f 84 e7 d0 00 e8    	je     0x733bdd20d72d
    733bf5200646:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf520064d:	e9 89 fe ff ff       	jmp    0x733bf52004db
    733bf5200652:	4c 89 4c 24 10       	mov    QWORD PTR [rsp+0x10],r9
    733bf5200657:	49 89 f7             	mov    r15,rsi
    733bf520065a:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    733bf520065f:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    733bf5200666:	24 01 01 00 
    733bf520066a:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf5200671:	04 00 00 00 
    733bf5200675:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    733bf520067c:	07 00 00 00 
    733bf5200680:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf5200687:	59 00 00 
    733bf520068a:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    733bf520068e:	4c 89 c7             	mov    rdi,r8
    733bf5200691:	89 ee                	mov    esi,ebp
    733bf5200693:	ff d0                	call   rax
    733bf5200695:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520069c:	00 
    733bf520069d:	84 c9                	test   cl,cl
    733bf520069f:	0f 85 cb 00 00 00    	jne    0x733bf5200770
    733bf52006a5:	89 c5                	mov    ebp,eax
    733bf52006a7:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf52006ab:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf52006b0:	4c 89 fe             	mov    rsi,r15
    733bf52006b3:	4c 8b 4c 24 10       	mov    r9,QWORD PTR [rsp+0x10]
    733bf52006b8:	e9 86 d0 00 e8       	jmp    0x733bdd20d743
    733bf52006bd:	49 89 f7             	mov    r15,rsi
    733bf52006c0:	48 89 7c 24 08       	mov    QWORD PTR [rsp+0x8],rdi
    733bf52006c5:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10124
    733bf52006cc:	24 01 01 00 
    733bf52006d0:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x4
    733bf52006d7:	04 00 00 00 
    733bf52006db:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0x7
    733bf52006e2:	07 00 00 00 
    733bf52006e6:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bf52006ed:	59 00 00 
    733bf52006f0:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
    733bf52006f4:	4c 89 c7             	mov    rdi,r8
    733bf52006f7:	89 de                	mov    esi,ebx
    733bf52006f9:	ff d0                	call   rax
    733bf52006fb:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf5200702:	00 
    733bf5200703:	84 c9                	test   cl,cl
    733bf5200705:	75 69                	jne    0x733bf5200770
    733bf5200707:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf520070b:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf5200710:	4c 89 fe             	mov    rsi,r15
    733bf5200713:	e9 41 d0 00 e8       	jmp    0x733bdd20d759
    733bf5200718:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1012e
    733bf520071f:	2e 01 01 00 
    733bf5200723:	41 c7 85 24 01 00 00 	mov    DWORD PTR [r13+0x124],0x2
    733bf520072a:	02 00 00 00 
    733bf520072e:	41 c7 85 34 01 00 00 	mov    DWORD PTR [r13+0x134],0xb
    733bf5200735:	0b 00 00 00 
    733bf5200739:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bf5200740:	59 00 00 
    733bf5200743:	49 89 ff             	mov    r15,rdi
    733bf5200746:	4c 89 ef             	mov    rdi,r13
    733bf5200749:	be 2a 00 00 00       	mov    esi,0x2a
    733bf520074e:	4c 89 c2             	mov    rdx,r8
    733bf5200751:	4d 89 c6             	mov    r14,r8
    733bf5200754:	ff d0                	call   rax
    733bf5200756:	4c 89 ff             	mov    rdi,r15
    733bf5200759:	4d 89 f0             	mov    r8,r14
    733bf520075c:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200763:	41 0f b6 8d 28 01 00 	movzx  ecx,BYTE PTR [r13+0x128]
    733bf520076a:	00 
    733bf520076b:	e9 24 d0 00 e8       	jmp    0x733bdd20d794
    733bf5200770:	41 8b 85 bc 00 00 00 	mov    eax,DWORD PTR [r13+0xbc]
    733bf5200777:	bb 07 00 00 00       	mov    ebx,0x7
    733bf520077c:	bd 04 00 00 00       	mov    ebp,0x4
    733bf5200781:	4c 8b 04 24          	mov    r8,QWORD PTR [rsp]
    733bf5200785:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
    733bf520078a:	e9 05 d0 00 e8       	jmp    0x733bdd20d794
