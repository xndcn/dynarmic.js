
build-native-instruction-analysis/capture/bcore-default-branch/pc-65556-0-126700950127136.bin:     file format binary


Disassembly of section .data:

0000733bdd200220 <.data>:
    733bdd200220:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    733bdd200227:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    733bdd20022e:	00 
    733bdd20022f:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    733bdd200236:	00 
    733bdd200237:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20023e:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    733bdd200245:	00 
    733bdd200246:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd20024d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    733bdd200254:	00 
    733bdd200255:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20025c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    733bdd200263:	00 
    733bdd200264:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20026b:	00 
    733bdd20026c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd200272:	83 fa 00             	cmp    edx,0x0
    733bdd200275:	0f 94 c0             	sete   al
    733bdd200278:	81 ea 14 00 01 00    	sub    edx,0x10014
    733bdd20027e:	83 fa 2a             	cmp    edx,0x2a
    733bdd200281:	0f 97 c2             	seta   dl
    733bdd200284:	08 d0                	or     al,dl
    733bdd200286:	24 01                	and    al,0x1
    733bdd200288:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20028e:	83 fa 00             	cmp    edx,0x0
    733bdd200291:	0f 94 c1             	sete   cl
    733bdd200294:	81 ea 14 00 01 00    	sub    edx,0x10014
    733bdd20029a:	83 fa 2a             	cmp    edx,0x2a
    733bdd20029d:	0f 97 c2             	seta   dl
    733bdd2002a0:	08 d1                	or     cl,dl
    733bdd2002a2:	20 c8                	and    al,cl
    733bdd2002a4:	a8 01                	test   al,0x1
    733bdd2002a6:	75 05                	jne    0x733bdd2002ad
    733bdd2002a8:	e9 19 27 00 00       	jmp    0x733bdd2029c6
    733bdd2002ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2002b4:	00 
    733bdd2002b5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd2002bc:	48 89 c8             	mov    rax,rcx
    733bdd2002bf:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd2002c5:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    733bdd2002cc:	00 
    733bdd2002cd:	8b 81 04 00 10 00    	mov    eax,DWORD PTR [rcx+0x100004]
    733bdd2002d3:	83 c0 01             	add    eax,0x1
    733bdd2002d6:	89 81 04 00 10 00    	mov    DWORD PTR [rcx+0x100004],eax
    733bdd2002dc:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd2002e1:	75 4c                	jne    0x733bdd20032f
    733bdd2002e3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    733bdd2002ea:	00 
    733bdd2002eb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd2002f1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    733bdd2002f8:	89 c2                	mov    edx,eax
    733bdd2002fa:	83 c2 01             	add    edx,0x1
    733bdd2002fd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd200303:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd200308:	73 23                	jae    0x733bdd20032d
    733bdd20030a:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    733bdd200311:	00 
    733bdd200312:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    733bdd200319:	89 c9                	mov    ecx,ecx
    733bdd20031b:	48 c1 e1 02          	shl    rcx,0x2
    733bdd20031f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd200326:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    733bdd20032d:	eb 00                	jmp    0x733bdd20032f
    733bdd20032f:	eb 00                	jmp    0x733bdd200331
    733bdd200331:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200338:	00 
    733bdd200339:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    733bdd20033c:	83 e8 04             	sub    eax,0x4
    733bdd20033f:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    733bdd200346:	8b 49 10             	mov    ecx,DWORD PTR [rcx+0x10]
    733bdd200349:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    733bdd200350:	83 e0 03             	and    eax,0x3
    733bdd200353:	83 f8 00             	cmp    eax,0x0
    733bdd200356:	0f 84 8e 00 00 00    	je     0x733bdd2003ea
    733bdd20035c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200363:	00 
    733bdd200364:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd20036b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200372:	00 
    733bdd200373:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20037a:	00 00 00 
    733bdd20037d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200384:	00 00 00 
    733bdd200387:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20038e:	59 00 00 
    733bdd200391:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd200396:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20039c:	ff d0                	call   rax
    733bdd20039e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2003a5:	00 
    733bdd2003a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2003ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2003b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2003b8:	be 01 00 00 00       	mov    esi,0x1
    733bdd2003bd:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2003c2:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2003c9:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2003d0:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2003d7:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2003de:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2003e5:	e9 80 26 00 00       	jmp    0x733bdd202a6a
    733bdd2003ea:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2003f1:	00 
    733bdd2003f2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd2003f9:	c1 e9 0c             	shr    ecx,0xc
    733bdd2003fc:	89 c9                	mov    ecx,ecx
    733bdd2003fe:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd200402:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    733bdd200409:	00 
    733bdd20040a:	48 83 f8 00          	cmp    rax,0x0
    733bdd20040e:	74 23                	je     0x733bdd200433
    733bdd200410:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    733bdd200417:	00 
    733bdd200418:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    733bdd20041f:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    733bdd200426:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20042c:	89 c9                	mov    ecx,ecx
    733bdd20042e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd200431:	eb 51                	jmp    0x733bdd200484
    733bdd200433:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20043a:	00 
    733bdd20043b:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    733bdd200442:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    733bdd200449:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd200450:	00 
    733bdd200451:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd200458:	00 00 00 
    733bdd20045b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200462:	00 00 00 
    733bdd200465:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20046c:	59 00 00 
    733bdd20046f:	ff d0                	call   rax
    733bdd200471:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200478:	00 
    733bdd200479:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200480:	75 32                	jne    0x733bdd2004b4
    733bdd200482:	eb 7c                	jmp    0x733bdd200500
    733bdd200484:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20048b:	00 
    733bdd20048c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    733bdd200493:	83 e8 04             	sub    eax,0x4
    733bdd200496:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    733bdd20049d:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    733bdd2004a0:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    733bdd2004a7:	83 e0 03             	and    eax,0x3
    733bdd2004aa:	83 f8 00             	cmp    eax,0x0
    733bdd2004ad:	75 53                	jne    0x733bdd200502
    733bdd2004af:	e9 dc 00 00 00       	jmp    0x733bdd200590
    733bdd2004b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2004bb:	00 
    733bdd2004bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2004c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2004c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2004ce:	be 01 00 00 00       	mov    esi,0x1
    733bdd2004d3:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2004d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2004df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2004e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2004ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2004f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2004fb:	e9 6a 25 00 00       	jmp    0x733bdd202a6a
    733bdd200500:	eb 82                	jmp    0x733bdd200484
    733bdd200502:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200509:	00 
    733bdd20050a:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd200511:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200518:	00 
    733bdd200519:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd200520:	00 00 00 
    733bdd200523:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd20052a:	00 00 00 
    733bdd20052d:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd200534:	59 00 00 
    733bdd200537:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd20053c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd200542:	ff d0                	call   rax
    733bdd200544:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20054b:	00 
    733bdd20054c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200552:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200558:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20055e:	be 01 00 00 00       	mov    esi,0x1
    733bdd200563:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200568:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20056f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200576:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20057d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200584:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20058b:	e9 da 24 00 00       	jmp    0x733bdd202a6a
    733bdd200590:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd200597:	00 
    733bdd200598:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd20059f:	c1 e9 0c             	shr    ecx,0xc
    733bdd2005a2:	89 c9                	mov    ecx,ecx
    733bdd2005a4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2005a8:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    733bdd2005af:	00 
    733bdd2005b0:	48 83 f8 00          	cmp    rax,0x0
    733bdd2005b4:	74 23                	je     0x733bdd2005d9
    733bdd2005b6:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    733bdd2005bd:	00 
    733bdd2005be:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    733bdd2005c5:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    733bdd2005cc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2005d2:	89 c9                	mov    ecx,ecx
    733bdd2005d4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2005d7:	eb 51                	jmp    0x733bdd20062a
    733bdd2005d9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2005e0:	00 
    733bdd2005e1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    733bdd2005e8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    733bdd2005ef:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2005f6:	00 
    733bdd2005f7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2005fe:	00 00 00 
    733bdd200601:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200608:	00 00 00 
    733bdd20060b:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd200612:	59 00 00 
    733bdd200615:	ff d0                	call   rax
    733bdd200617:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20061e:	00 
    733bdd20061f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200626:	75 32                	jne    0x733bdd20065a
    733bdd200628:	eb 7c                	jmp    0x733bdd2006a6
    733bdd20062a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200631:	00 
    733bdd200632:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    733bdd200639:	83 e8 04             	sub    eax,0x4
    733bdd20063c:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    733bdd200643:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    733bdd200646:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    733bdd20064d:	83 e0 03             	and    eax,0x3
    733bdd200650:	83 f8 00             	cmp    eax,0x0
    733bdd200653:	75 53                	jne    0x733bdd2006a8
    733bdd200655:	e9 dc 00 00 00       	jmp    0x733bdd200736
    733bdd20065a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200661:	00 
    733bdd200662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20066e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200674:	be 01 00 00 00       	mov    esi,0x1
    733bdd200679:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20067e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20068c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20069a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2006a1:	e9 c4 23 00 00       	jmp    0x733bdd202a6a
    733bdd2006a6:	eb 82                	jmp    0x733bdd20062a
    733bdd2006a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2006af:	00 
    733bdd2006b0:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd2006b7:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2006be:	00 
    733bdd2006bf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2006c6:	00 00 00 
    733bdd2006c9:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd2006d0:	00 00 00 
    733bdd2006d3:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2006da:	59 00 00 
    733bdd2006dd:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd2006e2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2006e8:	ff d0                	call   rax
    733bdd2006ea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2006f1:	00 
    733bdd2006f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2006f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2006fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200704:	be 01 00 00 00       	mov    esi,0x1
    733bdd200709:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20070e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200715:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20071c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200723:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20072a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200731:	e9 34 23 00 00       	jmp    0x733bdd202a6a
    733bdd200736:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd20073d:	00 
    733bdd20073e:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd200745:	c1 e9 0c             	shr    ecx,0xc
    733bdd200748:	89 c9                	mov    ecx,ecx
    733bdd20074a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20074e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    733bdd200755:	00 
    733bdd200756:	48 83 f8 00          	cmp    rax,0x0
    733bdd20075a:	74 23                	je     0x733bdd20077f
    733bdd20075c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    733bdd200763:	00 
    733bdd200764:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    733bdd20076b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    733bdd200772:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd200778:	89 c9                	mov    ecx,ecx
    733bdd20077a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd20077d:	eb 51                	jmp    0x733bdd2007d0
    733bdd20077f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200786:	00 
    733bdd200787:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    733bdd20078e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    733bdd200795:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd20079c:	00 
    733bdd20079d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2007a4:	00 00 00 
    733bdd2007a7:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd2007ae:	00 00 00 
    733bdd2007b1:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2007b8:	59 00 00 
    733bdd2007bb:	ff d0                	call   rax
    733bdd2007bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2007c4:	00 
    733bdd2007c5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2007cc:	75 32                	jne    0x733bdd200800
    733bdd2007ce:	eb 7c                	jmp    0x733bdd20084c
    733bdd2007d0:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2007d7:	00 
    733bdd2007d8:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    733bdd2007df:	83 e8 04             	sub    eax,0x4
    733bdd2007e2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    733bdd2007e9:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    733bdd2007ec:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    733bdd2007f3:	83 e0 03             	and    eax,0x3
    733bdd2007f6:	83 f8 00             	cmp    eax,0x0
    733bdd2007f9:	75 53                	jne    0x733bdd20084e
    733bdd2007fb:	e9 dc 00 00 00       	jmp    0x733bdd2008dc
    733bdd200800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200807:	00 
    733bdd200808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20080e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20081a:	be 01 00 00 00       	mov    esi,0x1
    733bdd20081f:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20082b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200847:	e9 1e 22 00 00       	jmp    0x733bdd202a6a
    733bdd20084c:	eb 82                	jmp    0x733bdd2007d0
    733bdd20084e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200855:	00 
    733bdd200856:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd20085d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200864:	00 
    733bdd200865:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20086c:	00 00 00 
    733bdd20086f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200876:	00 00 00 
    733bdd200879:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd200880:	59 00 00 
    733bdd200883:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd200888:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd20088e:	ff d0                	call   rax
    733bdd200890:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200897:	00 
    733bdd200898:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20089e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2008a4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2008aa:	be 01 00 00 00       	mov    esi,0x1
    733bdd2008af:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2008b4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2008bb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2008c2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2008c9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2008d0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2008d7:	e9 8e 21 00 00       	jmp    0x733bdd202a6a
    733bdd2008dc:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2008e3:	00 
    733bdd2008e4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd2008eb:	c1 e9 0c             	shr    ecx,0xc
    733bdd2008ee:	89 c9                	mov    ecx,ecx
    733bdd2008f0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2008f4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    733bdd2008fb:	00 
    733bdd2008fc:	48 83 f8 00          	cmp    rax,0x0
    733bdd200900:	74 23                	je     0x733bdd200925
    733bdd200902:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    733bdd200909:	00 
    733bdd20090a:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    733bdd200911:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    733bdd200918:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20091e:	89 c9                	mov    ecx,ecx
    733bdd200920:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd200923:	eb 51                	jmp    0x733bdd200976
    733bdd200925:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20092c:	00 
    733bdd20092d:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    733bdd200934:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    733bdd20093b:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd200942:	00 
    733bdd200943:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20094a:	00 00 00 
    733bdd20094d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200954:	00 00 00 
    733bdd200957:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd20095e:	59 00 00 
    733bdd200961:	ff d0                	call   rax
    733bdd200963:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20096a:	00 
    733bdd20096b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200972:	75 32                	jne    0x733bdd2009a6
    733bdd200974:	eb 7c                	jmp    0x733bdd2009f2
    733bdd200976:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20097d:	00 
    733bdd20097e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    733bdd200985:	83 e8 04             	sub    eax,0x4
    733bdd200988:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    733bdd20098f:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    733bdd200992:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    733bdd200999:	83 e0 03             	and    eax,0x3
    733bdd20099c:	83 f8 00             	cmp    eax,0x0
    733bdd20099f:	75 53                	jne    0x733bdd2009f4
    733bdd2009a1:	e9 dc 00 00 00       	jmp    0x733bdd200a82
    733bdd2009a6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2009ad:	00 
    733bdd2009ae:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2009b4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2009ba:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2009c0:	be 01 00 00 00       	mov    esi,0x1
    733bdd2009c5:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2009ca:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2009d1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2009d8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2009df:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2009e6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2009ed:	e9 78 20 00 00       	jmp    0x733bdd202a6a
    733bdd2009f2:	eb 82                	jmp    0x733bdd200976
    733bdd2009f4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2009fb:	00 
    733bdd2009fc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd200a03:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200a0a:	00 
    733bdd200a0b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd200a12:	00 00 00 
    733bdd200a15:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200a1c:	00 00 00 
    733bdd200a1f:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd200a26:	59 00 00 
    733bdd200a29:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd200a2e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd200a34:	ff d0                	call   rax
    733bdd200a36:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200a3d:	00 
    733bdd200a3e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200a44:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200a4a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200a50:	be 01 00 00 00       	mov    esi,0x1
    733bdd200a55:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200a5a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200a61:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200a68:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200a6f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200a76:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200a7d:	e9 e8 1f 00 00       	jmp    0x733bdd202a6a
    733bdd200a82:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd200a89:	00 
    733bdd200a8a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd200a91:	c1 e9 0c             	shr    ecx,0xc
    733bdd200a94:	89 c9                	mov    ecx,ecx
    733bdd200a96:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd200a9a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    733bdd200aa1:	00 
    733bdd200aa2:	48 83 f8 00          	cmp    rax,0x0
    733bdd200aa6:	74 23                	je     0x733bdd200acb
    733bdd200aa8:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    733bdd200aaf:	00 
    733bdd200ab0:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    733bdd200ab7:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    733bdd200abe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd200ac4:	89 c9                	mov    ecx,ecx
    733bdd200ac6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd200ac9:	eb 51                	jmp    0x733bdd200b1c
    733bdd200acb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200ad2:	00 
    733bdd200ad3:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    733bdd200ada:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    733bdd200ae1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd200ae8:	00 
    733bdd200ae9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd200af0:	00 00 00 
    733bdd200af3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200afa:	00 00 00 
    733bdd200afd:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd200b04:	59 00 00 
    733bdd200b07:	ff d0                	call   rax
    733bdd200b09:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200b10:	00 
    733bdd200b11:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200b18:	75 32                	jne    0x733bdd200b4c
    733bdd200b1a:	eb 7c                	jmp    0x733bdd200b98
    733bdd200b1c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200b23:	00 
    733bdd200b24:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    733bdd200b2b:	83 e8 04             	sub    eax,0x4
    733bdd200b2e:	89 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],eax
    733bdd200b35:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    733bdd200b38:	89 8c 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],ecx
    733bdd200b3f:	83 e0 03             	and    eax,0x3
    733bdd200b42:	83 f8 00             	cmp    eax,0x0
    733bdd200b45:	75 53                	jne    0x733bdd200b9a
    733bdd200b47:	e9 dc 00 00 00       	jmp    0x733bdd200c28
    733bdd200b4c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200b53:	00 
    733bdd200b54:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200b5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200b60:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200b66:	be 01 00 00 00       	mov    esi,0x1
    733bdd200b6b:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200b70:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200b77:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200b7e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200b85:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200b8c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200b93:	e9 d2 1e 00 00       	jmp    0x733bdd202a6a
    733bdd200b98:	eb 82                	jmp    0x733bdd200b1c
    733bdd200b9a:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200ba1:	00 
    733bdd200ba2:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    733bdd200ba9:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200bb0:	00 
    733bdd200bb1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd200bb8:	00 00 00 
    733bdd200bbb:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200bc2:	00 00 00 
    733bdd200bc5:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd200bcc:	59 00 00 
    733bdd200bcf:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd200bd4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd200bda:	ff d0                	call   rax
    733bdd200bdc:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200be3:	00 
    733bdd200be4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200bea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200bf0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200bf6:	be 01 00 00 00       	mov    esi,0x1
    733bdd200bfb:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200c00:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200c07:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200c0e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200c15:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200c1c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200c23:	e9 42 1e 00 00       	jmp    0x733bdd202a6a
    733bdd200c28:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd200c2f:	00 
    733bdd200c30:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    733bdd200c37:	c1 e9 0c             	shr    ecx,0xc
    733bdd200c3a:	89 c9                	mov    ecx,ecx
    733bdd200c3c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd200c40:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
    733bdd200c47:	00 
    733bdd200c48:	48 83 f8 00          	cmp    rax,0x0
    733bdd200c4c:	74 23                	je     0x733bdd200c71
    733bdd200c4e:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    733bdd200c55:	00 
    733bdd200c56:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    733bdd200c5d:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    733bdd200c64:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd200c6a:	89 c9                	mov    ecx,ecx
    733bdd200c6c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd200c6f:	eb 51                	jmp    0x733bdd200cc2
    733bdd200c71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200c78:	00 
    733bdd200c79:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    733bdd200c80:	8b b4 24 78 01 00 00 	mov    esi,DWORD PTR [rsp+0x178]
    733bdd200c87:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd200c8e:	00 
    733bdd200c8f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd200c96:	00 00 00 
    733bdd200c99:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200ca0:	00 00 00 
    733bdd200ca3:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd200caa:	59 00 00 
    733bdd200cad:	ff d0                	call   rax
    733bdd200caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200cb6:	00 
    733bdd200cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200cbe:	75 32                	jne    0x733bdd200cf2
    733bdd200cc0:	eb 7c                	jmp    0x733bdd200d3e
    733bdd200cc2:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200cc9:	00 
    733bdd200cca:	8b 84 24 78 01 00 00 	mov    eax,DWORD PTR [rsp+0x178]
    733bdd200cd1:	83 e8 04             	sub    eax,0x4
    733bdd200cd4:	89 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],eax
    733bdd200cdb:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    733bdd200cde:	89 8c 24 6c 01 00 00 	mov    DWORD PTR [rsp+0x16c],ecx
    733bdd200ce5:	83 e0 03             	and    eax,0x3
    733bdd200ce8:	83 f8 00             	cmp    eax,0x0
    733bdd200ceb:	75 53                	jne    0x733bdd200d40
    733bdd200ced:	e9 dc 00 00 00       	jmp    0x733bdd200dce
    733bdd200cf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200cf9:	00 
    733bdd200cfa:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200d00:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200d06:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200d0c:	be 01 00 00 00       	mov    esi,0x1
    733bdd200d11:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200d16:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200d1d:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200d24:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200d2b:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200d32:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200d39:	e9 2c 1d 00 00       	jmp    0x733bdd202a6a
    733bdd200d3e:	eb 82                	jmp    0x733bdd200cc2
    733bdd200d40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200d47:	00 
    733bdd200d48:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    733bdd200d4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200d56:	00 
    733bdd200d57:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd200d5e:	00 00 00 
    733bdd200d61:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200d68:	00 00 00 
    733bdd200d6b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd200d72:	59 00 00 
    733bdd200d75:	ba 14 00 01 00       	mov    edx,0x10014
    733bdd200d7a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd200d80:	ff d0                	call   rax
    733bdd200d82:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200d89:	00 
    733bdd200d8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200d90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200d96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200d9c:	be 01 00 00 00       	mov    esi,0x1
    733bdd200da1:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200da6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200dad:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200db4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200dbb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200dc2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200dc9:	e9 9c 1c 00 00       	jmp    0x733bdd202a6a
    733bdd200dce:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd200dd5:	00 
    733bdd200dd6:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    733bdd200ddd:	c1 e9 0c             	shr    ecx,0xc
    733bdd200de0:	89 c9                	mov    ecx,ecx
    733bdd200de2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd200de6:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    733bdd200ded:	00 
    733bdd200dee:	48 83 f8 00          	cmp    rax,0x0
    733bdd200df2:	74 23                	je     0x733bdd200e17
    733bdd200df4:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    733bdd200dfb:	00 
    733bdd200dfc:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    733bdd200e03:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    733bdd200e0a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd200e10:	89 c9                	mov    ecx,ecx
    733bdd200e12:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd200e15:	eb 51                	jmp    0x733bdd200e68
    733bdd200e17:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200e1e:	00 
    733bdd200e1f:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    733bdd200e26:	8b b4 24 68 01 00 00 	mov    esi,DWORD PTR [rsp+0x168]
    733bdd200e2d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd200e34:	00 
    733bdd200e35:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd200e3c:	00 00 00 
    733bdd200e3f:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    733bdd200e46:	00 00 00 
    733bdd200e49:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd200e50:	59 00 00 
    733bdd200e53:	ff d0                	call   rax
    733bdd200e55:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200e5c:	00 
    733bdd200e5d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200e64:	75 26                	jne    0x733bdd200e8c
    733bdd200e66:	eb 70                	jmp    0x733bdd200ed8
    733bdd200e68:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd200e6f:	00 
    733bdd200e70:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200e77:	00 
    733bdd200e78:	8b 94 24 68 01 00 00 	mov    edx,DWORD PTR [rsp+0x168]
    733bdd200e7f:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd200e82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd200e85:	75 53                	jne    0x733bdd200eda
    733bdd200e87:	e9 93 00 00 00       	jmp    0x733bdd200f1f
    733bdd200e8c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200e93:	00 
    733bdd200e94:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200e9a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200ea0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200ea6:	be 01 00 00 00       	mov    esi,0x1
    733bdd200eab:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200eb0:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200eb7:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200ebe:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200ec5:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200ecc:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200ed3:	e9 92 1b 00 00       	jmp    0x733bdd202a6a
    733bdd200ed8:	eb 8e                	jmp    0x733bdd200e68
    733bdd200eda:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200ee1:	00 
    733bdd200ee2:	c7 87 bc 00 00 00 16 	mov    DWORD PTR [rdi+0xbc],0x10016
    733bdd200ee9:	00 01 00 
    733bdd200eec:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd200ef3:	00 00 00 
    733bdd200ef6:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    733bdd200efd:	00 00 00 
    733bdd200f00:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd200f07:	59 00 00 
    733bdd200f0a:	ff d0                	call   rax
    733bdd200f0c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200f13:	00 
    733bdd200f14:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd200f1b:	75 04                	jne    0x733bdd200f21
    733bdd200f1d:	eb 4e                	jmp    0x733bdd200f6d
    733bdd200f1f:	eb 4e                	jmp    0x733bdd200f6f
    733bdd200f21:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200f28:	00 
    733bdd200f29:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd200f2f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd200f35:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd200f3b:	be 01 00 00 00       	mov    esi,0x1
    733bdd200f40:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd200f45:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd200f4c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd200f53:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd200f5a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd200f61:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd200f68:	e9 fd 1a 00 00       	jmp    0x733bdd202a6a
    733bdd200f6d:	eb b0                	jmp    0x733bdd200f1f
    733bdd200f6f:	eb 00                	jmp    0x733bdd200f71
    733bdd200f71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd200f78:	00 
    733bdd200f79:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    733bdd200f7c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd200f82:	83 c9 00             	or     ecx,0x0
    733bdd200f85:	89 8c 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],ecx
    733bdd200f8c:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd200f8f:	eb 00                	jmp    0x733bdd200f91
    733bdd200f91:	8b 84 24 68 01 00 00 	mov    eax,DWORD PTR [rsp+0x168]
    733bdd200f98:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd200f9f:	00 
    733bdd200fa0:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    733bdd200fa6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    733bdd200fad:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    733bdd200fb0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    733bdd200fb7:	83 e8 04             	sub    eax,0x4
    733bdd200fba:	89 84 24 58 01 00 00 	mov    DWORD PTR [rsp+0x158],eax
    733bdd200fc1:	83 e0 03             	and    eax,0x3
    733bdd200fc4:	83 f8 00             	cmp    eax,0x0
    733bdd200fc7:	0f 84 98 00 00 00    	je     0x733bdd201065
    733bdd200fcd:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd200fd4:	00 
    733bdd200fd5:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    733bdd200fdc:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd200fe3:	00 
    733bdd200fe4:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    733bdd200feb:	00 01 00 
    733bdd200fee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd200ff5:	00 00 00 
    733bdd200ff8:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd200fff:	00 00 00 
    733bdd201002:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd201009:	59 00 00 
    733bdd20100c:	ba 1a 00 01 00       	mov    edx,0x1001a
    733bdd201011:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd201017:	ff d0                	call   rax
    733bdd201019:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201020:	00 
    733bdd201021:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201027:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20102d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201033:	be 03 00 00 00       	mov    esi,0x3
    733bdd201038:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20103d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201044:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20104b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201052:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201059:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201060:	e9 05 1a 00 00       	jmp    0x733bdd202a6a
    733bdd201065:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd20106c:	00 
    733bdd20106d:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    733bdd201074:	c1 e9 0c             	shr    ecx,0xc
    733bdd201077:	89 c9                	mov    ecx,ecx
    733bdd201079:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20107d:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
    733bdd201084:	00 
    733bdd201085:	48 83 f8 00          	cmp    rax,0x0
    733bdd201089:	74 23                	je     0x733bdd2010ae
    733bdd20108b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    733bdd201092:	00 
    733bdd201093:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    733bdd20109a:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    733bdd2010a1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2010a7:	89 c9                	mov    ecx,ecx
    733bdd2010a9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd2010ac:	eb 5b                	jmp    0x733bdd201109
    733bdd2010ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2010b5:	00 
    733bdd2010b6:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    733bdd2010bd:	8b b4 24 58 01 00 00 	mov    esi,DWORD PTR [rsp+0x158]
    733bdd2010c4:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2010cb:	00 
    733bdd2010cc:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    733bdd2010d3:	00 01 00 
    733bdd2010d6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2010dd:	00 00 00 
    733bdd2010e0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd2010e7:	00 00 00 
    733bdd2010ea:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd2010f1:	59 00 00 
    733bdd2010f4:	ff d0                	call   rax
    733bdd2010f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2010fd:	00 
    733bdd2010fe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201105:	75 20                	jne    0x733bdd201127
    733bdd201107:	eb 6a                	jmp    0x733bdd201173
    733bdd201109:	8b 84 24 58 01 00 00 	mov    eax,DWORD PTR [rsp+0x158]
    733bdd201110:	83 e8 04             	sub    eax,0x4
    733bdd201113:	89 84 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],eax
    733bdd20111a:	83 e0 03             	and    eax,0x3
    733bdd20111d:	83 f8 00             	cmp    eax,0x0
    733bdd201120:	75 53                	jne    0x733bdd201175
    733bdd201122:	e9 e6 00 00 00       	jmp    0x733bdd20120d
    733bdd201127:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20112e:	00 
    733bdd20112f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201135:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20113b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201141:	be 03 00 00 00       	mov    esi,0x3
    733bdd201146:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd20114b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201152:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201159:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201160:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201167:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20116e:	e9 f7 18 00 00       	jmp    0x733bdd202a6a
    733bdd201173:	eb 94                	jmp    0x733bdd201109
    733bdd201175:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20117c:	00 
    733bdd20117d:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd201184:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd20118b:	00 
    733bdd20118c:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    733bdd201193:	00 01 00 
    733bdd201196:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd20119d:	00 00 00 
    733bdd2011a0:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd2011a7:	00 00 00 
    733bdd2011aa:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2011b1:	59 00 00 
    733bdd2011b4:	ba 1a 00 01 00       	mov    edx,0x1001a
    733bdd2011b9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd2011bf:	ff d0                	call   rax
    733bdd2011c1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2011c8:	00 
    733bdd2011c9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2011cf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2011d5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2011db:	be 03 00 00 00       	mov    esi,0x3
    733bdd2011e0:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2011e5:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2011ec:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2011f3:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2011fa:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201201:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201208:	e9 5d 18 00 00       	jmp    0x733bdd202a6a
    733bdd20120d:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd201214:	00 
    733bdd201215:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd20121c:	c1 e9 0c             	shr    ecx,0xc
    733bdd20121f:	89 c9                	mov    ecx,ecx
    733bdd201221:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd201225:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    733bdd20122c:	00 
    733bdd20122d:	48 83 f8 00          	cmp    rax,0x0
    733bdd201231:	74 23                	je     0x733bdd201256
    733bdd201233:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    733bdd20123a:	00 
    733bdd20123b:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    733bdd201242:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd201249:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20124f:	89 c9                	mov    ecx,ecx
    733bdd201251:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd201254:	eb 5b                	jmp    0x733bdd2012b1
    733bdd201256:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20125d:	00 
    733bdd20125e:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    733bdd201265:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    733bdd20126c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201273:	00 
    733bdd201274:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    733bdd20127b:	00 01 00 
    733bdd20127e:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd201285:	00 00 00 
    733bdd201288:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd20128f:	00 00 00 
    733bdd201292:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd201299:	59 00 00 
    733bdd20129c:	ff d0                	call   rax
    733bdd20129e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2012a5:	00 
    733bdd2012a6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2012ad:	75 2c                	jne    0x733bdd2012db
    733bdd2012af:	eb 76                	jmp    0x733bdd201327
    733bdd2012b1:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd2012b8:	00 
    733bdd2012b9:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2012c0:	00 
    733bdd2012c1:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    733bdd2012c8:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    733bdd2012cb:	83 ea 14             	sub    edx,0x14
    733bdd2012ce:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    733bdd2012d1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd2012d4:	75 53                	jne    0x733bdd201329
    733bdd2012d6:	e9 93 00 00 00       	jmp    0x733bdd20136e
    733bdd2012db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2012e2:	00 
    733bdd2012e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2012e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2012ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2012f5:	be 03 00 00 00       	mov    esi,0x3
    733bdd2012fa:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2012ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201306:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20130d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201314:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20131b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201322:	e9 43 17 00 00       	jmp    0x733bdd202a6a
    733bdd201327:	eb 88                	jmp    0x733bdd2012b1
    733bdd201329:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201330:	00 
    733bdd201331:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1001e
    733bdd201338:	00 01 00 
    733bdd20133b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd201342:	00 00 00 
    733bdd201345:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd20134c:	00 00 00 
    733bdd20134f:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd201356:	59 00 00 
    733bdd201359:	ff d0                	call   rax
    733bdd20135b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201362:	00 
    733bdd201363:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20136a:	75 04                	jne    0x733bdd201370
    733bdd20136c:	eb 4e                	jmp    0x733bdd2013bc
    733bdd20136e:	eb 4e                	jmp    0x733bdd2013be
    733bdd201370:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201377:	00 
    733bdd201378:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20137e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201384:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20138a:	be 03 00 00 00       	mov    esi,0x3
    733bdd20138f:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd201394:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20139b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2013a2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2013a9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2013b0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2013b7:	e9 ae 16 00 00       	jmp    0x733bdd202a6a
    733bdd2013bc:	eb b0                	jmp    0x733bdd20136e
    733bdd2013be:	eb 00                	jmp    0x733bdd2013c0
    733bdd2013c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2013c7:	00 
    733bdd2013c8:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    733bdd2013cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2013d5:	81 c9 00 f0 00 00    	or     ecx,0xf000
    733bdd2013db:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    733bdd2013e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2013e5:	eb 00                	jmp    0x733bdd2013e7
    733bdd2013e7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2013ee:	00 
    733bdd2013ef:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    733bdd2013f2:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd2013f8:	81 c9 00 00 42 43    	or     ecx,0x43420000
    733bdd2013fe:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    733bdd201405:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd201408:	eb 00                	jmp    0x733bdd20140a
    733bdd20140a:	8b 84 24 34 01 00 00 	mov    eax,DWORD PTR [rsp+0x134]
    733bdd201411:	83 e0 03             	and    eax,0x3
    733bdd201414:	83 f8 00             	cmp    eax,0x0
    733bdd201417:	0f 84 97 00 00 00    	je     0x733bdd2014b4
    733bdd20141d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201424:	00 
    733bdd201425:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    733bdd20142c:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201433:	00 
    733bdd201434:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10026
    733bdd20143b:	00 01 00 
    733bdd20143e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd201445:	00 00 00 
    733bdd201448:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd20144f:	00 00 00 
    733bdd201452:	31 c0                	xor    eax,eax
    733bdd201454:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20145b:	59 00 00 
    733bdd20145e:	ba 26 00 01 00       	mov    edx,0x10026
    733bdd201463:	45 31 c0             	xor    r8d,r8d
    733bdd201466:	ff d0                	call   rax
    733bdd201468:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20146f:	00 
    733bdd201470:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201476:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20147c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201482:	be 06 00 00 00       	mov    esi,0x6
    733bdd201487:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20148c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201493:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20149a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2014a1:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2014a8:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2014af:	e9 b6 15 00 00       	jmp    0x733bdd202a6a
    733bdd2014b4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2014bb:	00 
    733bdd2014bc:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    733bdd2014c3:	c1 e9 0c             	shr    ecx,0xc
    733bdd2014c6:	89 c9                	mov    ecx,ecx
    733bdd2014c8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2014cc:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    733bdd2014d3:	00 
    733bdd2014d4:	48 83 f8 00          	cmp    rax,0x0
    733bdd2014d8:	74 23                	je     0x733bdd2014fd
    733bdd2014da:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    733bdd2014e1:	00 
    733bdd2014e2:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    733bdd2014e9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2014ef:	89 c9                	mov    ecx,ecx
    733bdd2014f1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2014f4:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    733bdd2014fb:	eb 5d                	jmp    0x733bdd20155a
    733bdd2014fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201504:	00 
    733bdd201505:	8b b4 24 34 01 00 00 	mov    esi,DWORD PTR [rsp+0x134]
    733bdd20150c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201513:	00 
    733bdd201514:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10026
    733bdd20151b:	00 01 00 
    733bdd20151e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd201525:	00 00 00 
    733bdd201528:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20152f:	00 00 00 
    733bdd201532:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd201539:	59 00 00 
    733bdd20153c:	ff d0                	call   rax
    733bdd20153e:	89 c1                	mov    ecx,eax
    733bdd201540:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201547:	00 
    733bdd201548:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    733bdd20154f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201556:	75 1c                	jne    0x733bdd201574
    733bdd201558:	eb 66                	jmp    0x733bdd2015c0
    733bdd20155a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201561:	00 
    733bdd201562:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    733bdd201569:	89 8c 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],ecx
    733bdd201570:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd201572:	eb 5c                	jmp    0x733bdd2015d0
    733bdd201574:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20157b:	00 
    733bdd20157c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201582:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201588:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20158e:	be 06 00 00 00       	mov    esi,0x6
    733bdd201593:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd201598:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20159f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2015a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2015ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2015b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2015bb:	e9 aa 14 00 00       	jmp    0x733bdd202a6a
    733bdd2015c0:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    733bdd2015c7:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    733bdd2015ce:	eb 8a                	jmp    0x733bdd20155a
    733bdd2015d0:	eb 00                	jmp    0x733bdd2015d2
    733bdd2015d2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2015d9:	00 
    733bdd2015da:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    733bdd2015e1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd2015e7:	81 c9 31 4e 00 00    	or     ecx,0x4e31
    733bdd2015ed:	89 8c 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],ecx
    733bdd2015f4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd2015f7:	eb 00                	jmp    0x733bdd2015f9
    733bdd2015f9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201600:	00 
    733bdd201601:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    733bdd201608:	8b bc 24 1c 01 00 00 	mov    edi,DWORD PTR [rsp+0x11c]
    733bdd20160f:	89 fa                	mov    edx,edi
    733bdd201611:	29 ca                	sub    edx,ecx
    733bdd201613:	83 fa 00             	cmp    edx,0x0
    733bdd201616:	0f 94 c3             	sete   bl
    733bdd201619:	80 e3 01             	and    bl,0x1
    733bdd20161c:	0f b6 f3             	movzx  esi,bl
    733bdd20161f:	89 b4 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],esi
    733bdd201626:	c1 ea 1f             	shr    edx,0x1f
    733bdd201629:	89 fb                	mov    ebx,edi
    733bdd20162b:	c1 eb 1f             	shr    ebx,0x1f
    733bdd20162e:	41 89 c8             	mov    r8d,ecx
    733bdd201631:	41 c1 e8 1f          	shr    r8d,0x1f
    733bdd201635:	89 d5                	mov    ebp,edx
    733bdd201637:	31 dd                	xor    ebp,ebx
    733bdd201639:	44 31 c3             	xor    ebx,r8d
    733bdd20163c:	21 eb                	and    ebx,ebp
    733bdd20163e:	31 da                	xor    edx,ebx
    733bdd201640:	39 f9                	cmp    ecx,edi
    733bdd201642:	0f 96 c1             	setbe  cl
    733bdd201645:	80 e1 01             	and    cl,0x1
    733bdd201648:	0f b6 c9             	movzx  ecx,cl
    733bdd20164b:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd201651:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd201657:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd20165d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd201663:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd201669:	eb 00                	jmp    0x733bdd20166b
    733bdd20166b:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    733bdd201672:	83 f8 00             	cmp    eax,0x0
    733bdd201675:	74 33                	je     0x733bdd2016aa
    733bdd201677:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20167e:	00 
    733bdd20167f:	c7 81 bc 00 00 00 40 	mov    DWORD PTR [rcx+0xbc],0x10040
    733bdd201686:	00 01 00 
    733bdd201689:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd20168f:	83 c0 09             	add    eax,0x9
    733bdd201692:	89 84 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],eax
    733bdd201699:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd20169f:	0f 82 35 13 00 00    	jb     0x733bdd2029da
    733bdd2016a5:	e9 53 13 00 00       	jmp    0x733bdd2029fd
    733bdd2016aa:	eb 00                	jmp    0x733bdd2016ac
    733bdd2016ac:	eb 00                	jmp    0x733bdd2016ae
    733bdd2016ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2016b5:	00 
    733bdd2016b6:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    733bdd2016bc:	eb 00                	jmp    0x733bdd2016be
    733bdd2016be:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2016c5:	00 
    733bdd2016c6:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    733bdd2016cd:	83 c1 10             	add    ecx,0x10
    733bdd2016d0:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    733bdd2016d7:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd2016da:	eb 00                	jmp    0x733bdd2016dc
    733bdd2016dc:	8b 84 24 0c 01 00 00 	mov    eax,DWORD PTR [rsp+0x10c]
    733bdd2016e3:	83 e0 03             	and    eax,0x3
    733bdd2016e6:	83 f8 00             	cmp    eax,0x0
    733bdd2016e9:	0f 84 98 00 00 00    	je     0x733bdd201787
    733bdd2016ef:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2016f6:	00 
    733bdd2016f7:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    733bdd2016fe:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201705:	00 
    733bdd201706:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10034
    733bdd20170d:	00 01 00 
    733bdd201710:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd201717:	00 00 00 
    733bdd20171a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    733bdd201721:	00 00 00 
    733bdd201724:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20172b:	59 00 00 
    733bdd20172e:	ba 34 00 01 00       	mov    edx,0x10034
    733bdd201733:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd201739:	ff d0                	call   rax
    733bdd20173b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201742:	00 
    733bdd201743:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201749:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20174f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201755:	be 0c 00 00 00       	mov    esi,0xc
    733bdd20175a:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20175f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201766:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20176d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201774:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20177b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201782:	e9 e3 12 00 00       	jmp    0x733bdd202a6a
    733bdd201787:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd20178e:	00 
    733bdd20178f:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    733bdd201796:	c1 e9 0c             	shr    ecx,0xc
    733bdd201799:	89 c9                	mov    ecx,ecx
    733bdd20179b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20179f:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    733bdd2017a6:	00 
    733bdd2017a7:	48 83 f8 00          	cmp    rax,0x0
    733bdd2017ab:	74 20                	je     0x733bdd2017cd
    733bdd2017ad:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    733bdd2017b4:	00 
    733bdd2017b5:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    733bdd2017bc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2017c2:	89 c9                	mov    ecx,ecx
    733bdd2017c4:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    733bdd2017cb:	eb 59                	jmp    0x733bdd201826
    733bdd2017cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2017d4:	00 
    733bdd2017d5:	8b b4 24 0c 01 00 00 	mov    esi,DWORD PTR [rsp+0x10c]
    733bdd2017dc:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2017e3:	00 
    733bdd2017e4:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10034
    733bdd2017eb:	00 01 00 
    733bdd2017ee:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2017f5:	00 00 00 
    733bdd2017f8:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    733bdd2017ff:	00 00 00 
    733bdd201802:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd201809:	59 00 00 
    733bdd20180c:	ba 03 00 00 00       	mov    edx,0x3
    733bdd201811:	ff d0                	call   rax
    733bdd201813:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20181a:	00 
    733bdd20181b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201822:	75 14                	jne    0x733bdd201838
    733bdd201824:	eb 5e                	jmp    0x733bdd201884
    733bdd201826:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    733bdd20182d:	00 
    733bdd20182e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd201831:	75 53                	jne    0x733bdd201886
    733bdd201833:	e9 93 00 00 00       	jmp    0x733bdd2018cb
    733bdd201838:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20183f:	00 
    733bdd201840:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201846:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20184c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201852:	be 0c 00 00 00       	mov    esi,0xc
    733bdd201857:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20185c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201863:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20186a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201871:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201878:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd20187f:	e9 e6 11 00 00       	jmp    0x733bdd202a6a
    733bdd201884:	eb a0                	jmp    0x733bdd201826
    733bdd201886:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20188d:	00 
    733bdd20188e:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10036
    733bdd201895:	00 01 00 
    733bdd201898:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20189f:	00 00 00 
    733bdd2018a2:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    733bdd2018a9:	00 00 00 
    733bdd2018ac:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd2018b3:	59 00 00 
    733bdd2018b6:	ff d0                	call   rax
    733bdd2018b8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2018bf:	00 
    733bdd2018c0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2018c7:	75 04                	jne    0x733bdd2018cd
    733bdd2018c9:	eb 4e                	jmp    0x733bdd201919
    733bdd2018cb:	eb 4e                	jmp    0x733bdd20191b
    733bdd2018cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2018d4:	00 
    733bdd2018d5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2018db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2018e1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2018e7:	be 0c 00 00 00       	mov    esi,0xc
    733bdd2018ec:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2018f1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2018f8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2018ff:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201906:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20190d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201914:	e9 51 11 00 00       	jmp    0x733bdd202a6a
    733bdd201919:	eb b0                	jmp    0x733bdd2018cb
    733bdd20191b:	eb 00                	jmp    0x733bdd20191d
    733bdd20191d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201924:	00 
    733bdd201925:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    733bdd20192b:	eb 00                	jmp    0x733bdd20192d
    733bdd20192d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    733bdd201934:	83 e0 03             	and    eax,0x3
    733bdd201937:	83 f8 00             	cmp    eax,0x0
    733bdd20193a:	0f 84 97 00 00 00    	je     0x733bdd2019d7
    733bdd201940:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201947:	00 
    733bdd201948:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd20194f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201956:	00 
    733bdd201957:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    733bdd20195e:	00 01 00 
    733bdd201961:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd201968:	00 00 00 
    733bdd20196b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd201972:	00 00 00 
    733bdd201975:	31 c0                	xor    eax,eax
    733bdd201977:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20197e:	59 00 00 
    733bdd201981:	ba 38 00 01 00       	mov    edx,0x10038
    733bdd201986:	45 31 c0             	xor    r8d,r8d
    733bdd201989:	ff d0                	call   rax
    733bdd20198b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201992:	00 
    733bdd201993:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201999:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20199f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2019a5:	be 0e 00 00 00       	mov    esi,0xe
    733bdd2019aa:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd2019af:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2019b6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2019bd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2019c4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2019cb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2019d2:	e9 93 10 00 00       	jmp    0x733bdd202a6a
    733bdd2019d7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2019de:	00 
    733bdd2019df:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd2019e6:	c1 e9 0c             	shr    ecx,0xc
    733bdd2019e9:	89 c9                	mov    ecx,ecx
    733bdd2019eb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2019ef:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    733bdd2019f6:	00 
    733bdd2019f7:	48 83 f8 00          	cmp    rax,0x0
    733bdd2019fb:	74 23                	je     0x733bdd201a20
    733bdd2019fd:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    733bdd201a04:	00 
    733bdd201a05:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    733bdd201a0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd201a12:	89 c9                	mov    ecx,ecx
    733bdd201a14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd201a17:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    733bdd201a1e:	eb 5d                	jmp    0x733bdd201a7d
    733bdd201a20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201a27:	00 
    733bdd201a28:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    733bdd201a2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201a36:	00 
    733bdd201a37:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    733bdd201a3e:	00 01 00 
    733bdd201a41:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd201a48:	00 00 00 
    733bdd201a4b:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd201a52:	00 00 00 
    733bdd201a55:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd201a5c:	59 00 00 
    733bdd201a5f:	ff d0                	call   rax
    733bdd201a61:	89 c1                	mov    ecx,eax
    733bdd201a63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201a6a:	00 
    733bdd201a6b:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    733bdd201a72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201a79:	75 2e                	jne    0x733bdd201aa9
    733bdd201a7b:	eb 78                	jmp    0x733bdd201af5
    733bdd201a7d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    733bdd201a84:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    733bdd201a8b:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    733bdd201a92:	83 c0 04             	add    eax,0x4
    733bdd201a95:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    733bdd201a9c:	83 e0 03             	and    eax,0x3
    733bdd201a9f:	83 f8 00             	cmp    eax,0x0
    733bdd201aa2:	75 64                	jne    0x733bdd201b08
    733bdd201aa4:	e9 f6 00 00 00       	jmp    0x733bdd201b9f
    733bdd201aa9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201ab0:	00 
    733bdd201ab1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201ab7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201abd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201ac3:	be 0e 00 00 00       	mov    esi,0xe
    733bdd201ac8:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd201acd:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201ad4:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201adb:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201ae2:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201ae9:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201af0:	e9 75 0f 00 00       	jmp    0x733bdd202a6a
    733bdd201af5:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    733bdd201afc:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    733bdd201b03:	e9 75 ff ff ff       	jmp    0x733bdd201a7d
    733bdd201b08:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201b0f:	00 
    733bdd201b10:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd201b17:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201b1e:	00 
    733bdd201b1f:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    733bdd201b26:	00 01 00 
    733bdd201b29:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd201b30:	00 00 00 
    733bdd201b33:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    733bdd201b3a:	00 00 00 
    733bdd201b3d:	31 c0                	xor    eax,eax
    733bdd201b3f:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd201b46:	59 00 00 
    733bdd201b49:	ba 38 00 01 00       	mov    edx,0x10038
    733bdd201b4e:	45 31 c0             	xor    r8d,r8d
    733bdd201b51:	ff d0                	call   rax
    733bdd201b53:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201b5a:	00 
    733bdd201b5b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201b61:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201b67:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201b6d:	be 0e 00 00 00       	mov    esi,0xe
    733bdd201b72:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd201b77:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201b7e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201b85:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201b8c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201b93:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201b9a:	e9 cb 0e 00 00       	jmp    0x733bdd202a6a
    733bdd201b9f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd201ba6:	00 
    733bdd201ba7:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd201bae:	c1 e9 0c             	shr    ecx,0xc
    733bdd201bb1:	89 c9                	mov    ecx,ecx
    733bdd201bb3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd201bb7:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    733bdd201bbe:	00 
    733bdd201bbf:	48 83 f8 00          	cmp    rax,0x0
    733bdd201bc3:	74 23                	je     0x733bdd201be8
    733bdd201bc5:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    733bdd201bcc:	00 
    733bdd201bcd:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd201bd4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd201bda:	89 c9                	mov    ecx,ecx
    733bdd201bdc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd201bdf:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd201be6:	eb 60                	jmp    0x733bdd201c48
    733bdd201be8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201bef:	00 
    733bdd201bf0:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    733bdd201bf7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201bfe:	00 
    733bdd201bff:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    733bdd201c06:	00 01 00 
    733bdd201c09:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd201c10:	00 00 00 
    733bdd201c13:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    733bdd201c1a:	00 00 00 
    733bdd201c1d:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd201c24:	59 00 00 
    733bdd201c27:	ff d0                	call   rax
    733bdd201c29:	89 c1                	mov    ecx,eax
    733bdd201c2b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201c32:	00 
    733bdd201c33:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    733bdd201c3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201c41:	75 41                	jne    0x733bdd201c84
    733bdd201c43:	e9 88 00 00 00       	jmp    0x733bdd201cd0
    733bdd201c48:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201c4f:	00 
    733bdd201c50:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    733bdd201c57:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    733bdd201c5e:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    733bdd201c65:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    733bdd201c6c:	83 c1 04             	add    ecx,0x4
    733bdd201c6f:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    733bdd201c76:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd201c79:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd201c7f:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd201c82:	eb 5f                	jmp    0x733bdd201ce3
    733bdd201c84:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201c8b:	00 
    733bdd201c8c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201c92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201c98:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201c9e:	be 0e 00 00 00       	mov    esi,0xe
    733bdd201ca3:	b9 04 00 00 00       	mov    ecx,0x4
    733bdd201ca8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201caf:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201cb6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201cbd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201cc4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201ccb:	e9 9a 0d 00 00       	jmp    0x733bdd202a6a
    733bdd201cd0:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    733bdd201cd7:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    733bdd201cde:	e9 65 ff ff ff       	jmp    0x733bdd201c48
    733bdd201ce3:	eb 00                	jmp    0x733bdd201ce5
    733bdd201ce5:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    733bdd201cec:	83 e0 03             	and    eax,0x3
    733bdd201cef:	83 f8 00             	cmp    eax,0x0
    733bdd201cf2:	0f 84 97 00 00 00    	je     0x733bdd201d8f
    733bdd201cf8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201cff:	00 
    733bdd201d00:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd201d07:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201d0e:	00 
    733bdd201d0f:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd201d16:	00 01 00 
    733bdd201d19:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd201d20:	00 00 00 
    733bdd201d23:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd201d2a:	00 00 00 
    733bdd201d2d:	31 c0                	xor    eax,eax
    733bdd201d2f:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd201d36:	59 00 00 
    733bdd201d39:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd201d3e:	45 31 c0             	xor    r8d,r8d
    733bdd201d41:	ff d0                	call   rax
    733bdd201d43:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201d4a:	00 
    733bdd201d4b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201d51:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201d57:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201d5d:	be 0f 00 00 00       	mov    esi,0xf
    733bdd201d62:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd201d67:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201d6e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201d75:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201d7c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201d83:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201d8a:	e9 db 0c 00 00       	jmp    0x733bdd202a6a
    733bdd201d8f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd201d96:	00 
    733bdd201d97:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd201d9e:	c1 e9 0c             	shr    ecx,0xc
    733bdd201da1:	89 c9                	mov    ecx,ecx
    733bdd201da3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd201da7:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    733bdd201dae:	00 
    733bdd201daf:	48 83 f8 00          	cmp    rax,0x0
    733bdd201db3:	74 23                	je     0x733bdd201dd8
    733bdd201db5:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    733bdd201dbc:	00 
    733bdd201dbd:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    733bdd201dc4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd201dca:	89 c9                	mov    ecx,ecx
    733bdd201dcc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd201dcf:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    733bdd201dd6:	eb 5d                	jmp    0x733bdd201e35
    733bdd201dd8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201ddf:	00 
    733bdd201de0:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    733bdd201de7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201dee:	00 
    733bdd201def:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd201df6:	00 01 00 
    733bdd201df9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd201e00:	00 00 00 
    733bdd201e03:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd201e0a:	00 00 00 
    733bdd201e0d:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd201e14:	59 00 00 
    733bdd201e17:	ff d0                	call   rax
    733bdd201e19:	89 c1                	mov    ecx,eax
    733bdd201e1b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201e22:	00 
    733bdd201e23:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    733bdd201e2a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201e31:	75 32                	jne    0x733bdd201e65
    733bdd201e33:	eb 7c                	jmp    0x733bdd201eb1
    733bdd201e35:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    733bdd201e3c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd201e43:	00 
    733bdd201e44:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    733bdd201e4b:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    733bdd201e4e:	83 c0 04             	add    eax,0x4
    733bdd201e51:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    733bdd201e58:	83 e0 03             	and    eax,0x3
    733bdd201e5b:	83 f8 00             	cmp    eax,0x0
    733bdd201e5e:	75 64                	jne    0x733bdd201ec4
    733bdd201e60:	e9 f6 00 00 00       	jmp    0x733bdd201f5b
    733bdd201e65:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201e6c:	00 
    733bdd201e6d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201e73:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201e79:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201e7f:	be 0f 00 00 00       	mov    esi,0xf
    733bdd201e84:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd201e89:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201e90:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201e97:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201e9e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201ea5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201eac:	e9 b9 0b 00 00       	jmp    0x733bdd202a6a
    733bdd201eb1:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    733bdd201eb8:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    733bdd201ebf:	e9 71 ff ff ff       	jmp    0x733bdd201e35
    733bdd201ec4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd201ecb:	00 
    733bdd201ecc:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd201ed3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd201eda:	00 
    733bdd201edb:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd201ee2:	00 01 00 
    733bdd201ee5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd201eec:	00 00 00 
    733bdd201eef:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd201ef6:	00 00 00 
    733bdd201ef9:	31 c0                	xor    eax,eax
    733bdd201efb:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd201f02:	59 00 00 
    733bdd201f05:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd201f0a:	45 31 c0             	xor    r8d,r8d
    733bdd201f0d:	ff d0                	call   rax
    733bdd201f0f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201f16:	00 
    733bdd201f17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd201f1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd201f23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd201f29:	be 0f 00 00 00       	mov    esi,0xf
    733bdd201f2e:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd201f33:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd201f3a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd201f41:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd201f48:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd201f4f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd201f56:	e9 0f 0b 00 00       	jmp    0x733bdd202a6a
    733bdd201f5b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd201f62:	00 
    733bdd201f63:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd201f6a:	c1 e9 0c             	shr    ecx,0xc
    733bdd201f6d:	89 c9                	mov    ecx,ecx
    733bdd201f6f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd201f73:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    733bdd201f7a:	00 
    733bdd201f7b:	48 83 f8 00          	cmp    rax,0x0
    733bdd201f7f:	74 23                	je     0x733bdd201fa4
    733bdd201f81:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd201f88:	00 
    733bdd201f89:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    733bdd201f90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd201f96:	89 c9                	mov    ecx,ecx
    733bdd201f98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd201f9b:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd201fa2:	eb 5d                	jmp    0x733bdd202001
    733bdd201fa4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201fab:	00 
    733bdd201fac:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    733bdd201fb3:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd201fba:	00 
    733bdd201fbb:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd201fc2:	00 01 00 
    733bdd201fc5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd201fcc:	00 00 00 
    733bdd201fcf:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd201fd6:	00 00 00 
    733bdd201fd9:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd201fe0:	59 00 00 
    733bdd201fe3:	ff d0                	call   rax
    733bdd201fe5:	89 c1                	mov    ecx,eax
    733bdd201fe7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd201fee:	00 
    733bdd201fef:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    733bdd201ff6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd201ffd:	75 32                	jne    0x733bdd202031
    733bdd201fff:	eb 7c                	jmp    0x733bdd20207d
    733bdd202001:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    733bdd202008:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd20200f:	00 
    733bdd202010:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    733bdd202017:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    733bdd20201a:	83 c0 04             	add    eax,0x4
    733bdd20201d:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    733bdd202024:	83 e0 03             	and    eax,0x3
    733bdd202027:	83 f8 00             	cmp    eax,0x0
    733bdd20202a:	75 64                	jne    0x733bdd202090
    733bdd20202c:	e9 f6 00 00 00       	jmp    0x733bdd202127
    733bdd202031:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202038:	00 
    733bdd202039:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20203f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202045:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20204b:	be 0f 00 00 00       	mov    esi,0xf
    733bdd202050:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd202055:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20205c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd202063:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20206a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd202071:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202078:	e9 ed 09 00 00       	jmp    0x733bdd202a6a
    733bdd20207d:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    733bdd202084:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    733bdd20208b:	e9 71 ff ff ff       	jmp    0x733bdd202001
    733bdd202090:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd202097:	00 
    733bdd202098:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20209f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2020a6:	00 
    733bdd2020a7:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd2020ae:	00 01 00 
    733bdd2020b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2020b8:	00 00 00 
    733bdd2020bb:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd2020c2:	00 00 00 
    733bdd2020c5:	31 c0                	xor    eax,eax
    733bdd2020c7:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2020ce:	59 00 00 
    733bdd2020d1:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd2020d6:	45 31 c0             	xor    r8d,r8d
    733bdd2020d9:	ff d0                	call   rax
    733bdd2020db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2020e2:	00 
    733bdd2020e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2020e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2020ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2020f5:	be 0f 00 00 00       	mov    esi,0xf
    733bdd2020fa:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2020ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd202106:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20210d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202114:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20211b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202122:	e9 43 09 00 00       	jmp    0x733bdd202a6a
    733bdd202127:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd20212e:	00 
    733bdd20212f:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd202136:	c1 e9 0c             	shr    ecx,0xc
    733bdd202139:	89 c9                	mov    ecx,ecx
    733bdd20213b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20213f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    733bdd202146:	00 
    733bdd202147:	48 83 f8 00          	cmp    rax,0x0
    733bdd20214b:	74 23                	je     0x733bdd202170
    733bdd20214d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    733bdd202154:	00 
    733bdd202155:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    733bdd20215c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd202162:	89 c9                	mov    ecx,ecx
    733bdd202164:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd202167:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd20216e:	eb 5d                	jmp    0x733bdd2021cd
    733bdd202170:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202177:	00 
    733bdd202178:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    733bdd20217f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd202186:	00 
    733bdd202187:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd20218e:	00 01 00 
    733bdd202191:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202198:	00 00 00 
    733bdd20219b:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd2021a2:	00 00 00 
    733bdd2021a5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2021ac:	59 00 00 
    733bdd2021af:	ff d0                	call   rax
    733bdd2021b1:	89 c1                	mov    ecx,eax
    733bdd2021b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2021ba:	00 
    733bdd2021bb:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    733bdd2021c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2021c9:	75 32                	jne    0x733bdd2021fd
    733bdd2021cb:	eb 7c                	jmp    0x733bdd202249
    733bdd2021cd:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    733bdd2021d4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2021db:	00 
    733bdd2021dc:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    733bdd2021e3:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    733bdd2021e6:	83 c0 04             	add    eax,0x4
    733bdd2021e9:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    733bdd2021f0:	83 e0 03             	and    eax,0x3
    733bdd2021f3:	83 f8 00             	cmp    eax,0x0
    733bdd2021f6:	75 64                	jne    0x733bdd20225c
    733bdd2021f8:	e9 f6 00 00 00       	jmp    0x733bdd2022f3
    733bdd2021fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202204:	00 
    733bdd202205:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20220b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202211:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd202217:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20221c:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd202221:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd202228:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20222f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202236:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20223d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202244:	e9 21 08 00 00       	jmp    0x733bdd202a6a
    733bdd202249:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    733bdd202250:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    733bdd202257:	e9 71 ff ff ff       	jmp    0x733bdd2021cd
    733bdd20225c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd202263:	00 
    733bdd202264:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd20226b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd202272:	00 
    733bdd202273:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd20227a:	00 01 00 
    733bdd20227d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd202284:	00 00 00 
    733bdd202287:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd20228e:	00 00 00 
    733bdd202291:	31 c0                	xor    eax,eax
    733bdd202293:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20229a:	59 00 00 
    733bdd20229d:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd2022a2:	45 31 c0             	xor    r8d,r8d
    733bdd2022a5:	ff d0                	call   rax
    733bdd2022a7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2022ae:	00 
    733bdd2022af:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2022b5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2022bb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2022c1:	be 0f 00 00 00       	mov    esi,0xf
    733bdd2022c6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2022cb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2022d2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2022d9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2022e0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2022e7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2022ee:	e9 77 07 00 00       	jmp    0x733bdd202a6a
    733bdd2022f3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2022fa:	00 
    733bdd2022fb:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd202302:	c1 e9 0c             	shr    ecx,0xc
    733bdd202305:	89 c9                	mov    ecx,ecx
    733bdd202307:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20230b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd202312:	00 
    733bdd202313:	48 83 f8 00          	cmp    rax,0x0
    733bdd202317:	74 20                	je     0x733bdd202339
    733bdd202319:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd202320:	00 
    733bdd202321:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    733bdd202328:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20232e:	89 c9                	mov    ecx,ecx
    733bdd202330:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd202333:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd202337:	eb 5a                	jmp    0x733bdd202393
    733bdd202339:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202340:	00 
    733bdd202341:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    733bdd202348:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd20234f:	00 
    733bdd202350:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd202357:	00 01 00 
    733bdd20235a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202361:	00 00 00 
    733bdd202364:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd20236b:	00 00 00 
    733bdd20236e:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd202375:	59 00 00 
    733bdd202378:	ff d0                	call   rax
    733bdd20237a:	89 c1                	mov    ecx,eax
    733bdd20237c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202383:	00 
    733bdd202384:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    733bdd202388:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20238f:	75 2c                	jne    0x733bdd2023bd
    733bdd202391:	eb 76                	jmp    0x733bdd202409
    733bdd202393:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    733bdd20239a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2023a1:	00 
    733bdd2023a2:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    733bdd2023a6:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    733bdd2023a9:	83 c0 04             	add    eax,0x4
    733bdd2023ac:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    733bdd2023b0:	83 e0 03             	and    eax,0x3
    733bdd2023b3:	83 f8 00             	cmp    eax,0x0
    733bdd2023b6:	75 5b                	jne    0x733bdd202413
    733bdd2023b8:	e9 ea 00 00 00       	jmp    0x733bdd2024a7
    733bdd2023bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2023c4:	00 
    733bdd2023c5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2023cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2023d1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2023d7:	be 0f 00 00 00       	mov    esi,0xf
    733bdd2023dc:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2023e1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2023e8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2023ef:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2023f6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2023fd:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202404:	e9 61 06 00 00       	jmp    0x733bdd202a6a
    733bdd202409:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    733bdd20240d:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd202411:	eb 80                	jmp    0x733bdd202393
    733bdd202413:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20241a:	00 
    733bdd20241b:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd20241f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd202426:	00 
    733bdd202427:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd20242e:	00 01 00 
    733bdd202431:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd202438:	00 00 00 
    733bdd20243b:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd202442:	00 00 00 
    733bdd202445:	31 c0                	xor    eax,eax
    733bdd202447:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20244e:	59 00 00 
    733bdd202451:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd202456:	45 31 c0             	xor    r8d,r8d
    733bdd202459:	ff d0                	call   rax
    733bdd20245b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202462:	00 
    733bdd202463:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd202469:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20246f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd202475:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20247a:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20247f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd202486:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20248d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202494:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20249b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2024a2:	e9 c3 05 00 00       	jmp    0x733bdd202a6a
    733bdd2024a7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2024ae:	00 
    733bdd2024af:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd2024b3:	c1 e9 0c             	shr    ecx,0xc
    733bdd2024b6:	89 c9                	mov    ecx,ecx
    733bdd2024b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2024bc:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd2024c1:	48 83 f8 00          	cmp    rax,0x0
    733bdd2024c5:	74 1a                	je     0x733bdd2024e1
    733bdd2024c7:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2024cc:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd2024d0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2024d6:	89 c9                	mov    ecx,ecx
    733bdd2024d8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2024db:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd2024df:	eb 57                	jmp    0x733bdd202538
    733bdd2024e1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2024e8:	00 
    733bdd2024e9:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    733bdd2024ed:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd2024f4:	00 
    733bdd2024f5:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd2024fc:	00 01 00 
    733bdd2024ff:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202506:	00 00 00 
    733bdd202509:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd202510:	00 00 00 
    733bdd202513:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20251a:	59 00 00 
    733bdd20251d:	ff d0                	call   rax
    733bdd20251f:	89 c1                	mov    ecx,eax
    733bdd202521:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202528:	00 
    733bdd202529:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    733bdd20252d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd202534:	75 29                	jne    0x733bdd20255f
    733bdd202536:	eb 73                	jmp    0x733bdd2025ab
    733bdd202538:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    733bdd20253c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd202543:	00 
    733bdd202544:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    733bdd202548:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    733bdd20254b:	83 c0 04             	add    eax,0x4
    733bdd20254e:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd202552:	83 e0 03             	and    eax,0x3
    733bdd202555:	83 f8 00             	cmp    eax,0x0
    733bdd202558:	75 5b                	jne    0x733bdd2025b5
    733bdd20255a:	e9 ea 00 00 00       	jmp    0x733bdd202649
    733bdd20255f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202566:	00 
    733bdd202567:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20256d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202573:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd202579:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20257e:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd202583:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20258a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd202591:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202598:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20259f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2025a6:	e9 bf 04 00 00       	jmp    0x733bdd202a6a
    733bdd2025ab:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    733bdd2025af:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd2025b3:	eb 83                	jmp    0x733bdd202538
    733bdd2025b5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd2025bc:	00 
    733bdd2025bd:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd2025c1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd2025c8:	00 
    733bdd2025c9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd2025d0:	00 01 00 
    733bdd2025d3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2025da:	00 00 00 
    733bdd2025dd:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd2025e4:	00 00 00 
    733bdd2025e7:	31 c0                	xor    eax,eax
    733bdd2025e9:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2025f0:	59 00 00 
    733bdd2025f3:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd2025f8:	45 31 c0             	xor    r8d,r8d
    733bdd2025fb:	ff d0                	call   rax
    733bdd2025fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202604:	00 
    733bdd202605:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20260b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202611:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd202617:	be 0f 00 00 00       	mov    esi,0xf
    733bdd20261c:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd202621:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd202628:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd20262f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202636:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20263d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202644:	e9 21 04 00 00       	jmp    0x733bdd202a6a
    733bdd202649:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd202650:	00 
    733bdd202651:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd202655:	c1 e9 0c             	shr    ecx,0xc
    733bdd202658:	89 c9                	mov    ecx,ecx
    733bdd20265a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd20265e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd202663:	48 83 f8 00          	cmp    rax,0x0
    733bdd202667:	74 1a                	je     0x733bdd202683
    733bdd202669:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd20266e:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd202672:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd202678:	89 c9                	mov    ecx,ecx
    733bdd20267a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20267d:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd202681:	eb 57                	jmp    0x733bdd2026da
    733bdd202683:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20268a:	00 
    733bdd20268b:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    733bdd20268f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd202696:	00 
    733bdd202697:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd20269e:	00 01 00 
    733bdd2026a1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd2026a8:	00 00 00 
    733bdd2026ab:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd2026b2:	00 00 00 
    733bdd2026b5:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2026bc:	59 00 00 
    733bdd2026bf:	ff d0                	call   rax
    733bdd2026c1:	89 c1                	mov    ecx,eax
    733bdd2026c3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2026ca:	00 
    733bdd2026cb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd2026cf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2026d6:	75 29                	jne    0x733bdd202701
    733bdd2026d8:	eb 73                	jmp    0x733bdd20274d
    733bdd2026da:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    733bdd2026de:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd2026e5:	00 
    733bdd2026e6:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    733bdd2026ea:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    733bdd2026ed:	83 c0 04             	add    eax,0x4
    733bdd2026f0:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd2026f4:	83 e0 03             	and    eax,0x3
    733bdd2026f7:	83 f8 00             	cmp    eax,0x0
    733bdd2026fa:	75 5b                	jne    0x733bdd202757
    733bdd2026fc:	e9 ea 00 00 00       	jmp    0x733bdd2027eb
    733bdd202701:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202708:	00 
    733bdd202709:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd20270f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd202715:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd20271b:	be 0f 00 00 00       	mov    esi,0xf
    733bdd202720:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd202725:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20272c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd202733:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd20273a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd202741:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202748:	e9 1d 03 00 00       	jmp    0x733bdd202a6a
    733bdd20274d:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd202751:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd202755:	eb 83                	jmp    0x733bdd2026da
    733bdd202757:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd20275e:	00 
    733bdd20275f:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd202763:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    733bdd20276a:	00 
    733bdd20276b:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    733bdd202772:	00 01 00 
    733bdd202775:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20277c:	00 00 00 
    733bdd20277f:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    733bdd202786:	00 00 00 
    733bdd202789:	31 c0                	xor    eax,eax
    733bdd20278b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd202792:	59 00 00 
    733bdd202795:	ba 3c 00 01 00       	mov    edx,0x1003c
    733bdd20279a:	45 31 c0             	xor    r8d,r8d
    733bdd20279d:	ff d0                	call   rax
    733bdd20279f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2027a6:	00 
    733bdd2027a7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2027ad:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2027b3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2027b9:	be 0f 00 00 00       	mov    esi,0xf
    733bdd2027be:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2027c3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2027ca:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2027d1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2027d8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2027df:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2027e6:	e9 7f 02 00 00       	jmp    0x733bdd202a6a
    733bdd2027eb:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    733bdd2027f2:	00 
    733bdd2027f3:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd2027f7:	c1 e9 0c             	shr    ecx,0xc
    733bdd2027fa:	89 c9                	mov    ecx,ecx
    733bdd2027fc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd202800:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd202805:	48 83 f8 00          	cmp    rax,0x0
    733bdd202809:	74 1a                	je     0x733bdd202825
    733bdd20280b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd202810:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd202814:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20281a:	89 c9                	mov    ecx,ecx
    733bdd20281c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd20281f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd202823:	eb 57                	jmp    0x733bdd20287c
    733bdd202825:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20282c:	00 
    733bdd20282d:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd202831:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    733bdd202838:	00 
    733bdd202839:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    733bdd202840:	00 01 00 
    733bdd202843:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd20284a:	00 00 00 
    733bdd20284d:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    733bdd202854:	00 00 00 
    733bdd202857:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20285e:	59 00 00 
    733bdd202861:	ff d0                	call   rax
    733bdd202863:	89 c1                	mov    ecx,eax
    733bdd202865:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20286c:	00 
    733bdd20286d:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd202871:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd202878:	75 1d                	jne    0x733bdd202897
    733bdd20287a:	eb 67                	jmp    0x733bdd2028e3
    733bdd20287c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202883:	00 
    733bdd202884:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd202888:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    733bdd20288c:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    733bdd20288f:	83 c1 04             	add    ecx,0x4
    733bdd202892:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd202895:	eb 56                	jmp    0x733bdd2028ed
    733bdd202897:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd20289e:	00 
    733bdd20289f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd2028a5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2028ab:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd2028b1:	be 0f 00 00 00       	mov    esi,0xf
    733bdd2028b6:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd2028bb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2028c2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2028c9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2028d0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2028d7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2028de:	e9 87 01 00 00       	jmp    0x733bdd202a6a
    733bdd2028e3:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd2028e7:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd2028eb:	eb 8f                	jmp    0x733bdd20287c
    733bdd2028ed:	eb 00                	jmp    0x733bdd2028ef
    733bdd2028ef:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    733bdd2028f6:	83 e0 01             	and    eax,0x1
    733bdd2028f9:	83 f8 00             	cmp    eax,0x0
    733bdd2028fc:	75 3d                	jne    0x733bdd20293b
    733bdd2028fe:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    733bdd202905:	be 10 00 00 00       	mov    esi,0x10
    733bdd20290a:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20290f:	b0 01                	mov    al,0x1
    733bdd202911:	89 d7                	mov    edi,edx
    733bdd202913:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd20291a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd202921:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd202928:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd20292f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd202936:	e9 2f 01 00 00       	jmp    0x733bdd202a6a
    733bdd20293b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    733bdd202942:	00 
    733bdd202943:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    733bdd20294a:	00 
    733bdd20294b:	c7 87 bc 00 00 00 3e 	mov    DWORD PTR [rdi+0xbc],0x1003e
    733bdd202952:	00 01 00 
    733bdd202955:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20295c:	00 00 00 
    733bdd20295f:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    733bdd202966:	00 00 00 
    733bdd202969:	48 b8 d0 ca 25 8c cb 	movabs rax,0x59cb8c25cad0
    733bdd202970:	59 00 00 
    733bdd202973:	be 2a 00 00 00       	mov    esi,0x2a
    733bdd202978:	ff d0                	call   rax
    733bdd20297a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202981:	00 
    733bdd202982:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    733bdd202988:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20298e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    733bdd202994:	be 10 00 00 00       	mov    esi,0x10
    733bdd202999:	b9 02 00 00 00       	mov    ecx,0x2
    733bdd20299e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    733bdd2029a5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    733bdd2029ac:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    733bdd2029b3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    733bdd2029ba:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    733bdd2029c1:	e9 a4 00 00 00       	jmp    0x733bdd202a6a
    733bdd2029c6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd2029cd:	00 
    733bdd2029ce:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd2029d5:	e9 82 01 00 00       	jmp    0x733bdd202b5c
    733bdd2029da:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd2029e1:	00 
    733bdd2029e2:	48 89 c1             	mov    rcx,rax
    733bdd2029e5:	48 81 c1 00 02 08 00 	add    rcx,0x80200
    733bdd2029ec:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd2029f1:	81 b8 00 02 08 00 40 	cmp    DWORD PTR [rax+0x80200],0x10040
    733bdd2029f8:	00 01 00 
    733bdd2029fb:	74 32                	je     0x733bdd202a2f
    733bdd2029fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202a04:	00 
    733bdd202a05:	c7 80 bc 00 00 00 40 	mov    DWORD PTR [rax+0xbc],0x10040
    733bdd202a0c:	00 01 00 
    733bdd202a0f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd202a16:	00 00 00 
    733bdd202a19:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    733bdd202a20:	00 00 00 
    733bdd202a23:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd202a2a:	e9 2d 01 00 00       	jmp    0x733bdd202b5c
    733bdd202a2f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd202a36:	00 
    733bdd202a37:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd202a3e:	00 
    733bdd202a3f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd202a44:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    733bdd202a4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    733bdd202a52:	40 00 01 00 
    733bdd202a56:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd202a5d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd202a61:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd202a68:	ff e0                	jmp    rax
    733bdd202a6a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    733bdd202a71:	00 
    733bdd202a72:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    733bdd202a79:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    733bdd202a80:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    733bdd202a87:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    733bdd202a8e:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    733bdd202a95:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    733bdd202a99:	89 c3                	mov    ebx,eax
    733bdd202a9b:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    733bdd202a9f:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    733bdd202aa3:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    733bdd202aa7:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    733bdd202aab:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd202ab1:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    733bdd202ab5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd202abb:	73 2d                	jae    0x733bdd202aea
    733bdd202abd:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    733bdd202ac4:	00 
    733bdd202ac5:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd202ac9:	89 d1                	mov    ecx,edx
    733bdd202acb:	c1 e9 01             	shr    ecx,0x1
    733bdd202ace:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd202ad4:	89 c9                	mov    ecx,ecx
    733bdd202ad6:	48 c1 e1 04          	shl    rcx,0x4
    733bdd202ada:	48 89 c6             	mov    rsi,rax
    733bdd202add:	48 01 ce             	add    rsi,rcx
    733bdd202ae0:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd202ae5:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd202ae8:	74 32                	je     0x733bdd202b1c
    733bdd202aea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    733bdd202af1:	00 
    733bdd202af2:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    733bdd202af6:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd202afa:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    733bdd202afe:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    733bdd202b02:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    733bdd202b08:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    733bdd202b0e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    733bdd202b14:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    733bdd202b1a:	eb 40                	jmp    0x733bdd202b5c
    733bdd202b1c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    733bdd202b23:	00 
    733bdd202b24:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    733bdd202b2b:	00 
    733bdd202b2c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd202b31:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    733bdd202b35:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    733bdd202b39:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    733bdd202b40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd202b47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd202b4e:	00 
    733bdd202b4f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd202b53:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd202b5a:	ff e0                	jmp    rax
    733bdd202b5c:	48 81 c4 18 02 00 00 	add    rsp,0x218
    733bdd202b63:	c2 08 00             	ret    0x8
