
build-native-instruction-analysis/capture/bcore-default-branch/pc-66724-0-126700950159664.bin:     file format binary


Disassembly of section .data:

0000733bdd208130 <.data>:
    733bdd208130:	48 81 ec c8 00 00 00 	sub    rsp,0xc8
    733bdd208137:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
    733bdd20813e:	00 
    733bdd20813f:	4c 89 ac 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r13
    733bdd208146:	00 
    733bdd208147:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd20814e:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    733bdd208155:	00 
    733bdd208156:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd20815d:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    733bdd208164:	00 
    733bdd208165:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    733bdd20816c:	00 
    733bdd20816d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd208173:	83 fa 00             	cmp    edx,0x0
    733bdd208176:	0f 94 c0             	sete   al
    733bdd208179:	81 ea a4 04 01 00    	sub    edx,0x104a4
    733bdd20817f:	83 fa 18             	cmp    edx,0x18
    733bdd208182:	0f 97 c2             	seta   dl
    733bdd208185:	08 d0                	or     al,dl
    733bdd208187:	24 01                	and    al,0x1
    733bdd208189:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd20818f:	83 fa 00             	cmp    edx,0x0
    733bdd208192:	0f 94 c1             	sete   cl
    733bdd208195:	81 ea a4 04 01 00    	sub    edx,0x104a4
    733bdd20819b:	83 fa 18             	cmp    edx,0x18
    733bdd20819e:	0f 97 c2             	seta   dl
    733bdd2081a1:	08 d1                	or     cl,dl
    733bdd2081a3:	20 c8                	and    al,cl
    733bdd2081a5:	a8 01                	test   al,0x1
    733bdd2081a7:	75 05                	jne    0x733bdd2081ae
    733bdd2081a9:	e9 08 07 00 00       	jmp    0x733bdd2088b6
    733bdd2081ae:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2081b5:	00 
    733bdd2081b6:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd2081bd:	48 89 c8             	mov    rax,rcx
    733bdd2081c0:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd2081c6:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    733bdd2081cd:	00 
    733bdd2081ce:	8b 81 1c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10001c]
    733bdd2081d4:	83 c0 01             	add    eax,0x1
    733bdd2081d7:	89 81 1c 00 10 00    	mov    DWORD PTR [rcx+0x10001c],eax
    733bdd2081dd:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd2081e2:	75 4c                	jne    0x733bdd208230
    733bdd2081e4:	48 8b 8c 24 a0 00 00 	mov    rcx,QWORD PTR [rsp+0xa0]
    733bdd2081eb:	00 
    733bdd2081ec:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd2081f2:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    733bdd2081f9:	89 c2                	mov    edx,eax
    733bdd2081fb:	83 c2 01             	add    edx,0x1
    733bdd2081fe:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd208204:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd208209:	73 23                	jae    0x733bdd20822e
    733bdd20820b:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    733bdd208212:	00 
    733bdd208213:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    733bdd20821a:	89 c9                	mov    ecx,ecx
    733bdd20821c:	48 c1 e1 02          	shl    rcx,0x2
    733bdd208220:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd208227:	c7 04 08 07 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x7
    733bdd20822e:	eb 00                	jmp    0x733bdd208230
    733bdd208230:	eb 00                	jmp    0x733bdd208232
    733bdd208232:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208239:	00 
    733bdd20823a:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    733bdd20823d:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd208243:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd208249:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    733bdd208250:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd208253:	eb 00                	jmp    0x733bdd208255
    733bdd208255:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd20825c:	00 
    733bdd20825d:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    733bdd208264:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20826a:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    733bdd208270:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    733bdd208277:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd20827a:	eb 00                	jmp    0x733bdd20827c
    733bdd20827c:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    733bdd208283:	83 e0 03             	and    eax,0x3
    733bdd208286:	83 f8 00             	cmp    eax,0x0
    733bdd208289:	74 7d                	je     0x733bdd208308
    733bdd20828b:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd208292:	00 
    733bdd208293:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20829a:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    733bdd2082a1:	00 
    733bdd2082a2:	c7 87 bc 00 00 00 ac 	mov    DWORD PTR [rdi+0xbc],0x104ac
    733bdd2082a9:	04 01 00 
    733bdd2082ac:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd2082b3:	00 00 00 
    733bdd2082b6:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd2082bd:	00 00 00 
    733bdd2082c0:	31 c0                	xor    eax,eax
    733bdd2082c2:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2082c9:	59 00 00 
    733bdd2082cc:	ba ac 04 01 00       	mov    edx,0x104ac
    733bdd2082d1:	45 31 c0             	xor    r8d,r8d
    733bdd2082d4:	ff d0                	call   rax
    733bdd2082d6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2082dd:	00 
    733bdd2082de:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2082e4:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd2082e9:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2082ee:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd2082f5:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd2082fc:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd208303:	e9 4f 06 00 00       	jmp    0x733bdd208957
    733bdd208308:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd20830f:	00 
    733bdd208310:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd208317:	c1 e9 0c             	shr    ecx,0xc
    733bdd20831a:	89 c9                	mov    ecx,ecx
    733bdd20831c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd208320:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd208327:	00 
    733bdd208328:	48 83 f8 00          	cmp    rax,0x0
    733bdd20832c:	74 20                	je     0x733bdd20834e
    733bdd20832e:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd208335:	00 
    733bdd208336:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd20833d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd208343:	89 c9                	mov    ecx,ecx
    733bdd208345:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd208348:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd20834c:	eb 5a                	jmp    0x733bdd2083a8
    733bdd20834e:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208355:	00 
    733bdd208356:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    733bdd20835d:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    733bdd208364:	00 
    733bdd208365:	c7 80 bc 00 00 00 ac 	mov    DWORD PTR [rax+0xbc],0x104ac
    733bdd20836c:	04 01 00 
    733bdd20836f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd208376:	00 00 00 
    733bdd208379:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd208380:	00 00 00 
    733bdd208383:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20838a:	59 00 00 
    733bdd20838d:	ff d0                	call   rax
    733bdd20838f:	89 c1                	mov    ecx,eax
    733bdd208391:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208398:	00 
    733bdd208399:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    733bdd20839d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2083a4:	75 12                	jne    0x733bdd2083b8
    733bdd2083a6:	eb 42                	jmp    0x733bdd2083ea
    733bdd2083a8:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2083af:	00 
    733bdd2083b0:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    733bdd2083b4:	89 08                	mov    DWORD PTR [rax],ecx
    733bdd2083b6:	eb 3c                	jmp    0x733bdd2083f4
    733bdd2083b8:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2083bf:	00 
    733bdd2083c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2083c6:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd2083cb:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2083d0:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd2083d7:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd2083de:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd2083e5:	e9 6d 05 00 00       	jmp    0x733bdd208957
    733bdd2083ea:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    733bdd2083ee:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    733bdd2083f2:	eb b4                	jmp    0x733bdd2083a8
    733bdd2083f4:	eb 00                	jmp    0x733bdd2083f6
    733bdd2083f6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2083fd:	00 
    733bdd2083fe:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    733bdd208405:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd20840b:	81 c9 00 00 01 00    	or     ecx,0x10000
    733bdd208411:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    733bdd208415:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd208418:	eb 00                	jmp    0x733bdd20841a
    733bdd20841a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208421:	00 
    733bdd208422:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    733bdd208426:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    733bdd20842c:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    733bdd208432:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    733bdd208436:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    733bdd208439:	eb 00                	jmp    0x733bdd20843b
    733bdd20843b:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    733bdd20843f:	83 e0 03             	and    eax,0x3
    733bdd208442:	83 f8 00             	cmp    eax,0x0
    733bdd208445:	74 7a                	je     0x733bdd2084c1
    733bdd208447:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd20844e:	00 
    733bdd20844f:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd208453:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    733bdd20845a:	00 
    733bdd20845b:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x104b6
    733bdd208462:	04 01 00 
    733bdd208465:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd20846c:	00 00 00 
    733bdd20846f:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    733bdd208476:	00 00 00 
    733bdd208479:	31 c0                	xor    eax,eax
    733bdd20847b:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd208482:	59 00 00 
    733bdd208485:	ba b6 04 01 00       	mov    edx,0x104b6
    733bdd20848a:	45 31 c0             	xor    r8d,r8d
    733bdd20848d:	ff d0                	call   rax
    733bdd20848f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208496:	00 
    733bdd208497:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20849d:	b9 06 00 00 00       	mov    ecx,0x6
    733bdd2084a2:	b8 02 00 00 00       	mov    eax,0x2
    733bdd2084a7:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd2084ae:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd2084b5:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd2084bc:	e9 96 04 00 00       	jmp    0x733bdd208957
    733bdd2084c1:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd2084c8:	00 
    733bdd2084c9:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd2084cd:	c1 e9 0c             	shr    ecx,0xc
    733bdd2084d0:	89 c9                	mov    ecx,ecx
    733bdd2084d2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2084d6:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd2084db:	48 83 f8 00          	cmp    rax,0x0
    733bdd2084df:	74 1a                	je     0x733bdd2084fb
    733bdd2084e1:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd2084e6:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    733bdd2084ea:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2084f0:	89 c9                	mov    ecx,ecx
    733bdd2084f2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2084f5:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd2084f9:	eb 57                	jmp    0x733bdd208552
    733bdd2084fb:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208502:	00 
    733bdd208503:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    733bdd208507:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    733bdd20850e:	00 
    733bdd20850f:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x104b6
    733bdd208516:	04 01 00 
    733bdd208519:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd208520:	00 00 00 
    733bdd208523:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    733bdd20852a:	00 00 00 
    733bdd20852d:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd208534:	59 00 00 
    733bdd208537:	ff d0                	call   rax
    733bdd208539:	89 c1                	mov    ecx,eax
    733bdd20853b:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208542:	00 
    733bdd208543:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    733bdd208547:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd20854e:	75 13                	jne    0x733bdd208563
    733bdd208550:	eb 43                	jmp    0x733bdd208595
    733bdd208552:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208559:	00 
    733bdd20855a:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd20855e:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    733bdd208561:	eb 3c                	jmp    0x733bdd20859f
    733bdd208563:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd20856a:	00 
    733bdd20856b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208571:	b9 06 00 00 00       	mov    ecx,0x6
    733bdd208576:	b8 02 00 00 00       	mov    eax,0x2
    733bdd20857b:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd208582:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd208589:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd208590:	e9 c2 03 00 00       	jmp    0x733bdd208957
    733bdd208595:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    733bdd208599:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd20859d:	eb b3                	jmp    0x733bdd208552
    733bdd20859f:	eb 00                	jmp    0x733bdd2085a1
    733bdd2085a1:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2085a8:	00 
    733bdd2085a9:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    733bdd2085ac:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    733bdd2085b0:	83 e0 03             	and    eax,0x3
    733bdd2085b3:	83 f8 00             	cmp    eax,0x0
    733bdd2085b6:	74 7a                	je     0x733bdd208632
    733bdd2085b8:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd2085bf:	00 
    733bdd2085c0:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd2085c4:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    733bdd2085cb:	00 
    733bdd2085cc:	c7 87 bc 00 00 00 b8 	mov    DWORD PTR [rdi+0xbc],0x104b8
    733bdd2085d3:	04 01 00 
    733bdd2085d6:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd2085dd:	00 00 00 
    733bdd2085e0:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    733bdd2085e7:	00 00 00 
    733bdd2085ea:	31 c0                	xor    eax,eax
    733bdd2085ec:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd2085f3:	59 00 00 
    733bdd2085f6:	ba b8 04 01 00       	mov    edx,0x104b8
    733bdd2085fb:	45 31 c0             	xor    r8d,r8d
    733bdd2085fe:	ff d0                	call   rax
    733bdd208600:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208607:	00 
    733bdd208608:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20860e:	b9 07 00 00 00       	mov    ecx,0x7
    733bdd208613:	b8 04 00 00 00       	mov    eax,0x4
    733bdd208618:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd20861f:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd208626:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd20862d:	e9 25 03 00 00       	jmp    0x733bdd208957
    733bdd208632:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd208639:	00 
    733bdd20863a:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20863e:	c1 e9 0c             	shr    ecx,0xc
    733bdd208641:	89 c9                	mov    ecx,ecx
    733bdd208643:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd208647:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    733bdd20864c:	48 83 f8 00          	cmp    rax,0x0
    733bdd208650:	74 1a                	je     0x733bdd20866c
    733bdd208652:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    733bdd208657:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    733bdd20865b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd208661:	89 c9                	mov    ecx,ecx
    733bdd208663:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd208666:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20866a:	eb 57                	jmp    0x733bdd2086c3
    733bdd20866c:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208673:	00 
    733bdd208674:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    733bdd208678:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    733bdd20867f:	00 
    733bdd208680:	c7 80 bc 00 00 00 b8 	mov    DWORD PTR [rax+0xbc],0x104b8
    733bdd208687:	04 01 00 
    733bdd20868a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd208691:	00 00 00 
    733bdd208694:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd20869b:	00 00 00 
    733bdd20869e:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd2086a5:	59 00 00 
    733bdd2086a8:	ff d0                	call   rax
    733bdd2086aa:	89 c1                	mov    ecx,eax
    733bdd2086ac:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2086b3:	00 
    733bdd2086b4:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    733bdd2086b8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd2086bf:	75 22                	jne    0x733bdd2086e3
    733bdd2086c1:	eb 52                	jmp    0x733bdd208715
    733bdd2086c3:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    733bdd2086c7:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd2086cb:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    733bdd2086cf:	83 c0 04             	add    eax,0x4
    733bdd2086d2:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    733bdd2086d6:	83 e0 03             	and    eax,0x3
    733bdd2086d9:	83 f8 00             	cmp    eax,0x0
    733bdd2086dc:	75 41                	jne    0x733bdd20871f
    733bdd2086de:	e9 b6 00 00 00       	jmp    0x733bdd208799
    733bdd2086e3:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2086ea:	00 
    733bdd2086eb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd2086f1:	b9 07 00 00 00       	mov    ecx,0x7
    733bdd2086f6:	b8 04 00 00 00       	mov    eax,0x4
    733bdd2086fb:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd208702:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd208709:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd208710:	e9 42 02 00 00       	jmp    0x733bdd208957
    733bdd208715:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    733bdd208719:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd20871d:	eb a4                	jmp    0x733bdd2086c3
    733bdd20871f:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    733bdd208726:	00 
    733bdd208727:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20872b:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    733bdd208732:	00 
    733bdd208733:	c7 87 bc 00 00 00 b8 	mov    DWORD PTR [rdi+0xbc],0x104b8
    733bdd20873a:	04 01 00 
    733bdd20873d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    733bdd208744:	00 00 00 
    733bdd208747:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    733bdd20874e:	00 00 00 
    733bdd208751:	31 c0                	xor    eax,eax
    733bdd208753:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd20875a:	59 00 00 
    733bdd20875d:	ba b8 04 01 00       	mov    edx,0x104b8
    733bdd208762:	45 31 c0             	xor    r8d,r8d
    733bdd208765:	ff d0                	call   rax
    733bdd208767:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd20876e:	00 
    733bdd20876f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd208775:	b9 07 00 00 00       	mov    ecx,0x7
    733bdd20877a:	b8 04 00 00 00       	mov    eax,0x4
    733bdd20877f:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd208786:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd20878d:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd208794:	e9 be 01 00 00       	jmp    0x733bdd208957
    733bdd208799:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    733bdd2087a0:	00 
    733bdd2087a1:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd2087a5:	c1 e9 0c             	shr    ecx,0xc
    733bdd2087a8:	89 c9                	mov    ecx,ecx
    733bdd2087aa:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd2087ae:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd2087b3:	48 83 f8 00          	cmp    rax,0x0
    733bdd2087b7:	74 1a                	je     0x733bdd2087d3
    733bdd2087b9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd2087be:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd2087c2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd2087c8:	89 c9                	mov    ecx,ecx
    733bdd2087ca:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    733bdd2087cd:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd2087d1:	eb 57                	jmp    0x733bdd20882a
    733bdd2087d3:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2087da:	00 
    733bdd2087db:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    733bdd2087df:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    733bdd2087e6:	00 
    733bdd2087e7:	c7 80 bc 00 00 00 b8 	mov    DWORD PTR [rax+0xbc],0x104b8
    733bdd2087ee:	04 01 00 
    733bdd2087f1:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd2087f8:	00 00 00 
    733bdd2087fb:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    733bdd208802:	00 00 00 
    733bdd208805:	48 b8 f0 75 14 8c cb 	movabs rax,0x59cb8c1475f0
    733bdd20880c:	59 00 00 
    733bdd20880f:	ff d0                	call   rax
    733bdd208811:	89 c1                	mov    ecx,eax
    733bdd208813:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd20881a:	00 
    733bdd20881b:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    733bdd20881f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd208826:	75 27                	jne    0x733bdd20884f
    733bdd208828:	eb 57                	jmp    0x733bdd208881
    733bdd20882a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208831:	00 
    733bdd208832:	8b 74 24 40          	mov    esi,DWORD PTR [rsp+0x40]
    733bdd208836:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    733bdd20883a:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    733bdd20883e:	83 c1 04             	add    ecx,0x4
    733bdd208841:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    733bdd208844:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    733bdd20884a:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    733bdd20884d:	eb 3c                	jmp    0x733bdd20888b
    733bdd20884f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd208856:	00 
    733bdd208857:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd20885d:	b9 07 00 00 00       	mov    ecx,0x7
    733bdd208862:	b8 04 00 00 00       	mov    eax,0x4
    733bdd208867:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    733bdd20886e:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    733bdd208875:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    733bdd20887c:	e9 d6 00 00 00       	jmp    0x733bdd208957
    733bdd208881:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    733bdd208885:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd208889:	eb 9f                	jmp    0x733bdd20882a
    733bdd20888b:	eb 00                	jmp    0x733bdd20888d
    733bdd20888d:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    733bdd208894:	00 
    733bdd208895:	c7 81 bc 00 00 00 4c 	mov    DWORD PTR [rcx+0xbc],0x1014c
    733bdd20889c:	01 01 00 
    733bdd20889f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd2088a5:	83 c0 08             	add    eax,0x8
    733bdd2088a8:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    733bdd2088ac:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd2088b2:	72 16                	jb     0x733bdd2088ca
    733bdd2088b4:	eb 37                	jmp    0x733bdd2088ed
    733bdd2088b6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2088bd:	00 
    733bdd2088be:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd2088c5:	e9 4a 01 00 00       	jmp    0x733bdd208a14
    733bdd2088ca:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd2088d1:	00 
    733bdd2088d2:	48 89 c1             	mov    rcx,rax
    733bdd2088d5:	48 81 c1 60 0a 08 00 	add    rcx,0x80a60
    733bdd2088dc:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd2088e1:	81 b8 60 0a 08 00 4c 	cmp    DWORD PTR [rax+0x80a60],0x1014c
    733bdd2088e8:	01 01 00 
    733bdd2088eb:	74 32                	je     0x733bdd20891f
    733bdd2088ed:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2088f4:	00 
    733bdd2088f5:	c7 80 bc 00 00 00 4c 	mov    DWORD PTR [rax+0xbc],0x1014c
    733bdd2088fc:	01 01 00 
    733bdd2088ff:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd208906:	00 00 00 
    733bdd208909:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    733bdd208910:	00 00 00 
    733bdd208913:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd20891a:	e9 f5 00 00 00       	jmp    0x733bdd208a14
    733bdd20891f:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    733bdd208926:	00 
    733bdd208927:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    733bdd20892e:	00 
    733bdd20892f:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd208934:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    733bdd208938:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1014c
    733bdd20893f:	4c 01 01 00 
    733bdd208943:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd20894a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd20894e:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    733bdd208955:	ff e0                	jmp    rax
    733bdd208957:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    733bdd20895e:	00 
    733bdd20895f:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    733bdd208966:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    733bdd20896d:	8b b4 24 90 00 00 00 	mov    esi,DWORD PTR [rsp+0x90]
    733bdd208974:	89 c7                	mov    edi,eax
    733bdd208976:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd20897a:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd20897e:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd208982:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd208988:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd20898c:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd208992:	73 2d                	jae    0x733bdd2089c1
    733bdd208994:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    733bdd20899b:	00 
    733bdd20899c:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd2089a0:	89 d1                	mov    ecx,edx
    733bdd2089a2:	c1 e9 01             	shr    ecx,0x1
    733bdd2089a5:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd2089ab:	89 c9                	mov    ecx,ecx
    733bdd2089ad:	48 c1 e1 04          	shl    rcx,0x4
    733bdd2089b1:	48 89 c6             	mov    rsi,rax
    733bdd2089b4:	48 01 ce             	add    rsi,rcx
    733bdd2089b7:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd2089bc:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd2089bf:	74 1e                	je     0x733bdd2089df
    733bdd2089c1:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    733bdd2089c8:	00 
    733bdd2089c9:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd2089cd:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd2089d1:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd2089d7:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd2089dd:	eb 35                	jmp    0x733bdd208a14
    733bdd2089df:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    733bdd2089e6:	00 
    733bdd2089e7:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    733bdd2089ee:	00 
    733bdd2089ef:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd2089f4:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd2089f8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd2089ff:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd208a06:	00 
    733bdd208a07:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd208a0b:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    733bdd208a12:	ff e0                	jmp    rax
    733bdd208a14:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    733bdd208a1b:	c2 08 00             	ret    0x8
