
build-native-instruction-analysis/capture/bcore-default-branch/pc-65682-0-126700950153680.bin:     file format binary


Disassembly of section .data:

0000733bdd2069d0 <.data>:
    733bdd2069d0:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    733bdd2069d7:	4c 89 74 24 70       	mov    QWORD PTR [rsp+0x70],r14
    733bdd2069dc:	4c 89 6c 24 78       	mov    QWORD PTR [rsp+0x78],r13
    733bdd2069e1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    733bdd2069e8:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    733bdd2069ef:	00 
    733bdd2069f0:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    733bdd2069f7:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    733bdd2069fe:	00 
    733bdd2069ff:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    733bdd206a06:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    733bdd206a0d:	00 
    733bdd206a0e:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    733bdd206a13:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    733bdd206a19:	83 fa 00             	cmp    edx,0x0
    733bdd206a1c:	0f 94 c0             	sete   al
    733bdd206a1f:	81 ea 92 00 01 00    	sub    edx,0x10092
    733bdd206a25:	83 fa 06             	cmp    edx,0x6
    733bdd206a28:	0f 97 c2             	seta   dl
    733bdd206a2b:	08 d0                	or     al,dl
    733bdd206a2d:	24 01                	and    al,0x1
    733bdd206a2f:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    733bdd206a35:	83 fa 00             	cmp    edx,0x0
    733bdd206a38:	0f 94 c1             	sete   cl
    733bdd206a3b:	81 ea 92 00 01 00    	sub    edx,0x10092
    733bdd206a41:	83 fa 06             	cmp    edx,0x6
    733bdd206a44:	0f 97 c2             	seta   dl
    733bdd206a47:	08 d1                	or     cl,dl
    733bdd206a49:	20 c8                	and    al,cl
    733bdd206a4b:	a8 01                	test   al,0x1
    733bdd206a4d:	75 05                	jne    0x733bdd206a54
    733bdd206a4f:	e9 4f 03 00 00       	jmp    0x733bdd206da3
    733bdd206a54:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206a59:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    733bdd206a60:	48 89 c8             	mov    rax,rcx
    733bdd206a63:	48 05 00 00 10 00    	add    rax,0x100000
    733bdd206a69:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    733bdd206a6e:	8b 81 10 00 10 00    	mov    eax,DWORD PTR [rcx+0x100010]
    733bdd206a74:	83 c0 01             	add    eax,0x1
    733bdd206a77:	89 81 10 00 10 00    	mov    DWORD PTR [rcx+0x100010],eax
    733bdd206a7d:	3d 30 75 00 00       	cmp    eax,0x7530
    733bdd206a82:	75 40                	jne    0x733bdd206ac4
    733bdd206a84:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    733bdd206a89:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    733bdd206a8f:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    733bdd206a93:	89 c2                	mov    edx,eax
    733bdd206a95:	83 c2 01             	add    edx,0x1
    733bdd206a98:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    733bdd206a9e:	3d 00 01 00 00       	cmp    eax,0x100
    733bdd206aa3:	73 1d                	jae    0x733bdd206ac2
    733bdd206aa5:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    733bdd206aaa:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    733bdd206aae:	89 c9                	mov    ecx,ecx
    733bdd206ab0:	48 c1 e1 02          	shl    rcx,0x2
    733bdd206ab4:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    733bdd206abb:	c7 04 08 04 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x4
    733bdd206ac2:	eb 00                	jmp    0x733bdd206ac4
    733bdd206ac4:	eb 00                	jmp    0x733bdd206ac6
    733bdd206ac6:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206acb:	8b 38                	mov    edi,DWORD PTR [rax]
    733bdd206acd:	89 fa                	mov    edx,edi
    733bdd206acf:	83 ea 00             	sub    edx,0x0
    733bdd206ad2:	83 fa 00             	cmp    edx,0x0
    733bdd206ad5:	0f 94 c1             	sete   cl
    733bdd206ad8:	80 e1 01             	and    cl,0x1
    733bdd206adb:	0f b6 f1             	movzx  esi,cl
    733bdd206ade:	89 74 24 58          	mov    DWORD PTR [rsp+0x58],esi
    733bdd206ae2:	c1 ea 1f             	shr    edx,0x1f
    733bdd206ae5:	89 f9                	mov    ecx,edi
    733bdd206ae7:	c1 e9 1f             	shr    ecx,0x1f
    733bdd206aea:	89 d3                	mov    ebx,edx
    733bdd206aec:	31 cb                	xor    ebx,ecx
    733bdd206aee:	83 f1 00             	xor    ecx,0x0
    733bdd206af1:	21 d9                	and    ecx,ebx
    733bdd206af3:	31 ca                	xor    edx,ecx
    733bdd206af5:	31 c9                	xor    ecx,ecx
    733bdd206af7:	39 f9                	cmp    ecx,edi
    733bdd206af9:	0f 96 c1             	setbe  cl
    733bdd206afc:	80 e1 01             	and    cl,0x1
    733bdd206aff:	0f b6 c9             	movzx  ecx,cl
    733bdd206b02:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    733bdd206b08:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    733bdd206b0e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    733bdd206b14:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    733bdd206b1a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    733bdd206b20:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    733bdd206b26:	89 4c 24 5c          	mov    DWORD PTR [rsp+0x5c],ecx
    733bdd206b2a:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    733bdd206b30:	89 44 24 60          	mov    DWORD PTR [rsp+0x60],eax
    733bdd206b34:	eb 00                	jmp    0x733bdd206b36
    733bdd206b36:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    733bdd206b3a:	83 f8 00             	cmp    eax,0x0
    733bdd206b3d:	75 2d                	jne    0x733bdd206b6c
    733bdd206b3f:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    733bdd206b44:	c7 81 bc 00 00 00 c0 	mov    DWORD PTR [rcx+0xbc],0x100c0
    733bdd206b4b:	00 01 00 
    733bdd206b4e:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd206b54:	83 c0 02             	add    eax,0x2
    733bdd206b57:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    733bdd206b5b:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd206b61:	0f 82 4d 02 00 00    	jb     0x733bdd206db4
    733bdd206b67:	e9 6b 02 00 00       	jmp    0x733bdd206dd7
    733bdd206b6c:	eb 00                	jmp    0x733bdd206b6e
    733bdd206b6e:	eb 00                	jmp    0x733bdd206b70
    733bdd206b70:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    733bdd206b75:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    733bdd206b78:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    733bdd206b7c:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    733bdd206b7f:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    733bdd206b83:	83 e0 03             	and    eax,0x3
    733bdd206b86:	83 f8 00             	cmp    eax,0x0
    733bdd206b89:	74 69                	je     0x733bdd206bf4
    733bdd206b8b:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    733bdd206b90:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd206b94:	48 8b 74 24 70       	mov    rsi,QWORD PTR [rsp+0x70]
    733bdd206b99:	c7 87 bc 00 00 00 96 	mov    DWORD PTR [rdi+0xbc],0x10096
    733bdd206ba0:	00 01 00 
    733bdd206ba3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd206baa:	00 00 00 
    733bdd206bad:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd206bb4:	00 00 00 
    733bdd206bb7:	48 b8 d0 d8 25 8c cb 	movabs rax,0x59cb8c25d8d0
    733bdd206bbe:	59 00 00 
    733bdd206bc1:	ba 96 00 01 00       	mov    edx,0x10096
    733bdd206bc6:	41 b8 00 00 01 00    	mov    r8d,0x10000
    733bdd206bcc:	ff d0                	call   rax
    733bdd206bce:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206bd3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd206bd9:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd206bde:	b8 02 00 00 00       	mov    eax,0x2
    733bdd206be3:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    733bdd206be7:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    733bdd206beb:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    733bdd206bef:	e9 c8 02 00 00       	jmp    0x733bdd206ebc
    733bdd206bf4:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    733bdd206bfb:	00 
    733bdd206bfc:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd206c00:	c1 e9 0c             	shr    ecx,0xc
    733bdd206c03:	89 c9                	mov    ecx,ecx
    733bdd206c05:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    733bdd206c09:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    733bdd206c0e:	48 83 f8 00          	cmp    rax,0x0
    733bdd206c12:	74 1a                	je     0x733bdd206c2e
    733bdd206c14:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    733bdd206c19:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    733bdd206c1d:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    733bdd206c21:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd206c27:	89 c9                	mov    ecx,ecx
    733bdd206c29:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    733bdd206c2c:	eb 4c                	jmp    0x733bdd206c7a
    733bdd206c2e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206c33:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    733bdd206c37:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    733bdd206c3b:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    733bdd206c40:	c7 80 bc 00 00 00 96 	mov    DWORD PTR [rax+0xbc],0x10096
    733bdd206c47:	00 01 00 
    733bdd206c4a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206c51:	00 00 00 
    733bdd206c54:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    733bdd206c5b:	00 00 00 
    733bdd206c5e:	48 b8 20 76 14 8c cb 	movabs rax,0x59cb8c147620
    733bdd206c65:	59 00 00 
    733bdd206c68:	ff d0                	call   rax
    733bdd206c6a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206c6f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd206c76:	75 11                	jne    0x733bdd206c89
    733bdd206c78:	eb 35                	jmp    0x733bdd206caf
    733bdd206c7a:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    733bdd206c81:	00 
    733bdd206c82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    733bdd206c85:	75 2a                	jne    0x733bdd206cb1
    733bdd206c87:	eb 67                	jmp    0x733bdd206cf0
    733bdd206c89:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206c8e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd206c94:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd206c99:	b8 02 00 00 00       	mov    eax,0x2
    733bdd206c9e:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    733bdd206ca2:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    733bdd206ca6:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    733bdd206caa:	e9 0d 02 00 00       	jmp    0x733bdd206ebc
    733bdd206caf:	eb c9                	jmp    0x733bdd206c7a
    733bdd206cb1:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    733bdd206cb6:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10098
    733bdd206cbd:	00 01 00 
    733bdd206cc0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    733bdd206cc7:	00 00 00 
    733bdd206cca:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    733bdd206cd1:	00 00 00 
    733bdd206cd4:	48 b8 00 d6 25 8c cb 	movabs rax,0x59cb8c25d600
    733bdd206cdb:	59 00 00 
    733bdd206cde:	ff d0                	call   rax
    733bdd206ce0:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206ce5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    733bdd206cec:	75 04                	jne    0x733bdd206cf2
    733bdd206cee:	eb 28                	jmp    0x733bdd206d18
    733bdd206cf0:	eb 28                	jmp    0x733bdd206d1a
    733bdd206cf2:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206cf7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    733bdd206cfd:	b9 03 00 00 00       	mov    ecx,0x3
    733bdd206d02:	b8 02 00 00 00       	mov    eax,0x2
    733bdd206d07:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    733bdd206d0b:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    733bdd206d0f:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    733bdd206d13:	e9 a4 01 00 00       	jmp    0x733bdd206ebc
    733bdd206d18:	eb d6                	jmp    0x733bdd206cf0
    733bdd206d1a:	eb 00                	jmp    0x733bdd206d1c
    733bdd206d1c:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    733bdd206d21:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    733bdd206d25:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    733bdd206d29:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    733bdd206d2f:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    733bdd206d35:	83 ff 01             	cmp    edi,0x1
    733bdd206d38:	0f 97 c3             	seta   bl
    733bdd206d3b:	3d 98 00 01 00       	cmp    eax,0x10098
    733bdd206d40:	0f 94 c0             	sete   al
    733bdd206d43:	20 c3                	and    bl,al
    733bdd206d45:	b8 9c 00 01 00       	mov    eax,0x1009c
    733bdd206d4a:	f6 c3 01             	test   bl,0x1
    733bdd206d4d:	0f 45 c2             	cmovne eax,edx
    733bdd206d50:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    733bdd206d56:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    733bdd206d5c:	83 ff 01             	cmp    edi,0x1
    733bdd206d5f:	0f 97 c3             	seta   bl
    733bdd206d62:	81 fe 98 00 01 00    	cmp    esi,0x10098
    733bdd206d68:	40 0f 94 c6          	sete   sil
    733bdd206d6c:	40 20 f3             	and    bl,sil
    733bdd206d6f:	f6 c3 01             	test   bl,0x1
    733bdd206d72:	0f 45 c2             	cmovne eax,edx
    733bdd206d75:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    733bdd206d7b:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10428
    733bdd206d82:	04 01 00 
    733bdd206d85:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    733bdd206d8b:	83 c0 04             	add    eax,0x4
    733bdd206d8e:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    733bdd206d92:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd206d98:	0f 82 9a 00 00 00    	jb     0x733bdd206e38
    733bdd206d9e:	e9 b8 00 00 00       	jmp    0x733bdd206e5b
    733bdd206da3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206da8:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    733bdd206daf:	e9 b0 01 00 00       	jmp    0x733bdd206f64
    733bdd206db4:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd206dbb:	00 
    733bdd206dbc:	48 89 c1             	mov    rcx,rax
    733bdd206dbf:	48 81 c1 00 06 08 00 	add    rcx,0x80600
    733bdd206dc6:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    733bdd206dcb:	81 b8 00 06 08 00 c0 	cmp    DWORD PTR [rax+0x80600],0x100c0
    733bdd206dd2:	00 01 00 
    733bdd206dd5:	74 2f                	je     0x733bdd206e06
    733bdd206dd7:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206ddc:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x100c0
    733bdd206de3:	00 01 00 
    733bdd206de6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    733bdd206ded:	00 00 00 
    733bdd206df0:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    733bdd206df7:	00 00 00 
    733bdd206dfa:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd206e01:	e9 5e 01 00 00       	jmp    0x733bdd206f64
    733bdd206e06:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    733bdd206e0b:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    733bdd206e10:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    733bdd206e15:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    733bdd206e19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    733bdd206e20:	c0 00 01 00 
    733bdd206e24:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd206e2b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206e2f:	48 81 c4 98 00 00 00 	add    rsp,0x98
    733bdd206e36:	ff e0                	jmp    rax
    733bdd206e38:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd206e3f:	00 
    733bdd206e40:	48 89 c1             	mov    rcx,rax
    733bdd206e43:	48 81 c1 40 21 08 00 	add    rcx,0x82140
    733bdd206e4a:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    733bdd206e4f:	81 b8 40 21 08 00 28 	cmp    DWORD PTR [rax+0x82140],0x10428
    733bdd206e56:	04 01 00 
    733bdd206e59:	74 2f                	je     0x733bdd206e8a
    733bdd206e5b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206e60:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10428
    733bdd206e67:	04 01 00 
    733bdd206e6a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    733bdd206e71:	00 00 00 
    733bdd206e74:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    733bdd206e7b:	00 00 00 
    733bdd206e7e:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    733bdd206e85:	e9 da 00 00 00       	jmp    0x733bdd206f64
    733bdd206e8a:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    733bdd206e8f:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    733bdd206e94:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    733bdd206e99:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    733bdd206e9d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    733bdd206ea4:	28 04 01 00 
    733bdd206ea8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd206eaf:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206eb3:	48 81 c4 98 00 00 00 	add    rsp,0x98
    733bdd206eba:	ff e0                	jmp    rax
    733bdd206ebc:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    733bdd206ec1:	8b 54 24 40          	mov    edx,DWORD PTR [rsp+0x40]
    733bdd206ec5:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    733bdd206ec9:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    733bdd206ecd:	89 c7                	mov    edi,eax
    733bdd206ecf:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    733bdd206ed3:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    733bdd206ed7:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    733bdd206edb:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    733bdd206ee1:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    733bdd206ee5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    733bdd206eeb:	73 2d                	jae    0x733bdd206f1a
    733bdd206eed:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    733bdd206ef4:	00 
    733bdd206ef5:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    733bdd206ef9:	89 d1                	mov    ecx,edx
    733bdd206efb:	c1 e9 01             	shr    ecx,0x1
    733bdd206efe:	81 e1 ff ff 00 00    	and    ecx,0xffff
    733bdd206f04:	89 c9                	mov    ecx,ecx
    733bdd206f06:	48 c1 e1 04          	shl    rcx,0x4
    733bdd206f0a:	48 89 c6             	mov    rsi,rax
    733bdd206f0d:	48 01 ce             	add    rsi,rcx
    733bdd206f10:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    733bdd206f15:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    733bdd206f18:	74 1b                	je     0x733bdd206f35
    733bdd206f1a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    733bdd206f1f:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    733bdd206f23:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    733bdd206f27:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    733bdd206f2d:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    733bdd206f33:	eb 2f                	jmp    0x733bdd206f64
    733bdd206f35:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    733bdd206f3a:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    733bdd206f3f:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    733bdd206f44:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    733bdd206f48:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    733bdd206f4f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd206f56:	00 
    733bdd206f57:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    733bdd206f5b:	48 81 c4 98 00 00 00 	add    rsp,0x98
    733bdd206f62:	ff e0                	jmp    rax
    733bdd206f64:	48 81 c4 98 00 00 00 	add    rsp,0x98
    733bdd206f6b:	c2 08 00             	ret    0x8
