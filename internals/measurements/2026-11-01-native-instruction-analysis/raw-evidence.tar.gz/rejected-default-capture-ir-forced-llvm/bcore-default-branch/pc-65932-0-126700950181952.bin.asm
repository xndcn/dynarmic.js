
build-native-instruction-analysis/capture/bcore-default-branch/pc-65932-0-126700950181952.bin:     file format binary


Disassembly of section .data:

0000733bdd20d840 <.data>:
    733bdd20d840:	48 83 ec 18          	sub    rsp,0x18
    733bdd20d844:	b8 65 fe fe ff       	mov    eax,0xfffefe65
    733bdd20d849:	41 8b 8d a0 00 00 00 	mov    ecx,DWORD PTR [r13+0xa0]
    733bdd20d850:	01 c1                	add    ecx,eax
    733bdd20d852:	83 f9 f0             	cmp    ecx,0xfffffff0
    733bdd20d855:	0f 87 64 2f ff 17    	ja     0x733bf52007bf
    733bdd20d85b:	41 03 85 a4 00 00 00 	add    eax,DWORD PTR [r13+0xa4]
    733bdd20d862:	83 f8 f0             	cmp    eax,0xfffffff0
    733bdd20d865:	0f 87 54 2f ff 17    	ja     0x733bf52007bf
    733bdd20d86b:	4d 8b a5 38 01 00 00 	mov    r12,QWORD PTR [r13+0x138]
    733bdd20d872:	4d 8b 85 50 01 00 00 	mov    r8,QWORD PTR [r13+0x150]
    733bdd20d879:	41 8b 45 14          	mov    eax,DWORD PTR [r13+0x14]
    733bdd20d87d:	41 8b 4d 18          	mov    ecx,DWORD PTR [r13+0x18]
    733bdd20d881:	8d 51 01             	lea    edx,[rcx+0x1]
    733bdd20d884:	41 89 55 18          	mov    DWORD PTR [r13+0x18],edx
    733bdd20d888:	c1 e9 1f             	shr    ecx,0x1f
    733bdd20d88b:	89 d6                	mov    esi,edx
    733bdd20d88d:	c1 ee 1f             	shr    esi,0x1f
    733bdd20d890:	c4 e2 70 f2 ce       	andn   ecx,ecx,esi
    733bdd20d895:	41 89 8d f8 00 00 00 	mov    DWORD PTR [r13+0xf8],ecx
    733bdd20d89c:	41 89 8d fc 00 00 00 	mov    DWORD PTR [r13+0xfc],ecx
    733bdd20d8a3:	41 09 8d 00 01 00 00 	or     DWORD PTR [r13+0x100],ecx
    733bdd20d8aa:	31 c9                	xor    ecx,ecx
    733bdd20d8ac:	31 f6                	xor    esi,esi
    733bdd20d8ae:	31 ff                	xor    edi,edi
    733bdd20d8b0:	31 db                	xor    ebx,ebx
    733bdd20d8b2:	39 c2                	cmp    edx,eax
    733bdd20d8b4:	0f 97 c1             	seta   cl
    733bdd20d8b7:	40 0f 96 c6          	setbe  sil
    733bdd20d8bb:	40 0f 93 c7          	setae  dil
    733bdd20d8bf:	41 89 bd 14 01 00 00 	mov    DWORD PTR [r13+0x114],edi
    733bdd20d8c6:	0f 94 c3             	sete   bl
    733bdd20d8c9:	41 89 9d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ebx
    733bdd20d8d0:	41 89 8d e8 00 00 00 	mov    DWORD PTR [r13+0xe8],ecx
    733bdd20d8d7:	41 89 b5 ec 00 00 00 	mov    DWORD PTR [r13+0xec],esi
    733bdd20d8de:	41 89 b5 f0 00 00 00 	mov    DWORD PTR [r13+0xf0],esi
    733bdd20d8e5:	0f 82 ab 01 00 00    	jb     0x733bdd20da96
    733bdd20d8eb:	41 8b 45 00          	mov    eax,DWORD PTR [r13+0x0]
    733bdd20d8ef:	41 8b 6d 3c          	mov    ebp,DWORD PTR [r13+0x3c]
    733bdd20d8f3:	31 c9                	xor    ecx,ecx
    733bdd20d8f5:	41 33 45 1c          	xor    eax,DWORD PTR [r13+0x1c]
    733bdd20d8f9:	41 89 45 00          	mov    DWORD PTR [r13+0x0],eax
    733bdd20d8fd:	0f 94 c1             	sete   cl
    733bdd20d900:	c1 e8 1f             	shr    eax,0x1f
    733bdd20d903:	41 89 8d e4 00 00 00 	mov    DWORD PTR [r13+0xe4],ecx
    733bdd20d90a:	41 89 85 e8 00 00 00 	mov    DWORD PTR [r13+0xe8],eax
    733bdd20d911:	49 c7 85 ec 00 00 00 	mov    QWORD PTR [r13+0xec],0x0
    733bdd20d918:	00 00 00 00 
    733bdd20d91c:	49 c7 85 f8 00 00 00 	mov    QWORD PTR [r13+0xf8],0x0
    733bdd20d923:	00 00 00 00 
    733bdd20d927:	40 f6 c5 03          	test   bpl,0x3
    733bdd20d92b:	0f 85 f0 2e ff 17    	jne    0x733bf5200821
    733bdd20d931:	48 89 e8             	mov    rax,rbp
    733bdd20d934:	48 c1 e8 0c          	shr    rax,0xc
    733bdd20d938:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d93c:	48 85 c0             	test   rax,rax
    733bdd20d93f:	0f 84 3d 2f ff 17    	je     0x733bf5200882
    733bdd20d945:	89 e9                	mov    ecx,ebp
    733bdd20d947:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    733bdd20d94d:	8b 1c 08             	mov    ebx,DWORD PTR [rax+rcx*1]
    733bdd20d950:	8d 75 04             	lea    esi,[rbp+0x4]
    733bdd20d953:	89 f0                	mov    eax,esi
    733bdd20d955:	c1 e8 0c             	shr    eax,0xc
    733bdd20d958:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d95c:	48 85 c0             	test   rax,rax
    733bdd20d95f:	0f 84 7a 2f ff 17    	je     0x733bf52008df
    733bdd20d965:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20d96b:	44 8b 3c 30          	mov    r15d,DWORD PTR [rax+rsi*1]
    733bdd20d96f:	8d 75 08             	lea    esi,[rbp+0x8]
    733bdd20d972:	41 89 5d 3c          	mov    DWORD PTR [r13+0x3c],ebx
    733bdd20d976:	45 89 bd a8 00 00 00 	mov    DWORD PTR [r13+0xa8],r15d
    733bdd20d97d:	41 89 75 38          	mov    DWORD PTR [r13+0x38],esi
    733bdd20d981:	89 f0                	mov    eax,esi
    733bdd20d983:	c1 e8 0c             	shr    eax,0xc
    733bdd20d986:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d98a:	48 85 c0             	test   rax,rax
    733bdd20d98d:	0f 84 a8 2f ff 17    	je     0x733bf520093b
    733bdd20d993:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20d999:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    733bdd20d99c:	41 89 45 34          	mov    DWORD PTR [r13+0x34],eax
    733bdd20d9a0:	8d 75 0c             	lea    esi,[rbp+0xc]
    733bdd20d9a3:	89 f0                	mov    eax,esi
    733bdd20d9a5:	c1 e8 0c             	shr    eax,0xc
    733bdd20d9a8:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d9ac:	48 85 c0             	test   rax,rax
    733bdd20d9af:	0f 84 df 2f ff 17    	je     0x733bf5200994
    733bdd20d9b5:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20d9bb:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    733bdd20d9be:	41 89 45 1c          	mov    DWORD PTR [r13+0x1c],eax
    733bdd20d9c2:	8d 75 10             	lea    esi,[rbp+0x10]
    733bdd20d9c5:	89 f0                	mov    eax,esi
    733bdd20d9c7:	c1 e8 0c             	shr    eax,0xc
    733bdd20d9ca:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d9ce:	48 85 c0             	test   rax,rax
    733bdd20d9d1:	0f 84 16 30 ff 17    	je     0x733bf52009ed
    733bdd20d9d7:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20d9dd:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    733bdd20d9e0:	41 89 45 18          	mov    DWORD PTR [r13+0x18],eax
    733bdd20d9e4:	8d 75 14             	lea    esi,[rbp+0x14]
    733bdd20d9e7:	89 f0                	mov    eax,esi
    733bdd20d9e9:	c1 e8 0c             	shr    eax,0xc
    733bdd20d9ec:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20d9f0:	48 85 c0             	test   rax,rax
    733bdd20d9f3:	0f 84 4d 30 ff 17    	je     0x733bf5200a46
    733bdd20d9f9:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20d9ff:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    733bdd20da02:	41 89 45 14          	mov    DWORD PTR [r13+0x14],eax
    733bdd20da06:	8d 75 18             	lea    esi,[rbp+0x18]
    733bdd20da09:	89 f0                	mov    eax,esi
    733bdd20da0b:	c1 e8 0c             	shr    eax,0xc
    733bdd20da0e:	49 8b 04 c4          	mov    rax,QWORD PTR [r12+rax*8]
    733bdd20da12:	48 85 c0             	test   rax,rax
    733bdd20da15:	0f 84 84 30 ff 17    	je     0x733bf5200a9f
    733bdd20da1b:	81 e6 ff 0f 00 00    	and    esi,0xfff
    733bdd20da21:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    733bdd20da24:	41 89 45 10          	mov    DWORD PTR [r13+0x10],eax
    733bdd20da28:	83 c5 1c             	add    ebp,0x1c
    733bdd20da2b:	41 89 6d 38          	mov    DWORD PTR [r13+0x38],ebp
    733bdd20da2f:	b1 01                	mov    cl,0x1
    733bdd20da31:	bb 07 00 00 00       	mov    ebx,0x7
    733bdd20da36:	bd 02 00 00 00       	mov    ebp,0x2
    733bdd20da3b:	41 f6 c7 01          	test   r15b,0x1
    733bdd20da3f:	0f 85 af 30 ff 17    	jne    0x733bf5200af4
    733bdd20da45:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    733bdd20da4c:	01 d8                	add    eax,ebx
    733bdd20da4e:	41 8b 95 58 01 00 00 	mov    edx,DWORD PTR [r13+0x158]
    733bdd20da55:	39 d0                	cmp    eax,edx
    733bdd20da57:	0f 83 71 2d ff 17    	jae    0x733bf52007ce
    733bdd20da5d:	42 8d 14 fd 00 00 00 	lea    edx,[r15*8+0x0]
    733bdd20da64:	00 
    733bdd20da65:	81 e2 f0 ff 0f 00    	and    edx,0xffff0
    733bdd20da6b:	45 39 3c 10          	cmp    DWORD PTR [r8+rdx*1],r15d
    733bdd20da6f:	0f 85 59 2d ff 17    	jne    0x733bf52007ce
    733bdd20da75:	45 89 bd bc 00 00 00 	mov    DWORD PTR [r13+0xbc],r15d
    733bdd20da7c:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    733bdd20da83:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    733bdd20da8a:	00 
    733bdd20da8b:	49 8b 44 10 08       	mov    rax,QWORD PTR [r8+rdx*1+0x8]
    733bdd20da90:	48 83 c4 18          	add    rsp,0x18
    733bdd20da94:	ff e0                	jmp    rax
    733bdd20da96:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    733bdd20da9d:	7c 01 01 00 
    733bdd20daa1:	41 8b 85 5c 01 00 00 	mov    eax,DWORD PTR [r13+0x15c]
    733bdd20daa8:	83 c0 03             	add    eax,0x3
    733bdd20daab:	41 8b 8d 58 01 00 00 	mov    ecx,DWORD PTR [r13+0x158]
    733bdd20dab2:	39 c8                	cmp    eax,ecx
    733bdd20dab4:	0f 83 37 2d ff 17    	jae    0x733bf52007f1
    733bdd20daba:	41 81 b8 e0 0b 08 00 	cmp    DWORD PTR [r8+0x80be0],0x1017c
    733bdd20dac1:	7c 01 01 00 
    733bdd20dac5:	0f 85 26 2d ff 17    	jne    0x733bf52007f1
    733bdd20dacb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1017c
    733bdd20dad2:	7c 01 01 00 
    733bdd20dad6:	41 89 85 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],eax
    733bdd20dadd:	49 8b 80 e8 0b 08 00 	mov    rax,QWORD PTR [r8+0x80be8]
    733bdd20dae4:	48 83 c4 18          	add    rsp,0x18
    733bdd20dae8:	ff e0                	jmp    rax
