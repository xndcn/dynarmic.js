; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010176(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %1 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %1, align 4
  %2 = icmp eq i32 %guard_lb, 0
  %3 = sub i32 %guard_lb, 65910
  %4 = icmp ugt i32 %3, 18
  %5 = or i1 %2, %4
  %6 = and i1 true, %5
  %7 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb23 = load i32, ptr %7, align 4
  %8 = icmp eq i32 %guard_lb23, 0
  %9 = sub i32 %guard_lb23, 65910
  %10 = icmp ugt i32 %9, 18
  %11 = or i1 %8, %10
  %12 = and i1 %6, %11
  br i1 %12, label %insn_0x00010176_entry, label %lb_guard_miss, !prof !0

insn_0x00010176_entry:                            ; preds = %lb_guard
  %13 = getelementptr i8, ptr %cpu, i64 336
  %chain_table43 = load ptr, ptr %13, align 8
  %tier_table = getelementptr i8, ptr %chain_table43, i64 1048576
  %14 = getelementptr i8, ptr %tier_table, i64 48
  %15 = load i32, ptr %14, align 4
  %tier_count = add i32 %15, 1
  store i32 %tier_count, ptr %14, align 4
  %16 = icmp eq i32 %tier_count, 30000
  br i1 %16, label %17, label %27, !prof !1

17:                                               ; preds = %insn_0x00010176_entry
  %18 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %18, align 4
  %19 = add i32 %tier_requests, 1
  store i32 %19, ptr %18, align 4
  %20 = icmp ult i32 %tier_requests, 256
  br i1 %20, label %21, label %26

21:                                               ; preds = %17
  %22 = zext i32 %tier_requests to i64
  %23 = mul i64 %22, 4
  %24 = add i64 262148, %23
  %25 = getelementptr i8, ptr %tier_table, i64 %24
  store i32 12, ptr %25, align 4
  br label %26

26:                                               ; preds = %17, %21
  br label %27

27:                                               ; preds = %insn_0x00010176_entry, %26
  br label %insn_0x00010176

insn_0x00010176:                                  ; preds = %27
  %28 = getelementptr i8, ptr %cpu, i32 24
  %rd = load i32, ptr %28, align 4
  %rd_add = add i32 %rd, 1
  %29 = getelementptr i8, ptr %cpu, i32 24
  store i32 %rd_add, ptr %29, align 4
  %flgs = lshr i32 %rd, 31
  %flgn = lshr i32 %rd_add, 31
  %30 = xor i32 0, %flgn
  %31 = xor i32 %flgs, %flgn
  %overflow = and i32 %31, %30
  %32 = xor i32 %rd, -1
  %33 = icmp ult i32 %32, 1
  %ac0 = zext i1 %33 to i32
  %34 = icmp eq i32 %rd_add, 0
  %az = zext i1 %34 to i32
  %an = lshr i32 %rd_add, 31
  %35 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %35, align 4
  %36 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %37, align 4
  %38 = or i32 %vs_cur, %overflow
  %39 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %39, align 4
  %40 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 256
  store i32 %38, ptr %41, align 4
  %42 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %45, align 4
  br label %insn_0x00010178_entry

insn_0x00010178_entry:                            ; preds = %insn_0x00010176
  br label %insn_0x00010178

insn_0x00010178:                                  ; preds = %insn_0x00010178_entry
  %46 = getelementptr i8, ptr %cpu, i32 20
  %rx = load i32, ptr %46, align 4
  %47 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %47 to i32
  %48 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %48, align 4
  %49 = icmp eq i32 %rx, %rd_add
  %az1 = zext i1 %49 to i32
  %50 = icmp ugt i32 %rd_add, %rx
  %an2 = zext i1 %50 to i32
  %51 = icmp ule i32 %rd_add, %rx
  %ac03 = zext i1 %51 to i32
  %52 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac03, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac03, ptr %55, align 4
  br label %insn_0x0001017a_entry

insn_0x0001017a_entry:                            ; preds = %insn_0x00010178
  br label %insn_0x0001017a

insn_0x0001017a:                                  ; preds = %insn_0x0001017a_entry
  %cc_true = icmp ne i32 %cc, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x0001017a
  %56 = getelementptr i8, ptr %cpu, i32 188
  store i32 65938, ptr %56, align 4
  %57 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %57, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %58 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %58 monotonic, align 4, !range !2
  %59 = icmp ult i32 %chain_total, %chain_budget
  br i1 %59, label %chain_go, label %chain_leave24, !prof !0

brt_fallthru:                                     ; preds = %insn_0x0001017a
  br label %insn_0x0001017c_entry

insn_0x0001017c_entry:                            ; preds = %brt_fallthru
  br label %insn_0x0001017c

insn_0x0001017c:                                  ; preds = %insn_0x0001017c_entry
  %60 = getelementptr i8, ptr %cpu, i32 28
  %a = load i32, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 16
  %b = load i32, ptr %61, align 4
  %mul = mul i32 %a, %b
  %62 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mul, ptr %62, align 4
  br label %insn_0x0001017e_entry

insn_0x0001017e_entry:                            ; preds = %insn_0x0001017c
  br label %insn_0x0001017e

insn_0x0001017e:                                  ; preds = %insn_0x0001017e_entry
  %63 = getelementptr i8, ptr %cpu, i32 52
  %regmv_src = load i32, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 4
  store i32 %regmv_src, ptr %64, align 4
  br label %insn_0x00010180_entry

insn_0x00010180_entry:                            ; preds = %insn_0x0001017e
  br label %insn_0x00010180

insn_0x00010180:                                  ; preds = %insn_0x00010180_entry
  %add32 = add i32 %mul, %regmv_src
  %65 = getelementptr i8, ptr %cpu, i32 28
  store i32 %add32, ptr %65, align 4
  %flgs4 = lshr i32 %mul, 31
  %flgo = lshr i32 %regmv_src, 31
  %flgn5 = lshr i32 %add32, 31
  %66 = xor i32 %flgo, %flgn5
  %67 = xor i32 %flgs4, %flgn5
  %68 = and i32 %67, %66
  %69 = xor i32 %mul, -1
  %70 = icmp ult i32 %69, %regmv_src
  %ac06 = zext i1 %70 to i32
  %71 = icmp eq i32 %add32, 0
  %az7 = zext i1 %71 to i32
  %an8 = lshr i32 %add32, 31
  %72 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az7, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an8, ptr %73, align 4
  %74 = or i32 %38, %68
  %75 = getelementptr i8, ptr %cpu, i32 248
  store i32 %68, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 252
  store i32 %68, ptr %76, align 4
  %77 = getelementptr i8, ptr %cpu, i32 256
  store i32 %74, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac06, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac06, ptr %79, align 4
  br label %insn_0x00010182_entry

insn_0x00010182_entry:                            ; preds = %insn_0x00010180
  br label %insn_0x00010182

insn_0x00010182:                                  ; preds = %insn_0x00010182_entry
  %diff = sub i32 %add32, 0
  %80 = icmp eq i32 %diff, 0
  %az9 = zext i1 %80 to i32
  %flgn10 = lshr i32 %diff, 31
  %flgs11 = lshr i32 %add32, 31
  %81 = xor i32 %flgn10, %flgs11
  %82 = xor i32 %flgs11, 0
  %overflow12 = and i32 %82, %81
  %an13 = xor i32 %flgn10, %overflow12
  %83 = icmp ule i32 0, %add32
  %ac014 = zext i1 %83 to i32
  %84 = getelementptr i8, ptr %cpu, i32 276
  store i32 %an13, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az9, ptr %85, align 4
  %86 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an13, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac014, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac014, ptr %88, align 4
  br label %insn_0x00010184_entry

insn_0x00010184_entry:                            ; preds = %insn_0x00010182
  br label %insn_0x00010184

insn_0x00010184:                                  ; preds = %insn_0x00010184_entry
  %cc_false = icmp eq i32 %an13, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010184
  %89 = getelementptr i8, ptr %cpu, i32 188
  store i32 65904, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets27 = load i32, ptr %90, align 4
  %chain_total28 = add nuw i32 %chain_packets27, 8
  %91 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget29 = load atomic i32, ptr %91 monotonic, align 4, !range !2
  %92 = icmp ult i32 %chain_total28, %chain_budget29
  br i1 %92, label %chain_go25, label %chain_leave26, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010184
  br label %insn_0x00010186_entry

insn_0x00010186_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010186

insn_0x00010186:                                  ; preds = %insn_0x00010186_entry
  %93 = getelementptr i8, ptr %cpu, i32 0
  %rt = load i32, ptr %93, align 4
  %xor32 = xor i32 %rt, %add32
  %94 = getelementptr i8, ptr %cpu, i32 0
  store i32 %xor32, ptr %94, align 4
  %95 = icmp eq i32 %xor32, 0
  %az15 = zext i1 %95 to i32
  %an16 = lshr i32 %xor32, 31
  %96 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az15, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an16, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %100, align 4
  %101 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %101, align 4
  br label %insn_0x00010188_entry

insn_0x00010188_entry:                            ; preds = %insn_0x00010186
  br label %insn_0x00010188

insn_0x00010188:                                  ; preds = %insn_0x00010188_entry
  %102 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %103, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65928
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65932
  %104 = getelementptr i8, ptr %cpu, i32 156
  %lc17 = load i32, ptr %104, align 4
  %105 = getelementptr i8, ptr %cpu, i32 148
  %lt18 = load i32, ptr %105, align 4
  %lc_gt119 = icmp ugt i32 %lc17, 1
  %at_lb20 = icmp eq i32 %lb1, 65928
  %hwloop_cond21 = and i1 %lc_gt119, %at_lb20
  %hwloop_rets22 = select i1 %hwloop_cond21, i32 %lt18, i32 %hwloop_rets
  %106 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets22, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i32 188
  store i32 65808, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets36 = load i32, ptr %108, align 4
  %chain_total37 = add nuw i32 %chain_packets36, 10
  %109 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget38 = load atomic i32, ptr %109 monotonic, align 4, !range !2
  %110 = icmp ult i32 %chain_total37, %chain_budget38
  br i1 %110, label %chain_go34, label %chain_leave35, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %111 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %111, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 527504
  %112 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %112, align 4
  %113 = icmp eq i32 %slot_pc, 65938
  br i1 %113, label %chain_hit, label %chain_leave24, !prof !0

chain_leave24:                                    ; preds = %chain_go, %brt_taken
  %114 = getelementptr i8, ptr %cpu, i64 188
  store i32 65938, ptr %114, align 4
  %115 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %116, align 4
  %117 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %117, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %118 = getelementptr i8, ptr %cpu, i64 188
  store i32 65938, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %119, align 4
  %120 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %120, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go25:                                       ; preds = %brcc_taken
  %chain_slot30 = getelementptr i8, ptr %chain_table, i64 527232
  %121 = getelementptr i8, ptr %chain_slot30, i64 0
  %slot_pc31 = load i32, ptr %121, align 4
  %122 = icmp eq i32 %slot_pc31, 65904
  br i1 %122, label %chain_hit32, label %chain_leave26, !prof !0

chain_leave26:                                    ; preds = %chain_go25, %brcc_taken
  %123 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %126, align 1
  br label %return

chain_hit32:                                      ; preds = %chain_go25
  %127 = getelementptr i8, ptr %cpu, i64 188
  store i32 65904, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total28, ptr %128, align 4
  %129 = getelementptr i8, ptr %chain_slot30, i64 8
  %chain_fn33 = load ptr, ptr %129, align 8
  musttail call swifttailcc void %chain_fn33(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go34:                                       ; preds = %insn_0x00010188
  %chain_slot39 = getelementptr i8, ptr %chain_table, i64 526464
  %130 = getelementptr i8, ptr %chain_slot39, i64 0
  %slot_pc40 = load i32, ptr %130, align 4
  %131 = icmp eq i32 %slot_pc40, 65808
  br i1 %131, label %chain_hit41, label %chain_leave35, !prof !0

chain_leave35:                                    ; preds = %chain_go34, %insn_0x00010188
  %132 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %132, align 4
  %133 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %133, align 4
  %134 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %134, align 4
  %135 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %135, align 1
  br label %return

chain_hit41:                                      ; preds = %chain_go34
  %136 = getelementptr i8, ptr %cpu, i64 188
  store i32 65808, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total37, ptr %137, align 4
  %138 = getelementptr i8, ptr %chain_slot39, i64 8
  %chain_fn42 = load ptr, ptr %138, align 8
  musttail call swifttailcc void %chain_fn42(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave35, %chain_leave26, %chain_leave24, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

attributes #0 = { "no_callee_saved_registers" }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
