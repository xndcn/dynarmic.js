; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010084(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 65668
  %5 = icmp ugt i32 %4, 10
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb24 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb24, 0
  %10 = sub i32 %guard_lb24, 65668
  %11 = icmp ugt i32 %10, 10
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x00010084_entry, label %lb_guard_miss, !prof !0

insn_0x00010084_entry:                            ; preds = %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table39 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table39, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 64
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x00010084_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 16, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x00010084_entry, %27
  br label %insn_0x00010084

insn_0x00010084:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 16
  %rs = load i32, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 276
  %cc_old = load i32, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %31, align 4
  %addr = add i32 %fp, -4
  %32 = and i32 %addr, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010084
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65668, i32 %addr, i32 0)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010084
  %37 = lshr i32 %addr, 12
  %page_index = zext i32 %37 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %38 = and i32 %addr, 4095
  %page_offset = zext i32 %38 to i64
  %39 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %39, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %40 = getelementptr i8, ptr %cpu, i32 292
  store i32 8, ptr %40, align 4
  %41 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %41, align 4
  %42 = call i32 @mem_read32(ptr %mem, i32 %addr)
  %43 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %43, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %42, %did_jump_cont ]
  %44 = getelementptr i8, ptr %cpu, i32 0
  store i32 %rs, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val, ptr %45, align 4
  %46 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %47, align 4
  br label %insn_0x0001008c_entry

did_jump_exit:                                    ; preds = %page_slow
  %48 = getelementptr i8, ptr %cpu, i64 188
  %next_pc25 = load i32, ptr %48, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x0001008c_entry:                            ; preds = %page_done
  br label %insn_0x0001008c

insn_0x0001008c:                                  ; preds = %insn_0x0001008c_entry
  %addr1 = add i32 %fp, -8
  %49 = and i32 %addr1, 3
  %50 = icmp ne i32 %49, 0
  br i1 %50, label %data_misaligned2, label %data_aligned3, !prof !1

data_misaligned2:                                 ; preds = %insn_0x0001008c
  %51 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %51, align 4
  %52 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %52, align 4
  %53 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %53, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65676, i32 %addr1, i32 0)
  %54 = getelementptr i8, ptr %cpu, i64 188
  %next_pc26 = load i32, ptr %54, align 4
  br label %chain_exit

data_aligned3:                                    ; preds = %insn_0x0001008c
  %55 = lshr i32 %addr1, 12
  %page_index7 = zext i32 %55 to i64
  %page_slot8 = getelementptr ptr, ptr %page_table, i64 %page_index7
  %page9 = load ptr, ptr %page_slot8, align 8
  %page_mapped10 = icmp ne ptr %page9, null
  br i1 %page_mapped10, label %page_fast4, label %page_slow5, !prof !0

page_fast4:                                       ; preds = %data_aligned3
  %56 = and i32 %addr1, 4095
  %page_offset11 = zext i32 %56 to i64
  %57 = getelementptr i8, ptr %page9, i64 %page_offset11
  %page_val12 = load i32, ptr %57, align 4
  br label %page_done6

page_slow5:                                       ; preds = %data_aligned3
  %58 = getelementptr i8, ptr %cpu, i32 188
  store i32 65676, ptr %58, align 4
  %59 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %60, align 4
  %61 = call i32 @mem_read32(ptr %mem, i32 %addr1)
  %62 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %62, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_done6:                                       ; preds = %did_jump_cont14, %page_fast4
  %mem_val17 = phi i32 [ %page_val12, %page_fast4 ], [ %61, %did_jump_cont14 ]
  %63 = getelementptr i8, ptr %cpu, i32 8
  store i32 %mem_val17, ptr %63, align 4
  br label %insn_0x0001008e_entry

did_jump_exit13:                                  ; preds = %page_slow5
  %64 = getelementptr i8, ptr %cpu, i64 188
  %next_pc27 = load i32, ptr %64, align 4
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_slow5
  br label %page_done6

insn_0x0001008e_entry:                            ; preds = %page_done6
  br label %insn_0x0001008e

insn_0x0001008e:                                  ; preds = %insn_0x0001008e_entry
  %65 = getelementptr i8, ptr %cpu, i32 152
  %lc = load i32, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 144
  %lt = load i32, ptr %66, align 4
  %lc_gt1 = icmp ugt i32 %lc, 1
  %at_lb = icmp eq i32 %lb0, 65678
  %hwloop_cond = and i1 %lc_gt1, %at_lb
  %hwloop_rets = select i1 %hwloop_cond, i32 %lt, i32 65682
  %67 = getelementptr i8, ptr %cpu, i32 156
  %lc18 = load i32, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 148
  %lt19 = load i32, ptr %68, align 4
  %lc_gt120 = icmp ugt i32 %lc18, 1
  %at_lb21 = icmp eq i32 %lb1, 65678
  %hwloop_cond22 = and i1 %lc_gt120, %at_lb21
  %hwloop_rets23 = select i1 %hwloop_cond22, i32 %lt19, i32 %hwloop_rets
  %69 = getelementptr i8, ptr %cpu, i32 168
  store i32 %hwloop_rets23, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 188
  store i32 66344, ptr %70, align 4
  %71 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %71, align 4
  %chain_total = add nuw i32 %chain_packets, 3
  %72 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %72 monotonic, align 4, !range !2
  %73 = icmp ult i32 %chain_total, %chain_budget
  br i1 %73, label %chain_go, label %chain_leave28, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %74 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %74, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %insn_0x0001008e
  %chain_slot = getelementptr i8, ptr %chain_table, i64 530752
  %75 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %75, align 4
  %76 = icmp eq i32 %slot_pc, 66344
  br i1 %76, label %chain_hit, label %chain_leave28, !prof !0

chain_leave28:                                    ; preds = %chain_go, %insn_0x0001008e
  %77 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i64 308
  store i32 3, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %80, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %81 = getelementptr i8, ptr %cpu, i64 188
  store i32 66344, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %82, align 4
  %83 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %83, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit13, %data_misaligned2, %did_jump_exit, %data_misaligned
  %next_pc29 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc25, %did_jump_exit ], [ %next_pc26, %data_misaligned2 ], [ %next_pc27, %did_jump_exit13 ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %tail = phi i32 [ 8, %data_misaligned ], [ 8, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %tail30 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 2, %data_misaligned2 ], [ 2, %did_jump_exit13 ]
  %84 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets32 = load i32, ptr %84, align 4
  %chain_total33 = add nuw i32 %chain_packets32, %packets
  %85 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget34 = load atomic i32, ptr %85 monotonic, align 4, !range !2
  %86 = icmp ult i32 %chain_total33, %chain_budget34
  br i1 %86, label %chain_lookup, label %chain_leave31, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %87 = lshr i32 %next_pc29, 1
  %88 = and i32 %87, 65535
  %89 = zext i32 %88 to i64
  %90 = mul i64 %89, 16
  %chain_slot35 = getelementptr i8, ptr %chain_table, i64 %90
  %91 = getelementptr i8, ptr %chain_slot35, i64 0
  %slot_pc36 = load i32, ptr %91, align 4
  %92 = icmp eq i32 %slot_pc36, %next_pc29
  br i1 %92, label %chain_hit37, label %chain_leave31, !prof !0

chain_leave31:                                    ; preds = %chain_lookup, %chain_exit
  %93 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail30, ptr %94, align 4
  br label %return

chain_hit37:                                      ; preds = %chain_lookup
  %95 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total33, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %96, align 1
  %97 = getelementptr i8, ptr %chain_slot35, i64 8
  %chain_fn38 = load ptr, ptr %97, align 8
  musttail call swifttailcc void %chain_fn38(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave31, %chain_leave28, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
