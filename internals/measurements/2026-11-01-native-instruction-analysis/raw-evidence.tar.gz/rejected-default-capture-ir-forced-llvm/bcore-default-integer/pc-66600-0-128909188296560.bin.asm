
build-native-instruction-analysis/capture/bcore-default-integer/pc-66600-0-128909188296560.bin:     file format binary


Disassembly of section .data:

0000753e02606f70 <.data>:
    753e02606f70:	48 81 ec f8 00 00 00 	sub    rsp,0xf8
    753e02606f77:	4c 89 b4 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r14
    753e02606f7e:	00 
    753e02606f7f:	4c 89 ac 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],r13
    753e02606f86:	00 
    753e02606f87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02606f8e:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    753e02606f95:	00 
    753e02606f96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e02606f9d:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    753e02606fa4:	00 
    753e02606fa5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02606fac:	48 89 84 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rax
    753e02606fb3:	00 
    753e02606fb4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    753e02606fbb:	00 
    753e02606fbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02606fc2:	83 fa 00             	cmp    edx,0x0
    753e02606fc5:	0f 94 c0             	sete   al
    753e02606fc8:	81 ea 28 04 01 00    	sub    edx,0x10428
    753e02606fce:	83 fa 18             	cmp    edx,0x18
    753e02606fd1:	0f 97 c2             	seta   dl
    753e02606fd4:	08 d0                	or     al,dl
    753e02606fd6:	24 01                	and    al,0x1
    753e02606fd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02606fde:	83 fa 00             	cmp    edx,0x0
    753e02606fe1:	0f 94 c1             	sete   cl
    753e02606fe4:	81 ea 28 04 01 00    	sub    edx,0x10428
    753e02606fea:	83 fa 18             	cmp    edx,0x18
    753e02606fed:	0f 97 c2             	seta   dl
    753e02606ff0:	08 d1                	or     cl,dl
    753e02606ff2:	20 c8                	and    al,cl
    753e02606ff4:	a8 01                	test   al,0x1
    753e02606ff6:	75 05                	jne    0x753e02606ffd
    753e02606ff8:	e9 4f 0b 00 00       	jmp    0x753e02607b4c
    753e02606ffd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607004:	00 
    753e02607005:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e0260700c:	48 89 c8             	mov    rax,rcx
    753e0260700f:	48 05 00 00 10 00    	add    rax,0x100000
    753e02607015:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    753e0260701c:	00 
    753e0260701d:	8b 81 14 00 10 00    	mov    eax,DWORD PTR [rcx+0x100014]
    753e02607023:	83 c0 01             	add    eax,0x1
    753e02607026:	89 81 14 00 10 00    	mov    DWORD PTR [rcx+0x100014],eax
    753e0260702c:	3d 30 75 00 00       	cmp    eax,0x7530
    753e02607031:	75 4c                	jne    0x753e0260707f
    753e02607033:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
    753e0260703a:	00 
    753e0260703b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02607041:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    753e02607048:	89 c2                	mov    edx,eax
    753e0260704a:	83 c2 01             	add    edx,0x1
    753e0260704d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02607053:	3d 00 01 00 00       	cmp    eax,0x100
    753e02607058:	73 23                	jae    0x753e0260707d
    753e0260705a:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    753e02607061:	00 
    753e02607062:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    753e02607069:	89 c9                	mov    ecx,ecx
    753e0260706b:	48 c1 e1 02          	shl    rcx,0x2
    753e0260706f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02607076:	c7 04 08 05 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x5
    753e0260707d:	eb 00                	jmp    0x753e0260707f
    753e0260707f:	eb 00                	jmp    0x753e02607081
    753e02607081:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607088:	00 
    753e02607089:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    753e0260708c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02607092:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02607098:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    753e0260709f:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026070a2:	eb 00                	jmp    0x753e026070a4
    753e026070a4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    753e026070ab:	00 
    753e026070ac:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    753e026070af:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    753e026070b5:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    753e026070bc:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    753e026070bf:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    753e026070c6:	83 e8 04             	sub    eax,0x4
    753e026070c9:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e026070d0:	83 e0 03             	and    eax,0x3
    753e026070d3:	83 f8 00             	cmp    eax,0x0
    753e026070d6:	0f 84 98 00 00 00    	je     0x753e02607174
    753e026070dc:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e026070e3:	00 
    753e026070e4:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e026070eb:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    753e026070f2:	00 
    753e026070f3:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    753e026070fa:	04 01 00 
    753e026070fd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02607104:	00 00 00 
    753e02607107:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e0260710e:	00 00 00 
    753e02607111:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02607118:	5c 00 00 
    753e0260711b:	ba 2c 04 01 00       	mov    edx,0x1042c
    753e02607120:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02607126:	ff d0                	call   rax
    753e02607128:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260712f:	00 
    753e02607130:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607136:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260713c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607142:	be 02 00 00 00       	mov    esi,0x2
    753e02607147:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260714c:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607153:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e0260715a:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607161:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607168:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e0260716f:	e9 79 0a 00 00       	jmp    0x753e02607bed
    753e02607174:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    753e0260717b:	00 
    753e0260717c:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e02607183:	c1 e9 0c             	shr    ecx,0xc
    753e02607186:	89 c9                	mov    ecx,ecx
    753e02607188:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260718c:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    753e02607193:	00 
    753e02607194:	48 83 f8 00          	cmp    rax,0x0
    753e02607198:	74 23                	je     0x753e026071bd
    753e0260719a:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e026071a1:	00 
    753e026071a2:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e026071a9:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e026071b0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026071b6:	89 c9                	mov    ecx,ecx
    753e026071b8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026071bb:	eb 5b                	jmp    0x753e02607218
    753e026071bd:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026071c4:	00 
    753e026071c5:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e026071cc:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    753e026071d3:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e026071da:	00 
    753e026071db:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    753e026071e2:	04 01 00 
    753e026071e5:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026071ec:	00 00 00 
    753e026071ef:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e026071f6:	00 00 00 
    753e026071f9:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02607200:	5c 00 00 
    753e02607203:	ff d0                	call   rax
    753e02607205:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260720c:	00 
    753e0260720d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02607214:	75 20                	jne    0x753e02607236
    753e02607216:	eb 6a                	jmp    0x753e02607282
    753e02607218:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    753e0260721f:	83 e8 04             	sub    eax,0x4
    753e02607222:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e02607229:	83 e0 03             	and    eax,0x3
    753e0260722c:	83 f8 00             	cmp    eax,0x0
    753e0260722f:	75 53                	jne    0x753e02607284
    753e02607231:	e9 e6 00 00 00       	jmp    0x753e0260731c
    753e02607236:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260723d:	00 
    753e0260723e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607244:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260724a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607250:	be 02 00 00 00       	mov    esi,0x2
    753e02607255:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260725a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607261:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607268:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e0260726f:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607276:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e0260727d:	e9 6b 09 00 00       	jmp    0x753e02607bed
    753e02607282:	eb 94                	jmp    0x753e02607218
    753e02607284:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e0260728b:	00 
    753e0260728c:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e02607293:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    753e0260729a:	00 
    753e0260729b:	c7 87 bc 00 00 00 2c 	mov    DWORD PTR [rdi+0xbc],0x1042c
    753e026072a2:	04 01 00 
    753e026072a5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e026072ac:	00 00 00 
    753e026072af:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e026072b6:	00 00 00 
    753e026072b9:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026072c0:	5c 00 00 
    753e026072c3:	ba 2c 04 01 00       	mov    edx,0x1042c
    753e026072c8:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026072ce:	ff d0                	call   rax
    753e026072d0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026072d7:	00 
    753e026072d8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026072de:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026072e4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026072ea:	be 02 00 00 00       	mov    esi,0x2
    753e026072ef:	b9 04 00 00 00       	mov    ecx,0x4
    753e026072f4:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e026072fb:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607302:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607309:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607310:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607317:	e9 d1 08 00 00       	jmp    0x753e02607bed
    753e0260731c:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    753e02607323:	00 
    753e02607324:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260732b:	c1 e9 0c             	shr    ecx,0xc
    753e0260732e:	89 c9                	mov    ecx,ecx
    753e02607330:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02607334:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    753e0260733b:	00 
    753e0260733c:	48 83 f8 00          	cmp    rax,0x0
    753e02607340:	74 23                	je     0x753e02607365
    753e02607342:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    753e02607349:	00 
    753e0260734a:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    753e02607351:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e02607358:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260735e:	89 c9                	mov    ecx,ecx
    753e02607360:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02607363:	eb 5b                	jmp    0x753e026073c0
    753e02607365:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260736c:	00 
    753e0260736d:	8b 94 24 b8 00 00 00 	mov    edx,DWORD PTR [rsp+0xb8]
    753e02607374:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    753e0260737b:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e02607382:	00 
    753e02607383:	c7 80 bc 00 00 00 2c 	mov    DWORD PTR [rax+0xbc],0x1042c
    753e0260738a:	04 01 00 
    753e0260738d:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02607394:	00 00 00 
    753e02607397:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e0260739e:	00 00 00 
    753e026073a1:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026073a8:	5c 00 00 
    753e026073ab:	ff d0                	call   rax
    753e026073ad:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026073b4:	00 
    753e026073b5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026073bc:	75 2c                	jne    0x753e026073ea
    753e026073be:	eb 76                	jmp    0x753e02607436
    753e026073c0:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    753e026073c7:	00 
    753e026073c8:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    753e026073cf:	00 
    753e026073d0:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    753e026073d7:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    753e026073da:	83 ea 00             	sub    edx,0x0
    753e026073dd:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e026073e0:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e026073e3:	75 53                	jne    0x753e02607438
    753e026073e5:	e9 93 00 00 00       	jmp    0x753e0260747d
    753e026073ea:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026073f1:	00 
    753e026073f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026073f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026073fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607404:	be 02 00 00 00       	mov    esi,0x2
    753e02607409:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260740e:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607415:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e0260741c:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607423:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e0260742a:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607431:	e9 b7 07 00 00       	jmp    0x753e02607bed
    753e02607436:	eb 88                	jmp    0x753e026073c0
    753e02607438:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e0260743f:	00 
    753e02607440:	c7 87 bc 00 00 00 30 	mov    DWORD PTR [rdi+0xbc],0x10430
    753e02607447:	04 01 00 
    753e0260744a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02607451:	00 00 00 
    753e02607454:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e0260745b:	00 00 00 
    753e0260745e:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02607465:	5c 00 00 
    753e02607468:	ff d0                	call   rax
    753e0260746a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607471:	00 
    753e02607472:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02607479:	75 04                	jne    0x753e0260747f
    753e0260747b:	eb 4e                	jmp    0x753e026074cb
    753e0260747d:	eb 4e                	jmp    0x753e026074cd
    753e0260747f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607486:	00 
    753e02607487:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260748d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607493:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607499:	be 02 00 00 00       	mov    esi,0x2
    753e0260749e:	b9 04 00 00 00       	mov    ecx,0x4
    753e026074a3:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e026074aa:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e026074b1:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e026074b8:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e026074bf:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e026074c6:	e9 22 07 00 00       	jmp    0x753e02607bed
    753e026074cb:	eb b0                	jmp    0x753e0260747d
    753e026074cd:	eb 00                	jmp    0x753e026074cf
    753e026074cf:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026074d6:	00 
    753e026074d7:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    753e026074de:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026074e4:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    753e026074ea:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e026074f1:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026074f4:	eb 00                	jmp    0x753e026074f6
    753e026074f6:	8b 84 24 84 00 00 00 	mov    eax,DWORD PTR [rsp+0x84]
    753e026074fd:	83 e0 03             	and    eax,0x3
    753e02607500:	83 f8 00             	cmp    eax,0x0
    753e02607503:	0f 84 97 00 00 00    	je     0x753e026075a0
    753e02607509:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e02607510:	00 
    753e02607511:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    753e02607518:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    753e0260751f:	00 
    753e02607520:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10434
    753e02607527:	04 01 00 
    753e0260752a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02607531:	00 00 00 
    753e02607534:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    753e0260753b:	00 00 00 
    753e0260753e:	31 c0                	xor    eax,eax
    753e02607540:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02607547:	5c 00 00 
    753e0260754a:	ba 34 04 01 00       	mov    edx,0x10434
    753e0260754f:	45 31 c0             	xor    r8d,r8d
    753e02607552:	ff d0                	call   rax
    753e02607554:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260755b:	00 
    753e0260755c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607562:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607568:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260756e:	be 04 00 00 00       	mov    esi,0x4
    753e02607573:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607578:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e0260757f:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607586:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e0260758d:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607594:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e0260759b:	e9 4d 06 00 00       	jmp    0x753e02607bed
    753e026075a0:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    753e026075a7:	00 
    753e026075a8:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    753e026075af:	c1 e9 0c             	shr    ecx,0xc
    753e026075b2:	89 c9                	mov    ecx,ecx
    753e026075b4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026075b8:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753e026075bd:	48 83 f8 00          	cmp    rax,0x0
    753e026075c1:	74 1d                	je     0x753e026075e0
    753e026075c3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e026075c8:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    753e026075cf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026075d5:	89 c9                	mov    ecx,ecx
    753e026075d7:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026075da:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    753e026075de:	eb 5a                	jmp    0x753e0260763a
    753e026075e0:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026075e7:	00 
    753e026075e8:	8b b4 24 84 00 00 00 	mov    esi,DWORD PTR [rsp+0x84]
    753e026075ef:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e026075f6:	00 
    753e026075f7:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10434
    753e026075fe:	04 01 00 
    753e02607601:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02607608:	00 00 00 
    753e0260760b:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e02607612:	00 00 00 
    753e02607615:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260761c:	5c 00 00 
    753e0260761f:	ff d0                	call   rax
    753e02607621:	89 c1                	mov    ecx,eax
    753e02607623:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260762a:	00 
    753e0260762b:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    753e0260762f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02607636:	75 17                	jne    0x753e0260764f
    753e02607638:	eb 61                	jmp    0x753e0260769b
    753e0260763a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607641:	00 
    753e02607642:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e02607646:	89 4c 24 6c          	mov    DWORD PTR [rsp+0x6c],ecx
    753e0260764a:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e0260764d:	eb 56                	jmp    0x753e026076a5
    753e0260764f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607656:	00 
    753e02607657:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260765d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607663:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607669:	be 04 00 00 00       	mov    esi,0x4
    753e0260766e:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607673:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e0260767a:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607681:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607688:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e0260768f:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607696:	e9 52 05 00 00       	jmp    0x753e02607bed
    753e0260769b:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    753e0260769f:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    753e026076a3:	eb 95                	jmp    0x753e0260763a
    753e026076a5:	eb 00                	jmp    0x753e026076a7
    753e026076a7:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026076ae:	00 
    753e026076af:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    753e026076b3:	83 f9 04             	cmp    ecx,0x4
    753e026076b6:	0f 96 c1             	setbe  cl
    753e026076b9:	80 e1 01             	and    cl,0x1
    753e026076bc:	0f b6 c9             	movzx  ecx,cl
    753e026076bf:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e026076c3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    753e026076c9:	eb 00                	jmp    0x753e026076cb
    753e026076cb:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    753e026076cf:	83 f8 00             	cmp    eax,0x0
    753e026076d2:	74 30                	je     0x753e02607704
    753e026076d4:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    753e026076db:	00 
    753e026076dc:	c7 81 bc 00 00 00 42 	mov    DWORD PTR [rcx+0xbc],0x10442
    753e026076e3:	04 01 00 
    753e026076e6:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e026076ec:	83 c0 06             	add    eax,0x6
    753e026076ef:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e026076f3:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e026076f9:	0f 82 61 04 00 00    	jb     0x753e02607b60
    753e026076ff:	e9 7f 04 00 00       	jmp    0x753e02607b83
    753e02607704:	eb 00                	jmp    0x753e02607706
    753e02607706:	eb 00                	jmp    0x753e02607708
    753e02607708:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260770f:	00 
    753e02607710:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    753e02607716:	eb 00                	jmp    0x753e02607718
    753e02607718:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    753e0260771f:	83 e0 03             	and    eax,0x3
    753e02607722:	83 f8 00             	cmp    eax,0x0
    753e02607725:	0f 84 97 00 00 00    	je     0x753e026077c2
    753e0260772b:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e02607732:	00 
    753e02607733:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260773a:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    753e02607741:	00 
    753e02607742:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    753e02607749:	04 01 00 
    753e0260774c:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02607753:	00 00 00 
    753e02607756:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    753e0260775d:	00 00 00 
    753e02607760:	31 c0                	xor    eax,eax
    753e02607762:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02607769:	5c 00 00 
    753e0260776c:	ba 3c 04 01 00       	mov    edx,0x1043c
    753e02607771:	45 31 c0             	xor    r8d,r8d
    753e02607774:	ff d0                	call   rax
    753e02607776:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260777d:	00 
    753e0260777e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607784:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260778a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607790:	be 08 00 00 00       	mov    esi,0x8
    753e02607795:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260779a:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e026077a1:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e026077a8:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e026077af:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e026077b6:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e026077bd:	e9 2b 04 00 00       	jmp    0x753e02607bed
    753e026077c2:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    753e026077c9:	00 
    753e026077ca:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e026077d1:	c1 e9 0c             	shr    ecx,0xc
    753e026077d4:	89 c9                	mov    ecx,ecx
    753e026077d6:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026077da:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e026077df:	48 83 f8 00          	cmp    rax,0x0
    753e026077e3:	74 1d                	je     0x753e02607802
    753e026077e5:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e026077ea:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e026077f1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026077f7:	89 c9                	mov    ecx,ecx
    753e026077f9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026077fc:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e02607800:	eb 5a                	jmp    0x753e0260785c
    753e02607802:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607809:	00 
    753e0260780a:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    753e02607811:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e02607818:	00 
    753e02607819:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    753e02607820:	04 01 00 
    753e02607823:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260782a:	00 00 00 
    753e0260782d:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    753e02607834:	00 00 00 
    753e02607837:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260783e:	5c 00 00 
    753e02607841:	ff d0                	call   rax
    753e02607843:	89 c1                	mov    ecx,eax
    753e02607845:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260784c:	00 
    753e0260784d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e02607851:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02607858:	75 25                	jne    0x753e0260787f
    753e0260785a:	eb 6f                	jmp    0x753e026078cb
    753e0260785c:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    753e02607863:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    753e02607867:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e0260786b:	83 c0 04             	add    eax,0x4
    753e0260786e:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02607872:	83 e0 03             	and    eax,0x3
    753e02607875:	83 f8 00             	cmp    eax,0x0
    753e02607878:	75 5b                	jne    0x753e026078d5
    753e0260787a:	e9 ea 00 00 00       	jmp    0x753e02607969
    753e0260787f:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607886:	00 
    753e02607887:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260788d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607893:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607899:	be 08 00 00 00       	mov    esi,0x8
    753e0260789e:	b9 04 00 00 00       	mov    ecx,0x4
    753e026078a3:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e026078aa:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e026078b1:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e026078b8:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e026078bf:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e026078c6:	e9 22 03 00 00       	jmp    0x753e02607bed
    753e026078cb:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e026078cf:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e026078d3:	eb 87                	jmp    0x753e0260785c
    753e026078d5:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e026078dc:	00 
    753e026078dd:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e026078e1:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
    753e026078e8:	00 
    753e026078e9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1043c
    753e026078f0:	04 01 00 
    753e026078f3:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e026078fa:	00 00 00 
    753e026078fd:	c7 87 34 01 00 00 08 	mov    DWORD PTR [rdi+0x134],0x8
    753e02607904:	00 00 00 
    753e02607907:	31 c0                	xor    eax,eax
    753e02607909:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02607910:	5c 00 00 
    753e02607913:	ba 3c 04 01 00       	mov    edx,0x1043c
    753e02607918:	45 31 c0             	xor    r8d,r8d
    753e0260791b:	ff d0                	call   rax
    753e0260791d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607924:	00 
    753e02607925:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260792b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607931:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607937:	be 08 00 00 00       	mov    esi,0x8
    753e0260793c:	b9 04 00 00 00       	mov    ecx,0x4
    753e02607941:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607948:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e0260794f:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607956:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e0260795d:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607964:	e9 84 02 00 00       	jmp    0x753e02607bed
    753e02607969:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
    753e02607970:	00 
    753e02607971:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02607975:	c1 e9 0c             	shr    ecx,0xc
    753e02607978:	89 c9                	mov    ecx,ecx
    753e0260797a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260797e:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    753e02607983:	48 83 f8 00          	cmp    rax,0x0
    753e02607987:	74 1a                	je     0x753e026079a3
    753e02607989:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    753e0260798e:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02607992:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02607998:	89 c9                	mov    ecx,ecx
    753e0260799a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260799d:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e026079a1:	eb 57                	jmp    0x753e026079fa
    753e026079a3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026079aa:	00 
    753e026079ab:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e026079af:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e026079b6:	00 
    753e026079b7:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1043c
    753e026079be:	04 01 00 
    753e026079c1:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026079c8:	00 00 00 
    753e026079cb:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    753e026079d2:	00 00 00 
    753e026079d5:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026079dc:	5c 00 00 
    753e026079df:	ff d0                	call   rax
    753e026079e1:	89 c1                	mov    ecx,eax
    753e026079e3:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026079ea:	00 
    753e026079eb:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    753e026079ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026079f6:	75 2b                	jne    0x753e02607a23
    753e026079f8:	eb 75                	jmp    0x753e02607a6f
    753e026079fa:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607a01:	00 
    753e02607a02:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    753e02607a06:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02607a0a:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    753e02607a0e:	89 54 24 34          	mov    DWORD PTR [rsp+0x34],edx
    753e02607a12:	83 c1 04             	add    ecx,0x4
    753e02607a15:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e02607a18:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e02607a1e:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02607a21:	eb 56                	jmp    0x753e02607a79
    753e02607a23:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607a2a:	00 
    753e02607a2b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607a31:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607a37:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607a3d:	be 08 00 00 00       	mov    esi,0x8
    753e02607a42:	b9 04 00 00 00       	mov    ecx,0x4
    753e02607a47:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607a4e:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607a55:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607a5c:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607a63:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607a6a:	e9 7e 01 00 00       	jmp    0x753e02607bed
    753e02607a6f:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    753e02607a73:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e02607a77:	eb 81                	jmp    0x753e026079fa
    753e02607a79:	eb 00                	jmp    0x753e02607a7b
    753e02607a7b:	8b 44 24 34          	mov    eax,DWORD PTR [rsp+0x34]
    753e02607a7f:	83 e0 01             	and    eax,0x1
    753e02607a82:	83 f8 00             	cmp    eax,0x0
    753e02607a85:	75 3a                	jne    0x753e02607ac1
    753e02607a87:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    753e02607a8b:	be 09 00 00 00       	mov    esi,0x9
    753e02607a90:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607a95:	b0 01                	mov    al,0x1
    753e02607a97:	89 d7                	mov    edi,edx
    753e02607a99:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607aa0:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607aa7:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607aae:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607ab5:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607abc:	e9 2c 01 00 00       	jmp    0x753e02607bed
    753e02607ac1:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
    753e02607ac8:	00 
    753e02607ac9:	48 8b 94 24 d0 00 00 	mov    rdx,QWORD PTR [rsp+0xd0]
    753e02607ad0:	00 
    753e02607ad1:	c7 87 bc 00 00 00 40 	mov    DWORD PTR [rdi+0xbc],0x10440
    753e02607ad8:	04 01 00 
    753e02607adb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02607ae2:	00 00 00 
    753e02607ae5:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    753e02607aec:	00 00 00 
    753e02607aef:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e02607af6:	5c 00 00 
    753e02607af9:	be 2a 00 00 00       	mov    esi,0x2a
    753e02607afe:	ff d0                	call   rax
    753e02607b00:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607b07:	00 
    753e02607b08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607b0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607b14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607b1a:	be 09 00 00 00       	mov    esi,0x9
    753e02607b1f:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607b24:	89 bc 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],edi
    753e02607b2b:	89 b4 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],esi
    753e02607b32:	89 94 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],edx
    753e02607b39:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02607b40:	88 84 24 b3 00 00 00 	mov    BYTE PTR [rsp+0xb3],al
    753e02607b47:	e9 a1 00 00 00       	jmp    0x753e02607bed
    753e02607b4c:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607b53:	00 
    753e02607b54:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e02607b5b:	e9 7f 01 00 00       	jmp    0x753e02607cdf
    753e02607b60:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e02607b67:	00 
    753e02607b68:	48 89 c1             	mov    rcx,rax
    753e02607b6b:	48 81 c1 10 22 08 00 	add    rcx,0x82210
    753e02607b72:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e02607b77:	81 b8 10 22 08 00 42 	cmp    DWORD PTR [rax+0x82210],0x10442
    753e02607b7e:	04 01 00 
    753e02607b81:	74 32                	je     0x753e02607bb5
    753e02607b83:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607b8a:	00 
    753e02607b8b:	c7 80 bc 00 00 00 42 	mov    DWORD PTR [rax+0xbc],0x10442
    753e02607b92:	04 01 00 
    753e02607b95:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02607b9c:	00 00 00 
    753e02607b9f:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    753e02607ba6:	00 00 00 
    753e02607ba9:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e02607bb0:	e9 2a 01 00 00       	jmp    0x753e02607cdf
    753e02607bb5:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    753e02607bbc:	00 
    753e02607bbd:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    753e02607bc4:	00 
    753e02607bc5:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e02607bca:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02607bce:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10442
    753e02607bd5:	42 04 01 00 
    753e02607bd9:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02607be0:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02607be4:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    753e02607beb:	ff e0                	jmp    rax
    753e02607bed:	48 8b 8c 24 d8 00 00 	mov    rcx,QWORD PTR [rsp+0xd8]
    753e02607bf4:	00 
    753e02607bf5:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    753e02607bfc:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    753e02607c03:	8b b4 24 a8 00 00 00 	mov    esi,DWORD PTR [rsp+0xa8]
    753e02607c0a:	8b bc 24 ac 00 00 00 	mov    edi,DWORD PTR [rsp+0xac]
    753e02607c11:	8a 9c 24 b3 00 00 00 	mov    bl,BYTE PTR [rsp+0xb3]
    753e02607c18:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    753e02607c1c:	89 c3                	mov    ebx,eax
    753e02607c1e:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    753e02607c22:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    753e02607c26:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    753e02607c2a:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    753e02607c2e:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02607c34:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e02607c38:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02607c3e:	73 2d                	jae    0x753e02607c6d
    753e02607c40:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e02607c47:	00 
    753e02607c48:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02607c4c:	89 d1                	mov    ecx,edx
    753e02607c4e:	c1 e9 01             	shr    ecx,0x1
    753e02607c51:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02607c57:	89 c9                	mov    ecx,ecx
    753e02607c59:	48 c1 e1 04          	shl    rcx,0x4
    753e02607c5d:	48 89 c6             	mov    rsi,rax
    753e02607c60:	48 01 ce             	add    rsi,rcx
    753e02607c63:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e02607c68:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e02607c6b:	74 32                	je     0x753e02607c9f
    753e02607c6d:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02607c74:	00 
    753e02607c75:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    753e02607c79:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e02607c7d:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    753e02607c81:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    753e02607c85:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e02607c8b:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e02607c91:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e02607c97:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e02607c9d:	eb 40                	jmp    0x753e02607cdf
    753e02607c9f:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
    753e02607ca6:	00 
    753e02607ca7:	4c 8b ac 24 d8 00 00 	mov    r13,QWORD PTR [rsp+0xd8]
    753e02607cae:	00 
    753e02607caf:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e02607cb4:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    753e02607cb8:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02607cbc:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e02607cc3:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02607cca:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e02607cd1:	00 
    753e02607cd2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02607cd6:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    753e02607cdd:	ff e0                	jmp    rax
    753e02607cdf:	48 81 c4 f8 00 00 00 	add    rsp,0xf8
    753e02607ce6:	c2 08 00             	ret    0x8
