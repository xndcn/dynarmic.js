
build-native-instruction-analysis/capture/bcore-default-integer/pc-65772-0-128909188312992.bin:     file format binary


Disassembly of section .data:

0000753e0260afa0 <.data>:
    753e0260afa0:	48 83 ec 58          	sub    rsp,0x58
    753e0260afa4:	4c 89 74 24 40       	mov    QWORD PTR [rsp+0x40],r14
    753e0260afa9:	4d 89 e8             	mov    r8,r13
    753e0260afac:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260afb3:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    753e0260afb8:	45 8b 9d 58 01 00 00 	mov    r11d,DWORD PTR [r13+0x158]
    753e0260afbf:	b8 f3 fe fe ff       	mov    eax,0xfffefef3
    753e0260afc4:	41 8b 8d a4 00 00 00 	mov    ecx,DWORD PTR [r13+0xa4]
    753e0260afcb:	01 c1                	add    ecx,eax
    753e0260afcd:	83 f9 de             	cmp    ecx,0xffffffde
    753e0260afd0:	0f 87 2a 50 ff 17    	ja     0x753e1a600000
    753e0260afd6:	41 03 80 a0 00 00 00 	add    eax,DWORD PTR [r8+0xa0]
    753e0260afdd:	83 f8 de             	cmp    eax,0xffffffde
    753e0260afe0:	0f 87 1a 50 ff 17    	ja     0x753e1a600000
    753e0260afe6:	49 8b 80 38 01 00 00 	mov    rax,QWORD PTR [r8+0x138]
    753e0260afed:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
    753e0260aff2:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    753e0260aff5:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    753e0260aff9:	41 8b 58 08          	mov    ebx,DWORD PTR [r8+0x8]
    753e0260affd:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    753e0260b001:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    753e0260b005:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    753e0260b009:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e0260b00e:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    753e0260b015:	41 8b b0 5c 01 00 00 	mov    esi,DWORD PTR [r8+0x15c]
    753e0260b01c:	4c 89 44 24 30       	mov    QWORD PTR [rsp+0x30],r8
    753e0260b021:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    753e0260b028:	0f 1f 84 00 00 00 00 
    753e0260b02f:	00 
    753e0260b030:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    753e0260b035:	44 89 ca             	mov    edx,r9d
    753e0260b038:	c1 ea 1f             	shr    edx,0x1f
    753e0260b03b:	89 df                	mov    edi,ebx
    753e0260b03d:	ff c7                	inc    edi
    753e0260b03f:	44 89 e9             	mov    ecx,r13d
    753e0260b042:	41 39 fd             	cmp    r13d,edi
    753e0260b045:	89 f8                	mov    eax,edi
    753e0260b047:	41 0f 47 c5          	cmova  eax,r13d
    753e0260b04b:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    753e0260b04f:	89 7c 24 08          	mov    DWORD PTR [rsp+0x8],edi
    753e0260b053:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    753e0260b058:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
    753e0260b05f:	00 
    753e0260b060:	41 89 f4             	mov    r12d,esi
    753e0260b063:	89 f8                	mov    eax,edi
    753e0260b065:	8d 70 ff             	lea    esi,[rax-0x1]
    753e0260b068:	45 0f af f2          	imul   r14d,r10d
    753e0260b06c:	43 8d 1c 0e          	lea    ebx,[r14+r9*1]
    753e0260b070:	41 c1 ee 1f          	shr    r14d,0x1f
    753e0260b074:	89 df                	mov    edi,ebx
    753e0260b076:	c1 ef 1f             	shr    edi,0x1f
    753e0260b079:	89 fd                	mov    ebp,edi
    753e0260b07b:	31 d5                	xor    ebp,edx
    753e0260b07d:	44 31 f7             	xor    edi,r14d
    753e0260b080:	21 ef                	and    edi,ebp
    753e0260b082:	41 89 de             	mov    r14d,ebx
    753e0260b085:	41 c1 ee 0d          	shr    r14d,0xd
    753e0260b089:	41 31 de             	xor    r14d,ebx
    753e0260b08c:	44 89 f5             	mov    ebp,r14d
    753e0260b08f:	c1 e5 07             	shl    ebp,0x7
    753e0260b092:	c1 ee 1f             	shr    esi,0x1f
    753e0260b095:	89 c1                	mov    ecx,eax
    753e0260b097:	c1 e9 1f             	shr    ecx,0x1f
    753e0260b09a:	c4 e2 48 f2 c9       	andn   ecx,esi,ecx
    753e0260b09f:	41 09 cf             	or     r15d,ecx
    753e0260b0a2:	41 09 ff             	or     r15d,edi
    753e0260b0a5:	41 0f a4 de 07       	shld   r14d,ebx,0x7
    753e0260b0aa:	41 39 c5             	cmp    r13d,eax
    753e0260b0ad:	76 21                	jbe    0x753e0260b0d0
    753e0260b0af:	41 8d 74 24 0a       	lea    esi,[r12+0xa]
    753e0260b0b4:	44 39 de             	cmp    esi,r11d
    753e0260b0b7:	0f 83 1c 02 00 00    	jae    0x753e0260b2d9
    753e0260b0bd:	41 8b 88 58 01 00 00 	mov    ecx,DWORD PTR [r8+0x158]
    753e0260b0c4:	8d 78 01             	lea    edi,[rax+0x1]
    753e0260b0c7:	85 c9                	test   ecx,ecx
    753e0260b0c9:	75 95                	jne    0x753e0260b060
    753e0260b0cb:	e9 09 02 00 00       	jmp    0x753e0260b2d9
    753e0260b0d0:	0f 96 c0             	setbe  al
    753e0260b0d3:	0f b6 c0             	movzx  eax,al
    753e0260b0d6:	89 44 24 14          	mov    DWORD PTR [rsp+0x14],eax
    753e0260b0da:	31 db                	xor    ebx,ebx
    753e0260b0dc:	31 c0                	xor    eax,eax
    753e0260b0de:	44 3b 6c 24 08       	cmp    r13d,DWORD PTR [rsp+0x8]
    753e0260b0e3:	0f 93 c3             	setae  bl
    753e0260b0e6:	0f 92 c0             	setb   al
    753e0260b0e9:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    753e0260b0ed:	41 8b 78 3c          	mov    edi,DWORD PTR [r8+0x3c]
    753e0260b0f1:	40 f6 c7 03          	test   dil,0x3
    753e0260b0f5:	0f 85 10 03 00 00    	jne    0x753e0260b40b
    753e0260b0fb:	48 89 f8             	mov    rax,rdi
    753e0260b0fe:	48 c1 e8 0c          	shr    rax,0xc
    753e0260b102:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    753e0260b107:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    753e0260b10b:	48 85 c0             	test   rax,rax
    753e0260b10e:	89 5c 24 1c          	mov    DWORD PTR [rsp+0x1c],ebx
    753e0260b112:	0f 84 a4 03 00 00    	je     0x753e0260b4bc
    753e0260b118:	89 f9                	mov    ecx,edi
    753e0260b11a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260b120:	8b 0c 08             	mov    ecx,DWORD PTR [rax+rcx*1]
    753e0260b123:	8d 77 04             	lea    esi,[rdi+0x4]
    753e0260b126:	89 f0                	mov    eax,esi
    753e0260b128:	c1 e8 0c             	shr    eax,0xc
    753e0260b12b:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    753e0260b12f:	48 85 c0             	test   rax,rax
    753e0260b132:	0f 84 61 04 00 00    	je     0x753e0260b599
    753e0260b138:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753e0260b13e:	44 8b 2c 30          	mov    r13d,DWORD PTR [rax+rsi*1]
    753e0260b142:	8d 77 08             	lea    esi,[rdi+0x8]
    753e0260b145:	41 89 48 3c          	mov    DWORD PTR [r8+0x3c],ecx
    753e0260b149:	45 89 a8 a8 00 00 00 	mov    DWORD PTR [r8+0xa8],r13d
    753e0260b150:	41 89 70 38          	mov    DWORD PTR [r8+0x38],esi
    753e0260b154:	89 f0                	mov    eax,esi
    753e0260b156:	c1 e8 0c             	shr    eax,0xc
    753e0260b159:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    753e0260b15d:	48 85 c0             	test   rax,rax
    753e0260b160:	0f 84 16 05 00 00    	je     0x753e0260b67c
    753e0260b166:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753e0260b16c:	8b 0c 30             	mov    ecx,DWORD PTR [rax+rsi*1]
    753e0260b16f:	8d 77 0c             	lea    esi,[rdi+0xc]
    753e0260b172:	89 f0                	mov    eax,esi
    753e0260b174:	c1 e8 0c             	shr    eax,0xc
    753e0260b177:	48 8b 04 c2          	mov    rax,QWORD PTR [rdx+rax*8]
    753e0260b17b:	48 85 c0             	test   rax,rax
    753e0260b17e:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    753e0260b183:	0f 84 c9 05 00 00    	je     0x753e0260b752
    753e0260b189:	81 e6 ff 0f 00 00    	and    esi,0xfff
    753e0260b18f:	8b 04 30             	mov    eax,DWORD PTR [rax+rsi*1]
    753e0260b192:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    753e0260b196:	83 c7 10             	add    edi,0x10
    753e0260b199:	41 89 78 38          	mov    DWORD PTR [r8+0x38],edi
    753e0260b19d:	41 f6 c5 01          	test   r13b,0x1
    753e0260b1a1:	0f 85 74 06 00 00    	jne    0x753e0260b81b
    753e0260b1a7:	4d 89 e9             	mov    r9,r13
    753e0260b1aa:	c6 44 24 0f 01       	mov    BYTE PTR [rsp+0xf],0x1
    753e0260b1af:	c7 44 24 20 00 00 00 	mov    DWORD PTR [rsp+0x20],0x0
    753e0260b1b6:	00 
    753e0260b1b7:	bf 02 00 00 00       	mov    edi,0x2
    753e0260b1bc:	b9 0e 00 00 00       	mov    ecx,0xe
    753e0260b1c1:	c7 44 24 2c 00 00 00 	mov    DWORD PTR [rsp+0x2c],0x0
    753e0260b1c8:	00 
    753e0260b1c9:	89 d8                	mov    eax,ebx
    753e0260b1cb:	89 da                	mov    edx,ebx
    753e0260b1cd:	45 89 f5             	mov    r13d,r14d
    753e0260b1d0:	42 8d 34 21          	lea    esi,[rcx+r12*1]
    753e0260b1d4:	44 39 de             	cmp    esi,r11d
    753e0260b1d7:	0f 83 98 01 00 00    	jae    0x753e0260b375
    753e0260b1dd:	48 8b 5c 24 30       	mov    rbx,QWORD PTR [rsp+0x30]
    753e0260b1e2:	8b 9b 58 01 00 00    	mov    ebx,DWORD PTR [rbx+0x158]
    753e0260b1e8:	85 db                	test   ebx,ebx
    753e0260b1ea:	0f 84 85 01 00 00    	je     0x753e0260b375
    753e0260b1f0:	4d 89 ca             	mov    r10,r9
    753e0260b1f3:	41 81 fa ec 00 01 00 	cmp    r10d,0x100ec
    753e0260b1fa:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b1ff:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    753e0260b203:	0f 84 27 fe ff ff    	je     0x753e0260b030
    753e0260b209:	46 8d 1c d5 00 00 00 	lea    r11d,[r10*8+0x0]
    753e0260b210:	00 
    753e0260b211:	41 81 e3 f0 ff 0f 00 	and    r11d,0xffff0
    753e0260b218:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    753e0260b21d:	46 39 14 1b          	cmp    DWORD PTR [rbx+r11*1],r10d
    753e0260b221:	0f 85 4e 01 00 00    	jne    0x753e0260b375
    753e0260b227:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
    753e0260b22c:	4e 8b 44 1b 08       	mov    r8,QWORD PTR [rbx+r11*1+0x8]
    753e0260b231:	4c 8b 54 24 30       	mov    r10,QWORD PTR [rsp+0x30]
    753e0260b236:	45 89 2a             	mov    DWORD PTR [r10],r13d
    753e0260b239:	45 89 72 04          	mov    DWORD PTR [r10+0x4],r14d
    753e0260b23d:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    753e0260b241:	41 89 5a 08          	mov    DWORD PTR [r10+0x8],ebx
    753e0260b245:	41 89 6a 0c          	mov    DWORD PTR [r10+0xc],ebp
    753e0260b249:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    753e0260b24d:	41 89 5a 18          	mov    DWORD PTR [r10+0x18],ebx
    753e0260b251:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    753e0260b256:	41 89 6a 1c          	mov    DWORD PTR [r10+0x1c],ebp
    753e0260b25a:	45 89 8a bc 00 00 00 	mov    DWORD PTR [r10+0xbc],r9d
    753e0260b261:	41 89 92 e4 00 00 00 	mov    DWORD PTR [r10+0xe4],edx
    753e0260b268:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    753e0260b26c:	41 89 92 e8 00 00 00 	mov    DWORD PTR [r10+0xe8],edx
    753e0260b273:	41 89 82 ec 00 00 00 	mov    DWORD PTR [r10+0xec],eax
    753e0260b27a:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    753e0260b27e:	41 89 82 f0 00 00 00 	mov    DWORD PTR [r10+0xf0],eax
    753e0260b285:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    753e0260b289:	41 89 82 f8 00 00 00 	mov    DWORD PTR [r10+0xf8],eax
    753e0260b290:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    753e0260b294:	41 89 82 fc 00 00 00 	mov    DWORD PTR [r10+0xfc],eax
    753e0260b29b:	45 89 ba 00 01 00 00 	mov    DWORD PTR [r10+0x100],r15d
    753e0260b2a2:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b2a6:	41 89 82 14 01 00 00 	mov    DWORD PTR [r10+0x114],eax
    753e0260b2ad:	41 89 ba 24 01 00 00 	mov    DWORD PTR [r10+0x124],edi
    753e0260b2b4:	41 c6 82 28 01 00 00 	mov    BYTE PTR [r10+0x128],0x0
    753e0260b2bb:	00 
    753e0260b2bc:	41 89 8a 34 01 00 00 	mov    DWORD PTR [r10+0x134],ecx
    753e0260b2c3:	41 89 b2 5c 01 00 00 	mov    DWORD PTR [r10+0x15c],esi
    753e0260b2ca:	4d 89 d5             	mov    r13,r10
    753e0260b2cd:	4c 8b 74 24 40       	mov    r14,QWORD PTR [rsp+0x40]
    753e0260b2d2:	48 83 c4 58          	add    rsp,0x58
    753e0260b2d6:	41 ff e0             	jmp    r8
    753e0260b2d9:	31 c9                	xor    ecx,ecx
    753e0260b2db:	31 d2                	xor    edx,edx
    753e0260b2dd:	31 f6                	xor    esi,esi
    753e0260b2df:	31 ff                	xor    edi,edi
    753e0260b2e1:	41 39 c5             	cmp    r13d,eax
    753e0260b2e4:	0f 96 c1             	setbe  cl
    753e0260b2e7:	0f 94 c2             	sete   dl
    753e0260b2ea:	40 0f 92 c6          	setb   sil
    753e0260b2ee:	40 0f 93 c7          	setae  dil
    753e0260b2f2:	45 89 28             	mov    DWORD PTR [r8],r13d
    753e0260b2f5:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b2f9:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b2fd:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b301:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b305:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    753e0260b309:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x100ec
    753e0260b310:	ec 00 01 00 
    753e0260b314:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    753e0260b31b:	41 89 b0 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],esi
    753e0260b322:	41 89 b8 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edi
    753e0260b329:	41 89 b8 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edi
    753e0260b330:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b337:	00 00 00 00 
    753e0260b33b:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b342:	41 89 88 14 01 00 00 	mov    DWORD PTR [r8+0x114],ecx
    753e0260b349:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    753e0260b350:	02 00 00 00 
    753e0260b354:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x1
    753e0260b35b:	01 
    753e0260b35c:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xa
    753e0260b363:	0a 00 00 00 
    753e0260b367:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b36e:	48 83 c4 58          	add    rsp,0x58
    753e0260b372:	c2 08 00             	ret    0x8
    753e0260b375:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
    753e0260b37a:	44 89 2e             	mov    DWORD PTR [rsi],r13d
    753e0260b37d:	44 89 76 04          	mov    DWORD PTR [rsi+0x4],r14d
    753e0260b381:	8b 5c 24 10          	mov    ebx,DWORD PTR [rsp+0x10]
    753e0260b385:	89 5e 08             	mov    DWORD PTR [rsi+0x8],ebx
    753e0260b388:	89 6e 0c             	mov    DWORD PTR [rsi+0xc],ebp
    753e0260b38b:	8b 5c 24 18          	mov    ebx,DWORD PTR [rsp+0x18]
    753e0260b38f:	89 5e 18             	mov    DWORD PTR [rsi+0x18],ebx
    753e0260b392:	48 8b 6c 24 38       	mov    rbp,QWORD PTR [rsp+0x38]
    753e0260b397:	89 6e 1c             	mov    DWORD PTR [rsi+0x1c],ebp
    753e0260b39a:	44 89 8e bc 00 00 00 	mov    DWORD PTR [rsi+0xbc],r9d
    753e0260b3a1:	89 96 e4 00 00 00    	mov    DWORD PTR [rsi+0xe4],edx
    753e0260b3a7:	8b 54 24 08          	mov    edx,DWORD PTR [rsp+0x8]
    753e0260b3ab:	89 96 e8 00 00 00    	mov    DWORD PTR [rsi+0xe8],edx
    753e0260b3b1:	89 86 ec 00 00 00    	mov    DWORD PTR [rsi+0xec],eax
    753e0260b3b7:	8b 44 24 1c          	mov    eax,DWORD PTR [rsp+0x1c]
    753e0260b3bb:	89 86 f0 00 00 00    	mov    DWORD PTR [rsi+0xf0],eax
    753e0260b3c1:	8b 44 24 2c          	mov    eax,DWORD PTR [rsp+0x2c]
    753e0260b3c5:	89 86 f8 00 00 00    	mov    DWORD PTR [rsi+0xf8],eax
    753e0260b3cb:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    753e0260b3cf:	89 86 fc 00 00 00    	mov    DWORD PTR [rsi+0xfc],eax
    753e0260b3d5:	44 89 be 00 01 00 00 	mov    DWORD PTR [rsi+0x100],r15d
    753e0260b3dc:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b3e0:	89 86 14 01 00 00    	mov    DWORD PTR [rsi+0x114],eax
    753e0260b3e6:	89 be 24 01 00 00    	mov    DWORD PTR [rsi+0x124],edi
    753e0260b3ec:	0f b6 44 24 0f       	movzx  eax,BYTE PTR [rsp+0xf]
    753e0260b3f1:	88 86 28 01 00 00    	mov    BYTE PTR [rsi+0x128],al
    753e0260b3f7:	89 8e 34 01 00 00    	mov    DWORD PTR [rsi+0x134],ecx
    753e0260b3fd:	44 89 a6 5c 01 00 00 	mov    DWORD PTR [rsi+0x15c],r12d
    753e0260b404:	48 83 c4 58          	add    rsp,0x58
    753e0260b408:	c2 08 00             	ret    0x8
    753e0260b40b:	89 d9                	mov    ecx,ebx
    753e0260b40d:	44 89 db             	mov    ebx,r11d
    753e0260b410:	45 89 28             	mov    DWORD PTR [r8],r13d
    753e0260b413:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b417:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b41b:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b41f:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b423:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b427:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    753e0260b42b:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    753e0260b432:	04 01 01 00 
    753e0260b436:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    753e0260b43d:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b441:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b448:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    753e0260b44f:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    753e0260b456:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b45d:	00 00 00 00 
    753e0260b461:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b468:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b46c:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b473:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    753e0260b47a:	04 00 00 00 
    753e0260b47e:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b485:	00 
    753e0260b486:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    753e0260b48d:	0b 00 00 00 
    753e0260b491:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b498:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260b49f:	5c 00 00 
    753e0260b4a2:	48 89 f9             	mov    rcx,rdi
    753e0260b4a5:	4c 89 c7             	mov    rdi,r8
    753e0260b4a8:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
    753e0260b4ad:	ba 04 01 01 00       	mov    edx,0x10104
    753e0260b4b2:	45 31 c0             	xor    r8d,r8d
    753e0260b4b5:	ff d0                	call   rax
    753e0260b4b7:	e9 0e 04 00 00       	jmp    0x753e0260b8ca
    753e0260b4bc:	89 d9                	mov    ecx,ebx
    753e0260b4be:	44 89 db             	mov    ebx,r11d
    753e0260b4c1:	45 89 28             	mov    DWORD PTR [r8],r13d
    753e0260b4c4:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b4c8:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b4cc:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b4d0:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b4d4:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b4d8:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    753e0260b4dc:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    753e0260b4e3:	04 01 01 00 
    753e0260b4e7:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    753e0260b4ee:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b4f2:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b4f9:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    753e0260b500:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    753e0260b507:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b50e:	00 00 00 00 
    753e0260b512:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b519:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b51d:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b524:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    753e0260b52b:	04 00 00 00 
    753e0260b52f:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b536:	00 
    753e0260b537:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    753e0260b53e:	0b 00 00 00 
    753e0260b542:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b549:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260b550:	5c 00 00 
    753e0260b553:	48 89 fe             	mov    rsi,rdi
    753e0260b556:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    753e0260b55b:	48 89 74 24 20       	mov    QWORD PTR [rsp+0x20],rsi
    753e0260b560:	ff d0                	call   rax
    753e0260b562:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b567:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    753e0260b56e:	00 
    753e0260b56f:	84 c9                	test   cl,cl
    753e0260b571:	0f 85 60 03 00 00    	jne    0x753e0260b8d7
    753e0260b577:	41 89 db             	mov    r11d,ebx
    753e0260b57a:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    753e0260b57f:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    753e0260b584:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    753e0260b589:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    753e0260b58d:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753e0260b592:	89 c1                	mov    ecx,eax
    753e0260b594:	e9 8a fb ff ff       	jmp    0x753e0260b123
    753e0260b599:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    753e0260b59d:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753e0260b5a2:	89 d9                	mov    ecx,ebx
    753e0260b5a4:	44 89 db             	mov    ebx,r11d
    753e0260b5a7:	45 89 28             	mov    DWORD PTR [r8],r13d
    753e0260b5aa:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b5ae:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b5b2:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b5b6:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b5ba:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b5be:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    753e0260b5c2:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x10104
    753e0260b5c9:	04 01 01 00 
    753e0260b5cd:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    753e0260b5d4:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b5d8:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b5df:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    753e0260b5e6:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    753e0260b5ed:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b5f4:	00 00 00 00 
    753e0260b5f8:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b5ff:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b603:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b60a:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x4
    753e0260b611:	04 00 00 00 
    753e0260b615:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b61c:	00 
    753e0260b61d:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xb
    753e0260b624:	0b 00 00 00 
    753e0260b628:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b62f:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260b636:	5c 00 00 
    753e0260b639:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    753e0260b63e:	ff d0                	call   rax
    753e0260b640:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b645:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    753e0260b64c:	00 
    753e0260b64d:	84 c9                	test   cl,cl
    753e0260b64f:	0f 85 82 02 00 00    	jne    0x753e0260b8d7
    753e0260b655:	41 89 c5             	mov    r13d,eax
    753e0260b658:	41 89 db             	mov    r11d,ebx
    753e0260b65b:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    753e0260b660:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
    753e0260b665:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    753e0260b66a:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    753e0260b66e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753e0260b673:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e0260b677:	e9 c6 fa ff ff       	jmp    0x753e0260b142
    753e0260b67c:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753e0260b681:	89 d9                	mov    ecx,ebx
    753e0260b683:	44 89 db             	mov    ebx,r11d
    753e0260b686:	45 89 30             	mov    DWORD PTR [r8],r14d
    753e0260b689:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b68d:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b691:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b695:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b699:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b69d:	45 89 48 1c          	mov    DWORD PTR [r8+0x1c],r9d
    753e0260b6a1:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    753e0260b6a8:	0a 01 01 00 
    753e0260b6ac:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    753e0260b6b3:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b6b7:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b6be:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    753e0260b6c5:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    753e0260b6cc:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b6d3:	00 00 00 00 
    753e0260b6d7:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b6de:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b6e2:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b6e9:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    753e0260b6f0:	02 00 00 00 
    753e0260b6f4:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b6fb:	00 
    753e0260b6fc:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    753e0260b703:	0d 00 00 00 
    753e0260b707:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b70e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260b715:	5c 00 00 
    753e0260b718:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    753e0260b71d:	ff d0                	call   rax
    753e0260b71f:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b724:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    753e0260b72b:	00 
    753e0260b72c:	84 c9                	test   cl,cl
    753e0260b72e:	0f 85 a3 01 00 00    	jne    0x753e0260b8d7
    753e0260b734:	41 89 db             	mov    r11d,ebx
    753e0260b737:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
    753e0260b73c:	48 89 c1             	mov    rcx,rax
    753e0260b73f:	44 8b 54 24 18       	mov    r10d,DWORD PTR [rsp+0x18]
    753e0260b744:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    753e0260b748:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753e0260b74d:	e9 1d fa ff ff       	jmp    0x753e0260b16f
    753e0260b752:	48 89 7c 24 20       	mov    QWORD PTR [rsp+0x20],rdi
    753e0260b757:	89 da                	mov    edx,ebx
    753e0260b759:	44 89 db             	mov    ebx,r11d
    753e0260b75c:	45 89 30             	mov    DWORD PTR [r8],r14d
    753e0260b75f:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b763:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b767:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b76b:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b76f:	45 89 50 18          	mov    DWORD PTR [r8+0x18],r10d
    753e0260b773:	41 89 48 1c          	mov    DWORD PTR [r8+0x1c],ecx
    753e0260b777:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010a
    753e0260b77e:	0a 01 01 00 
    753e0260b782:	41 89 90 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],edx
    753e0260b789:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b78d:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b794:	41 89 90 ec 00 00 00 	mov    DWORD PTR [r8+0xec],edx
    753e0260b79b:	41 89 90 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],edx
    753e0260b7a2:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b7a9:	00 00 00 00 
    753e0260b7ad:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b7b4:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b7b8:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b7bf:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    753e0260b7c6:	02 00 00 00 
    753e0260b7ca:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b7d1:	00 
    753e0260b7d2:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xd
    753e0260b7d9:	0d 00 00 00 
    753e0260b7dd:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b7e4:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260b7eb:	5c 00 00 
    753e0260b7ee:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
    753e0260b7f3:	ff d0                	call   rax
    753e0260b7f5:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b7fa:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    753e0260b801:	00 
    753e0260b802:	84 c9                	test   cl,cl
    753e0260b804:	0f 85 cd 00 00 00    	jne    0x753e0260b8d7
    753e0260b80a:	41 89 db             	mov    r11d,ebx
    753e0260b80d:	8b 5c 24 1c          	mov    ebx,DWORD PTR [rsp+0x1c]
    753e0260b811:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
    753e0260b816:	e9 77 f9 ff ff       	jmp    0x753e0260b192
    753e0260b81b:	89 d9                	mov    ecx,ebx
    753e0260b81d:	44 89 db             	mov    ebx,r11d
    753e0260b820:	45 89 30             	mov    DWORD PTR [r8],r14d
    753e0260b823:	45 89 70 04          	mov    DWORD PTR [r8+0x4],r14d
    753e0260b827:	8b 44 24 10          	mov    eax,DWORD PTR [rsp+0x10]
    753e0260b82b:	41 89 40 08          	mov    DWORD PTR [r8+0x8],eax
    753e0260b82f:	41 89 68 0c          	mov    DWORD PTR [r8+0xc],ebp
    753e0260b833:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    753e0260b837:	41 89 40 18          	mov    DWORD PTR [r8+0x18],eax
    753e0260b83b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e0260b840:	41 89 40 1c          	mov    DWORD PTR [r8+0x1c],eax
    753e0260b844:	41 c7 80 bc 00 00 00 	mov    DWORD PTR [r8+0xbc],0x1010c
    753e0260b84b:	0c 01 01 00 
    753e0260b84f:	41 89 88 e4 00 00 00 	mov    DWORD PTR [r8+0xe4],ecx
    753e0260b856:	8b 44 24 08          	mov    eax,DWORD PTR [rsp+0x8]
    753e0260b85a:	41 89 80 e8 00 00 00 	mov    DWORD PTR [r8+0xe8],eax
    753e0260b861:	41 89 88 ec 00 00 00 	mov    DWORD PTR [r8+0xec],ecx
    753e0260b868:	41 89 88 f0 00 00 00 	mov    DWORD PTR [r8+0xf0],ecx
    753e0260b86f:	49 c7 80 f8 00 00 00 	mov    QWORD PTR [r8+0xf8],0x0
    753e0260b876:	00 00 00 00 
    753e0260b87a:	45 89 b8 00 01 00 00 	mov    DWORD PTR [r8+0x100],r15d
    753e0260b881:	8b 44 24 14          	mov    eax,DWORD PTR [rsp+0x14]
    753e0260b885:	41 89 80 14 01 00 00 	mov    DWORD PTR [r8+0x114],eax
    753e0260b88c:	41 c7 80 24 01 00 00 	mov    DWORD PTR [r8+0x124],0x2
    753e0260b893:	02 00 00 00 
    753e0260b897:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e0260b89e:	00 
    753e0260b89f:	41 c7 80 34 01 00 00 	mov    DWORD PTR [r8+0x134],0xe
    753e0260b8a6:	0e 00 00 00 
    753e0260b8aa:	45 89 a0 5c 01 00 00 	mov    DWORD PTR [r8+0x15c],r12d
    753e0260b8b1:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e0260b8b8:	5c 00 00 
    753e0260b8bb:	4c 89 c7             	mov    rdi,r8
    753e0260b8be:	be 2a 00 00 00       	mov    esi,0x2a
    753e0260b8c3:	48 8b 54 24 40       	mov    rdx,QWORD PTR [rsp+0x40]
    753e0260b8c8:	ff d0                	call   rax
    753e0260b8ca:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
    753e0260b8cf:	41 0f b6 88 28 01 00 	movzx  ecx,BYTE PTR [r8+0x128]
    753e0260b8d6:	00 
    753e0260b8d7:	88 4c 24 0f          	mov    BYTE PTR [rsp+0xf],cl
    753e0260b8db:	45 8b 88 bc 00 00 00 	mov    r9d,DWORD PTR [r8+0xbc]
    753e0260b8e2:	45 8b 28             	mov    r13d,DWORD PTR [r8]
    753e0260b8e5:	45 8b 70 04          	mov    r14d,DWORD PTR [r8+0x4]
    753e0260b8e9:	41 8b 40 08          	mov    eax,DWORD PTR [r8+0x8]
    753e0260b8ed:	89 44 24 10          	mov    DWORD PTR [rsp+0x10],eax
    753e0260b8f1:	41 8b 68 0c          	mov    ebp,DWORD PTR [r8+0xc]
    753e0260b8f5:	41 8b 40 18          	mov    eax,DWORD PTR [r8+0x18]
    753e0260b8f9:	89 44 24 18          	mov    DWORD PTR [rsp+0x18],eax
    753e0260b8fd:	41 8b 40 1c          	mov    eax,DWORD PTR [r8+0x1c]
    753e0260b901:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e0260b906:	41 8b 90 e4 00 00 00 	mov    edx,DWORD PTR [r8+0xe4]
    753e0260b90d:	41 8b 80 e8 00 00 00 	mov    eax,DWORD PTR [r8+0xe8]
    753e0260b914:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
    753e0260b918:	41 8b 80 ec 00 00 00 	mov    eax,DWORD PTR [r8+0xec]
    753e0260b91f:	41 8b 88 f0 00 00 00 	mov    ecx,DWORD PTR [r8+0xf0]
    753e0260b926:	89 4c 24 1c          	mov    DWORD PTR [rsp+0x1c],ecx
    753e0260b92a:	41 8b 88 f8 00 00 00 	mov    ecx,DWORD PTR [r8+0xf8]
    753e0260b931:	89 4c 24 2c          	mov    DWORD PTR [rsp+0x2c],ecx
    753e0260b935:	41 8b 88 fc 00 00 00 	mov    ecx,DWORD PTR [r8+0xfc]
    753e0260b93c:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    753e0260b940:	45 8b b8 00 01 00 00 	mov    r15d,DWORD PTR [r8+0x100]
    753e0260b947:	41 8b 88 14 01 00 00 	mov    ecx,DWORD PTR [r8+0x114]
    753e0260b94e:	89 4c 24 14          	mov    DWORD PTR [rsp+0x14],ecx
    753e0260b952:	41 8b b8 24 01 00 00 	mov    edi,DWORD PTR [r8+0x124]
    753e0260b959:	41 8b 88 34 01 00 00 	mov    ecx,DWORD PTR [r8+0x134]
    753e0260b960:	45 8b a0 5c 01 00 00 	mov    r12d,DWORD PTR [r8+0x15c]
    753e0260b967:	41 89 db             	mov    r11d,ebx
    753e0260b96a:	e9 61 f8 ff ff       	jmp    0x753e0260b1d0
