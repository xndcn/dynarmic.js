
build-native-instruction-analysis/capture/bcore-default-integer/pc-65772-0-128909188309520.bin:     file format binary


Disassembly of section .data:

0000753e0260a210 <.data>:
    753e0260a210:	48 81 ec e8 00 00 00 	sub    rsp,0xe8
    753e0260a217:	4c 89 b4 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],r14
    753e0260a21e:	00 
    753e0260a21f:	4c 89 ac 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r13
    753e0260a226:	00 
    753e0260a227:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260a22e:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    753e0260a235:	00 
    753e0260a236:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260a23d:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    753e0260a244:	00 
    753e0260a245:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    753e0260a24c:	00 
    753e0260a24d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e0260a253:	83 fa 00             	cmp    edx,0x0
    753e0260a256:	0f 94 c0             	sete   al
    753e0260a259:	81 ea ec 00 01 00    	sub    edx,0x100ec
    753e0260a25f:	83 fa 20             	cmp    edx,0x20
    753e0260a262:	0f 97 c2             	seta   dl
    753e0260a265:	08 d0                	or     al,dl
    753e0260a267:	24 01                	and    al,0x1
    753e0260a269:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260a26f:	83 fa 00             	cmp    edx,0x0
    753e0260a272:	0f 94 c1             	sete   cl
    753e0260a275:	81 ea ec 00 01 00    	sub    edx,0x100ec
    753e0260a27b:	83 fa 20             	cmp    edx,0x20
    753e0260a27e:	0f 97 c2             	seta   dl
    753e0260a281:	08 d1                	or     cl,dl
    753e0260a283:	20 c8                	and    al,cl
    753e0260a285:	a8 01                	test   al,0x1
    753e0260a287:	75 05                	jne    0x753e0260a28e
    753e0260a289:	e9 69 0b 00 00       	jmp    0x753e0260adf7
    753e0260a28e:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a295:	00 
    753e0260a296:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e0260a29d:	48 89 c8             	mov    rax,rcx
    753e0260a2a0:	48 05 00 00 10 00    	add    rax,0x100000
    753e0260a2a6:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    753e0260a2ad:	00 
    753e0260a2ae:	8b 81 24 00 10 00    	mov    eax,DWORD PTR [rcx+0x100024]
    753e0260a2b4:	83 c0 01             	add    eax,0x1
    753e0260a2b7:	89 81 24 00 10 00    	mov    DWORD PTR [rcx+0x100024],eax
    753e0260a2bd:	3d 30 75 00 00       	cmp    eax,0x7530
    753e0260a2c2:	75 4c                	jne    0x753e0260a310
    753e0260a2c4:	48 8b 8c 24 c0 00 00 	mov    rcx,QWORD PTR [rsp+0xc0]
    753e0260a2cb:	00 
    753e0260a2cc:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e0260a2d2:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e0260a2d9:	89 c2                	mov    edx,eax
    753e0260a2db:	83 c2 01             	add    edx,0x1
    753e0260a2de:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e0260a2e4:	3d 00 01 00 00       	cmp    eax,0x100
    753e0260a2e9:	73 23                	jae    0x753e0260a30e
    753e0260a2eb:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e0260a2f2:	00 
    753e0260a2f3:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e0260a2fa:	89 c9                	mov    ecx,ecx
    753e0260a2fc:	48 c1 e1 02          	shl    rcx,0x2
    753e0260a300:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e0260a307:	c7 04 08 09 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x9
    753e0260a30e:	eb 00                	jmp    0x753e0260a310
    753e0260a310:	eb 00                	jmp    0x753e0260a312
    753e0260a312:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a319:	00 
    753e0260a31a:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    753e0260a31d:	0f af 48 18          	imul   ecx,DWORD PTR [rax+0x18]
    753e0260a321:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    753e0260a328:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e0260a32b:	eb 00                	jmp    0x753e0260a32d
    753e0260a32d:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a334:	00 
    753e0260a335:	8b 8c 24 b8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb8]
    753e0260a33c:	8b 78 1c             	mov    edi,DWORD PTR [rax+0x1c]
    753e0260a33f:	89 ca                	mov    edx,ecx
    753e0260a341:	01 fa                	add    edx,edi
    753e0260a343:	89 94 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],edx
    753e0260a34a:	89 50 04             	mov    DWORD PTR [rax+0x4],edx
    753e0260a34d:	89 ce                	mov    esi,ecx
    753e0260a34f:	c1 ee 1f             	shr    esi,0x1f
    753e0260a352:	89 fb                	mov    ebx,edi
    753e0260a354:	c1 eb 1f             	shr    ebx,0x1f
    753e0260a357:	89 d5                	mov    ebp,edx
    753e0260a359:	c1 ed 1f             	shr    ebp,0x1f
    753e0260a35c:	31 eb                	xor    ebx,ebp
    753e0260a35e:	31 ee                	xor    esi,ebp
    753e0260a360:	21 de                	and    esi,ebx
    753e0260a362:	83 f1 ff             	xor    ecx,0xffffffff
    753e0260a365:	39 f9                	cmp    ecx,edi
    753e0260a367:	0f 92 c1             	setb   cl
    753e0260a36a:	80 e1 01             	and    cl,0x1
    753e0260a36d:	0f b6 c9             	movzx  ecx,cl
    753e0260a370:	83 fa 00             	cmp    edx,0x0
    753e0260a373:	0f 94 c3             	sete   bl
    753e0260a376:	80 e3 01             	and    bl,0x1
    753e0260a379:	0f b6 fb             	movzx  edi,bl
    753e0260a37c:	c1 ea 1f             	shr    edx,0x1f
    753e0260a37f:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    753e0260a385:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260a38b:	89 f2                	mov    edx,esi
    753e0260a38d:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    753e0260a393:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    753e0260a39a:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    753e0260a3a0:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    753e0260a3a6:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    753e0260a3ac:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260a3b2:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e0260a3b8:	eb 00                	jmp    0x753e0260a3ba
    753e0260a3ba:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a3c1:	00 
    753e0260a3c2:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e0260a3c9:	c1 e9 0d             	shr    ecx,0xd
    753e0260a3cc:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e0260a3d3:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    753e0260a3d6:	83 f9 00             	cmp    ecx,0x0
    753e0260a3d9:	0f 94 c2             	sete   dl
    753e0260a3dc:	80 e2 01             	and    dl,0x1
    753e0260a3df:	0f b6 d2             	movzx  edx,dl
    753e0260a3e2:	c1 e9 1f             	shr    ecx,0x1f
    753e0260a3e5:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260a3eb:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e0260a3f1:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260a3f8:	00 00 00 
    753e0260a3fb:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260a402:	00 00 00 
    753e0260a405:	eb 00                	jmp    0x753e0260a407
    753e0260a407:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a40e:	00 
    753e0260a40f:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    753e0260a416:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e0260a41d:	31 d1                	xor    ecx,edx
    753e0260a41f:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    753e0260a426:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e0260a429:	83 f9 00             	cmp    ecx,0x0
    753e0260a42c:	0f 94 c2             	sete   dl
    753e0260a42f:	80 e2 01             	and    dl,0x1
    753e0260a432:	0f b6 d2             	movzx  edx,dl
    753e0260a435:	c1 e9 1f             	shr    ecx,0x1f
    753e0260a438:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260a43e:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e0260a444:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    753e0260a44b:	00 00 00 
    753e0260a44e:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    753e0260a455:	00 00 00 
    753e0260a458:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260a45f:	00 00 00 
    753e0260a462:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260a469:	00 00 00 
    753e0260a46c:	eb 00                	jmp    0x753e0260a46e
    753e0260a46e:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a475:	00 
    753e0260a476:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    753e0260a47d:	c1 e1 07             	shl    ecx,0x7
    753e0260a480:	89 8c 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],ecx
    753e0260a487:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    753e0260a48a:	83 f9 00             	cmp    ecx,0x0
    753e0260a48d:	0f 94 c2             	sete   dl
    753e0260a490:	80 e2 01             	and    dl,0x1
    753e0260a493:	0f b6 d2             	movzx  edx,dl
    753e0260a496:	c1 e9 1f             	shr    ecx,0x1f
    753e0260a499:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260a49f:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e0260a4a5:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260a4ac:	00 00 00 
    753e0260a4af:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260a4b6:	00 00 00 
    753e0260a4b9:	eb 00                	jmp    0x753e0260a4bb
    753e0260a4bb:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a4c2:	00 
    753e0260a4c3:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    753e0260a4ca:	c1 e9 19             	shr    ecx,0x19
    753e0260a4cd:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    753e0260a4d4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e0260a4d7:	83 f9 00             	cmp    ecx,0x0
    753e0260a4da:	0f 94 c2             	sete   dl
    753e0260a4dd:	80 e2 01             	and    dl,0x1
    753e0260a4e0:	0f b6 d2             	movzx  edx,dl
    753e0260a4e3:	c1 e9 1f             	shr    ecx,0x1f
    753e0260a4e6:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260a4ec:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e0260a4f2:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260a4f9:	00 00 00 
    753e0260a4fc:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260a503:	00 00 00 
    753e0260a506:	eb 00                	jmp    0x753e0260a508
    753e0260a508:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a50f:	00 
    753e0260a510:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e0260a517:	8b 48 08             	mov    ecx,DWORD PTR [rax+0x8]
    753e0260a51a:	89 cf                	mov    edi,ecx
    753e0260a51c:	83 c7 01             	add    edi,0x1
    753e0260a51f:	89 bc 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],edi
    753e0260a526:	89 78 08             	mov    DWORD PTR [rax+0x8],edi
    753e0260a529:	89 ce                	mov    esi,ecx
    753e0260a52b:	c1 ee 1f             	shr    esi,0x1f
    753e0260a52e:	89 fd                	mov    ebp,edi
    753e0260a530:	c1 ed 1f             	shr    ebp,0x1f
    753e0260a533:	89 eb                	mov    ebx,ebp
    753e0260a535:	83 f3 00             	xor    ebx,0x0
    753e0260a538:	31 ee                	xor    esi,ebp
    753e0260a53a:	21 de                	and    esi,ebx
    753e0260a53c:	83 f1 ff             	xor    ecx,0xffffffff
    753e0260a53f:	83 f9 01             	cmp    ecx,0x1
    753e0260a542:	0f 92 c1             	setb   cl
    753e0260a545:	80 e1 01             	and    cl,0x1
    753e0260a548:	0f b6 c9             	movzx  ecx,cl
    753e0260a54b:	83 ff 00             	cmp    edi,0x0
    753e0260a54e:	0f 94 c3             	sete   bl
    753e0260a551:	80 e3 01             	and    bl,0x1
    753e0260a554:	0f b6 db             	movzx  ebx,bl
    753e0260a557:	c1 ef 1f             	shr    edi,0x1f
    753e0260a55a:	89 98 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],ebx
    753e0260a560:	89 b8 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edi
    753e0260a566:	09 f2                	or     edx,esi
    753e0260a568:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    753e0260a56e:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    753e0260a574:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    753e0260a57a:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260a580:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e0260a586:	eb 00                	jmp    0x753e0260a588
    753e0260a588:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a58f:	00 
    753e0260a590:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    753e0260a597:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260a59e:	09 d1                	or     ecx,edx
    753e0260a5a0:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    753e0260a5a7:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e0260a5aa:	83 f9 00             	cmp    ecx,0x0
    753e0260a5ad:	0f 94 c2             	sete   dl
    753e0260a5b0:	80 e2 01             	and    dl,0x1
    753e0260a5b3:	0f b6 d2             	movzx  edx,dl
    753e0260a5b6:	c1 e9 1f             	shr    ecx,0x1f
    753e0260a5b9:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260a5bf:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e0260a5c5:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    753e0260a5cc:	00 00 00 
    753e0260a5cf:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    753e0260a5d6:	00 00 00 
    753e0260a5d9:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260a5e0:	00 00 00 
    753e0260a5e3:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260a5ea:	00 00 00 
    753e0260a5ed:	eb 00                	jmp    0x753e0260a5ef
    753e0260a5ef:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a5f6:	00 
    753e0260a5f7:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    753e0260a5fe:	8b 38                	mov    edi,DWORD PTR [rax]
    753e0260a600:	39 cf                	cmp    edi,ecx
    753e0260a602:	0f 96 c2             	setbe  dl
    753e0260a605:	80 e2 01             	and    dl,0x1
    753e0260a608:	0f b6 d2             	movzx  edx,dl
    753e0260a60b:	89 94 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],edx
    753e0260a612:	89 90 14 01 00 00    	mov    DWORD PTR [rax+0x114],edx
    753e0260a618:	39 cf                	cmp    edi,ecx
    753e0260a61a:	0f 94 c2             	sete   dl
    753e0260a61d:	80 e2 01             	and    dl,0x1
    753e0260a620:	0f b6 f2             	movzx  esi,dl
    753e0260a623:	39 f9                	cmp    ecx,edi
    753e0260a625:	0f 97 c2             	seta   dl
    753e0260a628:	80 e2 01             	and    dl,0x1
    753e0260a62b:	0f b6 d2             	movzx  edx,dl
    753e0260a62e:	39 f9                	cmp    ecx,edi
    753e0260a630:	0f 96 c1             	setbe  cl
    753e0260a633:	80 e1 01             	and    cl,0x1
    753e0260a636:	0f b6 c9             	movzx  ecx,cl
    753e0260a639:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e0260a63f:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260a645:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260a64b:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e0260a651:	eb 00                	jmp    0x753e0260a653
    753e0260a653:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    753e0260a65a:	83 f8 00             	cmp    eax,0x0
    753e0260a65d:	75 33                	jne    0x753e0260a692
    753e0260a65f:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    753e0260a666:	00 
    753e0260a667:	c7 81 bc 00 00 00 ec 	mov    DWORD PTR [rcx+0xbc],0x100ec
    753e0260a66e:	00 01 00 
    753e0260a671:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260a677:	83 c0 0a             	add    eax,0xa
    753e0260a67a:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e0260a681:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260a687:	0f 82 7e 07 00 00    	jb     0x753e0260ae0b
    753e0260a68d:	e9 9d 07 00 00       	jmp    0x753e0260ae2f
    753e0260a692:	eb 00                	jmp    0x753e0260a694
    753e0260a694:	eb 00                	jmp    0x753e0260a696
    753e0260a696:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a69d:	00 
    753e0260a69e:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    753e0260a6a1:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    753e0260a6a8:	83 e0 03             	and    eax,0x3
    753e0260a6ab:	83 f8 00             	cmp    eax,0x0
    753e0260a6ae:	0f 84 91 00 00 00    	je     0x753e0260a745
    753e0260a6b4:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e0260a6bb:	00 
    753e0260a6bc:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260a6c3:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    753e0260a6ca:	00 
    753e0260a6cb:	c7 87 bc 00 00 00 04 	mov    DWORD PTR [rdi+0xbc],0x10104
    753e0260a6d2:	01 01 00 
    753e0260a6d5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260a6dc:	00 00 00 
    753e0260a6df:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    753e0260a6e6:	00 00 00 
    753e0260a6e9:	31 c0                	xor    eax,eax
    753e0260a6eb:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260a6f2:	5c 00 00 
    753e0260a6f5:	ba 04 01 01 00       	mov    edx,0x10104
    753e0260a6fa:	45 31 c0             	xor    r8d,r8d
    753e0260a6fd:	ff d0                	call   rax
    753e0260a6ff:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a706:	00 
    753e0260a707:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260a70d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260a713:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260a719:	be 0b 00 00 00       	mov    esi,0xb
    753e0260a71e:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260a723:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260a727:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260a72b:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260a732:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260a739:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260a740:	e9 1c 07 00 00       	jmp    0x753e0260ae61
    753e0260a745:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e0260a74c:	00 
    753e0260a74d:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260a754:	c1 e9 0c             	shr    ecx,0xc
    753e0260a757:	89 c9                	mov    ecx,ecx
    753e0260a759:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260a75d:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753e0260a762:	48 83 f8 00          	cmp    rax,0x0
    753e0260a766:	74 1d                	je     0x753e0260a785
    753e0260a768:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e0260a76d:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260a774:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260a77a:	89 c9                	mov    ecx,ecx
    753e0260a77c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260a77f:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260a783:	eb 5a                	jmp    0x753e0260a7df
    753e0260a785:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a78c:	00 
    753e0260a78d:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    753e0260a794:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    753e0260a79b:	00 
    753e0260a79c:	c7 80 bc 00 00 00 04 	mov    DWORD PTR [rax+0xbc],0x10104
    753e0260a7a3:	01 01 00 
    753e0260a7a6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260a7ad:	00 00 00 
    753e0260a7b0:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    753e0260a7b7:	00 00 00 
    753e0260a7ba:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260a7c1:	5c 00 00 
    753e0260a7c4:	ff d0                	call   rax
    753e0260a7c6:	89 c1                	mov    ecx,eax
    753e0260a7c8:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a7cf:	00 
    753e0260a7d0:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e0260a7d4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260a7db:	75 25                	jne    0x753e0260a802
    753e0260a7dd:	eb 69                	jmp    0x753e0260a848
    753e0260a7df:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    753e0260a7e6:	8b 4c 24 6c          	mov    ecx,DWORD PTR [rsp+0x6c]
    753e0260a7ea:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    753e0260a7ee:	83 c0 04             	add    eax,0x4
    753e0260a7f1:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e0260a7f5:	83 e0 03             	and    eax,0x3
    753e0260a7f8:	83 f8 00             	cmp    eax,0x0
    753e0260a7fb:	75 55                	jne    0x753e0260a852
    753e0260a7fd:	e9 de 00 00 00       	jmp    0x753e0260a8e0
    753e0260a802:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a809:	00 
    753e0260a80a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260a810:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260a816:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260a81c:	be 0b 00 00 00       	mov    esi,0xb
    753e0260a821:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260a826:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260a82a:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260a82e:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260a835:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260a83c:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260a843:	e9 19 06 00 00       	jmp    0x753e0260ae61
    753e0260a848:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    753e0260a84c:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260a850:	eb 8d                	jmp    0x753e0260a7df
    753e0260a852:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e0260a859:	00 
    753e0260a85a:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e0260a85e:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    753e0260a865:	00 
    753e0260a866:	c7 87 bc 00 00 00 04 	mov    DWORD PTR [rdi+0xbc],0x10104
    753e0260a86d:	01 01 00 
    753e0260a870:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260a877:	00 00 00 
    753e0260a87a:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    753e0260a881:	00 00 00 
    753e0260a884:	31 c0                	xor    eax,eax
    753e0260a886:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260a88d:	5c 00 00 
    753e0260a890:	ba 04 01 01 00       	mov    edx,0x10104
    753e0260a895:	45 31 c0             	xor    r8d,r8d
    753e0260a898:	ff d0                	call   rax
    753e0260a89a:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a8a1:	00 
    753e0260a8a2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260a8a8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260a8ae:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260a8b4:	be 0b 00 00 00       	mov    esi,0xb
    753e0260a8b9:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260a8be:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260a8c2:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260a8c6:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260a8cd:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260a8d4:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260a8db:	e9 81 05 00 00       	jmp    0x753e0260ae61
    753e0260a8e0:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e0260a8e7:	00 
    753e0260a8e8:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e0260a8ec:	c1 e9 0c             	shr    ecx,0xc
    753e0260a8ef:	89 c9                	mov    ecx,ecx
    753e0260a8f1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260a8f5:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e0260a8fa:	48 83 f8 00          	cmp    rax,0x0
    753e0260a8fe:	74 1a                	je     0x753e0260a91a
    753e0260a900:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e0260a905:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e0260a909:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260a90f:	89 c9                	mov    ecx,ecx
    753e0260a911:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260a914:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260a918:	eb 57                	jmp    0x753e0260a971
    753e0260a91a:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a921:	00 
    753e0260a922:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    753e0260a926:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    753e0260a92d:	00 
    753e0260a92e:	c7 80 bc 00 00 00 04 	mov    DWORD PTR [rax+0xbc],0x10104
    753e0260a935:	01 01 00 
    753e0260a938:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260a93f:	00 00 00 
    753e0260a942:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    753e0260a949:	00 00 00 
    753e0260a94c:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260a953:	5c 00 00 
    753e0260a956:	ff d0                	call   rax
    753e0260a958:	89 c1                	mov    ecx,eax
    753e0260a95a:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a961:	00 
    753e0260a962:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e0260a966:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260a96d:	75 2f                	jne    0x753e0260a99e
    753e0260a96f:	eb 73                	jmp    0x753e0260a9e4
    753e0260a971:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a978:	00 
    753e0260a979:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    753e0260a97d:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e0260a981:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    753e0260a985:	89 54 24 48          	mov    DWORD PTR [rsp+0x48],edx
    753e0260a989:	83 c1 04             	add    ecx,0x4
    753e0260a98c:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    753e0260a990:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e0260a993:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e0260a999:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e0260a99c:	eb 50                	jmp    0x753e0260a9ee
    753e0260a99e:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a9a5:	00 
    753e0260a9a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260a9ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260a9b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260a9b8:	be 0b 00 00 00       	mov    esi,0xb
    753e0260a9bd:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260a9c2:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260a9c6:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260a9ca:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260a9d1:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260a9d8:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260a9df:	e9 7d 04 00 00       	jmp    0x753e0260ae61
    753e0260a9e4:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e0260a9e8:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260a9ec:	eb 83                	jmp    0x753e0260a971
    753e0260a9ee:	eb 00                	jmp    0x753e0260a9f0
    753e0260a9f0:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260a9f7:	00 
    753e0260a9f8:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    753e0260a9ff:	89 08                	mov    DWORD PTR [rax],ecx
    753e0260aa01:	eb 00                	jmp    0x753e0260aa03
    753e0260aa03:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    753e0260aa07:	83 e0 03             	and    eax,0x3
    753e0260aa0a:	83 f8 00             	cmp    eax,0x0
    753e0260aa0d:	0f 84 8e 00 00 00    	je     0x753e0260aaa1
    753e0260aa13:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e0260aa1a:	00 
    753e0260aa1b:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260aa1f:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    753e0260aa26:	00 
    753e0260aa27:	c7 87 bc 00 00 00 0a 	mov    DWORD PTR [rdi+0xbc],0x1010a
    753e0260aa2e:	01 01 00 
    753e0260aa31:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260aa38:	00 00 00 
    753e0260aa3b:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    753e0260aa42:	00 00 00 
    753e0260aa45:	31 c0                	xor    eax,eax
    753e0260aa47:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260aa4e:	5c 00 00 
    753e0260aa51:	ba 0a 01 01 00       	mov    edx,0x1010a
    753e0260aa56:	45 31 c0             	xor    r8d,r8d
    753e0260aa59:	ff d0                	call   rax
    753e0260aa5b:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260aa62:	00 
    753e0260aa63:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260aa69:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260aa6f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260aa75:	be 0d 00 00 00       	mov    esi,0xd
    753e0260aa7a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260aa7f:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260aa83:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260aa87:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260aa8e:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260aa95:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260aa9c:	e9 c0 03 00 00       	jmp    0x753e0260ae61
    753e0260aaa1:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e0260aaa8:	00 
    753e0260aaa9:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260aaad:	c1 e9 0c             	shr    ecx,0xc
    753e0260aab0:	89 c9                	mov    ecx,ecx
    753e0260aab2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260aab6:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    753e0260aabb:	48 83 f8 00          	cmp    rax,0x0
    753e0260aabf:	74 1a                	je     0x753e0260aadb
    753e0260aac1:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    753e0260aac6:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260aaca:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260aad0:	89 c9                	mov    ecx,ecx
    753e0260aad2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260aad5:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e0260aad9:	eb 57                	jmp    0x753e0260ab32
    753e0260aadb:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260aae2:	00 
    753e0260aae3:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e0260aae7:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    753e0260aaee:	00 
    753e0260aaef:	c7 80 bc 00 00 00 0a 	mov    DWORD PTR [rax+0xbc],0x1010a
    753e0260aaf6:	01 01 00 
    753e0260aaf9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260ab00:	00 00 00 
    753e0260ab03:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    753e0260ab0a:	00 00 00 
    753e0260ab0d:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260ab14:	5c 00 00 
    753e0260ab17:	ff d0                	call   rax
    753e0260ab19:	89 c1                	mov    ecx,eax
    753e0260ab1b:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260ab22:	00 
    753e0260ab23:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    753e0260ab27:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260ab2e:	75 29                	jne    0x753e0260ab59
    753e0260ab30:	eb 6d                	jmp    0x753e0260ab9f
    753e0260ab32:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    753e0260ab36:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    753e0260ab3d:	00 
    753e0260ab3e:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    753e0260ab42:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    753e0260ab45:	83 c0 04             	add    eax,0x4
    753e0260ab48:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e0260ab4c:	83 e0 03             	and    eax,0x3
    753e0260ab4f:	83 f8 00             	cmp    eax,0x0
    753e0260ab52:	75 55                	jne    0x753e0260aba9
    753e0260ab54:	e9 de 00 00 00       	jmp    0x753e0260ac37
    753e0260ab59:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260ab60:	00 
    753e0260ab61:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260ab67:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260ab6d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260ab73:	be 0d 00 00 00       	mov    esi,0xd
    753e0260ab78:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260ab7d:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260ab81:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260ab85:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260ab8c:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260ab93:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260ab9a:	e9 c2 02 00 00       	jmp    0x753e0260ae61
    753e0260ab9f:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    753e0260aba3:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e0260aba7:	eb 89                	jmp    0x753e0260ab32
    753e0260aba9:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e0260abb0:	00 
    753e0260abb1:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e0260abb5:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
    753e0260abbc:	00 
    753e0260abbd:	c7 87 bc 00 00 00 0a 	mov    DWORD PTR [rdi+0xbc],0x1010a
    753e0260abc4:	01 01 00 
    753e0260abc7:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260abce:	00 00 00 
    753e0260abd1:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    753e0260abd8:	00 00 00 
    753e0260abdb:	31 c0                	xor    eax,eax
    753e0260abdd:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260abe4:	5c 00 00 
    753e0260abe7:	ba 0a 01 01 00       	mov    edx,0x1010a
    753e0260abec:	45 31 c0             	xor    r8d,r8d
    753e0260abef:	ff d0                	call   rax
    753e0260abf1:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260abf8:	00 
    753e0260abf9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260abff:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260ac05:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260ac0b:	be 0d 00 00 00       	mov    esi,0xd
    753e0260ac10:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260ac15:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260ac19:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260ac1d:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260ac24:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260ac2b:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260ac32:	e9 2a 02 00 00       	jmp    0x753e0260ae61
    753e0260ac37:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e0260ac3e:	00 
    753e0260ac3f:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e0260ac43:	c1 e9 0c             	shr    ecx,0xc
    753e0260ac46:	89 c9                	mov    ecx,ecx
    753e0260ac48:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260ac4c:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
    753e0260ac51:	48 83 f8 00          	cmp    rax,0x0
    753e0260ac55:	74 1a                	je     0x753e0260ac71
    753e0260ac57:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e0260ac5c:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e0260ac60:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260ac66:	89 c9                	mov    ecx,ecx
    753e0260ac68:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260ac6b:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e0260ac6f:	eb 57                	jmp    0x753e0260acc8
    753e0260ac71:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260ac78:	00 
    753e0260ac79:	8b 74 24 34          	mov    esi,DWORD PTR [rsp+0x34]
    753e0260ac7d:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
    753e0260ac84:	00 
    753e0260ac85:	c7 80 bc 00 00 00 0a 	mov    DWORD PTR [rax+0xbc],0x1010a
    753e0260ac8c:	01 01 00 
    753e0260ac8f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260ac96:	00 00 00 
    753e0260ac99:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    753e0260aca0:	00 00 00 
    753e0260aca3:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260acaa:	5c 00 00 
    753e0260acad:	ff d0                	call   rax
    753e0260acaf:	89 c1                	mov    ecx,eax
    753e0260acb1:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260acb8:	00 
    753e0260acb9:	89 4c 24 20          	mov    DWORD PTR [rsp+0x20],ecx
    753e0260acbd:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260acc4:	75 1d                	jne    0x753e0260ace3
    753e0260acc6:	eb 61                	jmp    0x753e0260ad29
    753e0260acc8:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260accf:	00 
    753e0260acd0:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e0260acd4:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    753e0260acd8:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    753e0260acdb:	83 c1 04             	add    ecx,0x4
    753e0260acde:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e0260ace1:	eb 50                	jmp    0x753e0260ad33
    753e0260ace3:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260acea:	00 
    753e0260aceb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260acf1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260acf7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260acfd:	be 0d 00 00 00       	mov    esi,0xd
    753e0260ad02:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260ad07:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260ad0b:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260ad0f:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260ad16:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260ad1d:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260ad24:	e9 38 01 00 00       	jmp    0x753e0260ae61
    753e0260ad29:	8b 44 24 20          	mov    eax,DWORD PTR [rsp+0x20]
    753e0260ad2d:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e0260ad31:	eb 95                	jmp    0x753e0260acc8
    753e0260ad33:	eb 00                	jmp    0x753e0260ad35
    753e0260ad35:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e0260ad39:	83 e0 01             	and    eax,0x1
    753e0260ad3c:	83 f8 00             	cmp    eax,0x0
    753e0260ad3f:	75 34                	jne    0x753e0260ad75
    753e0260ad41:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    753e0260ad45:	be 0e 00 00 00       	mov    esi,0xe
    753e0260ad4a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260ad4f:	b0 01                	mov    al,0x1
    753e0260ad51:	89 d7                	mov    edi,edx
    753e0260ad53:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260ad57:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260ad5b:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260ad62:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260ad69:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260ad70:	e9 ec 00 00 00       	jmp    0x753e0260ae61
    753e0260ad75:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
    753e0260ad7c:	00 
    753e0260ad7d:	48 8b 94 24 c8 00 00 	mov    rdx,QWORD PTR [rsp+0xc8]
    753e0260ad84:	00 
    753e0260ad85:	c7 87 bc 00 00 00 0c 	mov    DWORD PTR [rdi+0xbc],0x1010c
    753e0260ad8c:	01 01 00 
    753e0260ad8f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260ad96:	00 00 00 
    753e0260ad99:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260ada0:	00 00 00 
    753e0260ada3:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e0260adaa:	5c 00 00 
    753e0260adad:	be 2a 00 00 00       	mov    esi,0x2a
    753e0260adb2:	ff d0                	call   rax
    753e0260adb4:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260adbb:	00 
    753e0260adbc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260adc2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260adc8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260adce:	be 0e 00 00 00       	mov    esi,0xe
    753e0260add3:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260add8:	89 7c 24 78          	mov    DWORD PTR [rsp+0x78],edi
    753e0260addc:	89 74 24 7c          	mov    DWORD PTR [rsp+0x7c],esi
    753e0260ade0:	89 94 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],edx
    753e0260ade7:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e0260adee:	88 84 24 8b 00 00 00 	mov    BYTE PTR [rsp+0x8b],al
    753e0260adf5:	eb 6a                	jmp    0x753e0260ae61
    753e0260adf7:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260adfe:	00 
    753e0260adff:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e0260ae06:	e9 7c 01 00 00       	jmp    0x753e0260af87
    753e0260ae0b:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260ae12:	00 
    753e0260ae13:	8b 8c 24 90 00 00 00 	mov    ecx,DWORD PTR [rsp+0x90]
    753e0260ae1a:	c7 80 bc 00 00 00 ec 	mov    DWORD PTR [rax+0xbc],0x100ec
    753e0260ae21:	00 01 00 
    753e0260ae24:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    753e0260ae2a:	e9 5f f4 ff ff       	jmp    0x753e0260a28e
    753e0260ae2f:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260ae36:	00 
    753e0260ae37:	c7 80 bc 00 00 00 ec 	mov    DWORD PTR [rax+0xbc],0x100ec
    753e0260ae3e:	00 01 00 
    753e0260ae41:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260ae48:	00 00 00 
    753e0260ae4b:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    753e0260ae52:	00 00 00 
    753e0260ae55:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260ae5c:	e9 26 01 00 00       	jmp    0x753e0260af87
    753e0260ae61:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
    753e0260ae68:	00 
    753e0260ae69:	8b 54 24 78          	mov    edx,DWORD PTR [rsp+0x78]
    753e0260ae6d:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    753e0260ae71:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    753e0260ae78:	8b bc 24 84 00 00 00 	mov    edi,DWORD PTR [rsp+0x84]
    753e0260ae7f:	8a 9c 24 8b 00 00 00 	mov    bl,BYTE PTR [rsp+0x8b]
    753e0260ae86:	88 5c 24 0b          	mov    BYTE PTR [rsp+0xb],bl
    753e0260ae8a:	89 c3                	mov    ebx,eax
    753e0260ae8c:	89 5c 24 0c          	mov    DWORD PTR [rsp+0xc],ebx
    753e0260ae90:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e0260ae94:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e0260ae98:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e0260ae9c:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260aea2:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e0260aea6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260aeac:	73 0d                	jae    0x753e0260aebb
    753e0260aeae:	8b 44 24 18          	mov    eax,DWORD PTR [rsp+0x18]
    753e0260aeb2:	3d ec 00 01 00       	cmp    eax,0x100ec
    753e0260aeb7:	74 37                	je     0x753e0260aef0
    753e0260aeb9:	eb 5d                	jmp    0x753e0260af18
    753e0260aebb:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260aec2:	00 
    753e0260aec3:	8a 4c 24 0b          	mov    cl,BYTE PTR [rsp+0xb]
    753e0260aec7:	8b 54 24 0c          	mov    edx,DWORD PTR [rsp+0xc]
    753e0260aecb:	8b 74 24 10          	mov    esi,DWORD PTR [rsp+0x10]
    753e0260aecf:	8b 7c 24 14          	mov    edi,DWORD PTR [rsp+0x14]
    753e0260aed3:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e0260aed9:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e0260aedf:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e0260aee5:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e0260aeeb:	e9 97 00 00 00       	jmp    0x753e0260af87
    753e0260aef0:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e0260aef7:	00 
    753e0260aef8:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e0260aefc:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e0260af00:	89 90 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edx
    753e0260af06:	89 88 5c 01 00 00    	mov    DWORD PTR [rax+0x15c],ecx
    753e0260af0c:	c6 80 28 01 00 00 00 	mov    BYTE PTR [rax+0x128],0x0
    753e0260af13:	e9 76 f3 ff ff       	jmp    0x753e0260a28e
    753e0260af18:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e0260af1f:	00 
    753e0260af20:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e0260af24:	89 d1                	mov    ecx,edx
    753e0260af26:	c1 e9 01             	shr    ecx,0x1
    753e0260af29:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260af2f:	89 c9                	mov    ecx,ecx
    753e0260af31:	48 c1 e1 04          	shl    rcx,0x4
    753e0260af35:	48 89 c6             	mov    rsi,rax
    753e0260af38:	48 01 ce             	add    rsi,rcx
    753e0260af3b:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753e0260af3f:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e0260af42:	0f 85 73 ff ff ff    	jne    0x753e0260aebb
    753e0260af48:	4c 8b b4 24 c8 00 00 	mov    r14,QWORD PTR [rsp+0xc8]
    753e0260af4f:	00 
    753e0260af50:	4c 8b ac 24 d0 00 00 	mov    r13,QWORD PTR [rsp+0xd0]
    753e0260af57:	00 
    753e0260af58:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    753e0260af5c:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e0260af60:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e0260af64:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e0260af6b:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260af72:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260af79:	00 
    753e0260af7a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260af7e:	48 81 c4 e8 00 00 00 	add    rsp,0xe8
    753e0260af85:	ff e0                	jmp    rax
    753e0260af87:	48 81 c4 e8 00 00 00 	add    rsp,0xe8
    753e0260af8e:	c2 08 00             	ret    0x8
