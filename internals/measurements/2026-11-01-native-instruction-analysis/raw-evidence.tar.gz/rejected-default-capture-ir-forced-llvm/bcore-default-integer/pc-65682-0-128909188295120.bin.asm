
build-native-instruction-analysis/capture/bcore-default-integer/pc-65682-0-128909188295120.bin:     file format binary


Disassembly of section .data:

0000753e026069d0 <.data>:
    753e026069d0:	48 81 ec 98 00 00 00 	sub    rsp,0x98
    753e026069d7:	4c 89 74 24 70       	mov    QWORD PTR [rsp+0x70],r14
    753e026069dc:	4c 89 6c 24 78       	mov    QWORD PTR [rsp+0x78],r13
    753e026069e1:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e026069e8:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e026069ef:	00 
    753e026069f0:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e026069f7:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    753e026069fe:	00 
    753e026069ff:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02606a06:	48 89 84 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rax
    753e02606a0d:	00 
    753e02606a0e:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    753e02606a13:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02606a19:	83 fa 00             	cmp    edx,0x0
    753e02606a1c:	0f 94 c0             	sete   al
    753e02606a1f:	81 ea 92 00 01 00    	sub    edx,0x10092
    753e02606a25:	83 fa 06             	cmp    edx,0x6
    753e02606a28:	0f 97 c2             	seta   dl
    753e02606a2b:	08 d0                	or     al,dl
    753e02606a2d:	24 01                	and    al,0x1
    753e02606a2f:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02606a35:	83 fa 00             	cmp    edx,0x0
    753e02606a38:	0f 94 c1             	sete   cl
    753e02606a3b:	81 ea 92 00 01 00    	sub    edx,0x10092
    753e02606a41:	83 fa 06             	cmp    edx,0x6
    753e02606a44:	0f 97 c2             	seta   dl
    753e02606a47:	08 d1                	or     cl,dl
    753e02606a49:	20 c8                	and    al,cl
    753e02606a4b:	a8 01                	test   al,0x1
    753e02606a4d:	75 05                	jne    0x753e02606a54
    753e02606a4f:	e9 4f 03 00 00       	jmp    0x753e02606da3
    753e02606a54:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606a59:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02606a60:	48 89 c8             	mov    rax,rcx
    753e02606a63:	48 05 00 00 10 00    	add    rax,0x100000
    753e02606a69:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753e02606a6e:	8b 81 10 00 10 00    	mov    eax,DWORD PTR [rcx+0x100010]
    753e02606a74:	83 c0 01             	add    eax,0x1
    753e02606a77:	89 81 10 00 10 00    	mov    DWORD PTR [rcx+0x100010],eax
    753e02606a7d:	3d 30 75 00 00       	cmp    eax,0x7530
    753e02606a82:	75 40                	jne    0x753e02606ac4
    753e02606a84:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    753e02606a89:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02606a8f:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e02606a93:	89 c2                	mov    edx,eax
    753e02606a95:	83 c2 01             	add    edx,0x1
    753e02606a98:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02606a9e:	3d 00 01 00 00       	cmp    eax,0x100
    753e02606aa3:	73 1d                	jae    0x753e02606ac2
    753e02606aa5:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e02606aaa:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02606aae:	89 c9                	mov    ecx,ecx
    753e02606ab0:	48 c1 e1 02          	shl    rcx,0x2
    753e02606ab4:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02606abb:	c7 04 08 04 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x4
    753e02606ac2:	eb 00                	jmp    0x753e02606ac4
    753e02606ac4:	eb 00                	jmp    0x753e02606ac6
    753e02606ac6:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606acb:	8b 38                	mov    edi,DWORD PTR [rax]
    753e02606acd:	89 fa                	mov    edx,edi
    753e02606acf:	83 ea 00             	sub    edx,0x0
    753e02606ad2:	83 fa 00             	cmp    edx,0x0
    753e02606ad5:	0f 94 c1             	sete   cl
    753e02606ad8:	80 e1 01             	and    cl,0x1
    753e02606adb:	0f b6 f1             	movzx  esi,cl
    753e02606ade:	89 74 24 58          	mov    DWORD PTR [rsp+0x58],esi
    753e02606ae2:	c1 ea 1f             	shr    edx,0x1f
    753e02606ae5:	89 f9                	mov    ecx,edi
    753e02606ae7:	c1 e9 1f             	shr    ecx,0x1f
    753e02606aea:	89 d3                	mov    ebx,edx
    753e02606aec:	31 cb                	xor    ebx,ecx
    753e02606aee:	83 f1 00             	xor    ecx,0x0
    753e02606af1:	21 d9                	and    ecx,ebx
    753e02606af3:	31 ca                	xor    edx,ecx
    753e02606af5:	31 c9                	xor    ecx,ecx
    753e02606af7:	39 f9                	cmp    ecx,edi
    753e02606af9:	0f 96 c1             	setbe  cl
    753e02606afc:	80 e1 01             	and    cl,0x1
    753e02606aff:	0f b6 c9             	movzx  ecx,cl
    753e02606b02:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e02606b08:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02606b0e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e02606b14:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02606b1a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02606b20:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    753e02606b26:	89 4c 24 5c          	mov    DWORD PTR [rsp+0x5c],ecx
    753e02606b2a:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    753e02606b30:	89 44 24 60          	mov    DWORD PTR [rsp+0x60],eax
    753e02606b34:	eb 00                	jmp    0x753e02606b36
    753e02606b36:	8b 44 24 58          	mov    eax,DWORD PTR [rsp+0x58]
    753e02606b3a:	83 f8 00             	cmp    eax,0x0
    753e02606b3d:	75 2d                	jne    0x753e02606b6c
    753e02606b3f:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    753e02606b44:	c7 81 bc 00 00 00 c0 	mov    DWORD PTR [rcx+0xbc],0x100c0
    753e02606b4b:	00 01 00 
    753e02606b4e:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02606b54:	83 c0 02             	add    eax,0x2
    753e02606b57:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e02606b5b:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02606b61:	0f 82 4d 02 00 00    	jb     0x753e02606db4
    753e02606b67:	e9 6b 02 00 00       	jmp    0x753e02606dd7
    753e02606b6c:	eb 00                	jmp    0x753e02606b6e
    753e02606b6e:	eb 00                	jmp    0x753e02606b70
    753e02606b70:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    753e02606b75:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    753e02606b78:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02606b7c:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    753e02606b7f:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e02606b83:	83 e0 03             	and    eax,0x3
    753e02606b86:	83 f8 00             	cmp    eax,0x0
    753e02606b89:	74 69                	je     0x753e02606bf4
    753e02606b8b:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    753e02606b90:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02606b94:	48 8b 74 24 70       	mov    rsi,QWORD PTR [rsp+0x70]
    753e02606b99:	c7 87 bc 00 00 00 96 	mov    DWORD PTR [rdi+0xbc],0x10096
    753e02606ba0:	00 01 00 
    753e02606ba3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02606baa:	00 00 00 
    753e02606bad:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e02606bb4:	00 00 00 
    753e02606bb7:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02606bbe:	5c 00 00 
    753e02606bc1:	ba 96 00 01 00       	mov    edx,0x10096
    753e02606bc6:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02606bcc:	ff d0                	call   rax
    753e02606bce:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606bd3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02606bd9:	b9 03 00 00 00       	mov    ecx,0x3
    753e02606bde:	b8 02 00 00 00       	mov    eax,0x2
    753e02606be3:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    753e02606be7:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    753e02606beb:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    753e02606bef:	e9 c8 02 00 00       	jmp    0x753e02606ebc
    753e02606bf4:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e02606bfb:	00 
    753e02606bfc:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02606c00:	c1 e9 0c             	shr    ecx,0xc
    753e02606c03:	89 c9                	mov    ecx,ecx
    753e02606c05:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02606c09:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e02606c0e:	48 83 f8 00          	cmp    rax,0x0
    753e02606c12:	74 1a                	je     0x753e02606c2e
    753e02606c14:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e02606c19:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    753e02606c1d:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02606c21:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02606c27:	89 c9                	mov    ecx,ecx
    753e02606c29:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02606c2c:	eb 4c                	jmp    0x753e02606c7a
    753e02606c2e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606c33:	8b 54 24 50          	mov    edx,DWORD PTR [rsp+0x50]
    753e02606c37:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e02606c3b:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    753e02606c40:	c7 80 bc 00 00 00 96 	mov    DWORD PTR [rax+0xbc],0x10096
    753e02606c47:	00 01 00 
    753e02606c4a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606c51:	00 00 00 
    753e02606c54:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e02606c5b:	00 00 00 
    753e02606c5e:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02606c65:	5c 00 00 
    753e02606c68:	ff d0                	call   rax
    753e02606c6a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606c6f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02606c76:	75 11                	jne    0x753e02606c89
    753e02606c78:	eb 35                	jmp    0x753e02606caf
    753e02606c7a:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    753e02606c81:	00 
    753e02606c82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02606c85:	75 2a                	jne    0x753e02606cb1
    753e02606c87:	eb 67                	jmp    0x753e02606cf0
    753e02606c89:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606c8e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02606c94:	b9 03 00 00 00       	mov    ecx,0x3
    753e02606c99:	b8 02 00 00 00       	mov    eax,0x2
    753e02606c9e:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    753e02606ca2:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    753e02606ca6:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    753e02606caa:	e9 0d 02 00 00       	jmp    0x753e02606ebc
    753e02606caf:	eb c9                	jmp    0x753e02606c7a
    753e02606cb1:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
    753e02606cb6:	c7 87 bc 00 00 00 98 	mov    DWORD PTR [rdi+0xbc],0x10098
    753e02606cbd:	00 01 00 
    753e02606cc0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02606cc7:	00 00 00 
    753e02606cca:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e02606cd1:	00 00 00 
    753e02606cd4:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02606cdb:	5c 00 00 
    753e02606cde:	ff d0                	call   rax
    753e02606ce0:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606ce5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02606cec:	75 04                	jne    0x753e02606cf2
    753e02606cee:	eb 28                	jmp    0x753e02606d18
    753e02606cf0:	eb 28                	jmp    0x753e02606d1a
    753e02606cf2:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606cf7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02606cfd:	b9 03 00 00 00       	mov    ecx,0x3
    753e02606d02:	b8 02 00 00 00       	mov    eax,0x2
    753e02606d07:	89 54 24 40          	mov    DWORD PTR [rsp+0x40],edx
    753e02606d0b:	89 4c 24 44          	mov    DWORD PTR [rsp+0x44],ecx
    753e02606d0f:	89 44 24 48          	mov    DWORD PTR [rsp+0x48],eax
    753e02606d13:	e9 a4 01 00 00       	jmp    0x753e02606ebc
    753e02606d18:	eb d6                	jmp    0x753e02606cf0
    753e02606d1a:	eb 00                	jmp    0x753e02606d1c
    753e02606d1c:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    753e02606d21:	8b 74 24 60          	mov    esi,DWORD PTR [rsp+0x60]
    753e02606d25:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    753e02606d29:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    753e02606d2f:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    753e02606d35:	83 ff 01             	cmp    edi,0x1
    753e02606d38:	0f 97 c3             	seta   bl
    753e02606d3b:	3d 98 00 01 00       	cmp    eax,0x10098
    753e02606d40:	0f 94 c0             	sete   al
    753e02606d43:	20 c3                	and    bl,al
    753e02606d45:	b8 9c 00 01 00       	mov    eax,0x1009c
    753e02606d4a:	f6 c3 01             	test   bl,0x1
    753e02606d4d:	0f 45 c2             	cmovne eax,edx
    753e02606d50:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    753e02606d56:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    753e02606d5c:	83 ff 01             	cmp    edi,0x1
    753e02606d5f:	0f 97 c3             	seta   bl
    753e02606d62:	81 fe 98 00 01 00    	cmp    esi,0x10098
    753e02606d68:	40 0f 94 c6          	sete   sil
    753e02606d6c:	40 20 f3             	and    bl,sil
    753e02606d6f:	f6 c3 01             	test   bl,0x1
    753e02606d72:	0f 45 c2             	cmovne eax,edx
    753e02606d75:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    753e02606d7b:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10428
    753e02606d82:	04 01 00 
    753e02606d85:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02606d8b:	83 c0 04             	add    eax,0x4
    753e02606d8e:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e02606d92:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02606d98:	0f 82 9a 00 00 00    	jb     0x753e02606e38
    753e02606d9e:	e9 b8 00 00 00       	jmp    0x753e02606e5b
    753e02606da3:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606da8:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e02606daf:	e9 b0 01 00 00       	jmp    0x753e02606f64
    753e02606db4:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02606dbb:	00 
    753e02606dbc:	48 89 c1             	mov    rcx,rax
    753e02606dbf:	48 81 c1 00 06 08 00 	add    rcx,0x80600
    753e02606dc6:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e02606dcb:	81 b8 00 06 08 00 c0 	cmp    DWORD PTR [rax+0x80600],0x100c0
    753e02606dd2:	00 01 00 
    753e02606dd5:	74 2f                	je     0x753e02606e06
    753e02606dd7:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606ddc:	c7 80 bc 00 00 00 c0 	mov    DWORD PTR [rax+0xbc],0x100c0
    753e02606de3:	00 01 00 
    753e02606de6:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606ded:	00 00 00 
    753e02606df0:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e02606df7:	00 00 00 
    753e02606dfa:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e02606e01:	e9 5e 01 00 00       	jmp    0x753e02606f64
    753e02606e06:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    753e02606e0b:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    753e02606e10:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e02606e15:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    753e02606e19:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100c0
    753e02606e20:	c0 00 01 00 
    753e02606e24:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02606e2b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606e2f:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753e02606e36:	ff e0                	jmp    rax
    753e02606e38:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02606e3f:	00 
    753e02606e40:	48 89 c1             	mov    rcx,rax
    753e02606e43:	48 81 c1 40 21 08 00 	add    rcx,0x82140
    753e02606e4a:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    753e02606e4f:	81 b8 40 21 08 00 28 	cmp    DWORD PTR [rax+0x82140],0x10428
    753e02606e56:	04 01 00 
    753e02606e59:	74 2f                	je     0x753e02606e8a
    753e02606e5b:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606e60:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10428
    753e02606e67:	04 01 00 
    753e02606e6a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02606e71:	00 00 00 
    753e02606e74:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e02606e7b:	00 00 00 
    753e02606e7e:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e02606e85:	e9 da 00 00 00       	jmp    0x753e02606f64
    753e02606e8a:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    753e02606e8f:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    753e02606e94:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753e02606e99:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e02606e9d:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10428
    753e02606ea4:	28 04 01 00 
    753e02606ea8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02606eaf:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606eb3:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753e02606eba:	ff e0                	jmp    rax
    753e02606ebc:	48 8b 4c 24 78       	mov    rcx,QWORD PTR [rsp+0x78]
    753e02606ec1:	8b 54 24 40          	mov    edx,DWORD PTR [rsp+0x40]
    753e02606ec5:	8b 44 24 44          	mov    eax,DWORD PTR [rsp+0x44]
    753e02606ec9:	8b 74 24 48          	mov    esi,DWORD PTR [rsp+0x48]
    753e02606ecd:	89 c7                	mov    edi,eax
    753e02606ecf:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e02606ed3:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e02606ed7:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e02606edb:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02606ee1:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e02606ee5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02606eeb:	73 2d                	jae    0x753e02606f1a
    753e02606eed:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02606ef4:	00 
    753e02606ef5:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e02606ef9:	89 d1                	mov    ecx,edx
    753e02606efb:	c1 e9 01             	shr    ecx,0x1
    753e02606efe:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02606f04:	89 c9                	mov    ecx,ecx
    753e02606f06:	48 c1 e1 04          	shl    rcx,0x4
    753e02606f0a:	48 89 c6             	mov    rsi,rax
    753e02606f0d:	48 01 ce             	add    rsi,rcx
    753e02606f10:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e02606f15:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e02606f18:	74 1b                	je     0x753e02606f35
    753e02606f1a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e02606f1f:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    753e02606f23:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e02606f27:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    753e02606f2d:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    753e02606f33:	eb 2f                	jmp    0x753e02606f64
    753e02606f35:	4c 8b 74 24 70       	mov    r14,QWORD PTR [rsp+0x70]
    753e02606f3a:	4c 8b 6c 24 78       	mov    r13,QWORD PTR [rsp+0x78]
    753e02606f3f:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e02606f44:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e02606f48:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02606f4f:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e02606f56:	00 
    753e02606f57:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606f5b:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753e02606f62:	ff e0                	jmp    rax
    753e02606f64:	48 81 c4 98 00 00 00 	add    rsp,0x98
    753e02606f6b:	c2 08 00             	ret    0x8
