
build-native-instruction-analysis/capture/bcore-default-integer/pc-65772-0-128909590921216.bin:     file format binary


Disassembly of section .data:

0000753e1a600000 <.data>:
    753e1a600000:	41 c6 80 65 01 00 00 	mov    BYTE PTR [r8+0x165],0x1
    753e1a600007:	01 
    753e1a600008:	41 c6 80 28 01 00 00 	mov    BYTE PTR [r8+0x128],0x0
    753e1a60000f:	00 
    753e1a600010:	48 83 c4 58          	add    rsp,0x58
    753e1a600014:	c2 08 00             	ret    0x8
