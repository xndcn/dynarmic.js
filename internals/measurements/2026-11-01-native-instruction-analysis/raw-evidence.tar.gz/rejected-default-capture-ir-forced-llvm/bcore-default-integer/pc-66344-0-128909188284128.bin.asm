
build-native-instruction-analysis/capture/bcore-default-integer/pc-66344-0-128909188284128.bin:     file format binary


Disassembly of section .data:

0000753e02603ee0 <.data>:
    753e02603ee0:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    753e02603ee7:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    753e02603eee:	00 
    753e02603eef:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    753e02603ef6:	00 
    753e02603ef7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02603efe:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    753e02603f05:	00 
    753e02603f06:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e02603f0d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    753e02603f14:	00 
    753e02603f15:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02603f1c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    753e02603f23:	00 
    753e02603f24:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02603f2b:	00 
    753e02603f2c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02603f32:	83 fa 00             	cmp    edx,0x0
    753e02603f35:	0f 94 c0             	sete   al
    753e02603f38:	81 ea 28 03 01 00    	sub    edx,0x10328
    753e02603f3e:	83 fa 46             	cmp    edx,0x46
    753e02603f41:	0f 97 c2             	seta   dl
    753e02603f44:	08 d0                	or     al,dl
    753e02603f46:	24 01                	and    al,0x1
    753e02603f48:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02603f4e:	83 fa 00             	cmp    edx,0x0
    753e02603f51:	0f 94 c1             	sete   cl
    753e02603f54:	81 ea 28 03 01 00    	sub    edx,0x10328
    753e02603f5a:	83 fa 46             	cmp    edx,0x46
    753e02603f5d:	0f 97 c2             	seta   dl
    753e02603f60:	08 d1                	or     cl,dl
    753e02603f62:	20 c8                	and    al,cl
    753e02603f64:	a8 01                	test   al,0x1
    753e02603f66:	75 05                	jne    0x753e02603f6d
    753e02603f68:	e9 79 26 00 00       	jmp    0x753e026065e6
    753e02603f6d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02603f74:	00 
    753e02603f75:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02603f7c:	48 89 c8             	mov    rax,rcx
    753e02603f7f:	48 05 00 00 10 00    	add    rax,0x100000
    753e02603f85:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    753e02603f8c:	00 
    753e02603f8d:	8b 81 0c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10000c]
    753e02603f93:	83 c0 01             	add    eax,0x1
    753e02603f96:	89 81 0c 00 10 00    	mov    DWORD PTR [rcx+0x10000c],eax
    753e02603f9c:	3d c1 c5 00 00       	cmp    eax,0xc5c1
    753e02603fa1:	75 4c                	jne    0x753e02603fef
    753e02603fa3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    753e02603faa:	00 
    753e02603fab:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02603fb1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    753e02603fb8:	89 c2                	mov    edx,eax
    753e02603fba:	83 c2 01             	add    edx,0x1
    753e02603fbd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02603fc3:	3d 00 01 00 00       	cmp    eax,0x100
    753e02603fc8:	73 23                	jae    0x753e02603fed
    753e02603fca:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    753e02603fd1:	00 
    753e02603fd2:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    753e02603fd9:	89 c9                	mov    ecx,ecx
    753e02603fdb:	48 c1 e1 02          	shl    rcx,0x2
    753e02603fdf:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02603fe6:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    753e02603fed:	eb 00                	jmp    0x753e02603fef
    753e02603fef:	eb 00                	jmp    0x753e02603ff1
    753e02603ff1:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02603ff8:	00 
    753e02603ff9:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    753e02603ffc:	83 e8 04             	sub    eax,0x4
    753e02603fff:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    753e02604006:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    753e02604009:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    753e02604010:	83 e0 03             	and    eax,0x3
    753e02604013:	83 f8 00             	cmp    eax,0x0
    753e02604016:	0f 84 8e 00 00 00    	je     0x753e026040aa
    753e0260401c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604023:	00 
    753e02604024:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e0260402b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02604032:	00 
    753e02604033:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260403a:	00 00 00 
    753e0260403d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02604044:	00 00 00 
    753e02604047:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260404e:	5c 00 00 
    753e02604051:	ba 28 03 01 00       	mov    edx,0x10328
    753e02604056:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260405c:	ff d0                	call   rax
    753e0260405e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604065:	00 
    753e02604066:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260406c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604072:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604078:	be 01 00 00 00       	mov    esi,0x1
    753e0260407d:	b9 02 00 00 00       	mov    ecx,0x2
    753e02604082:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604089:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604090:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604097:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260409e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026040a5:	e9 20 28 00 00       	jmp    0x753e026068ca
    753e026040aa:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026040b1:	00 
    753e026040b2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e026040b9:	c1 e9 0c             	shr    ecx,0xc
    753e026040bc:	89 c9                	mov    ecx,ecx
    753e026040be:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026040c2:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    753e026040c9:	00 
    753e026040ca:	48 83 f8 00          	cmp    rax,0x0
    753e026040ce:	74 23                	je     0x753e026040f3
    753e026040d0:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    753e026040d7:	00 
    753e026040d8:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    753e026040df:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e026040e6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026040ec:	89 c9                	mov    ecx,ecx
    753e026040ee:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026040f1:	eb 51                	jmp    0x753e02604144
    753e026040f3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026040fa:	00 
    753e026040fb:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    753e02604102:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    753e02604109:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02604110:	00 
    753e02604111:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02604118:	00 00 00 
    753e0260411b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02604122:	00 00 00 
    753e02604125:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260412c:	5c 00 00 
    753e0260412f:	ff d0                	call   rax
    753e02604131:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604138:	00 
    753e02604139:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02604140:	75 32                	jne    0x753e02604174
    753e02604142:	eb 7c                	jmp    0x753e026041c0
    753e02604144:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260414b:	00 
    753e0260414c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    753e02604153:	83 e8 04             	sub    eax,0x4
    753e02604156:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    753e0260415d:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    753e02604160:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    753e02604167:	83 e0 03             	and    eax,0x3
    753e0260416a:	83 f8 00             	cmp    eax,0x0
    753e0260416d:	75 53                	jne    0x753e026041c2
    753e0260416f:	e9 dc 00 00 00       	jmp    0x753e02604250
    753e02604174:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260417b:	00 
    753e0260417c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604182:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604188:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260418e:	be 01 00 00 00       	mov    esi,0x1
    753e02604193:	b9 02 00 00 00       	mov    ecx,0x2
    753e02604198:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260419f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026041a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026041ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026041b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026041bb:	e9 0a 27 00 00       	jmp    0x753e026068ca
    753e026041c0:	eb 82                	jmp    0x753e02604144
    753e026041c2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026041c9:	00 
    753e026041ca:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e026041d1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026041d8:	00 
    753e026041d9:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026041e0:	00 00 00 
    753e026041e3:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e026041ea:	00 00 00 
    753e026041ed:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026041f4:	5c 00 00 
    753e026041f7:	ba 28 03 01 00       	mov    edx,0x10328
    753e026041fc:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02604202:	ff d0                	call   rax
    753e02604204:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260420b:	00 
    753e0260420c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604212:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604218:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260421e:	be 01 00 00 00       	mov    esi,0x1
    753e02604223:	b9 02 00 00 00       	mov    ecx,0x2
    753e02604228:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260422f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604236:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260423d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604244:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260424b:	e9 7a 26 00 00       	jmp    0x753e026068ca
    753e02604250:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02604257:	00 
    753e02604258:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e0260425f:	c1 e9 0c             	shr    ecx,0xc
    753e02604262:	89 c9                	mov    ecx,ecx
    753e02604264:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02604268:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    753e0260426f:	00 
    753e02604270:	48 83 f8 00          	cmp    rax,0x0
    753e02604274:	74 23                	je     0x753e02604299
    753e02604276:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    753e0260427d:	00 
    753e0260427e:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    753e02604285:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e0260428c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02604292:	89 c9                	mov    ecx,ecx
    753e02604294:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02604297:	eb 51                	jmp    0x753e026042ea
    753e02604299:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026042a0:	00 
    753e026042a1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    753e026042a8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    753e026042af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026042b6:	00 
    753e026042b7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026042be:	00 00 00 
    753e026042c1:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e026042c8:	00 00 00 
    753e026042cb:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026042d2:	5c 00 00 
    753e026042d5:	ff d0                	call   rax
    753e026042d7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026042de:	00 
    753e026042df:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026042e6:	75 32                	jne    0x753e0260431a
    753e026042e8:	eb 7c                	jmp    0x753e02604366
    753e026042ea:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026042f1:	00 
    753e026042f2:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    753e026042f9:	83 e8 04             	sub    eax,0x4
    753e026042fc:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    753e02604303:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    753e02604306:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    753e0260430d:	83 e0 03             	and    eax,0x3
    753e02604310:	83 f8 00             	cmp    eax,0x0
    753e02604313:	75 53                	jne    0x753e02604368
    753e02604315:	e9 dc 00 00 00       	jmp    0x753e026043f6
    753e0260431a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604321:	00 
    753e02604322:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604328:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260432e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604334:	be 01 00 00 00       	mov    esi,0x1
    753e02604339:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260433e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604345:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260434c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604353:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260435a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604361:	e9 64 25 00 00       	jmp    0x753e026068ca
    753e02604366:	eb 82                	jmp    0x753e026042ea
    753e02604368:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260436f:	00 
    753e02604370:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e02604377:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e0260437e:	00 
    753e0260437f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02604386:	00 00 00 
    753e02604389:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02604390:	00 00 00 
    753e02604393:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260439a:	5c 00 00 
    753e0260439d:	ba 28 03 01 00       	mov    edx,0x10328
    753e026043a2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026043a8:	ff d0                	call   rax
    753e026043aa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026043b1:	00 
    753e026043b2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026043b8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026043be:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026043c4:	be 01 00 00 00       	mov    esi,0x1
    753e026043c9:	b9 02 00 00 00       	mov    ecx,0x2
    753e026043ce:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026043d5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026043dc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026043e3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026043ea:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026043f1:	e9 d4 24 00 00       	jmp    0x753e026068ca
    753e026043f6:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026043fd:	00 
    753e026043fe:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e02604405:	c1 e9 0c             	shr    ecx,0xc
    753e02604408:	89 c9                	mov    ecx,ecx
    753e0260440a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260440e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    753e02604415:	00 
    753e02604416:	48 83 f8 00          	cmp    rax,0x0
    753e0260441a:	74 23                	je     0x753e0260443f
    753e0260441c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    753e02604423:	00 
    753e02604424:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    753e0260442b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e02604432:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02604438:	89 c9                	mov    ecx,ecx
    753e0260443a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260443d:	eb 51                	jmp    0x753e02604490
    753e0260443f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604446:	00 
    753e02604447:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    753e0260444e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    753e02604455:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e0260445c:	00 
    753e0260445d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02604464:	00 00 00 
    753e02604467:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e0260446e:	00 00 00 
    753e02604471:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02604478:	5c 00 00 
    753e0260447b:	ff d0                	call   rax
    753e0260447d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604484:	00 
    753e02604485:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260448c:	75 32                	jne    0x753e026044c0
    753e0260448e:	eb 7c                	jmp    0x753e0260450c
    753e02604490:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02604497:	00 
    753e02604498:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    753e0260449f:	83 e8 04             	sub    eax,0x4
    753e026044a2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    753e026044a9:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    753e026044ac:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    753e026044b3:	83 e0 03             	and    eax,0x3
    753e026044b6:	83 f8 00             	cmp    eax,0x0
    753e026044b9:	75 53                	jne    0x753e0260450e
    753e026044bb:	e9 dc 00 00 00       	jmp    0x753e0260459c
    753e026044c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026044c7:	00 
    753e026044c8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026044ce:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026044d4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026044da:	be 01 00 00 00       	mov    esi,0x1
    753e026044df:	b9 02 00 00 00       	mov    ecx,0x2
    753e026044e4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026044eb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026044f2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026044f9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604500:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604507:	e9 be 23 00 00       	jmp    0x753e026068ca
    753e0260450c:	eb 82                	jmp    0x753e02604490
    753e0260450e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604515:	00 
    753e02604516:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e0260451d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02604524:	00 
    753e02604525:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260452c:	00 00 00 
    753e0260452f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02604536:	00 00 00 
    753e02604539:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02604540:	5c 00 00 
    753e02604543:	ba 28 03 01 00       	mov    edx,0x10328
    753e02604548:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260454e:	ff d0                	call   rax
    753e02604550:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604557:	00 
    753e02604558:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260455e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604564:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260456a:	be 01 00 00 00       	mov    esi,0x1
    753e0260456f:	b9 02 00 00 00       	mov    ecx,0x2
    753e02604574:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260457b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604582:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604589:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604590:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604597:	e9 2e 23 00 00       	jmp    0x753e026068ca
    753e0260459c:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026045a3:	00 
    753e026045a4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e026045ab:	c1 e9 0c             	shr    ecx,0xc
    753e026045ae:	89 c9                	mov    ecx,ecx
    753e026045b0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026045b4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    753e026045bb:	00 
    753e026045bc:	48 83 f8 00          	cmp    rax,0x0
    753e026045c0:	74 23                	je     0x753e026045e5
    753e026045c2:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e026045c9:	00 
    753e026045ca:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    753e026045d1:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e026045d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026045de:	89 c9                	mov    ecx,ecx
    753e026045e0:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026045e3:	eb 51                	jmp    0x753e02604636
    753e026045e5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026045ec:	00 
    753e026045ed:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    753e026045f4:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    753e026045fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02604602:	00 
    753e02604603:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260460a:	00 00 00 
    753e0260460d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02604614:	00 00 00 
    753e02604617:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260461e:	5c 00 00 
    753e02604621:	ff d0                	call   rax
    753e02604623:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260462a:	00 
    753e0260462b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02604632:	75 32                	jne    0x753e02604666
    753e02604634:	eb 7c                	jmp    0x753e026046b2
    753e02604636:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260463d:	00 
    753e0260463e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    753e02604645:	83 e8 04             	sub    eax,0x4
    753e02604648:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    753e0260464f:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    753e02604652:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    753e02604659:	83 e0 03             	and    eax,0x3
    753e0260465c:	83 f8 00             	cmp    eax,0x0
    753e0260465f:	75 53                	jne    0x753e026046b4
    753e02604661:	e9 dc 00 00 00       	jmp    0x753e02604742
    753e02604666:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260466d:	00 
    753e0260466e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604674:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260467a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604680:	be 01 00 00 00       	mov    esi,0x1
    753e02604685:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260468a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604691:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604698:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260469f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026046a6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026046ad:	e9 18 22 00 00       	jmp    0x753e026068ca
    753e026046b2:	eb 82                	jmp    0x753e02604636
    753e026046b4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026046bb:	00 
    753e026046bc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e026046c3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026046ca:	00 
    753e026046cb:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026046d2:	00 00 00 
    753e026046d5:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e026046dc:	00 00 00 
    753e026046df:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026046e6:	5c 00 00 
    753e026046e9:	ba 28 03 01 00       	mov    edx,0x10328
    753e026046ee:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026046f4:	ff d0                	call   rax
    753e026046f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026046fd:	00 
    753e026046fe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604704:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260470a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604710:	be 01 00 00 00       	mov    esi,0x1
    753e02604715:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260471a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604721:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604728:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260472f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604736:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260473d:	e9 88 21 00 00       	jmp    0x753e026068ca
    753e02604742:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02604749:	00 
    753e0260474a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e02604751:	c1 e9 0c             	shr    ecx,0xc
    753e02604754:	89 c9                	mov    ecx,ecx
    753e02604756:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260475a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    753e02604761:	00 
    753e02604762:	48 83 f8 00          	cmp    rax,0x0
    753e02604766:	74 23                	je     0x753e0260478b
    753e02604768:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    753e0260476f:	00 
    753e02604770:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    753e02604777:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e0260477e:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02604784:	89 c9                	mov    ecx,ecx
    753e02604786:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02604789:	eb 51                	jmp    0x753e026047dc
    753e0260478b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604792:	00 
    753e02604793:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    753e0260479a:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    753e026047a1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026047a8:	00 
    753e026047a9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026047b0:	00 00 00 
    753e026047b3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e026047ba:	00 00 00 
    753e026047bd:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026047c4:	5c 00 00 
    753e026047c7:	ff d0                	call   rax
    753e026047c9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026047d0:	00 
    753e026047d1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026047d8:	75 26                	jne    0x753e02604800
    753e026047da:	eb 70                	jmp    0x753e0260484c
    753e026047dc:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e026047e3:	00 
    753e026047e4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026047eb:	00 
    753e026047ec:	8b 94 24 88 01 00 00 	mov    edx,DWORD PTR [rsp+0x188]
    753e026047f3:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e026047f6:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e026047f9:	75 53                	jne    0x753e0260484e
    753e026047fb:	e9 93 00 00 00       	jmp    0x753e02604893
    753e02604800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604807:	00 
    753e02604808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260480e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260481a:	be 01 00 00 00       	mov    esi,0x1
    753e0260481f:	b9 02 00 00 00       	mov    ecx,0x2
    753e02604824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260482b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604847:	e9 7e 20 00 00       	jmp    0x753e026068ca
    753e0260484c:	eb 8e                	jmp    0x753e026047dc
    753e0260484e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604855:	00 
    753e02604856:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    753e0260485d:	03 01 00 
    753e02604860:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02604867:	00 00 00 
    753e0260486a:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02604871:	00 00 00 
    753e02604874:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260487b:	5c 00 00 
    753e0260487e:	ff d0                	call   rax
    753e02604880:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604887:	00 
    753e02604888:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260488f:	75 04                	jne    0x753e02604895
    753e02604891:	eb 4e                	jmp    0x753e026048e1
    753e02604893:	eb 4e                	jmp    0x753e026048e3
    753e02604895:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260489c:	00 
    753e0260489d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026048a3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026048a9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026048af:	be 01 00 00 00       	mov    esi,0x1
    753e026048b4:	b9 02 00 00 00       	mov    ecx,0x2
    753e026048b9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026048c0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026048c7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026048ce:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026048d5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026048dc:	e9 e9 1f 00 00       	jmp    0x753e026068ca
    753e026048e1:	eb b0                	jmp    0x753e02604893
    753e026048e3:	eb 00                	jmp    0x753e026048e5
    753e026048e5:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    753e026048ec:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026048f3:	00 
    753e026048f4:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    753e026048fa:	89 94 24 74 01 00 00 	mov    DWORD PTR [rsp+0x174],edx
    753e02604901:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    753e02604904:	89 8c 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],ecx
    753e0260490b:	83 e8 04             	sub    eax,0x4
    753e0260490e:	89 84 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],eax
    753e02604915:	83 e0 03             	and    eax,0x3
    753e02604918:	83 f8 00             	cmp    eax,0x0
    753e0260491b:	0f 84 98 00 00 00    	je     0x753e026049b9
    753e02604921:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604928:	00 
    753e02604929:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    753e02604930:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02604937:	00 
    753e02604938:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    753e0260493f:	03 01 00 
    753e02604942:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02604949:	00 00 00 
    753e0260494c:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e02604953:	00 00 00 
    753e02604956:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260495d:	5c 00 00 
    753e02604960:	ba 2a 03 01 00       	mov    edx,0x1032a
    753e02604965:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260496b:	ff d0                	call   rax
    753e0260496d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604974:	00 
    753e02604975:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260497b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604981:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604987:	be 02 00 00 00       	mov    esi,0x2
    753e0260498c:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604991:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604998:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260499f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026049a6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026049ad:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026049b4:	e9 11 1f 00 00       	jmp    0x753e026068ca
    753e026049b9:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026049c0:	00 
    753e026049c1:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    753e026049c8:	c1 e9 0c             	shr    ecx,0xc
    753e026049cb:	89 c9                	mov    ecx,ecx
    753e026049cd:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026049d1:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    753e026049d8:	00 
    753e026049d9:	48 83 f8 00          	cmp    rax,0x0
    753e026049dd:	74 23                	je     0x753e02604a02
    753e026049df:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    753e026049e6:	00 
    753e026049e7:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    753e026049ee:	8b 8c 24 7c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x17c]
    753e026049f5:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026049fb:	89 c9                	mov    ecx,ecx
    753e026049fd:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02604a00:	eb 5b                	jmp    0x753e02604a5d
    753e02604a02:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604a09:	00 
    753e02604a0a:	8b 94 24 74 01 00 00 	mov    edx,DWORD PTR [rsp+0x174]
    753e02604a11:	8b b4 24 7c 01 00 00 	mov    esi,DWORD PTR [rsp+0x17c]
    753e02604a18:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02604a1f:	00 
    753e02604a20:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    753e02604a27:	03 01 00 
    753e02604a2a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02604a31:	00 00 00 
    753e02604a34:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e02604a3b:	00 00 00 
    753e02604a3e:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02604a45:	5c 00 00 
    753e02604a48:	ff d0                	call   rax
    753e02604a4a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604a51:	00 
    753e02604a52:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02604a59:	75 20                	jne    0x753e02604a7b
    753e02604a5b:	eb 6a                	jmp    0x753e02604ac7
    753e02604a5d:	8b 84 24 7c 01 00 00 	mov    eax,DWORD PTR [rsp+0x17c]
    753e02604a64:	83 e8 04             	sub    eax,0x4
    753e02604a67:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    753e02604a6e:	83 e0 03             	and    eax,0x3
    753e02604a71:	83 f8 00             	cmp    eax,0x0
    753e02604a74:	75 53                	jne    0x753e02604ac9
    753e02604a76:	e9 e6 00 00 00       	jmp    0x753e02604b61
    753e02604a7b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604a82:	00 
    753e02604a83:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604a89:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604a8f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604a95:	be 02 00 00 00       	mov    esi,0x2
    753e02604a9a:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604a9f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604aa6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604aad:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604ab4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604abb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604ac2:	e9 03 1e 00 00       	jmp    0x753e026068ca
    753e02604ac7:	eb 94                	jmp    0x753e02604a5d
    753e02604ac9:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604ad0:	00 
    753e02604ad1:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e02604ad8:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02604adf:	00 
    753e02604ae0:	c7 87 bc 00 00 00 2a 	mov    DWORD PTR [rdi+0xbc],0x1032a
    753e02604ae7:	03 01 00 
    753e02604aea:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02604af1:	00 00 00 
    753e02604af4:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e02604afb:	00 00 00 
    753e02604afe:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02604b05:	5c 00 00 
    753e02604b08:	ba 2a 03 01 00       	mov    edx,0x1032a
    753e02604b0d:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02604b13:	ff d0                	call   rax
    753e02604b15:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604b1c:	00 
    753e02604b1d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604b23:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604b29:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604b2f:	be 02 00 00 00       	mov    esi,0x2
    753e02604b34:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604b39:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604b40:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604b47:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604b4e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604b55:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604b5c:	e9 69 1d 00 00       	jmp    0x753e026068ca
    753e02604b61:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02604b68:	00 
    753e02604b69:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e02604b70:	c1 e9 0c             	shr    ecx,0xc
    753e02604b73:	89 c9                	mov    ecx,ecx
    753e02604b75:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02604b79:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
    753e02604b80:	00 
    753e02604b81:	48 83 f8 00          	cmp    rax,0x0
    753e02604b85:	74 23                	je     0x753e02604baa
    753e02604b87:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    753e02604b8e:	00 
    753e02604b8f:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    753e02604b96:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e02604b9d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02604ba3:	89 c9                	mov    ecx,ecx
    753e02604ba5:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02604ba8:	eb 5b                	jmp    0x753e02604c05
    753e02604baa:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604bb1:	00 
    753e02604bb2:	8b 94 24 78 01 00 00 	mov    edx,DWORD PTR [rsp+0x178]
    753e02604bb9:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    753e02604bc0:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02604bc7:	00 
    753e02604bc8:	c7 80 bc 00 00 00 2a 	mov    DWORD PTR [rax+0xbc],0x1032a
    753e02604bcf:	03 01 00 
    753e02604bd2:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02604bd9:	00 00 00 
    753e02604bdc:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e02604be3:	00 00 00 
    753e02604be6:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02604bed:	5c 00 00 
    753e02604bf0:	ff d0                	call   rax
    753e02604bf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604bf9:	00 
    753e02604bfa:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02604c01:	75 2c                	jne    0x753e02604c2f
    753e02604c03:	eb 76                	jmp    0x753e02604c7b
    753e02604c05:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e02604c0c:	00 
    753e02604c0d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02604c14:	00 
    753e02604c15:	8b 94 24 64 01 00 00 	mov    edx,DWORD PTR [rsp+0x164]
    753e02604c1c:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    753e02604c1f:	83 ea 00             	sub    edx,0x0
    753e02604c22:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e02604c25:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02604c28:	75 53                	jne    0x753e02604c7d
    753e02604c2a:	e9 93 00 00 00       	jmp    0x753e02604cc2
    753e02604c2f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604c36:	00 
    753e02604c37:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604c3d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604c43:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604c49:	be 02 00 00 00       	mov    esi,0x2
    753e02604c4e:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604c53:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604c5a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604c61:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604c68:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604c6f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604c76:	e9 4f 1c 00 00       	jmp    0x753e026068ca
    753e02604c7b:	eb 88                	jmp    0x753e02604c05
    753e02604c7d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604c84:	00 
    753e02604c85:	c7 87 bc 00 00 00 2e 	mov    DWORD PTR [rdi+0xbc],0x1032e
    753e02604c8c:	03 01 00 
    753e02604c8f:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02604c96:	00 00 00 
    753e02604c99:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e02604ca0:	00 00 00 
    753e02604ca3:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02604caa:	5c 00 00 
    753e02604cad:	ff d0                	call   rax
    753e02604caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604cb6:	00 
    753e02604cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02604cbe:	75 04                	jne    0x753e02604cc4
    753e02604cc0:	eb 4e                	jmp    0x753e02604d10
    753e02604cc2:	eb 4e                	jmp    0x753e02604d12
    753e02604cc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604ccb:	00 
    753e02604ccc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02604cd2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02604cd8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02604cde:	be 02 00 00 00       	mov    esi,0x2
    753e02604ce3:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604ce8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02604cef:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02604cf6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02604cfd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02604d04:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02604d0b:	e9 ba 1b 00 00       	jmp    0x753e026068ca
    753e02604d10:	eb b0                	jmp    0x753e02604cc2
    753e02604d12:	eb 00                	jmp    0x753e02604d14
    753e02604d14:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604d1b:	00 
    753e02604d1c:	8b 38                	mov    edi,DWORD PTR [rax]
    753e02604d1e:	89 bc 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edi
    753e02604d25:	83 ff 04             	cmp    edi,0x4
    753e02604d28:	0f 96 c1             	setbe  cl
    753e02604d2b:	80 e1 01             	and    cl,0x1
    753e02604d2e:	0f b6 c9             	movzx  ecx,cl
    753e02604d31:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e02604d38:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    753e02604d3e:	83 ff 04             	cmp    edi,0x4
    753e02604d41:	0f 94 c1             	sete   cl
    753e02604d44:	80 e1 01             	and    cl,0x1
    753e02604d47:	0f b6 f1             	movzx  esi,cl
    753e02604d4a:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604d4f:	39 f9                	cmp    ecx,edi
    753e02604d51:	0f 97 c1             	seta   cl
    753e02604d54:	80 e1 01             	and    cl,0x1
    753e02604d57:	0f b6 d1             	movzx  edx,cl
    753e02604d5a:	b9 04 00 00 00       	mov    ecx,0x4
    753e02604d5f:	39 f9                	cmp    ecx,edi
    753e02604d61:	0f 96 c1             	setbe  cl
    753e02604d64:	80 e1 01             	and    cl,0x1
    753e02604d67:	0f b6 c9             	movzx  ecx,cl
    753e02604d6a:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02604d70:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e02604d76:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02604d7c:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02604d82:	eb 00                	jmp    0x753e02604d84
    753e02604d84:	8b 84 24 54 01 00 00 	mov    eax,DWORD PTR [rsp+0x154]
    753e02604d8b:	83 f8 00             	cmp    eax,0x0
    753e02604d8e:	75 33                	jne    0x753e02604dc3
    753e02604d90:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02604d97:	00 
    753e02604d98:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    753e02604d9f:	03 01 00 
    753e02604da2:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02604da8:	83 c0 04             	add    eax,0x4
    753e02604dab:	89 84 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],eax
    753e02604db2:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02604db8:	0f 82 3c 18 00 00    	jb     0x753e026065fa
    753e02604dbe:	e9 5a 18 00 00       	jmp    0x753e0260661d
    753e02604dc3:	eb 00                	jmp    0x753e02604dc5
    753e02604dc5:	eb 00                	jmp    0x753e02604dc7
    753e02604dc7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604dce:	00 
    753e02604dcf:	8b 78 04             	mov    edi,DWORD PTR [rax+0x4]
    753e02604dd2:	89 bc 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],edi
    753e02604dd9:	89 fa                	mov    edx,edi
    753e02604ddb:	83 ea 00             	sub    edx,0x0
    753e02604dde:	83 fa 00             	cmp    edx,0x0
    753e02604de1:	0f 94 c1             	sete   cl
    753e02604de4:	80 e1 01             	and    cl,0x1
    753e02604de7:	0f b6 f1             	movzx  esi,cl
    753e02604dea:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    753e02604df1:	c1 ea 1f             	shr    edx,0x1f
    753e02604df4:	89 f9                	mov    ecx,edi
    753e02604df6:	c1 e9 1f             	shr    ecx,0x1f
    753e02604df9:	89 d3                	mov    ebx,edx
    753e02604dfb:	31 cb                	xor    ebx,ecx
    753e02604dfd:	83 f1 00             	xor    ecx,0x0
    753e02604e00:	21 d9                	and    ecx,ebx
    753e02604e02:	31 ca                	xor    edx,ecx
    753e02604e04:	31 c9                	xor    ecx,ecx
    753e02604e06:	39 f9                	cmp    ecx,edi
    753e02604e08:	0f 96 c1             	setbe  cl
    753e02604e0b:	80 e1 01             	and    cl,0x1
    753e02604e0e:	0f b6 c9             	movzx  ecx,cl
    753e02604e11:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e02604e17:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02604e1d:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e02604e23:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02604e29:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02604e2f:	eb 00                	jmp    0x753e02604e31
    753e02604e31:	8b 84 24 48 01 00 00 	mov    eax,DWORD PTR [rsp+0x148]
    753e02604e38:	83 f8 00             	cmp    eax,0x0
    753e02604e3b:	74 33                	je     0x753e02604e70
    753e02604e3d:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02604e44:	00 
    753e02604e45:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    753e02604e4c:	03 01 00 
    753e02604e4f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02604e55:	83 c0 06             	add    eax,0x6
    753e02604e58:	89 84 24 40 01 00 00 	mov    DWORD PTR [rsp+0x140],eax
    753e02604e5f:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02604e65:	0f 82 1f 18 00 00    	jb     0x753e0260668a
    753e02604e6b:	e9 3d 18 00 00       	jmp    0x753e026066ad
    753e02604e70:	eb 00                	jmp    0x753e02604e72
    753e02604e72:	eb 00                	jmp    0x753e02604e74
    753e02604e74:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604e7b:	00 
    753e02604e7c:	c7 40 0c 09 3d 00 00 	mov    DWORD PTR [rax+0xc],0x3d09
    753e02604e83:	eb 00                	jmp    0x753e02604e85
    753e02604e85:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604e8c:	00 
    753e02604e8d:	c7 40 0c 00 48 e8 01 	mov    DWORD PTR [rax+0xc],0x1e84800
    753e02604e94:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    753e02604e9b:	00 00 00 
    753e02604e9e:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    753e02604ea5:	00 00 00 
    753e02604ea8:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e02604eaf:	00 00 00 
    753e02604eb2:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e02604eb9:	00 00 00 
    753e02604ebc:	eb 00                	jmp    0x753e02604ebe
    753e02604ebe:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604ec5:	00 
    753e02604ec6:	8b bc 24 44 01 00 00 	mov    edi,DWORD PTR [rsp+0x144]
    753e02604ecd:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    753e02604ed3:	0f 96 c1             	setbe  cl
    753e02604ed6:	80 e1 01             	and    cl,0x1
    753e02604ed9:	0f b6 c9             	movzx  ecx,cl
    753e02604edc:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    753e02604ee3:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    753e02604ee9:	81 ff 00 48 e8 01    	cmp    edi,0x1e84800
    753e02604eef:	0f 94 c1             	sete   cl
    753e02604ef2:	80 e1 01             	and    cl,0x1
    753e02604ef5:	0f b6 f1             	movzx  esi,cl
    753e02604ef8:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    753e02604efd:	39 f9                	cmp    ecx,edi
    753e02604eff:	0f 97 c1             	seta   cl
    753e02604f02:	80 e1 01             	and    cl,0x1
    753e02604f05:	0f b6 d1             	movzx  edx,cl
    753e02604f08:	b9 00 48 e8 01       	mov    ecx,0x1e84800
    753e02604f0d:	39 f9                	cmp    ecx,edi
    753e02604f0f:	0f 96 c1             	setbe  cl
    753e02604f12:	80 e1 01             	and    cl,0x1
    753e02604f15:	0f b6 c9             	movzx  ecx,cl
    753e02604f18:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02604f1e:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e02604f24:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02604f2a:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02604f30:	eb 00                	jmp    0x753e02604f32
    753e02604f32:	8b 84 24 3c 01 00 00 	mov    eax,DWORD PTR [rsp+0x13c]
    753e02604f39:	83 f8 00             	cmp    eax,0x0
    753e02604f3c:	75 33                	jne    0x753e02604f71
    753e02604f3e:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02604f45:	00 
    753e02604f46:	c7 81 bc 00 00 00 70 	mov    DWORD PTR [rcx+0xbc],0x10370
    753e02604f4d:	03 01 00 
    753e02604f50:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02604f56:	83 c0 0a             	add    eax,0xa
    753e02604f59:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    753e02604f60:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02604f66:	0f 82 ae 17 00 00    	jb     0x753e0260671a
    753e02604f6c:	e9 cc 17 00 00       	jmp    0x753e0260673d
    753e02604f71:	eb 00                	jmp    0x753e02604f73
    753e02604f73:	eb 00                	jmp    0x753e02604f75
    753e02604f75:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604f7c:	00 
    753e02604f7d:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    753e02604f80:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02604f86:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02604f8c:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    753e02604f93:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02604f96:	eb 00                	jmp    0x753e02604f98
    753e02604f98:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02604f9f:	00 
    753e02604fa0:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e02604fa7:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e02604fad:	81 c9 f0 12 00 00    	or     ecx,0x12f0
    753e02604fb3:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    753e02604fba:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02604fbd:	eb 00                	jmp    0x753e02604fbf
    753e02604fbf:	8b 84 24 30 01 00 00 	mov    eax,DWORD PTR [rsp+0x130]
    753e02604fc6:	83 e0 03             	and    eax,0x3
    753e02604fc9:	83 f8 00             	cmp    eax,0x0
    753e02604fcc:	0f 84 98 00 00 00    	je     0x753e0260506a
    753e02604fd2:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02604fd9:	00 
    753e02604fda:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e02604fe1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02604fe8:	00 
    753e02604fe9:	c7 87 bc 00 00 00 48 	mov    DWORD PTR [rdi+0xbc],0x10348
    753e02604ff0:	03 01 00 
    753e02604ff3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02604ffa:	00 00 00 
    753e02604ffd:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    753e02605004:	00 00 00 
    753e02605007:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260500e:	5c 00 00 
    753e02605011:	ba 48 03 01 00       	mov    edx,0x10348
    753e02605016:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260501c:	ff d0                	call   rax
    753e0260501e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605025:	00 
    753e02605026:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260502c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605032:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605038:	be 0d 00 00 00       	mov    esi,0xd
    753e0260503d:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605042:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605049:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605050:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605057:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260505e:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605065:	e9 60 18 00 00       	jmp    0x753e026068ca
    753e0260506a:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02605071:	00 
    753e02605072:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e02605079:	c1 e9 0c             	shr    ecx,0xc
    753e0260507c:	89 c9                	mov    ecx,ecx
    753e0260507e:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02605082:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    753e02605089:	00 
    753e0260508a:	48 83 f8 00          	cmp    rax,0x0
    753e0260508e:	74 23                	je     0x753e026050b3
    753e02605090:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    753e02605097:	00 
    753e02605098:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    753e0260509f:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e026050a6:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026050ac:	89 c9                	mov    ecx,ecx
    753e026050ae:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026050b1:	eb 5b                	jmp    0x753e0260510e
    753e026050b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026050ba:	00 
    753e026050bb:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    753e026050c2:	8b b4 24 30 01 00 00 	mov    esi,DWORD PTR [rsp+0x130]
    753e026050c9:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026050d0:	00 
    753e026050d1:	c7 80 bc 00 00 00 48 	mov    DWORD PTR [rax+0xbc],0x10348
    753e026050d8:	03 01 00 
    753e026050db:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026050e2:	00 00 00 
    753e026050e5:	c7 80 34 01 00 00 0d 	mov    DWORD PTR [rax+0x134],0xd
    753e026050ec:	00 00 00 
    753e026050ef:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026050f6:	5c 00 00 
    753e026050f9:	ff d0                	call   rax
    753e026050fb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605102:	00 
    753e02605103:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260510a:	75 14                	jne    0x753e02605120
    753e0260510c:	eb 5e                	jmp    0x753e0260516c
    753e0260510e:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e02605115:	00 
    753e02605116:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02605119:	75 53                	jne    0x753e0260516e
    753e0260511b:	e9 93 00 00 00       	jmp    0x753e026051b3
    753e02605120:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605127:	00 
    753e02605128:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260512e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605134:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260513a:	be 0d 00 00 00       	mov    esi,0xd
    753e0260513f:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605144:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260514b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605152:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605159:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605160:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605167:	e9 5e 17 00 00       	jmp    0x753e026068ca
    753e0260516c:	eb a0                	jmp    0x753e0260510e
    753e0260516e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605175:	00 
    753e02605176:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1034a
    753e0260517d:	03 01 00 
    753e02605180:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02605187:	00 00 00 
    753e0260518a:	c7 87 34 01 00 00 0d 	mov    DWORD PTR [rdi+0x134],0xd
    753e02605191:	00 00 00 
    753e02605194:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260519b:	5c 00 00 
    753e0260519e:	ff d0                	call   rax
    753e026051a0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026051a7:	00 
    753e026051a8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026051af:	75 04                	jne    0x753e026051b5
    753e026051b1:	eb 4e                	jmp    0x753e02605201
    753e026051b3:	eb 4e                	jmp    0x753e02605203
    753e026051b5:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026051bc:	00 
    753e026051bd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026051c3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026051c9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026051cf:	be 0d 00 00 00       	mov    esi,0xd
    753e026051d4:	b9 02 00 00 00       	mov    ecx,0x2
    753e026051d9:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026051e0:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026051e7:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026051ee:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026051f5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026051fc:	e9 c9 16 00 00       	jmp    0x753e026068ca
    753e02605201:	eb b0                	jmp    0x753e026051b3
    753e02605203:	eb 00                	jmp    0x753e02605205
    753e02605205:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260520c:	00 
    753e0260520d:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e02605214:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260521a:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02605220:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02605227:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e0260522a:	eb 00                	jmp    0x753e0260522c
    753e0260522c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605233:	00 
    753e02605234:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    753e0260523b:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e02605241:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    753e02605247:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    753e0260524e:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02605251:	eb 00                	jmp    0x753e02605253
    753e02605253:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    753e0260525a:	83 e0 03             	and    eax,0x3
    753e0260525d:	83 f8 00             	cmp    eax,0x0
    753e02605260:	0f 84 98 00 00 00    	je     0x753e026052fe
    753e02605266:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260526d:	00 
    753e0260526e:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    753e02605275:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e0260527c:	00 
    753e0260527d:	c7 87 bc 00 00 00 52 	mov    DWORD PTR [rdi+0xbc],0x10352
    753e02605284:	03 01 00 
    753e02605287:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260528e:	00 00 00 
    753e02605291:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    753e02605298:	00 00 00 
    753e0260529b:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026052a2:	5c 00 00 
    753e026052a5:	ba 52 03 01 00       	mov    edx,0x10352
    753e026052aa:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026052b0:	ff d0                	call   rax
    753e026052b2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026052b9:	00 
    753e026052ba:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026052c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026052c6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026052cc:	be 10 00 00 00       	mov    esi,0x10
    753e026052d1:	b9 02 00 00 00       	mov    ecx,0x2
    753e026052d6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026052dd:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026052e4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026052eb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026052f2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026052f9:	e9 cc 15 00 00       	jmp    0x753e026068ca
    753e026052fe:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02605305:	00 
    753e02605306:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    753e0260530d:	c1 e9 0c             	shr    ecx,0xc
    753e02605310:	89 c9                	mov    ecx,ecx
    753e02605312:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02605316:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    753e0260531d:	00 
    753e0260531e:	48 83 f8 00          	cmp    rax,0x0
    753e02605322:	74 23                	je     0x753e02605347
    753e02605324:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    753e0260532b:	00 
    753e0260532c:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    753e02605333:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    753e0260533a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02605340:	89 c9                	mov    ecx,ecx
    753e02605342:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02605345:	eb 5b                	jmp    0x753e026053a2
    753e02605347:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260534e:	00 
    753e0260534f:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    753e02605356:	8b b4 24 20 01 00 00 	mov    esi,DWORD PTR [rsp+0x120]
    753e0260535d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02605364:	00 
    753e02605365:	c7 80 bc 00 00 00 52 	mov    DWORD PTR [rax+0xbc],0x10352
    753e0260536c:	03 01 00 
    753e0260536f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02605376:	00 00 00 
    753e02605379:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    753e02605380:	00 00 00 
    753e02605383:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260538a:	5c 00 00 
    753e0260538d:	ff d0                	call   rax
    753e0260538f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605396:	00 
    753e02605397:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260539e:	75 14                	jne    0x753e026053b4
    753e026053a0:	eb 5e                	jmp    0x753e02605400
    753e026053a2:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e026053a9:	00 
    753e026053aa:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e026053ad:	75 53                	jne    0x753e02605402
    753e026053af:	e9 93 00 00 00       	jmp    0x753e02605447
    753e026053b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026053bb:	00 
    753e026053bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026053c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026053c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026053ce:	be 10 00 00 00       	mov    esi,0x10
    753e026053d3:	b9 02 00 00 00       	mov    ecx,0x2
    753e026053d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026053df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026053e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026053ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026053f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026053fb:	e9 ca 14 00 00       	jmp    0x753e026068ca
    753e02605400:	eb a0                	jmp    0x753e026053a2
    753e02605402:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605409:	00 
    753e0260540a:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10354
    753e02605411:	03 01 00 
    753e02605414:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260541b:	00 00 00 
    753e0260541e:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    753e02605425:	00 00 00 
    753e02605428:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260542f:	5c 00 00 
    753e02605432:	ff d0                	call   rax
    753e02605434:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260543b:	00 
    753e0260543c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02605443:	75 04                	jne    0x753e02605449
    753e02605445:	eb 4e                	jmp    0x753e02605495
    753e02605447:	eb 4e                	jmp    0x753e02605497
    753e02605449:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605450:	00 
    753e02605451:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605457:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260545d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605463:	be 10 00 00 00       	mov    esi,0x10
    753e02605468:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260546d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605474:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260547b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605482:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605489:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605490:	e9 35 14 00 00       	jmp    0x753e026068ca
    753e02605495:	eb b0                	jmp    0x753e02605447
    753e02605497:	eb 00                	jmp    0x753e02605499
    753e02605499:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026054a0:	00 
    753e026054a1:	8b 8c 24 20 01 00 00 	mov    ecx,DWORD PTR [rsp+0x120]
    753e026054a8:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e026054ae:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e026054b4:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    753e026054bb:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026054be:	eb 00                	jmp    0x753e026054c0
    753e026054c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026054c7:	00 
    753e026054c8:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    753e026054cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026054d5:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    753e026054db:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    753e026054e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026054e5:	eb 00                	jmp    0x753e026054e7
    753e026054e7:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    753e026054ee:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026054f5:	00 
    753e026054f6:	8b 49 08             	mov    ecx,DWORD PTR [rcx+0x8]
    753e026054f9:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    753e02605500:	83 e0 03             	and    eax,0x3
    753e02605503:	83 f8 00             	cmp    eax,0x0
    753e02605506:	0f 84 98 00 00 00    	je     0x753e026055a4
    753e0260550c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605513:	00 
    753e02605514:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e0260551b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02605522:	00 
    753e02605523:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1035c
    753e0260552a:	03 01 00 
    753e0260552d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02605534:	00 00 00 
    753e02605537:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    753e0260553e:	00 00 00 
    753e02605541:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02605548:	5c 00 00 
    753e0260554b:	ba 5c 03 01 00       	mov    edx,0x1035c
    753e02605550:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02605556:	ff d0                	call   rax
    753e02605558:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260555f:	00 
    753e02605560:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605566:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260556c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605572:	be 13 00 00 00       	mov    esi,0x13
    753e02605577:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260557c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605583:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260558a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605591:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605598:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260559f:	e9 26 13 00 00       	jmp    0x753e026068ca
    753e026055a4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026055ab:	00 
    753e026055ac:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e026055b3:	c1 e9 0c             	shr    ecx,0xc
    753e026055b6:	89 c9                	mov    ecx,ecx
    753e026055b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026055bc:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    753e026055c3:	00 
    753e026055c4:	48 83 f8 00          	cmp    rax,0x0
    753e026055c8:	74 23                	je     0x753e026055ed
    753e026055ca:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    753e026055d1:	00 
    753e026055d2:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    753e026055d9:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e026055e0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026055e6:	89 c9                	mov    ecx,ecx
    753e026055e8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026055eb:	eb 5b                	jmp    0x753e02605648
    753e026055ed:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026055f4:	00 
    753e026055f5:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    753e026055fc:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    753e02605603:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e0260560a:	00 
    753e0260560b:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1035c
    753e02605612:	03 01 00 
    753e02605615:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260561c:	00 00 00 
    753e0260561f:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    753e02605626:	00 00 00 
    753e02605629:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02605630:	5c 00 00 
    753e02605633:	ff d0                	call   rax
    753e02605635:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260563c:	00 
    753e0260563d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02605644:	75 14                	jne    0x753e0260565a
    753e02605646:	eb 5e                	jmp    0x753e026056a6
    753e02605648:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e0260564f:	00 
    753e02605650:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02605653:	75 53                	jne    0x753e026056a8
    753e02605655:	e9 93 00 00 00       	jmp    0x753e026056ed
    753e0260565a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605661:	00 
    753e02605662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260566e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605674:	be 13 00 00 00       	mov    esi,0x13
    753e02605679:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260567e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260568c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260569a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026056a1:	e9 24 12 00 00       	jmp    0x753e026068ca
    753e026056a6:	eb a0                	jmp    0x753e02605648
    753e026056a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026056af:	00 
    753e026056b0:	c7 87 bc 00 00 00 5e 	mov    DWORD PTR [rdi+0xbc],0x1035e
    753e026056b7:	03 01 00 
    753e026056ba:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026056c1:	00 00 00 
    753e026056c4:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    753e026056cb:	00 00 00 
    753e026056ce:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e026056d5:	5c 00 00 
    753e026056d8:	ff d0                	call   rax
    753e026056da:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026056e1:	00 
    753e026056e2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026056e9:	75 04                	jne    0x753e026056ef
    753e026056eb:	eb 4e                	jmp    0x753e0260573b
    753e026056ed:	eb 4e                	jmp    0x753e0260573d
    753e026056ef:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026056f6:	00 
    753e026056f7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026056fd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605703:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605709:	be 13 00 00 00       	mov    esi,0x13
    753e0260570e:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605713:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260571a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605721:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605728:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260572f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605736:	e9 8f 11 00 00       	jmp    0x753e026068ca
    753e0260573b:	eb b0                	jmp    0x753e026056ed
    753e0260573d:	eb 00                	jmp    0x753e0260573f
    753e0260573f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605746:	00 
    753e02605747:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    753e0260574e:	89 fa                	mov    edx,edi
    753e02605750:	83 ea 02             	sub    edx,0x2
    753e02605753:	83 fa 00             	cmp    edx,0x0
    753e02605756:	0f 94 c1             	sete   cl
    753e02605759:	80 e1 01             	and    cl,0x1
    753e0260575c:	0f b6 f1             	movzx  esi,cl
    753e0260575f:	89 b4 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],esi
    753e02605766:	c1 ea 1f             	shr    edx,0x1f
    753e02605769:	89 f9                	mov    ecx,edi
    753e0260576b:	c1 e9 1f             	shr    ecx,0x1f
    753e0260576e:	89 d3                	mov    ebx,edx
    753e02605770:	31 cb                	xor    ebx,ecx
    753e02605772:	83 f1 00             	xor    ecx,0x0
    753e02605775:	21 d9                	and    ecx,ebx
    753e02605777:	31 ca                	xor    edx,ecx
    753e02605779:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260577e:	39 f9                	cmp    ecx,edi
    753e02605780:	0f 96 c1             	setbe  cl
    753e02605783:	80 e1 01             	and    cl,0x1
    753e02605786:	0f b6 c9             	movzx  ecx,cl
    753e02605789:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e0260578f:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02605795:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260579b:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e026057a1:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e026057a7:	eb 00                	jmp    0x753e026057a9
    753e026057a9:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    753e026057b0:	83 f8 00             	cmp    eax,0x0
    753e026057b3:	74 33                	je     0x753e026057e8
    753e026057b5:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026057bc:	00 
    753e026057bd:	c7 81 bc 00 00 00 7a 	mov    DWORD PTR [rcx+0xbc],0x1037a
    753e026057c4:	03 01 00 
    753e026057c7:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e026057cd:	83 c0 15             	add    eax,0x15
    753e026057d0:	89 84 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],eax
    753e026057d7:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e026057dd:	0f 82 c7 0f 00 00    	jb     0x753e026067aa
    753e026057e3:	e9 e5 0f 00 00       	jmp    0x753e026067cd
    753e026057e8:	eb 00                	jmp    0x753e026057ea
    753e026057ea:	eb 00                	jmp    0x753e026057ec
    753e026057ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026057f3:	00 
    753e026057f4:	8b bc 24 50 01 00 00 	mov    edi,DWORD PTR [rsp+0x150]
    753e026057fb:	89 fa                	mov    edx,edi
    753e026057fd:	83 ea 03             	sub    edx,0x3
    753e02605800:	83 fa 00             	cmp    edx,0x0
    753e02605803:	0f 94 c1             	sete   cl
    753e02605806:	80 e1 01             	and    cl,0x1
    753e02605809:	0f b6 f1             	movzx  esi,cl
    753e0260580c:	89 b4 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],esi
    753e02605813:	c1 ea 1f             	shr    edx,0x1f
    753e02605816:	89 f9                	mov    ecx,edi
    753e02605818:	c1 e9 1f             	shr    ecx,0x1f
    753e0260581b:	89 d3                	mov    ebx,edx
    753e0260581d:	31 cb                	xor    ebx,ecx
    753e0260581f:	83 f1 00             	xor    ecx,0x0
    753e02605822:	21 d9                	and    ecx,ebx
    753e02605824:	31 ca                	xor    edx,ecx
    753e02605826:	b9 03 00 00 00       	mov    ecx,0x3
    753e0260582b:	39 f9                	cmp    ecx,edi
    753e0260582d:	0f 96 c1             	setbe  cl
    753e02605830:	80 e1 01             	and    cl,0x1
    753e02605833:	0f b6 c9             	movzx  ecx,cl
    753e02605836:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e0260583c:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02605842:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e02605848:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260584e:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02605854:	eb 00                	jmp    0x753e02605856
    753e02605856:	8b 84 24 f4 00 00 00 	mov    eax,DWORD PTR [rsp+0xf4]
    753e0260585d:	83 f8 00             	cmp    eax,0x0
    753e02605860:	74 33                	je     0x753e02605895
    753e02605862:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02605869:	00 
    753e0260586a:	c7 81 bc 00 00 00 a4 	mov    DWORD PTR [rcx+0xbc],0x103a4
    753e02605871:	03 01 00 
    753e02605874:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260587a:	83 c0 17             	add    eax,0x17
    753e0260587d:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    753e02605884:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260588a:	0f 82 aa 0f 00 00    	jb     0x753e0260683a
    753e02605890:	e9 c8 0f 00 00       	jmp    0x753e0260685d
    753e02605895:	eb 00                	jmp    0x753e02605897
    753e02605897:	eb 00                	jmp    0x753e02605899
    753e02605899:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026058a0:	00 
    753e026058a1:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    753e026058a7:	eb 00                	jmp    0x753e026058a9
    753e026058a9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    753e026058b0:	83 e0 03             	and    eax,0x3
    753e026058b3:	83 f8 00             	cmp    eax,0x0
    753e026058b6:	0f 84 97 00 00 00    	je     0x753e02605953
    753e026058bc:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026058c3:	00 
    753e026058c4:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e026058cb:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026058d2:	00 
    753e026058d3:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    753e026058da:	03 01 00 
    753e026058dd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e026058e4:	00 00 00 
    753e026058e7:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    753e026058ee:	00 00 00 
    753e026058f1:	31 c0                	xor    eax,eax
    753e026058f3:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026058fa:	5c 00 00 
    753e026058fd:	ba 68 03 01 00       	mov    edx,0x10368
    753e02605902:	45 31 c0             	xor    r8d,r8d
    753e02605905:	ff d0                	call   rax
    753e02605907:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260590e:	00 
    753e0260590f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605915:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260591b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605921:	be 19 00 00 00       	mov    esi,0x19
    753e02605926:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260592b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605932:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605939:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605940:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605947:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260594e:	e9 77 0f 00 00       	jmp    0x753e026068ca
    753e02605953:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e0260595a:	00 
    753e0260595b:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e02605962:	c1 e9 0c             	shr    ecx,0xc
    753e02605965:	89 c9                	mov    ecx,ecx
    753e02605967:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260596b:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    753e02605972:	00 
    753e02605973:	48 83 f8 00          	cmp    rax,0x0
    753e02605977:	74 23                	je     0x753e0260599c
    753e02605979:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    753e02605980:	00 
    753e02605981:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e02605988:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260598e:	89 c9                	mov    ecx,ecx
    753e02605990:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02605993:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    753e0260599a:	eb 5d                	jmp    0x753e026059f9
    753e0260599c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026059a3:	00 
    753e026059a4:	8b b4 24 64 01 00 00 	mov    esi,DWORD PTR [rsp+0x164]
    753e026059ab:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026059b2:	00 
    753e026059b3:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    753e026059ba:	03 01 00 
    753e026059bd:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026059c4:	00 00 00 
    753e026059c7:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    753e026059ce:	00 00 00 
    753e026059d1:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026059d8:	5c 00 00 
    753e026059db:	ff d0                	call   rax
    753e026059dd:	89 c1                	mov    ecx,eax
    753e026059df:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026059e6:	00 
    753e026059e7:	89 8c 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],ecx
    753e026059ee:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026059f5:	75 2e                	jne    0x753e02605a25
    753e026059f7:	eb 78                	jmp    0x753e02605a71
    753e026059f9:	8b 84 24 64 01 00 00 	mov    eax,DWORD PTR [rsp+0x164]
    753e02605a00:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e02605a07:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    753e02605a0e:	83 c0 04             	add    eax,0x4
    753e02605a11:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    753e02605a18:	83 e0 03             	and    eax,0x3
    753e02605a1b:	83 f8 00             	cmp    eax,0x0
    753e02605a1e:	75 64                	jne    0x753e02605a84
    753e02605a20:	e9 f6 00 00 00       	jmp    0x753e02605b1b
    753e02605a25:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605a2c:	00 
    753e02605a2d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605a33:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605a39:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605a3f:	be 19 00 00 00       	mov    esi,0x19
    753e02605a44:	b9 04 00 00 00       	mov    ecx,0x4
    753e02605a49:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605a50:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605a57:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605a5e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605a65:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605a6c:	e9 59 0e 00 00       	jmp    0x753e026068ca
    753e02605a71:	8b 84 24 e0 00 00 00 	mov    eax,DWORD PTR [rsp+0xe0]
    753e02605a78:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    753e02605a7f:	e9 75 ff ff ff       	jmp    0x753e026059f9
    753e02605a84:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605a8b:	00 
    753e02605a8c:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    753e02605a93:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02605a9a:	00 
    753e02605a9b:	c7 87 bc 00 00 00 68 	mov    DWORD PTR [rdi+0xbc],0x10368
    753e02605aa2:	03 01 00 
    753e02605aa5:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02605aac:	00 00 00 
    753e02605aaf:	c7 87 34 01 00 00 19 	mov    DWORD PTR [rdi+0x134],0x19
    753e02605ab6:	00 00 00 
    753e02605ab9:	31 c0                	xor    eax,eax
    753e02605abb:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02605ac2:	5c 00 00 
    753e02605ac5:	ba 68 03 01 00       	mov    edx,0x10368
    753e02605aca:	45 31 c0             	xor    r8d,r8d
    753e02605acd:	ff d0                	call   rax
    753e02605acf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605ad6:	00 
    753e02605ad7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605add:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605ae3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605ae9:	be 19 00 00 00       	mov    esi,0x19
    753e02605aee:	b9 04 00 00 00       	mov    ecx,0x4
    753e02605af3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605afa:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605b01:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605b08:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605b0f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605b16:	e9 af 0d 00 00       	jmp    0x753e026068ca
    753e02605b1b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02605b22:	00 
    753e02605b23:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    753e02605b2a:	c1 e9 0c             	shr    ecx,0xc
    753e02605b2d:	89 c9                	mov    ecx,ecx
    753e02605b2f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02605b33:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
    753e02605b3a:	00 
    753e02605b3b:	48 83 f8 00          	cmp    rax,0x0
    753e02605b3f:	74 23                	je     0x753e02605b64
    753e02605b41:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
    753e02605b48:	00 
    753e02605b49:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    753e02605b50:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02605b56:	89 c9                	mov    ecx,ecx
    753e02605b58:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02605b5b:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    753e02605b62:	eb 60                	jmp    0x753e02605bc4
    753e02605b64:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605b6b:	00 
    753e02605b6c:	8b b4 24 dc 00 00 00 	mov    esi,DWORD PTR [rsp+0xdc]
    753e02605b73:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02605b7a:	00 
    753e02605b7b:	c7 80 bc 00 00 00 68 	mov    DWORD PTR [rax+0xbc],0x10368
    753e02605b82:	03 01 00 
    753e02605b85:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02605b8c:	00 00 00 
    753e02605b8f:	c7 80 34 01 00 00 19 	mov    DWORD PTR [rax+0x134],0x19
    753e02605b96:	00 00 00 
    753e02605b99:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02605ba0:	5c 00 00 
    753e02605ba3:	ff d0                	call   rax
    753e02605ba5:	89 c1                	mov    ecx,eax
    753e02605ba7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605bae:	00 
    753e02605baf:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    753e02605bb6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02605bbd:	75 41                	jne    0x753e02605c00
    753e02605bbf:	e9 88 00 00 00       	jmp    0x753e02605c4c
    753e02605bc4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605bcb:	00 
    753e02605bcc:	8b b4 24 d8 00 00 00 	mov    esi,DWORD PTR [rsp+0xd8]
    753e02605bd3:	8b 8c 24 dc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xdc]
    753e02605bda:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    753e02605be1:	89 94 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],edx
    753e02605be8:	83 c1 04             	add    ecx,0x4
    753e02605beb:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    753e02605bf2:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e02605bf5:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e02605bfb:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02605bfe:	eb 5f                	jmp    0x753e02605c5f
    753e02605c00:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605c07:	00 
    753e02605c08:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605c0e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605c14:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605c1a:	be 19 00 00 00       	mov    esi,0x19
    753e02605c1f:	b9 04 00 00 00       	mov    ecx,0x4
    753e02605c24:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605c2b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605c32:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605c39:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605c40:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605c47:	e9 7e 0c 00 00       	jmp    0x753e026068ca
    753e02605c4c:	8b 84 24 c8 00 00 00 	mov    eax,DWORD PTR [rsp+0xc8]
    753e02605c53:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    753e02605c5a:	e9 65 ff ff ff       	jmp    0x753e02605bc4
    753e02605c5f:	eb 00                	jmp    0x753e02605c61
    753e02605c61:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    753e02605c68:	83 e0 03             	and    eax,0x3
    753e02605c6b:	83 f8 00             	cmp    eax,0x0
    753e02605c6e:	0f 84 97 00 00 00    	je     0x753e02605d0b
    753e02605c74:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605c7b:	00 
    753e02605c7c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    753e02605c83:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02605c8a:	00 
    753e02605c8b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    753e02605c92:	03 01 00 
    753e02605c95:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02605c9c:	00 00 00 
    753e02605c9f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e02605ca6:	00 00 00 
    753e02605ca9:	31 c0                	xor    eax,eax
    753e02605cab:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02605cb2:	5c 00 00 
    753e02605cb5:	ba 6c 03 01 00       	mov    edx,0x1036c
    753e02605cba:	45 31 c0             	xor    r8d,r8d
    753e02605cbd:	ff d0                	call   rax
    753e02605cbf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605cc6:	00 
    753e02605cc7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605ccd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605cd3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605cd9:	be 1a 00 00 00       	mov    esi,0x1a
    753e02605cde:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605ce3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605cea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605cf1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605cf8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605cff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605d06:	e9 bf 0b 00 00       	jmp    0x753e026068ca
    753e02605d0b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02605d12:	00 
    753e02605d13:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    753e02605d1a:	c1 e9 0c             	shr    ecx,0xc
    753e02605d1d:	89 c9                	mov    ecx,ecx
    753e02605d1f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02605d23:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    753e02605d2a:	00 
    753e02605d2b:	48 83 f8 00          	cmp    rax,0x0
    753e02605d2f:	74 23                	je     0x753e02605d54
    753e02605d31:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    753e02605d38:	00 
    753e02605d39:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    753e02605d40:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02605d46:	89 c9                	mov    ecx,ecx
    753e02605d48:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02605d4b:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    753e02605d52:	eb 5d                	jmp    0x753e02605db1
    753e02605d54:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605d5b:	00 
    753e02605d5c:	8b b4 24 c4 00 00 00 	mov    esi,DWORD PTR [rsp+0xc4]
    753e02605d63:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02605d6a:	00 
    753e02605d6b:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    753e02605d72:	03 01 00 
    753e02605d75:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02605d7c:	00 00 00 
    753e02605d7f:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e02605d86:	00 00 00 
    753e02605d89:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02605d90:	5c 00 00 
    753e02605d93:	ff d0                	call   rax
    753e02605d95:	89 c1                	mov    ecx,eax
    753e02605d97:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605d9e:	00 
    753e02605d9f:	89 8c 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],ecx
    753e02605da6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02605dad:	75 32                	jne    0x753e02605de1
    753e02605daf:	eb 7c                	jmp    0x753e02605e2d
    753e02605db1:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [rsp+0xc4]
    753e02605db8:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02605dbf:	00 
    753e02605dc0:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e02605dc7:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    753e02605dca:	83 c0 04             	add    eax,0x4
    753e02605dcd:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e02605dd4:	83 e0 03             	and    eax,0x3
    753e02605dd7:	83 f8 00             	cmp    eax,0x0
    753e02605dda:	75 64                	jne    0x753e02605e40
    753e02605ddc:	e9 f6 00 00 00       	jmp    0x753e02605ed7
    753e02605de1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605de8:	00 
    753e02605de9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605def:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605df5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605dfb:	be 1a 00 00 00       	mov    esi,0x1a
    753e02605e00:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605e05:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605e0c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605e13:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605e1a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605e21:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605e28:	e9 9d 0a 00 00       	jmp    0x753e026068ca
    753e02605e2d:	8b 84 24 b0 00 00 00 	mov    eax,DWORD PTR [rsp+0xb0]
    753e02605e34:	89 84 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],eax
    753e02605e3b:	e9 71 ff ff ff       	jmp    0x753e02605db1
    753e02605e40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02605e47:	00 
    753e02605e48:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    753e02605e4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02605e56:	00 
    753e02605e57:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    753e02605e5e:	03 01 00 
    753e02605e61:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02605e68:	00 00 00 
    753e02605e6b:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e02605e72:	00 00 00 
    753e02605e75:	31 c0                	xor    eax,eax
    753e02605e77:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02605e7e:	5c 00 00 
    753e02605e81:	ba 6c 03 01 00       	mov    edx,0x1036c
    753e02605e86:	45 31 c0             	xor    r8d,r8d
    753e02605e89:	ff d0                	call   rax
    753e02605e8b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605e92:	00 
    753e02605e93:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605e99:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605e9f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605ea5:	be 1a 00 00 00       	mov    esi,0x1a
    753e02605eaa:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605eaf:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605eb6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605ebd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605ec4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605ecb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605ed2:	e9 f3 09 00 00       	jmp    0x753e026068ca
    753e02605ed7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02605ede:	00 
    753e02605edf:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    753e02605ee6:	c1 e9 0c             	shr    ecx,0xc
    753e02605ee9:	89 c9                	mov    ecx,ecx
    753e02605eeb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02605eef:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    753e02605ef6:	00 
    753e02605ef7:	48 83 f8 00          	cmp    rax,0x0
    753e02605efb:	74 23                	je     0x753e02605f20
    753e02605efd:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    753e02605f04:	00 
    753e02605f05:	8b 8c 24 ac 00 00 00 	mov    ecx,DWORD PTR [rsp+0xac]
    753e02605f0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02605f12:	89 c9                	mov    ecx,ecx
    753e02605f14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02605f17:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    753e02605f1e:	eb 5d                	jmp    0x753e02605f7d
    753e02605f20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605f27:	00 
    753e02605f28:	8b b4 24 ac 00 00 00 	mov    esi,DWORD PTR [rsp+0xac]
    753e02605f2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02605f36:	00 
    753e02605f37:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    753e02605f3e:	03 01 00 
    753e02605f41:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02605f48:	00 00 00 
    753e02605f4b:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e02605f52:	00 00 00 
    753e02605f55:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02605f5c:	5c 00 00 
    753e02605f5f:	ff d0                	call   rax
    753e02605f61:	89 c1                	mov    ecx,eax
    753e02605f63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605f6a:	00 
    753e02605f6b:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    753e02605f72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02605f79:	75 32                	jne    0x753e02605fad
    753e02605f7b:	eb 7c                	jmp    0x753e02605ff9
    753e02605f7d:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    753e02605f84:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02605f8b:	00 
    753e02605f8c:	8b 94 24 9c 00 00 00 	mov    edx,DWORD PTR [rsp+0x9c]
    753e02605f93:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    753e02605f96:	83 c0 04             	add    eax,0x4
    753e02605f99:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e02605fa0:	83 e0 03             	and    eax,0x3
    753e02605fa3:	83 f8 00             	cmp    eax,0x0
    753e02605fa6:	75 64                	jne    0x753e0260600c
    753e02605fa8:	e9 f6 00 00 00       	jmp    0x753e026060a3
    753e02605fad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02605fb4:	00 
    753e02605fb5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02605fbb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02605fc1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02605fc7:	be 1a 00 00 00       	mov    esi,0x1a
    753e02605fcc:	b9 02 00 00 00       	mov    ecx,0x2
    753e02605fd1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02605fd8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02605fdf:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02605fe6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02605fed:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02605ff4:	e9 d1 08 00 00       	jmp    0x753e026068ca
    753e02605ff9:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    753e02606000:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    753e02606007:	e9 71 ff ff ff       	jmp    0x753e02605f7d
    753e0260600c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02606013:	00 
    753e02606014:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260601b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02606022:	00 
    753e02606023:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    753e0260602a:	03 01 00 
    753e0260602d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02606034:	00 00 00 
    753e02606037:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e0260603e:	00 00 00 
    753e02606041:	31 c0                	xor    eax,eax
    753e02606043:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260604a:	5c 00 00 
    753e0260604d:	ba 6c 03 01 00       	mov    edx,0x1036c
    753e02606052:	45 31 c0             	xor    r8d,r8d
    753e02606055:	ff d0                	call   rax
    753e02606057:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260605e:	00 
    753e0260605f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02606065:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260606b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02606071:	be 1a 00 00 00       	mov    esi,0x1a
    753e02606076:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260607b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02606082:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02606089:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02606090:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02606097:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260609e:	e9 27 08 00 00       	jmp    0x753e026068ca
    753e026060a3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026060aa:	00 
    753e026060ab:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e026060b2:	c1 e9 0c             	shr    ecx,0xc
    753e026060b5:	89 c9                	mov    ecx,ecx
    753e026060b7:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026060bb:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    753e026060c2:	00 
    753e026060c3:	48 83 f8 00          	cmp    rax,0x0
    753e026060c7:	74 23                	je     0x753e026060ec
    753e026060c9:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    753e026060d0:	00 
    753e026060d1:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e026060d8:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026060de:	89 c9                	mov    ecx,ecx
    753e026060e0:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026060e3:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    753e026060ea:	eb 5d                	jmp    0x753e02606149
    753e026060ec:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026060f3:	00 
    753e026060f4:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    753e026060fb:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02606102:	00 
    753e02606103:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    753e0260610a:	03 01 00 
    753e0260610d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606114:	00 00 00 
    753e02606117:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e0260611e:	00 00 00 
    753e02606121:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02606128:	5c 00 00 
    753e0260612b:	ff d0                	call   rax
    753e0260612d:	89 c1                	mov    ecx,eax
    753e0260612f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606136:	00 
    753e02606137:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    753e0260613e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02606145:	75 2f                	jne    0x753e02606176
    753e02606147:	eb 79                	jmp    0x753e026061c2
    753e02606149:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    753e02606150:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02606157:	00 
    753e02606158:	8b 94 24 84 00 00 00 	mov    edx,DWORD PTR [rsp+0x84]
    753e0260615f:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    753e02606162:	83 c0 04             	add    eax,0x4
    753e02606165:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e02606169:	83 e0 03             	and    eax,0x3
    753e0260616c:	83 f8 00             	cmp    eax,0x0
    753e0260616f:	75 64                	jne    0x753e026061d5
    753e02606171:	e9 f3 00 00 00       	jmp    0x753e02606269
    753e02606176:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260617d:	00 
    753e0260617e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02606184:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260618a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02606190:	be 1a 00 00 00       	mov    esi,0x1a
    753e02606195:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260619a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026061a1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026061a8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026061af:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026061b6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026061bd:	e9 08 07 00 00       	jmp    0x753e026068ca
    753e026061c2:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    753e026061c9:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    753e026061d0:	e9 74 ff ff ff       	jmp    0x753e02606149
    753e026061d5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026061dc:	00 
    753e026061dd:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e026061e1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026061e8:	00 
    753e026061e9:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    753e026061f0:	03 01 00 
    753e026061f3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026061fa:	00 00 00 
    753e026061fd:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e02606204:	00 00 00 
    753e02606207:	31 c0                	xor    eax,eax
    753e02606209:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02606210:	5c 00 00 
    753e02606213:	ba 6c 03 01 00       	mov    edx,0x1036c
    753e02606218:	45 31 c0             	xor    r8d,r8d
    753e0260621b:	ff d0                	call   rax
    753e0260621d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606224:	00 
    753e02606225:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260622b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02606231:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02606237:	be 1a 00 00 00       	mov    esi,0x1a
    753e0260623c:	b9 02 00 00 00       	mov    ecx,0x2
    753e02606241:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02606248:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260624f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02606256:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260625d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02606264:	e9 61 06 00 00       	jmp    0x753e026068ca
    753e02606269:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02606270:	00 
    753e02606271:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02606275:	c1 e9 0c             	shr    ecx,0xc
    753e02606278:	89 c9                	mov    ecx,ecx
    753e0260627a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260627e:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753e02606283:	48 83 f8 00          	cmp    rax,0x0
    753e02606287:	74 1a                	je     0x753e026062a3
    753e02606289:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e0260628e:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02606292:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02606298:	89 c9                	mov    ecx,ecx
    753e0260629a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260629d:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e026062a1:	eb 57                	jmp    0x753e026062fa
    753e026062a3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026062aa:	00 
    753e026062ab:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    753e026062af:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026062b6:	00 
    753e026062b7:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    753e026062be:	03 01 00 
    753e026062c1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026062c8:	00 00 00 
    753e026062cb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e026062d2:	00 00 00 
    753e026062d5:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026062dc:	5c 00 00 
    753e026062df:	ff d0                	call   rax
    753e026062e1:	89 c1                	mov    ecx,eax
    753e026062e3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026062ea:	00 
    753e026062eb:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e026062ef:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026062f6:	75 29                	jne    0x753e02606321
    753e026062f8:	eb 73                	jmp    0x753e0260636d
    753e026062fa:	8b 44 24 7c          	mov    eax,DWORD PTR [rsp+0x7c]
    753e026062fe:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02606305:	00 
    753e02606306:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    753e0260630a:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    753e0260630d:	83 c0 04             	add    eax,0x4
    753e02606310:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e02606314:	83 e0 03             	and    eax,0x3
    753e02606317:	83 f8 00             	cmp    eax,0x0
    753e0260631a:	75 5b                	jne    0x753e02606377
    753e0260631c:	e9 ea 00 00 00       	jmp    0x753e0260640b
    753e02606321:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606328:	00 
    753e02606329:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260632f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02606335:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260633b:	be 1a 00 00 00       	mov    esi,0x1a
    753e02606340:	b9 02 00 00 00       	mov    ecx,0x2
    753e02606345:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260634c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02606353:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260635a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02606361:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02606368:	e9 5d 05 00 00       	jmp    0x753e026068ca
    753e0260636d:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    753e02606371:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e02606375:	eb 83                	jmp    0x753e026062fa
    753e02606377:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260637e:	00 
    753e0260637f:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02606383:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e0260638a:	00 
    753e0260638b:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1036c
    753e02606392:	03 01 00 
    753e02606395:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260639c:	00 00 00 
    753e0260639f:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e026063a6:	00 00 00 
    753e026063a9:	31 c0                	xor    eax,eax
    753e026063ab:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026063b2:	5c 00 00 
    753e026063b5:	ba 6c 03 01 00       	mov    edx,0x1036c
    753e026063ba:	45 31 c0             	xor    r8d,r8d
    753e026063bd:	ff d0                	call   rax
    753e026063bf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026063c6:	00 
    753e026063c7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026063cd:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026063d3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026063d9:	be 1a 00 00 00       	mov    esi,0x1a
    753e026063de:	b9 02 00 00 00       	mov    ecx,0x2
    753e026063e3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026063ea:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026063f1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026063f8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026063ff:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02606406:	e9 bf 04 00 00       	jmp    0x753e026068ca
    753e0260640b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02606412:	00 
    753e02606413:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02606417:	c1 e9 0c             	shr    ecx,0xc
    753e0260641a:	89 c9                	mov    ecx,ecx
    753e0260641c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02606420:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e02606425:	48 83 f8 00          	cmp    rax,0x0
    753e02606429:	74 1a                	je     0x753e02606445
    753e0260642b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e02606430:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02606434:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260643a:	89 c9                	mov    ecx,ecx
    753e0260643c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260643f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e02606443:	eb 57                	jmp    0x753e0260649c
    753e02606445:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260644c:	00 
    753e0260644d:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    753e02606451:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02606458:	00 
    753e02606459:	c7 80 bc 00 00 00 6c 	mov    DWORD PTR [rax+0xbc],0x1036c
    753e02606460:	03 01 00 
    753e02606463:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260646a:	00 00 00 
    753e0260646d:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e02606474:	00 00 00 
    753e02606477:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260647e:	5c 00 00 
    753e02606481:	ff d0                	call   rax
    753e02606483:	89 c1                	mov    ecx,eax
    753e02606485:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260648c:	00 
    753e0260648d:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e02606491:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02606498:	75 1d                	jne    0x753e026064b7
    753e0260649a:	eb 67                	jmp    0x753e02606503
    753e0260649c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026064a3:	00 
    753e026064a4:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e026064a8:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    753e026064ac:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    753e026064af:	83 c1 04             	add    ecx,0x4
    753e026064b2:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e026064b5:	eb 56                	jmp    0x753e0260650d
    753e026064b7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026064be:	00 
    753e026064bf:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026064c5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026064cb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026064d1:	be 1a 00 00 00       	mov    esi,0x1a
    753e026064d6:	b9 02 00 00 00       	mov    ecx,0x2
    753e026064db:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026064e2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026064e9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026064f0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026064f7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026064fe:	e9 c7 03 00 00       	jmp    0x753e026068ca
    753e02606503:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e02606507:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260650b:	eb 8f                	jmp    0x753e0260649c
    753e0260650d:	eb 00                	jmp    0x753e0260650f
    753e0260650f:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    753e02606516:	83 e0 01             	and    eax,0x1
    753e02606519:	83 f8 00             	cmp    eax,0x0
    753e0260651c:	75 3d                	jne    0x753e0260655b
    753e0260651e:	8b 94 24 c0 00 00 00 	mov    edx,DWORD PTR [rsp+0xc0]
    753e02606525:	be 1b 00 00 00       	mov    esi,0x1b
    753e0260652a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260652f:	b0 01                	mov    al,0x1
    753e02606531:	89 d7                	mov    edi,edx
    753e02606533:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260653a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02606541:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02606548:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260654f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02606556:	e9 6f 03 00 00       	jmp    0x753e026068ca
    753e0260655b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02606562:	00 
    753e02606563:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    753e0260656a:	00 
    753e0260656b:	c7 87 bc 00 00 00 6e 	mov    DWORD PTR [rdi+0xbc],0x1036e
    753e02606572:	03 01 00 
    753e02606575:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260657c:	00 00 00 
    753e0260657f:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    753e02606586:	00 00 00 
    753e02606589:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e02606590:	5c 00 00 
    753e02606593:	be 2a 00 00 00       	mov    esi,0x2a
    753e02606598:	ff d0                	call   rax
    753e0260659a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026065a1:	00 
    753e026065a2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026065a8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026065ae:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026065b4:	be 1b 00 00 00       	mov    esi,0x1b
    753e026065b9:	b9 02 00 00 00       	mov    ecx,0x2
    753e026065be:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026065c5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026065cc:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026065d3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026065da:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026065e1:	e9 e4 02 00 00       	jmp    0x753e026068ca
    753e026065e6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026065ed:	00 
    753e026065ee:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e026065f5:	e9 c2 03 00 00       	jmp    0x753e026069bc
    753e026065fa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02606601:	00 
    753e02606602:	48 89 c1             	mov    rcx,rax
    753e02606605:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    753e0260660c:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
    753e02606611:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    753e02606618:	03 01 00 
    753e0260661b:	74 32                	je     0x753e0260664f
    753e0260661d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606624:	00 
    753e02606625:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    753e0260662c:	03 01 00 
    753e0260662f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606636:	00 00 00 
    753e02606639:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e02606640:	00 00 00 
    753e02606643:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260664a:	e9 6d 03 00 00       	jmp    0x753e026069bc
    753e0260664f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02606656:	00 
    753e02606657:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e0260665e:	00 
    753e0260665f:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
    753e02606664:	8b 8c 24 4c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x14c]
    753e0260666b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753e02606672:	70 03 01 00 
    753e02606676:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260667d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606681:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02606688:	ff e0                	jmp    rax
    753e0260668a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02606691:	00 
    753e02606692:	48 89 c1             	mov    rcx,rax
    753e02606695:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    753e0260669c:	48 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],rcx
    753e026066a1:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    753e026066a8:	03 01 00 
    753e026066ab:	74 32                	je     0x753e026066df
    753e026066ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026066b4:	00 
    753e026066b5:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    753e026066bc:	03 01 00 
    753e026066bf:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026066c6:	00 00 00 
    753e026066c9:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    753e026066d0:	00 00 00 
    753e026066d3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e026066da:	e9 dd 02 00 00       	jmp    0x753e026069bc
    753e026066df:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e026066e6:	00 
    753e026066e7:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e026066ee:	00 
    753e026066ef:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    753e026066f4:	8b 8c 24 40 01 00 00 	mov    ecx,DWORD PTR [rsp+0x140]
    753e026066fb:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753e02606702:	70 03 01 00 
    753e02606706:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260670d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606711:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02606718:	ff e0                	jmp    rax
    753e0260671a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02606721:	00 
    753e02606722:	48 89 c1             	mov    rcx,rax
    753e02606725:	48 81 c1 80 1b 08 00 	add    rcx,0x81b80
    753e0260672c:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
    753e02606731:	81 b8 80 1b 08 00 70 	cmp    DWORD PTR [rax+0x81b80],0x10370
    753e02606738:	03 01 00 
    753e0260673b:	74 32                	je     0x753e0260676f
    753e0260673d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606744:	00 
    753e02606745:	c7 80 bc 00 00 00 70 	mov    DWORD PTR [rax+0xbc],0x10370
    753e0260674c:	03 01 00 
    753e0260674f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606756:	00 00 00 
    753e02606759:	c7 80 34 01 00 00 0a 	mov    DWORD PTR [rax+0x134],0xa
    753e02606760:	00 00 00 
    753e02606763:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260676a:	e9 4d 02 00 00       	jmp    0x753e026069bc
    753e0260676f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02606776:	00 
    753e02606777:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e0260677e:	00 
    753e0260677f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e02606784:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    753e0260678b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10370
    753e02606792:	70 03 01 00 
    753e02606796:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260679d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e026067a1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e026067a8:	ff e0                	jmp    rax
    753e026067aa:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e026067b1:	00 
    753e026067b2:	48 89 c1             	mov    rcx,rax
    753e026067b5:	48 81 c1 d0 1b 08 00 	add    rcx,0x81bd0
    753e026067bc:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    753e026067c1:	81 b8 d0 1b 08 00 7a 	cmp    DWORD PTR [rax+0x81bd0],0x1037a
    753e026067c8:	03 01 00 
    753e026067cb:	74 32                	je     0x753e026067ff
    753e026067cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026067d4:	00 
    753e026067d5:	c7 80 bc 00 00 00 7a 	mov    DWORD PTR [rax+0xbc],0x1037a
    753e026067dc:	03 01 00 
    753e026067df:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026067e6:	00 00 00 
    753e026067e9:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    753e026067f0:	00 00 00 
    753e026067f3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e026067fa:	e9 bd 01 00 00       	jmp    0x753e026069bc
    753e026067ff:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02606806:	00 
    753e02606807:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e0260680e:	00 
    753e0260680f:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    753e02606814:	8b 8c 24 f8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf8]
    753e0260681b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x1037a
    753e02606822:	7a 03 01 00 
    753e02606826:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260682d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02606831:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02606838:	ff e0                	jmp    rax
    753e0260683a:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02606841:	00 
    753e02606842:	48 89 c1             	mov    rcx,rax
    753e02606845:	48 81 c1 20 1d 08 00 	add    rcx,0x81d20
    753e0260684c:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e02606851:	81 b8 20 1d 08 00 a4 	cmp    DWORD PTR [rax+0x81d20],0x103a4
    753e02606858:	03 01 00 
    753e0260685b:	74 32                	je     0x753e0260688f
    753e0260685d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606864:	00 
    753e02606865:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x103a4
    753e0260686c:	03 01 00 
    753e0260686f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02606876:	00 00 00 
    753e02606879:	c7 80 34 01 00 00 17 	mov    DWORD PTR [rax+0x134],0x17
    753e02606880:	00 00 00 
    753e02606883:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260688a:	e9 2d 01 00 00       	jmp    0x753e026069bc
    753e0260688f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02606896:	00 
    753e02606897:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e0260689e:	00 
    753e0260689f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e026068a4:	8b 8c 24 f0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf0]
    753e026068ab:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x103a4
    753e026068b2:	a4 03 01 00 
    753e026068b6:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e026068bd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e026068c1:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e026068c8:	ff e0                	jmp    rax
    753e026068ca:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026068d1:	00 
    753e026068d2:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    753e026068d9:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    753e026068e0:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    753e026068e7:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    753e026068ee:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    753e026068f5:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    753e026068f9:	89 c3                	mov    ebx,eax
    753e026068fb:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    753e026068ff:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    753e02606903:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    753e02606907:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    753e0260690b:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02606911:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e02606915:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260691b:	73 2d                	jae    0x753e0260694a
    753e0260691d:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02606924:	00 
    753e02606925:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02606929:	89 d1                	mov    ecx,edx
    753e0260692b:	c1 e9 01             	shr    ecx,0x1
    753e0260692e:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02606934:	89 c9                	mov    ecx,ecx
    753e02606936:	48 c1 e1 04          	shl    rcx,0x4
    753e0260693a:	48 89 c6             	mov    rsi,rax
    753e0260693d:	48 01 ce             	add    rsi,rcx
    753e02606940:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e02606945:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e02606948:	74 32                	je     0x753e0260697c
    753e0260694a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02606951:	00 
    753e02606952:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    753e02606956:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e0260695a:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    753e0260695e:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    753e02606962:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e02606968:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e0260696e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e02606974:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e0260697a:	eb 40                	jmp    0x753e026069bc
    753e0260697c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02606983:	00 
    753e02606984:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e0260698b:	00 
    753e0260698c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e02606991:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    753e02606995:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02606999:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e026069a0:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e026069a7:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e026069ae:	00 
    753e026069af:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e026069b3:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e026069ba:	ff e0                	jmp    rax
    753e026069bc:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e026069c3:	c2 08 00             	ret    0x8
