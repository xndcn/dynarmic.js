
build-native-instruction-analysis/capture/bcore-default-integer/pc-65542-0-128909188324720.bin:     file format binary


Disassembly of section .data:

0000753e0260dd70 <.data>:
    753e0260dd70:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    753e0260dd77:	4c 89 74 24 60       	mov    QWORD PTR [rsp+0x60],r14
    753e0260dd7c:	4c 89 6c 24 68       	mov    QWORD PTR [rsp+0x68],r13
    753e0260dd81:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260dd88:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753e0260dd8d:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e0260dd94:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753e0260dd99:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260dda0:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e0260dda7:	00 
    753e0260dda8:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    753e0260ddad:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e0260ddb3:	83 fa 00             	cmp    edx,0x0
    753e0260ddb6:	0f 94 c0             	sete   al
    753e0260ddb9:	81 ea 06 00 01 00    	sub    edx,0x10006
    753e0260ddbf:	83 fa 0a             	cmp    edx,0xa
    753e0260ddc2:	0f 97 c2             	seta   dl
    753e0260ddc5:	08 d0                	or     al,dl
    753e0260ddc7:	24 01                	and    al,0x1
    753e0260ddc9:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260ddcf:	83 fa 00             	cmp    edx,0x0
    753e0260ddd2:	0f 94 c1             	sete   cl
    753e0260ddd5:	81 ea 06 00 01 00    	sub    edx,0x10006
    753e0260dddb:	83 fa 0a             	cmp    edx,0xa
    753e0260ddde:	0f 97 c2             	seta   dl
    753e0260dde1:	08 d1                	or     cl,dl
    753e0260dde3:	20 c8                	and    al,cl
    753e0260dde5:	a8 01                	test   al,0x1
    753e0260dde7:	75 05                	jne    0x753e0260ddee
    753e0260dde9:	e9 75 02 00 00       	jmp    0x753e0260e063
    753e0260ddee:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260ddf3:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e0260ddfa:	48 89 c8             	mov    rax,rcx
    753e0260ddfd:	48 05 00 00 10 00    	add    rax,0x100000
    753e0260de03:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e0260de08:	8b 81 30 00 10 00    	mov    eax,DWORD PTR [rcx+0x100030]
    753e0260de0e:	83 c0 01             	add    eax,0x1
    753e0260de11:	89 81 30 00 10 00    	mov    DWORD PTR [rcx+0x100030],eax
    753e0260de17:	3d 30 75 00 00       	cmp    eax,0x7530
    753e0260de1c:	75 40                	jne    0x753e0260de5e
    753e0260de1e:	48 8b 4c 24 58       	mov    rcx,QWORD PTR [rsp+0x58]
    753e0260de23:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e0260de29:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260de2d:	89 c2                	mov    edx,eax
    753e0260de2f:	83 c2 01             	add    edx,0x1
    753e0260de32:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e0260de38:	3d 00 01 00 00       	cmp    eax,0x100
    753e0260de3d:	73 1d                	jae    0x753e0260de5c
    753e0260de3f:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e0260de44:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    753e0260de48:	89 c9                	mov    ecx,ecx
    753e0260de4a:	48 c1 e1 02          	shl    rcx,0x2
    753e0260de4e:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e0260de55:	c7 04 08 0c 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xc
    753e0260de5c:	eb 00                	jmp    0x753e0260de5e
    753e0260de5e:	eb 00                	jmp    0x753e0260de60
    753e0260de60:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260de65:	8b 48 20             	mov    ecx,DWORD PTR [rax+0x20]
    753e0260de68:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260de6e:	81 c9 00 00 00 01    	or     ecx,0x1000000
    753e0260de74:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e0260de78:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    753e0260de7b:	eb 00                	jmp    0x753e0260de7d
    753e0260de7d:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260de82:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    753e0260de86:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e0260de8c:	83 c9 04             	or     ecx,0x4
    753e0260de8f:	89 4c 24 4c          	mov    DWORD PTR [rsp+0x4c],ecx
    753e0260de93:	89 48 20             	mov    DWORD PTR [rax+0x20],ecx
    753e0260de96:	eb 00                	jmp    0x753e0260de98
    753e0260de98:	8b 44 24 4c          	mov    eax,DWORD PTR [rsp+0x4c]
    753e0260de9c:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    753e0260dea1:	8b 09                	mov    ecx,DWORD PTR [rcx]
    753e0260dea3:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e0260dea7:	83 e0 03             	and    eax,0x3
    753e0260deaa:	83 f8 00             	cmp    eax,0x0
    753e0260dead:	74 69                	je     0x753e0260df18
    753e0260deaf:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    753e0260deb4:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260deb8:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
    753e0260debd:	c7 87 bc 00 00 00 0e 	mov    DWORD PTR [rdi+0xbc],0x1000e
    753e0260dec4:	00 01 00 
    753e0260dec7:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260dece:	00 00 00 
    753e0260ded1:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e0260ded8:	00 00 00 
    753e0260dedb:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260dee2:	5c 00 00 
    753e0260dee5:	ba 0e 00 01 00       	mov    edx,0x1000e
    753e0260deea:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260def0:	ff d0                	call   rax
    753e0260def2:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260def7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260defd:	b9 03 00 00 00       	mov    ecx,0x3
    753e0260df02:	b8 02 00 00 00       	mov    eax,0x2
    753e0260df07:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    753e0260df0b:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    753e0260df0f:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e0260df13:	e9 dd 01 00 00       	jmp    0x753e0260e0f5
    753e0260df18:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e0260df1f:	00 
    753e0260df20:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260df24:	c1 e9 0c             	shr    ecx,0xc
    753e0260df27:	89 c9                	mov    ecx,ecx
    753e0260df29:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260df2d:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    753e0260df32:	48 83 f8 00          	cmp    rax,0x0
    753e0260df36:	74 1a                	je     0x753e0260df52
    753e0260df38:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    753e0260df3d:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    753e0260df41:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e0260df45:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260df4b:	89 c9                	mov    ecx,ecx
    753e0260df4d:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260df50:	eb 4c                	jmp    0x753e0260df9e
    753e0260df52:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260df57:	8b 54 24 48          	mov    edx,DWORD PTR [rsp+0x48]
    753e0260df5b:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e0260df5f:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
    753e0260df64:	c7 80 bc 00 00 00 0e 	mov    DWORD PTR [rax+0xbc],0x1000e
    753e0260df6b:	00 01 00 
    753e0260df6e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260df75:	00 00 00 
    753e0260df78:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e0260df7f:	00 00 00 
    753e0260df82:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260df89:	5c 00 00 
    753e0260df8c:	ff d0                	call   rax
    753e0260df8e:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260df93:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260df9a:	75 0e                	jne    0x753e0260dfaa
    753e0260df9c:	eb 32                	jmp    0x753e0260dfd0
    753e0260df9e:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e0260dfa3:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260dfa6:	75 2a                	jne    0x753e0260dfd2
    753e0260dfa8:	eb 67                	jmp    0x753e0260e011
    753e0260dfaa:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260dfaf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260dfb5:	b9 03 00 00 00       	mov    ecx,0x3
    753e0260dfba:	b8 02 00 00 00       	mov    eax,0x2
    753e0260dfbf:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    753e0260dfc3:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    753e0260dfc7:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e0260dfcb:	e9 25 01 00 00       	jmp    0x753e0260e0f5
    753e0260dfd0:	eb cc                	jmp    0x753e0260df9e
    753e0260dfd2:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    753e0260dfd7:	c7 87 bc 00 00 00 10 	mov    DWORD PTR [rdi+0xbc],0x10010
    753e0260dfde:	00 01 00 
    753e0260dfe1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260dfe8:	00 00 00 
    753e0260dfeb:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e0260dff2:	00 00 00 
    753e0260dff5:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260dffc:	5c 00 00 
    753e0260dfff:	ff d0                	call   rax
    753e0260e001:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260e006:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260e00d:	75 04                	jne    0x753e0260e013
    753e0260e00f:	eb 28                	jmp    0x753e0260e039
    753e0260e011:	eb 28                	jmp    0x753e0260e03b
    753e0260e013:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260e018:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260e01e:	b9 03 00 00 00       	mov    ecx,0x3
    753e0260e023:	b8 02 00 00 00       	mov    eax,0x2
    753e0260e028:	89 54 24 3c          	mov    DWORD PTR [rsp+0x3c],edx
    753e0260e02c:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    753e0260e030:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e0260e034:	e9 bc 00 00 00       	jmp    0x753e0260e0f5
    753e0260e039:	eb d6                	jmp    0x753e0260e011
    753e0260e03b:	eb 00                	jmp    0x753e0260e03d
    753e0260e03d:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    753e0260e042:	c7 81 bc 00 00 00 10 	mov    DWORD PTR [rcx+0xbc],0x10010
    753e0260e049:	00 01 00 
    753e0260e04c:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260e052:	83 c0 04             	add    eax,0x4
    753e0260e055:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e0260e059:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260e05f:	72 13                	jb     0x753e0260e074
    753e0260e061:	eb 31                	jmp    0x753e0260e094
    753e0260e063:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260e068:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e0260e06f:	e9 26 01 00 00       	jmp    0x753e0260e19a
    753e0260e074:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e0260e079:	48 89 c1             	mov    rcx,rax
    753e0260e07c:	48 81 c1 80 00 08 00 	add    rcx,0x80080
    753e0260e083:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    753e0260e088:	81 b8 80 00 08 00 10 	cmp    DWORD PTR [rax+0x80080],0x10010
    753e0260e08f:	00 01 00 
    753e0260e092:	74 2f                	je     0x753e0260e0c3
    753e0260e094:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260e099:	c7 80 bc 00 00 00 10 	mov    DWORD PTR [rax+0xbc],0x10010
    753e0260e0a0:	00 01 00 
    753e0260e0a3:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260e0aa:	00 00 00 
    753e0260e0ad:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e0260e0b4:	00 00 00 
    753e0260e0b7:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260e0be:	e9 d7 00 00 00       	jmp    0x753e0260e19a
    753e0260e0c3:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    753e0260e0c8:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    753e0260e0cd:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753e0260e0d2:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e0260e0d6:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10010
    753e0260e0dd:	10 00 01 00 
    753e0260e0e1:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260e0e8:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260e0ec:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753e0260e0f3:	ff e0                	jmp    rax
    753e0260e0f5:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
    753e0260e0fa:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    753e0260e0fe:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    753e0260e102:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e0260e106:	89 c7                	mov    edi,eax
    753e0260e108:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e0260e10c:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e0260e110:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e0260e114:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260e11a:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e0260e11e:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260e124:	73 2a                	jae    0x753e0260e150
    753e0260e126:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e0260e12b:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e0260e12f:	89 d1                	mov    ecx,edx
    753e0260e131:	c1 e9 01             	shr    ecx,0x1
    753e0260e134:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260e13a:	89 c9                	mov    ecx,ecx
    753e0260e13c:	48 c1 e1 04          	shl    rcx,0x4
    753e0260e140:	48 89 c6             	mov    rsi,rax
    753e0260e143:	48 01 ce             	add    rsi,rcx
    753e0260e146:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e0260e14b:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e0260e14e:	74 1b                	je     0x753e0260e16b
    753e0260e150:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260e155:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    753e0260e159:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e0260e15d:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    753e0260e163:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    753e0260e169:	eb 2f                	jmp    0x753e0260e19a
    753e0260e16b:	4c 8b 74 24 60       	mov    r14,QWORD PTR [rsp+0x60]
    753e0260e170:	4c 8b 6c 24 68       	mov    r13,QWORD PTR [rsp+0x68]
    753e0260e175:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e0260e17a:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e0260e17e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260e185:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260e18c:	00 
    753e0260e18d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260e191:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753e0260e198:	ff e0                	jmp    rax
    753e0260e19a:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753e0260e1a1:	c2 08 00             	ret    0x8
