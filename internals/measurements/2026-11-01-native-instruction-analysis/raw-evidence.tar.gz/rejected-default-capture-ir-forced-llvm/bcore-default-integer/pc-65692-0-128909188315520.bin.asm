
build-native-instruction-analysis/capture/bcore-default-integer/pc-65692-0-128909188315520.bin:     file format binary


Disassembly of section .data:

0000753e0260b980 <.data>:
    753e0260b980:	48 81 ec 98 01 00 00 	sub    rsp,0x198
    753e0260b987:	4c 89 b4 24 70 01 00 	mov    QWORD PTR [rsp+0x170],r14
    753e0260b98e:	00 
    753e0260b98f:	4c 89 ac 24 78 01 00 	mov    QWORD PTR [rsp+0x178],r13
    753e0260b996:	00 
    753e0260b997:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260b99e:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    753e0260b9a5:	00 
    753e0260b9a6:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e0260b9ad:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
    753e0260b9b4:	00 
    753e0260b9b5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260b9bc:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    753e0260b9c3:	00 
    753e0260b9c4:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260b9cb:	00 
    753e0260b9cc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e0260b9d2:	83 fa 00             	cmp    edx,0x0
    753e0260b9d5:	0f 94 c0             	sete   al
    753e0260b9d8:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    753e0260b9de:	83 fa 22             	cmp    edx,0x22
    753e0260b9e1:	0f 97 c2             	seta   dl
    753e0260b9e4:	08 d0                	or     al,dl
    753e0260b9e6:	24 01                	and    al,0x1
    753e0260b9e8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260b9ee:	83 fa 00             	cmp    edx,0x0
    753e0260b9f1:	0f 94 c1             	sete   cl
    753e0260b9f4:	81 ea 9c 00 01 00    	sub    edx,0x1009c
    753e0260b9fa:	83 fa 22             	cmp    edx,0x22
    753e0260b9fd:	0f 97 c2             	seta   dl
    753e0260ba00:	08 d1                	or     cl,dl
    753e0260ba02:	20 c8                	and    al,cl
    753e0260ba04:	a8 01                	test   al,0x1
    753e0260ba06:	75 05                	jne    0x753e0260ba0d
    753e0260ba08:	e9 0a 1c 00 00       	jmp    0x753e0260d617
    753e0260ba0d:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ba14:	00 
    753e0260ba15:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e0260ba1c:	48 89 c8             	mov    rax,rcx
    753e0260ba1f:	48 05 00 00 10 00    	add    rax,0x100000
    753e0260ba25:	48 89 84 24 68 01 00 	mov    QWORD PTR [rsp+0x168],rax
    753e0260ba2c:	00 
    753e0260ba2d:	8b 81 28 00 10 00    	mov    eax,DWORD PTR [rcx+0x100028]
    753e0260ba33:	83 c0 01             	add    eax,0x1
    753e0260ba36:	89 81 28 00 10 00    	mov    DWORD PTR [rcx+0x100028],eax
    753e0260ba3c:	3d 30 75 00 00       	cmp    eax,0x7530
    753e0260ba41:	75 4c                	jne    0x753e0260ba8f
    753e0260ba43:	48 8b 8c 24 68 01 00 	mov    rcx,QWORD PTR [rsp+0x168]
    753e0260ba4a:	00 
    753e0260ba4b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e0260ba51:	89 84 24 64 01 00 00 	mov    DWORD PTR [rsp+0x164],eax
    753e0260ba58:	89 c2                	mov    edx,eax
    753e0260ba5a:	83 c2 01             	add    edx,0x1
    753e0260ba5d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e0260ba63:	3d 00 01 00 00       	cmp    eax,0x100
    753e0260ba68:	73 23                	jae    0x753e0260ba8d
    753e0260ba6a:	48 8b 84 24 68 01 00 	mov    rax,QWORD PTR [rsp+0x168]
    753e0260ba71:	00 
    753e0260ba72:	8b 8c 24 64 01 00 00 	mov    ecx,DWORD PTR [rsp+0x164]
    753e0260ba79:	89 c9                	mov    ecx,ecx
    753e0260ba7b:	48 c1 e1 02          	shl    rcx,0x2
    753e0260ba7f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e0260ba86:	c7 04 08 0a 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xa
    753e0260ba8d:	eb 00                	jmp    0x753e0260ba8f
    753e0260ba8f:	eb 00                	jmp    0x753e0260ba91
    753e0260ba91:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260ba98:	00 
    753e0260ba99:	8b 41 30             	mov    eax,DWORD PTR [rcx+0x30]
    753e0260ba9c:	89 84 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],eax
    753e0260baa3:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    753e0260baa6:	89 8c 24 60 01 00 00 	mov    DWORD PTR [rsp+0x160],ecx
    753e0260baad:	83 e0 03             	and    eax,0x3
    753e0260bab0:	83 f8 00             	cmp    eax,0x0
    753e0260bab3:	0f 84 8e 00 00 00    	je     0x753e0260bb47
    753e0260bab9:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260bac0:	00 
    753e0260bac1:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    753e0260bac8:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260bacf:	00 
    753e0260bad0:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260bad7:	00 00 00 
    753e0260bada:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e0260bae1:	00 00 00 
    753e0260bae4:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260baeb:	5c 00 00 
    753e0260baee:	ba 9c 00 01 00       	mov    edx,0x1009c
    753e0260baf3:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260baf9:	ff d0                	call   rax
    753e0260bafb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bb02:	00 
    753e0260bb03:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260bb09:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260bb0f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260bb15:	be 01 00 00 00       	mov    esi,0x1
    753e0260bb1a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260bb1f:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260bb26:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260bb2d:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260bb34:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260bb3b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bb42:	e9 74 1b 00 00       	jmp    0x753e0260d6bb
    753e0260bb47:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260bb4e:	00 
    753e0260bb4f:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    753e0260bb56:	c1 e9 0c             	shr    ecx,0xc
    753e0260bb59:	89 c9                	mov    ecx,ecx
    753e0260bb5b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260bb5f:	48 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],rax
    753e0260bb66:	00 
    753e0260bb67:	48 83 f8 00          	cmp    rax,0x0
    753e0260bb6b:	74 23                	je     0x753e0260bb90
    753e0260bb6d:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
    753e0260bb74:	00 
    753e0260bb75:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    753e0260bb7c:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    753e0260bb83:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260bb89:	89 c9                	mov    ecx,ecx
    753e0260bb8b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260bb8e:	eb 51                	jmp    0x753e0260bbe1
    753e0260bb90:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bb97:	00 
    753e0260bb98:	8b 94 24 60 01 00 00 	mov    edx,DWORD PTR [rsp+0x160]
    753e0260bb9f:	8b b4 24 5c 01 00 00 	mov    esi,DWORD PTR [rsp+0x15c]
    753e0260bba6:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260bbad:	00 
    753e0260bbae:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260bbb5:	00 00 00 
    753e0260bbb8:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e0260bbbf:	00 00 00 
    753e0260bbc2:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260bbc9:	5c 00 00 
    753e0260bbcc:	ff d0                	call   rax
    753e0260bbce:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bbd5:	00 
    753e0260bbd6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260bbdd:	75 14                	jne    0x753e0260bbf3
    753e0260bbdf:	eb 5e                	jmp    0x753e0260bc3f
    753e0260bbe1:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    753e0260bbe8:	00 
    753e0260bbe9:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260bbec:	75 53                	jne    0x753e0260bc41
    753e0260bbee:	e9 93 00 00 00       	jmp    0x753e0260bc86
    753e0260bbf3:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bbfa:	00 
    753e0260bbfb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260bc01:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260bc07:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260bc0d:	be 01 00 00 00       	mov    esi,0x1
    753e0260bc12:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260bc17:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260bc1e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260bc25:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260bc2c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260bc33:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bc3a:	e9 7c 1a 00 00       	jmp    0x753e0260d6bb
    753e0260bc3f:	eb a0                	jmp    0x753e0260bbe1
    753e0260bc41:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260bc48:	00 
    753e0260bc49:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    753e0260bc50:	00 01 00 
    753e0260bc53:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260bc5a:	00 00 00 
    753e0260bc5d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e0260bc64:	00 00 00 
    753e0260bc67:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260bc6e:	5c 00 00 
    753e0260bc71:	ff d0                	call   rax
    753e0260bc73:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bc7a:	00 
    753e0260bc7b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260bc82:	75 04                	jne    0x753e0260bc88
    753e0260bc84:	eb 4e                	jmp    0x753e0260bcd4
    753e0260bc86:	eb 4e                	jmp    0x753e0260bcd6
    753e0260bc88:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bc8f:	00 
    753e0260bc90:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260bc96:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260bc9c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260bca2:	be 01 00 00 00       	mov    esi,0x1
    753e0260bca7:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260bcac:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260bcb3:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260bcba:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260bcc1:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260bcc8:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bccf:	e9 e7 19 00 00       	jmp    0x753e0260d6bb
    753e0260bcd4:	eb b0                	jmp    0x753e0260bc86
    753e0260bcd6:	eb 00                	jmp    0x753e0260bcd8
    753e0260bcd8:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260bcdf:	00 
    753e0260bce0:	8b 41 34             	mov    eax,DWORD PTR [rcx+0x34]
    753e0260bce3:	89 84 24 38 01 00 00 	mov    DWORD PTR [rsp+0x138],eax
    753e0260bcea:	8b 09                	mov    ecx,DWORD PTR [rcx]
    753e0260bcec:	89 8c 24 3c 01 00 00 	mov    DWORD PTR [rsp+0x13c],ecx
    753e0260bcf3:	83 e0 03             	and    eax,0x3
    753e0260bcf6:	83 f8 00             	cmp    eax,0x0
    753e0260bcf9:	0f 84 95 00 00 00    	je     0x753e0260bd94
    753e0260bcff:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260bd06:	00 
    753e0260bd07:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    753e0260bd0e:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260bd15:	00 
    753e0260bd16:	c7 87 bc 00 00 00 9e 	mov    DWORD PTR [rdi+0xbc],0x1009e
    753e0260bd1d:	00 01 00 
    753e0260bd20:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260bd27:	00 00 00 
    753e0260bd2a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e0260bd31:	00 00 00 
    753e0260bd34:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260bd3b:	5c 00 00 
    753e0260bd3e:	ba 9e 00 01 00       	mov    edx,0x1009e
    753e0260bd43:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260bd49:	ff d0                	call   rax
    753e0260bd4b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bd52:	00 
    753e0260bd53:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    753e0260bd59:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260bd5f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260bd65:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260bd6a:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    753e0260bd71:	89 ce                	mov    esi,ecx
    753e0260bd73:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260bd7a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260bd81:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260bd88:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bd8f:	e9 27 19 00 00       	jmp    0x753e0260d6bb
    753e0260bd94:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260bd9b:	00 
    753e0260bd9c:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    753e0260bda3:	c1 e9 0c             	shr    ecx,0xc
    753e0260bda6:	89 c9                	mov    ecx,ecx
    753e0260bda8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260bdac:	48 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rax
    753e0260bdb3:	00 
    753e0260bdb4:	48 83 f8 00          	cmp    rax,0x0
    753e0260bdb8:	74 23                	je     0x753e0260bddd
    753e0260bdba:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
    753e0260bdc1:	00 
    753e0260bdc2:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    753e0260bdc9:	8b 8c 24 38 01 00 00 	mov    ecx,DWORD PTR [rsp+0x138]
    753e0260bdd0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260bdd6:	89 c9                	mov    ecx,ecx
    753e0260bdd8:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260bddb:	eb 5b                	jmp    0x753e0260be38
    753e0260bddd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bde4:	00 
    753e0260bde5:	8b 94 24 3c 01 00 00 	mov    edx,DWORD PTR [rsp+0x13c]
    753e0260bdec:	8b b4 24 38 01 00 00 	mov    esi,DWORD PTR [rsp+0x138]
    753e0260bdf3:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260bdfa:	00 
    753e0260bdfb:	c7 80 bc 00 00 00 9e 	mov    DWORD PTR [rax+0xbc],0x1009e
    753e0260be02:	00 01 00 
    753e0260be05:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260be0c:	00 00 00 
    753e0260be0f:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e0260be16:	00 00 00 
    753e0260be19:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260be20:	5c 00 00 
    753e0260be23:	ff d0                	call   rax
    753e0260be25:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260be2c:	00 
    753e0260be2d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260be34:	75 29                	jne    0x753e0260be5f
    753e0260be36:	eb 70                	jmp    0x753e0260bea8
    753e0260be38:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    753e0260be3f:	00 
    753e0260be40:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260be47:	00 
    753e0260be48:	8b 94 24 38 01 00 00 	mov    edx,DWORD PTR [rsp+0x138]
    753e0260be4f:	83 c2 04             	add    edx,0x4
    753e0260be52:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    753e0260be55:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260be58:	75 50                	jne    0x753e0260beaa
    753e0260be5a:	e9 90 00 00 00       	jmp    0x753e0260beef
    753e0260be5f:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260be66:	00 
    753e0260be67:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    753e0260be6d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260be73:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260be79:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260be7e:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    753e0260be85:	89 ce                	mov    esi,ecx
    753e0260be87:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260be8e:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260be95:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260be9c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bea3:	e9 13 18 00 00       	jmp    0x753e0260d6bb
    753e0260bea8:	eb 8e                	jmp    0x753e0260be38
    753e0260beaa:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260beb1:	00 
    753e0260beb2:	c7 87 bc 00 00 00 a0 	mov    DWORD PTR [rdi+0xbc],0x100a0
    753e0260beb9:	00 01 00 
    753e0260bebc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260bec3:	00 00 00 
    753e0260bec6:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e0260becd:	00 00 00 
    753e0260bed0:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260bed7:	5c 00 00 
    753e0260beda:	ff d0                	call   rax
    753e0260bedc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bee3:	00 
    753e0260bee4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260beeb:	75 04                	jne    0x753e0260bef1
    753e0260beed:	eb 4b                	jmp    0x753e0260bf3a
    753e0260beef:	eb 4b                	jmp    0x753e0260bf3c
    753e0260bef1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bef8:	00 
    753e0260bef9:	8b b0 bc 00 00 00    	mov    esi,DWORD PTR [rax+0xbc]
    753e0260beff:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260bf05:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260bf0b:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260bf10:	89 b4 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],esi
    753e0260bf17:	89 ce                	mov    esi,ecx
    753e0260bf19:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260bf20:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260bf27:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260bf2e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260bf35:	e9 81 17 00 00       	jmp    0x753e0260d6bb
    753e0260bf3a:	eb b3                	jmp    0x753e0260beef
    753e0260bf3c:	eb 00                	jmp    0x753e0260bf3e
    753e0260bf3e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bf45:	00 
    753e0260bf46:	8b 48 1c             	mov    ecx,DWORD PTR [rax+0x1c]
    753e0260bf49:	89 ca                	mov    edx,ecx
    753e0260bf4b:	83 c2 01             	add    edx,0x1
    753e0260bf4e:	89 94 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],edx
    753e0260bf55:	89 50 1c             	mov    DWORD PTR [rax+0x1c],edx
    753e0260bf58:	89 ce                	mov    esi,ecx
    753e0260bf5a:	c1 ee 1f             	shr    esi,0x1f
    753e0260bf5d:	89 d3                	mov    ebx,edx
    753e0260bf5f:	c1 eb 1f             	shr    ebx,0x1f
    753e0260bf62:	89 df                	mov    edi,ebx
    753e0260bf64:	83 f7 00             	xor    edi,0x0
    753e0260bf67:	31 de                	xor    esi,ebx
    753e0260bf69:	21 fe                	and    esi,edi
    753e0260bf6b:	83 f1 ff             	xor    ecx,0xffffffff
    753e0260bf6e:	83 f9 01             	cmp    ecx,0x1
    753e0260bf71:	0f 92 c1             	setb   cl
    753e0260bf74:	80 e1 01             	and    cl,0x1
    753e0260bf77:	0f b6 c9             	movzx  ecx,cl
    753e0260bf7a:	83 fa 00             	cmp    edx,0x0
    753e0260bf7d:	0f 94 c3             	sete   bl
    753e0260bf80:	80 e3 01             	and    bl,0x1
    753e0260bf83:	0f b6 fb             	movzx  edi,bl
    753e0260bf86:	c1 ea 1f             	shr    edx,0x1f
    753e0260bf89:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    753e0260bf8f:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260bf95:	89 f2                	mov    edx,esi
    753e0260bf97:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    753e0260bf9d:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    753e0260bfa3:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    753e0260bfa9:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    753e0260bfaf:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260bfb5:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e0260bfbb:	eb 00                	jmp    0x753e0260bfbd
    753e0260bfbd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bfc4:	00 
    753e0260bfc5:	c7 00 06 00 00 00    	mov    DWORD PTR [rax],0x6
    753e0260bfcb:	eb 00                	jmp    0x753e0260bfcd
    753e0260bfcd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260bfd4:	00 
    753e0260bfd5:	8b 40 2c             	mov    eax,DWORD PTR [rax+0x2c]
    753e0260bfd8:	89 84 24 28 01 00 00 	mov    DWORD PTR [rsp+0x128],eax
    753e0260bfdf:	83 e0 03             	and    eax,0x3
    753e0260bfe2:	83 f8 00             	cmp    eax,0x0
    753e0260bfe5:	0f 84 98 00 00 00    	je     0x753e0260c083
    753e0260bfeb:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260bff2:	00 
    753e0260bff3:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    753e0260bffa:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260c001:	00 
    753e0260c002:	c7 87 bc 00 00 00 a4 	mov    DWORD PTR [rdi+0xbc],0x100a4
    753e0260c009:	00 01 00 
    753e0260c00c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260c013:	00 00 00 
    753e0260c016:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    753e0260c01d:	00 00 00 
    753e0260c020:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260c027:	5c 00 00 
    753e0260c02a:	ba a4 00 01 00       	mov    edx,0x100a4
    753e0260c02f:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260c035:	ff d0                	call   rax
    753e0260c037:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c03e:	00 
    753e0260c03f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c045:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c04b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c051:	be 05 00 00 00       	mov    esi,0x5
    753e0260c056:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c05b:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c062:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c069:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c070:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c077:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c07e:	e9 38 16 00 00       	jmp    0x753e0260d6bb
    753e0260c083:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260c08a:	00 
    753e0260c08b:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    753e0260c092:	c1 e9 0c             	shr    ecx,0xc
    753e0260c095:	89 c9                	mov    ecx,ecx
    753e0260c097:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260c09b:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    753e0260c0a2:	00 
    753e0260c0a3:	48 83 f8 00          	cmp    rax,0x0
    753e0260c0a7:	74 23                	je     0x753e0260c0cc
    753e0260c0a9:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e0260c0b0:	00 
    753e0260c0b1:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    753e0260c0b8:	8b 8c 24 28 01 00 00 	mov    ecx,DWORD PTR [rsp+0x128]
    753e0260c0bf:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260c0c5:	89 c9                	mov    ecx,ecx
    753e0260c0c7:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260c0ca:	eb 5b                	jmp    0x753e0260c127
    753e0260c0cc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c0d3:	00 
    753e0260c0d4:	8b 94 24 2c 01 00 00 	mov    edx,DWORD PTR [rsp+0x12c]
    753e0260c0db:	8b b4 24 28 01 00 00 	mov    esi,DWORD PTR [rsp+0x128]
    753e0260c0e2:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260c0e9:	00 
    753e0260c0ea:	c7 80 bc 00 00 00 a4 	mov    DWORD PTR [rax+0xbc],0x100a4
    753e0260c0f1:	00 01 00 
    753e0260c0f4:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260c0fb:	00 00 00 
    753e0260c0fe:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    753e0260c105:	00 00 00 
    753e0260c108:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260c10f:	5c 00 00 
    753e0260c112:	ff d0                	call   rax
    753e0260c114:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c11b:	00 
    753e0260c11c:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c123:	75 14                	jne    0x753e0260c139
    753e0260c125:	eb 5e                	jmp    0x753e0260c185
    753e0260c127:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    753e0260c12e:	00 
    753e0260c12f:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260c132:	75 53                	jne    0x753e0260c187
    753e0260c134:	e9 93 00 00 00       	jmp    0x753e0260c1cc
    753e0260c139:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c140:	00 
    753e0260c141:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c147:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c14d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c153:	be 05 00 00 00       	mov    esi,0x5
    753e0260c158:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c15d:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c164:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c16b:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c172:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c179:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c180:	e9 36 15 00 00       	jmp    0x753e0260d6bb
    753e0260c185:	eb a0                	jmp    0x753e0260c127
    753e0260c187:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c18e:	00 
    753e0260c18f:	c7 87 bc 00 00 00 a6 	mov    DWORD PTR [rdi+0xbc],0x100a6
    753e0260c196:	00 01 00 
    753e0260c199:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260c1a0:	00 00 00 
    753e0260c1a3:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    753e0260c1aa:	00 00 00 
    753e0260c1ad:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260c1b4:	5c 00 00 
    753e0260c1b7:	ff d0                	call   rax
    753e0260c1b9:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c1c0:	00 
    753e0260c1c1:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c1c8:	75 04                	jne    0x753e0260c1ce
    753e0260c1ca:	eb 4e                	jmp    0x753e0260c21a
    753e0260c1cc:	eb 4e                	jmp    0x753e0260c21c
    753e0260c1ce:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c1d5:	00 
    753e0260c1d6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c1dc:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c1e2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c1e8:	be 05 00 00 00       	mov    esi,0x5
    753e0260c1ed:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c1f2:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c1f9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c200:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c207:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c20e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c215:	e9 a1 14 00 00       	jmp    0x753e0260d6bb
    753e0260c21a:	eb b0                	jmp    0x753e0260c1cc
    753e0260c21c:	eb 00                	jmp    0x753e0260c21e
    753e0260c21e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c225:	00 
    753e0260c226:	8b bc 24 2c 01 00 00 	mov    edi,DWORD PTR [rsp+0x12c]
    753e0260c22d:	89 fa                	mov    edx,edi
    753e0260c22f:	83 ea 06             	sub    edx,0x6
    753e0260c232:	83 fa 00             	cmp    edx,0x0
    753e0260c235:	0f 94 c1             	sete   cl
    753e0260c238:	80 e1 01             	and    cl,0x1
    753e0260c23b:	0f b6 f1             	movzx  esi,cl
    753e0260c23e:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e0260c245:	c1 ea 1f             	shr    edx,0x1f
    753e0260c248:	89 f9                	mov    ecx,edi
    753e0260c24a:	c1 e9 1f             	shr    ecx,0x1f
    753e0260c24d:	89 d3                	mov    ebx,edx
    753e0260c24f:	31 cb                	xor    ebx,ecx
    753e0260c251:	83 f1 00             	xor    ecx,0x0
    753e0260c254:	21 d9                	and    ecx,ebx
    753e0260c256:	31 ca                	xor    edx,ecx
    753e0260c258:	b9 06 00 00 00       	mov    ecx,0x6
    753e0260c25d:	39 f9                	cmp    ecx,edi
    753e0260c25f:	0f 96 c1             	setbe  cl
    753e0260c262:	80 e1 01             	and    cl,0x1
    753e0260c265:	0f b6 c9             	movzx  ecx,cl
    753e0260c268:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e0260c26e:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e0260c274:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260c27a:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e0260c280:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e0260c286:	eb 00                	jmp    0x753e0260c288
    753e0260c288:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    753e0260c28f:	83 f8 00             	cmp    eax,0x0
    753e0260c292:	75 33                	jne    0x753e0260c2c7
    753e0260c294:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260c29b:	00 
    753e0260c29c:	c7 81 bc 00 00 00 84 	mov    DWORD PTR [rcx+0xbc],0x10084
    753e0260c2a3:	00 01 00 
    753e0260c2a6:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260c2ac:	83 c0 07             	add    eax,0x7
    753e0260c2af:	89 84 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],eax
    753e0260c2b6:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260c2bc:	0f 82 69 13 00 00    	jb     0x753e0260d62b
    753e0260c2c2:	e9 87 13 00 00       	jmp    0x753e0260d64e
    753e0260c2c7:	eb 00                	jmp    0x753e0260c2c9
    753e0260c2c9:	eb 00                	jmp    0x753e0260c2cb
    753e0260c2cb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c2d2:	00 
    753e0260c2d3:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    753e0260c2d6:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260c2dc:	83 c9 00             	or     ecx,0x0
    753e0260c2df:	89 8c 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],ecx
    753e0260c2e6:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e0260c2e9:	eb 00                	jmp    0x753e0260c2eb
    753e0260c2eb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c2f2:	00 
    753e0260c2f3:	c7 00 02 00 00 00    	mov    DWORD PTR [rax],0x2
    753e0260c2f9:	eb 00                	jmp    0x753e0260c2fb
    753e0260c2fb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c302:	00 
    753e0260c303:	8b 8c 24 14 01 00 00 	mov    ecx,DWORD PTR [rsp+0x114]
    753e0260c30a:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e0260c310:	81 c9 10 f0 00 00    	or     ecx,0xf010
    753e0260c316:	89 8c 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],ecx
    753e0260c31d:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e0260c320:	eb 00                	jmp    0x753e0260c322
    753e0260c322:	8b 84 24 10 01 00 00 	mov    eax,DWORD PTR [rsp+0x110]
    753e0260c329:	83 e0 03             	and    eax,0x3
    753e0260c32c:	83 f8 00             	cmp    eax,0x0
    753e0260c32f:	0f 84 98 00 00 00    	je     0x753e0260c3cd
    753e0260c335:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c33c:	00 
    753e0260c33d:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e0260c344:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260c34b:	00 
    753e0260c34c:	c7 87 bc 00 00 00 b4 	mov    DWORD PTR [rdi+0xbc],0x100b4
    753e0260c353:	00 01 00 
    753e0260c356:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260c35d:	00 00 00 
    753e0260c360:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    753e0260c367:	00 00 00 
    753e0260c36a:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260c371:	5c 00 00 
    753e0260c374:	ba b4 00 01 00       	mov    edx,0x100b4
    753e0260c379:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260c37f:	ff d0                	call   rax
    753e0260c381:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c388:	00 
    753e0260c389:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c38f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c395:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c39b:	be 0b 00 00 00       	mov    esi,0xb
    753e0260c3a0:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c3a5:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c3ac:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c3b3:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c3ba:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c3c1:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c3c8:	e9 ee 12 00 00       	jmp    0x753e0260d6bb
    753e0260c3cd:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260c3d4:	00 
    753e0260c3d5:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e0260c3dc:	c1 e9 0c             	shr    ecx,0xc
    753e0260c3df:	89 c9                	mov    ecx,ecx
    753e0260c3e1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260c3e5:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
    753e0260c3ec:	00 
    753e0260c3ed:	48 83 f8 00          	cmp    rax,0x0
    753e0260c3f1:	74 20                	je     0x753e0260c413
    753e0260c3f3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260c3fa:	00 
    753e0260c3fb:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e0260c402:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260c408:	89 c9                	mov    ecx,ecx
    753e0260c40a:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    753e0260c411:	eb 59                	jmp    0x753e0260c46c
    753e0260c413:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c41a:	00 
    753e0260c41b:	8b b4 24 10 01 00 00 	mov    esi,DWORD PTR [rsp+0x110]
    753e0260c422:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260c429:	00 
    753e0260c42a:	c7 80 bc 00 00 00 b4 	mov    DWORD PTR [rax+0xbc],0x100b4
    753e0260c431:	00 01 00 
    753e0260c434:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260c43b:	00 00 00 
    753e0260c43e:	c7 80 34 01 00 00 0b 	mov    DWORD PTR [rax+0x134],0xb
    753e0260c445:	00 00 00 
    753e0260c448:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260c44f:	5c 00 00 
    753e0260c452:	ba 02 00 00 00       	mov    edx,0x2
    753e0260c457:	ff d0                	call   rax
    753e0260c459:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c460:	00 
    753e0260c461:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c468:	75 14                	jne    0x753e0260c47e
    753e0260c46a:	eb 5e                	jmp    0x753e0260c4ca
    753e0260c46c:	48 8b 84 24 88 01 00 	mov    rax,QWORD PTR [rsp+0x188]
    753e0260c473:	00 
    753e0260c474:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260c477:	75 53                	jne    0x753e0260c4cc
    753e0260c479:	e9 93 00 00 00       	jmp    0x753e0260c511
    753e0260c47e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c485:	00 
    753e0260c486:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c48c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c492:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c498:	be 0b 00 00 00       	mov    esi,0xb
    753e0260c49d:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c4a2:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c4a9:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c4b0:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c4b7:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c4be:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c4c5:	e9 f1 11 00 00       	jmp    0x753e0260d6bb
    753e0260c4ca:	eb a0                	jmp    0x753e0260c46c
    753e0260c4cc:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c4d3:	00 
    753e0260c4d4:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    753e0260c4db:	00 01 00 
    753e0260c4de:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260c4e5:	00 00 00 
    753e0260c4e8:	c7 87 34 01 00 00 0b 	mov    DWORD PTR [rdi+0x134],0xb
    753e0260c4ef:	00 00 00 
    753e0260c4f2:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260c4f9:	5c 00 00 
    753e0260c4fc:	ff d0                	call   rax
    753e0260c4fe:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c505:	00 
    753e0260c506:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c50d:	75 04                	jne    0x753e0260c513
    753e0260c50f:	eb 4e                	jmp    0x753e0260c55f
    753e0260c511:	eb 4e                	jmp    0x753e0260c561
    753e0260c513:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c51a:	00 
    753e0260c51b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c521:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c527:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c52d:	be 0b 00 00 00       	mov    esi,0xb
    753e0260c532:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c537:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c53e:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c545:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c54c:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c553:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c55a:	e9 5c 11 00 00       	jmp    0x753e0260d6bb
    753e0260c55f:	eb b0                	jmp    0x753e0260c511
    753e0260c561:	eb 00                	jmp    0x753e0260c563
    753e0260c563:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c56a:	00 
    753e0260c56b:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    753e0260c56e:	89 84 24 04 01 00 00 	mov    DWORD PTR [rsp+0x104],eax
    753e0260c575:	83 e0 03             	and    eax,0x3
    753e0260c578:	83 f8 00             	cmp    eax,0x0
    753e0260c57b:	0f 84 97 00 00 00    	je     0x753e0260c618
    753e0260c581:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c588:	00 
    753e0260c589:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    753e0260c590:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260c597:	00 
    753e0260c598:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    753e0260c59f:	00 01 00 
    753e0260c5a2:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260c5a9:	00 00 00 
    753e0260c5ac:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    753e0260c5b3:	00 00 00 
    753e0260c5b6:	31 c0                	xor    eax,eax
    753e0260c5b8:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260c5bf:	5c 00 00 
    753e0260c5c2:	ba b6 00 01 00       	mov    edx,0x100b6
    753e0260c5c7:	45 31 c0             	xor    r8d,r8d
    753e0260c5ca:	ff d0                	call   rax
    753e0260c5cc:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c5d3:	00 
    753e0260c5d4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c5da:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c5e0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c5e6:	be 0c 00 00 00       	mov    esi,0xc
    753e0260c5eb:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260c5f0:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c5f7:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c5fe:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c605:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c60c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c613:	e9 a3 10 00 00       	jmp    0x753e0260d6bb
    753e0260c618:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260c61f:	00 
    753e0260c620:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    753e0260c627:	c1 e9 0c             	shr    ecx,0xc
    753e0260c62a:	89 c9                	mov    ecx,ecx
    753e0260c62c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260c630:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    753e0260c637:	00 
    753e0260c638:	48 83 f8 00          	cmp    rax,0x0
    753e0260c63c:	74 23                	je     0x753e0260c661
    753e0260c63e:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    753e0260c645:	00 
    753e0260c646:	8b 8c 24 04 01 00 00 	mov    ecx,DWORD PTR [rsp+0x104]
    753e0260c64d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260c653:	89 c9                	mov    ecx,ecx
    753e0260c655:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260c658:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    753e0260c65f:	eb 5d                	jmp    0x753e0260c6be
    753e0260c661:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c668:	00 
    753e0260c669:	8b b4 24 04 01 00 00 	mov    esi,DWORD PTR [rsp+0x104]
    753e0260c670:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260c677:	00 
    753e0260c678:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    753e0260c67f:	00 01 00 
    753e0260c682:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260c689:	00 00 00 
    753e0260c68c:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    753e0260c693:	00 00 00 
    753e0260c696:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260c69d:	5c 00 00 
    753e0260c6a0:	ff d0                	call   rax
    753e0260c6a2:	89 c1                	mov    ecx,eax
    753e0260c6a4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c6ab:	00 
    753e0260c6ac:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    753e0260c6b3:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c6ba:	75 2e                	jne    0x753e0260c6ea
    753e0260c6bc:	eb 78                	jmp    0x753e0260c736
    753e0260c6be:	8b 84 24 04 01 00 00 	mov    eax,DWORD PTR [rsp+0x104]
    753e0260c6c5:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    753e0260c6cc:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    753e0260c6d3:	83 c0 04             	add    eax,0x4
    753e0260c6d6:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    753e0260c6dd:	83 e0 03             	and    eax,0x3
    753e0260c6e0:	83 f8 00             	cmp    eax,0x0
    753e0260c6e3:	75 64                	jne    0x753e0260c749
    753e0260c6e5:	e9 f6 00 00 00       	jmp    0x753e0260c7e0
    753e0260c6ea:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c6f1:	00 
    753e0260c6f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c6f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c6fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c704:	be 0c 00 00 00       	mov    esi,0xc
    753e0260c709:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260c70e:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c715:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c71c:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c723:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c72a:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c731:	e9 85 0f 00 00       	jmp    0x753e0260d6bb
    753e0260c736:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    753e0260c73d:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    753e0260c744:	e9 75 ff ff ff       	jmp    0x753e0260c6be
    753e0260c749:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c750:	00 
    753e0260c751:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e0260c758:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260c75f:	00 
    753e0260c760:	c7 87 bc 00 00 00 b6 	mov    DWORD PTR [rdi+0xbc],0x100b6
    753e0260c767:	00 01 00 
    753e0260c76a:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260c771:	00 00 00 
    753e0260c774:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    753e0260c77b:	00 00 00 
    753e0260c77e:	31 c0                	xor    eax,eax
    753e0260c780:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260c787:	5c 00 00 
    753e0260c78a:	ba b6 00 01 00       	mov    edx,0x100b6
    753e0260c78f:	45 31 c0             	xor    r8d,r8d
    753e0260c792:	ff d0                	call   rax
    753e0260c794:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c79b:	00 
    753e0260c79c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c7a2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c7a8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c7ae:	be 0c 00 00 00       	mov    esi,0xc
    753e0260c7b3:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260c7b8:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c7bf:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c7c6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c7cd:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c7d4:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c7db:	e9 db 0e 00 00       	jmp    0x753e0260d6bb
    753e0260c7e0:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260c7e7:	00 
    753e0260c7e8:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e0260c7ef:	c1 e9 0c             	shr    ecx,0xc
    753e0260c7f2:	89 c9                	mov    ecx,ecx
    753e0260c7f4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260c7f8:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    753e0260c7ff:	00 
    753e0260c800:	48 83 f8 00          	cmp    rax,0x0
    753e0260c804:	74 23                	je     0x753e0260c829
    753e0260c806:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e0260c80d:	00 
    753e0260c80e:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e0260c815:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260c81b:	89 c9                	mov    ecx,ecx
    753e0260c81d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260c820:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    753e0260c827:	eb 60                	jmp    0x753e0260c889
    753e0260c829:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c830:	00 
    753e0260c831:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    753e0260c838:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260c83f:	00 
    753e0260c840:	c7 80 bc 00 00 00 b6 	mov    DWORD PTR [rax+0xbc],0x100b6
    753e0260c847:	00 01 00 
    753e0260c84a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260c851:	00 00 00 
    753e0260c854:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    753e0260c85b:	00 00 00 
    753e0260c85e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260c865:	5c 00 00 
    753e0260c868:	ff d0                	call   rax
    753e0260c86a:	89 c1                	mov    ecx,eax
    753e0260c86c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c873:	00 
    753e0260c874:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    753e0260c87b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260c882:	75 41                	jne    0x753e0260c8c5
    753e0260c884:	e9 88 00 00 00       	jmp    0x753e0260c911
    753e0260c889:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c890:	00 
    753e0260c891:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    753e0260c898:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e0260c89f:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    753e0260c8a6:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    753e0260c8ad:	83 c1 04             	add    ecx,0x4
    753e0260c8b0:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    753e0260c8b7:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e0260c8ba:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e0260c8c0:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e0260c8c3:	eb 5f                	jmp    0x753e0260c924
    753e0260c8c5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c8cc:	00 
    753e0260c8cd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c8d3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c8d9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c8df:	be 0c 00 00 00       	mov    esi,0xc
    753e0260c8e4:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260c8e9:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c8f0:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c8f7:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c8fe:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c905:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c90c:	e9 aa 0d 00 00       	jmp    0x753e0260d6bb
    753e0260c911:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    753e0260c918:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    753e0260c91f:	e9 65 ff ff ff       	jmp    0x753e0260c889
    753e0260c924:	eb 00                	jmp    0x753e0260c926
    753e0260c926:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c92d:	00 
    753e0260c92e:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    753e0260c934:	eb 00                	jmp    0x753e0260c936
    753e0260c936:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    753e0260c93d:	83 e0 03             	and    eax,0x3
    753e0260c940:	83 f8 00             	cmp    eax,0x0
    753e0260c943:	0f 84 97 00 00 00    	je     0x753e0260c9e0
    753e0260c949:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260c950:	00 
    753e0260c951:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e0260c958:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260c95f:	00 
    753e0260c960:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260c967:	00 01 00 
    753e0260c96a:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260c971:	00 00 00 
    753e0260c974:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260c97b:	00 00 00 
    753e0260c97e:	31 c0                	xor    eax,eax
    753e0260c980:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260c987:	5c 00 00 
    753e0260c98a:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260c98f:	45 31 c0             	xor    r8d,r8d
    753e0260c992:	ff d0                	call   rax
    753e0260c994:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260c99b:	00 
    753e0260c99c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260c9a2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260c9a8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260c9ae:	be 0e 00 00 00       	mov    esi,0xe
    753e0260c9b3:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260c9b8:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260c9bf:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260c9c6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260c9cd:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260c9d4:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260c9db:	e9 db 0c 00 00       	jmp    0x753e0260d6bb
    753e0260c9e0:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260c9e7:	00 
    753e0260c9e8:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e0260c9ef:	c1 e9 0c             	shr    ecx,0xc
    753e0260c9f2:	89 c9                	mov    ecx,ecx
    753e0260c9f4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260c9f8:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    753e0260c9ff:	00 
    753e0260ca00:	48 83 f8 00          	cmp    rax,0x0
    753e0260ca04:	74 23                	je     0x753e0260ca29
    753e0260ca06:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    753e0260ca0d:	00 
    753e0260ca0e:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e0260ca15:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260ca1b:	89 c9                	mov    ecx,ecx
    753e0260ca1d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260ca20:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    753e0260ca27:	eb 5d                	jmp    0x753e0260ca86
    753e0260ca29:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ca30:	00 
    753e0260ca31:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    753e0260ca38:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260ca3f:	00 
    753e0260ca40:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260ca47:	00 01 00 
    753e0260ca4a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260ca51:	00 00 00 
    753e0260ca54:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260ca5b:	00 00 00 
    753e0260ca5e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260ca65:	5c 00 00 
    753e0260ca68:	ff d0                	call   rax
    753e0260ca6a:	89 c1                	mov    ecx,eax
    753e0260ca6c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ca73:	00 
    753e0260ca74:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    753e0260ca7b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260ca82:	75 32                	jne    0x753e0260cab6
    753e0260ca84:	eb 7c                	jmp    0x753e0260cb02
    753e0260ca86:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    753e0260ca8d:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260ca94:	00 
    753e0260ca95:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    753e0260ca9c:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    753e0260ca9f:	83 c0 04             	add    eax,0x4
    753e0260caa2:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e0260caa9:	83 e0 03             	and    eax,0x3
    753e0260caac:	83 f8 00             	cmp    eax,0x0
    753e0260caaf:	75 64                	jne    0x753e0260cb15
    753e0260cab1:	e9 f6 00 00 00       	jmp    0x753e0260cbac
    753e0260cab6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cabd:	00 
    753e0260cabe:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260cac4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260caca:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260cad0:	be 0e 00 00 00       	mov    esi,0xe
    753e0260cad5:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260cada:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260cae1:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260cae8:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260caef:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260caf6:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260cafd:	e9 b9 0b 00 00       	jmp    0x753e0260d6bb
    753e0260cb02:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    753e0260cb09:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    753e0260cb10:	e9 71 ff ff ff       	jmp    0x753e0260ca86
    753e0260cb15:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260cb1c:	00 
    753e0260cb1d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e0260cb24:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260cb2b:	00 
    753e0260cb2c:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260cb33:	00 01 00 
    753e0260cb36:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260cb3d:	00 00 00 
    753e0260cb40:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260cb47:	00 00 00 
    753e0260cb4a:	31 c0                	xor    eax,eax
    753e0260cb4c:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260cb53:	5c 00 00 
    753e0260cb56:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260cb5b:	45 31 c0             	xor    r8d,r8d
    753e0260cb5e:	ff d0                	call   rax
    753e0260cb60:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cb67:	00 
    753e0260cb68:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260cb6e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260cb74:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260cb7a:	be 0e 00 00 00       	mov    esi,0xe
    753e0260cb7f:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260cb84:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260cb8b:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260cb92:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260cb99:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260cba0:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260cba7:	e9 0f 0b 00 00       	jmp    0x753e0260d6bb
    753e0260cbac:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260cbb3:	00 
    753e0260cbb4:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e0260cbbb:	c1 e9 0c             	shr    ecx,0xc
    753e0260cbbe:	89 c9                	mov    ecx,ecx
    753e0260cbc0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260cbc4:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    753e0260cbcb:	00 
    753e0260cbcc:	48 83 f8 00          	cmp    rax,0x0
    753e0260cbd0:	74 23                	je     0x753e0260cbf5
    753e0260cbd2:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e0260cbd9:	00 
    753e0260cbda:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e0260cbe1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260cbe7:	89 c9                	mov    ecx,ecx
    753e0260cbe9:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260cbec:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e0260cbf3:	eb 5d                	jmp    0x753e0260cc52
    753e0260cbf5:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cbfc:	00 
    753e0260cbfd:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    753e0260cc04:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260cc0b:	00 
    753e0260cc0c:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260cc13:	00 01 00 
    753e0260cc16:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260cc1d:	00 00 00 
    753e0260cc20:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260cc27:	00 00 00 
    753e0260cc2a:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260cc31:	5c 00 00 
    753e0260cc34:	ff d0                	call   rax
    753e0260cc36:	89 c1                	mov    ecx,eax
    753e0260cc38:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cc3f:	00 
    753e0260cc40:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    753e0260cc47:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260cc4e:	75 32                	jne    0x753e0260cc82
    753e0260cc50:	eb 7c                	jmp    0x753e0260ccce
    753e0260cc52:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    753e0260cc59:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260cc60:	00 
    753e0260cc61:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    753e0260cc68:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    753e0260cc6b:	83 c0 04             	add    eax,0x4
    753e0260cc6e:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    753e0260cc75:	83 e0 03             	and    eax,0x3
    753e0260cc78:	83 f8 00             	cmp    eax,0x0
    753e0260cc7b:	75 64                	jne    0x753e0260cce1
    753e0260cc7d:	e9 f6 00 00 00       	jmp    0x753e0260cd78
    753e0260cc82:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cc89:	00 
    753e0260cc8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260cc90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260cc96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260cc9c:	be 0e 00 00 00       	mov    esi,0xe
    753e0260cca1:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260cca6:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260ccad:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260ccb4:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260ccbb:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260ccc2:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260ccc9:	e9 ed 09 00 00       	jmp    0x753e0260d6bb
    753e0260ccce:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    753e0260ccd5:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e0260ccdc:	e9 71 ff ff ff       	jmp    0x753e0260cc52
    753e0260cce1:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260cce8:	00 
    753e0260cce9:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260ccf0:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260ccf7:	00 
    753e0260ccf8:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260ccff:	00 01 00 
    753e0260cd02:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260cd09:	00 00 00 
    753e0260cd0c:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260cd13:	00 00 00 
    753e0260cd16:	31 c0                	xor    eax,eax
    753e0260cd18:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260cd1f:	5c 00 00 
    753e0260cd22:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260cd27:	45 31 c0             	xor    r8d,r8d
    753e0260cd2a:	ff d0                	call   rax
    753e0260cd2c:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cd33:	00 
    753e0260cd34:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260cd3a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260cd40:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260cd46:	be 0e 00 00 00       	mov    esi,0xe
    753e0260cd4b:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260cd50:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260cd57:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260cd5e:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260cd65:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260cd6c:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260cd73:	e9 43 09 00 00       	jmp    0x753e0260d6bb
    753e0260cd78:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260cd7f:	00 
    753e0260cd80:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260cd87:	c1 e9 0c             	shr    ecx,0xc
    753e0260cd8a:	89 c9                	mov    ecx,ecx
    753e0260cd8c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260cd90:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    753e0260cd97:	00 
    753e0260cd98:	48 83 f8 00          	cmp    rax,0x0
    753e0260cd9c:	74 23                	je     0x753e0260cdc1
    753e0260cd9e:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e0260cda5:	00 
    753e0260cda6:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260cdad:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260cdb3:	89 c9                	mov    ecx,ecx
    753e0260cdb5:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260cdb8:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e0260cdbf:	eb 5d                	jmp    0x753e0260ce1e
    753e0260cdc1:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cdc8:	00 
    753e0260cdc9:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    753e0260cdd0:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260cdd7:	00 
    753e0260cdd8:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260cddf:	00 01 00 
    753e0260cde2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260cde9:	00 00 00 
    753e0260cdec:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260cdf3:	00 00 00 
    753e0260cdf6:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260cdfd:	5c 00 00 
    753e0260ce00:	ff d0                	call   rax
    753e0260ce02:	89 c1                	mov    ecx,eax
    753e0260ce04:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ce0b:	00 
    753e0260ce0c:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    753e0260ce13:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260ce1a:	75 32                	jne    0x753e0260ce4e
    753e0260ce1c:	eb 7c                	jmp    0x753e0260ce9a
    753e0260ce1e:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    753e0260ce25:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260ce2c:	00 
    753e0260ce2d:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    753e0260ce34:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    753e0260ce37:	83 c0 04             	add    eax,0x4
    753e0260ce3a:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    753e0260ce41:	83 e0 03             	and    eax,0x3
    753e0260ce44:	83 f8 00             	cmp    eax,0x0
    753e0260ce47:	75 64                	jne    0x753e0260cead
    753e0260ce49:	e9 f6 00 00 00       	jmp    0x753e0260cf44
    753e0260ce4e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ce55:	00 
    753e0260ce56:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260ce5c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260ce62:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260ce68:	be 0e 00 00 00       	mov    esi,0xe
    753e0260ce6d:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260ce72:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260ce79:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260ce80:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260ce87:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260ce8e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260ce95:	e9 21 08 00 00       	jmp    0x753e0260d6bb
    753e0260ce9a:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    753e0260cea1:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e0260cea8:	e9 71 ff ff ff       	jmp    0x753e0260ce1e
    753e0260cead:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260ceb4:	00 
    753e0260ceb5:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260cebc:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260cec3:	00 
    753e0260cec4:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260cecb:	00 01 00 
    753e0260cece:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260ced5:	00 00 00 
    753e0260ced8:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260cedf:	00 00 00 
    753e0260cee2:	31 c0                	xor    eax,eax
    753e0260cee4:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260ceeb:	5c 00 00 
    753e0260ceee:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260cef3:	45 31 c0             	xor    r8d,r8d
    753e0260cef6:	ff d0                	call   rax
    753e0260cef8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260ceff:	00 
    753e0260cf00:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260cf06:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260cf0c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260cf12:	be 0e 00 00 00       	mov    esi,0xe
    753e0260cf17:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260cf1c:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260cf23:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260cf2a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260cf31:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260cf38:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260cf3f:	e9 77 07 00 00       	jmp    0x753e0260d6bb
    753e0260cf44:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260cf4b:	00 
    753e0260cf4c:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260cf53:	c1 e9 0c             	shr    ecx,0xc
    753e0260cf56:	89 c9                	mov    ecx,ecx
    753e0260cf58:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260cf5c:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e0260cf63:	00 
    753e0260cf64:	48 83 f8 00          	cmp    rax,0x0
    753e0260cf68:	74 20                	je     0x753e0260cf8a
    753e0260cf6a:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e0260cf71:	00 
    753e0260cf72:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260cf79:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260cf7f:	89 c9                	mov    ecx,ecx
    753e0260cf81:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260cf84:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e0260cf88:	eb 5a                	jmp    0x753e0260cfe4
    753e0260cf8a:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cf91:	00 
    753e0260cf92:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    753e0260cf99:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260cfa0:	00 
    753e0260cfa1:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260cfa8:	00 01 00 
    753e0260cfab:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260cfb2:	00 00 00 
    753e0260cfb5:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260cfbc:	00 00 00 
    753e0260cfbf:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260cfc6:	5c 00 00 
    753e0260cfc9:	ff d0                	call   rax
    753e0260cfcb:	89 c1                	mov    ecx,eax
    753e0260cfcd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260cfd4:	00 
    753e0260cfd5:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    753e0260cfd9:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260cfe0:	75 2c                	jne    0x753e0260d00e
    753e0260cfe2:	eb 76                	jmp    0x753e0260d05a
    753e0260cfe4:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    753e0260cfeb:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260cff2:	00 
    753e0260cff3:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    753e0260cff7:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    753e0260cffa:	83 c0 04             	add    eax,0x4
    753e0260cffd:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    753e0260d001:	83 e0 03             	and    eax,0x3
    753e0260d004:	83 f8 00             	cmp    eax,0x0
    753e0260d007:	75 5b                	jne    0x753e0260d064
    753e0260d009:	e9 ea 00 00 00       	jmp    0x753e0260d0f8
    753e0260d00e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d015:	00 
    753e0260d016:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d01c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d022:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d028:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d02d:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d032:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d039:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d040:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d047:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d04e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d055:	e9 61 06 00 00       	jmp    0x753e0260d6bb
    753e0260d05a:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    753e0260d05e:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e0260d062:	eb 80                	jmp    0x753e0260cfe4
    753e0260d064:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260d06b:	00 
    753e0260d06c:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e0260d070:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260d077:	00 
    753e0260d078:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260d07f:	00 01 00 
    753e0260d082:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260d089:	00 00 00 
    753e0260d08c:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260d093:	00 00 00 
    753e0260d096:	31 c0                	xor    eax,eax
    753e0260d098:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260d09f:	5c 00 00 
    753e0260d0a2:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260d0a7:	45 31 c0             	xor    r8d,r8d
    753e0260d0aa:	ff d0                	call   rax
    753e0260d0ac:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d0b3:	00 
    753e0260d0b4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d0ba:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d0c0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d0c6:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d0cb:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d0d0:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d0d7:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d0de:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d0e5:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d0ec:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d0f3:	e9 c3 05 00 00       	jmp    0x753e0260d6bb
    753e0260d0f8:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260d0ff:	00 
    753e0260d100:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e0260d104:	c1 e9 0c             	shr    ecx,0xc
    753e0260d107:	89 c9                	mov    ecx,ecx
    753e0260d109:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260d10d:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753e0260d112:	48 83 f8 00          	cmp    rax,0x0
    753e0260d116:	74 1a                	je     0x753e0260d132
    753e0260d118:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e0260d11d:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e0260d121:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260d127:	89 c9                	mov    ecx,ecx
    753e0260d129:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260d12c:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e0260d130:	eb 57                	jmp    0x753e0260d189
    753e0260d132:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d139:	00 
    753e0260d13a:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    753e0260d13e:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260d145:	00 
    753e0260d146:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260d14d:	00 01 00 
    753e0260d150:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260d157:	00 00 00 
    753e0260d15a:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260d161:	00 00 00 
    753e0260d164:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260d16b:	5c 00 00 
    753e0260d16e:	ff d0                	call   rax
    753e0260d170:	89 c1                	mov    ecx,eax
    753e0260d172:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d179:	00 
    753e0260d17a:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    753e0260d17e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260d185:	75 29                	jne    0x753e0260d1b0
    753e0260d187:	eb 73                	jmp    0x753e0260d1fc
    753e0260d189:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    753e0260d18d:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260d194:	00 
    753e0260d195:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    753e0260d199:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    753e0260d19c:	83 c0 04             	add    eax,0x4
    753e0260d19f:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    753e0260d1a3:	83 e0 03             	and    eax,0x3
    753e0260d1a6:	83 f8 00             	cmp    eax,0x0
    753e0260d1a9:	75 5b                	jne    0x753e0260d206
    753e0260d1ab:	e9 ea 00 00 00       	jmp    0x753e0260d29a
    753e0260d1b0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d1b7:	00 
    753e0260d1b8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d1be:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d1c4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d1ca:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d1cf:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d1d4:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d1db:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d1e2:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d1e9:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d1f0:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d1f7:	e9 bf 04 00 00       	jmp    0x753e0260d6bb
    753e0260d1fc:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    753e0260d200:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e0260d204:	eb 83                	jmp    0x753e0260d189
    753e0260d206:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260d20d:	00 
    753e0260d20e:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e0260d212:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260d219:	00 
    753e0260d21a:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260d221:	00 01 00 
    753e0260d224:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260d22b:	00 00 00 
    753e0260d22e:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260d235:	00 00 00 
    753e0260d238:	31 c0                	xor    eax,eax
    753e0260d23a:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260d241:	5c 00 00 
    753e0260d244:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260d249:	45 31 c0             	xor    r8d,r8d
    753e0260d24c:	ff d0                	call   rax
    753e0260d24e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d255:	00 
    753e0260d256:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d25c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d262:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d268:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d26d:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d272:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d279:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d280:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d287:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d28e:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d295:	e9 21 04 00 00       	jmp    0x753e0260d6bb
    753e0260d29a:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260d2a1:	00 
    753e0260d2a2:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e0260d2a6:	c1 e9 0c             	shr    ecx,0xc
    753e0260d2a9:	89 c9                	mov    ecx,ecx
    753e0260d2ab:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260d2af:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    753e0260d2b4:	48 83 f8 00          	cmp    rax,0x0
    753e0260d2b8:	74 1a                	je     0x753e0260d2d4
    753e0260d2ba:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    753e0260d2bf:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e0260d2c3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260d2c9:	89 c9                	mov    ecx,ecx
    753e0260d2cb:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260d2ce:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e0260d2d2:	eb 57                	jmp    0x753e0260d32b
    753e0260d2d4:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d2db:	00 
    753e0260d2dc:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    753e0260d2e0:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260d2e7:	00 
    753e0260d2e8:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260d2ef:	00 01 00 
    753e0260d2f2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260d2f9:	00 00 00 
    753e0260d2fc:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260d303:	00 00 00 
    753e0260d306:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260d30d:	5c 00 00 
    753e0260d310:	ff d0                	call   rax
    753e0260d312:	89 c1                	mov    ecx,eax
    753e0260d314:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d31b:	00 
    753e0260d31c:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e0260d320:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260d327:	75 29                	jne    0x753e0260d352
    753e0260d329:	eb 73                	jmp    0x753e0260d39e
    753e0260d32b:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    753e0260d32f:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260d336:	00 
    753e0260d337:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    753e0260d33b:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    753e0260d33e:	83 c0 04             	add    eax,0x4
    753e0260d341:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e0260d345:	83 e0 03             	and    eax,0x3
    753e0260d348:	83 f8 00             	cmp    eax,0x0
    753e0260d34b:	75 5b                	jne    0x753e0260d3a8
    753e0260d34d:	e9 ea 00 00 00       	jmp    0x753e0260d43c
    753e0260d352:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d359:	00 
    753e0260d35a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d360:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d366:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d36c:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d371:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d376:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d37d:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d384:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d38b:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d392:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d399:	e9 1d 03 00 00       	jmp    0x753e0260d6bb
    753e0260d39e:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e0260d3a2:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e0260d3a6:	eb 83                	jmp    0x753e0260d32b
    753e0260d3a8:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260d3af:	00 
    753e0260d3b0:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260d3b4:	48 8b b4 24 70 01 00 	mov    rsi,QWORD PTR [rsp+0x170]
    753e0260d3bb:	00 
    753e0260d3bc:	c7 87 bc 00 00 00 bc 	mov    DWORD PTR [rdi+0xbc],0x100bc
    753e0260d3c3:	00 01 00 
    753e0260d3c6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260d3cd:	00 00 00 
    753e0260d3d0:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e0260d3d7:	00 00 00 
    753e0260d3da:	31 c0                	xor    eax,eax
    753e0260d3dc:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260d3e3:	5c 00 00 
    753e0260d3e6:	ba bc 00 01 00       	mov    edx,0x100bc
    753e0260d3eb:	45 31 c0             	xor    r8d,r8d
    753e0260d3ee:	ff d0                	call   rax
    753e0260d3f0:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d3f7:	00 
    753e0260d3f8:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d3fe:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d404:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d40a:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d40f:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d414:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d41b:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d422:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d429:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d430:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d437:	e9 7f 02 00 00       	jmp    0x753e0260d6bb
    753e0260d43c:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e0260d443:	00 
    753e0260d444:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260d448:	c1 e9 0c             	shr    ecx,0xc
    753e0260d44b:	89 c9                	mov    ecx,ecx
    753e0260d44d:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260d451:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e0260d456:	48 83 f8 00          	cmp    rax,0x0
    753e0260d45a:	74 1a                	je     0x753e0260d476
    753e0260d45c:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e0260d461:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260d465:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260d46b:	89 c9                	mov    ecx,ecx
    753e0260d46d:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260d470:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e0260d474:	eb 57                	jmp    0x753e0260d4cd
    753e0260d476:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d47d:	00 
    753e0260d47e:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e0260d482:	48 8b bc 24 70 01 00 	mov    rdi,QWORD PTR [rsp+0x170]
    753e0260d489:	00 
    753e0260d48a:	c7 80 bc 00 00 00 bc 	mov    DWORD PTR [rax+0xbc],0x100bc
    753e0260d491:	00 01 00 
    753e0260d494:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260d49b:	00 00 00 
    753e0260d49e:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e0260d4a5:	00 00 00 
    753e0260d4a8:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260d4af:	5c 00 00 
    753e0260d4b2:	ff d0                	call   rax
    753e0260d4b4:	89 c1                	mov    ecx,eax
    753e0260d4b6:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d4bd:	00 
    753e0260d4be:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    753e0260d4c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260d4c9:	75 1d                	jne    0x753e0260d4e8
    753e0260d4cb:	eb 67                	jmp    0x753e0260d534
    753e0260d4cd:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d4d4:	00 
    753e0260d4d5:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260d4d9:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    753e0260d4dd:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    753e0260d4e0:	83 c1 04             	add    ecx,0x4
    753e0260d4e3:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e0260d4e6:	eb 56                	jmp    0x753e0260d53e
    753e0260d4e8:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d4ef:	00 
    753e0260d4f0:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d4f6:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d4fc:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d502:	be 0e 00 00 00       	mov    esi,0xe
    753e0260d507:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d50c:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d513:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d51a:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d521:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d528:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d52f:	e9 87 01 00 00       	jmp    0x753e0260d6bb
    753e0260d534:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    753e0260d538:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e0260d53c:	eb 8f                	jmp    0x753e0260d4cd
    753e0260d53e:	eb 00                	jmp    0x753e0260d540
    753e0260d540:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    753e0260d547:	83 e0 01             	and    eax,0x1
    753e0260d54a:	83 f8 00             	cmp    eax,0x0
    753e0260d54d:	75 3d                	jne    0x753e0260d58c
    753e0260d54f:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    753e0260d556:	be 0f 00 00 00       	mov    esi,0xf
    753e0260d55b:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d560:	b0 01                	mov    al,0x1
    753e0260d562:	89 d7                	mov    edi,edx
    753e0260d564:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d56b:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d572:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d579:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d580:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d587:	e9 2f 01 00 00       	jmp    0x753e0260d6bb
    753e0260d58c:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
    753e0260d593:	00 
    753e0260d594:	48 8b 94 24 70 01 00 	mov    rdx,QWORD PTR [rsp+0x170]
    753e0260d59b:	00 
    753e0260d59c:	c7 87 bc 00 00 00 be 	mov    DWORD PTR [rdi+0xbc],0x100be
    753e0260d5a3:	00 01 00 
    753e0260d5a6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260d5ad:	00 00 00 
    753e0260d5b0:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e0260d5b7:	00 00 00 
    753e0260d5ba:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e0260d5c1:	5c 00 00 
    753e0260d5c4:	be 2a 00 00 00       	mov    esi,0x2a
    753e0260d5c9:	ff d0                	call   rax
    753e0260d5cb:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d5d2:	00 
    753e0260d5d3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260d5d9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d5df:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260d5e5:	be 0f 00 00 00       	mov    esi,0xf
    753e0260d5ea:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260d5ef:	89 bc 24 48 01 00 00 	mov    DWORD PTR [rsp+0x148],edi
    753e0260d5f6:	89 b4 24 4c 01 00 00 	mov    DWORD PTR [rsp+0x14c],esi
    753e0260d5fd:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e0260d604:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e0260d60b:	88 84 24 5b 01 00 00 	mov    BYTE PTR [rsp+0x15b],al
    753e0260d612:	e9 a4 00 00 00       	jmp    0x753e0260d6bb
    753e0260d617:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d61e:	00 
    753e0260d61f:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e0260d626:	e9 82 01 00 00       	jmp    0x753e0260d7ad
    753e0260d62b:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    753e0260d632:	00 
    753e0260d633:	48 89 c1             	mov    rcx,rax
    753e0260d636:	48 81 c1 20 04 08 00 	add    rcx,0x80420
    753e0260d63d:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e0260d642:	81 b8 20 04 08 00 84 	cmp    DWORD PTR [rax+0x80420],0x10084
    753e0260d649:	00 01 00 
    753e0260d64c:	74 32                	je     0x753e0260d680
    753e0260d64e:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d655:	00 
    753e0260d656:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    753e0260d65d:	00 01 00 
    753e0260d660:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260d667:	00 00 00 
    753e0260d66a:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    753e0260d671:	00 00 00 
    753e0260d674:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260d67b:	e9 2d 01 00 00       	jmp    0x753e0260d7ad
    753e0260d680:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    753e0260d687:	00 
    753e0260d688:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    753e0260d68f:	00 
    753e0260d690:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e0260d695:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    753e0260d69c:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10084
    753e0260d6a3:	84 00 01 00 
    753e0260d6a7:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260d6ae:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260d6b2:	48 81 c4 98 01 00 00 	add    rsp,0x198
    753e0260d6b9:	ff e0                	jmp    rax
    753e0260d6bb:	48 8b 8c 24 78 01 00 	mov    rcx,QWORD PTR [rsp+0x178]
    753e0260d6c2:	00 
    753e0260d6c3:	8b 94 24 48 01 00 00 	mov    edx,DWORD PTR [rsp+0x148]
    753e0260d6ca:	8b 84 24 4c 01 00 00 	mov    eax,DWORD PTR [rsp+0x14c]
    753e0260d6d1:	8b b4 24 50 01 00 00 	mov    esi,DWORD PTR [rsp+0x150]
    753e0260d6d8:	8b bc 24 54 01 00 00 	mov    edi,DWORD PTR [rsp+0x154]
    753e0260d6df:	8a 9c 24 5b 01 00 00 	mov    bl,BYTE PTR [rsp+0x15b]
    753e0260d6e6:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    753e0260d6ea:	89 c3                	mov    ebx,eax
    753e0260d6ec:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    753e0260d6f0:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    753e0260d6f4:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    753e0260d6f8:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    753e0260d6fc:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260d702:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e0260d706:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260d70c:	73 2d                	jae    0x753e0260d73b
    753e0260d70e:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    753e0260d715:	00 
    753e0260d716:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e0260d71a:	89 d1                	mov    ecx,edx
    753e0260d71c:	c1 e9 01             	shr    ecx,0x1
    753e0260d71f:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260d725:	89 c9                	mov    ecx,ecx
    753e0260d727:	48 c1 e1 04          	shl    rcx,0x4
    753e0260d72b:	48 89 c6             	mov    rsi,rax
    753e0260d72e:	48 01 ce             	add    rsi,rcx
    753e0260d731:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e0260d736:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e0260d739:	74 32                	je     0x753e0260d76d
    753e0260d73b:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
    753e0260d742:	00 
    753e0260d743:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    753e0260d747:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e0260d74b:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    753e0260d74f:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    753e0260d753:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e0260d759:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e0260d75f:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e0260d765:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e0260d76b:	eb 40                	jmp    0x753e0260d7ad
    753e0260d76d:	4c 8b b4 24 70 01 00 	mov    r14,QWORD PTR [rsp+0x170]
    753e0260d774:	00 
    753e0260d775:	4c 8b ac 24 78 01 00 	mov    r13,QWORD PTR [rsp+0x178]
    753e0260d77c:	00 
    753e0260d77d:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e0260d782:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    753e0260d786:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e0260d78a:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e0260d791:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260d798:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260d79f:	00 
    753e0260d7a0:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260d7a4:	48 81 c4 98 01 00 00 	add    rsp,0x198
    753e0260d7ab:	ff e0                	jmp    rax
    753e0260d7ad:	48 81 c4 98 01 00 00 	add    rsp,0x198
    753e0260d7b4:	c2 08 00             	ret    0x8
