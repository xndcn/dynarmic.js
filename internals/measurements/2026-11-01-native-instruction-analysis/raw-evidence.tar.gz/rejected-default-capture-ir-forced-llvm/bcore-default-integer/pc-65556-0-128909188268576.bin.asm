
build-native-instruction-analysis/capture/bcore-default-integer/pc-65556-0-128909188268576.bin:     file format binary


Disassembly of section .data:

0000753e02600220 <.data>:
    753e02600220:	48 81 ec 18 02 00 00 	sub    rsp,0x218
    753e02600227:	4c 89 b4 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],r14
    753e0260022e:	00 
    753e0260022f:	4c 89 ac 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],r13
    753e02600236:	00 
    753e02600237:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260023e:	48 89 84 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rax
    753e02600245:	00 
    753e02600246:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e0260024d:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
    753e02600254:	00 
    753e02600255:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260025c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
    753e02600263:	00 
    753e02600264:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260026b:	00 
    753e0260026c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02600272:	83 fa 00             	cmp    edx,0x0
    753e02600275:	0f 94 c0             	sete   al
    753e02600278:	81 ea 14 00 01 00    	sub    edx,0x10014
    753e0260027e:	83 fa 2a             	cmp    edx,0x2a
    753e02600281:	0f 97 c2             	seta   dl
    753e02600284:	08 d0                	or     al,dl
    753e02600286:	24 01                	and    al,0x1
    753e02600288:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260028e:	83 fa 00             	cmp    edx,0x0
    753e02600291:	0f 94 c1             	sete   cl
    753e02600294:	81 ea 14 00 01 00    	sub    edx,0x10014
    753e0260029a:	83 fa 2a             	cmp    edx,0x2a
    753e0260029d:	0f 97 c2             	seta   dl
    753e026002a0:	08 d1                	or     cl,dl
    753e026002a2:	20 c8                	and    al,cl
    753e026002a4:	a8 01                	test   al,0x1
    753e026002a6:	75 05                	jne    0x753e026002ad
    753e026002a8:	e9 19 27 00 00       	jmp    0x753e026029c6
    753e026002ad:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026002b4:	00 
    753e026002b5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e026002bc:	48 89 c8             	mov    rax,rcx
    753e026002bf:	48 05 00 00 10 00    	add    rax,0x100000
    753e026002c5:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
    753e026002cc:	00 
    753e026002cd:	8b 81 04 00 10 00    	mov    eax,DWORD PTR [rcx+0x100004]
    753e026002d3:	83 c0 01             	add    eax,0x1
    753e026002d6:	89 81 04 00 10 00    	mov    DWORD PTR [rcx+0x100004],eax
    753e026002dc:	3d 30 75 00 00       	cmp    eax,0x7530
    753e026002e1:	75 4c                	jne    0x753e0260032f
    753e026002e3:	48 8b 8c 24 e8 01 00 	mov    rcx,QWORD PTR [rsp+0x1e8]
    753e026002ea:	00 
    753e026002eb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e026002f1:	89 84 24 e4 01 00 00 	mov    DWORD PTR [rsp+0x1e4],eax
    753e026002f8:	89 c2                	mov    edx,eax
    753e026002fa:	83 c2 01             	add    edx,0x1
    753e026002fd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02600303:	3d 00 01 00 00       	cmp    eax,0x100
    753e02600308:	73 23                	jae    0x753e0260032d
    753e0260030a:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
    753e02600311:	00 
    753e02600312:	8b 8c 24 e4 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1e4]
    753e02600319:	89 c9                	mov    ecx,ecx
    753e0260031b:	48 c1 e1 02          	shl    rcx,0x2
    753e0260031f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02600326:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    753e0260032d:	eb 00                	jmp    0x753e0260032f
    753e0260032f:	eb 00                	jmp    0x753e02600331
    753e02600331:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600338:	00 
    753e02600339:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    753e0260033c:	83 e8 04             	sub    eax,0x4
    753e0260033f:	89 84 24 dc 01 00 00 	mov    DWORD PTR [rsp+0x1dc],eax
    753e02600346:	8b 49 10             	mov    ecx,DWORD PTR [rcx+0x10]
    753e02600349:	89 8c 24 e0 01 00 00 	mov    DWORD PTR [rsp+0x1e0],ecx
    753e02600350:	83 e0 03             	and    eax,0x3
    753e02600353:	83 f8 00             	cmp    eax,0x0
    753e02600356:	0f 84 8e 00 00 00    	je     0x753e026003ea
    753e0260035c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600363:	00 
    753e02600364:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e0260036b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600372:	00 
    753e02600373:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260037a:	00 00 00 
    753e0260037d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600384:	00 00 00 
    753e02600387:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260038e:	5c 00 00 
    753e02600391:	ba 14 00 01 00       	mov    edx,0x10014
    753e02600396:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260039c:	ff d0                	call   rax
    753e0260039e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026003a5:	00 
    753e026003a6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026003ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026003b2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026003b8:	be 01 00 00 00       	mov    esi,0x1
    753e026003bd:	b9 02 00 00 00       	mov    ecx,0x2
    753e026003c2:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026003c9:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026003d0:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026003d7:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026003de:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026003e5:	e9 80 26 00 00       	jmp    0x753e02602a6a
    753e026003ea:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026003f1:	00 
    753e026003f2:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e026003f9:	c1 e9 0c             	shr    ecx,0xc
    753e026003fc:	89 c9                	mov    ecx,ecx
    753e026003fe:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02600402:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
    753e02600409:	00 
    753e0260040a:	48 83 f8 00          	cmp    rax,0x0
    753e0260040e:	74 23                	je     0x753e02600433
    753e02600410:	48 8b 84 24 c0 01 00 	mov    rax,QWORD PTR [rsp+0x1c0]
    753e02600417:	00 
    753e02600418:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    753e0260041f:	8b 8c 24 dc 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1dc]
    753e02600426:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260042c:	89 c9                	mov    ecx,ecx
    753e0260042e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02600431:	eb 51                	jmp    0x753e02600484
    753e02600433:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260043a:	00 
    753e0260043b:	8b 94 24 e0 01 00 00 	mov    edx,DWORD PTR [rsp+0x1e0]
    753e02600442:	8b b4 24 dc 01 00 00 	mov    esi,DWORD PTR [rsp+0x1dc]
    753e02600449:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02600450:	00 
    753e02600451:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02600458:	00 00 00 
    753e0260045b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600462:	00 00 00 
    753e02600465:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260046c:	5c 00 00 
    753e0260046f:	ff d0                	call   rax
    753e02600471:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600478:	00 
    753e02600479:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600480:	75 32                	jne    0x753e026004b4
    753e02600482:	eb 7c                	jmp    0x753e02600500
    753e02600484:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260048b:	00 
    753e0260048c:	8b 84 24 dc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1dc]
    753e02600493:	83 e8 04             	sub    eax,0x4
    753e02600496:	89 84 24 b8 01 00 00 	mov    DWORD PTR [rsp+0x1b8],eax
    753e0260049d:	8b 49 14             	mov    ecx,DWORD PTR [rcx+0x14]
    753e026004a0:	89 8c 24 bc 01 00 00 	mov    DWORD PTR [rsp+0x1bc],ecx
    753e026004a7:	83 e0 03             	and    eax,0x3
    753e026004aa:	83 f8 00             	cmp    eax,0x0
    753e026004ad:	75 53                	jne    0x753e02600502
    753e026004af:	e9 dc 00 00 00       	jmp    0x753e02600590
    753e026004b4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026004bb:	00 
    753e026004bc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026004c2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026004c8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026004ce:	be 01 00 00 00       	mov    esi,0x1
    753e026004d3:	b9 02 00 00 00       	mov    ecx,0x2
    753e026004d8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026004df:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026004e6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026004ed:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026004f4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026004fb:	e9 6a 25 00 00       	jmp    0x753e02602a6a
    753e02600500:	eb 82                	jmp    0x753e02600484
    753e02600502:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600509:	00 
    753e0260050a:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e02600511:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600518:	00 
    753e02600519:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02600520:	00 00 00 
    753e02600523:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e0260052a:	00 00 00 
    753e0260052d:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02600534:	5c 00 00 
    753e02600537:	ba 14 00 01 00       	mov    edx,0x10014
    753e0260053c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02600542:	ff d0                	call   rax
    753e02600544:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260054b:	00 
    753e0260054c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600552:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600558:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260055e:	be 01 00 00 00       	mov    esi,0x1
    753e02600563:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600568:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260056f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600576:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260057d:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600584:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260058b:	e9 da 24 00 00       	jmp    0x753e02602a6a
    753e02600590:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02600597:	00 
    753e02600598:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e0260059f:	c1 e9 0c             	shr    ecx,0xc
    753e026005a2:	89 c9                	mov    ecx,ecx
    753e026005a4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026005a8:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
    753e026005af:	00 
    753e026005b0:	48 83 f8 00          	cmp    rax,0x0
    753e026005b4:	74 23                	je     0x753e026005d9
    753e026005b6:	48 8b 84 24 b0 01 00 	mov    rax,QWORD PTR [rsp+0x1b0]
    753e026005bd:	00 
    753e026005be:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    753e026005c5:	8b 8c 24 b8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1b8]
    753e026005cc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026005d2:	89 c9                	mov    ecx,ecx
    753e026005d4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026005d7:	eb 51                	jmp    0x753e0260062a
    753e026005d9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026005e0:	00 
    753e026005e1:	8b 94 24 bc 01 00 00 	mov    edx,DWORD PTR [rsp+0x1bc]
    753e026005e8:	8b b4 24 b8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1b8]
    753e026005ef:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026005f6:	00 
    753e026005f7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026005fe:	00 00 00 
    753e02600601:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600608:	00 00 00 
    753e0260060b:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02600612:	5c 00 00 
    753e02600615:	ff d0                	call   rax
    753e02600617:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260061e:	00 
    753e0260061f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600626:	75 32                	jne    0x753e0260065a
    753e02600628:	eb 7c                	jmp    0x753e026006a6
    753e0260062a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600631:	00 
    753e02600632:	8b 84 24 b8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1b8]
    753e02600639:	83 e8 04             	sub    eax,0x4
    753e0260063c:	89 84 24 a8 01 00 00 	mov    DWORD PTR [rsp+0x1a8],eax
    753e02600643:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    753e02600646:	89 8c 24 ac 01 00 00 	mov    DWORD PTR [rsp+0x1ac],ecx
    753e0260064d:	83 e0 03             	and    eax,0x3
    753e02600650:	83 f8 00             	cmp    eax,0x0
    753e02600653:	75 53                	jne    0x753e026006a8
    753e02600655:	e9 dc 00 00 00       	jmp    0x753e02600736
    753e0260065a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600661:	00 
    753e02600662:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600668:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260066e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600674:	be 01 00 00 00       	mov    esi,0x1
    753e02600679:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260067e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600685:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260068c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600693:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260069a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026006a1:	e9 c4 23 00 00       	jmp    0x753e02602a6a
    753e026006a6:	eb 82                	jmp    0x753e0260062a
    753e026006a8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026006af:	00 
    753e026006b0:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e026006b7:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026006be:	00 
    753e026006bf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026006c6:	00 00 00 
    753e026006c9:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e026006d0:	00 00 00 
    753e026006d3:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026006da:	5c 00 00 
    753e026006dd:	ba 14 00 01 00       	mov    edx,0x10014
    753e026006e2:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026006e8:	ff d0                	call   rax
    753e026006ea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026006f1:	00 
    753e026006f2:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026006f8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026006fe:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600704:	be 01 00 00 00       	mov    esi,0x1
    753e02600709:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260070e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600715:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260071c:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600723:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260072a:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600731:	e9 34 23 00 00       	jmp    0x753e02602a6a
    753e02600736:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e0260073d:	00 
    753e0260073e:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e02600745:	c1 e9 0c             	shr    ecx,0xc
    753e02600748:	89 c9                	mov    ecx,ecx
    753e0260074a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260074e:	48 89 84 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rax
    753e02600755:	00 
    753e02600756:	48 83 f8 00          	cmp    rax,0x0
    753e0260075a:	74 23                	je     0x753e0260077f
    753e0260075c:	48 8b 84 24 a0 01 00 	mov    rax,QWORD PTR [rsp+0x1a0]
    753e02600763:	00 
    753e02600764:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    753e0260076b:	8b 8c 24 a8 01 00 00 	mov    ecx,DWORD PTR [rsp+0x1a8]
    753e02600772:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02600778:	89 c9                	mov    ecx,ecx
    753e0260077a:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260077d:	eb 51                	jmp    0x753e026007d0
    753e0260077f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600786:	00 
    753e02600787:	8b 94 24 ac 01 00 00 	mov    edx,DWORD PTR [rsp+0x1ac]
    753e0260078e:	8b b4 24 a8 01 00 00 	mov    esi,DWORD PTR [rsp+0x1a8]
    753e02600795:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e0260079c:	00 
    753e0260079d:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026007a4:	00 00 00 
    753e026007a7:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e026007ae:	00 00 00 
    753e026007b1:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026007b8:	5c 00 00 
    753e026007bb:	ff d0                	call   rax
    753e026007bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026007c4:	00 
    753e026007c5:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026007cc:	75 32                	jne    0x753e02600800
    753e026007ce:	eb 7c                	jmp    0x753e0260084c
    753e026007d0:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026007d7:	00 
    753e026007d8:	8b 84 24 a8 01 00 00 	mov    eax,DWORD PTR [rsp+0x1a8]
    753e026007df:	83 e8 04             	sub    eax,0x4
    753e026007e2:	89 84 24 98 01 00 00 	mov    DWORD PTR [rsp+0x198],eax
    753e026007e9:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    753e026007ec:	89 8c 24 9c 01 00 00 	mov    DWORD PTR [rsp+0x19c],ecx
    753e026007f3:	83 e0 03             	and    eax,0x3
    753e026007f6:	83 f8 00             	cmp    eax,0x0
    753e026007f9:	75 53                	jne    0x753e0260084e
    753e026007fb:	e9 dc 00 00 00       	jmp    0x753e026008dc
    753e02600800:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600807:	00 
    753e02600808:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260080e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600814:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260081a:	be 01 00 00 00       	mov    esi,0x1
    753e0260081f:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600824:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260082b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600832:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600839:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600840:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600847:	e9 1e 22 00 00       	jmp    0x753e02602a6a
    753e0260084c:	eb 82                	jmp    0x753e026007d0
    753e0260084e:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600855:	00 
    753e02600856:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e0260085d:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600864:	00 
    753e02600865:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260086c:	00 00 00 
    753e0260086f:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600876:	00 00 00 
    753e02600879:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02600880:	5c 00 00 
    753e02600883:	ba 14 00 01 00       	mov    edx,0x10014
    753e02600888:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260088e:	ff d0                	call   rax
    753e02600890:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600897:	00 
    753e02600898:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260089e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026008a4:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026008aa:	be 01 00 00 00       	mov    esi,0x1
    753e026008af:	b9 02 00 00 00       	mov    ecx,0x2
    753e026008b4:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026008bb:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026008c2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026008c9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026008d0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026008d7:	e9 8e 21 00 00       	jmp    0x753e02602a6a
    753e026008dc:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026008e3:	00 
    753e026008e4:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e026008eb:	c1 e9 0c             	shr    ecx,0xc
    753e026008ee:	89 c9                	mov    ecx,ecx
    753e026008f0:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026008f4:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
    753e026008fb:	00 
    753e026008fc:	48 83 f8 00          	cmp    rax,0x0
    753e02600900:	74 23                	je     0x753e02600925
    753e02600902:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
    753e02600909:	00 
    753e0260090a:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    753e02600911:	8b 8c 24 98 01 00 00 	mov    ecx,DWORD PTR [rsp+0x198]
    753e02600918:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260091e:	89 c9                	mov    ecx,ecx
    753e02600920:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02600923:	eb 51                	jmp    0x753e02600976
    753e02600925:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260092c:	00 
    753e0260092d:	8b 94 24 9c 01 00 00 	mov    edx,DWORD PTR [rsp+0x19c]
    753e02600934:	8b b4 24 98 01 00 00 	mov    esi,DWORD PTR [rsp+0x198]
    753e0260093b:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02600942:	00 
    753e02600943:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260094a:	00 00 00 
    753e0260094d:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600954:	00 00 00 
    753e02600957:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260095e:	5c 00 00 
    753e02600961:	ff d0                	call   rax
    753e02600963:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260096a:	00 
    753e0260096b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600972:	75 32                	jne    0x753e026009a6
    753e02600974:	eb 7c                	jmp    0x753e026009f2
    753e02600976:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260097d:	00 
    753e0260097e:	8b 84 24 98 01 00 00 	mov    eax,DWORD PTR [rsp+0x198]
    753e02600985:	83 e8 04             	sub    eax,0x4
    753e02600988:	89 84 24 88 01 00 00 	mov    DWORD PTR [rsp+0x188],eax
    753e0260098f:	8b 49 2c             	mov    ecx,DWORD PTR [rcx+0x2c]
    753e02600992:	89 8c 24 8c 01 00 00 	mov    DWORD PTR [rsp+0x18c],ecx
    753e02600999:	83 e0 03             	and    eax,0x3
    753e0260099c:	83 f8 00             	cmp    eax,0x0
    753e0260099f:	75 53                	jne    0x753e026009f4
    753e026009a1:	e9 dc 00 00 00       	jmp    0x753e02600a82
    753e026009a6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026009ad:	00 
    753e026009ae:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026009b4:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026009ba:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026009c0:	be 01 00 00 00       	mov    esi,0x1
    753e026009c5:	b9 02 00 00 00       	mov    ecx,0x2
    753e026009ca:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026009d1:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026009d8:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026009df:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026009e6:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026009ed:	e9 78 20 00 00       	jmp    0x753e02602a6a
    753e026009f2:	eb 82                	jmp    0x753e02600976
    753e026009f4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026009fb:	00 
    753e026009fc:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e02600a03:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600a0a:	00 
    753e02600a0b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02600a12:	00 00 00 
    753e02600a15:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600a1c:	00 00 00 
    753e02600a1f:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02600a26:	5c 00 00 
    753e02600a29:	ba 14 00 01 00       	mov    edx,0x10014
    753e02600a2e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02600a34:	ff d0                	call   rax
    753e02600a36:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600a3d:	00 
    753e02600a3e:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600a44:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600a4a:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600a50:	be 01 00 00 00       	mov    esi,0x1
    753e02600a55:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600a5a:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600a61:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600a68:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600a6f:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600a76:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600a7d:	e9 e8 1f 00 00       	jmp    0x753e02602a6a
    753e02600a82:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02600a89:	00 
    753e02600a8a:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e02600a91:	c1 e9 0c             	shr    ecx,0xc
    753e02600a94:	89 c9                	mov    ecx,ecx
    753e02600a96:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02600a9a:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
    753e02600aa1:	00 
    753e02600aa2:	48 83 f8 00          	cmp    rax,0x0
    753e02600aa6:	74 23                	je     0x753e02600acb
    753e02600aa8:	48 8b 84 24 80 01 00 	mov    rax,QWORD PTR [rsp+0x180]
    753e02600aaf:	00 
    753e02600ab0:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    753e02600ab7:	8b 8c 24 88 01 00 00 	mov    ecx,DWORD PTR [rsp+0x188]
    753e02600abe:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02600ac4:	89 c9                	mov    ecx,ecx
    753e02600ac6:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02600ac9:	eb 51                	jmp    0x753e02600b1c
    753e02600acb:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600ad2:	00 
    753e02600ad3:	8b 94 24 8c 01 00 00 	mov    edx,DWORD PTR [rsp+0x18c]
    753e02600ada:	8b b4 24 88 01 00 00 	mov    esi,DWORD PTR [rsp+0x188]
    753e02600ae1:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02600ae8:	00 
    753e02600ae9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02600af0:	00 00 00 
    753e02600af3:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600afa:	00 00 00 
    753e02600afd:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02600b04:	5c 00 00 
    753e02600b07:	ff d0                	call   rax
    753e02600b09:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600b10:	00 
    753e02600b11:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600b18:	75 32                	jne    0x753e02600b4c
    753e02600b1a:	eb 7c                	jmp    0x753e02600b98
    753e02600b1c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600b23:	00 
    753e02600b24:	8b 84 24 88 01 00 00 	mov    eax,DWORD PTR [rsp+0x188]
    753e02600b2b:	83 e8 04             	sub    eax,0x4
    753e02600b2e:	89 84 24 78 01 00 00 	mov    DWORD PTR [rsp+0x178],eax
    753e02600b35:	8b 49 30             	mov    ecx,DWORD PTR [rcx+0x30]
    753e02600b38:	89 8c 24 7c 01 00 00 	mov    DWORD PTR [rsp+0x17c],ecx
    753e02600b3f:	83 e0 03             	and    eax,0x3
    753e02600b42:	83 f8 00             	cmp    eax,0x0
    753e02600b45:	75 53                	jne    0x753e02600b9a
    753e02600b47:	e9 dc 00 00 00       	jmp    0x753e02600c28
    753e02600b4c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600b53:	00 
    753e02600b54:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600b5a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600b60:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600b66:	be 01 00 00 00       	mov    esi,0x1
    753e02600b6b:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600b70:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600b77:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600b7e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600b85:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600b8c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600b93:	e9 d2 1e 00 00       	jmp    0x753e02602a6a
    753e02600b98:	eb 82                	jmp    0x753e02600b1c
    753e02600b9a:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600ba1:	00 
    753e02600ba2:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    753e02600ba9:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600bb0:	00 
    753e02600bb1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02600bb8:	00 00 00 
    753e02600bbb:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600bc2:	00 00 00 
    753e02600bc5:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02600bcc:	5c 00 00 
    753e02600bcf:	ba 14 00 01 00       	mov    edx,0x10014
    753e02600bd4:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02600bda:	ff d0                	call   rax
    753e02600bdc:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600be3:	00 
    753e02600be4:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600bea:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600bf0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600bf6:	be 01 00 00 00       	mov    esi,0x1
    753e02600bfb:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600c00:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600c07:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600c0e:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600c15:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600c1c:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600c23:	e9 42 1e 00 00       	jmp    0x753e02602a6a
    753e02600c28:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02600c2f:	00 
    753e02600c30:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    753e02600c37:	c1 e9 0c             	shr    ecx,0xc
    753e02600c3a:	89 c9                	mov    ecx,ecx
    753e02600c3c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02600c40:	48 89 84 24 70 01 00 	mov    QWORD PTR [rsp+0x170],rax
    753e02600c47:	00 
    753e02600c48:	48 83 f8 00          	cmp    rax,0x0
    753e02600c4c:	74 23                	je     0x753e02600c71
    753e02600c4e:	48 8b 84 24 70 01 00 	mov    rax,QWORD PTR [rsp+0x170]
    753e02600c55:	00 
    753e02600c56:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    753e02600c5d:	8b 8c 24 78 01 00 00 	mov    ecx,DWORD PTR [rsp+0x178]
    753e02600c64:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02600c6a:	89 c9                	mov    ecx,ecx
    753e02600c6c:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02600c6f:	eb 51                	jmp    0x753e02600cc2
    753e02600c71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600c78:	00 
    753e02600c79:	8b 94 24 7c 01 00 00 	mov    edx,DWORD PTR [rsp+0x17c]
    753e02600c80:	8b b4 24 78 01 00 00 	mov    esi,DWORD PTR [rsp+0x178]
    753e02600c87:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02600c8e:	00 
    753e02600c8f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02600c96:	00 00 00 
    753e02600c99:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600ca0:	00 00 00 
    753e02600ca3:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02600caa:	5c 00 00 
    753e02600cad:	ff d0                	call   rax
    753e02600caf:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600cb6:	00 
    753e02600cb7:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600cbe:	75 32                	jne    0x753e02600cf2
    753e02600cc0:	eb 7c                	jmp    0x753e02600d3e
    753e02600cc2:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600cc9:	00 
    753e02600cca:	8b 84 24 78 01 00 00 	mov    eax,DWORD PTR [rsp+0x178]
    753e02600cd1:	83 e8 04             	sub    eax,0x4
    753e02600cd4:	89 84 24 68 01 00 00 	mov    DWORD PTR [rsp+0x168],eax
    753e02600cdb:	8b 49 34             	mov    ecx,DWORD PTR [rcx+0x34]
    753e02600cde:	89 8c 24 6c 01 00 00 	mov    DWORD PTR [rsp+0x16c],ecx
    753e02600ce5:	83 e0 03             	and    eax,0x3
    753e02600ce8:	83 f8 00             	cmp    eax,0x0
    753e02600ceb:	75 53                	jne    0x753e02600d40
    753e02600ced:	e9 dc 00 00 00       	jmp    0x753e02600dce
    753e02600cf2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600cf9:	00 
    753e02600cfa:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600d00:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600d06:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600d0c:	be 01 00 00 00       	mov    esi,0x1
    753e02600d11:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600d16:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600d1d:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600d24:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600d2b:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600d32:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600d39:	e9 2c 1d 00 00       	jmp    0x753e02602a6a
    753e02600d3e:	eb 82                	jmp    0x753e02600cc2
    753e02600d40:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600d47:	00 
    753e02600d48:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    753e02600d4f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600d56:	00 
    753e02600d57:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02600d5e:	00 00 00 
    753e02600d61:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600d68:	00 00 00 
    753e02600d6b:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02600d72:	5c 00 00 
    753e02600d75:	ba 14 00 01 00       	mov    edx,0x10014
    753e02600d7a:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02600d80:	ff d0                	call   rax
    753e02600d82:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600d89:	00 
    753e02600d8a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600d90:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600d96:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600d9c:	be 01 00 00 00       	mov    esi,0x1
    753e02600da1:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600da6:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600dad:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600db4:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600dbb:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600dc2:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600dc9:	e9 9c 1c 00 00       	jmp    0x753e02602a6a
    753e02600dce:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02600dd5:	00 
    753e02600dd6:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    753e02600ddd:	c1 e9 0c             	shr    ecx,0xc
    753e02600de0:	89 c9                	mov    ecx,ecx
    753e02600de2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02600de6:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    753e02600ded:	00 
    753e02600dee:	48 83 f8 00          	cmp    rax,0x0
    753e02600df2:	74 23                	je     0x753e02600e17
    753e02600df4:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02600dfb:	00 
    753e02600dfc:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    753e02600e03:	8b 8c 24 68 01 00 00 	mov    ecx,DWORD PTR [rsp+0x168]
    753e02600e0a:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02600e10:	89 c9                	mov    ecx,ecx
    753e02600e12:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02600e15:	eb 51                	jmp    0x753e02600e68
    753e02600e17:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600e1e:	00 
    753e02600e1f:	8b 94 24 6c 01 00 00 	mov    edx,DWORD PTR [rsp+0x16c]
    753e02600e26:	8b b4 24 68 01 00 00 	mov    esi,DWORD PTR [rsp+0x168]
    753e02600e2d:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02600e34:	00 
    753e02600e35:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02600e3c:	00 00 00 
    753e02600e3f:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02600e46:	00 00 00 
    753e02600e49:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02600e50:	5c 00 00 
    753e02600e53:	ff d0                	call   rax
    753e02600e55:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600e5c:	00 
    753e02600e5d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600e64:	75 26                	jne    0x753e02600e8c
    753e02600e66:	eb 70                	jmp    0x753e02600ed8
    753e02600e68:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e02600e6f:	00 
    753e02600e70:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600e77:	00 
    753e02600e78:	8b 94 24 68 01 00 00 	mov    edx,DWORD PTR [rsp+0x168]
    753e02600e7f:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e02600e82:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02600e85:	75 53                	jne    0x753e02600eda
    753e02600e87:	e9 93 00 00 00       	jmp    0x753e02600f1f
    753e02600e8c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600e93:	00 
    753e02600e94:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600e9a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600ea0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600ea6:	be 01 00 00 00       	mov    esi,0x1
    753e02600eab:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600eb0:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600eb7:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600ebe:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600ec5:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600ecc:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600ed3:	e9 92 1b 00 00       	jmp    0x753e02602a6a
    753e02600ed8:	eb 8e                	jmp    0x753e02600e68
    753e02600eda:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600ee1:	00 
    753e02600ee2:	c7 87 bc 00 00 00 16 	mov    DWORD PTR [rdi+0xbc],0x10016
    753e02600ee9:	00 01 00 
    753e02600eec:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02600ef3:	00 00 00 
    753e02600ef6:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02600efd:	00 00 00 
    753e02600f00:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02600f07:	5c 00 00 
    753e02600f0a:	ff d0                	call   rax
    753e02600f0c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600f13:	00 
    753e02600f14:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02600f1b:	75 04                	jne    0x753e02600f21
    753e02600f1d:	eb 4e                	jmp    0x753e02600f6d
    753e02600f1f:	eb 4e                	jmp    0x753e02600f6f
    753e02600f21:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600f28:	00 
    753e02600f29:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02600f2f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02600f35:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02600f3b:	be 01 00 00 00       	mov    esi,0x1
    753e02600f40:	b9 02 00 00 00       	mov    ecx,0x2
    753e02600f45:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02600f4c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02600f53:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02600f5a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02600f61:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02600f68:	e9 fd 1a 00 00       	jmp    0x753e02602a6a
    753e02600f6d:	eb b0                	jmp    0x753e02600f1f
    753e02600f6f:	eb 00                	jmp    0x753e02600f71
    753e02600f71:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02600f78:	00 
    753e02600f79:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    753e02600f7c:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02600f82:	83 c9 00             	or     ecx,0x0
    753e02600f85:	89 8c 24 5c 01 00 00 	mov    DWORD PTR [rsp+0x15c],ecx
    753e02600f8c:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02600f8f:	eb 00                	jmp    0x753e02600f91
    753e02600f91:	8b 84 24 68 01 00 00 	mov    eax,DWORD PTR [rsp+0x168]
    753e02600f98:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02600f9f:	00 
    753e02600fa0:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    753e02600fa6:	89 94 24 50 01 00 00 	mov    DWORD PTR [rsp+0x150],edx
    753e02600fad:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    753e02600fb0:	89 8c 24 54 01 00 00 	mov    DWORD PTR [rsp+0x154],ecx
    753e02600fb7:	83 e8 04             	sub    eax,0x4
    753e02600fba:	89 84 24 58 01 00 00 	mov    DWORD PTR [rsp+0x158],eax
    753e02600fc1:	83 e0 03             	and    eax,0x3
    753e02600fc4:	83 f8 00             	cmp    eax,0x0
    753e02600fc7:	0f 84 98 00 00 00    	je     0x753e02601065
    753e02600fcd:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02600fd4:	00 
    753e02600fd5:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    753e02600fdc:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02600fe3:	00 
    753e02600fe4:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    753e02600feb:	00 01 00 
    753e02600fee:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02600ff5:	00 00 00 
    753e02600ff8:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e02600fff:	00 00 00 
    753e02601002:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02601009:	5c 00 00 
    753e0260100c:	ba 1a 00 01 00       	mov    edx,0x1001a
    753e02601011:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02601017:	ff d0                	call   rax
    753e02601019:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601020:	00 
    753e02601021:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601027:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260102d:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601033:	be 03 00 00 00       	mov    esi,0x3
    753e02601038:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260103d:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601044:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260104b:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601052:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601059:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601060:	e9 05 1a 00 00       	jmp    0x753e02602a6a
    753e02601065:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e0260106c:	00 
    753e0260106d:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    753e02601074:	c1 e9 0c             	shr    ecx,0xc
    753e02601077:	89 c9                	mov    ecx,ecx
    753e02601079:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260107d:	48 89 84 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rax
    753e02601084:	00 
    753e02601085:	48 83 f8 00          	cmp    rax,0x0
    753e02601089:	74 23                	je     0x753e026010ae
    753e0260108b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02601092:	00 
    753e02601093:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    753e0260109a:	8b 8c 24 58 01 00 00 	mov    ecx,DWORD PTR [rsp+0x158]
    753e026010a1:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026010a7:	89 c9                	mov    ecx,ecx
    753e026010a9:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026010ac:	eb 5b                	jmp    0x753e02601109
    753e026010ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026010b5:	00 
    753e026010b6:	8b 94 24 50 01 00 00 	mov    edx,DWORD PTR [rsp+0x150]
    753e026010bd:	8b b4 24 58 01 00 00 	mov    esi,DWORD PTR [rsp+0x158]
    753e026010c4:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026010cb:	00 
    753e026010cc:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    753e026010d3:	00 01 00 
    753e026010d6:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026010dd:	00 00 00 
    753e026010e0:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e026010e7:	00 00 00 
    753e026010ea:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026010f1:	5c 00 00 
    753e026010f4:	ff d0                	call   rax
    753e026010f6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026010fd:	00 
    753e026010fe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601105:	75 20                	jne    0x753e02601127
    753e02601107:	eb 6a                	jmp    0x753e02601173
    753e02601109:	8b 84 24 58 01 00 00 	mov    eax,DWORD PTR [rsp+0x158]
    753e02601110:	83 e8 04             	sub    eax,0x4
    753e02601113:	89 84 24 44 01 00 00 	mov    DWORD PTR [rsp+0x144],eax
    753e0260111a:	83 e0 03             	and    eax,0x3
    753e0260111d:	83 f8 00             	cmp    eax,0x0
    753e02601120:	75 53                	jne    0x753e02601175
    753e02601122:	e9 e6 00 00 00       	jmp    0x753e0260120d
    753e02601127:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260112e:	00 
    753e0260112f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601135:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260113b:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601141:	be 03 00 00 00       	mov    esi,0x3
    753e02601146:	b9 04 00 00 00       	mov    ecx,0x4
    753e0260114b:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601152:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601159:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601160:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601167:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260116e:	e9 f7 18 00 00       	jmp    0x753e02602a6a
    753e02601173:	eb 94                	jmp    0x753e02601109
    753e02601175:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260117c:	00 
    753e0260117d:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e02601184:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e0260118b:	00 
    753e0260118c:	c7 87 bc 00 00 00 1a 	mov    DWORD PTR [rdi+0xbc],0x1001a
    753e02601193:	00 01 00 
    753e02601196:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260119d:	00 00 00 
    753e026011a0:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e026011a7:	00 00 00 
    753e026011aa:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026011b1:	5c 00 00 
    753e026011b4:	ba 1a 00 01 00       	mov    edx,0x1001a
    753e026011b9:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e026011bf:	ff d0                	call   rax
    753e026011c1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026011c8:	00 
    753e026011c9:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026011cf:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026011d5:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026011db:	be 03 00 00 00       	mov    esi,0x3
    753e026011e0:	b9 04 00 00 00       	mov    ecx,0x4
    753e026011e5:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026011ec:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026011f3:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026011fa:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601201:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601208:	e9 5d 18 00 00       	jmp    0x753e02602a6a
    753e0260120d:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02601214:	00 
    753e02601215:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e0260121c:	c1 e9 0c             	shr    ecx,0xc
    753e0260121f:	89 c9                	mov    ecx,ecx
    753e02601221:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02601225:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    753e0260122c:	00 
    753e0260122d:	48 83 f8 00          	cmp    rax,0x0
    753e02601231:	74 23                	je     0x753e02601256
    753e02601233:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    753e0260123a:	00 
    753e0260123b:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    753e02601242:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e02601249:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260124f:	89 c9                	mov    ecx,ecx
    753e02601251:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02601254:	eb 5b                	jmp    0x753e026012b1
    753e02601256:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260125d:	00 
    753e0260125e:	8b 94 24 54 01 00 00 	mov    edx,DWORD PTR [rsp+0x154]
    753e02601265:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    753e0260126c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601273:	00 
    753e02601274:	c7 80 bc 00 00 00 1a 	mov    DWORD PTR [rax+0xbc],0x1001a
    753e0260127b:	00 01 00 
    753e0260127e:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02601285:	00 00 00 
    753e02601288:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e0260128f:	00 00 00 
    753e02601292:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02601299:	5c 00 00 
    753e0260129c:	ff d0                	call   rax
    753e0260129e:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026012a5:	00 
    753e026012a6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026012ad:	75 2c                	jne    0x753e026012db
    753e026012af:	eb 76                	jmp    0x753e02601327
    753e026012b1:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e026012b8:	00 
    753e026012b9:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026012c0:	00 
    753e026012c1:	8b 94 24 44 01 00 00 	mov    edx,DWORD PTR [rsp+0x144]
    753e026012c8:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    753e026012cb:	83 ea 14             	sub    edx,0x14
    753e026012ce:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e026012d1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e026012d4:	75 53                	jne    0x753e02601329
    753e026012d6:	e9 93 00 00 00       	jmp    0x753e0260136e
    753e026012db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026012e2:	00 
    753e026012e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026012e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026012ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026012f5:	be 03 00 00 00       	mov    esi,0x3
    753e026012fa:	b9 04 00 00 00       	mov    ecx,0x4
    753e026012ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601306:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260130d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601314:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260131b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601322:	e9 43 17 00 00       	jmp    0x753e02602a6a
    753e02601327:	eb 88                	jmp    0x753e026012b1
    753e02601329:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601330:	00 
    753e02601331:	c7 87 bc 00 00 00 1e 	mov    DWORD PTR [rdi+0xbc],0x1001e
    753e02601338:	00 01 00 
    753e0260133b:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02601342:	00 00 00 
    753e02601345:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e0260134c:	00 00 00 
    753e0260134f:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02601356:	5c 00 00 
    753e02601359:	ff d0                	call   rax
    753e0260135b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601362:	00 
    753e02601363:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260136a:	75 04                	jne    0x753e02601370
    753e0260136c:	eb 4e                	jmp    0x753e026013bc
    753e0260136e:	eb 4e                	jmp    0x753e026013be
    753e02601370:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601377:	00 
    753e02601378:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260137e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601384:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260138a:	be 03 00 00 00       	mov    esi,0x3
    753e0260138f:	b9 04 00 00 00       	mov    ecx,0x4
    753e02601394:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260139b:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026013a2:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026013a9:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026013b0:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026013b7:	e9 ae 16 00 00       	jmp    0x753e02602a6a
    753e026013bc:	eb b0                	jmp    0x753e0260136e
    753e026013be:	eb 00                	jmp    0x753e026013c0
    753e026013c0:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026013c7:	00 
    753e026013c8:	8b 8c 24 5c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x15c]
    753e026013cf:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026013d5:	81 c9 00 f0 00 00    	or     ecx,0xf000
    753e026013db:	89 8c 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],ecx
    753e026013e2:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026013e5:	eb 00                	jmp    0x753e026013e7
    753e026013e7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026013ee:	00 
    753e026013ef:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
    753e026013f2:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e026013f8:	81 c9 00 00 42 43    	or     ecx,0x43420000
    753e026013fe:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    753e02601405:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e02601408:	eb 00                	jmp    0x753e0260140a
    753e0260140a:	8b 84 24 34 01 00 00 	mov    eax,DWORD PTR [rsp+0x134]
    753e02601411:	83 e0 03             	and    eax,0x3
    753e02601414:	83 f8 00             	cmp    eax,0x0
    753e02601417:	0f 84 97 00 00 00    	je     0x753e026014b4
    753e0260141d:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601424:	00 
    753e02601425:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e0260142c:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601433:	00 
    753e02601434:	c7 87 bc 00 00 00 26 	mov    DWORD PTR [rdi+0xbc],0x10026
    753e0260143b:	00 01 00 
    753e0260143e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02601445:	00 00 00 
    753e02601448:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    753e0260144f:	00 00 00 
    753e02601452:	31 c0                	xor    eax,eax
    753e02601454:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260145b:	5c 00 00 
    753e0260145e:	ba 26 00 01 00       	mov    edx,0x10026
    753e02601463:	45 31 c0             	xor    r8d,r8d
    753e02601466:	ff d0                	call   rax
    753e02601468:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260146f:	00 
    753e02601470:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601476:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260147c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601482:	be 06 00 00 00       	mov    esi,0x6
    753e02601487:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260148c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601493:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260149a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026014a1:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026014a8:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026014af:	e9 b6 15 00 00       	jmp    0x753e02602a6a
    753e026014b4:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026014bb:	00 
    753e026014bc:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e026014c3:	c1 e9 0c             	shr    ecx,0xc
    753e026014c6:	89 c9                	mov    ecx,ecx
    753e026014c8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026014cc:	48 89 84 24 28 01 00 	mov    QWORD PTR [rsp+0x128],rax
    753e026014d3:	00 
    753e026014d4:	48 83 f8 00          	cmp    rax,0x0
    753e026014d8:	74 23                	je     0x753e026014fd
    753e026014da:	48 8b 84 24 28 01 00 	mov    rax,QWORD PTR [rsp+0x128]
    753e026014e1:	00 
    753e026014e2:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e026014e9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026014ef:	89 c9                	mov    ecx,ecx
    753e026014f1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026014f4:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    753e026014fb:	eb 5d                	jmp    0x753e0260155a
    753e026014fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601504:	00 
    753e02601505:	8b b4 24 34 01 00 00 	mov    esi,DWORD PTR [rsp+0x134]
    753e0260150c:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601513:	00 
    753e02601514:	c7 80 bc 00 00 00 26 	mov    DWORD PTR [rax+0xbc],0x10026
    753e0260151b:	00 01 00 
    753e0260151e:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02601525:	00 00 00 
    753e02601528:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    753e0260152f:	00 00 00 
    753e02601532:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02601539:	5c 00 00 
    753e0260153c:	ff d0                	call   rax
    753e0260153e:	89 c1                	mov    ecx,eax
    753e02601540:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601547:	00 
    753e02601548:	89 8c 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],ecx
    753e0260154f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601556:	75 1c                	jne    0x753e02601574
    753e02601558:	eb 66                	jmp    0x753e026015c0
    753e0260155a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601561:	00 
    753e02601562:	8b 8c 24 24 01 00 00 	mov    ecx,DWORD PTR [rsp+0x124]
    753e02601569:	89 8c 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],ecx
    753e02601570:	89 08                	mov    DWORD PTR [rax],ecx
    753e02601572:	eb 5c                	jmp    0x753e026015d0
    753e02601574:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260157b:	00 
    753e0260157c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601582:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601588:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260158e:	be 06 00 00 00       	mov    esi,0x6
    753e02601593:	b9 02 00 00 00       	mov    ecx,0x2
    753e02601598:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260159f:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026015a6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026015ad:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026015b4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026015bb:	e9 aa 14 00 00       	jmp    0x753e02602a6a
    753e026015c0:	8b 84 24 20 01 00 00 	mov    eax,DWORD PTR [rsp+0x120]
    753e026015c7:	89 84 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],eax
    753e026015ce:	eb 8a                	jmp    0x753e0260155a
    753e026015d0:	eb 00                	jmp    0x753e026015d2
    753e026015d2:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026015d9:	00 
    753e026015da:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e026015e1:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026015e7:	81 c9 31 4e 00 00    	or     ecx,0x4e31
    753e026015ed:	89 8c 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],ecx
    753e026015f4:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e026015f7:	eb 00                	jmp    0x753e026015f9
    753e026015f9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601600:	00 
    753e02601601:	8b 8c 24 18 01 00 00 	mov    ecx,DWORD PTR [rsp+0x118]
    753e02601608:	8b bc 24 1c 01 00 00 	mov    edi,DWORD PTR [rsp+0x11c]
    753e0260160f:	89 fa                	mov    edx,edi
    753e02601611:	29 ca                	sub    edx,ecx
    753e02601613:	83 fa 00             	cmp    edx,0x0
    753e02601616:	0f 94 c3             	sete   bl
    753e02601619:	80 e3 01             	and    bl,0x1
    753e0260161c:	0f b6 f3             	movzx  esi,bl
    753e0260161f:	89 b4 24 14 01 00 00 	mov    DWORD PTR [rsp+0x114],esi
    753e02601626:	c1 ea 1f             	shr    edx,0x1f
    753e02601629:	89 fb                	mov    ebx,edi
    753e0260162b:	c1 eb 1f             	shr    ebx,0x1f
    753e0260162e:	41 89 c8             	mov    r8d,ecx
    753e02601631:	41 c1 e8 1f          	shr    r8d,0x1f
    753e02601635:	89 d5                	mov    ebp,edx
    753e02601637:	31 dd                	xor    ebp,ebx
    753e02601639:	44 31 c3             	xor    ebx,r8d
    753e0260163c:	21 eb                	and    ebx,ebp
    753e0260163e:	31 da                	xor    edx,ebx
    753e02601640:	39 f9                	cmp    ecx,edi
    753e02601642:	0f 96 c1             	setbe  cl
    753e02601645:	80 e1 01             	and    cl,0x1
    753e02601648:	0f b6 c9             	movzx  ecx,cl
    753e0260164b:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e02601651:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e02601657:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260165d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02601663:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02601669:	eb 00                	jmp    0x753e0260166b
    753e0260166b:	8b 84 24 14 01 00 00 	mov    eax,DWORD PTR [rsp+0x114]
    753e02601672:	83 f8 00             	cmp    eax,0x0
    753e02601675:	74 33                	je     0x753e026016aa
    753e02601677:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260167e:	00 
    753e0260167f:	c7 81 bc 00 00 00 40 	mov    DWORD PTR [rcx+0xbc],0x10040
    753e02601686:	00 01 00 
    753e02601689:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260168f:	83 c0 09             	add    eax,0x9
    753e02601692:	89 84 24 10 01 00 00 	mov    DWORD PTR [rsp+0x110],eax
    753e02601699:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260169f:	0f 82 35 13 00 00    	jb     0x753e026029da
    753e026016a5:	e9 53 13 00 00       	jmp    0x753e026029fd
    753e026016aa:	eb 00                	jmp    0x753e026016ac
    753e026016ac:	eb 00                	jmp    0x753e026016ae
    753e026016ae:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026016b5:	00 
    753e026016b6:	c7 00 03 00 00 00    	mov    DWORD PTR [rax],0x3
    753e026016bc:	eb 00                	jmp    0x753e026016be
    753e026016be:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026016c5:	00 
    753e026016c6:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e026016cd:	83 c1 10             	add    ecx,0x10
    753e026016d0:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    753e026016d7:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026016da:	eb 00                	jmp    0x753e026016dc
    753e026016dc:	8b 84 24 0c 01 00 00 	mov    eax,DWORD PTR [rsp+0x10c]
    753e026016e3:	83 e0 03             	and    eax,0x3
    753e026016e6:	83 f8 00             	cmp    eax,0x0
    753e026016e9:	0f 84 98 00 00 00    	je     0x753e02601787
    753e026016ef:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026016f6:	00 
    753e026016f7:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    753e026016fe:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601705:	00 
    753e02601706:	c7 87 bc 00 00 00 34 	mov    DWORD PTR [rdi+0xbc],0x10034
    753e0260170d:	00 01 00 
    753e02601710:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02601717:	00 00 00 
    753e0260171a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    753e02601721:	00 00 00 
    753e02601724:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260172b:	5c 00 00 
    753e0260172e:	ba 34 00 01 00       	mov    edx,0x10034
    753e02601733:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02601739:	ff d0                	call   rax
    753e0260173b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601742:	00 
    753e02601743:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601749:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260174f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601755:	be 0c 00 00 00       	mov    esi,0xc
    753e0260175a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260175f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601766:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260176d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601774:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260177b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601782:	e9 e3 12 00 00       	jmp    0x753e02602a6a
    753e02601787:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e0260178e:	00 
    753e0260178f:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    753e02601796:	c1 e9 0c             	shr    ecx,0xc
    753e02601799:	89 c9                	mov    ecx,ecx
    753e0260179b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260179f:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    753e026017a6:	00 
    753e026017a7:	48 83 f8 00          	cmp    rax,0x0
    753e026017ab:	74 20                	je     0x753e026017cd
    753e026017ad:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    753e026017b4:	00 
    753e026017b5:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    753e026017bc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026017c2:	89 c9                	mov    ecx,ecx
    753e026017c4:	c7 04 08 03 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x3
    753e026017cb:	eb 59                	jmp    0x753e02601826
    753e026017cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026017d4:	00 
    753e026017d5:	8b b4 24 0c 01 00 00 	mov    esi,DWORD PTR [rsp+0x10c]
    753e026017dc:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026017e3:	00 
    753e026017e4:	c7 80 bc 00 00 00 34 	mov    DWORD PTR [rax+0xbc],0x10034
    753e026017eb:	00 01 00 
    753e026017ee:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026017f5:	00 00 00 
    753e026017f8:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    753e026017ff:	00 00 00 
    753e02601802:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02601809:	5c 00 00 
    753e0260180c:	ba 03 00 00 00       	mov    edx,0x3
    753e02601811:	ff d0                	call   rax
    753e02601813:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260181a:	00 
    753e0260181b:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601822:	75 14                	jne    0x753e02601838
    753e02601824:	eb 5e                	jmp    0x753e02601884
    753e02601826:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
    753e0260182d:	00 
    753e0260182e:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02601831:	75 53                	jne    0x753e02601886
    753e02601833:	e9 93 00 00 00       	jmp    0x753e026018cb
    753e02601838:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260183f:	00 
    753e02601840:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601846:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260184c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601852:	be 0c 00 00 00       	mov    esi,0xc
    753e02601857:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260185c:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601863:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260186a:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601871:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601878:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e0260187f:	e9 e6 11 00 00       	jmp    0x753e02602a6a
    753e02601884:	eb a0                	jmp    0x753e02601826
    753e02601886:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260188d:	00 
    753e0260188e:	c7 87 bc 00 00 00 36 	mov    DWORD PTR [rdi+0xbc],0x10036
    753e02601895:	00 01 00 
    753e02601898:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260189f:	00 00 00 
    753e026018a2:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    753e026018a9:	00 00 00 
    753e026018ac:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e026018b3:	5c 00 00 
    753e026018b6:	ff d0                	call   rax
    753e026018b8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026018bf:	00 
    753e026018c0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026018c7:	75 04                	jne    0x753e026018cd
    753e026018c9:	eb 4e                	jmp    0x753e02601919
    753e026018cb:	eb 4e                	jmp    0x753e0260191b
    753e026018cd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026018d4:	00 
    753e026018d5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026018db:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026018e1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026018e7:	be 0c 00 00 00       	mov    esi,0xc
    753e026018ec:	b9 02 00 00 00       	mov    ecx,0x2
    753e026018f1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026018f8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026018ff:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601906:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260190d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601914:	e9 51 11 00 00       	jmp    0x753e02602a6a
    753e02601919:	eb b0                	jmp    0x753e026018cb
    753e0260191b:	eb 00                	jmp    0x753e0260191d
    753e0260191d:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601924:	00 
    753e02601925:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    753e0260192b:	eb 00                	jmp    0x753e0260192d
    753e0260192d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    753e02601934:	83 e0 03             	and    eax,0x3
    753e02601937:	83 f8 00             	cmp    eax,0x0
    753e0260193a:	0f 84 97 00 00 00    	je     0x753e026019d7
    753e02601940:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601947:	00 
    753e02601948:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e0260194f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601956:	00 
    753e02601957:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    753e0260195e:	00 01 00 
    753e02601961:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02601968:	00 00 00 
    753e0260196b:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e02601972:	00 00 00 
    753e02601975:	31 c0                	xor    eax,eax
    753e02601977:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260197e:	5c 00 00 
    753e02601981:	ba 38 00 01 00       	mov    edx,0x10038
    753e02601986:	45 31 c0             	xor    r8d,r8d
    753e02601989:	ff d0                	call   rax
    753e0260198b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601992:	00 
    753e02601993:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601999:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260199f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026019a5:	be 0e 00 00 00       	mov    esi,0xe
    753e026019aa:	b9 04 00 00 00       	mov    ecx,0x4
    753e026019af:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026019b6:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026019bd:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026019c4:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026019cb:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026019d2:	e9 93 10 00 00       	jmp    0x753e02602a6a
    753e026019d7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026019de:	00 
    753e026019df:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e026019e6:	c1 e9 0c             	shr    ecx,0xc
    753e026019e9:	89 c9                	mov    ecx,ecx
    753e026019eb:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026019ef:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    753e026019f6:	00 
    753e026019f7:	48 83 f8 00          	cmp    rax,0x0
    753e026019fb:	74 23                	je     0x753e02601a20
    753e026019fd:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    753e02601a04:	00 
    753e02601a05:	8b 8c 24 44 01 00 00 	mov    ecx,DWORD PTR [rsp+0x144]
    753e02601a0c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02601a12:	89 c9                	mov    ecx,ecx
    753e02601a14:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02601a17:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    753e02601a1e:	eb 5d                	jmp    0x753e02601a7d
    753e02601a20:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601a27:	00 
    753e02601a28:	8b b4 24 44 01 00 00 	mov    esi,DWORD PTR [rsp+0x144]
    753e02601a2f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601a36:	00 
    753e02601a37:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    753e02601a3e:	00 01 00 
    753e02601a41:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02601a48:	00 00 00 
    753e02601a4b:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e02601a52:	00 00 00 
    753e02601a55:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02601a5c:	5c 00 00 
    753e02601a5f:	ff d0                	call   rax
    753e02601a61:	89 c1                	mov    ecx,eax
    753e02601a63:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601a6a:	00 
    753e02601a6b:	89 8c 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],ecx
    753e02601a72:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601a79:	75 2e                	jne    0x753e02601aa9
    753e02601a7b:	eb 78                	jmp    0x753e02601af5
    753e02601a7d:	8b 84 24 44 01 00 00 	mov    eax,DWORD PTR [rsp+0x144]
    753e02601a84:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    753e02601a8b:	89 8c 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],ecx
    753e02601a92:	83 c0 04             	add    eax,0x4
    753e02601a95:	89 84 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],eax
    753e02601a9c:	83 e0 03             	and    eax,0x3
    753e02601a9f:	83 f8 00             	cmp    eax,0x0
    753e02601aa2:	75 64                	jne    0x753e02601b08
    753e02601aa4:	e9 f6 00 00 00       	jmp    0x753e02601b9f
    753e02601aa9:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601ab0:	00 
    753e02601ab1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601ab7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601abd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601ac3:	be 0e 00 00 00       	mov    esi,0xe
    753e02601ac8:	b9 04 00 00 00       	mov    ecx,0x4
    753e02601acd:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601ad4:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601adb:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601ae2:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601ae9:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601af0:	e9 75 0f 00 00       	jmp    0x753e02602a6a
    753e02601af5:	8b 84 24 f0 00 00 00 	mov    eax,DWORD PTR [rsp+0xf0]
    753e02601afc:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    753e02601b03:	e9 75 ff ff ff       	jmp    0x753e02601a7d
    753e02601b08:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601b0f:	00 
    753e02601b10:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e02601b17:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601b1e:	00 
    753e02601b1f:	c7 87 bc 00 00 00 38 	mov    DWORD PTR [rdi+0xbc],0x10038
    753e02601b26:	00 01 00 
    753e02601b29:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02601b30:	00 00 00 
    753e02601b33:	c7 87 34 01 00 00 0e 	mov    DWORD PTR [rdi+0x134],0xe
    753e02601b3a:	00 00 00 
    753e02601b3d:	31 c0                	xor    eax,eax
    753e02601b3f:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02601b46:	5c 00 00 
    753e02601b49:	ba 38 00 01 00       	mov    edx,0x10038
    753e02601b4e:	45 31 c0             	xor    r8d,r8d
    753e02601b51:	ff d0                	call   rax
    753e02601b53:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601b5a:	00 
    753e02601b5b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601b61:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601b67:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601b6d:	be 0e 00 00 00       	mov    esi,0xe
    753e02601b72:	b9 04 00 00 00       	mov    ecx,0x4
    753e02601b77:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601b7e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601b85:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601b8c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601b93:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601b9a:	e9 cb 0e 00 00       	jmp    0x753e02602a6a
    753e02601b9f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02601ba6:	00 
    753e02601ba7:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e02601bae:	c1 e9 0c             	shr    ecx,0xc
    753e02601bb1:	89 c9                	mov    ecx,ecx
    753e02601bb3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02601bb7:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
    753e02601bbe:	00 
    753e02601bbf:	48 83 f8 00          	cmp    rax,0x0
    753e02601bc3:	74 23                	je     0x753e02601be8
    753e02601bc5:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
    753e02601bcc:	00 
    753e02601bcd:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e02601bd4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02601bda:	89 c9                	mov    ecx,ecx
    753e02601bdc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02601bdf:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    753e02601be6:	eb 60                	jmp    0x753e02601c48
    753e02601be8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601bef:	00 
    753e02601bf0:	8b b4 24 ec 00 00 00 	mov    esi,DWORD PTR [rsp+0xec]
    753e02601bf7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601bfe:	00 
    753e02601bff:	c7 80 bc 00 00 00 38 	mov    DWORD PTR [rax+0xbc],0x10038
    753e02601c06:	00 01 00 
    753e02601c09:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02601c10:	00 00 00 
    753e02601c13:	c7 80 34 01 00 00 0e 	mov    DWORD PTR [rax+0x134],0xe
    753e02601c1a:	00 00 00 
    753e02601c1d:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02601c24:	5c 00 00 
    753e02601c27:	ff d0                	call   rax
    753e02601c29:	89 c1                	mov    ecx,eax
    753e02601c2b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601c32:	00 
    753e02601c33:	89 8c 24 d8 00 00 00 	mov    DWORD PTR [rsp+0xd8],ecx
    753e02601c3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601c41:	75 41                	jne    0x753e02601c84
    753e02601c43:	e9 88 00 00 00       	jmp    0x753e02601cd0
    753e02601c48:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601c4f:	00 
    753e02601c50:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    753e02601c57:	8b 8c 24 ec 00 00 00 	mov    ecx,DWORD PTR [rsp+0xec]
    753e02601c5e:	8b 94 24 dc 00 00 00 	mov    edx,DWORD PTR [rsp+0xdc]
    753e02601c65:	89 94 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edx
    753e02601c6c:	83 c1 04             	add    ecx,0x4
    753e02601c6f:	89 8c 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],ecx
    753e02601c76:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e02601c79:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e02601c7f:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02601c82:	eb 5f                	jmp    0x753e02601ce3
    753e02601c84:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601c8b:	00 
    753e02601c8c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601c92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601c98:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601c9e:	be 0e 00 00 00       	mov    esi,0xe
    753e02601ca3:	b9 04 00 00 00       	mov    ecx,0x4
    753e02601ca8:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601caf:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601cb6:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601cbd:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601cc4:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601ccb:	e9 9a 0d 00 00       	jmp    0x753e02602a6a
    753e02601cd0:	8b 84 24 d8 00 00 00 	mov    eax,DWORD PTR [rsp+0xd8]
    753e02601cd7:	89 84 24 dc 00 00 00 	mov    DWORD PTR [rsp+0xdc],eax
    753e02601cde:	e9 65 ff ff ff       	jmp    0x753e02601c48
    753e02601ce3:	eb 00                	jmp    0x753e02601ce5
    753e02601ce5:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    753e02601cec:	83 e0 03             	and    eax,0x3
    753e02601cef:	83 f8 00             	cmp    eax,0x0
    753e02601cf2:	0f 84 97 00 00 00    	je     0x753e02601d8f
    753e02601cf8:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601cff:	00 
    753e02601d00:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e02601d07:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601d0e:	00 
    753e02601d0f:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e02601d16:	00 01 00 
    753e02601d19:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02601d20:	00 00 00 
    753e02601d23:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e02601d2a:	00 00 00 
    753e02601d2d:	31 c0                	xor    eax,eax
    753e02601d2f:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02601d36:	5c 00 00 
    753e02601d39:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e02601d3e:	45 31 c0             	xor    r8d,r8d
    753e02601d41:	ff d0                	call   rax
    753e02601d43:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601d4a:	00 
    753e02601d4b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601d51:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601d57:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601d5d:	be 0f 00 00 00       	mov    esi,0xf
    753e02601d62:	b9 02 00 00 00       	mov    ecx,0x2
    753e02601d67:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601d6e:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601d75:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601d7c:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601d83:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601d8a:	e9 db 0c 00 00       	jmp    0x753e02602a6a
    753e02601d8f:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02601d96:	00 
    753e02601d97:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e02601d9e:	c1 e9 0c             	shr    ecx,0xc
    753e02601da1:	89 c9                	mov    ecx,ecx
    753e02601da3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02601da7:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
    753e02601dae:	00 
    753e02601daf:	48 83 f8 00          	cmp    rax,0x0
    753e02601db3:	74 23                	je     0x753e02601dd8
    753e02601db5:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
    753e02601dbc:	00 
    753e02601dbd:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e02601dc4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02601dca:	89 c9                	mov    ecx,ecx
    753e02601dcc:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02601dcf:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    753e02601dd6:	eb 5d                	jmp    0x753e02601e35
    753e02601dd8:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601ddf:	00 
    753e02601de0:	8b b4 24 d4 00 00 00 	mov    esi,DWORD PTR [rsp+0xd4]
    753e02601de7:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601dee:	00 
    753e02601def:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e02601df6:	00 01 00 
    753e02601df9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02601e00:	00 00 00 
    753e02601e03:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e02601e0a:	00 00 00 
    753e02601e0d:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02601e14:	5c 00 00 
    753e02601e17:	ff d0                	call   rax
    753e02601e19:	89 c1                	mov    ecx,eax
    753e02601e1b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601e22:	00 
    753e02601e23:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    753e02601e2a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601e31:	75 32                	jne    0x753e02601e65
    753e02601e33:	eb 7c                	jmp    0x753e02601eb1
    753e02601e35:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    753e02601e3c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02601e43:	00 
    753e02601e44:	8b 94 24 c4 00 00 00 	mov    edx,DWORD PTR [rsp+0xc4]
    753e02601e4b:	89 51 34             	mov    DWORD PTR [rcx+0x34],edx
    753e02601e4e:	83 c0 04             	add    eax,0x4
    753e02601e51:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e02601e58:	83 e0 03             	and    eax,0x3
    753e02601e5b:	83 f8 00             	cmp    eax,0x0
    753e02601e5e:	75 64                	jne    0x753e02601ec4
    753e02601e60:	e9 f6 00 00 00       	jmp    0x753e02601f5b
    753e02601e65:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601e6c:	00 
    753e02601e6d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601e73:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601e79:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601e7f:	be 0f 00 00 00       	mov    esi,0xf
    753e02601e84:	b9 02 00 00 00       	mov    ecx,0x2
    753e02601e89:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601e90:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601e97:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601e9e:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601ea5:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601eac:	e9 b9 0b 00 00       	jmp    0x753e02602a6a
    753e02601eb1:	8b 84 24 c0 00 00 00 	mov    eax,DWORD PTR [rsp+0xc0]
    753e02601eb8:	89 84 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],eax
    753e02601ebf:	e9 71 ff ff ff       	jmp    0x753e02601e35
    753e02601ec4:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02601ecb:	00 
    753e02601ecc:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e02601ed3:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02601eda:	00 
    753e02601edb:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e02601ee2:	00 01 00 
    753e02601ee5:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02601eec:	00 00 00 
    753e02601eef:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e02601ef6:	00 00 00 
    753e02601ef9:	31 c0                	xor    eax,eax
    753e02601efb:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02601f02:	5c 00 00 
    753e02601f05:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e02601f0a:	45 31 c0             	xor    r8d,r8d
    753e02601f0d:	ff d0                	call   rax
    753e02601f0f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601f16:	00 
    753e02601f17:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02601f1d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02601f23:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02601f29:	be 0f 00 00 00       	mov    esi,0xf
    753e02601f2e:	b9 02 00 00 00       	mov    ecx,0x2
    753e02601f33:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02601f3a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02601f41:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02601f48:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02601f4f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02601f56:	e9 0f 0b 00 00       	jmp    0x753e02602a6a
    753e02601f5b:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02601f62:	00 
    753e02601f63:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e02601f6a:	c1 e9 0c             	shr    ecx,0xc
    753e02601f6d:	89 c9                	mov    ecx,ecx
    753e02601f6f:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02601f73:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
    753e02601f7a:	00 
    753e02601f7b:	48 83 f8 00          	cmp    rax,0x0
    753e02601f7f:	74 23                	je     0x753e02601fa4
    753e02601f81:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02601f88:	00 
    753e02601f89:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e02601f90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02601f96:	89 c9                	mov    ecx,ecx
    753e02601f98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02601f9b:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e02601fa2:	eb 5d                	jmp    0x753e02602001
    753e02601fa4:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601fab:	00 
    753e02601fac:	8b b4 24 bc 00 00 00 	mov    esi,DWORD PTR [rsp+0xbc]
    753e02601fb3:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02601fba:	00 
    753e02601fbb:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e02601fc2:	00 01 00 
    753e02601fc5:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02601fcc:	00 00 00 
    753e02601fcf:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e02601fd6:	00 00 00 
    753e02601fd9:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02601fe0:	5c 00 00 
    753e02601fe3:	ff d0                	call   rax
    753e02601fe5:	89 c1                	mov    ecx,eax
    753e02601fe7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02601fee:	00 
    753e02601fef:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    753e02601ff6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02601ffd:	75 32                	jne    0x753e02602031
    753e02601fff:	eb 7c                	jmp    0x753e0260207d
    753e02602001:	8b 84 24 bc 00 00 00 	mov    eax,DWORD PTR [rsp+0xbc]
    753e02602008:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e0260200f:	00 
    753e02602010:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    753e02602017:	89 51 30             	mov    DWORD PTR [rcx+0x30],edx
    753e0260201a:	83 c0 04             	add    eax,0x4
    753e0260201d:	89 84 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],eax
    753e02602024:	83 e0 03             	and    eax,0x3
    753e02602027:	83 f8 00             	cmp    eax,0x0
    753e0260202a:	75 64                	jne    0x753e02602090
    753e0260202c:	e9 f6 00 00 00       	jmp    0x753e02602127
    753e02602031:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602038:	00 
    753e02602039:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260203f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602045:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260204b:	be 0f 00 00 00       	mov    esi,0xf
    753e02602050:	b9 02 00 00 00       	mov    ecx,0x2
    753e02602055:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260205c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02602063:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260206a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02602071:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602078:	e9 ed 09 00 00       	jmp    0x753e02602a6a
    753e0260207d:	8b 84 24 a8 00 00 00 	mov    eax,DWORD PTR [rsp+0xa8]
    753e02602084:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e0260208b:	e9 71 ff ff ff       	jmp    0x753e02602001
    753e02602090:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02602097:	00 
    753e02602098:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260209f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026020a6:	00 
    753e026020a7:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e026020ae:	00 01 00 
    753e026020b1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026020b8:	00 00 00 
    753e026020bb:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e026020c2:	00 00 00 
    753e026020c5:	31 c0                	xor    eax,eax
    753e026020c7:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026020ce:	5c 00 00 
    753e026020d1:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e026020d6:	45 31 c0             	xor    r8d,r8d
    753e026020d9:	ff d0                	call   rax
    753e026020db:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026020e2:	00 
    753e026020e3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026020e9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026020ef:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026020f5:	be 0f 00 00 00       	mov    esi,0xf
    753e026020fa:	b9 02 00 00 00       	mov    ecx,0x2
    753e026020ff:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02602106:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260210d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602114:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260211b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602122:	e9 43 09 00 00       	jmp    0x753e02602a6a
    753e02602127:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e0260212e:	00 
    753e0260212f:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e02602136:	c1 e9 0c             	shr    ecx,0xc
    753e02602139:	89 c9                	mov    ecx,ecx
    753e0260213b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260213f:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    753e02602146:	00 
    753e02602147:	48 83 f8 00          	cmp    rax,0x0
    753e0260214b:	74 23                	je     0x753e02602170
    753e0260214d:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e02602154:	00 
    753e02602155:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260215c:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02602162:	89 c9                	mov    ecx,ecx
    753e02602164:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02602167:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e0260216e:	eb 5d                	jmp    0x753e026021cd
    753e02602170:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602177:	00 
    753e02602178:	8b b4 24 a4 00 00 00 	mov    esi,DWORD PTR [rsp+0xa4]
    753e0260217f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02602186:	00 
    753e02602187:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e0260218e:	00 01 00 
    753e02602191:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602198:	00 00 00 
    753e0260219b:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e026021a2:	00 00 00 
    753e026021a5:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026021ac:	5c 00 00 
    753e026021af:	ff d0                	call   rax
    753e026021b1:	89 c1                	mov    ecx,eax
    753e026021b3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026021ba:	00 
    753e026021bb:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    753e026021c2:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026021c9:	75 32                	jne    0x753e026021fd
    753e026021cb:	eb 7c                	jmp    0x753e02602249
    753e026021cd:	8b 84 24 a4 00 00 00 	mov    eax,DWORD PTR [rsp+0xa4]
    753e026021d4:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026021db:	00 
    753e026021dc:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [rsp+0x94]
    753e026021e3:	89 51 2c             	mov    DWORD PTR [rcx+0x2c],edx
    753e026021e6:	83 c0 04             	add    eax,0x4
    753e026021e9:	89 84 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],eax
    753e026021f0:	83 e0 03             	and    eax,0x3
    753e026021f3:	83 f8 00             	cmp    eax,0x0
    753e026021f6:	75 64                	jne    0x753e0260225c
    753e026021f8:	e9 f6 00 00 00       	jmp    0x753e026022f3
    753e026021fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602204:	00 
    753e02602205:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260220b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602211:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02602217:	be 0f 00 00 00       	mov    esi,0xf
    753e0260221c:	b9 02 00 00 00       	mov    ecx,0x2
    753e02602221:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02602228:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260222f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602236:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260223d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602244:	e9 21 08 00 00       	jmp    0x753e02602a6a
    753e02602249:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    753e02602250:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e02602257:	e9 71 ff ff ff       	jmp    0x753e026021cd
    753e0260225c:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02602263:	00 
    753e02602264:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e0260226b:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02602272:	00 
    753e02602273:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e0260227a:	00 01 00 
    753e0260227d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02602284:	00 00 00 
    753e02602287:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e0260228e:	00 00 00 
    753e02602291:	31 c0                	xor    eax,eax
    753e02602293:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260229a:	5c 00 00 
    753e0260229d:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e026022a2:	45 31 c0             	xor    r8d,r8d
    753e026022a5:	ff d0                	call   rax
    753e026022a7:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026022ae:	00 
    753e026022af:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026022b5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026022bb:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026022c1:	be 0f 00 00 00       	mov    esi,0xf
    753e026022c6:	b9 02 00 00 00       	mov    ecx,0x2
    753e026022cb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026022d2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026022d9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026022e0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026022e7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026022ee:	e9 77 07 00 00       	jmp    0x753e02602a6a
    753e026022f3:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026022fa:	00 
    753e026022fb:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e02602302:	c1 e9 0c             	shr    ecx,0xc
    753e02602305:	89 c9                	mov    ecx,ecx
    753e02602307:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260230b:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e02602312:	00 
    753e02602313:	48 83 f8 00          	cmp    rax,0x0
    753e02602317:	74 20                	je     0x753e02602339
    753e02602319:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02602320:	00 
    753e02602321:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e02602328:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260232e:	89 c9                	mov    ecx,ecx
    753e02602330:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02602333:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e02602337:	eb 5a                	jmp    0x753e02602393
    753e02602339:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602340:	00 
    753e02602341:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [rsp+0x8c]
    753e02602348:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e0260234f:	00 
    753e02602350:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e02602357:	00 01 00 
    753e0260235a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602361:	00 00 00 
    753e02602364:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e0260236b:	00 00 00 
    753e0260236e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02602375:	5c 00 00 
    753e02602378:	ff d0                	call   rax
    753e0260237a:	89 c1                	mov    ecx,eax
    753e0260237c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602383:	00 
    753e02602384:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    753e02602388:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260238f:	75 2c                	jne    0x753e026023bd
    753e02602391:	eb 76                	jmp    0x753e02602409
    753e02602393:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    753e0260239a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026023a1:	00 
    753e026023a2:	8b 54 24 7c          	mov    edx,DWORD PTR [rsp+0x7c]
    753e026023a6:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    753e026023a9:	83 c0 04             	add    eax,0x4
    753e026023ac:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    753e026023b0:	83 e0 03             	and    eax,0x3
    753e026023b3:	83 f8 00             	cmp    eax,0x0
    753e026023b6:	75 5b                	jne    0x753e02602413
    753e026023b8:	e9 ea 00 00 00       	jmp    0x753e026024a7
    753e026023bd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026023c4:	00 
    753e026023c5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026023cb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026023d1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026023d7:	be 0f 00 00 00       	mov    esi,0xf
    753e026023dc:	b9 02 00 00 00       	mov    ecx,0x2
    753e026023e1:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026023e8:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026023ef:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026023f6:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026023fd:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602404:	e9 61 06 00 00       	jmp    0x753e02602a6a
    753e02602409:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    753e0260240d:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e02602411:	eb 80                	jmp    0x753e02602393
    753e02602413:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260241a:	00 
    753e0260241b:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e0260241f:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e02602426:	00 
    753e02602427:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e0260242e:	00 01 00 
    753e02602431:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02602438:	00 00 00 
    753e0260243b:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e02602442:	00 00 00 
    753e02602445:	31 c0                	xor    eax,eax
    753e02602447:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260244e:	5c 00 00 
    753e02602451:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e02602456:	45 31 c0             	xor    r8d,r8d
    753e02602459:	ff d0                	call   rax
    753e0260245b:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602462:	00 
    753e02602463:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02602469:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260246f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02602475:	be 0f 00 00 00       	mov    esi,0xf
    753e0260247a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260247f:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02602486:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260248d:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602494:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260249b:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026024a2:	e9 c3 05 00 00       	jmp    0x753e02602a6a
    753e026024a7:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026024ae:	00 
    753e026024af:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e026024b3:	c1 e9 0c             	shr    ecx,0xc
    753e026024b6:	89 c9                	mov    ecx,ecx
    753e026024b8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026024bc:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753e026024c1:	48 83 f8 00          	cmp    rax,0x0
    753e026024c5:	74 1a                	je     0x753e026024e1
    753e026024c7:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e026024cc:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e026024d0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026024d6:	89 c9                	mov    ecx,ecx
    753e026024d8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026024db:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e026024df:	eb 57                	jmp    0x753e02602538
    753e026024e1:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026024e8:	00 
    753e026024e9:	8b 74 24 74          	mov    esi,DWORD PTR [rsp+0x74]
    753e026024ed:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e026024f4:	00 
    753e026024f5:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e026024fc:	00 01 00 
    753e026024ff:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602506:	00 00 00 
    753e02602509:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e02602510:	00 00 00 
    753e02602513:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260251a:	5c 00 00 
    753e0260251d:	ff d0                	call   rax
    753e0260251f:	89 c1                	mov    ecx,eax
    753e02602521:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602528:	00 
    753e02602529:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    753e0260252d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02602534:	75 29                	jne    0x753e0260255f
    753e02602536:	eb 73                	jmp    0x753e026025ab
    753e02602538:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    753e0260253c:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02602543:	00 
    753e02602544:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    753e02602548:	89 51 18             	mov    DWORD PTR [rcx+0x18],edx
    753e0260254b:	83 c0 04             	add    eax,0x4
    753e0260254e:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    753e02602552:	83 e0 03             	and    eax,0x3
    753e02602555:	83 f8 00             	cmp    eax,0x0
    753e02602558:	75 5b                	jne    0x753e026025b5
    753e0260255a:	e9 ea 00 00 00       	jmp    0x753e02602649
    753e0260255f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602566:	00 
    753e02602567:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260256d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602573:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02602579:	be 0f 00 00 00       	mov    esi,0xf
    753e0260257e:	b9 02 00 00 00       	mov    ecx,0x2
    753e02602583:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260258a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02602591:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602598:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260259f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026025a6:	e9 bf 04 00 00       	jmp    0x753e02602a6a
    753e026025ab:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    753e026025af:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e026025b3:	eb 83                	jmp    0x753e02602538
    753e026025b5:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e026025bc:	00 
    753e026025bd:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e026025c1:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e026025c8:	00 
    753e026025c9:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e026025d0:	00 01 00 
    753e026025d3:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026025da:	00 00 00 
    753e026025dd:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e026025e4:	00 00 00 
    753e026025e7:	31 c0                	xor    eax,eax
    753e026025e9:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026025f0:	5c 00 00 
    753e026025f3:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e026025f8:	45 31 c0             	xor    r8d,r8d
    753e026025fb:	ff d0                	call   rax
    753e026025fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602604:	00 
    753e02602605:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260260b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602611:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02602617:	be 0f 00 00 00       	mov    esi,0xf
    753e0260261c:	b9 02 00 00 00       	mov    ecx,0x2
    753e02602621:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e02602628:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e0260262f:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602636:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260263d:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602644:	e9 21 04 00 00       	jmp    0x753e02602a6a
    753e02602649:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e02602650:	00 
    753e02602651:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02602655:	c1 e9 0c             	shr    ecx,0xc
    753e02602658:	89 c9                	mov    ecx,ecx
    753e0260265a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260265e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    753e02602663:	48 83 f8 00          	cmp    rax,0x0
    753e02602667:	74 1a                	je     0x753e02602683
    753e02602669:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    753e0260266e:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02602672:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02602678:	89 c9                	mov    ecx,ecx
    753e0260267a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260267d:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02602681:	eb 57                	jmp    0x753e026026da
    753e02602683:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260268a:	00 
    753e0260268b:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    753e0260268f:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02602696:	00 
    753e02602697:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e0260269e:	00 01 00 
    753e026026a1:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026026a8:	00 00 00 
    753e026026ab:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e026026b2:	00 00 00 
    753e026026b5:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026026bc:	5c 00 00 
    753e026026bf:	ff d0                	call   rax
    753e026026c1:	89 c1                	mov    ecx,eax
    753e026026c3:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026026ca:	00 
    753e026026cb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e026026cf:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026026d6:	75 29                	jne    0x753e02602701
    753e026026d8:	eb 73                	jmp    0x753e0260274d
    753e026026da:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    753e026026de:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e026026e5:	00 
    753e026026e6:	8b 54 24 4c          	mov    edx,DWORD PTR [rsp+0x4c]
    753e026026ea:	89 51 14             	mov    DWORD PTR [rcx+0x14],edx
    753e026026ed:	83 c0 04             	add    eax,0x4
    753e026026f0:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e026026f4:	83 e0 03             	and    eax,0x3
    753e026026f7:	83 f8 00             	cmp    eax,0x0
    753e026026fa:	75 5b                	jne    0x753e02602757
    753e026026fc:	e9 ea 00 00 00       	jmp    0x753e026027eb
    753e02602701:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602708:	00 
    753e02602709:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260270f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602715:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260271b:	be 0f 00 00 00       	mov    esi,0xf
    753e02602720:	b9 02 00 00 00       	mov    ecx,0x2
    753e02602725:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260272c:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02602733:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e0260273a:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e02602741:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602748:	e9 1d 03 00 00       	jmp    0x753e02602a6a
    753e0260274d:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e02602751:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02602755:	eb 83                	jmp    0x753e026026da
    753e02602757:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e0260275e:	00 
    753e0260275f:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02602763:	48 8b b4 24 f0 01 00 	mov    rsi,QWORD PTR [rsp+0x1f0]
    753e0260276a:	00 
    753e0260276b:	c7 87 bc 00 00 00 3c 	mov    DWORD PTR [rdi+0xbc],0x1003c
    753e02602772:	00 01 00 
    753e02602775:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260277c:	00 00 00 
    753e0260277f:	c7 87 34 01 00 00 0f 	mov    DWORD PTR [rdi+0x134],0xf
    753e02602786:	00 00 00 
    753e02602789:	31 c0                	xor    eax,eax
    753e0260278b:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02602792:	5c 00 00 
    753e02602795:	ba 3c 00 01 00       	mov    edx,0x1003c
    753e0260279a:	45 31 c0             	xor    r8d,r8d
    753e0260279d:	ff d0                	call   rax
    753e0260279f:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026027a6:	00 
    753e026027a7:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026027ad:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026027b3:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026027b9:	be 0f 00 00 00       	mov    esi,0xf
    753e026027be:	b9 02 00 00 00       	mov    ecx,0x2
    753e026027c3:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026027ca:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026027d1:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026027d8:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026027df:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026027e6:	e9 7f 02 00 00       	jmp    0x753e02602a6a
    753e026027eb:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
    753e026027f2:	00 
    753e026027f3:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e026027f7:	c1 e9 0c             	shr    ecx,0xc
    753e026027fa:	89 c9                	mov    ecx,ecx
    753e026027fc:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02602800:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e02602805:	48 83 f8 00          	cmp    rax,0x0
    753e02602809:	74 1a                	je     0x753e02602825
    753e0260280b:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e02602810:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02602814:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260281a:	89 c9                	mov    ecx,ecx
    753e0260281c:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260281f:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e02602823:	eb 57                	jmp    0x753e0260287c
    753e02602825:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260282c:	00 
    753e0260282d:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e02602831:	48 8b bc 24 f0 01 00 	mov    rdi,QWORD PTR [rsp+0x1f0]
    753e02602838:	00 
    753e02602839:	c7 80 bc 00 00 00 3c 	mov    DWORD PTR [rax+0xbc],0x1003c
    753e02602840:	00 01 00 
    753e02602843:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260284a:	00 00 00 
    753e0260284d:	c7 80 34 01 00 00 0f 	mov    DWORD PTR [rax+0x134],0xf
    753e02602854:	00 00 00 
    753e02602857:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260285e:	5c 00 00 
    753e02602861:	ff d0                	call   rax
    753e02602863:	89 c1                	mov    ecx,eax
    753e02602865:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260286c:	00 
    753e0260286d:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    753e02602871:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02602878:	75 1d                	jne    0x753e02602897
    753e0260287a:	eb 67                	jmp    0x753e026028e3
    753e0260287c:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602883:	00 
    753e02602884:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02602888:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    753e0260288c:	89 50 10             	mov    DWORD PTR [rax+0x10],edx
    753e0260288f:	83 c1 04             	add    ecx,0x4
    753e02602892:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02602895:	eb 56                	jmp    0x753e026028ed
    753e02602897:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e0260289e:	00 
    753e0260289f:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026028a5:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026028ab:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026028b1:	be 0f 00 00 00       	mov    esi,0xf
    753e026028b6:	b9 02 00 00 00       	mov    ecx,0x2
    753e026028bb:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026028c2:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026028c9:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026028d0:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026028d7:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026028de:	e9 87 01 00 00       	jmp    0x753e02602a6a
    753e026028e3:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    753e026028e7:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e026028eb:	eb 8f                	jmp    0x753e0260287c
    753e026028ed:	eb 00                	jmp    0x753e026028ef
    753e026028ef:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    753e026028f6:	83 e0 01             	and    eax,0x1
    753e026028f9:	83 f8 00             	cmp    eax,0x0
    753e026028fc:	75 3d                	jne    0x753e0260293b
    753e026028fe:	8b 94 24 d0 00 00 00 	mov    edx,DWORD PTR [rsp+0xd0]
    753e02602905:	be 10 00 00 00       	mov    esi,0x10
    753e0260290a:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260290f:	b0 01                	mov    al,0x1
    753e02602911:	89 d7                	mov    edi,edx
    753e02602913:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e0260291a:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e02602921:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e02602928:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e0260292f:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e02602936:	e9 2f 01 00 00       	jmp    0x753e02602a6a
    753e0260293b:	48 8b bc 24 f8 01 00 	mov    rdi,QWORD PTR [rsp+0x1f8]
    753e02602942:	00 
    753e02602943:	48 8b 94 24 f0 01 00 	mov    rdx,QWORD PTR [rsp+0x1f0]
    753e0260294a:	00 
    753e0260294b:	c7 87 bc 00 00 00 3e 	mov    DWORD PTR [rdi+0xbc],0x1003e
    753e02602952:	00 01 00 
    753e02602955:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260295c:	00 00 00 
    753e0260295f:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    753e02602966:	00 00 00 
    753e02602969:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e02602970:	5c 00 00 
    753e02602973:	be 2a 00 00 00       	mov    esi,0x2a
    753e02602978:	ff d0                	call   rax
    753e0260297a:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602981:	00 
    753e02602982:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02602988:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260298e:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02602994:	be 10 00 00 00       	mov    esi,0x10
    753e02602999:	b9 02 00 00 00       	mov    ecx,0x2
    753e0260299e:	89 bc 24 c8 01 00 00 	mov    DWORD PTR [rsp+0x1c8],edi
    753e026029a5:	89 b4 24 cc 01 00 00 	mov    DWORD PTR [rsp+0x1cc],esi
    753e026029ac:	89 94 24 d0 01 00 00 	mov    DWORD PTR [rsp+0x1d0],edx
    753e026029b3:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [rsp+0x1d4],ecx
    753e026029ba:	88 84 24 db 01 00 00 	mov    BYTE PTR [rsp+0x1db],al
    753e026029c1:	e9 a4 00 00 00       	jmp    0x753e02602a6a
    753e026029c6:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e026029cd:	00 
    753e026029ce:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e026029d5:	e9 82 01 00 00       	jmp    0x753e02602b5c
    753e026029da:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e026029e1:	00 
    753e026029e2:	48 89 c1             	mov    rcx,rax
    753e026029e5:	48 81 c1 00 02 08 00 	add    rcx,0x80200
    753e026029ec:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e026029f1:	81 b8 00 02 08 00 40 	cmp    DWORD PTR [rax+0x80200],0x10040
    753e026029f8:	00 01 00 
    753e026029fb:	74 32                	je     0x753e02602a2f
    753e026029fd:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602a04:	00 
    753e02602a05:	c7 80 bc 00 00 00 40 	mov    DWORD PTR [rax+0xbc],0x10040
    753e02602a0c:	00 01 00 
    753e02602a0f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602a16:	00 00 00 
    753e02602a19:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    753e02602a20:	00 00 00 
    753e02602a23:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e02602a2a:	e9 2d 01 00 00       	jmp    0x753e02602b5c
    753e02602a2f:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02602a36:	00 
    753e02602a37:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e02602a3e:	00 
    753e02602a3f:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e02602a44:	8b 8c 24 10 01 00 00 	mov    ecx,DWORD PTR [rsp+0x110]
    753e02602a4b:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10040
    753e02602a52:	40 00 01 00 
    753e02602a56:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02602a5d:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02602a61:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02602a68:	ff e0                	jmp    rax
    753e02602a6a:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
    753e02602a71:	00 
    753e02602a72:	8b 94 24 c8 01 00 00 	mov    edx,DWORD PTR [rsp+0x1c8]
    753e02602a79:	8b 84 24 cc 01 00 00 	mov    eax,DWORD PTR [rsp+0x1cc]
    753e02602a80:	8b b4 24 d0 01 00 00 	mov    esi,DWORD PTR [rsp+0x1d0]
    753e02602a87:	8b bc 24 d4 01 00 00 	mov    edi,DWORD PTR [rsp+0x1d4]
    753e02602a8e:	8a 9c 24 db 01 00 00 	mov    bl,BYTE PTR [rsp+0x1db]
    753e02602a95:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    753e02602a99:	89 c3                	mov    ebx,eax
    753e02602a9b:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    753e02602a9f:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    753e02602aa3:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    753e02602aa7:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    753e02602aab:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02602ab1:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e02602ab5:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02602abb:	73 2d                	jae    0x753e02602aea
    753e02602abd:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
    753e02602ac4:	00 
    753e02602ac5:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02602ac9:	89 d1                	mov    ecx,edx
    753e02602acb:	c1 e9 01             	shr    ecx,0x1
    753e02602ace:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02602ad4:	89 c9                	mov    ecx,ecx
    753e02602ad6:	48 c1 e1 04          	shl    rcx,0x4
    753e02602ada:	48 89 c6             	mov    rsi,rax
    753e02602add:	48 01 ce             	add    rsi,rcx
    753e02602ae0:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e02602ae5:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e02602ae8:	74 32                	je     0x753e02602b1c
    753e02602aea:	48 8b 84 24 f8 01 00 	mov    rax,QWORD PTR [rsp+0x1f8]
    753e02602af1:	00 
    753e02602af2:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    753e02602af6:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e02602afa:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    753e02602afe:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    753e02602b02:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e02602b08:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e02602b0e:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e02602b14:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e02602b1a:	eb 40                	jmp    0x753e02602b5c
    753e02602b1c:	4c 8b b4 24 f0 01 00 	mov    r14,QWORD PTR [rsp+0x1f0]
    753e02602b23:	00 
    753e02602b24:	4c 8b ac 24 f8 01 00 	mov    r13,QWORD PTR [rsp+0x1f8]
    753e02602b2b:	00 
    753e02602b2c:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e02602b31:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    753e02602b35:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e02602b39:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e02602b40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02602b47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e02602b4e:	00 
    753e02602b4f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02602b53:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02602b5a:	ff e0                	jmp    rax
    753e02602b5c:	48 81 c4 18 02 00 00 	add    rsp,0x218
    753e02602b63:	c2 08 00             	ret    0x8
