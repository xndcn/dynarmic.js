; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x00010488(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 66696
  %5 = icmp ugt i32 %4, 24
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb53 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb53, 0
  %10 = sub i32 %guard_lb53, 66696
  %11 = icmp ugt i32 %10, 24
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x00010488_entry, label %lb_guard_miss, !prof !0

insn_0x00010488_entry:                            ; preds = %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table72 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table72, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 28
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x00010488_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 7, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x00010488_entry, %27
  br label %insn_0x00010488

insn_0x00010488:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 40
  %old = load i32, ptr %29, align 4
  %lo_kept = and i32 %old, 65535
  %with_hi = or i32 %lo_kept, 65536
  %30 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi, ptr %30, align 4
  %31 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %32, align 4
  br label %insn_0x0001048c_entry

insn_0x0001048c_entry:                            ; preds = %insn_0x00010488
  br label %insn_0x0001048c

insn_0x0001048c:                                  ; preds = %insn_0x0001048c_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 4852
  %33 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo, ptr %33, align 4
  br label %insn_0x00010490_entry

insn_0x00010490_entry:                            ; preds = %insn_0x0001048c
  br label %insn_0x00010490

insn_0x00010490:                                  ; preds = %insn_0x00010490_entry
  %34 = and i32 %with_lo, 3
  %35 = icmp ne i32 %34, 0
  br i1 %35, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010490
  %36 = getelementptr i8, ptr %cpu, i32 188
  store i32 66704, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %37, align 4
  %38 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %38, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66704, i32 %with_lo, i32 0)
  %39 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %39, align 4
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010490
  %40 = lshr i32 %with_lo, 12
  %page_index = zext i32 %40 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %41 = and i32 %with_lo, 4095
  %page_offset = zext i32 %41 to i64
  %42 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %42, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %43 = getelementptr i8, ptr %cpu, i32 188
  store i32 66704, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 3, ptr %45, align 4
  %46 = call i32 @mem_read32(ptr %mem, i32 %with_lo)
  %47 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %47, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %46, %did_jump_cont ]
  %48 = getelementptr i8, ptr %cpu, i32 0
  store i32 %mem_val, ptr %48, align 4
  br label %insn_0x00010492_entry

did_jump_exit:                                    ; preds = %page_slow
  %49 = getelementptr i8, ptr %cpu, i64 188
  %next_pc54 = load i32, ptr %49, align 4
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

insn_0x00010492_entry:                            ; preds = %page_done
  br label %insn_0x00010492

insn_0x00010492:                                  ; preds = %insn_0x00010492_entry
  %lo_kept1 = and i32 %with_lo, 65535
  %with_hi2 = or i32 %lo_kept1, 65536
  %50 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_hi2, ptr %50, align 4
  br label %insn_0x00010496_entry

insn_0x00010496_entry:                            ; preds = %insn_0x00010492
  br label %insn_0x00010496

insn_0x00010496:                                  ; preds = %insn_0x00010496_entry
  %hi_kept3 = and i32 %with_hi2, -65536
  %with_lo4 = or i32 %hi_kept3, 4856
  %51 = getelementptr i8, ptr %cpu, i32 40
  store i32 %with_lo4, ptr %51, align 4
  br label %insn_0x0001049a_entry

insn_0x0001049a_entry:                            ; preds = %insn_0x00010496
  br label %insn_0x0001049a

insn_0x0001049a:                                  ; preds = %insn_0x0001049a_entry
  %52 = and i32 %with_lo4, 3
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %data_misaligned5, label %data_aligned6, !prof !1

data_misaligned5:                                 ; preds = %insn_0x0001049a
  %54 = getelementptr i8, ptr %cpu, i32 188
  store i32 66714, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %56, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66714, i32 %with_lo4, i32 0)
  %57 = getelementptr i8, ptr %cpu, i64 188
  %next_pc55 = load i32, ptr %57, align 4
  br label %chain_exit

data_aligned6:                                    ; preds = %insn_0x0001049a
  %58 = lshr i32 %with_lo4, 12
  %page_index10 = zext i32 %58 to i64
  %page_slot11 = getelementptr ptr, ptr %page_table, i64 %page_index10
  %page12 = load ptr, ptr %page_slot11, align 8
  %page_mapped13 = icmp ne ptr %page12, null
  br i1 %page_mapped13, label %page_fast7, label %page_slow8, !prof !0

page_fast7:                                       ; preds = %data_aligned6
  %59 = and i32 %with_lo4, 4095
  %page_offset14 = zext i32 %59 to i64
  %60 = getelementptr i8, ptr %page12, i64 %page_offset14
  %page_val15 = load i32, ptr %60, align 4
  br label %page_done9

page_slow8:                                       ; preds = %data_aligned6
  %61 = getelementptr i8, ptr %cpu, i32 188
  store i32 66714, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 308
  store i32 6, ptr %63, align 4
  %64 = call i32 @mem_read32(ptr %mem, i32 %with_lo4)
  %65 = getelementptr i8, ptr %cpu, i32 296
  %dj18 = load i8, ptr %65, align 1
  %dj_set19 = icmp ne i8 %dj18, 0
  br i1 %dj_set19, label %did_jump_exit16, label %did_jump_cont17, !prof !1

page_done9:                                       ; preds = %did_jump_cont17, %page_fast7
  %mem_val20 = phi i32 [ %page_val15, %page_fast7 ], [ %64, %did_jump_cont17 ]
  %66 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mem_val20, ptr %66, align 4
  br label %insn_0x0001049c_entry

did_jump_exit16:                                  ; preds = %page_slow8
  %67 = getelementptr i8, ptr %cpu, i64 188
  %next_pc56 = load i32, ptr %67, align 4
  br label %chain_exit

did_jump_cont17:                                  ; preds = %page_slow8
  br label %page_done9

insn_0x0001049c_entry:                            ; preds = %page_done9
  br label %insn_0x0001049c

insn_0x0001049c:                                  ; preds = %insn_0x0001049c_entry
  %68 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %68, align 4
  %69 = and i32 %fp, 3
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x0001049c
  %71 = getelementptr i8, ptr %cpu, i32 188
  store i32 66716, ptr %71, align 4
  %72 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %73, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66716, i32 %fp, i32 0)
  %74 = getelementptr i8, ptr %cpu, i64 188
  %next_pc57 = load i32, ptr %74, align 4
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x0001049c
  %75 = lshr i32 %fp, 12
  %page_index26 = zext i32 %75 to i64
  %page_slot27 = getelementptr ptr, ptr %page_table, i64 %page_index26
  %page28 = load ptr, ptr %page_slot27, align 8
  %page_mapped29 = icmp ne ptr %page28, null
  br i1 %page_mapped29, label %page_fast23, label %page_slow24, !prof !0

page_fast23:                                      ; preds = %data_aligned22
  %76 = and i32 %fp, 4095
  %page_offset30 = zext i32 %76 to i64
  %77 = getelementptr i8, ptr %page28, i64 %page_offset30
  %page_val31 = load i32, ptr %77, align 4
  br label %page_done25

page_slow24:                                      ; preds = %data_aligned22
  %78 = getelementptr i8, ptr %cpu, i32 188
  store i32 66716, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %79, align 4
  %80 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %80, align 4
  %81 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %82 = getelementptr i8, ptr %cpu, i32 296
  %dj34 = load i8, ptr %82, align 1
  %dj_set35 = icmp ne i8 %dj34, 0
  br i1 %dj_set35, label %did_jump_exit32, label %did_jump_cont33, !prof !1

page_done25:                                      ; preds = %did_jump_cont33, %page_fast23
  %mem_val36 = phi i32 [ %page_val31, %page_fast23 ], [ %81, %did_jump_cont33 ]
  %sp1 = add i32 %fp, 4
  %83 = and i32 %sp1, 3
  %84 = icmp ne i32 %83, 0
  br i1 %84, label %data_misaligned37, label %data_aligned38, !prof !1

did_jump_exit32:                                  ; preds = %page_slow24
  %85 = getelementptr i8, ptr %cpu, i64 188
  %next_pc58 = load i32, ptr %85, align 4
  br label %chain_exit

did_jump_cont33:                                  ; preds = %page_slow24
  br label %page_done25

data_misaligned37:                                ; preds = %page_done25
  %86 = getelementptr i8, ptr %cpu, i32 188
  store i32 66716, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %88, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 66716, i32 %sp1, i32 0)
  %89 = getelementptr i8, ptr %cpu, i64 188
  %next_pc59 = load i32, ptr %89, align 4
  br label %chain_exit

data_aligned38:                                   ; preds = %page_done25
  %90 = lshr i32 %sp1, 12
  %page_index42 = zext i32 %90 to i64
  %page_slot43 = getelementptr ptr, ptr %page_table, i64 %page_index42
  %page44 = load ptr, ptr %page_slot43, align 8
  %page_mapped45 = icmp ne ptr %page44, null
  br i1 %page_mapped45, label %page_fast39, label %page_slow40, !prof !0

page_fast39:                                      ; preds = %data_aligned38
  %91 = and i32 %sp1, 4095
  %page_offset46 = zext i32 %91 to i64
  %92 = getelementptr i8, ptr %page44, i64 %page_offset46
  %page_val47 = load i32, ptr %92, align 4
  br label %page_done41

page_slow40:                                      ; preds = %data_aligned38
  %93 = getelementptr i8, ptr %cpu, i32 188
  store i32 66716, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i32 308
  store i32 7, ptr %95, align 4
  %96 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %97 = getelementptr i8, ptr %cpu, i32 296
  %dj50 = load i8, ptr %97, align 1
  %dj_set51 = icmp ne i8 %dj50, 0
  br i1 %dj_set51, label %did_jump_exit48, label %did_jump_cont49, !prof !1

page_done41:                                      ; preds = %did_jump_cont49, %page_fast39
  %mem_val52 = phi i32 [ %page_val47, %page_fast39 ], [ %96, %did_jump_cont49 ]
  %sp2 = add i32 %sp1, 4
  %98 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val36, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val52, ptr %99, align 4
  %100 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %100, align 4
  br label %insn_0x000104a0_entry

did_jump_exit48:                                  ; preds = %page_slow40
  %101 = getelementptr i8, ptr %cpu, i64 188
  %next_pc60 = load i32, ptr %101, align 4
  br label %chain_exit

did_jump_cont49:                                  ; preds = %page_slow40
  br label %page_done41

insn_0x000104a0_entry:                            ; preds = %page_done41
  br label %insn_0x000104a0

insn_0x000104a0:                                  ; preds = %insn_0x000104a0_entry
  %102 = getelementptr i8, ptr %cpu, i32 188
  store i32 65744, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %103, align 4
  %chain_total = add nuw i32 %chain_packets, 8
  %104 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %104 monotonic, align 4, !range !2
  %105 = icmp ult i32 %chain_total, %chain_budget
  br i1 %105, label %chain_go, label %chain_leave61, !prof !0

lb_guard_miss:                                    ; preds = %lb_guard
  %106 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %106, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %insn_0x000104a0
  %chain_slot = getelementptr i8, ptr %chain_table, i64 525952
  %107 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %107, align 4
  %108 = icmp eq i32 %slot_pc, 65744
  br i1 %108, label %chain_hit, label %chain_leave61, !prof !0

chain_leave61:                                    ; preds = %chain_go, %insn_0x000104a0
  %109 = getelementptr i8, ptr %cpu, i64 188
  store i32 65744, ptr %109, align 4
  %110 = getelementptr i8, ptr %cpu, i64 292
  store i32 4, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i64 308
  store i32 8, ptr %111, align 4
  %112 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %112, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %113 = getelementptr i8, ptr %cpu, i64 188
  store i32 65744, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %114, align 4
  %115 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %115, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %did_jump_exit48, %data_misaligned37, %did_jump_exit32, %data_misaligned21, %did_jump_exit16, %data_misaligned5, %did_jump_exit, %data_misaligned
  %next_pc62 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc54, %did_jump_exit ], [ %next_pc55, %data_misaligned5 ], [ %next_pc56, %did_jump_exit16 ], [ %next_pc57, %data_misaligned21 ], [ %next_pc58, %did_jump_exit32 ], [ %next_pc59, %data_misaligned37 ], [ %next_pc60, %did_jump_exit48 ]
  %packets = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 6, %data_misaligned5 ], [ 6, %did_jump_exit16 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit32 ], [ 7, %data_misaligned37 ], [ 7, %did_jump_exit48 ]
  %tail = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned5 ], [ 2, %did_jump_exit16 ], [ 4, %data_misaligned21 ], [ 4, %did_jump_exit32 ], [ 4, %data_misaligned37 ], [ 4, %did_jump_exit48 ]
  %tail63 = phi i32 [ 3, %data_misaligned ], [ 3, %did_jump_exit ], [ 6, %data_misaligned5 ], [ 6, %did_jump_exit16 ], [ 7, %data_misaligned21 ], [ 7, %did_jump_exit32 ], [ 7, %data_misaligned37 ], [ 7, %did_jump_exit48 ]
  %116 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets65 = load i32, ptr %116, align 4
  %chain_total66 = add nuw i32 %chain_packets65, %packets
  %117 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget67 = load atomic i32, ptr %117 monotonic, align 4, !range !2
  %118 = icmp ult i32 %chain_total66, %chain_budget67
  br i1 %118, label %chain_lookup, label %chain_leave64, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %119 = lshr i32 %next_pc62, 1
  %120 = and i32 %119, 65535
  %121 = zext i32 %120 to i64
  %122 = mul i64 %121, 16
  %chain_slot68 = getelementptr i8, ptr %chain_table, i64 %122
  %123 = getelementptr i8, ptr %chain_slot68, i64 0
  %slot_pc69 = load i32, ptr %123, align 4
  %124 = icmp eq i32 %slot_pc69, %next_pc62
  br i1 %124, label %chain_hit70, label %chain_leave64, !prof !0

chain_leave64:                                    ; preds = %chain_lookup, %chain_exit
  %125 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail, ptr %125, align 4
  %126 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail63, ptr %126, align 4
  br label %return

chain_hit70:                                      ; preds = %chain_lookup
  %127 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total66, ptr %127, align 4
  %128 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %128, align 1
  %129 = getelementptr i8, ptr %chain_slot68, i64 8
  %chain_fn71 = load ptr, ptr %129, align 8
  musttail call swifttailcc void %chain_fn71(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave64, %chain_leave61, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
