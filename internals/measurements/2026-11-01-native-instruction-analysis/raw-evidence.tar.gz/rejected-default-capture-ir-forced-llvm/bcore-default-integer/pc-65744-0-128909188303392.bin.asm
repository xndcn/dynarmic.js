
build-native-instruction-analysis/capture/bcore-default-integer/pc-65744-0-128909188303392.bin:     file format binary


Disassembly of section .data:

0000753e02608a20 <.data>:
    753e02608a20:	48 81 ec 68 01 00 00 	sub    rsp,0x168
    753e02608a27:	4c 89 b4 24 40 01 00 	mov    QWORD PTR [rsp+0x140],r14
    753e02608a2e:	00 
    753e02608a2f:	4c 89 ac 24 48 01 00 	mov    QWORD PTR [rsp+0x148],r13
    753e02608a36:	00 
    753e02608a37:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02608a3e:	48 89 84 24 50 01 00 	mov    QWORD PTR [rsp+0x150],rax
    753e02608a45:	00 
    753e02608a46:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e02608a4d:	48 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],rax
    753e02608a54:	00 
    753e02608a55:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02608a5c:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
    753e02608a63:	00 
    753e02608a64:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02608a6b:	00 
    753e02608a6c:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02608a72:	83 fa 00             	cmp    edx,0x0
    753e02608a75:	0f 94 c0             	sete   al
    753e02608a78:	81 ea d0 00 01 00    	sub    edx,0x100d0
    753e02608a7e:	83 fa 3c             	cmp    edx,0x3c
    753e02608a81:	0f 97 c2             	seta   dl
    753e02608a84:	08 d0                	or     al,dl
    753e02608a86:	24 01                	and    al,0x1
    753e02608a88:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02608a8e:	83 fa 00             	cmp    edx,0x0
    753e02608a91:	0f 94 c1             	sete   cl
    753e02608a94:	81 ea d0 00 01 00    	sub    edx,0x100d0
    753e02608a9a:	83 fa 3c             	cmp    edx,0x3c
    753e02608a9d:	0f 97 c2             	seta   dl
    753e02608aa0:	08 d1                	or     cl,dl
    753e02608aa2:	20 c8                	and    al,cl
    753e02608aa4:	a8 01                	test   al,0x1
    753e02608aa6:	75 05                	jne    0x753e02608aad
    753e02608aa8:	e9 31 15 00 00       	jmp    0x753e02609fde
    753e02608aad:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608ab4:	00 
    753e02608ab5:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02608abc:	48 89 c8             	mov    rax,rcx
    753e02608abf:	48 05 00 00 10 00    	add    rax,0x100000
    753e02608ac5:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
    753e02608acc:	00 
    753e02608acd:	8b 81 20 00 10 00    	mov    eax,DWORD PTR [rcx+0x100020]
    753e02608ad3:	83 c0 01             	add    eax,0x1
    753e02608ad6:	89 81 20 00 10 00    	mov    DWORD PTR [rcx+0x100020],eax
    753e02608adc:	3d 75 a8 00 00       	cmp    eax,0xa875
    753e02608ae1:	75 4c                	jne    0x753e02608b2f
    753e02608ae3:	48 8b 8c 24 38 01 00 	mov    rcx,QWORD PTR [rsp+0x138]
    753e02608aea:	00 
    753e02608aeb:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02608af1:	89 84 24 34 01 00 00 	mov    DWORD PTR [rsp+0x134],eax
    753e02608af8:	89 c2                	mov    edx,eax
    753e02608afa:	83 c2 01             	add    edx,0x1
    753e02608afd:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02608b03:	3d 00 01 00 00       	cmp    eax,0x100
    753e02608b08:	73 23                	jae    0x753e02608b2d
    753e02608b0a:	48 8b 84 24 38 01 00 	mov    rax,QWORD PTR [rsp+0x138]
    753e02608b11:	00 
    753e02608b12:	8b 8c 24 34 01 00 00 	mov    ecx,DWORD PTR [rsp+0x134]
    753e02608b19:	89 c9                	mov    ecx,ecx
    753e02608b1b:	48 c1 e1 02          	shl    rcx,0x2
    753e02608b1f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02608b26:	c7 04 08 08 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x8
    753e02608b2d:	eb 00                	jmp    0x753e02608b2f
    753e02608b2f:	eb 00                	jmp    0x753e02608b31
    753e02608b31:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02608b38:	00 
    753e02608b39:	8b 41 38             	mov    eax,DWORD PTR [rcx+0x38]
    753e02608b3c:	83 e8 04             	sub    eax,0x4
    753e02608b3f:	89 84 24 2c 01 00 00 	mov    DWORD PTR [rsp+0x12c],eax
    753e02608b46:	8b 49 18             	mov    ecx,DWORD PTR [rcx+0x18]
    753e02608b49:	89 8c 24 30 01 00 00 	mov    DWORD PTR [rsp+0x130],ecx
    753e02608b50:	83 e0 03             	and    eax,0x3
    753e02608b53:	83 f8 00             	cmp    eax,0x0
    753e02608b56:	0f 84 8e 00 00 00    	je     0x753e02608bea
    753e02608b5c:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02608b63:	00 
    753e02608b64:	8b 8c 24 2c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x12c]
    753e02608b6b:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02608b72:	00 
    753e02608b73:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02608b7a:	00 00 00 
    753e02608b7d:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02608b84:	00 00 00 
    753e02608b87:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02608b8e:	5c 00 00 
    753e02608b91:	ba d0 00 01 00       	mov    edx,0x100d0
    753e02608b96:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02608b9c:	ff d0                	call   rax
    753e02608b9e:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608ba5:	00 
    753e02608ba6:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608bac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608bb2:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608bb8:	be 01 00 00 00       	mov    esi,0x1
    753e02608bbd:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608bc2:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608bc9:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608bd0:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608bd7:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608bde:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02608be5:	e9 28 15 00 00       	jmp    0x753e0260a112
    753e02608bea:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02608bf1:	00 
    753e02608bf2:	8b 8c 24 2c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x12c]
    753e02608bf9:	c1 e9 0c             	shr    ecx,0xc
    753e02608bfc:	89 c9                	mov    ecx,ecx
    753e02608bfe:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02608c02:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    753e02608c09:	00 
    753e02608c0a:	48 83 f8 00          	cmp    rax,0x0
    753e02608c0e:	74 23                	je     0x753e02608c33
    753e02608c10:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    753e02608c17:	00 
    753e02608c18:	8b 94 24 30 01 00 00 	mov    edx,DWORD PTR [rsp+0x130]
    753e02608c1f:	8b 8c 24 2c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x12c]
    753e02608c26:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02608c2c:	89 c9                	mov    ecx,ecx
    753e02608c2e:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02608c31:	eb 51                	jmp    0x753e02608c84
    753e02608c33:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608c3a:	00 
    753e02608c3b:	8b 94 24 30 01 00 00 	mov    edx,DWORD PTR [rsp+0x130]
    753e02608c42:	8b b4 24 2c 01 00 00 	mov    esi,DWORD PTR [rsp+0x12c]
    753e02608c49:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02608c50:	00 
    753e02608c51:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02608c58:	00 00 00 
    753e02608c5b:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02608c62:	00 00 00 
    753e02608c65:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02608c6c:	5c 00 00 
    753e02608c6f:	ff d0                	call   rax
    753e02608c71:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608c78:	00 
    753e02608c79:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02608c80:	75 32                	jne    0x753e02608cb4
    753e02608c82:	eb 7c                	jmp    0x753e02608d00
    753e02608c84:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02608c8b:	00 
    753e02608c8c:	8b 84 24 2c 01 00 00 	mov    eax,DWORD PTR [rsp+0x12c]
    753e02608c93:	83 e8 04             	sub    eax,0x4
    753e02608c96:	89 84 24 08 01 00 00 	mov    DWORD PTR [rsp+0x108],eax
    753e02608c9d:	8b 49 1c             	mov    ecx,DWORD PTR [rcx+0x1c]
    753e02608ca0:	89 8c 24 0c 01 00 00 	mov    DWORD PTR [rsp+0x10c],ecx
    753e02608ca7:	83 e0 03             	and    eax,0x3
    753e02608caa:	83 f8 00             	cmp    eax,0x0
    753e02608cad:	75 53                	jne    0x753e02608d02
    753e02608caf:	e9 dc 00 00 00       	jmp    0x753e02608d90
    753e02608cb4:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608cbb:	00 
    753e02608cbc:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608cc2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608cc8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608cce:	be 01 00 00 00       	mov    esi,0x1
    753e02608cd3:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608cd8:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608cdf:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608ce6:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608ced:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608cf4:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02608cfb:	e9 12 14 00 00       	jmp    0x753e0260a112
    753e02608d00:	eb 82                	jmp    0x753e02608c84
    753e02608d02:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02608d09:	00 
    753e02608d0a:	8b 8c 24 08 01 00 00 	mov    ecx,DWORD PTR [rsp+0x108]
    753e02608d11:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02608d18:	00 
    753e02608d19:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02608d20:	00 00 00 
    753e02608d23:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02608d2a:	00 00 00 
    753e02608d2d:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02608d34:	5c 00 00 
    753e02608d37:	ba d0 00 01 00       	mov    edx,0x100d0
    753e02608d3c:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02608d42:	ff d0                	call   rax
    753e02608d44:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608d4b:	00 
    753e02608d4c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608d52:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608d58:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608d5e:	be 01 00 00 00       	mov    esi,0x1
    753e02608d63:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608d68:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608d6f:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608d76:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608d7d:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608d84:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02608d8b:	e9 82 13 00 00       	jmp    0x753e0260a112
    753e02608d90:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02608d97:	00 
    753e02608d98:	8b 8c 24 08 01 00 00 	mov    ecx,DWORD PTR [rsp+0x108]
    753e02608d9f:	c1 e9 0c             	shr    ecx,0xc
    753e02608da2:	89 c9                	mov    ecx,ecx
    753e02608da4:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02608da8:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
    753e02608daf:	00 
    753e02608db0:	48 83 f8 00          	cmp    rax,0x0
    753e02608db4:	74 23                	je     0x753e02608dd9
    753e02608db6:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
    753e02608dbd:	00 
    753e02608dbe:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    753e02608dc5:	8b 8c 24 08 01 00 00 	mov    ecx,DWORD PTR [rsp+0x108]
    753e02608dcc:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02608dd2:	89 c9                	mov    ecx,ecx
    753e02608dd4:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e02608dd7:	eb 51                	jmp    0x753e02608e2a
    753e02608dd9:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608de0:	00 
    753e02608de1:	8b 94 24 0c 01 00 00 	mov    edx,DWORD PTR [rsp+0x10c]
    753e02608de8:	8b b4 24 08 01 00 00 	mov    esi,DWORD PTR [rsp+0x108]
    753e02608def:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02608df6:	00 
    753e02608df7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02608dfe:	00 00 00 
    753e02608e01:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e02608e08:	00 00 00 
    753e02608e0b:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02608e12:	5c 00 00 
    753e02608e15:	ff d0                	call   rax
    753e02608e17:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608e1e:	00 
    753e02608e1f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02608e26:	75 26                	jne    0x753e02608e4e
    753e02608e28:	eb 70                	jmp    0x753e02608e9a
    753e02608e2a:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    753e02608e31:	00 
    753e02608e32:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02608e39:	00 
    753e02608e3a:	8b 94 24 08 01 00 00 	mov    edx,DWORD PTR [rsp+0x108]
    753e02608e41:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e02608e44:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02608e47:	75 53                	jne    0x753e02608e9c
    753e02608e49:	e9 93 00 00 00       	jmp    0x753e02608ee1
    753e02608e4e:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608e55:	00 
    753e02608e56:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608e5c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608e62:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608e68:	be 01 00 00 00       	mov    esi,0x1
    753e02608e6d:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608e72:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608e79:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608e80:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608e87:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608e8e:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02608e95:	e9 78 12 00 00       	jmp    0x753e0260a112
    753e02608e9a:	eb 8e                	jmp    0x753e02608e2a
    753e02608e9c:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02608ea3:	00 
    753e02608ea4:	c7 87 bc 00 00 00 d2 	mov    DWORD PTR [rdi+0xbc],0x100d2
    753e02608eab:	00 01 00 
    753e02608eae:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02608eb5:	00 00 00 
    753e02608eb8:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e02608ebf:	00 00 00 
    753e02608ec2:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02608ec9:	5c 00 00 
    753e02608ecc:	ff d0                	call   rax
    753e02608ece:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608ed5:	00 
    753e02608ed6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02608edd:	75 04                	jne    0x753e02608ee3
    753e02608edf:	eb 4e                	jmp    0x753e02608f2f
    753e02608ee1:	eb 4e                	jmp    0x753e02608f31
    753e02608ee3:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608eea:	00 
    753e02608eeb:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608ef1:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608ef7:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608efd:	be 01 00 00 00       	mov    esi,0x1
    753e02608f02:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608f07:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608f0e:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608f15:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608f1c:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608f23:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02608f2a:	e9 e3 11 00 00       	jmp    0x753e0260a112
    753e02608f2f:	eb b0                	jmp    0x753e02608ee1
    753e02608f31:	eb 00                	jmp    0x753e02608f33
    753e02608f33:	8b 84 24 08 01 00 00 	mov    eax,DWORD PTR [rsp+0x108]
    753e02608f3a:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02608f41:	00 
    753e02608f42:	8b 91 a8 00 00 00    	mov    edx,DWORD PTR [rcx+0xa8]
    753e02608f48:	89 94 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],edx
    753e02608f4f:	8b 49 3c             	mov    ecx,DWORD PTR [rcx+0x3c]
    753e02608f52:	89 8c 24 f8 00 00 00 	mov    DWORD PTR [rsp+0xf8],ecx
    753e02608f59:	83 e8 04             	sub    eax,0x4
    753e02608f5c:	89 84 24 fc 00 00 00 	mov    DWORD PTR [rsp+0xfc],eax
    753e02608f63:	83 e0 03             	and    eax,0x3
    753e02608f66:	83 f8 00             	cmp    eax,0x0
    753e02608f69:	0f 84 98 00 00 00    	je     0x753e02609007
    753e02608f6f:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02608f76:	00 
    753e02608f77:	8b 8c 24 fc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xfc]
    753e02608f7e:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02608f85:	00 
    753e02608f86:	c7 87 bc 00 00 00 d2 	mov    DWORD PTR [rdi+0xbc],0x100d2
    753e02608f8d:	00 01 00 
    753e02608f90:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02608f97:	00 00 00 
    753e02608f9a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e02608fa1:	00 00 00 
    753e02608fa4:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02608fab:	5c 00 00 
    753e02608fae:	ba d2 00 01 00       	mov    edx,0x100d2
    753e02608fb3:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02608fb9:	ff d0                	call   rax
    753e02608fbb:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02608fc2:	00 
    753e02608fc3:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02608fc9:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608fcf:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608fd5:	be 02 00 00 00       	mov    esi,0x2
    753e02608fda:	b9 04 00 00 00       	mov    ecx,0x4
    753e02608fdf:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02608fe6:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02608fed:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02608ff4:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02608ffb:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609002:	e9 0b 11 00 00       	jmp    0x753e0260a112
    753e02609007:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e0260900e:	00 
    753e0260900f:	8b 8c 24 fc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xfc]
    753e02609016:	c1 e9 0c             	shr    ecx,0xc
    753e02609019:	89 c9                	mov    ecx,ecx
    753e0260901b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260901f:	48 89 84 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],rax
    753e02609026:	00 
    753e02609027:	48 83 f8 00          	cmp    rax,0x0
    753e0260902b:	74 23                	je     0x753e02609050
    753e0260902d:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
    753e02609034:	00 
    753e02609035:	8b 94 24 f4 00 00 00 	mov    edx,DWORD PTR [rsp+0xf4]
    753e0260903c:	8b 8c 24 fc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xfc]
    753e02609043:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02609049:	89 c9                	mov    ecx,ecx
    753e0260904b:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e0260904e:	eb 5b                	jmp    0x753e026090ab
    753e02609050:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609057:	00 
    753e02609058:	8b 94 24 f4 00 00 00 	mov    edx,DWORD PTR [rsp+0xf4]
    753e0260905f:	8b b4 24 fc 00 00 00 	mov    esi,DWORD PTR [rsp+0xfc]
    753e02609066:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e0260906d:	00 
    753e0260906e:	c7 80 bc 00 00 00 d2 	mov    DWORD PTR [rax+0xbc],0x100d2
    753e02609075:	00 01 00 
    753e02609078:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260907f:	00 00 00 
    753e02609082:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e02609089:	00 00 00 
    753e0260908c:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02609093:	5c 00 00 
    753e02609096:	ff d0                	call   rax
    753e02609098:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260909f:	00 
    753e026090a0:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026090a7:	75 20                	jne    0x753e026090c9
    753e026090a9:	eb 6a                	jmp    0x753e02609115
    753e026090ab:	8b 84 24 fc 00 00 00 	mov    eax,DWORD PTR [rsp+0xfc]
    753e026090b2:	83 e8 04             	sub    eax,0x4
    753e026090b5:	89 84 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],eax
    753e026090bc:	83 e0 03             	and    eax,0x3
    753e026090bf:	83 f8 00             	cmp    eax,0x0
    753e026090c2:	75 53                	jne    0x753e02609117
    753e026090c4:	e9 e6 00 00 00       	jmp    0x753e026091af
    753e026090c9:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026090d0:	00 
    753e026090d1:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026090d7:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026090dd:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026090e3:	be 02 00 00 00       	mov    esi,0x2
    753e026090e8:	b9 04 00 00 00       	mov    ecx,0x4
    753e026090ed:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e026090f4:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e026090fb:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609102:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609109:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609110:	e9 fd 0f 00 00       	jmp    0x753e0260a112
    753e02609115:	eb 94                	jmp    0x753e026090ab
    753e02609117:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e0260911e:	00 
    753e0260911f:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e02609126:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e0260912d:	00 
    753e0260912e:	c7 87 bc 00 00 00 d2 	mov    DWORD PTR [rdi+0xbc],0x100d2
    753e02609135:	00 01 00 
    753e02609138:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e0260913f:	00 00 00 
    753e02609142:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e02609149:	00 00 00 
    753e0260914c:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02609153:	5c 00 00 
    753e02609156:	ba d2 00 01 00       	mov    edx,0x100d2
    753e0260915b:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02609161:	ff d0                	call   rax
    753e02609163:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260916a:	00 
    753e0260916b:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609171:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609177:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260917d:	be 02 00 00 00       	mov    esi,0x2
    753e02609182:	b9 04 00 00 00       	mov    ecx,0x4
    753e02609187:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e0260918e:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609195:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e0260919c:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e026091a3:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e026091aa:	e9 63 0f 00 00       	jmp    0x753e0260a112
    753e026091af:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e026091b6:	00 
    753e026091b7:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e026091be:	c1 e9 0c             	shr    ecx,0xc
    753e026091c1:	89 c9                	mov    ecx,ecx
    753e026091c3:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026091c7:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    753e026091ce:	00 
    753e026091cf:	48 83 f8 00          	cmp    rax,0x0
    753e026091d3:	74 23                	je     0x753e026091f8
    753e026091d5:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e026091dc:	00 
    753e026091dd:	8b 94 24 f8 00 00 00 	mov    edx,DWORD PTR [rsp+0xf8]
    753e026091e4:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e026091eb:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026091f1:	89 c9                	mov    ecx,ecx
    753e026091f3:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026091f6:	eb 5b                	jmp    0x753e02609253
    753e026091f8:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026091ff:	00 
    753e02609200:	8b 94 24 f8 00 00 00 	mov    edx,DWORD PTR [rsp+0xf8]
    753e02609207:	8b b4 24 e4 00 00 00 	mov    esi,DWORD PTR [rsp+0xe4]
    753e0260920e:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02609215:	00 
    753e02609216:	c7 80 bc 00 00 00 d2 	mov    DWORD PTR [rax+0xbc],0x100d2
    753e0260921d:	00 01 00 
    753e02609220:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02609227:	00 00 00 
    753e0260922a:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e02609231:	00 00 00 
    753e02609234:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e0260923b:	5c 00 00 
    753e0260923e:	ff d0                	call   rax
    753e02609240:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609247:	00 
    753e02609248:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260924f:	75 2c                	jne    0x753e0260927d
    753e02609251:	eb 76                	jmp    0x753e026092c9
    753e02609253:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
    753e0260925a:	00 
    753e0260925b:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02609262:	00 
    753e02609263:	8b 94 24 e4 00 00 00 	mov    edx,DWORD PTR [rsp+0xe4]
    753e0260926a:	89 51 3c             	mov    DWORD PTR [rcx+0x3c],edx
    753e0260926d:	83 ea 00             	sub    edx,0x0
    753e02609270:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
    753e02609273:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02609276:	75 53                	jne    0x753e026092cb
    753e02609278:	e9 93 00 00 00       	jmp    0x753e02609310
    753e0260927d:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609284:	00 
    753e02609285:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260928b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609291:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609297:	be 02 00 00 00       	mov    esi,0x2
    753e0260929c:	b9 04 00 00 00       	mov    ecx,0x4
    753e026092a1:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e026092a8:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e026092af:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e026092b6:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e026092bd:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e026092c4:	e9 49 0e 00 00       	jmp    0x753e0260a112
    753e026092c9:	eb 88                	jmp    0x753e02609253
    753e026092cb:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e026092d2:	00 
    753e026092d3:	c7 87 bc 00 00 00 d6 	mov    DWORD PTR [rdi+0xbc],0x100d6
    753e026092da:	00 01 00 
    753e026092dd:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e026092e4:	00 00 00 
    753e026092e7:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e026092ee:	00 00 00 
    753e026092f1:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e026092f8:	5c 00 00 
    753e026092fb:	ff d0                	call   rax
    753e026092fd:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609304:	00 
    753e02609305:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260930c:	75 04                	jne    0x753e02609312
    753e0260930e:	eb 4e                	jmp    0x753e0260935e
    753e02609310:	eb 4e                	jmp    0x753e02609360
    753e02609312:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609319:	00 
    753e0260931a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609320:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609326:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e0260932c:	be 02 00 00 00       	mov    esi,0x2
    753e02609331:	b9 04 00 00 00       	mov    ecx,0x4
    753e02609336:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e0260933d:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609344:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e0260934b:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609352:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609359:	e9 b4 0d 00 00       	jmp    0x753e0260a112
    753e0260935e:	eb b0                	jmp    0x753e02609310
    753e02609360:	eb 00                	jmp    0x753e02609362
    753e02609362:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609369:	00 
    753e0260936a:	8b 38                	mov    edi,DWORD PTR [rax]
    753e0260936c:	89 bc 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],edi
    753e02609373:	89 fa                	mov    edx,edi
    753e02609375:	83 ea 00             	sub    edx,0x0
    753e02609378:	83 fa 00             	cmp    edx,0x0
    753e0260937b:	0f 94 c1             	sete   cl
    753e0260937e:	80 e1 01             	and    cl,0x1
    753e02609381:	0f b6 f1             	movzx  esi,cl
    753e02609384:	89 b4 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],esi
    753e0260938b:	c1 ea 1f             	shr    edx,0x1f
    753e0260938e:	89 f9                	mov    ecx,edi
    753e02609390:	c1 e9 1f             	shr    ecx,0x1f
    753e02609393:	89 d3                	mov    ebx,edx
    753e02609395:	31 cb                	xor    ebx,ecx
    753e02609397:	83 f1 00             	xor    ecx,0x0
    753e0260939a:	21 d9                	and    ecx,ebx
    753e0260939c:	31 ca                	xor    edx,ecx
    753e0260939e:	31 c9                	xor    ecx,ecx
    753e026093a0:	39 f9                	cmp    ecx,edi
    753e026093a2:	0f 96 c1             	setbe  cl
    753e026093a5:	80 e1 01             	and    cl,0x1
    753e026093a8:	0f b6 c9             	movzx  ecx,cl
    753e026093ab:	89 b0 14 01 00 00    	mov    DWORD PTR [rax+0x114],esi
    753e026093b1:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e026093b7:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e026093bd:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e026093c3:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e026093c9:	eb 00                	jmp    0x753e026093cb
    753e026093cb:	8b 84 24 d4 00 00 00 	mov    eax,DWORD PTR [rsp+0xd4]
    753e026093d2:	83 f8 00             	cmp    eax,0x0
    753e026093d5:	74 33                	je     0x753e0260940a
    753e026093d7:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e026093de:	00 
    753e026093df:	c7 81 bc 00 00 00 04 	mov    DWORD PTR [rcx+0xbc],0x10104
    753e026093e6:	01 01 00 
    753e026093e9:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e026093ef:	83 c0 04             	add    eax,0x4
    753e026093f2:	89 84 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],eax
    753e026093f9:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e026093ff:	0f 82 ed 0b 00 00    	jb     0x753e02609ff2
    753e02609405:	e9 0b 0c 00 00       	jmp    0x753e0260a015
    753e0260940a:	eb 00                	jmp    0x753e0260940c
    753e0260940c:	eb 00                	jmp    0x753e0260940e
    753e0260940e:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609415:	00 
    753e02609416:	8b 8c 24 30 01 00 00 	mov    ecx,DWORD PTR [rsp+0x130]
    753e0260941d:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02609423:	81 c9 00 00 19 00    	or     ecx,0x190000
    753e02609429:	89 8c 24 c8 00 00 00 	mov    DWORD PTR [rsp+0xc8],ecx
    753e02609430:	89 48 18             	mov    DWORD PTR [rax+0x18],ecx
    753e02609433:	eb 00                	jmp    0x753e02609435
    753e02609435:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260943c:	00 
    753e0260943d:	8b 8c 24 0c 01 00 00 	mov    ecx,DWORD PTR [rsp+0x10c]
    753e02609444:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260944a:	81 c9 00 00 6e 3c    	or     ecx,0x3c6e0000
    753e02609450:	89 8c 24 c4 00 00 00 	mov    DWORD PTR [rsp+0xc4],ecx
    753e02609457:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    753e0260945a:	eb 00                	jmp    0x753e0260945c
    753e0260945c:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609463:	00 
    753e02609464:	c7 40 08 00 00 00 00 	mov    DWORD PTR [rax+0x8],0x0
    753e0260946b:	eb 00                	jmp    0x753e0260946d
    753e0260946d:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609474:	00 
    753e02609475:	8b 8c 24 c8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc8]
    753e0260947c:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e02609482:	81 c9 0d 66 00 00    	or     ecx,0x660d
    753e02609488:	89 8c 24 c0 00 00 00 	mov    DWORD PTR [rsp+0xc0],ecx
    753e0260948f:	89 48 18             	mov    DWORD PTR [rax+0x18],ecx
    753e02609492:	eb 00                	jmp    0x753e02609494
    753e02609494:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260949b:	00 
    753e0260949c:	8b 8c 24 c4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc4]
    753e026094a3:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026094a9:	81 c9 5f f3 00 00    	or     ecx,0xf35f
    753e026094af:	89 8c 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],ecx
    753e026094b6:	89 48 1c             	mov    DWORD PTR [rax+0x1c],ecx
    753e026094b9:	eb 00                	jmp    0x753e026094bb
    753e026094bb:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026094c2:	00 
    753e026094c3:	8b 8c 24 c0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xc0]
    753e026094ca:	0f af 48 04          	imul   ecx,DWORD PTR [rax+0x4]
    753e026094ce:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    753e026094d5:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e026094d8:	eb 00                	jmp    0x753e026094da
    753e026094da:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026094e1:	00 
    753e026094e2:	8b bc 24 bc 00 00 00 	mov    edi,DWORD PTR [rsp+0xbc]
    753e026094e9:	8b 8c 24 b8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb8]
    753e026094f0:	89 ca                	mov    edx,ecx
    753e026094f2:	01 fa                	add    edx,edi
    753e026094f4:	89 94 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],edx
    753e026094fb:	89 50 04             	mov    DWORD PTR [rax+0x4],edx
    753e026094fe:	89 ce                	mov    esi,ecx
    753e02609500:	c1 ee 1f             	shr    esi,0x1f
    753e02609503:	89 fb                	mov    ebx,edi
    753e02609505:	c1 eb 1f             	shr    ebx,0x1f
    753e02609508:	89 d5                	mov    ebp,edx
    753e0260950a:	c1 ed 1f             	shr    ebp,0x1f
    753e0260950d:	31 eb                	xor    ebx,ebp
    753e0260950f:	31 ee                	xor    esi,ebp
    753e02609511:	21 de                	and    esi,ebx
    753e02609513:	83 f1 ff             	xor    ecx,0xffffffff
    753e02609516:	39 f9                	cmp    ecx,edi
    753e02609518:	0f 92 c1             	setb   cl
    753e0260951b:	80 e1 01             	and    cl,0x1
    753e0260951e:	0f b6 c9             	movzx  ecx,cl
    753e02609521:	83 fa 00             	cmp    edx,0x0
    753e02609524:	0f 94 c3             	sete   bl
    753e02609527:	80 e3 01             	and    bl,0x1
    753e0260952a:	0f b6 fb             	movzx  edi,bl
    753e0260952d:	c1 ea 1f             	shr    edx,0x1f
    753e02609530:	89 b8 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edi
    753e02609536:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e0260953c:	89 f2                	mov    edx,esi
    753e0260953e:	0b 90 00 01 00 00    	or     edx,DWORD PTR [rax+0x100]
    753e02609544:	89 94 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],edx
    753e0260954b:	89 b0 f8 00 00 00    	mov    DWORD PTR [rax+0xf8],esi
    753e02609551:	89 b0 fc 00 00 00    	mov    DWORD PTR [rax+0xfc],esi
    753e02609557:	89 90 00 01 00 00    	mov    DWORD PTR [rax+0x100],edx
    753e0260955d:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e02609563:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e02609569:	eb 00                	jmp    0x753e0260956b
    753e0260956b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609572:	00 
    753e02609573:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e0260957a:	c1 e9 0d             	shr    ecx,0xd
    753e0260957d:	89 8c 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],ecx
    753e02609584:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    753e02609587:	83 f9 00             	cmp    ecx,0x0
    753e0260958a:	0f 94 c2             	sete   dl
    753e0260958d:	80 e2 01             	and    dl,0x1
    753e02609590:	0f b6 d2             	movzx  edx,dl
    753e02609593:	c1 e9 1f             	shr    ecx,0x1f
    753e02609596:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260959c:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e026095a2:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e026095a9:	00 00 00 
    753e026095ac:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e026095b3:	00 00 00 
    753e026095b6:	eb 00                	jmp    0x753e026095b8
    753e026095b8:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026095bf:	00 
    753e026095c0:	8b 94 24 ac 00 00 00 	mov    edx,DWORD PTR [rsp+0xac]
    753e026095c7:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e026095ce:	31 d1                	xor    ecx,edx
    753e026095d0:	89 8c 24 a8 00 00 00 	mov    DWORD PTR [rsp+0xa8],ecx
    753e026095d7:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e026095da:	83 f9 00             	cmp    ecx,0x0
    753e026095dd:	0f 94 c2             	sete   dl
    753e026095e0:	80 e2 01             	and    dl,0x1
    753e026095e3:	0f b6 d2             	movzx  edx,dl
    753e026095e6:	c1 e9 1f             	shr    ecx,0x1f
    753e026095e9:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e026095ef:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e026095f5:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    753e026095fc:	00 00 00 
    753e026095ff:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    753e02609606:	00 00 00 
    753e02609609:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e02609610:	00 00 00 
    753e02609613:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e0260961a:	00 00 00 
    753e0260961d:	eb 00                	jmp    0x753e0260961f
    753e0260961f:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609626:	00 
    753e02609627:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    753e0260962e:	c1 e1 07             	shl    ecx,0x7
    753e02609631:	89 8c 24 a4 00 00 00 	mov    DWORD PTR [rsp+0xa4],ecx
    753e02609638:	89 48 0c             	mov    DWORD PTR [rax+0xc],ecx
    753e0260963b:	83 f9 00             	cmp    ecx,0x0
    753e0260963e:	0f 94 c2             	sete   dl
    753e02609641:	80 e2 01             	and    dl,0x1
    753e02609644:	0f b6 d2             	movzx  edx,dl
    753e02609647:	c1 e9 1f             	shr    ecx,0x1f
    753e0260964a:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e02609650:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e02609656:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260965d:	00 00 00 
    753e02609660:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e02609667:	00 00 00 
    753e0260966a:	eb 00                	jmp    0x753e0260966c
    753e0260966c:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609673:	00 
    753e02609674:	8b 8c 24 a8 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa8]
    753e0260967b:	c1 e9 19             	shr    ecx,0x19
    753e0260967e:	89 8c 24 a0 00 00 00 	mov    DWORD PTR [rsp+0xa0],ecx
    753e02609685:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e02609688:	83 f9 00             	cmp    ecx,0x0
    753e0260968b:	0f 94 c2             	sete   dl
    753e0260968e:	80 e2 01             	and    dl,0x1
    753e02609691:	0f b6 d2             	movzx  edx,dl
    753e02609694:	c1 e9 1f             	shr    ecx,0x1f
    753e02609697:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260969d:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e026096a3:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e026096aa:	00 00 00 
    753e026096ad:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e026096b4:	00 00 00 
    753e026096b7:	eb 00                	jmp    0x753e026096b9
    753e026096b9:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026096c0:	00 
    753e026096c1:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb4]
    753e026096c8:	c7 40 08 01 00 00 00 	mov    DWORD PTR [rax+0x8],0x1
    753e026096cf:	c7 80 e4 00 00 00 00 	mov    DWORD PTR [rax+0xe4],0x0
    753e026096d6:	00 00 00 
    753e026096d9:	c7 80 e8 00 00 00 00 	mov    DWORD PTR [rax+0xe8],0x0
    753e026096e0:	00 00 00 
    753e026096e3:	83 c9 00             	or     ecx,0x0
    753e026096e6:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e026096ed:	00 00 00 
    753e026096f0:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e026096f7:	00 00 00 
    753e026096fa:	89 88 00 01 00 00    	mov    DWORD PTR [rax+0x100],ecx
    753e02609700:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    753e02609707:	00 00 00 
    753e0260970a:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    753e02609711:	00 00 00 
    753e02609714:	eb 00                	jmp    0x753e02609716
    753e02609716:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260971d:	00 
    753e0260971e:	8b 94 24 a0 00 00 00 	mov    edx,DWORD PTR [rsp+0xa0]
    753e02609725:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xa4]
    753e0260972c:	09 d1                	or     ecx,edx
    753e0260972e:	89 8c 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],ecx
    753e02609735:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e02609738:	83 f9 00             	cmp    ecx,0x0
    753e0260973b:	0f 94 c2             	sete   dl
    753e0260973e:	80 e2 01             	and    dl,0x1
    753e02609741:	0f b6 d2             	movzx  edx,dl
    753e02609744:	c1 e9 1f             	shr    ecx,0x1f
    753e02609747:	89 90 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],edx
    753e0260974d:	89 88 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],ecx
    753e02609753:	c7 80 ec 00 00 00 00 	mov    DWORD PTR [rax+0xec],0x0
    753e0260975a:	00 00 00 
    753e0260975d:	c7 80 f0 00 00 00 00 	mov    DWORD PTR [rax+0xf0],0x0
    753e02609764:	00 00 00 
    753e02609767:	c7 80 f8 00 00 00 00 	mov    DWORD PTR [rax+0xf8],0x0
    753e0260976e:	00 00 00 
    753e02609771:	c7 80 fc 00 00 00 00 	mov    DWORD PTR [rax+0xfc],0x0
    753e02609778:	00 00 00 
    753e0260977b:	eb 00                	jmp    0x753e0260977d
    753e0260977d:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609784:	00 
    753e02609785:	8b bc 24 d0 00 00 00 	mov    edi,DWORD PTR [rsp+0xd0]
    753e0260978c:	83 ff 01             	cmp    edi,0x1
    753e0260978f:	0f 96 c1             	setbe  cl
    753e02609792:	80 e1 01             	and    cl,0x1
    753e02609795:	0f b6 c9             	movzx  ecx,cl
    753e02609798:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    753e0260979f:	89 88 14 01 00 00    	mov    DWORD PTR [rax+0x114],ecx
    753e026097a5:	83 ff 01             	cmp    edi,0x1
    753e026097a8:	0f 94 c1             	sete   cl
    753e026097ab:	80 e1 01             	and    cl,0x1
    753e026097ae:	0f b6 f1             	movzx  esi,cl
    753e026097b1:	b9 01 00 00 00       	mov    ecx,0x1
    753e026097b6:	39 f9                	cmp    ecx,edi
    753e026097b8:	0f 97 c1             	seta   cl
    753e026097bb:	80 e1 01             	and    cl,0x1
    753e026097be:	0f b6 d1             	movzx  edx,cl
    753e026097c1:	b9 01 00 00 00       	mov    ecx,0x1
    753e026097c6:	39 f9                	cmp    ecx,edi
    753e026097c8:	0f 96 c1             	setbe  cl
    753e026097cb:	80 e1 01             	and    cl,0x1
    753e026097ce:	0f b6 c9             	movzx  ecx,cl
    753e026097d1:	89 b0 e4 00 00 00    	mov    DWORD PTR [rax+0xe4],esi
    753e026097d7:	89 90 e8 00 00 00    	mov    DWORD PTR [rax+0xe8],edx
    753e026097dd:	89 88 ec 00 00 00    	mov    DWORD PTR [rax+0xec],ecx
    753e026097e3:	89 88 f0 00 00 00    	mov    DWORD PTR [rax+0xf0],ecx
    753e026097e9:	eb 00                	jmp    0x753e026097eb
    753e026097eb:	8b 84 24 98 00 00 00 	mov    eax,DWORD PTR [rsp+0x98]
    753e026097f2:	83 f8 00             	cmp    eax,0x0
    753e026097f5:	75 33                	jne    0x753e0260982a
    753e026097f7:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e026097fe:	00 
    753e026097ff:	c7 81 bc 00 00 00 ec 	mov    DWORD PTR [rcx+0xbc],0x100ec
    753e02609806:	00 01 00 
    753e02609809:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260980f:	83 c0 13             	add    eax,0x13
    753e02609812:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e02609819:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260981f:	0f 82 5d 08 00 00    	jb     0x753e0260a082
    753e02609825:	e9 7b 08 00 00       	jmp    0x753e0260a0a5
    753e0260982a:	eb 00                	jmp    0x753e0260982c
    753e0260982c:	eb 00                	jmp    0x753e0260982e
    753e0260982e:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    753e02609835:	83 e0 03             	and    eax,0x3
    753e02609838:	83 f8 00             	cmp    eax,0x0
    753e0260983b:	0f 84 97 00 00 00    	je     0x753e026098d8
    753e02609841:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02609848:	00 
    753e02609849:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e02609850:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02609857:	00 
    753e02609858:	c7 87 bc 00 00 00 04 	mov    DWORD PTR [rdi+0xbc],0x10104
    753e0260985f:	01 01 00 
    753e02609862:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02609869:	00 00 00 
    753e0260986c:	c7 87 34 01 00 00 14 	mov    DWORD PTR [rdi+0x134],0x14
    753e02609873:	00 00 00 
    753e02609876:	31 c0                	xor    eax,eax
    753e02609878:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260987f:	5c 00 00 
    753e02609882:	ba 04 01 01 00       	mov    edx,0x10104
    753e02609887:	45 31 c0             	xor    r8d,r8d
    753e0260988a:	ff d0                	call   rax
    753e0260988c:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609893:	00 
    753e02609894:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260989a:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026098a0:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026098a6:	be 14 00 00 00       	mov    esi,0x14
    753e026098ab:	b9 04 00 00 00       	mov    ecx,0x4
    753e026098b0:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e026098b7:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e026098be:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e026098c5:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e026098cc:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e026098d3:	e9 3a 08 00 00       	jmp    0x753e0260a112
    753e026098d8:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e026098df:	00 
    753e026098e0:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e026098e7:	c1 e9 0c             	shr    ecx,0xc
    753e026098ea:	89 c9                	mov    ecx,ecx
    753e026098ec:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026098f0:	48 89 84 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rax
    753e026098f7:	00 
    753e026098f8:	48 83 f8 00          	cmp    rax,0x0
    753e026098fc:	74 23                	je     0x753e02609921
    753e026098fe:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
    753e02609905:	00 
    753e02609906:	8b 8c 24 e4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xe4]
    753e0260990d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02609913:	89 c9                	mov    ecx,ecx
    753e02609915:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02609918:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    753e0260991f:	eb 5d                	jmp    0x753e0260997e
    753e02609921:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609928:	00 
    753e02609929:	8b b4 24 e4 00 00 00 	mov    esi,DWORD PTR [rsp+0xe4]
    753e02609930:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02609937:	00 
    753e02609938:	c7 80 bc 00 00 00 04 	mov    DWORD PTR [rax+0xbc],0x10104
    753e0260993f:	01 01 00 
    753e02609942:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02609949:	00 00 00 
    753e0260994c:	c7 80 34 01 00 00 14 	mov    DWORD PTR [rax+0x134],0x14
    753e02609953:	00 00 00 
    753e02609956:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260995d:	5c 00 00 
    753e02609960:	ff d0                	call   rax
    753e02609962:	89 c1                	mov    ecx,eax
    753e02609964:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260996b:	00 
    753e0260996c:	89 8c 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],ecx
    753e02609973:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260997a:	75 28                	jne    0x753e026099a4
    753e0260997c:	eb 72                	jmp    0x753e026099f0
    753e0260997e:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    753e02609985:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    753e0260998c:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    753e02609990:	83 c0 04             	add    eax,0x4
    753e02609993:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e02609997:	83 e0 03             	and    eax,0x3
    753e0260999a:	83 f8 00             	cmp    eax,0x0
    753e0260999d:	75 64                	jne    0x753e02609a03
    753e0260999f:	e9 f3 00 00 00       	jmp    0x753e02609a97
    753e026099a4:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e026099ab:	00 
    753e026099ac:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e026099b2:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026099b8:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e026099be:	be 14 00 00 00       	mov    esi,0x14
    753e026099c3:	b9 04 00 00 00       	mov    ecx,0x4
    753e026099c8:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e026099cf:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e026099d6:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e026099dd:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e026099e4:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e026099eb:	e9 22 07 00 00       	jmp    0x753e0260a112
    753e026099f0:	8b 84 24 80 00 00 00 	mov    eax,DWORD PTR [rsp+0x80]
    753e026099f7:	89 84 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],eax
    753e026099fe:	e9 7b ff ff ff       	jmp    0x753e0260997e
    753e02609a03:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02609a0a:	00 
    753e02609a0b:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02609a0f:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02609a16:	00 
    753e02609a17:	c7 87 bc 00 00 00 04 	mov    DWORD PTR [rdi+0xbc],0x10104
    753e02609a1e:	01 01 00 
    753e02609a21:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02609a28:	00 00 00 
    753e02609a2b:	c7 87 34 01 00 00 14 	mov    DWORD PTR [rdi+0x134],0x14
    753e02609a32:	00 00 00 
    753e02609a35:	31 c0                	xor    eax,eax
    753e02609a37:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02609a3e:	5c 00 00 
    753e02609a41:	ba 04 01 01 00       	mov    edx,0x10104
    753e02609a46:	45 31 c0             	xor    r8d,r8d
    753e02609a49:	ff d0                	call   rax
    753e02609a4b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609a52:	00 
    753e02609a53:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609a59:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609a5f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609a65:	be 14 00 00 00       	mov    esi,0x14
    753e02609a6a:	b9 04 00 00 00       	mov    ecx,0x4
    753e02609a6f:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609a76:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609a7d:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609a84:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609a8b:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609a92:	e9 7b 06 00 00       	jmp    0x753e0260a112
    753e02609a97:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02609a9e:	00 
    753e02609a9f:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02609aa3:	c1 e9 0c             	shr    ecx,0xc
    753e02609aa6:	89 c9                	mov    ecx,ecx
    753e02609aa8:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02609aac:	48 89 44 24 70       	mov    QWORD PTR [rsp+0x70],rax
    753e02609ab1:	48 83 f8 00          	cmp    rax,0x0
    753e02609ab5:	74 1a                	je     0x753e02609ad1
    753e02609ab7:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02609abc:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02609ac0:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02609ac6:	89 c9                	mov    ecx,ecx
    753e02609ac8:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02609acb:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e02609acf:	eb 57                	jmp    0x753e02609b28
    753e02609ad1:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609ad8:	00 
    753e02609ad9:	8b 74 24 7c          	mov    esi,DWORD PTR [rsp+0x7c]
    753e02609add:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02609ae4:	00 
    753e02609ae5:	c7 80 bc 00 00 00 04 	mov    DWORD PTR [rax+0xbc],0x10104
    753e02609aec:	01 01 00 
    753e02609aef:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02609af6:	00 00 00 
    753e02609af9:	c7 80 34 01 00 00 14 	mov    DWORD PTR [rax+0x134],0x14
    753e02609b00:	00 00 00 
    753e02609b03:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02609b0a:	5c 00 00 
    753e02609b0d:	ff d0                	call   rax
    753e02609b0f:	89 c1                	mov    ecx,eax
    753e02609b11:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609b18:	00 
    753e02609b19:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e02609b1d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02609b24:	75 2f                	jne    0x753e02609b55
    753e02609b26:	eb 79                	jmp    0x753e02609ba1
    753e02609b28:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609b2f:	00 
    753e02609b30:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    753e02609b34:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e02609b38:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
    753e02609b3c:	89 54 24 60          	mov    DWORD PTR [rsp+0x60],edx
    753e02609b40:	83 c1 04             	add    ecx,0x4
    753e02609b43:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    753e02609b47:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e02609b4a:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e02609b50:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02609b53:	eb 59                	jmp    0x753e02609bae
    753e02609b55:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609b5c:	00 
    753e02609b5d:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609b63:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609b69:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609b6f:	be 14 00 00 00       	mov    esi,0x14
    753e02609b74:	b9 04 00 00 00       	mov    ecx,0x4
    753e02609b79:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609b80:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609b87:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609b8e:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609b95:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609b9c:	e9 71 05 00 00       	jmp    0x753e0260a112
    753e02609ba1:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    753e02609ba5:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e02609ba9:	e9 7a ff ff ff       	jmp    0x753e02609b28
    753e02609bae:	eb 00                	jmp    0x753e02609bb0
    753e02609bb0:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609bb7:	00 
    753e02609bb8:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    753e02609bbf:	89 08                	mov    DWORD PTR [rax],ecx
    753e02609bc1:	eb 00                	jmp    0x753e02609bc3
    753e02609bc3:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    753e02609bc7:	83 e0 03             	and    eax,0x3
    753e02609bca:	83 f8 00             	cmp    eax,0x0
    753e02609bcd:	0f 84 94 00 00 00    	je     0x753e02609c67
    753e02609bd3:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02609bda:	00 
    753e02609bdb:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02609bdf:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02609be6:	00 
    753e02609be7:	c7 87 bc 00 00 00 0a 	mov    DWORD PTR [rdi+0xbc],0x1010a
    753e02609bee:	01 01 00 
    753e02609bf1:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02609bf8:	00 00 00 
    753e02609bfb:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    753e02609c02:	00 00 00 
    753e02609c05:	31 c0                	xor    eax,eax
    753e02609c07:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02609c0e:	5c 00 00 
    753e02609c11:	ba 0a 01 01 00       	mov    edx,0x1010a
    753e02609c16:	45 31 c0             	xor    r8d,r8d
    753e02609c19:	ff d0                	call   rax
    753e02609c1b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609c22:	00 
    753e02609c23:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609c29:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609c2f:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609c35:	be 16 00 00 00       	mov    esi,0x16
    753e02609c3a:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609c3f:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609c46:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609c4d:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609c54:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609c5b:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609c62:	e9 ab 04 00 00       	jmp    0x753e0260a112
    753e02609c67:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02609c6e:	00 
    753e02609c6f:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02609c73:	c1 e9 0c             	shr    ecx,0xc
    753e02609c76:	89 c9                	mov    ecx,ecx
    753e02609c78:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02609c7c:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e02609c81:	48 83 f8 00          	cmp    rax,0x0
    753e02609c85:	74 1a                	je     0x753e02609ca1
    753e02609c87:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e02609c8c:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e02609c90:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02609c96:	89 c9                	mov    ecx,ecx
    753e02609c98:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02609c9b:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e02609c9f:	eb 57                	jmp    0x753e02609cf8
    753e02609ca1:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609ca8:	00 
    753e02609ca9:	8b 74 24 64          	mov    esi,DWORD PTR [rsp+0x64]
    753e02609cad:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02609cb4:	00 
    753e02609cb5:	c7 80 bc 00 00 00 0a 	mov    DWORD PTR [rax+0xbc],0x1010a
    753e02609cbc:	01 01 00 
    753e02609cbf:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02609cc6:	00 00 00 
    753e02609cc9:	c7 80 34 01 00 00 16 	mov    DWORD PTR [rax+0x134],0x16
    753e02609cd0:	00 00 00 
    753e02609cd3:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02609cda:	5c 00 00 
    753e02609cdd:	ff d0                	call   rax
    753e02609cdf:	89 c1                	mov    ecx,eax
    753e02609ce1:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609ce8:	00 
    753e02609ce9:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e02609ced:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02609cf4:	75 29                	jne    0x753e02609d1f
    753e02609cf6:	eb 73                	jmp    0x753e02609d6b
    753e02609cf8:	8b 44 24 64          	mov    eax,DWORD PTR [rsp+0x64]
    753e02609cfc:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e02609d03:	00 
    753e02609d04:	8b 54 24 54          	mov    edx,DWORD PTR [rsp+0x54]
    753e02609d08:	89 51 1c             	mov    DWORD PTR [rcx+0x1c],edx
    753e02609d0b:	83 c0 04             	add    eax,0x4
    753e02609d0e:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02609d12:	83 e0 03             	and    eax,0x3
    753e02609d15:	83 f8 00             	cmp    eax,0x0
    753e02609d18:	75 5b                	jne    0x753e02609d75
    753e02609d1a:	e9 ea 00 00 00       	jmp    0x753e02609e09
    753e02609d1f:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609d26:	00 
    753e02609d27:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609d2d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609d33:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609d39:	be 16 00 00 00       	mov    esi,0x16
    753e02609d3e:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609d43:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609d4a:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609d51:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609d58:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609d5f:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609d66:	e9 a7 03 00 00       	jmp    0x753e0260a112
    753e02609d6b:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e02609d6f:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e02609d73:	eb 83                	jmp    0x753e02609cf8
    753e02609d75:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02609d7c:	00 
    753e02609d7d:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02609d81:	48 8b b4 24 40 01 00 	mov    rsi,QWORD PTR [rsp+0x140]
    753e02609d88:	00 
    753e02609d89:	c7 87 bc 00 00 00 0a 	mov    DWORD PTR [rdi+0xbc],0x1010a
    753e02609d90:	01 01 00 
    753e02609d93:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02609d9a:	00 00 00 
    753e02609d9d:	c7 87 34 01 00 00 16 	mov    DWORD PTR [rdi+0x134],0x16
    753e02609da4:	00 00 00 
    753e02609da7:	31 c0                	xor    eax,eax
    753e02609da9:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02609db0:	5c 00 00 
    753e02609db3:	ba 0a 01 01 00       	mov    edx,0x1010a
    753e02609db8:	45 31 c0             	xor    r8d,r8d
    753e02609dbb:	ff d0                	call   rax
    753e02609dbd:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609dc4:	00 
    753e02609dc5:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609dcb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609dd1:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609dd7:	be 16 00 00 00       	mov    esi,0x16
    753e02609ddc:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609de1:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609de8:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609def:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609df6:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609dfd:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609e04:	e9 09 03 00 00       	jmp    0x753e0260a112
    753e02609e09:	48 8b 84 24 60 01 00 	mov    rax,QWORD PTR [rsp+0x160]
    753e02609e10:	00 
    753e02609e11:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02609e15:	c1 e9 0c             	shr    ecx,0xc
    753e02609e18:	89 c9                	mov    ecx,ecx
    753e02609e1a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02609e1e:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
    753e02609e23:	48 83 f8 00          	cmp    rax,0x0
    753e02609e27:	74 1a                	je     0x753e02609e43
    753e02609e29:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
    753e02609e2e:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02609e32:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02609e38:	89 c9                	mov    ecx,ecx
    753e02609e3a:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02609e3d:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e02609e41:	eb 57                	jmp    0x753e02609e9a
    753e02609e43:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609e4a:	00 
    753e02609e4b:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e02609e4f:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
    753e02609e56:	00 
    753e02609e57:	c7 80 bc 00 00 00 0a 	mov    DWORD PTR [rax+0xbc],0x1010a
    753e02609e5e:	01 01 00 
    753e02609e61:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02609e68:	00 00 00 
    753e02609e6b:	c7 80 34 01 00 00 16 	mov    DWORD PTR [rax+0x134],0x16
    753e02609e72:	00 00 00 
    753e02609e75:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02609e7c:	5c 00 00 
    753e02609e7f:	ff d0                	call   rax
    753e02609e81:	89 c1                	mov    ecx,eax
    753e02609e83:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609e8a:	00 
    753e02609e8b:	89 4c 24 38          	mov    DWORD PTR [rsp+0x38],ecx
    753e02609e8f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02609e96:	75 1d                	jne    0x753e02609eb5
    753e02609e98:	eb 67                	jmp    0x753e02609f01
    753e02609e9a:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609ea1:	00 
    753e02609ea2:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02609ea6:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    753e02609eaa:	89 50 18             	mov    DWORD PTR [rax+0x18],edx
    753e02609ead:	83 c1 04             	add    ecx,0x4
    753e02609eb0:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e02609eb3:	eb 56                	jmp    0x753e02609f0b
    753e02609eb5:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609ebc:	00 
    753e02609ebd:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609ec3:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609ec9:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609ecf:	be 16 00 00 00       	mov    esi,0x16
    753e02609ed4:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609ed9:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609ee0:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609ee7:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609eee:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609ef5:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609efc:	e9 11 02 00 00       	jmp    0x753e0260a112
    753e02609f01:	8b 44 24 38          	mov    eax,DWORD PTR [rsp+0x38]
    753e02609f05:	89 44 24 3c          	mov    DWORD PTR [rsp+0x3c],eax
    753e02609f09:	eb 8f                	jmp    0x753e02609e9a
    753e02609f0b:	eb 00                	jmp    0x753e02609f0d
    753e02609f0d:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    753e02609f11:	83 e0 01             	and    eax,0x1
    753e02609f14:	83 f8 00             	cmp    eax,0x0
    753e02609f17:	75 3a                	jne    0x753e02609f53
    753e02609f19:	8b 54 24 60          	mov    edx,DWORD PTR [rsp+0x60]
    753e02609f1d:	be 17 00 00 00       	mov    esi,0x17
    753e02609f22:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609f27:	b0 01                	mov    al,0x1
    753e02609f29:	89 d7                	mov    edi,edx
    753e02609f2b:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609f32:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609f39:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609f40:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609f47:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609f4e:	e9 bf 01 00 00       	jmp    0x753e0260a112
    753e02609f53:	48 8b bc 24 48 01 00 	mov    rdi,QWORD PTR [rsp+0x148]
    753e02609f5a:	00 
    753e02609f5b:	48 8b 94 24 40 01 00 	mov    rdx,QWORD PTR [rsp+0x140]
    753e02609f62:	00 
    753e02609f63:	c7 87 bc 00 00 00 0c 	mov    DWORD PTR [rdi+0xbc],0x1010c
    753e02609f6a:	01 01 00 
    753e02609f6d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02609f74:	00 00 00 
    753e02609f77:	c7 87 34 01 00 00 17 	mov    DWORD PTR [rdi+0x134],0x17
    753e02609f7e:	00 00 00 
    753e02609f81:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e02609f88:	5c 00 00 
    753e02609f8b:	be 2a 00 00 00       	mov    esi,0x2a
    753e02609f90:	ff d0                	call   rax
    753e02609f92:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609f99:	00 
    753e02609f9a:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02609fa0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02609fa6:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02609fac:	be 17 00 00 00       	mov    esi,0x17
    753e02609fb1:	b9 02 00 00 00       	mov    ecx,0x2
    753e02609fb6:	89 bc 24 18 01 00 00 	mov    DWORD PTR [rsp+0x118],edi
    753e02609fbd:	89 b4 24 1c 01 00 00 	mov    DWORD PTR [rsp+0x11c],esi
    753e02609fc4:	89 94 24 20 01 00 00 	mov    DWORD PTR [rsp+0x120],edx
    753e02609fcb:	89 8c 24 24 01 00 00 	mov    DWORD PTR [rsp+0x124],ecx
    753e02609fd2:	88 84 24 2b 01 00 00 	mov    BYTE PTR [rsp+0x12b],al
    753e02609fd9:	e9 34 01 00 00       	jmp    0x753e0260a112
    753e02609fde:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e02609fe5:	00 
    753e02609fe6:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e02609fed:	e9 12 02 00 00       	jmp    0x753e0260a204
    753e02609ff2:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
    753e02609ff9:	00 
    753e02609ffa:	48 89 c1             	mov    rcx,rax
    753e02609ffd:	48 81 c1 20 08 08 00 	add    rcx,0x80820
    753e0260a004:	48 89 4c 24 30       	mov    QWORD PTR [rsp+0x30],rcx
    753e0260a009:	81 b8 20 08 08 00 04 	cmp    DWORD PTR [rax+0x80820],0x10104
    753e0260a010:	01 01 00 
    753e0260a013:	74 32                	je     0x753e0260a047
    753e0260a015:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260a01c:	00 
    753e0260a01d:	c7 80 bc 00 00 00 04 	mov    DWORD PTR [rax+0xbc],0x10104
    753e0260a024:	01 01 00 
    753e0260a027:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260a02e:	00 00 00 
    753e0260a031:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e0260a038:	00 00 00 
    753e0260a03b:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260a042:	e9 bd 01 00 00       	jmp    0x753e0260a204
    753e0260a047:	4c 8b b4 24 40 01 00 	mov    r14,QWORD PTR [rsp+0x140]
    753e0260a04e:	00 
    753e0260a04f:	4c 8b ac 24 48 01 00 	mov    r13,QWORD PTR [rsp+0x148]
    753e0260a056:	00 
    753e0260a057:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    753e0260a05c:	8b 8c 24 cc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xcc]
    753e0260a063:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10104
    753e0260a06a:	04 01 01 00 
    753e0260a06e:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260a075:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260a079:	48 81 c4 68 01 00 00 	add    rsp,0x168
    753e0260a080:	ff e0                	jmp    rax
    753e0260a082:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
    753e0260a089:	00 
    753e0260a08a:	48 89 c1             	mov    rcx,rax
    753e0260a08d:	48 81 c1 60 07 08 00 	add    rcx,0x80760
    753e0260a094:	48 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],rcx
    753e0260a099:	81 b8 60 07 08 00 ec 	cmp    DWORD PTR [rax+0x80760],0x100ec
    753e0260a0a0:	00 01 00 
    753e0260a0a3:	74 32                	je     0x753e0260a0d7
    753e0260a0a5:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260a0ac:	00 
    753e0260a0ad:	c7 80 bc 00 00 00 ec 	mov    DWORD PTR [rax+0xbc],0x100ec
    753e0260a0b4:	00 01 00 
    753e0260a0b7:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260a0be:	00 00 00 
    753e0260a0c1:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    753e0260a0c8:	00 00 00 
    753e0260a0cb:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260a0d2:	e9 2d 01 00 00       	jmp    0x753e0260a204
    753e0260a0d7:	4c 8b b4 24 40 01 00 	mov    r14,QWORD PTR [rsp+0x140]
    753e0260a0de:	00 
    753e0260a0df:	4c 8b ac 24 48 01 00 	mov    r13,QWORD PTR [rsp+0x148]
    753e0260a0e6:	00 
    753e0260a0e7:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
    753e0260a0ec:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260a0f3:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100ec
    753e0260a0fa:	ec 00 01 00 
    753e0260a0fe:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260a105:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260a109:	48 81 c4 68 01 00 00 	add    rsp,0x168
    753e0260a110:	ff e0                	jmp    rax
    753e0260a112:	48 8b 8c 24 48 01 00 	mov    rcx,QWORD PTR [rsp+0x148]
    753e0260a119:	00 
    753e0260a11a:	8b 94 24 18 01 00 00 	mov    edx,DWORD PTR [rsp+0x118]
    753e0260a121:	8b 84 24 1c 01 00 00 	mov    eax,DWORD PTR [rsp+0x11c]
    753e0260a128:	8b b4 24 20 01 00 00 	mov    esi,DWORD PTR [rsp+0x120]
    753e0260a12f:	8b bc 24 24 01 00 00 	mov    edi,DWORD PTR [rsp+0x124]
    753e0260a136:	8a 9c 24 2b 01 00 00 	mov    bl,BYTE PTR [rsp+0x12b]
    753e0260a13d:	88 5c 24 13          	mov    BYTE PTR [rsp+0x13],bl
    753e0260a141:	89 c3                	mov    ebx,eax
    753e0260a143:	89 5c 24 14          	mov    DWORD PTR [rsp+0x14],ebx
    753e0260a147:	89 7c 24 18          	mov    DWORD PTR [rsp+0x18],edi
    753e0260a14b:	89 74 24 1c          	mov    DWORD PTR [rsp+0x1c],esi
    753e0260a14f:	89 54 24 20          	mov    DWORD PTR [rsp+0x20],edx
    753e0260a153:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260a159:	89 44 24 24          	mov    DWORD PTR [rsp+0x24],eax
    753e0260a15d:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260a163:	73 2d                	jae    0x753e0260a192
    753e0260a165:	48 8b 84 24 50 01 00 	mov    rax,QWORD PTR [rsp+0x150]
    753e0260a16c:	00 
    753e0260a16d:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e0260a171:	89 d1                	mov    ecx,edx
    753e0260a173:	c1 e9 01             	shr    ecx,0x1
    753e0260a176:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260a17c:	89 c9                	mov    ecx,ecx
    753e0260a17e:	48 c1 e1 04          	shl    rcx,0x4
    753e0260a182:	48 89 c6             	mov    rsi,rax
    753e0260a185:	48 01 ce             	add    rsi,rcx
    753e0260a188:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e0260a18d:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e0260a190:	74 32                	je     0x753e0260a1c4
    753e0260a192:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
    753e0260a199:	00 
    753e0260a19a:	8a 4c 24 13          	mov    cl,BYTE PTR [rsp+0x13]
    753e0260a19e:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e0260a1a2:	8b 74 24 18          	mov    esi,DWORD PTR [rsp+0x18]
    753e0260a1a6:	8b 7c 24 1c          	mov    edi,DWORD PTR [rsp+0x1c]
    753e0260a1aa:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e0260a1b0:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e0260a1b6:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e0260a1bc:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e0260a1c2:	eb 40                	jmp    0x753e0260a204
    753e0260a1c4:	4c 8b b4 24 40 01 00 	mov    r14,QWORD PTR [rsp+0x140]
    753e0260a1cb:	00 
    753e0260a1cc:	4c 8b ac 24 48 01 00 	mov    r13,QWORD PTR [rsp+0x148]
    753e0260a1d3:	00 
    753e0260a1d4:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e0260a1d9:	8b 4c 24 24          	mov    ecx,DWORD PTR [rsp+0x24]
    753e0260a1dd:	8b 54 24 20          	mov    edx,DWORD PTR [rsp+0x20]
    753e0260a1e1:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e0260a1e8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260a1ef:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260a1f6:	00 
    753e0260a1f7:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260a1fb:	48 81 c4 68 01 00 00 	add    rsp,0x168
    753e0260a202:	ff e0                	jmp    rax
    753e0260a204:	48 81 c4 68 01 00 00 	add    rsp,0x168
    753e0260a20b:	c2 08 00             	ret    0x8
