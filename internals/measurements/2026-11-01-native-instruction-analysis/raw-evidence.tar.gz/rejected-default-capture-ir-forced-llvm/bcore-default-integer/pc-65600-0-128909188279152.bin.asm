
build-native-instruction-analysis/capture/bcore-default-integer/pc-65600-0-128909188279152.bin:     file format binary


Disassembly of section .data:

0000753e02602b70 <.data>:
    753e02602b70:	48 81 ec 28 01 00 00 	sub    rsp,0x128
    753e02602b77:	4c 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],r14
    753e02602b7e:	00 
    753e02602b7f:	4c 89 ac 24 08 01 00 	mov    QWORD PTR [rsp+0x108],r13
    753e02602b86:	00 
    753e02602b87:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02602b8e:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
    753e02602b95:	00 
    753e02602b96:	49 8b 85 40 01 00 00 	mov    rax,QWORD PTR [r13+0x140]
    753e02602b9d:	48 89 84 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rax
    753e02602ba4:	00 
    753e02602ba5:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02602bac:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
    753e02602bb3:	00 
    753e02602bb4:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    753e02602bbb:	00 
    753e02602bbc:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02602bc2:	83 fa 00             	cmp    edx,0x0
    753e02602bc5:	0f 94 c0             	sete   al
    753e02602bc8:	81 ea 40 00 01 00    	sub    edx,0x10040
    753e02602bce:	83 fa 4e             	cmp    edx,0x4e
    753e02602bd1:	0f 97 c2             	seta   dl
    753e02602bd4:	08 d0                	or     al,dl
    753e02602bd6:	24 01                	and    al,0x1
    753e02602bd8:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02602bde:	83 fa 00             	cmp    edx,0x0
    753e02602be1:	0f 94 c1             	sete   cl
    753e02602be4:	81 ea 40 00 01 00    	sub    edx,0x10040
    753e02602bea:	83 fa 4e             	cmp    edx,0x4e
    753e02602bed:	0f 97 c2             	seta   dl
    753e02602bf0:	08 d1                	or     cl,dl
    753e02602bf2:	20 c8                	and    al,cl
    753e02602bf4:	a8 01                	test   al,0x1
    753e02602bf6:	75 05                	jne    0x753e02602bfd
    753e02602bf8:	e9 6e 11 00 00       	jmp    0x753e02603d6b
    753e02602bfd:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602c04:	00 
    753e02602c05:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02602c0c:	48 89 c8             	mov    rax,rcx
    753e02602c0f:	48 05 00 00 10 00    	add    rax,0x100000
    753e02602c15:	48 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rax
    753e02602c1c:	00 
    753e02602c1d:	8b 81 08 00 10 00    	mov    eax,DWORD PTR [rcx+0x100008]
    753e02602c23:	83 c0 01             	add    eax,0x1
    753e02602c26:	89 81 08 00 10 00    	mov    DWORD PTR [rcx+0x100008],eax
    753e02602c2c:	3d 14 cd 00 00       	cmp    eax,0xcd14
    753e02602c31:	75 4c                	jne    0x753e02602c7f
    753e02602c33:	48 8b 8c 24 f8 00 00 	mov    rcx,QWORD PTR [rsp+0xf8]
    753e02602c3a:	00 
    753e02602c3b:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02602c41:	89 84 24 f4 00 00 00 	mov    DWORD PTR [rsp+0xf4],eax
    753e02602c48:	89 c2                	mov    edx,eax
    753e02602c4a:	83 c2 01             	add    edx,0x1
    753e02602c4d:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02602c53:	3d 00 01 00 00       	cmp    eax,0x100
    753e02602c58:	73 23                	jae    0x753e02602c7d
    753e02602c5a:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
    753e02602c61:	00 
    753e02602c62:	8b 8c 24 f4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xf4]
    753e02602c69:	89 c9                	mov    ecx,ecx
    753e02602c6b:	48 c1 e1 02          	shl    rcx,0x2
    753e02602c6f:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02602c76:	c7 04 08 02 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x2
    753e02602c7d:	eb 00                	jmp    0x753e02602c7f
    753e02602c7f:	eb 00                	jmp    0x753e02602c81
    753e02602c81:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602c88:	00 
    753e02602c89:	c7 40 28 01 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c01
    753e02602c90:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    753e02602c96:	89 8c 24 ec 00 00 00 	mov    DWORD PTR [rsp+0xec],ecx
    753e02602c9d:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    753e02602ca3:	89 84 24 f0 00 00 00 	mov    DWORD PTR [rsp+0xf0],eax
    753e02602caa:	eb 00                	jmp    0x753e02602cac
    753e02602cac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602cb3:	00 
    753e02602cb4:	c7 40 28 04 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf004
    753e02602cbb:	eb 00                	jmp    0x753e02602cbd
    753e02602cbd:	31 c0                	xor    eax,eax
    753e02602cbf:	a8 01                	test   al,0x1
    753e02602cc1:	75 02                	jne    0x753e02602cc5
    753e02602cc3:	eb 7b                	jmp    0x753e02602d40
    753e02602cc5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02602ccc:	00 
    753e02602ccd:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02602cd4:	00 
    753e02602cd5:	c7 87 bc 00 00 00 46 	mov    DWORD PTR [rdi+0xbc],0x10046
    753e02602cdc:	00 01 00 
    753e02602cdf:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02602ce6:	00 00 00 
    753e02602ce9:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e02602cf0:	00 00 00 
    753e02602cf3:	31 c0                	xor    eax,eax
    753e02602cf5:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02602cfc:	5c 00 00 
    753e02602cff:	ba 46 00 01 00       	mov    edx,0x10046
    753e02602d04:	b9 04 f0 00 00       	mov    ecx,0xf004
    753e02602d09:	45 31 c0             	xor    r8d,r8d
    753e02602d0c:	ff d0                	call   rax
    753e02602d0e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602d15:	00 
    753e02602d16:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602d1c:	b9 03 00 00 00       	mov    ecx,0x3
    753e02602d21:	b8 02 00 00 00       	mov    eax,0x2
    753e02602d26:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02602d2d:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02602d34:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02602d3b:	e9 cc 10 00 00       	jmp    0x753e02603e0c
    753e02602d40:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02602d47:	00 
    753e02602d48:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    753e02602d4c:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
    753e02602d53:	00 
    753e02602d54:	48 83 f8 00          	cmp    rax,0x0
    753e02602d58:	74 14                	je     0x753e02602d6e
    753e02602d5a:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
    753e02602d61:	00 
    753e02602d62:	8b 40 04             	mov    eax,DWORD PTR [rax+0x4]
    753e02602d65:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    753e02602d6c:	eb 5b                	jmp    0x753e02602dc9
    753e02602d6e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602d75:	00 
    753e02602d76:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e02602d7d:	00 
    753e02602d7e:	c7 80 bc 00 00 00 46 	mov    DWORD PTR [rax+0xbc],0x10046
    753e02602d85:	00 01 00 
    753e02602d88:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602d8f:	00 00 00 
    753e02602d92:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e02602d99:	00 00 00 
    753e02602d9c:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02602da3:	5c 00 00 
    753e02602da6:	be 04 f0 00 00       	mov    esi,0xf004
    753e02602dab:	ff d0                	call   rax
    753e02602dad:	89 c1                	mov    ecx,eax
    753e02602daf:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602db6:	00 
    753e02602db7:	89 8c 24 d0 00 00 00 	mov    DWORD PTR [rsp+0xd0],ecx
    753e02602dbe:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02602dc5:	75 1d                	jne    0x753e02602de4
    753e02602dc7:	eb 4d                	jmp    0x753e02602e16
    753e02602dc9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602dd0:	00 
    753e02602dd1:	8b 8c 24 d4 00 00 00 	mov    ecx,DWORD PTR [rsp+0xd4]
    753e02602dd8:	89 8c 24 cc 00 00 00 	mov    DWORD PTR [rsp+0xcc],ecx
    753e02602ddf:	89 48 10             	mov    DWORD PTR [rax+0x10],ecx
    753e02602de2:	eb 42                	jmp    0x753e02602e26
    753e02602de4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602deb:	00 
    753e02602dec:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602df2:	b9 03 00 00 00       	mov    ecx,0x3
    753e02602df7:	b8 02 00 00 00       	mov    eax,0x2
    753e02602dfc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02602e03:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02602e0a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02602e11:	e9 f6 0f 00 00       	jmp    0x753e02603e0c
    753e02602e16:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [rsp+0xd0]
    753e02602e1d:	89 84 24 d4 00 00 00 	mov    DWORD PTR [rsp+0xd4],eax
    753e02602e24:	eb a3                	jmp    0x753e02602dc9
    753e02602e26:	eb 00                	jmp    0x753e02602e28
    753e02602e28:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602e2f:	00 
    753e02602e30:	c7 40 28 08 f0 00 00 	mov    DWORD PTR [rax+0x28],0xf008
    753e02602e37:	eb 00                	jmp    0x753e02602e39
    753e02602e39:	31 c0                	xor    eax,eax
    753e02602e3b:	a8 01                	test   al,0x1
    753e02602e3d:	75 02                	jne    0x753e02602e41
    753e02602e3f:	eb 7b                	jmp    0x753e02602ebc
    753e02602e41:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02602e48:	00 
    753e02602e49:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02602e50:	00 
    753e02602e51:	c7 87 bc 00 00 00 4a 	mov    DWORD PTR [rdi+0xbc],0x1004a
    753e02602e58:	00 01 00 
    753e02602e5b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02602e62:	00 00 00 
    753e02602e65:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    753e02602e6c:	00 00 00 
    753e02602e6f:	31 c0                	xor    eax,eax
    753e02602e71:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02602e78:	5c 00 00 
    753e02602e7b:	ba 4a 00 01 00       	mov    edx,0x1004a
    753e02602e80:	b9 08 f0 00 00       	mov    ecx,0xf008
    753e02602e85:	45 31 c0             	xor    r8d,r8d
    753e02602e88:	ff d0                	call   rax
    753e02602e8a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602e91:	00 
    753e02602e92:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602e98:	b9 05 00 00 00       	mov    ecx,0x5
    753e02602e9d:	b8 02 00 00 00       	mov    eax,0x2
    753e02602ea2:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02602ea9:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02602eb0:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02602eb7:	e9 50 0f 00 00       	jmp    0x753e02603e0c
    753e02602ebc:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02602ec3:	00 
    753e02602ec4:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    753e02602ec8:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    753e02602ecf:	00 
    753e02602ed0:	48 83 f8 00          	cmp    rax,0x0
    753e02602ed4:	74 14                	je     0x753e02602eea
    753e02602ed6:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e02602edd:	00 
    753e02602ede:	8b 40 08             	mov    eax,DWORD PTR [rax+0x8]
    753e02602ee1:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e02602ee8:	eb 5b                	jmp    0x753e02602f45
    753e02602eea:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602ef1:	00 
    753e02602ef2:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e02602ef9:	00 
    753e02602efa:	c7 80 bc 00 00 00 4a 	mov    DWORD PTR [rax+0xbc],0x1004a
    753e02602f01:	00 01 00 
    753e02602f04:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02602f0b:	00 00 00 
    753e02602f0e:	c7 80 34 01 00 00 05 	mov    DWORD PTR [rax+0x134],0x5
    753e02602f15:	00 00 00 
    753e02602f18:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02602f1f:	5c 00 00 
    753e02602f22:	be 08 f0 00 00       	mov    esi,0xf008
    753e02602f27:	ff d0                	call   rax
    753e02602f29:	89 c1                	mov    ecx,eax
    753e02602f2b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602f32:	00 
    753e02602f33:	89 8c 24 b8 00 00 00 	mov    DWORD PTR [rsp+0xb8],ecx
    753e02602f3a:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02602f41:	75 1d                	jne    0x753e02602f60
    753e02602f43:	eb 4d                	jmp    0x753e02602f92
    753e02602f45:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602f4c:	00 
    753e02602f4d:	8b 8c 24 bc 00 00 00 	mov    ecx,DWORD PTR [rsp+0xbc]
    753e02602f54:	89 8c 24 b4 00 00 00 	mov    DWORD PTR [rsp+0xb4],ecx
    753e02602f5b:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02602f5e:	eb 42                	jmp    0x753e02602fa2
    753e02602f60:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602f67:	00 
    753e02602f68:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02602f6e:	b9 05 00 00 00       	mov    ecx,0x5
    753e02602f73:	b8 02 00 00 00       	mov    eax,0x2
    753e02602f78:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02602f7f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02602f86:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02602f8d:	e9 7a 0e 00 00       	jmp    0x753e02603e0c
    753e02602f92:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [rsp+0xb8]
    753e02602f99:	89 84 24 bc 00 00 00 	mov    DWORD PTR [rsp+0xbc],eax
    753e02602fa0:	eb a3                	jmp    0x753e02602f45
    753e02602fa2:	eb 00                	jmp    0x753e02602fa4
    753e02602fa4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602fab:	00 
    753e02602fac:	c7 00 01 00 00 00    	mov    DWORD PTR [rax],0x1
    753e02602fb2:	eb 00                	jmp    0x753e02602fb4
    753e02602fb4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602fbb:	00 
    753e02602fbc:	c7 40 2c 05 3c 00 00 	mov    DWORD PTR [rax+0x2c],0x3c05
    753e02602fc3:	eb 00                	jmp    0x753e02602fc5
    753e02602fc5:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602fcc:	00 
    753e02602fcd:	c7 40 2c 14 f0 00 00 	mov    DWORD PTR [rax+0x2c],0xf014
    753e02602fd4:	eb 00                	jmp    0x753e02602fd6
    753e02602fd6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02602fdd:	00 
    753e02602fde:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    753e02602fe1:	89 84 24 ac 00 00 00 	mov    DWORD PTR [rsp+0xac],eax
    753e02602fe8:	83 c0 fc             	add    eax,0xfffffffc
    753e02602feb:	89 84 24 b0 00 00 00 	mov    DWORD PTR [rsp+0xb0],eax
    753e02602ff2:	83 e0 03             	and    eax,0x3
    753e02602ff5:	83 f8 00             	cmp    eax,0x0
    753e02602ff8:	74 7e                	je     0x753e02603078
    753e02602ffa:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603001:	00 
    753e02603002:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e02603009:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603010:	00 
    753e02603011:	c7 87 bc 00 00 00 54 	mov    DWORD PTR [rdi+0xbc],0x10054
    753e02603018:	00 01 00 
    753e0260301b:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603022:	00 00 00 
    753e02603025:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    753e0260302c:	00 00 00 
    753e0260302f:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603036:	5c 00 00 
    753e02603039:	ba 54 00 01 00       	mov    edx,0x10054
    753e0260303e:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02603044:	ff d0                	call   rax
    753e02603046:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260304d:	00 
    753e0260304e:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603054:	b9 09 00 00 00       	mov    ecx,0x9
    753e02603059:	b8 02 00 00 00       	mov    eax,0x2
    753e0260305e:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603065:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e0260306c:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603073:	e9 94 0d 00 00       	jmp    0x753e02603e0c
    753e02603078:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e0260307f:	00 
    753e02603080:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e02603087:	c1 e9 0c             	shr    ecx,0xc
    753e0260308a:	89 c9                	mov    ecx,ecx
    753e0260308c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02603090:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    753e02603097:	00 
    753e02603098:	48 83 f8 00          	cmp    rax,0x0
    753e0260309c:	74 23                	je     0x753e026030c1
    753e0260309e:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    753e026030a5:	00 
    753e026030a6:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e026030ad:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [rsp+0xb0]
    753e026030b4:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026030ba:	89 c9                	mov    ecx,ecx
    753e026030bc:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026030bf:	eb 5b                	jmp    0x753e0260311c
    753e026030c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026030c8:	00 
    753e026030c9:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [rsp+0xb4]
    753e026030d0:	8b b4 24 b0 00 00 00 	mov    esi,DWORD PTR [rsp+0xb0]
    753e026030d7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e026030de:	00 
    753e026030df:	c7 80 bc 00 00 00 54 	mov    DWORD PTR [rax+0xbc],0x10054
    753e026030e6:	00 01 00 
    753e026030e9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026030f0:	00 00 00 
    753e026030f3:	c7 80 34 01 00 00 09 	mov    DWORD PTR [rax+0x134],0x9
    753e026030fa:	00 00 00 
    753e026030fd:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e02603104:	5c 00 00 
    753e02603107:	ff d0                	call   rax
    753e02603109:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603110:	00 
    753e02603111:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603118:	75 11                	jne    0x753e0260312b
    753e0260311a:	eb 41                	jmp    0x753e0260315d
    753e0260311c:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    753e02603123:	00 
    753e02603124:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02603127:	75 36                	jne    0x753e0260315f
    753e02603129:	eb 79                	jmp    0x753e026031a4
    753e0260312b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603132:	00 
    753e02603133:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603139:	b9 09 00 00 00       	mov    ecx,0x9
    753e0260313e:	b8 02 00 00 00       	mov    eax,0x2
    753e02603143:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e0260314a:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603151:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603158:	e9 af 0c 00 00       	jmp    0x753e02603e0c
    753e0260315d:	eb bd                	jmp    0x753e0260311c
    753e0260315f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603166:	00 
    753e02603167:	c7 87 bc 00 00 00 56 	mov    DWORD PTR [rdi+0xbc],0x10056
    753e0260316e:	00 01 00 
    753e02603171:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603178:	00 00 00 
    753e0260317b:	c7 87 34 01 00 00 09 	mov    DWORD PTR [rdi+0x134],0x9
    753e02603182:	00 00 00 
    753e02603185:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260318c:	5c 00 00 
    753e0260318f:	ff d0                	call   rax
    753e02603191:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603198:	00 
    753e02603199:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026031a0:	75 04                	jne    0x753e026031a6
    753e026031a2:	eb 34                	jmp    0x753e026031d8
    753e026031a4:	eb 34                	jmp    0x753e026031da
    753e026031a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026031ad:	00 
    753e026031ae:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026031b4:	b9 09 00 00 00       	mov    ecx,0x9
    753e026031b9:	b8 02 00 00 00       	mov    eax,0x2
    753e026031be:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e026031c5:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e026031cc:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e026031d3:	e9 34 0c 00 00       	jmp    0x753e02603e0c
    753e026031d8:	eb ca                	jmp    0x753e026031a4
    753e026031da:	eb 00                	jmp    0x753e026031dc
    753e026031dc:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026031e3:	00 
    753e026031e4:	c7 40 28 03 3c 00 00 	mov    DWORD PTR [rax+0x28],0x3c03
    753e026031eb:	eb 00                	jmp    0x753e026031ed
    753e026031ed:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026031f4:	00 
    753e026031f5:	c7 40 28 0c f0 00 00 	mov    DWORD PTR [rax+0x28],0xf00c
    753e026031fc:	eb 00                	jmp    0x753e026031fe
    753e026031fe:	31 c0                	xor    eax,eax
    753e02603200:	a8 01                	test   al,0x1
    753e02603202:	75 02                	jne    0x753e02603206
    753e02603204:	eb 7b                	jmp    0x753e02603281
    753e02603206:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e0260320d:	00 
    753e0260320e:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603215:	00 
    753e02603216:	c7 87 bc 00 00 00 5c 	mov    DWORD PTR [rdi+0xbc],0x1005c
    753e0260321d:	00 01 00 
    753e02603220:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603227:	00 00 00 
    753e0260322a:	c7 87 34 01 00 00 0c 	mov    DWORD PTR [rdi+0x134],0xc
    753e02603231:	00 00 00 
    753e02603234:	31 c0                	xor    eax,eax
    753e02603236:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260323d:	5c 00 00 
    753e02603240:	ba 5c 00 01 00       	mov    edx,0x1005c
    753e02603245:	b9 0c f0 00 00       	mov    ecx,0xf00c
    753e0260324a:	45 31 c0             	xor    r8d,r8d
    753e0260324d:	ff d0                	call   rax
    753e0260324f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603256:	00 
    753e02603257:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260325d:	b9 0c 00 00 00       	mov    ecx,0xc
    753e02603262:	b8 02 00 00 00       	mov    eax,0x2
    753e02603267:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e0260326e:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603275:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e0260327c:	e9 8b 0b 00 00       	jmp    0x753e02603e0c
    753e02603281:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02603288:	00 
    753e02603289:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    753e0260328d:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    753e02603294:	00 
    753e02603295:	48 83 f8 00          	cmp    rax,0x0
    753e02603299:	74 14                	je     0x753e026032af
    753e0260329b:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e026032a2:	00 
    753e026032a3:	8b 40 0c             	mov    eax,DWORD PTR [rax+0xc]
    753e026032a6:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e026032ad:	eb 5b                	jmp    0x753e0260330a
    753e026032af:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026032b6:	00 
    753e026032b7:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e026032be:	00 
    753e026032bf:	c7 80 bc 00 00 00 5c 	mov    DWORD PTR [rax+0xbc],0x1005c
    753e026032c6:	00 01 00 
    753e026032c9:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026032d0:	00 00 00 
    753e026032d3:	c7 80 34 01 00 00 0c 	mov    DWORD PTR [rax+0x134],0xc
    753e026032da:	00 00 00 
    753e026032dd:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026032e4:	5c 00 00 
    753e026032e7:	be 0c f0 00 00       	mov    esi,0xf00c
    753e026032ec:	ff d0                	call   rax
    753e026032ee:	89 c1                	mov    ecx,eax
    753e026032f0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026032f7:	00 
    753e026032f8:	89 8c 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],ecx
    753e026032ff:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603306:	75 1d                	jne    0x753e02603325
    753e02603308:	eb 4d                	jmp    0x753e02603357
    753e0260330a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603311:	00 
    753e02603312:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e02603319:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e02603320:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02603323:	eb 42                	jmp    0x753e02603367
    753e02603325:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260332c:	00 
    753e0260332d:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603333:	b9 0c 00 00 00       	mov    ecx,0xc
    753e02603338:	b8 02 00 00 00       	mov    eax,0x2
    753e0260333d:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603344:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e0260334b:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603352:	e9 b5 0a 00 00       	jmp    0x753e02603e0c
    753e02603357:	8b 84 24 90 00 00 00 	mov    eax,DWORD PTR [rsp+0x90]
    753e0260335e:	89 84 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],eax
    753e02603365:	eb a3                	jmp    0x753e0260330a
    753e02603367:	eb 00                	jmp    0x753e02603369
    753e02603369:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603370:	00 
    753e02603371:	8b 48 34             	mov    ecx,DWORD PTR [rax+0x34]
    753e02603374:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260337a:	83 c9 00             	or     ecx,0x0
    753e0260337d:	89 8c 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],ecx
    753e02603384:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    753e02603387:	eb 00                	jmp    0x753e02603389
    753e02603389:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603390:	00 
    753e02603391:	8b 48 30             	mov    ecx,DWORD PTR [rax+0x30]
    753e02603394:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260339a:	81 c9 00 00 00 01    	or     ecx,0x1000000
    753e026033a0:	89 8c 24 84 00 00 00 	mov    DWORD PTR [rsp+0x84],ecx
    753e026033a7:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    753e026033aa:	eb 00                	jmp    0x753e026033ac
    753e026033ac:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026033b3:	00 
    753e026033b4:	8b 8c 24 88 00 00 00 	mov    ecx,DWORD PTR [rsp+0x88]
    753e026033bb:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026033c1:	81 c9 18 f0 00 00    	or     ecx,0xf018
    753e026033c7:	89 48 34             	mov    DWORD PTR [rax+0x34],ecx
    753e026033ca:	eb 00                	jmp    0x753e026033cc
    753e026033cc:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    753e026033d3:	83 c0 f8             	add    eax,0xfffffff8
    753e026033d6:	89 84 24 80 00 00 00 	mov    DWORD PTR [rsp+0x80],eax
    753e026033dd:	83 e0 03             	and    eax,0x3
    753e026033e0:	83 f8 00             	cmp    eax,0x0
    753e026033e3:	74 7e                	je     0x753e02603463
    753e026033e5:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e026033ec:	00 
    753e026033ed:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    753e026033f4:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e026033fb:	00 
    753e026033fc:	c7 87 bc 00 00 00 6a 	mov    DWORD PTR [rdi+0xbc],0x1006a
    753e02603403:	00 01 00 
    753e02603406:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260340d:	00 00 00 
    753e02603410:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    753e02603417:	00 00 00 
    753e0260341a:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603421:	5c 00 00 
    753e02603424:	ba 6a 00 01 00       	mov    edx,0x1006a
    753e02603429:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260342f:	ff d0                	call   rax
    753e02603431:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603438:	00 
    753e02603439:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260343f:	b9 10 00 00 00       	mov    ecx,0x10
    753e02603444:	b8 02 00 00 00       	mov    eax,0x2
    753e02603449:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603450:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603457:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e0260345e:	e9 a9 09 00 00       	jmp    0x753e02603e0c
    753e02603463:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e0260346a:	00 
    753e0260346b:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    753e02603472:	c1 e9 0c             	shr    ecx,0xc
    753e02603475:	89 c9                	mov    ecx,ecx
    753e02603477:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260347b:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753e02603480:	48 83 f8 00          	cmp    rax,0x0
    753e02603484:	74 20                	je     0x753e026034a6
    753e02603486:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e0260348b:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    753e02603492:	8b 8c 24 80 00 00 00 	mov    ecx,DWORD PTR [rsp+0x80]
    753e02603499:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260349f:	89 c9                	mov    ecx,ecx
    753e026034a1:	89 14 08             	mov    DWORD PTR [rax+rcx*1],edx
    753e026034a4:	eb 5b                	jmp    0x753e02603501
    753e026034a6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026034ad:	00 
    753e026034ae:	8b 94 24 8c 00 00 00 	mov    edx,DWORD PTR [rsp+0x8c]
    753e026034b5:	8b b4 24 80 00 00 00 	mov    esi,DWORD PTR [rsp+0x80]
    753e026034bc:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e026034c3:	00 
    753e026034c4:	c7 80 bc 00 00 00 6a 	mov    DWORD PTR [rax+0xbc],0x1006a
    753e026034cb:	00 01 00 
    753e026034ce:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026034d5:	00 00 00 
    753e026034d8:	c7 80 34 01 00 00 10 	mov    DWORD PTR [rax+0x134],0x10
    753e026034df:	00 00 00 
    753e026034e2:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026034e9:	5c 00 00 
    753e026034ec:	ff d0                	call   rax
    753e026034ee:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026034f5:	00 
    753e026034f6:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026034fd:	75 11                	jne    0x753e02603510
    753e026034ff:	eb 41                	jmp    0x753e02603542
    753e02603501:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    753e02603508:	00 
    753e02603509:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e0260350c:	75 36                	jne    0x753e02603544
    753e0260350e:	eb 79                	jmp    0x753e02603589
    753e02603510:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603517:	00 
    753e02603518:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260351e:	b9 10 00 00 00       	mov    ecx,0x10
    753e02603523:	b8 02 00 00 00       	mov    eax,0x2
    753e02603528:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e0260352f:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603536:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e0260353d:	e9 ca 08 00 00       	jmp    0x753e02603e0c
    753e02603542:	eb bd                	jmp    0x753e02603501
    753e02603544:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e0260354b:	00 
    753e0260354c:	c7 87 bc 00 00 00 6c 	mov    DWORD PTR [rdi+0xbc],0x1006c
    753e02603553:	00 01 00 
    753e02603556:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260355d:	00 00 00 
    753e02603560:	c7 87 34 01 00 00 10 	mov    DWORD PTR [rdi+0x134],0x10
    753e02603567:	00 00 00 
    753e0260356a:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02603571:	5c 00 00 
    753e02603574:	ff d0                	call   rax
    753e02603576:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260357d:	00 
    753e0260357e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603585:	75 04                	jne    0x753e0260358b
    753e02603587:	eb 34                	jmp    0x753e026035bd
    753e02603589:	eb 34                	jmp    0x753e026035bf
    753e0260358b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603592:	00 
    753e02603593:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603599:	b9 10 00 00 00       	mov    ecx,0x10
    753e0260359e:	b8 02 00 00 00       	mov    eax,0x2
    753e026035a3:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e026035aa:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e026035b1:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e026035b8:	e9 4f 08 00 00       	jmp    0x753e02603e0c
    753e026035bd:	eb ca                	jmp    0x753e02603589
    753e026035bf:	eb 00                	jmp    0x753e026035c1
    753e026035c1:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026035c8:	00 
    753e026035c9:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
    753e026035d0:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e026035d6:	83 c9 00             	or     ecx,0x0
    753e026035d9:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    753e026035dd:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e026035e0:	eb 00                	jmp    0x753e026035e2
    753e026035e2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026035e9:	00 
    753e026035ea:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e026035ee:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026035f4:	81 c9 10 f0 00 00    	or     ecx,0xf010
    753e026035fa:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    753e026035fe:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02603601:	eb 00                	jmp    0x753e02603603
    753e02603603:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    753e02603607:	83 e0 03             	and    eax,0x3
    753e0260360a:	83 f8 00             	cmp    eax,0x0
    753e0260360d:	74 7b                	je     0x753e0260368a
    753e0260360f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603616:	00 
    753e02603617:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e0260361b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603622:	00 
    753e02603623:	c7 87 bc 00 00 00 74 	mov    DWORD PTR [rdi+0xbc],0x10074
    753e0260362a:	00 01 00 
    753e0260362d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603634:	00 00 00 
    753e02603637:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    753e0260363e:	00 00 00 
    753e02603641:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603648:	5c 00 00 
    753e0260364b:	ba 74 00 01 00       	mov    edx,0x10074
    753e02603650:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e02603656:	ff d0                	call   rax
    753e02603658:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260365f:	00 
    753e02603660:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603666:	b9 13 00 00 00       	mov    ecx,0x13
    753e0260366b:	b8 02 00 00 00       	mov    eax,0x2
    753e02603670:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603677:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e0260367e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603685:	e9 82 07 00 00       	jmp    0x753e02603e0c
    753e0260368a:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02603691:	00 
    753e02603692:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e02603696:	c1 e9 0c             	shr    ecx,0xc
    753e02603699:	89 c9                	mov    ecx,ecx
    753e0260369b:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260369f:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753e026036a4:	48 83 f8 00          	cmp    rax,0x0
    753e026036a8:	74 1a                	je     0x753e026036c4
    753e026036aa:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e026036af:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e026036b3:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026036b9:	89 c9                	mov    ecx,ecx
    753e026036bb:	c7 04 08 01 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x1
    753e026036c2:	eb 56                	jmp    0x753e0260371a
    753e026036c4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026036cb:	00 
    753e026036cc:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    753e026036d0:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e026036d7:	00 
    753e026036d8:	c7 80 bc 00 00 00 74 	mov    DWORD PTR [rax+0xbc],0x10074
    753e026036df:	00 01 00 
    753e026036e2:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026036e9:	00 00 00 
    753e026036ec:	c7 80 34 01 00 00 13 	mov    DWORD PTR [rax+0x134],0x13
    753e026036f3:	00 00 00 
    753e026036f6:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026036fd:	5c 00 00 
    753e02603700:	ba 01 00 00 00       	mov    edx,0x1
    753e02603705:	ff d0                	call   rax
    753e02603707:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260370e:	00 
    753e0260370f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603716:	75 11                	jne    0x753e02603729
    753e02603718:	eb 41                	jmp    0x753e0260375b
    753e0260371a:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    753e02603721:	00 
    753e02603722:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e02603725:	75 36                	jne    0x753e0260375d
    753e02603727:	eb 79                	jmp    0x753e026037a2
    753e02603729:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603730:	00 
    753e02603731:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603737:	b9 13 00 00 00       	mov    ecx,0x13
    753e0260373c:	b8 02 00 00 00       	mov    eax,0x2
    753e02603741:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603748:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e0260374f:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603756:	e9 b1 06 00 00       	jmp    0x753e02603e0c
    753e0260375b:	eb bd                	jmp    0x753e0260371a
    753e0260375d:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603764:	00 
    753e02603765:	c7 87 bc 00 00 00 76 	mov    DWORD PTR [rdi+0xbc],0x10076
    753e0260376c:	00 01 00 
    753e0260376f:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603776:	00 00 00 
    753e02603779:	c7 87 34 01 00 00 13 	mov    DWORD PTR [rdi+0x134],0x13
    753e02603780:	00 00 00 
    753e02603783:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e0260378a:	5c 00 00 
    753e0260378d:	ff d0                	call   rax
    753e0260378f:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603796:	00 
    753e02603797:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260379e:	75 04                	jne    0x753e026037a4
    753e026037a0:	eb 34                	jmp    0x753e026037d6
    753e026037a2:	eb 34                	jmp    0x753e026037d8
    753e026037a4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026037ab:	00 
    753e026037ac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026037b2:	b9 13 00 00 00       	mov    ecx,0x13
    753e026037b7:	b8 02 00 00 00       	mov    eax,0x2
    753e026037bc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e026037c3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e026037ca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e026037d1:	e9 36 06 00 00       	jmp    0x753e02603e0c
    753e026037d6:	eb ca                	jmp    0x753e026037a2
    753e026037d8:	eb 00                	jmp    0x753e026037da
    753e026037da:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026037e1:	00 
    753e026037e2:	c7 00 00 00 00 00    	mov    DWORD PTR [rax],0x0
    753e026037e8:	eb 00                	jmp    0x753e026037ea
    753e026037ea:	31 c0                	xor    eax,eax
    753e026037ec:	a8 01                	test   al,0x1
    753e026037ee:	75 02                	jne    0x753e026037f2
    753e026037f0:	eb 7c                	jmp    0x753e0260386e
    753e026037f2:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e026037f9:	00 
    753e026037fa:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603801:	00 
    753e02603802:	c7 87 bc 00 00 00 78 	mov    DWORD PTR [rdi+0xbc],0x10078
    753e02603809:	00 01 00 
    753e0260380c:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603813:	00 00 00 
    753e02603816:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    753e0260381d:	00 00 00 
    753e02603820:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603827:	5c 00 00 
    753e0260382a:	ba 78 00 01 00       	mov    edx,0x10078
    753e0260382f:	b9 14 f0 00 00       	mov    ecx,0xf014
    753e02603834:	41 b8 00 00 01 00    	mov    r8d,0x10000
    753e0260383a:	ff d0                	call   rax
    753e0260383c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603843:	00 
    753e02603844:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260384a:	b9 15 00 00 00       	mov    ecx,0x15
    753e0260384f:	b8 02 00 00 00       	mov    eax,0x2
    753e02603854:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e0260385b:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603862:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603869:	e9 9e 05 00 00       	jmp    0x753e02603e0c
    753e0260386e:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02603875:	00 
    753e02603876:	48 8b 40 78          	mov    rax,QWORD PTR [rax+0x78]
    753e0260387a:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    753e0260387f:	48 83 f8 00          	cmp    rax,0x0
    753e02603883:	74 0e                	je     0x753e02603893
    753e02603885:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    753e0260388a:	c7 40 14 00 00 00 00 	mov    DWORD PTR [rax+0x14],0x0
    753e02603891:	eb 56                	jmp    0x753e026038e9
    753e02603893:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260389a:	00 
    753e0260389b:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e026038a2:	00 
    753e026038a3:	c7 80 bc 00 00 00 78 	mov    DWORD PTR [rax+0xbc],0x10078
    753e026038aa:	00 01 00 
    753e026038ad:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e026038b4:	00 00 00 
    753e026038b7:	c7 80 34 01 00 00 15 	mov    DWORD PTR [rax+0x134],0x15
    753e026038be:	00 00 00 
    753e026038c1:	31 c0                	xor    eax,eax
    753e026038c3:	48 b8 20 86 d2 81 8e 	movabs rax,0x5c8e81d28620
    753e026038ca:	5c 00 00 
    753e026038cd:	be 14 f0 00 00       	mov    esi,0xf014
    753e026038d2:	31 d2                	xor    edx,edx
    753e026038d4:	ff d0                	call   rax
    753e026038d6:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026038dd:	00 
    753e026038de:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026038e5:	75 11                	jne    0x753e026038f8
    753e026038e7:	eb 41                	jmp    0x753e0260392a
    753e026038e9:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
    753e026038f0:	00 
    753e026038f1:	80 38 00             	cmp    BYTE PTR [rax],0x0
    753e026038f4:	75 36                	jne    0x753e0260392c
    753e026038f6:	eb 79                	jmp    0x753e02603971
    753e026038f8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026038ff:	00 
    753e02603900:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603906:	b9 15 00 00 00       	mov    ecx,0x15
    753e0260390b:	b8 02 00 00 00       	mov    eax,0x2
    753e02603910:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603917:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e0260391e:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603925:	e9 e2 04 00 00       	jmp    0x753e02603e0c
    753e0260392a:	eb bd                	jmp    0x753e026038e9
    753e0260392c:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603933:	00 
    753e02603934:	c7 87 bc 00 00 00 7a 	mov    DWORD PTR [rdi+0xbc],0x1007a
    753e0260393b:	00 01 00 
    753e0260393e:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603945:	00 00 00 
    753e02603948:	c7 87 34 01 00 00 15 	mov    DWORD PTR [rdi+0x134],0x15
    753e0260394f:	00 00 00 
    753e02603952:	48 b8 00 e6 e3 81 8e 	movabs rax,0x5c8e81e3e600
    753e02603959:	5c 00 00 
    753e0260395c:	ff d0                	call   rax
    753e0260395e:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603965:	00 
    753e02603966:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260396d:	75 04                	jne    0x753e02603973
    753e0260396f:	eb 34                	jmp    0x753e026039a5
    753e02603971:	eb 34                	jmp    0x753e026039a7
    753e02603973:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e0260397a:	00 
    753e0260397b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603981:	b9 15 00 00 00       	mov    ecx,0x15
    753e02603986:	b8 02 00 00 00       	mov    eax,0x2
    753e0260398b:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603992:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603999:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e026039a0:	e9 67 04 00 00       	jmp    0x753e02603e0c
    753e026039a5:	eb ca                	jmp    0x753e02603971
    753e026039a7:	eb 00                	jmp    0x753e026039a9
    753e026039a9:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026039b0:	00 
    753e026039b1:	c7 40 1c 00 00 00 00 	mov    DWORD PTR [rax+0x1c],0x0
    753e026039b8:	eb 00                	jmp    0x753e026039ba
    753e026039ba:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026039c1:	00 
    753e026039c2:	8b 8c 24 84 00 00 00 	mov    ecx,DWORD PTR [rsp+0x84]
    753e026039c9:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e026039cf:	83 c9 00             	or     ecx,0x0
    753e026039d2:	89 48 30             	mov    DWORD PTR [rax+0x30],ecx
    753e026039d5:	eb 00                	jmp    0x753e026039d7
    753e026039d7:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026039de:	00 
    753e026039df:	c7 40 18 00 00 00 00 	mov    DWORD PTR [rax+0x18],0x0
    753e026039e6:	eb 00                	jmp    0x753e026039e8
    753e026039e8:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e026039ef:	00 
    753e026039f0:	c7 40 14 01 00 00 00 	mov    DWORD PTR [rax+0x14],0x1
    753e026039f7:	eb 00                	jmp    0x753e026039f9
    753e026039f9:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    753e02603a00:	83 c0 fc             	add    eax,0xfffffffc
    753e02603a03:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    753e02603a07:	83 e0 03             	and    eax,0x3
    753e02603a0a:	83 f8 00             	cmp    eax,0x0
    753e02603a0d:	74 7a                	je     0x753e02603a89
    753e02603a0f:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603a16:	00 
    753e02603a17:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02603a1b:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603a22:	00 
    753e02603a23:	c7 87 bc 00 00 00 84 	mov    DWORD PTR [rdi+0xbc],0x10084
    753e02603a2a:	00 01 00 
    753e02603a2d:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    753e02603a34:	00 00 00 
    753e02603a37:	c7 87 34 01 00 00 1a 	mov    DWORD PTR [rdi+0x134],0x1a
    753e02603a3e:	00 00 00 
    753e02603a41:	31 c0                	xor    eax,eax
    753e02603a43:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603a4a:	5c 00 00 
    753e02603a4d:	ba 84 00 01 00       	mov    edx,0x10084
    753e02603a52:	45 31 c0             	xor    r8d,r8d
    753e02603a55:	ff d0                	call   rax
    753e02603a57:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603a5e:	00 
    753e02603a5f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603a65:	b9 1a 00 00 00       	mov    ecx,0x1a
    753e02603a6a:	b8 08 00 00 00       	mov    eax,0x8
    753e02603a6f:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603a76:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603a7d:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603a84:	e9 83 03 00 00       	jmp    0x753e02603e0c
    753e02603a89:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02603a90:	00 
    753e02603a91:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02603a95:	c1 e9 0c             	shr    ecx,0xc
    753e02603a98:	89 c9                	mov    ecx,ecx
    753e02603a9a:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02603a9e:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    753e02603aa3:	48 83 f8 00          	cmp    rax,0x0
    753e02603aa7:	74 1a                	je     0x753e02603ac3
    753e02603aa9:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    753e02603aae:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02603ab2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02603ab8:	89 c9                	mov    ecx,ecx
    753e02603aba:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02603abd:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02603ac1:	eb 57                	jmp    0x753e02603b1a
    753e02603ac3:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603aca:	00 
    753e02603acb:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    753e02603acf:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e02603ad6:	00 
    753e02603ad7:	c7 80 bc 00 00 00 84 	mov    DWORD PTR [rax+0xbc],0x10084
    753e02603ade:	00 01 00 
    753e02603ae1:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    753e02603ae8:	00 00 00 
    753e02603aeb:	c7 80 34 01 00 00 1a 	mov    DWORD PTR [rax+0x134],0x1a
    753e02603af2:	00 00 00 
    753e02603af5:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02603afc:	5c 00 00 
    753e02603aff:	ff d0                	call   rax
    753e02603b01:	89 c1                	mov    ecx,eax
    753e02603b03:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603b0a:	00 
    753e02603b0b:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e02603b0f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603b16:	75 1c                	jne    0x753e02603b34
    753e02603b18:	eb 4c                	jmp    0x753e02603b66
    753e02603b1a:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603b21:	00 
    753e02603b22:	8b 94 24 cc 00 00 00 	mov    edx,DWORD PTR [rsp+0xcc]
    753e02603b29:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e02603b2d:	89 10                	mov    DWORD PTR [rax],edx
    753e02603b2f:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e02603b32:	eb 3c                	jmp    0x753e02603b70
    753e02603b34:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603b3b:	00 
    753e02603b3c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603b42:	b9 1a 00 00 00       	mov    ecx,0x1a
    753e02603b47:	b8 08 00 00 00       	mov    eax,0x8
    753e02603b4c:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603b53:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603b5a:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603b61:	e9 a6 02 00 00       	jmp    0x753e02603e0c
    753e02603b66:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e02603b6a:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e02603b6e:	eb aa                	jmp    0x753e02603b1a
    753e02603b70:	eb 00                	jmp    0x753e02603b72
    753e02603b72:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [rsp+0xac]
    753e02603b79:	83 c0 f8             	add    eax,0xfffffff8
    753e02603b7c:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e02603b80:	83 e0 03             	and    eax,0x3
    753e02603b83:	83 f8 00             	cmp    eax,0x0
    753e02603b86:	74 7a                	je     0x753e02603c02
    753e02603b88:	48 8b bc 24 08 01 00 	mov    rdi,QWORD PTR [rsp+0x108]
    753e02603b8f:	00 
    753e02603b90:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02603b94:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
    753e02603b9b:	00 
    753e02603b9c:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    753e02603ba3:	00 01 00 
    753e02603ba6:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02603bad:	00 00 00 
    753e02603bb0:	c7 87 34 01 00 00 1b 	mov    DWORD PTR [rdi+0x134],0x1b
    753e02603bb7:	00 00 00 
    753e02603bba:	31 c0                	xor    eax,eax
    753e02603bbc:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02603bc3:	5c 00 00 
    753e02603bc6:	ba 8c 00 01 00       	mov    edx,0x1008c
    753e02603bcb:	45 31 c0             	xor    r8d,r8d
    753e02603bce:	ff d0                	call   rax
    753e02603bd0:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603bd7:	00 
    753e02603bd8:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603bde:	b9 1b 00 00 00       	mov    ecx,0x1b
    753e02603be3:	b8 02 00 00 00       	mov    eax,0x2
    753e02603be8:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603bef:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603bf6:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603bfd:	e9 0a 02 00 00       	jmp    0x753e02603e0c
    753e02603c02:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
    753e02603c09:	00 
    753e02603c0a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02603c0e:	c1 e9 0c             	shr    ecx,0xc
    753e02603c11:	89 c9                	mov    ecx,ecx
    753e02603c13:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02603c17:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e02603c1c:	48 83 f8 00          	cmp    rax,0x0
    753e02603c20:	74 1a                	je     0x753e02603c3c
    753e02603c22:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e02603c27:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e02603c2b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02603c31:	89 c9                	mov    ecx,ecx
    753e02603c33:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02603c36:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e02603c3a:	eb 57                	jmp    0x753e02603c93
    753e02603c3c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603c43:	00 
    753e02603c44:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e02603c48:	48 8b bc 24 00 01 00 	mov    rdi,QWORD PTR [rsp+0x100]
    753e02603c4f:	00 
    753e02603c50:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    753e02603c57:	00 01 00 
    753e02603c5a:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02603c61:	00 00 00 
    753e02603c64:	c7 80 34 01 00 00 1b 	mov    DWORD PTR [rax+0x134],0x1b
    753e02603c6b:	00 00 00 
    753e02603c6e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02603c75:	5c 00 00 
    753e02603c78:	ff d0                	call   rax
    753e02603c7a:	89 c1                	mov    ecx,eax
    753e02603c7c:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603c83:	00 
    753e02603c84:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    753e02603c88:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02603c8f:	75 13                	jne    0x753e02603ca4
    753e02603c91:	eb 43                	jmp    0x753e02603cd6
    753e02603c93:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603c9a:	00 
    753e02603c9b:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e02603c9f:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    753e02603ca2:	eb 3c                	jmp    0x753e02603ce0
    753e02603ca4:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603cab:	00 
    753e02603cac:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02603cb2:	b9 1b 00 00 00       	mov    ecx,0x1b
    753e02603cb7:	b8 02 00 00 00       	mov    eax,0x2
    753e02603cbc:	89 94 24 e0 00 00 00 	mov    DWORD PTR [rsp+0xe0],edx
    753e02603cc3:	89 8c 24 e4 00 00 00 	mov    DWORD PTR [rsp+0xe4],ecx
    753e02603cca:	89 84 24 e8 00 00 00 	mov    DWORD PTR [rsp+0xe8],eax
    753e02603cd1:	e9 36 01 00 00       	jmp    0x753e02603e0c
    753e02603cd6:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    753e02603cda:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e02603cde:	eb b3                	jmp    0x753e02603c93
    753e02603ce0:	eb 00                	jmp    0x753e02603ce2
    753e02603ce2:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    753e02603ce9:	00 
    753e02603cea:	8b b4 24 f0 00 00 00 	mov    esi,DWORD PTR [rsp+0xf0]
    753e02603cf1:	8b 84 24 ec 00 00 00 	mov    eax,DWORD PTR [rsp+0xec]
    753e02603cf8:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    753e02603cfe:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    753e02603d04:	83 ff 01             	cmp    edi,0x1
    753e02603d07:	0f 97 c3             	seta   bl
    753e02603d0a:	3d 8e 00 01 00       	cmp    eax,0x1008e
    753e02603d0f:	0f 94 c0             	sete   al
    753e02603d12:	20 c3                	and    bl,al
    753e02603d14:	b8 92 00 01 00       	mov    eax,0x10092
    753e02603d19:	f6 c3 01             	test   bl,0x1
    753e02603d1c:	0f 45 c2             	cmovne eax,edx
    753e02603d1f:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    753e02603d25:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    753e02603d2b:	83 ff 01             	cmp    edi,0x1
    753e02603d2e:	0f 97 c3             	seta   bl
    753e02603d31:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    753e02603d37:	40 0f 94 c6          	sete   sil
    753e02603d3b:	40 20 f3             	and    bl,sil
    753e02603d3e:	f6 c3 01             	test   bl,0x1
    753e02603d41:	0f 45 c2             	cmovne eax,edx
    753e02603d44:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    753e02603d4a:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    753e02603d51:	03 01 00 
    753e02603d54:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02603d5a:	83 c0 1c             	add    eax,0x1c
    753e02603d5d:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e02603d61:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02603d67:	72 16                	jb     0x753e02603d7f
    753e02603d69:	eb 37                	jmp    0x753e02603da2
    753e02603d6b:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603d72:	00 
    753e02603d73:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e02603d7a:	e9 4a 01 00 00       	jmp    0x753e02603ec9
    753e02603d7f:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    753e02603d86:	00 
    753e02603d87:	48 89 c1             	mov    rcx,rax
    753e02603d8a:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    753e02603d91:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    753e02603d96:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    753e02603d9d:	03 01 00 
    753e02603da0:	74 32                	je     0x753e02603dd4
    753e02603da2:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603da9:	00 
    753e02603daa:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    753e02603db1:	03 01 00 
    753e02603db4:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02603dbb:	00 00 00 
    753e02603dbe:	c7 80 34 01 00 00 1c 	mov    DWORD PTR [rax+0x134],0x1c
    753e02603dc5:	00 00 00 
    753e02603dc8:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e02603dcf:	e9 f5 00 00 00       	jmp    0x753e02603ec9
    753e02603dd4:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    753e02603ddb:	00 
    753e02603ddc:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    753e02603de3:	00 
    753e02603de4:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753e02603de9:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e02603ded:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753e02603df4:	28 03 01 00 
    753e02603df8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02603dff:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02603e03:	48 81 c4 28 01 00 00 	add    rsp,0x128
    753e02603e0a:	ff e0                	jmp    rax
    753e02603e0c:	48 8b 8c 24 08 01 00 	mov    rcx,QWORD PTR [rsp+0x108]
    753e02603e13:	00 
    753e02603e14:	8b 94 24 e0 00 00 00 	mov    edx,DWORD PTR [rsp+0xe0]
    753e02603e1b:	8b 84 24 e4 00 00 00 	mov    eax,DWORD PTR [rsp+0xe4]
    753e02603e22:	8b b4 24 e8 00 00 00 	mov    esi,DWORD PTR [rsp+0xe8]
    753e02603e29:	89 c7                	mov    edi,eax
    753e02603e2b:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e02603e2f:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e02603e33:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e02603e37:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02603e3d:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e02603e41:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02603e47:	73 2d                	jae    0x753e02603e76
    753e02603e49:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
    753e02603e50:	00 
    753e02603e51:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e02603e55:	89 d1                	mov    ecx,edx
    753e02603e57:	c1 e9 01             	shr    ecx,0x1
    753e02603e5a:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02603e60:	89 c9                	mov    ecx,ecx
    753e02603e62:	48 c1 e1 04          	shl    rcx,0x4
    753e02603e66:	48 89 c6             	mov    rsi,rax
    753e02603e69:	48 01 ce             	add    rsi,rcx
    753e02603e6c:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e02603e71:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e02603e74:	74 1e                	je     0x753e02603e94
    753e02603e76:	48 8b 84 24 08 01 00 	mov    rax,QWORD PTR [rsp+0x108]
    753e02603e7d:	00 
    753e02603e7e:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    753e02603e82:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e02603e86:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    753e02603e8c:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    753e02603e92:	eb 35                	jmp    0x753e02603ec9
    753e02603e94:	4c 8b b4 24 00 01 00 	mov    r14,QWORD PTR [rsp+0x100]
    753e02603e9b:	00 
    753e02603e9c:	4c 8b ac 24 08 01 00 	mov    r13,QWORD PTR [rsp+0x108]
    753e02603ea3:	00 
    753e02603ea4:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e02603ea9:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e02603ead:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02603eb4:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e02603ebb:	00 
    753e02603ebc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02603ec0:	48 81 c4 28 01 00 00 	add    rsp,0x128
    753e02603ec7:	ff e0                	jmp    rax
    753e02603ec9:	48 81 c4 28 01 00 00 	add    rsp,0x128
    753e02603ed0:	c2 08 00             	ret    0x8
