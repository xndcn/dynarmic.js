; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100ec(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %1, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %2 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %2, align 4
  %3 = icmp eq i32 %guard_lb, 0
  %4 = sub i32 %guard_lb, 65772
  %5 = icmp ugt i32 %4, 32
  %6 = or i1 %3, %5
  %7 = and i1 true, %6
  %8 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb68 = load i32, ptr %8, align 4
  %9 = icmp eq i32 %guard_lb68, 0
  %10 = sub i32 %guard_lb68, 65772
  %11 = icmp ugt i32 %10, 32
  %12 = or i1 %9, %11
  %13 = and i1 %7, %12
  br i1 %13, label %insn_0x000100ec_entry, label %lb_guard_miss, !prof !0

insn_0x000100ec_entry:                            ; preds = %chain_self, %chain_go, %lb_guard
  %14 = getelementptr i8, ptr %cpu, i64 336
  %chain_table86 = load ptr, ptr %14, align 8
  %tier_table = getelementptr i8, ptr %chain_table86, i64 1048576
  %15 = getelementptr i8, ptr %tier_table, i64 36
  %16 = load i32, ptr %15, align 4
  %tier_count = add i32 %16, 1
  store i32 %tier_count, ptr %15, align 4
  %17 = icmp eq i32 %tier_count, 30000
  br i1 %17, label %18, label %28, !prof !1

18:                                               ; preds = %insn_0x000100ec_entry
  %19 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %19, align 4
  %20 = add i32 %tier_requests, 1
  store i32 %20, ptr %19, align 4
  %21 = icmp ult i32 %tier_requests, 256
  br i1 %21, label %22, label %27

22:                                               ; preds = %18
  %23 = zext i32 %tier_requests to i64
  %24 = mul i64 %23, 4
  %25 = add i64 262148, %24
  %26 = getelementptr i8, ptr %tier_table, i64 %25
  store i32 9, ptr %26, align 4
  br label %27

27:                                               ; preds = %18, %22
  br label %28

28:                                               ; preds = %insn_0x000100ec_entry, %27
  br label %insn_0x000100ec

insn_0x000100ec:                                  ; preds = %28
  %29 = getelementptr i8, ptr %cpu, i32 4
  %a = load i32, ptr %29, align 4
  %30 = getelementptr i8, ptr %cpu, i32 24
  %b = load i32, ptr %30, align 4
  %mul = mul i32 %a, %b
  %31 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mul, ptr %31, align 4
  %32 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %32, align 4
  %33 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %33, align 4
  br label %insn_0x000100ee_entry

insn_0x000100ee_entry:                            ; preds = %insn_0x000100ec
  br label %insn_0x000100ee

insn_0x000100ee:                                  ; preds = %insn_0x000100ee_entry
  %34 = getelementptr i8, ptr %cpu, i32 28
  %rt = load i32, ptr %34, align 4
  %add32 = add i32 %mul, %rt
  %35 = getelementptr i8, ptr %cpu, i32 4
  store i32 %add32, ptr %35, align 4
  %flgs = lshr i32 %mul, 31
  %flgo = lshr i32 %rt, 31
  %flgn = lshr i32 %add32, 31
  %36 = xor i32 %flgo, %flgn
  %37 = xor i32 %flgs, %flgn
  %38 = and i32 %37, %36
  %39 = xor i32 %mul, -1
  %40 = icmp ult i32 %39, %rt
  %ac0 = zext i1 %40 to i32
  %41 = icmp eq i32 %add32, 0
  %az = zext i1 %41 to i32
  %an = lshr i32 %add32, 31
  %42 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %42, align 4
  %43 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %43, align 4
  %44 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %44, align 4
  %45 = or i32 %vs_cur, %38
  %46 = getelementptr i8, ptr %cpu, i32 248
  store i32 %38, ptr %46, align 4
  %47 = getelementptr i8, ptr %cpu, i32 252
  store i32 %38, ptr %47, align 4
  %48 = getelementptr i8, ptr %cpu, i32 256
  store i32 %45, ptr %48, align 4
  %49 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %49, align 4
  %50 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %50, align 4
  br label %insn_0x000100f0_entry

insn_0x000100f0_entry:                            ; preds = %insn_0x000100ee
  br label %insn_0x000100f0

insn_0x000100f0:                                  ; preds = %insn_0x000100f0_entry
  %lsr32 = lshr i32 %add32, 13
  %51 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsr32, ptr %51, align 4
  %52 = icmp eq i32 %lsr32, 0
  %az1 = zext i1 %52 to i32
  %an2 = lshr i32 %lsr32, 31
  %53 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az1, ptr %53, align 4
  %54 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an2, ptr %54, align 4
  %55 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %56, align 4
  br label %insn_0x000100f4_entry

insn_0x000100f4_entry:                            ; preds = %insn_0x000100f0
  br label %insn_0x000100f4

insn_0x000100f4:                                  ; preds = %insn_0x000100f4_entry
  %xor32 = xor i32 %add32, %lsr32
  %57 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %57, align 4
  %58 = icmp eq i32 %xor32, 0
  %az3 = zext i1 %58 to i32
  %an4 = lshr i32 %xor32, 31
  %59 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az3, ptr %59, align 4
  %60 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an4, ptr %60, align 4
  %61 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %61, align 4
  %62 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %62, align 4
  %63 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %63, align 4
  %64 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %64, align 4
  br label %insn_0x000100f6_entry

insn_0x000100f6_entry:                            ; preds = %insn_0x000100f4
  br label %insn_0x000100f6

insn_0x000100f6:                                  ; preds = %insn_0x000100f6_entry
  %lsl32 = shl i32 %xor32, 7
  %65 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsl32, ptr %65, align 4
  %66 = icmp eq i32 %lsl32, 0
  %az5 = zext i1 %66 to i32
  %an6 = lshr i32 %lsl32, 31
  %67 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az5, ptr %67, align 4
  %68 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an6, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %70, align 4
  br label %insn_0x000100fa_entry

insn_0x000100fa_entry:                            ; preds = %insn_0x000100f6
  br label %insn_0x000100fa

insn_0x000100fa:                                  ; preds = %insn_0x000100fa_entry
  %lsr = lshr i32 %xor32, 25
  %71 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr, ptr %71, align 4
  %72 = icmp eq i32 %lsr, 0
  %az7 = zext i1 %72 to i32
  %an8 = lshr i32 %lsr, 31
  %73 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az7, ptr %73, align 4
  %74 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an8, ptr %74, align 4
  %75 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %75, align 4
  %76 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %76, align 4
  br label %insn_0x000100fc_entry

insn_0x000100fc_entry:                            ; preds = %insn_0x000100fa
  br label %insn_0x000100fc

insn_0x000100fc:                                  ; preds = %insn_0x000100fc_entry
  %77 = getelementptr i8, ptr %cpu, i32 8
  %rd = load i32, ptr %77, align 4
  %rd_add = add i32 %rd, 1
  %78 = getelementptr i8, ptr %cpu, i32 8
  store i32 %rd_add, ptr %78, align 4
  %flgs9 = lshr i32 %rd, 31
  %flgn10 = lshr i32 %rd_add, 31
  %79 = xor i32 0, %flgn10
  %80 = xor i32 %flgs9, %flgn10
  %overflow = and i32 %80, %79
  %81 = xor i32 %rd, -1
  %82 = icmp ult i32 %81, 1
  %ac011 = zext i1 %82 to i32
  %83 = icmp eq i32 %rd_add, 0
  %az12 = zext i1 %83 to i32
  %an13 = lshr i32 %rd_add, 31
  %84 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az12, ptr %84, align 4
  %85 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an13, ptr %85, align 4
  %86 = or i32 %45, %overflow
  %87 = getelementptr i8, ptr %cpu, i32 248
  store i32 %overflow, ptr %87, align 4
  %88 = getelementptr i8, ptr %cpu, i32 252
  store i32 %overflow, ptr %88, align 4
  %89 = getelementptr i8, ptr %cpu, i32 256
  store i32 %86, ptr %89, align 4
  %90 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac011, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac011, ptr %91, align 4
  br label %insn_0x000100fe_entry

insn_0x000100fe_entry:                            ; preds = %insn_0x000100fc
  br label %insn_0x000100fe

insn_0x000100fe:                                  ; preds = %insn_0x000100fe_entry
  %or32 = or i32 %lsl32, %lsr
  %92 = getelementptr i8, ptr %cpu, i32 4
  store i32 %or32, ptr %92, align 4
  %93 = icmp eq i32 %or32, 0
  %az14 = zext i1 %93 to i32
  %an15 = lshr i32 %or32, 31
  %94 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az14, ptr %94, align 4
  %95 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an15, ptr %95, align 4
  %96 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %96, align 4
  %97 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %97, align 4
  %98 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %98, align 4
  %99 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %99, align 4
  br label %insn_0x00010100_entry

insn_0x00010100_entry:                            ; preds = %insn_0x000100fe
  br label %insn_0x00010100

insn_0x00010100:                                  ; preds = %insn_0x00010100_entry
  %100 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %100, align 4
  %101 = icmp ule i32 %rx, %rd_add
  %cc = zext i1 %101 to i32
  %102 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %102, align 4
  %103 = icmp eq i32 %rx, %rd_add
  %az16 = zext i1 %103 to i32
  %104 = icmp ugt i32 %rd_add, %rx
  %an17 = zext i1 %104 to i32
  %105 = icmp ule i32 %rd_add, %rx
  %ac018 = zext i1 %105 to i32
  %106 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az16, ptr %106, align 4
  %107 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an17, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac018, ptr %108, align 4
  %109 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac018, ptr %109, align 4
  br label %insn_0x00010102_entry

insn_0x00010102_entry:                            ; preds = %insn_0x00010100
  br label %insn_0x00010102

insn_0x00010102:                                  ; preds = %insn_0x00010102_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010102
  %110 = getelementptr i8, ptr %cpu, i32 188
  store i32 65772, ptr %110, align 4
  %111 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %111, align 4
  %chain_total = add nuw i32 %chain_packets, 10
  %112 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %112 monotonic, align 4, !range !2
  %113 = icmp ult i32 %chain_total, %chain_budget
  br i1 %113, label %chain_go, label %chain_leave69, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010102
  br label %insn_0x00010104_entry

insn_0x00010104_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010104

insn_0x00010104:                                  ; preds = %insn_0x00010104_entry
  %114 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %114, align 4
  %115 = and i32 %fp, 3
  %116 = icmp ne i32 %115, 0
  br i1 %116, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x00010104
  %117 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %117, align 4
  %118 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %118, align 4
  %119 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %119, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %fp, i32 0)
  %120 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %120, align 4
  %121 = getelementptr i8, ptr %cpu, i64 188
  %122 = load i32, ptr %121, align 4
  %123 = getelementptr i8, ptr %cpu, i64 296
  %124 = load i8, ptr %123, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x00010104
  %125 = lshr i32 %fp, 12
  %page_index = zext i32 %125 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned
  %126 = and i32 %fp, 4095
  %page_offset = zext i32 %126 to i64
  %127 = getelementptr i8, ptr %page, i64 %page_offset
  %page_val = load i32, ptr %127, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned
  %128 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %128, align 4
  %129 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %129, align 4
  %130 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %130, align 4
  %131 = call i32 @mem_read32(ptr %mem, i32 %fp)
  %132 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %132, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_done:                                        ; preds = %did_jump_cont, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %131, %did_jump_cont ]
  %sp1 = add i32 %fp, 4
  %133 = and i32 %sp1, 3
  %134 = icmp ne i32 %133, 0
  br i1 %134, label %data_misaligned19, label %data_aligned20, !prof !1

did_jump_exit:                                    ; preds = %page_slow
  %135 = getelementptr i8, ptr %cpu, i64 188
  %next_pc70 = load i32, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i64 188
  %137 = load i32, ptr %136, align 4
  %138 = getelementptr i8, ptr %cpu, i64 296
  %139 = load i8, ptr %138, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_slow
  br label %page_done

data_misaligned19:                                ; preds = %page_done
  %140 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %140, align 4
  %141 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %141, align 4
  %142 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %142, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp1, i32 0)
  %143 = getelementptr i8, ptr %cpu, i64 188
  %next_pc71 = load i32, ptr %143, align 4
  %144 = getelementptr i8, ptr %cpu, i64 188
  %145 = load i32, ptr %144, align 4
  %146 = getelementptr i8, ptr %cpu, i64 296
  %147 = load i8, ptr %146, align 1
  br label %chain_exit

data_aligned20:                                   ; preds = %page_done
  %148 = lshr i32 %sp1, 12
  %page_index24 = zext i32 %148 to i64
  %page_slot25 = getelementptr ptr, ptr %page_table, i64 %page_index24
  %page26 = load ptr, ptr %page_slot25, align 8
  %page_mapped27 = icmp ne ptr %page26, null
  br i1 %page_mapped27, label %page_fast21, label %page_slow22, !prof !0

page_fast21:                                      ; preds = %data_aligned20
  %149 = and i32 %sp1, 4095
  %page_offset28 = zext i32 %149 to i64
  %150 = getelementptr i8, ptr %page26, i64 %page_offset28
  %page_val29 = load i32, ptr %150, align 4
  br label %page_done23

page_slow22:                                      ; preds = %data_aligned20
  %151 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 308
  store i32 11, ptr %153, align 4
  %154 = call i32 @mem_read32(ptr %mem, i32 %sp1)
  %155 = getelementptr i8, ptr %cpu, i32 296
  %dj32 = load i8, ptr %155, align 1
  %dj_set33 = icmp ne i8 %dj32, 0
  br i1 %dj_set33, label %did_jump_exit30, label %did_jump_cont31, !prof !1

page_done23:                                      ; preds = %did_jump_cont31, %page_fast21
  %mem_val34 = phi i32 [ %page_val29, %page_fast21 ], [ %154, %did_jump_cont31 ]
  %sp2 = add i32 %sp1, 4
  %156 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %156, align 4
  %157 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val34, ptr %157, align 4
  %158 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2, ptr %158, align 4
  br label %insn_0x00010108_entry

did_jump_exit30:                                  ; preds = %page_slow22
  %159 = getelementptr i8, ptr %cpu, i64 188
  %next_pc72 = load i32, ptr %159, align 4
  %160 = getelementptr i8, ptr %cpu, i64 188
  %161 = load i32, ptr %160, align 4
  %162 = getelementptr i8, ptr %cpu, i64 296
  %163 = load i8, ptr %162, align 1
  br label %chain_exit

did_jump_cont31:                                  ; preds = %page_slow22
  br label %page_done23

insn_0x00010108_entry:                            ; preds = %page_done23
  br label %insn_0x00010108

insn_0x00010108:                                  ; preds = %insn_0x00010108_entry
  %164 = getelementptr i8, ptr %cpu, i32 0
  store i32 %or32, ptr %164, align 4
  br label %insn_0x0001010a_entry

insn_0x0001010a_entry:                            ; preds = %insn_0x00010108
  br label %insn_0x0001010a

insn_0x0001010a:                                  ; preds = %insn_0x0001010a_entry
  %165 = and i32 %sp2, 3
  %166 = icmp ne i32 %165, 0
  br i1 %166, label %data_misaligned35, label %data_aligned36, !prof !1

data_misaligned35:                                ; preds = %insn_0x0001010a
  %167 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %167, align 4
  %168 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %168, align 4
  %169 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %169, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp2, i32 0)
  %170 = getelementptr i8, ptr %cpu, i64 188
  %next_pc73 = load i32, ptr %170, align 4
  %171 = getelementptr i8, ptr %cpu, i64 188
  %172 = load i32, ptr %171, align 4
  %173 = getelementptr i8, ptr %cpu, i64 296
  %174 = load i8, ptr %173, align 1
  br label %chain_exit

data_aligned36:                                   ; preds = %insn_0x0001010a
  %175 = lshr i32 %sp2, 12
  %page_index40 = zext i32 %175 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_fast37, label %page_slow38, !prof !0

page_fast37:                                      ; preds = %data_aligned36
  %176 = and i32 %sp2, 4095
  %page_offset44 = zext i32 %176 to i64
  %177 = getelementptr i8, ptr %page42, i64 %page_offset44
  %page_val45 = load i32, ptr %177, align 4
  br label %page_done39

page_slow38:                                      ; preds = %data_aligned36
  %178 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %179, align 4
  %180 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %180, align 4
  %181 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %182 = getelementptr i8, ptr %cpu, i32 296
  %dj48 = load i8, ptr %182, align 1
  %dj_set49 = icmp ne i8 %dj48, 0
  br i1 %dj_set49, label %did_jump_exit46, label %did_jump_cont47, !prof !1

page_done39:                                      ; preds = %did_jump_cont47, %page_fast37
  %mem_val50 = phi i32 [ %page_val45, %page_fast37 ], [ %181, %did_jump_cont47 ]
  %183 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val50, ptr %183, align 4
  %sp_inc = add i32 %sp2, 4
  %184 = and i32 %sp_inc, 3
  %185 = icmp ne i32 %184, 0
  br i1 %185, label %data_misaligned51, label %data_aligned52, !prof !1

did_jump_exit46:                                  ; preds = %page_slow38
  %186 = getelementptr i8, ptr %cpu, i64 188
  %next_pc74 = load i32, ptr %186, align 4
  %187 = getelementptr i8, ptr %cpu, i64 188
  %188 = load i32, ptr %187, align 4
  %189 = getelementptr i8, ptr %cpu, i64 296
  %190 = load i8, ptr %189, align 1
  br label %chain_exit

did_jump_cont47:                                  ; preds = %page_slow38
  br label %page_done39

data_misaligned51:                                ; preds = %page_done39
  %191 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %191, align 4
  %192 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %193, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp_inc, i32 0)
  %194 = getelementptr i8, ptr %cpu, i64 188
  %next_pc75 = load i32, ptr %194, align 4
  %195 = getelementptr i8, ptr %cpu, i64 188
  %196 = load i32, ptr %195, align 4
  %197 = getelementptr i8, ptr %cpu, i64 296
  %198 = load i8, ptr %197, align 1
  br label %chain_exit

data_aligned52:                                   ; preds = %page_done39
  %199 = lshr i32 %sp_inc, 12
  %page_index56 = zext i32 %199 to i64
  %page_slot57 = getelementptr ptr, ptr %page_table, i64 %page_index56
  %page58 = load ptr, ptr %page_slot57, align 8
  %page_mapped59 = icmp ne ptr %page58, null
  br i1 %page_mapped59, label %page_fast53, label %page_slow54, !prof !0

page_fast53:                                      ; preds = %data_aligned52
  %200 = and i32 %sp_inc, 4095
  %page_offset60 = zext i32 %200 to i64
  %201 = getelementptr i8, ptr %page58, i64 %page_offset60
  %page_val61 = load i32, ptr %201, align 4
  br label %page_done55

page_slow54:                                      ; preds = %data_aligned52
  %202 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %202, align 4
  %203 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 308
  store i32 13, ptr %204, align 4
  %205 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %206 = getelementptr i8, ptr %cpu, i32 296
  %dj64 = load i8, ptr %206, align 1
  %dj_set65 = icmp ne i8 %dj64, 0
  br i1 %dj_set65, label %did_jump_exit62, label %did_jump_cont63, !prof !1

page_done55:                                      ; preds = %did_jump_cont63, %page_fast53
  %mem_val66 = phi i32 [ %page_val61, %page_fast53 ], [ %205, %did_jump_cont63 ]
  %207 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val66, ptr %207, align 4
  %sp_inc67 = add i32 %sp_inc, 4
  %208 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc67, ptr %208, align 4
  br label %insn_0x0001010c_entry

did_jump_exit62:                                  ; preds = %page_slow54
  %209 = getelementptr i8, ptr %cpu, i64 188
  %next_pc76 = load i32, ptr %209, align 4
  %210 = getelementptr i8, ptr %cpu, i64 188
  %211 = load i32, ptr %210, align 4
  %212 = getelementptr i8, ptr %cpu, i64 296
  %213 = load i8, ptr %212, align 1
  br label %chain_exit

did_jump_cont63:                                  ; preds = %page_slow54
  br label %page_done55

insn_0x0001010c_entry:                            ; preds = %page_done55
  br label %insn_0x0001010c

insn_0x0001010c:                                  ; preds = %insn_0x0001010c_entry
  %lsb = and i32 %mem_val34, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001010c
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001010c
  %214 = getelementptr i8, ptr %cpu, i32 188
  store i32 65804, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %215, align 4
  %216 = getelementptr i8, ptr %cpu, i32 308
  store i32 14, ptr %216, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %217 = getelementptr i8, ptr %cpu, i64 188
  %next_pc77 = load i32, ptr %217, align 4
  %218 = getelementptr i8, ptr %cpu, i64 188
  %219 = load i32, ptr %218, align 4
  %220 = getelementptr i8, ptr %cpu, i64 296
  %221 = load i8, ptr %220, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %222 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %222, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brcc_taken
  %223 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %223, align 4
  %224 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %224, align 4
  br label %insn_0x000100ec_entry

chain_leave69:                                    ; preds = %brcc_taken
  %225 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %225, align 4
  %226 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %226, align 4
  %227 = getelementptr i8, ptr %cpu, i64 308
  store i32 10, ptr %227, align 4
  %228 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %228, align 1
  br label %return

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit62, %data_misaligned51, %did_jump_exit46, %data_misaligned35, %did_jump_exit30, %data_misaligned19, %did_jump_exit, %data_misaligned
  %next_pc78 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc70, %did_jump_exit ], [ %next_pc71, %data_misaligned19 ], [ %next_pc72, %did_jump_exit30 ], [ %next_pc73, %data_misaligned35 ], [ %next_pc74, %did_jump_exit46 ], [ %next_pc75, %data_misaligned51 ], [ %next_pc76, %did_jump_exit62 ], [ %mem_val34, %jump_aligned ], [ %next_pc77, %jump_misalign ]
  %packets = phi i32 [ 11, %data_misaligned ], [ 11, %did_jump_exit ], [ 11, %data_misaligned19 ], [ 11, %did_jump_exit30 ], [ 13, %data_misaligned35 ], [ 13, %did_jump_exit46 ], [ 13, %data_misaligned51 ], [ 13, %did_jump_exit62 ], [ 14, %jump_aligned ], [ 14, %jump_misalign ]
  %tail = phi i32 [ %122, %data_misaligned ], [ %137, %did_jump_exit ], [ %145, %data_misaligned19 ], [ %161, %did_jump_exit30 ], [ %172, %data_misaligned35 ], [ %188, %did_jump_exit46 ], [ %196, %data_misaligned51 ], [ %211, %did_jump_exit62 ], [ %mem_val34, %jump_aligned ], [ %219, %jump_misalign ]
  %tail79 = phi i32 [ 4, %data_misaligned ], [ 4, %did_jump_exit ], [ 4, %data_misaligned19 ], [ 4, %did_jump_exit30 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit46 ], [ 2, %data_misaligned51 ], [ 2, %did_jump_exit62 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail80 = phi i32 [ 11, %data_misaligned ], [ 11, %did_jump_exit ], [ 11, %data_misaligned19 ], [ 11, %did_jump_exit30 ], [ 13, %data_misaligned35 ], [ 13, %did_jump_exit46 ], [ 13, %data_misaligned51 ], [ 13, %did_jump_exit62 ], [ 14, %jump_aligned ], [ 14, %jump_misalign ]
  %tail81 = phi i8 [ %124, %data_misaligned ], [ %139, %did_jump_exit ], [ %147, %data_misaligned19 ], [ %163, %did_jump_exit30 ], [ %174, %data_misaligned35 ], [ %190, %did_jump_exit46 ], [ %198, %data_misaligned51 ], [ %213, %did_jump_exit62 ], [ 1, %jump_aligned ], [ %221, %jump_misalign ]
  %229 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets83 = load i32, ptr %229, align 4
  %chain_total84 = add nuw i32 %chain_packets83, %packets
  %230 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget85 = load atomic i32, ptr %230 monotonic, align 4, !range !2
  %231 = icmp ult i32 %chain_total84, %chain_budget85
  br i1 %231, label %chain_lookup, label %chain_leave82, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %232 = icmp eq i32 %next_pc78, 65772
  br i1 %232, label %chain_self, label %chain_other, !prof !3

chain_leave82:                                    ; preds = %chain_other, %chain_exit
  %233 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %233, align 4
  %234 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail79, ptr %234, align 4
  %235 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail80, ptr %235, align 4
  %236 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail81, ptr %236, align 1
  br label %return

chain_self:                                       ; preds = %chain_lookup
  %237 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc78, ptr %237, align 4
  %238 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total84, ptr %238, align 4
  %239 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %239, align 1
  br label %insn_0x000100ec_entry

chain_other:                                      ; preds = %chain_lookup
  %240 = lshr i32 %next_pc78, 1
  %241 = and i32 %240, 65535
  %242 = zext i32 %241 to i64
  %243 = mul i64 %242, 16
  %chain_slot = getelementptr i8, ptr %chain_table, i64 %243
  %244 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %244, align 4
  %245 = icmp eq i32 %slot_pc, %next_pc78
  br i1 %245, label %chain_hit, label %chain_leave82, !prof !0

chain_hit:                                        ; preds = %chain_other
  %246 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc78, ptr %246, align 4
  %247 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total84, ptr %247, align 4
  %248 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %248, align 1
  %249 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %249, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave82, %chain_leave69, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
!3 = !{!"branch_weights", i32 63, i32 1}
