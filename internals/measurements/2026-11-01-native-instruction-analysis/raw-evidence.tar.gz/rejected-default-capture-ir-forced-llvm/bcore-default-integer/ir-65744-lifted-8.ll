; ModuleID = 'bb_module'
source_filename = "bb_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

define swifttailcc void @bb_0x000100d0(ptr swiftself %cpu, ptr swiftasync %mem) #0 {
entry:
  %0 = getelementptr i8, ptr %cpu, i64 336
  %chain_table = load ptr, ptr %0, align 8
  %1 = getelementptr i8, ptr %cpu, i32 320
  %cec_pending_flag = load ptr, ptr %1, align 8
  %2 = getelementptr i8, ptr %cpu, i32 312
  %page_table = load ptr, ptr %2, align 8
  br label %lb_guard

lb_guard:                                         ; preds = %entry
  %3 = getelementptr i8, ptr %cpu, i64 160
  %guard_lb = load i32, ptr %3, align 4
  %4 = icmp eq i32 %guard_lb, 0
  %5 = sub i32 %guard_lb, 65744
  %6 = icmp ugt i32 %5, 60
  %7 = or i1 %4, %6
  %8 = and i1 true, %7
  %9 = getelementptr i8, ptr %cpu, i64 164
  %guard_lb140 = load i32, ptr %9, align 4
  %10 = icmp eq i32 %guard_lb140, 0
  %11 = sub i32 %guard_lb140, 65744
  %12 = icmp ugt i32 %11, 60
  %13 = or i1 %10, %12
  %14 = and i1 %8, %13
  br i1 %14, label %insn_0x000100d0_entry, label %lb_guard_miss, !prof !0

insn_0x000100d0_entry:                            ; preds = %lb_guard
  %15 = getelementptr i8, ptr %cpu, i64 336
  %chain_table181 = load ptr, ptr %15, align 8
  %tier_table = getelementptr i8, ptr %chain_table181, i64 1048576
  %16 = getelementptr i8, ptr %tier_table, i64 32
  %17 = load i32, ptr %16, align 4
  %tier_count = add i32 %17, 1
  store i32 %tier_count, ptr %16, align 4
  %18 = icmp eq i32 %tier_count, 43125
  br i1 %18, label %19, label %29, !prof !1

19:                                               ; preds = %insn_0x000100d0_entry
  %20 = getelementptr i8, ptr %tier_table, i64 262144
  %tier_requests = load i32, ptr %20, align 4
  %21 = add i32 %tier_requests, 1
  store i32 %21, ptr %20, align 4
  %22 = icmp ult i32 %tier_requests, 256
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = zext i32 %tier_requests to i64
  %25 = mul i64 %24, 4
  %26 = add i64 262148, %25
  %27 = getelementptr i8, ptr %tier_table, i64 %26
  store i32 8, ptr %27, align 4
  br label %28

28:                                               ; preds = %19, %23
  br label %29

29:                                               ; preds = %insn_0x000100d0_entry, %28
  br label %insn_0x000100d0

insn_0x000100d0:                                  ; preds = %29
  %30 = getelementptr i8, ptr %cpu, i32 56
  %sp = load i32, ptr %30, align 4
  %sp_dec = sub i32 %sp, 4
  %31 = getelementptr i8, ptr %cpu, i32 24
  %r = load i32, ptr %31, align 4
  %32 = and i32 %sp_dec, 3
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %data_misaligned, label %data_aligned, !prof !1

data_misaligned:                                  ; preds = %insn_0x000100d0
  %34 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %34, align 4
  %35 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %35, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65744, i32 %sp_dec, i32 65536)
  %36 = getelementptr i8, ptr %cpu, i64 188
  %next_pc = load i32, ptr %36, align 4
  %37 = getelementptr i8, ptr %cpu, i64 188
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %cpu, i64 296
  %40 = load i8, ptr %39, align 1
  br label %chain_exit

data_aligned:                                     ; preds = %insn_0x000100d0
  %41 = lshr i32 %sp_dec, 12
  %page_index = zext i32 %41 to i64
  %page_slot = getelementptr ptr, ptr %page_table, i64 %page_index
  %page = load ptr, ptr %page_slot, align 8
  %page_mapped = icmp ne ptr %page, null
  br i1 %page_mapped, label %page_wr_fast, label %page_wr_slow, !prof !0

page_wr_fast:                                     ; preds = %data_aligned
  %42 = and i32 %sp_dec, 4095
  %page_offset = zext i32 %42 to i64
  %43 = getelementptr i8, ptr %page, i64 %page_offset
  store i32 %r, ptr %43, align 4
  br label %page_wr_done

page_wr_slow:                                     ; preds = %data_aligned
  %44 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %44, align 4
  %45 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %45, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec, i32 %r)
  %46 = getelementptr i8, ptr %cpu, i32 296
  %dj = load i8, ptr %46, align 1
  %dj_set = icmp ne i8 %dj, 0
  br i1 %dj_set, label %did_jump_exit, label %did_jump_cont, !prof !1

page_wr_done:                                     ; preds = %did_jump_cont, %page_wr_fast
  %sp_dec1 = sub i32 %sp_dec, 4
  %47 = getelementptr i8, ptr %cpu, i32 28
  %r2 = load i32, ptr %47, align 4
  %48 = and i32 %sp_dec1, 3
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %data_misaligned3, label %data_aligned4, !prof !1

did_jump_exit:                                    ; preds = %page_wr_slow
  %50 = getelementptr i8, ptr %cpu, i64 188
  %next_pc141 = load i32, ptr %50, align 4
  %51 = getelementptr i8, ptr %cpu, i64 188
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %cpu, i64 296
  %54 = load i8, ptr %53, align 1
  br label %chain_exit

did_jump_cont:                                    ; preds = %page_wr_slow
  br label %page_wr_done

data_misaligned3:                                 ; preds = %page_wr_done
  %55 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %55, align 4
  %56 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %56, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65744, i32 %sp_dec1, i32 65536)
  %57 = getelementptr i8, ptr %cpu, i64 188
  %next_pc142 = load i32, ptr %57, align 4
  %58 = getelementptr i8, ptr %cpu, i64 188
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %cpu, i64 296
  %61 = load i8, ptr %60, align 1
  br label %chain_exit

data_aligned4:                                    ; preds = %page_wr_done
  %62 = lshr i32 %sp_dec1, 12
  %page_index8 = zext i32 %62 to i64
  %page_slot9 = getelementptr ptr, ptr %page_table, i64 %page_index8
  %page10 = load ptr, ptr %page_slot9, align 8
  %page_mapped11 = icmp ne ptr %page10, null
  br i1 %page_mapped11, label %page_wr_fast5, label %page_wr_slow6, !prof !0

page_wr_fast5:                                    ; preds = %data_aligned4
  %63 = and i32 %sp_dec1, 4095
  %page_offset12 = zext i32 %63 to i64
  %64 = getelementptr i8, ptr %page10, i64 %page_offset12
  store i32 %r2, ptr %64, align 4
  br label %page_wr_done7

page_wr_slow6:                                    ; preds = %data_aligned4
  %65 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %65, align 4
  %66 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %66, align 4
  call void @mem_write32(ptr %mem, i32 %sp_dec1, i32 %r2)
  %67 = getelementptr i8, ptr %cpu, i32 296
  %dj15 = load i8, ptr %67, align 1
  %dj_set16 = icmp ne i8 %dj15, 0
  br i1 %dj_set16, label %did_jump_exit13, label %did_jump_cont14, !prof !1

page_wr_done7:                                    ; preds = %did_jump_cont14, %page_wr_fast5
  %68 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_dec1, ptr %68, align 4
  %69 = getelementptr i8, ptr %cpu, i32 160
  %lb0 = load i32, ptr %69, align 4
  %70 = getelementptr i8, ptr %cpu, i32 164
  %lb1 = load i32, ptr %70, align 4
  %cec_pending = load i8, ptr %cec_pending_flag, align 1
  %71 = icmp ne i8 %cec_pending, 0
  br i1 %71, label %cec_check, label %cec_checked, !prof !1

did_jump_exit13:                                  ; preds = %page_wr_slow6
  %72 = getelementptr i8, ptr %cpu, i64 188
  %next_pc143 = load i32, ptr %72, align 4
  %73 = getelementptr i8, ptr %cpu, i64 188
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %cpu, i64 296
  %76 = load i8, ptr %75, align 1
  br label %chain_exit

did_jump_cont14:                                  ; preds = %page_wr_slow6
  br label %page_wr_done7

cec_check:                                        ; preds = %page_wr_done7
  %77 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %77, align 4
  %78 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %78, align 4
  %79 = getelementptr i8, ptr %cpu, i32 308
  store i32 1, ptr %79, align 4
  call void @cec_check_pending(ptr %cpu)
  %80 = getelementptr i8, ptr %cpu, i32 296
  %dj19 = load i8, ptr %80, align 1
  %dj_set20 = icmp ne i8 %dj19, 0
  br i1 %dj_set20, label %did_jump_exit17, label %did_jump_cont18, !prof !1

cec_checked:                                      ; preds = %did_jump_cont18, %page_wr_done7
  br label %insn_0x000100d2_entry

did_jump_exit17:                                  ; preds = %cec_check
  %81 = getelementptr i8, ptr %cpu, i64 188
  %next_pc144 = load i32, ptr %81, align 4
  %82 = getelementptr i8, ptr %cpu, i64 188
  %83 = load i32, ptr %82, align 4
  %84 = getelementptr i8, ptr %cpu, i64 296
  %85 = load i8, ptr %84, align 1
  br label %chain_exit

did_jump_cont18:                                  ; preds = %cec_check
  br label %cec_checked

insn_0x000100d2_entry:                            ; preds = %cec_checked
  br label %insn_0x000100d2

insn_0x000100d2:                                  ; preds = %insn_0x000100d2_entry
  %86 = getelementptr i8, ptr %cpu, i32 168
  %rets = load i32, ptr %86, align 4
  %87 = getelementptr i8, ptr %cpu, i32 60
  %fp = load i32, ptr %87, align 4
  %sp1 = sub i32 %sp_dec1, 4
  %88 = and i32 %sp1, 3
  %89 = icmp ne i32 %88, 0
  br i1 %89, label %data_misaligned21, label %data_aligned22, !prof !1

data_misaligned21:                                ; preds = %insn_0x000100d2
  %90 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %90, align 4
  %91 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %91, align 4
  %92 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %92, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65746, i32 %sp1, i32 65536)
  %93 = getelementptr i8, ptr %cpu, i64 188
  %next_pc145 = load i32, ptr %93, align 4
  %94 = getelementptr i8, ptr %cpu, i64 188
  %95 = load i32, ptr %94, align 4
  %96 = getelementptr i8, ptr %cpu, i64 296
  %97 = load i8, ptr %96, align 1
  br label %chain_exit

data_aligned22:                                   ; preds = %insn_0x000100d2
  %98 = lshr i32 %sp1, 12
  %page_index26 = zext i32 %98 to i64
  %page_slot27 = getelementptr ptr, ptr %page_table, i64 %page_index26
  %page28 = load ptr, ptr %page_slot27, align 8
  %page_mapped29 = icmp ne ptr %page28, null
  br i1 %page_mapped29, label %page_wr_fast23, label %page_wr_slow24, !prof !0

page_wr_fast23:                                   ; preds = %data_aligned22
  %99 = and i32 %sp1, 4095
  %page_offset30 = zext i32 %99 to i64
  %100 = getelementptr i8, ptr %page28, i64 %page_offset30
  store i32 %rets, ptr %100, align 4
  br label %page_wr_done25

page_wr_slow24:                                   ; preds = %data_aligned22
  %101 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %101, align 4
  %102 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %102, align 4
  %103 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %103, align 4
  call void @mem_write32(ptr %mem, i32 %sp1, i32 %rets)
  %104 = getelementptr i8, ptr %cpu, i32 296
  %dj33 = load i8, ptr %104, align 1
  %dj_set34 = icmp ne i8 %dj33, 0
  br i1 %dj_set34, label %did_jump_exit31, label %did_jump_cont32, !prof !1

page_wr_done25:                                   ; preds = %did_jump_cont32, %page_wr_fast23
  %sp2 = sub i32 %sp1, 4
  %105 = and i32 %sp2, 3
  %106 = icmp ne i32 %105, 0
  br i1 %106, label %data_misaligned35, label %data_aligned36, !prof !1

did_jump_exit31:                                  ; preds = %page_wr_slow24
  %107 = getelementptr i8, ptr %cpu, i64 188
  %next_pc146 = load i32, ptr %107, align 4
  %108 = getelementptr i8, ptr %cpu, i64 188
  %109 = load i32, ptr %108, align 4
  %110 = getelementptr i8, ptr %cpu, i64 296
  %111 = load i8, ptr %110, align 1
  br label %chain_exit

did_jump_cont32:                                  ; preds = %page_wr_slow24
  br label %page_wr_done25

data_misaligned35:                                ; preds = %page_wr_done25
  %112 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %112, align 4
  %113 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %113, align 4
  %114 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %114, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65746, i32 %sp2, i32 65536)
  %115 = getelementptr i8, ptr %cpu, i64 188
  %next_pc147 = load i32, ptr %115, align 4
  %116 = getelementptr i8, ptr %cpu, i64 188
  %117 = load i32, ptr %116, align 4
  %118 = getelementptr i8, ptr %cpu, i64 296
  %119 = load i8, ptr %118, align 1
  br label %chain_exit

data_aligned36:                                   ; preds = %page_wr_done25
  %120 = lshr i32 %sp2, 12
  %page_index40 = zext i32 %120 to i64
  %page_slot41 = getelementptr ptr, ptr %page_table, i64 %page_index40
  %page42 = load ptr, ptr %page_slot41, align 8
  %page_mapped43 = icmp ne ptr %page42, null
  br i1 %page_mapped43, label %page_wr_fast37, label %page_wr_slow38, !prof !0

page_wr_fast37:                                   ; preds = %data_aligned36
  %121 = and i32 %sp2, 4095
  %page_offset44 = zext i32 %121 to i64
  %122 = getelementptr i8, ptr %page42, i64 %page_offset44
  store i32 %fp, ptr %122, align 4
  br label %page_wr_done39

page_wr_slow38:                                   ; preds = %data_aligned36
  %123 = getelementptr i8, ptr %cpu, i32 188
  store i32 65746, ptr %123, align 4
  %124 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %124, align 4
  %125 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %125, align 4
  call void @mem_write32(ptr %mem, i32 %sp2, i32 %fp)
  %126 = getelementptr i8, ptr %cpu, i32 296
  %dj47 = load i8, ptr %126, align 1
  %dj_set48 = icmp ne i8 %dj47, 0
  br i1 %dj_set48, label %did_jump_exit45, label %did_jump_cont46, !prof !1

page_wr_done39:                                   ; preds = %did_jump_cont46, %page_wr_fast37
  %127 = getelementptr i8, ptr %cpu, i32 60
  store i32 %sp2, ptr %127, align 4
  %sp3 = sub i32 %sp2, 0
  %128 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp3, ptr %128, align 4
  %cec_pending49 = load i8, ptr %cec_pending_flag, align 1
  %129 = icmp ne i8 %cec_pending49, 0
  br i1 %129, label %cec_check50, label %cec_checked51, !prof !1

did_jump_exit45:                                  ; preds = %page_wr_slow38
  %130 = getelementptr i8, ptr %cpu, i64 188
  %next_pc148 = load i32, ptr %130, align 4
  %131 = getelementptr i8, ptr %cpu, i64 188
  %132 = load i32, ptr %131, align 4
  %133 = getelementptr i8, ptr %cpu, i64 296
  %134 = load i8, ptr %133, align 1
  br label %chain_exit

did_jump_cont46:                                  ; preds = %page_wr_slow38
  br label %page_wr_done39

cec_check50:                                      ; preds = %page_wr_done39
  %135 = getelementptr i8, ptr %cpu, i32 188
  store i32 65750, ptr %135, align 4
  %136 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %136, align 4
  %137 = getelementptr i8, ptr %cpu, i32 308
  store i32 2, ptr %137, align 4
  call void @cec_check_pending(ptr %cpu)
  %138 = getelementptr i8, ptr %cpu, i32 296
  %dj54 = load i8, ptr %138, align 1
  %dj_set55 = icmp ne i8 %dj54, 0
  br i1 %dj_set55, label %did_jump_exit52, label %did_jump_cont53, !prof !1

cec_checked51:                                    ; preds = %did_jump_cont53, %page_wr_done39
  br label %insn_0x000100d6_entry

did_jump_exit52:                                  ; preds = %cec_check50
  %139 = getelementptr i8, ptr %cpu, i64 188
  %next_pc149 = load i32, ptr %139, align 4
  %140 = getelementptr i8, ptr %cpu, i64 188
  %141 = load i32, ptr %140, align 4
  %142 = getelementptr i8, ptr %cpu, i64 296
  %143 = load i8, ptr %142, align 1
  br label %chain_exit

did_jump_cont53:                                  ; preds = %cec_check50
  br label %cec_checked51

insn_0x000100d6_entry:                            ; preds = %cec_checked51
  br label %insn_0x000100d6

insn_0x000100d6:                                  ; preds = %insn_0x000100d6_entry
  %144 = getelementptr i8, ptr %cpu, i32 0
  %rx = load i32, ptr %144, align 4
  %diff = sub i32 %rx, 0
  %145 = icmp eq i32 %diff, 0
  %az = zext i1 %145 to i32
  %flgn = lshr i32 %diff, 31
  %flgs = lshr i32 %rx, 31
  %146 = xor i32 %flgn, %flgs
  %147 = xor i32 %flgs, 0
  %overflow = and i32 %147, %146
  %an = xor i32 %flgn, %overflow
  %148 = icmp ule i32 0, %rx
  %ac0 = zext i1 %148 to i32
  %149 = getelementptr i8, ptr %cpu, i32 276
  store i32 %az, ptr %149, align 4
  %150 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az, ptr %150, align 4
  %151 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an, ptr %151, align 4
  %152 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac0, ptr %152, align 4
  %153 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac0, ptr %153, align 4
  br label %insn_0x000100d8_entry

insn_0x000100d8_entry:                            ; preds = %insn_0x000100d6
  br label %insn_0x000100d8

insn_0x000100d8:                                  ; preds = %insn_0x000100d8_entry
  %cc_true = icmp ne i32 %az, 0
  br i1 %cc_true, label %brt_taken, label %brt_fallthru

brt_taken:                                        ; preds = %insn_0x000100d8
  %154 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %154, align 4
  %155 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets = load i32, ptr %155, align 4
  %chain_total = add nuw i32 %chain_packets, 4
  %156 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget = load atomic i32, ptr %156 monotonic, align 4, !range !2
  %157 = icmp ult i32 %chain_total, %chain_budget
  br i1 %157, label %chain_go, label %chain_leave150, !prof !0

brt_fallthru:                                     ; preds = %insn_0x000100d8
  br label %insn_0x000100da_entry

insn_0x000100da_entry:                            ; preds = %brt_fallthru
  br label %insn_0x000100da

insn_0x000100da:                                  ; preds = %insn_0x000100da_entry
  %lo_kept = and i32 %r, 65535
  %with_hi = or i32 %lo_kept, 1638400
  %158 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_hi, ptr %158, align 4
  br label %insn_0x000100de_entry

insn_0x000100de_entry:                            ; preds = %insn_0x000100da
  br label %insn_0x000100de

insn_0x000100de:                                  ; preds = %insn_0x000100de_entry
  %lo_kept56 = and i32 %r2, 65535
  %with_hi57 = or i32 %lo_kept56, 1013841920
  %159 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_hi57, ptr %159, align 4
  br label %insn_0x000100e2_entry

insn_0x000100e2_entry:                            ; preds = %insn_0x000100de
  br label %insn_0x000100e2

insn_0x000100e2:                                  ; preds = %insn_0x000100e2_entry
  %160 = getelementptr i8, ptr %cpu, i32 8
  store i32 0, ptr %160, align 4
  br label %insn_0x000100e4_entry

insn_0x000100e4_entry:                            ; preds = %insn_0x000100e2
  br label %insn_0x000100e4

insn_0x000100e4:                                  ; preds = %insn_0x000100e4_entry
  %hi_kept = and i32 %with_hi, -65536
  %with_lo = or i32 %hi_kept, 26125
  %161 = getelementptr i8, ptr %cpu, i32 24
  store i32 %with_lo, ptr %161, align 4
  br label %insn_0x000100e8_entry

insn_0x000100e8_entry:                            ; preds = %insn_0x000100e4
  br label %insn_0x000100e8

insn_0x000100e8:                                  ; preds = %insn_0x000100e8_entry
  %hi_kept58 = and i32 %with_hi57, -65536
  %with_lo59 = or i32 %hi_kept58, 62303
  %162 = getelementptr i8, ptr %cpu, i32 28
  store i32 %with_lo59, ptr %162, align 4
  br label %insn_0x000100ec_entry

insn_0x000100ec_entry:                            ; preds = %insn_0x000100e8
  br label %insn_0x000100ec

insn_0x000100ec:                                  ; preds = %insn_0x000100ec_entry
  %163 = getelementptr i8, ptr %cpu, i32 4
  %a = load i32, ptr %163, align 4
  %mul = mul i32 %a, %with_lo
  %164 = getelementptr i8, ptr %cpu, i32 4
  store i32 %mul, ptr %164, align 4
  br label %insn_0x000100ee_entry

insn_0x000100ee_entry:                            ; preds = %insn_0x000100ec
  br label %insn_0x000100ee

insn_0x000100ee:                                  ; preds = %insn_0x000100ee_entry
  %add32 = add i32 %mul, %with_lo59
  %165 = getelementptr i8, ptr %cpu, i32 4
  store i32 %add32, ptr %165, align 4
  %flgs60 = lshr i32 %mul, 31
  %flgo = lshr i32 %with_lo59, 31
  %flgn61 = lshr i32 %add32, 31
  %166 = xor i32 %flgo, %flgn61
  %167 = xor i32 %flgs60, %flgn61
  %168 = and i32 %167, %166
  %169 = xor i32 %mul, -1
  %170 = icmp ult i32 %169, %with_lo59
  %ac062 = zext i1 %170 to i32
  %171 = icmp eq i32 %add32, 0
  %az63 = zext i1 %171 to i32
  %an64 = lshr i32 %add32, 31
  %172 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az63, ptr %172, align 4
  %173 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an64, ptr %173, align 4
  %174 = getelementptr i8, ptr %cpu, i32 256
  %vs_cur = load i32, ptr %174, align 4
  %175 = or i32 %vs_cur, %168
  %176 = getelementptr i8, ptr %cpu, i32 248
  store i32 %168, ptr %176, align 4
  %177 = getelementptr i8, ptr %cpu, i32 252
  store i32 %168, ptr %177, align 4
  %178 = getelementptr i8, ptr %cpu, i32 256
  store i32 %175, ptr %178, align 4
  %179 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac062, ptr %179, align 4
  %180 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac062, ptr %180, align 4
  br label %insn_0x000100f0_entry

insn_0x000100f0_entry:                            ; preds = %insn_0x000100ee
  br label %insn_0x000100f0

insn_0x000100f0:                                  ; preds = %insn_0x000100f0_entry
  %lsr32 = lshr i32 %add32, 13
  %181 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsr32, ptr %181, align 4
  %182 = icmp eq i32 %lsr32, 0
  %az65 = zext i1 %182 to i32
  %an66 = lshr i32 %lsr32, 31
  %183 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az65, ptr %183, align 4
  %184 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an66, ptr %184, align 4
  %185 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %185, align 4
  %186 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %186, align 4
  br label %insn_0x000100f4_entry

insn_0x000100f4_entry:                            ; preds = %insn_0x000100f0
  br label %insn_0x000100f4

insn_0x000100f4:                                  ; preds = %insn_0x000100f4_entry
  %xor32 = xor i32 %add32, %lsr32
  %187 = getelementptr i8, ptr %cpu, i32 4
  store i32 %xor32, ptr %187, align 4
  %188 = icmp eq i32 %xor32, 0
  %az67 = zext i1 %188 to i32
  %an68 = lshr i32 %xor32, 31
  %189 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az67, ptr %189, align 4
  %190 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an68, ptr %190, align 4
  %191 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %191, align 4
  %192 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %192, align 4
  %193 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %193, align 4
  %194 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %194, align 4
  br label %insn_0x000100f6_entry

insn_0x000100f6_entry:                            ; preds = %insn_0x000100f4
  br label %insn_0x000100f6

insn_0x000100f6:                                  ; preds = %insn_0x000100f6_entry
  %lsl32 = shl i32 %xor32, 7
  %195 = getelementptr i8, ptr %cpu, i32 12
  store i32 %lsl32, ptr %195, align 4
  %196 = icmp eq i32 %lsl32, 0
  %az69 = zext i1 %196 to i32
  %an70 = lshr i32 %lsl32, 31
  %197 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az69, ptr %197, align 4
  %198 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an70, ptr %198, align 4
  %199 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %199, align 4
  %200 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %200, align 4
  br label %insn_0x000100fa_entry

insn_0x000100fa_entry:                            ; preds = %insn_0x000100f6
  br label %insn_0x000100fa

insn_0x000100fa:                                  ; preds = %insn_0x000100fa_entry
  %lsr = lshr i32 %xor32, 25
  %201 = getelementptr i8, ptr %cpu, i32 4
  store i32 %lsr, ptr %201, align 4
  %202 = icmp eq i32 %lsr, 0
  %az71 = zext i1 %202 to i32
  %an72 = lshr i32 %lsr, 31
  %203 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az71, ptr %203, align 4
  %204 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an72, ptr %204, align 4
  %205 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %205, align 4
  %206 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %206, align 4
  br label %insn_0x000100fc_entry

insn_0x000100fc_entry:                            ; preds = %insn_0x000100fa
  br label %insn_0x000100fc

insn_0x000100fc:                                  ; preds = %insn_0x000100fc_entry
  %207 = getelementptr i8, ptr %cpu, i32 8
  store i32 1, ptr %207, align 4
  %208 = getelementptr i8, ptr %cpu, i32 228
  store i32 0, ptr %208, align 4
  %209 = getelementptr i8, ptr %cpu, i32 232
  store i32 0, ptr %209, align 4
  %210 = or i32 %175, 0
  %211 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %211, align 4
  %212 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %212, align 4
  %213 = getelementptr i8, ptr %cpu, i32 256
  store i32 %210, ptr %213, align 4
  %214 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %214, align 4
  %215 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %215, align 4
  br label %insn_0x000100fe_entry

insn_0x000100fe_entry:                            ; preds = %insn_0x000100fc
  br label %insn_0x000100fe

insn_0x000100fe:                                  ; preds = %insn_0x000100fe_entry
  %or32 = or i32 %lsl32, %lsr
  %216 = getelementptr i8, ptr %cpu, i32 4
  store i32 %or32, ptr %216, align 4
  %217 = icmp eq i32 %or32, 0
  %az73 = zext i1 %217 to i32
  %an74 = lshr i32 %or32, 31
  %218 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az73, ptr %218, align 4
  %219 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an74, ptr %219, align 4
  %220 = getelementptr i8, ptr %cpu, i32 236
  store i32 0, ptr %220, align 4
  %221 = getelementptr i8, ptr %cpu, i32 240
  store i32 0, ptr %221, align 4
  %222 = getelementptr i8, ptr %cpu, i32 248
  store i32 0, ptr %222, align 4
  %223 = getelementptr i8, ptr %cpu, i32 252
  store i32 0, ptr %223, align 4
  br label %insn_0x00010100_entry

insn_0x00010100_entry:                            ; preds = %insn_0x000100fe
  br label %insn_0x00010100

insn_0x00010100:                                  ; preds = %insn_0x00010100_entry
  %224 = icmp ule i32 %rx, 1
  %cc = zext i1 %224 to i32
  %225 = getelementptr i8, ptr %cpu, i32 276
  store i32 %cc, ptr %225, align 4
  %226 = icmp eq i32 %rx, 1
  %az75 = zext i1 %226 to i32
  %227 = icmp ugt i32 1, %rx
  %an76 = zext i1 %227 to i32
  %228 = icmp ule i32 1, %rx
  %ac077 = zext i1 %228 to i32
  %229 = getelementptr i8, ptr %cpu, i32 228
  store i32 %az75, ptr %229, align 4
  %230 = getelementptr i8, ptr %cpu, i32 232
  store i32 %an76, ptr %230, align 4
  %231 = getelementptr i8, ptr %cpu, i32 236
  store i32 %ac077, ptr %231, align 4
  %232 = getelementptr i8, ptr %cpu, i32 240
  store i32 %ac077, ptr %232, align 4
  br label %insn_0x00010102_entry

insn_0x00010102_entry:                            ; preds = %insn_0x00010100
  br label %insn_0x00010102

insn_0x00010102:                                  ; preds = %insn_0x00010102_entry
  %cc_false = icmp eq i32 %cc, 0
  br i1 %cc_false, label %brcc_taken, label %brcc_fallthru

brcc_taken:                                       ; preds = %insn_0x00010102
  %233 = getelementptr i8, ptr %cpu, i32 188
  store i32 65772, ptr %233, align 4
  %234 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets153 = load i32, ptr %234, align 4
  %chain_total154 = add nuw i32 %chain_packets153, 19
  %235 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget155 = load atomic i32, ptr %235 monotonic, align 4, !range !2
  %236 = icmp ult i32 %chain_total154, %chain_budget155
  br i1 %236, label %chain_go151, label %chain_leave152, !prof !0

brcc_fallthru:                                    ; preds = %insn_0x00010102
  br label %insn_0x00010104_entry

insn_0x00010104_entry:                            ; preds = %brcc_fallthru
  br label %insn_0x00010104

insn_0x00010104:                                  ; preds = %insn_0x00010104_entry
  %237 = and i32 %sp2, 3
  %238 = icmp ne i32 %237, 0
  br i1 %238, label %data_misaligned78, label %data_aligned79, !prof !1

data_misaligned78:                                ; preds = %insn_0x00010104
  %239 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %239, align 4
  %240 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %240, align 4
  %241 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %241, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp2, i32 0)
  %242 = getelementptr i8, ptr %cpu, i64 188
  %next_pc160 = load i32, ptr %242, align 4
  %243 = getelementptr i8, ptr %cpu, i64 188
  %244 = load i32, ptr %243, align 4
  %245 = getelementptr i8, ptr %cpu, i64 296
  %246 = load i8, ptr %245, align 1
  br label %chain_exit

data_aligned79:                                   ; preds = %insn_0x00010104
  %247 = lshr i32 %sp2, 12
  %page_index80 = zext i32 %247 to i64
  %page_slot81 = getelementptr ptr, ptr %page_table, i64 %page_index80
  %page82 = load ptr, ptr %page_slot81, align 8
  %page_mapped83 = icmp ne ptr %page82, null
  br i1 %page_mapped83, label %page_fast, label %page_slow, !prof !0

page_fast:                                        ; preds = %data_aligned79
  %248 = and i32 %sp2, 4095
  %page_offset84 = zext i32 %248 to i64
  %249 = getelementptr i8, ptr %page82, i64 %page_offset84
  %page_val = load i32, ptr %249, align 4
  br label %page_done

page_slow:                                        ; preds = %data_aligned79
  %250 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %250, align 4
  %251 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %251, align 4
  %252 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %252, align 4
  %253 = call i32 @mem_read32(ptr %mem, i32 %sp2)
  %254 = getelementptr i8, ptr %cpu, i32 296
  %dj87 = load i8, ptr %254, align 1
  %dj_set88 = icmp ne i8 %dj87, 0
  br i1 %dj_set88, label %did_jump_exit85, label %did_jump_cont86, !prof !1

page_done:                                        ; preds = %did_jump_cont86, %page_fast
  %mem_val = phi i32 [ %page_val, %page_fast ], [ %253, %did_jump_cont86 ]
  %sp189 = add i32 %sp2, 4
  %255 = and i32 %sp189, 3
  %256 = icmp ne i32 %255, 0
  br i1 %256, label %data_misaligned90, label %data_aligned91, !prof !1

did_jump_exit85:                                  ; preds = %page_slow
  %257 = getelementptr i8, ptr %cpu, i64 188
  %next_pc161 = load i32, ptr %257, align 4
  %258 = getelementptr i8, ptr %cpu, i64 188
  %259 = load i32, ptr %258, align 4
  %260 = getelementptr i8, ptr %cpu, i64 296
  %261 = load i8, ptr %260, align 1
  br label %chain_exit

did_jump_cont86:                                  ; preds = %page_slow
  br label %page_done

data_misaligned90:                                ; preds = %page_done
  %262 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %262, align 4
  %263 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %263, align 4
  %264 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %264, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65796, i32 %sp189, i32 0)
  %265 = getelementptr i8, ptr %cpu, i64 188
  %next_pc162 = load i32, ptr %265, align 4
  %266 = getelementptr i8, ptr %cpu, i64 188
  %267 = load i32, ptr %266, align 4
  %268 = getelementptr i8, ptr %cpu, i64 296
  %269 = load i8, ptr %268, align 1
  br label %chain_exit

data_aligned91:                                   ; preds = %page_done
  %270 = lshr i32 %sp189, 12
  %page_index95 = zext i32 %270 to i64
  %page_slot96 = getelementptr ptr, ptr %page_table, i64 %page_index95
  %page97 = load ptr, ptr %page_slot96, align 8
  %page_mapped98 = icmp ne ptr %page97, null
  br i1 %page_mapped98, label %page_fast92, label %page_slow93, !prof !0

page_fast92:                                      ; preds = %data_aligned91
  %271 = and i32 %sp189, 4095
  %page_offset99 = zext i32 %271 to i64
  %272 = getelementptr i8, ptr %page97, i64 %page_offset99
  %page_val100 = load i32, ptr %272, align 4
  br label %page_done94

page_slow93:                                      ; preds = %data_aligned91
  %273 = getelementptr i8, ptr %cpu, i32 188
  store i32 65796, ptr %273, align 4
  %274 = getelementptr i8, ptr %cpu, i32 292
  store i32 4, ptr %274, align 4
  %275 = getelementptr i8, ptr %cpu, i32 308
  store i32 20, ptr %275, align 4
  %276 = call i32 @mem_read32(ptr %mem, i32 %sp189)
  %277 = getelementptr i8, ptr %cpu, i32 296
  %dj103 = load i8, ptr %277, align 1
  %dj_set104 = icmp ne i8 %dj103, 0
  br i1 %dj_set104, label %did_jump_exit101, label %did_jump_cont102, !prof !1

page_done94:                                      ; preds = %did_jump_cont102, %page_fast92
  %mem_val105 = phi i32 [ %page_val100, %page_fast92 ], [ %276, %did_jump_cont102 ]
  %sp2106 = add i32 %sp189, 4
  %278 = getelementptr i8, ptr %cpu, i32 60
  store i32 %mem_val, ptr %278, align 4
  %279 = getelementptr i8, ptr %cpu, i32 168
  store i32 %mem_val105, ptr %279, align 4
  %280 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp2106, ptr %280, align 4
  br label %insn_0x00010108_entry

did_jump_exit101:                                 ; preds = %page_slow93
  %281 = getelementptr i8, ptr %cpu, i64 188
  %next_pc163 = load i32, ptr %281, align 4
  %282 = getelementptr i8, ptr %cpu, i64 188
  %283 = load i32, ptr %282, align 4
  %284 = getelementptr i8, ptr %cpu, i64 296
  %285 = load i8, ptr %284, align 1
  br label %chain_exit

did_jump_cont102:                                 ; preds = %page_slow93
  br label %page_done94

insn_0x00010108_entry:                            ; preds = %page_done94
  br label %insn_0x00010108

insn_0x00010108:                                  ; preds = %insn_0x00010108_entry
  %286 = getelementptr i8, ptr %cpu, i32 0
  store i32 %or32, ptr %286, align 4
  br label %insn_0x0001010a_entry

insn_0x0001010a_entry:                            ; preds = %insn_0x00010108
  br label %insn_0x0001010a

insn_0x0001010a:                                  ; preds = %insn_0x0001010a_entry
  %287 = and i32 %sp2106, 3
  %288 = icmp ne i32 %287, 0
  br i1 %288, label %data_misaligned107, label %data_aligned108, !prof !1

data_misaligned107:                               ; preds = %insn_0x0001010a
  %289 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %289, align 4
  %290 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %290, align 4
  %291 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %291, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp2106, i32 0)
  %292 = getelementptr i8, ptr %cpu, i64 188
  %next_pc164 = load i32, ptr %292, align 4
  %293 = getelementptr i8, ptr %cpu, i64 188
  %294 = load i32, ptr %293, align 4
  %295 = getelementptr i8, ptr %cpu, i64 296
  %296 = load i8, ptr %295, align 1
  br label %chain_exit

data_aligned108:                                  ; preds = %insn_0x0001010a
  %297 = lshr i32 %sp2106, 12
  %page_index112 = zext i32 %297 to i64
  %page_slot113 = getelementptr ptr, ptr %page_table, i64 %page_index112
  %page114 = load ptr, ptr %page_slot113, align 8
  %page_mapped115 = icmp ne ptr %page114, null
  br i1 %page_mapped115, label %page_fast109, label %page_slow110, !prof !0

page_fast109:                                     ; preds = %data_aligned108
  %298 = and i32 %sp2106, 4095
  %page_offset116 = zext i32 %298 to i64
  %299 = getelementptr i8, ptr %page114, i64 %page_offset116
  %page_val117 = load i32, ptr %299, align 4
  br label %page_done111

page_slow110:                                     ; preds = %data_aligned108
  %300 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %300, align 4
  %301 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %301, align 4
  %302 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %302, align 4
  %303 = call i32 @mem_read32(ptr %mem, i32 %sp2106)
  %304 = getelementptr i8, ptr %cpu, i32 296
  %dj120 = load i8, ptr %304, align 1
  %dj_set121 = icmp ne i8 %dj120, 0
  br i1 %dj_set121, label %did_jump_exit118, label %did_jump_cont119, !prof !1

page_done111:                                     ; preds = %did_jump_cont119, %page_fast109
  %mem_val122 = phi i32 [ %page_val117, %page_fast109 ], [ %303, %did_jump_cont119 ]
  %305 = getelementptr i8, ptr %cpu, i32 28
  store i32 %mem_val122, ptr %305, align 4
  %sp_inc = add i32 %sp2106, 4
  %306 = and i32 %sp_inc, 3
  %307 = icmp ne i32 %306, 0
  br i1 %307, label %data_misaligned123, label %data_aligned124, !prof !1

did_jump_exit118:                                 ; preds = %page_slow110
  %308 = getelementptr i8, ptr %cpu, i64 188
  %next_pc165 = load i32, ptr %308, align 4
  %309 = getelementptr i8, ptr %cpu, i64 188
  %310 = load i32, ptr %309, align 4
  %311 = getelementptr i8, ptr %cpu, i64 296
  %312 = load i8, ptr %311, align 1
  br label %chain_exit

did_jump_cont119:                                 ; preds = %page_slow110
  br label %page_done111

data_misaligned123:                               ; preds = %page_done111
  %313 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %313, align 4
  %314 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %314, align 4
  %315 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %315, align 4
  call void @cec_data_alignment(ptr %cpu, ptr %mem, i32 65802, i32 %sp_inc, i32 0)
  %316 = getelementptr i8, ptr %cpu, i64 188
  %next_pc166 = load i32, ptr %316, align 4
  %317 = getelementptr i8, ptr %cpu, i64 188
  %318 = load i32, ptr %317, align 4
  %319 = getelementptr i8, ptr %cpu, i64 296
  %320 = load i8, ptr %319, align 1
  br label %chain_exit

data_aligned124:                                  ; preds = %page_done111
  %321 = lshr i32 %sp_inc, 12
  %page_index128 = zext i32 %321 to i64
  %page_slot129 = getelementptr ptr, ptr %page_table, i64 %page_index128
  %page130 = load ptr, ptr %page_slot129, align 8
  %page_mapped131 = icmp ne ptr %page130, null
  br i1 %page_mapped131, label %page_fast125, label %page_slow126, !prof !0

page_fast125:                                     ; preds = %data_aligned124
  %322 = and i32 %sp_inc, 4095
  %page_offset132 = zext i32 %322 to i64
  %323 = getelementptr i8, ptr %page130, i64 %page_offset132
  %page_val133 = load i32, ptr %323, align 4
  br label %page_done127

page_slow126:                                     ; preds = %data_aligned124
  %324 = getelementptr i8, ptr %cpu, i32 188
  store i32 65802, ptr %324, align 4
  %325 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %325, align 4
  %326 = getelementptr i8, ptr %cpu, i32 308
  store i32 22, ptr %326, align 4
  %327 = call i32 @mem_read32(ptr %mem, i32 %sp_inc)
  %328 = getelementptr i8, ptr %cpu, i32 296
  %dj136 = load i8, ptr %328, align 1
  %dj_set137 = icmp ne i8 %dj136, 0
  br i1 %dj_set137, label %did_jump_exit134, label %did_jump_cont135, !prof !1

page_done127:                                     ; preds = %did_jump_cont135, %page_fast125
  %mem_val138 = phi i32 [ %page_val133, %page_fast125 ], [ %327, %did_jump_cont135 ]
  %329 = getelementptr i8, ptr %cpu, i32 24
  store i32 %mem_val138, ptr %329, align 4
  %sp_inc139 = add i32 %sp_inc, 4
  %330 = getelementptr i8, ptr %cpu, i32 56
  store i32 %sp_inc139, ptr %330, align 4
  br label %insn_0x0001010c_entry

did_jump_exit134:                                 ; preds = %page_slow126
  %331 = getelementptr i8, ptr %cpu, i64 188
  %next_pc167 = load i32, ptr %331, align 4
  %332 = getelementptr i8, ptr %cpu, i64 188
  %333 = load i32, ptr %332, align 4
  %334 = getelementptr i8, ptr %cpu, i64 296
  %335 = load i8, ptr %334, align 1
  br label %chain_exit

did_jump_cont135:                                 ; preds = %page_slow126
  br label %page_done127

insn_0x0001010c_entry:                            ; preds = %page_done127
  br label %insn_0x0001010c

insn_0x0001010c:                                  ; preds = %insn_0x0001010c_entry
  %lsb = and i32 %mem_val105, 1
  %is_odd = icmp ne i32 %lsb, 0
  br i1 %is_odd, label %jump_misalign, label %jump_aligned, !prof !1

jump_aligned:                                     ; preds = %insn_0x0001010c
  br label %chain_exit

jump_misalign:                                    ; preds = %insn_0x0001010c
  %336 = getelementptr i8, ptr %cpu, i32 188
  store i32 65804, ptr %336, align 4
  %337 = getelementptr i8, ptr %cpu, i32 292
  store i32 2, ptr %337, align 4
  %338 = getelementptr i8, ptr %cpu, i32 308
  store i32 23, ptr %338, align 4
  call void @cec_exception(ptr %cpu, i32 42, ptr %mem)
  %339 = getelementptr i8, ptr %cpu, i64 188
  %next_pc168 = load i32, ptr %339, align 4
  %340 = getelementptr i8, ptr %cpu, i64 188
  %341 = load i32, ptr %340, align 4
  %342 = getelementptr i8, ptr %cpu, i64 296
  %343 = load i8, ptr %342, align 1
  br label %chain_exit

lb_guard_miss:                                    ; preds = %lb_guard
  %344 = getelementptr i8, ptr %cpu, i64 357
  store i8 1, ptr %344, align 1
  br label %return

chain_leave:                                      ; No predecessors!
  br label %return

chain_go:                                         ; preds = %brt_taken
  %chain_slot = getelementptr i8, ptr %chain_table, i64 526368
  %345 = getelementptr i8, ptr %chain_slot, i64 0
  %slot_pc = load i32, ptr %345, align 4
  %346 = icmp eq i32 %slot_pc, 65796
  br i1 %346, label %chain_hit, label %chain_leave150, !prof !0

chain_leave150:                                   ; preds = %chain_go, %brt_taken
  %347 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %347, align 4
  %348 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %348, align 4
  %349 = getelementptr i8, ptr %cpu, i64 308
  store i32 4, ptr %349, align 4
  %350 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %350, align 1
  br label %return

chain_hit:                                        ; preds = %chain_go
  %351 = getelementptr i8, ptr %cpu, i64 188
  store i32 65796, ptr %351, align 4
  %352 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total, ptr %352, align 4
  %353 = getelementptr i8, ptr %chain_slot, i64 8
  %chain_fn = load ptr, ptr %353, align 8
  musttail call swifttailcc void %chain_fn(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_go151:                                      ; preds = %brcc_taken
  %chain_slot156 = getelementptr i8, ptr %chain_table, i64 526176
  %354 = getelementptr i8, ptr %chain_slot156, i64 0
  %slot_pc157 = load i32, ptr %354, align 4
  %355 = icmp eq i32 %slot_pc157, 65772
  br i1 %355, label %chain_hit158, label %chain_leave152, !prof !0

chain_leave152:                                   ; preds = %chain_go151, %brcc_taken
  %356 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %356, align 4
  %357 = getelementptr i8, ptr %cpu, i64 292
  store i32 2, ptr %357, align 4
  %358 = getelementptr i8, ptr %cpu, i64 308
  store i32 19, ptr %358, align 4
  %359 = getelementptr i8, ptr %cpu, i64 296
  store i8 1, ptr %359, align 1
  br label %return

chain_hit158:                                     ; preds = %chain_go151
  %360 = getelementptr i8, ptr %cpu, i64 188
  store i32 65772, ptr %360, align 4
  %361 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total154, ptr %361, align 4
  %362 = getelementptr i8, ptr %chain_slot156, i64 8
  %chain_fn159 = load ptr, ptr %362, align 8
  musttail call swifttailcc void %chain_fn159(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

chain_exit:                                       ; preds = %jump_misalign, %jump_aligned, %did_jump_exit134, %data_misaligned123, %did_jump_exit118, %data_misaligned107, %did_jump_exit101, %data_misaligned90, %did_jump_exit85, %data_misaligned78, %did_jump_exit52, %did_jump_exit45, %data_misaligned35, %did_jump_exit31, %data_misaligned21, %did_jump_exit17, %did_jump_exit13, %data_misaligned3, %did_jump_exit, %data_misaligned
  %next_pc169 = phi i32 [ %next_pc, %data_misaligned ], [ %next_pc141, %did_jump_exit ], [ %next_pc142, %data_misaligned3 ], [ %next_pc143, %did_jump_exit13 ], [ %next_pc144, %did_jump_exit17 ], [ %next_pc145, %data_misaligned21 ], [ %next_pc146, %did_jump_exit31 ], [ %next_pc147, %data_misaligned35 ], [ %next_pc148, %did_jump_exit45 ], [ %next_pc149, %did_jump_exit52 ], [ %next_pc160, %data_misaligned78 ], [ %next_pc161, %did_jump_exit85 ], [ %next_pc162, %data_misaligned90 ], [ %next_pc163, %did_jump_exit101 ], [ %next_pc164, %data_misaligned107 ], [ %next_pc165, %did_jump_exit118 ], [ %next_pc166, %data_misaligned123 ], [ %next_pc167, %did_jump_exit134 ], [ %mem_val105, %jump_aligned ], [ %next_pc168, %jump_misalign ]
  %packets = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit17 ], [ 2, %data_misaligned21 ], [ 2, %did_jump_exit31 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit52 ], [ 20, %data_misaligned78 ], [ 20, %did_jump_exit85 ], [ 20, %data_misaligned90 ], [ 20, %did_jump_exit101 ], [ 22, %data_misaligned107 ], [ 22, %did_jump_exit118 ], [ 22, %data_misaligned123 ], [ 22, %did_jump_exit134 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail = phi i32 [ %38, %data_misaligned ], [ %52, %did_jump_exit ], [ %59, %data_misaligned3 ], [ %74, %did_jump_exit13 ], [ %83, %did_jump_exit17 ], [ %95, %data_misaligned21 ], [ %109, %did_jump_exit31 ], [ %117, %data_misaligned35 ], [ %132, %did_jump_exit45 ], [ %141, %did_jump_exit52 ], [ %244, %data_misaligned78 ], [ %259, %did_jump_exit85 ], [ %267, %data_misaligned90 ], [ %283, %did_jump_exit101 ], [ %294, %data_misaligned107 ], [ %310, %did_jump_exit118 ], [ %318, %data_misaligned123 ], [ %333, %did_jump_exit134 ], [ %mem_val105, %jump_aligned ], [ %341, %jump_misalign ]
  %tail170 = phi i32 [ 2, %data_misaligned ], [ 2, %did_jump_exit ], [ 2, %data_misaligned3 ], [ 2, %did_jump_exit13 ], [ 2, %did_jump_exit17 ], [ 4, %data_misaligned21 ], [ 4, %did_jump_exit31 ], [ 4, %data_misaligned35 ], [ 4, %did_jump_exit45 ], [ 4, %did_jump_exit52 ], [ 4, %data_misaligned78 ], [ 4, %did_jump_exit85 ], [ 4, %data_misaligned90 ], [ 4, %did_jump_exit101 ], [ 2, %data_misaligned107 ], [ 2, %did_jump_exit118 ], [ 2, %data_misaligned123 ], [ 2, %did_jump_exit134 ], [ 2, %jump_aligned ], [ 2, %jump_misalign ]
  %tail171 = phi i32 [ 1, %data_misaligned ], [ 1, %did_jump_exit ], [ 1, %data_misaligned3 ], [ 1, %did_jump_exit13 ], [ 1, %did_jump_exit17 ], [ 2, %data_misaligned21 ], [ 2, %did_jump_exit31 ], [ 2, %data_misaligned35 ], [ 2, %did_jump_exit45 ], [ 2, %did_jump_exit52 ], [ 20, %data_misaligned78 ], [ 20, %did_jump_exit85 ], [ 20, %data_misaligned90 ], [ 20, %did_jump_exit101 ], [ 22, %data_misaligned107 ], [ 22, %did_jump_exit118 ], [ 22, %data_misaligned123 ], [ 22, %did_jump_exit134 ], [ 23, %jump_aligned ], [ 23, %jump_misalign ]
  %tail172 = phi i8 [ %40, %data_misaligned ], [ %54, %did_jump_exit ], [ %61, %data_misaligned3 ], [ %76, %did_jump_exit13 ], [ %85, %did_jump_exit17 ], [ %97, %data_misaligned21 ], [ %111, %did_jump_exit31 ], [ %119, %data_misaligned35 ], [ %134, %did_jump_exit45 ], [ %143, %did_jump_exit52 ], [ %246, %data_misaligned78 ], [ %261, %did_jump_exit85 ], [ %269, %data_misaligned90 ], [ %285, %did_jump_exit101 ], [ %296, %data_misaligned107 ], [ %312, %did_jump_exit118 ], [ %320, %data_misaligned123 ], [ %335, %did_jump_exit134 ], [ 1, %jump_aligned ], [ %343, %jump_misalign ]
  %363 = getelementptr i8, ptr %cpu, i64 348
  %chain_packets174 = load i32, ptr %363, align 4
  %chain_total175 = add nuw i32 %chain_packets174, %packets
  %364 = getelementptr i8, ptr %cpu, i64 344
  %chain_budget176 = load atomic i32, ptr %364 monotonic, align 4, !range !2
  %365 = icmp ult i32 %chain_total175, %chain_budget176
  br i1 %365, label %chain_lookup, label %chain_leave173, !prof !0

chain_lookup:                                     ; preds = %chain_exit
  %366 = lshr i32 %next_pc169, 1
  %367 = and i32 %366, 65535
  %368 = zext i32 %367 to i64
  %369 = mul i64 %368, 16
  %chain_slot177 = getelementptr i8, ptr %chain_table, i64 %369
  %370 = getelementptr i8, ptr %chain_slot177, i64 0
  %slot_pc178 = load i32, ptr %370, align 4
  %371 = icmp eq i32 %slot_pc178, %next_pc169
  br i1 %371, label %chain_hit179, label %chain_leave173, !prof !0

chain_leave173:                                   ; preds = %chain_lookup, %chain_exit
  %372 = getelementptr i8, ptr %cpu, i64 188
  store i32 %tail, ptr %372, align 4
  %373 = getelementptr i8, ptr %cpu, i64 292
  store i32 %tail170, ptr %373, align 4
  %374 = getelementptr i8, ptr %cpu, i64 308
  store i32 %tail171, ptr %374, align 4
  %375 = getelementptr i8, ptr %cpu, i64 296
  store i8 %tail172, ptr %375, align 1
  br label %return

chain_hit179:                                     ; preds = %chain_lookup
  %376 = getelementptr i8, ptr %cpu, i64 188
  store i32 %next_pc169, ptr %376, align 4
  %377 = getelementptr i8, ptr %cpu, i64 348
  store i32 %chain_total175, ptr %377, align 4
  %378 = getelementptr i8, ptr %cpu, i64 296
  store i8 0, ptr %378, align 1
  %379 = getelementptr i8, ptr %chain_slot177, i64 8
  %chain_fn180 = load ptr, ptr %379, align 8
  musttail call swifttailcc void %chain_fn180(ptr swiftself %cpu, ptr swiftasync %mem) #0
  ret void

return:                                           ; preds = %chain_leave173, %chain_leave152, %chain_leave150, %chain_leave, %lb_guard_miss
  ret void
}

declare void @bfin_syscall(ptr, ptr)

declare i8 @mem_read8(ptr, i32)

declare i16 @mem_read16(ptr, i32)

declare i32 @mem_read32(ptr, i32)

declare void @mem_write8(ptr, i32, i8 zeroext)

declare void @mem_write16(ptr, i32, i16 zeroext)

declare void @mem_write32(ptr, i32, i32)

; Function Attrs: cold
declare void @cec_data_alignment(ptr, ptr, i32, i32, i32) #1

; Function Attrs: cold
declare void @cec_check_pending(ptr) #1

; Function Attrs: cold
declare void @cec_exception(ptr, i32, ptr) #1

attributes #0 = { "no_callee_saved_registers" }
attributes #1 = { cold }

!0 = !{!"branch_weights", i32 1048576, i32 1}
!1 = !{!"branch_weights", i32 1, i32 1048576}
!2 = !{i32 0, i32 -2147483648}
