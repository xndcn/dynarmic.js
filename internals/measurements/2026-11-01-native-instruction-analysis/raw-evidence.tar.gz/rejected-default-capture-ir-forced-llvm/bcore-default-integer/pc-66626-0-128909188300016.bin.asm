
build-native-instruction-analysis/capture/bcore-default-integer/pc-66626-0-128909188300016.bin:     file format binary


Disassembly of section .data:

0000753e02607cf0 <.data>:
    753e02607cf0:	48 81 ec 88 00 00 00 	sub    rsp,0x88
    753e02607cf7:	4c 89 74 24 68       	mov    QWORD PTR [rsp+0x68],r14
    753e02607cfc:	4c 89 6c 24 70       	mov    QWORD PTR [rsp+0x70],r13
    753e02607d01:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02607d08:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
    753e02607d0d:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e02607d14:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e02607d1b:	00 
    753e02607d1c:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    753e02607d21:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02607d27:	83 fa 00             	cmp    edx,0x0
    753e02607d2a:	0f 94 c0             	sete   al
    753e02607d2d:	81 ea 42 04 01 00    	sub    edx,0x10442
    753e02607d33:	83 fa 0c             	cmp    edx,0xc
    753e02607d36:	0f 97 c2             	seta   dl
    753e02607d39:	08 d0                	or     al,dl
    753e02607d3b:	24 01                	and    al,0x1
    753e02607d3d:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e02607d43:	83 fa 00             	cmp    edx,0x0
    753e02607d46:	0f 94 c1             	sete   cl
    753e02607d49:	81 ea 42 04 01 00    	sub    edx,0x10442
    753e02607d4f:	83 fa 0c             	cmp    edx,0xc
    753e02607d52:	0f 97 c2             	seta   dl
    753e02607d55:	08 d1                	or     cl,dl
    753e02607d57:	20 c8                	and    al,cl
    753e02607d59:	a8 01                	test   al,0x1
    753e02607d5b:	75 05                	jne    0x753e02607d62
    753e02607d5d:	e9 d6 02 00 00       	jmp    0x753e02608038
    753e02607d62:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607d67:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02607d6e:	48 89 c8             	mov    rax,rcx
    753e02607d71:	48 05 00 00 10 00    	add    rax,0x100000
    753e02607d77:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
    753e02607d7c:	8b 81 18 00 10 00    	mov    eax,DWORD PTR [rcx+0x100018]
    753e02607d82:	83 c0 01             	add    eax,0x1
    753e02607d85:	89 81 18 00 10 00    	mov    DWORD PTR [rcx+0x100018],eax
    753e02607d8b:	3d 30 75 00 00       	cmp    eax,0x7530
    753e02607d90:	75 40                	jne    0x753e02607dd2
    753e02607d92:	48 8b 4c 24 60       	mov    rcx,QWORD PTR [rsp+0x60]
    753e02607d97:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e02607d9d:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    753e02607da1:	89 c2                	mov    edx,eax
    753e02607da3:	83 c2 01             	add    edx,0x1
    753e02607da6:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02607dac:	3d 00 01 00 00       	cmp    eax,0x100
    753e02607db1:	73 1d                	jae    0x753e02607dd0
    753e02607db3:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
    753e02607db8:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e02607dbc:	89 c9                	mov    ecx,ecx
    753e02607dbe:	48 c1 e1 02          	shl    rcx,0x2
    753e02607dc2:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02607dc9:	c7 04 08 06 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x6
    753e02607dd0:	eb 00                	jmp    0x753e02607dd2
    753e02607dd2:	eb 00                	jmp    0x753e02607dd4
    753e02607dd4:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607dd9:	8b 48 24             	mov    ecx,DWORD PTR [rax+0x24]
    753e02607ddc:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02607de2:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02607de8:	89 4c 24 58          	mov    DWORD PTR [rsp+0x58],ecx
    753e02607dec:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    753e02607def:	eb 00                	jmp    0x753e02607df1
    753e02607df1:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607df6:	8b 4c 24 58          	mov    ecx,DWORD PTR [rsp+0x58]
    753e02607dfa:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e02607e00:	81 c9 9c 11 00 00    	or     ecx,0x119c
    753e02607e06:	89 4c 24 54          	mov    DWORD PTR [rsp+0x54],ecx
    753e02607e0a:	89 48 24             	mov    DWORD PTR [rax+0x24],ecx
    753e02607e0d:	eb 00                	jmp    0x753e02607e0f
    753e02607e0f:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607e14:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    753e02607e18:	8b 50 28             	mov    edx,DWORD PTR [rax+0x28]
    753e02607e1b:	c1 e2 02             	shl    edx,0x2
    753e02607e1e:	01 d1                	add    ecx,edx
    753e02607e20:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e02607e24:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02607e27:	eb 00                	jmp    0x753e02607e29
    753e02607e29:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e02607e2d:	83 e0 03             	and    eax,0x3
    753e02607e30:	83 f8 00             	cmp    eax,0x0
    753e02607e33:	74 7c                	je     0x753e02607eb1
    753e02607e35:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    753e02607e3a:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    753e02607e3e:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
    753e02607e43:	c7 87 bc 00 00 00 4c 	mov    DWORD PTR [rdi+0xbc],0x1044c
    753e02607e4a:	04 01 00 
    753e02607e4d:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02607e54:	00 00 00 
    753e02607e57:	c7 87 34 01 00 00 04 	mov    DWORD PTR [rdi+0x134],0x4
    753e02607e5e:	00 00 00 
    753e02607e61:	31 c0                	xor    eax,eax
    753e02607e63:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02607e6a:	5c 00 00 
    753e02607e6d:	ba 4c 04 01 00       	mov    edx,0x1044c
    753e02607e72:	45 31 c0             	xor    r8d,r8d
    753e02607e75:	ff d0                	call   rax
    753e02607e77:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607e7c:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607e82:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607e88:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607e8e:	be 04 00 00 00       	mov    esi,0x4
    753e02607e93:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607e98:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    753e02607e9c:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    753e02607ea0:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    753e02607ea4:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e02607ea8:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    753e02607eac:	e9 98 01 00 00       	jmp    0x753e02608049
    753e02607eb1:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02607eb8:	00 
    753e02607eb9:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    753e02607ebd:	c1 e9 0c             	shr    ecx,0xc
    753e02607ec0:	89 c9                	mov    ecx,ecx
    753e02607ec2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02607ec6:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
    753e02607ecb:	48 83 f8 00          	cmp    rax,0x0
    753e02607ecf:	74 1a                	je     0x753e02607eeb
    753e02607ed1:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
    753e02607ed6:	8b 4c 24 50          	mov    ecx,DWORD PTR [rsp+0x50]
    753e02607eda:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02607ee0:	89 c9                	mov    ecx,ecx
    753e02607ee2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02607ee5:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e02607ee9:	eb 4e                	jmp    0x753e02607f39
    753e02607eeb:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607ef0:	8b 74 24 50          	mov    esi,DWORD PTR [rsp+0x50]
    753e02607ef4:	48 8b 7c 24 68       	mov    rdi,QWORD PTR [rsp+0x68]
    753e02607ef9:	c7 80 bc 00 00 00 4c 	mov    DWORD PTR [rax+0xbc],0x1044c
    753e02607f00:	04 01 00 
    753e02607f03:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02607f0a:	00 00 00 
    753e02607f0d:	c7 80 34 01 00 00 04 	mov    DWORD PTR [rax+0x134],0x4
    753e02607f14:	00 00 00 
    753e02607f17:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02607f1e:	5c 00 00 
    753e02607f21:	ff d0                	call   rax
    753e02607f23:	89 c1                	mov    ecx,eax
    753e02607f25:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607f2a:	89 4c 24 28          	mov    DWORD PTR [rsp+0x28],ecx
    753e02607f2e:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02607f35:	75 14                	jne    0x753e02607f4b
    753e02607f37:	eb 4c                	jmp    0x753e02607f85
    753e02607f39:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607f3e:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e02607f42:	89 4c 24 24          	mov    DWORD PTR [rsp+0x24],ecx
    753e02607f46:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02607f49:	eb 44                	jmp    0x753e02607f8f
    753e02607f4b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02607f50:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e02607f56:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02607f5c:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02607f62:	be 04 00 00 00       	mov    esi,0x4
    753e02607f67:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607f6c:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    753e02607f70:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    753e02607f74:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    753e02607f78:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e02607f7c:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    753e02607f80:	e9 c4 00 00 00       	jmp    0x753e02608049
    753e02607f85:	8b 44 24 28          	mov    eax,DWORD PTR [rsp+0x28]
    753e02607f89:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e02607f8d:	eb aa                	jmp    0x753e02607f39
    753e02607f8f:	eb 00                	jmp    0x753e02607f91
    753e02607f91:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
    753e02607f95:	83 e0 01             	and    eax,0x1
    753e02607f98:	83 f8 00             	cmp    eax,0x0
    753e02607f9b:	75 2b                	jne    0x753e02607fc8
    753e02607f9d:	8b 54 24 24          	mov    edx,DWORD PTR [rsp+0x24]
    753e02607fa1:	be 05 00 00 00       	mov    esi,0x5
    753e02607fa6:	b9 02 00 00 00       	mov    ecx,0x2
    753e02607fab:	b0 01                	mov    al,0x1
    753e02607fad:	89 d7                	mov    edi,edx
    753e02607faf:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    753e02607fb3:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    753e02607fb7:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    753e02607fbb:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e02607fbf:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    753e02607fc3:	e9 81 00 00 00       	jmp    0x753e02608049
    753e02607fc8:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
    753e02607fcd:	48 8b 54 24 68       	mov    rdx,QWORD PTR [rsp+0x68]
    753e02607fd2:	c7 87 bc 00 00 00 4e 	mov    DWORD PTR [rdi+0xbc],0x1044e
    753e02607fd9:	04 01 00 
    753e02607fdc:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e02607fe3:	00 00 00 
    753e02607fe6:	c7 87 34 01 00 00 05 	mov    DWORD PTR [rdi+0x134],0x5
    753e02607fed:	00 00 00 
    753e02607ff0:	48 b8 d0 da e3 81 8e 	movabs rax,0x5c8e81e3dad0
    753e02607ff7:	5c 00 00 
    753e02607ffa:	be 2a 00 00 00       	mov    esi,0x2a
    753e02607fff:	ff d0                	call   rax
    753e02608001:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e02608006:	8b b8 bc 00 00 00    	mov    edi,DWORD PTR [rax+0xbc]
    753e0260800c:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608012:	8a 80 28 01 00 00    	mov    al,BYTE PTR [rax+0x128]
    753e02608018:	be 05 00 00 00       	mov    esi,0x5
    753e0260801d:	b9 02 00 00 00       	mov    ecx,0x2
    753e02608022:	89 7c 24 3c          	mov    DWORD PTR [rsp+0x3c],edi
    753e02608026:	89 74 24 40          	mov    DWORD PTR [rsp+0x40],esi
    753e0260802a:	89 54 24 44          	mov    DWORD PTR [rsp+0x44],edx
    753e0260802e:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e02608032:	88 44 24 4f          	mov    BYTE PTR [rsp+0x4f],al
    753e02608036:	eb 11                	jmp    0x753e02608049
    753e02608038:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e0260803d:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e02608044:	e9 d2 00 00 00       	jmp    0x753e0260811b
    753e02608049:	48 8b 4c 24 70       	mov    rcx,QWORD PTR [rsp+0x70]
    753e0260804e:	8b 54 24 3c          	mov    edx,DWORD PTR [rsp+0x3c]
    753e02608052:	8b 44 24 40          	mov    eax,DWORD PTR [rsp+0x40]
    753e02608056:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e0260805a:	8b 7c 24 48          	mov    edi,DWORD PTR [rsp+0x48]
    753e0260805e:	8a 5c 24 4f          	mov    bl,BYTE PTR [rsp+0x4f]
    753e02608062:	88 5c 24 0f          	mov    BYTE PTR [rsp+0xf],bl
    753e02608066:	89 c3                	mov    ebx,eax
    753e02608068:	89 5c 24 10          	mov    DWORD PTR [rsp+0x10],ebx
    753e0260806c:	89 7c 24 14          	mov    DWORD PTR [rsp+0x14],edi
    753e02608070:	89 74 24 18          	mov    DWORD PTR [rsp+0x18],esi
    753e02608074:	89 54 24 1c          	mov    DWORD PTR [rsp+0x1c],edx
    753e02608078:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260807e:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
    753e02608082:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02608088:	73 29                	jae    0x753e026080b3
    753e0260808a:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
    753e0260808f:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    753e02608093:	89 d1                	mov    ecx,edx
    753e02608095:	c1 e9 01             	shr    ecx,0x1
    753e02608098:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260809e:	89 c9                	mov    ecx,ecx
    753e026080a0:	48 c1 e1 04          	shl    rcx,0x4
    753e026080a4:	48 89 c6             	mov    rsi,rax
    753e026080a7:	48 01 ce             	add    rsi,rcx
    753e026080aa:	48 89 34 24          	mov    QWORD PTR [rsp],rsi
    753e026080ae:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e026080b1:	74 2f                	je     0x753e026080e2
    753e026080b3:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
    753e026080b8:	8a 4c 24 0f          	mov    cl,BYTE PTR [rsp+0xf]
    753e026080bc:	8b 54 24 10          	mov    edx,DWORD PTR [rsp+0x10]
    753e026080c0:	8b 74 24 14          	mov    esi,DWORD PTR [rsp+0x14]
    753e026080c4:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
    753e026080c8:	89 b8 bc 00 00 00    	mov    DWORD PTR [rax+0xbc],edi
    753e026080ce:	89 b0 24 01 00 00    	mov    DWORD PTR [rax+0x124],esi
    753e026080d4:	89 90 34 01 00 00    	mov    DWORD PTR [rax+0x134],edx
    753e026080da:	88 88 28 01 00 00    	mov    BYTE PTR [rax+0x128],cl
    753e026080e0:	eb 39                	jmp    0x753e0260811b
    753e026080e2:	4c 8b 74 24 68       	mov    r14,QWORD PTR [rsp+0x68]
    753e026080e7:	4c 8b 6c 24 70       	mov    r13,QWORD PTR [rsp+0x70]
    753e026080ec:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
    753e026080f0:	8b 4c 24 20          	mov    ecx,DWORD PTR [rsp+0x20]
    753e026080f4:	8b 54 24 1c          	mov    edx,DWORD PTR [rsp+0x1c]
    753e026080f8:	41 89 95 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],edx
    753e026080ff:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02608106:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260810d:	00 
    753e0260810e:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02608112:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753e02608119:	ff e0                	jmp    rax
    753e0260811b:	48 81 c4 88 00 00 00 	add    rsp,0x88
    753e02608122:	c2 08 00             	ret    0x8
