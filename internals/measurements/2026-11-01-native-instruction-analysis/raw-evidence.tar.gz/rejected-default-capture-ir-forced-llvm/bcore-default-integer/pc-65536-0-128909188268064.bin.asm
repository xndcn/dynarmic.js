
build-native-instruction-analysis/capture/bcore-default-integer/pc-65536-0-128909188268064.bin:     file format binary


Disassembly of section .data:

0000753e02600020 <.data>:
    753e02600020:	4c 89 74 24 e8       	mov    QWORD PTR [rsp-0x18],r14
    753e02600025:	4c 89 6c 24 f0       	mov    QWORD PTR [rsp-0x10],r13
    753e0260002a:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e02600031:	48 89 44 24 f8       	mov    QWORD PTR [rsp-0x8],rax
    753e02600036:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    753e0260003b:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02600041:	83 fa 00             	cmp    edx,0x0
    753e02600044:	0f 94 c0             	sete   al
    753e02600047:	81 ea 00 00 01 00    	sub    edx,0x10000
    753e0260004d:	83 fa 02             	cmp    edx,0x2
    753e02600050:	0f 97 c2             	seta   dl
    753e02600053:	08 d0                	or     al,dl
    753e02600055:	24 01                	and    al,0x1
    753e02600057:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260005d:	83 fa 00             	cmp    edx,0x0
    753e02600060:	0f 94 c1             	sete   cl
    753e02600063:	81 ea 00 00 01 00    	sub    edx,0x10000
    753e02600069:	83 fa 02             	cmp    edx,0x2
    753e0260006c:	0f 97 c2             	seta   dl
    753e0260006f:	08 d1                	or     cl,dl
    753e02600071:	20 c8                	and    al,cl
    753e02600073:	a8 01                	test   al,0x1
    753e02600075:	75 05                	jne    0x753e0260007c
    753e02600077:	e9 16 01 00 00       	jmp    0x753e02600192
    753e0260007c:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    753e02600081:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e02600088:	48 89 c8             	mov    rax,rcx
    753e0260008b:	48 05 00 00 10 00    	add    rax,0x100000
    753e02600091:	48 89 44 24 e0       	mov    QWORD PTR [rsp-0x20],rax
    753e02600096:	8b 81 00 00 10 00    	mov    eax,DWORD PTR [rcx+0x100000]
    753e0260009c:	83 c0 01             	add    eax,0x1
    753e0260009f:	89 81 00 00 10 00    	mov    DWORD PTR [rcx+0x100000],eax
    753e026000a5:	3d 30 75 00 00       	cmp    eax,0x7530
    753e026000aa:	75 40                	jne    0x753e026000ec
    753e026000ac:	48 8b 4c 24 e0       	mov    rcx,QWORD PTR [rsp-0x20]
    753e026000b1:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e026000b7:	89 44 24 dc          	mov    DWORD PTR [rsp-0x24],eax
    753e026000bb:	89 c2                	mov    edx,eax
    753e026000bd:	83 c2 01             	add    edx,0x1
    753e026000c0:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e026000c6:	3d 00 01 00 00       	cmp    eax,0x100
    753e026000cb:	73 1d                	jae    0x753e026000ea
    753e026000cd:	48 8b 44 24 e0       	mov    rax,QWORD PTR [rsp-0x20]
    753e026000d2:	8b 4c 24 dc          	mov    ecx,DWORD PTR [rsp-0x24]
    753e026000d6:	89 c9                	mov    ecx,ecx
    753e026000d8:	48 c1 e1 02          	shl    rcx,0x2
    753e026000dc:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e026000e3:	c7 04 08 00 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x0
    753e026000ea:	eb 00                	jmp    0x753e026000ec
    753e026000ec:	eb 00                	jmp    0x753e026000ee
    753e026000ee:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    753e026000f3:	8b 48 38             	mov    ecx,DWORD PTR [rax+0x38]
    753e026000f6:	83 c1 f4             	add    ecx,0xfffffff4
    753e026000f9:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e026000fc:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    753e02600102:	89 4c 24 d4          	mov    DWORD PTR [rsp-0x2c],ecx
    753e02600106:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    753e0260010c:	89 44 24 d8          	mov    DWORD PTR [rsp-0x28],eax
    753e02600110:	eb 00                	jmp    0x753e02600112
    753e02600112:	48 8b 4c 24 f0       	mov    rcx,QWORD PTR [rsp-0x10]
    753e02600117:	8b 74 24 d8          	mov    esi,DWORD PTR [rsp-0x28]
    753e0260011b:	8b 44 24 d4          	mov    eax,DWORD PTR [rsp-0x2c]
    753e0260011f:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    753e02600125:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    753e0260012b:	83 ff 01             	cmp    edi,0x1
    753e0260012e:	0f 97 c3             	seta   bl
    753e02600131:	3d 02 00 01 00       	cmp    eax,0x10002
    753e02600136:	0f 94 c0             	sete   al
    753e02600139:	20 c3                	and    bl,al
    753e0260013b:	b8 06 00 01 00       	mov    eax,0x10006
    753e02600140:	f6 c3 01             	test   bl,0x1
    753e02600143:	0f 45 c2             	cmovne eax,edx
    753e02600146:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    753e0260014c:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    753e02600152:	83 ff 01             	cmp    edi,0x1
    753e02600155:	0f 97 c3             	seta   bl
    753e02600158:	81 fe 02 00 01 00    	cmp    esi,0x10002
    753e0260015e:	40 0f 94 c6          	sete   sil
    753e02600162:	40 20 f3             	and    bl,sil
    753e02600165:	f6 c3 01             	test   bl,0x1
    753e02600168:	0f 45 c2             	cmovne eax,edx
    753e0260016b:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    753e02600171:	c7 81 bc 00 00 00 14 	mov    DWORD PTR [rcx+0xbc],0x10014
    753e02600178:	00 01 00 
    753e0260017b:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e02600181:	83 c0 02             	add    eax,0x2
    753e02600184:	89 44 24 d0          	mov    DWORD PTR [rsp-0x30],eax
    753e02600188:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260018e:	72 10                	jb     0x753e026001a0
    753e02600190:	eb 2e                	jmp    0x753e026001c0
    753e02600192:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    753e02600197:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e0260019e:	eb 77                	jmp    0x753e02600217
    753e026001a0:	48 8b 44 24 f8       	mov    rax,QWORD PTR [rsp-0x8]
    753e026001a5:	48 89 c1             	mov    rcx,rax
    753e026001a8:	48 81 c1 a0 00 08 00 	add    rcx,0x800a0
    753e026001af:	48 89 4c 24 c8       	mov    QWORD PTR [rsp-0x38],rcx
    753e026001b4:	81 b8 a0 00 08 00 14 	cmp    DWORD PTR [rax+0x800a0],0x10014
    753e026001bb:	00 01 00 
    753e026001be:	74 2c                	je     0x753e026001ec
    753e026001c0:	48 8b 44 24 f0       	mov    rax,QWORD PTR [rsp-0x10]
    753e026001c5:	c7 80 bc 00 00 00 14 	mov    DWORD PTR [rax+0xbc],0x10014
    753e026001cc:	00 01 00 
    753e026001cf:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026001d6:	00 00 00 
    753e026001d9:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e026001e0:	00 00 00 
    753e026001e3:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e026001ea:	eb 2b                	jmp    0x753e02600217
    753e026001ec:	4c 8b 74 24 e8       	mov    r14,QWORD PTR [rsp-0x18]
    753e026001f1:	4c 8b 6c 24 f0       	mov    r13,QWORD PTR [rsp-0x10]
    753e026001f6:	48 8b 44 24 c8       	mov    rax,QWORD PTR [rsp-0x38]
    753e026001fb:	8b 4c 24 d0          	mov    ecx,DWORD PTR [rsp-0x30]
    753e026001ff:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10014
    753e02600206:	14 00 01 00 
    753e0260020a:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e02600211:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02600215:	ff e0                	jmp    rax
    753e02600217:	c2 08 00             	ret    0x8
