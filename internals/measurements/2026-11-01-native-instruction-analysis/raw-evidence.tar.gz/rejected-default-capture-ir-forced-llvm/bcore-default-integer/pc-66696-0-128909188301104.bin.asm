
build-native-instruction-analysis/capture/bcore-default-integer/pc-66696-0-128909188301104.bin:     file format binary


Disassembly of section .data:

0000753e02608130 <.data>:
    753e02608130:	48 81 ec c8 00 00 00 	sub    rsp,0xc8
    753e02608137:	4c 89 b4 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r14
    753e0260813e:	00 
    753e0260813f:	4c 89 ac 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r13
    753e02608146:	00 
    753e02608147:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260814e:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
    753e02608155:	00 
    753e02608156:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260815d:	48 89 84 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rax
    753e02608164:	00 
    753e02608165:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    753e0260816c:	00 
    753e0260816d:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e02608173:	83 fa 00             	cmp    edx,0x0
    753e02608176:	0f 94 c0             	sete   al
    753e02608179:	81 ea 88 04 01 00    	sub    edx,0x10488
    753e0260817f:	83 fa 18             	cmp    edx,0x18
    753e02608182:	0f 97 c2             	seta   dl
    753e02608185:	08 d0                	or     al,dl
    753e02608187:	24 01                	and    al,0x1
    753e02608189:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260818f:	83 fa 00             	cmp    edx,0x0
    753e02608192:	0f 94 c1             	sete   cl
    753e02608195:	81 ea 88 04 01 00    	sub    edx,0x10488
    753e0260819b:	83 fa 18             	cmp    edx,0x18
    753e0260819e:	0f 97 c2             	seta   dl
    753e026081a1:	08 d1                	or     cl,dl
    753e026081a3:	20 c8                	and    al,cl
    753e026081a5:	a8 01                	test   al,0x1
    753e026081a7:	75 05                	jne    0x753e026081ae
    753e026081a9:	e9 08 07 00 00       	jmp    0x753e026088b6
    753e026081ae:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026081b5:	00 
    753e026081b6:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e026081bd:	48 89 c8             	mov    rax,rcx
    753e026081c0:	48 05 00 00 10 00    	add    rax,0x100000
    753e026081c6:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    753e026081cd:	00 
    753e026081ce:	8b 81 1c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10001c]
    753e026081d4:	83 c0 01             	add    eax,0x1
    753e026081d7:	89 81 1c 00 10 00    	mov    DWORD PTR [rcx+0x10001c],eax
    753e026081dd:	3d 30 75 00 00       	cmp    eax,0x7530
    753e026081e2:	75 4c                	jne    0x753e02608230
    753e026081e4:	48 8b 8c 24 a0 00 00 	mov    rcx,QWORD PTR [rsp+0xa0]
    753e026081eb:	00 
    753e026081ec:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e026081f2:	89 84 24 9c 00 00 00 	mov    DWORD PTR [rsp+0x9c],eax
    753e026081f9:	89 c2                	mov    edx,eax
    753e026081fb:	83 c2 01             	add    edx,0x1
    753e026081fe:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e02608204:	3d 00 01 00 00       	cmp    eax,0x100
    753e02608209:	73 23                	jae    0x753e0260822e
    753e0260820b:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    753e02608212:	00 
    753e02608213:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x9c]
    753e0260821a:	89 c9                	mov    ecx,ecx
    753e0260821c:	48 c1 e1 02          	shl    rcx,0x2
    753e02608220:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e02608227:	c7 04 08 07 00 00 00 	mov    DWORD PTR [rax+rcx*1],0x7
    753e0260822e:	eb 00                	jmp    0x753e02608230
    753e02608230:	eb 00                	jmp    0x753e02608232
    753e02608232:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608239:	00 
    753e0260823a:	8b 48 28             	mov    ecx,DWORD PTR [rax+0x28]
    753e0260823d:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e02608243:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02608249:	89 8c 24 98 00 00 00 	mov    DWORD PTR [rsp+0x98],ecx
    753e02608250:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02608253:	eb 00                	jmp    0x753e02608255
    753e02608255:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e0260825c:	00 
    753e0260825d:	8b 8c 24 98 00 00 00 	mov    ecx,DWORD PTR [rsp+0x98]
    753e02608264:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e0260826a:	81 c9 f4 12 00 00    	or     ecx,0x12f4
    753e02608270:	89 8c 24 94 00 00 00 	mov    DWORD PTR [rsp+0x94],ecx
    753e02608277:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e0260827a:	eb 00                	jmp    0x753e0260827c
    753e0260827c:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [rsp+0x94]
    753e02608283:	83 e0 03             	and    eax,0x3
    753e02608286:	83 f8 00             	cmp    eax,0x0
    753e02608289:	74 7d                	je     0x753e02608308
    753e0260828b:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    753e02608292:	00 
    753e02608293:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260829a:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    753e026082a1:	00 
    753e026082a2:	c7 87 bc 00 00 00 90 	mov    DWORD PTR [rdi+0xbc],0x10490
    753e026082a9:	04 01 00 
    753e026082ac:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e026082b3:	00 00 00 
    753e026082b6:	c7 87 34 01 00 00 03 	mov    DWORD PTR [rdi+0x134],0x3
    753e026082bd:	00 00 00 
    753e026082c0:	31 c0                	xor    eax,eax
    753e026082c2:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026082c9:	5c 00 00 
    753e026082cc:	ba 90 04 01 00       	mov    edx,0x10490
    753e026082d1:	45 31 c0             	xor    r8d,r8d
    753e026082d4:	ff d0                	call   rax
    753e026082d6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026082dd:	00 
    753e026082de:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026082e4:	b9 03 00 00 00       	mov    ecx,0x3
    753e026082e9:	b8 02 00 00 00       	mov    eax,0x2
    753e026082ee:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e026082f5:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e026082fc:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e02608303:	e9 4f 06 00 00       	jmp    0x753e02608957
    753e02608308:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e0260830f:	00 
    753e02608310:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e02608317:	c1 e9 0c             	shr    ecx,0xc
    753e0260831a:	89 c9                	mov    ecx,ecx
    753e0260831c:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02608320:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e02608327:	00 
    753e02608328:	48 83 f8 00          	cmp    rax,0x0
    753e0260832c:	74 20                	je     0x753e0260834e
    753e0260832e:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e02608335:	00 
    753e02608336:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e0260833d:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02608343:	89 c9                	mov    ecx,ecx
    753e02608345:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02608348:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e0260834c:	eb 5a                	jmp    0x753e026083a8
    753e0260834e:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608355:	00 
    753e02608356:	8b b4 24 94 00 00 00 	mov    esi,DWORD PTR [rsp+0x94]
    753e0260835d:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    753e02608364:	00 
    753e02608365:	c7 80 bc 00 00 00 90 	mov    DWORD PTR [rax+0xbc],0x10490
    753e0260836c:	04 01 00 
    753e0260836f:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02608376:	00 00 00 
    753e02608379:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e02608380:	00 00 00 
    753e02608383:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260838a:	5c 00 00 
    753e0260838d:	ff d0                	call   rax
    753e0260838f:	89 c1                	mov    ecx,eax
    753e02608391:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608398:	00 
    753e02608399:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
    753e0260839d:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026083a4:	75 12                	jne    0x753e026083b8
    753e026083a6:	eb 42                	jmp    0x753e026083ea
    753e026083a8:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026083af:	00 
    753e026083b0:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e026083b4:	89 08                	mov    DWORD PTR [rax],ecx
    753e026083b6:	eb 3c                	jmp    0x753e026083f4
    753e026083b8:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026083bf:	00 
    753e026083c0:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026083c6:	b9 03 00 00 00       	mov    ecx,0x3
    753e026083cb:	b8 02 00 00 00       	mov    eax,0x2
    753e026083d0:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e026083d7:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e026083de:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e026083e5:	e9 6d 05 00 00       	jmp    0x753e02608957
    753e026083ea:	8b 44 24 78          	mov    eax,DWORD PTR [rsp+0x78]
    753e026083ee:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e026083f2:	eb b4                	jmp    0x753e026083a8
    753e026083f4:	eb 00                	jmp    0x753e026083f6
    753e026083f6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026083fd:	00 
    753e026083fe:	8b 8c 24 94 00 00 00 	mov    ecx,DWORD PTR [rsp+0x94]
    753e02608405:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260840b:	81 c9 00 00 01 00    	or     ecx,0x10000
    753e02608411:	89 4c 24 74          	mov    DWORD PTR [rsp+0x74],ecx
    753e02608415:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02608418:	eb 00                	jmp    0x753e0260841a
    753e0260841a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608421:	00 
    753e02608422:	8b 4c 24 74          	mov    ecx,DWORD PTR [rsp+0x74]
    753e02608426:	81 e1 00 00 ff ff    	and    ecx,0xffff0000
    753e0260842c:	81 c9 f8 12 00 00    	or     ecx,0x12f8
    753e02608432:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    753e02608436:	89 48 28             	mov    DWORD PTR [rax+0x28],ecx
    753e02608439:	eb 00                	jmp    0x753e0260843b
    753e0260843b:	8b 44 24 70          	mov    eax,DWORD PTR [rsp+0x70]
    753e0260843f:	83 e0 03             	and    eax,0x3
    753e02608442:	83 f8 00             	cmp    eax,0x0
    753e02608445:	74 7a                	je     0x753e026084c1
    753e02608447:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    753e0260844e:	00 
    753e0260844f:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e02608453:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    753e0260845a:	00 
    753e0260845b:	c7 87 bc 00 00 00 9a 	mov    DWORD PTR [rdi+0xbc],0x1049a
    753e02608462:	04 01 00 
    753e02608465:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260846c:	00 00 00 
    753e0260846f:	c7 87 34 01 00 00 06 	mov    DWORD PTR [rdi+0x134],0x6
    753e02608476:	00 00 00 
    753e02608479:	31 c0                	xor    eax,eax
    753e0260847b:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e02608482:	5c 00 00 
    753e02608485:	ba 9a 04 01 00       	mov    edx,0x1049a
    753e0260848a:	45 31 c0             	xor    r8d,r8d
    753e0260848d:	ff d0                	call   rax
    753e0260848f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608496:	00 
    753e02608497:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260849d:	b9 06 00 00 00       	mov    ecx,0x6
    753e026084a2:	b8 02 00 00 00       	mov    eax,0x2
    753e026084a7:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e026084ae:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e026084b5:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e026084bc:	e9 96 04 00 00       	jmp    0x753e02608957
    753e026084c1:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e026084c8:	00 
    753e026084c9:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e026084cd:	c1 e9 0c             	shr    ecx,0xc
    753e026084d0:	89 c9                	mov    ecx,ecx
    753e026084d2:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026084d6:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
    753e026084db:	48 83 f8 00          	cmp    rax,0x0
    753e026084df:	74 1a                	je     0x753e026084fb
    753e026084e1:	48 8b 44 24 68       	mov    rax,QWORD PTR [rsp+0x68]
    753e026084e6:	8b 4c 24 70          	mov    ecx,DWORD PTR [rsp+0x70]
    753e026084ea:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026084f0:	89 c9                	mov    ecx,ecx
    753e026084f2:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026084f5:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e026084f9:	eb 57                	jmp    0x753e02608552
    753e026084fb:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608502:	00 
    753e02608503:	8b 74 24 70          	mov    esi,DWORD PTR [rsp+0x70]
    753e02608507:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    753e0260850e:	00 
    753e0260850f:	c7 80 bc 00 00 00 9a 	mov    DWORD PTR [rax+0xbc],0x1049a
    753e02608516:	04 01 00 
    753e02608519:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e02608520:	00 00 00 
    753e02608523:	c7 80 34 01 00 00 06 	mov    DWORD PTR [rax+0x134],0x6
    753e0260852a:	00 00 00 
    753e0260852d:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e02608534:	5c 00 00 
    753e02608537:	ff d0                	call   rax
    753e02608539:	89 c1                	mov    ecx,eax
    753e0260853b:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608542:	00 
    753e02608543:	89 4c 24 60          	mov    DWORD PTR [rsp+0x60],ecx
    753e02608547:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260854e:	75 13                	jne    0x753e02608563
    753e02608550:	eb 43                	jmp    0x753e02608595
    753e02608552:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608559:	00 
    753e0260855a:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
    753e0260855e:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e02608561:	eb 3c                	jmp    0x753e0260859f
    753e02608563:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e0260856a:	00 
    753e0260856b:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608571:	b9 06 00 00 00       	mov    ecx,0x6
    753e02608576:	b8 02 00 00 00       	mov    eax,0x2
    753e0260857b:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e02608582:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e02608589:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e02608590:	e9 c2 03 00 00       	jmp    0x753e02608957
    753e02608595:	8b 44 24 60          	mov    eax,DWORD PTR [rsp+0x60]
    753e02608599:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
    753e0260859d:	eb b3                	jmp    0x753e02608552
    753e0260859f:	eb 00                	jmp    0x753e026085a1
    753e026085a1:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026085a8:	00 
    753e026085a9:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    753e026085ac:	89 44 24 5c          	mov    DWORD PTR [rsp+0x5c],eax
    753e026085b0:	83 e0 03             	and    eax,0x3
    753e026085b3:	83 f8 00             	cmp    eax,0x0
    753e026085b6:	74 7a                	je     0x753e02608632
    753e026085b8:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    753e026085bf:	00 
    753e026085c0:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e026085c4:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    753e026085cb:	00 
    753e026085cc:	c7 87 bc 00 00 00 9c 	mov    DWORD PTR [rdi+0xbc],0x1049c
    753e026085d3:	04 01 00 
    753e026085d6:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e026085dd:	00 00 00 
    753e026085e0:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    753e026085e7:	00 00 00 
    753e026085ea:	31 c0                	xor    eax,eax
    753e026085ec:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e026085f3:	5c 00 00 
    753e026085f6:	ba 9c 04 01 00       	mov    edx,0x1049c
    753e026085fb:	45 31 c0             	xor    r8d,r8d
    753e026085fe:	ff d0                	call   rax
    753e02608600:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608607:	00 
    753e02608608:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260860e:	b9 07 00 00 00       	mov    ecx,0x7
    753e02608613:	b8 04 00 00 00       	mov    eax,0x4
    753e02608618:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e0260861f:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e02608626:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e0260862d:	e9 25 03 00 00       	jmp    0x753e02608957
    753e02608632:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e02608639:	00 
    753e0260863a:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e0260863e:	c1 e9 0c             	shr    ecx,0xc
    753e02608641:	89 c9                	mov    ecx,ecx
    753e02608643:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e02608647:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
    753e0260864c:	48 83 f8 00          	cmp    rax,0x0
    753e02608650:	74 1a                	je     0x753e0260866c
    753e02608652:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
    753e02608657:	8b 4c 24 5c          	mov    ecx,DWORD PTR [rsp+0x5c]
    753e0260865b:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e02608661:	89 c9                	mov    ecx,ecx
    753e02608663:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e02608666:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e0260866a:	eb 57                	jmp    0x753e026086c3
    753e0260866c:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608673:	00 
    753e02608674:	8b 74 24 5c          	mov    esi,DWORD PTR [rsp+0x5c]
    753e02608678:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    753e0260867f:	00 
    753e02608680:	c7 80 bc 00 00 00 9c 	mov    DWORD PTR [rax+0xbc],0x1049c
    753e02608687:	04 01 00 
    753e0260868a:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02608691:	00 00 00 
    753e02608694:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    753e0260869b:	00 00 00 
    753e0260869e:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e026086a5:	5c 00 00 
    753e026086a8:	ff d0                	call   rax
    753e026086aa:	89 c1                	mov    ecx,eax
    753e026086ac:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026086b3:	00 
    753e026086b4:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e026086b8:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e026086bf:	75 22                	jne    0x753e026086e3
    753e026086c1:	eb 52                	jmp    0x753e02608715
    753e026086c3:	8b 44 24 5c          	mov    eax,DWORD PTR [rsp+0x5c]
    753e026086c7:	8b 4c 24 4c          	mov    ecx,DWORD PTR [rsp+0x4c]
    753e026086cb:	89 4c 24 40          	mov    DWORD PTR [rsp+0x40],ecx
    753e026086cf:	83 c0 04             	add    eax,0x4
    753e026086d2:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e026086d6:	83 e0 03             	and    eax,0x3
    753e026086d9:	83 f8 00             	cmp    eax,0x0
    753e026086dc:	75 41                	jne    0x753e0260871f
    753e026086de:	e9 b6 00 00 00       	jmp    0x753e02608799
    753e026086e3:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026086ea:	00 
    753e026086eb:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e026086f1:	b9 07 00 00 00       	mov    ecx,0x7
    753e026086f6:	b8 04 00 00 00       	mov    eax,0x4
    753e026086fb:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e02608702:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e02608709:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e02608710:	e9 42 02 00 00       	jmp    0x753e02608957
    753e02608715:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e02608719:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e0260871d:	eb a4                	jmp    0x753e026086c3
    753e0260871f:	48 8b bc 24 b0 00 00 	mov    rdi,QWORD PTR [rsp+0xb0]
    753e02608726:	00 
    753e02608727:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260872b:	48 8b b4 24 a8 00 00 	mov    rsi,QWORD PTR [rsp+0xa8]
    753e02608732:	00 
    753e02608733:	c7 87 bc 00 00 00 9c 	mov    DWORD PTR [rdi+0xbc],0x1049c
    753e0260873a:	04 01 00 
    753e0260873d:	c7 87 24 01 00 00 04 	mov    DWORD PTR [rdi+0x124],0x4
    753e02608744:	00 00 00 
    753e02608747:	c7 87 34 01 00 00 07 	mov    DWORD PTR [rdi+0x134],0x7
    753e0260874e:	00 00 00 
    753e02608751:	31 c0                	xor    eax,eax
    753e02608753:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260875a:	5c 00 00 
    753e0260875d:	ba 9c 04 01 00       	mov    edx,0x1049c
    753e02608762:	45 31 c0             	xor    r8d,r8d
    753e02608765:	ff d0                	call   rax
    753e02608767:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e0260876e:	00 
    753e0260876f:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e02608775:	b9 07 00 00 00       	mov    ecx,0x7
    753e0260877a:	b8 04 00 00 00       	mov    eax,0x4
    753e0260877f:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e02608786:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e0260878d:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e02608794:	e9 be 01 00 00       	jmp    0x753e02608957
    753e02608799:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
    753e026087a0:	00 
    753e026087a1:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e026087a5:	c1 e9 0c             	shr    ecx,0xc
    753e026087a8:	89 c9                	mov    ecx,ecx
    753e026087aa:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e026087ae:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e026087b3:	48 83 f8 00          	cmp    rax,0x0
    753e026087b7:	74 1a                	je     0x753e026087d3
    753e026087b9:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e026087be:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e026087c2:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e026087c8:	89 c9                	mov    ecx,ecx
    753e026087ca:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e026087cd:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e026087d1:	eb 57                	jmp    0x753e0260882a
    753e026087d3:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026087da:	00 
    753e026087db:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e026087df:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
    753e026087e6:	00 
    753e026087e7:	c7 80 bc 00 00 00 9c 	mov    DWORD PTR [rax+0xbc],0x1049c
    753e026087ee:	04 01 00 
    753e026087f1:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e026087f8:	00 00 00 
    753e026087fb:	c7 80 34 01 00 00 07 	mov    DWORD PTR [rax+0x134],0x7
    753e02608802:	00 00 00 
    753e02608805:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260880c:	5c 00 00 
    753e0260880f:	ff d0                	call   rax
    753e02608811:	89 c1                	mov    ecx,eax
    753e02608813:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e0260881a:	00 
    753e0260881b:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    753e0260881f:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e02608826:	75 27                	jne    0x753e0260884f
    753e02608828:	eb 57                	jmp    0x753e02608881
    753e0260882a:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608831:	00 
    753e02608832:	8b 74 24 40          	mov    esi,DWORD PTR [rsp+0x40]
    753e02608836:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260883a:	8b 54 24 34          	mov    edx,DWORD PTR [rsp+0x34]
    753e0260883e:	83 c1 04             	add    ecx,0x4
    753e02608841:	89 70 3c             	mov    DWORD PTR [rax+0x3c],esi
    753e02608844:	89 90 a8 00 00 00    	mov    DWORD PTR [rax+0xa8],edx
    753e0260884a:	89 48 38             	mov    DWORD PTR [rax+0x38],ecx
    753e0260884d:	eb 3c                	jmp    0x753e0260888b
    753e0260884f:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e02608856:	00 
    753e02608857:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260885d:	b9 07 00 00 00       	mov    ecx,0x7
    753e02608862:	b8 04 00 00 00       	mov    eax,0x4
    753e02608867:	89 94 24 88 00 00 00 	mov    DWORD PTR [rsp+0x88],edx
    753e0260886e:	89 8c 24 8c 00 00 00 	mov    DWORD PTR [rsp+0x8c],ecx
    753e02608875:	89 84 24 90 00 00 00 	mov    DWORD PTR [rsp+0x90],eax
    753e0260887c:	e9 d6 00 00 00       	jmp    0x753e02608957
    753e02608881:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    753e02608885:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e02608889:	eb 9f                	jmp    0x753e0260882a
    753e0260888b:	eb 00                	jmp    0x753e0260888d
    753e0260888d:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    753e02608894:	00 
    753e02608895:	c7 81 bc 00 00 00 d0 	mov    DWORD PTR [rcx+0xbc],0x100d0
    753e0260889c:	00 01 00 
    753e0260889f:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e026088a5:	83 c0 08             	add    eax,0x8
    753e026088a8:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e026088ac:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e026088b2:	72 16                	jb     0x753e026088ca
    753e026088b4:	eb 37                	jmp    0x753e026088ed
    753e026088b6:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026088bd:	00 
    753e026088be:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e026088c5:	e9 4a 01 00 00       	jmp    0x753e02608a14
    753e026088ca:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    753e026088d1:	00 
    753e026088d2:	48 89 c1             	mov    rcx,rax
    753e026088d5:	48 81 c1 80 06 08 00 	add    rcx,0x80680
    753e026088dc:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    753e026088e1:	81 b8 80 06 08 00 d0 	cmp    DWORD PTR [rax+0x80680],0x100d0
    753e026088e8:	00 01 00 
    753e026088eb:	74 32                	je     0x753e0260891f
    753e026088ed:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026088f4:	00 
    753e026088f5:	c7 80 bc 00 00 00 d0 	mov    DWORD PTR [rax+0xbc],0x100d0
    753e026088fc:	00 01 00 
    753e026088ff:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e02608906:	00 00 00 
    753e02608909:	c7 80 34 01 00 00 08 	mov    DWORD PTR [rax+0x134],0x8
    753e02608910:	00 00 00 
    753e02608913:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260891a:	e9 f5 00 00 00       	jmp    0x753e02608a14
    753e0260891f:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    753e02608926:	00 
    753e02608927:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    753e0260892e:	00 
    753e0260892f:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753e02608934:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e02608938:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x100d0
    753e0260893f:	d0 00 01 00 
    753e02608943:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260894a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260894e:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    753e02608955:	ff e0                	jmp    rax
    753e02608957:	48 8b 8c 24 b0 00 00 	mov    rcx,QWORD PTR [rsp+0xb0]
    753e0260895e:	00 
    753e0260895f:	8b 94 24 88 00 00 00 	mov    edx,DWORD PTR [rsp+0x88]
    753e02608966:	8b 84 24 8c 00 00 00 	mov    eax,DWORD PTR [rsp+0x8c]
    753e0260896d:	8b b4 24 90 00 00 00 	mov    esi,DWORD PTR [rsp+0x90]
    753e02608974:	89 c7                	mov    edi,eax
    753e02608976:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e0260897a:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e0260897e:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e02608982:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e02608988:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e0260898c:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e02608992:	73 2d                	jae    0x753e026089c1
    753e02608994:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
    753e0260899b:	00 
    753e0260899c:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e026089a0:	89 d1                	mov    ecx,edx
    753e026089a2:	c1 e9 01             	shr    ecx,0x1
    753e026089a5:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e026089ab:	89 c9                	mov    ecx,ecx
    753e026089ad:	48 c1 e1 04          	shl    rcx,0x4
    753e026089b1:	48 89 c6             	mov    rsi,rax
    753e026089b4:	48 01 ce             	add    rsi,rcx
    753e026089b7:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e026089bc:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e026089bf:	74 1e                	je     0x753e026089df
    753e026089c1:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
    753e026089c8:	00 
    753e026089c9:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    753e026089cd:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e026089d1:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    753e026089d7:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    753e026089dd:	eb 35                	jmp    0x753e02608a14
    753e026089df:	4c 8b b4 24 a8 00 00 	mov    r14,QWORD PTR [rsp+0xa8]
    753e026089e6:	00 
    753e026089e7:	4c 8b ac 24 b0 00 00 	mov    r13,QWORD PTR [rsp+0xb0]
    753e026089ee:	00 
    753e026089ef:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e026089f4:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e026089f8:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e026089ff:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e02608a06:	00 
    753e02608a07:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e02608a0b:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    753e02608a12:	ff e0                	jmp    rax
    753e02608a14:	48 81 c4 c8 00 00 00 	add    rsp,0xc8
    753e02608a1b:	c2 08 00             	ret    0x8
