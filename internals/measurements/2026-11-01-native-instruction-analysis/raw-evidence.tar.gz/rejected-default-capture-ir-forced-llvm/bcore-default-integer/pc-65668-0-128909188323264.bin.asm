
build-native-instruction-analysis/capture/bcore-default-integer/pc-65668-0-128909188323264.bin:     file format binary


Disassembly of section .data:

0000753e0260d7c0 <.data>:
    753e0260d7c0:	48 81 ec a8 00 00 00 	sub    rsp,0xa8
    753e0260d7c7:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
    753e0260d7ce:	00 
    753e0260d7cf:	4c 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r13
    753e0260d7d6:	00 
    753e0260d7d7:	49 8b 85 50 01 00 00 	mov    rax,QWORD PTR [r13+0x150]
    753e0260d7de:	48 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rax
    753e0260d7e5:	00 
    753e0260d7e6:	49 8b 85 38 01 00 00 	mov    rax,QWORD PTR [r13+0x138]
    753e0260d7ed:	48 89 84 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rax
    753e0260d7f4:	00 
    753e0260d7f5:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    753e0260d7fc:	00 
    753e0260d7fd:	8b 91 a0 00 00 00    	mov    edx,DWORD PTR [rcx+0xa0]
    753e0260d803:	83 fa 00             	cmp    edx,0x0
    753e0260d806:	0f 94 c0             	sete   al
    753e0260d809:	81 ea 84 00 01 00    	sub    edx,0x10084
    753e0260d80f:	83 fa 0a             	cmp    edx,0xa
    753e0260d812:	0f 97 c2             	seta   dl
    753e0260d815:	08 d0                	or     al,dl
    753e0260d817:	24 01                	and    al,0x1
    753e0260d819:	8b 91 a4 00 00 00    	mov    edx,DWORD PTR [rcx+0xa4]
    753e0260d81f:	83 fa 00             	cmp    edx,0x0
    753e0260d822:	0f 94 c1             	sete   cl
    753e0260d825:	81 ea 84 00 01 00    	sub    edx,0x10084
    753e0260d82b:	83 fa 0a             	cmp    edx,0xa
    753e0260d82e:	0f 97 c2             	seta   dl
    753e0260d831:	08 d1                	or     cl,dl
    753e0260d833:	20 c8                	and    al,cl
    753e0260d835:	a8 01                	test   al,0x1
    753e0260d837:	75 05                	jne    0x753e0260d83e
    753e0260d839:	e9 c9 03 00 00       	jmp    0x753e0260dc07
    753e0260d83e:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d845:	00 
    753e0260d846:	48 8b 88 50 01 00 00 	mov    rcx,QWORD PTR [rax+0x150]
    753e0260d84d:	48 89 c8             	mov    rax,rcx
    753e0260d850:	48 05 00 00 10 00    	add    rax,0x100000
    753e0260d856:	48 89 84 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rax
    753e0260d85d:	00 
    753e0260d85e:	8b 81 2c 00 10 00    	mov    eax,DWORD PTR [rcx+0x10002c]
    753e0260d864:	83 c0 01             	add    eax,0x1
    753e0260d867:	89 81 2c 00 10 00    	mov    DWORD PTR [rcx+0x10002c],eax
    753e0260d86d:	3d 30 75 00 00       	cmp    eax,0x7530
    753e0260d872:	75 46                	jne    0x753e0260d8ba
    753e0260d874:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
    753e0260d87b:	00 
    753e0260d87c:	8b 81 00 00 04 00    	mov    eax,DWORD PTR [rcx+0x40000]
    753e0260d882:	89 44 24 7c          	mov    DWORD PTR [rsp+0x7c],eax
    753e0260d886:	89 c2                	mov    edx,eax
    753e0260d888:	83 c2 01             	add    edx,0x1
    753e0260d88b:	89 91 00 00 04 00    	mov    DWORD PTR [rcx+0x40000],edx
    753e0260d891:	3d 00 01 00 00       	cmp    eax,0x100
    753e0260d896:	73 20                	jae    0x753e0260d8b8
    753e0260d898:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
    753e0260d89f:	00 
    753e0260d8a0:	8b 4c 24 7c          	mov    ecx,DWORD PTR [rsp+0x7c]
    753e0260d8a4:	89 c9                	mov    ecx,ecx
    753e0260d8a6:	48 c1 e1 02          	shl    rcx,0x2
    753e0260d8aa:	48 81 c1 04 00 04 00 	add    rcx,0x40004
    753e0260d8b1:	c7 04 08 0b 00 00 00 	mov    DWORD PTR [rax+rcx*1],0xb
    753e0260d8b8:	eb 00                	jmp    0x753e0260d8ba
    753e0260d8ba:	eb 00                	jmp    0x753e0260d8bc
    753e0260d8bc:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d8c3:	00 
    753e0260d8c4:	8b 48 10             	mov    ecx,DWORD PTR [rax+0x10]
    753e0260d8c7:	89 4c 24 70          	mov    DWORD PTR [rsp+0x70],ecx
    753e0260d8cb:	8b 40 3c             	mov    eax,DWORD PTR [rax+0x3c]
    753e0260d8ce:	89 44 24 74          	mov    DWORD PTR [rsp+0x74],eax
    753e0260d8d2:	83 c0 fc             	add    eax,0xfffffffc
    753e0260d8d5:	89 44 24 78          	mov    DWORD PTR [rsp+0x78],eax
    753e0260d8d9:	83 e0 03             	and    eax,0x3
    753e0260d8dc:	83 f8 00             	cmp    eax,0x0
    753e0260d8df:	74 67                	je     0x753e0260d948
    753e0260d8e1:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    753e0260d8e8:	00 
    753e0260d8e9:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    753e0260d8ed:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    753e0260d8f4:	00 
    753e0260d8f5:	c7 87 24 01 00 00 08 	mov    DWORD PTR [rdi+0x124],0x8
    753e0260d8fc:	00 00 00 
    753e0260d8ff:	c7 87 34 01 00 00 01 	mov    DWORD PTR [rdi+0x134],0x1
    753e0260d906:	00 00 00 
    753e0260d909:	31 c0                	xor    eax,eax
    753e0260d90b:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260d912:	5c 00 00 
    753e0260d915:	ba 84 00 01 00       	mov    edx,0x10084
    753e0260d91a:	45 31 c0             	xor    r8d,r8d
    753e0260d91d:	ff d0                	call   rax
    753e0260d91f:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d926:	00 
    753e0260d927:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260d92d:	b9 01 00 00 00       	mov    ecx,0x1
    753e0260d932:	b8 08 00 00 00       	mov    eax,0x8
    753e0260d937:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    753e0260d93b:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e0260d93f:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260d943:	e9 60 03 00 00       	jmp    0x753e0260dca8
    753e0260d948:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    753e0260d94f:	00 
    753e0260d950:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    753e0260d954:	c1 e9 0c             	shr    ecx,0xc
    753e0260d957:	89 c9                	mov    ecx,ecx
    753e0260d959:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260d95d:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
    753e0260d962:	48 83 f8 00          	cmp    rax,0x0
    753e0260d966:	74 1a                	je     0x753e0260d982
    753e0260d968:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
    753e0260d96d:	8b 4c 24 78          	mov    ecx,DWORD PTR [rsp+0x78]
    753e0260d971:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260d977:	89 c9                	mov    ecx,ecx
    753e0260d979:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260d97c:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260d980:	eb 4d                	jmp    0x753e0260d9cf
    753e0260d982:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d989:	00 
    753e0260d98a:	8b 74 24 78          	mov    esi,DWORD PTR [rsp+0x78]
    753e0260d98e:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    753e0260d995:	00 
    753e0260d996:	c7 80 24 01 00 00 08 	mov    DWORD PTR [rax+0x124],0x8
    753e0260d99d:	00 00 00 
    753e0260d9a0:	c7 80 34 01 00 00 01 	mov    DWORD PTR [rax+0x134],0x1
    753e0260d9a7:	00 00 00 
    753e0260d9aa:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260d9b1:	5c 00 00 
    753e0260d9b4:	ff d0                	call   rax
    753e0260d9b6:	89 c1                	mov    ecx,eax
    753e0260d9b8:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d9bf:	00 
    753e0260d9c0:	89 4c 24 50          	mov    DWORD PTR [rsp+0x50],ecx
    753e0260d9c4:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260d9cb:	75 2d                	jne    0x753e0260d9fa
    753e0260d9cd:	eb 54                	jmp    0x753e0260da23
    753e0260d9cf:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260d9d6:	00 
    753e0260d9d7:	8b 54 24 70          	mov    edx,DWORD PTR [rsp+0x70]
    753e0260d9db:	8b 4c 24 54          	mov    ecx,DWORD PTR [rsp+0x54]
    753e0260d9df:	89 10                	mov    DWORD PTR [rax],edx
    753e0260d9e1:	89 48 04             	mov    DWORD PTR [rax+0x4],ecx
    753e0260d9e4:	8b 88 a0 00 00 00    	mov    ecx,DWORD PTR [rax+0xa0]
    753e0260d9ea:	89 4c 24 48          	mov    DWORD PTR [rsp+0x48],ecx
    753e0260d9ee:	8b 80 a4 00 00 00    	mov    eax,DWORD PTR [rax+0xa4]
    753e0260d9f4:	89 44 24 4c          	mov    DWORD PTR [rsp+0x4c],eax
    753e0260d9f8:	eb 33                	jmp    0x753e0260da2d
    753e0260d9fa:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260da01:	00 
    753e0260da02:	8b 90 bc 00 00 00    	mov    edx,DWORD PTR [rax+0xbc]
    753e0260da08:	b9 01 00 00 00       	mov    ecx,0x1
    753e0260da0d:	b8 08 00 00 00       	mov    eax,0x8
    753e0260da12:	89 54 24 64          	mov    DWORD PTR [rsp+0x64],edx
    753e0260da16:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e0260da1a:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260da1e:	e9 85 02 00 00       	jmp    0x753e0260dca8
    753e0260da23:	8b 44 24 50          	mov    eax,DWORD PTR [rsp+0x50]
    753e0260da27:	89 44 24 54          	mov    DWORD PTR [rsp+0x54],eax
    753e0260da2b:	eb a2                	jmp    0x753e0260d9cf
    753e0260da2d:	eb 00                	jmp    0x753e0260da2f
    753e0260da2f:	8b 44 24 74          	mov    eax,DWORD PTR [rsp+0x74]
    753e0260da33:	83 c0 f8             	add    eax,0xfffffff8
    753e0260da36:	89 44 24 44          	mov    DWORD PTR [rsp+0x44],eax
    753e0260da3a:	83 e0 03             	and    eax,0x3
    753e0260da3d:	83 f8 00             	cmp    eax,0x0
    753e0260da40:	74 6e                	je     0x753e0260dab0
    753e0260da42:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
    753e0260da49:	00 
    753e0260da4a:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260da4e:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
    753e0260da55:	00 
    753e0260da56:	c7 87 bc 00 00 00 8c 	mov    DWORD PTR [rdi+0xbc],0x1008c
    753e0260da5d:	00 01 00 
    753e0260da60:	c7 87 24 01 00 00 02 	mov    DWORD PTR [rdi+0x124],0x2
    753e0260da67:	00 00 00 
    753e0260da6a:	c7 87 34 01 00 00 02 	mov    DWORD PTR [rdi+0x134],0x2
    753e0260da71:	00 00 00 
    753e0260da74:	31 c0                	xor    eax,eax
    753e0260da76:	48 b8 d0 e8 e3 81 8e 	movabs rax,0x5c8e81e3e8d0
    753e0260da7d:	5c 00 00 
    753e0260da80:	ba 8c 00 01 00       	mov    edx,0x1008c
    753e0260da85:	45 31 c0             	xor    r8d,r8d
    753e0260da88:	ff d0                	call   rax
    753e0260da8a:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260da91:	00 
    753e0260da92:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    753e0260da98:	b8 02 00 00 00       	mov    eax,0x2
    753e0260da9d:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    753e0260daa1:	89 c1                	mov    ecx,eax
    753e0260daa3:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e0260daa7:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260daab:	e9 f8 01 00 00       	jmp    0x753e0260dca8
    753e0260dab0:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
    753e0260dab7:	00 
    753e0260dab8:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260dabc:	c1 e9 0c             	shr    ecx,0xc
    753e0260dabf:	89 c9                	mov    ecx,ecx
    753e0260dac1:	48 8b 04 c8          	mov    rax,QWORD PTR [rax+rcx*8]
    753e0260dac5:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
    753e0260daca:	48 83 f8 00          	cmp    rax,0x0
    753e0260dace:	74 1a                	je     0x753e0260daea
    753e0260dad0:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
    753e0260dad5:	8b 4c 24 44          	mov    ecx,DWORD PTR [rsp+0x44]
    753e0260dad9:	81 e1 ff 0f 00 00    	and    ecx,0xfff
    753e0260dadf:	89 c9                	mov    ecx,ecx
    753e0260dae1:	8b 04 08             	mov    eax,DWORD PTR [rax+rcx*1]
    753e0260dae4:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e0260dae8:	eb 57                	jmp    0x753e0260db41
    753e0260daea:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260daf1:	00 
    753e0260daf2:	8b 74 24 44          	mov    esi,DWORD PTR [rsp+0x44]
    753e0260daf6:	48 8b bc 24 88 00 00 	mov    rdi,QWORD PTR [rsp+0x88]
    753e0260dafd:	00 
    753e0260dafe:	c7 80 bc 00 00 00 8c 	mov    DWORD PTR [rax+0xbc],0x1008c
    753e0260db05:	00 01 00 
    753e0260db08:	c7 80 24 01 00 00 02 	mov    DWORD PTR [rax+0x124],0x2
    753e0260db0f:	00 00 00 
    753e0260db12:	c7 80 34 01 00 00 02 	mov    DWORD PTR [rax+0x134],0x2
    753e0260db19:	00 00 00 
    753e0260db1c:	48 b8 f0 85 d2 81 8e 	movabs rax,0x5c8e81d285f0
    753e0260db23:	5c 00 00 
    753e0260db26:	ff d0                	call   rax
    753e0260db28:	89 c1                	mov    ecx,eax
    753e0260db2a:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260db31:	00 
    753e0260db32:	89 4c 24 30          	mov    DWORD PTR [rsp+0x30],ecx
    753e0260db36:	80 b8 28 01 00 00 00 	cmp    BYTE PTR [rax+0x128],0x0
    753e0260db3d:	75 13                	jne    0x753e0260db52
    753e0260db3f:	eb 37                	jmp    0x753e0260db78
    753e0260db41:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260db48:	00 
    753e0260db49:	8b 4c 24 34          	mov    ecx,DWORD PTR [rsp+0x34]
    753e0260db4d:	89 48 08             	mov    DWORD PTR [rax+0x8],ecx
    753e0260db50:	eb 30                	jmp    0x753e0260db82
    753e0260db52:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260db59:	00 
    753e0260db5a:	8b 88 bc 00 00 00    	mov    ecx,DWORD PTR [rax+0xbc]
    753e0260db60:	b8 02 00 00 00       	mov    eax,0x2
    753e0260db65:	89 4c 24 64          	mov    DWORD PTR [rsp+0x64],ecx
    753e0260db69:	89 c1                	mov    ecx,eax
    753e0260db6b:	89 4c 24 68          	mov    DWORD PTR [rsp+0x68],ecx
    753e0260db6f:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
    753e0260db73:	e9 30 01 00 00       	jmp    0x753e0260dca8
    753e0260db78:	8b 44 24 30          	mov    eax,DWORD PTR [rsp+0x30]
    753e0260db7c:	89 44 24 34          	mov    DWORD PTR [rsp+0x34],eax
    753e0260db80:	eb bf                	jmp    0x753e0260db41
    753e0260db82:	eb 00                	jmp    0x753e0260db84
    753e0260db84:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    753e0260db8b:	00 
    753e0260db8c:	8b 74 24 4c          	mov    esi,DWORD PTR [rsp+0x4c]
    753e0260db90:	8b 44 24 48          	mov    eax,DWORD PTR [rsp+0x48]
    753e0260db94:	8b b9 98 00 00 00    	mov    edi,DWORD PTR [rcx+0x98]
    753e0260db9a:	8b 91 90 00 00 00    	mov    edx,DWORD PTR [rcx+0x90]
    753e0260dba0:	83 ff 01             	cmp    edi,0x1
    753e0260dba3:	0f 97 c3             	seta   bl
    753e0260dba6:	3d 8e 00 01 00       	cmp    eax,0x1008e
    753e0260dbab:	0f 94 c0             	sete   al
    753e0260dbae:	20 c3                	and    bl,al
    753e0260dbb0:	b8 92 00 01 00       	mov    eax,0x10092
    753e0260dbb5:	f6 c3 01             	test   bl,0x1
    753e0260dbb8:	0f 45 c2             	cmovne eax,edx
    753e0260dbbb:	8b b9 9c 00 00 00    	mov    edi,DWORD PTR [rcx+0x9c]
    753e0260dbc1:	8b 91 94 00 00 00    	mov    edx,DWORD PTR [rcx+0x94]
    753e0260dbc7:	83 ff 01             	cmp    edi,0x1
    753e0260dbca:	0f 97 c3             	seta   bl
    753e0260dbcd:	81 fe 8e 00 01 00    	cmp    esi,0x1008e
    753e0260dbd3:	40 0f 94 c6          	sete   sil
    753e0260dbd7:	40 20 f3             	and    bl,sil
    753e0260dbda:	f6 c3 01             	test   bl,0x1
    753e0260dbdd:	0f 45 c2             	cmovne eax,edx
    753e0260dbe0:	89 81 a8 00 00 00    	mov    DWORD PTR [rcx+0xa8],eax
    753e0260dbe6:	c7 81 bc 00 00 00 28 	mov    DWORD PTR [rcx+0xbc],0x10328
    753e0260dbed:	03 01 00 
    753e0260dbf0:	8b 81 5c 01 00 00    	mov    eax,DWORD PTR [rcx+0x15c]
    753e0260dbf6:	83 c0 03             	add    eax,0x3
    753e0260dbf9:	89 44 24 2c          	mov    DWORD PTR [rsp+0x2c],eax
    753e0260dbfd:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260dc03:	72 16                	jb     0x753e0260dc1b
    753e0260dc05:	eb 37                	jmp    0x753e0260dc3e
    753e0260dc07:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260dc0e:	00 
    753e0260dc0f:	c6 80 65 01 00 00 01 	mov    BYTE PTR [rax+0x165],0x1
    753e0260dc16:	e9 41 01 00 00       	jmp    0x753e0260dd5c
    753e0260dc1b:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e0260dc22:	00 
    753e0260dc23:	48 89 c1             	mov    rcx,rax
    753e0260dc26:	48 81 c1 40 19 08 00 	add    rcx,0x81940
    753e0260dc2d:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
    753e0260dc32:	81 b8 40 19 08 00 28 	cmp    DWORD PTR [rax+0x81940],0x10328
    753e0260dc39:	03 01 00 
    753e0260dc3c:	74 32                	je     0x753e0260dc70
    753e0260dc3e:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260dc45:	00 
    753e0260dc46:	c7 80 bc 00 00 00 28 	mov    DWORD PTR [rax+0xbc],0x10328
    753e0260dc4d:	03 01 00 
    753e0260dc50:	c7 80 24 01 00 00 04 	mov    DWORD PTR [rax+0x124],0x4
    753e0260dc57:	00 00 00 
    753e0260dc5a:	c7 80 34 01 00 00 03 	mov    DWORD PTR [rax+0x134],0x3
    753e0260dc61:	00 00 00 
    753e0260dc64:	c6 80 28 01 00 00 01 	mov    BYTE PTR [rax+0x128],0x1
    753e0260dc6b:	e9 ec 00 00 00       	jmp    0x753e0260dd5c
    753e0260dc70:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    753e0260dc77:	00 
    753e0260dc78:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    753e0260dc7f:	00 
    753e0260dc80:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
    753e0260dc85:	8b 4c 24 2c          	mov    ecx,DWORD PTR [rsp+0x2c]
    753e0260dc89:	41 c7 85 bc 00 00 00 	mov    DWORD PTR [r13+0xbc],0x10328
    753e0260dc90:	28 03 01 00 
    753e0260dc94:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260dc9b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260dc9f:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    753e0260dca6:	ff e0                	jmp    rax
    753e0260dca8:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
    753e0260dcaf:	00 
    753e0260dcb0:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
    753e0260dcb4:	8b 44 24 68          	mov    eax,DWORD PTR [rsp+0x68]
    753e0260dcb8:	8b 74 24 6c          	mov    esi,DWORD PTR [rsp+0x6c]
    753e0260dcbc:	89 c7                	mov    edi,eax
    753e0260dcbe:	89 7c 24 10          	mov    DWORD PTR [rsp+0x10],edi
    753e0260dcc2:	89 74 24 14          	mov    DWORD PTR [rsp+0x14],esi
    753e0260dcc6:	89 54 24 18          	mov    DWORD PTR [rsp+0x18],edx
    753e0260dcca:	03 81 5c 01 00 00    	add    eax,DWORD PTR [rcx+0x15c]
    753e0260dcd0:	89 44 24 1c          	mov    DWORD PTR [rsp+0x1c],eax
    753e0260dcd4:	3b 81 58 01 00 00    	cmp    eax,DWORD PTR [rcx+0x158]
    753e0260dcda:	73 2d                	jae    0x753e0260dd09
    753e0260dcdc:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
    753e0260dce3:	00 
    753e0260dce4:	8b 54 24 18          	mov    edx,DWORD PTR [rsp+0x18]
    753e0260dce8:	89 d1                	mov    ecx,edx
    753e0260dcea:	c1 e9 01             	shr    ecx,0x1
    753e0260dced:	81 e1 ff ff 00 00    	and    ecx,0xffff
    753e0260dcf3:	89 c9                	mov    ecx,ecx
    753e0260dcf5:	48 c1 e1 04          	shl    rcx,0x4
    753e0260dcf9:	48 89 c6             	mov    rsi,rax
    753e0260dcfc:	48 01 ce             	add    rsi,rcx
    753e0260dcff:	48 89 74 24 08       	mov    QWORD PTR [rsp+0x8],rsi
    753e0260dd04:	39 14 08             	cmp    DWORD PTR [rax+rcx*1],edx
    753e0260dd07:	74 1e                	je     0x753e0260dd27
    753e0260dd09:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
    753e0260dd10:	00 
    753e0260dd11:	8b 4c 24 10          	mov    ecx,DWORD PTR [rsp+0x10]
    753e0260dd15:	8b 54 24 14          	mov    edx,DWORD PTR [rsp+0x14]
    753e0260dd19:	89 90 24 01 00 00    	mov    DWORD PTR [rax+0x124],edx
    753e0260dd1f:	89 88 34 01 00 00    	mov    DWORD PTR [rax+0x134],ecx
    753e0260dd25:	eb 35                	jmp    0x753e0260dd5c
    753e0260dd27:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
    753e0260dd2e:	00 
    753e0260dd2f:	4c 8b ac 24 90 00 00 	mov    r13,QWORD PTR [rsp+0x90]
    753e0260dd36:	00 
    753e0260dd37:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
    753e0260dd3c:	8b 4c 24 1c          	mov    ecx,DWORD PTR [rsp+0x1c]
    753e0260dd40:	41 89 8d 5c 01 00 00 	mov    DWORD PTR [r13+0x15c],ecx
    753e0260dd47:	41 c6 85 28 01 00 00 	mov    BYTE PTR [r13+0x128],0x0
    753e0260dd4e:	00 
    753e0260dd4f:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
    753e0260dd53:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    753e0260dd5a:	ff e0                	jmp    rax
    753e0260dd5c:	48 81 c4 a8 00 00 00 	add    rsp,0xa8
    753e0260dd63:	c2 08 00             	ret    0x8
