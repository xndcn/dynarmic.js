# Run only after all collections terminate. Archive data/recipes, not SDK binaries.
import pathlib, shutil, hashlib, json, tarfile, subprocess
root=pathlib.Path('/tmp/dynarmic-a64-static-evidence')
stage=root/'archive';stage.mkdir()
allowed={'.json','.jsonl','.log','.exit','.mjs','.py','.sh','.patch'}
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in allowed:shutil.copy2(p,stage/p.name)
for name in ['paired-fixed','paired-population','paired-population-profile','population-aa','population-matched','paired-coremark','paired-coremark-repeat','coremark-combined','cpu-after','duration-paired']:
 shutil.copytree(root/name,stage/name)
shutil.copy2('/tmp/dynarmic-coremark-120k/manifest.json',stage/'duration-workload-manifest.json')
manifest={'baseRevision':subprocess.check_output(['git','rev-parse','bb7f1af'],text=True).strip(),
 'sourceObservation':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'note':'Candidate implementation is bound by source.patch and hashes. Build-tree source observations are not build-time attestations.',
 'sources':{}}
for p in sorted(pathlib.Path('src/dynarmic/frontend/wasm').glob('*.h')):
 manifest['sources'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for file in ['patches/0006-wasm-a64-decoder-index.patch','tests/unit/a64_decoder_test.cpp','tests/bench/cpu_profile.mjs','tests/bench/protocol.mjs','tests/bench/coremark_protocol.mjs','tests/bench/coremark/sample.mjs','tests/bench/coremark/compare.mjs']:
 manifest['sources'][file]=hashlib.sha256(pathlib.Path(file).read_bytes()).hexdigest()
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
hashes={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
output=pathlib.Path('docs/measurements/2026-10-23-a64-decoder/evidence.tar.gz')
assert not output.exists()
with tarfile.open(output,'w:gz') as tar:
 for p in sorted(stage.iterdir()):tar.add(p,arcname=p.name)
print('Archived',len(hashes),'files;',output.stat().st_size,'bytes')
