#!/bin/bash
# Regression gate for the wasm backend.
#
#   tests/regress.sh [--strict] [--coremark WORKLOAD_DIR] [EM_BUILD] [NATIVE_BUILD]
#       (defaults: build-em build-native)
#
# EM_BUILD     Emscripten build tree (JIT hosts: jit_runbin.js, smc_test.js, ...)
# NATIVE_BUILD host build tree (ARM guests, reference programs, IR-level tests)
#
# Every guest runs under jit_runbin in memory modes 0 (thunks), 1 (page table
# fastmem) and 2 (flat window), must reach its PASS marker, and the *_log
# variants must reproduce the reference program's mix log exactly.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
strict=0
if [ "${1:-}" = "--strict" ]; then
    strict=1
    shift
fi
coremark=""
if [ "${1:-}" = "--coremark" ]; then
    coremark="$(cd "${2:?--coremark needs a built workload directory}" && pwd)" || exit 2
    shift 2
fi
EM="$(cd "${1:-$ROOT/build-em}" && pwd)"
NATIVE="$(cd "${2:-$ROOT/build-native}" && pwd)"
HOSTS="$EM/tests"
GUESTS="$NATIVE/tests/guest"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
cd "$WORK"

fail=0
bad() { echo "FAIL $*"; fail=1; }

# Small fixed-program hosts.
node "$HOSTS/jit_demo.js" | grep '^PASS' >/dev/null || bad jit_demo
node --test "$ROOT"/tests/bench/*.test.mjs >/dev/null || bad benchmark_protocol
benchmark_runs=1
[ "$strict" -eq 1 ] && benchmark_runs=5
node "$ROOT/tests/bench/run.mjs" "$HOSTS" --runs "$benchmark_runs" --output benchmark.json >/dev/null \
    || bad benchmark_runner
node "$ROOT/tests/bench/validate.mjs" benchmark.json >/dev/null \
    || bad benchmark_schema
node "$HOSTS/smc_test.js" "$GUESTS/smc.bin" | grep '^PASS' >/dev/null || bad smc_test

node "$HOSTS/instance_test.js" | grep '^PASS' >/dev/null || bad instance_test
node "$HOSTS/runtime_table_test.js" | grep '^PASS' >/dev/null || bad runtime_table_test
node "$HOSTS/stats_test.js" | grep '^PASS' >/dev/null || bad stats_test
node "$HOSTS/lifecycle_test.js" | grep '^PASS' >/dev/null || bad lifecycle_test
node "$ROOT/tests/bench/cache_run.mjs" "$HOSTS" --runs "$benchmark_runs" --output cache-benchmark.json \
    || bad cache_benchmark_runner
node "$ROOT/tests/bench/cache_validate.mjs" cache-benchmark.json >/dev/null \
    || bad cache_benchmark_schema
node "$ROOT/tests/bench/cache_population_run.mjs" "$HOSTS" --runs "$benchmark_runs" --output cache-population.json \
    || bad cache_population_runner
node "$ROOT/tests/bench/cache_population_validate.mjs" cache-population.json >/dev/null \
    || bad cache_population_schema

# Planner properties and decoder equivalence (checks stay enabled in Release).
"$NATIVE/tests/region_plan_test" || bad region_plan
"$NATIVE/tests/arm_decoder_test" || bad arm_decoder
"$NATIVE/tests/a64_decoder_test" || bad a64_decoder

# IR-level tests (emitted natively, executed by Node).
"$NATIVE/tests/smoke_ir" smoke.wasm >/dev/null 2>&1 && node "$ROOT/tests/ir/smoke.mjs" smoke.wasm >/dev/null || bad smoke_ir
"$NATIVE/tests/sat64_ir" sat64.wasm >/dev/null && node "$ROOT/tests/ir/sat64.mjs" sat64.wasm >/dev/null || bad sat64_ir
"$NATIVE/tests/wasm_binary_test" . >/dev/null && node "$ROOT/tests/ir/wasm_binary_test.mjs" . >/dev/null || bad wasm_binary_test

# Frontend-only and full-pipeline translation of the same program, run by the JS dispatcher.
for mode in --raw ""; do
    specs=()
    for a in 1000 1008 1010 1014; do
        "$NATIVE/tests/tools/block_dump" $mode loop $a b$a.wasm >/dev/null 2>&1 || bad "block_dump${mode:+ $mode} $a"
        specs+=("$a=b$a.wasm")
    done
    node "$ROOT/tests/tools/dispatch.mjs" "${specs[@]}" 1000 2000 \
        --expect halt=0,r0=0,r1=16,r15=0x2000,z=1 >/dev/null 2>&1 || bad "dispatch loop${mode:+ $mode}"
done

# Guests run to completion.
for t in coproc crc crypto fp16 fp media neon neon2 neon3 neon4 neon5 neon6 qc test; do
    for m in 0 1 2; do
        node "$HOSTS/jit_runbin.js" "$GUESTS/$t.bin" $m > run.out 2>&1
        grep -q PASS-marker run.out || bad "$t/$m"
        if [ "$t" = test ]; then
            # Per-stage checksums must match the native build of the same C.
            "$GUESTS/host_ref" | awk '/^stage/{printf "result%s %s\n", substr($1, 6), $2}' > want.txt
            grep -E '^result[0-5] ' run.out | diff -q want.txt - >/dev/null || bad "test/$m checksums"
        fi
    done
done

# Strict mix-log comparison against the reference programs.
ref() {  # ref <guest> <reference program> <log it writes>
    rm -f "$3"
    "$GUESTS/$2" >/dev/null || { bad "$2"; return; }
    mv "$3" "$1_expect.log"
}
ref neon4 neon4_ref ref_mix.log
ref neon5 neon5_ref ref_mix.log
ref neon6 neon6_ref ref_mix.log
ref fp16 fp16_ref ref_mix.log
ref media media_ref_log ref_mix.log
ref neon neon_ref_log ref_mix.log
ref neon2 neon2_ref_log ref2_mix.log
ref neon3 neon3_ref_log ref3_mix.log
ref qc qc_ref qc_ref.log
for t in neon neon2 neon3 neon4 neon5 neon6 media fp16 qc; do
    for m in 0 1 2; do
        rm -f guest_mix.log
        node "$HOSTS/jit_runbin.js" "$GUESTS/${t}_log.bin" $m >/dev/null 2>&1
        cmp -s "${t}_expect.log" guest_mix.log || bad "mix-log $t/$m"
    done
done

# A64 guests (tests/guest64): the same C workloads, checked against the same
# native reference programs.
GUESTS64="$NATIVE/tests/guest64"
if [ -d "$GUESTS64" ]; then
    "$GUESTS/host_ref" | awk '/^stage/{printf "result%s %s\n", substr($1, 6), $2}' > want_test.txt
    echo "result0 $("$GUESTS/fp_ref")" > want_fp.txt
    for t in test test_o3 fp fp_fma; do
        for m in 0 1 2; do
            node "$HOSTS/a64_runbin.js" "$GUESTS64/$t.bin" $m > run.out 2>&1
            grep -q PASS-marker run.out || { bad "a64 $t/$m"; continue; }
            case $t in
            test*) grep -E '^result[0-5] ' run.out | diff -q want_test.txt - >/dev/null || bad "a64 $t/$m checksums" ;;
            fp) grep -E '^result0 ' run.out | diff -q want_fp.txt - >/dev/null || bad "a64 fp/$m checksum" ;;
            fp_fma) grep -E '^result0 ' run.out > "fma_$m.txt"; cmp -s fma_0.txt "fma_$m.txt" || bad "a64 fp_fma/$m differs from mode 0" ;;
            esac
        done
    done
elif [ "$strict" -eq 1 ]; then
    bad "a64 guest programs missing"
fi

# Differential fuzzing against Unicorn (needs: pip install unicorn capstone).
if python3 -c "import unicorn, capstone" 2>/dev/null; then
    for m in 0 1 2; do
        python3 "$ROOT/tests/a64/fuzz.py" --host "$HOSTS/a64_fuzz.js" --count 1500 --seed 7$m --len 4 --mode $m > fuzz.out 2>&1 \
            || { bad "a64 fuzz/$m"; head -20 fuzz.out; }
        # The same inside a loop: self-loop register caching / deferred flags.
        python3 "$ROOT/tests/a64/fuzz.py" --host "$HOSTS/a64_fuzz.js" --count 1000 --seed 8$m --len 6 --loop 3 --mode $m > fuzz.out 2>&1 \
            || { bad "a64 loop fuzz/$m"; head -20 fuzz.out; }
        # Branches inside the loop: multi-block regions.
        python3 "$ROOT/tests/a64/fuzz.py" --host "$HOSTS/a64_fuzz.js" --count 1000 --seed 9$m --len 6 --loop 3 --branches 0.4 --mode $m > fuzz.out 2>&1 \
            || { bad "a64 region fuzz/$m"; head -20 fuzz.out; }
    done
    # A32 / Thumb, straight-line and in loops with branches (regions).
    for m in 0 1 2; do
        for isa in "" --thumb; do
            python3 "$ROOT/tests/a32/fuzz.py" --host "$HOSTS/a32_fuzz.js" --count 1500 --seed 5$m --len 3 --mode $m $isa > fuzz.out 2>&1 \
                || { bad "a32 fuzz$isa/$m"; head -20 fuzz.out; }
            python3 "$ROOT/tests/a32/fuzz.py" --host "$HOSTS/a32_fuzz.js" --count 800 --seed 6$m --len 5 --loop 3 --branches 0.4 --mode $m $isa > fuzz.out 2>&1 \
                || { bad "a32 region fuzz$isa/$m"; head -20 fuzz.out; }
        done
    done
    python3 "$ROOT/tests/fuzz/check_corpus.py" \
        --a32-host "$HOSTS/a32_fuzz.js" --a64-host "$HOSTS/a64_fuzz.js" \
        > corpus.out 2>&1 || { bad checked_in_fuzz_corpus; cat corpus.out; }
else
    echo "skipping a64 / a32 fuzz (python3 -m pip install unicorn capstone)"
    [ "$strict" -eq 1 ] && bad "fuzz dependencies missing"
fi

# Browser example's JIT build on the demo guests (both architectures, all
# memory modes) under Node; the output must match the native build.
if [ -f "$EM/examples/browser/dist/arm_jit.js" ]; then
    node "$ROOT/examples/browser/fault_test.mjs" "$EM/examples/browser" || bad browser_fault_halts
    browser_runs=1
    [ "$strict" -eq 1 ] && browser_runs=3
    node "$ROOT/examples/browser/bench.mjs" "$EM/examples/browser" "$browser_runs" \
        --json browser-benchmark.json > demo.out 2>&1
    node "$ROOT/tests/bench/browser_validate.mjs" browser-benchmark.json >/dev/null \
        || { bad "browser benchmark schema"; cat demo.out; }
    grep -q 'FAIL' demo.out && { bad "browser demo"; cat demo.out; }
    [ "$(grep -c 'PASS' demo.out)" -ge 4 ] || { bad "browser demo (missing results)"; cat demo.out; }
elif [ "$strict" -eq 1 ]; then
    bad "browser example artifact missing"
fi

# External CoreMark is opt-in; an explicitly requested workload must pass.
# Keep its report/failure artifacts outside WORK, including on regression failure.
if [ -n "$coremark" ]; then
    coremark_result="$(mktemp -d)"
    echo "CoreMark evidence: $coremark_result"
    node "$ROOT/tests/bench/coremark/run.mjs" "$EM/examples/browser" "$coremark" \
        --runs "$benchmark_runs" --output "$coremark_result/report.json" || bad coremark_workload
else
    echo "CoreMark not requested (use --coremark WORKLOAD_DIR); application gate not covered"
fi

echo "regression done fail=$fail"
exit $fail
