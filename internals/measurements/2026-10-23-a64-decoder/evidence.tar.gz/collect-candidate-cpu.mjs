import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=process.cwd(), e='/tmp/dynarmic-a64-static-evidence';
const {parseHostOutput}=await import(pathToFileURL(path.join(root,'tests/bench/protocol.mjs')));
const {parseCoremark}=await import(pathToFileURL(path.join(root,'tests/bench/coremark_protocol.mjs')));
const {summarizeCpuProfile}=await import(pathToFileURL(path.join(root,'tests/bench/cpu_profile.mjs')));
const {hashFile,systemInfo}=await import(pathToFileURL(path.join(root,'tests/bench/environment.mjs')));
const dir=path.join(e,'cpu-after');fs.mkdirSync(dir);
const observations=[];
const native=JSON.parse(fs.readFileSync(path.join(e,'production-strict-coremark.json'))).native.metrics;
for(let round=0;round<5;round++) for(const caseName of ['fixed','coremark']) {
 const stem=`${caseName}-${round}`;
 const host=path.join(e,caseName==='fixed'?'named-a64.js':'named-coremark.js');
 const args=caseName==='fixed'?[host,'2']:[path.join(root,'tests/bench/coremark/sample.mjs'),host,'/tmp/dynarmic-coremark-v1-final/coremark_a64.bin','a64','2'];
 const argv=['--cpu-prof','--cpu-prof-interval=100',`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${stem}.cpuprofile`,...args];
 const child=spawnSync(process.execPath,argv,{encoding:'utf8',timeout:60000});
 fs.writeFileSync(path.join(dir,stem+'.stdout'),child.stdout);fs.writeFileSync(path.join(dir,stem+'.stderr'),child.stderr);
 assert.equal(child.status,0,child.stderr);
 let samples;
 if(caseName==='fixed') samples=parseHostOutput(child.stdout);
 else {
  const lines=child.stdout.split('\n').filter(l=>l.startsWith('COREMARK_SAMPLE '));assert.equal(lines.length,1);
  const sample=JSON.parse(lines[0].slice(16));assert.equal(sample.haltReason,0x01000000);
  sample.metrics=parseCoremark(sample.stdout,4000);assert.deepEqual(sample.metrics.crc,native.crc);samples=[sample];
 }
 const file=path.join(dir,stem+'.cpuprofile'), profile=JSON.parse(fs.readFileSync(file));
 const summary=summarizeCpuProfile(profile), compiler=summarizeCpuProfile(profile,'AddressSpace::GetOrEmit');
 fs.writeFileSync(path.join(dir,stem+'.summary.json'),JSON.stringify(summary,null,2));
 fs.writeFileSync(path.join(dir,stem+'.compiler.json'),JSON.stringify(compiler,null,2));
 assert(!profile.nodes.some(n=>n.callFrame.functionName.includes('GetDecodeTable')), 'runtime decode-table initializer survives');
 observations.push({caseName,round,argv,status:child.status,profileSha256:hashFile(file),hostSha256:hashFile(host),wasmSha256:hashFile(host.replace(/\.js$/,'.wasm')),samples,totalSamples:summary.totalSamples,compilerSamples:compiler.selectedSamples});
 fs.writeFileSync(path.join(dir,'observations.json'),JSON.stringify({timestamp:new Date().toISOString(),...systemInfo(),observations},null,2));
}
console.log('PASS candidate CPU profiles: 10 validated runs, no runtime decode-table frame');
