import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const [before, after, workload, output, count = '10'] = process.argv.slice(2);
assert(before && after && workload && output);
const runs = Number(count); assert(Number.isInteger(runs) && runs >= 5);
fs.mkdirSync(output); // Refuse existing cohorts.
const root = process.cwd();
const {summarizeCoremark, validateCoremarkReport} = await import(pathToFileURL(path.join(root, 'tests/bench/coremark_protocol.mjs')));
const {compareCoremark} = await import(pathToFileURL(path.join(root, 'tests/bench/coremark/compare.mjs')));
const files = [[], []], commands = [];
for (let round = 0; round < runs; ++round) for (const side of round % 2 ? [1, 0] : [0, 1]) {
 const file = path.join(output, `${side ? 'after' : 'before'}-${round}.json`);
 const argv = [path.join(root, 'tests/bench/coremark/run.mjs'), path.resolve(side ? after : before), path.resolve(workload), '--runs', '1', '--output', file];
 const r = spawnSync(process.execPath, argv, {encoding: 'utf8', timeout: 300000, maxBuffer: 4 * 1024 * 1024});
 commands.push({argv, status: r.status, signal: r.signal, stdout: r.stdout, stderr: r.stderr});
 fs.writeFileSync(path.join(output, 'commands.json'), JSON.stringify(commands, null, 2));
 assert.equal(r.status, 0, String(r.error || r.stderr || r.signal));
 files[side].push(file);
}
const reports = files.map(group => {
 const reports = group.map(f => JSON.parse(fs.readFileSync(f)));
 reports.forEach(r => validateCoremarkReport(r));
 const merged = structuredClone(reports[0]);
 merged.collection = 'Alternating complete six-case fresh-process cohorts; all rounds retained';
 for (const c of merged.cases) {
  c.runs = runs;
  c.samples = reports.flatMap((r, process) => {
   for (const key of ['node', 'v8', 'runtime', 'host', 'build', 'artifact', 'workloadSha256', 'git']) assert.deepEqual(r[key], merged[key], `changed ${key}`);
   return r.cases.find(item => item.name === c.name).samples.map(s => ({...s, process}));
  });
  c.summary = summarizeCoremark(c.samples, merged.build.profile);
 }
 merged.durationQualified = merged.cases.every(c => c.summary.durationQualified);
 validateCoremarkReport(merged);
 return merged;
});
reports.forEach((r, i) => fs.writeFileSync(path.join(output, i ? 'after.json' : 'before.json'), JSON.stringify(r, null, 2)));
const comparison = compareCoremark(...reports);
fs.writeFileSync(path.join(output, 'comparison.json'), JSON.stringify(comparison, null, 2));
console.log(`CoreMark paired ${comparison.pass ? 'PASS' : 'FAIL'}`);
process.exitCode = comparison.pass ? 0 : 1;
