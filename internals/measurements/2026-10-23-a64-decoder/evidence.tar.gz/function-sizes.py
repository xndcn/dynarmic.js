# Inspect named function-body sizes in a Wasm binary; diagnostic recipe.
import pathlib,json,subprocess,sys
class Reader:
 def __init__(self,data): self.data=data; self.pos=0
 def byte(self):
  n=self.data[self.pos];self.pos+=1;return n
 def uleb(self):
  n=shift=0
  while True:
   b=self.byte();n|=(b&127)<<shift
   if b<128:return n
   shift+=7
   assert shift<64
 def take(self,n):
  assert self.pos+n<=len(self.data)
  data=self.data[self.pos:self.pos+n];self.pos+=n;return data
 def string(self):return self.take(self.uleb()).decode()
for path in sys.argv[1:]:
 raw=pathlib.Path(path).read_bytes();assert raw[:8]==b'\0asm\x01\0\0\0'
 r=Reader(raw[8:]);bodies=[];names={};imports=0
 while r.pos<len(r.data):
  section=r.byte();s=Reader(r.take(r.uleb()))
  if section==2:
   for _ in range(s.uleb()):
    s.string();s.string();kind=s.byte()
    if kind==0: imports+=1;s.uleb()
    elif kind in (1,2):
     if kind==1:s.byte()
     flags=s.uleb();s.uleb()
     if flags&1:s.uleb()
    elif kind==3:s.byte();s.byte()
    else:raise ValueError(f'unsupported import kind {kind}')
  elif section==10:
   for _ in range(s.uleb()):
    size=s.uleb();s.take(size);bodies.append(size)
  elif section==0 and s.string()=='name':
   while s.pos<len(s.data):
    kind=s.byte();sub=Reader(s.take(s.uleb()))
    if kind==1:
     for _ in range(sub.uleb()):
      index=sub.uleb();names[index]=sub.string()
 selected=[]
 for index,size in enumerate(bodies,imports):
  name=names.get(index,'')
  if ('A64AddressSpace' in name and 'GenerateIR' in name) or 'GetDecodeTable' in name:
   demangle=subprocess.run(['c++filt',name],capture_output=True,text=True,check=True).stdout.strip()
   selected.append({'index':index,'bytes':size,'name':demangle})
 print(json.dumps({'file':path,'moduleBytes':len(raw),'importedFunctions':imports,'functions':selected}))
