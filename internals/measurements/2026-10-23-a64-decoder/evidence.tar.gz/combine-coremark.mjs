import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const {summarizeCoremark, validateCoremarkReport}=await import(pathToFileURL(path.resolve('tests/bench/coremark_protocol.mjs')));
const {compareCoremark}=await import(pathToFileURL(path.resolve('tests/bench/coremark/compare.mjs')));
const root='/tmp/dynarmic-a64-static-evidence';
const out=path.join(root,'coremark-combined');fs.mkdirSync(out);
const reports=['before','after'].map(side=>{
 const parts=['paired-coremark','paired-coremark-repeat'].map(d=>JSON.parse(fs.readFileSync(path.join(root,d,side+'.json'))));
 parts.forEach(r=>validateCoremarkReport(r));
 const merged=structuredClone(parts[0]);
 for(const key of ['node','v8','runtime','host','build','artifact','workloadSha256','git','methodology']) assert.deepEqual(parts[0][key],parts[1][key]);
 merged.collection='All 10 initial and 25 follow-up alternating cohorts retained; 35 fresh processes per case';
 for(const c of merged.cases) {
  const other=parts[1].cases.find(k=>k.name===c.name);const offset=c.runs;
  c.samples.push(...other.samples.map(s=>({...s,process:s.process+offset})));c.runs+=other.runs;
  c.summary=summarizeCoremark(c.samples,merged.build.profile);
 }
 merged.durationQualified=merged.cases.every(c=>c.summary.durationQualified);validateCoremarkReport(merged);
 fs.writeFileSync(path.join(out,side+'.json'),JSON.stringify(merged,null,2),{flag:'wx'});return merged;
});
const comparison=compareCoremark(...reports);
fs.writeFileSync(path.join(out,'comparison.json'),JSON.stringify(comparison,null,2),{flag:'wx'});
console.log(JSON.stringify(comparison,null,2));process.exitCode=comparison.pass?0:1;
