#!/bin/bash
set -u
E=/tmp/dynarmic-a64-static-evidence
run() {
    "$@"
    result=$?
    printf '%s %s\n' "$result" "$*" >> "$E/performance-status.log"
    return 0
}
run taskset -c 0,2,4,6 node tests/bench/run.mjs build-em/tests --runs 5 --output "$E/fixed-after.json"
run taskset -c 0,2,4,6 node tests/bench/cache_population_run.mjs build-em/tests --runs 5 --output "$E/population-after.json"
run taskset -c 0,2,4,6 node tests/bench/cache_population_run.mjs build-em-profile/tests --runs 5 --output "$E/population-profile-after.json"
run taskset -c 0,2,4,6 node tests/bench/paired_run.mjs fixed "$E/baseline/tests" build-em/tests "$E/fixed-before.json" "$E/fixed-after.json" "$E/paired-fixed" --runs 25
run taskset -c 0,2,4,6 node tests/bench/paired_run.mjs population "$E/baseline/tests" build-em/tests "$E/population-before.json" "$E/population-after.json" "$E/paired-population" --runs 25
run taskset -c 0,2,4,6 node tests/bench/paired_run.mjs population "$E/baseline-profile/tests" build-em-profile/tests "$E/population-profile-before.json" "$E/population-profile-after.json" "$E/paired-population-profile" --runs 25
run taskset -c 0,2,4,6 node "$E/collect-coremark-paired.mjs" "$E/baseline/examples/browser" build-em/examples/browser /tmp/dynarmic-coremark-v1-final "$E/paired-coremark" 10
