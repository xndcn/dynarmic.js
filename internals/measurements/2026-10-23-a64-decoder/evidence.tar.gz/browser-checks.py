import pathlib,subprocess,socket,tempfile
root=pathlib.Path.cwd()
evidence=pathlib.Path('/tmp/dynarmic-a64-static-evidence')
def port():
 with socket.socket() as s:
  s.bind(('127.0.0.1',0)); return s.getsockname()[1]
for build in ['build-em','build-em-profile']:
 http,debug=port(),port()
 with tempfile.TemporaryDirectory(prefix='a64-static-chrome-') as profile:
  with (evidence/f'{build}-server.log').open('w') as hs,(evidence/f'{build}-chrome-process.log').open('w') as cs:
   server=subprocess.Popen(['python3','-m','http.server',str(http),'--bind','127.0.0.1','-d',str(root/build/'examples/browser/dist')],stdout=hs,stderr=hs)
   chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-gpu',f'--user-data-dir={profile}',f'--remote-debugging-port={debug}','about:blank'],stdout=cs,stderr=cs)
   try:
    with (evidence/f'{build}-chrome.log').open('w') as log:
     subprocess.run(['node','examples/browser/verify_chrome.js',f'http://127.0.0.1:{http}/index.html?auto=1',str(debug)],stdout=log,stderr=subprocess.STDOUT,timeout=150,check=True)
   finally:
    for proc in [chrome,server]:
     proc.terminate()
     try: proc.wait(timeout=10)
     except subprocess.TimeoutExpired: proc.kill();proc.wait()
 with (evidence/f'{build}-firefox.log').open('w') as log:
  subprocess.run(['node','examples/browser/verify_browser.mjs','/usr/bin/firefox',str(root/build/'examples/browser/dist')],stdout=log,stderr=subprocess.STDOUT,timeout=150,check=True)
