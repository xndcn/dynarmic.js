#!/usr/bin/env python3
"""Static flag/command assembly audit. Never invokes a compiler or benchmark."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
from types import SimpleNamespace


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main_body(path):
    tree = ast.parse(path.read_text())
    return next(node.body for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name == "main")


def defaults(path):
    result = {}
    for node in main_body(path):
        if not isinstance(node, ast.Expr) or not isinstance(node.value, ast.Call):
            continue
        call = node.value
        if not isinstance(call.func, ast.Attribute) or call.func.attr != "add_argument" or not call.args:
            continue
        name = ast.literal_eval(call.args[0])
        if not name.startswith("--arm-"):
            continue
        values = {item.arg: ast.literal_eval(item.value) for item in call.keywords
                  if item.arg in {"default", "action"}}
        if "default" in values:
            result[name] = values["default"]
        elif values.get("action") == "store_true":
            result[name] = False
    return result


def model(path, args):
    body = main_body(path)
    nodes, capturing, count = [], False, 0
    for node in body:
        if (isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "common"):
            capturing = True
        if not capturing:
            continue
        nodes.append(node)
        if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name) and node.value.func.id == "run"):
            count += 1
            if count == 3:
                break
    assert count == 3, "Expected ARM compiler, objcopy, Wasm compiler command assembly"
    commands = []
    environment = {
        "args": args, "VERSION": "2025-09-13", "HERE": Path("/repo/examples/quickjs"),
        "source": Path("/shared-cache/quickjs-2025-09-13"), "cache": Path("/shared-cache"),
        "dist": Path("/variant"), "engine_path": Path("/shared-cache/quickjs-2025-09-13/quickjs.c"),
        "ENGINE_FILES": ["quickjs.c", "dtoa.c", "libregexp.c", "libunicode.c", "cutils.c"],
        "arm_cc": "arm-none-eabi-gcc", "emcc": "emcc", "objcopy": "arm-none-eabi-objcopy",
        # These are deliberate substitutes: no compiler, filesystem mutation,
        # source extraction, platform-adaptation code or benchmark is executed.
        "arm_dispatch_source": lambda source, cache, dispatch: source if dispatch == "switch" else cache / "quickjs-arm.c",
        "run": lambda command: commands.append([str(item) for item in command]),
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), environment)
    manifest = next(node.value for node in body if isinstance(node, ast.Assign)
                    and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "manifest")
    flag_node = next(value for key, value in zip(manifest.keys, manifest.values)
                     if isinstance(key, ast.Constant) and key.value == "flags")
    flags = eval(compile(ast.Expression(flag_node), str(path), "eval"), environment)
    return commands, flags


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, default=here / "build-followups.py")
    parser.add_argument("--after", type=Path, default=here / "build-flags-metadata.py")
    parser.add_argument("--output", type=Path, default=here / "command-equivalence.json")
    args = parser.parse_args()
    before_defaults, after_defaults = defaults(args.before), defaults(args.after)
    assert before_defaults == after_defaults
    assert before_defaults["--arm-opt"] == "O2" and before_defaults["--arm-isa"] == "arm"
    combinations = []
    for opt, dispatch, lto, isa, no_gcse, no_cross in itertools.product(
            ["O2", "O3", "Os"], ["switch", "threaded"], [False, True],
            ["arm", "thumb"], [False, True], [False, True]):
        config = dict(arm_opt=opt, arm_dispatch=dispatch, arm_lto=lto,
                      arm_isa=isa, arm_no_gcse=no_gcse, arm_no_crossjumping=no_cross)
        before, old_flags = model(args.before, SimpleNamespace(**config))
        after, new_flags = model(args.after, SimpleNamespace(**config))
        assert before == after, config
        assert old_flags["armEffective"] == new_flags["armEffective"], config
        assert old_flags["wasmEffective"] == new_flags["wasmEffective"], config
        assert not any(flag.startswith("-O") for flag in new_flags["common"])
        assert new_flags["arm"][0] == "-" + opt and new_flags["wasm"][0] == "-O2"
        combinations.append({"configuration": config, "commandsEqual": True,
                             "effectiveFlagsEqual": True,
                             "commandArraysSha256": digest(json.dumps(after, separators=(",", ":")).encode())})
    assert len(combinations) == 96
    report = {
        "schema": "dynarmic.js/quickjs-command-equivalence-v1",
        "verifiedAt": datetime.now(timezone.utc).isoformat(),
        "scope": "Static AST execution of flag/command assembly and manifest flag expressions only",
        "runtimeTest": False, "compilersInvoked": False, "benchmarksRun": False,
        "limitations": "Does not establish runtime correctness or performance. Both archived builders defaulted to O2 and ARM instructions at this check. Later default changes require separate validation.",
        "before": {"path": str(args.before), "sha256": digest(args.before.read_bytes()), "defaults": before_defaults},
        "after": {"path": str(args.after), "originalRepoPath": "examples/quickjs/build.py",
                  "sha256": digest(args.after.read_bytes()), "defaults": after_defaults},
        "scriptSha256": digest(Path(__file__).read_bytes()),
        "configurationCount": len(combinations), "commandArrayCount": len(combinations) * 3,
        "checks": {"everyArgumentAndOrderEqual": True, "effectiveFlagsEqual": True,
                   "commonContainsNoOptimizationLevel": True, "targetFlagsContainCorrectOptimizationLevel": True},
        "configurations": combinations,
    }
    with args.output.open("x") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
    print(f"PASS: {len(combinations)} configurations, 288 command arrays; static equivalence only. Wrote {args.output}")


if __name__ == "__main__":
    main()
